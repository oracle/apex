prompt --application/pages/page_00407
begin
--   Manifest
--     PAGE: 00407
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>407
,p_name=>'REST and Workflow'
,p_alias=>'REST-AND-WORKFLOW'
,p_step_title=>'REST and Workflow'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99778944743901395)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(94274508379483476)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99783829587280127)
,p_plug_name=>'Start Workflow'
,p_title=>'1. Start Workflow'
,p_icon_css_classes=>'fa-number-1'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:t-Alert--accessibleHeading:js-headingLevel-2:t-Form--standardPadding:margin-bottom-sm'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'Please choose a product and launch the workflow'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(100041994919162535)
,p_plug_name=>'Button'
,p_parent_plug_id=>wwv_flow_imp.id(99783829587280127)
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_landmark_type=>'exclude_landmark'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99784673227280135)
,p_plug_name=>'Workflow Console'
,p_title=>'2. Workflow Console'
,p_icon_css_classes=>'fa-number-2'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:t-Alert--accessibleHeading:js-headingLevel-2:t-Form--standardPadding:margin-bottom-md'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'After launching the process you can open the workflow console for more details about the workflow </br>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(100041679067162532)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page demonstrates how to seamlessly integrate Oracle APEX REST Data Sources with Workflow Designer to orchestrate  business processes. ',
' By leveraging the <strong>EBA_REST_PRODUCT_WORKFLOW </strong> REST Data Source, the workflow fetches product details in a GET step and then uses those details to create a new order via a POST step into the <strong>EBA_DEMO_REST_ORDER_WORKFLOW</stron'
||'g> table. ',
'</p>',
' <p>Once the order is successfully created, the workflow sends an email notification to the user and flags the process as Creating Order, showcasing how external APIs can enrich workflow steps without writing low-level integration code. ',
' </p>',
'<strong>Note: </strong> you can inspect each step''s status and payloads by clicking the <strong>Open Workflow Console</strong> button below, illustrating  visibility and control.',
'  '))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99783995581280128)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(100041994919162535)
,p_button_name=>'START_WORKFLOW'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Start Workflow'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99784786868280136)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(99784673227280135)
,p_button_name=>'Open_Workflow_Console'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Open Workflow Console'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:408:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(100041589721162531)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(99778944743901395)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(100041426913162530)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(99778944743901395)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:406:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(99784049899280129)
,p_name=>'P407_WF_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(99783829587280127)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(99784586871280134)
,p_name=>'P407_PRODUCT_ID'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(99783829587280127)
,p_prompt=>'Product Name'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select product_name ',
'  from eba_demo_rest_producttable'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct product_name as display_value,',
'                product_id   as return_value',
'  from eba_demo_rest_producttable',
' where product_name is not null',
' order by product_name;',
''))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99784217521280130)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_WORKFLOW'
,p_process_name=>'Start a new workflow'
,p_attribute_01=>'START'
,p_attribute_02=>wwv_flow_imp.id(99739218066397751)
,p_attribute_04=>'P407_WF_ID'
,p_process_error_message=>'Error'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Workflow started'
,p_internal_uid=>7716596994107023
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(99784272109280131)
,p_page_process_id=>wwv_flow_imp.id(99784217521280130)
,p_workflow_variable_id=>wwv_flow_imp.id(99782119840280109)
,p_page_id=>407
,p_value_type=>'ITEM'
,p_value=>'P407_PRODUCT_ID'
);
wwv_flow_imp.component_end;
end;
/
