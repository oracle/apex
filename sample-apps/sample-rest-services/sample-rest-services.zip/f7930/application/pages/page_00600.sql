prompt --application/pages/page_00600
begin
--   Manifest
--     PAGE: 00600
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>600
,p_name=>'Help'
,p_alias=>'HELP1'
,p_step_title=>'Help'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_required_patch=>wwv_flow_imp.id(94279328512483503)
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105130608397418354)
,p_plug_name=>'Help Container'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105130773792418355)
,p_plug_name=>'About this application'
,p_parent_plug_id=>wwv_flow_imp.id(105130608397418354)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div>',
'  <h2>About This Application</h2>',
'  <p>',
'   This application demonstrates seamless integration of external REST services with Oracle APEX. It leverages diverse REST data sources, including ORDS, OData, simple HTTP, and custom plugins. Advanced PL/SQL processes handle data transformation, va'
||'lidation, and error management. Dynamic interactive reporting and Oracle JET visualizations display insights. The app synchronizes external data into local tables to ensure robust performance. Overall, it exemplifies a modern, scalable approach to in'
||'tegrating REST services within Oracle APEX.',
'  </p>',
'</div>',
''))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105130883971418356)
,p_plug_name=>'Quick Start'
,p_parent_plug_id=>wwv_flow_imp.id(105130608397418354)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<H2>Getting Started</h2>',
'<p>Make sure that the APEX engine can connect to the APEX server via HTTP. A <i>Network ACL</i> is needed. Have a look into the APEX Installation Guide - chapter "Enabling Network Services in Oracle Database 11g or Later" for more information.</p>',
'<p>Run the application as a developer; at the bottom of the page will be buttons for viewing the page in the APEX Application Builder. Click on the "Edit Page X" button to see how the pages are defined.</p>',
'',
'<p>If you have questions, ask them on the <a href="https://forums.oracle.com/ords/apexds/domain/dev-community/category/apex" target="_blank">Oracle APEX Forum</a>.</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105130936574418357)
,p_plug_name=>'Features'
,p_parent_plug_id=>wwv_flow_imp.id(105130608397418354)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h2>Features</h2>',
'<p>',
'    <ul>',
'        <li><b>Multiple REST Data Source Types</b> Simple HTTP, ORDS, OData, Custom Plugin</li>',
'        <li><b>Data Profiles</b> Mapping JSON responses to columns & Handling nested JSON responses </li>',
'        <li><b>Data Synchronization</b> Importing and synchronizing external REST data into local Oracle tables </li>',
'        <li><b>Advanced PL/SQL Processing and Business Logic</b> Writing custom PL/SQL code for complex operations beyond simple declarative data binding </li>',
'        <li><b>Data Display Options</b> Interactive Reporting and Visualization</li>',
'        <li><b>Error Handling and Debugging </b>Robust Error Handling in PL/SQL,User-Friendly Notifications & Debug Mode Activation</li>',
'  </ul>',
'</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(105131008687418358)
,p_name=>'Application information'
,p_template=>4072358936313175081
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'t-HeroRegion--featured'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--rightAligned'
,p_new_grid_row=>false
,p_grid_column_span=>3
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select aa.version app_version,',
'       to_char(aa.pages,''999G999G990'') pages,',
'       ''Oracle'' vendor',
'  from apex_applications aa',
' where aa.application_id = :APP_ID'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99560914552142814)
,p_query_column_id=>1
,p_column_alias=>'APP_VERSION'
,p_column_display_sequence=>10
,p_column_heading=>'App Version'
,p_use_as_row_header=>'Y'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99560097405142814)
,p_query_column_id=>2
,p_column_alias=>'PAGES'
,p_column_display_sequence=>20
,p_column_heading=>'Pages'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99560432640142814)
,p_query_column_id=>3
,p_column_alias=>'VENDOR'
,p_column_display_sequence=>30
,p_column_heading=>'Vendor'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp.component_end;
end;
/
