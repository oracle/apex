prompt --application/pages/page_00301
begin
--   Manifest
--     PAGE: 00301
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>301
,p_name=>'REST Endpoint Status'
,p_alias=>'REST-ENDPOINTS-STATUS'
,p_step_title=>'REST Endpoint Status'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'LEORODRI'
,p_last_upd_yyyymmddhh24miss=>'20220927000252'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(59629230228443785)
,p_name=>'REST Endpoint Test Results'
,p_template=>wwv_flow_imp.id(3590559686829398335)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Cards--featured force-fa-lg:t-Cards--displayIcons:t-Cards--3cols:t-Cards--animColorFill'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NAME as card_title,',
'       URL,',
'       LAST_STATUS,',
'       case ',
'           when last_status is null then ''fa-question''',
'           when last_status = ''OK'' then ''fa-check''',
'           else ''fa-exception''',
'       end as card_icon,',
'       case  ',
'           when last_status is null then ''u-color-29''',
'           when last_status = ''OK'' then ''u-color-35''',
'           else ''u-color-39'' ',
'       end as card_color,',
'       case  ',
'           when last_status=''OK'' then ''OK''',
'           when last_status=''ERROR_ACL'' then ''Network Access Control List (ACL)''',
'           when last_status=''ERROR_CERT'' then ''SSL Certificate error (Wallet)''',
'           when last_status=''ERROR_NETWORK'' then ''Networking issue (e.g. Proxy Server)''',
'           when last_status like ''ERROR_HTTP%'' then ''HTTP Error '' || substr( last_status, 12 )',
'           when last_status like ''ERROR_OTHER%'' then ''Other Error: '' || substr( last_status, 13 )',
'           else ''Other Error''',
'       end as card_text,',
'       url as card_subtext',
'  from EBA_RESTDEMO_SAMPLE_URLS',
' where name != ''ORDS EMP'''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3590566118689398355)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(60371917204838270)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>3
,p_column_heading=>'Card title'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(60371369137838264)
,p_query_column_id=>2
,p_column_alias=>'URL'
,p_column_display_sequence=>1
,p_column_heading=>'Url'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(60371373006838265)
,p_query_column_id=>3
,p_column_alias=>'LAST_STATUS'
,p_column_display_sequence=>2
,p_column_heading=>'Last status'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(60372038350838271)
,p_query_column_id=>4
,p_column_alias=>'CARD_ICON'
,p_column_display_sequence=>4
,p_column_heading=>'Card icon'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(60372167912838272)
,p_query_column_id=>5
,p_column_alias=>'CARD_COLOR'
,p_column_display_sequence=>5
,p_column_heading=>'Card color'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(60372375352838275)
,p_query_column_id=>6
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>7
,p_column_heading=>'Card text'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(60372320248838274)
,p_query_column_id=>7
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>6
,p_column_heading=>'Card subtext'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(60372501831838276)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2940025268357922268)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page contains test results for the REST endpoint URLs used in this application. Test results are being stored in a local table. Click the <strong>Test Endpoints</strong> button to execute the test. Failure in accessing the endpoint URLs can h'
||'ave the following reasons.',
'</p>',
'<ul>',
'<li><strong>Missing Network Connectivity</strong><br>',
'    The database server has either no connection to the internet or is behind a firewall. Set a proxy server either at the',
'    application level (in Shared Components) or at the Application Express instance level.</li>',
'<li><strong>Certificate Validation Errors</strong></br>',
'    When the database cannot verify the server certificate of an HTTPS endpoint, the service cannot be accessed. In that case,',
'    the CA certificate must be added to the database wallet and the wallet must be configured in Application Express. See',
'    <a href="https://blogs.oracle.com/apex/apex-https-certificates-and-the-oracle-wallet" target="_blank">"APEX, HTTPS, certificates and the Oracle Wallet"</a> for more information.</li>',
'<li><strong>Network Access Control List</strong><br>',
'    The APEX Engine User (e.g. APEX_190100) is not allowed to perform outbound HTTP requests. A <em>PL/SQL Network ACL</em> must be',
'    configured in the database in order to allow requests the service endpoints.</li>',
'</ul>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(60393966434883724)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3590562262097398340)
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3134375712591842148)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3590583130937398425)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(60371558969838266)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(60393966434883724)
,p_button_name=>'TEST'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3590583018639398423)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Test Endpoints'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(60371712359838268)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Test Endpoints'
,p_process_sql_clob=>'eba_restdemo_sample_pkg.test_all;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(60371558969838266)
,p_process_success_message=>'URL Endpoints tested. '
);
wwv_flow_imp.component_end;
end;
/
