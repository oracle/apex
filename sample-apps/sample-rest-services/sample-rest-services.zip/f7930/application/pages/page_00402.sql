prompt --application/pages/page_00402
begin
--   Manifest
--     PAGE: 00402
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>402
,p_name=>'Invoke API Process'
,p_alias=>'INVOKE-API-PROCESS1'
,p_step_title=>'Invoke API Process'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(103034668051635879)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    This page demonstrates how to use the <strong>Invoke API</strong> page process with the  ',
'    <strong>PUT</strong> operation of a REST Data Source. Clicking the <strong>Raise Salary</strong> ',
'    button will open a dialog which allows to enter a new <em>Salary</em> value; and to submit',
'    the change to a REST API.',
'</p>',
''))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(103296719754565764)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(94274508379483476)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(103951476716663671)
,p_plug_name=>'Employees Data'
,p_region_name=>'empIR'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>30
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(96620419708252440)
,p_query_type=>'SQL'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(103951592012663672)
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'AHMAMED'
,p_internal_uid=>11883971485490565
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103952098817663677)
,p_db_column_name=>'EMPNO'
,p_display_order=>10
,p_column_identifier=>'E'
,p_column_label=>'Employee Number'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103952207605663678)
,p_db_column_name=>'ENAME'
,p_display_order=>20
,p_column_identifier=>'F'
,p_column_label=>'Employee'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'Y'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103951680544663673)
,p_db_column_name=>'JOB'
,p_display_order=>30
,p_column_identifier=>'A'
,p_column_label=>'Job'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103951750258663674)
,p_db_column_name=>'MGR'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Manager'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103951878746663675)
,p_db_column_name=>'SAL'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Salary'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103951977021663676)
,p_db_column_name=>'COMM'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Commission'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103952384647663680)
,p_db_column_name=>'HIREDATE'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Hiredate'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103952298608663679)
,p_db_column_name=>'DEPTNO'
,p_display_order=>100
,p_column_identifier=>'G'
,p_column_label=>'Department'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(103969868354206691)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'45757'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EMPNO:ENAME:JOB:SAL:HIREDATE:MGR:COMM:DEPTNO:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98353879174089845)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(103296719754565764)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:404:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98353723211089844)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(103296719754565764)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:401:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99398131456485071)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(103951476716663671)
,p_button_name=>'Raise_Salary'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Raise Salary'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:403:&SESSION.::&DEBUG.:403::'
,p_icon_css_classes=>'fa-compass'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104068008580777300)
,p_name=>'P402_STATUS'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104623145748123301)
,p_name=>'P402_MESSAGE'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99400496705485073)
,p_name=>'Capture Status Value '
,p_event_sequence=>20
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99401012456485073)
,p_event_id=>wwv_flow_imp.id(99400496705485073)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P402_STATUS'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P403_STATUS'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99402252544485074)
,p_name=>'Capture Message Value'
,p_event_sequence=>30
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99402781078485074)
,p_event_id=>wwv_flow_imp.id(99402252544485074)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P402_MESSAGE'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P403_MESSAGE'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99401396878485073)
,p_name=>'Success Message Display'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P402_MESSAGE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99401865729485074)
,p_event_id=>wwv_flow_imp.id(99401396878485073)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var ordsStatus   = apex.item("P402_STATUS").getValue(),',
'    ordsResponse = apex.item("P402_MESSAGE").getValue();',
'',
'',
'try {',
' ',
'  switch (parseInt(ordsStatus)) {',
'    case 200:',
'      apex.message.showPageSuccess(apex.lang.formatMessage(''P402.DA.ORDS.RESPONSE'', ordsResponse));  ',
'      apex.region("empIR").refresh();',
'      break;',
'',
'    case 400:',
'      apex.message.showErrors([',
'        {',
'          type: "error",',
'          location: ["inline", "page"],',
'          message: apex.lang.formatMessage(''P402.DA.ORDS.RESPONSE'', ordsResponse) ,',
'          unsafe: false',
'        }',
'      ]);',
'      break;',
'    case 401:',
'      apex.debug.error(ordsResponse);',
'      apex.message.showErrors([',
'        {',
'          type: "error",',
'          location: ["inline", "page"],',
'          message: apex.lang.formatMessage(''P402.DA.UNAUTHORIZED.MSG''),',
'          unsafe: false',
'        }',
'      ]);',
'      break;',
'    case 403:',
'      apex.debug.error(ordsResponse);',
'      apex.message.showErrors([',
'        {',
'          type: "error",',
'          location: ["inline", "page"],',
'          message: apex.lang.formatMessage(''P402.DA.FORBIDDEN.MSG''),',
'          unsafe: false',
'        }',
'      ]);',
'      break;',
'    case 404:',
'      apex.debug.error(ordsResponse);',
'      apex.message.showErrors([',
'        {',
'          type: "error",',
'          location: ["inline", "page"],',
'          message: apex.lang.formatMessage(''P402.DA.NOTFOUND.MSG''),',
'          unsafe: false',
'        }',
'      ]);',
'      break;',
'    case 500:',
'      apex.debug.error(ordsResponse);',
'      apex.message.showErrors([',
'        {',
'          type: "error",',
'          location: ["inline", "page"],',
'          message: apex.lang.formatMessage(''P402.DA.SERVEREERR.MSG''),',
'          unsafe: false',
'        }',
'      ]);',
'      break;',
'    default:',
'      apex.debug.error(ordsResponse);',
'      apex.message.showErrors([',
'        {',
'          type: "error",',
'          location: ["inline", "page"],',
'          message: apex.lang.formatMessage(''P402.DA.UNEXPECTEDERR.MSG''),',
'          unsafe: false',
'        }',
'      ]);',
'      break;',
'  }',
'} catch (e) {',
'  apex.message.showErrors([',
'    {',
'      type: "error",',
'      location: ["inline", "page"],',
'      message: apex.lang.formatMessage("P402.DA.ERROR.MSG", e.message),',
'      unsafe: false',
'    }',
'  ]);',
'}',
''))
);
wwv_flow_imp.component_end;
end;
/
