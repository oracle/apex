prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Connection Setup'
,p_alias=>'CONNECTION-SETUP'
,p_step_title=>'Connection Setup'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2979075366320325194
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_comment=>'Use this items on this page to configure the app.'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(98354529967089852)
,p_plug_name=>'3. Proxy Setup'
,p_title=>'Proxy Setup'
,p_icon_css_classes=>'fa-number-3'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:margin-bottom-md'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'not apex_application_global.g_cloud'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105148837260543437)
,p_plug_name=>'1. Remote Server Setup'
,p_title=>'Remote Server Setup'
,p_icon_css_classes=>'fa-number-1'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:margin-bottom-md'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br/>',
'<p>Enter here your remote server Base URL and Schema Alias </p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105150824400543457)
,p_plug_name=>'Remote Server Setup Guide'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105863336262184626)
,p_plug_name=>'Welcome to Sample REST Services'
,p_parent_plug_id=>wwv_flow_imp.id(105150824400543457)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Please take a moment to complete this first time setup.',
''))
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105863391727184627)
,p_plug_name=>'Guide'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'The Sample REST Services application is a comprehensive Oracle APEX REST Data integration and visualization demo, showcasing how APEX can efficiently consume, manipulate, and display data from RESTful services using components like Reports, Forms, Ch'
||'arts, Maps or others. It serves as a reference application for exploring various techniques for integrating external REST APIs with Oracle APEX, handling data dynamically, and enhancing user experience with different presentation formats.',
'</p><p>To  get started, please configure the following settings.</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105863460360184628)
,p_plug_name=>'Button Remote Server'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>60
,p_location=>null
,p_landmark_type=>'exclude_landmark'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105863858365184631)
,p_plug_name=>'2. OData URL Setup'
,p_title=>'OData URL Setup'
,p_icon_css_classes=>'fa-number-2'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:margin-bottom-md'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br/>',
'<p>Enter the URL of a working OData endpoint returning "Northwind" data</p>',
''))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99581510773267925)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(105863460360184628)
,p_button_name=>'Complete_Setup'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Complete Setup'
,p_button_position=>'CHANGE'
,p_icon_css_classes=>'fa-check-circle'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(99586265981267930)
,p_branch_name=>'Move to home page'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'REMOTE_SERVER'
,p_branch_condition_text=>'YES'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98354633060089853)
,p_name=>'P2_PROXY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(98354529967089852)
,p_prompt=>'Proxy  Server'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_protection_level=>'S'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    <p>',
'    Use this field to specify a proxy server to be used by the application.',
'    Using a proxy server may be required for REST requests done by the application, for instance when REST Data Sources or the APEX_WEB_SERVICE package is used.',
'    ',
'    </p>',
'',
'    <p>',
'        Example: http://www-proxy.example.com',
'    </p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105152308574543444)
,p_name=>'P2_BASE_URL'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(105148837260543437)
,p_item_default=>'apex_util.host_url(''APEX_PATH'');'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Base URL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--indicatorAsterisk:t-Form-fieldContainer--xlarge'
,p_protection_level=>'S'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'   <p>The <strong>Base URL</strong> is the portion of your ORDS URL that includes the protocol, host, port (if applicable), and the path up to (and including) <code>/ords/</code>. It does not include the schema or workspace name.</p>',
'   <p>Examples:</p>',
'   <ul>',
'      <li><strong>Dev Instance:</strong> For example: <code>http://yourserver.example.com:8084/ords/</code></li>',
'      <li><strong>apex.oracle.com:</strong> For example: <code>https://apex.oracle.com/pls/apex/</code></li>',
'   </ul>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105152396687543445)
,p_name=>'P2_SCHEMA'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(105148837260543437)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select lower(path_prefix)',
'  from apex_workspaces',
' where workspace_id = v(''workspace_id'');'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Schema Alias '
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--indicatorAsterisk:t-Form-fieldContainer--xlarge'
,p_protection_level=>'S'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'   <p>The <strong>Schema</strong> is the workspace or schema name that appears in your ORDS URL immediately after <code>/ords/</code>. Examples:</p>',
'   <ul>',
unistr('      <li><strong>Internal Instance:</strong> If your full URL is: <code>http://yourserver.example.com:8084/ords/r/myworkspace/\2026</code>, then the Schema is <em>myworkspace</em>.</li>'),
'      <li><strong>apex.oracle.com:</strong> If your URL is: <code>https://apex.oracle.com/pls/apex/workspace/</code>, then the Schema is <em>workspace</em>.</li>',
'   </ul>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105866509430184636)
,p_name=>'P2_ODATA_URL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(105863858365184631)
,p_item_default=>'apex_app_setting.get_value(p_name =>''ODATA_URL'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'OData Endpoint URL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_protection_level=>'S'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Please enter the URL of a valid OData endpoint that provides "Northwind" data</p> </br>',
'Example: <em>https://ODataBaseUrl/version/Northwind/</em>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(99584691230267929)
,p_validation_name=>'P2_BASE_URL not null'
,p_validation_sequence=>10
,p_validation=>'P2_BASE_URL'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_associated_item=>wwv_flow_imp.id(105152308574543444)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(99585032531267929)
,p_validation_name=>'P2_SCHEMA is not null'
,p_validation_sequence=>20
,p_validation=>'P2_SCHEMA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_associated_item=>wwv_flow_imp.id(105152396687543445)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99585817529267929)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Persist User Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'    apex_app_setting.set_value(''REMOTE_SERVER_BASE_URL'', :P2_BASE_URL);',
'    apex_app_setting.set_value(''REMOTE_SERVER_SCHEMA_ALIAS'', :P2_SCHEMA);',
'    apex_app_setting.set_value(''ODATA_URL'', :P2_ODATA_URL);',
'    apex_app_setting.set_value(''REMOTE_SERVER_INITIALIZED'', ''YES'');',
'    :REMOTE_SERVER := ''YES'';',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error while setup the connection.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(99581510773267925)
,p_process_success_message=>'Connection setup successfully.'
,p_internal_uid=>7518197002094822
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(98354791771089854)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Proxy'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   if :P2_PROXY is not null and not apex_application_global.g_cloud then',
'      apex_application_admin.set_proxy_server(',
'         p_application_id => v(''app_id''),',
'         p_proxy_server   => :P2_PROXY',
'      );',
'   end if;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6287171243916747
);
wwv_flow_imp.component_end;
end;
/
