prompt --application/pages/page_00223
begin
--   Manifest
--     PAGE: 00223
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>223
,p_name=>'PL/SQL Access'
,p_alias=>'PL-SQL-ACCESS'
,p_step_title=>'PL/SQL Access'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
,p_last_updated_by=>'LEORODRI'
,p_last_upd_yyyymmddhh24miss=>'20220927000659'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50609423182171549)
,p_plug_name=>'EBA_RESTDEMO_SAMPLE_GITHUB table'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3590558140460398328)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>'select * from eba_restdemo_sample_github'
,p_plug_source_type=>'NATIVE_IG'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(59628081486443774)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(59628260551443775)
,p_name=>'LANGUAGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LANGUAGE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Language'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(59628345406443776)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Description'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(59628460266443777)
,p_name=>'UPDATED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPDATED_ON'
,p_data_type=>'TIMESTAMP'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>'Updated on'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'CENTER'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_format_mask=>'mm/dd/yyyy hh24:mi:ss'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(59628529287443778)
,p_name=>'CREATED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_ON'
,p_data_type=>'TIMESTAMP'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>'Created on'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'CENTER'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_format_mask=>'mm/dd/yyyy hh24:mi:ss'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(59628604538443779)
,p_name=>'ISSUES_CNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ISSUES_CNT'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Issues cnt'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>90
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(59628737788443780)
,p_name=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROWID'
,p_data_type=>'ROWID'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(59628786763443781)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_enable_hide=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(59628960078443782)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
,p_enable_hide=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(59627975865443773)
,p_internal_uid=>57117106489764432
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_max_row_count=>100000
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(59913034596610954)
,p_interactive_grid_id=>wwv_flow_imp.id(59627975865443773)
,p_static_id=>'14581'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(59913076147610954)
,p_report_id=>wwv_flow_imp.id(59913034596610954)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(59913613873610959)
,p_view_id=>wwv_flow_imp.id(59913076147610954)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(59628081486443774)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(59914049133610964)
,p_view_id=>wwv_flow_imp.id(59913076147610954)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(59628260551443775)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(59914549077610966)
,p_view_id=>wwv_flow_imp.id(59913076147610954)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(59628345406443776)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(59914992163610967)
,p_view_id=>wwv_flow_imp.id(59913076147610954)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(59628460266443777)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(59915509437610968)
,p_view_id=>wwv_flow_imp.id(59913076147610954)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(59628529287443778)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(59916000475610970)
,p_view_id=>wwv_flow_imp.id(59913076147610954)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(59628604538443779)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(59917071840612660)
,p_view_id=>wwv_flow_imp.id(59913076147610954)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(59628737788443780)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(59917636399612662)
,p_view_id=>wwv_flow_imp.id(59913076147610954)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(59628786763443781)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50611598463171571)
,p_plug_name=>'PL/SQL Code'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3590555680698398324)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'<pre>',
'declare',
'    l_context     apex_exec.t_context;',
'    l_filters     apex_exec.t_filters;',
'    l_columns     apex_exec.t_columns;',
'     ',
'    l_name_idx    pls_integer;',
'    l_lang_idx    pls_integer;',
'    l_desc_idx    pls_integer;',
'    l_upd_idx     pls_integer;',
'    l_cr_idx      pls_integer;',
'    l_issues_idx  pls_integer;',
'begin',
'    apex_exec.add_column( p_columns => l_columns, p_column_name => ''NAME'' );',
'    apex_exec.add_column( p_columns => l_columns, p_column_name => ''LANGUAGE'' );',
'    apex_exec.add_column( p_columns => l_columns, p_column_name => ''DESCRIPTION'' );',
'    apex_exec.add_column( p_columns => l_columns, p_column_name => ''UPDATED_AT'' );',
'    apex_exec.add_column( p_columns => l_columns, p_column_name => ''CREATED_AT'' );',
'    apex_exec.add_column( p_columns => l_columns, p_column_name => ''OPEN_ISSUES_COUNT'' );',
'',
'    l_context := apex_exec.open_web_source_query(',
'        p_module_static_id  => ''Sample_Application_Github_Repositories'',',
'        p_columns           => l_columns,',
'        p_max_rows          => 1000 );',
'',
'    l_name_idx   := apex_exec.get_column_position( l_context, ''NAME'' );',
'    l_lang_idx   := apex_exec.get_column_position( l_context, ''LANGUAGE'' );',
'    l_desc_idx   := apex_exec.get_column_position( l_context, ''DESCRIPTION'' );',
'    l_upd_idx    := apex_exec.get_column_position( l_context, ''UPDATED_AT'' );',
'    l_cr_idx     := apex_exec.get_column_position( l_context, ''CREATED_AT'' );',
'    l_issues_idx := apex_exec.get_column_position( l_context, ''OPEN_ISSUES_COUNT'' );',
'',
'    while apex_exec.next_row( l_context ) loop',
'',
'        insert into eba_restdemo_sample_github values (',
'            apex_exec.get_varchar2    ( l_context, l_name_idx ), ',
'            apex_exec.get_varchar2    ( l_context, l_lang_idx ), ',
'            apex_exec.get_varchar2    ( l_context, l_desc_idx ), ',
'            apex_exec.get_timestamp_tz( l_context, l_upd_idx ), ',
'            apex_exec.get_timestamp_tz( l_context, l_cr_idx ), ',
'            apex_exec.get_number      ( l_context, l_issues_idx ));',
'',
'    end loop;',
'    ',
'    apex_exec.close( l_context );',
'exception',
'    when others then',
'    apex_exec.close( l_context );',
'    raise;    ',
'end;',
'</pre>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50611689662171572)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2940025268357922268)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'Github repository count for <strong>Oracle</strong>: &P223_REPO_CNT.',
'</p></p>',
'This page illustrates how to use an existing Web Source Module with PL/SQL and the <strong>APEX_EXEC</strong> package. When the <strong>Download</strong> button is clicked, the <strong>EBA_RESTDEMO_SAMPLE_GITHUB</strong> table is being populated with'
||' data from the Web Source Module. The Interactive Grid below works on that local table, data can thus be edited.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(51649168560779752)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3590562262097398340)
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3134375712591842148)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3590583130937398425)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(50611928786171574)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(51649168560779752)
,p_button_name=>'Clear'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3590583018639398423)
,p_button_image_alt=>'Clear'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(50610954948171564)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(51649168560779752)
,p_button_name=>'Download'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3590583018639398423)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Download'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(50609261360171547)
,p_name=>'P223_REPO_CNT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(50611598463171571)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(50611009748171565)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Download REST Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_context     apex_exec.t_context;',
'    l_filters     apex_exec.t_filters;',
'    l_columns     apex_exec.t_columns;',
'     ',
'    l_name_idx    pls_integer;',
'    l_lang_idx    pls_integer;',
'    l_desc_idx    pls_integer;',
'    l_upd_idx     pls_integer;',
'    l_cr_idx      pls_integer;',
'    l_issues_idx  pls_integer;',
'begin',
'    delete from eba_restdemo_sample_github;',
'',
'    apex_exec.add_column( p_columns => l_columns, p_column_name => ''NAME'' );',
'    apex_exec.add_column( p_columns => l_columns, p_column_name => ''LANGUAGE'' );',
'    apex_exec.add_column( p_columns => l_columns, p_column_name => ''DESCRIPTION'' );',
'    apex_exec.add_column( p_columns => l_columns, p_column_name => ''UPDATED_AT'' );',
'    apex_exec.add_column( p_columns => l_columns, p_column_name => ''CREATED_AT'' );',
'    apex_exec.add_column( p_columns => l_columns, p_column_name => ''OPEN_ISSUES_COUNT'' );',
'',
'    l_context := apex_exec.open_web_source_query(',
'        p_module_static_id  => ''Sample_Application_Github_Repositories'',',
'        p_columns           => l_columns,',
'        p_max_rows          => 1000 );',
'',
'    l_name_idx   := apex_exec.get_column_position( l_context, ''NAME'' );',
'    l_lang_idx   := apex_exec.get_column_position( l_context, ''LANGUAGE'' );',
'    l_desc_idx   := apex_exec.get_column_position( l_context, ''DESCRIPTION'' );',
'    l_upd_idx    := apex_exec.get_column_position( l_context, ''UPDATED_AT'' );',
'    l_cr_idx     := apex_exec.get_column_position( l_context, ''CREATED_AT'' );',
'    l_issues_idx := apex_exec.get_column_position( l_context, ''OPEN_ISSUES_COUNT'' );',
'',
'    while apex_exec.next_row( l_context ) loop',
'',
'        insert into eba_restdemo_sample_github values (',
'            apex_exec.get_varchar2    ( l_context, l_name_idx ), ',
'            apex_exec.get_varchar2    ( l_context, l_lang_idx ), ',
'            apex_exec.get_varchar2    ( l_context, l_desc_idx ), ',
'            apex_exec.get_timestamp_tz( l_context, l_upd_idx ), ',
'            apex_exec.get_timestamp_tz( l_context, l_cr_idx ), ',
'            apex_exec.get_number      ( l_context, l_issues_idx ));',
'',
'    end loop;',
'    ',
'    apex_exec.close( l_context );',
'exception',
'    when others then',
'    apex_exec.close( l_context );',
'    raise;    ',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(50610954948171564)
,p_process_success_message=>'Github Repository Information downloaded from REST Service.'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(50612067643171575)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Clear local table'
,p_process_sql_clob=>'delete from eba_restdemo_sample_github;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(50611928786171574)
,p_process_success_message=>'Local data deleted.'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59628987896443783)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(50609423182171549)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'EBA_RESTDEMO_SAMPLE_GITHUB table - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(50609281728171548)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Repo Count'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(*) into :P223_REPO_CNT',
'  from table( eba_restdemo_sample_pkg.get_github_repos );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
