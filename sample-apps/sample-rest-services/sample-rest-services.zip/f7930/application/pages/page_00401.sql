prompt --application/pages/page_00401
begin
--   Manifest
--     PAGE: 00401
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>401
,p_name=>'REST Synchronization'
,p_alias=>'REST-SYNCHRONIZATION'
,p_step_title=>'REST Synchronization'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16434744680414720)
,p_plug_name=>'API key Not  Provided'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>'This page relies on a REST Data Source. You need to provide your own API key for <strong>themoviedb.org</strong>. Go to administration and set your own api key in the Manage web credentials page'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'apex_app_setting.get_value(''TMDB_APIKEY'') = ''NO'''
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99392747446460888)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(94274508379483476)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99735585516397715)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div >',
'  <p>',
'    This page demonstrates the integration of external RESTful data with local database tables, emphasizing the efficiency and flexibility of data synchronization.    The page utilizes a REST Data Source named <strong>EBA_REST_MOVIE_SYNCHRONIZATION</'
||'strong> to fetch data from an external movie database API.',
'',
'  </p>',
'  <p>',
'    This data is synchronized into a local table, <strong>EBA_DEMO_REST_MOVIES_SYNC</strong>, ensuring that the application benefits from faster data access and reduced latency.    By configuring the interactive report to use the synchronized table, '
||'the application achieves improved performance, especially when handling large datasets.',
'',
'  </p>',
'',
'  <p>',
'    <strong>Note: </strong> The <strong>Synchronize Data</strong> button on the page invokes the <strong>APEX_REST_SOURCE_SYNC.SYNCHRONIZE_DATA</strong> API, allowing users to refresh the local data on-demand.',
'    This approach ensures that the interactive report always displays the most up-to-date information without relying solely on scheduled synchronizations.',
'  </p>',
'</div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99735673039397716)
,p_plug_name=>'Synchronization Results'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(99758843148949282)
,p_use_local_sync_table=>true
,p_query_type=>'SQL'
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_app_setting.get_value(''TMDB_APIKEY'') =  ''YES''',
'and exists (',
'  select 1',
'    from sys.user_tables',
'   where table_name = ''EBA_DEMO_REST_MOVIES_SYNC''',
');'))
,p_plug_display_when_cond2=>'SQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(99735734420397717)
,p_no_data_found_message=>'Table contains no data yet. Please click the Synchronize Data button.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'AHMAMED'
,p_internal_uid=>7668113893224610
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99735884586397718)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99735923602397719)
,p_db_column_name=>'ADULT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Adult'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99736084203397720)
,p_db_column_name=>'TITLE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Title'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'Y'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99736166980397721)
,p_db_column_name=>'VIDEO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Video'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99736240856397722)
,p_db_column_name=>'OVERVIEW'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Overview'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99736356300397723)
,p_db_column_name=>'GENRE_IDS'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Genre Ids'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99736505262397724)
,p_db_column_name=>'POPULARITY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Popularity'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99736603710397725)
,p_db_column_name=>'VOTE_COUNT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Vote Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99736712148397726)
,p_db_column_name=>'POSTER_PATH'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Poster Path'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99736721834397727)
,p_db_column_name=>'RELEASE_DATE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Release Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99736832293397728)
,p_db_column_name=>'VOTE_AVERAGE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Vote Average'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99736941869397729)
,p_db_column_name=>'BACKDROP_PATH'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Backdrop Path'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99737097177397730)
,p_db_column_name=>'ORIGINAL_TITLE'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Original Title'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99737140489397731)
,p_db_column_name=>'ORIGINAL_LANGUAGE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Original Language'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(99769911647035059)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'77023'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:ADULT:TITLE:VIDEO:OVERVIEW:GENRE_IDS:POPULARITY:VOTE_COUNT:POSTER_PATH:RELEASE_DATE:VOTE_AVERAGE:BACKDROP_PATH:ORIGINAL_TITLE:ORIGINAL_LANGUAGE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(100799219846345241)
,p_plug_name=>'Synchronization Table Doesnt Exists'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>'REST Synchronization requires a local table to exist, so please click the <strong>Create Table</strong> button to create it.'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_app_setting.get_value(''TMDB_APIKEY'') =  ''YES''',
'and not exists (',
'  select 1',
'    from sys.user_tables',
'   where table_name = ''EBA_DEMO_REST_MOVIES_SYNC''',
')'))
,p_plug_display_when_cond2=>'SQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16434789932414721)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(16434744680414720)
,p_button_name=>'Set_API_Key'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Set API Key'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:503:&SESSION.::&DEBUG.::P304_SOURCE:401'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(100799247267345242)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(100799219846345241)
,p_button_name=>'Create_Table'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Table'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98353643487089843)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(99392747446460888)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:402:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98353555743089842)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(99392747446460888)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99737377839397733)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(99735673039397716)
,p_button_name=>'Synchronize_Data'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Synchronize Data'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99737468115397734)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Trigger Synchronization'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_rest_source_sync.synchronize_data(',
'        p_module_static_id   => ''eba_rest_movie_synchronization'',',
'        p_run_in_background  => false,',
'        p_application_id     => :APP_ID',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error while triggering synchronization.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(99737377839397733)
,p_process_success_message=>'Data synchronized successfully.'
,p_internal_uid=>7669847588224627
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(100799080480345240)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Table Synchronization definiton'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'apex_rest_source_sync.synchronize_table_definition(',
'        p_module_static_id     => ''eba_rest_movie_synchronization'',',
'        p_drop_unused_columns  => true ',
');',
'  ',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Sync table is not created.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(100799247267345242)
,p_process_success_message=>'Table created successfully.'
,p_internal_uid=>8731459953172133
);
wwv_flow_imp.component_end;
end;
/
