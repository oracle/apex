prompt --application/pages/page_00404
begin
--   Manifest
--     PAGE: 00404
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>404
,p_name=>'REST Data & PL/SQL'
,p_alias=>'REST-DATA-PL-SQL2'
,p_step_title=>'REST Data & PL/SQL'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(108995404117767715)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(94274508379483476)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(109330291782323331)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div>',
'  <p>',
' This page demonstrates an ETL process within Oracle APEX by dynamically retrieving and aggregating data from two external REST Data Sources.',
'  </p>',
'  <p>',
'    <strong>Data Source Calls:</strong>',
'  </p>',
'  <ul>',
'    <li>',
'      <strong>Stores Data:</strong> Fetches key store details such as <strong>STORE_ID</strong> and <strong>STORE_NAME</strong> from the <strong>EBA_REST_STORES</strong> REST Data Source.',
'    </li>',
'    <li>',
'      <strong>Orders Data:</strong> Retrieves order records  <strong>STORE_ID</strong> and <strong>ORDER_DATETIME</strong>  from the <strong>EBA_REST_ORDERS</strong> REST Data Source.',
'    </li>',
'  </ul>',
'  <p>',
unistr('    <strong>Data Processing and Transformation:</strong> The PL/SQL code uses the <strong>APEX_EXEC</strong> package to process JSON responses row-by-row. Order datetime strings are converted to dates and the data is aggregated per store\2014calculating ')
||unistr('total orders and the latest order date/time\2014using PL/SQL collections.'),
'  </p>',
'  <p>',
'    <strong>Data Storage and Display:</strong> Aggregated results (store ID, store name, total orders, and latest order datetime) are inserted into the local summary table <strong>STORE_ORDER_SUMMARY</strong>. An Interactive Report then queries this '
||'table to provide users with an up-to-date summary of store performance. Users can refresh the data or schedule the process to run at intervals.',
'  </p>',
'    <strong>Note:</strong> The PL/SQL code for this ETL can be viewed in the <em>Process_ETL</em> process in Page Designer.',
'</div>',
''))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(111246004768637620)
,p_plug_name=>'Actions'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ul>',
'    <li>',
'      <strong>Start process & send report:</strong> the button initiates the entire ETL process. When clicked, it triggers a PL/SQL process that retrieves and aggregates data from two REST Data Sources and then sends a summary report via email. Pleas'
||'e ensure you enter a valid email address to receive the report.',
'    </li>',
'   ',
'  </ul>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(112068432997377035)
,p_plug_name=>'ETL Order Summary Results'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>50
,p_query_type=>'TABLE'
,p_query_table=>'EBA_DEMO_REST_STOREORDERSUMMARY'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(112068520495377036)
,p_no_data_found_message=>'No data found. Use the Process Data & Send Report button to generate data.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'AHMAMED'
,p_internal_uid=>20000899968203929
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(112068636172377037)
,p_db_column_name=>'STORE_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Store Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(112068727934377038)
,p_db_column_name=>'STORE_NAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Store Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'Y'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(112068797014377039)
,p_db_column_name=>'TOTAL_ORDERS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Total Orders'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(112068957369377040)
,p_db_column_name=>'LAST_ORDER_DATETIME'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Last Order Datetime'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(112069047271377041)
,p_db_column_name=>'LOAD_TIMESTAMP'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Load Timestamp'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(112112156752984330)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'53612'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'STORE_ID:STORE_NAME:TOTAL_ORDERS:LAST_ORDER_DATETIME:LOAD_TIMESTAMP'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99413714373706664)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(111246004768637620)
,p_button_name=>'Download'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--pill:t-Button--gapTop:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Process Data & Send report'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99415216075706666)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(108995404117767715)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Previous'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:402:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99415562069706666)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(108995404117767715)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:405:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(111423175658497727)
,p_name=>'P404_EMAIL'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(111246004768637620)
,p_prompt=>'Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15711475915912857)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Truncate Table Before Processing'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'    execute immediate ''truncate table eba_demo_rest_storeordersummary'';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>7784579219706901
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99419388537706668)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process_ETL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    eba_demo_rest_etl_pkg.process_store_order_summary(',
'        p_email => :P404_EMAIL',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(99413714373706664)
,p_internal_uid=>7351768010533561
);
wwv_flow_imp.component_end;
end;
/
