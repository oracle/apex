prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7930
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>12319406322640193
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(184198375531348306)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table eba_restdemo_sample_emp',
'/',
'',
'drop package eba_restdemo_sample_pkg',
'/',
'',
'drop table eba_restdemo_sample_github',
'/',
'',
'drop type eba_restdemo_github_repo_ct',
'/',
'',
'drop type eba_restdemo_github_repo_t',
'/',
'',
'drop table eba_restdemo_sample_urls',
'/',
'',
'drop table eba_restdemo_sample_lang',
'/'))
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
);
wwv_flow_imp.component_end;
end;
/
