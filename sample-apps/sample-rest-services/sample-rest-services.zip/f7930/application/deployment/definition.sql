prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7930
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- ==========================================================================='||wwv_flow.LF||
'-- section: remove OR';
wwv_flow_imp.g_varchar2_table(2) := 'DS REST modules'||wwv_flow.LF||
'-- ==========================================================================='||wwv_flow.LF||
''||wwv_flow.LF||
'begi';
wwv_flow_imp.g_varchar2_table(3) := 'n'||wwv_flow.LF||
'    ords.drop_rest_for_object(p_object => ''EBA_DEMO_REST_TASKS'');'||wwv_flow.LF||
'    ords.drop_rest_for_object(p_';
wwv_flow_imp.g_varchar2_table(4) := 'object => ''EBA_DEMO_REST_ORDERS'');'||wwv_flow.LF||
'    ords.drop_rest_for_object(p_object => ''EBA_DEMO_REST_DEPARTME';
wwv_flow_imp.g_varchar2_table(5) := 'NT'');'||wwv_flow.LF||
'    ords.drop_rest_for_object(p_object => ''EBA_DEMO_REST_EMPLOYEE'');'||wwv_flow.LF||
'    ords.drop_rest_for_ob';
wwv_flow_imp.g_varchar2_table(6) := 'ject(p_object => ''EBA_DEMO_REST_STORES'');'||wwv_flow.LF||
'    ords.delete_module       (p_module_name => ''eba.rest.e';
wwv_flow_imp.g_varchar2_table(7) := 'mp'');'||wwv_flow.LF||
'    ords.delete_module       (p_module_name => ''eba.rest.orders'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'  '||wwv_flow.LF||
'-- ==============';
wwv_flow_imp.g_varchar2_table(8) := '============================================================='||wwv_flow.LF||
'-- section: remove PL/SQL packages'||wwv_flow.LF||
'-- ';
wwv_flow_imp.g_varchar2_table(9) := '==========================================================================='||wwv_flow.LF||
''||wwv_flow.LF||
'drop package eba_demo_r';
wwv_flow_imp.g_varchar2_table(10) := 'est_data_pkg;'||wwv_flow.LF||
'drop package eba_demo_rest_etl_pkg;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- ==============================================';
wwv_flow_imp.g_varchar2_table(11) := '============================='||wwv_flow.LF||
'-- section: remove views'||wwv_flow.LF||
'-- ==========================================';
wwv_flow_imp.g_varchar2_table(12) := '================================='||wwv_flow.LF||
''||wwv_flow.LF||
'drop view customer_order_products;'||wwv_flow.LF||
'drop view product_orders;'||wwv_flow.LF||
'drop';
wwv_flow_imp.g_varchar2_table(13) := ' view product_reviews;'||wwv_flow.LF||
'drop view store_orders;'||wwv_flow.LF||
'drop view store_orders_status;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- ==================';
wwv_flow_imp.g_varchar2_table(14) := '========================================================='||wwv_flow.LF||
'-- section: remove tables'||wwv_flow.LF||
'-- =============';
wwv_flow_imp.g_varchar2_table(15) := '=============================================================='||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba_demo_rest_producttabl';
wwv_flow_imp.g_varchar2_table(16) := 'e           cascade constraints purge;'||wwv_flow.LF||
'drop table eba_demo_rest_order_workflow         cascade const';
wwv_flow_imp.g_varchar2_table(17) := 'raints purge;'||wwv_flow.LF||
'drop table eba_demo_rest_purchaseorders         cascade constraints purge;'||wwv_flow.LF||
'drop table ';
wwv_flow_imp.g_varchar2_table(18) := 'eba_demo_rest_stores                 cascade constraints purge;'||wwv_flow.LF||
'drop table eba_demo_rest_assignees  ';
wwv_flow_imp.g_varchar2_table(19) := '            cascade constraints purge;'||wwv_flow.LF||
'drop table eba_demo_rest_customers              cascade const';
wwv_flow_imp.g_varchar2_table(20) := 'raints purge;'||wwv_flow.LF||
'drop table eba_demo_rest_department             cascade constraints purge;'||wwv_flow.LF||
'drop table ';
wwv_flow_imp.g_varchar2_table(21) := 'eba_demo_rest_dept_local             cascade constraints purge;'||wwv_flow.LF||
'drop table eba_demo_rest_employee   ';
wwv_flow_imp.g_varchar2_table(22) := '            cascade constraints purge;'||wwv_flow.LF||
'drop table eba_demo_rest_employeecustom         cascade const';
wwv_flow_imp.g_varchar2_table(23) := 'raints purge;'||wwv_flow.LF||
'drop table eba_demo_rest_orderitems             cascade constraints purge;'||wwv_flow.LF||
'drop table ';
wwv_flow_imp.g_varchar2_table(24) := 'eba_demo_rest_orders                 cascade constraints purge;'||wwv_flow.LF||
'drop table eba_demo_rest_storeorders';
wwv_flow_imp.g_varchar2_table(25) := 'ummary      cascade constraints purge;'||wwv_flow.LF||
'drop table eba_demo_rest_tasks                  cascade const';
wwv_flow_imp.g_varchar2_table(26) := 'raints purge;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- ==========================================================================='||wwv_flow.LF||
'-- ';
wwv_flow_imp.g_varchar2_table(27) := 'section: remove sequence'||wwv_flow.LF||
'-- ========================================================================';
wwv_flow_imp.g_varchar2_table(28) := '==='||wwv_flow.LF||
''||wwv_flow.LF||
'drop sequence dept_seq;'||wwv_flow.LF||
'drop sequence eba_demo_emp_seq;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(94382806445719195)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
);
wwv_flow_imp.component_end;
end;
/
