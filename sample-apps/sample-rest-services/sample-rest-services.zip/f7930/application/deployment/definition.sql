prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7930
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(94382806445719195)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- ===========================================================================',
'-- section: remove ORDS REST modules',
'-- ===========================================================================',
'',
'begin',
'    ords.drop_rest_for_object(p_object => ''EBA_DEMO_REST_TASKS'');',
'    ords.drop_rest_for_object(p_object => ''EBA_DEMO_REST_ORDERS'');',
'    ords.drop_rest_for_object(p_object => ''EBA_DEMO_REST_DEPARTMENT'');',
'    ords.drop_rest_for_object(p_object => ''EBA_DEMO_REST_EMPLOYEE'');',
'    ords.drop_rest_for_object(p_object => ''EBA_DEMO_REST_STORES'');',
'    ords.delete_module       (p_module_name => ''eba.rest.emp'');',
'    ords.delete_module       (p_module_name => ''eba.rest.orders'');',
'end;',
'/',
'  ',
'-- ===========================================================================',
'-- section: remove PL/SQL packages',
'-- ===========================================================================',
'',
'drop package eba_demo_rest_data_pkg;',
'drop package eba_demo_rest_etl_pkg;',
'',
'-- ===========================================================================',
'-- section: remove views',
'-- ===========================================================================',
'',
'drop view customer_order_products;',
'drop view product_orders;',
'drop view product_reviews;',
'drop view store_orders;',
'drop view store_orders_status;',
'',
'-- ===========================================================================',
'-- section: remove tables',
'-- ===========================================================================',
'',
'drop table eba_demo_rest_producttable           cascade constraints purge;',
'drop table eba_demo_rest_order_workflow         cascade constraints purge;',
'drop table eba_demo_rest_purchaseorders         cascade constraints purge;',
'drop table eba_demo_rest_stores                 cascade constraints purge;',
'drop table eba_demo_rest_assignees              cascade constraints purge;',
'drop table eba_demo_rest_customers              cascade constraints purge;',
'drop table eba_demo_rest_department             cascade constraints purge;',
'drop table eba_demo_rest_dept_local             cascade constraints purge;',
'drop table eba_demo_rest_employee               cascade constraints purge;',
'drop table eba_demo_rest_employeecustom         cascade constraints purge;',
'drop table eba_demo_rest_orderitems             cascade constraints purge;',
'drop table eba_demo_rest_orders                 cascade constraints purge;',
'drop table eba_demo_rest_storeordersummary      cascade constraints purge;',
'drop table eba_demo_rest_tasks                  cascade constraints purge;',
'',
'',
'',
'',
'-- ===========================================================================',
'-- section: remove sequence',
'-- ===========================================================================',
'',
'drop sequence dept_seq;',
'drop sequence eba_demo_emp_seq;',
'',
''))
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
);
wwv_flow_imp.component_end;
end;
/
