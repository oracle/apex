prompt --application/deployment/install/install_sequences_objects_definition
begin
--   Manifest
--     INSTALL: INSTALL-Sequences Objects Definition
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- ==========================================================================='||wwv_flow.LF||
'--  Sequence Definiti';
wwv_flow_imp.g_varchar2_table(2) := 'ons'||wwv_flow.LF||
'-- ==========================================================================='||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    execut';
wwv_flow_imp.g_varchar2_table(3) := 'e immediate '''||wwv_flow.LF||
'        create sequence dept_seq'||wwv_flow.LF||
'            minvalue 1'||wwv_flow.LF||
'            maxvalue 999999999';
wwv_flow_imp.g_varchar2_table(4) := '9999999999999999999'||wwv_flow.LF||
'            increment by 1'||wwv_flow.LF||
'            start with 50'||wwv_flow.LF||
'            cache 20'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(5) := '      noorder'||wwv_flow.LF||
'            nocycle'||wwv_flow.LF||
'            nokeep'||wwv_flow.LF||
'            noscale'||wwv_flow.LF||
'            global'||wwv_flow.LF||
'    '';'||wwv_flow.LF||
'e';
wwv_flow_imp.g_varchar2_table(6) := 'xception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        if sqlcode = -955 then'||wwv_flow.LF||
'            null; '||wwv_flow.LF||
'        else'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(7) := '     raise;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    execute immediate '''||wwv_flow.LF||
'        create sequence eba_demo_e';
wwv_flow_imp.g_varchar2_table(8) := 'mp_seq'||wwv_flow.LF||
'            minvalue 1'||wwv_flow.LF||
'            maxvalue 9999999999999999999999999999'||wwv_flow.LF||
'            incremen';
wwv_flow_imp.g_varchar2_table(9) := 't by 1'||wwv_flow.LF||
'            start with 21'||wwv_flow.LF||
'            cache 20'||wwv_flow.LF||
'            noorder'||wwv_flow.LF||
'            nocycle'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(10) := '      nokeep'||wwv_flow.LF||
'            noscale'||wwv_flow.LF||
'            global'||wwv_flow.LF||
'    '';'||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        if';
wwv_flow_imp.g_varchar2_table(11) := ' sqlcode = -955 then'||wwv_flow.LF||
'            null; '||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            raise;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(98535054195994084)
,p_install_id=>wwv_flow_imp.id(94382806445719195)
,p_name=>'Sequences Objects Definition'
,p_sequence=>49
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98535168963994086)
,p_script_id=>wwv_flow_imp.id(98535054195994084)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'DEPT_SEQ'
);
wwv_flow_imp.component_end;
end;
/
