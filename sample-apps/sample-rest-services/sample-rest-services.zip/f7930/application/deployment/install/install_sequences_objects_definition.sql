prompt --application/deployment/install/install_sequences_objects_definition
begin
--   Manifest
--     INSTALL: INSTALL-Sequences Objects Definition
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(98535054195994084)
,p_install_id=>wwv_flow_imp.id(94382806445719195)
,p_name=>'Sequences Objects Definition'
,p_sequence=>49
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- ===========================================================================',
'--  Sequence Definitions',
'-- ===========================================================================',
'',
'begin',
'    execute immediate ''',
'        create sequence dept_seq',
'            minvalue 1',
'            maxvalue 9999999999999999999999999999',
'            increment by 1',
'            start with 50',
'            cache 20',
'            noorder',
'            nocycle',
'            nokeep',
'            noscale',
'            global',
'    '';',
'exception',
'    when others then',
'        if sqlcode = -955 then',
'            null; ',
'        else',
'            raise;',
'        end if;',
'end;',
'/',
'',
'begin',
'    execute immediate ''',
'        create sequence eba_demo_emp_seq',
'            minvalue 1',
'            maxvalue 9999999999999999999999999999',
'            increment by 1',
'            start with 21',
'            cache 20',
'            noorder',
'            nocycle',
'            nokeep',
'            noscale',
'            global',
'    '';',
'exception',
'    when others then',
'        if sqlcode = -955 then',
'            null; ',
'        else',
'            raise;',
'        end if;',
'end;',
'/',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98535168963994086)
,p_script_id=>wwv_flow_imp.id(98535054195994084)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'DEPT_SEQ'
);
wwv_flow_imp.component_end;
end;
/
