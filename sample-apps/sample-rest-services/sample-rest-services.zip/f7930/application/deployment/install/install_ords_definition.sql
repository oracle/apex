prompt --application/deployment/install/install_ords_definition
begin
--   Manifest
--     INSTALL: INSTALL-ORDS Definition
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- =========================================================================== '||wwv_flow.LF||
'-- RESTful Service D';
wwv_flow_imp.g_varchar2_table(2) := 'efinitions '||wwv_flow.LF||
'-- ==========================================================================='||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(3) := 'ords.enable_schema('||wwv_flow.LF||
'      p_enabled              => true,'||wwv_flow.LF||
'      p_url_mapping_type     => ''BASE_PATH';
wwv_flow_imp.g_varchar2_table(4) := ''','||wwv_flow.LF||
'      p_url_mapping_pattern  => :APP_USER,'||wwv_flow.LF||
'      p_auto_rest_auth       => false'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.d';
wwv_flow_imp.g_varchar2_table(5) := 'efine_module('||wwv_flow.LF||
'      p_module_name          => ''eba.rest.emp'','||wwv_flow.LF||
'      p_base_path            => ''/data';
wwv_flow_imp.g_varchar2_table(6) := '/'','||wwv_flow.LF||
'      p_items_per_page       => 25,'||wwv_flow.LF||
'      p_status               => ''PUBLISHED'','||wwv_flow.LF||
'      p_comment';
wwv_flow_imp.g_varchar2_table(7) := 's             => null'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_template('||wwv_flow.LF||
'      p_module_name          => ''eba.rest.emp''';
wwv_flow_imp.g_varchar2_table(8) := ','||wwv_flow.LF||
'      p_pattern              => ''emp'','||wwv_flow.LF||
'      p_priority             => 0,'||wwv_flow.LF||
'      p_etag_type       ';
wwv_flow_imp.g_varchar2_table(9) := '     => ''HASH'','||wwv_flow.LF||
'      p_etag_query           => null,'||wwv_flow.LF||
'      p_comments             => null'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(10) := ' ords.define_handler('||wwv_flow.LF||
'      p_module_name          => ''eba.rest.emp'','||wwv_flow.LF||
'      p_pattern              =';
wwv_flow_imp.g_varchar2_table(11) := '> ''emp'','||wwv_flow.LF||
'      p_method               => ''GET'','||wwv_flow.LF||
'      p_source_type          => ''json/collection'','||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(12) := '     p_mimes_allowed        => null,'||wwv_flow.LF||
'      p_comments             => null,'||wwv_flow.LF||
'      p_source           ';
wwv_flow_imp.g_varchar2_table(13) := '    => '||wwv_flow.LF||
'        ''select * from  eba_demo_rest_employee'''||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_template('||wwv_flow.LF||
'      p_modu';
wwv_flow_imp.g_varchar2_table(14) := 'le_name          => ''eba.rest.emp'','||wwv_flow.LF||
'      p_pattern              => ''emp/:id'','||wwv_flow.LF||
'      p_priority     ';
wwv_flow_imp.g_varchar2_table(15) := '        => 0,'||wwv_flow.LF||
'      p_etag_type            => ''HASH'','||wwv_flow.LF||
'      p_etag_query           => null,'||wwv_flow.LF||
'      p_';
wwv_flow_imp.g_varchar2_table(16) := 'comments             => null'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_handler('||wwv_flow.LF||
'      p_module_name          => ''eba.res';
wwv_flow_imp.g_varchar2_table(17) := 't.emp'','||wwv_flow.LF||
'      p_pattern              => ''emp/:id'','||wwv_flow.LF||
'      p_method               => ''PUT'','||wwv_flow.LF||
'      p_so';
wwv_flow_imp.g_varchar2_table(18) := 'urce_type          => ''plsql/block'','||wwv_flow.LF||
'      p_mimes_allowed        => ''application/json'','||wwv_flow.LF||
'      p_com';
wwv_flow_imp.g_varchar2_table(19) := 'ments             => null,'||wwv_flow.LF||
'      p_source               => '||wwv_flow.LF||
'            ''declare'||wwv_flow.LF||
'                cur';
wwv_flow_imp.g_varchar2_table(20) := 'rent_salary  eba_demo_rest_employee.sal%type;'||wwv_flow.LF||
'                dept_name       eba_demo_rest_departme';
wwv_flow_imp.g_varchar2_table(21) := 'nt.dname%type;'||wwv_flow.LF||
'            begin'||wwv_flow.LF||
'                select'||wwv_flow.LF||
'                    e.sal,'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(22) := '   d.dname'||wwv_flow.LF||
'                into'||wwv_flow.LF||
'                    current_salary,'||wwv_flow.LF||
'                    dept_name'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(23) := '              from'||wwv_flow.LF||
'                    eba_demo_rest_employee e'||wwv_flow.LF||
'                    join eba_demo_re';
wwv_flow_imp.g_varchar2_table(24) := 'st_department d'||wwv_flow.LF||
'                        on e.deptno = d.deptno'||wwv_flow.LF||
'                where'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(25) := '     e.empno = :id;'||wwv_flow.LF||
''||wwv_flow.LF||
'                if :sal < 0 then'||wwv_flow.LF||
'                    htp.p('||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(26) := '     ''''{"status":400,"message":"New salary must be positive value."}'''''||wwv_flow.LF||
'                    );'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(27) := '              return;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'                if current_salary >= 6000 then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(28) := '              htp.p('||wwv_flow.LF||
'                        ''''{"status":400,"message":"No Update: Employee with sal';
wwv_flow_imp.g_varchar2_table(29) := 'ary.'''''||wwv_flow.LF||
'                        || current_salary'||wwv_flow.LF||
'                        || '''' is not authorized for';
wwv_flow_imp.g_varchar2_table(30) := ' a raise."}'''''||wwv_flow.LF||
'                    );'||wwv_flow.LF||
'                    return;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(31) := '      if upper(dept_name) = ''''RESEARCH'''' then'||wwv_flow.LF||
'                    htp.p('||wwv_flow.LF||
'                        ''''{';
wwv_flow_imp.g_varchar2_table(32) := '"status":400,"message":"No Update: Employees in research department are not eligible for a raise."}''';
wwv_flow_imp.g_varchar2_table(33) := ''''||wwv_flow.LF||
'                    );'||wwv_flow.LF||
'                    return;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'                update';
wwv_flow_imp.g_varchar2_table(34) := ''||wwv_flow.LF||
'                    eba_demo_rest_employee'||wwv_flow.LF||
'                set'||wwv_flow.LF||
'                    sal = :sal'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(35) := '           where'||wwv_flow.LF||
'                    empno = :id;'||wwv_flow.LF||
''||wwv_flow.LF||
'                commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'                htp.p('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(36) := '                   ''''{"status":200,"location":'''''||wwv_flow.LF||
'                    || :id'||wwv_flow.LF||
'                    || ''';
wwv_flow_imp.g_varchar2_table(37) := ''',"message":"Salary updated successfully."}'''''||wwv_flow.LF||
'                );'||wwv_flow.LF||
'            exception'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(38) := '   when no_data_found then'||wwv_flow.LF||
'                    htp.p('||wwv_flow.LF||
'                        ''''{"status":404,"messa';
wwv_flow_imp.g_varchar2_table(39) := 'ge":"Employee not found."}'''''||wwv_flow.LF||
'                    );'||wwv_flow.LF||
'                when others then'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(40) := '     rollback;'||wwv_flow.LF||
'                    htp.p('||wwv_flow.LF||
'                        ''''{"status":400,"message":"'''''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(41) := '                    || sys.htf.escape_sc(sqlerrm)'||wwv_flow.LF||
'                        || ''''"}'''''||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(42) := '    );'||wwv_flow.LF||
'            end;'||wwv_flow.LF||
'            '');'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_parameter('||wwv_flow.LF||
'      p_module_name          => ''e';
wwv_flow_imp.g_varchar2_table(43) := 'ba.rest.emp'','||wwv_flow.LF||
'      p_pattern              => ''emp/:id'','||wwv_flow.LF||
'      p_method               => ''PUT'','||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(44) := '  p_name                 => ''id'','||wwv_flow.LF||
'      p_bind_variable_name   => ''id'','||wwv_flow.LF||
'      p_source_type         ';
wwv_flow_imp.g_varchar2_table(45) := ' => ''URI'','||wwv_flow.LF||
'      p_param_type           => ''INT'','||wwv_flow.LF||
'      p_access_method        => ''IN'','||wwv_flow.LF||
'      p_comm';
wwv_flow_imp.g_varchar2_table(46) := 'ents             => null'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_parameter('||wwv_flow.LF||
'      p_module_name          => ''eba.rest.';
wwv_flow_imp.g_varchar2_table(47) := 'emp'','||wwv_flow.LF||
'      p_pattern              => ''emp/:id'','||wwv_flow.LF||
'      p_method               => ''PUT'','||wwv_flow.LF||
'      p_name';
wwv_flow_imp.g_varchar2_table(48) := '                 => ''res'','||wwv_flow.LF||
'      p_bind_variable_name   => ''res'','||wwv_flow.LF||
'      p_source_type          => ''R';
wwv_flow_imp.g_varchar2_table(49) := 'ESPONSE'','||wwv_flow.LF||
'      p_param_type           => ''STRING'','||wwv_flow.LF||
'      p_access_method        => ''OUT'','||wwv_flow.LF||
'      p_c';
wwv_flow_imp.g_varchar2_table(50) := 'omments             => null'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_handler('||wwv_flow.LF||
'      p_module_name          => ''eba.rest';
wwv_flow_imp.g_varchar2_table(51) := '.emp'','||wwv_flow.LF||
'      p_pattern              => ''emp/:id'','||wwv_flow.LF||
'      p_method               => ''GET'','||wwv_flow.LF||
'      p_sou';
wwv_flow_imp.g_varchar2_table(52) := 'rce_type          => ''json/collection'','||wwv_flow.LF||
'      p_mimes_allowed        => null,'||wwv_flow.LF||
'      p_comments      ';
wwv_flow_imp.g_varchar2_table(53) := '       => null,'||wwv_flow.LF||
'      p_source               => '||wwv_flow.LF||
'        ''select * '||wwv_flow.LF||
'            from eba_demo_rest_e';
wwv_flow_imp.g_varchar2_table(54) := 'mployee '''||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_parameter('||wwv_flow.LF||
'      p_module_name          => ''eba.rest.emp'','||wwv_flow.LF||
'      p_p';
wwv_flow_imp.g_varchar2_table(55) := 'attern              => ''emp/:id'','||wwv_flow.LF||
'      p_method               => ''GET'','||wwv_flow.LF||
'      p_name               ';
wwv_flow_imp.g_varchar2_table(56) := '  => ''id'','||wwv_flow.LF||
'      p_bind_variable_name   => ''id'','||wwv_flow.LF||
'      p_source_type          => ''URI'','||wwv_flow.LF||
'      p_para';
wwv_flow_imp.g_varchar2_table(57) := 'm_type           => ''INT'','||wwv_flow.LF||
'      p_access_method        => ''IN'','||wwv_flow.LF||
'      p_comments             => nul';
wwv_flow_imp.g_varchar2_table(58) := 'l'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_template('||wwv_flow.LF||
'      p_module_name          => ''eba.rest.emp'','||wwv_flow.LF||
'      p_pattern   ';
wwv_flow_imp.g_varchar2_table(59) := '           => ''Pagination'','||wwv_flow.LF||
'      p_priority             => 0,'||wwv_flow.LF||
'      p_etag_type            => ''HASH';
wwv_flow_imp.g_varchar2_table(60) := ''','||wwv_flow.LF||
'      p_etag_query           => null,'||wwv_flow.LF||
'      p_comments             => null'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_';
wwv_flow_imp.g_varchar2_table(61) := 'handler('||wwv_flow.LF||
'      p_module_name          => ''eba.rest.emp'','||wwv_flow.LF||
'      p_pattern              => ''Pagination';
wwv_flow_imp.g_varchar2_table(62) := ''','||wwv_flow.LF||
'      p_method               => ''GET'','||wwv_flow.LF||
'      p_source_type          => ''json/collection'','||wwv_flow.LF||
'      p';
wwv_flow_imp.g_varchar2_table(63) := '_mimes_allowed        => null,'||wwv_flow.LF||
'      p_comments             => null,'||wwv_flow.LF||
'      p_source               =>';
wwv_flow_imp.g_varchar2_table(64) := ' '||wwv_flow.LF||
'            ''select'||wwv_flow.LF||
'                level         as id,    '||wwv_flow.LF||
'                case ora_hash(level, ';
wwv_flow_imp.g_varchar2_table(65) := '3) + 1'||wwv_flow.LF||
'                    when 1 then ''''HR'''''||wwv_flow.LF||
'                    when 2 then ''''SALES'''''||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(66) := '        when 3 then ''''DEVELOPMENT'''''||wwv_flow.LF||
'                    when 4 then ''''QA'''''||wwv_flow.LF||
'                end      ';
wwv_flow_imp.g_varchar2_table(67) := '     as dept,'||wwv_flow.LF||
'                case ora_hash(level, 9) + 1'||wwv_flow.LF||
'                    when 1 then 1500'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(68) := '               when 2 then 2600'||wwv_flow.LF||
'                    when 3 then 500'||wwv_flow.LF||
'                    else 2000'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(69) := '              end           as sal,'||wwv_flow.LF||
'                level         as rnum,'||wwv_flow.LF||
'                round(dbm';
wwv_flow_imp.g_varchar2_table(70) := 's_random.value(100, 500), 0) as bonus,'||wwv_flow.LF||
'                case mod(level, 5)'||wwv_flow.LF||
'                    when 0';
wwv_flow_imp.g_varchar2_table(71) := ' then ''''Alvaro'''''||wwv_flow.LF||
'                    when 1 then ''''Morata'''''||wwv_flow.LF||
'                    when 2 then ''''Junior';
wwv_flow_imp.g_varchar2_table(72) := ''''''||wwv_flow.LF||
'                    when 3 then ''''Pathe'''''||wwv_flow.LF||
'                    when 4 then ''''Antonyo'''''||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(73) := '     end           as name,'||wwv_flow.LF||
'                case mod(level, 3)'||wwv_flow.LF||
'                    when 0 then ''''Act';
wwv_flow_imp.g_varchar2_table(74) := 'ive'''''||wwv_flow.LF||
'                    when 1 then ''''On Leave'''''||wwv_flow.LF||
'                    when 2 then ''''Retired'''''||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(75) := '           end           as status'||wwv_flow.LF||
'             from sys.dual connect by level < 1000'||wwv_flow.LF||
'            '''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(76) := '    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_module('||wwv_flow.LF||
'      p_module_name          => ''eba.rest.orders'','||wwv_flow.LF||
'      p_base_path  ';
wwv_flow_imp.g_varchar2_table(77) := '          => ''/orders/'','||wwv_flow.LF||
'      p_items_per_page       => 25,'||wwv_flow.LF||
'      p_status               => ''PUBLIS';
wwv_flow_imp.g_varchar2_table(78) := 'HED'','||wwv_flow.LF||
'      p_comments             => null'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_template('||wwv_flow.LF||
'      p_module_name      ';
wwv_flow_imp.g_varchar2_table(79) := '    => ''eba.rest.orders'','||wwv_flow.LF||
'      p_pattern              => ''purchaseorders/'','||wwv_flow.LF||
'      p_priority       ';
wwv_flow_imp.g_varchar2_table(80) := '      => 0,'||wwv_flow.LF||
'      p_etag_type            => ''HASH'','||wwv_flow.LF||
'      p_etag_query           => null,'||wwv_flow.LF||
'      p_co';
wwv_flow_imp.g_varchar2_table(81) := 'mments             => null'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_handler('||wwv_flow.LF||
'      p_module_name          => ''eba.rest.';
wwv_flow_imp.g_varchar2_table(82) := 'orders'','||wwv_flow.LF||
'      p_pattern              => ''purchaseorders/'','||wwv_flow.LF||
'      p_method               => ''GET'','||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(83) := '     p_source_type          => ''json/collection'','||wwv_flow.LF||
'      p_mimes_allowed        => null,'||wwv_flow.LF||
'      p_comm';
wwv_flow_imp.g_varchar2_table(84) := 'ents             => null,'||wwv_flow.LF||
'      p_source               => '||wwv_flow.LF||
'        ''select po '||wwv_flow.LF||
'            as "{}po"';
wwv_flow_imp.g_varchar2_table(85) := ' '||wwv_flow.LF||
'           from eba_demo_rest_purchaseorders '''||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_template('||wwv_flow.LF||
'      p_module_name';
wwv_flow_imp.g_varchar2_table(86) := '          => ''eba.rest.orders'','||wwv_flow.LF||
'      p_pattern              => ''product/:id'','||wwv_flow.LF||
'      p_priority     ';
wwv_flow_imp.g_varchar2_table(87) := '        => 0,'||wwv_flow.LF||
'      p_etag_type            => ''HASH'','||wwv_flow.LF||
'      p_etag_query           => null,'||wwv_flow.LF||
'      p_';
wwv_flow_imp.g_varchar2_table(88) := 'comments             => null'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_handler('||wwv_flow.LF||
'      p_module_name          => ''eba.res';
wwv_flow_imp.g_varchar2_table(89) := 't.orders'','||wwv_flow.LF||
'      p_pattern              => ''product/:id'','||wwv_flow.LF||
'      p_method               => ''GET'','||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(90) := '   p_source_type          => ''json/item'','||wwv_flow.LF||
'      p_mimes_allowed        => null,'||wwv_flow.LF||
'      p_comments    ';
wwv_flow_imp.g_varchar2_table(91) := '         => null,'||wwv_flow.LF||
'      p_source               => '||wwv_flow.LF||
'        ''select * '||wwv_flow.LF||
'            from eba_demo_rest';
wwv_flow_imp.g_varchar2_table(92) := '_producttable '||wwv_flow.LF||
'            where product_id = :id'||wwv_flow.LF||
'        '''||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_parameter('||wwv_flow.LF||
'      p';
wwv_flow_imp.g_varchar2_table(93) := '_module_name          => ''eba.rest.orders'','||wwv_flow.LF||
'      p_pattern              => ''product/:id'','||wwv_flow.LF||
'      p_m';
wwv_flow_imp.g_varchar2_table(94) := 'ethod               => ''GET'','||wwv_flow.LF||
'      p_name                 => ''id'','||wwv_flow.LF||
'      p_bind_variable_name   => ';
wwv_flow_imp.g_varchar2_table(95) := '''id'','||wwv_flow.LF||
'      p_source_type          => ''URI'','||wwv_flow.LF||
'      p_param_type           => ''INT'','||wwv_flow.LF||
'      p_access_m';
wwv_flow_imp.g_varchar2_table(96) := 'ethod        => ''IN'','||wwv_flow.LF||
'      p_comments             => null'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_template('||wwv_flow.LF||
'      p_m';
wwv_flow_imp.g_varchar2_table(97) := 'odule_name          => ''eba.rest.orders'','||wwv_flow.LF||
'      p_pattern              => ''product_post'','||wwv_flow.LF||
'      p_pr';
wwv_flow_imp.g_varchar2_table(98) := 'iority             => 0,'||wwv_flow.LF||
'      p_etag_type            => ''HASH'','||wwv_flow.LF||
'      p_etag_query           => nul';
wwv_flow_imp.g_varchar2_table(99) := 'l,'||wwv_flow.LF||
'      p_comments             => null'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_handler('||wwv_flow.LF||
'      p_module_name          ';
wwv_flow_imp.g_varchar2_table(100) := '=> ''eba.rest.orders'','||wwv_flow.LF||
'      p_pattern              => ''product_post'','||wwv_flow.LF||
'      p_method               =';
wwv_flow_imp.g_varchar2_table(101) := '> ''POST'','||wwv_flow.LF||
'      p_source_type          => ''plsql/block'','||wwv_flow.LF||
'      p_mimes_allowed        => ''applicatio';
wwv_flow_imp.g_varchar2_table(102) := 'n/json'','||wwv_flow.LF||
'      p_comments             => null,'||wwv_flow.LF||
'      p_source               => '||wwv_flow.LF||
'        ''insert into';
wwv_flow_imp.g_varchar2_table(103) := ' eba_demo_rest_order_workflow ('||wwv_flow.LF||
'            user_id,'||wwv_flow.LF||
'            product_name,'||wwv_flow.LF||
'            product_d';
wwv_flow_imp.g_varchar2_table(104) := 'etails'||wwv_flow.LF||
'        ) values ('||wwv_flow.LF||
'            :USER_ID,'||wwv_flow.LF||
'            :PRODUCT_NAME,'||wwv_flow.LF||
'            :PRODUCT_DETA';
wwv_flow_imp.g_varchar2_table(105) := 'ILS'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'        '''||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords.define_handler('||wwv_flow.LF||
'      p_module_name          => ''eba.rest.ord';
wwv_flow_imp.g_varchar2_table(106) := 'ers'','||wwv_flow.LF||
'      p_pattern              => ''product_post'','||wwv_flow.LF||
'      p_method               => ''GET'','||wwv_flow.LF||
'      p';
wwv_flow_imp.g_varchar2_table(107) := '_source_type          => ''json/item'','||wwv_flow.LF||
'      p_mimes_allowed        => null,'||wwv_flow.LF||
'      p_comments        ';
wwv_flow_imp.g_varchar2_table(108) := '     => null,'||wwv_flow.LF||
'      p_source               => '||wwv_flow.LF||
'        ''select * '||wwv_flow.LF||
'            from eba_demo_rest_ord';
wwv_flow_imp.g_varchar2_table(109) := 'er_workflow'||wwv_flow.LF||
'        '''||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords_metadata.ords.enable_object('||wwv_flow.LF||
'      p_enabled              => tr';
wwv_flow_imp.g_varchar2_table(110) := 'ue, '||wwv_flow.LF||
'      p_object               => ''EBA_DEMO_REST_EMPLOYEE'','||wwv_flow.LF||
'      p_object_type          => ''TABL';
wwv_flow_imp.g_varchar2_table(111) := 'E'','||wwv_flow.LF||
'      p_object_alias         => ''employee'','||wwv_flow.LF||
'      p_auto_rest_auth       => false'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords';
wwv_flow_imp.g_varchar2_table(112) := '_metadata.ords.enable_object('||wwv_flow.LF||
'      p_enabled              => true, '||wwv_flow.LF||
'      p_object               =>';
wwv_flow_imp.g_varchar2_table(113) := ' ''EBA_DEMO_REST_ORDERS'','||wwv_flow.LF||
'      p_object_type          => ''TABLE'','||wwv_flow.LF||
'      p_object_alias         => ''o';
wwv_flow_imp.g_varchar2_table(114) := 'rders'','||wwv_flow.LF||
'      p_auto_rest_auth       => false'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords_metadata.ords.enable_object('||wwv_flow.LF||
'      p_en';
wwv_flow_imp.g_varchar2_table(115) := 'abled              => true, '||wwv_flow.LF||
'      p_object               => ''EBA_DEMO_REST_TASKS'','||wwv_flow.LF||
'      p_object_t';
wwv_flow_imp.g_varchar2_table(116) := 'ype          => ''TABLE'','||wwv_flow.LF||
'      p_object_alias         => ''tasks'','||wwv_flow.LF||
'      p_auto_rest_auth       => fa';
wwv_flow_imp.g_varchar2_table(117) := 'lse'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords_metadata.ords.enable_object('||wwv_flow.LF||
'      p_enabled              => true, '||wwv_flow.LF||
'      p_objec';
wwv_flow_imp.g_varchar2_table(118) := 't               => ''EBA_DEMO_REST_DEPARTMENT'','||wwv_flow.LF||
'      p_object_type          => ''TABLE'','||wwv_flow.LF||
'      p_obje';
wwv_flow_imp.g_varchar2_table(119) := 'ct_alias         => ''departments'','||wwv_flow.LF||
'      p_auto_rest_auth       => false'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ords_metadata.ord';
wwv_flow_imp.g_varchar2_table(120) := 's.enable_object('||wwv_flow.LF||
'      p_enabled              => true, '||wwv_flow.LF||
'      p_object               => ''EBA_DEMO_RE';
wwv_flow_imp.g_varchar2_table(121) := 'ST_STORES'','||wwv_flow.LF||
'      p_object_type          => ''TABLE'','||wwv_flow.LF||
'      p_object_alias         => ''stores'','||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(122) := ' p_auto_rest_auth       => false'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'  commit;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(97677868630390769)
,p_install_id=>wwv_flow_imp.id(94382806445719195)
,p_name=>'ORDS Definition'
,p_sequence=>100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
