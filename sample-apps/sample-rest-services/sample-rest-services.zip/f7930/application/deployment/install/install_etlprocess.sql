prompt --application/deployment/install/install_etlprocess
begin
--   Manifest
--     INSTALL: INSTALL-ETLProcess
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '----------------------------------------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '---'||wwv_flow.LF||
'-- REST Data Source and PLSQL ETL Process Package '||wwv_flow.LF||
'---------------------------------------------';
wwv_flow_imp.g_varchar2_table(3) := '----------------------------------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package eba_demo_rest';
wwv_flow_imp.g_varchar2_table(4) := '_etl_pkg as'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    procedure process_store_order_summary('||wwv_flow.LF||
'        p_email in varchar2'||wwv_flow.LF||
'    );'||wwv_flow.LF||
'    '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := 'end eba_demo_rest_etl_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package body eba_demo_rest_etl_pkg as'||wwv_flow.LF||
''||wwv_flow.LF||
'   procedure ';
wwv_flow_imp.g_varchar2_table(6) := 'process_store_order_summary( p_email in varchar2 ) as'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_store_context apex_exec.t_context;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '        l_store_columns apex_exec.t_columns;'||wwv_flow.LF||
'        l_store_id_idx pls_integer;'||wwv_flow.LF||
'        l_store_nam';
wwv_flow_imp.g_varchar2_table(8) := 'e_idx pls_integer;'||wwv_flow.LF||
'        l_order_context apex_exec.t_context;'||wwv_flow.LF||
'        l_order_columns apex_exec.t_';
wwv_flow_imp.g_varchar2_table(9) := 'columns;'||wwv_flow.LF||
'        l_order_store_id_idx pls_integer;'||wwv_flow.LF||
'        l_order_datetime_idx pls_integer;'||wwv_flow.LF||
''||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(10) := '  type t_store_rec is record ('||wwv_flow.LF||
'            store_id number,'||wwv_flow.LF||
'            store_name varchar2(255));'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(11) := '        type t_store_tab is table of t_store_rec index by pls_integer;'||wwv_flow.LF||
'        l_stores t_store_tab;';
wwv_flow_imp.g_varchar2_table(12) := ''||wwv_flow.LF||
'        l_store_count pls_integer := 0;'||wwv_flow.LF||
''||wwv_flow.LF||
'        type t_order_rec is record ('||wwv_flow.LF||
'            store_id ';
wwv_flow_imp.g_varchar2_table(13) := 'number,'||wwv_flow.LF||
'            order_datetime date);'||wwv_flow.LF||
''||wwv_flow.LF||
'        type t_order_tab is table of t_order_rec index by';
wwv_flow_imp.g_varchar2_table(14) := ' pls_integer;'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_orders t_order_tab;'||wwv_flow.LF||
'        l_order_count pls_integer := 0;'||wwv_flow.LF||
'        l_order';
wwv_flow_imp.g_varchar2_table(15) := '_datetime_str varchar2(50);'||wwv_flow.LF||
'        l_html_table clob;'||wwv_flow.LF||
'        l_report_line clob;'||wwv_flow.LF||
'        l_placeho';
wwv_flow_imp.g_varchar2_table(16) := 'lders clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        apex_exec.add_column(p_columns => l_store_columns, p_column_name => ''';
wwv_flow_imp.g_varchar2_table(17) := 'STORE_ID'');'||wwv_flow.LF||
'        apex_exec.add_column(p_columns => l_store_columns, p_column_name => ''STORE_NAME''';
wwv_flow_imp.g_varchar2_table(18) := ');'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_store_context := apex_exec.open_web_source_query('||wwv_flow.LF||
'            p_module_static_id => ''e';
wwv_flow_imp.g_varchar2_table(19) := 'ba_rest_stores'','||wwv_flow.LF||
'            p_columns => l_store_columns,'||wwv_flow.LF||
'            p_max_rows => 1000 );'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(20) := ' l_store_id_idx := apex_exec.get_column_position(l_store_context, ''STORE_ID'');'||wwv_flow.LF||
'        l_store_name_';
wwv_flow_imp.g_varchar2_table(21) := 'idx := apex_exec.get_column_position(l_store_context, ''STORE_NAME'');'||wwv_flow.LF||
''||wwv_flow.LF||
'        while apex_exec.next_r';
wwv_flow_imp.g_varchar2_table(22) := 'ow(l_store_context) loop'||wwv_flow.LF||
'            l_store_count := l_store_count + 1;'||wwv_flow.LF||
'            l_stores(l_stor';
wwv_flow_imp.g_varchar2_table(23) := 'e_count).store_id := apex_exec.get_number(l_store_context, l_store_id_idx);'||wwv_flow.LF||
'            l_stores(l_s';
wwv_flow_imp.g_varchar2_table(24) := 'tore_count).store_name := apex_exec.get_varchar2(l_store_context, l_store_name_idx);'||wwv_flow.LF||
'        end loo';
wwv_flow_imp.g_varchar2_table(25) := 'p;'||wwv_flow.LF||
''||wwv_flow.LF||
'        apex_exec.close(l_store_context);'||wwv_flow.LF||
'        apex_exec.add_column(p_columns => l_order_colu';
wwv_flow_imp.g_varchar2_table(26) := 'mns, p_column_name => ''STORE_ID'');'||wwv_flow.LF||
'        apex_exec.add_column(p_columns => l_order_columns, p_colu';
wwv_flow_imp.g_varchar2_table(27) := 'mn_name => ''ORDER_DATETIME'');'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_order_context := apex_exec.open_web_source_query('||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(28) := '   p_module_static_id => ''eba_rest_orders'','||wwv_flow.LF||
'            p_columns => l_order_columns,'||wwv_flow.LF||
'            p_';
wwv_flow_imp.g_varchar2_table(29) := 'max_rows => 1000 );'||wwv_flow.LF||
'        l_order_store_id_idx := apex_exec.get_column_position(l_order_context, ''';
wwv_flow_imp.g_varchar2_table(30) := 'STORE_ID'');'||wwv_flow.LF||
'        l_order_datetime_idx := apex_exec.get_column_position(l_order_context, ''ORDER_DA';
wwv_flow_imp.g_varchar2_table(31) := 'TETIME'');'||wwv_flow.LF||
''||wwv_flow.LF||
'        while apex_exec.next_row(l_order_context) loop'||wwv_flow.LF||
'            l_order_count := l_ord';
wwv_flow_imp.g_varchar2_table(32) := 'er_count + 1;'||wwv_flow.LF||
'            l_orders(l_order_count).store_id := apex_exec.get_number(l_order_context, ';
wwv_flow_imp.g_varchar2_table(33) := 'l_order_store_id_idx);'||wwv_flow.LF||
'            l_order_datetime_str := apex_exec.get_varchar2(l_order_context, l';
wwv_flow_imp.g_varchar2_table(34) := '_order_datetime_idx);'||wwv_flow.LF||
'            l_orders(l_order_count).order_datetime := to_date(l_order_datetime';
wwv_flow_imp.g_varchar2_table(35) := '_str, ''yyyy-mm-dd"t"hh24:mi:ss"z"'');'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        apex_exec.close(l_order_context);'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(36) := '       for l_i in 1 .. l_store_count loop'||wwv_flow.LF||
'            declare'||wwv_flow.LF||
'                l_total_orders number ';
wwv_flow_imp.g_varchar2_table(37) := ':= 0;'||wwv_flow.LF||
'                l_last_order_datetime date := null;'||wwv_flow.LF||
'            begin'||wwv_flow.LF||
'                for l_j ';
wwv_flow_imp.g_varchar2_table(38) := 'in 1 .. l_order_count loop'||wwv_flow.LF||
'                    if l_orders(l_j).store_id = l_stores(l_i).store_id th';
wwv_flow_imp.g_varchar2_table(39) := 'en'||wwv_flow.LF||
'                        l_total_orders := l_total_orders + 1;'||wwv_flow.LF||
'                        if l_last_o';
wwv_flow_imp.g_varchar2_table(40) := 'rder_datetime is null or l_orders(l_j).order_datetime > l_last_order_datetime then'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(41) := '           l_last_order_datetime := l_orders(l_j).order_datetime;'||wwv_flow.LF||
'                        end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(42) := '                  end if;'||wwv_flow.LF||
'                end loop;'||wwv_flow.LF||
'                insert into eba_demo_rest_storeo';
wwv_flow_imp.g_varchar2_table(43) := 'rdersummary ('||wwv_flow.LF||
'                    store_id,'||wwv_flow.LF||
'                    store_name,'||wwv_flow.LF||
'                    tota';
wwv_flow_imp.g_varchar2_table(44) := 'l_orders,'||wwv_flow.LF||
'                    last_order_datetime,'||wwv_flow.LF||
'                    load_timestamp)'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(45) := '   values ('||wwv_flow.LF||
'                    l_stores(l_i).store_id,'||wwv_flow.LF||
'                    l_stores(l_i).store_name';
wwv_flow_imp.g_varchar2_table(46) := ','||wwv_flow.LF||
'                    l_total_orders,'||wwv_flow.LF||
'                    l_last_order_datetime,'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(47) := ' sysdate );'||wwv_flow.LF||
'            end;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'        l_html_table := '''||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(48) := '     <table>'||wwv_flow.LF||
'                <tr>'||wwv_flow.LF||
'                <th>Store Name</th>'||wwv_flow.LF||
'                <th>Total Orde';
wwv_flow_imp.g_varchar2_table(49) := 'rs</th>'||wwv_flow.LF||
'                </tr>'||wwv_flow.LF||
'                '';'||wwv_flow.LF||
'        for l_rec in ('||wwv_flow.LF||
'            select store_nam';
wwv_flow_imp.g_varchar2_table(50) := 'e,'||wwv_flow.LF||
'                   total_orders'||wwv_flow.LF||
'            from eba_demo_rest_storeordersummary'||wwv_flow.LF||
'            orde';
wwv_flow_imp.g_varchar2_table(51) := 'r by store_name'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_report_line := ''<tr>'||wwv_flow.LF||
'                        <td>'' || a';
wwv_flow_imp.g_varchar2_table(52) := 'pex_escape.html(l_rec.store_name) || ''</td>'||wwv_flow.LF||
'                        <td>'' || apex_escape.html(l_rec.';
wwv_flow_imp.g_varchar2_table(53) := 'total_orders) || ''</td>'||wwv_flow.LF||
'                    </tr>'||wwv_flow.LF||
'                    '';'||wwv_flow.LF||
'            l_html_table :=';
wwv_flow_imp.g_varchar2_table(54) := ' l_html_table || l_report_line;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_html_table := l_html_table || ''</table>';
wwv_flow_imp.g_varchar2_table(55) := ''';'||wwv_flow.LF||
'        apex_json.initialize_clob_output;'||wwv_flow.LF||
'        apex_json.open_object;'||wwv_flow.LF||
'        apex_json.write(';
wwv_flow_imp.g_varchar2_table(56) := '''ORDER_SUMMARY_TABLE'', l_html_table);'||wwv_flow.LF||
'        apex_json.close_object;'||wwv_flow.LF||
'        l_placeholders := apex';
wwv_flow_imp.g_varchar2_table(57) := '_json.get_clob_output;'||wwv_flow.LF||
'        apex_json.free_output;'||wwv_flow.LF||
''||wwv_flow.LF||
'        apex_mail.send('||wwv_flow.LF||
'            p_from =>';
wwv_flow_imp.g_varchar2_table(58) := ' p_email,'||wwv_flow.LF||
'            p_to => p_email,'||wwv_flow.LF||
'            p_template_static_id => ''STORE_ORDER_SUMMARY'','||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(59) := '          p_placeholders => l_placeholders'||wwv_flow.LF||
'        );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'        apex_mail.push_queue;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(60) := ' apex_application.g_print_success_message := apex_lang.get_message(''P404.PROCESS.SUCCESS'');'||wwv_flow.LF||
'    exce';
wwv_flow_imp.g_varchar2_table(61) := 'ption'||wwv_flow.LF||
'        when others then'||wwv_flow.LF||
'            apex_exec.close(l_store_context);'||wwv_flow.LF||
'            apex_exec.c';
wwv_flow_imp.g_varchar2_table(62) := 'lose(l_order_context);'||wwv_flow.LF||
'            raise;'||wwv_flow.LF||
'    end process_store_order_summary;'||wwv_flow.LF||
'    '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_demo_r';
wwv_flow_imp.g_varchar2_table(63) := 'est_etl_pkg;'||wwv_flow.LF||
'/ ';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16909641997831357)
,p_install_id=>wwv_flow_imp.id(94382806445719195)
,p_name=>'ETLProcess'
,p_sequence=>130
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(16909741988831362)
,p_script_id=>wwv_flow_imp.id(16909641997831357)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_DEMO_REST_ETL_PKG'
);
wwv_flow_imp.component_end;
end;
/
