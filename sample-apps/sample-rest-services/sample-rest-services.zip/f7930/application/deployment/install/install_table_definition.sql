prompt --application/deployment/install/install_table_definition
begin
--   Manifest
--     INSTALL: INSTALL-Table Definition
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- ==========================================================================='||wwv_flow.LF||
'-- table definitions'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2) := '-- ==========================================================================='||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_dem';
wwv_flow_imp.g_varchar2_table(3) := 'o_rest_producttable ('||wwv_flow.LF||
'    product_id         number             not null enable,'||wwv_flow.LF||
'    product_name   ';
wwv_flow_imp.g_varchar2_table(4) := '    varchar2(255)      not null enable,'||wwv_flow.LF||
'    unit_price         number(10,2),'||wwv_flow.LF||
'    product_details    ';
wwv_flow_imp.g_varchar2_table(5) := 'blob,'||wwv_flow.LF||
'    product_image      blob,'||wwv_flow.LF||
'    image_mime_type    varchar2(512),'||wwv_flow.LF||
'    image_filename     varc';
wwv_flow_imp.g_varchar2_table(6) := 'har2(512),'||wwv_flow.LF||
'    image_charset      varchar2(512),'||wwv_flow.LF||
'    image_last_updated date,'||wwv_flow.LF||
'    constraint eba_dem';
wwv_flow_imp.g_varchar2_table(7) := 'o_rest_producttable_pk'||wwv_flow.LF||
'        primary key (product_id)'||wwv_flow.LF||
'        using index enable,'||wwv_flow.LF||
'    constraint e';
wwv_flow_imp.g_varchar2_table(8) := 'ba_demo_rest_product_json_c'||wwv_flow.LF||
'        check (product_details is json) enable'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo';
wwv_flow_imp.g_varchar2_table(9) := '_rest_order_workflow ('||wwv_flow.LF||
'    id               number generated always as identity,'||wwv_flow.LF||
'    user_id        ';
wwv_flow_imp.g_varchar2_table(10) := '  varchar2(100),'||wwv_flow.LF||
'    product_name     varchar2(255),'||wwv_flow.LF||
'    product_details  clob,'||wwv_flow.LF||
'    constraint eba_d';
wwv_flow_imp.g_varchar2_table(11) := 'emo_rest_order_workflow_pk'||wwv_flow.LF||
'        primary key (id)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_rest_purchaseorders ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(12) := '    id               number not null enable,'||wwv_flow.LF||
'    po               clob,'||wwv_flow.LF||
'    constraint eba_demo_rest';
wwv_flow_imp.g_varchar2_table(13) := '_purchaseorders_pk '||wwv_flow.LF||
'        primary key (id) '||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_rest_stores ('||wwv_flow.LF||
'    store_id  ';
wwv_flow_imp.g_varchar2_table(14) := '              number           not null enable,'||wwv_flow.LF||
'    store_name              varchar2(255)    not nul';
wwv_flow_imp.g_varchar2_table(15) := 'l enable,'||wwv_flow.LF||
'    web_address             varchar2(100),'||wwv_flow.LF||
'    physical_address        varchar2(512),'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(16) := 'latitude                number,'||wwv_flow.LF||
'    longitude               number,'||wwv_flow.LF||
'    logo                    blob';
wwv_flow_imp.g_varchar2_table(17) := ','||wwv_flow.LF||
'    logo_mime_type          varchar2(512),'||wwv_flow.LF||
'    logo_filename           varchar2(512),'||wwv_flow.LF||
'    logo_cha';
wwv_flow_imp.g_varchar2_table(18) := 'rset            varchar2(512),'||wwv_flow.LF||
'    logo_last_updated       date,'||wwv_flow.LF||
'    constraint eba_demo_rest_stores';
wwv_flow_imp.g_varchar2_table(19) := '_pk'||wwv_flow.LF||
'        primary key (store_id)'||wwv_flow.LF||
'        using index enable,'||wwv_flow.LF||
'    constraint eba_demo_rest_store_na';
wwv_flow_imp.g_varchar2_table(20) := 'me_u'||wwv_flow.LF||
'        unique (store_name)'||wwv_flow.LF||
'        using index enable,'||wwv_flow.LF||
'    constraint eba_demo_rest_store_at_l';
wwv_flow_imp.g_varchar2_table(21) := 'east_one_address_c'||wwv_flow.LF||
'        check (coalesce(web_address, physical_address) is not null) enable'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(22) := 'eate table eba_demo_rest_assignees ('||wwv_flow.LF||
'    id           number default on null to_number(sys_guid(), ''';
wwv_flow_imp.g_varchar2_table(23) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') not null enable,'||wwv_flow.LF||
'    full_name    varchar2(255 char)             ';
wwv_flow_imp.g_varchar2_table(24) := '   not null enable,'||wwv_flow.LF||
'    email        varchar2(255 char),'||wwv_flow.LF||
'    phone_number number,'||wwv_flow.LF||
'    created      d';
wwv_flow_imp.g_varchar2_table(25) := 'ate                             not null enable,'||wwv_flow.LF||
'    created_by   varchar2(255 char)                ';
wwv_flow_imp.g_varchar2_table(26) := ' ,'||wwv_flow.LF||
'    updated      date                             not null enable,'||wwv_flow.LF||
'    updated_by   varchar2(255 ';
wwv_flow_imp.g_varchar2_table(27) := 'char)                 ,'||wwv_flow.LF||
'    constraint eba_demo_rest_assignees_id_pk'||wwv_flow.LF||
'        primary key (id)'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(28) := '  using index enable'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_rest_customers ('||wwv_flow.LF||
'    customer_id   number         not';
wwv_flow_imp.g_varchar2_table(29) := ' null enable,'||wwv_flow.LF||
'    full_name     varchar2(255)  not null enable,'||wwv_flow.LF||
'    email_address varchar2(255)  not';
wwv_flow_imp.g_varchar2_table(30) := ' null enable,'||wwv_flow.LF||
'    constraint eba_demo_rest_customers_pk'||wwv_flow.LF||
'        primary key (customer_id)'||wwv_flow.LF||
'        us';
wwv_flow_imp.g_varchar2_table(31) := 'ing index enable,'||wwv_flow.LF||
'    constraint eba_demo_rest_customers_email_u'||wwv_flow.LF||
'        unique (email_address)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(32) := '    using index enable'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_rest_department ('||wwv_flow.LF||
'    deptno                   numb';
wwv_flow_imp.g_varchar2_table(33) := 'er,'||wwv_flow.LF||
'    dname                    varchar2(4000),'||wwv_flow.LF||
'    loc                      varchar2(4000),'||wwv_flow.LF||
'    co';
wwv_flow_imp.g_varchar2_table(34) := 'nstraint eba_demo_rest_department_pk'||wwv_flow.LF||
'        primary key (deptno)'||wwv_flow.LF||
'        using index enable'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'cre';
wwv_flow_imp.g_varchar2_table(35) := 'ate table eba_demo_rest_dept_local ('||wwv_flow.LF||
'    deptno number,'||wwv_flow.LF||
'    dname  varchar2(4000),'||wwv_flow.LF||
'    loc    varcha';
wwv_flow_imp.g_varchar2_table(36) := 'r2(4000),'||wwv_flow.LF||
'    primary key (deptno)'||wwv_flow.LF||
'        using index enable'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_rest_employe';
wwv_flow_imp.g_varchar2_table(37) := 'e ('||wwv_flow.LF||
'    empno                      number,'||wwv_flow.LF||
'    ename                      varchar2(4000),'||wwv_flow.LF||
'    job   ';
wwv_flow_imp.g_varchar2_table(38) := '                     varchar2(4000),'||wwv_flow.LF||
'    mgr                        number,'||wwv_flow.LF||
'    hiredate            ';
wwv_flow_imp.g_varchar2_table(39) := '       date,'||wwv_flow.LF||
'    sal                        number,'||wwv_flow.LF||
'    comm                       number,'||wwv_flow.LF||
'    deptn';
wwv_flow_imp.g_varchar2_table(40) := 'o                     number,'||wwv_flow.LF||
'   '||wwv_flow.LF||
'    constraint eba_demo_rest_employee_pk'||wwv_flow.LF||
'        primary key (empn';
wwv_flow_imp.g_varchar2_table(41) := 'o)'||wwv_flow.LF||
'        using index enable'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_rest_employeecustom ('||wwv_flow.LF||
'    deptno            ';
wwv_flow_imp.g_varchar2_table(42) := 'number,'||wwv_flow.LF||
'    empno             number,'||wwv_flow.LF||
'    emp_name          varchar2(50),'||wwv_flow.LF||
'    role_desc         varc';
wwv_flow_imp.g_varchar2_table(43) := 'har2(50),'||wwv_flow.LF||
'    hourly_rate       number(6,2),'||wwv_flow.LF||
'    bonus_eligibility varchar2(3),'||wwv_flow.LF||
''||wwv_flow.LF||
'    constraint eba_';
wwv_flow_imp.g_varchar2_table(44) := 'demo_rest_employeecustom_pk'||wwv_flow.LF||
'        primary key (empno)'||wwv_flow.LF||
'        using index enable'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create table ';
wwv_flow_imp.g_varchar2_table(45) := 'eba_demo_rest_orderitems ('||wwv_flow.LF||
'    order_id     number           not null enable,'||wwv_flow.LF||
'    line_item_id numbe';
wwv_flow_imp.g_varchar2_table(46) := 'r           not null enable,'||wwv_flow.LF||
'    product_id   number           not null,'||wwv_flow.LF||
'    unit_price   number(10,';
wwv_flow_imp.g_varchar2_table(47) := '2)     not null enable,'||wwv_flow.LF||
'    quantity     number           not null enable,'||wwv_flow.LF||
'    constraint eba_demo_r';
wwv_flow_imp.g_varchar2_table(48) := 'est_orderitems_pk'||wwv_flow.LF||
'        primary key (order_id, line_item_id)'||wwv_flow.LF||
'        using index enable,'||wwv_flow.LF||
'    const';
wwv_flow_imp.g_varchar2_table(49) := 'raint eba_demo_rest_orderitems_product_u'||wwv_flow.LF||
'        unique (product_id, order_id)'||wwv_flow.LF||
'        using index e';
wwv_flow_imp.g_varchar2_table(50) := 'nable'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_rest_orders ('||wwv_flow.LF||
'    order_id       number             not null enable,';
wwv_flow_imp.g_varchar2_table(51) := ''||wwv_flow.LF||
'    order_datetime timestamp(6)       not null enable,'||wwv_flow.LF||
'    customer_id    number             not nu';
wwv_flow_imp.g_varchar2_table(52) := 'll enable,'||wwv_flow.LF||
'    order_status   varchar2(10)       not null,'||wwv_flow.LF||
'    store_id       number             not';
wwv_flow_imp.g_varchar2_table(53) := ' null enable,'||wwv_flow.LF||
'    constraint eba_demo_rest_orders_pk'||wwv_flow.LF||
'        primary key (order_id)'||wwv_flow.LF||
'        using in';
wwv_flow_imp.g_varchar2_table(54) := 'dex enable,'||wwv_flow.LF||
'    constraint eba_demo_rest_order_status_c'||wwv_flow.LF||
'        check (order_status in (''CANCELLED'',';
wwv_flow_imp.g_varchar2_table(55) := '''COMPLETE'',''OPEN'',''PAID'',''REFUNDED'',''SHIPPED'')) enable'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_rest_storeordersumm';
wwv_flow_imp.g_varchar2_table(56) := 'ary ('||wwv_flow.LF||
'    store_id            number,'||wwv_flow.LF||
'    store_name          varchar2(255),'||wwv_flow.LF||
'    total_orders       ';
wwv_flow_imp.g_varchar2_table(57) := ' number,'||wwv_flow.LF||
'    last_order_datetime date,'||wwv_flow.LF||
'    load_timestamp      date default sysdate,'||wwv_flow.LF||
''||wwv_flow.LF||
'    constraint';
wwv_flow_imp.g_varchar2_table(58) := ' eba_demo_rest_storeordersummary_pk'||wwv_flow.LF||
'        primary key (store_id)'||wwv_flow.LF||
'        using index enable'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(59) := 'eate table eba_demo_rest_tasks ('||wwv_flow.LF||
'    id           number             not null enable,'||wwv_flow.LF||
'    project   ';
wwv_flow_imp.g_varchar2_table(60) := '   varchar2(30)       not null enable,'||wwv_flow.LF||
'    task_name    varchar2(255),'||wwv_flow.LF||
'    start_date   date        ';
wwv_flow_imp.g_varchar2_table(61) := '       not null enable,'||wwv_flow.LF||
'    end_date     date,'||wwv_flow.LF||
'    status       varchar2(30)       not null enable,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(62) := '    assigned_to  varchar2(30),'||wwv_flow.LF||
'    cost         number,'||wwv_flow.LF||
'    budget       number,'||wwv_flow.LF||
'    created      ti';
wwv_flow_imp.g_varchar2_table(63) := 'mestamp(6) with time zone not null enable,'||wwv_flow.LF||
'    created_by   varchar2(255)       ,'||wwv_flow.LF||
'    updated      t';
wwv_flow_imp.g_varchar2_table(64) := 'imestamp(6) with time zone not null enable,'||wwv_flow.LF||
'    updated_by   varchar2(255)       ,'||wwv_flow.LF||
'    constraint eb';
wwv_flow_imp.g_varchar2_table(65) := 'a_demo_rest_tasks_pk'||wwv_flow.LF||
'        primary key (id)'||wwv_flow.LF||
'        using index enable,'||wwv_flow.LF||
'    constraint eba_demo_re';
wwv_flow_imp.g_varchar2_table(66) := 'st_tasks_uk'||wwv_flow.LF||
'        unique (project, task_name)'||wwv_flow.LF||
'        using index enable'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- ================';
wwv_flow_imp.g_varchar2_table(67) := '==========================================================='||wwv_flow.LF||
'--  indexes & constraints'||wwv_flow.LF||
'-- ===========';
wwv_flow_imp.g_varchar2_table(68) := '================================================================'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_rest_custome';
wwv_flow_imp.g_varchar2_table(69) := 'rs_name_idx'||wwv_flow.LF||
'    on eba_demo_rest_customers (full_name);'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_rest_orders_customer_';
wwv_flow_imp.g_varchar2_table(70) := 'idx'||wwv_flow.LF||
'    on eba_demo_rest_orders (customer_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_rest_orders_store_idx'||wwv_flow.LF||
'    on e';
wwv_flow_imp.g_varchar2_table(71) := 'ba_demo_rest_orders (store_id);'||wwv_flow.LF||
'create index eba_demo_rest_orderitems_productid_idx'||wwv_flow.LF||
'    on eba_demo_';
wwv_flow_imp.g_varchar2_table(72) := 'rest_orderitems (product_id);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_rest_orderitems'||wwv_flow.LF||
'    add constraint eba_demo_re';
wwv_flow_imp.g_varchar2_table(73) := 'st_orderitems_order_id_fk'||wwv_flow.LF||
'        foreign key (order_id)'||wwv_flow.LF||
'        references eba_demo_rest_orders (or';
wwv_flow_imp.g_varchar2_table(74) := 'der_id)'||wwv_flow.LF||
'        on delete cascade enable;'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_rest_orderitems'||wwv_flow.LF||
'    add constraint e';
wwv_flow_imp.g_varchar2_table(75) := 'ba_demo_rest_orderitems_product_id_fk'||wwv_flow.LF||
'        foreign key (product_id)'||wwv_flow.LF||
'        references eba_demo_r';
wwv_flow_imp.g_varchar2_table(76) := 'est_producttable (product_id)'||wwv_flow.LF||
'        on delete cascade enable;'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_rest_orders'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(77) := '  add constraint eba_demo_rest_orders_customer_id_fk'||wwv_flow.LF||
'        foreign key (customer_id)'||wwv_flow.LF||
'        refer';
wwv_flow_imp.g_varchar2_table(78) := 'ences eba_demo_rest_customers (customer_id)'||wwv_flow.LF||
'        on delete cascade enable;'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_';
wwv_flow_imp.g_varchar2_table(79) := 'rest_orders'||wwv_flow.LF||
'    add constraint eba_demo_rest_orders_store_id_fk'||wwv_flow.LF||
'        foreign key (store_id)'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(80) := '   references eba_demo_rest_stores (store_id)'||wwv_flow.LF||
'        on delete cascade enable;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- ===========';
wwv_flow_imp.g_varchar2_table(81) := '================================================================'||wwv_flow.LF||
'--  view definitions'||wwv_flow.LF||
'-- ===========';
wwv_flow_imp.g_varchar2_table(82) := '================================================================'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace force editionabl';
wwv_flow_imp.g_varchar2_table(83) := 'e view customer_order_products ('||wwv_flow.LF||
'    order_id,'||wwv_flow.LF||
'    order_datetime,'||wwv_flow.LF||
'    order_status,'||wwv_flow.LF||
'    customer_id';
wwv_flow_imp.g_varchar2_table(84) := ','||wwv_flow.LF||
'    email_address,'||wwv_flow.LF||
'    full_name,'||wwv_flow.LF||
'    order_total,'||wwv_flow.LF||
'    items'||wwv_flow.LF||
') as'||wwv_flow.LF||
'    select'||wwv_flow.LF||
'        o.order_id'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(85) := '    , o.order_datetime'||wwv_flow.LF||
'      , o.order_status'||wwv_flow.LF||
'      , c.customer_id'||wwv_flow.LF||
'      , c.email_address'||wwv_flow.LF||
'      , ';
wwv_flow_imp.g_varchar2_table(86) := 'c.full_name'||wwv_flow.LF||
'      , sum(oi.quantity * oi.unit_price) order_total'||wwv_flow.LF||
'      , listagg(p.product_name, '', ';
wwv_flow_imp.g_varchar2_table(87) := ''' on overflow truncate ''...'' with count)'||wwv_flow.LF||
'          within group (order by oi.line_item_id) items'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(88) := ' from eba_demo_rest_orders o'||wwv_flow.LF||
'    join eba_demo_rest_orderitems oi'||wwv_flow.LF||
'      on o.order_id = oi.order_id'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(89) := '    join eba_demo_rest_customers c'||wwv_flow.LF||
'      on o.customer_id = c.customer_id'||wwv_flow.LF||
'    join eba_demo_rest_pro';
wwv_flow_imp.g_varchar2_table(90) := 'ducttable p'||wwv_flow.LF||
'      on oi.product_id = p.product_id'||wwv_flow.LF||
'    group by'||wwv_flow.LF||
'        o.order_id'||wwv_flow.LF||
'      , o.order_da';
wwv_flow_imp.g_varchar2_table(91) := 'tetime'||wwv_flow.LF||
'      , o.order_status'||wwv_flow.LF||
'      , c.customer_id'||wwv_flow.LF||
'      , c.email_address'||wwv_flow.LF||
'      , c.full_name'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(92) := 'reate or replace force editionable view product_orders ('||wwv_flow.LF||
'    product_name,'||wwv_flow.LF||
'    order_status,'||wwv_flow.LF||
'    tot';
wwv_flow_imp.g_varchar2_table(93) := 'al_sales,'||wwv_flow.LF||
'    order_count'||wwv_flow.LF||
') as'||wwv_flow.LF||
'    select'||wwv_flow.LF||
'        p.product_name'||wwv_flow.LF||
'      , o.order_status'||wwv_flow.LF||
'      , sum(';
wwv_flow_imp.g_varchar2_table(94) := 'oi.quantity * oi.unit_price) total_sales'||wwv_flow.LF||
'      , count(*) order_count'||wwv_flow.LF||
'    from eba_demo_rest_orders ';
wwv_flow_imp.g_varchar2_table(95) := 'o'||wwv_flow.LF||
'    join eba_demo_rest_orderitems oi'||wwv_flow.LF||
'      on o.order_id = oi.order_id'||wwv_flow.LF||
'    join eba_demo_rest_cust';
wwv_flow_imp.g_varchar2_table(96) := 'omers c'||wwv_flow.LF||
'      on o.customer_id = c.customer_id'||wwv_flow.LF||
'    join eba_demo_rest_producttable p'||wwv_flow.LF||
'      on oi.pro';
wwv_flow_imp.g_varchar2_table(97) := 'duct_id = p.product_id'||wwv_flow.LF||
'    group by'||wwv_flow.LF||
'        p.product_name'||wwv_flow.LF||
'      , o.order_status'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create or repla';
wwv_flow_imp.g_varchar2_table(98) := 'ce force editionable view product_reviews ('||wwv_flow.LF||
'    product_name,'||wwv_flow.LF||
'    rating,'||wwv_flow.LF||
'    avg_rating,'||wwv_flow.LF||
'    review';
wwv_flow_imp.g_varchar2_table(99) := ''||wwv_flow.LF||
') as'||wwv_flow.LF||
'    select'||wwv_flow.LF||
'        p.product_name'||wwv_flow.LF||
'      , r.rating'||wwv_flow.LF||
'      , round(avg(r.rating) over (partition';
wwv_flow_imp.g_varchar2_table(100) := ' by product_name), 2) avg_rating'||wwv_flow.LF||
'      , r.review'||wwv_flow.LF||
'    from eba_demo_rest_producttable p'||wwv_flow.LF||
'    , json_t';
wwv_flow_imp.g_varchar2_table(101) := 'able('||wwv_flow.LF||
'        p.product_details, ''$'''||wwv_flow.LF||
'        columns nested path ''$.reviews[*]'''||wwv_flow.LF||
'            columns ';
wwv_flow_imp.g_varchar2_table(102) := '('||wwv_flow.LF||
'                rating number path ''$.rating'','||wwv_flow.LF||
'                review varchar2(4000) path ''$.revie';
wwv_flow_imp.g_varchar2_table(103) := 'w'''||wwv_flow.LF||
'            )'||wwv_flow.LF||
'      ) r'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace force editionable view store_orders ('||wwv_flow.LF||
'    total,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(104) := ' store_name,'||wwv_flow.LF||
'    address,'||wwv_flow.LF||
'    latitude,'||wwv_flow.LF||
'    longitude,'||wwv_flow.LF||
'    order_status,'||wwv_flow.LF||
'    order_count,'||wwv_flow.LF||
'    total_';
wwv_flow_imp.g_varchar2_table(105) := 'sales'||wwv_flow.LF||
') as'||wwv_flow.LF||
'    select'||wwv_flow.LF||
'        case grouping_id(store_name, order_status)'||wwv_flow.LF||
'            when 1 then ''ST';
wwv_flow_imp.g_varchar2_table(106) := 'ORE TOTAL'''||wwv_flow.LF||
'            when 2 then ''STATUS TOTAL'''||wwv_flow.LF||
'            when 3 then ''GRAND TOTAL'''||wwv_flow.LF||
'        end ';
wwv_flow_imp.g_varchar2_table(107) := 'total'||wwv_flow.LF||
'      , s.store_name'||wwv_flow.LF||
'      , coalesce(s.web_address, s.physical_address) address'||wwv_flow.LF||
'      , s.lat';
wwv_flow_imp.g_varchar2_table(108) := 'itude'||wwv_flow.LF||
'      , s.longitude'||wwv_flow.LF||
'      , o.order_status'||wwv_flow.LF||
'      , count(distinct o.order_id) order_count'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(109) := '  , sum(oi.quantity * oi.unit_price) total_sales'||wwv_flow.LF||
'    from eba_demo_rest_stores s'||wwv_flow.LF||
'    join eba_demo_r';
wwv_flow_imp.g_varchar2_table(110) := 'est_orders o'||wwv_flow.LF||
'      on s.store_id = o.store_id'||wwv_flow.LF||
'    join eba_demo_rest_orderitems oi'||wwv_flow.LF||
'      on o.order_';
wwv_flow_imp.g_varchar2_table(111) := 'id = oi.order_id'||wwv_flow.LF||
'    group by '||wwv_flow.LF||
'        grouping sets ('||wwv_flow.LF||
'            (s.store_name, coalesce(s.web_add';
wwv_flow_imp.g_varchar2_table(112) := 'ress, s.physical_address), s.latitude, s.longitude),'||wwv_flow.LF||
'            (s.store_name, coalesce(s.web_addre';
wwv_flow_imp.g_varchar2_table(113) := 'ss, s.physical_address), s.latitude, s.longitude, o.order_status),'||wwv_flow.LF||
'            o.order_status,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(114) := '       ()'||wwv_flow.LF||
'        )'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace force editionable view store_orders_status ('||wwv_flow.LF||
'    store_name';
wwv_flow_imp.g_varchar2_table(115) := ','||wwv_flow.LF||
'    address,'||wwv_flow.LF||
'    latitude,'||wwv_flow.LF||
'    longitude,'||wwv_flow.LF||
'    order_status,'||wwv_flow.LF||
'    order_count,'||wwv_flow.LF||
'    total_sales'||wwv_flow.LF||
') as'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(116) := '    select'||wwv_flow.LF||
'        s.store_name'||wwv_flow.LF||
'      , coalesce(s.web_address, s.physical_address) address'||wwv_flow.LF||
'      , ';
wwv_flow_imp.g_varchar2_table(117) := 's.latitude'||wwv_flow.LF||
'      , s.longitude'||wwv_flow.LF||
'      , o.order_status'||wwv_flow.LF||
'      , count(distinct o.order_id) order_count';
wwv_flow_imp.g_varchar2_table(118) := ''||wwv_flow.LF||
'      , sum(oi.quantity * oi.unit_price) total_sales'||wwv_flow.LF||
'    from eba_demo_rest_stores s'||wwv_flow.LF||
'    join eba_d';
wwv_flow_imp.g_varchar2_table(119) := 'emo_rest_orders o'||wwv_flow.LF||
'      on s.store_id = o.store_id'||wwv_flow.LF||
'    join eba_demo_rest_orderitems oi'||wwv_flow.LF||
'      on o.o';
wwv_flow_imp.g_varchar2_table(120) := 'rder_id = oi.order_id'||wwv_flow.LF||
'    group by'||wwv_flow.LF||
'        s.store_name'||wwv_flow.LF||
'      , coalesce(s.web_address, s.physical_a';
wwv_flow_imp.g_varchar2_table(121) := 'ddress)'||wwv_flow.LF||
'      , s.latitude'||wwv_flow.LF||
'      , s.longitude'||wwv_flow.LF||
'      , o.order_status'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- =======================';
wwv_flow_imp.g_varchar2_table(122) := '===================================================='||wwv_flow.LF||
'--  triggers'||wwv_flow.LF||
'-- ===============================';
wwv_flow_imp.g_varchar2_table(123) := '============================================'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_demo_rest_employee_t'||wwv_flow.LF||
'bef';
wwv_flow_imp.g_varchar2_table(124) := 'ore insert on eba_demo_rest_employee'||wwv_flow.LF||
'for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.empno is null then'||wwv_flow.LF||
'        selec';
wwv_flow_imp.g_varchar2_table(125) := 't eba_demo_emp_seq.nextval into :new.empno from sys.dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(98571459512689208)
,p_install_id=>wwv_flow_imp.id(94382806445719195)
,p_name=>'Table Definition'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98571549692689208)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_ASSIGNEES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98571784955689209)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_CUSTOMERS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98571954211689209)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_DEPARTMENT'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98572219961689209)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_DEPT_LOCAL'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98572407575689209)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_EMPLOYEE'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98572612565689209)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_EMPLOYEECUSTOM'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98572753200689209)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_ORDERITEMS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98572971952689209)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_ORDERS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98573127698689209)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_PRODUCTTABLE'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98573409768689209)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_PURCHASEORDERS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98573814004689209)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_STOREORDERSUMMARY'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98573926035689209)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_STORES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98574183217689209)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_TASKS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98574364560689209)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_TMDBCREDS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(98574537417689209)
,p_script_id=>wwv_flow_imp.id(98571459512689208)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REST_TODOS'
);
wwv_flow_imp.component_end;
end;
/
