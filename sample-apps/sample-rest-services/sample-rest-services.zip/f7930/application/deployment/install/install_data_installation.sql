prompt --application/deployment/install/install_data_installation
begin
--   Manifest
--     INSTALL: INSTALL-Data installation
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(101142335494412475)
,p_install_id=>wwv_flow_imp.id(94382806445719195)
,p_name=>'Data installation'
,p_sequence=>120
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-------------------------------------------------------------------------------------------------------',
'-- Reset And Load Data Package ',
'-------------------------------------------------------------------------------------------------------',
'',
'',
'create or replace package eba_demo_rest_data_pkg as',
'',
'    procedure clear_data;',
'    -- clears all the data in the database tables',
'',
'    procedure load_data;',
'    -- loads data into the database tables',
'    procedure reset_data;',
'',
'end eba_demo_rest_data_pkg;',
'/',
'create or replace package body eba_demo_rest_data_pkg as',
'',
'    procedure clear_data is',
'        begin',
'            delete from eba_demo_rest_assignees;',
'            delete from eba_demo_rest_customers;',
'            delete from eba_demo_rest_department;',
'            delete from eba_demo_rest_employee;',
'            delete from eba_demo_rest_employeecustom;',
'            delete from eba_demo_rest_orderitems;',
'            delete from eba_demo_rest_orders;',
'            delete from eba_demo_rest_producttable;',
'            delete from eba_demo_rest_purchaseorders;',
'            delete from eba_demo_rest_stores;',
'            delete from eba_demo_rest_tasks;',
'            delete from eba_demo_rest_dept_local;',
'        end clear_data;',
'',
'',
'    procedure load_data is',
'        begin',
'',
'',
'            -- department data ',
'',
'            insert into eba_demo_rest_department (deptno, dname, loc) values (10, ''ACCOUNTING'', ''NEW YORK'');',
'            insert into eba_demo_rest_department (deptno, dname, loc) values (20, ''RESEARCH'',   ''DALLAS'');',
'            insert into eba_demo_rest_department (deptno, dname, loc) values (30, ''SALES'',      ''CHICAGO'');',
'            insert into eba_demo_rest_department (deptno, dname, loc) values (40, ''OPERATIONS'', ''BOSTON'');',
'',
'            -- dept local ',
'',
'            insert into eba_demo_rest_dept_local (deptno, dname, loc) values (10, ''ACCOUNTING'', ''NEW YORK'');',
'            insert into eba_demo_rest_dept_local (deptno, dname, loc) values (20, ''RESEARCH'',   ''DALLAS'');',
'            insert into eba_demo_rest_dept_local (deptno, dname, loc) values (30, ''SALES'',      ''CHICAGO'');',
'            insert into eba_demo_rest_dept_local (deptno, dname, loc) values (40, ''OPERATIONS'', ''BOSTON'');',
'',
'',
'            -- assignes Data ',
'            insert into eba_demo_rest_assignees (id, full_name, email, phone_number, created, created_by, updated, updated_by) values (1,''Landon Glover'',''wubju@example.com'',70,sysdate,null,sysdate,null);',
'            insert into eba_demo_rest_assignees (id, full_name, email, phone_number, created, created_by, updated, updated_by) values (2,''Jack Jackson'',''buoki@example.com'',97,sysdate,null,sysdate,null);',
'            insert into eba_demo_rest_assignees (id, full_name, email, phone_number, created, created_by, updated, updated_by) values (3,''Grace Dennis'',''wudi@example.com'',20,sysdate,null,sysdate,null);',
'            insert into eba_demo_rest_assignees (id, full_name, email, phone_number, created, created_by, updated, updated_by) values (4,''Cecelia Jennings'',''razworgaz@example.com'',97,sysdate,null,sysdate,null);',
'            insert into eba_demo_rest_assignees (id, full_name, email, phone_number, created, created_by, updated, updated_by) values (5,''George Klein'',''it@example.com'',75,sysdate,null,sysdate,null);',
'            insert into eba_demo_rest_assignees (id, full_name, email, phone_number, created, created_by, updated, updated_by) values (6,''Elnora Payne'',''ketbeun@example.com'',84,sysdate,null,sysdate,null);',
'            insert into eba_demo_rest_assignees (id, full_name, email, phone_number, created, created_by, updated, updated_by) values (7,''Aaron Erickson'',''ze@example.com'',86,sysdate,null,sysdate,null);',
'            insert into eba_demo_rest_assignees (id, full_name, email, phone_number, created, created_by, updated, updated_by) values (8,''Elizabeth Wilkins'',''uglitma@example.com'',58,sysdate,null,sysdate,null);',
'            insert into eba_demo_rest_assignees (id, full_name, email, phone_number, created, created_by, updated, updated_by) values (9,''Philip Brewer'',''pi@example.com'',18,sysdate,null,sysdate,null);',
'            insert into eba_demo_rest_assignees (id, full_name, email, phone_number, created, created_by, updated, updated_by) values (10,''Katie Anderson'',''binotse@example.com'',78,sysdate,null,sysdate,null);',
'',
'            -- customers DAta ',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (1,  ''Tammy Bryant'',      ''tammy.bryant@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (2,  ''Roy White'',         ''roy.white@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (3,  ''Gary Jenkins'',      ''gary.jenkins@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (4,  ''Victor Morris'',     ''victor.morris@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (5,  ''Beverly Hughes'',    ''beverly.hughes@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (6,  ''Evelyn Torres'',     ''evelyn.torres@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (7,  ''Carl Lee'',          ''carl.lee@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (8,  ''Douglas Flores'',    ''douglas.flores@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (9,  ''Norma Robinson'',    ''norma.robinson@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (10, ''Gregory Sanchez'',   ''gregory.sanchez@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (11, ''Judy Evans'',        ''judy.evans@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (12, ''Jean Patterson'',    ''jean.patterson@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (13, ''Michelle Ramirez'',  ''michelle.ramirez@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (14, ''Elizabeth Martinez'',''elizabeth.martinez@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (15, ''Walter Rogers'',     ''walter.rogers@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (16, ''Ralph Foster'',      ''ralph.foster@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (17, ''Tina Simmons'',      ''tina.simmons@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (18, ''Peter Jones'',       ''peter.jones@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (19, ''Kathryn Rogers'',    ''kathryn.rogers@example.com'');',
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (20, ''Dennis Lopez'',      ''dennis.lopez@example.com'');',
'',
'',
'',
'            -- employee data ',
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8839, ''MARTIN'', null, 8902, to_date(''2022-11-17'',''YYYY-MM-DD''), 5000, 500, 10);',
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8698, ''BERNARD'', ''DIRECTEUR'', 8839, to_date(''2023-05-01'',''YYYY-MM-DD''), 2000, 285, 30);',
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8782, ''PETIT'', ''DIRECTEUR'', 8839, to_date(''2023-06-09'',''YYYY-MM-DD''), 2450, 245, 10);',
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8566, ''DUBOIS'', ''DIRECTEUR'', 8839, to_date(''2022-04-02'',''YYYY-MM-DD''), 2975, 298, 20);',
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8788, ''ROUX'', ''ANALYSTE'', 8566, to_date(''2023-12-09'',''YYYY-MM-DD''), 3000, 300, 20);',
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8902, ''DUPONT'', ''ANALYSTE'', 8566, to_date(''2022-12-05'',''YYYY-MM-DD''), 3000, 300, 20);',
unistr('            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8369, ''VINCENT'', ''EMPLOY\00C9'', 8902, to_date(''2022-12-17'',''YYYY-MM-DD''), 800, null, 20);'),
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8499, ''LEFEVRE'', ''VENDEUR'', 8698, to_date(''2023-02-20'',''YYYY-MM-DD''), 1600, 300, 30);',
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8521, ''LAMBERT'', ''VENDEUR'', 8698, to_date(''2023-02-22'',''YYYY-MM-DD''), 1250, 500, 30);',
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8654, ''GARNIER'', ''VENDEUR'', 8698, to_date(''2023-09-28'',''YYYY-MM-DD''), 1250, 1400, 30);',
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8844, ''MORIN'', ''VENDEUR'', 8698, to_date(''2023-09-08'',''YYYY-MM-DD''), 1500, 0, 30);',
unistr('            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8876, ''CL\00C9MENT'', ''EMPLOY\00C9'', 8788, to_date(''2024-01-02'',''YYYY-MM-DD''), 1100, 110, 20);'),
unistr('            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8900, ''SIMON'', ''EMPLOY\00C9'', 8698, to_date(''2022-12-05'',''YYYY-MM-DD''), 950, null, 30);'),
unistr('            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8934, ''LAURENT'', ''EMPLOY\00C9'', 8782, to_date(''2023-01-23'',''YYYY-MM-DD''), 1500, null, 10);'),
'',
'',
'',
'            -- employee custom ',
'            insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bonus_eligibility) values (20, 7369, ''SMITH'',              ''Junior Clerk'',        15.5,  ''Yes'');',
'            insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bonus_eligibility) values (30, 7499, ''ALLEN'',              ''Sales Associate'',     18,    ''Yes'');',
'            insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bonus_eligibility) values (30, 7521, ''WARD'',               ''Sales Associate'',     18.5,  ''Yes'');',
'            insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bonus_eligibility) values (20, 7566, ''JONES'',              ''Operations Manager'',  25,    ''Yes'');',
'            insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bonus_eligibility) values (30, 7654, ''MARTIN'',             ''Sales Representative'',19,    ''Yes'');',
'            insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bonus_eligibility) values (30, 7698, ''BLAKE'',              ''Senior Manager'',      28,    ''Yes'');',
'            insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bonus_eligibility) values (10, 7782, ''CLARK'',              ''Admin Manager'',       23,    ''Yes'');',
'            insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bonus_eligibility) values (20, 7788, ''SCOTT'',              ''Senior Analyst'',      27,    ''Yes'');',
'            insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bonus_eligibility) values (10, 7839, ''KING'',               ''Executive Director'',  35,    ''Yes'');',
'            insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bonus_eligibility) values (30, 7844, ''TURNER'',             ''Sales Representative'',18.75,''Yes'');',
'            insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bonus_eligibility) values (20, 7876, ''ADAMS'',              ''Junior Clerk'',        15.75,''No'');',
'            insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bonus_eligibility) values (30, 7900, ''JAMES'',              ''Junior Clerk'',        16,    ''No'');',
'            insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bonus_eligibility) values (20, 7902, ''FORD'',               ''Senior Analyst'',      28,    ''Yes'');',
'            insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bonus_eligibility) values (10, 7934, ''MILLER'',             ''Junior Clerk'',        16.5,  ''No'');',
'',
'',
'        -- stores Data ',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (1,''Online'',''https://www.example.com'',''Redwood Shores 500 Oracle Parkway'',39.529395,-112.267237);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (2,''San Francisco'',null,''Redwood Shores 500 Oracle Parkway Redwood Shores, CA 94065'',37.529395,-122.267237);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (3,''Seattle'',null,''1501 Fourth Avenue Suite 1800 Seattle, WA 98101'',47.6053,-122.33221);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (4,''New York City'',null,''205 Lexington Ave7th Floor New York, NY 10016'',40.745216,-73.980518);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (5,''Chicago'',null,''233 South Wacker Dr. 45th Floor Chicago, IL 60606'',41.878751,-87.636675);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (6,''London'',null,''One South Place London EC2M 2RB'',51.519281,-0.087296);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (7,''Bucharest'',null,''Floreasca Park43 Soseaua Pipera, corp B.Sector 2 Bucharest , 014254 RO'',44.43225,26.10626);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (8,''Berlin'',null,''Behrenstrabe 42 (Humboldt Carre) 10117 Berlin'',52.5161,13.3873);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (9,''Utrecht'',null,''Hertogswetering 163-167, 3543 AS Utrecht, Netherlands'',52.103263,5.061644);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (10,''Madrid'',null,''C/ Jose Echegaray 6BLas Rozas28230 Madrid'',40.4929,-3.8737);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (11,''Johannesburg'',null,''Woodmead North Office Park 54 Maxwell Drive Jukskeiview, Sandton, 2196'',-26.044222,28.094662);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (12,''Lagos'',null,''1391 Tiamiyu Savage St, Victoria Island, Lagos, Nigeria'',6.42806,3.42199);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (13,''Bengaluru'',null,''193, Bannerghatta Main Rd, Industrial Area, Stage 2, BTM Layout, Bengaluru, Karnataka 560076, India'',12.89'
||'39,77.5978);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (14,''Mumbai'',null,''First International Financial Center Unit No. 501, Level 5 No. C54 & 55, G Block Bandra Kurla Complex CTS No.'
||' 4207, Kolekalyan Village Mumbai - 400 051 India'',19.069405,72.870143);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (15,''New Dehli'',null,''F-01/02, First Floor Salcon Rasvillas D-1, District Centre, Saket, New Delhi - 110017 India'',28.527693,77.'
||'220135);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (16,''Sydney'',null,''Riverside Corporate Park 4 Julius Avenue North Ryde NSW 2113'',-33.797279,151.143826);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (17,''Perth'',null,''Level 9 225 St Georges Terrace Perth WA 6000'',-31.953715,115.851645);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (18,''Sao Paulo'',null,''Rua Dr. Jose Aureo Bustamante, 455 - Vila Cordeiro, CEP 04710-090 Sao Paulo'',-23.5475,-46.63611);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (19,''Buenos Aires'',null,''Juana Manso 1069, Buenos Aires, Argentina'',-34.61016,-58.362867);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (20,''Mexico City'',null,''Montes Urales # 470 P3 Col. Lomas de Chapultepec Delegacion Miguel Hidalgo - C.P. 11000'',19.428489,-99.2'
||'05745);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (21,''Bejing'',null,''China, Beijing Shi, Haidian Qu, Dongbeiwang W Rd, 8, 100085'',40.0572,116.290061);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (22,''Tokyo'',null,''2 Chome-5-? Kitaaoyama, Minato City, Tokyo 107-0061, Japan'',35.671534,139.718584);',
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (23,''Tel Aviv'',null,''B, Aharon Bart St 18, Petah Tikva, 4951400, Israel'',32.100664,34.862138);',
'',
'            -- Orders data',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (453,to_timestamp(''2022-07-23 12.13.03'',''YYYY-MM-DD HH24.MI.SS''),4,''COMPLETE'',4);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (506,to_timestamp(''2022-08-07 10.56.44'',''YYYY-MM-DD HH24.MI.SS''),4,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (513,to_timestamp(''2022-08-09 08.00.22'',''YYYY-MM-DD HH24.MI.SS''),15,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (544,to_timestamp(''2022-08-16 18.32.10'',''YYYY-MM-DD HH24.MI.SS''),3,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (585,to_timestamp(''2022-08-26 11.02.38'',''YYYY-MM-DD HH24.MI.SS''),4,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (608,to_timestamp(''2022-09-01 08.01.41'',''YYYY-MM-DD HH24.MI.SS''),3,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (672,to_timestamp(''2022-09-13 01.37.34'',''YYYY-MM-DD HH24.MI.SS''),4,''COMPLETE'',4);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (687,to_timestamp(''2022-09-17 00.09.10'',''YYYY-MM-DD HH24.MI.SS''),16,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (707,to_timestamp(''2022-09-20 18.12.35'',''YYYY-MM-DD HH24.MI.SS''),5,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (760,to_timestamp(''2022-09-29 07.19.53'',''YYYY-MM-DD HH24.MI.SS''),19,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (761,to_timestamp(''2022-09-29 08.35.11'',''YYYY-MM-DD HH24.MI.SS''),11,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (765,to_timestamp(''2022-09-29 21.36.52'',''YYYY-MM-DD HH24.MI.SS''),2,''COMPLETE'',2);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (766,to_timestamp(''2022-09-30 00.38.08'',''YYYY-MM-DD HH24.MI.SS''),3,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (769,to_timestamp(''2022-09-30 02.49.28'',''YYYY-MM-DD HH24.MI.SS''),6,''REFUNDED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (808,to_timestamp(''2022-10-08 04.06.33'',''YYYY-MM-DD HH24.MI.SS''),14,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (832,to_timestamp(''2022-10-12 23.16.40'',''YYYY-MM-DD HH24.MI.SS''),3,''COMPLETE'',3);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (839,to_timestamp(''2022-10-14 13.59.20'',''YYYY-MM-DD HH24.MI.SS''),12,''COMPLETE'',12);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (862,to_timestamp(''2022-10-19 14.34.20'',''YYYY-MM-DD HH24.MI.SS''),7,''COMPLETE'',7);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (899,to_timestamp(''2022-10-27 09.42.00'',''YYYY-MM-DD HH24.MI.SS''),17,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (920,to_timestamp(''2022-10-30 17.59.30'',''YYYY-MM-DD HH24.MI.SS''),4,''COMPLETE'',4);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (928,to_timestamp(''2022-10-31 17.07.56'',''YYYY-MM-DD HH24.MI.SS''),9,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (943,to_timestamp(''2022-11-03 16.41.53'',''YYYY-MM-DD HH24.MI.SS''),10,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (950,to_timestamp(''2022-11-05 07.02.43'',''YYYY-MM-DD HH24.MI.SS''),7,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (960,to_timestamp(''2022-11-06 21.18.36'',''YYYY-MM-DD HH24.MI.SS''),11,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (968,to_timestamp(''2022-11-08 00.30.18'',''YYYY-MM-DD HH24.MI.SS''),9,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (972,to_timestamp(''2022-11-09 02.12.47'',''YYYY-MM-DD HH24.MI.SS''),6,''COMPLETE'',6);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (986,to_timestamp(''2022-11-11 19.03.57'',''YYYY-MM-DD HH24.MI.SS''),10,''CANCELLED'',10);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (993,to_timestamp(''2022-11-13 10.16.45'',''YYYY-MM-DD HH24.MI.SS''),8,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1052,to_timestamp(''2022-11-22 17.14.32'',''YYYY-MM-DD HH24.MI.SS''),13,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1058,to_timestamp(''2022-11-24 03.58.10'',''YYYY-MM-DD HH24.MI.SS''),6,''CANCELLED'',6);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1082,to_timestamp(''2022-11-28 05.29.33'',''YYYY-MM-DD HH24.MI.SS''),8,''CANCELLED'',8);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1102,to_timestamp(''2022-12-01 22.25.32'',''YYYY-MM-DD HH24.MI.SS''),9,''COMPLETE'',9);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1,to_timestamp(''2022-02-25 02.24.33'',''YYYY-MM-DD HH24.MI.SS''),3,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (3,to_timestamp(''2022-03-02 12.21.18'',''YYYY-MM-DD HH24.MI.SS''),18,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (5,to_timestamp(''2022-03-04 07.05.41'',''YYYY-MM-DD HH24.MI.SS''),2,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (7,to_timestamp(''2022-03-14 14.01.22'',''YYYY-MM-DD HH24.MI.SS''),9,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (17,to_timestamp(''2022-03-19 20.51.57'',''YYYY-MM-DD HH24.MI.SS''),16,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (20,to_timestamp(''2022-03-21 23.11.43'',''YYYY-MM-DD HH24.MI.SS''),3,''COMPLETE'',3);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (63,to_timestamp(''2022-04-11 19.21.35'',''YYYY-MM-DD HH24.MI.SS''),3,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (78,to_timestamp(''2022-04-17 23.00.11'',''YYYY-MM-DD HH24.MI.SS''),20,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (79,to_timestamp(''2022-04-18 16.39.13'',''YYYY-MM-DD HH24.MI.SS''),14,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (82,to_timestamp(''2022-04-19 13.24.05'',''YYYY-MM-DD HH24.MI.SS''),13,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (92,to_timestamp(''2022-04-21 21.25.03'',''YYYY-MM-DD HH24.MI.SS''),17,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (125,to_timestamp(''2022-05-01 01.45.50'',''YYYY-MM-DD HH24.MI.SS''),12,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (132,to_timestamp(''2022-05-02 14.19.08'',''YYYY-MM-DD HH24.MI.SS''),17,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (159,to_timestamp(''2022-05-11 01.56.08'',''YYYY-MM-DD HH24.MI.SS''),1,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (182,to_timestamp(''2022-05-16 17.00.13'',''YYYY-MM-DD HH24.MI.SS''),1,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (196,to_timestamp(''2022-05-19 05.57.59'',''YYYY-MM-DD HH24.MI.SS''),8,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (201,to_timestamp(''2022-05-20 00.52.12'',''YYYY-MM-DD HH24.MI.SS''),1,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (204,to_timestamp(''2022-05-21 00.43.26'',''YYYY-MM-DD HH24.MI.SS''),6,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (240,to_timestamp(''2022-05-28 13.31.20'',''YYYY-MM-DD HH24.MI.SS''),8,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (290,to_timestamp(''2022-06-13 02.12.59'',''YYYY-MM-DD HH24.MI.SS''),15,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (298,to_timestamp(''2022-06-14 09.34.20'',''YYYY-MM-DD HH24.MI.SS''),3,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (306,to_timestamp(''2022-06-16 16.24.36'',''YYYY-MM-DD HH24.MI.SS''),5,''COMPLETE'',5);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (307,to_timestamp(''2022-06-16 17.31.39'',''YYYY-MM-DD HH24.MI.SS''),3,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (331,to_timestamp(''2022-06-24 02.29.17'',''YYYY-MM-DD HH24.MI.SS''),5,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (349,to_timestamp(''2022-06-29 20.24.23'',''YYYY-MM-DD HH24.MI.SS''),14,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (401,to_timestamp(''2022-07-11 22.55.57'',''YYYY-MM-DD HH24.MI.SS''),16,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (430,to_timestamp(''2022-07-17 08.56.02'',''YYYY-MM-DD HH24.MI.SS''),8,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (437,to_timestamp(''2022-07-18 18.41.45'',''YYYY-MM-DD HH24.MI.SS''),10,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values '))
);
wwv_flow_imp_shared.append_to_install_script(
 p_id=>wwv_flow_imp.id(101142335494412475)
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(1111,to_timestamp(''2022-12-03 12.42.17'',''YYYY-MM-DD HH24.MI.SS''),6,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1119,to_timestamp(''2022-12-05 21.35.51'',''YYYY-MM-DD HH24.MI.SS''),14,''CANCELLED'',14);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1121,to_timestamp(''2022-12-05 23.25.14'',''YYYY-MM-DD HH24.MI.SS''),7,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1169,to_timestamp(''2022-12-15 04.16.06'',''YYYY-MM-DD HH24.MI.SS''),14,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1191,to_timestamp(''2022-12-20 15.12.50'',''YYYY-MM-DD HH24.MI.SS''),14,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1195,to_timestamp(''2022-12-21 06.46.35'',''YYYY-MM-DD HH24.MI.SS''),15,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1200,to_timestamp(''2022-12-21 12.24.05'',''YYYY-MM-DD HH24.MI.SS''),17,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1260,to_timestamp(''2022-12-30 13.21.21'',''YYYY-MM-DD HH24.MI.SS''),9,''CANCELLED'',9);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1321,to_timestamp(''2023-01-09 06.32.45'',''YYYY-MM-DD HH24.MI.SS''),11,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1348,to_timestamp(''2023-01-13 20.57.23'',''YYYY-MM-DD HH24.MI.SS''),18,''COMPLETE'',18);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1363,to_timestamp(''2023-01-16 22.00.07'',''YYYY-MM-DD HH24.MI.SS''),19,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1373,to_timestamp(''2023-01-18 15.27.07'',''YYYY-MM-DD HH24.MI.SS''),16,''CANCELLED'',16);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1390,to_timestamp(''2023-01-21 04.51.37'',''YYYY-MM-DD HH24.MI.SS''),1,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1400,to_timestamp(''2023-01-22 18.52.24'',''YYYY-MM-DD HH24.MI.SS''),15,''COMPLETE'',15);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1418,to_timestamp(''2023-01-25 17.30.59'',''YYYY-MM-DD HH24.MI.SS''),13,''CANCELLED'',13);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1437,to_timestamp(''2023-01-28 21.08.42'',''YYYY-MM-DD HH24.MI.SS''),16,''CANCELLED'',16);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1439,to_timestamp(''2023-01-29 04.52.36'',''YYYY-MM-DD HH24.MI.SS''),16,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1448,to_timestamp(''2023-01-31 07.09.51'',''YYYY-MM-DD HH24.MI.SS''),16,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1450,to_timestamp(''2023-01-31 07.56.41'',''YYYY-MM-DD HH24.MI.SS''),6,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1451,to_timestamp(''2023-01-31 08.10.59'',''YYYY-MM-DD HH24.MI.SS''),16,''CANCELLED'',16);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1455,to_timestamp(''2023-02-01 03.40.10'',''YYYY-MM-DD HH24.MI.SS''),4,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1468,to_timestamp(''2023-02-02 14.27.01'',''YYYY-MM-DD HH24.MI.SS''),4,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1471,to_timestamp(''2023-02-02 19.29.40'',''YYYY-MM-DD HH24.MI.SS''),14,''CANCELLED'',14);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1483,to_timestamp(''2023-02-04 08.09.09'',''YYYY-MM-DD HH24.MI.SS''),14,''COMPLETE'',14);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1486,to_timestamp(''2023-02-05 04.35.40'',''YYYY-MM-DD HH24.MI.SS''),15,''COMPLETE'',15);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1491,to_timestamp(''2023-02-05 21.16.42'',''YYYY-MM-DD HH24.MI.SS''),1,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1498,to_timestamp(''2023-02-06 18.40.27'',''YYYY-MM-DD HH24.MI.SS''),13,''COMPLETE'',13);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1513,to_timestamp(''2023-02-09 17.17.37'',''YYYY-MM-DD HH24.MI.SS''),20,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1520,to_timestamp(''2023-02-10 12.46.23'',''YYYY-MM-DD HH24.MI.SS''),3,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1525,to_timestamp(''2023-02-11 02.22.05'',''YYYY-MM-DD HH24.MI.SS''),10,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1543,to_timestamp(''2023-02-13 00.54.09'',''YYYY-MM-DD HH24.MI.SS''),8,''CANCELLED'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1549,to_timestamp(''2023-02-13 17.28.26'',''YYYY-MM-DD HH24.MI.SS''),19,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1552,to_timestamp(''2023-02-14 01.13.25'',''YYYY-MM-DD HH24.MI.SS''),17,''CANCELLED'',17);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1555,to_timestamp(''2023-02-14 04.22.00'',''YYYY-MM-DD HH24.MI.SS''),7,''CANCELLED'',7);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1560,to_timestamp(''2023-02-14 18.38.06'',''YYYY-MM-DD HH24.MI.SS''),14,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1561,to_timestamp(''2023-02-14 21.01.04'',''YYYY-MM-DD HH24.MI.SS''),8,''COMPLETE'',8);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1635,to_timestamp(''2023-02-26 02.22.36'',''YYYY-MM-DD HH24.MI.SS''),11,''CANCELLED'',11);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1637,to_timestamp(''2023-02-26 15.21.00'',''YYYY-MM-DD HH24.MI.SS''),12,''COMPLETE'',1);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1659,to_timestamp(''2023-03-02 14.20.04'',''YYYY-MM-DD HH24.MI.SS''),18,''CANCELLED'',18);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1730,to_timestamp(''2023-03-15 15.38.39'',''YYYY-MM-DD HH24.MI.SS''),10,''COMPLETE'',10);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1731,to_timestamp(''2023-03-16 09.57.43'',''YYYY-MM-DD HH24.MI.SS''),19,''CANCELLED'',19);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1776,to_timestamp(''2023-03-24 12.05.43'',''YYYY-MM-DD HH24.MI.SS''),20,''COMPLETE'',20);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1808,to_timestamp(''2023-03-29 23.37.35'',''YYYY-MM-DD HH24.MI.SS''),20,''CANCELLED'',20);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1817,to_timestamp(''2023-03-31 10.58.36'',''YYYY-MM-DD HH24.MI.SS''),8,''CANCELLED'',8);',
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1890,to_timestamp(''2023-04-15 12.36.09'',''YYYY-MM-DD HH24.MI.SS''),7,''CANCELLED'',7);',
'',
'',
'     -- Products data',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (16,''Women''''s Socks (Grey)'',39.89,null);',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (17,''Women''''s Sweater (Brown)'',24.46,utl_raw.cast_to_raw(''{"colour":"brown","gender":"Women''''s","brand":"KLUGGER","description":"Dolore '
||'adipisicing commodo consequat Lorem ut incididunt. Ullamco nulla qui qui pariatur qui officia adipisicing magna aliqua ex qui incididunt.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":7,"review":"Fugiat cillum anim in qui laborum velit '
||'eu consectetur ad fugiat."},{"rating":6,"review":"Elit duis nostrud ad non enim elit mollit deserunt."},{"rating":2,"review":"Amet anim mollit laboris deserunt deserunt laboris anim ad commodo dolor."},{"rating":7,"review":"Labore nulla ullamco aute '
||'labore esse do proident sit."},{"rating":5,"review":"Non amet cillum eu cillum cupidatat occaecat excepteur ad voluptate culpa id."},{"rating":4,"review":"Non aliqua nisi anim qui consectetur id dolore duis sint aliqua ea tempor laborum."},{"rating":'
||'5,"review":"Elit ea Lorem duis amet."},{"rating":10,"review":"Aliqua velit nulla exercitation dolor minim ipsum culpa nostrud occaecat proident voluptate."},{"rating":3,"review":"Exercitation anim eu et veniam tempor ea."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (18,''Women''''s Jacket (Black)'',14.34,null);',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (19,''Men''''s Coat (Red)'',28.21,utl_raw.cast_to_raw(''{"colour":"red","gender":"Men''''s","brand":"VELOS","description":"Sint quis dolor in d'
||'olore sint elit ullamco ex magna laborum id eu. Magna fugiat qui pariatur dolore ex est esse minim elit velit.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating":7,"review":"Esse velit est cupidatat ea labore cupidatat ipsum ullamco cupidata'
||'t Lorem."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (20,''Girl''''s Shorts (Green)'',38.34,utl_raw.cast_to_raw(''{"colour":"green","gender":"Girl''''s","brand":"TRASOLA","description":"These shor'
||'ts are perfect for a day out at sea. Made with quick-drying and breathable materials, they are comfortable to wear even in hot and humid conditions.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Veniam'
||' consectetur ea nisi irure aute cillum."},{"rating":8,"review":"Consequat ex incididunt pariatur mollit magna incididunt veniam pariatur aliqua ex exercitation aute mollit ullamco."},{"rating":4,"review":"Proident tempor cupidatat ut cillum nisi sunt'
||' consectetur veniam dolore est ut."},{"rating":8,"review":"Deserunt amet quis do duis nulla officia anim sint do eiusmod exercitation."},{"rating":5,"review":"Anim magna incididunt mollit deserunt proident veniam occaecat ex ut ex incididunt."},{"rat'
||'ing":4,"review":"Consectetur cillum minim dolore cupidatat esse."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (21,''Girl''''s Pyjamas (White)'',39.78,utl_raw.cast_to_raw(''{"colour":"black","gender":"Girl''''s","brand":"UTARIAN","description":"Fugiat ad'
||'ipisicing sunt ullamco est ea. Dolor excepteur sit ad eu.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Proident consequat consequat eu enim Lorem incididunt ad amet excepteur tempor aliquip ad aliquip'
||' ea."},{"rating":7,"review":"Nulla sint anim aliqua laboris sint eu adipisicing incididunt."},{"rating":10,"review":"Aliqua aliquip non commodo duis consequat ad nisi et magna."},{"rating":9,"review":"Tempor consequat Lorem ipsum proident do nisi est'
||' dolore."},{"rating":7,"review":"Pariatur amet laborum dolor dolore incididunt sint labore."},{"rating":10,"review":"Eu exercitation incididunt et est."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (22,''Men''''s Shorts (Black)'',10.33,utl_raw.cast_to_raw(''{"colour":"black","gender":"Men''''s","brand":"TERSANKI","description":"Occaecat ve'
||'niam do aliqua irure consectetur ea fugiat aliqua qui ea veniam officia. Culpa officia Lorem dolor ullamco culpa adipisicing qui exercitation labore minim exercitation sunt.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating":3,"review":"Cons'
||'equat anim reprehenderit commodo non aliqua laborum aute."},{"rating":6,"review":"Labore cillum do qui magna culpa ea excepteur quis."},{"rating":1,"review":"Dolor amet quis ea magna."},{"rating":7,"review":"Minim sit nostrud anim nostrud excepteur n'
||'ostrud ea ex veniam consectetur elit."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (23,''Men''''s Pyjamas (Blue)'',48.39,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Men''''s","brand":"ADORNICA","description":"Irure amet L'
||'orem consequat aliquip officia dolore amet officia. Do elit laboris non dolore nostrud dolore cupidatat ea quis aliquip ex aliquip non ex.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating":3,"review":"Laboris elit pariatur labore duis fugia'
||'t ad in nulla tempor."},{"rating":5,"review":"Voluptate minim officia id excepteur."},{"rating":8,"review":"Eiusmod cupidatat et nisi ipsum non aliqua."},{"rating":1,"review":"Aute veniam irure dolor laborum esse ut ex tempor non velit."},{"rating":2'
||',"review":"Nostrud nostrud mollit incididunt et tempor excepteur sit ut id exercitation."},{"rating":6,"review":"Labore tempor cillum laborum commodo et sit est qui aute enim id aute."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (24,''Boy''''s Sweater (Red)'',9.8,utl_raw.cast_to_raw(''{"colour":"red","gender":"Boy''''s","brand":"PHARMEX","description":"Ex occaecat nulla'
||' esse duis nulla laboris aute. Commodo magna Lorem exercitation occaecat do anim minim non ad non ex do nulla ad.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Ea reprehenderit occaecat commodo exercit'
||'ation ut adipisicing laboris adipisicing ex aute reprehenderit nisi sint qui."},{"rating":8,"review":"Qui anim sint dolore id dolor proident occaecat."},{"rating":5,"review":"Dolore fugiat mollit Lorem aliqua id consequat irure veniam."},{"rating":2,'
||'"review":"Esse dolore occaecat consectetur sit sit labore exercitation sint occaecat quis enim occaecat."},{"rating":4,"review":"Do commodo do laboris qui minim fugiat nisi nostrud elit."},{"rating":7,"review":"Pariatur eu non eiusmod ex dolor veniam'
||'."},{"rating":3,"review":"Magna aliqua dolor sint anim aliquip officia officia esse labore do."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (25,''Girl''''s Jeans (Grey)'',48.75,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Girl''''s","brand":"KINETICUT","description":"Ut aliqua n'
||'ostrud exercitation cupidatat cupidatat in. Sit tempor eu cillum quis incididunt consectetur quis amet.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":2,"review":"Id consectetur minim anim nisi occaecat elit labore'
||' duis."},{"rating":5,"review":"Ut fugiat qui velit fugiat nostrud ea dolor amet magna id pariatur."},{"rating":3,"review":"Labore laborum eiusmod qui minim exercitation."},{"rating":4,"review":"Excepteur ea mollit ad pariatur mollit veniam."},{"ratin'
||'g":9,"review":"Consectetur aliquip deserunt fugiat excepteur elit occaecat culpa fugiat dolor in."},{"rating":1,"review":"Adipisicing adipisicing mollit reprehenderit ex nulla in ea ad exercitation irure ullamco."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (26,''Girl''''s Hoodie (White)'',39.91,utl_raw.cast_to_raw(''{"colour":"white","gender":"Girl''''s","brand":"PROXSOFT","description":"Aliquip c'
||'ulpa eu deserunt ex culpa in laborum adipisicing. Amet et id minim esse ea non qui veniam.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":6,"review":"Commodo ut fugiat voluptate adipisicing deserunt."},{"rating":4,'
||'"review":"Fugiat cupidatat amet fugiat cupidatat ea ea."},{"rating":7,"review":"Incididunt ex enim commodo sit consequat enim."},{"rating":3,"review":"Ullamco in et aute laboris cillum."},{"rating":3,"review":"Reprehenderit Lorem proident sit deserun'
||'t do tempor commodo velit velit nulla ipsum."},{"rating":10,"review":"Dolore pariatur velit enim est culpa eiusmod cupidatat deserunt esse elit exercitation sunt proident exercitation."},{"rating":2,"review":"Minim fugiat elit aliquip nostrud velit r'
||'eprehenderit cillum."},{"rating":4,"review":"Sint Lorem est laborum consectetur pariatur minim tempor ullamco Lorem est."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (27,''Boy''''s Coat (Blue)'',10.24,utl_raw.cast_to_raw(''{"colour":"brown","gender":"Boy''''s","brand":"GRONK","description":"Quis aliquip fugi'
||'at sunt qui eu velit aliqua sint eiusmod mollit id ad. Anim anim ipsum in reprehenderit amet amet consectetur incididunt qui cillum Lorem.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":8,"review":"Sit id elit cupi'
||'datat aute consectetur esse proident aliqua ad voluptate cillum Lorem."},{"rating":6,"review":"Enim enim fugiat consectetur ut sunt veniam ad sit minim amet Lorem veniam mollit."},{"rating":5,"review":"Dolor ipsum consectetur nostrud ex Lorem pariatu'
||'r voluptate."},{"rating":8,"review":"Commodo magna sint sint dolore aute anim laborum."},{"rating":4,"review":"Laboris amet proident occaecat dolore labore exercitation dolore sunt Lorem sunt anim."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (28,''Men''''s Hoodie (Red)'',24.71,utl_raw.cast_to_raw(''{"colour":"red","gender":"Men''''s","brand":"FANGOLD","description":"Dolor irure dolo'
||'re est ipsum nisi incididunt laboris culpa. Ullamco ad cupidatat sint culpa adipisicing pariatur.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating":3,"review":"Proident aliqua aliquip aute quis cillum."},{"rating":5,"review":"Pariatur enim '
||'ipsum aliqua Lorem eiusmod consequat cupidatat irure nulla sint fugiat veniam amet ipsum."},{"rating":10,"review":"Sint duis ipsum reprehenderit Lorem aute pariatur elit."},{"rating":4,"review":"Enim qui qui consequat culpa ex velit sint excepteur ip'
||'sum in amet mollit mollit."},{"rating":10,"review":"Qui velit reprehenderit fugiat adipisicing anim incididunt anim commodo occaecat consectetur in aute."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (29,''Boy''''s Shirt (Black)'',37.34,utl_raw.cast_to_raw(''{"colour":"black","gender":"Boy''''s","brand":"SQUISH","description":"Pariatur nulla'
||' elit pariatur excepteur ullamco officia incididunt. Aliquip quis aliquip cupidatat magna fugiat eiusmod pariatur excepteur tempor officia voluptate fugiat.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":5,"review"'
||':"Non esse labore ullamco laboris irure cupidatat ex proident eiusmod."},{"rating":10,"review":"Ea velit et mollit labore consequat."},{"rating":6,"review":"Labore sit pariatur Lorem ad sint consectetur incididunt deserunt eiusmod sit nostrud dolore '
||'eiusmod sint."},{"rating":1,"review":"Id voluptate sunt amet laboris laborum ad dolor aliqua ipsum sint qui aute eu esse."},{"rating":5,"review":"Sint Lorem dolore do ea."},{"rating":9,"review":"Quis pariatur consequat nisi labore Lorem elit in qui L'
||'orem."},{"rating":2,"review":"Consectetur voluptate tempor ullamco voluptate labore sint."},{"rating":9,"review":"Qui laboris tempor ullamco ullamco commodo sint occaecat Lorem."},{"rating":1,"review":"Laborum eu sit duis et culpa eu duis irure incid'
||'idunt amet."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (30,''Women''''s Pyjamas (Grey)'',28.59,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Women''''s","brand":"THREDZ","description":"Quis aliqu'
||'a eiusmod incididunt quis ut ea aliqua sunt veniam ut et cupidatat eiusmod. Sunt sunt duis excepteur excepteur do exercitation.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":1,"review":"Et anim culpa voluptate pariatur ullamco dolore ad'
||' aliquip."},{"rating":4,"review":"Nulla non ea nisi nulla elit veniam duis."},{"rating":4,"review":"Lorem adipisicing deserunt duis id sint aliquip minim deserunt magna sunt magna laborum dolore."},{"rating":3,"review":"Officia amet magna eu nulla do'
||'lore magna pariatur deserunt amet reprehenderit."},{"rating":3,"review":"Ad aliqua ex eu cillum labore elit mollit reprehenderit anim."},{"rating":1,"review":"Duis excepteur magna aliqua qui officia ipsum sunt."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (31,''Women''''s Skirt (Green)'',5.65,utl_raw.cast_to_raw(''{"colour":"green","gender":"Women''''s","brand":"ZIDANT","description":"Et est offi'
||'cia est amet est nisi sit veniam proident. Ullamco proident culpa velit proident quis dolore occaecat proident Lorem tempor.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (32,''Women''''s Jacket (Blue)'',37,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Women''''s","brand":"ZOGAK","description":"Tempor ipsum du'
||'is aliqua veniam qui laboris et ut officia. Fugiat fugiat nisi labore excepteur ullamco excepteur veniam in in et adipisicing sint.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":9,"review":"Sit amet id ut laborum in exercitation laborum'
||' Lorem fugiat ex."},{"rating":7,"review":"Nisi non mollit dolore id aute velit laboris consequat voluptate id."},{"rating":1,"review":"Nisi nisi fugiat non nisi amet esse."},{"rating":1,"review":"Laborum eiusmod id ipsum aliqua adipisicing cillum eni'
||'m."},{"rating":8,"review":"Duis aliqua ut nulla proident voluptate incididunt elit est exercitation id aute."},{"rating":4,"review":"Veniam labore exercitation eiusmod nisi mollit anim eu."},{"rating":6,"review":"Exercitation eu est irure velit paria'
||'tur."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (33,''Boy''''s Pyjamas (Grey)'',23.32,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Boy''''s","brand":"RETRACK","description":"Sit consectet'
||'ur Lorem culpa ipsum ad ullamco ea aute qui ea. Laboris ipsum enim enim veniam.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Ut incididunt veniam ullamco voluptate occaecat velit."},{"rating":5,"revie'
||'w":"Consectetur cupidatat voluptate dolore velit culpa est id enim aute."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (34,''Women''''s Jeans (Red)'',7.18,utl_raw.cast_to_raw(''{"colour":"red","gender":"Women''''s","brand":"PANZENT","description":"Eiusmod culpa '
||'dolore occaecat excepteur esse magna fugiat dolore cupidatat laboris mollit culpa. Consequat dolor qui tempor sit minim sit excepteur enim excepteur aute minim.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":10,"review":"Nulla enim cillu'
||'m pariatur do consectetur et Lorem."},{"rating":1,"review":"Cupidatat fugiat incididunt fugiat eu."},{"rating":1,"review":"Ullamco eiusmod adipisicing fugiat reprehenderit mollit aliquip."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (35,''Girl''''s Dress (Red)'',49.12,utl_raw.cast_to_raw(''{"colour":"red","gender":"Girl''''s","brand":"NIXELT","description":"Ipsum pariatur l'
||'aborum nulla pariatur consequat consequat amet nisi. Ut in quis officia excepteur.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":10,"review":"Ut est anim sit nulla commodo velit occaecat amet mollit fugiat id."},{'
||'"rating":2,"review":"Eu quis ea anim incididunt nisi nisi velit velit labore do."},{"rating":9,"review":"Eu laborum laborum reprehenderit minim officia anim."},{"rating":8,"review":"Et consectetur labore ullamco occaecat cupidatat magna pariatur esse'
||' qui ut mollit ea cillum."},{"rating":4,"review":"Dolore culpa magna commodo aute do culpa non commodo qui id commodo consectetur exercitation."},{"rating":6,"review":"Adipisicing laborum tempor sunt laboris et sint aute pariatur."},{"rating":9,"revi'
||'ew":"Excepteur voluptate qui magna in cillum aliqua."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (36,''Women''''s Trousers (Blue)'',29.51,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Women''''s","brand":"TROLLERY","description":"Proiden'
||'t sunt ipsum pariatur duis dolor eu dolore culpa ad aliquip elit. Mollit Lorem et aliquip commodo est anim amet eiusmod amet dolore laborum tempor officia.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":10,"review":"Consequat ut commodo '
||'irure sit elit anim amet eu est sunt tempor non."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (37,''Boy''''s Jeans (Blue)'',22.98,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Boy''''s","brand":"AVIT","description":"Velit velit esse n'
||'ulla minim minim laborum esse. Sint minim id aliquip amet fugiat dolor aliqua.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (38,''Girl''''s Pyjamas (Red)'',11,utl_raw.cast_to_raw(''{"colour":"red","gender":"Girl''''s","brand":"EMTRAK","description":"Magna est occaeca'
||'t consectetur ullamco mollit dolore aute irure consectetur nulla ipsum id elit occaecat. Amet Lorem sint nulla eiusmod commodo aliqua cillum anim tempor tempor pariatur do nostrud minim.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"'
||'reviews":[{"rating":4,"review":"Consectetur velit adipisicing excepteur in excepteur sit excepteur irure veniam velit."},{"rating":4,"review":"Consectetur exercitation exercitation irure commodo officia do adipisicing ullamco sit anim consequat."},{"'
||'rating":9,"review":"Minim occaecat sunt laborum voluptate culpa enim elit."},{"rating":2,"review":"Reprehenderit labore incididunt ex ullamco nostrud cillum irure mollit dolore aliqua enim tempor aliquip laborum."},{"rating":2,"review":"Enim commodo '
||'adipisicing consequat commodo."},{"rating":8,"review":"Sint ut cillum Lorem ut ad aliquip elit sunt labore laboris consequat Lorem aliqua occaecat."},{"rating":2,"review":"Et consectetur in officia ullamco labore ea duis amet."},{"rating":8,"review":'
||'"Reprehenderit enim tempor proident commodo ex eu fugiat cupidatat exercitation culpa id adipisicing deserunt officia."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (39,''Boy''''s Trousers (Blue)'',34.06,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Boy''''s","brand":"DIGINETIC","description":"Dolor aliq'
||'ua minim nostrud non labore in ullamco mollit mollit sit non. Duis nulla exercitation et adipisicing nostrud voluptate cupidatat eu reprehenderit.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":6,"review":"Culpa id'
||' consequat cillum dolor."},{"rating":8,"review":"Qui do quis magna nostrud exercitation enim aute dolore proident ipsum sint nostrud deserunt."},{"rating":9,"review":"Excepteur fugiat adipisicing laboris ea culpa cupidatat laborum occaecat nostrud."}'
||']}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (40,''Girl''''s Pyjamas (Black)'',8.66,utl_raw.cast_to_raw(''{"colour":"black","gender":"Girl''''s","brand":"ISOLOGICS","description":"Ex exerc'
||'itation aliquip cillum adipisicing cupidatat. Culpa labore eiusmod do ut ipsum incididunt ipsum labore.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":6,"review":"Duis minim duis dolor laboris eiusmod consequat fug'
||'iat adipisicing ex non culpa Lorem proident qui."},{"rating":4,"review":"Veniam tempor commodo aliqua sit ex mollit cillum aute officia fugiat tempor sunt nulla elit."},{"rating":10,"review":"Dolore officia aute magna eiusmod exercitation esse amet t'
||'empor."},{"rating":7,"review":"Proident nisi voluptate ea esse exercitation ullamco consequat consectetur in enim amet adipisicing commodo nulla."},{"rating":4,"review":"Irure ullamco id adipisicing fugiat Lorem do non officia nisi sunt esse mollit c'
||'onsectetur."},{"rating":9,"review":"Laboris do elit dolor officia irure esse incididunt pariatur elit."},{"rating":1,"review":"Aliqua Lorem nostrud et reprehenderit exercitation exercitation nostrud consectetur dolor."}]}''));',
'            insert into eba_demo_rest_pr'))
);
wwv_flow_imp_shared.append_to_install_script(
 p_id=>wwv_flow_imp.id(101142335494412475)
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'oducttable (product_id, product_name, unit_price, product_details) values (41,''Women''''s Dress (Black)'',10.11,utl_raw.cast_to_raw(''{"colour":"black","gender":"Women''''s","brand":"NEOCENT","description":"Eu enim aliquip deserunt est duis do sunt consequ'
||'at sit sit labore nisi. Culpa mollit cupidatat Lorem et minim sit.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":4,"review":"Ex culpa sint ad eu quis."},{"rating":4,"review":"Irure labore adipisicing velit sint sint."},{"rating":4,"revi'
||'ew":"Ullamco dolore ad qui consequat labore do cillum velit."},{"rating":5,"review":"Velit officia eiusmod proident dolore occaecat eu eiusmod."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (1,''Boy''''s Shirt (White)'',29.55,utl_raw.cast_to_raw(''{"colour":"white","gender":"Boy''''s","brand":"COMTOURS","description":"Labore commod'
||'o velit cupidatat ullamco ea proident velit sunt adipisicing. Esse tempor exercitation reprehenderit ullamco esse incididunt dolore laboris Lorem ipsum fugiat ea.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (2,''Women''''s Shirt (Green)'',16.67,utl_raw.cast_to_raw(''{"colour":"green","gender":"Women''''s","brand":"NIKE","description":"Excepteur ani'
||'m adipisicing aliqua ad. Ex aliquip ad tempor cupidatat dolore ipsum ex anim Lorem aute amet.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":8,"review":"Laborum ipsum adipisicing magna nulla tempor incididunt."},{"rating":10,"review":"Cu'
||'pidatat dolore nulla pariatur quis quis."},{"rating":9,"review":"Pariatur mollit dolor in deserunt cillum consectetur."},{"rating":3,"review":"Dolore occaecat mollit id ad aliqua irure reprehenderit amet eiusmod pariatur."},{"rating":10,"review":"Est'
||' pariatur et qui minim velit non consectetur sint fugiat ad."},{"rating":6,"review":"Et pariatur ipsum eu qui."},{"rating":6,"review":"Voluptate labore irure cupidatat mollit irure quis fugiat enim laborum consectetur officia sunt."},{"rating":8,"rev'
||'iew":"Irure elit do et elit aute veniam proident sunt."},{"rating":8,"review":"Aute mollit proident id veniam occaecat dolore mollit dolore nostrud."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (3,''Boy''''s Sweater (Green)'',44.17,utl_raw.cast_to_raw(''{"colour":"green","gender":"Boy''''s","brand":"KINETICA","description":"Occaecat do'
||'lore in ut et ad pariatur laborum mollit nulla exercitation. Laboris esse tempor quis velit nostrud exercitation veniam reprehenderit minim minim exercitation.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":5,"revi'
||'ew":"Sunt ad proident excepteur laboris officia eu reprehenderit dolor nostrud elit nulla pariatur incididunt Lorem."},{"rating":2,"review":"Ullamco ad amet fugiat adipisicing."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (4,''Boy''''s Trousers (White)'',43.71,utl_raw.cast_to_raw(''{"colour":"white","gender":"Boy''''s","brand":"INTERLOO","description":"Nostrud es'
||'se velit incididunt occaecat ullamco dolor quis reprehenderit proident dolore deserunt tempor qui proident. Magna deserunt sit minim eu commodo minim labore occaecat ea id sint laborum.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"r'
||'eviews":[{"rating":7,"review":"Anim culpa qui est adipisicing qui dolore enim. Sint duis aute laborum nisi ut elit Lorem nisi proident consectetur."},{"rating":6,"review":"Reprehenderit ad ipsum sint mollit aliqua."},{"rating":4,"review":"Enim culpa '
||'reprehenderit non ullamco non ex veniam. Sit do incididunt ullamco ad et et aliquip deserunt dolor officia nostrud ipsum officia nostrud. Lorem esse tempor aliqua ut quis occaecat."},{"rating":9,"review":"Pariatur sit dolor dolor tempor commodo aute '
||'culpa sit."},{"rating":2,"review":"Sunt enim sunt occaecat exercitation deserunt nisi anim mollit deserunt non laboris cillum."},{"rating":8,"review":"Exercitation et duis quis minim id duis veniam occaecat amet cillum velit pariatur tempor. Culpa al'
||'iquip adipisicing aliquip non minim occaecat eu nisi esse veniam eu aliqua."},{"rating":5,"review":"Culpa elit nulla dolore mollit tempor mollit in. Voluptate deserunt eiusmod sint id excepteur eiusmod excepteur qui enim cupidatat. Nostrud enim anim '
||'commodo adipisicing nisi dolore commodo elit commodo aliqua aliquip laborum."},{"rating":4,"review":"Exercitation sunt consequat anim nisi sunt cillum esse amet ut reprehenderit ea. Laborum labore ipsum consectetur ad excepteur proident fugiat consec'
||'tetur eiusmod incididunt officia enim ullamco."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (5,''Girl''''s Shorts (Red)'',38.28,utl_raw.cast_to_raw(''{"colour":"red","gender":"Girl''''s","brand":"OZEAN","description":"These sea shorts '
||'are designed with quick-drying and breathable materials, making them the perfect choice for a day out on the water.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (6,''Boy''''s Socks (Grey)'',19.16,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Boy''''s","brand":"GROK","description":"Pariatur elit adipi'
||'sicing aute dolor sunt laborum ullamco aliqua exercitation consectetur. Lorem qui sint ullamco sint commodo anim.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":5,"review":"Ea eu sit est consectetur quis in dolor u'
||'t."},{"rating":6,"review":"In do cillum occaecat minim."},{"rating":6,"review":"Laborum laborum excepteur ipsum aliquip reprehenderit cillum irure proident voluptate eiusmod in culpa."},{"rating":9,"review":"Exercitation magna proident non deserunt c'
||'onsectetur consectetur do ex sint id irure ipsum voluptate."},{"rating":7,"review":"Aliquip irure minim quis quis voluptate reprehenderit mollit dolore."},{"rating":1,"review":"Duis mollit aute cillum aute culpa magna."},{"rating":9,"review":"Magna e'
||'xercitation exercitation sit commodo proident fugiat occaecat ullamco voluptate do consectetur officia velit."},{"rating":7,"review":"Laboris nostrud et nulla tempor commodo non aute ipsum excepteur qui dolore enim."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (7,''Boy''''s Socks (Black)'',19.58,utl_raw.cast_to_raw(''{"colour":"black","gender":"Boy''''s","brand":"ENERVATE","description":"Sit minim sun'
||'t nulla proident velit Lorem dolor. Aute reprehenderit laborum labore proident non esse nisi ex magna consectetur minim ex est.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":8,"review":"Laborum laboris eu occaecat'
||' amet adipisicing consequat veniam velit."},{"rating":2,"review":"Mollit fugiat commodo minim sint do irure duis quis ex minim ad."},{"rating":2,"review":"Sit duis aliquip proident et nostrud enim anim amet dolor consequat tempor culpa."},{"rating":3'
||',"review":"Proident aute voluptate aute irure."},{"rating":2,"review":"Ex excepteur duis irure veniam elit occaecat sit Lorem labore id minim tempor dolore officia."},{"rating":2,"review":"Amet fugiat commodo qui eiusmod dolore sint fugiat commodo el'
||'it qui esse in officia."},{"rating":2,"review":"Dolor proident proident ad officia cillum dolor aute officia enim exercitation."},{"rating":4,"review":"Dolor esse cupidatat eiusmod non veniam elit nostrud aliquip eu elit."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (8,''Boy''''s Coat (Brown)'',21.16,utl_raw.cast_to_raw(''{"colour":"brown","gender":"Boy''''s","brand":"KOFFEE","description":"Voluptate quis e'
||'xcepteur mollit id dolore. Sunt aliquip in magna ut irure nostrud duis officia fugiat aute.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (9,''Women''''s Jeans (Brown)'',29.49,utl_raw.cast_to_raw(''{"colour":"brown","gender":"Women''''s","brand":"PROTODYNE","description":"Est dolo'
||'r tempor sint commodo irure sint ut dolor proident enim Lorem. Pariatur deserunt nostrud quis minim non.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":2,"review":"Occaecat cupidatat in id elit magna Lorem esse ad magna labore non qui ma'
||'gna."},{"rating":8,"review":"Cupidatat cupidatat laboris consectetur labore veniam aliqua et incididunt duis sunt proident."},{"rating":2,"review":"Esse ipsum veniam ullamco irure ad minim mollit consequat non dolor labore."},{"rating":1,"review":"Ci'
||'llum ea minim voluptate id ut consectetur commodo nostrud cillum eiusmod eiusmod dolore cillum veniam."},{"rating":5,"review":"Excepteur adipisicing culpa dolor id et irure sint ex non nostrud velit pariatur esse quis."},{"rating":9,"review":"Do fugi'
||'at aliqua sunt quis proident fugiat."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (10,''Women''''s Skirt (Red)'',30.69,utl_raw.cast_to_raw(''{"colour":"green","gender":"Women''''s","brand":"FLYBOYZ","description":"Qui aliquip'
||' dolor aute labore amet nostrud deserunt nulla ut veniam id. Ut aute velit tempor anim ex sit nisi.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":7,"review":"Mollit consequat minim sit consequat deserunt duis."},{"rating":8,"review":"Qu'
||'is eu esse proident elit eu aliqua magna voluptate labore adipisicing voluptate ex do."},{"rating":6,"review":"Laborum nulla aliquip nulla adipisicing aliquip qui cupidatat aliquip in."},{"rating":3,"review":"Exercitation aute voluptate voluptate tem'
||'por sit enim ut veniam do."},{"rating":8,"review":"Cillum cillum anim aliqua eu deserunt amet eu ut veniam in qui."},{"rating":7,"review":"Nostrud aliqua ullamco irure consectetur elit nisi eu elit reprehenderit ut."},{"rating":5,"review":"Irure nisi'
||' dolore dolore ut non ad minim pariatur."},{"rating":2,"review":"Laboris aliqua sint est incididunt sunt non tempor irure reprehenderit labore."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (11,''Boy''''s Shorts (Blue)'',10.48,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Boy''''s","brand":"WRAPTURE","description":"Id sit adipis'
||'icing ea dolore fugiat laborum ut dolore. Reprehenderit aliqua non adipisicing aliqua adipisicing aute ullamco consectetur est aliqua.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Laborum labore exerc'
||'itation culpa sint cillum aute duis labore do excepteur."},{"rating":10,"review":"Do velit laborum adipisicing velit."},{"rating":6,"review":"Culpa dolor aute adipisicing ad."},{"rating":6,"review":"Sit sunt elit proident fugiat consectetur id incidi'
||'dunt nulla nulla magna consectetur."},{"rating":6,"review":"Adipisicing ipsum eiusmod sint ullamco dolor irure qui officia."},{"rating":4,"review":"Ipsum commodo amet non ut labore."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (12,''Boy''''s Socks (White)'',12.64,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Boy''''s","brand":"HANDSHAKE","description":"Tempor labor'
||'um voluptate mollit aliquip et tempor nostrud Lorem. Nostrud anim exercitation est fugiat elit est deserunt mollit exercitation.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":8,"review":"Quis culpa laborum ex magn'
||'a."},{"rating":3,"review":"Culpa ullamco deserunt ex ea."},{"rating":3,"review":"Fugiat ullamco reprehenderit tempor nulla ad fugiat qui excepteur sunt officia deserunt nulla."},{"rating":2,"review":"Mollit dolore magna magna veniam culpa ullamco tem'
||'por esse id in occaecat excepteur ullamco ea."},{"rating":10,"review":"Culpa dolore enim consequat aliquip nulla ipsum."},{"rating":2,"review":"Excepteur aliqua sunt exercitation mollit pariatur anim tempor."},{"rating":8,"review":"Proident culpa tem'
||'por dolore deserunt anim ea deserunt quis duis."},{"rating":8,"review":"Reprehenderit est do quis quis reprehenderit adipisicing qui Lorem mollit sit labore veniam."},{"rating":1,"review":"Mollit dolore ad laboris ut cillum velit in sint labore nulla'
||' Lorem minim."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (13,''Boy''''s Hoodie (Grey)'',26.14,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Boy''''s","brand":"SUNCLIPSE","description":"Voluptate ir'
||'ure voluptate labore sint amet occaecat elit ea incididunt aliquip. Tempor laboris tempor tempor magna officia in aliqua consequat elit occaecat.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Fugiat of'
||'ficia nostrud cillum duis consequat sunt culpa duis laborum reprehenderit laborum."},{"rating":10,"review":"Et do reprehenderit do irure tempor id aliquip voluptate anim consequat amet sunt."},{"rating":3,"review":"Minim adipisicing dolore eiusmod la'
||'borum aliqua non Lorem laboris minim est cillum qui qui Lorem."},{"rating":4,"review":"Esse Lorem aute deserunt quis."},{"rating":1,"review":"Ex deserunt aliqua consectetur elit cillum cillum ex et mollit sint."},{"rating":4,"review":"Magna esse ipsu'
||'m ipsum irure officia nostrud ad velit sit."},{"rating":8,"review":"Mollit et tempor esse fugiat fugiat ad voluptate irure est sunt proident magna anim ex."},{"rating":4,"review":"Nulla nisi esse ut exercitation commodo irure non amet labore mollit e'
||'t elit."},{"rating":1,"review":"Enim officia anim proident consequat."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (14,''Women''''s Skirt (Brown)'',13.97,utl_raw.cast_to_raw(''{"colour":"brown","gender":"Women''''s","brand":"ISOTRONIC","description":"Magna L'
||'orem do ad incididunt qui magna irure commodo nisi. Dolore ipsum adipisicing magna ea ullamco Lorem officia culpa do laborum voluptate.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":1,"review":"Officia occaecat laboris magna sint tempor'
||' officia deserunt proident eu excepteur."},{"rating":2,"review":"Aliqua nisi sint enim ad mollit qui."},{"rating":3,"review":"Fugiat excepteur eiusmod incididunt Lorem nostrud nostrud labore aute esse aliquip."},{"rating":8,"review":"Voluptate ad eni'
||'m anim culpa veniam amet."},{"rating":3,"review":"Do cillum quis cillum Lorem tempor labore laboris."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (15,''Girl''''s Coat (Blue)'',13.09,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Girl''''s","brand":"DECRATEX","description":"Proident ut o'
||'fficia non duis est eu aliquip culpa cupidatat est incididunt amet ipsum veniam. Aliqua ea cupidatat incididunt ad excepteur irure ad pariatur occaecat duis incididunt excepteur amet.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"rev'
||'iews":[{"rating":8,"review":"Officia irure deserunt mollit Lorem dolor dolor minim deserunt."},{"rating":10,"review":"Aliqua nostrud dolore enim dolore reprehenderit officia quis aliquip irure occaecat et."},{"rating":2,"review":"Consectetur consequa'
||'t ut cupidatat et elit et cillum veniam exercitation Lorem culpa ipsum."},{"rating":9,"review":"Nisi tempor incididunt Lorem sit sit do mollit qui aliquip qui eu quis Lorem."},{"rating":9,"review":"Sunt nulla ad dolore fugiat cillum et."},{"rating":8'
||',"review":"Incididunt nostrud officia sunt cupidatat culpa ex id ut."},{"rating":1,"review":"Deserunt sit officia enim adipisicing exercitation velit ipsum dolore laboris officia mollit ex esse et."},{"rating":3,"review":"Aliqua nulla laborum id moll'
||'it irure incididunt aliqua mollit qui nostrud consectetur sint aliqua quis."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (42,''Boy''''s Jeans (Black)'',16.64,utl_raw.cast_to_raw(''{"colour":"black","gender":"Boy''''s","brand":"EARTHMARK","description":"Duis dolor '
||'est eu elit anim proident aliqua eu tempor. Est fugiat non ullamco et pariatur nulla exercitation eiusmod id officia minim.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":10,"review":"Anim aliquip id reprehenderit '
||'laboris."},{"rating":7,"review":"Nostrud non cupidatat id eiusmod aliquip anim ullamco aliquip cupidatat excepteur dolor reprehenderit."},{"rating":6,"review":"Veniam consequat deserunt nostrud sunt est commodo sint eu fugiat ipsum deserunt aute elit'
||' est."},{"rating":9,"review":"Eiusmod excepteur ut ullamco eiusmod labore deserunt."},{"rating":5,"review":"Aute deserunt eu voluptate id irure aliquip duis sint proident dolore dolor."},{"rating":5,"review":"Dolore mollit quis elit qui voluptate ad '
||'culpa voluptate elit consectetur."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (43,''Boy''''s Trousers (Black)'',39.32,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Boy''''s","brand":"PHOLIO","description":"Voluptate ex'
||' mollit enim minim nulla proident dolor eu nostrud velit. Ex ullamco aute dolor duis elit elit.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":3,"review":"Labore non exercitation anim id deserunt excepteur dolore s'
||'unt deserunt dolor."},{"rating":5,"review":"Laborum eiusmod mollit amet nulla ex esse culpa ut elit reprehenderit labore ex Lorem cupidatat."},{"rating":7,"review":"Reprehenderit dolore aute consectetur voluptate excepteur veniam nulla ad."},{"rating'
||'":5,"review":"Reprehenderit proident in elit pariatur."},{"rating":8,"review":"Magna laborum ad deserunt voluptate enim excepteur enim dolore veniam consequat officia anim dolore mollit."},{"rating":3,"review":"Elit et reprehenderit amet aute amet la'
||'boris minim irure sint."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (44,''Women''''s Coat (Black)'',31.68,utl_raw.cast_to_raw(''{"colour":"black","gender":"Women''''s","brand":"COMVEYOR","description":"Exercitat'
||'ion ut ad reprehenderit sunt eiusmod sit. Qui nisi ut esse mollit nisi.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":7,"review":"Ad consequat nisi est tempor nisi nulla veniam consectetur ad ut laborum magna."},{"rating":8,"review":"In'
||'cididunt magna ipsum cupidatat elit eiusmod enim mollit eiusmod id esse sit elit irure Lorem."},{"rating":7,"review":"Aute aliquip et esse consequat reprehenderit ipsum ut."},{"rating":8,"review":"Consectetur commodo cupidatat nostrud qui labore magn'
||'a duis sit."},{"rating":8,"review":"Qui occaecat elit exercitation do est officia fugiat adipisicing velit occaecat deserunt Lorem ex adipisicing."},{"rating":6,"review":"Velit est commodo esse sint id ullamco aute ut ut officia laboris irure in."},{'
||'"rating":10,"review":"Ad nulla labore cupidatat do laboris do elit cupidatat excepteur occaecat cupidatat."},{"rating":5,"review":"Do esse magna occaecat non."},{"rating":10,"review":"Et sint qui tempor nostrud sunt sit duis dolor excepteur voluptate'
||'."}]}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (45,''Men''''s Jeans (Grey)'',27.64,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Men''''s","brand":"QNEKT","description":"Dolore duis minim'
||' dolor est fugiat sit dolor nisi anim Lorem culpa id. Consequat labore et reprehenderit pariatur culpa minim laboris pariatur esse aliquip.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating":7,"review":"Veniam qui ipsum consequat laboris ad '
||'aliquip est reprehenderit esse sint cupidatat tempor."},{"rating":8,"review":"Ut anim anim ipsum ipsum irure."},{"rating":9,"review":"Non qui sunt ullamco deserunt sint."},{"rating":10,"review":"Nostrud fugiat velit aliqua eu culpa do excepteur do."}'
||']}''));',
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (46,''Girl''''s Trousers (Red)'',39.16,utl_raw.cast_to_raw(''{"colour":"red","gender":"Girl''''s","brand":"OTHERSIDE","description":"Lorem offi'
||'cia laborum deserunt veniam cillum anim adipisicing minim aute ad esse sint sit tempor. Magna enim proident eiusmod incididunt adipisicing duis deserunt pariatur sint officia occaecat est minim ipsum.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr'
||'","9-10 Yr"],"reviews":[{"rating":9,"review":"Magna magna ullamco ipsum pariatur occaecat eiusmod amet ea sunt reprehenderit dolore aute voluptate."},{"rating":7,"review":"Eiusmod cupidatat cillum qui dolor consequat."},{"rating":4,"review":"Do proid'
||'ent cillum cupidatat laboris in cillum."},{"rating":5,"review":"Sunt eiusmod ea labore est sint adipisicing velit duis."},{"rating":6,"review":"Ut consectetur ad magna officia ut aliqua deserunt magna."}]}''));',
'           -- tasks data ',
'',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (1, ''ACME Web Express'', ''Identify server requirements'', to_date(''2024-02-23'
||' 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2024-02-24 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''John Watson'', 200, 500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (2, ''ACME Web Express'', ''Determine Web listener configuration(s)'', to_date('
||'''2025-02-25 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-25 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''James Cassidy'', 600, 500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (3, ''ACME Web Express'', ''Run installation'', to_date(''2025-02-28 14:34:02'','''
||'YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-28 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''James Cassidy'', 200, 200, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (4, ''ACME Web Express'', ''Create pilot workspace'', to_date(''2025-03-02 14:34'
||':02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-02 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''John Watson'', 100, 100, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (5, ''ACME Web Express'', ''Specify security authentication scheme(s)'', to_dat'
||'e(''2025-03-07 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-07 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''John Watson'', 200, 300, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (6, ''ACME Web Express'', ''Configure Workspace provisioning'', to_date(''2025-0'
||'3-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''John Watson'', 200, 100, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (7, ''ACME Web Express'', ''Select servers for Development, Test, Production'','
||' to_date(''2025-03-11 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-13 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''James Cassidy'', 200, 600, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (8, ''Bug Tracker'', ''Document quality assurance procedures'', to_date(''2025-0'
||'1-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-01-12 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Myra Sutcliff'', 3000, 2000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (9, ''Bug Tracker'', ''Review automated testing tools'', to_date(''2025-01-13 14'
||':34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-01-15 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Myra Sutcliff'', 750, 1500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (10, ''Bug Tracker'', ''Implement bug tracking software'', to_date(''2025-01-28 '
||'14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-01-28 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Myra Sutcliff'', 100, 100, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (11, ''Bug Tracker'', ''Train developers on tracking bugs'', to_date(''2025-02-0'
||'4 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''On-Hold'', ''Myra Sutcliff'', 1000, 2000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (12, ''Bug Tracker'', ''Measure effectiveness of improved QA'', to_date(''2025-0'
||'2-16 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-16 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Myra Sutcliff'', 0, 500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (13, ''Convert Spreadsheets'', ''Collect mission-critical spreadsheets'', to_da'
||'te(''2025-02-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-23 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Pam King'', 2500, 4000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (14, ''Convert Spreadsheets'', ''Lock spreadsheets'', to_date(''2025-02-25 14:34'
||':02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-25 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Pam King'', 300, 800, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (15, ''Convert Spreadsheets'', ''Create ACME Web Express applications from spr'
||'eadsheets'', to_date(''2025-03-05 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Pam King'', 6000, 10000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (16, ''Convert Spreadsheets'', ''Send links to previous spreadsheet owners'', t'
||'o_date(''2025-03-11 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-11 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Pam King'', 0, 500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (17, ''Discussion Forum'', ''Identify owners'', to_date(''2025-01-29 14:34:02'','''
||'YYYY-MM-DD HH24:MI:SS''), to_date(''2025-01-29 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Hank Davis'', 250, 300, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (18, ''Discussion Forum'', ''Install ACME Web Express application on internet '
||'server'', to_date(''2025-02-04 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-04 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Hank Davis'', 100, 100, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (19, ''Discussion Forum'', ''Monitor participation'', to_date(''2025-03-06 14:34'
||':02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-07 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Hank Davis'', 450, 500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (20, ''Email Integration'', ''Complete plan'', to_date(''2025-02-15 14:34:02'',''Y'
||'YYY-MM-DD HH24:MI:SS''), to_date(''2025-02-16 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Bob Nile'', 3000, 1500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (21, ''Email Integration'', ''Check software licenses'', to_date(''2025-02-18 14'
||':34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-18 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Bob Nile'', 200, 200, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (22, ''Email Integration'', ''Get R'))
);
wwv_flow_imp_shared.append_to_install_script(
 p_id=>wwv_flow_imp.id(101142335494412475)
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'FPs for new server'', to_date(''2025-03-04 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-05 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Bob Nile'', 2000, 1000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (23, ''Email Integration'', ''Purchase backup server'', to_date(''2025-03-21 14:'
||'34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-23 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Bob Nile'', 0, 3000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (24, ''Employee Satisfaction Survey'', ''Complete questionnaire'', to_date(''202'
||'5-02-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Irene Jones'', 1200, 800, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (25, ''Employee Satisfaction Survey'', ''Review with legal'', to_date(''2025-02-'
||'10 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-10 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''On-Hold'', ''Irene Jones'', 200, 400, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (26, ''Employee Satisfaction Survey'', ''Plan rollout schedule'', to_date(''2025'
||'-02-11 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-11 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''On-Hold'', ''Irene Jones'', 0, 750, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (27, ''Client Server Conversion'', ''Identify pilot Client Server applications'
||''', to_date(''2025-02-20 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-20 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Scott Spencer'', 200, 200, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (28, ''Client Server Conversion'', ''Migrate pilot Client Server to ACME Web E'
||'xpress'', to_date(''2025-02-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-25 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Scott Spencer'', 4500, 5000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (29, ''Client Server Conversion'', ''Post-migration review'', to_date(''2025-02-'
||'26 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-26 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Pam King'', 500, 300, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (30, ''Client Server Conversion'', ''Plan migration schedule'', to_date(''2025-0'
||'3-01 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-01 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Pam King'', 1000, 1000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (31, ''Client Server Conversion'', ''Migrate Client Server applications'', to_d'
||'ate(''2025-03-06 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Pam King'', 300, 12000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (32, ''Client Server Conversion'', ''Test migrated applications'', to_date(''202'
||'5-03-11 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-12 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Russ Saunders'', 0, 6000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (33, ''Client Server Conversion'', ''User acceptance testing'', to_date(''2025-0'
||'3-15 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-17 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Russ Saunders'', 0, 2500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (34, ''Client Server Conversion'', ''End-user Training'', to_date(''2025-03-21 1'
||'4:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-21 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Myra Sutcliff'', 0, 2500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (35, ''Client Server Conversion'', ''Rollout migrated Client Server in ACME We'
||'b Express'', to_date(''2025-03-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Pam King'', 0, 200, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (36, ''Load Packaged Apps'', ''Identify point solutions required'', to_date(''20'
||'25-02-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''John Watson'', 200, 300, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (37, ''Load Packaged Apps'', ''Install in development'', to_date(''2025-02-23 14'
||':34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-23 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''John Watson'', 100, 100, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (38, ''Load Packaged Apps'', ''Customize solutions'', to_date(''2025-02-26 14:34'
||':02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-28 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''John Watson'', 1500, 4000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (39, ''Load Packaged Apps'', ''Implement in Production'', to_date(''2025-03-01 1'
||'4:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-01 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''On-Hold'', ''John Watson'', 200, 1500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (40, ''Load Packaged Apps'', ''Train Administrators of Packaged Apps'', to_date'
||'(''2025-03-03 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-03 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''John Watson'', 0, 1000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (41, ''Maintain Support Systems'', ''HR software upgrades'', to_date(''2025-02-0'
||'1 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-04 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Pam King'', 8000, 7000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (42, ''Maintain Support Systems'', ''Apply Billing System updates'', to_date(''2'
||'025-02-05 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-07 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Russ Saunders'', 9500, 7000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (43, ''Maintain Support Systems'', ''Arrange for vacation coverage'', to_date('''
||'2025-02-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Al Bines'', 300, 500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (44, ''Maintain Support Systems'', ''Investigate new Virus Protection software'
||''', to_date(''2025-03-21 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Pam King'', 1700, 1500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (45, ''Migrate Desktop Application'', ''Identify pilot desktop applications'', '
||'to_date(''2025-02-13 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-13 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Bob Nile'', 300, 500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (46, ''Migrate Desktop Application'', ''Migrate pilot applications to ACME Web'
||' Express'', to_date(''2025-02-15 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-16 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Bob Nile'', 1250, 1500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (47, ''Migrate Desktop Application'', ''Plan migration schedule'', to_date(''202'
||'5-02-19 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-19 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Bob Nile'', 600, 200, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (48, ''Migrate Desktop Application'', ''Migrate desktop applications'', to_date'
||'(''2025-03-14 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-18 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Bob Nile'', 1000, 8000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (49, ''Migrate Desktop Application'', ''User acceptance testing'', to_date(''202'
||'5-03-20 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-21 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Bob Nile'', 1500, 6000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (50, ''Migrate Desktop Application'', ''End-user Training'', to_date(''2025-03-2'
||'4 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-25 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''John Watson'', 0, 2000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (51, ''Migrate Desktop Application'', ''Post-migration review'', to_date(''2025-'
||'04-07 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-04-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Bob Nile'', 100, 100, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (52, ''Migrate from Legacy Server'', ''Obtain Legacy Server credentials'', to_d'
||'ate(''2025-03-26 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-26 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''James Cassidy'', 0, 500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (53, ''Migrate from Legacy Server'', ''Map data usage'', to_date(''2025-03-28 14'
||':34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-30 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Bob Nile'', 0, 8000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (54, ''Migrate from Legacy Server'', ''Identify integration points'', to_date('''
||'2025-03-31 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-04-01 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Bob Nile'', 0, 2000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (55, ''Migrate from Legacy Server'', ''Create DB Connection to new server'', to'
||'_date(''2025-03-31 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-31 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Scott Spencer'', 0, 100, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (56, ''Migrate from Legacy Server'', ''Migrate table structures'', to_date(''202'
||'5-03-25 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-26 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''John Watson'', 0, 2500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (57, ''Migrate from Legacy Server'', ''Import data'', to_date(''2025-04-06 14:34'
||':02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-04-07 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''John Watson'', 0, 1000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (58, ''Migrate from Legacy Server'', ''Convert processes'', to_date(''2025-04-06'
||' 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-04-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Pam King'', 0, 3000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (59, ''Migrate from Legacy Server'', ''Notify users'', to_date(''2025-04-11 14:3'
||'4:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-04-11 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Bob Nile'', 0, 200, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (60, ''Migrate from Legacy Server'', ''Cut over to new database'', to_date(''202'
||'5-04-12 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-04-12 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Bob Nile'', 0, 1500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (61, ''Migrate from Legacy Server'', ''Decommission Legacy Server'', to_date(''2'
||'025-04-26 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-04-26 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Al Bines'', 0, 500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (62, ''Public Website'', ''Determine host server'', to_date(''2025-02-08 14:34:0'
||'2'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Tiger Scott'', 200, 200, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (63, ''Public Website'', ''Check software licenses'', to_date(''2025-02-08 14:34'
||':02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Tom Suess'', 100, 100, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (64, ''Public Website'', ''Purchase additional software licenses, if needed'', '
||'to_date(''2025-02-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-10 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''On-Hold'', ''Al Bines'', 300, 1000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (65, ''Public Website'', ''Develop web pages'', sysdate, to_date(''2025-03-08 14'
||':34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Tiger Scott'', 0, 2000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (66, ''Public Website'', ''Plan rollout schedule'', to_date(''2025-03-09 14:34:0'
||'2'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Tom Suess'', 0, 100, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (67, ''Software Project Tracking'', ''Conduct project kickoff meeting'', to_dat'
||'e(''2025-03-03 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-03 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Pam King'', 100, 100, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (68, ''Software Project Tracking'', ''Customize Software Projects software'', t'
||'o_date(''2025-03-06 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), sysdate, ''Open'', ''Tom Suess'', 600, 1000, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (69, ''Software Project Tracking'', ''Enter base data (Projects, Milestones, e'
||'tc.)'', to_date(''2025-03-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Tom Suess'', 200, 200, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (70, ''Software Project Tracking'', ''Load current tasks and enhancements'', to'
||'_date(''2025-03-10 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-10 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Tom Suess'', 400, 500, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (71, ''Training for ACME Web Express'', ''Create training workspace'', to_date('
||'''2025-02-20 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-21 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''James Cassidy'', 500, 700, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (72, ''Training for ACME Web Express'', ''Publish links to self-study courses'''
||', to_date(''2025-02-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''John Watson'', 100, 100, sysdate, null, sysdate, null);',
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (73, ''Training for ACME Web Express'', ''Publish development standards'', to_d'
||'ate(''2025-02-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-23 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''On-Hold'', ''John Watson'', 1000, 2000, sysdate, null, sysdate, null);',
'',
'        -- update tasks to current time ',
'            update eba_demo_rest_tasks',
'               set start_date = start_date + (SYSDATE - TO_DATE(''05052025'',''MMDDYYYY'')),',
'                   end_date = end_date + (SYSDATE - TO_DATE(''05052025'',''MMDDYYYY''));',
'      ',
'        -- Order items data',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (349,1,11,30.69,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (349,2,12,10.48,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (401,1,28,10.24,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (401,2,12,10.48,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (430,1,18,24.46,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (430,2,15,13.97,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (437,1,37,29.51,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (437,2,20,28.21,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (453,1,43,16.64,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (453,2,2,29.55,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (506,1,18,24.46,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (506,2,21,38.34,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (513,1,11,30.69,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (513,2,4,44.17,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (513,3,19,14.34,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (544,1,37,29.51,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (544,2,6,38.28,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (544,3,27,39.91,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (585,1,29,24.71,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (585,2,31,28.59,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (585,3,37,29.51,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (608,1,15,13.97,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (608,2,23,10.33,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (608,3,35,7.18,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (672,1,46,39.16,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (687,1,42,10.11,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (687,2,13,12.64,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (707,1,18,24.46,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (760,1,46,39.16,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (760,2,20,28.21,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (761,1,33,37,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (761,2,2,29.55,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (765,1,34,23.32,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (765,2,13,12.64,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (766,1,12,10.48,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (769,1,42,10.11,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (808,1,39,11,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (808,2,13,12.64,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1,1,33,37,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1,2,11,30.69,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (3,1,41,8.66,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (5,1,40,34.06,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (5,2,32,5.65,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (7,1,36,49.12,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (7,2,29,24.71,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (17,1,46,39.16,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (17,2,26,48.75,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (20,1,27,39.91,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (20,2,9,21.16,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (20,3,32,5.65,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (63,1,7,19.16,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (63,2,24,48.39,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (78,1,3,16.67,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (78,2,35,7.18,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (78,3,9,21.16,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (79,1,34,23.32,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (79,2,8,19.58,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (79,3,4,44.17,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (82,1,21,38.34,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (82,2,10,29.49,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (92,1,15,13.97,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (125,1,22,39.78,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product'))
);
wwv_flow_imp_shared.append_to_install_script(
 p_id=>wwv_flow_imp.id(101142335494412475)
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'_id, unit_price, quantity) values (125,2,39,11,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (132,1,11,30.69,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (132,2,31,28.59,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (132,3,10,29.49,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (159,1,8,19.58,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (182,1,23,10.33,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (182,2,20,28.21,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (196,1,3,16.67,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (196,2,23,10.33,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (201,1,19,14.34,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (201,2,36,49.12,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (204,1,33,37,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (204,2,12,10.48,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (240,1,12,10.48,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (240,2,17,39.89,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (290,1,11,30.69,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (290,2,27,39.91,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (290,3,38,22.98,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (298,1,9,21.16,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (298,2,43,16.64,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (306,1,28,10.24,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (307,1,38,22.98,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (307,2,19,14.34,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (331,1,34,23.32,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1483,1,46,39.16,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1483,2,23,10.33,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1483,3,14,26.14,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1486,1,44,39.32,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1486,2,36,49.12,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1486,3,14,26.14,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1491,1,12,10.48,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1498,1,16,13.09,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1498,2,5,43.71,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1513,1,36,49.12,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1513,2,5,43.71,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1513,3,44,39.32,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1520,1,13,12.64,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1520,2,46,27.64,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1520,3,33,37,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1525,1,40,34.06,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1525,2,17,39.89,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1543,1,21,38.34,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1543,2,26,48.75,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1543,3,11,30.69,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1549,1,14,26.14,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1549,2,43,16.64,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1552,1,34,23.32,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1555,1,17,39.89,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1555,2,34,23.32,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1560,1,8,19.58,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1560,2,21,38.34,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1561,1,43,16.64,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1561,2,7,19.16,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1635,1,15,13.97,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1635,2,4,44.17,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1635,3,36,49.12,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1637,1,25,9.8,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1659,1,14,26.14,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1730,1,20,28.21,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1730,2,11,30.69,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1731,1,39,11,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1731,2,21,38.34,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1776,1,34,23.32,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1776,2,25,9.8,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1776,3,20,28.21,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1808,1,14,26.14,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1817,1,34,23.32,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1817,2,42,10.11,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1817,3,22,39.78,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1890,1,2,29.55,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1890,2,46,39.16,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (832,1,10,29.49,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (832,2,9,21.16,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (839,1,38,22.98,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (839,2,7,19.16,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (862,1,23,10.33,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (862,2,33,37,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (899,1,31,28.59,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (920,1,41,8.66,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (920,2,4,44.17,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (928,1,3,16.67,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (928,2,12,10.48,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (928,3,35,7.18,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (943,1,6,38.28,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (950,1,22,39.78,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (950,2,23,10.33,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (960,1,26,48.75,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (960,2,43,16.64,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (960,3,24,48.39,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (968,1,30,37.34,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (968,2,13,12.64,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (968,3,35,7.18,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (972,1,27,39.91,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (972,2,23,10.33,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (986,1,12,10.48,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (986,2,14,26.14,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (993,1,35,7.18,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (993,2,14,26.14,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (993,3,19,14.34,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1052,1,36,49.12,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1052,2,33,37,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1052,3,44,39.32,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1058,1,16,13.09,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1058,2,34,23.32,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1058,3,2,29.55,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1082,1,22,39.78,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1082,2,20,28.21,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1102,1,10,29.49,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1102,2,39,11,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1102,3,14,26.14,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1111,1,41,8.66,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1111,2,13,12.64,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1119,1,25,9.8,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1119,2,9,21.16,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1119,3,45,31.68,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1121,1,27,39.91,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1169,1,9,21.16,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1169,2,22,39.78,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1191,1,33,37,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1191,2,40,34.06,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1191,3,14,26.14,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1195,1,13,12.64,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1200,1,19,14.34,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1200,2,27,39.91,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1200,3,7,19.16,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1260,1,30,37.34,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1260,2,5,43.71,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1321,1,43,16.64,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1321,2,37,29.51,1);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1321,3,46,39.16,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1348,1,31,28.59,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1348,2,23,10.33,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1348,3,3,16.67,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1363,1,11,30.69,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1363,2,14,26.14,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1373,1,17,39.89,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1373,2,29,24.71,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1390,1,12,10.48,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1390,2,28,10.24,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1390,3,9,21.16,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1400,1,11,30.69,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1400,2,6,38.28,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1418,1,31,28.59,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1418,2,45,31.68,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1437,1,3,16.67,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1439,1,46,27.64,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1439,2,9,21.16,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1448,1,2,29.55,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1450,1,4,44.17,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1451,1,10,29.49,5);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1451,2,35,7.18,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1455,1,45,31.68,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1455,2,23,10.33,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1468,1,2,29.55,3);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1468,2,45,31.68,4);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1471,1,14,26.14,2);',
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1471,2,6,38.28,3);',
'',
'',
'        -- purchase order ',
'',
'',
'            insert into eba_demo_rest_purchaseorders (id,po) values (81,''{"PONumber":9,"Reference":"AHUNOLD-20141130","Requestor":"Alexander Hunold","User":"AHUNOLD","Special Instructions":"Counter to Counter","LineItems":[{"ItemNumber":1,"Part":{"De'
||'scription":"Fatal Fury Ova"},"Quantity":7.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (82,''{"PONumber":10,"Reference":"STOBIAS-20140515","Requestor":"Sigal Tobias","User":"STOBIAS","Special Instructions":"Surface Mail","LineItems":[{"ItemNumber":1,"Part":{"Description'
||'":"The Manchurian Candidate"},"Quantity":3.0},{"ItemNumber":2,"Part":{"Description":"The Great Santini"},"Quantity":5.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (83,''{"PONumber":11,"Reference":"STOBIAS-20140516","Requestor":"Sigal Tobias","User":"STOBIAS","Special Instructions":"Courier","LineItems":[{"ItemNumber":1,"Part":{"Description":"Sh'
||'anghai Triad"},"Quantity":7.0},{"ItemNumber":2,"Part":{"Description":"Hanover Street"},"Quantity":1.0},{"ItemNumber":3,"Part":{"Description":"Dr. Seuss'''' How the Grinch Stole Christmas"},"Quantity":5.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (84,''{"PONumber":12,"Reference":"SVOLLMAN-20140502","Requestor":"Shanta Vollman","User":"SVOLLMAN","Special Instructions":"Ground","LineItems":[{"ItemNumber":1,"Part":{"Description":'
||'"Dakota"},"Quantity":7.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (85,''{"PONumber":13,"Reference":"SVOLLMAN-20140524","Requestor":"Shanta Vollman","User":"SVOLLMAN","Special Instructions":"Air Mail","LineItems":[{"ItemNumber":1,"Part":{"Description'
||'":"Enemy Mine"},"Quantity":7.0},{"ItemNumber":2,"Part":{"Description":"The Pink Panther"},"Quantity":5.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (86,''{"PONumber":14,"Reference":"SVOLLMAN-20140525","Requestor":"Shanta Vollman","User":"SVOLLMAN","Special Instructions":"Counter to Counter","LineItems":[{"ItemNumber":1,"Part":{"D'
||'escription":"Mr. Mom"},"Quantity":8.0},{"ItemNumber":2,"Part":{"Description":"Confessions of Sorority Girls"},"Quantity":4.0},{"ItemNumber":3,"Part":{"Description":"Attraction"},"Quantity":3.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (87,''{"PONumber":15,"Reference":"SVOLLMAN-20140506","Requestor":"Shanta Vollman","User":"SVOLLMAN","Special Instructions":"COD","LineItems":[{"ItemNumber":1,"Part":{"Description":"Tr'
||'ue Crime"},"Quantity":7.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (88,''{"PONumber":16,"Reference":"SVOLLMAN-20140531","Requestor":"Shanta Vollman","User":"SVOLLMAN","Special Instructions":"Courier","LineItems":[{"ItemNumber":1,"Part":{"Description"'
||':"Karaoke Favorites Vol. 3"},"Quantity":1.0},{"ItemNumber":2,"Part":{"Description":"Traveller"},"Quantity":9.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (89,''{"PONumber":17,"Reference":"TFOX-20140511","Requestor":"Tayler Fox","User":"TFOX","Special Instructions":"Ground","LineItems":[{"ItemNumber":1,"Part":{"Description":"Circuit 5"}'
||',"Quantity":3.0},{"ItemNumber":2,"Part":{"Description":"Eric Clapton: July 1986"},"Quantity":2.0},{"ItemNumber":3,"Part":{"Description":"Adventures of the Old West: The 49ers and the California Gold Rush"},"Quantity":3.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (90,''{"PONumber":18,"Reference":"GGEONI-20141114","Requestor":"Girard Geoni","User":"GGEONI","Special Instructions":"Courier","LineItems":[{"ItemNumber":1,"Part":{"Description":"Gene'
||'si: La Creazione e il Diluvio"},"Quantity":6.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (91,''{"PONumber":1,"Reference":"MSULLIVA-20141102","Requestor":"Martha Sullivan","User":"MSULLIVA","Special Instructions":"Surface Mail","LineItems":[{"ItemNumber":1,"Part":{"Descrip'
||'tion":"Run Lola Run"},"Quantity":7.0},{"ItemNumber":2,"Part":{"Description":"Felicia''''s Journey"},"Quantity":1.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (92,''{"PONumber":2,"Reference":"MSULLIVA(-20141113","Requestor":"Martha Sullivan","User":"MSULLIVA","Special Instructions":"Next Day Air","LineItems":[{"ItemNumber":1,"Part":{"Descri'
||'ption":"Menace II Society"},"Quantity":3.0},{"ItemNumber":2,"Part":{"Description":"Best of Musikladen Live: Procol Harum"},"Quantity":5.0},{"ItemNumber":3,"Part":{"Description":"Anywhere But Here"},"Quantity":9.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (93,''{"PONumber":3,"Reference":"TRAJS-20140518","Requestor":"Trenna Rajs","User":"TRAJS","Special Instructions":"Courier","LineItems":[{"ItemNumber":1,"Part":{"Description":"Tora! To'
||'ra! Tora!"},"Quantity":2.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (94,''{"PONumber":4,"Reference":"TRAJS-20140520","Requestor":"Trenna Rajs","User":"TRAJS","Special Instructions":"Ground","LineItems":[{"ItemNumber":1,"Part":{"Description":"Mistress"'
||'},"Quantity":6.0},{"ItemNumber":2,"Part":{"Description":"Haunted"},"Quantity":6.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (95,''{"PONumber":5,"Reference":"MSULLIVA-20141121","Requestor":"Martha Sullivan","User":"MSULLIVA","Special Instructions":"Air Mail","LineItems":[{"ItemNumber":1,"Part":{"Description'
||'":"Anaconda"},"Quantity":9.0},{"ItemNumber":2,"Part":{"Description":"Tron"},"Quantity":2.0},{"ItemNumber":3,"Part":{"Description":"The Evening Star"},"Quantity":6.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (96,''{"PONumber":6,"Reference":"TRAJS-20140530","Requestor":"Trenna Rajs","User":"TRAJS","Special Instructions":"Next Day Air","LineItems":[{"ItemNumber":1,"Part":{"Description":"La '
||'Cucaracha"},"Quantity":8.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (97,''{"PONumber":7,"Reference":"VJONES-20140503","Requestor":"Vance Jones","User":"VJONES","Special Instructions":"Hand Carry","LineItems":[{"ItemNumber":1,"Part":{"Description":"The'
||' Kentucky Fried Movie"},"Quantity":3.0},{"ItemNumber":2,"Part":{"Description":"The Loves of Carmen"},"Quantity":4.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (98,''{"PONumber":8,"Reference":"VJONES-20140504","Requestor":"Vance Jones","User":"VJONES","Special Instructions":"Counter to Counter","LineItems":[{"ItemNumber":1,"Part":{"Descripti'
||'on":"Digimon: The Movie"},"Quantity":4.0},{"ItemNumber":2,"Part":{"Description":"Fair Game"},"Quantity":8.0},{"ItemNumber":3,"Part":{"Description":"Barbra Streisand: Timeless- Live In Concert"},"Quantity":2.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (99,''{"PONumber":19,"Reference":"IMIKKILI-20141114","Requestor":"Irene Mikkilineni","User":"IMIKKILI","Special Instructions":"Hand Carry","LineItems":[{"ItemNumber":1,"Part":{"Descri'
||'ption":"Best of Musikladen Live: Ladies of Rock"},"Quantity":3.0},{"ItemNumber":2,"Part":{"Description":"Dangerous Minds"},"Quantity":7.0}]}'');',
'            insert into eba_demo_rest_purchaseorders (id,po) values (100,''{"PONumber":20,"Reference":"IMIKKILI-20141115","Requestor":"Irene Mikkilineni","User":"IMIKKILI","Special Instructions":"Courier","LineItems":[{"ItemNumber":1,"Part":{"Descript'
||'ion":"Offspring: Huck It"},"Quantity":5.0},{"ItemNumber":2,"Part":{"Description":"Alice"},"Quantity":2.0},{"ItemNumber":3,"Part":{"Description":"The Reptile"},"Quantity":3.0}]}'');',
'               ',
'        end load_data;',
'    ',
'    procedure reset_data is',
'        begin',
'            clear_data;',
'            load_data;',
'        end reset_data;',
'',
'end eba_demo_rest_data_pkg;',
'/',
'',
'begin',
'    eba_demo_rest_data_pkg.reset_data;',
'end;',
'/'))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(101142456661412478)
,p_script_id=>wwv_flow_imp.id(101142335494412475)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_DEMO_REST_DATA_PKG'
);
wwv_flow_imp.component_end;
end;
/
