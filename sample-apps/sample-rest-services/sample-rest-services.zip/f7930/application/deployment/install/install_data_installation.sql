prompt --application/deployment/install/install_data_installation
begin
--   Manifest
--     INSTALL: INSTALL-Data installation
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '----------------------------------------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '---'||wwv_flow.LF||
'-- Reset And Load Data Package '||wwv_flow.LF||
'----------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(3) := '---------------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package eba_demo_rest_data_pkg as'||wwv_flow.LF||
''||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(4) := 'rocedure clear_data;'||wwv_flow.LF||
'    -- clears all the data in the database tables'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure load_data;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(5) := ' -- loads data into the database tables'||wwv_flow.LF||
'    procedure reset_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_demo_rest_data_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'cre';
wwv_flow_imp.g_varchar2_table(6) := 'ate or replace package body eba_demo_rest_data_pkg as'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure clear_data is'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(7) := '         delete from eba_demo_rest_assignees;'||wwv_flow.LF||
'            delete from eba_demo_rest_customers;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(8) := '       delete from eba_demo_rest_department;'||wwv_flow.LF||
'            delete from eba_demo_rest_employee;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(9) := '     delete from eba_demo_rest_employeecustom;'||wwv_flow.LF||
'            delete from eba_demo_rest_orderitems;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(10) := '         delete from eba_demo_rest_orders;'||wwv_flow.LF||
'            delete from eba_demo_rest_producttable;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(11) := '       delete from eba_demo_rest_purchaseorders;'||wwv_flow.LF||
'            delete from eba_demo_rest_stores;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(12) := '       delete from eba_demo_rest_tasks;'||wwv_flow.LF||
'            delete from eba_demo_rest_dept_local;'||wwv_flow.LF||
'        en';
wwv_flow_imp.g_varchar2_table(13) := 'd clear_data;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure load_data is'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'            -- department data '||wwv_flow.LF||
''||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(14) := '    insert into eba_demo_rest_department (deptno, dname, loc) values (10, ''ACCOUNTING'', ''NEW YORK'');';
wwv_flow_imp.g_varchar2_table(15) := ''||wwv_flow.LF||
'            insert into eba_demo_rest_department (deptno, dname, loc) values (20, ''RESEARCH'',   ''DA';
wwv_flow_imp.g_varchar2_table(16) := 'LLAS'');'||wwv_flow.LF||
'            insert into eba_demo_rest_department (deptno, dname, loc) values (30, ''SALES'',  ';
wwv_flow_imp.g_varchar2_table(17) := '    ''CHICAGO'');'||wwv_flow.LF||
'            insert into eba_demo_rest_department (deptno, dname, loc) values (40, ''O';
wwv_flow_imp.g_varchar2_table(18) := 'PERATIONS'', ''BOSTON'');'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- dept local '||wwv_flow.LF||
''||wwv_flow.LF||
'            insert into eba_demo_rest_dept_local';
wwv_flow_imp.g_varchar2_table(19) := ' (deptno, dname, loc) values (10, ''ACCOUNTING'', ''NEW YORK'');'||wwv_flow.LF||
'            insert into eba_demo_rest_d';
wwv_flow_imp.g_varchar2_table(20) := 'ept_local (deptno, dname, loc) values (20, ''RESEARCH'',   ''DALLAS'');'||wwv_flow.LF||
'            insert into eba_demo';
wwv_flow_imp.g_varchar2_table(21) := '_rest_dept_local (deptno, dname, loc) values (30, ''SALES'',      ''CHICAGO'');'||wwv_flow.LF||
'            insert into ';
wwv_flow_imp.g_varchar2_table(22) := 'eba_demo_rest_dept_local (deptno, dname, loc) values (40, ''OPERATIONS'', ''BOSTON'');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'            -- ';
wwv_flow_imp.g_varchar2_table(23) := 'assignes Data '||wwv_flow.LF||
'            insert into eba_demo_rest_assignees (id, full_name, email, phone_number, ';
wwv_flow_imp.g_varchar2_table(24) := 'created, created_by, updated, updated_by) values (1,''Landon Glover'',''wubju@example.com'',70,sysdate,n';
wwv_flow_imp.g_varchar2_table(25) := 'ull,sysdate,null);'||wwv_flow.LF||
'            insert into eba_demo_rest_assignees (id, full_name, email, phone_numb';
wwv_flow_imp.g_varchar2_table(26) := 'er, created, created_by, updated, updated_by) values (2,''Jack Jackson'',''buoki@example.com'',97,sysdat';
wwv_flow_imp.g_varchar2_table(27) := 'e,null,sysdate,null);'||wwv_flow.LF||
'            insert into eba_demo_rest_assignees (id, full_name, email, phone_n';
wwv_flow_imp.g_varchar2_table(28) := 'umber, created, created_by, updated, updated_by) values (3,''Grace Dennis'',''wudi@example.com'',20,sysd';
wwv_flow_imp.g_varchar2_table(29) := 'ate,null,sysdate,null);'||wwv_flow.LF||
'            insert into eba_demo_rest_assignees (id, full_name, email, phone';
wwv_flow_imp.g_varchar2_table(30) := '_number, created, created_by, updated, updated_by) values (4,''Cecelia Jennings'',''razworgaz@example.c';
wwv_flow_imp.g_varchar2_table(31) := 'om'',97,sysdate,null,sysdate,null);'||wwv_flow.LF||
'            insert into eba_demo_rest_assignees (id, full_name, e';
wwv_flow_imp.g_varchar2_table(32) := 'mail, phone_number, created, created_by, updated, updated_by) values (5,''George Klein'',''it@example.c';
wwv_flow_imp.g_varchar2_table(33) := 'om'',75,sysdate,null,sysdate,null);'||wwv_flow.LF||
'            insert into eba_demo_rest_assignees (id, full_name, e';
wwv_flow_imp.g_varchar2_table(34) := 'mail, phone_number, created, created_by, updated, updated_by) values (6,''Elnora Payne'',''ketbeun@exam';
wwv_flow_imp.g_varchar2_table(35) := 'ple.com'',84,sysdate,null,sysdate,null);'||wwv_flow.LF||
'            insert into eba_demo_rest_assignees (id, full_na';
wwv_flow_imp.g_varchar2_table(36) := 'me, email, phone_number, created, created_by, updated, updated_by) values (7,''Aaron Erickson'',''ze@ex';
wwv_flow_imp.g_varchar2_table(37) := 'ample.com'',86,sysdate,null,sysdate,null);'||wwv_flow.LF||
'            insert into eba_demo_rest_assignees (id, full_';
wwv_flow_imp.g_varchar2_table(38) := 'name, email, phone_number, created, created_by, updated, updated_by) values (8,''Elizabeth Wilkins'',''';
wwv_flow_imp.g_varchar2_table(39) := 'uglitma@example.com'',58,sysdate,null,sysdate,null);'||wwv_flow.LF||
'            insert into eba_demo_rest_assignees ';
wwv_flow_imp.g_varchar2_table(40) := '(id, full_name, email, phone_number, created, created_by, updated, updated_by) values (9,''Philip Bre';
wwv_flow_imp.g_varchar2_table(41) := 'wer'',''pi@example.com'',18,sysdate,null,sysdate,null);'||wwv_flow.LF||
'            insert into eba_demo_rest_assignees';
wwv_flow_imp.g_varchar2_table(42) := ' (id, full_name, email, phone_number, created, created_by, updated, updated_by) values (10,''Katie An';
wwv_flow_imp.g_varchar2_table(43) := 'derson'',''binotse@example.com'',78,sysdate,null,sysdate,null);'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- customers DAta '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(44) := '     insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (1,  ''Tammy ';
wwv_flow_imp.g_varchar2_table(45) := 'Bryant'',      ''tammy.bryant@example.com'');'||wwv_flow.LF||
'            insert into eba_demo_rest_customers (customer';
wwv_flow_imp.g_varchar2_table(46) := '_id, full_name, email_address) values (2,  ''Roy White'',         ''roy.white@example.com'');'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(47) := '  insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (3,  ''Gary Jenk';
wwv_flow_imp.g_varchar2_table(48) := 'ins'',      ''gary.jenkins@example.com'');'||wwv_flow.LF||
'            insert into eba_demo_rest_customers (customer_id';
wwv_flow_imp.g_varchar2_table(49) := ', full_name, email_address) values (4,  ''Victor Morris'',     ''victor.morris@example.com'');'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(50) := '   insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (5,  ''Beverly ';
wwv_flow_imp.g_varchar2_table(51) := 'Hughes'',    ''beverly.hughes@example.com'');'||wwv_flow.LF||
'            insert into eba_demo_rest_customers (customer';
wwv_flow_imp.g_varchar2_table(52) := '_id, full_name, email_address) values (6,  ''Evelyn Torres'',     ''evelyn.torres@example.com'');'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(53) := '      insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (7,  ''Carl ';
wwv_flow_imp.g_varchar2_table(54) := 'Lee'',          ''carl.lee@example.com'');'||wwv_flow.LF||
'            insert into eba_demo_rest_customers (customer_id';
wwv_flow_imp.g_varchar2_table(55) := ', full_name, email_address) values (8,  ''Douglas Flores'',    ''douglas.flores@example.com'');'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(56) := '    insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (9,  ''Norma R';
wwv_flow_imp.g_varchar2_table(57) := 'obinson'',    ''norma.robinson@example.com'');'||wwv_flow.LF||
'            insert into eba_demo_rest_customers (custome';
wwv_flow_imp.g_varchar2_table(58) := 'r_id, full_name, email_address) values (10, ''Gregory Sanchez'',   ''gregory.sanchez@example.com'');'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(59) := '         insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (11, ''Ju';
wwv_flow_imp.g_varchar2_table(60) := 'dy Evans'',        ''judy.evans@example.com'');'||wwv_flow.LF||
'            insert into eba_demo_rest_customers (custom';
wwv_flow_imp.g_varchar2_table(61) := 'er_id, full_name, email_address) values (12, ''Jean Patterson'',    ''jean.patterson@example.com'');'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(62) := '         insert into eba_demo_rest_customers (customer_id, full_name, email_address) values (13, ''Mi';
wwv_flow_imp.g_varchar2_table(63) := 'chelle Ramirez'',  ''michelle.ramirez@example.com'');'||wwv_flow.LF||
'            insert into eba_demo_rest_customers (';
wwv_flow_imp.g_varchar2_table(64) := 'customer_id, full_name, email_address) values (14, ''Elizabeth Martinez'',''elizabeth.martinez@example.';
wwv_flow_imp.g_varchar2_table(65) := 'com'');'||wwv_flow.LF||
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) value';
wwv_flow_imp.g_varchar2_table(66) := 's (15, ''Walter Rogers'',     ''walter.rogers@example.com'');'||wwv_flow.LF||
'            insert into eba_demo_rest_cust';
wwv_flow_imp.g_varchar2_table(67) := 'omers (customer_id, full_name, email_address) values (16, ''Ralph Foster'',      ''ralph.foster@example';
wwv_flow_imp.g_varchar2_table(68) := '.com'');'||wwv_flow.LF||
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) valu';
wwv_flow_imp.g_varchar2_table(69) := 'es (17, ''Tina Simmons'',      ''tina.simmons@example.com'');'||wwv_flow.LF||
'            insert into eba_demo_rest_cust';
wwv_flow_imp.g_varchar2_table(70) := 'omers (customer_id, full_name, email_address) values (18, ''Peter Jones'',       ''peter.jones@example.';
wwv_flow_imp.g_varchar2_table(71) := 'com'');'||wwv_flow.LF||
'            insert into eba_demo_rest_customers (customer_id, full_name, email_address) value';
wwv_flow_imp.g_varchar2_table(72) := 's (19, ''Kathryn Rogers'',    ''kathryn.rogers@example.com'');'||wwv_flow.LF||
'            insert into eba_demo_rest_cus';
wwv_flow_imp.g_varchar2_table(73) := 'tomers (customer_id, full_name, email_address) values (20, ''Dennis Lopez'',      ''dennis.lopez@exampl';
wwv_flow_imp.g_varchar2_table(74) := 'e.com'');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'            -- employee data '||wwv_flow.LF||
'            insert into eba_demo_rest_employee (empno, ena';
wwv_flow_imp.g_varchar2_table(75) := 'me, job, mgr, hiredate, sal, comm, deptno) values (8839, ''MARTIN'', null, 8902, to_date(''2022-11-17'',';
wwv_flow_imp.g_varchar2_table(76) := '''YYYY-MM-DD''), 5000, 500, 10);'||wwv_flow.LF||
'            insert into eba_demo_rest_employee (empno, ename, job, mg';
wwv_flow_imp.g_varchar2_table(77) := 'r, hiredate, sal, comm, deptno) values (8698, ''BERNARD'', ''DIRECTEUR'', 8839, to_date(''2023-05-01'',''YY';
wwv_flow_imp.g_varchar2_table(78) := 'YY-MM-DD''), 2000, 285, 30);'||wwv_flow.LF||
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, ';
wwv_flow_imp.g_varchar2_table(79) := 'hiredate, sal, comm, deptno) values (8782, ''PETIT'', ''DIRECTEUR'', 8839, to_date(''2023-06-09'',''YYYY-MM';
wwv_flow_imp.g_varchar2_table(80) := '-DD''), 2450, 245, 10);'||wwv_flow.LF||
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hired';
wwv_flow_imp.g_varchar2_table(81) := 'ate, sal, comm, deptno) values (8566, ''DUBOIS'', ''DIRECTEUR'', 8839, to_date(''2022-04-02'',''YYYY-MM-DD''';
wwv_flow_imp.g_varchar2_table(82) := '), 2975, 298, 20);'||wwv_flow.LF||
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate,';
wwv_flow_imp.g_varchar2_table(83) := ' sal, comm, deptno) values (8788, ''ROUX'', ''ANALYSTE'', 8566, to_date(''2023-12-09'',''YYYY-MM-DD''), 3000';
wwv_flow_imp.g_varchar2_table(84) := ', 300, 20);'||wwv_flow.LF||
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, c';
wwv_flow_imp.g_varchar2_table(85) := 'omm, deptno) values (8902, ''DUPONT'', ''ANALYSTE'', 8566, to_date(''2022-12-05'',''YYYY-MM-DD''), 3000, 300';
wwv_flow_imp.g_varchar2_table(86) := ', 20);'||wwv_flow.LF||
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, ';
wwv_flow_imp.g_varchar2_table(87) := unistr('deptno) values (8369, ''VINCENT'', ''EMPLOY\00C9'', 8902, to_date(''2022-12-17'',''YYYY-MM-DD''), 800, null, 20)');
wwv_flow_imp.g_varchar2_table(88) := ';'||wwv_flow.LF||
'            insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptn';
wwv_flow_imp.g_varchar2_table(89) := 'o) values (8499, ''LEFEVRE'', ''VENDEUR'', 8698, to_date(''2023-02-20'',''YYYY-MM-DD''), 1600, 300, 30);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(90) := '         insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) va';
wwv_flow_imp.g_varchar2_table(91) := 'lues (8521, ''LAMBERT'', ''VENDEUR'', 8698, to_date(''2023-02-22'',''YYYY-MM-DD''), 1250, 500, 30);'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(92) := '    insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values ';
wwv_flow_imp.g_varchar2_table(93) := '(8654, ''GARNIER'', ''VENDEUR'', 8698, to_date(''2023-09-28'',''YYYY-MM-DD''), 1250, 1400, 30);'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(94) := 'insert into eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (884';
wwv_flow_imp.g_varchar2_table(95) := '4, ''MORIN'', ''VENDEUR'', 8698, to_date(''2023-09-08'',''YYYY-MM-DD''), 1500, 0, 30);'||wwv_flow.LF||
'            insert in';
wwv_flow_imp.g_varchar2_table(96) := unistr('to eba_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8876, ''CL\00C9ME');
wwv_flow_imp.g_varchar2_table(97) := unistr('NT'', ''EMPLOY\00C9'', 8788, to_date(''2024-01-02'',''YYYY-MM-DD''), 1100, 110, 20);'||wwv_flow.LF||
'            insert into eb');
wwv_flow_imp.g_varchar2_table(98) := 'a_demo_rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8900, ''SIMON'', ''E';
wwv_flow_imp.g_varchar2_table(99) := unistr('MPLOY\00C9'', 8698, to_date(''2022-12-05'',''YYYY-MM-DD''), 950, null, 30);'||wwv_flow.LF||
'            insert into eba_demo_');
wwv_flow_imp.g_varchar2_table(100) := 'rest_employee (empno, ename, job, mgr, hiredate, sal, comm, deptno) values (8934, ''LAURENT'', ''EMPLOY';
wwv_flow_imp.g_varchar2_table(101) := unistr('\00C9'', 8782, to_date(''2023-01-23'',''YYYY-MM-DD''), 1500, null, 10);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'            -- employee custom '||wwv_flow.LF||
'  ');
wwv_flow_imp.g_varchar2_table(102) := '          insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate,';
wwv_flow_imp.g_varchar2_table(103) := ' bonus_eligibility) values (20, 7369, ''SMITH'',              ''Junior Clerk'',        15.5,  ''Yes'');'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(104) := '          insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate,';
wwv_flow_imp.g_varchar2_table(105) := ' bonus_eligibility) values (30, 7499, ''ALLEN'',              ''Sales Associate'',     18,    ''Yes'');'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(106) := '          insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate,';
wwv_flow_imp.g_varchar2_table(107) := ' bonus_eligibility) values (30, 7521, ''WARD'',               ''Sales Associate'',     18.5,  ''Yes'');'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(108) := '          insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate,';
wwv_flow_imp.g_varchar2_table(109) := ' bonus_eligibility) values (20, 7566, ''JONES'',              ''Operations Manager'',  25,    ''Yes'');'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(110) := '          insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate,';
wwv_flow_imp.g_varchar2_table(111) := ' bonus_eligibility) values (30, 7654, ''MARTIN'',             ''Sales Representative'',19,    ''Yes'');'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(112) := '          insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate,';
wwv_flow_imp.g_varchar2_table(113) := ' bonus_eligibility) values (30, 7698, ''BLAKE'',              ''Senior Manager'',      28,    ''Yes'');'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(114) := '          insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate,';
wwv_flow_imp.g_varchar2_table(115) := ' bonus_eligibility) values (10, 7782, ''CLARK'',              ''Admin Manager'',       23,    ''Yes'');'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(116) := '          insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate,';
wwv_flow_imp.g_varchar2_table(117) := ' bonus_eligibility) values (20, 7788, ''SCOTT'',              ''Senior Analyst'',      27,    ''Yes'');'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(118) := '          insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate,';
wwv_flow_imp.g_varchar2_table(119) := ' bonus_eligibility) values (10, 7839, ''KING'',               ''Executive Director'',  35,    ''Yes'');'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(120) := '          insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate,';
wwv_flow_imp.g_varchar2_table(121) := ' bonus_eligibility) values (30, 7844, ''TURNER'',             ''Sales Representative'',18.75,''Yes'');'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(122) := '         insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, ';
wwv_flow_imp.g_varchar2_table(123) := 'bonus_eligibility) values (20, 7876, ''ADAMS'',              ''Junior Clerk'',        15.75,''No'');'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(124) := '       insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bo';
wwv_flow_imp.g_varchar2_table(125) := 'nus_eligibility) values (30, 7900, ''JAMES'',              ''Junior Clerk'',        16,    ''No'');'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(126) := '      insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bon';
wwv_flow_imp.g_varchar2_table(127) := 'us_eligibility) values (20, 7902, ''FORD'',               ''Senior Analyst'',      28,    ''Yes'');'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(128) := '      insert into eba_demo_rest_employeecustom (deptno, empno, emp_name, role_desc, hourly_rate, bon';
wwv_flow_imp.g_varchar2_table(129) := 'us_eligibility) values (10, 7934, ''MILLER'',             ''Junior Clerk'',        16.5,  ''No'');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(130) := '   -- stores Data '||wwv_flow.LF||
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,phy';
wwv_flow_imp.g_varchar2_table(131) := 'sical_address,latitude,longitude) values (1,''Online'',''https://www.example.com'',''Redwood Shores 500 O';
wwv_flow_imp.g_varchar2_table(132) := 'racle Parkway'',39.529395,-112.267237);'||wwv_flow.LF||
'            insert into eba_demo_rest_stores (store_id,store_';
wwv_flow_imp.g_varchar2_table(133) := 'name,web_address,physical_address,latitude,longitude) values (2,''San Francisco'',null,''Redwood Shores';
wwv_flow_imp.g_varchar2_table(134) := ' 500 Oracle Parkway Redwood Shores, CA 94065'',37.529395,-122.267237);'||wwv_flow.LF||
'            insert into eba_de';
wwv_flow_imp.g_varchar2_table(135) := 'mo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (3,''Seat';
wwv_flow_imp.g_varchar2_table(136) := 'tle'',null,''1501 Fourth Avenue Suite 1800 Seattle, WA 98101'',47.6053,-122.33221);'||wwv_flow.LF||
'            insert ';
wwv_flow_imp.g_varchar2_table(137) := 'into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) valu';
wwv_flow_imp.g_varchar2_table(138) := 'es (4,''New York City'',null,''205 Lexington Ave7th Floor New York, NY 10016'',40.745216,-73.980518);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(139) := '          insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitud';
wwv_flow_imp.g_varchar2_table(140) := 'e,longitude) values (5,''Chicago'',null,''233 South Wacker Dr. 45th Floor Chicago, IL 60606'',41.878751,';
wwv_flow_imp.g_varchar2_table(141) := '-87.636675);'||wwv_flow.LF||
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_';
wwv_flow_imp.g_varchar2_table(142) := 'address,latitude,longitude) values (6,''London'',null,''One South Place London EC2M 2RB'',51.519281,-0.0';
wwv_flow_imp.g_varchar2_table(143) := '87296);'||wwv_flow.LF||
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_addre';
wwv_flow_imp.g_varchar2_table(144) := 'ss,latitude,longitude) values (7,''Bucharest'',null,''Floreasca Park43 Soseaua Pipera, corp B.Sector 2 ';
wwv_flow_imp.g_varchar2_table(145) := 'Bucharest , 014254 RO'',44.43225,26.10626);'||wwv_flow.LF||
'            insert into eba_demo_rest_stores (store_id,st';
wwv_flow_imp.g_varchar2_table(146) := 'ore_name,web_address,physical_address,latitude,longitude) values (8,''Berlin'',null,''Behrenstrabe 42 (';
wwv_flow_imp.g_varchar2_table(147) := 'Humboldt Carre) 10117 Berlin'',52.5161,13.3873);'||wwv_flow.LF||
'            insert into eba_demo_rest_stores (store_';
wwv_flow_imp.g_varchar2_table(148) := 'id,store_name,web_address,physical_address,latitude,longitude) values (9,''Utrecht'',null,''Hertogswete';
wwv_flow_imp.g_varchar2_table(149) := 'ring 163-167, 3543 AS Utrecht, Netherlands'',52.103263,5.061644);'||wwv_flow.LF||
'            insert into eba_demo_re';
wwv_flow_imp.g_varchar2_table(150) := 'st_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (10,''Madrid'',';
wwv_flow_imp.g_varchar2_table(151) := 'null,''C/ Jose Echegaray 6BLas Rozas28230 Madrid'',40.4929,-3.8737);'||wwv_flow.LF||
'            insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(152) := 'rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (11,''Johann';
wwv_flow_imp.g_varchar2_table(153) := 'esburg'',null,''Woodmead North Office Park 54 Maxwell Drive Jukskeiview, Sandton, 2196'',-26.044222,28.';
wwv_flow_imp.g_varchar2_table(154) := '094662);'||wwv_flow.LF||
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_addr';
wwv_flow_imp.g_varchar2_table(155) := 'ess,latitude,longitude) values (12,''Lagos'',null,''1391 Tiamiyu Savage St, Victoria Island, Lagos, Nig';
wwv_flow_imp.g_varchar2_table(156) := 'eria'',6.42806,3.42199);'||wwv_flow.LF||
'            insert into eba_demo_rest_stores (store_id,store_name,web_addres';
wwv_flow_imp.g_varchar2_table(157) := 's,physical_address,latitude,longitude) values (13,''Bengaluru'',null,''193, Bannerghatta Main Rd, Indus';
wwv_flow_imp.g_varchar2_table(158) := 'trial Area, Stage 2, BTM Layout, Bengaluru, Karnataka 560076, India'',12.8939,77.5978);'||wwv_flow.LF||
'            i';
wwv_flow_imp.g_varchar2_table(159) := 'nsert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude';
wwv_flow_imp.g_varchar2_table(160) := ') values (14,''Mumbai'',null,''First International Financial Center Unit No. 501, Level 5 No. C54 & 55,';
wwv_flow_imp.g_varchar2_table(161) := ' G Block Bandra Kurla Complex CTS No. 4207, Kolekalyan Village Mumbai - 400 051 India'',19.069405,72.';
wwv_flow_imp.g_varchar2_table(162) := '870143);'||wwv_flow.LF||
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_addr';
wwv_flow_imp.g_varchar2_table(163) := 'ess,latitude,longitude) values (15,''New Dehli'',null,''F-01/02, First Floor Salcon Rasvillas D-1, Dist';
wwv_flow_imp.g_varchar2_table(164) := 'rict Centre, Saket, New Delhi - 110017 India'',28.527693,77.220135);'||wwv_flow.LF||
'            insert into eba_demo';
wwv_flow_imp.g_varchar2_table(165) := '_rest_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (16,''Sydne';
wwv_flow_imp.g_varchar2_table(166) := 'y'',null,''Riverside Corporate Park 4 Julius Avenue North Ryde NSW 2113'',-33.797279,151.143826);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(167) := '       insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,latitude,l';
wwv_flow_imp.g_varchar2_table(168) := 'ongitude) values (17,''Perth'',null,''Level 9 225 St Georges Terrace Perth WA 6000'',-31.953715,115.8516';
wwv_flow_imp.g_varchar2_table(169) := '45);'||wwv_flow.LF||
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,physical_address,';
wwv_flow_imp.g_varchar2_table(170) := 'latitude,longitude) values (18,''Sao Paulo'',null,''Rua Dr. Jose Aureo Bustamante, 455 - Vila Cordeiro,';
wwv_flow_imp.g_varchar2_table(171) := ' CEP 04710-090 Sao Paulo'',-23.5475,-46.63611);'||wwv_flow.LF||
'            insert into eba_demo_rest_stores (store_i';
wwv_flow_imp.g_varchar2_table(172) := 'd,store_name,web_address,physical_address,latitude,longitude) values (19,''Buenos Aires'',null,''Juana ';
wwv_flow_imp.g_varchar2_table(173) := 'Manso 1069, Buenos Aires, Argentina'',-34.61016,-58.362867);'||wwv_flow.LF||
'            insert into eba_demo_rest_st';
wwv_flow_imp.g_varchar2_table(174) := 'ores (store_id,store_name,web_address,physical_address,latitude,longitude) values (20,''Mexico City'',';
wwv_flow_imp.g_varchar2_table(175) := 'null,''Montes Urales # 470 P3 Col. Lomas de Chapultepec Delegacion Miguel Hidalgo - C.P. 11000'',19.42';
wwv_flow_imp.g_varchar2_table(176) := '8489,-99.205745);'||wwv_flow.LF||
'            insert into eba_demo_rest_stores (store_id,store_name,web_address,phys';
wwv_flow_imp.g_varchar2_table(177) := 'ical_address,latitude,longitude) values (21,''Bejing'',null,''China, Beijing Shi, Haidian Qu, Dongbeiwa';
wwv_flow_imp.g_varchar2_table(178) := 'ng W Rd, 8, 100085'',40.0572,116.290061);'||wwv_flow.LF||
'            insert into eba_demo_rest_stores (store_id,stor';
wwv_flow_imp.g_varchar2_table(179) := 'e_name,web_address,physical_address,latitude,longitude) values (22,''Tokyo'',null,''2 Chome-5-? Kitaaoy';
wwv_flow_imp.g_varchar2_table(180) := 'ama, Minato City, Tokyo 107-0061, Japan'',35.671534,139.718584);'||wwv_flow.LF||
'            insert into eba_demo_res';
wwv_flow_imp.g_varchar2_table(181) := 't_stores (store_id,store_name,web_address,physical_address,latitude,longitude) values (23,''Tel Aviv''';
wwv_flow_imp.g_varchar2_table(182) := ',null,''B, Aharon Bart St 18, Petah Tikva, 4951400, Israel'',32.100664,34.862138);'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- Ord';
wwv_flow_imp.g_varchar2_table(183) := 'ers data'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_sta';
wwv_flow_imp.g_varchar2_table(184) := 'tus,store_id) values (453,to_timestamp(''2022-07-23 12.13.03'',''YYYY-MM-DD HH24.MI.SS''),4,''COMPLETE'',4';
wwv_flow_imp.g_varchar2_table(185) := ');'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,st';
wwv_flow_imp.g_varchar2_table(186) := 'ore_id) values (506,to_timestamp(''2022-08-07 10.56.44'',''YYYY-MM-DD HH24.MI.SS''),4,''COMPLETE'',1);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(187) := '         insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id';
wwv_flow_imp.g_varchar2_table(188) := ') values (513,to_timestamp(''2022-08-09 08.00.22'',''YYYY-MM-DD HH24.MI.SS''),15,''CANCELLED'',1);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(189) := '     insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) va';
wwv_flow_imp.g_varchar2_table(190) := 'lues (544,to_timestamp(''2022-08-16 18.32.10'',''YYYY-MM-DD HH24.MI.SS''),3,''CANCELLED'',1);'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(191) := 'insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values ';
wwv_flow_imp.g_varchar2_table(192) := '(585,to_timestamp(''2022-08-26 11.02.38'',''YYYY-MM-DD HH24.MI.SS''),4,''CANCELLED'',1);'||wwv_flow.LF||
'            inser';
wwv_flow_imp.g_varchar2_table(193) := 't into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (608,';
wwv_flow_imp.g_varchar2_table(194) := 'to_timestamp(''2022-09-01 08.01.41'',''YYYY-MM-DD HH24.MI.SS''),3,''CANCELLED'',1);'||wwv_flow.LF||
'            insert int';
wwv_flow_imp.g_varchar2_table(195) := 'o eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (672,to_ti';
wwv_flow_imp.g_varchar2_table(196) := 'mestamp(''2022-09-13 01.37.34'',''YYYY-MM-DD HH24.MI.SS''),4,''COMPLETE'',4);'||wwv_flow.LF||
'            insert into eba_';
wwv_flow_imp.g_varchar2_table(197) := 'demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (687,to_timestam';
wwv_flow_imp.g_varchar2_table(198) := 'p(''2022-09-17 00.09.10'',''YYYY-MM-DD HH24.MI.SS''),16,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(199) := 'rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (707,to_timestamp(''20';
wwv_flow_imp.g_varchar2_table(200) := '22-09-20 18.12.35'',''YYYY-MM-DD HH24.MI.SS''),5,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_';
wwv_flow_imp.g_varchar2_table(201) := 'orders (order_id,order_datetime,customer_id,order_status,store_id) values (760,to_timestamp(''2022-09';
wwv_flow_imp.g_varchar2_table(202) := '-29 07.19.53'',''YYYY-MM-DD HH24.MI.SS''),19,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_order';
wwv_flow_imp.g_varchar2_table(203) := 's (order_id,order_datetime,customer_id,order_status,store_id) values (761,to_timestamp(''2022-09-29 0';
wwv_flow_imp.g_varchar2_table(204) := '8.35.11'',''YYYY-MM-DD HH24.MI.SS''),11,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (o';
wwv_flow_imp.g_varchar2_table(205) := 'rder_id,order_datetime,customer_id,order_status,store_id) values (765,to_timestamp(''2022-09-29 21.36';
wwv_flow_imp.g_varchar2_table(206) := '.52'',''YYYY-MM-DD HH24.MI.SS''),2,''COMPLETE'',2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_i';
wwv_flow_imp.g_varchar2_table(207) := 'd,order_datetime,customer_id,order_status,store_id) values (766,to_timestamp(''2022-09-30 00.38.08'',''';
wwv_flow_imp.g_varchar2_table(208) := 'YYYY-MM-DD HH24.MI.SS''),3,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,orde';
wwv_flow_imp.g_varchar2_table(209) := 'r_datetime,customer_id,order_status,store_id) values (769,to_timestamp(''2022-09-30 02.49.28'',''YYYY-M';
wwv_flow_imp.g_varchar2_table(210) := 'M-DD HH24.MI.SS''),6,''REFUNDED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_date';
wwv_flow_imp.g_varchar2_table(211) := 'time,customer_id,order_status,store_id) values (808,to_timestamp(''2022-10-08 04.06.33'',''YYYY-MM-DD H';
wwv_flow_imp.g_varchar2_table(212) := 'H24.MI.SS''),14,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime';
wwv_flow_imp.g_varchar2_table(213) := ',customer_id,order_status,store_id) values (832,to_timestamp(''2022-10-12 23.16.40'',''YYYY-MM-DD HH24.';
wwv_flow_imp.g_varchar2_table(214) := 'MI.SS''),3,''COMPLETE'',3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,custo';
wwv_flow_imp.g_varchar2_table(215) := 'mer_id,order_status,store_id) values (839,to_timestamp(''2022-10-14 13.59.20'',''YYYY-MM-DD HH24.MI.SS''';
wwv_flow_imp.g_varchar2_table(216) := '),12,''COMPLETE'',12);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_';
wwv_flow_imp.g_varchar2_table(217) := 'id,order_status,store_id) values (862,to_timestamp(''2022-10-19 14.34.20'',''YYYY-MM-DD HH24.MI.SS''),7,';
wwv_flow_imp.g_varchar2_table(218) := '''COMPLETE'',7);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,ord';
wwv_flow_imp.g_varchar2_table(219) := 'er_status,store_id) values (899,to_timestamp(''2022-10-27 09.42.00'',''YYYY-MM-DD HH24.MI.SS''),17,''CANC';
wwv_flow_imp.g_varchar2_table(220) := 'ELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_s';
wwv_flow_imp.g_varchar2_table(221) := 'tatus,store_id) values (920,to_timestamp(''2022-10-30 17.59.30'',''YYYY-MM-DD HH24.MI.SS''),4,''COMPLETE''';
wwv_flow_imp.g_varchar2_table(222) := ',4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,';
wwv_flow_imp.g_varchar2_table(223) := 'store_id) values (928,to_timestamp(''2022-10-31 17.07.56'',''YYYY-MM-DD HH24.MI.SS''),9,''COMPLETE'',1);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(224) := '           insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_';
wwv_flow_imp.g_varchar2_table(225) := 'id) values (943,to_timestamp(''2022-11-03 16.41.53'',''YYYY-MM-DD HH24.MI.SS''),10,''CANCELLED'',1);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(226) := '       insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) ';
wwv_flow_imp.g_varchar2_table(227) := 'values (950,to_timestamp(''2022-11-05 07.02.43'',''YYYY-MM-DD HH24.MI.SS''),7,''COMPLETE'',1);'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(228) := ' insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values';
wwv_flow_imp.g_varchar2_table(229) := ' (960,to_timestamp(''2022-11-06 21.18.36'',''YYYY-MM-DD HH24.MI.SS''),11,''CANCELLED'',1);'||wwv_flow.LF||
'            ins';
wwv_flow_imp.g_varchar2_table(230) := 'ert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (96';
wwv_flow_imp.g_varchar2_table(231) := '8,to_timestamp(''2022-11-08 00.30.18'',''YYYY-MM-DD HH24.MI.SS''),9,''COMPLETE'',1);'||wwv_flow.LF||
'            insert in';
wwv_flow_imp.g_varchar2_table(232) := 'to eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (972,to_t';
wwv_flow_imp.g_varchar2_table(233) := 'imestamp(''2022-11-09 02.12.47'',''YYYY-MM-DD HH24.MI.SS''),6,''COMPLETE'',6);'||wwv_flow.LF||
'            insert into eba';
wwv_flow_imp.g_varchar2_table(234) := '_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (986,to_timesta';
wwv_flow_imp.g_varchar2_table(235) := 'mp(''2022-11-11 19.03.57'',''YYYY-MM-DD HH24.MI.SS''),10,''CANCELLED'',10);'||wwv_flow.LF||
'            insert into eba_de';
wwv_flow_imp.g_varchar2_table(236) := 'mo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (993,to_timestamp(';
wwv_flow_imp.g_varchar2_table(237) := '''2022-11-13 10.16.45'',''YYYY-MM-DD HH24.MI.SS''),8,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_re';
wwv_flow_imp.g_varchar2_table(238) := 'st_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1052,to_timestamp(''202';
wwv_flow_imp.g_varchar2_table(239) := '2-11-22 17.14.32'',''YYYY-MM-DD HH24.MI.SS''),13,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_o';
wwv_flow_imp.g_varchar2_table(240) := 'rders (order_id,order_datetime,customer_id,order_status,store_id) values (1058,to_timestamp(''2022-11';
wwv_flow_imp.g_varchar2_table(241) := '-24 03.58.10'',''YYYY-MM-DD HH24.MI.SS''),6,''CANCELLED'',6);'||wwv_flow.LF||
'            insert into eba_demo_rest_order';
wwv_flow_imp.g_varchar2_table(242) := 's (order_id,order_datetime,customer_id,order_status,store_id) values (1082,to_timestamp(''2022-11-28 ';
wwv_flow_imp.g_varchar2_table(243) := '05.29.33'',''YYYY-MM-DD HH24.MI.SS''),8,''CANCELLED'',8);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (o';
wwv_flow_imp.g_varchar2_table(244) := 'rder_id,order_datetime,customer_id,order_status,store_id) values (1102,to_timestamp(''2022-12-01 22.2';
wwv_flow_imp.g_varchar2_table(245) := '5.32'',''YYYY-MM-DD HH24.MI.SS''),9,''COMPLETE'',9);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_';
wwv_flow_imp.g_varchar2_table(246) := 'id,order_datetime,customer_id,order_status,store_id) values (1,to_timestamp(''2022-02-25 02.24.33'',''Y';
wwv_flow_imp.g_varchar2_table(247) := 'YYY-MM-DD HH24.MI.SS''),3,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,orde';
wwv_flow_imp.g_varchar2_table(248) := 'r_datetime,customer_id,order_status,store_id) values (3,to_timestamp(''2022-03-02 12.21.18'',''YYYY-MM-';
wwv_flow_imp.g_varchar2_table(249) := 'DD HH24.MI.SS''),18,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datet';
wwv_flow_imp.g_varchar2_table(250) := 'ime,customer_id,order_status,store_id) values (5,to_timestamp(''2022-03-04 07.05.41'',''YYYY-MM-DD HH24';
wwv_flow_imp.g_varchar2_table(251) := '.MI.SS''),2,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,cus';
wwv_flow_imp.g_varchar2_table(252) := 'tomer_id,order_status,store_id) values (7,to_timestamp(''2022-03-14 14.01.22'',''YYYY-MM-DD HH24.MI.SS''';
wwv_flow_imp.g_varchar2_table(253) := '),9,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id';
wwv_flow_imp.g_varchar2_table(254) := ',order_status,store_id) values (17,to_timestamp(''2022-03-19 20.51.57'',''YYYY-MM-DD HH24.MI.SS''),16,''C';
wwv_flow_imp.g_varchar2_table(255) := 'OMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order';
wwv_flow_imp.g_varchar2_table(256) := '_status,store_id) values (20,to_timestamp(''2022-03-21 23.11.43'',''YYYY-MM-DD HH24.MI.SS''),3,''COMPLETE';
wwv_flow_imp.g_varchar2_table(257) := ''',3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status';
wwv_flow_imp.g_varchar2_table(258) := ',store_id) values (63,to_timestamp(''2022-04-11 19.21.35'',''YYYY-MM-DD HH24.MI.SS''),3,''COMPLETE'',1);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(259) := '           insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_';
wwv_flow_imp.g_varchar2_table(260) := 'id) values (78,to_timestamp(''2022-04-17 23.00.11'',''YYYY-MM-DD HH24.MI.SS''),20,''COMPLETE'',1);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(261) := '     insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) va';
wwv_flow_imp.g_varchar2_table(262) := 'lues (79,to_timestamp(''2022-04-18 16.39.13'',''YYYY-MM-DD HH24.MI.SS''),14,''COMPLETE'',1);'||wwv_flow.LF||
'            i';
wwv_flow_imp.g_varchar2_table(263) := 'nsert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (';
wwv_flow_imp.g_varchar2_table(264) := '82,to_timestamp(''2022-04-19 13.24.05'',''YYYY-MM-DD HH24.MI.SS''),13,''COMPLETE'',1);'||wwv_flow.LF||
'            insert ';
wwv_flow_imp.g_varchar2_table(265) := 'into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (92,to_';
wwv_flow_imp.g_varchar2_table(266) := 'timestamp(''2022-04-21 21.25.03'',''YYYY-MM-DD HH24.MI.SS''),17,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into e';
wwv_flow_imp.g_varchar2_table(267) := 'ba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (125,to_times';
wwv_flow_imp.g_varchar2_table(268) := 'tamp(''2022-05-01 01.45.50'',''YYYY-MM-DD HH24.MI.SS''),12,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_d';
wwv_flow_imp.g_varchar2_table(269) := 'emo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (132,to_timestamp';
wwv_flow_imp.g_varchar2_table(270) := '(''2022-05-02 14.19.08'',''YYYY-MM-DD HH24.MI.SS''),17,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_r';
wwv_flow_imp.g_varchar2_table(271) := 'est_orders (order_id,order_datetime,customer_id,order_status,store_id) values (159,to_timestamp(''202';
wwv_flow_imp.g_varchar2_table(272) := '2-05-11 01.56.08'',''YYYY-MM-DD HH24.MI.SS''),1,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_o';
wwv_flow_imp.g_varchar2_table(273) := 'rders (order_id,order_datetime,customer_id,order_status,store_id) values (182,to_timestamp(''2022-05-';
wwv_flow_imp.g_varchar2_table(274) := '16 17.00.13'',''YYYY-MM-DD HH24.MI.SS''),1,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders ';
wwv_flow_imp.g_varchar2_table(275) := '(order_id,order_datetime,customer_id,order_status,store_id) values (196,to_timestamp(''2022-05-19 05.';
wwv_flow_imp.g_varchar2_table(276) := '57.59'',''YYYY-MM-DD HH24.MI.SS''),8,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (orde';
wwv_flow_imp.g_varchar2_table(277) := 'r_id,order_datetime,customer_id,order_status,store_id) values (201,to_timestamp(''2022-05-20 00.52.12';
wwv_flow_imp.g_varchar2_table(278) := ''',''YYYY-MM-DD HH24.MI.SS''),1,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,o';
wwv_flow_imp.g_varchar2_table(279) := 'rder_datetime,customer_id,order_status,store_id) values (204,to_timestamp(''2022-05-21 00.43.26'',''YYY';
wwv_flow_imp.g_varchar2_table(280) := 'Y-MM-DD HH24.MI.SS''),6,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_';
wwv_flow_imp.g_varchar2_table(281) := 'datetime,customer_id,order_status,store_id) values (240,to_timestamp(''2022-05-28 13.31.20'',''YYYY-MM-';
wwv_flow_imp.g_varchar2_table(282) := 'DD HH24.MI.SS''),8,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datet';
wwv_flow_imp.g_varchar2_table(283) := 'ime,customer_id,order_status,store_id) values (290,to_timestamp(''2022-06-13 02.12.59'',''YYYY-MM-DD HH';
wwv_flow_imp.g_varchar2_table(284) := '24.MI.SS''),15,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,';
wwv_flow_imp.g_varchar2_table(285) := 'customer_id,order_status,store_id) values (298,to_timestamp(''2022-06-14 09.34.20'',''YYYY-MM-DD HH24.M';
wwv_flow_imp.g_varchar2_table(286) := 'I.SS''),3,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,custom';
wwv_flow_imp.g_varchar2_table(287) := 'er_id,order_status,store_id) values (306,to_timestamp(''2022-06-16 16.24.36'',''YYYY-MM-DD HH24.MI.SS'')';
wwv_flow_imp.g_varchar2_table(288) := ',5,''COMPLETE'',5);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,';
wwv_flow_imp.g_varchar2_table(289) := 'order_status,store_id) values (307,to_timestamp(''2022-06-16 17.31.39'',''YYYY-MM-DD HH24.MI.SS''),3,''CA';
wwv_flow_imp.g_varchar2_table(290) := 'NCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order';
wwv_flow_imp.g_varchar2_table(291) := '_status,store_id) values (331,to_timestamp(''2022-06-24 02.29.17'',''YYYY-MM-DD HH24.MI.SS''),5,''COMPLET';
wwv_flow_imp.g_varchar2_table(292) := 'E'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_statu';
wwv_flow_imp.g_varchar2_table(293) := 's,store_id) values (349,to_timestamp(''2022-06-29 20.24.23'',''YYYY-MM-DD HH24.MI.SS''),14,''COMPLETE'',1)';
wwv_flow_imp.g_varchar2_table(294) := ';'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,sto';
wwv_flow_imp.g_varchar2_table(295) := 're_id) values (401,to_timestamp(''2022-07-11 22.55.57'',''YYYY-MM-DD HH24.MI.SS''),16,''CANCELLED'',1);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(296) := '          insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_i';
wwv_flow_imp.g_varchar2_table(297) := 'd) values (430,to_timestamp(''2022-07-17 08.56.02'',''YYYY-MM-DD HH24.MI.SS''),8,''COMPLETE'',1);'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(298) := '    insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) val';
wwv_flow_imp.g_varchar2_table(299) := 'ues (437,to_timestamp(''2022-07-18 18.41.45'',''YYYY-MM-DD HH24.MI.SS''),10,''CANCELLED'',1);'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(300) := 'insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values ';
wwv_flow_imp.g_varchar2_table(301) := '(1111,to_timestamp(''2022-12-03 12.42.17'',''YYYY-MM-DD HH24.MI.SS''),6,''COMPLETE'',1);'||wwv_flow.LF||
'            inser';
wwv_flow_imp.g_varchar2_table(302) := 't into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1119';
wwv_flow_imp.g_varchar2_table(303) := ',to_timestamp(''2022-12-05 21.35.51'',''YYYY-MM-DD HH24.MI.SS''),14,''CANCELLED'',14);'||wwv_flow.LF||
'            insert ';
wwv_flow_imp.g_varchar2_table(304) := 'into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1121,t';
wwv_flow_imp.g_varchar2_table(305) := 'o_timestamp(''2022-12-05 23.25.14'',''YYYY-MM-DD HH24.MI.SS''),7,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into';
wwv_flow_imp.g_varchar2_table(306) := ' eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1169,to_ti';
wwv_flow_imp.g_varchar2_table(307) := 'mestamp(''2022-12-15 04.16.06'',''YYYY-MM-DD HH24.MI.SS''),14,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eb';
wwv_flow_imp.g_varchar2_table(308) := 'a_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1191,to_times';
wwv_flow_imp.g_varchar2_table(309) := 'tamp(''2022-12-20 15.12.50'',''YYYY-MM-DD HH24.MI.SS''),14,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_d';
wwv_flow_imp.g_varchar2_table(310) := 'emo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1195,to_timestam';
wwv_flow_imp.g_varchar2_table(311) := 'p(''2022-12-21 06.46.35'',''YYYY-MM-DD HH24.MI.SS''),15,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(312) := 'rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1200,to_timestamp(''2';
wwv_flow_imp.g_varchar2_table(313) := '022-12-21 12.24.05'',''YYYY-MM-DD HH24.MI.SS''),17,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest';
wwv_flow_imp.g_varchar2_table(314) := '_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1260,to_timestamp(''2022-';
wwv_flow_imp.g_varchar2_table(315) := '12-30 13.21.21'',''YYYY-MM-DD HH24.MI.SS''),9,''CANCELLED'',9);'||wwv_flow.LF||
'            insert into eba_demo_rest_ord';
wwv_flow_imp.g_varchar2_table(316) := 'ers (order_id,order_datetime,customer_id,order_status,store_id) values (1321,to_timestamp(''2023-01-0';
wwv_flow_imp.g_varchar2_table(317) := '9 06.32.45'',''YYYY-MM-DD HH24.MI.SS''),11,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders';
wwv_flow_imp.g_varchar2_table(318) := ' (order_id,order_datetime,customer_id,order_status,store_id) values (1348,to_timestamp(''2023-01-13 2';
wwv_flow_imp.g_varchar2_table(319) := '0.57.23'',''YYYY-MM-DD HH24.MI.SS''),18,''COMPLETE'',18);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (o';
wwv_flow_imp.g_varchar2_table(320) := 'rder_id,order_datetime,customer_id,order_status,store_id) values (1363,to_timestamp(''2023-01-16 22.0';
wwv_flow_imp.g_varchar2_table(321) := '0.07'',''YYYY-MM-DD HH24.MI.SS''),19,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (orde';
wwv_flow_imp.g_varchar2_table(322) := 'r_id,order_datetime,customer_id,order_status,store_id) values (1373,to_timestamp(''2023-01-18 15.27.0';
wwv_flow_imp.g_varchar2_table(323) := '7'',''YYYY-MM-DD HH24.MI.SS''),16,''CANCELLED'',16);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_';
wwv_flow_imp.g_varchar2_table(324) := 'id,order_datetime,customer_id,order_status,store_id) values (1390,to_timestamp(''2023-01-21 04.51.37''';
wwv_flow_imp.g_varchar2_table(325) := ',''YYYY-MM-DD HH24.MI.SS''),1,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,or';
wwv_flow_imp.g_varchar2_table(326) := 'der_datetime,customer_id,order_status,store_id) values (1400,to_timestamp(''2023-01-22 18.52.24'',''YYY';
wwv_flow_imp.g_varchar2_table(327) := 'Y-MM-DD HH24.MI.SS''),15,''COMPLETE'',15);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order';
wwv_flow_imp.g_varchar2_table(328) := '_datetime,customer_id,order_status,store_id) values (1418,to_timestamp(''2023-01-25 17.30.59'',''YYYY-M';
wwv_flow_imp.g_varchar2_table(329) := 'M-DD HH24.MI.SS''),13,''CANCELLED'',13);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_d';
wwv_flow_imp.g_varchar2_table(330) := 'atetime,customer_id,order_status,store_id) values (1437,to_timestamp(''2023-01-28 21.08.42'',''YYYY-MM-';
wwv_flow_imp.g_varchar2_table(331) := 'DD HH24.MI.SS''),16,''CANCELLED'',16);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_dat';
wwv_flow_imp.g_varchar2_table(332) := 'etime,customer_id,order_status,store_id) values (1439,to_timestamp(''2023-01-29 04.52.36'',''YYYY-MM-DD';
wwv_flow_imp.g_varchar2_table(333) := ' HH24.MI.SS''),16,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_dateti';
wwv_flow_imp.g_varchar2_table(334) := 'me,customer_id,order_status,store_id) values (1448,to_timestamp(''2023-01-31 07.09.51'',''YYYY-MM-DD HH';
wwv_flow_imp.g_varchar2_table(335) := '24.MI.SS''),16,''CANCELLED'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,';
wwv_flow_imp.g_varchar2_table(336) := 'customer_id,order_status,store_id) values (1450,to_timestamp(''2023-01-31 07.56.41'',''YYYY-MM-DD HH24.';
wwv_flow_imp.g_varchar2_table(337) := 'MI.SS''),6,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,custo';
wwv_flow_imp.g_varchar2_table(338) := 'mer_id,order_status,store_id) values (1451,to_timestamp(''2023-01-31 08.10.59'',''YYYY-MM-DD HH24.MI.SS';
wwv_flow_imp.g_varchar2_table(339) := '''),16,''CANCELLED'',16);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,custome';
wwv_flow_imp.g_varchar2_table(340) := 'r_id,order_status,store_id) values (1455,to_timestamp(''2023-02-01 03.40.10'',''YYYY-MM-DD HH24.MI.SS'')';
wwv_flow_imp.g_varchar2_table(341) := ',4,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,';
wwv_flow_imp.g_varchar2_table(342) := 'order_status,store_id) values (1468,to_timestamp(''2023-02-02 14.27.01'',''YYYY-MM-DD HH24.MI.SS''),4,''C';
wwv_flow_imp.g_varchar2_table(343) := 'OMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order';
wwv_flow_imp.g_varchar2_table(344) := '_status,store_id) values (1471,to_timestamp(''2023-02-02 19.29.40'',''YYYY-MM-DD HH24.MI.SS''),14,''CANCE';
wwv_flow_imp.g_varchar2_table(345) := 'LLED'',14);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_s';
wwv_flow_imp.g_varchar2_table(346) := 'tatus,store_id) values (1483,to_timestamp(''2023-02-04 08.09.09'',''YYYY-MM-DD HH24.MI.SS''),14,''COMPLET';
wwv_flow_imp.g_varchar2_table(347) := 'E'',14);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_stat';
wwv_flow_imp.g_varchar2_table(348) := 'us,store_id) values (1486,to_timestamp(''2023-02-05 04.35.40'',''YYYY-MM-DD HH24.MI.SS''),15,''COMPLETE'',';
wwv_flow_imp.g_varchar2_table(349) := '15);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,';
wwv_flow_imp.g_varchar2_table(350) := 'store_id) values (1491,to_timestamp(''2023-02-05 21.16.42'',''YYYY-MM-DD HH24.MI.SS''),1,''CANCELLED'',1);';
wwv_flow_imp.g_varchar2_table(351) := ''||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,stor';
wwv_flow_imp.g_varchar2_table(352) := 'e_id) values (1498,to_timestamp(''2023-02-06 18.40.27'',''YYYY-MM-DD HH24.MI.SS''),13,''COMPLETE'',13);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(353) := '          insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_i';
wwv_flow_imp.g_varchar2_table(354) := 'd) values (1513,to_timestamp(''2023-02-09 17.17.37'',''YYYY-MM-DD HH24.MI.SS''),20,''CANCELLED'',1);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(355) := '       insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) ';
wwv_flow_imp.g_varchar2_table(356) := 'values (1520,to_timestamp(''2023-02-10 12.46.23'',''YYYY-MM-DD HH24.MI.SS''),3,''CANCELLED'',1);'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(357) := '   insert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) valu';
wwv_flow_imp.g_varchar2_table(358) := 'es (1525,to_timestamp(''2023-02-11 02.22.05'',''YYYY-MM-DD HH24.MI.SS''),10,''COMPLETE'',1);'||wwv_flow.LF||
'            i';
wwv_flow_imp.g_varchar2_table(359) := 'nsert into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (';
wwv_flow_imp.g_varchar2_table(360) := '1543,to_timestamp(''2023-02-13 00.54.09'',''YYYY-MM-DD HH24.MI.SS''),8,''CANCELLED'',1);'||wwv_flow.LF||
'            inser';
wwv_flow_imp.g_varchar2_table(361) := 't into eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1549';
wwv_flow_imp.g_varchar2_table(362) := ',to_timestamp(''2023-02-13 17.28.26'',''YYYY-MM-DD HH24.MI.SS''),19,''COMPLETE'',1);'||wwv_flow.LF||
'            insert in';
wwv_flow_imp.g_varchar2_table(363) := 'to eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1552,to_';
wwv_flow_imp.g_varchar2_table(364) := 'timestamp(''2023-02-14 01.13.25'',''YYYY-MM-DD HH24.MI.SS''),17,''CANCELLED'',17);'||wwv_flow.LF||
'            insert into';
wwv_flow_imp.g_varchar2_table(365) := ' eba_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1555,to_ti';
wwv_flow_imp.g_varchar2_table(366) := 'mestamp(''2023-02-14 04.22.00'',''YYYY-MM-DD HH24.MI.SS''),7,''CANCELLED'',7);'||wwv_flow.LF||
'            insert into eba';
wwv_flow_imp.g_varchar2_table(367) := '_demo_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1560,to_timest';
wwv_flow_imp.g_varchar2_table(368) := 'amp(''2023-02-14 18.38.06'',''YYYY-MM-DD HH24.MI.SS''),14,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_dem';
wwv_flow_imp.g_varchar2_table(369) := 'o_rest_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1561,to_timestamp(';
wwv_flow_imp.g_varchar2_table(370) := '''2023-02-14 21.01.04'',''YYYY-MM-DD HH24.MI.SS''),8,''COMPLETE'',8);'||wwv_flow.LF||
'            insert into eba_demo_res';
wwv_flow_imp.g_varchar2_table(371) := 't_orders (order_id,order_datetime,customer_id,order_status,store_id) values (1635,to_timestamp(''2023';
wwv_flow_imp.g_varchar2_table(372) := '-02-26 02.22.36'',''YYYY-MM-DD HH24.MI.SS''),11,''CANCELLED'',11);'||wwv_flow.LF||
'            insert into eba_demo_rest_';
wwv_flow_imp.g_varchar2_table(373) := 'orders (order_id,order_datetime,customer_id,order_status,store_id) values (1637,to_timestamp(''2023-0';
wwv_flow_imp.g_varchar2_table(374) := '2-26 15.21.00'',''YYYY-MM-DD HH24.MI.SS''),12,''COMPLETE'',1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orde';
wwv_flow_imp.g_varchar2_table(375) := 'rs (order_id,order_datetime,customer_id,order_status,store_id) values (1659,to_timestamp(''2023-03-02';
wwv_flow_imp.g_varchar2_table(376) := ' 14.20.04'',''YYYY-MM-DD HH24.MI.SS''),18,''CANCELLED'',18);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders';
wwv_flow_imp.g_varchar2_table(377) := ' (order_id,order_datetime,customer_id,order_status,store_id) values (1730,to_timestamp(''2023-03-15 1';
wwv_flow_imp.g_varchar2_table(378) := '5.38.39'',''YYYY-MM-DD HH24.MI.SS''),10,''COMPLETE'',10);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (o';
wwv_flow_imp.g_varchar2_table(379) := 'rder_id,order_datetime,customer_id,order_status,store_id) values (1731,to_timestamp(''2023-03-16 09.5';
wwv_flow_imp.g_varchar2_table(380) := '7.43'',''YYYY-MM-DD HH24.MI.SS''),19,''CANCELLED'',19);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (ord';
wwv_flow_imp.g_varchar2_table(381) := 'er_id,order_datetime,customer_id,order_status,store_id) values (1776,to_timestamp(''2023-03-24 12.05.';
wwv_flow_imp.g_varchar2_table(382) := '43'',''YYYY-MM-DD HH24.MI.SS''),20,''COMPLETE'',20);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_';
wwv_flow_imp.g_varchar2_table(383) := 'id,order_datetime,customer_id,order_status,store_id) values (1808,to_timestamp(''2023-03-29 23.37.35''';
wwv_flow_imp.g_varchar2_table(384) := ',''YYYY-MM-DD HH24.MI.SS''),20,''CANCELLED'',20);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id';
wwv_flow_imp.g_varchar2_table(385) := ',order_datetime,customer_id,order_status,store_id) values (1817,to_timestamp(''2023-03-31 10.58.36'',''';
wwv_flow_imp.g_varchar2_table(386) := 'YYYY-MM-DD HH24.MI.SS''),8,''CANCELLED'',8);'||wwv_flow.LF||
'            insert into eba_demo_rest_orders (order_id,ord';
wwv_flow_imp.g_varchar2_table(387) := 'er_datetime,customer_id,order_status,store_id) values (1890,to_timestamp(''2023-04-15 12.36.09'',''YYYY';
wwv_flow_imp.g_varchar2_table(388) := '-MM-DD HH24.MI.SS''),7,''CANCELLED'',7);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'     -- Products data'||wwv_flow.LF||
'            insert into eba_demo_rest_';
wwv_flow_imp.g_varchar2_table(389) := 'producttable (product_id, product_name, unit_price, product_details) values (16,''Women''''s Socks (Gre';
wwv_flow_imp.g_varchar2_table(390) := 'y)'',39.89,null);'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_';
wwv_flow_imp.g_varchar2_table(391) := 'price, product_details) values (17,''Women''''s Sweater (Brown)'',24.46,utl_raw.cast_to_raw(''{"colour":"';
wwv_flow_imp.g_varchar2_table(392) := 'brown","gender":"Women''''s","brand":"KLUGGER","description":"Dolore adipisicing commodo consequat Lor';
wwv_flow_imp.g_varchar2_table(393) := 'em ut incididunt. Ullamco nulla qui qui pariatur qui officia adipisicing magna aliqua ex qui incidid';
wwv_flow_imp.g_varchar2_table(394) := 'unt.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":7,"review":"Fugiat cillum anim in q';
wwv_flow_imp.g_varchar2_table(395) := 'ui laborum velit eu consectetur ad fugiat."},{"rating":6,"review":"Elit duis nostrud ad non enim eli';
wwv_flow_imp.g_varchar2_table(396) := 't mollit deserunt."},{"rating":2,"review":"Amet anim mollit laboris deserunt deserunt laboris anim a';
wwv_flow_imp.g_varchar2_table(397) := 'd commodo dolor."},{"rating":7,"review":"Labore nulla ullamco aute labore esse do proident sit."},{"';
wwv_flow_imp.g_varchar2_table(398) := 'rating":5,"review":"Non amet cillum eu cillum cupidatat occaecat excepteur ad voluptate culpa id."},';
wwv_flow_imp.g_varchar2_table(399) := '{"rating":4,"review":"Non aliqua nisi anim qui consectetur id dolore duis sint aliqua ea tempor labo';
wwv_flow_imp.g_varchar2_table(400) := 'rum."},{"rating":5,"review":"Elit ea Lorem duis amet."},{"rating":10,"review":"Aliqua velit nulla ex';
wwv_flow_imp.g_varchar2_table(401) := 'ercitation dolor minim ipsum culpa nostrud occaecat proident voluptate."},{"rating":3,"review":"Exer';
wwv_flow_imp.g_varchar2_table(402) := 'citation anim eu et veniam tempor ea."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (pr';
wwv_flow_imp.g_varchar2_table(403) := 'oduct_id, product_name, unit_price, product_details) values (18,''Women''''s Jacket (Black)'',14.34,null';
wwv_flow_imp.g_varchar2_table(404) := ');'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product';
wwv_flow_imp.g_varchar2_table(405) := '_details) values (19,''Men''''s Coat (Red)'',28.21,utl_raw.cast_to_raw(''{"colour":"red","gender":"Men''''s';
wwv_flow_imp.g_varchar2_table(406) := '","brand":"VELOS","description":"Sint quis dolor in dolore sint elit ullamco ex magna laborum id eu.';
wwv_flow_imp.g_varchar2_table(407) := ' Magna fugiat qui pariatur dolore ex est esse minim elit velit.","sizes":["XS","S","M","L","XL","XXL';
wwv_flow_imp.g_varchar2_table(408) := '"],"reviews":[{"rating":7,"review":"Esse velit est cupidatat ea labore cupidatat ipsum ullamco cupid';
wwv_flow_imp.g_varchar2_table(409) := 'atat Lorem."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, product_name, un';
wwv_flow_imp.g_varchar2_table(410) := 'it_price, product_details) values (20,''Girl''''s Shorts (Green)'',38.34,utl_raw.cast_to_raw(''{"colour":';
wwv_flow_imp.g_varchar2_table(411) := '"green","gender":"Girl''''s","brand":"TRASOLA","description":"These shorts are perfect for a day out a';
wwv_flow_imp.g_varchar2_table(412) := 't sea. Made with quick-drying and breathable materials, they are comfortable to wear even in hot and';
wwv_flow_imp.g_varchar2_table(413) := ' humid conditions.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating';
wwv_flow_imp.g_varchar2_table(414) := '":7,"review":"Veniam consectetur ea nisi irure aute cillum."},{"rating":8,"review":"Consequat ex inc';
wwv_flow_imp.g_varchar2_table(415) := 'ididunt pariatur mollit magna incididunt veniam pariatur aliqua ex exercitation aute mollit ullamco.';
wwv_flow_imp.g_varchar2_table(416) := '"},{"rating":4,"review":"Proident tempor cupidatat ut cillum nisi sunt consectetur veniam dolore est';
wwv_flow_imp.g_varchar2_table(417) := ' ut."},{"rating":8,"review":"Deserunt amet quis do duis nulla officia anim sint do eiusmod exercitat';
wwv_flow_imp.g_varchar2_table(418) := 'ion."},{"rating":5,"review":"Anim magna incididunt mollit deserunt proident veniam occaecat ex ut ex';
wwv_flow_imp.g_varchar2_table(419) := ' incididunt."},{"rating":4,"review":"Consectetur cillum minim dolore cupidatat esse."}]}''));'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(420) := '     insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) ';
wwv_flow_imp.g_varchar2_table(421) := 'values (21,''Girl''''s Pyjamas (White)'',39.78,utl_raw.cast_to_raw(''{"colour":"black","gender":"Girl''''s"';
wwv_flow_imp.g_varchar2_table(422) := ',"brand":"UTARIAN","description":"Fugiat adipisicing sunt ullamco est ea. Dolor excepteur sit ad eu.';
wwv_flow_imp.g_varchar2_table(423) := '","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Proi';
wwv_flow_imp.g_varchar2_table(424) := 'dent consequat consequat eu enim Lorem incididunt ad amet excepteur tempor aliquip ad aliquip ea."},';
wwv_flow_imp.g_varchar2_table(425) := '{"rating":7,"review":"Nulla sint anim aliqua laboris sint eu adipisicing incididunt."},{"rating":10,';
wwv_flow_imp.g_varchar2_table(426) := '"review":"Aliqua aliquip non commodo duis consequat ad nisi et magna."},{"rating":9,"review":"Tempor';
wwv_flow_imp.g_varchar2_table(427) := ' consequat Lorem ipsum proident do nisi est dolore."},{"rating":7,"review":"Pariatur amet laborum do';
wwv_flow_imp.g_varchar2_table(428) := 'lor dolore incididunt sint labore."},{"rating":10,"review":"Eu exercitation incididunt et est."}]}'')';
wwv_flow_imp.g_varchar2_table(429) := ');'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product';
wwv_flow_imp.g_varchar2_table(430) := '_details) values (22,''Men''''s Shorts (Black)'',10.33,utl_raw.cast_to_raw(''{"colour":"black","gender":"';
wwv_flow_imp.g_varchar2_table(431) := 'Men''''s","brand":"TERSANKI","description":"Occaecat veniam do aliqua irure consectetur ea fugiat aliq';
wwv_flow_imp.g_varchar2_table(432) := 'ua qui ea veniam officia. Culpa officia Lorem dolor ullamco culpa adipisicing qui exercitation labor';
wwv_flow_imp.g_varchar2_table(433) := 'e minim exercitation sunt.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating":3,"review":"C';
wwv_flow_imp.g_varchar2_table(434) := 'onsequat anim reprehenderit commodo non aliqua laborum aute."},{"rating":6,"review":"Labore cillum d';
wwv_flow_imp.g_varchar2_table(435) := 'o qui magna culpa ea excepteur quis."},{"rating":1,"review":"Dolor amet quis ea magna."},{"rating":7';
wwv_flow_imp.g_varchar2_table(436) := ',"review":"Minim sit nostrud anim nostrud excepteur nostrud ea ex veniam consectetur elit."}]}''));'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(437) := '           insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_det';
wwv_flow_imp.g_varchar2_table(438) := 'ails) values (23,''Men''''s Pyjamas (Blue)'',48.39,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Men''''';
wwv_flow_imp.g_varchar2_table(439) := 's","brand":"ADORNICA","description":"Irure amet Lorem consequat aliquip officia dolore amet officia.';
wwv_flow_imp.g_varchar2_table(440) := ' Do elit laboris non dolore nostrud dolore cupidatat ea quis aliquip ex aliquip non ex.","sizes":["X';
wwv_flow_imp.g_varchar2_table(441) := 'S","S","M","L","XL","XXL"],"reviews":[{"rating":3,"review":"Laboris elit pariatur labore duis fugiat';
wwv_flow_imp.g_varchar2_table(442) := ' ad in nulla tempor."},{"rating":5,"review":"Voluptate minim officia id excepteur."},{"rating":8,"re';
wwv_flow_imp.g_varchar2_table(443) := 'view":"Eiusmod cupidatat et nisi ipsum non aliqua."},{"rating":1,"review":"Aute veniam irure dolor l';
wwv_flow_imp.g_varchar2_table(444) := 'aborum esse ut ex tempor non velit."},{"rating":2,"review":"Nostrud nostrud mollit incididunt et tem';
wwv_flow_imp.g_varchar2_table(445) := 'por excepteur sit ut id exercitation."},{"rating":6,"review":"Labore tempor cillum laborum commodo e';
wwv_flow_imp.g_varchar2_table(446) := 't sit est qui aute enim id aute."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product';
wwv_flow_imp.g_varchar2_table(447) := '_id, product_name, unit_price, product_details) values (24,''Boy''''s Sweater (Red)'',9.8,utl_raw.cast_t';
wwv_flow_imp.g_varchar2_table(448) := 'o_raw(''{"colour":"red","gender":"Boy''''s","brand":"PHARMEX","description":"Ex occaecat nulla esse dui';
wwv_flow_imp.g_varchar2_table(449) := 's nulla laboris aute. Commodo magna Lorem exercitation occaecat do anim minim non ad non ex do nulla';
wwv_flow_imp.g_varchar2_table(450) := ' ad.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"';
wwv_flow_imp.g_varchar2_table(451) := 'Ea reprehenderit occaecat commodo exercitation ut adipisicing laboris adipisicing ex aute reprehende';
wwv_flow_imp.g_varchar2_table(452) := 'rit nisi sint qui."},{"rating":8,"review":"Qui anim sint dolore id dolor proident occaecat."},{"rati';
wwv_flow_imp.g_varchar2_table(453) := 'ng":5,"review":"Dolore fugiat mollit Lorem aliqua id consequat irure veniam."},{"rating":2,"review":';
wwv_flow_imp.g_varchar2_table(454) := '"Esse dolore occaecat consectetur sit sit labore exercitation sint occaecat quis enim occaecat."},{"';
wwv_flow_imp.g_varchar2_table(455) := 'rating":4,"review":"Do commodo do laboris qui minim fugiat nisi nostrud elit."},{"rating":7,"review"';
wwv_flow_imp.g_varchar2_table(456) := ':"Pariatur eu non eiusmod ex dolor veniam."},{"rating":3,"review":"Magna aliqua dolor sint anim aliq';
wwv_flow_imp.g_varchar2_table(457) := 'uip officia officia esse labore do."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (prod';
wwv_flow_imp.g_varchar2_table(458) := 'uct_id, product_name, unit_price, product_details) values (25,''Girl''''s Jeans (Grey)'',48.75,utl_raw.c';
wwv_flow_imp.g_varchar2_table(459) := 'ast_to_raw(''{"colour":"grey","gender":"Girl''''s","brand":"KINETICUT","description":"Ut aliqua nostrud';
wwv_flow_imp.g_varchar2_table(460) := ' exercitation cupidatat cupidatat in. Sit tempor eu cillum quis incididunt consectetur quis amet.","';
wwv_flow_imp.g_varchar2_table(461) := 'sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":2,"review":"Id cons';
wwv_flow_imp.g_varchar2_table(462) := 'ectetur minim anim nisi occaecat elit labore duis."},{"rating":5,"review":"Ut fugiat qui velit fugia';
wwv_flow_imp.g_varchar2_table(463) := 't nostrud ea dolor amet magna id pariatur."},{"rating":3,"review":"Labore laborum eiusmod qui minim ';
wwv_flow_imp.g_varchar2_table(464) := 'exercitation."},{"rating":4,"review":"Excepteur ea mollit ad pariatur mollit veniam."},{"rating":9,"';
wwv_flow_imp.g_varchar2_table(465) := 'review":"Consectetur aliquip deserunt fugiat excepteur elit occaecat culpa fugiat dolor in."},{"rati';
wwv_flow_imp.g_varchar2_table(466) := 'ng":1,"review":"Adipisicing adipisicing mollit reprehenderit ex nulla in ea ad exercitation irure ul';
wwv_flow_imp.g_varchar2_table(467) := 'lamco."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_pr';
wwv_flow_imp.g_varchar2_table(468) := 'ice, product_details) values (26,''Girl''''s Hoodie (White)'',39.91,utl_raw.cast_to_raw(''{"colour":"whit';
wwv_flow_imp.g_varchar2_table(469) := 'e","gender":"Girl''''s","brand":"PROXSOFT","description":"Aliquip culpa eu deserunt ex culpa in laboru';
wwv_flow_imp.g_varchar2_table(470) := 'm adipisicing. Amet et id minim esse ea non qui veniam.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7';
wwv_flow_imp.g_varchar2_table(471) := '-8 Yr","9-10 Yr"],"reviews":[{"rating":6,"review":"Commodo ut fugiat voluptate adipisicing deserunt.';
wwv_flow_imp.g_varchar2_table(472) := '"},{"rating":4,"review":"Fugiat cupidatat amet fugiat cupidatat ea ea."},{"rating":7,"review":"Incid';
wwv_flow_imp.g_varchar2_table(473) := 'idunt ex enim commodo sit consequat enim."},{"rating":3,"review":"Ullamco in et aute laboris cillum.';
wwv_flow_imp.g_varchar2_table(474) := '"},{"rating":3,"review":"Reprehenderit Lorem proident sit deserunt do tempor commodo velit velit nul';
wwv_flow_imp.g_varchar2_table(475) := 'la ipsum."},{"rating":10,"review":"Dolore pariatur velit enim est culpa eiusmod cupidatat deserunt e';
wwv_flow_imp.g_varchar2_table(476) := 'sse elit exercitation sunt proident exercitation."},{"rating":2,"review":"Minim fugiat elit aliquip ';
wwv_flow_imp.g_varchar2_table(477) := 'nostrud velit reprehenderit cillum."},{"rating":4,"review":"Sint Lorem est laborum consectetur paria';
wwv_flow_imp.g_varchar2_table(478) := 'tur minim tempor ullamco Lorem est."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (prod';
wwv_flow_imp.g_varchar2_table(479) := 'uct_id, product_name, unit_price, product_details) values (27,''Boy''''s Coat (Blue)'',10.24,utl_raw.cas';
wwv_flow_imp.g_varchar2_table(480) := 't_to_raw(''{"colour":"brown","gender":"Boy''''s","brand":"GRONK","description":"Quis aliquip fugiat sun';
wwv_flow_imp.g_varchar2_table(481) := 't qui eu velit aliqua sint eiusmod mollit id ad. Anim anim ipsum in reprehenderit amet amet consecte';
wwv_flow_imp.g_varchar2_table(482) := 'tur incididunt qui cillum Lorem.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"revi';
wwv_flow_imp.g_varchar2_table(483) := 'ews":[{"rating":8,"review":"Sit id elit cupidatat aute consectetur esse proident aliqua ad voluptate';
wwv_flow_imp.g_varchar2_table(484) := ' cillum Lorem."},{"rating":6,"review":"Enim enim fugiat consectetur ut sunt veniam ad sit minim amet';
wwv_flow_imp.g_varchar2_table(485) := ' Lorem veniam mollit."},{"rating":5,"review":"Dolor ipsum consectetur nostrud ex Lorem pariatur volu';
wwv_flow_imp.g_varchar2_table(486) := 'ptate."},{"rating":8,"review":"Commodo magna sint sint dolore aute anim laborum."},{"rating":4,"revi';
wwv_flow_imp.g_varchar2_table(487) := 'ew":"Laboris amet proident occaecat dolore labore exercitation dolore sunt Lorem sunt anim."}]}''));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(488) := '            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_de';
wwv_flow_imp.g_varchar2_table(489) := 'tails) values (28,''Men''''s Hoodie (Red)'',24.71,utl_raw.cast_to_raw(''{"colour":"red","gender":"Men''''s"';
wwv_flow_imp.g_varchar2_table(490) := ',"brand":"FANGOLD","description":"Dolor irure dolore est ipsum nisi incididunt laboris culpa. Ullamc';
wwv_flow_imp.g_varchar2_table(491) := 'o ad cupidatat sint culpa adipisicing pariatur.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"';
wwv_flow_imp.g_varchar2_table(492) := 'rating":3,"review":"Proident aliqua aliquip aute quis cillum."},{"rating":5,"review":"Pariatur enim ';
wwv_flow_imp.g_varchar2_table(493) := 'ipsum aliqua Lorem eiusmod consequat cupidatat irure nulla sint fugiat veniam amet ipsum."},{"rating';
wwv_flow_imp.g_varchar2_table(494) := '":10,"review":"Sint duis ipsum reprehenderit Lorem aute pariatur elit."},{"rating":4,"review":"Enim ';
wwv_flow_imp.g_varchar2_table(495) := 'qui qui consequat culpa ex velit sint excepteur ipsum in amet mollit mollit."},{"rating":10,"review"';
wwv_flow_imp.g_varchar2_table(496) := ':"Qui velit reprehenderit fugiat adipisicing anim incididunt anim commodo occaecat consectetur in au';
wwv_flow_imp.g_varchar2_table(497) := 'te."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price';
wwv_flow_imp.g_varchar2_table(498) := ', product_details) values (29,''Boy''''s Shirt (Black)'',37.34,utl_raw.cast_to_raw(''{"colour":"black","g';
wwv_flow_imp.g_varchar2_table(499) := 'ender":"Boy''''s","brand":"SQUISH","description":"Pariatur nulla elit pariatur excepteur ullamco offic';
wwv_flow_imp.g_varchar2_table(500) := 'ia incididunt. Aliquip quis aliquip cupidatat magna fugiat eiusmod pariatur excepteur tempor officia';
wwv_flow_imp.g_varchar2_table(501) := ' voluptate fugiat.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating';
wwv_flow_imp.g_varchar2_table(502) := '":5,"review":"Non esse labore ullamco laboris irure cupidatat ex proident eiusmod."},{"rating":10,"r';
wwv_flow_imp.g_varchar2_table(503) := 'eview":"Ea velit et mollit labore consequat."},{"rating":6,"review":"Labore sit pariatur Lorem ad si';
wwv_flow_imp.g_varchar2_table(504) := 'nt consectetur incididunt deserunt eiusmod sit nostrud dolore eiusmod sint."},{"rating":1,"review":"';
wwv_flow_imp.g_varchar2_table(505) := 'Id voluptate sunt amet laboris laborum ad dolor aliqua ipsum sint qui aute eu esse."},{"rating":5,"r';
wwv_flow_imp.g_varchar2_table(506) := 'eview":"Sint Lorem dolore do ea."},{"rating":9,"review":"Quis pariatur consequat nisi labore Lorem e';
wwv_flow_imp.g_varchar2_table(507) := 'lit in qui Lorem."},{"rating":2,"review":"Consectetur voluptate tempor ullamco voluptate labore sint';
wwv_flow_imp.g_varchar2_table(508) := '."},{"rating":9,"review":"Qui laboris tempor ullamco ullamco commodo sint occaecat Lorem."},{"rating';
wwv_flow_imp.g_varchar2_table(509) := '":1,"review":"Laborum eu sit duis et culpa eu duis irure incididunt amet."}]}''));'||wwv_flow.LF||
'            insert';
wwv_flow_imp.g_varchar2_table(510) := ' into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (30,';
wwv_flow_imp.g_varchar2_table(511) := '''Women''''s Pyjamas (Grey)'',28.59,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Women''''s","brand":"T';
wwv_flow_imp.g_varchar2_table(512) := 'HREDZ","description":"Quis aliqua eiusmod incididunt quis ut ea aliqua sunt veniam ut et cupidatat e';
wwv_flow_imp.g_varchar2_table(513) := 'iusmod. Sunt sunt duis excepteur excepteur do exercitation.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"';
wwv_flow_imp.g_varchar2_table(514) := 'reviews":[{"rating":1,"review":"Et anim culpa voluptate pariatur ullamco dolore ad aliquip."},{"rati';
wwv_flow_imp.g_varchar2_table(515) := 'ng":4,"review":"Nulla non ea nisi nulla elit veniam duis."},{"rating":4,"review":"Lorem adipisicing ';
wwv_flow_imp.g_varchar2_table(516) := 'deserunt duis id sint aliquip minim deserunt magna sunt magna laborum dolore."},{"rating":3,"review"';
wwv_flow_imp.g_varchar2_table(517) := ':"Officia amet magna eu nulla dolore magna pariatur deserunt amet reprehenderit."},{"rating":3,"revi';
wwv_flow_imp.g_varchar2_table(518) := 'ew":"Ad aliqua ex eu cillum labore elit mollit reprehenderit anim."},{"rating":1,"review":"Duis exce';
wwv_flow_imp.g_varchar2_table(519) := 'pteur magna aliqua qui officia ipsum sunt."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttabl';
wwv_flow_imp.g_varchar2_table(520) := 'e (product_id, product_name, unit_price, product_details) values (31,''Women''''s Skirt (Green)'',5.65,u';
wwv_flow_imp.g_varchar2_table(521) := 'tl_raw.cast_to_raw(''{"colour":"green","gender":"Women''''s","brand":"ZIDANT","description":"Et est off';
wwv_flow_imp.g_varchar2_table(522) := 'icia est amet est nisi sit veniam proident. Ullamco proident culpa velit proident quis dolore occaec';
wwv_flow_imp.g_varchar2_table(523) := 'at proident Lorem tempor.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[]}''));'||wwv_flow.LF||
'            inser';
wwv_flow_imp.g_varchar2_table(524) := 't into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (32';
wwv_flow_imp.g_varchar2_table(525) := ',''Women''''s Jacket (Blue)'',37,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Women''''s","brand":"ZOGA';
wwv_flow_imp.g_varchar2_table(526) := 'K","description":"Tempor ipsum duis aliqua veniam qui laboris et ut officia. Fugiat fugiat nisi labo';
wwv_flow_imp.g_varchar2_table(527) := 're excepteur ullamco excepteur veniam in in et adipisicing sint.","sizes":[0,2,4,6,8,10,12,14,16,18,';
wwv_flow_imp.g_varchar2_table(528) := '20],"reviews":[{"rating":9,"review":"Sit amet id ut laborum in exercitation laborum Lorem fugiat ex.';
wwv_flow_imp.g_varchar2_table(529) := '"},{"rating":7,"review":"Nisi non mollit dolore id aute velit laboris consequat voluptate id."},{"ra';
wwv_flow_imp.g_varchar2_table(530) := 'ting":1,"review":"Nisi nisi fugiat non nisi amet esse."},{"rating":1,"review":"Laborum eiusmod id ip';
wwv_flow_imp.g_varchar2_table(531) := 'sum aliqua adipisicing cillum enim."},{"rating":8,"review":"Duis aliqua ut nulla proident voluptate ';
wwv_flow_imp.g_varchar2_table(532) := 'incididunt elit est exercitation id aute."},{"rating":4,"review":"Veniam labore exercitation eiusmod';
wwv_flow_imp.g_varchar2_table(533) := ' nisi mollit anim eu."},{"rating":6,"review":"Exercitation eu est irure velit pariatur."}]}''));'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(534) := '        insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_detail';
wwv_flow_imp.g_varchar2_table(535) := 's) values (33,''Boy''''s Pyjamas (Grey)'',23.32,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Boy''''s",';
wwv_flow_imp.g_varchar2_table(536) := '"brand":"RETRACK","description":"Sit consectetur Lorem culpa ipsum ad ullamco ea aute qui ea. Labori';
wwv_flow_imp.g_varchar2_table(537) := 's ipsum enim enim veniam.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{';
wwv_flow_imp.g_varchar2_table(538) := '"rating":7,"review":"Ut incididunt veniam ullamco voluptate occaecat velit."},{"rating":5,"review":"';
wwv_flow_imp.g_varchar2_table(539) := 'Consectetur cupidatat voluptate dolore velit culpa est id enim aute."}]}''));'||wwv_flow.LF||
'            insert into';
wwv_flow_imp.g_varchar2_table(540) := ' eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (34,''Wome';
wwv_flow_imp.g_varchar2_table(541) := 'n''''s Jeans (Red)'',7.18,utl_raw.cast_to_raw(''{"colour":"red","gender":"Women''''s","brand":"PANZENT","d';
wwv_flow_imp.g_varchar2_table(542) := 'escription":"Eiusmod culpa dolore occaecat excepteur esse magna fugiat dolore cupidatat laboris moll';
wwv_flow_imp.g_varchar2_table(543) := 'it culpa. Consequat dolor qui tempor sit minim sit excepteur enim excepteur aute minim.","sizes":[0,';
wwv_flow_imp.g_varchar2_table(544) := '2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":10,"review":"Nulla enim cillum pariatur do consectet';
wwv_flow_imp.g_varchar2_table(545) := 'ur et Lorem."},{"rating":1,"review":"Cupidatat fugiat incididunt fugiat eu."},{"rating":1,"review":"';
wwv_flow_imp.g_varchar2_table(546) := 'Ullamco eiusmod adipisicing fugiat reprehenderit mollit aliquip."}]}''));'||wwv_flow.LF||
'            insert into eba';
wwv_flow_imp.g_varchar2_table(547) := '_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (35,''Girl''''s ';
wwv_flow_imp.g_varchar2_table(548) := 'Dress (Red)'',49.12,utl_raw.cast_to_raw(''{"colour":"red","gender":"Girl''''s","brand":"NIXELT","descrip';
wwv_flow_imp.g_varchar2_table(549) := 'tion":"Ipsum pariatur laborum nulla pariatur consequat consequat amet nisi. Ut in quis officia excep';
wwv_flow_imp.g_varchar2_table(550) := 'teur.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":10,"review"';
wwv_flow_imp.g_varchar2_table(551) := ':"Ut est anim sit nulla commodo velit occaecat amet mollit fugiat id."},{"rating":2,"review":"Eu qui';
wwv_flow_imp.g_varchar2_table(552) := 's ea anim incididunt nisi nisi velit velit labore do."},{"rating":9,"review":"Eu laborum laborum rep';
wwv_flow_imp.g_varchar2_table(553) := 'rehenderit minim officia anim."},{"rating":8,"review":"Et consectetur labore ullamco occaecat cupida';
wwv_flow_imp.g_varchar2_table(554) := 'tat magna pariatur esse qui ut mollit ea cillum."},{"rating":4,"review":"Dolore culpa magna commodo ';
wwv_flow_imp.g_varchar2_table(555) := 'aute do culpa non commodo qui id commodo consectetur exercitation."},{"rating":6,"review":"Adipisici';
wwv_flow_imp.g_varchar2_table(556) := 'ng laborum tempor sunt laboris et sint aute pariatur."},{"rating":9,"review":"Excepteur voluptate qu';
wwv_flow_imp.g_varchar2_table(557) := 'i magna in cillum aliqua."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, pr';
wwv_flow_imp.g_varchar2_table(558) := 'oduct_name, unit_price, product_details) values (36,''Women''''s Trousers (Blue)'',29.51,utl_raw.cast_to';
wwv_flow_imp.g_varchar2_table(559) := '_raw(''{"colour":"blue","gender":"Women''''s","brand":"TROLLERY","description":"Proident sunt ipsum par';
wwv_flow_imp.g_varchar2_table(560) := 'iatur duis dolor eu dolore culpa ad aliquip elit. Mollit Lorem et aliquip commodo est anim amet eius';
wwv_flow_imp.g_varchar2_table(561) := 'mod amet dolore laborum tempor officia.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":';
wwv_flow_imp.g_varchar2_table(562) := '10,"review":"Consequat ut commodo irure sit elit anim amet eu est sunt tempor non."}]}''));'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(563) := '   insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) va';
wwv_flow_imp.g_varchar2_table(564) := 'lues (37,''Boy''''s Jeans (Blue)'',22.98,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Boy''''s","brand"';
wwv_flow_imp.g_varchar2_table(565) := ':"AVIT","description":"Velit velit esse nulla minim minim laborum esse. Sint minim id aliquip amet f';
wwv_flow_imp.g_varchar2_table(566) := 'ugiat dolor aliqua.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[]}''));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(567) := '            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_de';
wwv_flow_imp.g_varchar2_table(568) := 'tails) values (38,''Girl''''s Pyjamas (Red)'',11,utl_raw.cast_to_raw(''{"colour":"red","gender":"Girl''''s"';
wwv_flow_imp.g_varchar2_table(569) := ',"brand":"EMTRAK","description":"Magna est occaecat consectetur ullamco mollit dolore aute irure con';
wwv_flow_imp.g_varchar2_table(570) := 'sectetur nulla ipsum id elit occaecat. Amet Lorem sint nulla eiusmod commodo aliqua cillum anim temp';
wwv_flow_imp.g_varchar2_table(571) := 'or tempor pariatur do nostrud minim.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"';
wwv_flow_imp.g_varchar2_table(572) := 'reviews":[{"rating":4,"review":"Consectetur velit adipisicing excepteur in excepteur sit excepteur i';
wwv_flow_imp.g_varchar2_table(573) := 'rure veniam velit."},{"rating":4,"review":"Consectetur exercitation exercitation irure commodo offic';
wwv_flow_imp.g_varchar2_table(574) := 'ia do adipisicing ullamco sit anim consequat."},{"rating":9,"review":"Minim occaecat sunt laborum vo';
wwv_flow_imp.g_varchar2_table(575) := 'luptate culpa enim elit."},{"rating":2,"review":"Reprehenderit labore incididunt ex ullamco nostrud ';
wwv_flow_imp.g_varchar2_table(576) := 'cillum irure mollit dolore aliqua enim tempor aliquip laborum."},{"rating":2,"review":"Enim commodo ';
wwv_flow_imp.g_varchar2_table(577) := 'adipisicing consequat commodo."},{"rating":8,"review":"Sint ut cillum Lorem ut ad aliquip elit sunt ';
wwv_flow_imp.g_varchar2_table(578) := 'labore laboris consequat Lorem aliqua occaecat."},{"rating":2,"review":"Et consectetur in officia ul';
wwv_flow_imp.g_varchar2_table(579) := 'lamco labore ea duis amet."},{"rating":8,"review":"Reprehenderit enim tempor proident commodo ex eu ';
wwv_flow_imp.g_varchar2_table(580) := 'fugiat cupidatat exercitation culpa id adipisicing deserunt officia."}]}''));'||wwv_flow.LF||
'            insert into';
wwv_flow_imp.g_varchar2_table(581) := ' eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (39,''Boy''';
wwv_flow_imp.g_varchar2_table(582) := '''s Trousers (Blue)'',34.06,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Boy''''s","brand":"DIGINETIC';
wwv_flow_imp.g_varchar2_table(583) := '","description":"Dolor aliqua minim nostrud non labore in ullamco mollit mollit sit non. Duis nulla ';
wwv_flow_imp.g_varchar2_table(584) := 'exercitation et adipisicing nostrud voluptate cupidatat eu reprehenderit.","sizes":["1 Yr","2 Yr","3';
wwv_flow_imp.g_varchar2_table(585) := '-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":6,"review":"Culpa id consequat cillum dolor';
wwv_flow_imp.g_varchar2_table(586) := '."},{"rating":8,"review":"Qui do quis magna nostrud exercitation enim aute dolore proident ipsum sin';
wwv_flow_imp.g_varchar2_table(587) := 't nostrud deserunt."},{"rating":9,"review":"Excepteur fugiat adipisicing laboris ea culpa cupidatat ';
wwv_flow_imp.g_varchar2_table(588) := 'laborum occaecat nostrud."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, pr';
wwv_flow_imp.g_varchar2_table(589) := 'oduct_name, unit_price, product_details) values (40,''Girl''''s Pyjamas (Black)'',8.66,utl_raw.cast_to_r';
wwv_flow_imp.g_varchar2_table(590) := 'aw(''{"colour":"black","gender":"Girl''''s","brand":"ISOLOGICS","description":"Ex exercitation aliquip ';
wwv_flow_imp.g_varchar2_table(591) := 'cillum adipisicing cupidatat. Culpa labore eiusmod do ut ipsum incididunt ipsum labore.","sizes":["1';
wwv_flow_imp.g_varchar2_table(592) := ' Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":6,"review":"Duis minim duis d';
wwv_flow_imp.g_varchar2_table(593) := 'olor laboris eiusmod consequat fugiat adipisicing ex non culpa Lorem proident qui."},{"rating":4,"re';
wwv_flow_imp.g_varchar2_table(594) := 'view":"Veniam tempor commodo aliqua sit ex mollit cillum aute officia fugiat tempor sunt nulla elit.';
wwv_flow_imp.g_varchar2_table(595) := '"},{"rating":10,"review":"Dolore officia aute magna eiusmod exercitation esse amet tempor."},{"ratin';
wwv_flow_imp.g_varchar2_table(596) := 'g":7,"review":"Proident nisi voluptate ea esse exercitation ullamco consequat consectetur in enim am';
wwv_flow_imp.g_varchar2_table(597) := 'et adipisicing commodo nulla."},{"rating":4,"review":"Irure ullamco id adipisicing fugiat Lorem do n';
wwv_flow_imp.g_varchar2_table(598) := 'on officia nisi sunt esse mollit consectetur."},{"rating":9,"review":"Laboris do elit dolor officia ';
wwv_flow_imp.g_varchar2_table(599) := 'irure esse incididunt pariatur elit."},{"rating":1,"review":"Aliqua Lorem nostrud et reprehenderit e';
wwv_flow_imp.g_varchar2_table(600) := 'xercitation exercitation nostrud consectetur dolor."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_pr';
wwv_flow_imp.g_varchar2_table(601) := 'oducttable (product_id, product_name, unit_price, product_details) values (41,''Women''''s Dress (Black';
wwv_flow_imp.g_varchar2_table(602) := ')'',10.11,utl_raw.cast_to_raw(''{"colour":"black","gender":"Women''''s","brand":"NEOCENT","description":';
wwv_flow_imp.g_varchar2_table(603) := '"Eu enim aliquip deserunt est duis do sunt consequat sit sit labore nisi. Culpa mollit cupidatat Lor';
wwv_flow_imp.g_varchar2_table(604) := 'em et minim sit.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":4,"review":"Ex culpa si';
wwv_flow_imp.g_varchar2_table(605) := 'nt ad eu quis."},{"rating":4,"review":"Irure labore adipisicing velit sint sint."},{"rating":4,"revi';
wwv_flow_imp.g_varchar2_table(606) := 'ew":"Ullamco dolore ad qui consequat labore do cillum velit."},{"rating":5,"review":"Velit officia e';
wwv_flow_imp.g_varchar2_table(607) := 'iusmod proident dolore occaecat eu eiusmod."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttab';
wwv_flow_imp.g_varchar2_table(608) := 'le (product_id, product_name, unit_price, product_details) values (1,''Boy''''s Shirt (White)'',29.55,ut';
wwv_flow_imp.g_varchar2_table(609) := 'l_raw.cast_to_raw(''{"colour":"white","gender":"Boy''''s","brand":"COMTOURS","description":"Labore comm';
wwv_flow_imp.g_varchar2_table(610) := 'odo velit cupidatat ullamco ea proident velit sunt adipisicing. Esse tempor exercitation reprehender';
wwv_flow_imp.g_varchar2_table(611) := 'it ullamco esse incididunt dolore laboris Lorem ipsum fugiat ea.","sizes":["1 Yr","2 Yr","3-4 Yr","5';
wwv_flow_imp.g_varchar2_table(612) := '-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (pro';
wwv_flow_imp.g_varchar2_table(613) := 'duct_id, product_name, unit_price, product_details) values (2,''Women''''s Shirt (Green)'',16.67,utl_raw';
wwv_flow_imp.g_varchar2_table(614) := '.cast_to_raw(''{"colour":"green","gender":"Women''''s","brand":"NIKE","description":"Excepteur anim adi';
wwv_flow_imp.g_varchar2_table(615) := 'pisicing aliqua ad. Ex aliquip ad tempor cupidatat dolore ipsum ex anim Lorem aute amet.","sizes":[0';
wwv_flow_imp.g_varchar2_table(616) := ',2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":8,"review":"Laborum ipsum adipisicing magna nulla t';
wwv_flow_imp.g_varchar2_table(617) := 'empor incididunt."},{"rating":10,"review":"Cupidatat dolore nulla pariatur quis quis."},{"rating":9,';
wwv_flow_imp.g_varchar2_table(618) := '"review":"Pariatur mollit dolor in deserunt cillum consectetur."},{"rating":3,"review":"Dolore occae';
wwv_flow_imp.g_varchar2_table(619) := 'cat mollit id ad aliqua irure reprehenderit amet eiusmod pariatur."},{"rating":10,"review":"Est pari';
wwv_flow_imp.g_varchar2_table(620) := 'atur et qui minim velit non consectetur sint fugiat ad."},{"rating":6,"review":"Et pariatur ipsum eu';
wwv_flow_imp.g_varchar2_table(621) := ' qui."},{"rating":6,"review":"Voluptate labore irure cupidatat mollit irure quis fugiat enim laborum';
wwv_flow_imp.g_varchar2_table(622) := ' consectetur officia sunt."},{"rating":8,"review":"Irure elit do et elit aute veniam proident sunt."';
wwv_flow_imp.g_varchar2_table(623) := '},{"rating":8,"review":"Aute mollit proident id veniam occaecat dolore mollit dolore nostrud."}]}''))';
wwv_flow_imp.g_varchar2_table(624) := ';'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_';
wwv_flow_imp.g_varchar2_table(625) := 'details) values (3,''Boy''''s Sweater (Green)'',44.17,utl_raw.cast_to_raw(''{"colour":"green","gender":"B';
wwv_flow_imp.g_varchar2_table(626) := 'oy''''s","brand":"KINETICA","description":"Occaecat dolore in ut et ad pariatur laborum mollit nulla e';
wwv_flow_imp.g_varchar2_table(627) := 'xercitation. Laboris esse tempor quis velit nostrud exercitation veniam reprehenderit minim minim ex';
wwv_flow_imp.g_varchar2_table(628) := 'ercitation.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":5,"re';
wwv_flow_imp.g_varchar2_table(629) := 'view":"Sunt ad proident excepteur laboris officia eu reprehenderit dolor nostrud elit nulla pariatur';
wwv_flow_imp.g_varchar2_table(630) := ' incididunt Lorem."},{"rating":2,"review":"Ullamco ad amet fugiat adipisicing."}]}''));'||wwv_flow.LF||
'            i';
wwv_flow_imp.g_varchar2_table(631) := 'nsert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values';
wwv_flow_imp.g_varchar2_table(632) := ' (4,''Boy''''s Trousers (White)'',43.71,utl_raw.cast_to_raw(''{"colour":"white","gender":"Boy''''s","brand"';
wwv_flow_imp.g_varchar2_table(633) := ':"INTERLOO","description":"Nostrud esse velit incididunt occaecat ullamco dolor quis reprehenderit p';
wwv_flow_imp.g_varchar2_table(634) := 'roident dolore deserunt tempor qui proident. Magna deserunt sit minim eu commodo minim labore occaec';
wwv_flow_imp.g_varchar2_table(635) := 'at ea id sint laborum.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"ra';
wwv_flow_imp.g_varchar2_table(636) := 'ting":7,"review":"Anim culpa qui est adipisicing qui dolore enim. Sint duis aute laborum nisi ut eli';
wwv_flow_imp.g_varchar2_table(637) := 't Lorem nisi proident consectetur."},{"rating":6,"review":"Reprehenderit ad ipsum sint mollit aliqua';
wwv_flow_imp.g_varchar2_table(638) := '."},{"rating":4,"review":"Enim culpa reprehenderit non ullamco non ex veniam. Sit do incididunt ulla';
wwv_flow_imp.g_varchar2_table(639) := 'mco ad et et aliquip deserunt dolor officia nostrud ipsum officia nostrud. Lorem esse tempor aliqua ';
wwv_flow_imp.g_varchar2_table(640) := 'ut quis occaecat."},{"rating":9,"review":"Pariatur sit dolor dolor tempor commodo aute culpa sit."},';
wwv_flow_imp.g_varchar2_table(641) := '{"rating":2,"review":"Sunt enim sunt occaecat exercitation deserunt nisi anim mollit deserunt non la';
wwv_flow_imp.g_varchar2_table(642) := 'boris cillum."},{"rating":8,"review":"Exercitation et duis quis minim id duis veniam occaecat amet c';
wwv_flow_imp.g_varchar2_table(643) := 'illum velit pariatur tempor. Culpa aliquip adipisicing aliquip non minim occaecat eu nisi esse venia';
wwv_flow_imp.g_varchar2_table(644) := 'm eu aliqua."},{"rating":5,"review":"Culpa elit nulla dolore mollit tempor mollit in. Voluptate dese';
wwv_flow_imp.g_varchar2_table(645) := 'runt eiusmod sint id excepteur eiusmod excepteur qui enim cupidatat. Nostrud enim anim commodo adipi';
wwv_flow_imp.g_varchar2_table(646) := 'sicing nisi dolore commodo elit commodo aliqua aliquip laborum."},{"rating":4,"review":"Exercitation';
wwv_flow_imp.g_varchar2_table(647) := ' sunt consequat anim nisi sunt cillum esse amet ut reprehenderit ea. Laborum labore ipsum consectetu';
wwv_flow_imp.g_varchar2_table(648) := 'r ad excepteur proident fugiat consectetur eiusmod incididunt officia enim ullamco."}]}''));'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(649) := '    insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) v';
wwv_flow_imp.g_varchar2_table(650) := 'alues (5,''Girl''''s Shorts (Red)'',38.28,utl_raw.cast_to_raw(''{"colour":"red","gender":"Girl''''s","brand';
wwv_flow_imp.g_varchar2_table(651) := '":"OZEAN","description":"These sea shorts are designed with quick-drying and breathable materials, m';
wwv_flow_imp.g_varchar2_table(652) := 'aking them the perfect choice for a day out on the water.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr",';
wwv_flow_imp.g_varchar2_table(653) := '"7-8 Yr","9-10 Yr"],"reviews":[]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id';
wwv_flow_imp.g_varchar2_table(654) := ', product_name, unit_price, product_details) values (6,''Boy''''s Socks (Grey)'',19.16,utl_raw.cast_to_r';
wwv_flow_imp.g_varchar2_table(655) := 'aw(''{"colour":"grey","gender":"Boy''''s","brand":"GROK","description":"Pariatur elit adipisicing aute ';
wwv_flow_imp.g_varchar2_table(656) := 'dolor sunt laborum ullamco aliqua exercitation consectetur. Lorem qui sint ullamco sint commodo anim';
wwv_flow_imp.g_varchar2_table(657) := '.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":5,"review":"Ea ';
wwv_flow_imp.g_varchar2_table(658) := 'eu sit est consectetur quis in dolor ut."},{"rating":6,"review":"In do cillum occaecat minim."},{"ra';
wwv_flow_imp.g_varchar2_table(659) := 'ting":6,"review":"Laborum laborum excepteur ipsum aliquip reprehenderit cillum irure proident volupt';
wwv_flow_imp.g_varchar2_table(660) := 'ate eiusmod in culpa."},{"rating":9,"review":"Exercitation magna proident non deserunt consectetur c';
wwv_flow_imp.g_varchar2_table(661) := 'onsectetur do ex sint id irure ipsum voluptate."},{"rating":7,"review":"Aliquip irure minim quis qui';
wwv_flow_imp.g_varchar2_table(662) := 's voluptate reprehenderit mollit dolore."},{"rating":1,"review":"Duis mollit aute cillum aute culpa ';
wwv_flow_imp.g_varchar2_table(663) := 'magna."},{"rating":9,"review":"Magna exercitation exercitation sit commodo proident fugiat occaecat ';
wwv_flow_imp.g_varchar2_table(664) := 'ullamco voluptate do consectetur officia velit."},{"rating":7,"review":"Laboris nostrud et nulla tem';
wwv_flow_imp.g_varchar2_table(665) := 'por commodo non aute ipsum excepteur qui dolore enim."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_';
wwv_flow_imp.g_varchar2_table(666) := 'producttable (product_id, product_name, unit_price, product_details) values (7,''Boy''''s Socks (Black)';
wwv_flow_imp.g_varchar2_table(667) := ''',19.58,utl_raw.cast_to_raw(''{"colour":"black","gender":"Boy''''s","brand":"ENERVATE","description":"S';
wwv_flow_imp.g_varchar2_table(668) := 'it minim sunt nulla proident velit Lorem dolor. Aute reprehenderit laborum labore proident non esse ';
wwv_flow_imp.g_varchar2_table(669) := 'nisi ex magna consectetur minim ex est.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"';
wwv_flow_imp.g_varchar2_table(670) := '],"reviews":[{"rating":8,"review":"Laborum laboris eu occaecat amet adipisicing consequat veniam vel';
wwv_flow_imp.g_varchar2_table(671) := 'it."},{"rating":2,"review":"Mollit fugiat commodo minim sint do irure duis quis ex minim ad."},{"rat';
wwv_flow_imp.g_varchar2_table(672) := 'ing":2,"review":"Sit duis aliquip proident et nostrud enim anim amet dolor consequat tempor culpa."}';
wwv_flow_imp.g_varchar2_table(673) := ',{"rating":3,"review":"Proident aute voluptate aute irure."},{"rating":2,"review":"Ex excepteur duis';
wwv_flow_imp.g_varchar2_table(674) := ' irure veniam elit occaecat sit Lorem labore id minim tempor dolore officia."},{"rating":2,"review":';
wwv_flow_imp.g_varchar2_table(675) := '"Amet fugiat commodo qui eiusmod dolore sint fugiat commodo elit qui esse in officia."},{"rating":2,';
wwv_flow_imp.g_varchar2_table(676) := '"review":"Dolor proident proident ad officia cillum dolor aute officia enim exercitation."},{"rating';
wwv_flow_imp.g_varchar2_table(677) := '":4,"review":"Dolor esse cupidatat eiusmod non veniam elit nostrud aliquip eu elit."}]}''));'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(678) := '    insert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) v';
wwv_flow_imp.g_varchar2_table(679) := 'alues (8,''Boy''''s Coat (Brown)'',21.16,utl_raw.cast_to_raw(''{"colour":"brown","gender":"Boy''''s","brand';
wwv_flow_imp.g_varchar2_table(680) := '":"KOFFEE","description":"Voluptate quis excepteur mollit id dolore. Sunt aliquip in magna ut irure ';
wwv_flow_imp.g_varchar2_table(681) := 'nostrud duis officia fugiat aute.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"rev';
wwv_flow_imp.g_varchar2_table(682) := 'iews":[]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_pri';
wwv_flow_imp.g_varchar2_table(683) := 'ce, product_details) values (9,''Women''''s Jeans (Brown)'',29.49,utl_raw.cast_to_raw(''{"colour":"brown"';
wwv_flow_imp.g_varchar2_table(684) := ',"gender":"Women''''s","brand":"PROTODYNE","description":"Est dolor tempor sint commodo irure sint ut ';
wwv_flow_imp.g_varchar2_table(685) := 'dolor proident enim Lorem. Pariatur deserunt nostrud quis minim non.","sizes":[0,2,4,6,8,10,12,14,16';
wwv_flow_imp.g_varchar2_table(686) := ',18,20],"reviews":[{"rating":2,"review":"Occaecat cupidatat in id elit magna Lorem esse ad magna lab';
wwv_flow_imp.g_varchar2_table(687) := 'ore non qui magna."},{"rating":8,"review":"Cupidatat cupidatat laboris consectetur labore veniam ali';
wwv_flow_imp.g_varchar2_table(688) := 'qua et incididunt duis sunt proident."},{"rating":2,"review":"Esse ipsum veniam ullamco irure ad min';
wwv_flow_imp.g_varchar2_table(689) := 'im mollit consequat non dolor labore."},{"rating":1,"review":"Cillum ea minim voluptate id ut consec';
wwv_flow_imp.g_varchar2_table(690) := 'tetur commodo nostrud cillum eiusmod eiusmod dolore cillum veniam."},{"rating":5,"review":"Excepteur';
wwv_flow_imp.g_varchar2_table(691) := ' adipisicing culpa dolor id et irure sint ex non nostrud velit pariatur esse quis."},{"rating":9,"re';
wwv_flow_imp.g_varchar2_table(692) := 'view":"Do fugiat aliqua sunt quis proident fugiat."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_pro';
wwv_flow_imp.g_varchar2_table(693) := 'ducttable (product_id, product_name, unit_price, product_details) values (10,''Women''''s Skirt (Red)'',';
wwv_flow_imp.g_varchar2_table(694) := '30.69,utl_raw.cast_to_raw(''{"colour":"green","gender":"Women''''s","brand":"FLYBOYZ","description":"Qu';
wwv_flow_imp.g_varchar2_table(695) := 'i aliquip dolor aute labore amet nostrud deserunt nulla ut veniam id. Ut aute velit tempor anim ex s';
wwv_flow_imp.g_varchar2_table(696) := 'it nisi.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":7,"review":"Mollit consequat mi';
wwv_flow_imp.g_varchar2_table(697) := 'nim sit consequat deserunt duis."},{"rating":8,"review":"Quis eu esse proident elit eu aliqua magna ';
wwv_flow_imp.g_varchar2_table(698) := 'voluptate labore adipisicing voluptate ex do."},{"rating":6,"review":"Laborum nulla aliquip nulla ad';
wwv_flow_imp.g_varchar2_table(699) := 'ipisicing aliquip qui cupidatat aliquip in."},{"rating":3,"review":"Exercitation aute voluptate volu';
wwv_flow_imp.g_varchar2_table(700) := 'ptate tempor sit enim ut veniam do."},{"rating":8,"review":"Cillum cillum anim aliqua eu deserunt am';
wwv_flow_imp.g_varchar2_table(701) := 'et eu ut veniam in qui."},{"rating":7,"review":"Nostrud aliqua ullamco irure consectetur elit nisi e';
wwv_flow_imp.g_varchar2_table(702) := 'u elit reprehenderit ut."},{"rating":5,"review":"Irure nisi dolore dolore ut non ad minim pariatur."';
wwv_flow_imp.g_varchar2_table(703) := '},{"rating":2,"review":"Laboris aliqua sint est incididunt sunt non tempor irure reprehenderit labor';
wwv_flow_imp.g_varchar2_table(704) := 'e."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price,';
wwv_flow_imp.g_varchar2_table(705) := ' product_details) values (11,''Boy''''s Shorts (Blue)'',10.48,utl_raw.cast_to_raw(''{"colour":"blue","gen';
wwv_flow_imp.g_varchar2_table(706) := 'der":"Boy''''s","brand":"WRAPTURE","description":"Id sit adipisicing ea dolore fugiat laborum ut dolor';
wwv_flow_imp.g_varchar2_table(707) := 'e. Reprehenderit aliqua non adipisicing aliqua adipisicing aute ullamco consectetur est aliqua.","si';
wwv_flow_imp.g_varchar2_table(708) := 'zes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Laborum l';
wwv_flow_imp.g_varchar2_table(709) := 'abore exercitation culpa sint cillum aute duis labore do excepteur."},{"rating":10,"review":"Do veli';
wwv_flow_imp.g_varchar2_table(710) := 't laborum adipisicing velit."},{"rating":6,"review":"Culpa dolor aute adipisicing ad."},{"rating":6,';
wwv_flow_imp.g_varchar2_table(711) := '"review":"Sit sunt elit proident fugiat consectetur id incididunt nulla nulla magna consectetur."},{';
wwv_flow_imp.g_varchar2_table(712) := '"rating":6,"review":"Adipisicing ipsum eiusmod sint ullamco dolor irure qui officia."},{"rating":4,"';
wwv_flow_imp.g_varchar2_table(713) := 'review":"Ipsum commodo amet non ut labore."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttabl';
wwv_flow_imp.g_varchar2_table(714) := 'e (product_id, product_name, unit_price, product_details) values (12,''Boy''''s Socks (White)'',12.64,ut';
wwv_flow_imp.g_varchar2_table(715) := 'l_raw.cast_to_raw(''{"colour":"grey","gender":"Boy''''s","brand":"HANDSHAKE","description":"Tempor labo';
wwv_flow_imp.g_varchar2_table(716) := 'rum voluptate mollit aliquip et tempor nostrud Lorem. Nostrud anim exercitation est fugiat elit est ';
wwv_flow_imp.g_varchar2_table(717) := 'deserunt mollit exercitation.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews';
wwv_flow_imp.g_varchar2_table(718) := '":[{"rating":8,"review":"Quis culpa laborum ex magna."},{"rating":3,"review":"Culpa ullamco deserunt';
wwv_flow_imp.g_varchar2_table(719) := ' ex ea."},{"rating":3,"review":"Fugiat ullamco reprehenderit tempor nulla ad fugiat qui excepteur su';
wwv_flow_imp.g_varchar2_table(720) := 'nt officia deserunt nulla."},{"rating":2,"review":"Mollit dolore magna magna veniam culpa ullamco te';
wwv_flow_imp.g_varchar2_table(721) := 'mpor esse id in occaecat excepteur ullamco ea."},{"rating":10,"review":"Culpa dolore enim consequat ';
wwv_flow_imp.g_varchar2_table(722) := 'aliquip nulla ipsum."},{"rating":2,"review":"Excepteur aliqua sunt exercitation mollit pariatur anim';
wwv_flow_imp.g_varchar2_table(723) := ' tempor."},{"rating":8,"review":"Proident culpa tempor dolore deserunt anim ea deserunt quis duis."}';
wwv_flow_imp.g_varchar2_table(724) := ',{"rating":8,"review":"Reprehenderit est do quis quis reprehenderit adipisicing qui Lorem mollit sit';
wwv_flow_imp.g_varchar2_table(725) := ' labore veniam."},{"rating":1,"review":"Mollit dolore ad laboris ut cillum velit in sint labore null';
wwv_flow_imp.g_varchar2_table(726) := 'a Lorem minim."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, product_name,';
wwv_flow_imp.g_varchar2_table(727) := ' unit_price, product_details) values (13,''Boy''''s Hoodie (Grey)'',26.14,utl_raw.cast_to_raw(''{"colour"';
wwv_flow_imp.g_varchar2_table(728) := ':"grey","gender":"Boy''''s","brand":"SUNCLIPSE","description":"Voluptate irure voluptate labore sint a';
wwv_flow_imp.g_varchar2_table(729) := 'met occaecat elit ea incididunt aliquip. Tempor laboris tempor tempor magna officia in aliqua conseq';
wwv_flow_imp.g_varchar2_table(730) := 'uat elit occaecat.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating';
wwv_flow_imp.g_varchar2_table(731) := '":7,"review":"Fugiat officia nostrud cillum duis consequat sunt culpa duis laborum reprehenderit lab';
wwv_flow_imp.g_varchar2_table(732) := 'orum."},{"rating":10,"review":"Et do reprehenderit do irure tempor id aliquip voluptate anim consequ';
wwv_flow_imp.g_varchar2_table(733) := 'at amet sunt."},{"rating":3,"review":"Minim adipisicing dolore eiusmod laborum aliqua non Lorem labo';
wwv_flow_imp.g_varchar2_table(734) := 'ris minim est cillum qui qui Lorem."},{"rating":4,"review":"Esse Lorem aute deserunt quis."},{"ratin';
wwv_flow_imp.g_varchar2_table(735) := 'g":1,"review":"Ex deserunt aliqua consectetur elit cillum cillum ex et mollit sint."},{"rating":4,"r';
wwv_flow_imp.g_varchar2_table(736) := 'eview":"Magna esse ipsum ipsum irure officia nostrud ad velit sit."},{"rating":8,"review":"Mollit et';
wwv_flow_imp.g_varchar2_table(737) := ' tempor esse fugiat fugiat ad voluptate irure est sunt proident magna anim ex."},{"rating":4,"review';
wwv_flow_imp.g_varchar2_table(738) := '":"Nulla nisi esse ut exercitation commodo irure non amet labore mollit et elit."},{"rating":1,"revi';
wwv_flow_imp.g_varchar2_table(739) := 'ew":"Enim officia anim proident consequat."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttabl';
wwv_flow_imp.g_varchar2_table(740) := 'e (product_id, product_name, unit_price, product_details) values (14,''Women''''s Skirt (Brown)'',13.97,';
wwv_flow_imp.g_varchar2_table(741) := 'utl_raw.cast_to_raw(''{"colour":"brown","gender":"Women''''s","brand":"ISOTRONIC","description":"Magna ';
wwv_flow_imp.g_varchar2_table(742) := 'Lorem do ad incididunt qui magna irure commodo nisi. Dolore ipsum adipisicing magna ea ullamco Lorem';
wwv_flow_imp.g_varchar2_table(743) := ' officia culpa do laborum voluptate.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":1,"';
wwv_flow_imp.g_varchar2_table(744) := 'review":"Officia occaecat laboris magna sint tempor officia deserunt proident eu excepteur."},{"rati';
wwv_flow_imp.g_varchar2_table(745) := 'ng":2,"review":"Aliqua nisi sint enim ad mollit qui."},{"rating":3,"review":"Fugiat excepteur eiusmo';
wwv_flow_imp.g_varchar2_table(746) := 'd incididunt Lorem nostrud nostrud labore aute esse aliquip."},{"rating":8,"review":"Voluptate ad en';
wwv_flow_imp.g_varchar2_table(747) := 'im anim culpa veniam amet."},{"rating":3,"review":"Do cillum quis cillum Lorem tempor labore laboris';
wwv_flow_imp.g_varchar2_table(748) := '."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, product_name, unit_price, ';
wwv_flow_imp.g_varchar2_table(749) := 'product_details) values (15,''Girl''''s Coat (Blue)'',13.09,utl_raw.cast_to_raw(''{"colour":"blue","gende';
wwv_flow_imp.g_varchar2_table(750) := 'r":"Girl''''s","brand":"DECRATEX","description":"Proident ut officia non duis est eu aliquip culpa cup';
wwv_flow_imp.g_varchar2_table(751) := 'idatat est incididunt amet ipsum veniam. Aliqua ea cupidatat incididunt ad excepteur irure ad pariat';
wwv_flow_imp.g_varchar2_table(752) := 'ur occaecat duis incididunt excepteur amet.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10';
wwv_flow_imp.g_varchar2_table(753) := ' Yr"],"reviews":[{"rating":8,"review":"Officia irure deserunt mollit Lorem dolor dolor minim deserun';
wwv_flow_imp.g_varchar2_table(754) := 't."},{"rating":10,"review":"Aliqua nostrud dolore enim dolore reprehenderit officia quis aliquip iru';
wwv_flow_imp.g_varchar2_table(755) := 're occaecat et."},{"rating":2,"review":"Consectetur consequat ut cupidatat et elit et cillum veniam ';
wwv_flow_imp.g_varchar2_table(756) := 'exercitation Lorem culpa ipsum."},{"rating":9,"review":"Nisi tempor incididunt Lorem sit sit do moll';
wwv_flow_imp.g_varchar2_table(757) := 'it qui aliquip qui eu quis Lorem."},{"rating":9,"review":"Sunt nulla ad dolore fugiat cillum et."},{';
wwv_flow_imp.g_varchar2_table(758) := '"rating":8,"review":"Incididunt nostrud officia sunt cupidatat culpa ex id ut."},{"rating":1,"review';
wwv_flow_imp.g_varchar2_table(759) := '":"Deserunt sit officia enim adipisicing exercitation velit ipsum dolore laboris officia mollit ex e';
wwv_flow_imp.g_varchar2_table(760) := 'sse et."},{"rating":3,"review":"Aliqua nulla laborum id mollit irure incididunt aliqua mollit qui no';
wwv_flow_imp.g_varchar2_table(761) := 'strud consectetur sint aliqua quis."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (prod';
wwv_flow_imp.g_varchar2_table(762) := 'uct_id, product_name, unit_price, product_details) values (42,''Boy''''s Jeans (Black)'',16.64,utl_raw.c';
wwv_flow_imp.g_varchar2_table(763) := 'ast_to_raw(''{"colour":"black","gender":"Boy''''s","brand":"EARTHMARK","description":"Duis dolor est eu';
wwv_flow_imp.g_varchar2_table(764) := ' elit anim proident aliqua eu tempor. Est fugiat non ullamco et pariatur nulla exercitation eiusmod ';
wwv_flow_imp.g_varchar2_table(765) := 'id officia minim.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating"';
wwv_flow_imp.g_varchar2_table(766) := ':10,"review":"Anim aliquip id reprehenderit laboris."},{"rating":7,"review":"Nostrud non cupidatat i';
wwv_flow_imp.g_varchar2_table(767) := 'd eiusmod aliquip anim ullamco aliquip cupidatat excepteur dolor reprehenderit."},{"rating":6,"revie';
wwv_flow_imp.g_varchar2_table(768) := 'w":"Veniam consequat deserunt nostrud sunt est commodo sint eu fugiat ipsum deserunt aute elit est."';
wwv_flow_imp.g_varchar2_table(769) := '},{"rating":9,"review":"Eiusmod excepteur ut ullamco eiusmod labore deserunt."},{"rating":5,"review"';
wwv_flow_imp.g_varchar2_table(770) := ':"Aute deserunt eu voluptate id irure aliquip duis sint proident dolore dolor."},{"rating":5,"review';
wwv_flow_imp.g_varchar2_table(771) := '":"Dolore mollit quis elit qui voluptate ad culpa voluptate elit consectetur."}]}''));'||wwv_flow.LF||
'            in';
wwv_flow_imp.g_varchar2_table(772) := 'sert into eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values ';
wwv_flow_imp.g_varchar2_table(773) := '(43,''Boy''''s Trousers (Black)'',39.32,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Boy''''s","brand":';
wwv_flow_imp.g_varchar2_table(774) := '"PHOLIO","description":"Voluptate ex mollit enim minim nulla proident dolor eu nostrud velit. Ex ull';
wwv_flow_imp.g_varchar2_table(775) := 'amco aute dolor duis elit elit.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"revie';
wwv_flow_imp.g_varchar2_table(776) := 'ws":[{"rating":3,"review":"Labore non exercitation anim id deserunt excepteur dolore sunt deserunt d';
wwv_flow_imp.g_varchar2_table(777) := 'olor."},{"rating":5,"review":"Laborum eiusmod mollit amet nulla ex esse culpa ut elit reprehenderit ';
wwv_flow_imp.g_varchar2_table(778) := 'labore ex Lorem cupidatat."},{"rating":7,"review":"Reprehenderit dolore aute consectetur voluptate e';
wwv_flow_imp.g_varchar2_table(779) := 'xcepteur veniam nulla ad."},{"rating":5,"review":"Reprehenderit proident in elit pariatur."},{"ratin';
wwv_flow_imp.g_varchar2_table(780) := 'g":8,"review":"Magna laborum ad deserunt voluptate enim excepteur enim dolore veniam consequat offic';
wwv_flow_imp.g_varchar2_table(781) := 'ia anim dolore mollit."},{"rating":3,"review":"Elit et reprehenderit amet aute amet laboris minim ir';
wwv_flow_imp.g_varchar2_table(782) := 'ure sint."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, product_name, unit';
wwv_flow_imp.g_varchar2_table(783) := '_price, product_details) values (44,''Women''''s Coat (Black)'',31.68,utl_raw.cast_to_raw(''{"colour":"bl';
wwv_flow_imp.g_varchar2_table(784) := 'ack","gender":"Women''''s","brand":"COMVEYOR","description":"Exercitation ut ad reprehenderit sunt eiu';
wwv_flow_imp.g_varchar2_table(785) := 'smod sit. Qui nisi ut esse mollit nisi.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":';
wwv_flow_imp.g_varchar2_table(786) := '7,"review":"Ad consequat nisi est tempor nisi nulla veniam consectetur ad ut laborum magna."},{"rati';
wwv_flow_imp.g_varchar2_table(787) := 'ng":8,"review":"Incididunt magna ipsum cupidatat elit eiusmod enim mollit eiusmod id esse sit elit i';
wwv_flow_imp.g_varchar2_table(788) := 'rure Lorem."},{"rating":7,"review":"Aute aliquip et esse consequat reprehenderit ipsum ut."},{"ratin';
wwv_flow_imp.g_varchar2_table(789) := 'g":8,"review":"Consectetur commodo cupidatat nostrud qui labore magna duis sit."},{"rating":8,"revie';
wwv_flow_imp.g_varchar2_table(790) := 'w":"Qui occaecat elit exercitation do est officia fugiat adipisicing velit occaecat deserunt Lorem e';
wwv_flow_imp.g_varchar2_table(791) := 'x adipisicing."},{"rating":6,"review":"Velit est commodo esse sint id ullamco aute ut ut officia lab';
wwv_flow_imp.g_varchar2_table(792) := 'oris irure in."},{"rating":10,"review":"Ad nulla labore cupidatat do laboris do elit cupidatat excep';
wwv_flow_imp.g_varchar2_table(793) := 'teur occaecat cupidatat."},{"rating":5,"review":"Do esse magna occaecat non."},{"rating":10,"review"';
wwv_flow_imp.g_varchar2_table(794) := ':"Et sint qui tempor nostrud sunt sit duis dolor excepteur voluptate."}]}''));'||wwv_flow.LF||
'            insert int';
wwv_flow_imp.g_varchar2_table(795) := 'o eba_demo_rest_producttable (product_id, product_name, unit_price, product_details) values (45,''Men';
wwv_flow_imp.g_varchar2_table(796) := '''''s Jeans (Grey)'',27.64,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Men''''s","brand":"QNEKT","des';
wwv_flow_imp.g_varchar2_table(797) := 'cription":"Dolore duis minim dolor est fugiat sit dolor nisi anim Lorem culpa id. Consequat labore e';
wwv_flow_imp.g_varchar2_table(798) := 't reprehenderit pariatur culpa minim laboris pariatur esse aliquip.","sizes":["XS","S","M","L","XL",';
wwv_flow_imp.g_varchar2_table(799) := '"XXL"],"reviews":[{"rating":7,"review":"Veniam qui ipsum consequat laboris ad aliquip est reprehende';
wwv_flow_imp.g_varchar2_table(800) := 'rit esse sint cupidatat tempor."},{"rating":8,"review":"Ut anim anim ipsum ipsum irure."},{"rating":';
wwv_flow_imp.g_varchar2_table(801) := '9,"review":"Non qui sunt ullamco deserunt sint."},{"rating":10,"review":"Nostrud fugiat velit aliqua';
wwv_flow_imp.g_varchar2_table(802) := ' eu culpa do excepteur do."}]}''));'||wwv_flow.LF||
'            insert into eba_demo_rest_producttable (product_id, p';
wwv_flow_imp.g_varchar2_table(803) := 'roduct_name, unit_price, product_details) values (46,''Girl''''s Trousers (Red)'',39.16,utl_raw.cast_to_';
wwv_flow_imp.g_varchar2_table(804) := 'raw(''{"colour":"red","gender":"Girl''''s","brand":"OTHERSIDE","description":"Lorem officia laborum des';
wwv_flow_imp.g_varchar2_table(805) := 'erunt veniam cillum anim adipisicing minim aute ad esse sint sit tempor. Magna enim proident eiusmod';
wwv_flow_imp.g_varchar2_table(806) := ' incididunt adipisicing duis deserunt pariatur sint officia occaecat est minim ipsum.","sizes":["1 Y';
wwv_flow_imp.g_varchar2_table(807) := 'r","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":9,"review":"Magna magna ullamco';
wwv_flow_imp.g_varchar2_table(808) := ' ipsum pariatur occaecat eiusmod amet ea sunt reprehenderit dolore aute voluptate."},{"rating":7,"re';
wwv_flow_imp.g_varchar2_table(809) := 'view":"Eiusmod cupidatat cillum qui dolor consequat."},{"rating":4,"review":"Do proident cillum cupi';
wwv_flow_imp.g_varchar2_table(810) := 'datat laboris in cillum."},{"rating":5,"review":"Sunt eiusmod ea labore est sint adipisicing velit d';
wwv_flow_imp.g_varchar2_table(811) := 'uis."},{"rating":6,"review":"Ut consectetur ad magna officia ut aliqua deserunt magna."}]}''));'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(812) := '      -- tasks data '||wwv_flow.LF||
''||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_dat';
wwv_flow_imp.g_varchar2_table(813) := 'e, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (1,';
wwv_flow_imp.g_varchar2_table(814) := ' ''ACME Web Express'', ''Identify server requirements'', to_date(''2024-02-23 14:34:02'',''YYYY-MM-DD HH24:';
wwv_flow_imp.g_varchar2_table(815) := 'MI:SS''), to_date(''2024-02-24 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''John Watson'', 200, 500, ';
wwv_flow_imp.g_varchar2_table(816) := 'sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, ';
wwv_flow_imp.g_varchar2_table(817) := 'start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) v';
wwv_flow_imp.g_varchar2_table(818) := 'alues (2, ''ACME Web Express'', ''Determine Web listener configuration(s)'', to_date(''2025-02-25 14:34:0';
wwv_flow_imp.g_varchar2_table(819) := '2'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-25 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Jame';
wwv_flow_imp.g_varchar2_table(820) := 's Cassidy'', 600, 500, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id';
wwv_flow_imp.g_varchar2_table(821) := ', project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, ';
wwv_flow_imp.g_varchar2_table(822) := 'updated, updated_by) values (3, ''ACME Web Express'', ''Run installation'', to_date(''2025-02-28 14:34:02';
wwv_flow_imp.g_varchar2_table(823) := ''',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-28 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''James';
wwv_flow_imp.g_varchar2_table(824) := ' Cassidy'', 200, 200, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id,';
wwv_flow_imp.g_varchar2_table(825) := ' project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, u';
wwv_flow_imp.g_varchar2_table(826) := 'pdated, updated_by) values (4, ''ACME Web Express'', ''Create pilot workspace'', to_date(''2025-03-02 14:';
wwv_flow_imp.g_varchar2_table(827) := '34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-02 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''';
wwv_flow_imp.g_varchar2_table(828) := 'John Watson'', 100, 100, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (';
wwv_flow_imp.g_varchar2_table(829) := 'id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by';
wwv_flow_imp.g_varchar2_table(830) := ', updated, updated_by) values (5, ''ACME Web Express'', ''Specify security authentication scheme(s)'', t';
wwv_flow_imp.g_varchar2_table(831) := 'o_date(''2025-03-07 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-07 14:34:02'',''YYYY-MM-DD HH2';
wwv_flow_imp.g_varchar2_table(832) := '4:MI:SS''), ''Open'', ''John Watson'', 200, 300, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into e';
wwv_flow_imp.g_varchar2_table(833) := 'ba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget,';
wwv_flow_imp.g_varchar2_table(834) := ' created, created_by, updated, updated_by) values (6, ''ACME Web Express'', ''Configure Workspace provi';
wwv_flow_imp.g_varchar2_table(835) := 'sioning'', to_date(''2025-03-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-08 14:34:02'',''YYY';
wwv_flow_imp.g_varchar2_table(836) := 'Y-MM-DD HH24:MI:SS''), ''Open'', ''John Watson'', 200, 100, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            in';
wwv_flow_imp.g_varchar2_table(837) := 'sert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, co';
wwv_flow_imp.g_varchar2_table(838) := 'st, budget, created, created_by, updated, updated_by) values (7, ''ACME Web Express'', ''Select servers';
wwv_flow_imp.g_varchar2_table(839) := ' for Development, Test, Production'', to_date(''2025-03-11 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date';
wwv_flow_imp.g_varchar2_table(840) := '(''2025-03-13 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''James Cassidy'', 200, 600, sysdate, null, s';
wwv_flow_imp.g_varchar2_table(841) := 'ysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_';
wwv_flow_imp.g_varchar2_table(842) := 'date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (8, ''Bug T';
wwv_flow_imp.g_varchar2_table(843) := 'racker'', ''Document quality assurance procedures'', to_date(''2025-01-09 14:34:02'',''YYYY-MM-DD HH24:MI:';
wwv_flow_imp.g_varchar2_table(844) := 'SS''), to_date(''2025-01-12 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Myra Sutcliff'', 3000, 2000,';
wwv_flow_imp.g_varchar2_table(845) := ' sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name,';
wwv_flow_imp.g_varchar2_table(846) := ' start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) ';
wwv_flow_imp.g_varchar2_table(847) := 'values (9, ''Bug Tracker'', ''Review automated testing tools'', to_date(''2025-01-13 14:34:02'',''YYYY-MM-D';
wwv_flow_imp.g_varchar2_table(848) := 'D HH24:MI:SS''), to_date(''2025-01-15 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Myra Sutcliff'', 7';
wwv_flow_imp.g_varchar2_table(849) := '50, 1500, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, t';
wwv_flow_imp.g_varchar2_table(850) := 'ask_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, upd';
wwv_flow_imp.g_varchar2_table(851) := 'ated_by) values (10, ''Bug Tracker'', ''Implement bug tracking software'', to_date(''2025-01-28 14:34:02''';
wwv_flow_imp.g_varchar2_table(852) := ',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-01-28 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Myra S';
wwv_flow_imp.g_varchar2_table(853) := 'utcliff'', 100, 100, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, ';
wwv_flow_imp.g_varchar2_table(854) := 'project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, up';
wwv_flow_imp.g_varchar2_table(855) := 'dated, updated_by) values (11, ''Bug Tracker'', ''Train developers on tracking bugs'', to_date(''2025-02-';
wwv_flow_imp.g_varchar2_table(856) := '04 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''On-H';
wwv_flow_imp.g_varchar2_table(857) := 'old'', ''Myra Sutcliff'', 1000, 2000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_r';
wwv_flow_imp.g_varchar2_table(858) := 'est_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created,';
wwv_flow_imp.g_varchar2_table(859) := ' created_by, updated, updated_by) values (12, ''Bug Tracker'', ''Measure effectiveness of improved QA'',';
wwv_flow_imp.g_varchar2_table(860) := ' to_date(''2025-02-16 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-16 14:34:02'',''YYYY-MM-DD H';
wwv_flow_imp.g_varchar2_table(861) := 'H24:MI:SS''), ''Pending'', ''Myra Sutcliff'', 0, 500, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert i';
wwv_flow_imp.g_varchar2_table(862) := 'nto eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, bu';
wwv_flow_imp.g_varchar2_table(863) := 'dget, created, created_by, updated, updated_by) values (13, ''Convert Spreadsheets'', ''Collect mission';
wwv_flow_imp.g_varchar2_table(864) := '-critical spreadsheets'', to_date(''2025-02-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-23';
wwv_flow_imp.g_varchar2_table(865) := ' 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Pam King'', 2500, 4000, sysdate, null, sysdate, null)';
wwv_flow_imp.g_varchar2_table(866) := ';'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status,';
wwv_flow_imp.g_varchar2_table(867) := ' assigned_to, cost, budget, created, created_by, updated, updated_by) values (14, ''Convert Spreadshe';
wwv_flow_imp.g_varchar2_table(868) := 'ets'', ''Lock spreadsheets'', to_date(''2025-02-25 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-';
wwv_flow_imp.g_varchar2_table(869) := '25 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Pam King'', 300, 800, sysdate, null, sysdate, null)';
wwv_flow_imp.g_varchar2_table(870) := ';'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status,';
wwv_flow_imp.g_varchar2_table(871) := ' assigned_to, cost, budget, created, created_by, updated, updated_by) values (15, ''Convert Spreadshe';
wwv_flow_imp.g_varchar2_table(872) := 'ets'', ''Create ACME Web Express applications from spreadsheets'', to_date(''2025-03-05 14:34:02'',''YYYY-';
wwv_flow_imp.g_varchar2_table(873) := 'MM-DD HH24:MI:SS''), to_date(''2025-03-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Pam King'', 6000';
wwv_flow_imp.g_varchar2_table(874) := ', 10000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, ta';
wwv_flow_imp.g_varchar2_table(875) := 'sk_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, upda';
wwv_flow_imp.g_varchar2_table(876) := 'ted_by) values (16, ''Convert Spreadsheets'', ''Send links to previous spreadsheet owners'', to_date(''20';
wwv_flow_imp.g_varchar2_table(877) := '25-03-11 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-11 14:34:02'',''YYYY-MM-DD HH24:MI:SS''),';
wwv_flow_imp.g_varchar2_table(878) := ' ''Pending'', ''Pam King'', 0, 500, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest';
wwv_flow_imp.g_varchar2_table(879) := '_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, cr';
wwv_flow_imp.g_varchar2_table(880) := 'eated_by, updated, updated_by) values (17, ''Discussion Forum'', ''Identify owners'', to_date(''2025-01-2';
wwv_flow_imp.g_varchar2_table(881) := '9 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-01-29 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Close';
wwv_flow_imp.g_varchar2_table(882) := 'd'', ''Hank Davis'', 250, 300, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tas';
wwv_flow_imp.g_varchar2_table(883) := 'ks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, create';
wwv_flow_imp.g_varchar2_table(884) := 'd_by, updated, updated_by) values (18, ''Discussion Forum'', ''Install ACME Web Express application on ';
wwv_flow_imp.g_varchar2_table(885) := 'internet server'', to_date(''2025-02-04 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-04 14:34:';
wwv_flow_imp.g_varchar2_table(886) := '02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Hank Davis'', 100, 100, sysdate, null, sysdate, null);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(887) := '       insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assign';
wwv_flow_imp.g_varchar2_table(888) := 'ed_to, cost, budget, created, created_by, updated, updated_by) values (19, ''Discussion Forum'', ''Moni';
wwv_flow_imp.g_varchar2_table(889) := 'tor participation'', to_date(''2025-03-06 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-07 14:3';
wwv_flow_imp.g_varchar2_table(890) := '4:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Hank Davis'', 450, 500, sysdate, null, sysdate, null);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(891) := '       insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assign';
wwv_flow_imp.g_varchar2_table(892) := 'ed_to, cost, budget, created, created_by, updated, updated_by) values (20, ''Email Integration'', ''Com';
wwv_flow_imp.g_varchar2_table(893) := 'plete plan'', to_date(''2025-02-15 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-16 14:34:02'',''';
wwv_flow_imp.g_varchar2_table(894) := 'YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Bob Nile'', 3000, 1500, sysdate, null, sysdate, null);'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(895) := '  insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to';
wwv_flow_imp.g_varchar2_table(896) := ', cost, budget, created, created_by, updated, updated_by) values (21, ''Email Integration'', ''Check so';
wwv_flow_imp.g_varchar2_table(897) := 'ftware licenses'', to_date(''2025-02-18 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-18 14:34:';
wwv_flow_imp.g_varchar2_table(898) := '02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Bob Nile'', 200, 200, sysdate, null, sysdate, null);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(899) := '     insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned';
wwv_flow_imp.g_varchar2_table(900) := '_to, cost, budget, created, created_by, updated, updated_by) values (22, ''Email Integration'', ''Get R';
wwv_flow_imp.g_varchar2_table(901) := 'FPs for new server'', to_date(''2025-03-04 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-05 14:';
wwv_flow_imp.g_varchar2_table(902) := '34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Bob Nile'', 2000, 1000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(903) := '          insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, ass';
wwv_flow_imp.g_varchar2_table(904) := 'igned_to, cost, budget, created, created_by, updated, updated_by) values (23, ''Email Integration'', ''';
wwv_flow_imp.g_varchar2_table(905) := 'Purchase backup server'', to_date(''2025-03-21 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-23';
wwv_flow_imp.g_varchar2_table(906) := ' 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Bob Nile'', 0, 3000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(907) := '            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, a';
wwv_flow_imp.g_varchar2_table(908) := 'ssigned_to, cost, budget, created, created_by, updated, updated_by) values (24, ''Employee Satisfacti';
wwv_flow_imp.g_varchar2_table(909) := 'on Survey'', ''Complete questionnaire'', to_date(''2025-02-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_dat';
wwv_flow_imp.g_varchar2_table(910) := 'e(''2025-02-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Irene Jones'', 1200, 800, sysdate, null,';
wwv_flow_imp.g_varchar2_table(911) := ' sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, en';
wwv_flow_imp.g_varchar2_table(912) := 'd_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (25, ''Em';
wwv_flow_imp.g_varchar2_table(913) := 'ployee Satisfaction Survey'', ''Review with legal'', to_date(''2025-02-10 14:34:02'',''YYYY-MM-DD HH24:MI:';
wwv_flow_imp.g_varchar2_table(914) := 'SS''), to_date(''2025-02-10 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''On-Hold'', ''Irene Jones'', 200, 400, sy';
wwv_flow_imp.g_varchar2_table(915) := 'sdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, st';
wwv_flow_imp.g_varchar2_table(916) := 'art_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) val';
wwv_flow_imp.g_varchar2_table(917) := 'ues (26, ''Employee Satisfaction Survey'', ''Plan rollout schedule'', to_date(''2025-02-11 14:34:02'',''YYY';
wwv_flow_imp.g_varchar2_table(918) := 'Y-MM-DD HH24:MI:SS''), to_date(''2025-02-11 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''On-Hold'', ''Irene Jone';
wwv_flow_imp.g_varchar2_table(919) := 's'', 0, 750, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project,';
wwv_flow_imp.g_varchar2_table(920) := ' task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, u';
wwv_flow_imp.g_varchar2_table(921) := 'pdated_by) values (27, ''Client Server Conversion'', ''Identify pilot Client Server applications'', to_d';
wwv_flow_imp.g_varchar2_table(922) := 'ate(''2025-02-20 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-20 14:34:02'',''YYYY-MM-DD HH24:M';
wwv_flow_imp.g_varchar2_table(923) := 'I:SS''), ''Closed'', ''Scott Spencer'', 200, 200, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into ';
wwv_flow_imp.g_varchar2_table(924) := 'eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget';
wwv_flow_imp.g_varchar2_table(925) := ', created, created_by, updated, updated_by) values (28, ''Client Server Conversion'', ''Migrate pilot C';
wwv_flow_imp.g_varchar2_table(926) := 'lient Server to ACME Web Express'', to_date(''2025-02-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''';
wwv_flow_imp.g_varchar2_table(927) := '2025-02-25 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Scott Spencer'', 4500, 5000, sysdate, null,';
wwv_flow_imp.g_varchar2_table(928) := ' sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, en';
wwv_flow_imp.g_varchar2_table(929) := 'd_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (29, ''Cl';
wwv_flow_imp.g_varchar2_table(930) := 'ient Server Conversion'', ''Post-migration review'', to_date(''2025-02-26 14:34:02'',''YYYY-MM-DD HH24:MI:';
wwv_flow_imp.g_varchar2_table(931) := 'SS''), to_date(''2025-02-26 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Pam King'', 500, 300, sysdat';
wwv_flow_imp.g_varchar2_table(932) := 'e, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_';
wwv_flow_imp.g_varchar2_table(933) := 'date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values ';
wwv_flow_imp.g_varchar2_table(934) := '(30, ''Client Server Conversion'', ''Plan migration schedule'', to_date(''2025-03-01 14:34:02'',''YYYY-MM-D';
wwv_flow_imp.g_varchar2_table(935) := 'D HH24:MI:SS''), to_date(''2025-03-01 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Pam King'', 1000, ';
wwv_flow_imp.g_varchar2_table(936) := '1000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_';
wwv_flow_imp.g_varchar2_table(937) := 'name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated';
wwv_flow_imp.g_varchar2_table(938) := '_by) values (31, ''Client Server Conversion'', ''Migrate Client Server applications'', to_date(''2025-03-';
wwv_flow_imp.g_varchar2_table(939) := '06 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open';
wwv_flow_imp.g_varchar2_table(940) := ''', ''Pam King'', 300, 12000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_task';
wwv_flow_imp.g_varchar2_table(941) := 's (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created';
wwv_flow_imp.g_varchar2_table(942) := '_by, updated, updated_by) values (32, ''Client Server Conversion'', ''Test migrated applications'', to_d';
wwv_flow_imp.g_varchar2_table(943) := 'ate(''2025-03-11 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-12 14:34:02'',''YYYY-MM-DD HH24:M';
wwv_flow_imp.g_varchar2_table(944) := 'I:SS''), ''Pending'', ''Russ Saunders'', 0, 6000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into ';
wwv_flow_imp.g_varchar2_table(945) := 'eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget';
wwv_flow_imp.g_varchar2_table(946) := ', created, created_by, updated, updated_by) values (33, ''Client Server Conversion'', ''User acceptance';
wwv_flow_imp.g_varchar2_table(947) := ' testing'', to_date(''2025-03-15 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-17 14:34:02'',''YY';
wwv_flow_imp.g_varchar2_table(948) := 'YY-MM-DD HH24:MI:SS''), ''Pending'', ''Russ Saunders'', 0, 2500, sysdate, null, sysdate, null);'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(949) := '   insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_t';
wwv_flow_imp.g_varchar2_table(950) := 'o, cost, budget, created, created_by, updated, updated_by) values (34, ''Client Server Conversion'', ''';
wwv_flow_imp.g_varchar2_table(951) := 'End-user Training'', to_date(''2025-03-21 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-21 14:3';
wwv_flow_imp.g_varchar2_table(952) := '4:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Myra Sutcliff'', 0, 2500, sysdate, null, sysdate, null);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(953) := '            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, a';
wwv_flow_imp.g_varchar2_table(954) := 'ssigned_to, cost, budget, created, created_by, updated, updated_by) values (35, ''Client Server Conve';
wwv_flow_imp.g_varchar2_table(955) := 'rsion'', ''Rollout migrated Client Server in ACME Web Express'', to_date(''2025-03-22 14:34:02'',''YYYY-MM';
wwv_flow_imp.g_varchar2_table(956) := '-DD HH24:MI:SS''), to_date(''2025-03-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Pam King'', 0, ';
wwv_flow_imp.g_varchar2_table(957) := '200, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_n';
wwv_flow_imp.g_varchar2_table(958) := 'ame, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_';
wwv_flow_imp.g_varchar2_table(959) := 'by) values (36, ''Load Packaged Apps'', ''Identify point solutions required'', to_date(''2025-02-22 14:34';
wwv_flow_imp.g_varchar2_table(960) := ':02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Jo';
wwv_flow_imp.g_varchar2_table(961) := 'hn Watson'', 200, 300, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id';
wwv_flow_imp.g_varchar2_table(962) := ', project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, ';
wwv_flow_imp.g_varchar2_table(963) := 'updated, updated_by) values (37, ''Load Packaged Apps'', ''Install in development'', to_date(''2025-02-23';
wwv_flow_imp.g_varchar2_table(964) := ' 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-23 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed';
wwv_flow_imp.g_varchar2_table(965) := ''', ''John Watson'', 100, 100, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tas';
wwv_flow_imp.g_varchar2_table(966) := 'ks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, create';
wwv_flow_imp.g_varchar2_table(967) := 'd_by, updated, updated_by) values (38, ''Load Packaged Apps'', ''Customize solutions'', to_date(''2025-02';
wwv_flow_imp.g_varchar2_table(968) := '-26 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-28 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Ope';
wwv_flow_imp.g_varchar2_table(969) := 'n'', ''John Watson'', 1500, 4000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_';
wwv_flow_imp.g_varchar2_table(970) := 'tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, cre';
wwv_flow_imp.g_varchar2_table(971) := 'ated_by, updated, updated_by) values (39, ''Load Packaged Apps'', ''Implement in Production'', to_date(''';
wwv_flow_imp.g_varchar2_table(972) := '2025-03-01 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-01 14:34:02'',''YYYY-MM-DD HH24:MI:SS''';
wwv_flow_imp.g_varchar2_table(973) := '), ''On-Hold'', ''John Watson'', 200, 1500, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_d';
wwv_flow_imp.g_varchar2_table(974) := 'emo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, cre';
wwv_flow_imp.g_varchar2_table(975) := 'ated, created_by, updated, updated_by) values (40, ''Load Packaged Apps'', ''Train Administrators of Pa';
wwv_flow_imp.g_varchar2_table(976) := 'ckaged Apps'', to_date(''2025-03-03 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-03 14:34:02'',';
wwv_flow_imp.g_varchar2_table(977) := '''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''John Watson'', 0, 1000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(978) := '    insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_';
wwv_flow_imp.g_varchar2_table(979) := 'to, cost, budget, created, created_by, updated, updated_by) values (41, ''Maintain Support Systems'', ';
wwv_flow_imp.g_varchar2_table(980) := '''HR software upgrades'', to_date(''2025-02-01 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-04 ';
wwv_flow_imp.g_varchar2_table(981) := '14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Pam King'', 8000, 7000, sysdate, null, sysdate, null);';
wwv_flow_imp.g_varchar2_table(982) := ''||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, ';
wwv_flow_imp.g_varchar2_table(983) := 'assigned_to, cost, budget, created, created_by, updated, updated_by) values (42, ''Maintain Support S';
wwv_flow_imp.g_varchar2_table(984) := 'ystems'', ''Apply Billing System updates'', to_date(''2025-02-05 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_';
wwv_flow_imp.g_varchar2_table(985) := 'date(''2025-02-07 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Russ Saunders'', 9500, 7000, sysdate,';
wwv_flow_imp.g_varchar2_table(986) := ' null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_da';
wwv_flow_imp.g_varchar2_table(987) := 'te, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (4';
wwv_flow_imp.g_varchar2_table(988) := '3, ''Maintain Support Systems'', ''Arrange for vacation coverage'', to_date(''2025-02-09 14:34:02'',''YYYY-';
wwv_flow_imp.g_varchar2_table(989) := 'MM-DD HH24:MI:SS''), to_date(''2025-02-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Al Bines'', 300,';
wwv_flow_imp.g_varchar2_table(990) := ' 500, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_';
wwv_flow_imp.g_varchar2_table(991) := 'name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated';
wwv_flow_imp.g_varchar2_table(992) := '_by) values (44, ''Maintain Support Systems'', ''Investigate new Virus Protection software'', to_date(''2';
wwv_flow_imp.g_varchar2_table(993) := '025-03-21 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS'')';
wwv_flow_imp.g_varchar2_table(994) := ', ''Open'', ''Pam King'', 1700, 1500, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_re';
wwv_flow_imp.g_varchar2_table(995) := 'st_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, ';
wwv_flow_imp.g_varchar2_table(996) := 'created_by, updated, updated_by) values (45, ''Migrate Desktop Application'', ''Identify pilot desktop ';
wwv_flow_imp.g_varchar2_table(997) := 'applications'', to_date(''2025-02-13 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-13 14:34:02''';
wwv_flow_imp.g_varchar2_table(998) := ',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Bob Nile'', 300, 500, sysdate, null, sysdate, null);'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(999) := '  insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to';
wwv_flow_imp.g_varchar2_table(1000) := ', cost, budget, created, created_by, updated, updated_by) values (46, ''Migrate Desktop Application'',';
wwv_flow_imp.g_varchar2_table(1001) := ' ''Migrate pilot applications to ACME Web Express'', to_date(''2025-02-15 14:34:02'',''YYYY-MM-DD HH24:MI';
wwv_flow_imp.g_varchar2_table(1002) := ':SS''), to_date(''2025-02-16 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Bob Nile'', 1250, 1500, sys';
wwv_flow_imp.g_varchar2_table(1003) := 'date, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, sta';
wwv_flow_imp.g_varchar2_table(1004) := 'rt_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) valu';
wwv_flow_imp.g_varchar2_table(1005) := 'es (47, ''Migrate Desktop Application'', ''Plan migration schedule'', to_date(''2025-02-19 14:34:02'',''YYY';
wwv_flow_imp.g_varchar2_table(1006) := 'Y-MM-DD HH24:MI:SS''), to_date(''2025-02-19 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Bob Nile'', ';
wwv_flow_imp.g_varchar2_table(1007) := '600, 200, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, t';
wwv_flow_imp.g_varchar2_table(1008) := 'ask_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, upd';
wwv_flow_imp.g_varchar2_table(1009) := 'ated_by) values (48, ''Migrate Desktop Application'', ''Migrate desktop applications'', to_date(''2025-03';
wwv_flow_imp.g_varchar2_table(1010) := '-14 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-18 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Ope';
wwv_flow_imp.g_varchar2_table(1011) := 'n'', ''Bob Nile'', 1000, 8000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tas';
wwv_flow_imp.g_varchar2_table(1012) := 'ks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, create';
wwv_flow_imp.g_varchar2_table(1013) := 'd_by, updated, updated_by) values (49, ''Migrate Desktop Application'', ''User acceptance testing'', to_';
wwv_flow_imp.g_varchar2_table(1014) := 'date(''2025-03-20 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-21 14:34:02'',''YYYY-MM-DD HH24:';
wwv_flow_imp.g_varchar2_table(1015) := 'MI:SS''), ''Open'', ''Bob Nile'', 1500, 6000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_';
wwv_flow_imp.g_varchar2_table(1016) := 'demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, cr';
wwv_flow_imp.g_varchar2_table(1017) := 'eated, created_by, updated, updated_by) values (50, ''Migrate Desktop Application'', ''End-user Trainin';
wwv_flow_imp.g_varchar2_table(1018) := 'g'', to_date(''2025-03-24 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-25 14:34:02'',''YYYY-MM-D';
wwv_flow_imp.g_varchar2_table(1019) := 'D HH24:MI:SS''), ''Open'', ''John Watson'', 0, 2000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert in';
wwv_flow_imp.g_varchar2_table(1020) := 'to eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, bud';
wwv_flow_imp.g_varchar2_table(1021) := 'get, created, created_by, updated, updated_by) values (51, ''Migrate Desktop Application'', ''Post-migr';
wwv_flow_imp.g_varchar2_table(1022) := 'ation review'', to_date(''2025-04-07 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-04-08 14:34:02''';
wwv_flow_imp.g_varchar2_table(1023) := ',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Bob Nile'', 100, 100, sysdate, null, sysdate, null);'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(1024) := '   insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_t';
wwv_flow_imp.g_varchar2_table(1025) := 'o, cost, budget, created, created_by, updated, updated_by) values (52, ''Migrate from Legacy Server'',';
wwv_flow_imp.g_varchar2_table(1026) := ' ''Obtain Legacy Server credentials'', to_date(''2025-03-26 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date';
wwv_flow_imp.g_varchar2_table(1027) := '(''2025-03-26 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''James Cassidy'', 0, 500, sysdate, null, ';
wwv_flow_imp.g_varchar2_table(1028) := 'sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end';
wwv_flow_imp.g_varchar2_table(1029) := '_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (53, ''Mig';
wwv_flow_imp.g_varchar2_table(1030) := 'rate from Legacy Server'', ''Map data usage'', to_date(''2025-03-28 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ';
wwv_flow_imp.g_varchar2_table(1031) := 'to_date(''2025-03-30 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Bob Nile'', 0, 8000, sysdate, nul';
wwv_flow_imp.g_varchar2_table(1032) := 'l, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, ';
wwv_flow_imp.g_varchar2_table(1033) := 'end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (54, ''';
wwv_flow_imp.g_varchar2_table(1034) := 'Migrate from Legacy Server'', ''Identify integration points'', to_date(''2025-03-31 14:34:02'',''YYYY-MM-D';
wwv_flow_imp.g_varchar2_table(1035) := 'D HH24:MI:SS''), to_date(''2025-04-01 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Bob Nile'', 0, 20';
wwv_flow_imp.g_varchar2_table(1036) := '00, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_na';
wwv_flow_imp.g_varchar2_table(1037) := 'me, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_b';
wwv_flow_imp.g_varchar2_table(1038) := 'y) values (55, ''Migrate from Legacy Server'', ''Create DB Connection to new server'', to_date(''2025-03-';
wwv_flow_imp.g_varchar2_table(1039) := '31 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-31 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pend';
wwv_flow_imp.g_varchar2_table(1040) := 'ing'', ''Scott Spencer'', 0, 100, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_';
wwv_flow_imp.g_varchar2_table(1041) := 'tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, cre';
wwv_flow_imp.g_varchar2_table(1042) := 'ated_by, updated, updated_by) values (56, ''Migrate from Legacy Server'', ''Migrate table structures'', ';
wwv_flow_imp.g_varchar2_table(1043) := 'to_date(''2025-03-25 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-26 14:34:02'',''YYYY-MM-DD HH';
wwv_flow_imp.g_varchar2_table(1044) := '24:MI:SS''), ''Pending'', ''John Watson'', 0, 2500, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert int';
wwv_flow_imp.g_varchar2_table(1045) := 'o eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, budg';
wwv_flow_imp.g_varchar2_table(1046) := 'et, created, created_by, updated, updated_by) values (57, ''Migrate from Legacy Server'', ''Import data';
wwv_flow_imp.g_varchar2_table(1047) := ''', to_date(''2025-04-06 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-04-07 14:34:02'',''YYYY-MM-DD';
wwv_flow_imp.g_varchar2_table(1048) := ' HH24:MI:SS''), ''Pending'', ''John Watson'', 0, 1000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert ';
wwv_flow_imp.g_varchar2_table(1049) := 'into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, b';
wwv_flow_imp.g_varchar2_table(1050) := 'udget, created, created_by, updated, updated_by) values (58, ''Migrate from Legacy Server'', ''Convert ';
wwv_flow_imp.g_varchar2_table(1051) := 'processes'', to_date(''2025-04-06 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-04-08 14:34:02'',''Y';
wwv_flow_imp.g_varchar2_table(1052) := 'YYY-MM-DD HH24:MI:SS''), ''Pending'', ''Pam King'', 0, 3000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            i';
wwv_flow_imp.g_varchar2_table(1053) := 'nsert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, c';
wwv_flow_imp.g_varchar2_table(1054) := 'ost, budget, created, created_by, updated, updated_by) values (59, ''Migrate from Legacy Server'', ''No';
wwv_flow_imp.g_varchar2_table(1055) := 'tify users'', to_date(''2025-04-11 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-04-11 14:34:02'',''';
wwv_flow_imp.g_varchar2_table(1056) := 'YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Bob Nile'', 0, 200, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            i';
wwv_flow_imp.g_varchar2_table(1057) := 'nsert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, c';
wwv_flow_imp.g_varchar2_table(1058) := 'ost, budget, created, created_by, updated, updated_by) values (60, ''Migrate from Legacy Server'', ''Cu';
wwv_flow_imp.g_varchar2_table(1059) := 't over to new database'', to_date(''2025-04-12 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-04-12';
wwv_flow_imp.g_varchar2_table(1060) := ' 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Bob Nile'', 0, 1500, sysdate, null, sysdate, null);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1061) := '            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, a';
wwv_flow_imp.g_varchar2_table(1062) := 'ssigned_to, cost, budget, created, created_by, updated, updated_by) values (61, ''Migrate from Legacy';
wwv_flow_imp.g_varchar2_table(1063) := ' Server'', ''Decommission Legacy Server'', to_date(''2025-04-26 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_d';
wwv_flow_imp.g_varchar2_table(1064) := 'ate(''2025-04-26 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Pending'', ''Al Bines'', 0, 500, sysdate, null, sy';
wwv_flow_imp.g_varchar2_table(1065) := 'sdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_d';
wwv_flow_imp.g_varchar2_table(1066) := 'ate, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (62, ''Publi';
wwv_flow_imp.g_varchar2_table(1067) := 'c Website'', ''Determine host server'', to_date(''2025-02-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date';
wwv_flow_imp.g_varchar2_table(1068) := '(''2025-02-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Tiger Scott'', 200, 200, sysdate, null, s';
wwv_flow_imp.g_varchar2_table(1069) := 'ysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_';
wwv_flow_imp.g_varchar2_table(1070) := 'date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (63, ''Publ';
wwv_flow_imp.g_varchar2_table(1071) := 'ic Website'', ''Check software licenses'', to_date(''2025-02-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_d';
wwv_flow_imp.g_varchar2_table(1072) := 'ate(''2025-02-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Tom Suess'', 100, 100, sysdate, null, ';
wwv_flow_imp.g_varchar2_table(1073) := 'sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end';
wwv_flow_imp.g_varchar2_table(1074) := '_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (64, ''Pub';
wwv_flow_imp.g_varchar2_table(1075) := 'lic Website'', ''Purchase additional software licenses, if needed'', to_date(''2025-02-09 14:34:02'',''YYY';
wwv_flow_imp.g_varchar2_table(1076) := 'Y-MM-DD HH24:MI:SS''), to_date(''2025-02-10 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''On-Hold'', ''Al Bines'',';
wwv_flow_imp.g_varchar2_table(1077) := ' 300, 1000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project,';
wwv_flow_imp.g_varchar2_table(1078) := ' task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, u';
wwv_flow_imp.g_varchar2_table(1079) := 'pdated_by) values (65, ''Public Website'', ''Develop web pages'', sysdate, to_date(''2025-03-08 14:34:02''';
wwv_flow_imp.g_varchar2_table(1080) := ',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Tiger Scott'', 0, 2000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(1081) := '  insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to';
wwv_flow_imp.g_varchar2_table(1082) := ', cost, budget, created, created_by, updated, updated_by) values (66, ''Public Website'', ''Plan rollou';
wwv_flow_imp.g_varchar2_table(1083) := 't schedule'', to_date(''2025-03-09 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-03-09 14:34:02'',''';
wwv_flow_imp.g_varchar2_table(1084) := 'YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Tom Suess'', 0, 100, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            ins';
wwv_flow_imp.g_varchar2_table(1085) := 'ert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cos';
wwv_flow_imp.g_varchar2_table(1086) := 't, budget, created, created_by, updated, updated_by) values (67, ''Software Project Tracking'', ''Condu';
wwv_flow_imp.g_varchar2_table(1087) := 'ct project kickoff meeting'', to_date(''2025-03-03 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-0';
wwv_flow_imp.g_varchar2_table(1088) := '3-03 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''Pam King'', 100, 100, sysdate, null, sysdate, nul';
wwv_flow_imp.g_varchar2_table(1089) := 'l);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, statu';
wwv_flow_imp.g_varchar2_table(1090) := 's, assigned_to, cost, budget, created, created_by, updated, updated_by) values (68, ''Software Projec';
wwv_flow_imp.g_varchar2_table(1091) := 't Tracking'', ''Customize Software Projects software'', to_date(''2025-03-06 14:34:02'',''YYYY-MM-DD HH24:';
wwv_flow_imp.g_varchar2_table(1092) := 'MI:SS''), sysdate, ''Open'', ''Tom Suess'', 600, 1000, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert ';
wwv_flow_imp.g_varchar2_table(1093) := 'into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, cost, b';
wwv_flow_imp.g_varchar2_table(1094) := 'udget, created, created_by, updated, updated_by) values (69, ''Software Project Tracking'', ''Enter bas';
wwv_flow_imp.g_varchar2_table(1095) := 'e data (Projects, Milestones, etc.)'', to_date(''2025-03-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_dat';
wwv_flow_imp.g_varchar2_table(1096) := 'e(''2025-03-08 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Tom Suess'', 200, 200, sysdate, null, sysd';
wwv_flow_imp.g_varchar2_table(1097) := 'ate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_name, start_date, end_dat';
wwv_flow_imp.g_varchar2_table(1098) := 'e, status, assigned_to, cost, budget, created, created_by, updated, updated_by) values (70, ''Softwar';
wwv_flow_imp.g_varchar2_table(1099) := 'e Project Tracking'', ''Load current tasks and enhancements'', to_date(''2025-03-10 14:34:02'',''YYYY-MM-D';
wwv_flow_imp.g_varchar2_table(1100) := 'D HH24:MI:SS''), to_date(''2025-03-10 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Open'', ''Tom Suess'', 400, 50';
wwv_flow_imp.g_varchar2_table(1101) := '0, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks (id, project, task_nam';
wwv_flow_imp.g_varchar2_table(1102) := 'e, start_date, end_date, status, assigned_to, cost, budget, created, created_by, updated, updated_by';
wwv_flow_imp.g_varchar2_table(1103) := ') values (71, ''Training for ACME Web Express'', ''Create training workspace'', to_date(''2025-02-20 14:3';
wwv_flow_imp.g_varchar2_table(1104) := '4:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-21 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''Closed'', ''J';
wwv_flow_imp.g_varchar2_table(1105) := 'ames Cassidy'', 500, 700, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            insert into eba_demo_rest_tasks ';
wwv_flow_imp.g_varchar2_table(1106) := '(id, project, task_name, start_date, end_date, status, assigned_to, cost, budget, created, created_b';
wwv_flow_imp.g_varchar2_table(1107) := 'y, updated, updated_by) values (72, ''Training for ACME Web Express'', ''Publish links to self-study co';
wwv_flow_imp.g_varchar2_table(1108) := 'urses'', to_date(''2025-02-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''2025-02-22 14:34:02'',''YYYY-';
wwv_flow_imp.g_varchar2_table(1109) := 'MM-DD HH24:MI:SS''), ''Closed'', ''John Watson'', 100, 100, sysdate, null, sysdate, null);'||wwv_flow.LF||
'            in';
wwv_flow_imp.g_varchar2_table(1110) := 'sert into eba_demo_rest_tasks (id, project, task_name, start_date, end_date, status, assigned_to, co';
wwv_flow_imp.g_varchar2_table(1111) := 'st, budget, created, created_by, updated, updated_by) values (73, ''Training for ACME Web Express'', ''';
wwv_flow_imp.g_varchar2_table(1112) := 'Publish development standards'', to_date(''2025-02-22 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), to_date(''202';
wwv_flow_imp.g_varchar2_table(1113) := '5-02-23 14:34:02'',''YYYY-MM-DD HH24:MI:SS''), ''On-Hold'', ''John Watson'', 1000, 2000, sysdate, null, sys';
wwv_flow_imp.g_varchar2_table(1114) := 'date, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- update tasks to current time '||wwv_flow.LF||
'            update eba_demo_rest_tasks'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(1115) := '         set start_date = start_date + (SYSDATE - TO_DATE(''05052025'',''MMDDYYYY'')),'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(1116) := '  end_date = end_date + (SYSDATE - TO_DATE(''05052025'',''MMDDYYYY''));'||wwv_flow.LF||
'      '||wwv_flow.LF||
'        -- Order items da';
wwv_flow_imp.g_varchar2_table(1117) := 'ta'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price,';
wwv_flow_imp.g_varchar2_table(1118) := ' quantity) values (349,1,11,30.69,5);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, li';
wwv_flow_imp.g_varchar2_table(1119) := 'ne_item_id, product_id, unit_price, quantity) values (349,2,12,10.48,4);'||wwv_flow.LF||
'            insert into eba';
wwv_flow_imp.g_varchar2_table(1120) := '_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (401,1,28,10';
wwv_flow_imp.g_varchar2_table(1121) := '.24,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_p';
wwv_flow_imp.g_varchar2_table(1122) := 'rice, quantity) values (401,2,12,10.48,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_i';
wwv_flow_imp.g_varchar2_table(1123) := 'd, line_item_id, product_id, unit_price, quantity) values (430,1,18,24.46,2);'||wwv_flow.LF||
'            insert int';
wwv_flow_imp.g_varchar2_table(1124) := 'o eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (430,2,';
wwv_flow_imp.g_varchar2_table(1125) := '15,13.97,5);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, u';
wwv_flow_imp.g_varchar2_table(1126) := 'nit_price, quantity) values (437,1,37,29.51,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (or';
wwv_flow_imp.g_varchar2_table(1127) := 'der_id, line_item_id, product_id, unit_price, quantity) values (437,2,20,28.21,5);'||wwv_flow.LF||
'            inser';
wwv_flow_imp.g_varchar2_table(1128) := 't into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (4';
wwv_flow_imp.g_varchar2_table(1129) := '53,1,43,16.64,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_';
wwv_flow_imp.g_varchar2_table(1130) := 'id, unit_price, quantity) values (453,2,2,29.55,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems';
wwv_flow_imp.g_varchar2_table(1131) := ' (order_id, line_item_id, product_id, unit_price, quantity) values (506,1,18,24.46,4);'||wwv_flow.LF||
'            i';
wwv_flow_imp.g_varchar2_table(1132) := 'nsert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) value';
wwv_flow_imp.g_varchar2_table(1133) := 's (506,2,21,38.34,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, prod';
wwv_flow_imp.g_varchar2_table(1134) := 'uct_id, unit_price, quantity) values (513,1,11,30.69,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_order';
wwv_flow_imp.g_varchar2_table(1135) := 'items (order_id, line_item_id, product_id, unit_price, quantity) values (513,2,4,44.17,2);'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(1136) := '   insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) v';
wwv_flow_imp.g_varchar2_table(1137) := 'alues (513,3,19,14.34,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, ';
wwv_flow_imp.g_varchar2_table(1138) := 'product_id, unit_price, quantity) values (544,1,37,29.51,5);'||wwv_flow.LF||
'            insert into eba_demo_rest_o';
wwv_flow_imp.g_varchar2_table(1139) := 'rderitems (order_id, line_item_id, product_id, unit_price, quantity) values (544,2,6,38.28,2);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(1140) := '       insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantit';
wwv_flow_imp.g_varchar2_table(1141) := 'y) values (544,3,27,39.91,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_';
wwv_flow_imp.g_varchar2_table(1142) := 'id, product_id, unit_price, quantity) values (585,1,29,24.71,3);'||wwv_flow.LF||
'            insert into eba_demo_re';
wwv_flow_imp.g_varchar2_table(1143) := 'st_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (585,2,31,28.59,2);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1144) := '            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, qu';
wwv_flow_imp.g_varchar2_table(1145) := 'antity) values (585,3,37,29.51,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_';
wwv_flow_imp.g_varchar2_table(1146) := 'item_id, product_id, unit_price, quantity) values (608,1,15,13.97,5);'||wwv_flow.LF||
'            insert into eba_de';
wwv_flow_imp.g_varchar2_table(1147) := 'mo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (608,2,23,10.33';
wwv_flow_imp.g_varchar2_table(1148) := ',5);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_pric';
wwv_flow_imp.g_varchar2_table(1149) := 'e, quantity) values (608,3,35,7.18,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, l';
wwv_flow_imp.g_varchar2_table(1150) := 'ine_item_id, product_id, unit_price, quantity) values (672,1,46,39.16,4);'||wwv_flow.LF||
'            insert into eb';
wwv_flow_imp.g_varchar2_table(1151) := 'a_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (687,1,42,1';
wwv_flow_imp.g_varchar2_table(1152) := '0.11,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_';
wwv_flow_imp.g_varchar2_table(1153) := 'price, quantity) values (687,2,13,12.64,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_';
wwv_flow_imp.g_varchar2_table(1154) := 'id, line_item_id, product_id, unit_price, quantity) values (707,1,18,24.46,3);'||wwv_flow.LF||
'            insert in';
wwv_flow_imp.g_varchar2_table(1155) := 'to eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (760,1';
wwv_flow_imp.g_varchar2_table(1156) := ',46,39.16,5);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, ';
wwv_flow_imp.g_varchar2_table(1157) := 'unit_price, quantity) values (760,2,20,28.21,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (o';
wwv_flow_imp.g_varchar2_table(1158) := 'rder_id, line_item_id, product_id, unit_price, quantity) values (761,1,33,37,3);'||wwv_flow.LF||
'            insert ';
wwv_flow_imp.g_varchar2_table(1159) := 'into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (761';
wwv_flow_imp.g_varchar2_table(1160) := ',2,2,29.55,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id,';
wwv_flow_imp.g_varchar2_table(1161) := ' unit_price, quantity) values (765,1,34,23.32,5);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (';
wwv_flow_imp.g_varchar2_table(1162) := 'order_id, line_item_id, product_id, unit_price, quantity) values (765,2,13,12.64,5);'||wwv_flow.LF||
'            ins';
wwv_flow_imp.g_varchar2_table(1163) := 'ert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values ';
wwv_flow_imp.g_varchar2_table(1164) := '(766,1,12,10.48,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, produc';
wwv_flow_imp.g_varchar2_table(1165) := 't_id, unit_price, quantity) values (769,1,42,10.11,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderit';
wwv_flow_imp.g_varchar2_table(1166) := 'ems (order_id, line_item_id, product_id, unit_price, quantity) values (808,1,39,11,3);'||wwv_flow.LF||
'            i';
wwv_flow_imp.g_varchar2_table(1167) := 'nsert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) value';
wwv_flow_imp.g_varchar2_table(1168) := 's (808,2,13,12.64,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, prod';
wwv_flow_imp.g_varchar2_table(1169) := 'uct_id, unit_price, quantity) values (1,1,33,37,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems';
wwv_flow_imp.g_varchar2_table(1170) := ' (order_id, line_item_id, product_id, unit_price, quantity) values (1,2,11,30.69,2);'||wwv_flow.LF||
'            ins';
wwv_flow_imp.g_varchar2_table(1171) := 'ert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values ';
wwv_flow_imp.g_varchar2_table(1172) := '(3,1,41,8.66,5);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_i';
wwv_flow_imp.g_varchar2_table(1173) := 'd, unit_price, quantity) values (5,1,40,34.06,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (';
wwv_flow_imp.g_varchar2_table(1174) := 'order_id, line_item_id, product_id, unit_price, quantity) values (5,2,32,5.65,3);'||wwv_flow.LF||
'            insert';
wwv_flow_imp.g_varchar2_table(1175) := ' into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (7,';
wwv_flow_imp.g_varchar2_table(1176) := '1,36,49.12,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id,';
wwv_flow_imp.g_varchar2_table(1177) := ' unit_price, quantity) values (7,2,29,24.71,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (or';
wwv_flow_imp.g_varchar2_table(1178) := 'der_id, line_item_id, product_id, unit_price, quantity) values (17,1,46,39.16,4);'||wwv_flow.LF||
'            insert';
wwv_flow_imp.g_varchar2_table(1179) := ' into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (17';
wwv_flow_imp.g_varchar2_table(1180) := ',2,26,48.75,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id';
wwv_flow_imp.g_varchar2_table(1181) := ', unit_price, quantity) values (20,1,27,39.91,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (';
wwv_flow_imp.g_varchar2_table(1182) := 'order_id, line_item_id, product_id, unit_price, quantity) values (20,2,9,21.16,2);'||wwv_flow.LF||
'            inser';
wwv_flow_imp.g_varchar2_table(1183) := 't into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (2';
wwv_flow_imp.g_varchar2_table(1184) := '0,3,32,5.65,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id';
wwv_flow_imp.g_varchar2_table(1185) := ', unit_price, quantity) values (63,1,7,19.16,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (o';
wwv_flow_imp.g_varchar2_table(1186) := 'rder_id, line_item_id, product_id, unit_price, quantity) values (63,2,24,48.39,2);'||wwv_flow.LF||
'            inser';
wwv_flow_imp.g_varchar2_table(1187) := 't into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (7';
wwv_flow_imp.g_varchar2_table(1188) := '8,1,3,16.67,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id';
wwv_flow_imp.g_varchar2_table(1189) := ', unit_price, quantity) values (78,2,35,7.18,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (o';
wwv_flow_imp.g_varchar2_table(1190) := 'rder_id, line_item_id, product_id, unit_price, quantity) values (78,3,9,21.16,5);'||wwv_flow.LF||
'            insert';
wwv_flow_imp.g_varchar2_table(1191) := ' into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (79';
wwv_flow_imp.g_varchar2_table(1192) := ',1,34,23.32,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id';
wwv_flow_imp.g_varchar2_table(1193) := ', unit_price, quantity) values (79,2,8,19.58,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (o';
wwv_flow_imp.g_varchar2_table(1194) := 'rder_id, line_item_id, product_id, unit_price, quantity) values (79,3,4,44.17,3);'||wwv_flow.LF||
'            insert';
wwv_flow_imp.g_varchar2_table(1195) := ' into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (82';
wwv_flow_imp.g_varchar2_table(1196) := ',1,21,38.34,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id';
wwv_flow_imp.g_varchar2_table(1197) := ', unit_price, quantity) values (82,2,10,29.49,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (';
wwv_flow_imp.g_varchar2_table(1198) := 'order_id, line_item_id, product_id, unit_price, quantity) values (92,1,15,13.97,1);'||wwv_flow.LF||
'            inse';
wwv_flow_imp.g_varchar2_table(1199) := 'rt into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (';
wwv_flow_imp.g_varchar2_table(1200) := '125,1,22,39.78,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product';
wwv_flow_imp.g_varchar2_table(1201) := '_id, unit_price, quantity) values (125,2,39,11,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems ';
wwv_flow_imp.g_varchar2_table(1202) := '(order_id, line_item_id, product_id, unit_price, quantity) values (132,1,11,30.69,4);'||wwv_flow.LF||
'            in';
wwv_flow_imp.g_varchar2_table(1203) := 'sert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values';
wwv_flow_imp.g_varchar2_table(1204) := ' (132,2,31,28.59,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, produ';
wwv_flow_imp.g_varchar2_table(1205) := 'ct_id, unit_price, quantity) values (132,3,10,29.49,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderi';
wwv_flow_imp.g_varchar2_table(1206) := 'tems (order_id, line_item_id, product_id, unit_price, quantity) values (159,1,8,19.58,2);'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(1207) := '  insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) va';
wwv_flow_imp.g_varchar2_table(1208) := 'lues (182,1,23,10.33,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, p';
wwv_flow_imp.g_varchar2_table(1209) := 'roduct_id, unit_price, quantity) values (182,2,20,28.21,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_or';
wwv_flow_imp.g_varchar2_table(1210) := 'deritems (order_id, line_item_id, product_id, unit_price, quantity) values (196,1,3,16.67,3);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(1211) := '      insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity';
wwv_flow_imp.g_varchar2_table(1212) := ') values (196,2,23,10.33,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_i';
wwv_flow_imp.g_varchar2_table(1213) := 'd, product_id, unit_price, quantity) values (201,1,19,14.34,4);'||wwv_flow.LF||
'            insert into eba_demo_res';
wwv_flow_imp.g_varchar2_table(1214) := 't_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (201,2,36,49.12,2);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1215) := '           insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, qua';
wwv_flow_imp.g_varchar2_table(1216) := 'ntity) values (204,1,33,37,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item';
wwv_flow_imp.g_varchar2_table(1217) := '_id, product_id, unit_price, quantity) values (204,2,12,10.48,2);'||wwv_flow.LF||
'            insert into eba_demo_r';
wwv_flow_imp.g_varchar2_table(1218) := 'est_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (240,1,12,10.48,2);';
wwv_flow_imp.g_varchar2_table(1219) := ''||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, q';
wwv_flow_imp.g_varchar2_table(1220) := 'uantity) values (240,2,17,39.89,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line';
wwv_flow_imp.g_varchar2_table(1221) := '_item_id, product_id, unit_price, quantity) values (290,1,11,30.69,4);'||wwv_flow.LF||
'            insert into eba_d';
wwv_flow_imp.g_varchar2_table(1222) := 'emo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (290,2,27,39.9';
wwv_flow_imp.g_varchar2_table(1223) := '1,5);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_pri';
wwv_flow_imp.g_varchar2_table(1224) := 'ce, quantity) values (290,3,38,22.98,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id,';
wwv_flow_imp.g_varchar2_table(1225) := ' line_item_id, product_id, unit_price, quantity) values (298,1,9,21.16,4);'||wwv_flow.LF||
'            insert into e';
wwv_flow_imp.g_varchar2_table(1226) := 'ba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (298,2,43,';
wwv_flow_imp.g_varchar2_table(1227) := '16.64,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit';
wwv_flow_imp.g_varchar2_table(1228) := '_price, quantity) values (306,1,28,10.24,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order';
wwv_flow_imp.g_varchar2_table(1229) := '_id, line_item_id, product_id, unit_price, quantity) values (307,1,38,22.98,4);'||wwv_flow.LF||
'            insert i';
wwv_flow_imp.g_varchar2_table(1230) := 'nto eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (307,';
wwv_flow_imp.g_varchar2_table(1231) := '2,19,14.34,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id,';
wwv_flow_imp.g_varchar2_table(1232) := ' unit_price, quantity) values (331,1,34,23.32,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (';
wwv_flow_imp.g_varchar2_table(1233) := 'order_id, line_item_id, product_id, unit_price, quantity) values (1483,1,46,39.16,5);'||wwv_flow.LF||
'            in';
wwv_flow_imp.g_varchar2_table(1234) := 'sert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values';
wwv_flow_imp.g_varchar2_table(1235) := ' (1483,2,23,10.33,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, prod';
wwv_flow_imp.g_varchar2_table(1236) := 'uct_id, unit_price, quantity) values (1483,3,14,26.14,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orde';
wwv_flow_imp.g_varchar2_table(1237) := 'ritems (order_id, line_item_id, product_id, unit_price, quantity) values (1486,1,44,39.32,3);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(1238) := '      insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity';
wwv_flow_imp.g_varchar2_table(1239) := ') values (1486,2,36,49.12,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_';
wwv_flow_imp.g_varchar2_table(1240) := 'id, product_id, unit_price, quantity) values (1486,3,14,26.14,5);'||wwv_flow.LF||
'            insert into eba_demo_r';
wwv_flow_imp.g_varchar2_table(1241) := 'est_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1491,1,12,10.48,2)';
wwv_flow_imp.g_varchar2_table(1242) := ';'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, ';
wwv_flow_imp.g_varchar2_table(1243) := 'quantity) values (1498,1,16,13.09,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, li';
wwv_flow_imp.g_varchar2_table(1244) := 'ne_item_id, product_id, unit_price, quantity) values (1498,2,5,43.71,4);'||wwv_flow.LF||
'            insert into eba';
wwv_flow_imp.g_varchar2_table(1245) := '_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1513,1,36,4';
wwv_flow_imp.g_varchar2_table(1246) := '9.12,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_';
wwv_flow_imp.g_varchar2_table(1247) := 'price, quantity) values (1513,2,5,43.71,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_';
wwv_flow_imp.g_varchar2_table(1248) := 'id, line_item_id, product_id, unit_price, quantity) values (1513,3,44,39.32,4);'||wwv_flow.LF||
'            insert i';
wwv_flow_imp.g_varchar2_table(1249) := 'nto eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1520';
wwv_flow_imp.g_varchar2_table(1250) := ',1,13,12.64,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id';
wwv_flow_imp.g_varchar2_table(1251) := ', unit_price, quantity) values (1520,2,46,27.64,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems';
wwv_flow_imp.g_varchar2_table(1252) := ' (order_id, line_item_id, product_id, unit_price, quantity) values (1520,3,33,37,1);'||wwv_flow.LF||
'            ins';
wwv_flow_imp.g_varchar2_table(1253) := 'ert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values ';
wwv_flow_imp.g_varchar2_table(1254) := '(1525,1,40,34.06,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, produ';
wwv_flow_imp.g_varchar2_table(1255) := 'ct_id, unit_price, quantity) values (1525,2,17,39.89,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_order';
wwv_flow_imp.g_varchar2_table(1256) := 'items (order_id, line_item_id, product_id, unit_price, quantity) values (1543,1,21,38.34,1);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(1257) := '     insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity)';
wwv_flow_imp.g_varchar2_table(1258) := ' values (1543,2,26,48.75,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_i';
wwv_flow_imp.g_varchar2_table(1259) := 'd, product_id, unit_price, quantity) values (1543,3,11,30.69,4);'||wwv_flow.LF||
'            insert into eba_demo_re';
wwv_flow_imp.g_varchar2_table(1260) := 'st_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1549,1,14,26.14,2);';
wwv_flow_imp.g_varchar2_table(1261) := ''||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, q';
wwv_flow_imp.g_varchar2_table(1262) := 'uantity) values (1549,2,43,16.64,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, lin';
wwv_flow_imp.g_varchar2_table(1263) := 'e_item_id, product_id, unit_price, quantity) values (1552,1,34,23.32,2);'||wwv_flow.LF||
'            insert into eba';
wwv_flow_imp.g_varchar2_table(1264) := '_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1555,1,17,3';
wwv_flow_imp.g_varchar2_table(1265) := '9.89,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_';
wwv_flow_imp.g_varchar2_table(1266) := 'price, quantity) values (1555,2,34,23.32,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order';
wwv_flow_imp.g_varchar2_table(1267) := '_id, line_item_id, product_id, unit_price, quantity) values (1560,1,8,19.58,5);'||wwv_flow.LF||
'            insert i';
wwv_flow_imp.g_varchar2_table(1268) := 'nto eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1560';
wwv_flow_imp.g_varchar2_table(1269) := ',2,21,38.34,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id';
wwv_flow_imp.g_varchar2_table(1270) := ', unit_price, quantity) values (1561,1,43,16.64,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems';
wwv_flow_imp.g_varchar2_table(1271) := ' (order_id, line_item_id, product_id, unit_price, quantity) values (1561,2,7,19.16,3);'||wwv_flow.LF||
'            i';
wwv_flow_imp.g_varchar2_table(1272) := 'nsert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) value';
wwv_flow_imp.g_varchar2_table(1273) := 's (1635,1,15,13.97,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, pro';
wwv_flow_imp.g_varchar2_table(1274) := 'duct_id, unit_price, quantity) values (1635,2,4,44.17,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orde';
wwv_flow_imp.g_varchar2_table(1275) := 'ritems (order_id, line_item_id, product_id, unit_price, quantity) values (1635,3,36,49.12,2);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(1276) := '      insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity';
wwv_flow_imp.g_varchar2_table(1277) := ') values (1637,1,25,9.8,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id';
wwv_flow_imp.g_varchar2_table(1278) := ', product_id, unit_price, quantity) values (1659,1,14,26.14,3);'||wwv_flow.LF||
'            insert into eba_demo_res';
wwv_flow_imp.g_varchar2_table(1279) := 't_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1730,1,20,28.21,3);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1280) := '            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, qu';
wwv_flow_imp.g_varchar2_table(1281) := 'antity) values (1730,2,11,30.69,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line';
wwv_flow_imp.g_varchar2_table(1282) := '_item_id, product_id, unit_price, quantity) values (1731,1,39,11,2);'||wwv_flow.LF||
'            insert into eba_dem';
wwv_flow_imp.g_varchar2_table(1283) := 'o_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1731,2,21,38.34';
wwv_flow_imp.g_varchar2_table(1284) := ',3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_pric';
wwv_flow_imp.g_varchar2_table(1285) := 'e, quantity) values (1776,1,34,23.32,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id,';
wwv_flow_imp.g_varchar2_table(1286) := ' line_item_id, product_id, unit_price, quantity) values (1776,2,25,9.8,2);'||wwv_flow.LF||
'            insert into e';
wwv_flow_imp.g_varchar2_table(1287) := 'ba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1776,3,20';
wwv_flow_imp.g_varchar2_table(1288) := ',28.21,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, uni';
wwv_flow_imp.g_varchar2_table(1289) := 't_price, quantity) values (1808,1,14,26.14,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (ord';
wwv_flow_imp.g_varchar2_table(1290) := 'er_id, line_item_id, product_id, unit_price, quantity) values (1817,1,34,23.32,3);'||wwv_flow.LF||
'            inser';
wwv_flow_imp.g_varchar2_table(1291) := 't into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1';
wwv_flow_imp.g_varchar2_table(1292) := '817,2,42,10.11,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product';
wwv_flow_imp.g_varchar2_table(1293) := '_id, unit_price, quantity) values (1817,3,22,39.78,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderit';
wwv_flow_imp.g_varchar2_table(1294) := 'ems (order_id, line_item_id, product_id, unit_price, quantity) values (1890,1,2,29.55,3);'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(1295) := '  insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) va';
wwv_flow_imp.g_varchar2_table(1296) := 'lues (1890,2,46,39.16,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, ';
wwv_flow_imp.g_varchar2_table(1297) := 'product_id, unit_price, quantity) values (832,1,10,29.49,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_o';
wwv_flow_imp.g_varchar2_table(1298) := 'rderitems (order_id, line_item_id, product_id, unit_price, quantity) values (832,2,9,21.16,4);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(1299) := '       insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantit';
wwv_flow_imp.g_varchar2_table(1300) := 'y) values (839,1,38,22.98,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_';
wwv_flow_imp.g_varchar2_table(1301) := 'id, product_id, unit_price, quantity) values (839,2,7,19.16,5);'||wwv_flow.LF||
'            insert into eba_demo_res';
wwv_flow_imp.g_varchar2_table(1302) := 't_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (862,1,23,10.33,1);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1303) := '           insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, qua';
wwv_flow_imp.g_varchar2_table(1304) := 'ntity) values (862,2,33,37,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item';
wwv_flow_imp.g_varchar2_table(1305) := '_id, product_id, unit_price, quantity) values (899,1,31,28.59,2);'||wwv_flow.LF||
'            insert into eba_demo_r';
wwv_flow_imp.g_varchar2_table(1306) := 'est_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (920,1,41,8.66,2);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1307) := '            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, qu';
wwv_flow_imp.g_varchar2_table(1308) := 'antity) values (920,2,4,44.17,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_i';
wwv_flow_imp.g_varchar2_table(1309) := 'tem_id, product_id, unit_price, quantity) values (928,1,3,16.67,2);'||wwv_flow.LF||
'            insert into eba_demo';
wwv_flow_imp.g_varchar2_table(1310) := '_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (928,2,12,10.48,4';
wwv_flow_imp.g_varchar2_table(1311) := ');'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price,';
wwv_flow_imp.g_varchar2_table(1312) := ' quantity) values (928,3,35,7.18,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, lin';
wwv_flow_imp.g_varchar2_table(1313) := 'e_item_id, product_id, unit_price, quantity) values (943,1,6,38.28,2);'||wwv_flow.LF||
'            insert into eba_d';
wwv_flow_imp.g_varchar2_table(1314) := 'emo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (950,1,22,39.7';
wwv_flow_imp.g_varchar2_table(1315) := '8,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_pri';
wwv_flow_imp.g_varchar2_table(1316) := 'ce, quantity) values (950,2,23,10.33,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id,';
wwv_flow_imp.g_varchar2_table(1317) := ' line_item_id, product_id, unit_price, quantity) values (960,1,26,48.75,2);'||wwv_flow.LF||
'            insert into ';
wwv_flow_imp.g_varchar2_table(1318) := 'eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (960,2,43';
wwv_flow_imp.g_varchar2_table(1319) := ',16.64,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, uni';
wwv_flow_imp.g_varchar2_table(1320) := 't_price, quantity) values (960,3,24,48.39,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (orde';
wwv_flow_imp.g_varchar2_table(1321) := 'r_id, line_item_id, product_id, unit_price, quantity) values (968,1,30,37.34,2);'||wwv_flow.LF||
'            insert ';
wwv_flow_imp.g_varchar2_table(1322) := 'into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (968';
wwv_flow_imp.g_varchar2_table(1323) := ',2,13,12.64,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id';
wwv_flow_imp.g_varchar2_table(1324) := ', unit_price, quantity) values (968,3,35,7.18,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (';
wwv_flow_imp.g_varchar2_table(1325) := 'order_id, line_item_id, product_id, unit_price, quantity) values (972,1,27,39.91,3);'||wwv_flow.LF||
'            ins';
wwv_flow_imp.g_varchar2_table(1326) := 'ert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values ';
wwv_flow_imp.g_varchar2_table(1327) := '(972,2,23,10.33,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, produc';
wwv_flow_imp.g_varchar2_table(1328) := 't_id, unit_price, quantity) values (986,1,12,10.48,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderit';
wwv_flow_imp.g_varchar2_table(1329) := 'ems (order_id, line_item_id, product_id, unit_price, quantity) values (986,2,14,26.14,5);'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(1330) := '  insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) va';
wwv_flow_imp.g_varchar2_table(1331) := 'lues (993,1,35,7.18,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, pr';
wwv_flow_imp.g_varchar2_table(1332) := 'oduct_id, unit_price, quantity) values (993,2,14,26.14,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_ord';
wwv_flow_imp.g_varchar2_table(1333) := 'eritems (order_id, line_item_id, product_id, unit_price, quantity) values (993,3,19,14.34,4);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(1334) := '      insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity';
wwv_flow_imp.g_varchar2_table(1335) := ') values (1052,1,36,49.12,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_';
wwv_flow_imp.g_varchar2_table(1336) := 'id, product_id, unit_price, quantity) values (1052,2,33,37,3);'||wwv_flow.LF||
'            insert into eba_demo_rest';
wwv_flow_imp.g_varchar2_table(1337) := '_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1052,3,44,39.32,4);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1338) := '           insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, qua';
wwv_flow_imp.g_varchar2_table(1339) := 'ntity) values (1058,1,16,13.09,5);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_';
wwv_flow_imp.g_varchar2_table(1340) := 'item_id, product_id, unit_price, quantity) values (1058,2,34,23.32,1);'||wwv_flow.LF||
'            insert into eba_d';
wwv_flow_imp.g_varchar2_table(1341) := 'emo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1058,3,2,29.5';
wwv_flow_imp.g_varchar2_table(1342) := '5,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_pri';
wwv_flow_imp.g_varchar2_table(1343) := 'ce, quantity) values (1082,1,22,39.78,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id';
wwv_flow_imp.g_varchar2_table(1344) := ', line_item_id, product_id, unit_price, quantity) values (1082,2,20,28.21,2);'||wwv_flow.LF||
'            insert int';
wwv_flow_imp.g_varchar2_table(1345) := 'o eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1102,1';
wwv_flow_imp.g_varchar2_table(1346) := ',10,29.49,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, ';
wwv_flow_imp.g_varchar2_table(1347) := 'unit_price, quantity) values (1102,2,39,11,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (ord';
wwv_flow_imp.g_varchar2_table(1348) := 'er_id, line_item_id, product_id, unit_price, quantity) values (1102,3,14,26.14,2);'||wwv_flow.LF||
'            inser';
wwv_flow_imp.g_varchar2_table(1349) := 't into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1';
wwv_flow_imp.g_varchar2_table(1350) := '111,1,41,8.66,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_';
wwv_flow_imp.g_varchar2_table(1351) := 'id, unit_price, quantity) values (1111,2,13,12.64,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderite';
wwv_flow_imp.g_varchar2_table(1352) := 'ms (order_id, line_item_id, product_id, unit_price, quantity) values (1119,1,25,9.8,3);'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(1353) := 'insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) valu';
wwv_flow_imp.g_varchar2_table(1354) := 'es (1119,2,9,21.16,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, pro';
wwv_flow_imp.g_varchar2_table(1355) := 'duct_id, unit_price, quantity) values (1119,3,45,31.68,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_ord';
wwv_flow_imp.g_varchar2_table(1356) := 'eritems (order_id, line_item_id, product_id, unit_price, quantity) values (1121,1,27,39.91,4);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(1357) := '       insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantit';
wwv_flow_imp.g_varchar2_table(1358) := 'y) values (1169,1,9,21.16,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_';
wwv_flow_imp.g_varchar2_table(1359) := 'id, product_id, unit_price, quantity) values (1169,2,22,39.78,5);'||wwv_flow.LF||
'            insert into eba_demo_r';
wwv_flow_imp.g_varchar2_table(1360) := 'est_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1191,1,33,37,2);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1361) := '           insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, qua';
wwv_flow_imp.g_varchar2_table(1362) := 'ntity) values (1191,2,40,34.06,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_';
wwv_flow_imp.g_varchar2_table(1363) := 'item_id, product_id, unit_price, quantity) values (1191,3,14,26.14,3);'||wwv_flow.LF||
'            insert into eba_d';
wwv_flow_imp.g_varchar2_table(1364) := 'emo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1195,1,13,12.';
wwv_flow_imp.g_varchar2_table(1365) := '64,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_pr';
wwv_flow_imp.g_varchar2_table(1366) := 'ice, quantity) values (1200,1,19,14.34,5);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_i';
wwv_flow_imp.g_varchar2_table(1367) := 'd, line_item_id, product_id, unit_price, quantity) values (1200,2,27,39.91,3);'||wwv_flow.LF||
'            insert in';
wwv_flow_imp.g_varchar2_table(1368) := 'to eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1200,';
wwv_flow_imp.g_varchar2_table(1369) := '3,7,19.16,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, ';
wwv_flow_imp.g_varchar2_table(1370) := 'unit_price, quantity) values (1260,1,30,37.34,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (';
wwv_flow_imp.g_varchar2_table(1371) := 'order_id, line_item_id, product_id, unit_price, quantity) values (1260,2,5,43.71,4);'||wwv_flow.LF||
'            ins';
wwv_flow_imp.g_varchar2_table(1372) := 'ert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values ';
wwv_flow_imp.g_varchar2_table(1373) := '(1321,1,43,16.64,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, produ';
wwv_flow_imp.g_varchar2_table(1374) := 'ct_id, unit_price, quantity) values (1321,2,37,29.51,1);'||wwv_flow.LF||
'            insert into eba_demo_rest_order';
wwv_flow_imp.g_varchar2_table(1375) := 'items (order_id, line_item_id, product_id, unit_price, quantity) values (1321,3,46,39.16,3);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(1376) := '     insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity)';
wwv_flow_imp.g_varchar2_table(1377) := ' values (1348,1,31,28.59,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_i';
wwv_flow_imp.g_varchar2_table(1378) := 'd, product_id, unit_price, quantity) values (1348,2,23,10.33,2);'||wwv_flow.LF||
'            insert into eba_demo_re';
wwv_flow_imp.g_varchar2_table(1379) := 'st_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1348,3,3,16.67,5);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1380) := '            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, qu';
wwv_flow_imp.g_varchar2_table(1381) := 'antity) values (1363,1,11,30.69,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line';
wwv_flow_imp.g_varchar2_table(1382) := '_item_id, product_id, unit_price, quantity) values (1363,2,14,26.14,2);'||wwv_flow.LF||
'            insert into eba_';
wwv_flow_imp.g_varchar2_table(1383) := 'demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1373,1,17,39';
wwv_flow_imp.g_varchar2_table(1384) := '.89,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_p';
wwv_flow_imp.g_varchar2_table(1385) := 'rice, quantity) values (1373,2,29,24.71,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_';
wwv_flow_imp.g_varchar2_table(1386) := 'id, line_item_id, product_id, unit_price, quantity) values (1390,1,12,10.48,2);'||wwv_flow.LF||
'            insert i';
wwv_flow_imp.g_varchar2_table(1387) := 'nto eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1390';
wwv_flow_imp.g_varchar2_table(1388) := ',2,28,10.24,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id';
wwv_flow_imp.g_varchar2_table(1389) := ', unit_price, quantity) values (1390,3,9,21.16,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems ';
wwv_flow_imp.g_varchar2_table(1390) := '(order_id, line_item_id, product_id, unit_price, quantity) values (1400,1,11,30.69,5);'||wwv_flow.LF||
'            i';
wwv_flow_imp.g_varchar2_table(1391) := 'nsert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) value';
wwv_flow_imp.g_varchar2_table(1392) := 's (1400,2,6,38.28,5);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, prod';
wwv_flow_imp.g_varchar2_table(1393) := 'uct_id, unit_price, quantity) values (1418,1,31,28.59,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orde';
wwv_flow_imp.g_varchar2_table(1394) := 'ritems (order_id, line_item_id, product_id, unit_price, quantity) values (1418,2,45,31.68,3);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(1395) := '      insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity';
wwv_flow_imp.g_varchar2_table(1396) := ') values (1437,1,3,16.67,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_i';
wwv_flow_imp.g_varchar2_table(1397) := 'd, product_id, unit_price, quantity) values (1439,1,46,27.64,4);'||wwv_flow.LF||
'            insert into eba_demo_re';
wwv_flow_imp.g_varchar2_table(1398) := 'st_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1439,2,9,21.16,3);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1399) := '            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, qu';
wwv_flow_imp.g_varchar2_table(1400) := 'antity) values (1448,1,2,29.55,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_';
wwv_flow_imp.g_varchar2_table(1401) := 'item_id, product_id, unit_price, quantity) values (1450,1,4,44.17,3);'||wwv_flow.LF||
'            insert into eba_de';
wwv_flow_imp.g_varchar2_table(1402) := 'mo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1451,1,10,29.4';
wwv_flow_imp.g_varchar2_table(1403) := '9,5);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_pri';
wwv_flow_imp.g_varchar2_table(1404) := 'ce, quantity) values (1451,2,35,7.18,4);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id,';
wwv_flow_imp.g_varchar2_table(1405) := ' line_item_id, product_id, unit_price, quantity) values (1455,1,45,31.68,3);'||wwv_flow.LF||
'            insert into';
wwv_flow_imp.g_varchar2_table(1406) := ' eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (1455,2,';
wwv_flow_imp.g_varchar2_table(1407) := '23,10.33,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, product_id, u';
wwv_flow_imp.g_varchar2_table(1408) := 'nit_price, quantity) values (1468,1,2,29.55,3);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (or';
wwv_flow_imp.g_varchar2_table(1409) := 'der_id, line_item_id, product_id, unit_price, quantity) values (1468,2,45,31.68,4);'||wwv_flow.LF||
'            inse';
wwv_flow_imp.g_varchar2_table(1410) := 'rt into eba_demo_rest_orderitems (order_id, line_item_id, product_id, unit_price, quantity) values (';
wwv_flow_imp.g_varchar2_table(1411) := '1471,1,14,26.14,2);'||wwv_flow.LF||
'            insert into eba_demo_rest_orderitems (order_id, line_item_id, produc';
wwv_flow_imp.g_varchar2_table(1412) := 't_id, unit_price, quantity) values (1471,2,6,38.28,3);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'        -- purchase order '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'            in';
wwv_flow_imp.g_varchar2_table(1413) := 'sert into eba_demo_rest_purchaseorders (id,po) values (81,''{"PONumber":9,"Reference":"AHUNOLD-201411';
wwv_flow_imp.g_varchar2_table(1414) := '30","Requestor":"Alexander Hunold","User":"AHUNOLD","Special Instructions":"Counter to Counter","Lin';
wwv_flow_imp.g_varchar2_table(1415) := 'eItems":[{"ItemNumber":1,"Part":{"Description":"Fatal Fury Ova"},"Quantity":7.0}]}'');'||wwv_flow.LF||
'            in';
wwv_flow_imp.g_varchar2_table(1416) := 'sert into eba_demo_rest_purchaseorders (id,po) values (82,''{"PONumber":10,"Reference":"STOBIAS-20140';
wwv_flow_imp.g_varchar2_table(1417) := '515","Requestor":"Sigal Tobias","User":"STOBIAS","Special Instructions":"Surface Mail","LineItems":[';
wwv_flow_imp.g_varchar2_table(1418) := '{"ItemNumber":1,"Part":{"Description":"The Manchurian Candidate"},"Quantity":3.0},{"ItemNumber":2,"P';
wwv_flow_imp.g_varchar2_table(1419) := 'art":{"Description":"The Great Santini"},"Quantity":5.0}]}'');'||wwv_flow.LF||
'            insert into eba_demo_rest_';
wwv_flow_imp.g_varchar2_table(1420) := 'purchaseorders (id,po) values (83,''{"PONumber":11,"Reference":"STOBIAS-20140516","Requestor":"Sigal ';
wwv_flow_imp.g_varchar2_table(1421) := 'Tobias","User":"STOBIAS","Special Instructions":"Courier","LineItems":[{"ItemNumber":1,"Part":{"Desc';
wwv_flow_imp.g_varchar2_table(1422) := 'ription":"Shanghai Triad"},"Quantity":7.0},{"ItemNumber":2,"Part":{"Description":"Hanover Street"},"';
wwv_flow_imp.g_varchar2_table(1423) := 'Quantity":1.0},{"ItemNumber":3,"Part":{"Description":"Dr. Seuss'''' How the Grinch Stole Christmas"},"';
wwv_flow_imp.g_varchar2_table(1424) := 'Quantity":5.0}]}'');'||wwv_flow.LF||
'            insert into eba_demo_rest_purchaseorders (id,po) values (84,''{"PONum';
wwv_flow_imp.g_varchar2_table(1425) := 'ber":12,"Reference":"SVOLLMAN-20140502","Requestor":"Shanta Vollman","User":"SVOLLMAN","Special Inst';
wwv_flow_imp.g_varchar2_table(1426) := 'ructions":"Ground","LineItems":[{"ItemNumber":1,"Part":{"Description":"Dakota"},"Quantity":7.0}]}'');';
wwv_flow_imp.g_varchar2_table(1427) := ''||wwv_flow.LF||
'            insert into eba_demo_rest_purchaseorders (id,po) values (85,''{"PONumber":13,"Reference"';
wwv_flow_imp.g_varchar2_table(1428) := ':"SVOLLMAN-20140524","Requestor":"Shanta Vollman","User":"SVOLLMAN","Special Instructions":"Air Mail';
wwv_flow_imp.g_varchar2_table(1429) := '","LineItems":[{"ItemNumber":1,"Part":{"Description":"Enemy Mine"},"Quantity":7.0},{"ItemNumber":2,"';
wwv_flow_imp.g_varchar2_table(1430) := 'Part":{"Description":"The Pink Panther"},"Quantity":5.0}]}'');'||wwv_flow.LF||
'            insert into eba_demo_rest_';
wwv_flow_imp.g_varchar2_table(1431) := 'purchaseorders (id,po) values (86,''{"PONumber":14,"Reference":"SVOLLMAN-20140525","Requestor":"Shant';
wwv_flow_imp.g_varchar2_table(1432) := 'a Vollman","User":"SVOLLMAN","Special Instructions":"Counter to Counter","LineItems":[{"ItemNumber":';
wwv_flow_imp.g_varchar2_table(1433) := '1,"Part":{"Description":"Mr. Mom"},"Quantity":8.0},{"ItemNumber":2,"Part":{"Description":"Confession';
wwv_flow_imp.g_varchar2_table(1434) := 's of Sorority Girls"},"Quantity":4.0},{"ItemNumber":3,"Part":{"Description":"Attraction"},"Quantity"';
wwv_flow_imp.g_varchar2_table(1435) := ':3.0}]}'');'||wwv_flow.LF||
'            insert into eba_demo_rest_purchaseorders (id,po) values (87,''{"PONumber":15,"';
wwv_flow_imp.g_varchar2_table(1436) := 'Reference":"SVOLLMAN-20140506","Requestor":"Shanta Vollman","User":"SVOLLMAN","Special Instructions"';
wwv_flow_imp.g_varchar2_table(1437) := ':"COD","LineItems":[{"ItemNumber":1,"Part":{"Description":"True Crime"},"Quantity":7.0}]}'');'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(1438) := '     insert into eba_demo_rest_purchaseorders (id,po) values (88,''{"PONumber":16,"Reference":"SVOLLM';
wwv_flow_imp.g_varchar2_table(1439) := 'AN-20140531","Requestor":"Shanta Vollman","User":"SVOLLMAN","Special Instructions":"Courier","LineIt';
wwv_flow_imp.g_varchar2_table(1440) := 'ems":[{"ItemNumber":1,"Part":{"Description":"Karaoke Favorites Vol. 3"},"Quantity":1.0},{"ItemNumber';
wwv_flow_imp.g_varchar2_table(1441) := '":2,"Part":{"Description":"Traveller"},"Quantity":9.0}]}'');'||wwv_flow.LF||
'            insert into eba_demo_rest_pu';
wwv_flow_imp.g_varchar2_table(1442) := 'rchaseorders (id,po) values (89,''{"PONumber":17,"Reference":"TFOX-20140511","Requestor":"Tayler Fox"';
wwv_flow_imp.g_varchar2_table(1443) := ',"User":"TFOX","Special Instructions":"Ground","LineItems":[{"ItemNumber":1,"Part":{"Description":"C';
wwv_flow_imp.g_varchar2_table(1444) := 'ircuit 5"},"Quantity":3.0},{"ItemNumber":2,"Part":{"Description":"Eric Clapton: July 1986"},"Quantit';
wwv_flow_imp.g_varchar2_table(1445) := 'y":2.0},{"ItemNumber":3,"Part":{"Description":"Adventures of the Old West: The 49ers and the Califor';
wwv_flow_imp.g_varchar2_table(1446) := 'nia Gold Rush"},"Quantity":3.0}]}'');'||wwv_flow.LF||
'            insert into eba_demo_rest_purchaseorders (id,po) va';
wwv_flow_imp.g_varchar2_table(1447) := 'lues (90,''{"PONumber":18,"Reference":"GGEONI-20141114","Requestor":"Girard Geoni","User":"GGEONI","S';
wwv_flow_imp.g_varchar2_table(1448) := 'pecial Instructions":"Courier","LineItems":[{"ItemNumber":1,"Part":{"Description":"Genesi: La Creazi';
wwv_flow_imp.g_varchar2_table(1449) := 'one e il Diluvio"},"Quantity":6.0}]}'');'||wwv_flow.LF||
'            insert into eba_demo_rest_purchaseorders (id,po)';
wwv_flow_imp.g_varchar2_table(1450) := ' values (91,''{"PONumber":1,"Reference":"MSULLIVA-20141102","Requestor":"Martha Sullivan","User":"MSU';
wwv_flow_imp.g_varchar2_table(1451) := 'LLIVA","Special Instructions":"Surface Mail","LineItems":[{"ItemNumber":1,"Part":{"Description":"Run';
wwv_flow_imp.g_varchar2_table(1452) := ' Lola Run"},"Quantity":7.0},{"ItemNumber":2,"Part":{"Description":"Felicia''''s Journey"},"Quantity":1';
wwv_flow_imp.g_varchar2_table(1453) := '.0}]}'');'||wwv_flow.LF||
'            insert into eba_demo_rest_purchaseorders (id,po) values (92,''{"PONumber":2,"Ref';
wwv_flow_imp.g_varchar2_table(1454) := 'erence":"MSULLIVA(-20141113","Requestor":"Martha Sullivan","User":"MSULLIVA","Special Instructions":';
wwv_flow_imp.g_varchar2_table(1455) := '"Next Day Air","LineItems":[{"ItemNumber":1,"Part":{"Description":"Menace II Society"},"Quantity":3.';
wwv_flow_imp.g_varchar2_table(1456) := '0},{"ItemNumber":2,"Part":{"Description":"Best of Musikladen Live: Procol Harum"},"Quantity":5.0},{"';
wwv_flow_imp.g_varchar2_table(1457) := 'ItemNumber":3,"Part":{"Description":"Anywhere But Here"},"Quantity":9.0}]}'');'||wwv_flow.LF||
'            insert int';
wwv_flow_imp.g_varchar2_table(1458) := 'o eba_demo_rest_purchaseorders (id,po) values (93,''{"PONumber":3,"Reference":"TRAJS-20140518","Reque';
wwv_flow_imp.g_varchar2_table(1459) := 'stor":"Trenna Rajs","User":"TRAJS","Special Instructions":"Courier","LineItems":[{"ItemNumber":1,"Pa';
wwv_flow_imp.g_varchar2_table(1460) := 'rt":{"Description":"Tora! Tora! Tora!"},"Quantity":2.0}]}'');'||wwv_flow.LF||
'            insert into eba_demo_rest_p';
wwv_flow_imp.g_varchar2_table(1461) := 'urchaseorders (id,po) values (94,''{"PONumber":4,"Reference":"TRAJS-20140520","Requestor":"Trenna Raj';
wwv_flow_imp.g_varchar2_table(1462) := 's","User":"TRAJS","Special Instructions":"Ground","LineItems":[{"ItemNumber":1,"Part":{"Description"';
wwv_flow_imp.g_varchar2_table(1463) := ':"Mistress"},"Quantity":6.0},{"ItemNumber":2,"Part":{"Description":"Haunted"},"Quantity":6.0}]}'');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1464) := '           insert into eba_demo_rest_purchaseorders (id,po) values (95,''{"PONumber":5,"Reference":"M';
wwv_flow_imp.g_varchar2_table(1465) := 'SULLIVA-20141121","Requestor":"Martha Sullivan","User":"MSULLIVA","Special Instructions":"Air Mail",';
wwv_flow_imp.g_varchar2_table(1466) := '"LineItems":[{"ItemNumber":1,"Part":{"Description":"Anaconda"},"Quantity":9.0},{"ItemNumber":2,"Part';
wwv_flow_imp.g_varchar2_table(1467) := '":{"Description":"Tron"},"Quantity":2.0},{"ItemNumber":3,"Part":{"Description":"The Evening Star"},"';
wwv_flow_imp.g_varchar2_table(1468) := 'Quantity":6.0}]}'');'||wwv_flow.LF||
'            insert into eba_demo_rest_purchaseorders (id,po) values (96,''{"PONum';
wwv_flow_imp.g_varchar2_table(1469) := 'ber":6,"Reference":"TRAJS-20140530","Requestor":"Trenna Rajs","User":"TRAJS","Special Instructions":';
wwv_flow_imp.g_varchar2_table(1470) := '"Next Day Air","LineItems":[{"ItemNumber":1,"Part":{"Description":"La Cucaracha"},"Quantity":8.0}]}''';
wwv_flow_imp.g_varchar2_table(1471) := ');'||wwv_flow.LF||
'            insert into eba_demo_rest_purchaseorders (id,po) values (97,''{"PONumber":7,"Reference';
wwv_flow_imp.g_varchar2_table(1472) := '":"VJONES-20140503","Requestor":"Vance Jones","User":"VJONES","Special Instructions":"Hand Carry","L';
wwv_flow_imp.g_varchar2_table(1473) := 'ineItems":[{"ItemNumber":1,"Part":{"Description":"The Kentucky Fried Movie"},"Quantity":3.0},{"ItemN';
wwv_flow_imp.g_varchar2_table(1474) := 'umber":2,"Part":{"Description":"The Loves of Carmen"},"Quantity":4.0}]}'');'||wwv_flow.LF||
'            insert into e';
wwv_flow_imp.g_varchar2_table(1475) := 'ba_demo_rest_purchaseorders (id,po) values (98,''{"PONumber":8,"Reference":"VJONES-20140504","Request';
wwv_flow_imp.g_varchar2_table(1476) := 'or":"Vance Jones","User":"VJONES","Special Instructions":"Counter to Counter","LineItems":[{"ItemNum';
wwv_flow_imp.g_varchar2_table(1477) := 'ber":1,"Part":{"Description":"Digimon: The Movie"},"Quantity":4.0},{"ItemNumber":2,"Part":{"Descript';
wwv_flow_imp.g_varchar2_table(1478) := 'ion":"Fair Game"},"Quantity":8.0},{"ItemNumber":3,"Part":{"Description":"Barbra Streisand: Timeless-';
wwv_flow_imp.g_varchar2_table(1479) := ' Live In Concert"},"Quantity":2.0}]}'');'||wwv_flow.LF||
'            insert into eba_demo_rest_purchaseorders (id,po)';
wwv_flow_imp.g_varchar2_table(1480) := ' values (99,''{"PONumber":19,"Reference":"IMIKKILI-20141114","Requestor":"Irene Mikkilineni","User":"';
wwv_flow_imp.g_varchar2_table(1481) := 'IMIKKILI","Special Instructions":"Hand Carry","LineItems":[{"ItemNumber":1,"Part":{"Description":"Be';
wwv_flow_imp.g_varchar2_table(1482) := 'st of Musikladen Live: Ladies of Rock"},"Quantity":3.0},{"ItemNumber":2,"Part":{"Description":"Dange';
wwv_flow_imp.g_varchar2_table(1483) := 'rous Minds"},"Quantity":7.0}]}'');'||wwv_flow.LF||
'            insert into eba_demo_rest_purchaseorders (id,po) value';
wwv_flow_imp.g_varchar2_table(1484) := 's (100,''{"PONumber":20,"Reference":"IMIKKILI-20141115","Requestor":"Irene Mikkilineni","User":"IMIKK';
wwv_flow_imp.g_varchar2_table(1485) := 'ILI","Special Instructions":"Courier","LineItems":[{"ItemNumber":1,"Part":{"Description":"Offspring:';
wwv_flow_imp.g_varchar2_table(1486) := ' Huck It"},"Quantity":5.0},{"ItemNumber":2,"Part":{"Description":"Alice"},"Quantity":2.0},{"ItemNumb';
wwv_flow_imp.g_varchar2_table(1487) := 'er":3,"Part":{"Description":"The Reptile"},"Quantity":3.0}]}'');'||wwv_flow.LF||
'               '||wwv_flow.LF||
'        end load_dat';
wwv_flow_imp.g_varchar2_table(1488) := 'a;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    procedure reset_data is'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            clear_data;'||wwv_flow.LF||
'            load_data;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(1489) := '     end reset_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_demo_rest_data_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_demo_rest_data_pkg.reset_data;'||wwv_flow.LF||
'en';
wwv_flow_imp.g_varchar2_table(1490) := 'd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(101142335494412475)
,p_install_id=>wwv_flow_imp.id(94382806445719195)
,p_name=>'Data installation'
,p_sequence=>120
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(101142456661412478)
,p_script_id=>wwv_flow_imp.id(101142335494412475)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_DEMO_REST_DATA_PKG'
);
wwv_flow_imp.component_end;
end;
/
