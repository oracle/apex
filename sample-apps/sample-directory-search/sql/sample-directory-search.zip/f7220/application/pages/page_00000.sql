prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page'
,p_reload_on_submit=>null
,p_warn_on_unsaved_changes=>null
,p_autocomplete_on_off=>'OFF'
,p_protection_level=>'D'
,p_page_component_map=>'14'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2197421472961807148)
,p_plug_name=>'Help Region'
,p_static_id=>'help-region'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-callout:js-dialog-size600x400'
,p_region_attributes=>'data-parent-element="#HELP"'
,p_plug_template=>1488796984234986045
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2197421562922807149)
,p_plug_name=>'Help Text'
,p_static_id=>'new'
,p_parent_plug_id=>wwv_flow_imp.id(2197421472961807148)
,p_region_css_classes=>'u-text-body-sm'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_text clob;',
'begin',
'    for c1 in (',
'        select help_text',
'          from apex_application_pages',
'         where page_id        = :APP_PAGE_ID',
'           and application_id = :APP_ID )',
'    loop',
'        if c1.help_text is null then',
'            l_text := ''No help is available for this page.'';',
'        else',
'            l_text := l_text || ''<p>'' || c1.help_text || ''</p>'';',
'        end if;',
'    end loop;',
'',
'    return l_text;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2197421656611807150)
,p_button_sequence=>10
,p_button_name=>'HELP'
,p_static_id=>'help'
,p_button_static_id=>'HELP'
,p_show_as_disabled=>false
,p_button_action=>'DEFINED_BY_DA_ACTION'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Help'
,p_button_position=>'BEFORE_NAVIGATION_BAR'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'2,3,6,201'
,p_button_condition_type=>'CURRENT_PAGE_IN_CONDITION'
,p_button_css_classes=>'u-color-1'
,p_icon_css_classes=>'fa-question-circle-o'
);
wwv_flow_imp_page.create_component_da_action(
 p_id=>wwv_flow_imp.id(5949328445920627002)
,p_button_id=>wwv_flow_imp.id(2197421656611807150)
,p_action_sequence=>20
,p_action=>'NATIVE_OPEN_REGION'
,p_static_id=>'native-open-region'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2197421472961807148)
,p_stop_execution_on_error=>true
);
wwv_flow_imp_page.create_component_da_action(
 p_id=>wwv_flow_imp.id(5949328312754627001)
,p_button_id=>wwv_flow_imp.id(2197421656611807150)
,p_action_sequence=>10
,p_action=>'NATIVE_REFRESH'
,p_static_id=>'native-refresh'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2197421562922807149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
,p_stop_execution_on_error=>true
);
wwv_flow_imp.component_end;
end;
/
