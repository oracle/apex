prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Employees Content Row'
,p_alias=>'EMPLOYEES-CONTENT-ROW'
,p_step_title=>'Employees Content Row'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Fix wrapping of Quick Picks during page load */',
'.t-Form-itemWrapper:has(.apex-quick-picks) {',
'    flex-wrap: wrap;',
'',
'   .apex-quick-picks {',
'        order: 5;',
'   }',
'}',
'',
'/* Add margin to quick picks */',
'.apex-quick-picks {',
'    margin-block-start: .25rem;',
'}'))
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#:t-PageBody--noContentPadding'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>Search with a Content Row region</h3>',
'<p>',
'    This page provides full text search on the employee directory using a <strong>Content Row</strong> region. The ',
'    region SQL query makes use of the Oracle Text index, which allows to provide exact, fuzzy or name search. The',
'    index is configured to first do exact search on names, following by fuzzy search on names, ',
'    and then on other attributes,  so that the most relevant results are first.',
'</p>',
'<p>',
'    See the <em>Quick Picks</em> under the search field for examples.',
'</p>',
'<p><strong>Search Options</strong></p>',
'<dl>',
unistr('    <dt><code>M\00FCller</code></dt>'),
unistr('    <dd>Search for <strong>M\00FCller</strong> across all attributes, starting with the name. Apply normal and fuzzy search.</dd>'),
'    <dt><code>email:jochen.margraf.30@example.invalid</code></dt>',
'    <dd>The <strong>email</strong> prefix initiates exact search for the given email address. Useful if that address is known.</dd>',
'    <dt><code>phone:4711</code> or <code>4711</code></dt>',
'    <dd>If a plain number is detected, then the search is done for phone numbers ending with the provided number.</dd>',
'    <dt><code>New York</code></dt>',
'    <dd>If the name of a known city is entered, then the search is done for the city.</dd>',
'    <dt><code>United States</code></dt>',
'    <dd>If the name of a known country is entered, then the search is done for the country.</dd>',
'</dl>',
'',
''))
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2198730435967730657)
,p_plug_name=>'Employees'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon:t-Form--noPadding:t-Form--large:t-Form--stretchInputs'
,p_plug_template=>2677445476673898083
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_landmark_type=>'search'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2197156278645049057)
,p_plug_name=>'Results'
,p_static_id=>'results'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.*,',
'       apex_util.prepare_url(''f?p='' || :APP_ID || '':4:'' || :APP_SESSION || ''::::P4_EMPLOYEE_ID:'' || employee_id ) as edit_url,',
'       substr( last_name,1,1) || substr( first_name, 1,1) as initials',
'  from eba_srch_txt_employees e',
' where contains( last_name, eba_search_text_helper.get_name_search_query( :P3_SEARCH ), 1 ) > 0',
''))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'score(1) desc'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P3_SEARCH'
,p_plug_query_num_rows=>30
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'No search conducted or no results found.'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_INITIALS', 'INITIALS',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_TYPE', 'initials',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignEnd',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--sm',
  'BADGE_ICON', 'fa-users',
  'BADGE_LABEL', 'Direct Reports',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_POS', 't-ContentRow-badge--posEnd',
  'BADGE_SHAPE', 't-Badge--circle',
  'BADGE_SIZE', 't-Badge--md',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'DIRECT_REPORTS',
  'DESCRIPTION', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<div class="u-flex u-flex-col u-gap-1">',
    '  <div>',
    '    <strong>&JOB_TITLE.</strong>',
    '    {if ?COST_CENTER/} &middot; &COST_CENTER.{endif/}',
    '  </div>',
    '',
    '  <div class="u-flex u-flex-wrap u-align-items-center u-gap-x-4 u-gap-y-1">',
    '    <span class="u-inline-flex u-align-items-center u-gap-2"',
    '          {if ?CURRENT_LOCAL_TIME/}title="Local time: &CURRENT_LOCAL_TIME!ATTR. &TIMEZONE!ATTR."{endif/}>',
    '      <span class="fa fa-flag-&COUNTRY_CODE!ATTR." aria-hidden="true"></span>',
    '      <span>{if ?CITY/}&CITY. &middot; {endif/}&COUNTRY.</span>',
    '    </span>',
    '',
    '    {if ?EMAIL/}',
    '      <a href="mailto:&EMAIL!ATTR." class="u-wrap-anywhere">&EMAIL.</a>',
    '    {endif/}',
    '',
    '    {if ?PHONE_NUMBER/}',
    '      <span>&PHONE_COUNTRY_CODE. &PHONE_NUMBER.</span>',
    '    {endif/}',
    '  </div>',
    '</div>')),
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '<a href="&EDIT_URL!RAW.">&FIRST_NAME. &LAST_NAME.</a>')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197157123897049066)
,p_name=>'CAREER_LEVEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CAREER_LEVEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197157040821049065)
,p_name=>'CITY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CITY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197157353029049068)
,p_name=>'COST_CENTER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COST_CENTER_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>110
,p_is_group=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(2198750204862806355)
,p_lov_display_extra=>true
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197156862086049063)
,p_name=>'COUNTRY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COUNTRY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197417867026807112)
,p_name=>'COUNTRY_CODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COUNTRY_CODE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>230
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197157621623049071)
,p_name=>'DIRECT_REPORTS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DIRECT_REPORTS'
,p_data_type=>'NUMBER'
,p_display_sequence=>140
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2198733315975740441)
,p_name=>'EDIT_URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EDIT_URL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>220
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197156608285049061)
,p_name=>'EMAIL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMAIL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197417914689807113)
,p_name=>'EMPLOYEE_GROUPS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMPLOYEE_GROUPS'
,p_data_type=>'CLOB'
,p_display_sequence=>240
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197156353557049058)
,p_name=>'EMPLOYEE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMPLOYEE_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197156407832049059)
,p_name=>'FIRST_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FIRST_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>true
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197418095382807114)
,p_name=>'GENDER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GENDER'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>250
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197156905014049064)
,p_name=>'GEOGRAPHIC_REGION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GEOGRAPHIC_REGION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2198732279572740430)
,p_name=>'INITIALS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INITIALS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>210
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197157263460049067)
,p_name=>'JOB_TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'JOB_TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197156569730049060)
,p_name=>'LAST_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>true
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197157400225049069)
,p_name=>'MANAGER_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MANAGER_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>120
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197157515399049070)
,p_name=>'ORG_SIZE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ORG_SIZE'
,p_data_type=>'NUMBER'
,p_display_sequence=>130
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2198731844186740426)
,p_name=>'PERMALINK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PERMALINK'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>190
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197157691528049072)
,p_name=>'PHONE_COUNTRY_CODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PHONE_COUNTRY_CODE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>150
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197157844133049073)
,p_name=>'PHONE_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PHONE_NUMBER'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>160
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2198731674069740424)
,p_name=>'PROFILE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROFILE'
,p_data_type=>'CLOB'
,p_display_sequence=>170
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2198731786075740425)
,p_name=>'TAGS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TAGS'
,p_data_type=>'CLOB'
,p_display_sequence=>180
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2198731960675740427)
,p_name=>'TIMEZONE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIMEZONE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>200
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197156714635049062)
,p_name=>'USER_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USER_ID'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(2197421327627807147)
,p_region_id=>wwv_flow_imp.id(2197156278645049057)
,p_position_id=>365743646611256091
,p_display_sequence=>10
,p_template_id=>365744248288287220
,p_label=>'Details'
,p_static_id=>'details'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::P4_EMPLOYEE_ID:&EMPLOYEE_ID.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-info-circle-o'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2198733228014740440)
,p_name=>'P3_DUMMY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2198730435967730657)
,p_item_display_point=>'SMART_FILTERS'
,p_prompt=>'Dummy'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1612549609962752680
,p_item_css_classes=>'u-hidden'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(2198344427383573804)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2197156156012049056)
,p_name=>'P3_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2198730435967730657)
,p_item_display_point=>'SMART_FILTERS'
,p_prompt=>'Search'
,p_placeholder=>'Search by name, email or last digits of phone number'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>72
,p_field_template=>2044213549383960320
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'SEARCH',
  'trim_spaces', 'BOTH')).to_clob
,p_quick_pick_type=>'SQL_QUERY'
,p_quick_pick_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select ''M\00FCller''                              d, ''M\00FCller''                              r from sys.dual                                                             union all '),
unistr('select ''city:'' || lower(city) || '' m\00FCller''   d, ''city:'' || lower(city) || '' m\00FCller''   r from eba_srch_txt_employees where last_name = ''Muller'' and rownum=1   union all'),
'select ''New York''                            d, ''New York''                            r from sys.dual                                                             union all',
'select ''France''                              d, ''France''                              r from sys.dual                                                             union all',
'select ''email:'' || email                     d, ''email:'' || email                     r from eba_srch_txt_employees where country = ''France''   and rownum = 1 union all',
'select ''phone:'' || substr(phone_number, -3 ) d, ''phone:'' || substr(phone_number, -3 ) r from eba_srch_txt_employees where country = ''Germany''  and rownum = 1',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2198732508910740433)
,p_name=>'KeyDown'
,p_static_id=>'keydown'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_SEARCH'
,p_bind_type=>'bind'
,p_execution_type=>'DEBOUNCE'
,p_execution_time=>250
,p_execution_immediate=>false
,p_bind_event_type=>'keyup'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2198732660807740434)
,p_event_id=>wwv_flow_imp.id(2198732508910740433)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2197156278645049057)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'$v("P3_SEARCH").length >= 2 || $v("P3_SEARCH").length === 0'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2198732015543740428)
,p_name=>'Search'
,p_static_id=>'search'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_SEARCH'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2198732105217740429)
,p_event_id=>wwv_flow_imp.id(2198732015543740428)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2197156278645049057)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
