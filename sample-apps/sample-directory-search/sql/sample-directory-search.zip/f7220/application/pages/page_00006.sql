prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Employee Faceted Search'
,p_alias=>'EMPLOYEE-FACETED-SEARCH'
,p_step_title=>'Employee Faceted Search'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2530071015796209513
,p_page_template_options=>'#DEFAULT#:t-PageBody--noContentPadding'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>Search using Faceted Search</h3>',
'<p>',
'    This page provides full text search on the employee directory as part of a Faceted Search region. The ',
'    <em>Search</em> facet has its <strong>Search Type</strong> attribute set to <strong>Oracle Text</strong>,  ',
'    which allows to provide exact, fuzzy or name search. The',
'    index is configured to first do exact search on names, following by fuzzy search on names, ',
'    and then on other attributes,  so that the most relevant results are first.',
'</p>',
'<p><strong>Search Options</strong></p>',
'<dl>',
unistr('    <dt><code>M\00FCller</code></dt>'),
unistr('    <dd>Search for <strong>M\00FCller</strong> across all attributes, starting with the name. Apply normal and fuzzy search.</dd>'),
'    <dt><code>email:jochen.margraf.30@example.invalid</code></dt>',
'    <dd>The <strong>email</strong> prefix initiates exact search for the given email address. Useful if that address is known.</dd>',
'    <dt><code>phone:4711</code> or <code>4711</code></dt>',
'    <dd>If a plain number is detected, then the search is done for phone numbers ending with the provided number.</dd>',
'    <dt><code>New York</code></dt>',
'    <dd>If the name of a known city is entered, then the search is done for the city.</dd>',
'    <dt><code>United States</code></dt>',
'    <dd>If the name of a known country is entered, then the search is done for the country.</dd>',
'</dl>',
'',
''))
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2235768436890012902)
,p_plug_name=>'Employees'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon:t-Form--noPadding'
,p_plug_template=>2677445476673898083
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_landmark_type=>'search'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2236028211814719002)
,p_plug_name=>'Results'
,p_static_id=>'results'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select EMPLOYEE_ID,',
'       FIRST_NAME,',
'       LAST_NAME,',
'       substr(LAST_NAME, 1, 1) || substr(FIRST_NAME, 1, 1) as INITIALS,',
'       EMAIL,',
'       USER_ID,',
'       COUNTRY,',
'       COUNTRY_CODE,',
'       GEOGRAPHIC_REGION,',
'       CITY,',
'       CAREER_LEVEL,',
'       JOB_TITLE,',
'       COST_CENTER_ID,',
'       COST_CENTER_DESCRIPTION,',
'       MANAGER_ID,',
'       ORG_SIZE,',
'       DIRECT_REPORTS,',
'       PHONE_COUNTRY_CODE,',
'       PHONE_NUMBER,',
'       PROFILE,',
'       TAGS,',
'       PERMALINK,',
'       TIMEZONE,',
'       employee_groups',
'  from eba_srch_txt_EMPLOYEE_ORG_v'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_INITIALS', 'INITIALS',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_SIZE', 't-Avatar--sm',
  'AVATAR_TYPE', 'initials',
  'DESCRIPTION', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<div class="u-flex u-flex-col u-gap-1">',
    '  <div>',
    '    <strong>&JOB_TITLE.</strong>',
    '    {if ?COST_CENTER_DESCRIPTION/} &middot; &COST_CENTER_DESCRIPTION.{endif/}',
    '  </div>',
    '',
    '  <div class="u-flex u-flex-wrap u-align-items-center u-gap-x-4 u-gap-y-1">',
    '    <span class="u-inline-flex u-align-items-center u-gap-2">',
    '      <span class="fa fa-flag-&COUNTRY_CODE!ATTR." aria-hidden="true"></span>',
    '      <span>&COUNTRY.</span>',
    '    </span>',
    '',
    '    {if ?EMAIL/}',
    '      <a href="mailto:&EMAIL!ATTR." class="u-wrap-anywhere">&EMAIL.</a>',
    '    {endif/}',
    '',
    '    <span>&DIRECT_REPORTS. Direct Reports</span>',
    '  </div>',
    '</div>')),
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'MISC', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{loop TAGS/}',
    '  <span class="a-Chip a-Chip--applied u-pointer-events-none u-text-body-2xs">&APEX$ITEM.</span>',
    '{endloop/}')),
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '<a href="f?p=&APP_ID.:4:&APP_SESSION.::::P4_EMPLOYEE_ID:&EMPLOYEE_ID.">&FIRST_NAME. &LAST_NAME.</a>')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236029190761719011)
,p_name=>'CAREER_LEVEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CAREER_LEVEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236029019134719010)
,p_name=>'CITY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CITY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236029418950719014)
,p_name=>'COST_CENTER_DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COST_CENTER_DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>120
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236029300487719013)
,p_name=>'COST_CENTER_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COST_CENTER_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>110
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236028804623719008)
,p_name=>'COUNTRY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COUNTRY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197417784594807111)
,p_name=>'COUNTRY_CODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COUNTRY_CODE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>230
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236029757078719017)
,p_name=>'DIRECT_REPORTS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DIRECT_REPORTS'
,p_data_type=>'NUMBER'
,p_display_sequence=>150
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236028604947719006)
,p_name=>'EMAIL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMAIL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2197417481135807108)
,p_name=>'EMPLOYEE_GROUPS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMPLOYEE_GROUPS'
,p_data_type=>'CLOB'
,p_display_sequence=>220
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236028335499719003)
,p_name=>'EMPLOYEE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMPLOYEE_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236028489699719004)
,p_name=>'FIRST_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FIRST_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>true
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236028995439719009)
,p_name=>'GEOGRAPHIC_REGION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GEOGRAPHIC_REGION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2474884356562580803)
,p_name=>'INITIALS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INITIALS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>240
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236029213697719012)
,p_name=>'JOB_TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'JOB_TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236028568124719005)
,p_name=>'LAST_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>true
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236029548504719015)
,p_name=>'MANAGER_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MANAGER_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>130
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236029686422719016)
,p_name=>'ORG_SIZE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ORG_SIZE'
,p_data_type=>'NUMBER'
,p_display_sequence=>140
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236030290160719022)
,p_name=>'PERMALINK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PERMALINK'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>200
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236029876968719018)
,p_name=>'PHONE_COUNTRY_CODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PHONE_COUNTRY_CODE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>160
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236029907114719019)
,p_name=>'PHONE_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PHONE_NUMBER'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>170
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236030084162719020)
,p_name=>'PROFILE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROFILE'
,p_data_type=>'CLOB'
,p_display_sequence=>180
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236030149665719021)
,p_name=>'TAGS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TAGS'
,p_data_type=>'CLOB'
,p_display_sequence=>190
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236030338339719023)
,p_name=>'TIMEZONE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIMEZONE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>210
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2236028767062719007)
,p_name=>'USER_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USER_ID'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2236030729780719027)
,p_plug_name=>'Search'
,p_static_id=>'search'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(2236028211814719002)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2236031147056719031)
,p_name=>'P6_COUNTRY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2236030729780719027)
,p_prompt=>'Country'
,p_source=>'COUNTRY'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2236031275123719032)
,p_name=>'P6_EMPLOYEE_GROUPS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2236030729780719027)
,p_prompt=>'Groups'
,p_source=>'EMPLOYEE_GROUPS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'GROUPS'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
,p_multi_value_type=>'JSON_ARRAY'
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2236030925838719029)
,p_name=>'P6_JOB_TITLE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2236030729780719027)
,p_prompt=>'Job Title'
,p_source=>'JOB_TITLE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2236031078035719030)
,p_name=>'P6_REGION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2236030729780719027)
,p_prompt=>'Region'
,p_source=>'GEOGRAPHIC_REGION'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2236030859223719028)
,p_name=>'P6_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2236030729780719027)
,p_prompt=>'Search'
,p_source=>'LAST_NAME'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'external_page_item', 'P6_SEARCH_FIELD',
  'input_field', 'PAGE_ITEM',
  'search_type', 'ORACLE_TEXT')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2235772925151012929)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2235768436890012902)
,p_button_name=>'RESET'
,p_static_id=>'reset'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&APP_SESSION.::&DEBUG.:RR,6::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2474884162853580801)
,p_name=>'P6_SEARCH_FIELD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2235768436890012902)
,p_item_display_point=>'SMART_FILTERS'
,p_prompt=>'Search Field'
,p_placeholder=>'Search...'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>72
,p_field_template=>2044213549383960320
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'SEARCH',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp.component_end;
end;
/
