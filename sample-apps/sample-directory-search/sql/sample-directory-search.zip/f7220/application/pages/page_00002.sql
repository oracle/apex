prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Employees Search Region'
,p_alias=>'EMPLOYEES'
,p_step_title=>'Employees Search Region'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Set Search Field to be XXL */',
'.t-Form--xlarge, .t-Form-fieldContainer--xlarge {',
'    --ut-field-input-icon-size: 1.5rem;',
'    --ut-field-input-icon-padding-x: .75rem;',
'    --a-field-input-padding-y: 1rem;',
'    --a-field-input-padding-x: 1rem;',
'}',
'',
'/* Fix wrapping of Quick Picks during page load */',
'.t-Form-itemWrapper:has(.apex-quick-picks) {',
'    flex-wrap: wrap;',
'',
'   .apex-quick-picks {',
'        order: 5;',
'   }',
'}',
'',
'/* Add margin to quick picks and center */',
'.apex-quick-picks {',
'    margin-block-start: .25rem;',
'    text-align: center;',
'}',
'',
'/* Result tweaks */',
'.a-SearchResults-list {',
'  --a-resultsitem-background-color: var(--ut-component-toolbar-background-color);',
'  --a-searchresults-gap: .5rem;',
'}',
'',
'/* Animate Results In */',
'.t-ResultsRegion {',
'  interpolate-size: allow-keywords;',
'  block-size: 0;',
'  overflow: clip;',
'  transition: block-size 1s ease;',
'',
'  &:has(.a-SearchResults-item) {',
'    block-size: auto;',
'  }',
'}'))
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#:t-DeferredRendering:t-PageBody--verticalMiddle'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>Search Configuration and Search Region</h3>',
'<p>',
'    This page provides full text search on the employee directory using the <code>Employees</code> <strong>Search Configuration</strong>. ',
'    The Search Configuration is based on an Oracle Text index, which allows to provide exact, fuzzy or name search. The',
'    index is configured to first do exact search on names, following by fuzzy search on names, and then on other attributes, ',
'    so that the most relevant results are first.',
'</p>',
'<p>',
'    See the <em>Quick Picks</em> under the search field for examples.',
'</p>',
'<p><strong>Search Options</strong></p>',
'<dl>',
unistr('    <dt><code>M\00FCller</code></dt>'),
unistr('    <dd>Search for <strong>M\00FCller</strong> across all attributes, starting with the name. Apply normal and fuzzy search.</dd>'),
'    <dt><code>email:jochen.margraf.30@example.invalid</code></dt>',
'    <dd>The <strong>email</strong> prefix initiates exact search for the given email address. Useful if that address is known.</dd>',
'    <dt><code>phone:4711</code> or <code>4711</code></dt>',
'    <dd>If a plain number is detected, then the search is done for phone numbers ending with the provided number.</dd>',
'    <dt><code>New York</code></dt>',
'    <dd>If the name of a known city is entered, then the search is done for the city.</dd>',
'    <dt><code>United States</code></dt>',
'    <dd>If the name of a known country is entered, then the search is done for the country.</dd>',
'</dl>',
'',
''))
,p_page_component_map=>'26'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2474884208274580802)
,p_plug_name=>'Employees'
,p_static_id=>'employees'
,p_region_css_classes=>'mxw800 margin-auto'
,p_region_template_options=>'#DEFAULT#:margin-top-md:margin-bottom-md'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_landmark_type=>'search'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2198525758217939602)
,p_plug_name=>'Search Results'
,p_static_id=>'search-results'
,p_region_css_classes=>'mxw800 margin-auto'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1559166540494593256
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'custom_layout', 'N',
  'lazy_loading', 'Y',
  'minimum_characters', '1',
  'no_results_found_message', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<p class="u-tC u-margin-5 u-text-muted-color">No results found. Please check your spelling or try selecting one of the QuickPick suggestions above.</p>',
    '')),
  'results_per_page', '30',
  'results_per_page_type', 'STATIC',
  'search_as_you_type', 'Y',
  'search_page_item', 'P2_SEARCH',
  'show_result_count', 'N',
  'use_pagination', 'Y')).to_clob
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(2198526146385939604)
,p_region_id=>wwv_flow_imp.id(2198525758217939602)
,p_search_config_id=>wwv_flow_imp.id(2198523431254919514)
,p_use_as_initial_result=>false
,p_display_sequence=>10
,p_name=>'Employees'
,p_static_id=>'employees'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2198526696383939612)
,p_name=>'P2_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2474884208274580802)
,p_prompt=>'Search'
,p_placeholder=>'Search by name, email or last digits of phone number.'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_field_template=>2044213549383960320
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge:t-Form-fieldContainer--noPadding'
,p_warn_on_unsaved_changes=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'SEARCH',
  'trim_spaces', 'BOTH')).to_clob
,p_quick_pick_type=>'SQL_QUERY'
,p_quick_pick_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select ''M\00FCller''                              d, ''M\00FCller''                              r from sys.dual                                                             union all '),
unistr('select ''city:'' || lower(city) || '' m\00FCller''   d, ''city:'' || lower(city) || '' m\00FCller''   r from eba_srch_txt_employees where last_name = ''Muller'' and rownum=1   union all'),
'select ''New York''                            d, ''New York''                            r from sys.dual                                                             union all',
'select ''France''                              d, ''France''                              r from sys.dual                                                             union all',
'select ''email:'' || email                     d, ''email:'' || email                     r from eba_srch_txt_employees where country = ''France''   and rownum = 1 union all',
'select ''phone:'' || substr(phone_number, -3 ) d, ''phone:'' || substr(phone_number, -3 ) r from eba_srch_txt_employees where country = ''Germany''  and rownum = 1',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2197155817565049053)
,p_name=>'Refresh Results on Change (click on Quick Pick)'
,p_static_id=>'new'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_SEARCH'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2197155948926049054)
,p_event_id=>wwv_flow_imp.id(2197155817565049053)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2198525758217939602)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
