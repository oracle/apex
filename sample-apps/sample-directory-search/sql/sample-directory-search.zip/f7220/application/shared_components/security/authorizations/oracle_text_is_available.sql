prompt --application/shared_components/security/authorizations/oracle_text_is_available
begin
--   Manifest
--     SECURITY SCHEME: Oracle Text is available
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(2502695747460736)
,p_name=>'Oracle Text is available'
,p_static_id=>'oracle-text-is-available'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'plsql_function_body', wwv_flow_string.join(wwv_flow_t_varchar2(
    'declare',
    '    l_idx_exists number;',
    'begin',
    '    execute immediate q''#',
    'select 1',
    '  from sys.user_indexes',
    ' where index_name      = ''FT_EBA_SRCH_TXT_EMPS_FTIDX_IDX''',
    '   and table_name      = ''EBA_SRCH_TXT_EMPLOYEES''',
    '   and domidx_status   = ''VALID''',
    '   and domidx_opstatus = ''VALID''',
    '   and rownum          = 1#''',
    '   into l_idx_exists;',
    '',
    '    return true;',
    'exception',
    '    when others then',
    '        return false;',
    'end;',
    '',
    '')))).to_clob
,p_version_scn=>'SH256:sXMOC4p4MJvQQaZJXHWuBkAIovyLSemKXW0f_gI4acQ'
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
