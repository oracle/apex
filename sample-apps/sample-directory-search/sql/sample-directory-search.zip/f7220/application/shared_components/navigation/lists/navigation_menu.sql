prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2198345684502573823)
,p_name=>'Navigation Menu'
,p_static_id=>'navigation-menu'
,p_version_scn=>'SH256:kFQH1C_E0RDNQp2pyJkNh4mCNQ39X0LUaVn3oDQLBZk'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2198146794081451774)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Data and Index'
,p_static_id=>'administration'
,p_list_item_link_target=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-sign-in'
,p_list_text_01=>'Review summary on employee data and the Oracle Text index.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'201'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2235768066656012900)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Faceted Search'
,p_static_id=>'employee-faceted-search'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6,RR:::'
,p_list_item_icon=>'fa-table-search'
,p_list_text_01=>'<strong>Faceted Search</strong> utilizing Oracle Text for the search facet.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2198524507349939584)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Search (Search Region)'
,p_static_id=>'employees'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RP,2,RR:::'
,p_list_item_icon=>'fa-search'
,p_list_text_01=>'Employee Search using Oracle Text. Uses APEX <strong>Search Configuration</strong> and a <strong>Search Region</strong>.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2198730060860730649)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Search (Content Row)'
,p_static_id=>'employees-content-row'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3,RR:::'
,p_list_item_icon=>'fa-media-list'
,p_list_text_01=>'Employee Search using <strong>Content Row</strong> region, based on a SQL Query using Oracle Text CONTAINS.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2198357077564574023)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_static_id=>'home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_text_01=>'Application Home Page'
,p_list_text_04=>'home-page-item'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
