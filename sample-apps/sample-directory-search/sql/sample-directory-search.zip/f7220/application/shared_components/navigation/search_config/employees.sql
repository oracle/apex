prompt --application/shared_components/navigation/search_config/employees
begin
--   Manifest
--     SEARCH CONFIG: Employees
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(2198523431254919514)
,p_label=>'Employees'
,p_static_id=>'employees'
,p_search_type=>'TEXT_MANUAL'
,p_query_type=>'SQL'
,p_query_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select employee_id,',
'       first_name,',
'       last_name,',
'       first_name || '' '' || last_name as name,',
'       email,',
'       user_id,',
'       country,',
'       country_code,',
'       geographic_region,',
'       city,',
'       career_level,',
'       job_title,',
'       cost_center_id,',
'       manager_id,',
'       org_size,',
'       direct_reports,',
'       phone_country_code,',
'       phone_number,',
'       profile,',
'       tags,',
'       permalink,',
'       to_char( systimestamp at time zone timezone, ''HH24:MI'' ) as current_local_time,',
'       timezone',
'  from eba_srch_txt_employees',
''))
,p_oratext_index_column_name=>'LAST_NAME'
,p_oratext_function_type=>'CUSTOM'
,p_oratext_function=>'eba_search_text_helper.get_name_search_query'
,p_pk_column_name=>'EMPLOYEE_ID'
,p_title_column_name=>'NAME'
,p_subtitle_column_name=>'CITY'
,p_description_column_name=>'JOB_TITLE'
,p_custom_01_column_name=>'PHONE_NUMBER'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.::P4_EMPLOYEE_ID:&EMPLOYEE_ID.'
,p_icon_source_type=>'INITIALS'
,p_default_row_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<article class="a-ResultsItem u-flex u-align-items-center u-gap-4 &RESULT_CSS_CLASSES!ATTR.">',
'  {if ?ICON_VALUE/}',
'    <span class="t-Avatar t-Avatar--initials t-Avatar--md u-color u-flex-shrink-0"',
'          aria-hidden="true">&ICON_VALUE.</span>',
'  {endif/}',
'',
'  <div class="u-flex u-flex-col u-gap-1 u-min-w-0">',
'    <h3 class="a-ResultsItem-title u-margin-0 u-text-md">',
'      <a href="&LINK!ATTR.">&NAME.</a>',
'    </h3>',
'',
'    <div class="u-text-sm u-text-secondary">&JOB_TITLE.</div>',
'',
'    <div class="u-flex u-flex-wrap u-align-items-center u-gap-x-4 u-gap-y-1 u-text-sm u-text-secondary">',
'      <span class="u-inline-flex u-align-items-center u-gap-2"',
'            {if ?CURRENT_LOCAL_TIME/}title="Local time: &CURRENT_LOCAL_TIME!ATTR. &TIMEZONE!ATTR."{endif/}>',
'        <span class="fa fa-flag-&COUNTRY_CODE!ATTR." aria-hidden="true"></span>',
'        <span>{if ?CITY/}&CITY. &middot; {endif/}&COUNTRY.</span>',
'      </span>',
'',
'      {if ?EMAIL/}',
'        <a href="mailto:&EMAIL!ATTR." class="u-wrap-anywhere">&EMAIL.</a>',
'      {endif/}',
'',
'      {if ?PHONE_NUMBER/}',
'        <span>&PHONE_COUNTRY_CODE. &PHONE_NUMBER.</span>',
'      {endif/}',
'    </div>',
'  </div>',
'</article>'))
,p_version_scn=>'SH256:_oxQ1LqH7p9h3BgPSDc4hDeRp3Iz69tqZBXV9djpNTw'
);
wwv_flow_imp.component_end;
end;
/
