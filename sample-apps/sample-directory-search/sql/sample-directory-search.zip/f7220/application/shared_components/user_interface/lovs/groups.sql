prompt --application/shared_components/user_interface/lovs/groups
begin
--   Manifest
--     GROUPS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(4615446328374517747)
,p_lov_name=>'GROUPS'
,p_static_id=>'groups'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'EBA_SRCH_TXT_GROUPS'
,p_return_column_name=>'GROUP_ID'
,p_display_column_name=>'GROUP_NAME'
,p_default_sort_column_name=>'GROUP_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'SH256:LhvA6a3WhqXmuvyt_-yns7pcjOKpNw6fuUfTYbR3eeA'
);
wwv_flow_imp.component_end;
end;
/
