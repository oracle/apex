prompt --application/shared_components/user_interface/lovs/employees_first_name
begin
--   Manifest
--     EMPLOYEES.FIRST_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2198760575632847847)
,p_lov_name=>'EMPLOYEES.FIRST_NAME'
,p_static_id=>'employees-first-name'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'EBA_SRCH_TXT_EMPLOYEES'
,p_return_column_name=>'EMPLOYEE_ID'
,p_display_column_name=>'FIRST_NAME'
,p_default_sort_column_name=>'FIRST_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'SH256:_RYNVe2JLwed7-GKtvu_ttYIBzrz4hqVsH15plbXPJU'
);
wwv_flow_imp.component_end;
end;
/
