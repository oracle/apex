prompt --application/shared_components/user_interface/lovs/cost_centers_cost_center_description
begin
--   Manifest
--     COST_CENTERS.COST_CENTER_DESCRIPTION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2198759828530847845)
,p_lov_name=>'COST_CENTERS.COST_CENTER_DESCRIPTION'
,p_static_id=>'cost-centers-cost-center-description'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'EBA_SRCH_TXT_COST_CENTERS'
,p_return_column_name=>'COST_CENTER_ID'
,p_display_column_name=>'COST_CENTER_DESCRIPTION'
,p_default_sort_column_name=>'COST_CENTER_DESCRIPTION'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'SH256:g6GPFNILiF4lDJRpYPQLU7TC40xa_29LP418x3U80Rc'
);
wwv_flow_imp.component_end;
end;
/
