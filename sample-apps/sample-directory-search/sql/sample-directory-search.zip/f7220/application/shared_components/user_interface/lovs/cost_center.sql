prompt --application/shared_components/user_interface/lovs/cost_center
begin
--   Manifest
--     COST_CENTER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2198750204862806355)
,p_lov_name=>'COST_CENTER'
,p_static_id=>'cost-center'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select cost_center_description, cost_center_id',
'  from eba_srch_txt_cost_centers',
' '))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'COST_CENTER_ID'
,p_display_column_name=>'COST_CENTER_DESCRIPTION'
,p_default_sort_column_name=>'COST_CENTER_DESCRIPTION'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'SH256:UGRr7vjAlhdjcZY1dPjOJYKyAAELuVQszkNZb8i5lsU'
);
wwv_flow_imp.component_end;
end;
/
