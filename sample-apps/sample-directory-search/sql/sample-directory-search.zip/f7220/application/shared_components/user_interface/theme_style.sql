prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 42
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(2457324691270432357)
,p_theme_id=>42
,p_name=>'Directory'
,p_static_id=>'directory'
,p_css_file_urls=>'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#'
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Iris.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Accent-Pillar":"ocean","@g_Header_Style":"pillar-light","@g_Nav_Style":"light","@g_FontFamily":"oracle_sans"},"customCSS":"","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#2457324691270432357.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
