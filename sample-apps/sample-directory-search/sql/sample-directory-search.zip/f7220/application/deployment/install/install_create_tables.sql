prompt --application/deployment/install/install_create_tables
begin
--   Manifest
--     INSTALL: INSTALL-Create Tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_srch_txt_cost_centers ('||wwv_flow.LF||
'  cost_center_id number default on null to_number(sys_guid(';
wwv_flow_imp.g_varchar2_table(2) := '), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'    constraint cost_center_id_pk primary key,'||wwv_flow.LF||
'  cost_center_d';
wwv_flow_imp.g_varchar2_table(3) := 'escription varchar2(400 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_srch_txt_groups ('||wwv_flow.LF||
'  group_id number defa';
wwv_flow_imp.g_varchar2_table(4) := 'ult on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'    constraint group_id_pk pri';
wwv_flow_imp.g_varchar2_table(5) := 'mary key,'||wwv_flow.LF||
'  group_name varchar2(200 char) not null,'||wwv_flow.LF||
'  group_description varchar2(400 char),'||wwv_flow.LF||
'  constr';
wwv_flow_imp.g_varchar2_table(6) := 'aint groups_group_name_uk unique (group_name)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_srch_txt_employees ('||wwv_flow.LF||
'  employee_i';
wwv_flow_imp.g_varchar2_table(7) := 'd number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'    constraint em';
wwv_flow_imp.g_varchar2_table(8) := 'ployee_id_pk primary key,'||wwv_flow.LF||
'  first_name varchar2(100 char) not null,'||wwv_flow.LF||
'  last_name varchar2(100 char) n';
wwv_flow_imp.g_varchar2_table(9) := 'ot null,'||wwv_flow.LF||
'  email varchar2(320 char) not null,'||wwv_flow.LF||
'  user_id varchar2(255 char) not null,'||wwv_flow.LF||
'  country varch';
wwv_flow_imp.g_varchar2_table(10) := 'ar2(100 char),'||wwv_flow.LF||
'  country_code varchar2( 2 char),'||wwv_flow.LF||
'  geographic_region varchar2(100 char),'||wwv_flow.LF||
'  city varc';
wwv_flow_imp.g_varchar2_table(11) := 'har2(100 char),'||wwv_flow.LF||
'  career_level varchar2(50 char),'||wwv_flow.LF||
'  job_title varchar2(200 char),'||wwv_flow.LF||
'  cost_center_id n';
wwv_flow_imp.g_varchar2_table(12) := 'umber,'||wwv_flow.LF||
'  manager_id number,'||wwv_flow.LF||
'  org_size number,'||wwv_flow.LF||
'  direct_reports number,'||wwv_flow.LF||
'  phone_country_code varchar';
wwv_flow_imp.g_varchar2_table(13) := '2(8 char),'||wwv_flow.LF||
'  phone_number varchar2(32 char),'||wwv_flow.LF||
'  profile json,'||wwv_flow.LF||
'  tags json,'||wwv_flow.LF||
'  employee_groups json,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(14) := 'permalink varchar2(1000 char),'||wwv_flow.LF||
'  timezone varchar2(64 char),'||wwv_flow.LF||
'  gender varchar2(1 char),'||wwv_flow.LF||
'  constraint';
wwv_flow_imp.g_varchar2_table(15) := ' employees_cost_center_id_fk foreign key (cost_center_id)'||wwv_flow.LF||
'    references eba_srch_txt_cost_centers (';
wwv_flow_imp.g_varchar2_table(16) := 'cost_center_id),'||wwv_flow.LF||
'  constraint employees_manager_id_fk foreign key (manager_id)'||wwv_flow.LF||
'    references eba_sr';
wwv_flow_imp.g_varchar2_table(17) := 'ch_txt_employees (employee_id),'||wwv_flow.LF||
'  constraint employees_email_uk unique (email),'||wwv_flow.LF||
'  constraint employe';
wwv_flow_imp.g_varchar2_table(18) := 'es_user_id_uk unique (user_id),'||wwv_flow.LF||
'  constraint employees_org_size_ck check (org_size is null or org_si';
wwv_flow_imp.g_varchar2_table(19) := 'ze >= 0),'||wwv_flow.LF||
'  constraint employees_direct_reports_ck check (direct_reports is null or direct_reports >';
wwv_flow_imp.g_varchar2_table(20) := '= 0)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index employees_cost_center_i on eba_srch_txt_employees (cost_center_id);'||wwv_flow.LF||
'create ind';
wwv_flow_imp.g_varchar2_table(21) := 'ex employees_manager_i on eba_srch_txt_employees (manager_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace  view eba_srch_txt';
wwv_flow_imp.g_varchar2_table(22) := '_employee_org_v as'||wwv_flow.LF||
'select'||wwv_flow.LF||
'  e.employee_id,'||wwv_flow.LF||
'  e.first_name,'||wwv_flow.LF||
'  e.last_name,'||wwv_flow.LF||
'  e.email,'||wwv_flow.LF||
'  e.user_id,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(23) := 'e.country,'||wwv_flow.LF||
'  e.country_code,'||wwv_flow.LF||
'  e.geographic_region,'||wwv_flow.LF||
'  e.city,'||wwv_flow.LF||
'  e.career_level,'||wwv_flow.LF||
'  e.job_title,'||wwv_flow.LF||
'  e.c';
wwv_flow_imp.g_varchar2_table(24) := 'ost_center_id,'||wwv_flow.LF||
'  cc.cost_center_description,'||wwv_flow.LF||
'  e.manager_id,'||wwv_flow.LF||
'  e.org_size,'||wwv_flow.LF||
'  e.direct_reports,'||wwv_flow.LF||
'  e.p';
wwv_flow_imp.g_varchar2_table(25) := 'hone_country_code,'||wwv_flow.LF||
'  e.phone_number,'||wwv_flow.LF||
'  e.profile,'||wwv_flow.LF||
'  e.tags,'||wwv_flow.LF||
'  e.employee_groups,'||wwv_flow.LF||
'  e.permalink,'||wwv_flow.LF||
'  e.';
wwv_flow_imp.g_varchar2_table(26) := 'timezone'||wwv_flow.LF||
'from eba_srch_txt_employees e'||wwv_flow.LF||
'left join eba_srch_txt_cost_centers cc'||wwv_flow.LF||
'  on cc.cost_center_id';
wwv_flow_imp.g_varchar2_table(27) := ' = e.cost_center_id'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE TABLE eba_srch_txt_countries ('||wwv_flow.LF||
'  country_code_alpha2       CHAR(2 CHAR';
wwv_flow_imp.g_varchar2_table(28) := ') CONSTRAINT countries_pk PRIMARY KEY,'||wwv_flow.LF||
'  country_code_alpha3       CHAR(3 CHAR) NOT NULL,'||wwv_flow.LF||
'  region  ';
wwv_flow_imp.g_varchar2_table(29) := '                  VARCHAR2(20 CHAR) NOT NULL,'||wwv_flow.LF||
'  country_name              VARCHAR2(200 CHAR) NOT NUL';
wwv_flow_imp.g_varchar2_table(30) := 'L,'||wwv_flow.LF||
'  country_name_english      VARCHAR2(200 CHAR) NOT NULL,'||wwv_flow.LF||
'  capital_city              VARCHAR2(150';
wwv_flow_imp.g_varchar2_table(31) := ' CHAR),'||wwv_flow.LF||
'  estimated_population      NUMBER(15,0) NOT NULL,'||wwv_flow.LF||
'  estimated_population_year NUMBER(4) NOT';
wwv_flow_imp.g_varchar2_table(32) := ' NULL,'||wwv_flow.LF||
'  official_or_common_language VARCHAR2(500 CHAR) NOT NULL,'||wwv_flow.LF||
'  description               VARCHA';
wwv_flow_imp.g_varchar2_table(33) := 'R2(500 CHAR) NOT NULL,'||wwv_flow.LF||
'  CONSTRAINT countries_alpha3_uk UNIQUE (country_code_alpha3),'||wwv_flow.LF||
'  CONSTRAINT c';
wwv_flow_imp.g_varchar2_table(34) := 'ountries_alpha2_ck CHECK (country_code_alpha2 = UPPER(country_code_alpha2)),'||wwv_flow.LF||
'  CONSTRAINT countries_';
wwv_flow_imp.g_varchar2_table(35) := 'alpha3_ck CHECK (country_code_alpha3 = UPPER(country_code_alpha3)),'||wwv_flow.LF||
'  CONSTRAINT countries_region_ck';
wwv_flow_imp.g_varchar2_table(36) := ' CHECK (region IN (''Africa'', ''Americas'', ''Antarctica'', ''Asia'', ''Europe'', ''Oceania'')),'||wwv_flow.LF||
'  CONSTRAINT c';
wwv_flow_imp.g_varchar2_table(37) := 'ountries_population_ck CHECK (estimated_population >= 0),'||wwv_flow.LF||
'  CONSTRAINT countries_population_year_ck ';
wwv_flow_imp.g_varchar2_table(38) := 'CHECK (estimated_population_year BETWEEN 1900 AND 2100)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'COMMENT ON TABLE  eba_srch_txt_countries';
wwv_flow_imp.g_varchar2_table(39) := ' IS ''ISO 3166-1 country and territory reference data.'';'||wwv_flow.LF||
'COMMENT ON COLUMN eba_srch_txt_countries.cou';
wwv_flow_imp.g_varchar2_table(40) := 'ntry_code_alpha2 IS ''ISO 3166-1 Alpha-2 code; primary key.'';'||wwv_flow.LF||
'COMMENT ON COLUMN eba_srch_txt_countrie';
wwv_flow_imp.g_varchar2_table(41) := 's.country_code_alpha3 IS ''ISO 3166-1 Alpha-3 code.'';'||wwv_flow.LF||
'COMMENT ON COLUMN eba_srch_txt_countries.region';
wwv_flow_imp.g_varchar2_table(42) := ' IS ''UN M49 broad geographic region.'';'||wwv_flow.LF||
'COMMENT ON COLUMN eba_srch_txt_countries.country_name IS ''Cou';
wwv_flow_imp.g_varchar2_table(43) := 'ntry or territory name in a native/local spelling.'';'||wwv_flow.LF||
'COMMENT ON COLUMN eba_srch_txt_countries.countr';
wwv_flow_imp.g_varchar2_table(44) := 'y_name_english IS ''Country or territory name in common US English.'';'||wwv_flow.LF||
'COMMENT ON COLUMN eba_srch_txt_';
wwv_flow_imp.g_varchar2_table(45) := 'countries.capital_city IS ''Capital city in English; null where no permanent capital is applicable.'';';
wwv_flow_imp.g_varchar2_table(46) := ''||wwv_flow.LF||
'COMMENT ON COLUMN eba_srch_txt_countries.estimated_population IS ''Estimated resident population for';
wwv_flow_imp.g_varchar2_table(47) := ' the associated estimate year.'';'||wwv_flow.LF||
'COMMENT ON COLUMN eba_srch_txt_countries.estimated_population_year ';
wwv_flow_imp.g_varchar2_table(48) := 'IS ''Year represented by estimated_population.'';'||wwv_flow.LF||
'COMMENT ON COLUMN eba_srch_txt_countries.official_or';
wwv_flow_imp.g_varchar2_table(49) := '_common_language IS ''Official or most commonly used language(s).'';'||wwv_flow.LF||
'COMMENT ON COLUMN eba_srch_txt_co';
wwv_flow_imp.g_varchar2_table(50) := 'untries.description IS ''Short country or territory description, limited to 500 characters.'';'||wwv_flow.LF||
''||wwv_flow.LF||
'INSERT';
wwv_flow_imp.g_varchar2_table(51) := ' ALL'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_n';
wwv_flow_imp.g_varchar2_table(52) := 'ame,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, of';
wwv_flow_imp.g_varchar2_table(53) := 'ficial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''AD'', ''AND'', UNISTR(''Europe''), UNISTR(''Andor';
wwv_flow_imp.g_varchar2_table(54) := 'ra''),'||wwv_flow.LF||
'    UNISTR(''Andorra''), UNISTR(''Andorra la Vella''), 83753,'||wwv_flow.LF||
'    2026, UNISTR(''Catalan''),'||wwv_flow.LF||
'    UNI';
wwv_flow_imp.g_varchar2_table(55) := 'STR(''Andorra is located in Southern Europe. Its capital is Andorra la Vella. The primary official or';
wwv_flow_imp.g_varchar2_table(56) := ' common language is Catalan.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_';
wwv_flow_imp.g_varchar2_table(57) := 'code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(58) := ' estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''AE'', ''ARE'', U';
wwv_flow_imp.g_varchar2_table(59) := 'NISTR(''Asia''), UNISTR(''\0627\0644\0625\0645\0627\0631\0627\062A''),'||wwv_flow.LF||
'    UNISTR(''United Arab Emirates''';
wwv_flow_imp.g_varchar2_table(60) := '), UNISTR(''Abu Dhabi''), 11574682,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic''),'||wwv_flow.LF||
'    UNISTR(''United Arab Emirates is lo';
wwv_flow_imp.g_varchar2_table(61) := 'cated in Western Asia. Its capital is Abu Dhabi. The primary official or common language is Arabic.''';
wwv_flow_imp.g_varchar2_table(62) := ')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_';
wwv_flow_imp.g_varchar2_table(63) := 'name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, o';
wwv_flow_imp.g_varchar2_table(64) := 'fficial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''AF'', ''AFG'', UNISTR(''Asia''), UNISTR(''\0627\';
wwv_flow_imp.g_varchar2_table(65) := '0641\063A\0627\0646\0633\062A\0627\0646''),'||wwv_flow.LF||
'    UNISTR(''Afghanistan''), UNISTR(''Kabul''), 45047068,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(66) := ' 2026, UNISTR(''Dari, Pashto, Turkmen''),'||wwv_flow.LF||
'    UNISTR(''Afghanistan is located in Southern Asia. Its cap';
wwv_flow_imp.g_varchar2_table(67) := 'ital is Kabul. Official or common languages include Dari, Pashto, and Turkmen.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch';
wwv_flow_imp.g_varchar2_table(68) := '_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_nam';
wwv_flow_imp.g_varchar2_table(69) := 'e_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_lan';
wwv_flow_imp.g_varchar2_table(70) := 'guage, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''AG'', ''ATG'', UNISTR(''Americas''), UNISTR(''Antigua and Barbuda''),'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(71) := '    UNISTR(''Antigua and Barbuda''), UNISTR(''Saint John''''s''), 94626,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(72) := 'UNISTR(''Antigua and Barbuda is located in Caribbean. Its capital is Saint John''''s. The primary offic';
wwv_flow_imp.g_varchar2_table(73) := 'ial or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, co';
wwv_flow_imp.g_varchar2_table(74) := 'untry_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_populatio';
wwv_flow_imp.g_varchar2_table(75) := 'n,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''AI'', ''A';
wwv_flow_imp.g_varchar2_table(76) := 'IA'', UNISTR(''Americas''), UNISTR(''Anguilla''),'||wwv_flow.LF||
'    UNISTR(''Anguilla''), UNISTR(''The Valley''), 14817,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(77) := '  2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Anguilla is located in Caribbean. Its capital is The Valley. ';
wwv_flow_imp.g_varchar2_table(78) := 'The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    countr';
wwv_flow_imp.g_varchar2_table(79) := 'y_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, es';
wwv_flow_imp.g_varchar2_table(80) := 'timated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALU';
wwv_flow_imp.g_varchar2_table(81) := 'ES ('||wwv_flow.LF||
'    ''AL'', ''ALB'', UNISTR(''Europe''), UNISTR(''Shqip\00EBria''),'||wwv_flow.LF||
'    UNISTR(''Albania''), UNISTR(''Tira';
wwv_flow_imp.g_varchar2_table(82) := 'na''), 2751025,'||wwv_flow.LF||
'    2026, UNISTR(''Albanian''),'||wwv_flow.LF||
'    UNISTR(''Albania is located in Southeast Europe. Its';
wwv_flow_imp.g_varchar2_table(83) := ' capital is Tirana. The primary official or common language is Albanian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_c';
wwv_flow_imp.g_varchar2_table(84) := 'ountries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_engl';
wwv_flow_imp.g_varchar2_table(85) := 'ish, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language,';
wwv_flow_imp.g_varchar2_table(86) := ' description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''AM'', ''ARM'', UNISTR(''Asia''), UNISTR(''\0540\0561\0575\0561\057D\057F\05';
wwv_flow_imp.g_varchar2_table(87) := '61\0576''),'||wwv_flow.LF||
'    UNISTR(''Armenia''), UNISTR(''Yerevan''), 2930915,'||wwv_flow.LF||
'    2026, UNISTR(''Armenian''),'||wwv_flow.LF||
'    UNIS';
wwv_flow_imp.g_varchar2_table(88) := 'TR(''Armenia is located in Western Asia. Its capital is Yerevan. The primary official or common langu';
wwv_flow_imp.g_varchar2_table(89) := 'age is Armenian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3,';
wwv_flow_imp.g_varchar2_table(90) := ' region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_p';
wwv_flow_imp.g_varchar2_table(91) := 'opulation_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''AO'', ''AGO'', UNISTR(''Afric';
wwv_flow_imp.g_varchar2_table(92) := 'a''), UNISTR(''Angola''),'||wwv_flow.LF||
'    UNISTR(''Angola''), UNISTR(''Luanda''), 40215180,'||wwv_flow.LF||
'    2026, UNISTR(''Portugues';
wwv_flow_imp.g_varchar2_table(93) := 'e''),'||wwv_flow.LF||
'    UNISTR(''Angola is located in Middle Africa. Its capital is Luanda. The primary official or ';
wwv_flow_imp.g_varchar2_table(94) := 'common language is Portuguese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, countr';
wwv_flow_imp.g_varchar2_table(95) := 'y_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(96) := '   estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''AQ'', ''ATA'',';
wwv_flow_imp.g_varchar2_table(97) := ' UNISTR(''Antarctica''), UNISTR(''Antarctica''),'||wwv_flow.LF||
'    UNISTR(''Antarctica''), NULL, 0,'||wwv_flow.LF||
'    2024, UNISTR(''No';
wwv_flow_imp.g_varchar2_table(98) := 't applicable''),'||wwv_flow.LF||
'    UNISTR(''Antarctica is located in Antarctic and has no permanent capital. No perm';
wwv_flow_imp.g_varchar2_table(99) := 'anent resident language population is recorded.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_co';
wwv_flow_imp.g_varchar2_table(100) := 'de_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estima';
wwv_flow_imp.g_varchar2_table(101) := 'ted_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES (';
wwv_flow_imp.g_varchar2_table(102) := ''||wwv_flow.LF||
'    ''AR'', ''ARG'', UNISTR(''Americas''), UNISTR(''Argentina''),'||wwv_flow.LF||
'    UNISTR(''Argentina''), UNISTR(''Buenos A';
wwv_flow_imp.g_varchar2_table(103) := 'ires''), 46003734,'||wwv_flow.LF||
'    2026, UNISTR(''Guaran\00ED, Spanish''),'||wwv_flow.LF||
'    UNISTR(''Argentina is located in Sout';
wwv_flow_imp.g_varchar2_table(104) := 'h America. Its capital is Buenos Aires. Official or common languages include Guaran\00ED and Spanish';
wwv_flow_imp.g_varchar2_table(105) := '.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, countr';
wwv_flow_imp.g_varchar2_table(106) := 'y_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year,';
wwv_flow_imp.g_varchar2_table(107) := ' official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''AS'', ''ASM'', UNISTR(''Oceania''), UNISTR(''S';
wwv_flow_imp.g_varchar2_table(108) := '\0101moa Amelika''),'||wwv_flow.LF||
'    UNISTR(''American Samoa''), UNISTR(''Pago Pago''), 45318,'||wwv_flow.LF||
'    2026, UNISTR(''Engl';
wwv_flow_imp.g_varchar2_table(109) := 'ish, Samoan''),'||wwv_flow.LF||
'    UNISTR(''American Samoa is located in Polynesia. Its capital is Pago Pago. Officia';
wwv_flow_imp.g_varchar2_table(110) := 'l or common languages include English and Samoan.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_';
wwv_flow_imp.g_varchar2_table(111) := 'code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, esti';
wwv_flow_imp.g_varchar2_table(112) := 'mated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES';
wwv_flow_imp.g_varchar2_table(113) := ' ('||wwv_flow.LF||
'    ''AT'', ''AUT'', UNISTR(''Europe''), UNISTR(''\00D6sterreich''),'||wwv_flow.LF||
'    UNISTR(''Austria''), UNISTR(''Vienn';
wwv_flow_imp.g_varchar2_table(114) := 'a''), 9107266,'||wwv_flow.LF||
'    2026, UNISTR(''Austro-Bavarian German''),'||wwv_flow.LF||
'    UNISTR(''Austria is located in Central ';
wwv_flow_imp.g_varchar2_table(115) := 'Europe. Its capital is Vienna. The primary official or common language is Austro-Bavarian German.'')'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(116) := '  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_na';
wwv_flow_imp.g_varchar2_table(117) := 'me,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, off';
wwv_flow_imp.g_varchar2_table(118) := 'icial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''AU'', ''AUS'', UNISTR(''Oceania''), UNISTR(''Austr';
wwv_flow_imp.g_varchar2_table(119) := 'alia''),'||wwv_flow.LF||
'    UNISTR(''Australia''), UNISTR(''Canberra''), 27227096,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNIS';
wwv_flow_imp.g_varchar2_table(120) := 'TR(''Australia is located in Australia and New Zealand. Its capital is Canberra. The primary official';
wwv_flow_imp.g_varchar2_table(121) := ' or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, count';
wwv_flow_imp.g_varchar2_table(122) := 'ry_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(123) := '    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''AW'', ''ABW''';
wwv_flow_imp.g_varchar2_table(124) := ', UNISTR(''Americas''), UNISTR(''Aruba''),'||wwv_flow.LF||
'    UNISTR(''Aruba''), UNISTR(''Oranjestad''), 108164,'||wwv_flow.LF||
'    2026, ';
wwv_flow_imp.g_varchar2_table(125) := 'UNISTR(''Dutch, Papiamento''),'||wwv_flow.LF||
'    UNISTR(''Aruba is located in Caribbean. Its capital is Oranjestad. O';
wwv_flow_imp.g_varchar2_table(126) := 'fficial or common languages include Dutch and Papiamento.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(127) := 'country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_ci';
wwv_flow_imp.g_varchar2_table(128) := 'ty, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(129) := ') VALUES ('||wwv_flow.LF||
'    ''AX'', ''ALA'', UNISTR(''Europe''), UNISTR(''\00C5land''),'||wwv_flow.LF||
'    UNISTR(''\00C5land Islands''), ';
wwv_flow_imp.g_varchar2_table(130) := 'UNISTR(''Mariehamn''), 30600,'||wwv_flow.LF||
'    2024, UNISTR(''Swedish''),'||wwv_flow.LF||
'    UNISTR(''\00C5land Islands is located in';
wwv_flow_imp.g_varchar2_table(131) := ' Northern Europe. Its capital is Mariehamn. The primary official or common language is Swedish.'')'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(132) := ')'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name';
wwv_flow_imp.g_varchar2_table(133) := ','||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, offic';
wwv_flow_imp.g_varchar2_table(134) := 'ial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''AZ'', ''AZE'', UNISTR(''Asia''), UNISTR(''Az\0259rba';
wwv_flow_imp.g_varchar2_table(135) := 'ycan''),'||wwv_flow.LF||
'    UNISTR(''Azerbaijan''), UNISTR(''Baku''), 10454855,'||wwv_flow.LF||
'    2026, UNISTR(''Azerbaijani, Russian'')';
wwv_flow_imp.g_varchar2_table(136) := ','||wwv_flow.LF||
'    UNISTR(''Azerbaijan is located in Western Asia. Its capital is Baku. Official or common languag';
wwv_flow_imp.g_varchar2_table(137) := 'es include Azerbaijani and Russian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, c';
wwv_flow_imp.g_varchar2_table(138) := 'ountry_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_populati';
wwv_flow_imp.g_varchar2_table(139) := 'on,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BA'', ''';
wwv_flow_imp.g_varchar2_table(140) := 'BIH'', UNISTR(''Europe''), UNISTR(''Bosna i Hercegovina''),'||wwv_flow.LF||
'    UNISTR(''Bosnia and Herzegovina''), UNISTR(';
wwv_flow_imp.g_varchar2_table(141) := '''Sarajevo''), 3114242,'||wwv_flow.LF||
'    2026, UNISTR(''Bosnian, Croatian, Serbian''),'||wwv_flow.LF||
'    UNISTR(''Bosnia and Herzego';
wwv_flow_imp.g_varchar2_table(142) := 'vina is located in Southeast Europe. Its capital is Sarajevo. Official or common languages include B';
wwv_flow_imp.g_varchar2_table(143) := 'osnian, Croatian, and Serbian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, countr';
wwv_flow_imp.g_varchar2_table(144) := 'y_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(145) := '   estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BB'', ''BRB'',';
wwv_flow_imp.g_varchar2_table(146) := ' UNISTR(''Americas''), UNISTR(''Barbados''),'||wwv_flow.LF||
'    UNISTR(''Barbados''), UNISTR(''Bridgetown''), 282724,'||wwv_flow.LF||
'    2';
wwv_flow_imp.g_varchar2_table(147) := '026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Barbados is located in Caribbean. Its capital is Bridgetown. The';
wwv_flow_imp.g_varchar2_table(148) := ' primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_c';
wwv_flow_imp.g_varchar2_table(149) := 'ode_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estim';
wwv_flow_imp.g_varchar2_table(150) := 'ated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ';
wwv_flow_imp.g_varchar2_table(151) := '('||wwv_flow.LF||
'    ''BD'', ''BGD'', UNISTR(''Asia''), UNISTR(''\09AC\09BE\0982\09B2\09BE\09A6\09C7\09B6''),'||wwv_flow.LF||
'    UNISTR(''B';
wwv_flow_imp.g_varchar2_table(152) := 'angladesh''), UNISTR(''Dhaka''), 177818044,'||wwv_flow.LF||
'    2026, UNISTR(''Bengali''),'||wwv_flow.LF||
'    UNISTR(''Bangladesh is loca';
wwv_flow_imp.g_varchar2_table(153) := 'ted in Southern Asia. Its capital is Dhaka. The primary official or common language is Bengali.'')'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(154) := ')'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name';
wwv_flow_imp.g_varchar2_table(155) := ','||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, offic';
wwv_flow_imp.g_varchar2_table(156) := 'ial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BE'', ''BEL'', UNISTR(''Europe''), UNISTR(''Belgien''';
wwv_flow_imp.g_varchar2_table(157) := '),'||wwv_flow.LF||
'    UNISTR(''Belgium''), UNISTR(''Brussels''), 11774642,'||wwv_flow.LF||
'    2026, UNISTR(''German, French, Dutch''),'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(158) := '   UNISTR(''Belgium is located in Western Europe. Its capital is Brussels. Official or common languag';
wwv_flow_imp.g_varchar2_table(159) := 'es include German, French, and Dutch.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2,';
wwv_flow_imp.g_varchar2_table(160) := ' country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_popula';
wwv_flow_imp.g_varchar2_table(161) := 'tion,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BF'',';
wwv_flow_imp.g_varchar2_table(162) := ' ''BFA'', UNISTR(''Africa''), UNISTR(''Burkina Faso''),'||wwv_flow.LF||
'    UNISTR(''Burkina Faso''), UNISTR(''Ouagadougou''),';
wwv_flow_imp.g_varchar2_table(163) := ' 24601700,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''Burkina Faso is located in Western Africa. Its ca';
wwv_flow_imp.g_varchar2_table(164) := 'pital is Ouagadougou. The primary official or common language is French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_c';
wwv_flow_imp.g_varchar2_table(165) := 'ountries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_engl';
wwv_flow_imp.g_varchar2_table(166) := 'ish, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language,';
wwv_flow_imp.g_varchar2_table(167) := ' description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BG'', ''BGR'', UNISTR(''Europe''), UNISTR(''\0411\044A\043B\0433\0430\0440\';
wwv_flow_imp.g_varchar2_table(168) := '0438\044F''),'||wwv_flow.LF||
'    UNISTR(''Bulgaria''), UNISTR(''Sofia''), 6667660,'||wwv_flow.LF||
'    2026, UNISTR(''Bulgarian''),'||wwv_flow.LF||
'    UN';
wwv_flow_imp.g_varchar2_table(169) := 'ISTR(''Bulgaria is located in Southeast Europe. Its capital is Sofia. The primary official or common ';
wwv_flow_imp.g_varchar2_table(170) := 'language is Bulgarian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_a';
wwv_flow_imp.g_varchar2_table(171) := 'lpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estim';
wwv_flow_imp.g_varchar2_table(172) := 'ated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BH'', ''BHR'', UNISTR(';
wwv_flow_imp.g_varchar2_table(173) := '''Asia''), UNISTR(''\0627\0644\0628\062D\0631\064A\0646''),'||wwv_flow.LF||
'    UNISTR(''Bahrain''), UNISTR(''Manama''), 167';
wwv_flow_imp.g_varchar2_table(174) := '5572,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic''),'||wwv_flow.LF||
'    UNISTR(''Bahrain is located in Western Asia. Its capital is Man';
wwv_flow_imp.g_varchar2_table(175) := 'ama. The primary official or common language is Arabic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    co';
wwv_flow_imp.g_varchar2_table(176) := 'untry_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city';
wwv_flow_imp.g_varchar2_table(177) := ', estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) ';
wwv_flow_imp.g_varchar2_table(178) := 'VALUES ('||wwv_flow.LF||
'    ''BI'', ''BDI'', UNISTR(''Africa''), UNISTR(''Uburundi''),'||wwv_flow.LF||
'    UNISTR(''Burundi''), UNISTR(''Giteg';
wwv_flow_imp.g_varchar2_table(179) := 'a''), 14729157,'||wwv_flow.LF||
'    2026, UNISTR(''French, Kirundi''),'||wwv_flow.LF||
'    UNISTR(''Burundi is located in Eastern Africa';
wwv_flow_imp.g_varchar2_table(180) := '. Its capital is Gitega. Official or common languages include French and Kirundi.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_s';
wwv_flow_imp.g_varchar2_table(181) := 'rch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_';
wwv_flow_imp.g_varchar2_table(182) := 'name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_';
wwv_flow_imp.g_varchar2_table(183) := 'language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BJ'', ''BEN'', UNISTR(''Africa''), UNISTR(''B\00E9nin''),'||wwv_flow.LF||
'    UNIST';
wwv_flow_imp.g_varchar2_table(184) := 'R(''Benin''), UNISTR(''Porto-Novo''), 15170420,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''Benin is located';
wwv_flow_imp.g_varchar2_table(185) := ' in Western Africa. Its capital is Porto-Novo. The primary official or common language is French.'')'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(186) := '  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_na';
wwv_flow_imp.g_varchar2_table(187) := 'me,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, off';
wwv_flow_imp.g_varchar2_table(188) := 'icial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BL'', ''BLM'', UNISTR(''Americas''), UNISTR(''Sain';
wwv_flow_imp.g_varchar2_table(189) := 't-Barth\00E9lemy''),'||wwv_flow.LF||
'    UNISTR(''Saint Barth\00E9lemy''), UNISTR(''Gustavia''), 11550,'||wwv_flow.LF||
'    2026, UNISTR(';
wwv_flow_imp.g_varchar2_table(190) := '''French''),'||wwv_flow.LF||
'    UNISTR(''Saint Barth\00E9lemy is located in Caribbean. Its capital is Gustavia. The pr';
wwv_flow_imp.g_varchar2_table(191) := 'imary official or common language is French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_';
wwv_flow_imp.g_varchar2_table(192) := 'alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated';
wwv_flow_imp.g_varchar2_table(193) := '_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(194) := '  ''BM'', ''BMU'', UNISTR(''Americas''), UNISTR(''Bermuda''),'||wwv_flow.LF||
'    UNISTR(''Bermuda''), UNISTR(''Hamilton''), 644';
wwv_flow_imp.g_varchar2_table(195) := '59,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Bermuda is located in North America. Its capital is Ham';
wwv_flow_imp.g_varchar2_table(196) := 'ilton. The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(197) := ' country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_c';
wwv_flow_imp.g_varchar2_table(198) := 'ity, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(199) := ' ) VALUES ('||wwv_flow.LF||
'    ''BN'', ''BRN'', UNISTR(''Asia''), UNISTR(''Negara Brunei Darussalam''),'||wwv_flow.LF||
'    UNISTR(''Brunei''';
wwv_flow_imp.g_varchar2_table(200) := '), UNISTR(''Bandar Seri Begawan''), 469775,'||wwv_flow.LF||
'    2026, UNISTR(''Malay''),'||wwv_flow.LF||
'    UNISTR(''Brunei is located i';
wwv_flow_imp.g_varchar2_table(201) := 'n South-Eastern Asia. Its capital is Bandar Seri Begawan. The primary official or common language is';
wwv_flow_imp.g_varchar2_table(202) := ' Malay.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, ';
wwv_flow_imp.g_varchar2_table(203) := 'country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population';
wwv_flow_imp.g_varchar2_table(204) := '_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BO'', ''BOL'', UNISTR(''Americas''), UN';
wwv_flow_imp.g_varchar2_table(205) := 'ISTR(''Wuliwya''),'||wwv_flow.LF||
'    UNISTR(''Bolivia''), UNISTR(''Sucre''), 12749291,'||wwv_flow.LF||
'    2026, UNISTR(''Aymara, Guaran\';
wwv_flow_imp.g_varchar2_table(206) := '00ED, Quechua, Spanish''),'||wwv_flow.LF||
'    UNISTR(''Bolivia is located in South America. Its capital is Sucre. Off';
wwv_flow_imp.g_varchar2_table(207) := 'icial or common languages include Aymara, Guaran\00ED, Quechua, and other local languages.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  i';
wwv_flow_imp.g_varchar2_table(208) := 'nto eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(209) := ' country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_o';
wwv_flow_imp.g_varchar2_table(210) := 'r_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BQ'', ''BES'', UNISTR(''Americas''), UNISTR(''Caribisch N';
wwv_flow_imp.g_varchar2_table(211) := 'ederland''),'||wwv_flow.LF||
'    UNISTR(''Caribbean Netherlands''), UNISTR(''Kralendijk''), 31913,'||wwv_flow.LF||
'    2026, UNISTR(''Engl';
wwv_flow_imp.g_varchar2_table(212) := 'ish, Dutch, Papiamento''),'||wwv_flow.LF||
'    UNISTR(''Caribbean Netherlands is located in Caribbean. Its capital is ';
wwv_flow_imp.g_varchar2_table(213) := 'Kralendijk. Official or common languages include English, Dutch, and Papiamento.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_sr';
wwv_flow_imp.g_varchar2_table(214) := 'ch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_n';
wwv_flow_imp.g_varchar2_table(215) := 'ame_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_l';
wwv_flow_imp.g_varchar2_table(216) := 'anguage, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BR'', ''BRA'', UNISTR(''Americas''), UNISTR(''Brasil''),'||wwv_flow.LF||
'    UNISTR(';
wwv_flow_imp.g_varchar2_table(217) := '''Brazil''), UNISTR(''Bras\00EDlia''), 213562666,'||wwv_flow.LF||
'    2026, UNISTR(''Portuguese''),'||wwv_flow.LF||
'    UNISTR(''Brazil is ';
wwv_flow_imp.g_varchar2_table(218) := 'located in South America. Its capital is Bras\00EDlia. The primary official or common language is Po';
wwv_flow_imp.g_varchar2_table(219) := 'rtuguese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region';
wwv_flow_imp.g_varchar2_table(220) := ', country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_populati';
wwv_flow_imp.g_varchar2_table(221) := 'on_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BS'', ''BHS'', UNISTR(''Americas''), ';
wwv_flow_imp.g_varchar2_table(222) := 'UNISTR(''Bahamas''),'||wwv_flow.LF||
'    UNISTR(''Bahamas''), UNISTR(''Nassau''), 404628,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(223) := ' UNISTR(''Bahamas is located in Caribbean. Its capital is Nassau. The primary official or common lang';
wwv_flow_imp.g_varchar2_table(224) := 'uage is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3,';
wwv_flow_imp.g_varchar2_table(225) := ' region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_p';
wwv_flow_imp.g_varchar2_table(226) := 'opulation_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BT'', ''BTN'', UNISTR(''Asia''';
wwv_flow_imp.g_varchar2_table(227) := '), UNISTR(''\0F60\0F56\0FB2\0F74\0F42\0F0B\0F61\0F74\0F63\0F0B''),'||wwv_flow.LF||
'    UNISTR(''Bhutan''), UNISTR(''Thimp';
wwv_flow_imp.g_varchar2_table(228) := 'hu''), 802214,'||wwv_flow.LF||
'    2026, UNISTR(''Dzongkha''),'||wwv_flow.LF||
'    UNISTR(''Bhutan is located in Southern Asia. Its capi';
wwv_flow_imp.g_varchar2_table(229) := 'tal is Thimphu. The primary official or common language is Dzongkha.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_count';
wwv_flow_imp.g_varchar2_table(230) := 'ries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english,';
wwv_flow_imp.g_varchar2_table(231) := ' capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, des';
wwv_flow_imp.g_varchar2_table(232) := 'cription'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BV'', ''BVT'', UNISTR(''Antarctica''), UNISTR(''Bouvet\00F8ya''),'||wwv_flow.LF||
'    UNISTR(''Bo';
wwv_flow_imp.g_varchar2_table(233) := 'uvet Island''), NULL, 0,'||wwv_flow.LF||
'    2024, UNISTR(''Norwegian''),'||wwv_flow.LF||
'    UNISTR(''Bouvet Island is located in Antar';
wwv_flow_imp.g_varchar2_table(234) := 'ctic and has no permanent capital. The primary official or common language is Norwegian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  int';
wwv_flow_imp.g_varchar2_table(235) := 'o eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(236) := 'ountry_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_';
wwv_flow_imp.g_varchar2_table(237) := 'common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BW'', ''BWA'', UNISTR(''Africa''), UNISTR(''Botswana''),'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(238) := ' UNISTR(''Botswana''), UNISTR(''Gaborone''), 2603388,'||wwv_flow.LF||
'    2026, UNISTR(''English, Tswana''),'||wwv_flow.LF||
'    UNISTR(''B';
wwv_flow_imp.g_varchar2_table(239) := 'otswana is located in Southern Africa. Its capital is Gaborone. Official or common languages include';
wwv_flow_imp.g_varchar2_table(240) := ' English and Tswana.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alp';
wwv_flow_imp.g_varchar2_table(241) := 'ha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimat';
wwv_flow_imp.g_varchar2_table(242) := 'ed_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BY'', ''BLR'', UNISTR(''E';
wwv_flow_imp.g_varchar2_table(243) := 'urope''), UNISTR(''\0411\0435\043B\0430\0440\0443\0301\0441\044C''),'||wwv_flow.LF||
'    UNISTR(''Belarus''), UNISTR(''Min';
wwv_flow_imp.g_varchar2_table(244) := 'sk''), 8937018,'||wwv_flow.LF||
'    2026, UNISTR(''Belarusian, Russian''),'||wwv_flow.LF||
'    UNISTR(''Belarus is located in Eastern Eu';
wwv_flow_imp.g_varchar2_table(245) := 'rope. Its capital is Minsk. Official or common languages include Belarusian and Russian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  int';
wwv_flow_imp.g_varchar2_table(246) := 'o eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(247) := 'ountry_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_';
wwv_flow_imp.g_varchar2_table(248) := 'common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''BZ'', ''BLZ'', UNISTR(''Americas''), UNISTR(''Belice''),'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(249) := ' UNISTR(''Belize''), UNISTR(''Belmopan''), 428644,'||wwv_flow.LF||
'    2026, UNISTR(''Belizean Creole, English, Spanish'')';
wwv_flow_imp.g_varchar2_table(250) := ','||wwv_flow.LF||
'    UNISTR(''Belize is located in Central America. Its capital is Belmopan. Official or common lang';
wwv_flow_imp.g_varchar2_table(251) := 'uages include Belizean Creole, English, and Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    count';
wwv_flow_imp.g_varchar2_table(252) := 'ry_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, e';
wwv_flow_imp.g_varchar2_table(253) := 'stimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VAL';
wwv_flow_imp.g_varchar2_table(254) := 'UES ('||wwv_flow.LF||
'    ''CA'', ''CAN'', UNISTR(''Americas''), UNISTR(''Canada''),'||wwv_flow.LF||
'    UNISTR(''Canada''), UNISTR(''Ottawa''),';
wwv_flow_imp.g_varchar2_table(255) := ' 40467728,'||wwv_flow.LF||
'    2026, UNISTR(''English, French''),'||wwv_flow.LF||
'    UNISTR(''Canada is located in North America. Its ';
wwv_flow_imp.g_varchar2_table(256) := 'capital is Ottawa. Official or common languages include English and French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_tx';
wwv_flow_imp.g_varchar2_table(257) := 't_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_e';
wwv_flow_imp.g_varchar2_table(258) := 'nglish, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_langua';
wwv_flow_imp.g_varchar2_table(259) := 'ge, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CC'', ''CCK'', UNISTR(''Oceania''), UNISTR(''Cocos (Keeling) Islands''),'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(260) := '    UNISTR(''Cocos (Keeling) Islands''), UNISTR(''West Island''), 600,'||wwv_flow.LF||
'    2024, UNISTR(''English''),'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(261) := 'UNISTR(''Cocos (Keeling) Islands is located in Australia and New Zealand. Its capital is West Island.';
wwv_flow_imp.g_varchar2_table(262) := ' The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    count';
wwv_flow_imp.g_varchar2_table(263) := 'ry_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, e';
wwv_flow_imp.g_varchar2_table(264) := 'stimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VAL';
wwv_flow_imp.g_varchar2_table(265) := 'UES ('||wwv_flow.LF||
'    ''CD'', ''COD'', UNISTR(''Africa''), UNISTR(''RD Congo''),'||wwv_flow.LF||
'    UNISTR(''Democratic Republic of the ';
wwv_flow_imp.g_varchar2_table(266) := 'Congo''), UNISTR(''Kinshasa''), 116452162,'||wwv_flow.LF||
'    2026, UNISTR(''French, Kikongo, Lingala, Tshiluba, Swahil';
wwv_flow_imp.g_varchar2_table(267) := 'i''),'||wwv_flow.LF||
'    UNISTR(''Democratic Republic of the Congo is located in Middle Africa. Its capital is Kinsha';
wwv_flow_imp.g_varchar2_table(268) := 'sa. Official or common languages include French, Kikongo, Lingala, and other local languages.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(269) := '  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(270) := '    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, officia';
wwv_flow_imp.g_varchar2_table(271) := 'l_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CF'', ''CAF'', UNISTR(''Africa''), UNISTR(''R\00E9publ';
wwv_flow_imp.g_varchar2_table(272) := 'ique centrafricaine''),'||wwv_flow.LF||
'    UNISTR(''Central African Republic''), UNISTR(''Bangui''), 5698984,'||wwv_flow.LF||
'    2026, ';
wwv_flow_imp.g_varchar2_table(273) := 'UNISTR(''French, Sango''),'||wwv_flow.LF||
'    UNISTR(''Central African Republic is located in Middle Africa. Its capit';
wwv_flow_imp.g_varchar2_table(274) := 'al is Bangui. Official or common languages include French and Sango.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_count';
wwv_flow_imp.g_varchar2_table(275) := 'ries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english,';
wwv_flow_imp.g_varchar2_table(276) := ' capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, des';
wwv_flow_imp.g_varchar2_table(277) := 'cription'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CG'', ''COG'', UNISTR(''Africa''), UNISTR(''R\00E9publique du Congo''),'||wwv_flow.LF||
'    UNIS';
wwv_flow_imp.g_varchar2_table(278) := 'TR(''Congo''), UNISTR(''Brazzaville''), 6637786,'||wwv_flow.LF||
'    2026, UNISTR(''French, Kikongo, Lingala''),'||wwv_flow.LF||
'    UNIST';
wwv_flow_imp.g_varchar2_table(279) := 'R(''Congo is located in Middle Africa. Its capital is Brazzaville. Official or common languages inclu';
wwv_flow_imp.g_varchar2_table(280) := 'de French, Kikongo, and Lingala.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, coun';
wwv_flow_imp.g_varchar2_table(281) := 'try_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,';
wwv_flow_imp.g_varchar2_table(282) := ''||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CH'', ''CHE';
wwv_flow_imp.g_varchar2_table(283) := ''', UNISTR(''Europe''), UNISTR(''Suisse''),'||wwv_flow.LF||
'    UNISTR(''Switzerland''), UNISTR(''Bern''), 9007798,'||wwv_flow.LF||
'    2026,';
wwv_flow_imp.g_varchar2_table(284) := ' UNISTR(''French, Swiss German, Italian, Romansh''),'||wwv_flow.LF||
'    UNISTR(''Switzerland is located in Western Eur';
wwv_flow_imp.g_varchar2_table(285) := 'ope. Its capital is Bern. Official or common languages include French, Swiss German, Italian, and ot';
wwv_flow_imp.g_varchar2_table(286) := 'her local languages.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alp';
wwv_flow_imp.g_varchar2_table(287) := 'ha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimat';
wwv_flow_imp.g_varchar2_table(288) := 'ed_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CI'', ''CIV'', UNISTR(''A';
wwv_flow_imp.g_varchar2_table(289) := 'frica''), UNISTR(''C\00F4te d''''Ivoire''),'||wwv_flow.LF||
'    UNISTR(''Ivory Coast''), UNISTR(''Yamoussoukro''), 33494346,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(290) := '    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''Ivory Coast is located in Western Africa. Its capital is Yam';
wwv_flow_imp.g_varchar2_table(291) := 'oussoukro. The primary official or common language is French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(292) := '    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capita';
wwv_flow_imp.g_varchar2_table(293) := 'l_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, descriptio';
wwv_flow_imp.g_varchar2_table(294) := 'n'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CK'', ''COK'', UNISTR(''Oceania''), UNISTR(''K\016Bki ''''\0100irani''),'||wwv_flow.LF||
'    UNISTR(''Cook';
wwv_flow_imp.g_varchar2_table(295) := ' Islands''), UNISTR(''Avarua''), 12826,'||wwv_flow.LF||
'    2026, UNISTR(''English, Cook Islands M\0101ori''),'||wwv_flow.LF||
'    UNISTR';
wwv_flow_imp.g_varchar2_table(296) := '(''Cook Islands is located in Polynesia. Its capital is Avarua. Official or common languages include ';
wwv_flow_imp.g_varchar2_table(297) := 'English and Cook Islands M\0101ori.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, c';
wwv_flow_imp.g_varchar2_table(298) := 'ountry_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_populati';
wwv_flow_imp.g_varchar2_table(299) := 'on,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CL'', ''';
wwv_flow_imp.g_varchar2_table(300) := 'CHL'', UNISTR(''Americas''), UNISTR(''Chile''),'||wwv_flow.LF||
'    UNISTR(''Chile''), UNISTR(''Santiago''), 19945850,'||wwv_flow.LF||
'    20';
wwv_flow_imp.g_varchar2_table(301) := '26, UNISTR(''Spanish''),'||wwv_flow.LF||
'    UNISTR(''Chile is located in South America. Its capital is Santiago. The p';
wwv_flow_imp.g_varchar2_table(302) := 'rimary official or common language is Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_cod';
wwv_flow_imp.g_varchar2_table(303) := 'e_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimat';
wwv_flow_imp.g_varchar2_table(304) := 'ed_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(305) := '    ''CM'', ''CMR'', UNISTR(''Africa''), UNISTR(''Cameroun''),'||wwv_flow.LF||
'    UNISTR(''Cameroon''), UNISTR(''Yaound\00E9'')';
wwv_flow_imp.g_varchar2_table(306) := ', 30640817,'||wwv_flow.LF||
'    2026, UNISTR(''English, French''),'||wwv_flow.LF||
'    UNISTR(''Cameroon is located in Middle Africa. I';
wwv_flow_imp.g_varchar2_table(307) := 'ts capital is Yaound\00E9. Official or common languages include English and French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba';
wwv_flow_imp.g_varchar2_table(308) := '_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    countr';
wwv_flow_imp.g_varchar2_table(309) := 'y_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_commo';
wwv_flow_imp.g_varchar2_table(310) := 'n_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CN'', ''CHN'', UNISTR(''Asia''), UNISTR(''\4E2D\56FD''),'||wwv_flow.LF||
'    UNIS';
wwv_flow_imp.g_varchar2_table(311) := 'TR(''China''), UNISTR(''Beijing''), 1412914089,'||wwv_flow.LF||
'    2026, UNISTR(''Chinese''),'||wwv_flow.LF||
'    UNISTR(''China is locate';
wwv_flow_imp.g_varchar2_table(312) := 'd in Eastern Asia. Its capital is Beijing. The primary official or common language is Chinese.'')'||wwv_flow.LF||
'  )';
wwv_flow_imp.g_varchar2_table(313) := ''||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,';
wwv_flow_imp.g_varchar2_table(314) := ''||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, offici';
wwv_flow_imp.g_varchar2_table(315) := 'al_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CO'', ''COL'', UNISTR(''Americas''), UNISTR(''Colombi';
wwv_flow_imp.g_varchar2_table(316) := 'a''),'||wwv_flow.LF||
'    UNISTR(''Colombia''), UNISTR(''Bogot\00E1''), 53936226,'||wwv_flow.LF||
'    2026, UNISTR(''Spanish''),'||wwv_flow.LF||
'    UNISTR';
wwv_flow_imp.g_varchar2_table(317) := '(''Colombia is located in South America. Its capital is Bogot\00E1. The primary official or common la';
wwv_flow_imp.g_varchar2_table(318) := 'nguage is Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha';
wwv_flow_imp.g_varchar2_table(319) := '3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated';
wwv_flow_imp.g_varchar2_table(320) := '_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CR'', ''CRI'', UNISTR(''Ame';
wwv_flow_imp.g_varchar2_table(321) := 'ricas''), UNISTR(''Costa Rica''),'||wwv_flow.LF||
'    UNISTR(''Costa Rica''), UNISTR(''San Jos\00E9''), 5174789,'||wwv_flow.LF||
'    2026, ';
wwv_flow_imp.g_varchar2_table(322) := 'UNISTR(''Spanish''),'||wwv_flow.LF||
'    UNISTR(''Costa Rica is located in Central America. Its capital is San Jos\00E9';
wwv_flow_imp.g_varchar2_table(323) := '. The primary official or common language is Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'SELECT 1 FROM dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'INSERT ALL'||wwv_flow.LF||
'  into e';
wwv_flow_imp.g_varchar2_table(324) := 'ba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    coun';
wwv_flow_imp.g_varchar2_table(325) := 'try_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_com';
wwv_flow_imp.g_varchar2_table(326) := 'mon_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CU'', ''CUB'', UNISTR(''Americas''), UNISTR(''Cuba''),'||wwv_flow.LF||
'    UNIS';
wwv_flow_imp.g_varchar2_table(327) := 'TR(''Cuba''), UNISTR(''Havana''), 10892659,'||wwv_flow.LF||
'    2026, UNISTR(''Spanish''),'||wwv_flow.LF||
'    UNISTR(''Cuba is located in ';
wwv_flow_imp.g_varchar2_table(328) := 'Caribbean. Its capital is Havana. The primary official or common language is Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into e';
wwv_flow_imp.g_varchar2_table(329) := 'ba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    coun';
wwv_flow_imp.g_varchar2_table(330) := 'try_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_com';
wwv_flow_imp.g_varchar2_table(331) := 'mon_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CV'', ''CPV'', UNISTR(''Africa''), UNISTR(''Cabo Verde''),'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(332) := 'UNISTR(''Cape Verde''), UNISTR(''Praia''), 529630,'||wwv_flow.LF||
'    2026, UNISTR(''Portuguese''),'||wwv_flow.LF||
'    UNISTR(''Cape Verd';
wwv_flow_imp.g_varchar2_table(333) := 'e is located in Western Africa. Its capital is Praia. The primary official or common language is Por';
wwv_flow_imp.g_varchar2_table(334) := 'tuguese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region,';
wwv_flow_imp.g_varchar2_table(335) := ' country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_populatio';
wwv_flow_imp.g_varchar2_table(336) := 'n_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CW'', ''CUW'', UNISTR(''Americas''), U';
wwv_flow_imp.g_varchar2_table(337) := 'NISTR(''Pais K\00F2rsou''),'||wwv_flow.LF||
'    UNISTR(''Cura\00E7ao''), UNISTR(''Willemstad''), 185440,'||wwv_flow.LF||
'    2026, UNISTR(';
wwv_flow_imp.g_varchar2_table(338) := '''English, Dutch, Papiamento''),'||wwv_flow.LF||
'    UNISTR(''Cura\00E7ao is located in Caribbean. Its capital is Wille';
wwv_flow_imp.g_varchar2_table(339) := 'mstad. Official or common languages include English, Dutch, and Papiamento.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_tx';
wwv_flow_imp.g_varchar2_table(340) := 't_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_e';
wwv_flow_imp.g_varchar2_table(341) := 'nglish, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_langua';
wwv_flow_imp.g_varchar2_table(342) := 'ge, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CX'', ''CXR'', UNISTR(''Oceania''), UNISTR(''Christmas Island''),'||wwv_flow.LF||
'    UNI';
wwv_flow_imp.g_varchar2_table(343) := 'STR(''Christmas Island''), UNISTR(''Flying Fish Cove''), 1700,'||wwv_flow.LF||
'    2024, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''';
wwv_flow_imp.g_varchar2_table(344) := 'Christmas Island is located in Australia and New Zealand. Its capital is Flying Fish Cove. The prima';
wwv_flow_imp.g_varchar2_table(345) := 'ry official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_al';
wwv_flow_imp.g_varchar2_table(346) := 'pha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_p';
wwv_flow_imp.g_varchar2_table(347) := 'opulation,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(348) := '''CY'', ''CYP'', UNISTR(''Europe''), UNISTR(''\039A\03CD\03C0\03C1\03BF\03C2''),'||wwv_flow.LF||
'    UNISTR(''Cyprus''), UNIST';
wwv_flow_imp.g_varchar2_table(349) := 'R(''Nicosia''), 1382334,'||wwv_flow.LF||
'    2026, UNISTR(''Greek, Turkish''),'||wwv_flow.LF||
'    UNISTR(''Cyprus is located in Southern';
wwv_flow_imp.g_varchar2_table(350) := ' Europe. Its capital is Nicosia. Official or common languages include Greek and Turkish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  int';
wwv_flow_imp.g_varchar2_table(351) := 'o eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(352) := 'ountry_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_';
wwv_flow_imp.g_varchar2_table(353) := 'common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''CZ'', ''CZE'', UNISTR(''Europe''), UNISTR(''\010Cesko''),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(354) := '  UNISTR(''Czechia''), UNISTR(''Prague''), 10527780,'||wwv_flow.LF||
'    2026, UNISTR(''Czech, Slovak''),'||wwv_flow.LF||
'    UNISTR(''Czec';
wwv_flow_imp.g_varchar2_table(355) := 'hia is located in Central Europe. Its capital is Prague. Official or common languages include Czech ';
wwv_flow_imp.g_varchar2_table(356) := 'and Slovak.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, regi';
wwv_flow_imp.g_varchar2_table(357) := 'on, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_popula';
wwv_flow_imp.g_varchar2_table(358) := 'tion_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''DE'', ''DEU'', UNISTR(''Europe''), ';
wwv_flow_imp.g_varchar2_table(359) := 'UNISTR(''Deutschland''),'||wwv_flow.LF||
'    UNISTR(''Germany''), UNISTR(''Berlin''), 83644258,'||wwv_flow.LF||
'    2026, UNISTR(''German'')';
wwv_flow_imp.g_varchar2_table(360) := ','||wwv_flow.LF||
'    UNISTR(''Germany is located in Western Europe. Its capital is Berlin. The primary official or c';
wwv_flow_imp.g_varchar2_table(361) := 'ommon language is German.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_cod';
wwv_flow_imp.g_varchar2_table(362) := 'e_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    es';
wwv_flow_imp.g_varchar2_table(363) := 'timated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''DJ'', ''DJI'', UNIS';
wwv_flow_imp.g_varchar2_table(364) := 'TR(''Africa''), UNISTR(''\062C\064A\0628\0648\062A\064A''),'||wwv_flow.LF||
'    UNISTR(''Djibouti''), UNISTR(''Djibouti''), ';
wwv_flow_imp.g_varchar2_table(365) := '1199459,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic, French''),'||wwv_flow.LF||
'    UNISTR(''Djibouti is located in Eastern Africa. Its ';
wwv_flow_imp.g_varchar2_table(366) := 'capital is Djibouti. Official or common languages include Arabic and French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_t';
wwv_flow_imp.g_varchar2_table(367) := 'xt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_';
wwv_flow_imp.g_varchar2_table(368) := 'english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_langu';
wwv_flow_imp.g_varchar2_table(369) := 'age, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''DK'', ''DNK'', UNISTR(''Europe''), UNISTR(''Danmark''),'||wwv_flow.LF||
'    UNISTR(''Denm';
wwv_flow_imp.g_varchar2_table(370) := 'ark''), UNISTR(''Copenhagen''), 6023520,'||wwv_flow.LF||
'    2026, UNISTR(''Danish''),'||wwv_flow.LF||
'    UNISTR(''Denmark is located in ';
wwv_flow_imp.g_varchar2_table(371) := 'Northern Europe. Its capital is Copenhagen. The primary official or common language is Danish.'')'||wwv_flow.LF||
'  )';
wwv_flow_imp.g_varchar2_table(372) := ''||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,';
wwv_flow_imp.g_varchar2_table(373) := ''||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, offici';
wwv_flow_imp.g_varchar2_table(374) := 'al_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''DM'', ''DMA'', UNISTR(''Americas''), UNISTR(''Dominic';
wwv_flow_imp.g_varchar2_table(375) := 'a''),'||wwv_flow.LF||
'    UNISTR(''Dominica''), UNISTR(''Roseau''), 65511,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Domin';
wwv_flow_imp.g_varchar2_table(376) := 'ica is located in Caribbean. Its capital is Roseau. The primary official or common language is Engli';
wwv_flow_imp.g_varchar2_table(377) := 'sh.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, coun';
wwv_flow_imp.g_varchar2_table(378) := 'try_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_yea';
wwv_flow_imp.g_varchar2_table(379) := 'r, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''DO'', ''DOM'', UNISTR(''Americas''), UNISTR';
wwv_flow_imp.g_varchar2_table(380) := '(''Rep\00FAblica Dominicana''),'||wwv_flow.LF||
'    UNISTR(''Dominican Republic''), UNISTR(''Santo Domingo''), 11609500,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(381) := '   2026, UNISTR(''Spanish''),'||wwv_flow.LF||
'    UNISTR(''Dominican Republic is located in Caribbean. Its capital is S';
wwv_flow_imp.g_varchar2_table(382) := 'anto Domingo. The primary official or common language is Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countrie';
wwv_flow_imp.g_varchar2_table(383) := 's ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, ca';
wwv_flow_imp.g_varchar2_table(384) := 'pital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, descri';
wwv_flow_imp.g_varchar2_table(385) := 'ption'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''DZ'', ''DZA'', UNISTR(''Africa''), UNISTR(''\0627\0644\062C\0632\0627\0626\0631''),';
wwv_flow_imp.g_varchar2_table(386) := ''||wwv_flow.LF||
'    UNISTR(''Algeria''), UNISTR(''Algiers''), 48028334,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic''),'||wwv_flow.LF||
'    UNISTR(''Algeria';
wwv_flow_imp.g_varchar2_table(387) := ' is located in Northern Africa. Its capital is Algiers. The primary official or common language is A';
wwv_flow_imp.g_varchar2_table(388) := 'rabic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, c';
wwv_flow_imp.g_varchar2_table(389) := 'ountry_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_';
wwv_flow_imp.g_varchar2_table(390) := 'year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''EC'', ''ECU'', UNISTR(''Americas''), UNI';
wwv_flow_imp.g_varchar2_table(391) := 'STR(''Ecuador''),'||wwv_flow.LF||
'    UNISTR(''Ecuador''), UNISTR(''Quito''), 18444506,'||wwv_flow.LF||
'    2026, UNISTR(''Spanish''),'||wwv_flow.LF||
'    U';
wwv_flow_imp.g_varchar2_table(392) := 'NISTR(''Ecuador is located in South America. Its capital is Quito. The primary official or common lan';
wwv_flow_imp.g_varchar2_table(393) := 'guage is Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3';
wwv_flow_imp.g_varchar2_table(394) := ', region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_';
wwv_flow_imp.g_varchar2_table(395) := 'population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''EE'', ''EST'', UNISTR(''Euro';
wwv_flow_imp.g_varchar2_table(396) := 'pe''), UNISTR(''Eesti''),'||wwv_flow.LF||
'    UNISTR(''Estonia''), UNISTR(''Tallinn''), 1331062,'||wwv_flow.LF||
'    2026, UNISTR(''Estonian';
wwv_flow_imp.g_varchar2_table(397) := '''),'||wwv_flow.LF||
'    UNISTR(''Estonia is located in Northern Europe. Its capital is Tallinn. The primary official ';
wwv_flow_imp.g_varchar2_table(398) := 'or common language is Estonian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, count';
wwv_flow_imp.g_varchar2_table(399) := 'ry_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(400) := '    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''EG'', ''EGY''';
wwv_flow_imp.g_varchar2_table(401) := ', UNISTR(''Africa''), UNISTR(''\0645\0635\0631''),'||wwv_flow.LF||
'    UNISTR(''Egypt''), UNISTR(''Cairo''), 120101175,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(402) := '2026, UNISTR(''Arabic''),'||wwv_flow.LF||
'    UNISTR(''Egypt is located in Northern Africa. Its capital is Cairo. The p';
wwv_flow_imp.g_varchar2_table(403) := 'rimary official or common language is Arabic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code';
wwv_flow_imp.g_varchar2_table(404) := '_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimate';
wwv_flow_imp.g_varchar2_table(405) := 'd_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(406) := '   ''EH'', ''ESH'', UNISTR(''Africa''), UNISTR(''\0627\0644\0635\062D\0631\0627\0621 \0627\0644\063A\0631\0';
wwv_flow_imp.g_varchar2_table(407) := '628\064A\0629''),'||wwv_flow.LF||
'    UNISTR(''Western Sahara''), UNISTR(''El Aai\00FAn''), 610813,'||wwv_flow.LF||
'    2026, UNISTR(''Ber';
wwv_flow_imp.g_varchar2_table(408) := 'ber, Hassaniya, Spanish''),'||wwv_flow.LF||
'    UNISTR(''Western Sahara is located in Northern Africa. Its capital is ';
wwv_flow_imp.g_varchar2_table(409) := 'El Aai\00FAn. Official or common languages include Berber, Hassaniya, and Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_';
wwv_flow_imp.g_varchar2_table(410) := 'srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country';
wwv_flow_imp.g_varchar2_table(411) := '_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common';
wwv_flow_imp.g_varchar2_table(412) := '_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''ER'', ''ERI'', UNISTR(''Africa''), UNISTR(''\0625\0631\064A\062A\';
wwv_flow_imp.g_varchar2_table(413) := '0631\064A\0627''),'||wwv_flow.LF||
'    UNISTR(''Eritrea''), UNISTR(''Asmara''), 3682669,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic, Englis';
wwv_flow_imp.g_varchar2_table(414) := 'h, Tigrinya''),'||wwv_flow.LF||
'    UNISTR(''Eritrea is located in Eastern Africa. Its capital is Asmara. Official or ';
wwv_flow_imp.g_varchar2_table(415) := 'common languages include Arabic, English, and Tigrinya.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    co';
wwv_flow_imp.g_varchar2_table(416) := 'untry_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city';
wwv_flow_imp.g_varchar2_table(417) := ', estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) ';
wwv_flow_imp.g_varchar2_table(418) := 'VALUES ('||wwv_flow.LF||
'    ''ES'', ''ESP'', UNISTR(''Europe''), UNISTR(''Espa\00F1a''),'||wwv_flow.LF||
'    UNISTR(''Spain''), UNISTR(''Madri';
wwv_flow_imp.g_varchar2_table(419) := 'd''), 47850793,'||wwv_flow.LF||
'    2026, UNISTR(''Spanish''),'||wwv_flow.LF||
'    UNISTR(''Spain is located in Southern Europe. Its cap';
wwv_flow_imp.g_varchar2_table(420) := 'ital is Madrid. The primary official or common language is Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countr';
wwv_flow_imp.g_varchar2_table(421) := 'ies ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, ';
wwv_flow_imp.g_varchar2_table(422) := 'capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, desc';
wwv_flow_imp.g_varchar2_table(423) := 'ription'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''ET'', ''ETH'', UNISTR(''Africa''), UNISTR(''\12A2\1275\12EE\1335\12EB''),'||wwv_flow.LF||
'    UNI';
wwv_flow_imp.g_varchar2_table(424) := 'STR(''Ethiopia''), UNISTR(''Addis Ababa''), 138902185,'||wwv_flow.LF||
'    2026, UNISTR(''Amharic''),'||wwv_flow.LF||
'    UNISTR(''Ethiopia';
wwv_flow_imp.g_varchar2_table(425) := ' is located in Eastern Africa. Its capital is Addis Ababa. The primary official or common language i';
wwv_flow_imp.g_varchar2_table(426) := 's Amharic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, regio';
wwv_flow_imp.g_varchar2_table(427) := 'n, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_populat';
wwv_flow_imp.g_varchar2_table(428) := 'ion_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''FI'', ''FIN'', UNISTR(''Europe''), U';
wwv_flow_imp.g_varchar2_table(429) := 'NISTR(''Suomi''),'||wwv_flow.LF||
'    UNISTR(''Finland''), UNISTR(''Helsinki''), 5621739,'||wwv_flow.LF||
'    2026, UNISTR(''Finnish, Swedi';
wwv_flow_imp.g_varchar2_table(430) := 'sh''),'||wwv_flow.LF||
'    UNISTR(''Finland is located in Northern Europe. Its capital is Helsinki. Official or common';
wwv_flow_imp.g_varchar2_table(431) := ' languages include Finnish and Swedish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha';
wwv_flow_imp.g_varchar2_table(432) := '2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_popu';
wwv_flow_imp.g_varchar2_table(433) := 'lation,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''FJ';
wwv_flow_imp.g_varchar2_table(434) := ''', ''FJI'', UNISTR(''Oceania''), UNISTR(''Viti''),'||wwv_flow.LF||
'    UNISTR(''Fiji''), UNISTR(''Suva''), 937282,'||wwv_flow.LF||
'    2026, U';
wwv_flow_imp.g_varchar2_table(435) := 'NISTR(''English, Fijian, Fiji Hindi''),'||wwv_flow.LF||
'    UNISTR(''Fiji is located in Melanesia. Its capital is Suva.';
wwv_flow_imp.g_varchar2_table(436) := ' Official or common languages include English, Fijian, and Fiji Hindi.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_cou';
wwv_flow_imp.g_varchar2_table(437) := 'ntries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_englis';
wwv_flow_imp.g_varchar2_table(438) := 'h, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, d';
wwv_flow_imp.g_varchar2_table(439) := 'escription'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''FK'', ''FLK'', UNISTR(''Americas''), UNISTR(''Falkland Islands''),'||wwv_flow.LF||
'    UNISTR(';
wwv_flow_imp.g_varchar2_table(440) := '''Falkland Islands''), UNISTR(''Stanley''), 3465,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Falkland Isla';
wwv_flow_imp.g_varchar2_table(441) := 'nds is located in South America. Its capital is Stanley. The primary official or common language is ';
wwv_flow_imp.g_varchar2_table(442) := 'English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region,';
wwv_flow_imp.g_varchar2_table(443) := ' country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_populatio';
wwv_flow_imp.g_varchar2_table(444) := 'n_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''FM'', ''FSM'', UNISTR(''Oceania''), UN';
wwv_flow_imp.g_varchar2_table(445) := 'ISTR(''Micronesia''),'||wwv_flow.LF||
'    UNISTR(''Micronesia''), UNISTR(''Palikir''), 114182,'||wwv_flow.LF||
'    2026, UNISTR(''English'')';
wwv_flow_imp.g_varchar2_table(446) := ','||wwv_flow.LF||
'    UNISTR(''Micronesia is located in Micronesia. Its capital is Palikir. The primary official or c';
wwv_flow_imp.g_varchar2_table(447) := 'ommon language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_co';
wwv_flow_imp.g_varchar2_table(448) := 'de_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(449) := 'stimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''FO'', ''FRO'', UNI';
wwv_flow_imp.g_varchar2_table(450) := 'STR(''Europe''), UNISTR(''F\00E6r\00F8erne''),'||wwv_flow.LF||
'    UNISTR(''Faroe Islands''), UNISTR(''T\00F3rshavn''), 5652';
wwv_flow_imp.g_varchar2_table(451) := '6,'||wwv_flow.LF||
'    2026, UNISTR(''Danish, Faroese''),'||wwv_flow.LF||
'    UNISTR(''Faroe Islands is located in Northern Europe. Its';
wwv_flow_imp.g_varchar2_table(452) := ' capital is T\00F3rshavn. Official or common languages include Danish and Faroese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_';
wwv_flow_imp.g_varchar2_table(453) := 'srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country';
wwv_flow_imp.g_varchar2_table(454) := '_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common';
wwv_flow_imp.g_varchar2_table(455) := '_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''FR'', ''FRA'', UNISTR(''Europe''), UNISTR(''France''),'||wwv_flow.LF||
'    UNISTR(';
wwv_flow_imp.g_varchar2_table(456) := '''France''), UNISTR(''Paris''), 66746401,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''France is located in W';
wwv_flow_imp.g_varchar2_table(457) := 'estern Europe. Its capital is Paris. The primary official or common language is French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into';
wwv_flow_imp.g_varchar2_table(458) := ' eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    co';
wwv_flow_imp.g_varchar2_table(459) := 'untry_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_c';
wwv_flow_imp.g_varchar2_table(460) := 'ommon_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GA'', ''GAB'', UNISTR(''Africa''), UNISTR(''Gabon''),'||wwv_flow.LF||
'    UNI';
wwv_flow_imp.g_varchar2_table(461) := 'STR(''Gabon''), UNISTR(''Libreville''), 2647400,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''Gabon is locate';
wwv_flow_imp.g_varchar2_table(462) := 'd in Middle Africa. Its capital is Libreville. The primary official or common language is French.'')'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(463) := '  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_na';
wwv_flow_imp.g_varchar2_table(464) := 'me,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, off';
wwv_flow_imp.g_varchar2_table(465) := 'icial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GB'', ''GBR'', UNISTR(''Europe''), UNISTR(''United';
wwv_flow_imp.g_varchar2_table(466) := ' Kingdom''),'||wwv_flow.LF||
'    UNISTR(''United Kingdom''), UNISTR(''London''), 69931528,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(467) := '   UNISTR(''United Kingdom is located in Northern Europe. Its capital is London. The primary official';
wwv_flow_imp.g_varchar2_table(468) := ' or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, count';
wwv_flow_imp.g_varchar2_table(469) := 'ry_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(470) := '    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GD'', ''GRD''';
wwv_flow_imp.g_varchar2_table(471) := ', UNISTR(''Americas''), UNISTR(''Grenada''),'||wwv_flow.LF||
'    UNISTR(''Grenada''), UNISTR(''St. George''''s''), 117362,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(472) := ' 2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Grenada is located in Caribbean. Its capital is St. George''''s.';
wwv_flow_imp.g_varchar2_table(473) := ' The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    count';
wwv_flow_imp.g_varchar2_table(474) := 'ry_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, e';
wwv_flow_imp.g_varchar2_table(475) := 'stimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VAL';
wwv_flow_imp.g_varchar2_table(476) := 'UES ('||wwv_flow.LF||
'    ''GE'', ''GEO'', UNISTR(''Asia''), UNISTR(''\10E1\10D0\10E5\10D0\10E0\10D7\10D5\10D4\10DA\10DD''),';
wwv_flow_imp.g_varchar2_table(477) := ''||wwv_flow.LF||
'    UNISTR(''Georgia''), UNISTR(''Tbilisi''), 3804642,'||wwv_flow.LF||
'    2026, UNISTR(''Georgian''),'||wwv_flow.LF||
'    UNISTR(''Georgi';
wwv_flow_imp.g_varchar2_table(478) := 'a is located in Western Asia. Its capital is Tbilisi. The primary official or common language is Geo';
wwv_flow_imp.g_varchar2_table(479) := 'rgian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, c';
wwv_flow_imp.g_varchar2_table(480) := 'ountry_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_';
wwv_flow_imp.g_varchar2_table(481) := 'year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GF'', ''GUF'', UNISTR(''Americas''), UNI';
wwv_flow_imp.g_varchar2_table(482) := 'STR(''Guyane fran\00E7aise''),'||wwv_flow.LF||
'    UNISTR(''French Guiana''), UNISTR(''Cayenne''), 318872,'||wwv_flow.LF||
'    2026, UNIST';
wwv_flow_imp.g_varchar2_table(483) := 'R(''French''),'||wwv_flow.LF||
'    UNISTR(''French Guiana is located in South America. Its capital is Cayenne. The prim';
wwv_flow_imp.g_varchar2_table(484) := 'ary official or common language is French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_al';
wwv_flow_imp.g_varchar2_table(485) := 'pha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_p';
wwv_flow_imp.g_varchar2_table(486) := 'opulation,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(487) := '''GG'', ''GGY'', UNISTR(''Europe''), UNISTR(''Guernesey''),'||wwv_flow.LF||
'    UNISTR(''Guernsey''), UNISTR(''St. Peter Port'')';
wwv_flow_imp.g_varchar2_table(488) := ', 64610,'||wwv_flow.LF||
'    2026, UNISTR(''English, French, Guern\00E9siais''),'||wwv_flow.LF||
'    UNISTR(''Guernsey is located in No';
wwv_flow_imp.g_varchar2_table(489) := 'rthern Europe. Its capital is St. Peter Port. Official or common languages include English, French, ';
wwv_flow_imp.g_varchar2_table(490) := 'and Guern\00E9siais.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alp';
wwv_flow_imp.g_varchar2_table(491) := 'ha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimat';
wwv_flow_imp.g_varchar2_table(492) := 'ed_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GH'', ''GHA'', UNISTR(''A';
wwv_flow_imp.g_varchar2_table(493) := 'frica''), UNISTR(''Ghana''),'||wwv_flow.LF||
'    UNISTR(''Ghana''), UNISTR(''Accra''), 35697557,'||wwv_flow.LF||
'    2026, UNISTR(''English''';
wwv_flow_imp.g_varchar2_table(494) := '),'||wwv_flow.LF||
'    UNISTR(''Ghana is located in Western Africa. Its capital is Accra. The primary official or com';
wwv_flow_imp.g_varchar2_table(495) := 'mon language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code';
wwv_flow_imp.g_varchar2_table(496) := '_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    est';
wwv_flow_imp.g_varchar2_table(497) := 'imated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GI'', ''GIB'', UNIST';
wwv_flow_imp.g_varchar2_table(498) := 'R(''Europe''), UNISTR(''Gibraltar''),'||wwv_flow.LF||
'    UNISTR(''Gibraltar''), UNISTR(''Gibraltar''), 40867,'||wwv_flow.LF||
'    2026, UNI';
wwv_flow_imp.g_varchar2_table(499) := 'STR(''English''),'||wwv_flow.LF||
'    UNISTR(''Gibraltar is located in Southern Europe. Its capital is Gibraltar. The p';
wwv_flow_imp.g_varchar2_table(500) := 'rimary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_cod';
wwv_flow_imp.g_varchar2_table(501) := 'e_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimat';
wwv_flow_imp.g_varchar2_table(502) := 'ed_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(503) := '    ''GL'', ''GRL'', UNISTR(''Americas''), UNISTR(''Kalaallit Nunaat''),'||wwv_flow.LF||
'    UNISTR(''Greenland''), UNISTR(''Nu';
wwv_flow_imp.g_varchar2_table(504) := 'uk''), 55629,'||wwv_flow.LF||
'    2026, UNISTR(''Greenlandic''),'||wwv_flow.LF||
'    UNISTR(''Greenland is located in North America. Its';
wwv_flow_imp.g_varchar2_table(505) := ' capital is Nuuk. The primary official or common language is Greenlandic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_';
wwv_flow_imp.g_varchar2_table(506) := 'countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_eng';
wwv_flow_imp.g_varchar2_table(507) := 'lish, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language';
wwv_flow_imp.g_varchar2_table(508) := ', description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GM'', ''GMB'', UNISTR(''Africa''), UNISTR(''Gambia''),'||wwv_flow.LF||
'    UNISTR(''Gambia'')';
wwv_flow_imp.g_varchar2_table(509) := ', UNISTR(''Banjul''), 2884079,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Gambia is located in Western A';
wwv_flow_imp.g_varchar2_table(510) := 'frica. Its capital is Banjul. The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_s';
wwv_flow_imp.g_varchar2_table(511) := 'rch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_';
wwv_flow_imp.g_varchar2_table(512) := 'name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_';
wwv_flow_imp.g_varchar2_table(513) := 'language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GN'', ''GIN'', UNISTR(''Africa''), UNISTR(''Guin\00E9e''),'||wwv_flow.LF||
'    UNIS';
wwv_flow_imp.g_varchar2_table(514) := 'TR(''Guinea''), UNISTR(''Conakry''), 15441992,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''Guinea is located';
wwv_flow_imp.g_varchar2_table(515) := ' in Western Africa. Its capital is Conakry. The primary official or common language is French.'')'||wwv_flow.LF||
'  )';
wwv_flow_imp.g_varchar2_table(516) := ''||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,';
wwv_flow_imp.g_varchar2_table(517) := ''||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, offici';
wwv_flow_imp.g_varchar2_table(518) := 'al_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GP'', ''GLP'', UNISTR(''Americas''), UNISTR(''Guadelo';
wwv_flow_imp.g_varchar2_table(519) := 'upe''),'||wwv_flow.LF||
'    UNISTR(''Guadeloupe''), UNISTR(''Basse-Terre''), 372453,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNIS';
wwv_flow_imp.g_varchar2_table(520) := 'TR(''Guadeloupe is located in Caribbean. Its capital is Basse-Terre. The primary official or common l';
wwv_flow_imp.g_varchar2_table(521) := 'anguage is French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha';
wwv_flow_imp.g_varchar2_table(522) := '3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated';
wwv_flow_imp.g_varchar2_table(523) := '_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GQ'', ''GNQ'', UNISTR(''Afr';
wwv_flow_imp.g_varchar2_table(524) := 'ica''), UNISTR(''Guin\00E9e \00E9quatoriale''),'||wwv_flow.LF||
'    UNISTR(''Equatorial Guinea''), UNISTR(''Malabo''), 1984';
wwv_flow_imp.g_varchar2_table(525) := '468,'||wwv_flow.LF||
'    2026, UNISTR(''French, Portuguese, Spanish''),'||wwv_flow.LF||
'    UNISTR(''Equatorial Guinea is located in Mi';
wwv_flow_imp.g_varchar2_table(526) := 'ddle Africa. Its capital is Malabo. Official or common languages include French, Portuguese, and Spa';
wwv_flow_imp.g_varchar2_table(527) := 'nish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, co';
wwv_flow_imp.g_varchar2_table(528) := 'untry_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_y';
wwv_flow_imp.g_varchar2_table(529) := 'ear, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GR'', ''GRC'', UNISTR(''Europe''), UNISTR';
wwv_flow_imp.g_varchar2_table(530) := '(''\0395\03BB\03BB\03AC\03B4\03B1''),'||wwv_flow.LF||
'    UNISTR(''Greece''), UNISTR(''Athens''), 9897116,'||wwv_flow.LF||
'    2026, UNIST';
wwv_flow_imp.g_varchar2_table(531) := 'R(''Greek''),'||wwv_flow.LF||
'    UNISTR(''Greece is located in Southern Europe. Its capital is Athens. The primary off';
wwv_flow_imp.g_varchar2_table(532) := 'icial or common language is Greek.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, co';
wwv_flow_imp.g_varchar2_table(533) := 'untry_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_populatio';
wwv_flow_imp.g_varchar2_table(534) := 'n,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GS'', ''S';
wwv_flow_imp.g_varchar2_table(535) := 'GS'', UNISTR(''Antarctica''), UNISTR(''South Georgia''),'||wwv_flow.LF||
'    UNISTR(''South Georgia''), UNISTR(''King Edward';
wwv_flow_imp.g_varchar2_table(536) := ' Point''), 0,'||wwv_flow.LF||
'    2024, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''South Georgia is located in Antarctic. Its cap';
wwv_flow_imp.g_varchar2_table(537) := 'ital is King Edward Point. The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch';
wwv_flow_imp.g_varchar2_table(538) := '_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_nam';
wwv_flow_imp.g_varchar2_table(539) := 'e_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_lan';
wwv_flow_imp.g_varchar2_table(540) := 'guage, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GT'', ''GTM'', UNISTR(''Americas''), UNISTR(''Guatemala''),'||wwv_flow.LF||
'    UNISTR';
wwv_flow_imp.g_varchar2_table(541) := '(''Guatemala''), UNISTR(''Guatemala City''), 18967978,'||wwv_flow.LF||
'    2026, UNISTR(''Spanish''),'||wwv_flow.LF||
'    UNISTR(''Guatemal';
wwv_flow_imp.g_varchar2_table(542) := 'a is located in Central America. Its capital is Guatemala City. The primary official or common langu';
wwv_flow_imp.g_varchar2_table(543) := 'age is Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, ';
wwv_flow_imp.g_varchar2_table(544) := 'region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_po';
wwv_flow_imp.g_varchar2_table(545) := 'pulation_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GU'', ''GUM'', UNISTR(''Oceani';
wwv_flow_imp.g_varchar2_table(546) := 'a''), UNISTR(''Gu\00E5h\00E5n''),'||wwv_flow.LF||
'    UNISTR(''Guam''), UNISTR(''Hag\00E5t\00F1a''), 170185,'||wwv_flow.LF||
'    2026, UNIS';
wwv_flow_imp.g_varchar2_table(547) := 'TR(''Chamorro, English, Spanish''),'||wwv_flow.LF||
'    UNISTR(''Guam is located in Micronesia. Its capital is Hag\00E5';
wwv_flow_imp.g_varchar2_table(548) := 't\00F1a. Official or common languages include Chamorro, English, and Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_';
wwv_flow_imp.g_varchar2_table(549) := 'txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name';
wwv_flow_imp.g_varchar2_table(550) := '_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_lang';
wwv_flow_imp.g_varchar2_table(551) := 'uage, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''GW'', ''GNB'', UNISTR(''Africa''), UNISTR(''Guin\00E9-Bissau''),'||wwv_flow.LF||
'    UN';
wwv_flow_imp.g_varchar2_table(552) := 'ISTR(''Guinea-Bissau''), UNISTR(''Bissau''), 2297808,'||wwv_flow.LF||
'    2026, UNISTR(''Portuguese, Upper Guinea Creole''';
wwv_flow_imp.g_varchar2_table(553) := '),'||wwv_flow.LF||
'    UNISTR(''Guinea-Bissau is located in Western Africa. Its capital is Bissau. Official or common';
wwv_flow_imp.g_varchar2_table(554) := ' languages include Portuguese and Upper Guinea Creole.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    cou';
wwv_flow_imp.g_varchar2_table(555) := 'ntry_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city,';
wwv_flow_imp.g_varchar2_table(556) := ' estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) V';
wwv_flow_imp.g_varchar2_table(557) := 'ALUES ('||wwv_flow.LF||
'    ''GY'', ''GUY'', UNISTR(''Americas''), UNISTR(''Guyana''),'||wwv_flow.LF||
'    UNISTR(''Guyana''), UNISTR(''Georget';
wwv_flow_imp.g_varchar2_table(558) := 'own''), 840890,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Guyana is located in South America. Its capi';
wwv_flow_imp.g_varchar2_table(559) := 'tal is Georgetown. The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_cou';
wwv_flow_imp.g_varchar2_table(560) := 'ntries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_englis';
wwv_flow_imp.g_varchar2_table(561) := 'h, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, d';
wwv_flow_imp.g_varchar2_table(562) := 'escription'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''HK'', ''HKG'', UNISTR(''Asia''), UNISTR(''\9999\6E2F''),'||wwv_flow.LF||
'    UNISTR(''Hong Kong';
wwv_flow_imp.g_varchar2_table(563) := '''), UNISTR(''City of Victoria''), 7378602,'||wwv_flow.LF||
'    2026, UNISTR(''English, Chinese''),'||wwv_flow.LF||
'    UNISTR(''Hong Kong';
wwv_flow_imp.g_varchar2_table(564) := ' is located in Eastern Asia. Its capital is City of Victoria. Official or common languages include E';
wwv_flow_imp.g_varchar2_table(565) := 'nglish and Chinese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alph';
wwv_flow_imp.g_varchar2_table(566) := 'a3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimate';
wwv_flow_imp.g_varchar2_table(567) := 'd_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''HM'', ''HMD'', UNISTR(''An';
wwv_flow_imp.g_varchar2_table(568) := 'tarctica''), UNISTR(''Heard Island and McDonald Islands''),'||wwv_flow.LF||
'    UNISTR(''Heard Island and McDonald Islan';
wwv_flow_imp.g_varchar2_table(569) := 'ds''), NULL, 0,'||wwv_flow.LF||
'    2024, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Heard Island and McDonald Islands is located';
wwv_flow_imp.g_varchar2_table(570) := ' in Antarctic and has no permanent capital. The primary official or common language is English.'')'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(571) := ')'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name';
wwv_flow_imp.g_varchar2_table(572) := ','||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, offic';
wwv_flow_imp.g_varchar2_table(573) := 'ial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''HN'', ''HND'', UNISTR(''Americas''), UNISTR(''Hondur';
wwv_flow_imp.g_varchar2_table(574) := 'as''),'||wwv_flow.LF||
'    UNISTR(''Honduras''), UNISTR(''Tegucigalpa''), 11184760,'||wwv_flow.LF||
'    2026, UNISTR(''Spanish''),'||wwv_flow.LF||
'    UNIS';
wwv_flow_imp.g_varchar2_table(575) := 'TR(''Honduras is located in Central America. Its capital is Tegucigalpa. The primary official or comm';
wwv_flow_imp.g_varchar2_table(576) := 'on language is Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_';
wwv_flow_imp.g_varchar2_table(577) := 'alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    esti';
wwv_flow_imp.g_varchar2_table(578) := 'mated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''HR'', ''HRV'', UNISTR';
wwv_flow_imp.g_varchar2_table(579) := '(''Europe''), UNISTR(''Hrvatska''),'||wwv_flow.LF||
'    UNISTR(''Croatia''), UNISTR(''Zagreb''), 3822345,'||wwv_flow.LF||
'    2026, UNISTR(''';
wwv_flow_imp.g_varchar2_table(580) := 'Croatian''),'||wwv_flow.LF||
'    UNISTR(''Croatia is located in Southeast Europe. Its capital is Zagreb. The primary o';
wwv_flow_imp.g_varchar2_table(581) := 'fficial or common language is Croatian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha';
wwv_flow_imp.g_varchar2_table(582) := '2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_popu';
wwv_flow_imp.g_varchar2_table(583) := 'lation,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''HT';
wwv_flow_imp.g_varchar2_table(584) := ''', ''HTI'', UNISTR(''Americas''), UNISTR(''Ha\00EFti''),'||wwv_flow.LF||
'    UNISTR(''Haiti''), UNISTR(''Port-au-Prince''), 12';
wwv_flow_imp.g_varchar2_table(585) := '037506,'||wwv_flow.LF||
'    2026, UNISTR(''French, Haitian Creole''),'||wwv_flow.LF||
'    UNISTR(''Haiti is located in Caribbean. Its c';
wwv_flow_imp.g_varchar2_table(586) := 'apital is Port-au-Prince. Official or common languages include French and Haitian Creole.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  in';
wwv_flow_imp.g_varchar2_table(587) := 'to eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(588) := 'country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or';
wwv_flow_imp.g_varchar2_table(589) := '_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''HU'', ''HUN'', UNISTR(''Europe''), UNISTR(''Magyarorsz\00E';
wwv_flow_imp.g_varchar2_table(590) := '1g''),'||wwv_flow.LF||
'    UNISTR(''Hungary''), UNISTR(''Budapest''), 9585818,'||wwv_flow.LF||
'    2026, UNISTR(''Hungarian''),'||wwv_flow.LF||
'    UNISTR(';
wwv_flow_imp.g_varchar2_table(591) := '''Hungary is located in Central Europe. Its capital is Budapest. The primary official or common langu';
wwv_flow_imp.g_varchar2_table(592) := 'age is Hungarian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'SELECT 1 FROM dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'INSERT ALL'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_';
wwv_flow_imp.g_varchar2_table(593) := 'code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, esti';
wwv_flow_imp.g_varchar2_table(594) := 'mated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES';
wwv_flow_imp.g_varchar2_table(595) := ' ('||wwv_flow.LF||
'    ''ID'', ''IDN'', UNISTR(''Asia''), UNISTR(''Indonesia''),'||wwv_flow.LF||
'    UNISTR(''Indonesia''), UNISTR(''Jakarta''),';
wwv_flow_imp.g_varchar2_table(596) := ' 287886782,'||wwv_flow.LF||
'    2026, UNISTR(''Indonesian''),'||wwv_flow.LF||
'    UNISTR(''Indonesia is located in South-Eastern Asia. ';
wwv_flow_imp.g_varchar2_table(597) := 'Its capital is Jakarta. The primary official or common language is Indonesian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch';
wwv_flow_imp.g_varchar2_table(598) := '_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_nam';
wwv_flow_imp.g_varchar2_table(599) := 'e_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_lan';
wwv_flow_imp.g_varchar2_table(600) := 'guage, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''IE'', ''IRL'', UNISTR(''Europe''), UNISTR(''\00C9ire''),'||wwv_flow.LF||
'    UNISTR(''I';
wwv_flow_imp.g_varchar2_table(601) := 'reland''), UNISTR(''Dublin''), 5356950,'||wwv_flow.LF||
'    2026, UNISTR(''English, Irish''),'||wwv_flow.LF||
'    UNISTR(''Ireland is loca';
wwv_flow_imp.g_varchar2_table(602) := 'ted in Northern Europe. Its capital is Dublin. Official or common languages include English and Iris';
wwv_flow_imp.g_varchar2_table(603) := 'h.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, count';
wwv_flow_imp.g_varchar2_table(604) := 'ry_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year';
wwv_flow_imp.g_varchar2_table(605) := ', official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''IL'', ''ISR'', UNISTR(''Asia''), UNISTR(''\06';
wwv_flow_imp.g_varchar2_table(606) := '25\0633\0631\0627\0626\064A\0644''),'||wwv_flow.LF||
'    UNISTR(''Israel''), UNISTR(''Jerusalem''), 9647689,'||wwv_flow.LF||
'    2026, UN';
wwv_flow_imp.g_varchar2_table(607) := 'ISTR(''Arabic, Hebrew''),'||wwv_flow.LF||
'    UNISTR(''Israel is located in Western Asia. Its capital is Jerusalem. Off';
wwv_flow_imp.g_varchar2_table(608) := 'icial or common languages include Arabic and Hebrew.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    count';
wwv_flow_imp.g_varchar2_table(609) := 'ry_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, e';
wwv_flow_imp.g_varchar2_table(610) := 'stimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VAL';
wwv_flow_imp.g_varchar2_table(611) := 'UES ('||wwv_flow.LF||
'    ''IM'', ''IMN'', UNISTR(''Europe''), UNISTR(''Mannin''),'||wwv_flow.LF||
'    UNISTR(''Isle of Man''), UNISTR(''Dougla';
wwv_flow_imp.g_varchar2_table(612) := 's''), 84054,'||wwv_flow.LF||
'    2026, UNISTR(''English, Manx''),'||wwv_flow.LF||
'    UNISTR(''Isle of Man is located in Northern Europe';
wwv_flow_imp.g_varchar2_table(613) := '. Its capital is Douglas. Official or common languages include English and Manx.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_sr';
wwv_flow_imp.g_varchar2_table(614) := 'ch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_n';
wwv_flow_imp.g_varchar2_table(615) := 'ame_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_l';
wwv_flow_imp.g_varchar2_table(616) := 'anguage, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''IN'', ''IND'', UNISTR(''Asia''), UNISTR(''\092D\093E\0930\0924''),'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(617) := '   UNISTR(''India''), UNISTR(''New Delhi''), 1476625576,'||wwv_flow.LF||
'    2026, UNISTR(''English, Hindi, Tamil''),'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(618) := 'UNISTR(''India is located in Southern Asia. Its capital is New Delhi. Official or common languages in';
wwv_flow_imp.g_varchar2_table(619) := 'clude English, Hindi, and Tamil.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, coun';
wwv_flow_imp.g_varchar2_table(620) := 'try_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,';
wwv_flow_imp.g_varchar2_table(621) := ''||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''IO'', ''IOT';
wwv_flow_imp.g_varchar2_table(622) := ''', UNISTR(''Africa''), UNISTR(''British Indian Ocean Territory''),'||wwv_flow.LF||
'    UNISTR(''British Indian Ocean Terr';
wwv_flow_imp.g_varchar2_table(623) := 'itory''), UNISTR(''Diego Garcia''), 0,'||wwv_flow.LF||
'    2024, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''British Indian Ocean Te';
wwv_flow_imp.g_varchar2_table(624) := 'rritory is located in Eastern Africa. Its capital is Diego Garcia. The primary official or common la';
wwv_flow_imp.g_varchar2_table(625) := 'nguage is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha';
wwv_flow_imp.g_varchar2_table(626) := '3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated';
wwv_flow_imp.g_varchar2_table(627) := '_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''IQ'', ''IRQ'', UNISTR(''Asi';
wwv_flow_imp.g_varchar2_table(628) := 'a''), UNISTR(''\0627\0644\0639\0631\0627\0642''),'||wwv_flow.LF||
'    UNISTR(''Iraq''), UNISTR(''Baghdad''), 48007437,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(629) := '2026, UNISTR(''Arabic, Aramaic, Sorani''),'||wwv_flow.LF||
'    UNISTR(''Iraq is located in Western Asia. Its capital is';
wwv_flow_imp.g_varchar2_table(630) := ' Baghdad. Official or common languages include Arabic, Aramaic, and Sorani.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_tx';
wwv_flow_imp.g_varchar2_table(631) := 't_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_e';
wwv_flow_imp.g_varchar2_table(632) := 'nglish, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_langua';
wwv_flow_imp.g_varchar2_table(633) := 'ge, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''IR'', ''IRN'', UNISTR(''Asia''), UNISTR(''\0627\06CC\0631\0627\0646''),'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(634) := '   UNISTR(''Iran''), UNISTR(''Tehran''), 93168497,'||wwv_flow.LF||
'    2026, UNISTR(''Persian (Farsi)''),'||wwv_flow.LF||
'    UNISTR(''Iran';
wwv_flow_imp.g_varchar2_table(635) := ' is located in Southern Asia. Its capital is Tehran. The primary official or common language is Pers';
wwv_flow_imp.g_varchar2_table(636) := 'ian (Farsi).'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, reg';
wwv_flow_imp.g_varchar2_table(637) := 'ion, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_popul';
wwv_flow_imp.g_varchar2_table(638) := 'ation_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''IS'', ''ISL'', UNISTR(''Europe''),';
wwv_flow_imp.g_varchar2_table(639) := ' UNISTR(''\00CDsland''),'||wwv_flow.LF||
'    UNISTR(''Iceland''), UNISTR(''Reykjavik''), 402329,'||wwv_flow.LF||
'    2026, UNISTR(''Iceland';
wwv_flow_imp.g_varchar2_table(640) := 'ic''),'||wwv_flow.LF||
'    UNISTR(''Iceland is located in Northern Europe. Its capital is Reykjavik. The primary offic';
wwv_flow_imp.g_varchar2_table(641) := 'ial or common language is Icelandic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, ';
wwv_flow_imp.g_varchar2_table(642) := 'country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_populat';
wwv_flow_imp.g_varchar2_table(643) := 'ion,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''IT'', ';
wwv_flow_imp.g_varchar2_table(644) := '''ITA'', UNISTR(''Europe''), UNISTR(''Italia''),'||wwv_flow.LF||
'    UNISTR(''Italy''), UNISTR(''Rome''), 58926166,'||wwv_flow.LF||
'    2026, ';
wwv_flow_imp.g_varchar2_table(645) := 'UNISTR(''Italian''),'||wwv_flow.LF||
'    UNISTR(''Italy is located in Southern Europe. Its capital is Rome. The primary';
wwv_flow_imp.g_varchar2_table(646) := ' official or common language is Italian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alph';
wwv_flow_imp.g_varchar2_table(647) := 'a2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_pop';
wwv_flow_imp.g_varchar2_table(648) := 'ulation,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''J';
wwv_flow_imp.g_varchar2_table(649) := 'E'', ''JEY'', UNISTR(''Europe''), UNISTR(''J\00E8rri''),'||wwv_flow.LF||
'    UNISTR(''Jersey''), UNISTR(''Saint Helier''), 1041';
wwv_flow_imp.g_varchar2_table(650) := '06,'||wwv_flow.LF||
'    2026, UNISTR(''English, French, J\00E8rriais''),'||wwv_flow.LF||
'    UNISTR(''Jersey is located in Northern Eur';
wwv_flow_imp.g_varchar2_table(651) := 'ope. Its capital is Saint Helier. Official or common languages include English, French, and J\00E8rr';
wwv_flow_imp.g_varchar2_table(652) := 'iais.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, co';
wwv_flow_imp.g_varchar2_table(653) := 'untry_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_y';
wwv_flow_imp.g_varchar2_table(654) := 'ear, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''JM'', ''JAM'', UNISTR(''Americas''), UNIS';
wwv_flow_imp.g_varchar2_table(655) := 'TR(''Jamaica''),'||wwv_flow.LF||
'    UNISTR(''Jamaica''), UNISTR(''Kingston''), 2833404,'||wwv_flow.LF||
'    2026, UNISTR(''English, Jamaic';
wwv_flow_imp.g_varchar2_table(656) := 'an Patois''),'||wwv_flow.LF||
'    UNISTR(''Jamaica is located in Caribbean. Its capital is Kingston. Official or commo';
wwv_flow_imp.g_varchar2_table(657) := 'n languages include English and Jamaican Patois.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_c';
wwv_flow_imp.g_varchar2_table(658) := 'ode_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estim';
wwv_flow_imp.g_varchar2_table(659) := 'ated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ';
wwv_flow_imp.g_varchar2_table(660) := '('||wwv_flow.LF||
'    ''JO'', ''JOR'', UNISTR(''Asia''), UNISTR(''\0627\0644\0623\0631\062F\0646''),'||wwv_flow.LF||
'    UNISTR(''Jordan''), U';
wwv_flow_imp.g_varchar2_table(661) := 'NISTR(''Amman''), 11589532,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic''),'||wwv_flow.LF||
'    UNISTR(''Jordan is located in Western Asia.';
wwv_flow_imp.g_varchar2_table(662) := ' Its capital is Amman. The primary official or common language is Arabic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_';
wwv_flow_imp.g_varchar2_table(663) := 'countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_eng';
wwv_flow_imp.g_varchar2_table(664) := 'lish, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language';
wwv_flow_imp.g_varchar2_table(665) := ', description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''JP'', ''JPN'', UNISTR(''Asia''), UNISTR(''\65E5\672C''),'||wwv_flow.LF||
'    UNISTR(''Japan''';
wwv_flow_imp.g_varchar2_table(666) := '), UNISTR(''Tokyo''), 122427731,'||wwv_flow.LF||
'    2026, UNISTR(''Japanese''),'||wwv_flow.LF||
'    UNISTR(''Japan is located in Eastern';
wwv_flow_imp.g_varchar2_table(667) := ' Asia. Its capital is Tokyo. The primary official or common language is Japanese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_s';
wwv_flow_imp.g_varchar2_table(668) := 'rch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_';
wwv_flow_imp.g_varchar2_table(669) := 'name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_';
wwv_flow_imp.g_varchar2_table(670) := 'language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''KE'', ''KEN'', UNISTR(''Africa''), UNISTR(''Kenya''),'||wwv_flow.LF||
'    UNISTR(''K';
wwv_flow_imp.g_varchar2_table(671) := 'enya''), UNISTR(''Nairobi''), 58636412,'||wwv_flow.LF||
'    2026, UNISTR(''English, Swahili''),'||wwv_flow.LF||
'    UNISTR(''Kenya is loca';
wwv_flow_imp.g_varchar2_table(672) := 'ted in Eastern Africa. Its capital is Nairobi. Official or common languages include English and Swah';
wwv_flow_imp.g_varchar2_table(673) := 'ili.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, cou';
wwv_flow_imp.g_varchar2_table(674) := 'ntry_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_ye';
wwv_flow_imp.g_varchar2_table(675) := 'ar, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''KG'', ''KGZ'', UNISTR(''Asia''), UNISTR(''\';
wwv_flow_imp.g_varchar2_table(676) := '041A\044B\0440\0433\044B\0437\0441\0442\0430\043D''),'||wwv_flow.LF||
'    UNISTR(''Kyrgyzstan''), UNISTR(''Bishkek''), 74';
wwv_flow_imp.g_varchar2_table(677) := '00464,'||wwv_flow.LF||
'    2026, UNISTR(''Kyrgyz, Russian''),'||wwv_flow.LF||
'    UNISTR(''Kyrgyzstan is located in Central Asia. Its c';
wwv_flow_imp.g_varchar2_table(678) := 'apital is Bishkek. Official or common languages include Kyrgyz and Russian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_tx';
wwv_flow_imp.g_varchar2_table(679) := 't_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_e';
wwv_flow_imp.g_varchar2_table(680) := 'nglish, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_langua';
wwv_flow_imp.g_varchar2_table(681) := 'ge, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''KH'', ''KHM'', UNISTR(''Asia''), UNISTR(''K\00E2mp\016Dch\00E9a''),'||wwv_flow.LF||
'    U';
wwv_flow_imp.g_varchar2_table(682) := 'NISTR(''Cambodia''), UNISTR(''Phnom Penh''), 18051219,'||wwv_flow.LF||
'    2026, UNISTR(''Khmer''),'||wwv_flow.LF||
'    UNISTR(''Cambodia i';
wwv_flow_imp.g_varchar2_table(683) := 's located in South-Eastern Asia. Its capital is Phnom Penh. The primary official or common language ';
wwv_flow_imp.g_varchar2_table(684) := 'is Khmer.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region';
wwv_flow_imp.g_varchar2_table(685) := ', country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_populati';
wwv_flow_imp.g_varchar2_table(686) := 'on_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''KI'', ''KIR'', UNISTR(''Oceania''), U';
wwv_flow_imp.g_varchar2_table(687) := 'NISTR(''Kiribati''),'||wwv_flow.LF||
'    UNISTR(''Kiribati''), UNISTR(''South Tarawa''), 138445,'||wwv_flow.LF||
'    2026, UNISTR(''English';
wwv_flow_imp.g_varchar2_table(688) := ', Gilbertese''),'||wwv_flow.LF||
'    UNISTR(''Kiribati is located in Micronesia. Its capital is South Tarawa. Official';
wwv_flow_imp.g_varchar2_table(689) := ' or common languages include English and Gilbertese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    count';
wwv_flow_imp.g_varchar2_table(690) := 'ry_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, e';
wwv_flow_imp.g_varchar2_table(691) := 'stimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VAL';
wwv_flow_imp.g_varchar2_table(692) := 'UES ('||wwv_flow.LF||
'    ''KM'', ''COM'', UNISTR(''Africa''), UNISTR(''\062C\0632\0631 \0627\0644\0642\0645\0631''),'||wwv_flow.LF||
'    UN';
wwv_flow_imp.g_varchar2_table(693) := 'ISTR(''Comoros''), UNISTR(''Moroni''), 899010,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic, French, Comorian''),'||wwv_flow.LF||
'    UNISTR(';
wwv_flow_imp.g_varchar2_table(694) := '''Comoros is located in Eastern Africa. Its capital is Moroni. Official or common languages include A';
wwv_flow_imp.g_varchar2_table(695) := 'rabic, French, and Comorian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_';
wwv_flow_imp.g_varchar2_table(696) := 'code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(697) := ' estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''KN'', ''KNA'', U';
wwv_flow_imp.g_varchar2_table(698) := 'NISTR(''Americas''), UNISTR(''Saint Kitts and Nevis''),'||wwv_flow.LF||
'    UNISTR(''Saint Kitts and Nevis''), UNISTR(''Bas';
wwv_flow_imp.g_varchar2_table(699) := 'seterre''), 46992,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Saint Kitts and Nevis is located in Carib';
wwv_flow_imp.g_varchar2_table(700) := 'bean. Its capital is Basseterre. The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eb';
wwv_flow_imp.g_varchar2_table(701) := 'a_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    count';
wwv_flow_imp.g_varchar2_table(702) := 'ry_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_comm';
wwv_flow_imp.g_varchar2_table(703) := 'on_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''KP'', ''PRK'', UNISTR(''Asia''), UNISTR(''\C870\C120''),'||wwv_flow.LF||
'    UNI';
wwv_flow_imp.g_varchar2_table(704) := 'STR(''North Korea''), UNISTR(''Pyongyang''), 26633691,'||wwv_flow.LF||
'    2026, UNISTR(''Korean''),'||wwv_flow.LF||
'    UNISTR(''North Kor';
wwv_flow_imp.g_varchar2_table(705) := 'ea is located in Eastern Asia. Its capital is Pyongyang. The primary official or common language is ';
wwv_flow_imp.g_varchar2_table(706) := 'Korean.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, ';
wwv_flow_imp.g_varchar2_table(707) := 'country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population';
wwv_flow_imp.g_varchar2_table(708) := '_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''KR'', ''KOR'', UNISTR(''Asia''), UNISTR';
wwv_flow_imp.g_varchar2_table(709) := '(''\D55C\AD6D''),'||wwv_flow.LF||
'    UNISTR(''South Korea''), UNISTR(''Seoul''), 51600388,'||wwv_flow.LF||
'    2026, UNISTR(''Korean''),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(710) := '  UNISTR(''South Korea is located in Eastern Asia. Its capital is Seoul. The primary official or comm';
wwv_flow_imp.g_varchar2_table(711) := 'on language is Korean.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_a';
wwv_flow_imp.g_varchar2_table(712) := 'lpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estim';
wwv_flow_imp.g_varchar2_table(713) := 'ated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''KW'', ''KWT'', UNISTR(';
wwv_flow_imp.g_varchar2_table(714) := '''Asia''), UNISTR(''\0627\0644\0643\0648\064A\062A''),'||wwv_flow.LF||
'    UNISTR(''Kuwait''), UNISTR(''Kuwait City''), 5102';
wwv_flow_imp.g_varchar2_table(715) := '773,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic''),'||wwv_flow.LF||
'    UNISTR(''Kuwait is located in Western Asia. Its capital is Kuwai';
wwv_flow_imp.g_varchar2_table(716) := 't City. The primary official or common language is Arabic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(717) := ' country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_c';
wwv_flow_imp.g_varchar2_table(718) := 'ity, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(719) := ' ) VALUES ('||wwv_flow.LF||
'    ''KY'', ''CYM'', UNISTR(''Americas''), UNISTR(''Cayman Islands''),'||wwv_flow.LF||
'    UNISTR(''Cayman Island';
wwv_flow_imp.g_varchar2_table(720) := 's''), UNISTR(''George Town''), 77196,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Cayman Islands is locate';
wwv_flow_imp.g_varchar2_table(721) := 'd in Caribbean. Its capital is George Town. The primary official or common language is English.'')'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(722) := ')'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name';
wwv_flow_imp.g_varchar2_table(723) := ','||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, offic';
wwv_flow_imp.g_varchar2_table(724) := 'ial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''KZ'', ''KAZ'', UNISTR(''Asia''), UNISTR(''\049A\0430';
wwv_flow_imp.g_varchar2_table(725) := '\0437\0430\049B\0441\0442\0430\043D''),'||wwv_flow.LF||
'    UNISTR(''Kazakhstan''), UNISTR(''Astana''), 21083626,'||wwv_flow.LF||
'    202';
wwv_flow_imp.g_varchar2_table(726) := '6, UNISTR(''Kazakh, Russian''),'||wwv_flow.LF||
'    UNISTR(''Kazakhstan is located in Central Asia. Its capital is Asta';
wwv_flow_imp.g_varchar2_table(727) := 'na. Official or common languages include Kazakh and Russian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(728) := '   country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital';
wwv_flow_imp.g_varchar2_table(729) := '_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description';
wwv_flow_imp.g_varchar2_table(730) := ''||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''LA'', ''LAO'', UNISTR(''Asia''), UNISTR(''\0EAA\0E9B\0E9B\0EA5\0EB2\0EA7''),'||wwv_flow.LF||
'    UNISTR(';
wwv_flow_imp.g_varchar2_table(731) := '''Laos''), UNISTR(''Vientiane''), 7974018,'||wwv_flow.LF||
'    2026, UNISTR(''Lao''),'||wwv_flow.LF||
'    UNISTR(''Laos is located in South';
wwv_flow_imp.g_varchar2_table(732) := '-Eastern Asia. Its capital is Vientiane. The primary official or common language is Lao.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  int';
wwv_flow_imp.g_varchar2_table(733) := 'o eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(734) := 'ountry_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_';
wwv_flow_imp.g_varchar2_table(735) := 'common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''LB'', ''LBN'', UNISTR(''Asia''), UNISTR(''\0644\0628\0646\0';
wwv_flow_imp.g_varchar2_table(736) := '627\0646''),'||wwv_flow.LF||
'    UNISTR(''Lebanon''), UNISTR(''Beirut''), 5897467,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic, French''),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(737) := '  UNISTR(''Lebanon is located in Western Asia. Its capital is Beirut. Official or common languages in';
wwv_flow_imp.g_varchar2_table(738) := 'clude Arabic and French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code';
wwv_flow_imp.g_varchar2_table(739) := '_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    est';
wwv_flow_imp.g_varchar2_table(740) := 'imated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''LC'', ''LCA'', UNIST';
wwv_flow_imp.g_varchar2_table(741) := 'R(''Americas''), UNISTR(''Saint Lucia''),'||wwv_flow.LF||
'    UNISTR(''Saint Lucia''), UNISTR(''Castries''), 180488,'||wwv_flow.LF||
'    202';
wwv_flow_imp.g_varchar2_table(742) := '6, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Saint Lucia is located in Caribbean. Its capital is Castries. The ';
wwv_flow_imp.g_varchar2_table(743) := 'primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_co';
wwv_flow_imp.g_varchar2_table(744) := 'de_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estima';
wwv_flow_imp.g_varchar2_table(745) := 'ted_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES (';
wwv_flow_imp.g_varchar2_table(746) := ''||wwv_flow.LF||
'    ''LI'', ''LIE'', UNISTR(''Europe''), UNISTR(''Liechtenstein''),'||wwv_flow.LF||
'    UNISTR(''Liechtenstein''), UNISTR(''Va';
wwv_flow_imp.g_varchar2_table(747) := 'duz''), 40368,'||wwv_flow.LF||
'    2026, UNISTR(''German''),'||wwv_flow.LF||
'    UNISTR(''Liechtenstein is located in Western Europe. It';
wwv_flow_imp.g_varchar2_table(748) := 's capital is Vaduz. The primary official or common language is German.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_cou';
wwv_flow_imp.g_varchar2_table(749) := 'ntries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_englis';
wwv_flow_imp.g_varchar2_table(750) := 'h, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, d';
wwv_flow_imp.g_varchar2_table(751) := 'escription'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''LK'', ''LKA'', UNISTR(''Asia''), UNISTR(''\0DC1\0DCA\200D\0DBB\0DD3 \0DBD\0D8';
wwv_flow_imp.g_varchar2_table(752) := '2\0D9A\0DCF\0DC0''),'||wwv_flow.LF||
'    UNISTR(''Sri Lanka''), UNISTR(''Colombo''), 23348315,'||wwv_flow.LF||
'    2026, UNISTR(''Sinhala,';
wwv_flow_imp.g_varchar2_table(753) := ' Tamil''),'||wwv_flow.LF||
'    UNISTR(''Sri Lanka is located in Southern Asia. Its capital is Colombo. Official or com';
wwv_flow_imp.g_varchar2_table(754) := 'mon languages include Sinhala and Tamil.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alph';
wwv_flow_imp.g_varchar2_table(755) := 'a2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_pop';
wwv_flow_imp.g_varchar2_table(756) := 'ulation,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''L';
wwv_flow_imp.g_varchar2_table(757) := 'R'', ''LBR'', UNISTR(''Africa''), UNISTR(''Liberia''),'||wwv_flow.LF||
'    UNISTR(''Liberia''), UNISTR(''Monrovia''), 5853949,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(758) := '    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Liberia is located in Western Africa. Its capital is Monrov';
wwv_flow_imp.g_varchar2_table(759) := 'ia. The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    co';
wwv_flow_imp.g_varchar2_table(760) := 'untry_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city';
wwv_flow_imp.g_varchar2_table(761) := ', estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) ';
wwv_flow_imp.g_varchar2_table(762) := 'VALUES ('||wwv_flow.LF||
'    ''LS'', ''LSO'', UNISTR(''Africa''), UNISTR(''Lesotho''),'||wwv_flow.LF||
'    UNISTR(''Lesotho''), UNISTR(''Maseru';
wwv_flow_imp.g_varchar2_table(763) := '''), 2389336,'||wwv_flow.LF||
'    2026, UNISTR(''English, Sotho''),'||wwv_flow.LF||
'    UNISTR(''Lesotho is located in Southern Africa. ';
wwv_flow_imp.g_varchar2_table(764) := 'Its capital is Maseru. Official or common languages include English and Sotho.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch';
wwv_flow_imp.g_varchar2_table(765) := '_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_nam';
wwv_flow_imp.g_varchar2_table(766) := 'e_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_lan';
wwv_flow_imp.g_varchar2_table(767) := 'guage, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''LT'', ''LTU'', UNISTR(''Europe''), UNISTR(''Lietuva''),'||wwv_flow.LF||
'    UNISTR(''Li';
wwv_flow_imp.g_varchar2_table(768) := 'thuania''), UNISTR(''Vilnius''), 2797338,'||wwv_flow.LF||
'    2026, UNISTR(''Lithuanian''),'||wwv_flow.LF||
'    UNISTR(''Lithuania is loca';
wwv_flow_imp.g_varchar2_table(769) := 'ted in Northern Europe. Its capital is Vilnius. The primary official or common language is Lithuania';
wwv_flow_imp.g_varchar2_table(770) := 'n.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, count';
wwv_flow_imp.g_varchar2_table(771) := 'ry_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year';
wwv_flow_imp.g_varchar2_table(772) := ', official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''LU'', ''LUX'', UNISTR(''Europe''), UNISTR(''L';
wwv_flow_imp.g_varchar2_table(773) := 'uxemburg''),'||wwv_flow.LF||
'    UNISTR(''Luxembourg''), UNISTR(''Luxembourg''), 687448,'||wwv_flow.LF||
'    2026, UNISTR(''German, French';
wwv_flow_imp.g_varchar2_table(774) := ', Luxembourgish''),'||wwv_flow.LF||
'    UNISTR(''Luxembourg is located in Western Europe. Its capital is Luxembourg. O';
wwv_flow_imp.g_varchar2_table(775) := 'fficial or common languages include German, French, and Luxembourgish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_cou';
wwv_flow_imp.g_varchar2_table(776) := 'ntries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_englis';
wwv_flow_imp.g_varchar2_table(777) := 'h, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, d';
wwv_flow_imp.g_varchar2_table(778) := 'escription'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''LV'', ''LVA'', UNISTR(''Europe''), UNISTR(''Latvija''),'||wwv_flow.LF||
'    UNISTR(''Latvia''), ';
wwv_flow_imp.g_varchar2_table(779) := 'UNISTR(''Riga''), 1835935,'||wwv_flow.LF||
'    2026, UNISTR(''Latvian''),'||wwv_flow.LF||
'    UNISTR(''Latvia is located in Northern Euro';
wwv_flow_imp.g_varchar2_table(780) := 'pe. Its capital is Riga. The primary official or common language is Latvian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_t';
wwv_flow_imp.g_varchar2_table(781) := 'xt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_';
wwv_flow_imp.g_varchar2_table(782) := 'english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_langu';
wwv_flow_imp.g_varchar2_table(783) := 'age, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''LY'', ''LBY'', UNISTR(''Africa''), UNISTR(''\0644\064A\0628\064A\0627'')';
wwv_flow_imp.g_varchar2_table(784) := ','||wwv_flow.LF||
'    UNISTR(''Libya''), UNISTR(''Tripoli''), 7539852,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic''),'||wwv_flow.LF||
'    UNISTR(''Libya is ';
wwv_flow_imp.g_varchar2_table(785) := 'located in Northern Africa. Its capital is Tripoli. The primary official or common language is Arabi';
wwv_flow_imp.g_varchar2_table(786) := 'c.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, count';
wwv_flow_imp.g_varchar2_table(787) := 'ry_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year';
wwv_flow_imp.g_varchar2_table(788) := ', official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''MA'', ''MAR'', UNISTR(''Africa''), UNISTR(''\';
wwv_flow_imp.g_varchar2_table(789) := '0627\0644\0645\063A\0631\0628''),'||wwv_flow.LF||
'    UNISTR(''Morocco''), UNISTR(''Rabat''), 38762441,'||wwv_flow.LF||
'    2026, UNISTR(';
wwv_flow_imp.g_varchar2_table(790) := '''Arabic, Berber''),'||wwv_flow.LF||
'    UNISTR(''Morocco is located in Northern Africa. Its capital is Rabat. Official';
wwv_flow_imp.g_varchar2_table(791) := ' or common languages include Arabic and Berber.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_co';
wwv_flow_imp.g_varchar2_table(792) := 'de_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estima';
wwv_flow_imp.g_varchar2_table(793) := 'ted_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES (';
wwv_flow_imp.g_varchar2_table(794) := ''||wwv_flow.LF||
'    ''MC'', ''MCO'', UNISTR(''Europe''), UNISTR(''Monaco''),'||wwv_flow.LF||
'    UNISTR(''Monaco''), UNISTR(''Monaco''), 38087,';
wwv_flow_imp.g_varchar2_table(795) := ''||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''Monaco is located in Western Europe. Its capital is Monaco.';
wwv_flow_imp.g_varchar2_table(796) := ' The primary official or common language is French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    countr';
wwv_flow_imp.g_varchar2_table(797) := 'y_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, es';
wwv_flow_imp.g_varchar2_table(798) := 'timated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALU';
wwv_flow_imp.g_varchar2_table(799) := 'ES ('||wwv_flow.LF||
'    ''MD'', ''MDA'', UNISTR(''Europe''), UNISTR(''Moldova''),'||wwv_flow.LF||
'    UNISTR(''Moldova''), UNISTR(''Chi\0219in';
wwv_flow_imp.g_varchar2_table(800) := '\0103u''), 2961253,'||wwv_flow.LF||
'    2026, UNISTR(''Moldavian''),'||wwv_flow.LF||
'    UNISTR(''Moldova is located in Eastern Europe. ';
wwv_flow_imp.g_varchar2_table(801) := 'Its capital is Chi\0219in\0103u. The primary official or common language is Moldavian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into ';
wwv_flow_imp.g_varchar2_table(802) := 'eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    cou';
wwv_flow_imp.g_varchar2_table(803) := 'ntry_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_co';
wwv_flow_imp.g_varchar2_table(804) := 'mmon_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''ME'', ''MNE'', UNISTR(''Europe''), UNISTR(''\0426\0440\043D\0';
wwv_flow_imp.g_varchar2_table(805) := '430 \0413\043E\0440\0430''),'||wwv_flow.LF||
'    UNISTR(''Montenegro''), UNISTR(''Podgorica''), 626233,'||wwv_flow.LF||
'    2026, UNISTR(';
wwv_flow_imp.g_varchar2_table(806) := '''Montenegrin''),'||wwv_flow.LF||
'    UNISTR(''Montenegro is located in Southeast Europe. Its capital is Podgorica. The';
wwv_flow_imp.g_varchar2_table(807) := ' primary official or common language is Montenegrin.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    count';
wwv_flow_imp.g_varchar2_table(808) := 'ry_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, e';
wwv_flow_imp.g_varchar2_table(809) := 'stimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VAL';
wwv_flow_imp.g_varchar2_table(810) := 'UES ('||wwv_flow.LF||
'    ''MF'', ''MAF'', UNISTR(''Americas''), UNISTR(''Saint-Martin''),'||wwv_flow.LF||
'    UNISTR(''Saint Martin''), UNIST';
wwv_flow_imp.g_varchar2_table(811) := 'R(''Marigot''), 23898,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''Saint Martin is located in Caribbean. I';
wwv_flow_imp.g_varchar2_table(812) := 'ts capital is Marigot. The primary official or common language is French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_';
wwv_flow_imp.g_varchar2_table(813) := 'countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_eng';
wwv_flow_imp.g_varchar2_table(814) := 'lish, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language';
wwv_flow_imp.g_varchar2_table(815) := ', description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''MG'', ''MDG'', UNISTR(''Africa''), UNISTR(''Madagasikara''),'||wwv_flow.LF||
'    UNISTR(''Ma';
wwv_flow_imp.g_varchar2_table(816) := 'dagascar''), UNISTR(''Antananarivo''), 33522052,'||wwv_flow.LF||
'    2026, UNISTR(''French, Malagasy''),'||wwv_flow.LF||
'    UNISTR(''Mada';
wwv_flow_imp.g_varchar2_table(817) := 'gascar is located in Eastern Africa. Its capital is Antananarivo. Official or common languages inclu';
wwv_flow_imp.g_varchar2_table(818) := 'de French and Malagasy.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_';
wwv_flow_imp.g_varchar2_table(819) := 'alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    esti';
wwv_flow_imp.g_varchar2_table(820) := 'mated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''MH'', ''MHL'', UNISTR';
wwv_flow_imp.g_varchar2_table(821) := '(''Oceania''), UNISTR(''M\0327aje\013C''),'||wwv_flow.LF||
'    UNISTR(''Marshall Islands''), UNISTR(''Majuro''), 35075,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(822) := '2026, UNISTR(''English, Marshallese''),'||wwv_flow.LF||
'    UNISTR(''Marshall Islands is located in Micronesia. Its cap';
wwv_flow_imp.g_varchar2_table(823) := 'ital is Majuro. Official or common languages include English and Marshallese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_';
wwv_flow_imp.g_varchar2_table(824) := 'txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name';
wwv_flow_imp.g_varchar2_table(825) := '_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_lang';
wwv_flow_imp.g_varchar2_table(826) := 'uage, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''MK'', ''MKD'', UNISTR(''Europe''), UNISTR(''\041C\0430\043A\0435\0434\';
wwv_flow_imp.g_varchar2_table(827) := '043E\043D\0438\0458\0430''),'||wwv_flow.LF||
'    UNISTR(''North Macedonia''), UNISTR(''Skopje''), 1804062,'||wwv_flow.LF||
'    2026, UNIS';
wwv_flow_imp.g_varchar2_table(828) := 'TR(''Macedonian''),'||wwv_flow.LF||
'    UNISTR(''North Macedonia is located in Southeast Europe. Its capital is Skopje.';
wwv_flow_imp.g_varchar2_table(829) := ' The primary official or common language is Macedonian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    co';
wwv_flow_imp.g_varchar2_table(830) := 'untry_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city';
wwv_flow_imp.g_varchar2_table(831) := ', estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) ';
wwv_flow_imp.g_varchar2_table(832) := 'VALUES ('||wwv_flow.LF||
'    ''ML'', ''MLI'', UNISTR(''Africa''), UNISTR(''Mali''),'||wwv_flow.LF||
'    UNISTR(''Mali''), UNISTR(''Bamako''), 25';
wwv_flow_imp.g_varchar2_table(833) := '932275,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''Mali is located in Western Africa. Its capital is Ba';
wwv_flow_imp.g_varchar2_table(834) := 'mako. The primary official or common language is French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(835) := 'ountry_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_cit';
wwv_flow_imp.g_varchar2_table(836) := 'y, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  )';
wwv_flow_imp.g_varchar2_table(837) := ' VALUES ('||wwv_flow.LF||
'    ''MM'', ''MMR'', UNISTR(''Asia''), UNISTR(''\1019\103C\1014\103A\1019\102C''),'||wwv_flow.LF||
'    UNISTR(''Mya';
wwv_flow_imp.g_varchar2_table(838) := 'nmar''), UNISTR(''Naypyidaw''), 55184819,'||wwv_flow.LF||
'    2026, UNISTR(''Burmese''),'||wwv_flow.LF||
'    UNISTR(''Myanmar is located i';
wwv_flow_imp.g_varchar2_table(839) := 'n South-Eastern Asia. Its capital is Naypyidaw. The primary official or common language is Burmese.''';
wwv_flow_imp.g_varchar2_table(840) := ')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_';
wwv_flow_imp.g_varchar2_table(841) := 'name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, o';
wwv_flow_imp.g_varchar2_table(842) := 'fficial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''MN'', ''MNG'', UNISTR(''Asia''), UNISTR(''\041C\';
wwv_flow_imp.g_varchar2_table(843) := '043E\043D\0433\043E\043B \0443\043B\0441''),'||wwv_flow.LF||
'    UNISTR(''Mongolia''), UNISTR(''Ulan Bator''), 3556798,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(844) := '   2026, UNISTR(''Mongolian''),'||wwv_flow.LF||
'    UNISTR(''Mongolia is located in Eastern Asia. Its capital is Ulan B';
wwv_flow_imp.g_varchar2_table(845) := 'ator. The primary official or common language is Mongolian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(846) := '  country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_';
wwv_flow_imp.g_varchar2_table(847) := 'city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(848) := '  ) VALUES ('||wwv_flow.LF||
'    ''MO'', ''MAC'', UNISTR(''Asia''), UNISTR(''\6FB3\95E8''),'||wwv_flow.LF||
'    UNISTR(''Macau''), NULL, 72318';
wwv_flow_imp.g_varchar2_table(849) := '8,'||wwv_flow.LF||
'    2026, UNISTR(''Portuguese, Chinese''),'||wwv_flow.LF||
'    UNISTR(''Macau is located in Eastern Asia and has no ';
wwv_flow_imp.g_varchar2_table(850) := 'permanent capital. Official or common languages include Portuguese and Chinese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_src';
wwv_flow_imp.g_varchar2_table(851) := 'h_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_na';
wwv_flow_imp.g_varchar2_table(852) := 'me_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_la';
wwv_flow_imp.g_varchar2_table(853) := 'nguage, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''MP'', ''MNP'', UNISTR(''Oceania''), UNISTR(''Na Islas Mari\00E5nas'')';
wwv_flow_imp.g_varchar2_table(854) := ','||wwv_flow.LF||
'    UNISTR(''Northern Mariana Islands''), UNISTR(''Saipan''), 42914,'||wwv_flow.LF||
'    2026, UNISTR(''Carolinian, Cha';
wwv_flow_imp.g_varchar2_table(855) := 'morro, English''),'||wwv_flow.LF||
'    UNISTR(''Northern Mariana Islands is located in Micronesia. Its capital is Saip';
wwv_flow_imp.g_varchar2_table(856) := 'an. Official or common languages include Carolinian, Chamorro, and English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_tx';
wwv_flow_imp.g_varchar2_table(857) := 't_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_e';
wwv_flow_imp.g_varchar2_table(858) := 'nglish, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_langua';
wwv_flow_imp.g_varchar2_table(859) := 'ge, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''MQ'', ''MTQ'', UNISTR(''Americas''), UNISTR(''Martinique''),'||wwv_flow.LF||
'    UNISTR(''';
wwv_flow_imp.g_varchar2_table(860) := 'Martinique''), UNISTR(''Fort-de-France''), 337711,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''Martinique i';
wwv_flow_imp.g_varchar2_table(861) := 's located in Caribbean. Its capital is Fort-de-France. The primary official or common language is Fr';
wwv_flow_imp.g_varchar2_table(862) := 'ench.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'SELECT 1 FROM dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'INSERT ALL'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2,';
wwv_flow_imp.g_varchar2_table(863) := ' country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_popula';
wwv_flow_imp.g_varchar2_table(864) := 'tion,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''MR'',';
wwv_flow_imp.g_varchar2_table(865) := ' ''MRT'', UNISTR(''Africa''), UNISTR(''\0645\0648\0631\064A\062A\0627\0646\064A\0627''),'||wwv_flow.LF||
'    UNISTR(''Mauri';
wwv_flow_imp.g_varchar2_table(866) := 'tania''), UNISTR(''Nouakchott''), 5461319,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic''),'||wwv_flow.LF||
'    UNISTR(''Mauritania is locate';
wwv_flow_imp.g_varchar2_table(867) := 'd in Western Africa. Its capital is Nouakchott. The primary official or common language is Arabic.'')';
wwv_flow_imp.g_varchar2_table(868) := ''||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_n';
wwv_flow_imp.g_varchar2_table(869) := 'ame,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, of';
wwv_flow_imp.g_varchar2_table(870) := 'ficial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''MS'', ''MSR'', UNISTR(''Americas''), UNISTR(''Mon';
wwv_flow_imp.g_varchar2_table(871) := 'tserrat''),'||wwv_flow.LF||
'    UNISTR(''Montserrat''), UNISTR(''Plymouth''), 4328,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNIS';
wwv_flow_imp.g_varchar2_table(872) := 'TR(''Montserrat is located in Caribbean. Its capital is Plymouth. The primary official or common lang';
wwv_flow_imp.g_varchar2_table(873) := 'uage is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3,';
wwv_flow_imp.g_varchar2_table(874) := ' region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_p';
wwv_flow_imp.g_varchar2_table(875) := 'opulation_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''MT'', ''MLT'', UNISTR(''Europ';
wwv_flow_imp.g_varchar2_table(876) := 'e''), UNISTR(''Malta''),'||wwv_flow.LF||
'    UNISTR(''Malta''), UNISTR(''Valletta''), 549011,'||wwv_flow.LF||
'    2026, UNISTR(''English, Ma';
wwv_flow_imp.g_varchar2_table(877) := 'ltese''),'||wwv_flow.LF||
'    UNISTR(''Malta is located in Southern Europe. Its capital is Valletta. Official or commo';
wwv_flow_imp.g_varchar2_table(878) := 'n languages include English and Maltese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alph';
wwv_flow_imp.g_varchar2_table(879) := 'a2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_pop';
wwv_flow_imp.g_varchar2_table(880) := 'ulation,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''M';
wwv_flow_imp.g_varchar2_table(881) := 'U'', ''MUS'', UNISTR(''Africa''), UNISTR(''Maurice''),'||wwv_flow.LF||
'    UNISTR(''Mauritius''), UNISTR(''Port Louis''), 12650';
wwv_flow_imp.g_varchar2_table(882) := '59,'||wwv_flow.LF||
'    2026, UNISTR(''English, French, Mauritian Creole''),'||wwv_flow.LF||
'    UNISTR(''Mauritius is located in Easte';
wwv_flow_imp.g_varchar2_table(883) := 'rn Africa. Its capital is Port Louis. Official or common languages include English, French, and Maur';
wwv_flow_imp.g_varchar2_table(884) := 'itian Creole.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, re';
wwv_flow_imp.g_varchar2_table(885) := 'gion, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_popu';
wwv_flow_imp.g_varchar2_table(886) := 'lation_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''MV'', ''MDV'', UNISTR(''Asia''), ';
wwv_flow_imp.g_varchar2_table(887) := 'UNISTR(''\078B\07A8\0788\07AC\0780\07A8\0783\07A7\0787\07B0\0796\07AD\078E\07AC''),'||wwv_flow.LF||
'    UNISTR(''Maldiv';
wwv_flow_imp.g_varchar2_table(888) := 'es''), UNISTR(''Mal\00E9''), 531517,'||wwv_flow.LF||
'    2026, UNISTR(''Maldivian''),'||wwv_flow.LF||
'    UNISTR(''Maldives is located in ';
wwv_flow_imp.g_varchar2_table(889) := 'Southern Asia. Its capital is Mal\00E9. The primary official or common language is Maldivian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(890) := '  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(891) := '    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, officia';
wwv_flow_imp.g_varchar2_table(892) := 'l_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''MW'', ''MWI'', UNISTR(''Africa''), UNISTR(''Mala\0175i';
wwv_flow_imp.g_varchar2_table(893) := '''),'||wwv_flow.LF||
'    UNISTR(''Malawi''), UNISTR(''Lilongwe''), 22785535,'||wwv_flow.LF||
'    2026, UNISTR(''English, Chewa''),'||wwv_flow.LF||
'    UNIS';
wwv_flow_imp.g_varchar2_table(894) := 'TR(''Malawi is located in Eastern Africa. Its capital is Lilongwe. Official or common languages inclu';
wwv_flow_imp.g_varchar2_table(895) := 'de English and Chewa.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_al';
wwv_flow_imp.g_varchar2_table(896) := 'pha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estima';
wwv_flow_imp.g_varchar2_table(897) := 'ted_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''MX'', ''MEX'', UNISTR(''';
wwv_flow_imp.g_varchar2_table(898) := 'Americas''), UNISTR(''M\00E9xico''),'||wwv_flow.LF||
'    UNISTR(''Mexico''), UNISTR(''Mexico City''), 132997658,'||wwv_flow.LF||
'    2026, ';
wwv_flow_imp.g_varchar2_table(899) := 'UNISTR(''Spanish''),'||wwv_flow.LF||
'    UNISTR(''Mexico is located in North America. Its capital is Mexico City. The p';
wwv_flow_imp.g_varchar2_table(900) := 'rimary official or common language is Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_cod';
wwv_flow_imp.g_varchar2_table(901) := 'e_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimat';
wwv_flow_imp.g_varchar2_table(902) := 'ed_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(903) := '    ''MY'', ''MYS'', UNISTR(''Asia''), UNISTR(''\0645\0644\064A\0633\064A\0627''),'||wwv_flow.LF||
'    UNISTR(''Malaysia''), U';
wwv_flow_imp.g_varchar2_table(904) := 'NISTR(''Kuala Lumpur''), 36385115,'||wwv_flow.LF||
'    2026, UNISTR(''English, Malay''),'||wwv_flow.LF||
'    UNISTR(''Malaysia is located';
wwv_flow_imp.g_varchar2_table(905) := ' in South-Eastern Asia. Its capital is Kuala Lumpur. Official or common languages include English an';
wwv_flow_imp.g_varchar2_table(906) := 'd Malay.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region,';
wwv_flow_imp.g_varchar2_table(907) := ' country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_populatio';
wwv_flow_imp.g_varchar2_table(908) := 'n_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''MZ'', ''MOZ'', UNISTR(''Africa''), UNI';
wwv_flow_imp.g_varchar2_table(909) := 'STR(''Mo\00E7ambique''),'||wwv_flow.LF||
'    UNISTR(''Mozambique''), UNISTR(''Maputo''), 36639850,'||wwv_flow.LF||
'    2026, UNISTR(''Portu';
wwv_flow_imp.g_varchar2_table(910) := 'guese''),'||wwv_flow.LF||
'    UNISTR(''Mozambique is located in Eastern Africa. Its capital is Maputo. The primary off';
wwv_flow_imp.g_varchar2_table(911) := 'icial or common language is Portuguese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha';
wwv_flow_imp.g_varchar2_table(912) := '2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_popu';
wwv_flow_imp.g_varchar2_table(913) := 'lation,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''NA';
wwv_flow_imp.g_varchar2_table(914) := ''', ''NAM'', UNISTR(''Africa''), UNISTR(''Namibi\00EB''),'||wwv_flow.LF||
'    UNISTR(''Namibia''), UNISTR(''Windhoek''), 315324';
wwv_flow_imp.g_varchar2_table(915) := '6,'||wwv_flow.LF||
'    2026, UNISTR(''Afrikaans, German, English, Herero, Khoekhoe, Kwangali, Lozi, Ndonga, Tswana''),';
wwv_flow_imp.g_varchar2_table(916) := ''||wwv_flow.LF||
'    UNISTR(''Namibia is located in Southern Africa. Its capital is Windhoek. Official or common lang';
wwv_flow_imp.g_varchar2_table(917) := 'uages include Afrikaans, German, English, and other local languages.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_count';
wwv_flow_imp.g_varchar2_table(918) := 'ries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english,';
wwv_flow_imp.g_varchar2_table(919) := ' capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, des';
wwv_flow_imp.g_varchar2_table(920) := 'cription'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''NC'', ''NCL'', UNISTR(''Oceania''), UNISTR(''Nouvelle-Cal\00E9donie''),'||wwv_flow.LF||
'    UNIS';
wwv_flow_imp.g_varchar2_table(921) := 'TR(''New Caledonia''), UNISTR(''Noum\00E9a''), 297892,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''New Caled';
wwv_flow_imp.g_varchar2_table(922) := 'onia is located in Melanesia. Its capital is Noum\00E9a. The primary official or common language is ';
wwv_flow_imp.g_varchar2_table(923) := 'French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, ';
wwv_flow_imp.g_varchar2_table(924) := 'country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population';
wwv_flow_imp.g_varchar2_table(925) := '_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''NE'', ''NER'', UNISTR(''Africa''), UNIS';
wwv_flow_imp.g_varchar2_table(926) := 'TR(''Niger''),'||wwv_flow.LF||
'    UNISTR(''Niger''), UNISTR(''Niamey''), 28814878,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR';
wwv_flow_imp.g_varchar2_table(927) := '(''Niger is located in Western Africa. Its capital is Niamey. The primary official or common language';
wwv_flow_imp.g_varchar2_table(928) := ' is French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, regi';
wwv_flow_imp.g_varchar2_table(929) := 'on, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_popula';
wwv_flow_imp.g_varchar2_table(930) := 'tion_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''NF'', ''NFK'', UNISTR(''Oceania''),';
wwv_flow_imp.g_varchar2_table(931) := ' UNISTR(''Norf''''k Ailen''),'||wwv_flow.LF||
'    UNISTR(''Norfolk Island''), UNISTR(''Kingston''), 2200,'||wwv_flow.LF||
'    2024, UNISTR(''';
wwv_flow_imp.g_varchar2_table(932) := 'English, Norfuk''),'||wwv_flow.LF||
'    UNISTR(''Norfolk Island is located in Australia and New Zealand. Its capital i';
wwv_flow_imp.g_varchar2_table(933) := 's Kingston. Official or common languages include English and Norfuk.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_count';
wwv_flow_imp.g_varchar2_table(934) := 'ries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english,';
wwv_flow_imp.g_varchar2_table(935) := ' capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, des';
wwv_flow_imp.g_varchar2_table(936) := 'cription'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''NG'', ''NGA'', UNISTR(''Africa''), UNISTR(''Nigeria''),'||wwv_flow.LF||
'    UNISTR(''Nigeria''), U';
wwv_flow_imp.g_varchar2_table(937) := 'NISTR(''Abuja''), 242431832,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Nigeria is located in Western Af';
wwv_flow_imp.g_varchar2_table(938) := 'rica. Its capital is Abuja. The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_src';
wwv_flow_imp.g_varchar2_table(939) := 'h_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_na';
wwv_flow_imp.g_varchar2_table(940) := 'me_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_la';
wwv_flow_imp.g_varchar2_table(941) := 'nguage, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''NI'', ''NIC'', UNISTR(''Americas''), UNISTR(''Nicaragua''),'||wwv_flow.LF||
'    UNIST';
wwv_flow_imp.g_varchar2_table(942) := 'R(''Nicaragua''), UNISTR(''Managua''), 7097329,'||wwv_flow.LF||
'    2026, UNISTR(''Spanish''),'||wwv_flow.LF||
'    UNISTR(''Nicaragua is lo';
wwv_flow_imp.g_varchar2_table(943) := 'cated in Central America. Its capital is Managua. The primary official or common language is Spanish';
wwv_flow_imp.g_varchar2_table(944) := '.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, countr';
wwv_flow_imp.g_varchar2_table(945) := 'y_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year,';
wwv_flow_imp.g_varchar2_table(946) := ' official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''NL'', ''NLD'', UNISTR(''Europe''), UNISTR(''Ne';
wwv_flow_imp.g_varchar2_table(947) := 'derland''),'||wwv_flow.LF||
'    UNISTR(''Netherlands''), UNISTR(''Amsterdam''), 18448775,'||wwv_flow.LF||
'    2026, UNISTR(''Dutch''),'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(948) := 'UNISTR(''Netherlands is located in Western Europe. Its capital is Amsterdam. The primary official or ';
wwv_flow_imp.g_varchar2_table(949) := 'common language is Dutch.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_cod';
wwv_flow_imp.g_varchar2_table(950) := 'e_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    es';
wwv_flow_imp.g_varchar2_table(951) := 'timated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''NO'', ''NOR'', UNIS';
wwv_flow_imp.g_varchar2_table(952) := 'TR(''Europe''), UNISTR(''Noreg''),'||wwv_flow.LF||
'    UNISTR(''Norway''), UNISTR(''Oslo''), 5652989,'||wwv_flow.LF||
'    2026, UNISTR(''Norw';
wwv_flow_imp.g_varchar2_table(953) := 'egian Nynorsk, Norwegian Bokm\00E5l, Sami''),'||wwv_flow.LF||
'    UNISTR(''Norway is located in Northern Europe. Its c';
wwv_flow_imp.g_varchar2_table(954) := 'apital is Oslo. Official or common languages include Norwegian Nynorsk, Norwegian Bokm\00E5l, and Sa';
wwv_flow_imp.g_varchar2_table(955) := 'mi.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, coun';
wwv_flow_imp.g_varchar2_table(956) := 'try_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_yea';
wwv_flow_imp.g_varchar2_table(957) := 'r, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''NP'', ''NPL'', UNISTR(''Asia''), UNISTR(''\0';
wwv_flow_imp.g_varchar2_table(958) := '928\0947\092A\093E\0932''),'||wwv_flow.LF||
'    UNISTR(''Nepal''), UNISTR(''Kathmandu''), 29629410,'||wwv_flow.LF||
'    2026, UNISTR(''Nep';
wwv_flow_imp.g_varchar2_table(959) := 'ali''),'||wwv_flow.LF||
'    UNISTR(''Nepal is located in Southern Asia. Its capital is Kathmandu. The primary official';
wwv_flow_imp.g_varchar2_table(960) := ' or common language is Nepali.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, countr';
wwv_flow_imp.g_varchar2_table(961) := 'y_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(962) := '   estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''NR'', ''NRU'',';
wwv_flow_imp.g_varchar2_table(963) := ' UNISTR(''Oceania''), UNISTR(''Nauru''),'||wwv_flow.LF||
'    UNISTR(''Nauru''), UNISTR(''Yaren''), 12101,'||wwv_flow.LF||
'    2026, UNISTR(''';
wwv_flow_imp.g_varchar2_table(964) := 'English, Nauru''),'||wwv_flow.LF||
'    UNISTR(''Nauru is located in Micronesia. Its capital is Yaren. Official or comm';
wwv_flow_imp.g_varchar2_table(965) := 'on languages include English and Nauru.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha';
wwv_flow_imp.g_varchar2_table(966) := '2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_popu';
wwv_flow_imp.g_varchar2_table(967) := 'lation,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''NU';
wwv_flow_imp.g_varchar2_table(968) := ''', ''NIU'', UNISTR(''Oceania''), UNISTR(''Niu\0113''),'||wwv_flow.LF||
'    UNISTR(''Niue''), UNISTR(''Alofi''), 1822,'||wwv_flow.LF||
'    2026';
wwv_flow_imp.g_varchar2_table(969) := ', UNISTR(''English, Niuean''),'||wwv_flow.LF||
'    UNISTR(''Niue is located in Polynesia. Its capital is Alofi. Officia';
wwv_flow_imp.g_varchar2_table(970) := 'l or common languages include English and Niuean.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_';
wwv_flow_imp.g_varchar2_table(971) := 'code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, esti';
wwv_flow_imp.g_varchar2_table(972) := 'mated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES';
wwv_flow_imp.g_varchar2_table(973) := ' ('||wwv_flow.LF||
'    ''NZ'', ''NZL'', UNISTR(''Oceania''), UNISTR(''Aotearoa''),'||wwv_flow.LF||
'    UNISTR(''New Zealand''), UNISTR(''Wellin';
wwv_flow_imp.g_varchar2_table(974) := 'gton''), 5287479,'||wwv_flow.LF||
'    2026, UNISTR(''English, M\0101ori, New Zealand Sign Language''),'||wwv_flow.LF||
'    UNISTR(''New ';
wwv_flow_imp.g_varchar2_table(975) := 'Zealand is located in Australia and New Zealand. Its capital is Wellington. Official or common langu';
wwv_flow_imp.g_varchar2_table(976) := 'ages include English, M\0101ori, and New Zealand Sign Language.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ';
wwv_flow_imp.g_varchar2_table(977) := '('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capi';
wwv_flow_imp.g_varchar2_table(978) := 'tal_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, descript';
wwv_flow_imp.g_varchar2_table(979) := 'ion'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''OM'', ''OMN'', UNISTR(''Asia''), UNISTR(''\0639\0645\0627\0646''),'||wwv_flow.LF||
'    UNISTR(''Oman'')';
wwv_flow_imp.g_varchar2_table(980) := ', UNISTR(''Muscat''), 5671458,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic''),'||wwv_flow.LF||
'    UNISTR(''Oman is located in Western Asia';
wwv_flow_imp.g_varchar2_table(981) := '. Its capital is Muscat. The primary official or common language is Arabic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_tx';
wwv_flow_imp.g_varchar2_table(982) := 't_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_e';
wwv_flow_imp.g_varchar2_table(983) := 'nglish, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_langua';
wwv_flow_imp.g_varchar2_table(984) := 'ge, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''PA'', ''PAN'', UNISTR(''Americas''), UNISTR(''Panam\00E1''),'||wwv_flow.LF||
'    UNISTR(''';
wwv_flow_imp.g_varchar2_table(985) := 'Panama''), UNISTR(''Panama City''), 4625718,'||wwv_flow.LF||
'    2026, UNISTR(''Spanish''),'||wwv_flow.LF||
'    UNISTR(''Panama is located';
wwv_flow_imp.g_varchar2_table(986) := ' in Central America. Its capital is Panama City. The primary official or common language is Spanish.';
wwv_flow_imp.g_varchar2_table(987) := ''')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country';
wwv_flow_imp.g_varchar2_table(988) := '_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, ';
wwv_flow_imp.g_varchar2_table(989) := 'official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''PE'', ''PER'', UNISTR(''Americas''), UNISTR(''P';
wwv_flow_imp.g_varchar2_table(990) := 'iruw''),'||wwv_flow.LF||
'    UNISTR(''Peru''), UNISTR(''Lima''), 34922148,'||wwv_flow.LF||
'    2026, UNISTR(''Aymara, Quechua, Spanish''),'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(991) := '    UNISTR(''Peru is located in South America. Its capital is Lima. Official or common languages incl';
wwv_flow_imp.g_varchar2_table(992) := 'ude Aymara, Quechua, and Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, cou';
wwv_flow_imp.g_varchar2_table(993) := 'ntry_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population';
wwv_flow_imp.g_varchar2_table(994) := ','||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''PF'', ''PY';
wwv_flow_imp.g_varchar2_table(995) := 'F'', UNISTR(''Oceania''), UNISTR(''Polyn\00E9sie fran\00E7aise''),'||wwv_flow.LF||
'    UNISTR(''French Polynesia''), UNISTR';
wwv_flow_imp.g_varchar2_table(996) := '(''Papeet\0113''), 283076,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''French Polynesia is located in Poly';
wwv_flow_imp.g_varchar2_table(997) := 'nesia. Its capital is Papeet\0113. The primary official or common language is French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into e';
wwv_flow_imp.g_varchar2_table(998) := 'ba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    coun';
wwv_flow_imp.g_varchar2_table(999) := 'try_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_com';
wwv_flow_imp.g_varchar2_table(1000) := 'mon_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''PG'', ''PNG'', UNISTR(''Oceania''), UNISTR(''Papua Niu Gini''),';
wwv_flow_imp.g_varchar2_table(1001) := ''||wwv_flow.LF||
'    UNISTR(''Papua New Guinea''), UNISTR(''Port Moresby''), 10947848,'||wwv_flow.LF||
'    2026, UNISTR(''English, Hiri M';
wwv_flow_imp.g_varchar2_table(1002) := 'otu, Tok Pisin''),'||wwv_flow.LF||
'    UNISTR(''Papua New Guinea is located in Melanesia. Its capital is Port Moresby.';
wwv_flow_imp.g_varchar2_table(1003) := ' Official or common languages include English, Hiri Motu, and Tok Pisin.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_c';
wwv_flow_imp.g_varchar2_table(1004) := 'ountries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_engl';
wwv_flow_imp.g_varchar2_table(1005) := 'ish, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language,';
wwv_flow_imp.g_varchar2_table(1006) := ' description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''PH'', ''PHL'', UNISTR(''Asia''), UNISTR(''Pilipinas''),'||wwv_flow.LF||
'    UNISTR(''Philippi';
wwv_flow_imp.g_varchar2_table(1007) := 'nes''), UNISTR(''Manila''), 117724472,'||wwv_flow.LF||
'    2026, UNISTR(''English, Filipino''),'||wwv_flow.LF||
'    UNISTR(''Philippines i';
wwv_flow_imp.g_varchar2_table(1008) := 's located in South-Eastern Asia. Its capital is Manila. Official or common languages include English';
wwv_flow_imp.g_varchar2_table(1009) := ' and Filipino.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, r';
wwv_flow_imp.g_varchar2_table(1010) := 'egion, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_pop';
wwv_flow_imp.g_varchar2_table(1011) := 'ulation_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''PK'', ''PAK'', UNISTR(''Asia''),';
wwv_flow_imp.g_varchar2_table(1012) := ' UNISTR(''\067E\0627\0643\0633\062A\0627\0646''),'||wwv_flow.LF||
'    UNISTR(''Pakistan''), UNISTR(''Islamabad''), 2592997';
wwv_flow_imp.g_varchar2_table(1013) := '92,'||wwv_flow.LF||
'    2026, UNISTR(''English, Urdu''),'||wwv_flow.LF||
'    UNISTR(''Pakistan is located in Southern Asia. Its capital';
wwv_flow_imp.g_varchar2_table(1014) := ' is Islamabad. Official or common languages include English and Urdu.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_coun';
wwv_flow_imp.g_varchar2_table(1015) := 'tries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english';
wwv_flow_imp.g_varchar2_table(1016) := ', capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, de';
wwv_flow_imp.g_varchar2_table(1017) := 'scription'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''PL'', ''POL'', UNISTR(''Europe''), UNISTR(''Polska''),'||wwv_flow.LF||
'    UNISTR(''Poland''), UN';
wwv_flow_imp.g_varchar2_table(1018) := 'ISTR(''Warsaw''), 37843188,'||wwv_flow.LF||
'    2026, UNISTR(''Polish''),'||wwv_flow.LF||
'    UNISTR(''Poland is located in Central Europ';
wwv_flow_imp.g_varchar2_table(1019) := 'e. Its capital is Warsaw. The primary official or common language is Polish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_t';
wwv_flow_imp.g_varchar2_table(1020) := 'xt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_';
wwv_flow_imp.g_varchar2_table(1021) := 'english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_langu';
wwv_flow_imp.g_varchar2_table(1022) := 'age, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''PM'', ''SPM'', UNISTR(''Americas''), UNISTR(''Saint-Pierre-et-Miquelon''';
wwv_flow_imp.g_varchar2_table(1023) := '),'||wwv_flow.LF||
'    UNISTR(''Saint Pierre and Miquelon''), UNISTR(''Saint-Pierre''), 5513,'||wwv_flow.LF||
'    2026, UNISTR(''French'')';
wwv_flow_imp.g_varchar2_table(1024) := ','||wwv_flow.LF||
'    UNISTR(''Saint Pierre and Miquelon is located in North America. Its capital is Saint-Pierre. Th';
wwv_flow_imp.g_varchar2_table(1025) := 'e primary official or common language is French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_c';
wwv_flow_imp.g_varchar2_table(1026) := 'ode_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estim';
wwv_flow_imp.g_varchar2_table(1027) := 'ated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ';
wwv_flow_imp.g_varchar2_table(1028) := '('||wwv_flow.LF||
'    ''PN'', ''PCN'', UNISTR(''Oceania''), UNISTR(''Pitcairn Islands''),'||wwv_flow.LF||
'    UNISTR(''Pitcairn Islands''), UN';
wwv_flow_imp.g_varchar2_table(1029) := 'ISTR(''Adamstown''), 35,'||wwv_flow.LF||
'    2024, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Pitcairn Islands is located in Polyn';
wwv_flow_imp.g_varchar2_table(1030) := 'esia. Its capital is Adamstown. The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba';
wwv_flow_imp.g_varchar2_table(1031) := '_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    countr';
wwv_flow_imp.g_varchar2_table(1032) := 'y_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_commo';
wwv_flow_imp.g_varchar2_table(1033) := 'n_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''PR'', ''PRI'', UNISTR(''Americas''), UNISTR(''Puerto Rico''),'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(1034) := ' UNISTR(''Puerto Rico''), UNISTR(''San Juan''), 3222688,'||wwv_flow.LF||
'    2026, UNISTR(''English, Spanish''),'||wwv_flow.LF||
'    UNIST';
wwv_flow_imp.g_varchar2_table(1035) := 'R(''Puerto Rico is located in Caribbean. Its capital is San Juan. Official or common languages includ';
wwv_flow_imp.g_varchar2_table(1036) := 'e English and Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_a';
wwv_flow_imp.g_varchar2_table(1037) := 'lpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estim';
wwv_flow_imp.g_varchar2_table(1038) := 'ated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''PS'', ''PSE'', UNISTR(';
wwv_flow_imp.g_varchar2_table(1039) := '''Asia''), UNISTR(''\0641\0644\0633\0637\064A\0646''),'||wwv_flow.LF||
'    UNISTR(''Palestine''), UNISTR(''Ramallah''), 5692';
wwv_flow_imp.g_varchar2_table(1040) := '790,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic''),'||wwv_flow.LF||
'    UNISTR(''Palestine is located in Western Asia. Its capital is Ra';
wwv_flow_imp.g_varchar2_table(1041) := 'mallah. The primary official or common language is Arabic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(1042) := ' country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_c';
wwv_flow_imp.g_varchar2_table(1043) := 'ity, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1044) := ' ) VALUES ('||wwv_flow.LF||
'    ''PT'', ''PRT'', UNISTR(''Europe''), UNISTR(''Portugal''),'||wwv_flow.LF||
'    UNISTR(''Portugal''), UNISTR(''L';
wwv_flow_imp.g_varchar2_table(1045) := 'isbon''), 10395362,'||wwv_flow.LF||
'    2026, UNISTR(''Portuguese''),'||wwv_flow.LF||
'    UNISTR(''Portugal is located in Southern Europ';
wwv_flow_imp.g_varchar2_table(1046) := 'e. Its capital is Lisbon. The primary official or common language is Portuguese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_sr';
wwv_flow_imp.g_varchar2_table(1047) := 'ch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_n';
wwv_flow_imp.g_varchar2_table(1048) := 'ame_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_l';
wwv_flow_imp.g_varchar2_table(1049) := 'anguage, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''PW'', ''PLW'', UNISTR(''Oceania''), UNISTR(''Belau''),'||wwv_flow.LF||
'    UNISTR(''P';
wwv_flow_imp.g_varchar2_table(1050) := 'alau''), UNISTR(''Ngerulmud''), 17614,'||wwv_flow.LF||
'    2026, UNISTR(''English, Palauan''),'||wwv_flow.LF||
'    UNISTR(''Palau is locat';
wwv_flow_imp.g_varchar2_table(1051) := 'ed in Micronesia. Its capital is Ngerulmud. Official or common languages include English and Palauan';
wwv_flow_imp.g_varchar2_table(1052) := '.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, countr';
wwv_flow_imp.g_varchar2_table(1053) := 'y_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year,';
wwv_flow_imp.g_varchar2_table(1054) := ' official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''PY'', ''PRY'', UNISTR(''Americas''), UNISTR(''';
wwv_flow_imp.g_varchar2_table(1055) := 'Paragu\00E1i''),'||wwv_flow.LF||
'    UNISTR(''Paraguay''), UNISTR(''Asunci\00F3n''), 7095279,'||wwv_flow.LF||
'    2026, UNISTR(''Guaran\00';
wwv_flow_imp.g_varchar2_table(1056) := 'ED, Spanish''),'||wwv_flow.LF||
'    UNISTR(''Paraguay is located in South America. Its capital is Asunci\00F3n. Offici';
wwv_flow_imp.g_varchar2_table(1057) := 'al or common languages include Guaran\00ED and Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    co';
wwv_flow_imp.g_varchar2_table(1058) := 'untry_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city';
wwv_flow_imp.g_varchar2_table(1059) := ', estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) ';
wwv_flow_imp.g_varchar2_table(1060) := 'VALUES ('||wwv_flow.LF||
'    ''QA'', ''QAT'', UNISTR(''Asia''), UNISTR(''\0642\0637\0631''),'||wwv_flow.LF||
'    UNISTR(''Qatar''), UNISTR(''Do';
wwv_flow_imp.g_varchar2_table(1061) := 'ha''), 3173559,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic''),'||wwv_flow.LF||
'    UNISTR(''Qatar is located in Western Asia. Its capital';
wwv_flow_imp.g_varchar2_table(1062) := ' is Doha. The primary official or common language is Arabic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1063) := '   country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital';
wwv_flow_imp.g_varchar2_table(1064) := '_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description';
wwv_flow_imp.g_varchar2_table(1065) := ''||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''RE'', ''REU'', UNISTR(''Africa''), UNISTR(''La R\00E9union''),'||wwv_flow.LF||
'    UNISTR(''R\00E9union'')';
wwv_flow_imp.g_varchar2_table(1066) := ', UNISTR(''Saint-Denis''), 886298,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''R\00E9union is located in E';
wwv_flow_imp.g_varchar2_table(1067) := 'astern Africa. Its capital is Saint-Denis. The primary official or common language is French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1068) := '  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1069) := '    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, officia';
wwv_flow_imp.g_varchar2_table(1070) := 'l_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''RO'', ''ROU'', UNISTR(''Europe''), UNISTR(''Rom\00E2ni';
wwv_flow_imp.g_varchar2_table(1071) := 'a''),'||wwv_flow.LF||
'    UNISTR(''Romania''), UNISTR(''Bucharest''), 18800605,'||wwv_flow.LF||
'    2026, UNISTR(''Romanian''),'||wwv_flow.LF||
'    UNISTR(';
wwv_flow_imp.g_varchar2_table(1072) := '''Romania is located in Southeast Europe. Its capital is Bucharest. The primary official or common la';
wwv_flow_imp.g_varchar2_table(1073) := 'nguage is Romanian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alph';
wwv_flow_imp.g_varchar2_table(1074) := 'a3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimate';
wwv_flow_imp.g_varchar2_table(1075) := 'd_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''RS'', ''SRB'', UNISTR(''Eu';
wwv_flow_imp.g_varchar2_table(1076) := 'rope''), UNISTR(''\0421\0440\0431\0438\0458\0430''),'||wwv_flow.LF||
'    UNISTR(''Serbia''), UNISTR(''Belgrade''), 6641964,';
wwv_flow_imp.g_varchar2_table(1077) := ''||wwv_flow.LF||
'    2026, UNISTR(''Serbian''),'||wwv_flow.LF||
'    UNISTR(''Serbia is located in Southeast Europe. Its capital is Belg';
wwv_flow_imp.g_varchar2_table(1078) := 'rade. The primary official or common language is Serbian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(1079) := 'country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_ci';
wwv_flow_imp.g_varchar2_table(1080) := 'ty, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(1081) := ') VALUES ('||wwv_flow.LF||
'    ''RU'', ''RUS'', UNISTR(''Europe''), UNISTR(''\0420\043E\0441\0441\0438\044F''),'||wwv_flow.LF||
'    UNISTR(''';
wwv_flow_imp.g_varchar2_table(1082) := 'Russia''), UNISTR(''Moscow''), 143394458,'||wwv_flow.LF||
'    2026, UNISTR(''Russian''),'||wwv_flow.LF||
'    UNISTR(''Russia is located in';
wwv_flow_imp.g_varchar2_table(1083) := ' Eastern Europe. Its capital is Moscow. The primary official or common language is Russian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(1084) := 'into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(1085) := '  country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_';
wwv_flow_imp.g_varchar2_table(1086) := 'or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''RW'', ''RWA'', UNISTR(''Africa''), UNISTR(''Rwanda''),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(1087) := '  UNISTR(''Rwanda''), UNISTR(''Kigali''), 14889693,'||wwv_flow.LF||
'    2026, UNISTR(''English, French, Kinyarwanda''),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(1088) := '  UNISTR(''Rwanda is located in Eastern Africa. Its capital is Kigali. Official or common languages i';
wwv_flow_imp.g_varchar2_table(1089) := 'nclude English, French, and Kinyarwanda.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alph';
wwv_flow_imp.g_varchar2_table(1090) := 'a2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_pop';
wwv_flow_imp.g_varchar2_table(1091) := 'ulation,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''S';
wwv_flow_imp.g_varchar2_table(1092) := 'A'', ''SAU'', UNISTR(''Asia''), UNISTR(''\0627\0644\0633\0639\0648\062F\064A\0629''),'||wwv_flow.LF||
'    UNISTR(''Saudi Ara';
wwv_flow_imp.g_varchar2_table(1093) := 'bia''), UNISTR(''Riyadh''), 35165787,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic''),'||wwv_flow.LF||
'    UNISTR(''Saudi Arabia is located i';
wwv_flow_imp.g_varchar2_table(1094) := 'n Western Asia. Its capital is Riyadh. The primary official or common language is Arabic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  in';
wwv_flow_imp.g_varchar2_table(1095) := 'to eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(1096) := 'country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or';
wwv_flow_imp.g_varchar2_table(1097) := '_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SB'', ''SLB'', UNISTR(''Oceania''), UNISTR(''Solomon Islan';
wwv_flow_imp.g_varchar2_table(1098) := 'ds''),'||wwv_flow.LF||
'    UNISTR(''Solomon Islands''), UNISTR(''Honiara''), 858288,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNI';
wwv_flow_imp.g_varchar2_table(1099) := 'STR(''Solomon Islands is located in Melanesia. Its capital is Honiara. The primary official or common';
wwv_flow_imp.g_varchar2_table(1100) := ' language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_al';
wwv_flow_imp.g_varchar2_table(1101) := 'pha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estima';
wwv_flow_imp.g_varchar2_table(1102) := 'ted_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SC'', ''SYC'', UNISTR(''';
wwv_flow_imp.g_varchar2_table(1103) := 'Africa''), UNISTR(''Sesel''),'||wwv_flow.LF||
'    UNISTR(''Seychelles''), UNISTR(''Victoria''), 134959,'||wwv_flow.LF||
'    2026, UNISTR(''S';
wwv_flow_imp.g_varchar2_table(1104) := 'eychellois Creole, English, French''),'||wwv_flow.LF||
'    UNISTR(''Seychelles is located in Eastern Africa. Its capit';
wwv_flow_imp.g_varchar2_table(1105) := 'al is Victoria. Official or common languages include Seychellois Creole, English, and French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1106) := '  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1107) := '    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, officia';
wwv_flow_imp.g_varchar2_table(1108) := 'l_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SD'', ''SDN'', UNISTR(''Africa''), UNISTR(''\0627\0644';
wwv_flow_imp.g_varchar2_table(1109) := '\0633\0648\062F\0627\0646''),'||wwv_flow.LF||
'    UNISTR(''Sudan''), UNISTR(''Khartoum''), 53282719,'||wwv_flow.LF||
'    2026, UNISTR(''Ar';
wwv_flow_imp.g_varchar2_table(1110) := 'abic, English''),'||wwv_flow.LF||
'    UNISTR(''Sudan is located in Northern Africa. Its capital is Khartoum. Official ';
wwv_flow_imp.g_varchar2_table(1111) := 'or common languages include Arabic and English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_co';
wwv_flow_imp.g_varchar2_table(1112) := 'de_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estima';
wwv_flow_imp.g_varchar2_table(1113) := 'ted_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES (';
wwv_flow_imp.g_varchar2_table(1114) := ''||wwv_flow.LF||
'    ''SE'', ''SWE'', UNISTR(''Europe''), UNISTR(''Sverige''),'||wwv_flow.LF||
'    UNISTR(''Sweden''), UNISTR(''Stockholm''), 10';
wwv_flow_imp.g_varchar2_table(1115) := '701046,'||wwv_flow.LF||
'    2026, UNISTR(''Swedish''),'||wwv_flow.LF||
'    UNISTR(''Sweden is located in Northern Europe. Its capital i';
wwv_flow_imp.g_varchar2_table(1116) := 's Stockholm. The primary official or common language is Swedish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries';
wwv_flow_imp.g_varchar2_table(1117) := ' ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, cap';
wwv_flow_imp.g_varchar2_table(1118) := 'ital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, descrip';
wwv_flow_imp.g_varchar2_table(1119) := 'tion'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SG'', ''SGP'', UNISTR(''Asia''), UNISTR(''Singapura''),'||wwv_flow.LF||
'    UNISTR(''Singapore''), UNI';
wwv_flow_imp.g_varchar2_table(1120) := 'STR(''Singapore''), 5905748,'||wwv_flow.LF||
'    2026, UNISTR(''English, Malay, Tamil, Chinese''),'||wwv_flow.LF||
'    UNISTR(''Singapore';
wwv_flow_imp.g_varchar2_table(1121) := ' is located in South-Eastern Asia. Its capital is Singapore. Official or common languages include En';
wwv_flow_imp.g_varchar2_table(1122) := 'glish, Malay, Tamil, and other local languages.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_co';
wwv_flow_imp.g_varchar2_table(1123) := 'de_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estima';
wwv_flow_imp.g_varchar2_table(1124) := 'ted_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES (';
wwv_flow_imp.g_varchar2_table(1125) := ''||wwv_flow.LF||
'    ''SH'', ''SHN'', UNISTR(''Africa''), UNISTR(''Saint Helena, Ascension and Tristan da Cunha''),'||wwv_flow.LF||
'    UNIS';
wwv_flow_imp.g_varchar2_table(1126) := 'TR(''Saint Helena, Ascension and Tristan da Cunha''), UNISTR(''Jamestown''), 5148,'||wwv_flow.LF||
'    2026, UNISTR(''Eng';
wwv_flow_imp.g_varchar2_table(1127) := 'lish''),'||wwv_flow.LF||
'    UNISTR(''Saint Helena, Ascension and Tristan da Cunha is located in Western Africa. Its c';
wwv_flow_imp.g_varchar2_table(1128) := 'apital is Jamestown. The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_c';
wwv_flow_imp.g_varchar2_table(1129) := 'ountries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_engl';
wwv_flow_imp.g_varchar2_table(1130) := 'ish, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language,';
wwv_flow_imp.g_varchar2_table(1131) := ' description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SI'', ''SVN'', UNISTR(''Europe''), UNISTR(''Slovenija''),'||wwv_flow.LF||
'    UNISTR(''Sloven';
wwv_flow_imp.g_varchar2_table(1132) := 'ia''), UNISTR(''Ljubljana''), 2114574,'||wwv_flow.LF||
'    2026, UNISTR(''Slovene''),'||wwv_flow.LF||
'    UNISTR(''Slovenia is located in ';
wwv_flow_imp.g_varchar2_table(1133) := 'Central Europe. Its capital is Ljubljana. The primary official or common language is Slovene.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1134) := 'SELECT 1 FROM dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'INSERT ALL'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_cod';
wwv_flow_imp.g_varchar2_table(1135) := 'e_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    es';
wwv_flow_imp.g_varchar2_table(1136) := 'timated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SJ'', ''SJM'', UNIS';
wwv_flow_imp.g_varchar2_table(1137) := 'TR(''Europe''), UNISTR(''Svalbard og Jan Mayen''),'||wwv_flow.LF||
'    UNISTR(''Svalbard and Jan Mayen''), UNISTR(''Longyea';
wwv_flow_imp.g_varchar2_table(1138) := 'rbyen''), 2600,'||wwv_flow.LF||
'    2024, UNISTR(''Norwegian''),'||wwv_flow.LF||
'    UNISTR(''Svalbard and Jan Mayen is located in North';
wwv_flow_imp.g_varchar2_table(1139) := 'ern Europe. Its capital is Longyearbyen. The primary official or common language is Norwegian.'')'||wwv_flow.LF||
'  )';
wwv_flow_imp.g_varchar2_table(1140) := ''||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,';
wwv_flow_imp.g_varchar2_table(1141) := ''||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, offici';
wwv_flow_imp.g_varchar2_table(1142) := 'al_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SK'', ''SVK'', UNISTR(''Europe''), UNISTR(''Slovensko';
wwv_flow_imp.g_varchar2_table(1143) := '''),'||wwv_flow.LF||
'    UNISTR(''Slovakia''), UNISTR(''Bratislava''), 5451342,'||wwv_flow.LF||
'    2026, UNISTR(''Slovak''),'||wwv_flow.LF||
'    UNISTR(''S';
wwv_flow_imp.g_varchar2_table(1144) := 'lovakia is located in Central Europe. Its capital is Bratislava. The primary official or common lang';
wwv_flow_imp.g_varchar2_table(1145) := 'uage is Slovak.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, ';
wwv_flow_imp.g_varchar2_table(1146) := 'region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_po';
wwv_flow_imp.g_varchar2_table(1147) := 'pulation_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SL'', ''SLE'', UNISTR(''Africa';
wwv_flow_imp.g_varchar2_table(1148) := '''), UNISTR(''Sierra Leone''),'||wwv_flow.LF||
'    UNISTR(''Sierra Leone''), UNISTR(''Freetown''), 8996744,'||wwv_flow.LF||
'    2026, UNIST';
wwv_flow_imp.g_varchar2_table(1149) := 'R(''English''),'||wwv_flow.LF||
'    UNISTR(''Sierra Leone is located in Western Africa. Its capital is Freetown. The pr';
wwv_flow_imp.g_varchar2_table(1150) := 'imary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code';
wwv_flow_imp.g_varchar2_table(1151) := '_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimate';
wwv_flow_imp.g_varchar2_table(1152) := 'd_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1153) := '   ''SM'', ''SMR'', UNISTR(''Europe''), UNISTR(''San Marino''),'||wwv_flow.LF||
'    UNISTR(''San Marino''), UNISTR(''City of Sa';
wwv_flow_imp.g_varchar2_table(1154) := 'n Marino''), 33605,'||wwv_flow.LF||
'    2026, UNISTR(''Italian''),'||wwv_flow.LF||
'    UNISTR(''San Marino is located in Southern Europe';
wwv_flow_imp.g_varchar2_table(1155) := '. Its capital is City of San Marino. The primary official or common language is Italian.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  int';
wwv_flow_imp.g_varchar2_table(1156) := 'o eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(1157) := 'ountry_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_';
wwv_flow_imp.g_varchar2_table(1158) := 'common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SN'', ''SEN'', UNISTR(''Africa''), UNISTR(''S\00E9n\00E9gal';
wwv_flow_imp.g_varchar2_table(1159) := '''),'||wwv_flow.LF||
'    UNISTR(''Senegal''), UNISTR(''Dakar''), 19366548,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''Senega';
wwv_flow_imp.g_varchar2_table(1160) := 'l is located in Western Africa. Its capital is Dakar. The primary official or common language is Fre';
wwv_flow_imp.g_varchar2_table(1161) := 'nch.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, cou';
wwv_flow_imp.g_varchar2_table(1162) := 'ntry_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_ye';
wwv_flow_imp.g_varchar2_table(1163) := 'ar, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SO'', ''SOM'', UNISTR(''Africa''), UNISTR(';
wwv_flow_imp.g_varchar2_table(1164) := '''\0627\0644\0635\0648\0645\0627\0644''),'||wwv_flow.LF||
'    UNISTR(''Somalia''), UNISTR(''Mogadishu''), 20305907,'||wwv_flow.LF||
'    20';
wwv_flow_imp.g_varchar2_table(1165) := '26, UNISTR(''Arabic, Somali''),'||wwv_flow.LF||
'    UNISTR(''Somalia is located in Eastern Africa. Its capital is Mogad';
wwv_flow_imp.g_varchar2_table(1166) := 'ishu. Official or common languages include Arabic and Somali.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1167) := '    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capita';
wwv_flow_imp.g_varchar2_table(1168) := 'l_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, descriptio';
wwv_flow_imp.g_varchar2_table(1169) := 'n'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SR'', ''SUR'', UNISTR(''Americas''), UNISTR(''Suriname''),'||wwv_flow.LF||
'    UNISTR(''Suriname''), UNIS';
wwv_flow_imp.g_varchar2_table(1170) := 'TR(''Paramaribo''), 645256,'||wwv_flow.LF||
'    2026, UNISTR(''Dutch''),'||wwv_flow.LF||
'    UNISTR(''Suriname is located in South Americ';
wwv_flow_imp.g_varchar2_table(1171) := 'a. Its capital is Paramaribo. The primary official or common language is Dutch.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_src';
wwv_flow_imp.g_varchar2_table(1172) := 'h_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_na';
wwv_flow_imp.g_varchar2_table(1173) := 'me_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_la';
wwv_flow_imp.g_varchar2_table(1174) := 'nguage, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SS'', ''SSD'', UNISTR(''Africa''), UNISTR(''South Sudan''),'||wwv_flow.LF||
'    UNIST';
wwv_flow_imp.g_varchar2_table(1175) := 'R(''South Sudan''), UNISTR(''Juba''), 12436037,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''South Sudan is ';
wwv_flow_imp.g_varchar2_table(1176) := 'located in Middle Africa. Its capital is Juba. The primary official or common language is English.'')';
wwv_flow_imp.g_varchar2_table(1177) := ''||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_n';
wwv_flow_imp.g_varchar2_table(1178) := 'ame,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, of';
wwv_flow_imp.g_varchar2_table(1179) := 'ficial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''ST'', ''STP'', UNISTR(''Africa''), UNISTR(''S\00E';
wwv_flow_imp.g_varchar2_table(1180) := '3o Tom\00E9 e Pr\00EDncipe''),'||wwv_flow.LF||
'    UNISTR(''S\00E3o Tom\00E9 and Pr\00EDncipe''), UNISTR(''S\00E3o Tom\0';
wwv_flow_imp.g_varchar2_table(1181) := '0E9''), 244994,'||wwv_flow.LF||
'    2026, UNISTR(''Portuguese''),'||wwv_flow.LF||
'    UNISTR(''S\00E3o Tom\00E9 and Pr\00EDncipe is loca';
wwv_flow_imp.g_varchar2_table(1182) := 'ted in Middle Africa. Its capital is S\00E3o Tom\00E9. The primary official or common language is Po';
wwv_flow_imp.g_varchar2_table(1183) := 'rtuguese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region';
wwv_flow_imp.g_varchar2_table(1184) := ', country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_populati';
wwv_flow_imp.g_varchar2_table(1185) := 'on_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SV'', ''SLV'', UNISTR(''Americas''), ';
wwv_flow_imp.g_varchar2_table(1186) := 'UNISTR(''El Salvador''),'||wwv_flow.LF||
'    UNISTR(''El Salvador''), UNISTR(''San Salvador''), 6391254,'||wwv_flow.LF||
'    2026, UNISTR(';
wwv_flow_imp.g_varchar2_table(1187) := '''Spanish''),'||wwv_flow.LF||
'    UNISTR(''El Salvador is located in Central America. Its capital is San Salvador. The ';
wwv_flow_imp.g_varchar2_table(1188) := 'primary official or common language is Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_co';
wwv_flow_imp.g_varchar2_table(1189) := 'de_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estima';
wwv_flow_imp.g_varchar2_table(1190) := 'ted_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES (';
wwv_flow_imp.g_varchar2_table(1191) := ''||wwv_flow.LF||
'    ''SX'', ''SXM'', UNISTR(''Americas''), UNISTR(''Saint-Martin''),'||wwv_flow.LF||
'    UNISTR(''Sint Maarten''), UNISTR(''Ph';
wwv_flow_imp.g_varchar2_table(1192) := 'ilipsburg''), 44447,'||wwv_flow.LF||
'    2026, UNISTR(''English, French, Dutch''),'||wwv_flow.LF||
'    UNISTR(''Sint Maarten is located ';
wwv_flow_imp.g_varchar2_table(1193) := 'in Caribbean. Its capital is Philipsburg. Official or common languages include English, French, and ';
wwv_flow_imp.g_varchar2_table(1194) := 'Dutch.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, c';
wwv_flow_imp.g_varchar2_table(1195) := 'ountry_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_';
wwv_flow_imp.g_varchar2_table(1196) := 'year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SY'', ''SYR'', UNISTR(''Asia''), UNISTR(';
wwv_flow_imp.g_varchar2_table(1197) := '''\0633\0648\0631\064A\0627''),'||wwv_flow.LF||
'    UNISTR(''Syria''), UNISTR(''Damascus''), 26472497,'||wwv_flow.LF||
'    2026, UNISTR(''A';
wwv_flow_imp.g_varchar2_table(1198) := 'rabic''),'||wwv_flow.LF||
'    UNISTR(''Syria is located in Western Asia. Its capital is Damascus. The primary official';
wwv_flow_imp.g_varchar2_table(1199) := ' or common language is Arabic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, countr';
wwv_flow_imp.g_varchar2_table(1200) := 'y_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1201) := '   estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''SZ'', ''SWZ'',';
wwv_flow_imp.g_varchar2_table(1202) := ' UNISTR(''Africa''), UNISTR(''eSwatini''),'||wwv_flow.LF||
'    UNISTR(''Eswatini''), UNISTR(''Lobamba''), 1269859,'||wwv_flow.LF||
'    2026,';
wwv_flow_imp.g_varchar2_table(1203) := ' UNISTR(''English, Swazi''),'||wwv_flow.LF||
'    UNISTR(''Eswatini is located in Southern Africa. Its capital is Lobamb';
wwv_flow_imp.g_varchar2_table(1204) := 'a. Official or common languages include English and Swazi.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(1205) := ' country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_c';
wwv_flow_imp.g_varchar2_table(1206) := 'ity, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1207) := ' ) VALUES ('||wwv_flow.LF||
'    ''TC'', ''TCA'', UNISTR(''Americas''), UNISTR(''Turks and Caicos Islands''),'||wwv_flow.LF||
'    UNISTR(''Tur';
wwv_flow_imp.g_varchar2_table(1208) := 'ks and Caicos Islands''), UNISTR(''Cockburn Town''), 47148,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Tu';
wwv_flow_imp.g_varchar2_table(1209) := 'rks and Caicos Islands is located in Caribbean. Its capital is Cockburn Town. The primary official o';
wwv_flow_imp.g_varchar2_table(1210) := 'r common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country';
wwv_flow_imp.g_varchar2_table(1211) := '_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(1212) := '  estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''TD'', ''TCD'', ';
wwv_flow_imp.g_varchar2_table(1213) := 'UNISTR(''Africa''), UNISTR(''\062A\0634\0627\062F''),'||wwv_flow.LF||
'    UNISTR(''Chad''), UNISTR(''N''''Djamena''), 21560380';
wwv_flow_imp.g_varchar2_table(1214) := ','||wwv_flow.LF||
'    2026, UNISTR(''Arabic, French''),'||wwv_flow.LF||
'    UNISTR(''Chad is located in Middle Africa. Its capital is N';
wwv_flow_imp.g_varchar2_table(1215) := '''''Djamena. Official or common languages include Arabic and French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countri';
wwv_flow_imp.g_varchar2_table(1216) := 'es ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, c';
wwv_flow_imp.g_varchar2_table(1217) := 'apital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, descr';
wwv_flow_imp.g_varchar2_table(1218) := 'iption'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''TF'', ''ATF'', UNISTR(''Antarctica''), UNISTR(''Terres australes et antarctiques ';
wwv_flow_imp.g_varchar2_table(1219) := 'fran\00E7aises''),'||wwv_flow.LF||
'    UNISTR(''French Southern and Antarctic Lands''), UNISTR(''Port-aux-Fran\00E7ais'')';
wwv_flow_imp.g_varchar2_table(1220) := ', 0,'||wwv_flow.LF||
'    2024, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''French Southern and Antarctic Lands is located in Antar';
wwv_flow_imp.g_varchar2_table(1221) := 'ctic. Its capital is Port-aux-Fran\00E7ais. The primary official or common language is French.'')'||wwv_flow.LF||
'  )';
wwv_flow_imp.g_varchar2_table(1222) := ''||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,';
wwv_flow_imp.g_varchar2_table(1223) := ''||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, offici';
wwv_flow_imp.g_varchar2_table(1224) := 'al_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''TG'', ''TGO'', UNISTR(''Africa''), UNISTR(''Togo''),'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1225) := '   UNISTR(''Togo''), UNISTR(''Lom\00E9''), 9930918,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''Togo is loca';
wwv_flow_imp.g_varchar2_table(1226) := 'ted in Western Africa. Its capital is Lom\00E9. The primary official or common language is French.'')';
wwv_flow_imp.g_varchar2_table(1227) := ''||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_n';
wwv_flow_imp.g_varchar2_table(1228) := 'ame,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, of';
wwv_flow_imp.g_varchar2_table(1229) := 'ficial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''TH'', ''THA'', UNISTR(''Asia''), UNISTR(''\0E1B\0';
wwv_flow_imp.g_varchar2_table(1230) := 'E23\0E30\0E40\0E17\0E28\0E44\0E17\0E22''),'||wwv_flow.LF||
'    UNISTR(''Thailand''), UNISTR(''Bangkok''), 71559614,'||wwv_flow.LF||
'    2';
wwv_flow_imp.g_varchar2_table(1231) := '026, UNISTR(''Thai''),'||wwv_flow.LF||
'    UNISTR(''Thailand is located in South-Eastern Asia. Its capital is Bangkok. ';
wwv_flow_imp.g_varchar2_table(1232) := 'The primary official or common language is Thai.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_c';
wwv_flow_imp.g_varchar2_table(1233) := 'ode_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estim';
wwv_flow_imp.g_varchar2_table(1234) := 'ated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ';
wwv_flow_imp.g_varchar2_table(1235) := '('||wwv_flow.LF||
'    ''TJ'', ''TJK'', UNISTR(''Asia''), UNISTR(''\0422\0430\0434\0436\0438\043A\0438\0441\0442\0430\043D'')';
wwv_flow_imp.g_varchar2_table(1236) := ','||wwv_flow.LF||
'    UNISTR(''Tajikistan''), UNISTR(''Dushanbe''), 10978598,'||wwv_flow.LF||
'    2026, UNISTR(''Russian, Tajik''),'||wwv_flow.LF||
'    UN';
wwv_flow_imp.g_varchar2_table(1237) := 'ISTR(''Tajikistan is located in Central Asia. Its capital is Dushanbe. Official or common languages i';
wwv_flow_imp.g_varchar2_table(1238) := 'nclude Russian and Tajik.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_cod';
wwv_flow_imp.g_varchar2_table(1239) := 'e_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    es';
wwv_flow_imp.g_varchar2_table(1240) := 'timated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''TK'', ''TKL'', UNIS';
wwv_flow_imp.g_varchar2_table(1241) := 'TR(''Oceania''), UNISTR(''Tokelau''),'||wwv_flow.LF||
'    UNISTR(''Tokelau''), UNISTR(''Fakaofo''), 2691,'||wwv_flow.LF||
'    2026, UNISTR(''';
wwv_flow_imp.g_varchar2_table(1242) := 'English, Samoan, Tokelauan''),'||wwv_flow.LF||
'    UNISTR(''Tokelau is located in Polynesia. Its capital is Fakaofo. O';
wwv_flow_imp.g_varchar2_table(1243) := 'fficial or common languages include English, Samoan, and Tokelauan.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countr';
wwv_flow_imp.g_varchar2_table(1244) := 'ies ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, ';
wwv_flow_imp.g_varchar2_table(1245) := 'capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, desc';
wwv_flow_imp.g_varchar2_table(1246) := 'ription'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''TL'', ''TLS'', UNISTR(''Asia''), UNISTR(''Tim\00F3r-Leste''),'||wwv_flow.LF||
'    UNISTR(''Timor-L';
wwv_flow_imp.g_varchar2_table(1247) := 'este''), UNISTR(''Dili''), 1436923,'||wwv_flow.LF||
'    2026, UNISTR(''Portuguese, Tetum''),'||wwv_flow.LF||
'    UNISTR(''Timor-Leste is l';
wwv_flow_imp.g_varchar2_table(1248) := 'ocated in South-Eastern Asia. Its capital is Dili. Official or common languages include Portuguese a';
wwv_flow_imp.g_varchar2_table(1249) := 'nd Tetum.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region';
wwv_flow_imp.g_varchar2_table(1250) := ', country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_populati';
wwv_flow_imp.g_varchar2_table(1251) := 'on_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''TM'', ''TKM'', UNISTR(''Asia''), UNIS';
wwv_flow_imp.g_varchar2_table(1252) := 'TR(''\0422\0443\0440\043A\043C\0435\043D\0438\044F''),'||wwv_flow.LF||
'    UNISTR(''Turkmenistan''), UNISTR(''Ashgabat''),';
wwv_flow_imp.g_varchar2_table(1253) := ' 7736632,'||wwv_flow.LF||
'    2026, UNISTR(''Russian, Turkmen''),'||wwv_flow.LF||
'    UNISTR(''Turkmenistan is located in Central Asia.';
wwv_flow_imp.g_varchar2_table(1254) := ' Its capital is Ashgabat. Official or common languages include Russian and Turkmen.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba';
wwv_flow_imp.g_varchar2_table(1255) := '_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    countr';
wwv_flow_imp.g_varchar2_table(1256) := 'y_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_commo';
wwv_flow_imp.g_varchar2_table(1257) := 'n_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''TN'', ''TUN'', UNISTR(''Africa''), UNISTR(''\062A\0648\0646\0633';
wwv_flow_imp.g_varchar2_table(1258) := '''),'||wwv_flow.LF||
'    UNISTR(''Tunisia''), UNISTR(''Tunis''), 12415138,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic''),'||wwv_flow.LF||
'    UNISTR(''Tunisi';
wwv_flow_imp.g_varchar2_table(1259) := 'a is located in Northern Africa. Its capital is Tunis. The primary official or common language is Ar';
wwv_flow_imp.g_varchar2_table(1260) := 'abic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, co';
wwv_flow_imp.g_varchar2_table(1261) := 'untry_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_y';
wwv_flow_imp.g_varchar2_table(1262) := 'ear, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''TO'', ''TON'', UNISTR(''Oceania''), UNIST';
wwv_flow_imp.g_varchar2_table(1263) := 'R(''Tonga''),'||wwv_flow.LF||
'    UNISTR(''Tonga''), UNISTR(''Nuku''''alofa''), 103291,'||wwv_flow.LF||
'    2026, UNISTR(''English, Tongan''),';
wwv_flow_imp.g_varchar2_table(1264) := ''||wwv_flow.LF||
'    UNISTR(''Tonga is located in Polynesia. Its capital is Nuku''''alofa. Official or common languages';
wwv_flow_imp.g_varchar2_table(1265) := ' include English and Tongan.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_';
wwv_flow_imp.g_varchar2_table(1266) := 'code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(1267) := ' estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''TR'', ''TUR'', U';
wwv_flow_imp.g_varchar2_table(1268) := 'NISTR(''Asia''), UNISTR(''T\00FCrkiye''),'||wwv_flow.LF||
'    UNISTR(''Turkey''), UNISTR(''Ankara''), 87926082,'||wwv_flow.LF||
'    2026, UN';
wwv_flow_imp.g_varchar2_table(1269) := 'ISTR(''Turkish''),'||wwv_flow.LF||
'    UNISTR(''Turkey is located in Western Asia. Its capital is Ankara. The primary o';
wwv_flow_imp.g_varchar2_table(1270) := 'fficial or common language is Turkish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2';
wwv_flow_imp.g_varchar2_table(1271) := ', country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_popul';
wwv_flow_imp.g_varchar2_table(1272) := 'ation,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''TT''';
wwv_flow_imp.g_varchar2_table(1273) := ', ''TTO'', UNISTR(''Americas''), UNISTR(''Trinidad and Tobago''),'||wwv_flow.LF||
'    UNISTR(''Trinidad and Tobago''), UNIST';
wwv_flow_imp.g_varchar2_table(1274) := 'R(''Port of Spain''), 1513268,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Trinidad and Tobago is located';
wwv_flow_imp.g_varchar2_table(1275) := ' in Caribbean. Its capital is Port of Spain. The primary official or common language is English.'')'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1276) := ' )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_nam';
wwv_flow_imp.g_varchar2_table(1277) := 'e,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, offi';
wwv_flow_imp.g_varchar2_table(1278) := 'cial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''TV'', ''TUV'', UNISTR(''Oceania''), UNISTR(''Tuvalu';
wwv_flow_imp.g_varchar2_table(1279) := '''),'||wwv_flow.LF||
'    UNISTR(''Tuvalu''), UNISTR(''Funafuti''), 9362,'||wwv_flow.LF||
'    2026, UNISTR(''English, Tuvaluan''),'||wwv_flow.LF||
'    UNIST';
wwv_flow_imp.g_varchar2_table(1280) := 'R(''Tuvalu is located in Polynesia. Its capital is Funafuti. Official or common languages include Eng';
wwv_flow_imp.g_varchar2_table(1281) := 'lish and Tuvaluan.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha';
wwv_flow_imp.g_varchar2_table(1282) := '3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated';
wwv_flow_imp.g_varchar2_table(1283) := '_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''TW'', ''TWN'', UNISTR(''Asi';
wwv_flow_imp.g_varchar2_table(1284) := 'a''), UNISTR(''\53F0\7063''),'||wwv_flow.LF||
'    UNISTR(''Taiwan''), UNISTR(''Taipei''), 23011292,'||wwv_flow.LF||
'    2026, UNISTR(''Chine';
wwv_flow_imp.g_varchar2_table(1285) := 'se''),'||wwv_flow.LF||
'    UNISTR(''Taiwan is located in Eastern Asia. Its capital is Taipei. The primary official or ';
wwv_flow_imp.g_varchar2_table(1286) := 'common language is Chinese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_c';
wwv_flow_imp.g_varchar2_table(1287) := 'ode_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(1288) := 'estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''TZ'', ''TZA'', UN';
wwv_flow_imp.g_varchar2_table(1289) := 'ISTR(''Africa''), UNISTR(''Tanzania''),'||wwv_flow.LF||
'    UNISTR(''Tanzania''), UNISTR(''Dodoma''), 72563780,'||wwv_flow.LF||
'    2026, UN';
wwv_flow_imp.g_varchar2_table(1290) := 'ISTR(''English, Swahili''),'||wwv_flow.LF||
'    UNISTR(''Tanzania is located in Eastern Africa. Its capital is Dodoma. ';
wwv_flow_imp.g_varchar2_table(1291) := 'Official or common languages include English and Swahili.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(1292) := 'country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_ci';
wwv_flow_imp.g_varchar2_table(1293) := 'ty, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(1294) := ') VALUES ('||wwv_flow.LF||
'    ''UA'', ''UKR'', UNISTR(''Europe''), UNISTR(''\0423\043A\0440\0430\0457\043D\0430''),'||wwv_flow.LF||
'    UNI';
wwv_flow_imp.g_varchar2_table(1295) := 'STR(''Ukraine''), UNISTR(''Kyiv''), 39535848,'||wwv_flow.LF||
'    2026, UNISTR(''Ukrainian''),'||wwv_flow.LF||
'    UNISTR(''Ukraine is loca';
wwv_flow_imp.g_varchar2_table(1296) := 'ted in Eastern Europe. Its capital is Kyiv. The primary official or common language is Ukrainian.'')'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1297) := '  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_na';
wwv_flow_imp.g_varchar2_table(1298) := 'me,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, off';
wwv_flow_imp.g_varchar2_table(1299) := 'icial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''UG'', ''UGA'', UNISTR(''Africa''), UNISTR(''Uganda';
wwv_flow_imp.g_varchar2_table(1300) := '''),'||wwv_flow.LF||
'    UNISTR(''Uganda''), UNISTR(''Kampala''), 52761470,'||wwv_flow.LF||
'    2026, UNISTR(''English, Swahili''),'||wwv_flow.LF||
'    UNI';
wwv_flow_imp.g_varchar2_table(1301) := 'STR(''Uganda is located in Eastern Africa. Its capital is Kampala. Official or common languages inclu';
wwv_flow_imp.g_varchar2_table(1302) := 'de English and Swahili.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_';
wwv_flow_imp.g_varchar2_table(1303) := 'alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    esti';
wwv_flow_imp.g_varchar2_table(1304) := 'mated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''UM'', ''UMI'', UNISTR';
wwv_flow_imp.g_varchar2_table(1305) := '(''Americas''), UNISTR(''United States Minor Outlying Islands''),'||wwv_flow.LF||
'    UNISTR(''United States Minor Outlyi';
wwv_flow_imp.g_varchar2_table(1306) := 'ng Islands''), NULL, 0,'||wwv_flow.LF||
'    2024, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''United States Minor Outlying Islands';
wwv_flow_imp.g_varchar2_table(1307) := ' is located in North America and has no permanent capital. The primary official or common language i';
wwv_flow_imp.g_varchar2_table(1308) := 's English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, regio';
wwv_flow_imp.g_varchar2_table(1309) := 'n, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_populat';
wwv_flow_imp.g_varchar2_table(1310) := 'ion_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''US'', ''USA'', UNISTR(''Americas''),';
wwv_flow_imp.g_varchar2_table(1311) := ' UNISTR(''United States''),'||wwv_flow.LF||
'    UNISTR(''United States''), UNISTR(''Washington D.C.''), 349035494,'||wwv_flow.LF||
'    202';
wwv_flow_imp.g_varchar2_table(1312) := '6, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''United States is located in North America. Its capital is Washingt';
wwv_flow_imp.g_varchar2_table(1313) := 'on D.C. The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(1314) := '  country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_';
wwv_flow_imp.g_varchar2_table(1315) := 'city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1316) := '  ) VALUES ('||wwv_flow.LF||
'    ''UY'', ''URY'', UNISTR(''Americas''), UNISTR(''Uruguay''),'||wwv_flow.LF||
'    UNISTR(''Uruguay''), UNISTR(''';
wwv_flow_imp.g_varchar2_table(1317) := 'Montevideo''), 3382537,'||wwv_flow.LF||
'    2026, UNISTR(''Spanish''),'||wwv_flow.LF||
'    UNISTR(''Uruguay is located in South America.';
wwv_flow_imp.g_varchar2_table(1318) := ' Its capital is Montevideo. The primary official or common language is Spanish.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_src';
wwv_flow_imp.g_varchar2_table(1319) := 'h_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_na';
wwv_flow_imp.g_varchar2_table(1320) := 'me_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_la';
wwv_flow_imp.g_varchar2_table(1321) := 'nguage, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''UZ'', ''UZB'', UNISTR(''Asia''), UNISTR(''\0423\0437\0431\0435\043A\';
wwv_flow_imp.g_varchar2_table(1322) := '0438\0441\0442\0430\043D''),'||wwv_flow.LF||
'    UNISTR(''Uzbekistan''), UNISTR(''Tashkent''), 37724223,'||wwv_flow.LF||
'    2026, UNISTR';
wwv_flow_imp.g_varchar2_table(1323) := '(''Russian, Uzbek''),'||wwv_flow.LF||
'    UNISTR(''Uzbekistan is located in Central Asia. Its capital is Tashkent. Offi';
wwv_flow_imp.g_varchar2_table(1324) := 'cial or common languages include Russian and Uzbek.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    countr';
wwv_flow_imp.g_varchar2_table(1325) := 'y_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, es';
wwv_flow_imp.g_varchar2_table(1326) := 'timated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALU';
wwv_flow_imp.g_varchar2_table(1327) := 'ES ('||wwv_flow.LF||
'    ''VA'', ''VAT'', UNISTR(''Europe''), UNISTR(''Vaticano''),'||wwv_flow.LF||
'    UNISTR(''Vatican City''), UNISTR(''Vati';
wwv_flow_imp.g_varchar2_table(1328) := 'can City''), 506,'||wwv_flow.LF||
'    2026, UNISTR(''Italian, Latin''),'||wwv_flow.LF||
'    UNISTR(''Vatican City is located in Southern';
wwv_flow_imp.g_varchar2_table(1329) := ' Europe. Its capital is Vatican City. Official or common languages include Italian and Latin.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1330) := '  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1331) := '    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, officia';
wwv_flow_imp.g_varchar2_table(1332) := 'l_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''VC'', ''VCT'', UNISTR(''Americas''), UNISTR(''Saint Vi';
wwv_flow_imp.g_varchar2_table(1333) := 'ncent and the Grenadines''),'||wwv_flow.LF||
'    UNISTR(''Saint Vincent and the Grenadines''), UNISTR(''Kingstown''), 992';
wwv_flow_imp.g_varchar2_table(1334) := '44,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Saint Vincent and the Grenadines is located in Caribbea';
wwv_flow_imp.g_varchar2_table(1335) := 'n. Its capital is Kingstown. The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_sr';
wwv_flow_imp.g_varchar2_table(1336) := 'ch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_n';
wwv_flow_imp.g_varchar2_table(1337) := 'ame_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_l';
wwv_flow_imp.g_varchar2_table(1338) := 'anguage, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''VE'', ''VEN'', UNISTR(''Americas''), UNISTR(''Venezuela''),'||wwv_flow.LF||
'    UNIS';
wwv_flow_imp.g_varchar2_table(1339) := 'TR(''Venezuela''), UNISTR(''Caracas''), 28633711,'||wwv_flow.LF||
'    2026, UNISTR(''Spanish''),'||wwv_flow.LF||
'    UNISTR(''Venezuela is ';
wwv_flow_imp.g_varchar2_table(1340) := 'located in South America. Its capital is Caracas. The primary official or common language is Spanish';
wwv_flow_imp.g_varchar2_table(1341) := '.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, countr';
wwv_flow_imp.g_varchar2_table(1342) := 'y_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year,';
wwv_flow_imp.g_varchar2_table(1343) := ' official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''VG'', ''VGB'', UNISTR(''Americas''), UNISTR(''';
wwv_flow_imp.g_varchar2_table(1344) := 'British Virgin Islands''),'||wwv_flow.LF||
'    UNISTR(''British Virgin Islands''), UNISTR(''Road Town''), 39936,'||wwv_flow.LF||
'    2026';
wwv_flow_imp.g_varchar2_table(1345) := ', UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''British Virgin Islands is located in Caribbean. Its capital is Road';
wwv_flow_imp.g_varchar2_table(1346) := ' Town. The primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(1347) := ' country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_c';
wwv_flow_imp.g_varchar2_table(1348) := 'ity, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1349) := ' ) VALUES ('||wwv_flow.LF||
'    ''VI'', ''VIR'', UNISTR(''Americas''), UNISTR(''United States Virgin Islands''),'||wwv_flow.LF||
'    UNISTR(';
wwv_flow_imp.g_varchar2_table(1350) := '''United States Virgin Islands''), UNISTR(''Charlotte Amalie''), 83400,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(1351) := ' UNISTR(''United States Virgin Islands is located in Caribbean. Its capital is Charlotte Amalie. The ';
wwv_flow_imp.g_varchar2_table(1352) := 'primary official or common language is English.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_co';
wwv_flow_imp.g_varchar2_table(1353) := 'de_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estima';
wwv_flow_imp.g_varchar2_table(1354) := 'ted_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES (';
wwv_flow_imp.g_varchar2_table(1355) := ''||wwv_flow.LF||
'    ''VN'', ''VNM'', UNISTR(''Asia''), UNISTR(''Vi\1EC7t Nam''),'||wwv_flow.LF||
'    UNISTR(''Vietnam''), UNISTR(''Hanoi''), 10';
wwv_flow_imp.g_varchar2_table(1356) := '2177431,'||wwv_flow.LF||
'    2026, UNISTR(''Vietnamese''),'||wwv_flow.LF||
'    UNISTR(''Vietnam is located in South-Eastern Asia. Its c';
wwv_flow_imp.g_varchar2_table(1357) := 'apital is Hanoi. The primary official or common language is Vietnamese.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_co';
wwv_flow_imp.g_varchar2_table(1358) := 'untries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_engli';
wwv_flow_imp.g_varchar2_table(1359) := 'sh, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, ';
wwv_flow_imp.g_varchar2_table(1360) := 'description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''VU'', ''VUT'', UNISTR(''Oceania''), UNISTR(''Vanuatu''),'||wwv_flow.LF||
'    UNISTR(''Vanuatu''';
wwv_flow_imp.g_varchar2_table(1361) := '), UNISTR(''Port Vila''), 342564,'||wwv_flow.LF||
'    2026, UNISTR(''Bislama, English, French''),'||wwv_flow.LF||
'    UNISTR(''Vanuatu is';
wwv_flow_imp.g_varchar2_table(1362) := ' located in Melanesia. Its capital is Port Vila. Official or common languages include Bislama, Engli';
wwv_flow_imp.g_varchar2_table(1363) := 'sh, and French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, ';
wwv_flow_imp.g_varchar2_table(1364) := 'region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_po';
wwv_flow_imp.g_varchar2_table(1365) := 'pulation_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''WF'', ''WLF'', UNISTR(''Oceani';
wwv_flow_imp.g_varchar2_table(1366) := 'a''), UNISTR(''Wallis et Futuna''),'||wwv_flow.LF||
'    UNISTR(''Wallis and Futuna''), UNISTR(''Mata-Utu''), 11113,'||wwv_flow.LF||
'    202';
wwv_flow_imp.g_varchar2_table(1367) := '6, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''Wallis and Futuna is located in Polynesia. Its capital is Mata-Utu.';
wwv_flow_imp.g_varchar2_table(1368) := ' The primary official or common language is French.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    countr';
wwv_flow_imp.g_varchar2_table(1369) := 'y_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, capital_city, es';
wwv_flow_imp.g_varchar2_table(1370) := 'timated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, description'||wwv_flow.LF||
'  ) VALU';
wwv_flow_imp.g_varchar2_table(1371) := 'ES ('||wwv_flow.LF||
'    ''WS'', ''WSM'', UNISTR(''Oceania''), UNISTR(''S\0101moa''),'||wwv_flow.LF||
'    UNISTR(''Samoa''), UNISTR(''Apia''), 2';
wwv_flow_imp.g_varchar2_table(1372) := '20528,'||wwv_flow.LF||
'    2026, UNISTR(''English, Samoan''),'||wwv_flow.LF||
'    UNISTR(''Samoa is located in Polynesia. Its capital i';
wwv_flow_imp.g_varchar2_table(1373) := 's Apia. Official or common languages include English and Samoan.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries';
wwv_flow_imp.g_varchar2_table(1374) := ' ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    country_name_english, cap';
wwv_flow_imp.g_varchar2_table(1375) := 'ital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_common_language, descrip';
wwv_flow_imp.g_varchar2_table(1376) := 'tion'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''YE'', ''YEM'', UNISTR(''Asia''), UNISTR(''\0627\0644\064A\0645\0646''),'||wwv_flow.LF||
'    UNISTR(''';
wwv_flow_imp.g_varchar2_table(1377) := 'Yemen''), UNISTR(''Sana''''a''), 42961653,'||wwv_flow.LF||
'    2026, UNISTR(''Arabic''),'||wwv_flow.LF||
'    UNISTR(''Yemen is located in We';
wwv_flow_imp.g_varchar2_table(1378) := 'stern Asia. Its capital is Sana''''a. The primary official or common language is Arabic.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into ';
wwv_flow_imp.g_varchar2_table(1379) := 'eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    cou';
wwv_flow_imp.g_varchar2_table(1380) := 'ntry_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_co';
wwv_flow_imp.g_varchar2_table(1381) := 'mmon_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''YT'', ''MYT'', UNISTR(''Africa''), UNISTR(''Mayotte''),'||wwv_flow.LF||
'    UN';
wwv_flow_imp.g_varchar2_table(1382) := 'ISTR(''Mayotte''), UNISTR(''Mamoudzou''), 347536,'||wwv_flow.LF||
'    2026, UNISTR(''French''),'||wwv_flow.LF||
'    UNISTR(''Mayotte is loc';
wwv_flow_imp.g_varchar2_table(1383) := 'ated in Eastern Africa. Its capital is Mamoudzou. The primary official or common language is French.';
wwv_flow_imp.g_varchar2_table(1384) := ''')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country';
wwv_flow_imp.g_varchar2_table(1385) := '_name,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, ';
wwv_flow_imp.g_varchar2_table(1386) := 'official_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''ZA'', ''ZAF'', UNISTR(''Africa''), UNISTR(''Sew';
wwv_flow_imp.g_varchar2_table(1387) := 'ula Afrika''),'||wwv_flow.LF||
'    UNISTR(''South Africa''), UNISTR(''Pretoria''), 65453084,'||wwv_flow.LF||
'    2026, UNISTR(''Afrikaans,';
wwv_flow_imp.g_varchar2_table(1388) := ' English, Southern Ndebele, Northern Sotho, Southern Sotho, Swazi, Tswana, Tsonga, Venda, Xhosa, Zul';
wwv_flow_imp.g_varchar2_table(1389) := 'u''),'||wwv_flow.LF||
'    UNISTR(''South Africa is located in Southern Africa. Its capital is Pretoria. Official or co';
wwv_flow_imp.g_varchar2_table(1390) := 'mmon languages include Afrikaans, English, Southern Ndebele, and other local languages.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  into';
wwv_flow_imp.g_varchar2_table(1391) := ' eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_name,'||wwv_flow.LF||
'    co';
wwv_flow_imp.g_varchar2_table(1392) := 'untry_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, official_or_c';
wwv_flow_imp.g_varchar2_table(1393) := 'ommon_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''ZM'', ''ZMB'', UNISTR(''Africa''), UNISTR(''Zambia''),'||wwv_flow.LF||
'    UN';
wwv_flow_imp.g_varchar2_table(1394) := 'ISTR(''Zambia''), UNISTR(''Lusaka''), 22521915,'||wwv_flow.LF||
'    2026, UNISTR(''English''),'||wwv_flow.LF||
'    UNISTR(''Zambia is locat';
wwv_flow_imp.g_varchar2_table(1395) := 'ed in Eastern Africa. Its capital is Lusaka. The primary official or common language is English.'')'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1396) := ' )'||wwv_flow.LF||
'  into eba_srch_txt_countries ('||wwv_flow.LF||
'    country_code_alpha2, country_code_alpha3, region, country_nam';
wwv_flow_imp.g_varchar2_table(1397) := 'e,'||wwv_flow.LF||
'    country_name_english, capital_city, estimated_population,'||wwv_flow.LF||
'    estimated_population_year, offi';
wwv_flow_imp.g_varchar2_table(1398) := 'cial_or_common_language, description'||wwv_flow.LF||
'  ) VALUES ('||wwv_flow.LF||
'    ''ZW'', ''ZWE'', UNISTR(''Africa''), UNISTR(''Zimbabw';
wwv_flow_imp.g_varchar2_table(1399) := 'e''),'||wwv_flow.LF||
'    UNISTR(''Zimbabwe''), UNISTR(''Harare''), 17273580,'||wwv_flow.LF||
'    2026, UNISTR(''Chibarwe, English, Kalang';
wwv_flow_imp.g_varchar2_table(1400) := 'a, Khoisan, Ndau, Northern Ndebele, Chewa, Shona, Sotho, Tonga, Tswana, Tsonga, Venda, Xhosa, Zimbab';
wwv_flow_imp.g_varchar2_table(1401) := 'wean Sign Language''),'||wwv_flow.LF||
'    UNISTR(''Zimbabwe is located in Eastern Africa. Its capital is Harare. Offi';
wwv_flow_imp.g_varchar2_table(1402) := 'cial or common languages include Chibarwe, English, Kalanga, and other local languages.'')'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'SELECT';
wwv_flow_imp.g_varchar2_table(1403) := ' 1 FROM dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'COMMIT;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2198361708506577057)
,p_install_id=>wwv_flow_imp.id(2198361304136574490)
,p_name=>'Create Tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
