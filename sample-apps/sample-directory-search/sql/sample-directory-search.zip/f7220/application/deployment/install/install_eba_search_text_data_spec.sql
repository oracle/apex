prompt --application/deployment/install/install_eba_search_text_data_spec
begin
--   Manifest
--     INSTALL: INSTALL-eba_search_text_data spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_search_text_data as'||wwv_flow.LF||
'  procedure create_cost_center ('||wwv_flow.LF||
'    p_cost_center';
wwv_flow_imp.g_varchar2_table(2) := '_description in eba_srch_txt_cost_centers.cost_center_description%type,'||wwv_flow.LF||
'    p_created_cost_center_id';
wwv_flow_imp.g_varchar2_table(3) := ' out eba_srch_txt_cost_centers.cost_center_id%type'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedure create_group ('||wwv_flow.LF||
'    p_group_name';
wwv_flow_imp.g_varchar2_table(4) := ' in eba_srch_txt_groups.group_name%type,'||wwv_flow.LF||
'    p_group_description in eba_srch_txt_groups.group_descri';
wwv_flow_imp.g_varchar2_table(5) := 'ption%type,'||wwv_flow.LF||
'    p_created_group_id out eba_srch_txt_groups.group_id%type'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedure create_em';
wwv_flow_imp.g_varchar2_table(6) := 'ployee ('||wwv_flow.LF||
'    p_first_name in eba_srch_txt_employees.first_name%type,'||wwv_flow.LF||
'    p_last_name in eba_srch_txt';
wwv_flow_imp.g_varchar2_table(7) := '_employees.last_name%type,'||wwv_flow.LF||
'    p_email in eba_srch_txt_employees.email%type,'||wwv_flow.LF||
'    p_user_id in eba_sr';
wwv_flow_imp.g_varchar2_table(8) := 'ch_txt_employees.user_id%type,'||wwv_flow.LF||
'    p_country in eba_srch_txt_employees.country%type,'||wwv_flow.LF||
'    p_country_c';
wwv_flow_imp.g_varchar2_table(9) := 'ode in eba_srch_txt_employees.country_code%type,'||wwv_flow.LF||
'    p_geographic_region in eba_srch_txt_employees.g';
wwv_flow_imp.g_varchar2_table(10) := 'eographic_region%type,'||wwv_flow.LF||
'    p_city in eba_srch_txt_employees.city%type,'||wwv_flow.LF||
'    p_career_level in eba_src';
wwv_flow_imp.g_varchar2_table(11) := 'h_txt_employees.career_level%type,'||wwv_flow.LF||
'    p_job_title in eba_srch_txt_employees.job_title%type,'||wwv_flow.LF||
'    p_c';
wwv_flow_imp.g_varchar2_table(12) := 'ost_center_id in eba_srch_txt_employees.cost_center_id%type,'||wwv_flow.LF||
'    p_manager_id in eba_srch_txt_employ';
wwv_flow_imp.g_varchar2_table(13) := 'ees.manager_id%type,'||wwv_flow.LF||
'    p_org_size in eba_srch_txt_employees.org_size%type,'||wwv_flow.LF||
'    p_direct_reports in';
wwv_flow_imp.g_varchar2_table(14) := ' eba_srch_txt_employees.direct_reports%type,'||wwv_flow.LF||
'    p_phone_country_code in eba_srch_txt_employees.phon';
wwv_flow_imp.g_varchar2_table(15) := 'e_country_code%type,'||wwv_flow.LF||
'    p_phone_number in eba_srch_txt_employees.phone_number%type,'||wwv_flow.LF||
'    p_profile i';
wwv_flow_imp.g_varchar2_table(16) := 'n eba_srch_txt_employees.profile%type,'||wwv_flow.LF||
'    p_tags in eba_srch_txt_employees.tags%type,'||wwv_flow.LF||
'    p_employe';
wwv_flow_imp.g_varchar2_table(17) := 'e_groups in varchar2,'||wwv_flow.LF||
'    p_permalink in eba_srch_txt_employees.permalink%type,'||wwv_flow.LF||
'    p_timezone in eb';
wwv_flow_imp.g_varchar2_table(18) := 'a_srch_txt_employees.timezone%type,'||wwv_flow.LF||
'    p_created_employee_id out eba_srch_txt_employees.employee_id';
wwv_flow_imp.g_varchar2_table(19) := '%type'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedure seed_cost_centers ('||wwv_flow.LF||
'    p_num_rows in int'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedure seed_groups ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(20) := '  p_num_rows in int'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'  /**'||wwv_flow.LF||
'   * Generates employee rows with country-appropriate names and orga';
wwv_flow_imp.g_varchar2_table(21) := 'nization'||wwv_flow.LF||
'   * attributes. Cost centers must be seeded before calling this procedure when'||wwv_flow.LF||
'   * p_num_';
wwv_flow_imp.g_varchar2_table(22) := 'rows is greater than zero.'||wwv_flow.LF||
'   *'||wwv_flow.LF||
'   * @param p_num_rows Number of employee rows to generate. Must be ';
wwv_flow_imp.g_varchar2_table(23) := 'zero or'||wwv_flow.LF||
'   *                   greater.'||wwv_flow.LF||
'   *'||wwv_flow.LF||
'   * @example Generate 1,234 employees after the requir';
wwv_flow_imp.g_varchar2_table(24) := 'ed reference data exists:'||wwv_flow.LF||
'   * <pre>'||wwv_flow.LF||
'   * begin'||wwv_flow.LF||
'   *   eba_search_text_data.seed_cost_centers(30);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(25) := '  *   eba_search_text_data.seed_groups(20);'||wwv_flow.LF||
'   *   eba_search_text_data.seed_employees(1234);'||wwv_flow.LF||
'   *  ';
wwv_flow_imp.g_varchar2_table(26) := ' commit;'||wwv_flow.LF||
'   * end;'||wwv_flow.LF||
'   * /'||wwv_flow.LF||
'   * </pre>'||wwv_flow.LF||
'   */'||wwv_flow.LF||
'  procedure seed_employees ('||wwv_flow.LF||
'    p_num_rows in int'||wwv_flow.LF||
'  );'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(27) := ''||wwv_flow.LF||
'  procedure seed_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'  /**'||wwv_flow.LF||
'   * Deletes all data generated by this package from EMPLOYEE_GROUPS,';
wwv_flow_imp.g_varchar2_table(28) := ''||wwv_flow.LF||
'   * EMPLOYEES, GROUPS, and COST_CENTERS in foreign-key-safe order.'||wwv_flow.LF||
'   *'||wwv_flow.LF||
'   * The procedure does no';
wwv_flow_imp.g_varchar2_table(29) := 't commit. The caller controls the transaction and'||wwv_flow.LF||
'   * can issue COMMIT or ROLLBACK after the call.'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(30) := '   *'||wwv_flow.LF||
'   * @example Remove generated data and seed a fresh data set:'||wwv_flow.LF||
'   * <pre>'||wwv_flow.LF||
'   * begin'||wwv_flow.LF||
'   *   eba';
wwv_flow_imp.g_varchar2_table(31) := '_search_text_data.remove_data;'||wwv_flow.LF||
'   *   eba_search_text_data.seed_cost_centers(30);'||wwv_flow.LF||
'   *   eba_search_';
wwv_flow_imp.g_varchar2_table(32) := 'text_data.seed_groups(20);'||wwv_flow.LF||
'   *   eba_search_text_data.seed_employees(1234);'||wwv_flow.LF||
'   *   commit;'||wwv_flow.LF||
'   * end';
wwv_flow_imp.g_varchar2_table(33) := ';'||wwv_flow.LF||
'   * /'||wwv_flow.LF||
'   * </pre>'||wwv_flow.LF||
'   */'||wwv_flow.LF||
'  procedure remove_data;'||wwv_flow.LF||
'end eba_search_text_data;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2198361905839581810)
,p_install_id=>wwv_flow_imp.id(2198361304136574490)
,p_name=>'eba_search_text_data spec'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
