prompt --application/deployment/install/install_initialize
begin
--   Manifest
--     INSTALL: INSTALL-Initialize
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    eba_search_text_data.seed_data;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_search_text_helper.create_text_index';
wwv_flow_imp.g_varchar2_table(2) := '('||wwv_flow.LF||
'        p_table_name   => ''EBA_SRCH_TXT_EMPLOYEES'','||wwv_flow.LF||
'        p_index_name   => ''EBA_SRCH_TXT_EMPS_F';
wwv_flow_imp.g_varchar2_table(3) := 'TIDX'','||wwv_flow.LF||
'        p_index_column => ''LAST_NAME'','||wwv_flow.LF||
'        p_config       =>  eba_search_text_helper.get_';
wwv_flow_imp.g_varchar2_table(4) := 'config );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'sho err';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2198520058720914063)
,p_install_id=>wwv_flow_imp.id(2198361304136574490)
,p_name=>'Initialize'
,p_sequence=>60
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
