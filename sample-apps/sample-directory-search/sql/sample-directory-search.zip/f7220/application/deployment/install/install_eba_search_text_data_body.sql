prompt --application/deployment/install/install_eba_search_text_data_body
begin
--   Manifest
--     INSTALL: INSTALL-eba_search_text_data body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body eba_search_text_data as'||wwv_flow.LF||
'  type t_name_array is table of varchar2(200)';
wwv_flow_imp.g_varchar2_table(2) := ' index by pls_integer;'||wwv_flow.LF||
''||wwv_flow.LF||
'  g_cost_center_names t_name_array;'||wwv_flow.LF||
'  g_group_names t_name_array;'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedu';
wwv_flow_imp.g_varchar2_table(3) := 're initialize_reference_data as'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    g_cost_center_names(1) := ''Executive Leadership'';'||wwv_flow.LF||
'    g_';
wwv_flow_imp.g_varchar2_table(4) := 'cost_center_names(2) := ''Corporate Strategy'';'||wwv_flow.LF||
'    g_cost_center_names(3) := ''Finance & Accounting'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := '    g_cost_center_names(4) := ''Treasury & Cash Management'';'||wwv_flow.LF||
'    g_cost_center_names(5) := ''Tax'';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(6) := ' g_cost_center_names(6) := ''Internal Audit'';'||wwv_flow.LF||
'    g_cost_center_names(7) := ''Human Resources'';'||wwv_flow.LF||
'    g_';
wwv_flow_imp.g_varchar2_table(7) := 'cost_center_names(8) := ''Talent Acquisition'';'||wwv_flow.LF||
'    g_cost_center_names(9) := ''Legal & Compliance'';'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(8) := '  g_cost_center_names(10) := ''Risk Management'';'||wwv_flow.LF||
'    g_cost_center_names(11) := ''Information Technolo';
wwv_flow_imp.g_varchar2_table(9) := 'gy'';'||wwv_flow.LF||
'    g_cost_center_names(12) := ''Cybersecurity'';'||wwv_flow.LF||
'    g_cost_center_names(13) := ''Data & Analytic';
wwv_flow_imp.g_varchar2_table(10) := 's'';'||wwv_flow.LF||
'    g_cost_center_names(14) := ''Software Engineering'';'||wwv_flow.LF||
'    g_cost_center_names(15) := ''Product M';
wwv_flow_imp.g_varchar2_table(11) := 'anagement'';'||wwv_flow.LF||
'    g_cost_center_names(16) := ''Quality Assurance'';'||wwv_flow.LF||
'    g_cost_center_names(17) := ''Ente';
wwv_flow_imp.g_varchar2_table(12) := 'rprise Architecture'';'||wwv_flow.LF||
'    g_cost_center_names(18) := ''Cloud & Infrastructure'';'||wwv_flow.LF||
'    g_cost_center_nam';
wwv_flow_imp.g_varchar2_table(13) := 'es(19) := ''Technical Support'';'||wwv_flow.LF||
'    g_cost_center_names(20) := ''Professional Services'';'||wwv_flow.LF||
'    g_cost_ce';
wwv_flow_imp.g_varchar2_table(14) := 'nter_names(21) := ''Consulting Delivery'';'||wwv_flow.LF||
'    g_cost_center_names(22) := ''Program Management'';'||wwv_flow.LF||
'    g_';
wwv_flow_imp.g_varchar2_table(15) := 'cost_center_names(23) := ''Sales'';'||wwv_flow.LF||
'    g_cost_center_names(24) := ''Marketing'';'||wwv_flow.LF||
'    g_cost_center_name';
wwv_flow_imp.g_varchar2_table(16) := 's(25) := ''Business Development'';'||wwv_flow.LF||
'    g_cost_center_names(26) := ''Customer Success'';'||wwv_flow.LF||
'    g_cost_cente';
wwv_flow_imp.g_varchar2_table(17) := 'r_names(27) := ''Operations'';'||wwv_flow.LF||
'    g_cost_center_names(28) := ''Procurement & Vendor Management'';'||wwv_flow.LF||
'    g';
wwv_flow_imp.g_varchar2_table(18) := '_cost_center_names(29) := ''Corporate Communications'';'||wwv_flow.LF||
'    g_cost_center_names(30) := ''Facilities & W';
wwv_flow_imp.g_varchar2_table(19) := 'orkplace'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    g_group_names(1) := ''Technology Architecture Council'';'||wwv_flow.LF||
'    g_group_names(2) := ''Clou';
wwv_flow_imp.g_varchar2_table(20) := 'd Engineering Guild'';'||wwv_flow.LF||
'    g_group_names(3) := ''Cybersecurity Community'';'||wwv_flow.LF||
'    g_group_names(4) := ''Da';
wwv_flow_imp.g_varchar2_table(21) := 'ta & Analytics Forum'';'||wwv_flow.LF||
'    g_group_names(5) := ''AI & Machine Learning Network'';'||wwv_flow.LF||
'    g_group_names(6)';
wwv_flow_imp.g_varchar2_table(22) := ' := ''APEX & Low-Code Guild'';'||wwv_flow.LF||
'    g_group_names(7) := ''Developer Productivity Group'';'||wwv_flow.LF||
'    g_group_nam';
wwv_flow_imp.g_varchar2_table(23) := 'es(8) := ''DevOps & SRE Community'';'||wwv_flow.LF||
'    g_group_names(9) := ''Quality Engineering Forum'';'||wwv_flow.LF||
'    g_group_';
wwv_flow_imp.g_varchar2_table(24) := 'names(10) := ''Product Management Community'';'||wwv_flow.LF||
'    g_group_names(11) := ''UX & Design Guild'';'||wwv_flow.LF||
'    g_gro';
wwv_flow_imp.g_varchar2_table(25) := 'up_names(12) := ''Customer Experience Forum'';'||wwv_flow.LF||
'    g_group_names(13) := ''Customer Success Network'';'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(26) := '  g_group_names(14) := ''Sales Excellence Community'';'||wwv_flow.LF||
'    g_group_names(15) := ''Partner Ecosystem For';
wwv_flow_imp.g_varchar2_table(27) := 'um'';'||wwv_flow.LF||
'    g_group_names(16) := ''Marketing & Brand Community'';'||wwv_flow.LF||
'    g_group_names(17) := ''Corporate Com';
wwv_flow_imp.g_varchar2_table(28) := 'munications Network'';'||wwv_flow.LF||
'    g_group_names(18) := ''Finance & Accounting Forum'';'||wwv_flow.LF||
'    g_group_names(19) :';
wwv_flow_imp.g_varchar2_table(29) := '= ''FP&A Community'';'||wwv_flow.LF||
'    g_group_names(20) := ''Procurement & Vendor Management'';'||wwv_flow.LF||
'    g_group_names(21';
wwv_flow_imp.g_varchar2_table(30) := ') := ''Legal & Compliance Network'';'||wwv_flow.LF||
'    g_group_names(22) := ''Internal Audit & Controls'';'||wwv_flow.LF||
'    g_group';
wwv_flow_imp.g_varchar2_table(31) := '_names(23) := ''People & Culture Community'';'||wwv_flow.LF||
'    g_group_names(24) := ''Talent Development Network'';'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(32) := '   g_group_names(25) := ''Emerging Leaders Forum'';'||wwv_flow.LF||
'    g_group_names(26) := ''Women in Technology Netw';
wwv_flow_imp.g_varchar2_table(33) := 'ork'';'||wwv_flow.LF||
'    g_group_names(27) := ''Inclusion & Belonging Council'';'||wwv_flow.LF||
'    g_group_names(28) := ''Sustainabi';
wwv_flow_imp.g_varchar2_table(34) := 'lity & ESG Network'';'||wwv_flow.LF||
'    g_group_names(29) := ''Community Impact Group'';'||wwv_flow.LF||
'    g_group_names(30) := ''Pr';
wwv_flow_imp.g_varchar2_table(35) := 'ofessional Development Forum'';'||wwv_flow.LF||
'    g_group_names(31) := ''Innovation & Ideas Lab'';'||wwv_flow.LF||
'    g_group_names(';
wwv_flow_imp.g_varchar2_table(36) := '32) := ''Leadership Communication Circle'';'||wwv_flow.LF||
'    g_group_names(33) := ''Project & Program Management'';'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(37) := '   g_group_names(34) := ''Agile Practice Community'';'||wwv_flow.LF||
'    g_group_names(35) := ''Business Continuity Ne';
wwv_flow_imp.g_varchar2_table(38) := 'twork'';'||wwv_flow.LF||
'    g_group_names(36) := ''Global Collaboration Forum'';'||wwv_flow.LF||
'    g_group_names(37) := ''Knowledge S';
wwv_flow_imp.g_varchar2_table(39) := 'haring Network'';'||wwv_flow.LF||
'    g_group_names(38) := ''Customer Advisory Council'';'||wwv_flow.LF||
'    g_group_names(39) := ''Bus';
wwv_flow_imp.g_varchar2_table(40) := 'iness Analysis Community'';'||wwv_flow.LF||
'    g_group_names(40) := ''Workplace Wellbeing Network'';'||wwv_flow.LF||
'  end initialize_';
wwv_flow_imp.g_varchar2_table(41) := 'reference_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedure create_cost_center ('||wwv_flow.LF||
'    p_cost_center_description in eba_srch_txt_cost';
wwv_flow_imp.g_varchar2_table(42) := '_centers.cost_center_description%type,'||wwv_flow.LF||
'    p_created_cost_center_id out eba_srch_txt_cost_centers.co';
wwv_flow_imp.g_varchar2_table(43) := 'st_center_id%type'||wwv_flow.LF||
'  ) as'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    insert into eba_srch_txt_cost_centers ('||wwv_flow.LF||
'      cost_center_descr';
wwv_flow_imp.g_varchar2_table(44) := 'iption'||wwv_flow.LF||
'    ) values ('||wwv_flow.LF||
'      p_cost_center_description'||wwv_flow.LF||
'    ) returning cost_center_id into p_created_';
wwv_flow_imp.g_varchar2_table(45) := 'cost_center_id;'||wwv_flow.LF||
'  end create_cost_center;'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedure create_group ('||wwv_flow.LF||
'    p_group_name in eba_srch_t';
wwv_flow_imp.g_varchar2_table(46) := 'xt_groups.group_name%type,'||wwv_flow.LF||
'    p_group_description in eba_srch_txt_groups.group_description%type,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(47) := '  p_created_group_id out eba_srch_txt_groups.group_id%type'||wwv_flow.LF||
'  ) as'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    insert into eba_srch_t';
wwv_flow_imp.g_varchar2_table(48) := 'xt_groups ('||wwv_flow.LF||
'      group_name,'||wwv_flow.LF||
'      group_description'||wwv_flow.LF||
'    ) values ('||wwv_flow.LF||
'      p_group_name,'||wwv_flow.LF||
'      p_gro';
wwv_flow_imp.g_varchar2_table(49) := 'up_description'||wwv_flow.LF||
'    ) returning group_id into p_created_group_id;'||wwv_flow.LF||
'  end create_group;'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedure cr';
wwv_flow_imp.g_varchar2_table(50) := 'eate_employee ('||wwv_flow.LF||
'    p_first_name in eba_srch_txt_employees.first_name%type,'||wwv_flow.LF||
'    p_last_name in eba_s';
wwv_flow_imp.g_varchar2_table(51) := 'rch_txt_employees.last_name%type,'||wwv_flow.LF||
'    p_email in eba_srch_txt_employees.email%type,'||wwv_flow.LF||
'    p_user_id in';
wwv_flow_imp.g_varchar2_table(52) := ' eba_srch_txt_employees.user_id%type,'||wwv_flow.LF||
'    p_country in eba_srch_txt_employees.country%type,'||wwv_flow.LF||
'    p_co';
wwv_flow_imp.g_varchar2_table(53) := 'untry_code in eba_srch_txt_employees.country_code%type,'||wwv_flow.LF||
'    p_geographic_region in eba_srch_txt_empl';
wwv_flow_imp.g_varchar2_table(54) := 'oyees.geographic_region%type,'||wwv_flow.LF||
'    p_city in eba_srch_txt_employees.city%type,'||wwv_flow.LF||
'    p_career_level in ';
wwv_flow_imp.g_varchar2_table(55) := 'eba_srch_txt_employees.career_level%type,'||wwv_flow.LF||
'    p_job_title in eba_srch_txt_employees.job_title%type,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(56) := '    p_cost_center_id in eba_srch_txt_employees.cost_center_id%type,'||wwv_flow.LF||
'    p_manager_id in eba_srch_txt';
wwv_flow_imp.g_varchar2_table(57) := '_employees.manager_id%type,'||wwv_flow.LF||
'    p_org_size in eba_srch_txt_employees.org_size%type,'||wwv_flow.LF||
'    p_direct_rep';
wwv_flow_imp.g_varchar2_table(58) := 'orts in eba_srch_txt_employees.direct_reports%type,'||wwv_flow.LF||
'    p_phone_country_code in eba_srch_txt_employe';
wwv_flow_imp.g_varchar2_table(59) := 'es.phone_country_code%type,'||wwv_flow.LF||
'    p_phone_number in eba_srch_txt_employees.phone_number%type,'||wwv_flow.LF||
'    p_pr';
wwv_flow_imp.g_varchar2_table(60) := 'ofile in eba_srch_txt_employees.profile%type,'||wwv_flow.LF||
'    p_tags in eba_srch_txt_employees.tags%type,'||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(61) := 'employee_groups in varchar2,'||wwv_flow.LF||
'    p_permalink in eba_srch_txt_employees.permalink%type,'||wwv_flow.LF||
'    p_timezon';
wwv_flow_imp.g_varchar2_table(62) := 'e in eba_srch_txt_employees.timezone%type,'||wwv_flow.LF||
'    p_created_employee_id out eba_srch_txt_employees.empl';
wwv_flow_imp.g_varchar2_table(63) := 'oyee_id%type'||wwv_flow.LF||
'  ) as'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    insert into eba_srch_txt_employees ('||wwv_flow.LF||
'      first_name,'||wwv_flow.LF||
'      last_na';
wwv_flow_imp.g_varchar2_table(64) := 'me,'||wwv_flow.LF||
'      email,'||wwv_flow.LF||
'      user_id,'||wwv_flow.LF||
'      country,'||wwv_flow.LF||
'      country_code,'||wwv_flow.LF||
'      geographic_region,'||wwv_flow.LF||
'      ci';
wwv_flow_imp.g_varchar2_table(65) := 'ty,'||wwv_flow.LF||
'      career_level,'||wwv_flow.LF||
'      job_title,'||wwv_flow.LF||
'      cost_center_id,'||wwv_flow.LF||
'      manager_id,'||wwv_flow.LF||
'      org_size,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(66) := '   direct_reports,'||wwv_flow.LF||
'      phone_country_code,'||wwv_flow.LF||
'      phone_number,'||wwv_flow.LF||
'      profile,'||wwv_flow.LF||
'      tags,'||wwv_flow.LF||
'      em';
wwv_flow_imp.g_varchar2_table(67) := 'ployee_groups,'||wwv_flow.LF||
'      permalink,'||wwv_flow.LF||
'      timezone'||wwv_flow.LF||
'    ) values ('||wwv_flow.LF||
'      p_first_name,'||wwv_flow.LF||
'      p_last_name,';
wwv_flow_imp.g_varchar2_table(68) := ''||wwv_flow.LF||
'      p_email,'||wwv_flow.LF||
'      p_user_id,'||wwv_flow.LF||
'      p_country,'||wwv_flow.LF||
'      p_country_code,'||wwv_flow.LF||
'      p_geographic_region,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(69) := '     p_city,'||wwv_flow.LF||
'      p_career_level,'||wwv_flow.LF||
'      p_job_title,'||wwv_flow.LF||
'      p_cost_center_id,'||wwv_flow.LF||
'      p_manager_id,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(70) := '    p_org_size,'||wwv_flow.LF||
'      p_direct_reports,'||wwv_flow.LF||
'      p_phone_country_code,'||wwv_flow.LF||
'      p_phone_number,'||wwv_flow.LF||
'      p_pr';
wwv_flow_imp.g_varchar2_table(71) := 'ofile,'||wwv_flow.LF||
'      p_tags,'||wwv_flow.LF||
'      p_employee_groups,'||wwv_flow.LF||
'      p_permalink,'||wwv_flow.LF||
'      p_timezone'||wwv_flow.LF||
'    ) returning em';
wwv_flow_imp.g_varchar2_table(72) := 'ployee_id into p_created_employee_id;'||wwv_flow.LF||
'  end create_employee;'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedure seed_cost_centers ('||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(73) := 'num_rows in int'||wwv_flow.LF||
'  ) as'||wwv_flow.LF||
'    l_created_cost_center_id eba_srch_txt_cost_centers.cost_center_id%type;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(74) := ' begin'||wwv_flow.LF||
'    if p_num_rows is null or p_num_rows < 0 or p_num_rows > g_cost_center_names.count then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(75) := '    raise_application_error(-20001, ''seed_cost_centers accepts a row count from 0 through 30.'');'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(76) := ' end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_num_rows > 0 then'||wwv_flow.LF||
'      for i in 1..p_num_rows loop'||wwv_flow.LF||
'        create_cost_center('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(77) := '         p_cost_center_description => g_cost_center_names(i),'||wwv_flow.LF||
'          p_created_cost_center_id => ';
wwv_flow_imp.g_varchar2_table(78) := 'l_created_cost_center_id'||wwv_flow.LF||
'        );'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  end seed_cost_centers;'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedur';
wwv_flow_imp.g_varchar2_table(79) := 'e seed_groups ('||wwv_flow.LF||
'    p_num_rows in int'||wwv_flow.LF||
'  ) as'||wwv_flow.LF||
'    l_created_group_id eba_srch_txt_groups.group_id%typ';
wwv_flow_imp.g_varchar2_table(80) := 'e;'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    if p_num_rows is null or p_num_rows < 0 or p_num_rows > g_group_names.count then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(81) := '  raise_application_error(-20002, ''seed_groups accepts a row count from 0 through 40.'');'||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(82) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_num_rows > 0 then'||wwv_flow.LF||
'      for i in 1..p_num_rows loop'||wwv_flow.LF||
'        create_group('||wwv_flow.LF||
'          p_gro';
wwv_flow_imp.g_varchar2_table(83) := 'up_name => g_group_names(i),'||wwv_flow.LF||
'          p_group_description => ''Corporate employee community for '' ||';
wwv_flow_imp.g_varchar2_table(84) := ' lower(g_group_names(i)) || ''.'','||wwv_flow.LF||
'          p_created_group_id => l_created_group_id'||wwv_flow.LF||
'        );'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(85) := ' end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  end seed_groups;'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedure remove_data as'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    update eba_srch_tx';
wwv_flow_imp.g_varchar2_table(86) := 't_employees'||wwv_flow.LF||
'       set manager_id = null;'||wwv_flow.LF||
'    delete from eba_srch_txt_employees;'||wwv_flow.LF||
'    delete from eb';
wwv_flow_imp.g_varchar2_table(87) := 'a_srch_txt_groups;'||wwv_flow.LF||
'    delete from eba_srch_txt_cost_centers;'||wwv_flow.LF||
'  end remove_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedure seed_d';
wwv_flow_imp.g_varchar2_table(88) := 'ata as'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    seed_cost_centers(30);'||wwv_flow.LF||
'    seed_groups(40);'||wwv_flow.LF||
'    seed_employees(1234);'||wwv_flow.LF||
'  end seed_';
wwv_flow_imp.g_varchar2_table(89) := 'data;'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedure seed_employees ('||wwv_flow.LF||
'    p_num_rows in int'||wwv_flow.LF||
'  ) as'||wwv_flow.LF||
'    type t_string_array is table of';
wwv_flow_imp.g_varchar2_table(90) := ' varchar2(100) index by pls_integer;'||wwv_flow.LF||
'    type t_number_array is table of number index by pls_integer';
wwv_flow_imp.g_varchar2_table(91) := ';'||wwv_flow.LF||
'    type t_integer_array is table of pls_integer index by pls_integer;'||wwv_flow.LF||
'    type t_name_pool is tab';
wwv_flow_imp.g_varchar2_table(92) := 'le of varchar2(100) index by varchar2(40);'||wwv_flow.LF||
'    type t_manager_pool is table of eba_srch_txt_employee';
wwv_flow_imp.g_varchar2_table(93) := 's.manager_id%type index by varchar2(40);'||wwv_flow.LF||
'    type t_catalog_array is table of varchar2(32767) index ';
wwv_flow_imp.g_varchar2_table(94) := 'by pls_integer;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_country_name t_string_array;'||wwv_flow.LF||
'    l_country_code t_string_array;'||wwv_flow.LF||
'    l_name_gr';
wwv_flow_imp.g_varchar2_table(95) := 'oup t_string_array;'||wwv_flow.LF||
'    l_country_weight t_number_array;'||wwv_flow.LF||
'    l_country_target t_integer_array;'||wwv_flow.LF||
'    l';
wwv_flow_imp.g_varchar2_table(96) := '_country_fraction t_number_array;'||wwv_flow.LF||
'    l_employee_country t_integer_array;'||wwv_flow.LF||
'    l_cost_center_id t_num';
wwv_flow_imp.g_varchar2_table(97) := 'ber_array;'||wwv_flow.LF||
'    l_group_id t_number_array;'||wwv_flow.LF||
'    l_manager_id t_number_array;'||wwv_flow.LF||
'    l_manager_country t_i';
wwv_flow_imp.g_varchar2_table(98) := 'nteger_array;'||wwv_flow.LF||
'    l_manager_by_country t_manager_pool;'||wwv_flow.LF||
'    l_manager_by_region t_manager_pool;'||wwv_flow.LF||
'    l';
wwv_flow_imp.g_varchar2_table(99) := '_manager_count_by_country t_integer_array;'||wwv_flow.LF||
'    l_manager_count_by_region t_integer_array;'||wwv_flow.LF||
'    l_cost';
wwv_flow_imp.g_varchar2_table(100) := '_center_name t_string_array;'||wwv_flow.LF||
'    l_group_name t_string_array;'||wwv_flow.LF||
'    l_first_name_pool t_name_pool;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(101) := ' l_last_name_pool t_name_pool;'||wwv_flow.LF||
'    l_first_name_extension_pool t_name_pool;'||wwv_flow.LF||
'    l_last_name_extensio';
wwv_flow_imp.g_varchar2_table(102) := 'n_pool t_name_pool;'||wwv_flow.LF||
'    l_first_name_catalog t_catalog_array;'||wwv_flow.LF||
'    l_last_name_catalog t_catalog_arra';
wwv_flow_imp.g_varchar2_table(103) := 'y;'||wwv_flow.LF||
'    l_first_name_order t_integer_array;'||wwv_flow.LF||
'    l_last_name_order t_integer_array;'||wwv_flow.LF||
'    l_first_name_n';
wwv_flow_imp.g_varchar2_table(104) := 'ext t_integer_array;'||wwv_flow.LF||
'    l_last_name_next t_integer_array;'||wwv_flow.LF||
'    l_first_name_pool_size_by_group t_int';
wwv_flow_imp.g_varchar2_table(105) := 'eger_array;'||wwv_flow.LF||
'    l_last_name_pool_size_by_group t_integer_array;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_country_count pls_integer := ';
wwv_flow_imp.g_varchar2_table(106) := '45;'||wwv_flow.LF||
'    -- One hyphenated first name per 200 names (0.5%) and one hyphenated'||wwv_flow.LF||
'    -- last name per 20';
wwv_flow_imp.g_varchar2_table(107) := ' names (5%) at most for each seed_employees call.'||wwv_flow.LF||
'    l_max_name_pool_size constant pls_integer := 3';
wwv_flow_imp.g_varchar2_table(108) := '000;'||wwv_flow.LF||
'    l_first_name_hyphen_interval constant pls_integer := 200;'||wwv_flow.LF||
'    l_last_name_hyphen_interval c';
wwv_flow_imp.g_varchar2_table(109) := 'onstant pls_integer := 20;'||wwv_flow.LF||
'    l_name_group_count constant pls_integer := 14;'||wwv_flow.LF||
'    l_cost_center_coun';
wwv_flow_imp.g_varchar2_table(110) := 't pls_integer := 0;'||wwv_flow.LF||
'    l_group_count pls_integer := 0;'||wwv_flow.LF||
'    l_manager_count pls_integer := 0;'||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(111) := 'total_weight number := 0;'||wwv_flow.LF||
'    l_assigned_rows pls_integer := 0;'||wwv_flow.LF||
'    l_remaining_rows pls_integer := ';
wwv_flow_imp.g_varchar2_table(112) := '0;'||wwv_flow.LF||
'    l_best_country pls_integer;'||wwv_flow.LF||
'    l_best_fraction number;'||wwv_flow.LF||
'    l_sequence_no pls_integer := 0;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(113) := '   l_swap_no pls_integer;'||wwv_flow.LF||
'    l_country_no pls_integer;'||wwv_flow.LF||
'    l_region_no pls_integer;'||wwv_flow.LF||
'    l_cost_cent';
wwv_flow_imp.g_varchar2_table(114) := 'er_no pls_integer;'||wwv_flow.LF||
'    l_group_no pls_integer;'||wwv_flow.LF||
'    l_membership_count pls_integer;'||wwv_flow.LF||
'    l_first_name_';
wwv_flow_imp.g_varchar2_table(115) := 'pick_count pls_integer := 0;'||wwv_flow.LF||
'    l_last_name_pick_count pls_integer := 0;'||wwv_flow.LF||
'    l_employee_id eba_srch';
wwv_flow_imp.g_varchar2_table(116) := '_txt_employees.employee_id%type;'||wwv_flow.LF||
'    l_first_name eba_srch_txt_employees.first_name%type;'||wwv_flow.LF||
'    l_last';
wwv_flow_imp.g_varchar2_table(117) := '_name eba_srch_txt_employees.last_name%type;'||wwv_flow.LF||
'    l_first_identifier varchar2(200);'||wwv_flow.LF||
'    l_last_identi';
wwv_flow_imp.g_varchar2_table(118) := 'fier varchar2(200);'||wwv_flow.LF||
'    l_email eba_srch_txt_employees.email%type;'||wwv_flow.LF||
'    l_user_id eba_srch_txt_employ';
wwv_flow_imp.g_varchar2_table(119) := 'ees.user_id%type;'||wwv_flow.LF||
'    l_job_title eba_srch_txt_employees.job_title%type;'||wwv_flow.LF||
'    l_career_level eba_srch';
wwv_flow_imp.g_varchar2_table(120) := '_txt_employees.career_level%type;'||wwv_flow.LF||
'    l_city eba_srch_txt_employees.city%type;'||wwv_flow.LF||
'    l_region eba_srch';
wwv_flow_imp.g_varchar2_table(121) := '_txt_employees.geographic_region%type;'||wwv_flow.LF||
'    l_phone_country_code eba_srch_txt_employees.phone_country';
wwv_flow_imp.g_varchar2_table(122) := '_code%type;'||wwv_flow.LF||
'    l_phone_number eba_srch_txt_employees.phone_number%type;'||wwv_flow.LF||
'    l_direct_reports eba_sr';
wwv_flow_imp.g_varchar2_table(123) := 'ch_txt_employees.direct_reports%type;'||wwv_flow.LF||
'    l_selected_manager_id eba_srch_txt_employees.manager_id%ty';
wwv_flow_imp.g_varchar2_table(124) := 'pe;'||wwv_flow.LF||
'    l_employee_groups varchar2(32767);'||wwv_flow.LF||
'    l_profile eba_srch_txt_employees.profile%type;'||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(125) := 'tags eba_srch_txt_employees.tags%type;'||wwv_flow.LF||
'    l_is_manager boolean;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function name_group_index ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(126) := '    p_group in varchar2'||wwv_flow.LF||
'    ) return pls_integer is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      case p_group'||wwv_flow.LF||
'        when ''NA'' t';
wwv_flow_imp.g_varchar2_table(127) := 'hen return 1;'||wwv_flow.LF||
'        when ''LA'' then return 2;'||wwv_flow.LF||
'        when ''WE'' then return 3;'||wwv_flow.LF||
'        when ''EE'' th';
wwv_flow_imp.g_varchar2_table(128) := 'en return 4;'||wwv_flow.LF||
'        when ''GR'' then return 5;'||wwv_flow.LF||
'        when ''IN'' then return 6;'||wwv_flow.LF||
'        when ''SEA'' th';
wwv_flow_imp.g_varchar2_table(129) := 'en return 7;'||wwv_flow.LF||
'        when ''CN'' then return 8;'||wwv_flow.LF||
'        when ''JP'' then return 9;'||wwv_flow.LF||
'        when ''KR'' the';
wwv_flow_imp.g_varchar2_table(130) := 'n return 10;'||wwv_flow.LF||
'        when ''IL'' then return 11;'||wwv_flow.LF||
'        when ''AR'' then return 12;'||wwv_flow.LF||
'        when ''TR'' t';
wwv_flow_imp.g_varchar2_table(131) := 'hen return 13;'||wwv_flow.LF||
'        when ''AF'' then return 14;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'          raise_application_error(-200';
wwv_flow_imp.g_varchar2_table(132) := '05, ''Unsupported name group: '' || p_group);'||wwv_flow.LF||
'      end case;'||wwv_flow.LF||
'    end name_group_index;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function ';
wwv_flow_imp.g_varchar2_table(133) := 'name_group_code ('||wwv_flow.LF||
'      p_group_no in pls_integer'||wwv_flow.LF||
'    ) return varchar2 is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      case p_gr';
wwv_flow_imp.g_varchar2_table(134) := 'oup_no'||wwv_flow.LF||
'        when 1 then return ''NA'';'||wwv_flow.LF||
'        when 2 then return ''LA'';'||wwv_flow.LF||
'        when 3 then return ';
wwv_flow_imp.g_varchar2_table(135) := '''WE'';'||wwv_flow.LF||
'        when 4 then return ''EE'';'||wwv_flow.LF||
'        when 5 then return ''GR'';'||wwv_flow.LF||
'        when 6 then return ''';
wwv_flow_imp.g_varchar2_table(136) := 'IN'';'||wwv_flow.LF||
'        when 7 then return ''SEA'';'||wwv_flow.LF||
'        when 8 then return ''CN'';'||wwv_flow.LF||
'        when 9 then return ''';
wwv_flow_imp.g_varchar2_table(137) := 'JP'';'||wwv_flow.LF||
'        when 10 then return ''KR'';'||wwv_flow.LF||
'        when 11 then return ''IL'';'||wwv_flow.LF||
'        when 12 then return';
wwv_flow_imp.g_varchar2_table(138) := ' ''AR'';'||wwv_flow.LF||
'        when 13 then return ''TR'';'||wwv_flow.LF||
'        when 14 then return ''AF'';'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'          ra';
wwv_flow_imp.g_varchar2_table(139) := 'ise_application_error(-20006, ''Unsupported name group number: '' || p_group_no);'||wwv_flow.LF||
'      end case;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(140) := 'end name_group_code;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function load_name_catalog ('||wwv_flow.LF||
'      p_catalog in varchar2,'||wwv_flow.LF||
'      p_group in';
wwv_flow_imp.g_varchar2_table(141) := ' varchar2,'||wwv_flow.LF||
'      p_pool in out t_name_pool'||wwv_flow.LF||
'    ) return pls_integer is'||wwv_flow.LF||
'      l_name_no pls_integer :';
wwv_flow_imp.g_varchar2_table(142) := '= 0;'||wwv_flow.LF||
'      l_name_value varchar2(100);'||wwv_flow.LF||
'      l_catalog_pos pls_integer := 1;'||wwv_flow.LF||
'      l_delimiter_pos p';
wwv_flow_imp.g_varchar2_table(143) := 'ls_integer;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      if p_catalog is null then'||wwv_flow.LF||
'        return 0;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      loop'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(144) := '      l_delimiter_pos := instr(p_catalog, ''|'', l_catalog_pos);'||wwv_flow.LF||
'        if l_delimiter_pos = 0 then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(145) := '         l_name_value := substr(p_catalog, l_catalog_pos);'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'          l_name_value := su';
wwv_flow_imp.g_varchar2_table(146) := 'bstr(p_catalog, l_catalog_pos, l_delimiter_pos - l_catalog_pos);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        exit when ';
wwv_flow_imp.g_varchar2_table(147) := 'l_name_value is null;'||wwv_flow.LF||
'        l_name_no := l_name_no + 1;'||wwv_flow.LF||
'        p_pool(p_group || '':'' || to_char(l';
wwv_flow_imp.g_varchar2_table(148) := '_name_no, ''FM0000'')) := l_name_value;'||wwv_flow.LF||
''||wwv_flow.LF||
'        exit when l_delimiter_pos = 0;'||wwv_flow.LF||
'        l_catalog_pos ';
wwv_flow_imp.g_varchar2_table(149) := ':= l_delimiter_pos + 1;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'      return l_name_no;'||wwv_flow.LF||
'    end load_name_catalog;'||wwv_flow.LF||
''||wwv_flow.LF||
'    pro';
wwv_flow_imp.g_varchar2_table(150) := 'cedure reset_name_order ('||wwv_flow.LF||
'      p_order in out t_integer_array,'||wwv_flow.LF||
'      p_pool_size_by_group in t_inte';
wwv_flow_imp.g_varchar2_table(151) := 'ger_array,'||wwv_flow.LF||
'      p_group_no in pls_integer'||wwv_flow.LF||
'    ) is'||wwv_flow.LF||
'      l_group_pool_size pls_integer := p_pool_si';
wwv_flow_imp.g_varchar2_table(152) := 'ze_by_group(p_group_no);'||wwv_flow.LF||
'      l_group_offset pls_integer := (p_group_no - 1) * l_max_name_pool_size';
wwv_flow_imp.g_varchar2_table(153) := ';'||wwv_flow.LF||
'      l_index pls_integer;'||wwv_flow.LF||
'      l_swap_index pls_integer;'||wwv_flow.LF||
'      l_value pls_integer;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(154) := '    for l_index in 1..l_group_pool_size loop'||wwv_flow.LF||
'        p_order(l_group_offset + l_index) := l_index;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(155) := '     end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'      for l_index in reverse 2..l_group_pool_size loop'||wwv_flow.LF||
'        l_swap_index := trunc';
wwv_flow_imp.g_varchar2_table(156) := '(dbms_random.value(1, l_index + 1));'||wwv_flow.LF||
'        l_value := p_order(l_group_offset + l_index);'||wwv_flow.LF||
'        p';
wwv_flow_imp.g_varchar2_table(157) := '_order(l_group_offset + l_index) := p_order(l_group_offset + l_swap_index);'||wwv_flow.LF||
'        p_order(l_group_';
wwv_flow_imp.g_varchar2_table(158) := 'offset + l_swap_index) := l_value;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'    end reset_name_order;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function pick_firs';
wwv_flow_imp.g_varchar2_table(159) := 't_name ('||wwv_flow.LF||
'      p_group in varchar2'||wwv_flow.LF||
'    ) return varchar2 is'||wwv_flow.LF||
'      l_group_no pls_integer;'||wwv_flow.LF||
'      l_na';
wwv_flow_imp.g_varchar2_table(160) := 'me_position pls_integer;'||wwv_flow.LF||
'      l_name_code pls_integer;'||wwv_flow.LF||
'      l_name_value varchar2(100);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(161) := '      l_group_no := name_group_index(p_group);'||wwv_flow.LF||
''||wwv_flow.LF||
'      if l_first_name_next(l_group_no) > l_first_nam';
wwv_flow_imp.g_varchar2_table(162) := 'e_pool_size_by_group(l_group_no) then'||wwv_flow.LF||
'        reset_name_order(l_first_name_order, l_first_name_pool';
wwv_flow_imp.g_varchar2_table(163) := '_size_by_group, l_group_no);'||wwv_flow.LF||
'        l_first_name_next(l_group_no) := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      l_name';
wwv_flow_imp.g_varchar2_table(164) := '_position := l_first_name_next(l_group_no);'||wwv_flow.LF||
'      l_name_code := l_first_name_order((l_group_no - 1)';
wwv_flow_imp.g_varchar2_table(165) := ' * l_max_name_pool_size + l_name_position);'||wwv_flow.LF||
'      l_first_name_next(l_group_no) := l_name_position +';
wwv_flow_imp.g_varchar2_table(166) := ' 1;'||wwv_flow.LF||
'      l_first_name_pick_count := l_first_name_pick_count + 1;'||wwv_flow.LF||
'      l_name_value := l_first_name';
wwv_flow_imp.g_varchar2_table(167) := '_pool('||wwv_flow.LF||
'        p_group || '':'' || to_char(l_name_code, ''FM0000'')'||wwv_flow.LF||
'      );'||wwv_flow.LF||
''||wwv_flow.LF||
'      if mod(l_first_name_';
wwv_flow_imp.g_varchar2_table(168) := 'pick_count, l_first_name_hyphen_interval) = 0 then'||wwv_flow.LF||
'        return l_name_value'||wwv_flow.LF||
'          || ''-'''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(169) := '      || l_first_name_pool('||wwv_flow.LF||
'               p_group || '':'' || to_char('||wwv_flow.LF||
'                 trunc(dbms_ra';
wwv_flow_imp.g_varchar2_table(170) := 'ndom.value(1, l_first_name_pool_size_by_group(l_group_no) + 1)),'||wwv_flow.LF||
'                 ''FM0000'''||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(171) := '      )'||wwv_flow.LF||
'             );'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      return l_name_value;'||wwv_flow.LF||
'    end pick_first_name;'||wwv_flow.LF||
''||wwv_flow.LF||
'    func';
wwv_flow_imp.g_varchar2_table(172) := 'tion pick_last_name ('||wwv_flow.LF||
'      p_group in varchar2'||wwv_flow.LF||
'    ) return varchar2 is'||wwv_flow.LF||
'      l_group_no pls_intege';
wwv_flow_imp.g_varchar2_table(173) := 'r;'||wwv_flow.LF||
'      l_name_position pls_integer;'||wwv_flow.LF||
'      l_name_code pls_integer;'||wwv_flow.LF||
'      l_name_value varchar2(100';
wwv_flow_imp.g_varchar2_table(174) := ');'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      l_group_no := name_group_index(p_group);'||wwv_flow.LF||
''||wwv_flow.LF||
'      if l_last_name_next(l_group_no) >';
wwv_flow_imp.g_varchar2_table(175) := ' l_last_name_pool_size_by_group(l_group_no) then'||wwv_flow.LF||
'        reset_name_order(l_last_name_order, l_last_';
wwv_flow_imp.g_varchar2_table(176) := 'name_pool_size_by_group, l_group_no);'||wwv_flow.LF||
'        l_last_name_next(l_group_no) := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(177) := '  l_name_position := l_last_name_next(l_group_no);'||wwv_flow.LF||
'      l_name_code := l_last_name_order((l_group_n';
wwv_flow_imp.g_varchar2_table(178) := 'o - 1) * l_max_name_pool_size + l_name_position);'||wwv_flow.LF||
'      l_last_name_next(l_group_no) := l_name_posit';
wwv_flow_imp.g_varchar2_table(179) := 'ion + 1;'||wwv_flow.LF||
'      l_last_name_pick_count := l_last_name_pick_count + 1;'||wwv_flow.LF||
'      l_name_value := l_last_na';
wwv_flow_imp.g_varchar2_table(180) := 'me_pool('||wwv_flow.LF||
'        p_group || '':'' || to_char(l_name_code, ''FM0000'')'||wwv_flow.LF||
'      );'||wwv_flow.LF||
''||wwv_flow.LF||
'      if mod(l_last_name';
wwv_flow_imp.g_varchar2_table(181) := '_pick_count, l_last_name_hyphen_interval) = 0 then'||wwv_flow.LF||
'        return l_name_value'||wwv_flow.LF||
'          || ''-'''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(182) := '      || l_last_name_pool('||wwv_flow.LF||
'               p_group || '':'' || to_char('||wwv_flow.LF||
'                 trunc(dbms_ran';
wwv_flow_imp.g_varchar2_table(183) := 'dom.value(1, l_last_name_pool_size_by_group(l_group_no) + 1)),'||wwv_flow.LF||
'                 ''FM0000'''||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(184) := '    )'||wwv_flow.LF||
'             );'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      return l_name_value;'||wwv_flow.LF||
'    end pick_last_name;'||wwv_flow.LF||
''||wwv_flow.LF||
'    functio';
wwv_flow_imp.g_varchar2_table(185) := 'n region_index ('||wwv_flow.LF||
'      p_country_no in pls_integer'||wwv_flow.LF||
'    ) return pls_integer is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      if p_';
wwv_flow_imp.g_varchar2_table(186) := 'country_no in (1, 2, 3, 4, 43, 44, 45) then'||wwv_flow.LF||
'        return 1;'||wwv_flow.LF||
'      elsif p_country_no in (5, 6, 7, ';
wwv_flow_imp.g_varchar2_table(187) := '8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25) then'||wwv_flow.LF||
'        return 2;'||wwv_flow.LF||
'      e';
wwv_flow_imp.g_varchar2_table(188) := 'lsif p_country_no in (26, 27, 28, 29, 30, 31, 32, 33, 34, 35) then'||wwv_flow.LF||
'        return 3;'||wwv_flow.LF||
'      elsif p_c';
wwv_flow_imp.g_varchar2_table(189) := 'ountry_no in (36, 37, 41, 42) then'||wwv_flow.LF||
'        return 4;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'        return 5;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(190) := 'end region_index;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function pick_region ('||wwv_flow.LF||
'      p_country_no in pls_integer'||wwv_flow.LF||
'    ) return varchar';
wwv_flow_imp.g_varchar2_table(191) := '2 is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      case region_index(p_country_no)'||wwv_flow.LF||
'        when 1 then return ''Americas'';'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(192) := 'when 2 then return ''Europe'';'||wwv_flow.LF||
'        when 3 then return ''Asia Pacific'';'||wwv_flow.LF||
'        when 4 then return ''';
wwv_flow_imp.g_varchar2_table(193) := 'Middle East'';'||wwv_flow.LF||
'        else return ''Africa'';'||wwv_flow.LF||
'      end case;'||wwv_flow.LF||
'    end pick_region;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function pick_';
wwv_flow_imp.g_varchar2_table(194) := 'timezone ('||wwv_flow.LF||
'      p_country_no in pls_integer,'||wwv_flow.LF||
'      p_city       in varchar2 default null '||wwv_flow.LF||
'    ) ret';
wwv_flow_imp.g_varchar2_table(195) := 'urn varchar2 is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      case p_country_no'||wwv_flow.LF||
'        when 1 then return case p_city '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(196) := '                 when ''New York'' then ''America/New_York'''||wwv_flow.LF||
'                           when ''Chicago''  ';
wwv_flow_imp.g_varchar2_table(197) := 'then ''America/Chicago'''||wwv_flow.LF||
'                           when ''Seattle''  then ''America/Los_Angeles'''||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(198) := '                    end;'||wwv_flow.LF||
'        when 2 then return case p_city '||wwv_flow.LF||
'                           when ''To';
wwv_flow_imp.g_varchar2_table(199) := 'ronto'' then ''America/Toronto'''||wwv_flow.LF||
'                           when ''Vancouver''  then ''America/Vancouver'''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(200) := '                           when ''Montreal''  then ''America/Montreal'''||wwv_flow.LF||
'                           end;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(201) := '        when 3 then return ''America/Mexico_City'';'||wwv_flow.LF||
'        when 4 then return ''America/Sao_Paulo'';'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(202) := '      when 5 then return ''Europe/London'';'||wwv_flow.LF||
'        when 6 then return ''Europe/Dublin'';'||wwv_flow.LF||
'        when 7';
wwv_flow_imp.g_varchar2_table(203) := ' then return ''Europe/Berlin'';'||wwv_flow.LF||
'        when 8 then return ''Europe/Paris'';'||wwv_flow.LF||
'        when 9 then return ';
wwv_flow_imp.g_varchar2_table(204) := '''Europe/Amsterdam'';'||wwv_flow.LF||
'        when 10 then return ''Europe/Brussels'';'||wwv_flow.LF||
'        when 11 then return ''Euro';
wwv_flow_imp.g_varchar2_table(205) := 'pe/Luxembourg'';'||wwv_flow.LF||
'        when 12 then return ''Europe/Zurich'';'||wwv_flow.LF||
'        when 13 then return ''Europe/Vie';
wwv_flow_imp.g_varchar2_table(206) := 'nna'';'||wwv_flow.LF||
'        when 14 then return ''Europe/Madrid'';'||wwv_flow.LF||
'        when 15 then return ''Europe/Lisbon'';'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(207) := '    when 16 then return ''Europe/Rome'';'||wwv_flow.LF||
'        when 17 then return ''Europe/Athens'';'||wwv_flow.LF||
'        when 18 ';
wwv_flow_imp.g_varchar2_table(208) := 'then return ''Europe/Warsaw'';'||wwv_flow.LF||
'        when 19 then return ''Europe/Prague'';'||wwv_flow.LF||
'        when 20 then retur';
wwv_flow_imp.g_varchar2_table(209) := 'n ''Europe/Bucharest'';'||wwv_flow.LF||
'        when 21 then return ''Europe/Budapest'';'||wwv_flow.LF||
'        when 22 then return ''Eu';
wwv_flow_imp.g_varchar2_table(210) := 'rope/Stockholm'';'||wwv_flow.LF||
'        when 23 then return ''Europe/Oslo'';'||wwv_flow.LF||
'        when 24 then return ''Europe/Cope';
wwv_flow_imp.g_varchar2_table(211) := 'nhagen'';'||wwv_flow.LF||
'        when 25 then return ''Europe/Helsinki'';'||wwv_flow.LF||
'        when 26 then return ''Asia/Kolkata'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(212) := '        when 27 then return ''Asia/Singapore'';'||wwv_flow.LF||
'        when 28 then return ''Australia/Sydney'';'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(213) := '  when 29 then return ''Pacific/Auckland'';'||wwv_flow.LF||
'        when 30 then return ''Asia/Tokyo'';'||wwv_flow.LF||
'        when 31 ';
wwv_flow_imp.g_varchar2_table(214) := 'then return ''Asia/Seoul'';'||wwv_flow.LF||
'        when 32 then return ''Asia/Shanghai'';'||wwv_flow.LF||
'        when 33 then return ''';
wwv_flow_imp.g_varchar2_table(215) := 'Asia/Hong_Kong'';'||wwv_flow.LF||
'        when 34 then return ''Asia/Manila'';'||wwv_flow.LF||
'        when 35 then return ''Asia/Kuala_';
wwv_flow_imp.g_varchar2_table(216) := 'Lumpur'';'||wwv_flow.LF||
'        when 36 then return ''Asia/Jerusalem'';'||wwv_flow.LF||
'        when 37 then return ''Asia/Dubai'';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(217) := '     when 38 then return ''Africa/Johannesburg'';'||wwv_flow.LF||
'        when 39 then return ''Africa/Lagos'';'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(218) := 'when 40 then return ''Africa/Nairobi'';'||wwv_flow.LF||
'        when 41 then return ''Africa/Cairo'';'||wwv_flow.LF||
'        when 42 th';
wwv_flow_imp.g_varchar2_table(219) := 'en return ''Europe/Istanbul'';'||wwv_flow.LF||
'        when 43 then return ''America/Santiago'';'||wwv_flow.LF||
'        when 44 then re';
wwv_flow_imp.g_varchar2_table(220) := 'turn ''America/Argentina/Buenos_Aires'';'||wwv_flow.LF||
'        when 45 then return ''America/Bogota'';'||wwv_flow.LF||
'        else re';
wwv_flow_imp.g_varchar2_table(221) := 'turn ''UTC'';'||wwv_flow.LF||
'      end case;'||wwv_flow.LF||
'    end pick_timezone;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function choose_manager_id ('||wwv_flow.LF||
'      p_country';
wwv_flow_imp.g_varchar2_table(222) := '_no in pls_integer'||wwv_flow.LF||
'    ) return eba_srch_txt_employees.manager_id%type is'||wwv_flow.LF||
'      l_same_country_count';
wwv_flow_imp.g_varchar2_table(223) := ' pls_integer := 0;'||wwv_flow.LF||
'      l_same_region_count pls_integer := 0;'||wwv_flow.LF||
'      l_region_no pls_integer;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(224) := 'l_pick_no pls_integer;'||wwv_flow.LF||
'      l_roll pls_integer := trunc(dbms_random.value(1, 101));'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(225) := ' if l_manager_count = 0 then'||wwv_flow.LF||
'        return null;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if l_manager_count_by_country';
wwv_flow_imp.g_varchar2_table(226) := '.exists(p_country_no) then'||wwv_flow.LF||
'        l_same_country_count := l_manager_count_by_country(p_country_no);';
wwv_flow_imp.g_varchar2_table(227) := ''||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      l_region_no := region_index(p_country_no);'||wwv_flow.LF||
'      if l_manager_count_by_region.';
wwv_flow_imp.g_varchar2_table(228) := 'exists(l_region_no) then'||wwv_flow.LF||
'        l_same_region_count := l_manager_count_by_region(l_region_no);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(229) := '  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if l_same_country_count > 0 and l_roll <= 80 then'||wwv_flow.LF||
'        l_pick_no := trunc(dbms_r';
wwv_flow_imp.g_varchar2_table(230) := 'andom.value(1, l_same_country_count + 1));'||wwv_flow.LF||
'        return l_manager_by_country('||wwv_flow.LF||
'          ''C:'' || to';
wwv_flow_imp.g_varchar2_table(231) := '_char(p_country_no) || '':'' || to_char(l_pick_no)'||wwv_flow.LF||
'        );'||wwv_flow.LF||
'      elsif l_same_region_count > 0 and ';
wwv_flow_imp.g_varchar2_table(232) := 'l_roll <= 95 then'||wwv_flow.LF||
'        l_pick_no := trunc(dbms_random.value(1, l_same_region_count + 1));'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(233) := ' return l_manager_by_region('||wwv_flow.LF||
'          ''R:'' || to_char(l_region_no) || '':'' || to_char(l_pick_no)'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(234) := '     );'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      l_pick_no := trunc(dbms_random.value(1, l_manager_count + 1));'||wwv_flow.LF||
'      re';
wwv_flow_imp.g_varchar2_table(235) := 'turn l_manager_id(l_pick_no);'||wwv_flow.LF||
'    end choose_manager_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function normalize_identifier ('||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(236) := 'p_value in varchar2'||wwv_flow.LF||
'    ) return varchar2 is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      return lower(regexp_replace(p_value, ''[';
wwv_flow_imp.g_varchar2_table(237) := '^[:alnum:]]'', ''''));'||wwv_flow.LF||
'    end normalize_identifier;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function pick_city ('||wwv_flow.LF||
'      p_country_no in pl';
wwv_flow_imp.g_varchar2_table(238) := 's_integer'||wwv_flow.LF||
'    ) return varchar2 is'||wwv_flow.LF||
'      l_city_no pls_integer := trunc(dbms_random.value(1, 4));'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(239) := '  begin'||wwv_flow.LF||
'      case p_country_no'||wwv_flow.LF||
'        when 1 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''New';
wwv_flow_imp.g_varchar2_table(240) := ' York''; when 2 then return ''Chicago''; else return ''Seattle''; end case;'||wwv_flow.LF||
'        when 2 then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(241) := ' case l_city_no when 1 then return ''Toronto''; when 2 then return ''Vancouver''; else return ''Montreal''';
wwv_flow_imp.g_varchar2_table(242) := '; end case;'||wwv_flow.LF||
'        when 3 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Mexico City''; when 2 th';
wwv_flow_imp.g_varchar2_table(243) := 'en return ''Monterrey''; else return ''Guadalajara''; end case;'||wwv_flow.LF||
'        when 4 then'||wwv_flow.LF||
'          case l_cit';
wwv_flow_imp.g_varchar2_table(244) := 'y_no when 1 then return ''Sao Paulo''; when 2 then return ''Rio de Janeiro''; else return ''Curitiba''; en';
wwv_flow_imp.g_varchar2_table(245) := 'd case;'||wwv_flow.LF||
'        when 5 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''London''; when 2 then return';
wwv_flow_imp.g_varchar2_table(246) := ' ''Manchester''; else return ''Edinburgh''; end case;'||wwv_flow.LF||
'        when 6 then'||wwv_flow.LF||
'          case l_city_no when ';
wwv_flow_imp.g_varchar2_table(247) := '1 then return ''Dublin''; when 2 then return ''Cork''; else return ''Galway''; end case;'||wwv_flow.LF||
'        when 7 th';
wwv_flow_imp.g_varchar2_table(248) := 'en'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Frankfurt''; when 2 then return ''Munich''; else return';
wwv_flow_imp.g_varchar2_table(249) := ' ''Berlin''; end case;'||wwv_flow.LF||
'        when 8 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Paris''; when 2';
wwv_flow_imp.g_varchar2_table(250) := ' then return ''Lyon''; else return ''Toulouse''; end case;'||wwv_flow.LF||
'        when 9 then'||wwv_flow.LF||
'          case l_city_no ';
wwv_flow_imp.g_varchar2_table(251) := 'when 1 then return ''Amsterdam''; when 2 then return ''Rotterdam''; else return ''Utrecht''; end case;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(252) := '     when 10 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Brussels''; when 2 then return ''Antwer';
wwv_flow_imp.g_varchar2_table(253) := 'p''; else return ''Ghent''; end case;'||wwv_flow.LF||
'        when 11 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ';
wwv_flow_imp.g_varchar2_table(254) := '''Luxembourg City''; when 2 then return ''Esch-sur-Alzette''; else return ''Differdange''; end case;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(255) := '   when 12 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Zurich''; when 2 then return ''Geneva''; e';
wwv_flow_imp.g_varchar2_table(256) := 'lse return ''Basel''; end case;'||wwv_flow.LF||
'        when 13 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Vien';
wwv_flow_imp.g_varchar2_table(257) := 'na''; when 2 then return ''Graz''; else return ''Salzburg''; end case;'||wwv_flow.LF||
'        when 14 then'||wwv_flow.LF||
'          cas';
wwv_flow_imp.g_varchar2_table(258) := 'e l_city_no when 1 then return ''Madrid''; when 2 then return ''Barcelona''; else return ''Valencia''; end';
wwv_flow_imp.g_varchar2_table(259) := ' case;'||wwv_flow.LF||
'        when 15 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Lisbon''; when 2 then return';
wwv_flow_imp.g_varchar2_table(260) := ' ''Porto''; else return ''Braga''; end case;'||wwv_flow.LF||
'        when 16 then'||wwv_flow.LF||
'          case l_city_no when 1 then r';
wwv_flow_imp.g_varchar2_table(261) := 'eturn ''Milan''; when 2 then return ''Rome''; else return ''Turin''; end case;'||wwv_flow.LF||
'        when 17 then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(262) := '    case l_city_no when 1 then return ''Athens''; when 2 then return ''Thessaloniki''; else return ''Patr';
wwv_flow_imp.g_varchar2_table(263) := 'as''; end case;'||wwv_flow.LF||
'        when 18 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Warsaw''; when 2 the';
wwv_flow_imp.g_varchar2_table(264) := 'n return ''Krakow''; else return ''Wroclaw''; end case;'||wwv_flow.LF||
'        when 19 then'||wwv_flow.LF||
'          case l_city_no wh';
wwv_flow_imp.g_varchar2_table(265) := 'en 1 then return ''Prague''; when 2 then return ''Brno''; else return ''Ostrava''; end case;'||wwv_flow.LF||
'        when ';
wwv_flow_imp.g_varchar2_table(266) := '20 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Bucharest''; when 2 then return ''Cluj-Napoca''; e';
wwv_flow_imp.g_varchar2_table(267) := 'lse return ''Timisoara''; end case;'||wwv_flow.LF||
'        when 21 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''';
wwv_flow_imp.g_varchar2_table(268) := 'Budapest''; when 2 then return ''Debrecen''; else return ''Szeged''; end case;'||wwv_flow.LF||
'        when 22 then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(269) := '     case l_city_no when 1 then return ''Stockholm''; when 2 then return ''Gothenburg''; else return ''Ma';
wwv_flow_imp.g_varchar2_table(270) := 'lmo''; end case;'||wwv_flow.LF||
'        when 23 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Oslo''; when 2 then';
wwv_flow_imp.g_varchar2_table(271) := ' return ''Bergen''; else return ''Trondheim''; end case;'||wwv_flow.LF||
'        when 24 then'||wwv_flow.LF||
'          case l_city_no w';
wwv_flow_imp.g_varchar2_table(272) := 'hen 1 then return ''Copenhagen''; when 2 then return ''Aarhus''; else return ''Odense''; end case;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(273) := ' when 25 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Helsinki''; when 2 then return ''Espoo''; el';
wwv_flow_imp.g_varchar2_table(274) := 'se return ''Tampere''; end case;'||wwv_flow.LF||
'        when 26 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Ben';
wwv_flow_imp.g_varchar2_table(275) := 'galuru''; when 2 then return ''Hyderabad''; else return ''Pune''; end case;'||wwv_flow.LF||
'        when 27 then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(276) := '  case l_city_no when 1 then return ''Singapore''; when 2 then return ''Jurong East''; else return ''Tamp';
wwv_flow_imp.g_varchar2_table(277) := 'ines''; end case;'||wwv_flow.LF||
'        when 28 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Sydney''; when 2 t';
wwv_flow_imp.g_varchar2_table(278) := 'hen return ''Melbourne''; else return ''Brisbane''; end case;'||wwv_flow.LF||
'        when 29 then'||wwv_flow.LF||
'          case l_city';
wwv_flow_imp.g_varchar2_table(279) := '_no when 1 then return ''Auckland''; when 2 then return ''Wellington''; else return ''Christchurch''; end ';
wwv_flow_imp.g_varchar2_table(280) := 'case;'||wwv_flow.LF||
'        when 30 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Tokyo''; when 2 then return ''';
wwv_flow_imp.g_varchar2_table(281) := 'Osaka''; else return ''Nagoya''; end case;'||wwv_flow.LF||
'        when 31 then'||wwv_flow.LF||
'          case l_city_no when 1 then re';
wwv_flow_imp.g_varchar2_table(282) := 'turn ''Seoul''; when 2 then return ''Busan''; else return ''Incheon''; end case;'||wwv_flow.LF||
'        when 32 then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(283) := '      case l_city_no when 1 then return ''Shanghai''; when 2 then return ''Beijing''; else return ''Shenz';
wwv_flow_imp.g_varchar2_table(284) := 'hen''; end case;'||wwv_flow.LF||
'        when 33 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Hong Kong''; when 2';
wwv_flow_imp.g_varchar2_table(285) := ' then return ''Kowloon''; else return ''Sha Tin''; end case;'||wwv_flow.LF||
'        when 34 then'||wwv_flow.LF||
'          case l_city_';
wwv_flow_imp.g_varchar2_table(286) := 'no when 1 then return ''Manila''; when 2 then return ''Cebu City''; else return ''Davao City''; end case;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(287) := '        when 35 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Kuala Lumpur''; when 2 then return ';
wwv_flow_imp.g_varchar2_table(288) := '''Penang''; else return ''Johor Bahru''; end case;'||wwv_flow.LF||
'        when 36 then'||wwv_flow.LF||
'          case l_city_no when 1 ';
wwv_flow_imp.g_varchar2_table(289) := 'then return ''Tel Aviv''; when 2 then return ''Jerusalem''; else return ''Haifa''; end case;'||wwv_flow.LF||
'        when ';
wwv_flow_imp.g_varchar2_table(290) := '37 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Dubai''; when 2 then return ''Abu Dhabi''; else re';
wwv_flow_imp.g_varchar2_table(291) := 'turn ''Sharjah''; end case;'||wwv_flow.LF||
'        when 38 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Johannes';
wwv_flow_imp.g_varchar2_table(292) := 'burg''; when 2 then return ''Cape Town''; else return ''Durban''; end case;'||wwv_flow.LF||
'        when 39 then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(293) := '  case l_city_no when 1 then return ''Lagos''; when 2 then return ''Abuja''; else return ''Port Harcourt''';
wwv_flow_imp.g_varchar2_table(294) := '; end case;'||wwv_flow.LF||
'        when 40 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Nairobi''; when 2 then ';
wwv_flow_imp.g_varchar2_table(295) := 'return ''Mombasa''; else return ''Kisumu''; end case;'||wwv_flow.LF||
'        when 41 then'||wwv_flow.LF||
'          case l_city_no when';
wwv_flow_imp.g_varchar2_table(296) := ' 1 then return ''Cairo''; when 2 then return ''Alexandria''; else return ''Giza''; end case;'||wwv_flow.LF||
'        when ';
wwv_flow_imp.g_varchar2_table(297) := '42 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Istanbul''; when 2 then return ''Ankara''; else re';
wwv_flow_imp.g_varchar2_table(298) := 'turn ''Izmir''; end case;'||wwv_flow.LF||
'        when 43 then'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Santiago'';';
wwv_flow_imp.g_varchar2_table(299) := ' when 2 then return ''Valparaiso''; else return ''Concepcion''; end case;'||wwv_flow.LF||
'        when 44 then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(300) := ' case l_city_no when 1 then return ''Buenos Aires''; when 2 then return ''Cordoba''; else return ''Rosari';
wwv_flow_imp.g_varchar2_table(301) := 'o''; end case;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'          case l_city_no when 1 then return ''Bogota''; when 2 then return ';
wwv_flow_imp.g_varchar2_table(302) := '''Medellin''; else return ''Cali''; end case;'||wwv_flow.LF||
'      end case;'||wwv_flow.LF||
'    end pick_city;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function pick_phon';
wwv_flow_imp.g_varchar2_table(303) := 'e_country_code ('||wwv_flow.LF||
'      p_country_no in pls_integer'||wwv_flow.LF||
'    ) return varchar2 is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      case p_c';
wwv_flow_imp.g_varchar2_table(304) := 'ountry_no'||wwv_flow.LF||
'        when 1 then return ''+1''; when 2 then return ''+1''; when 3 then return ''+52'';'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(305) := '  when 4 then return ''+55''; when 5 then return ''+44''; when 6 then return ''+353'';'||wwv_flow.LF||
'        when 7 then';
wwv_flow_imp.g_varchar2_table(306) := ' return ''+49''; when 8 then return ''+33''; when 9 then return ''+31'';'||wwv_flow.LF||
'        when 10 then return ''+32''';
wwv_flow_imp.g_varchar2_table(307) := '; when 11 then return ''+352''; when 12 then return ''+41'';'||wwv_flow.LF||
'        when 13 then return ''+43''; when 14 ';
wwv_flow_imp.g_varchar2_table(308) := 'then return ''+34''; when 15 then return ''+351'';'||wwv_flow.LF||
'        when 16 then return ''+39''; when 17 then retur';
wwv_flow_imp.g_varchar2_table(309) := 'n ''+30''; when 18 then return ''+48'';'||wwv_flow.LF||
'        when 19 then return ''+420''; when 20 then return ''+40''; w';
wwv_flow_imp.g_varchar2_table(310) := 'hen 21 then return ''+36'';'||wwv_flow.LF||
'        when 22 then return ''+46''; when 23 then return ''+47''; when 24 then';
wwv_flow_imp.g_varchar2_table(311) := ' return ''+45'';'||wwv_flow.LF||
'        when 25 then return ''+358''; when 26 then return ''+91''; when 27 then return ''+';
wwv_flow_imp.g_varchar2_table(312) := '65'';'||wwv_flow.LF||
'        when 28 then return ''+61''; when 29 then return ''+64''; when 30 then return ''+81'';'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(313) := '  when 31 then return ''+82''; when 32 then return ''+86''; when 33 then return ''+852'';'||wwv_flow.LF||
'        when 34 ';
wwv_flow_imp.g_varchar2_table(314) := 'then return ''+63''; when 35 then return ''+60''; when 36 then return ''+972'';'||wwv_flow.LF||
'        when 37 then retur';
wwv_flow_imp.g_varchar2_table(315) := 'n ''+971''; when 38 then return ''+27''; when 39 then return ''+234'';'||wwv_flow.LF||
'        when 40 then return ''+254'';';
wwv_flow_imp.g_varchar2_table(316) := ' when 41 then return ''+20''; when 42 then return ''+90'';'||wwv_flow.LF||
'        when 43 then return ''+56''; when 44 th';
wwv_flow_imp.g_varchar2_table(317) := 'en return ''+54''; else return ''+57'';'||wwv_flow.LF||
'      end case;'||wwv_flow.LF||
'    end pick_phone_country_code;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function c';
wwv_flow_imp.g_varchar2_table(318) := 'hoose_cost_center ('||wwv_flow.LF||
'      p_country_no in pls_integer'||wwv_flow.LF||
'    ) return pls_integer is'||wwv_flow.LF||
'      l_roll pls_i';
wwv_flow_imp.g_varchar2_table(319) := 'nteger := trunc(dbms_random.value(1, 101));'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      if p_country_no = 26 then'||wwv_flow.LF||
'        if l_r';
wwv_flow_imp.g_varchar2_table(320) := 'oll <= 35 then return 14;'||wwv_flow.LF||
'        elsif l_roll <= 55 then return 11;'||wwv_flow.LF||
'        elsif l_roll <= 68 then';
wwv_flow_imp.g_varchar2_table(321) := ' return 18;'||wwv_flow.LF||
'        elsif l_roll <= 78 then return 19;'||wwv_flow.LF||
'        elsif l_roll <= 86 then return 16;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(322) := '      elsif l_roll <= 92 then return 13;'||wwv_flow.LF||
'        elsif l_roll <= 96 then return 21;'||wwv_flow.LF||
'        elsif l_';
wwv_flow_imp.g_varchar2_table(323) := 'roll <= 98 then return 23;'||wwv_flow.LF||
'        else return 7;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'      elsif p_country_no in (3, 4,';
wwv_flow_imp.g_varchar2_table(324) := ' 43, 44, 45) then'||wwv_flow.LF||
'        if l_roll <= 25 then return 23;'||wwv_flow.LF||
'        elsif l_roll <= 43 then return 25;';
wwv_flow_imp.g_varchar2_table(325) := ''||wwv_flow.LF||
'        elsif l_roll <= 58 then return 20;'||wwv_flow.LF||
'        elsif l_roll <= 70 then return 26;'||wwv_flow.LF||
'        elsif';
wwv_flow_imp.g_varchar2_table(326) := ' l_roll <= 80 then return 27;'||wwv_flow.LF||
'        elsif l_roll <= 88 then return 3;'||wwv_flow.LF||
'        elsif l_roll <= 93 t';
wwv_flow_imp.g_varchar2_table(327) := 'hen return 11;'||wwv_flow.LF||
'        elsif l_roll <= 97 then return 14;'||wwv_flow.LF||
'        else return 7;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(328) := '   elsif p_country_no in (5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,';
wwv_flow_imp.g_varchar2_table(329) := ' 25) then'||wwv_flow.LF||
'        if l_roll <= 18 then return 20;'||wwv_flow.LF||
'        elsif l_roll <= 32 then return 14;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(330) := ' elsif l_roll <= 44 then return 23;'||wwv_flow.LF||
'        elsif l_roll <= 53 then return 3;'||wwv_flow.LF||
'        elsif l_roll <';
wwv_flow_imp.g_varchar2_table(331) := '= 62 then return 27;'||wwv_flow.LF||
'        elsif l_roll <= 70 then return 11;'||wwv_flow.LF||
'        elsif l_roll <= 78 then retu';
wwv_flow_imp.g_varchar2_table(332) := 'rn 13;'||wwv_flow.LF||
'        elsif l_roll <= 85 then return 26;'||wwv_flow.LF||
'        elsif l_roll <= 91 then return 15;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(333) := ' else return 9;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'        if l_roll <= 18 then return 20;'||wwv_flow.LF||
'        elsif l_r';
wwv_flow_imp.g_varchar2_table(334) := 'oll <= 32 then return 14;'||wwv_flow.LF||
'        elsif l_roll <= 45 then return 23;'||wwv_flow.LF||
'        elsif l_roll <= 56 then';
wwv_flow_imp.g_varchar2_table(335) := ' return 27;'||wwv_flow.LF||
'        elsif l_roll <= 65 then return 11;'||wwv_flow.LF||
'        elsif l_roll <= 73 then return 13;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(336) := '      elsif l_roll <= 81 then return 26;'||wwv_flow.LF||
'        elsif l_roll <= 88 then return 3;'||wwv_flow.LF||
'        elsif l_r';
wwv_flow_imp.g_varchar2_table(337) := 'oll <= 94 then return 7;'||wwv_flow.LF||
'        else return 22;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'    end choose_cost_c';
wwv_flow_imp.g_varchar2_table(338) := 'enter;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function pick_career_level ('||wwv_flow.LF||
'      p_cost_center_no in pls_integer'||wwv_flow.LF||
'    ) return varchar2';
wwv_flow_imp.g_varchar2_table(339) := ' is'||wwv_flow.LF||
'      l_roll pls_integer := trunc(dbms_random.value(1, 101));'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      if p_cost_center_n';
wwv_flow_imp.g_varchar2_table(340) := 'o = 1 then'||wwv_flow.LF||
'        return ''Executive'';'||wwv_flow.LF||
'      elsif p_cost_center_no in (2, 9, 10, 15, 17, 20, 21, 22';
wwv_flow_imp.g_varchar2_table(341) := ', 23, 25, 26) and l_roll <= 8 then'||wwv_flow.LF||
'        return ''Director'';'||wwv_flow.LF||
'      elsif l_roll <= 8 then'||wwv_flow.LF||
'        r';
wwv_flow_imp.g_varchar2_table(342) := 'eturn ''Associate'';'||wwv_flow.LF||
'      elsif l_roll <= 48 then'||wwv_flow.LF||
'        return ''Individual Contributor'';'||wwv_flow.LF||
'      elsi';
wwv_flow_imp.g_varchar2_table(343) := 'f l_roll <= 72 then'||wwv_flow.LF||
'        return ''Senior Individual Contributor'';'||wwv_flow.LF||
'      elsif l_roll <= 90 then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(344) := '      return ''Manager'';'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'        return ''Senior Manager'';'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'    end pick_caree';
wwv_flow_imp.g_varchar2_table(345) := 'r_level;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function pick_job_title ('||wwv_flow.LF||
'      p_cost_center_no in pls_integer'||wwv_flow.LF||
'    ) return varchar2 ';
wwv_flow_imp.g_varchar2_table(346) := 'is'||wwv_flow.LF||
'      l_choice pls_integer := trunc(dbms_random.value(1, 5));'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      case p_cost_center_';
wwv_flow_imp.g_varchar2_table(347) := 'no'||wwv_flow.LF||
'        when 1 then case l_choice when 1 then return ''Chief Operating Officer''; when 2 then retur';
wwv_flow_imp.g_varchar2_table(348) := 'n ''Chief Financial Officer''; when 3 then return ''Chief Technology Officer''; else return ''Chief Peopl';
wwv_flow_imp.g_varchar2_table(349) := 'e Officer''; end case;'||wwv_flow.LF||
'        when 2 then case l_choice when 1 then return ''Strategy Manager''; when ';
wwv_flow_imp.g_varchar2_table(350) := '2 then return ''Corporate Development Manager''; when 3 then return ''Strategic Planning Lead''; else re';
wwv_flow_imp.g_varchar2_table(351) := 'turn ''Senior Strategy Analyst''; end case;'||wwv_flow.LF||
'        when 3 then case l_choice when 1 then return ''Fina';
wwv_flow_imp.g_varchar2_table(352) := 'ncial Analyst''; when 2 then return ''Finance Manager''; when 3 then return ''Senior Accountant''; else r';
wwv_flow_imp.g_varchar2_table(353) := 'eturn ''FP&A Analyst''; end case;'||wwv_flow.LF||
'        when 4 then case l_choice when 1 then return ''Treasury Analy';
wwv_flow_imp.g_varchar2_table(354) := 'st''; when 2 then return ''Treasury Manager''; when 3 then return ''Cash Management Specialist''; else re';
wwv_flow_imp.g_varchar2_table(355) := 'turn ''Liquidity Risk Analyst''; end case;'||wwv_flow.LF||
'        when 5 then case l_choice when 1 then return ''Tax A';
wwv_flow_imp.g_varchar2_table(356) := 'nalyst''; when 2 then return ''Tax Manager''; when 3 then return ''Tax Compliance Specialist''; else retu';
wwv_flow_imp.g_varchar2_table(357) := 'rn ''International Tax Analyst''; end case;'||wwv_flow.LF||
'        when 6 then case l_choice when 1 then return ''Inte';
wwv_flow_imp.g_varchar2_table(358) := 'rnal Auditor''; when 2 then return ''Internal Audit Manager''; when 3 then return ''IT Audit Specialist''';
wwv_flow_imp.g_varchar2_table(359) := '; else return ''Audit Controls Analyst''; end case;'||wwv_flow.LF||
'        when 7 then case l_choice when 1 then retu';
wwv_flow_imp.g_varchar2_table(360) := 'rn ''HR Business Partner''; when 2 then return ''People Operations Manager''; when 3 then return ''Employ';
wwv_flow_imp.g_varchar2_table(361) := 'ee Relations Specialist''; else return ''HR Analyst''; end case;'||wwv_flow.LF||
'        when 8 then case l_choice when';
wwv_flow_imp.g_varchar2_table(362) := ' 1 then return ''Talent Acquisition Partner''; when 2 then return ''Technical Recruiter''; when 3 then r';
wwv_flow_imp.g_varchar2_table(363) := 'eturn ''Recruiting Coordinator''; else return ''Sourcing Lead''; end case;'||wwv_flow.LF||
'        when 9 then case l_ch';
wwv_flow_imp.g_varchar2_table(364) := 'oice when 1 then return ''Compliance Counsel''; when 2 then return ''Regulatory Affairs Manager''; when ';
wwv_flow_imp.g_varchar2_table(365) := '3 then return ''Legal Operations Specialist''; else return ''Ethics and Compliance Analyst''; end case;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(366) := '        when 10 then case l_choice when 1 then return ''Enterprise Risk Manager''; when 2 then return ';
wwv_flow_imp.g_varchar2_table(367) := '''Operational Risk Analyst''; when 3 then return ''Risk Controls Specialist''; else return ''Model Risk A';
wwv_flow_imp.g_varchar2_table(368) := 'nalyst''; end case;'||wwv_flow.LF||
'        when 11 then case l_choice when 1 then return ''IT Service Manager''; when ';
wwv_flow_imp.g_varchar2_table(369) := '2 then return ''Systems Administrator''; when 3 then return ''Network Engineer''; else return ''IT Busine';
wwv_flow_imp.g_varchar2_table(370) := 'ss Analyst''; end case;'||wwv_flow.LF||
'        when 12 then case l_choice when 1 then return ''Cybersecurity Analyst''';
wwv_flow_imp.g_varchar2_table(371) := '; when 2 then return ''Security Engineer''; when 3 then return ''Identity and Access Manager''; else ret';
wwv_flow_imp.g_varchar2_table(372) := 'urn ''Security Operations Lead''; end case;'||wwv_flow.LF||
'        when 13 then case l_choice when 1 then return ''Dat';
wwv_flow_imp.g_varchar2_table(373) := 'a Analyst''; when 2 then return ''Data Engineer''; when 3 then return ''BI Developer''; else return ''Anal';
wwv_flow_imp.g_varchar2_table(374) := 'ytics Manager''; end case;'||wwv_flow.LF||
'        when 14 then case l_choice when 1 then return ''Software Engineer'';';
wwv_flow_imp.g_varchar2_table(375) := ' when 2 then return ''Senior Software Engineer''; when 3 then return ''Full Stack Developer''; else retu';
wwv_flow_imp.g_varchar2_table(376) := 'rn ''Backend Engineer''; end case;'||wwv_flow.LF||
'        when 15 then case l_choice when 1 then return ''Product Mana';
wwv_flow_imp.g_varchar2_table(377) := 'ger''; when 2 then return ''Product Owner''; when 3 then return ''Product Operations Analyst''; else retu';
wwv_flow_imp.g_varchar2_table(378) := 'rn ''Product Strategy Manager''; end case;'||wwv_flow.LF||
'        when 16 then case l_choice when 1 then return ''QA E';
wwv_flow_imp.g_varchar2_table(379) := 'ngineer''; when 2 then return ''Test Automation Engineer''; when 3 then return ''Quality Assurance Analy';
wwv_flow_imp.g_varchar2_table(380) := 'st''; else return ''Release Quality Lead''; end case;'||wwv_flow.LF||
'        when 17 then case l_choice when 1 then re';
wwv_flow_imp.g_varchar2_table(381) := 'turn ''Enterprise Architect''; when 2 then return ''Solutions Architect''; when 3 then return ''Technical';
wwv_flow_imp.g_varchar2_table(382) := ' Architect''; else return ''Architecture Manager''; end case;'||wwv_flow.LF||
'        when 18 then case l_choice when 1';
wwv_flow_imp.g_varchar2_table(383) := ' then return ''Cloud Engineer''; when 2 then return ''DevOps Engineer''; when 3 then return ''Site Reliab';
wwv_flow_imp.g_varchar2_table(384) := 'ility Engineer''; else return ''Infrastructure Architect''; end case;'||wwv_flow.LF||
'        when 19 then case l_choic';
wwv_flow_imp.g_varchar2_table(385) := 'e when 1 then return ''Technical Support Engineer''; when 2 then return ''Customer Support Specialist'';';
wwv_flow_imp.g_varchar2_table(386) := ' when 3 then return ''Service Delivery Analyst''; else return ''Support Operations Manager''; end case;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(387) := '        when 20 then case l_choice when 1 then return ''Engagement Manager''; when 2 then return ''Impl';
wwv_flow_imp.g_varchar2_table(388) := 'ementation Consultant''; when 3 then return ''Solution Consultant''; else return ''Delivery Consultant'';';
wwv_flow_imp.g_varchar2_table(389) := ' end case;'||wwv_flow.LF||
'        when 21 then case l_choice when 1 then return ''Management Consultant''; when 2 the';
wwv_flow_imp.g_varchar2_table(390) := 'n return ''Technology Consultant''; when 3 then return ''Business Analyst''; else return ''Principal Cons';
wwv_flow_imp.g_varchar2_table(391) := 'ultant''; end case;'||wwv_flow.LF||
'        when 22 then case l_choice when 1 then return ''Program Manager''; when 2 t';
wwv_flow_imp.g_varchar2_table(392) := 'hen return ''Project Manager''; when 3 then return ''PMO Analyst''; else return ''Delivery Program Lead'';';
wwv_flow_imp.g_varchar2_table(393) := ' end case;'||wwv_flow.LF||
'        when 23 then case l_choice when 1 then return ''Account Executive''; when 2 then re';
wwv_flow_imp.g_varchar2_table(394) := 'turn ''Enterprise Sales Manager''; when 3 then return ''Regional Sales Director''; else return ''Sales Op';
wwv_flow_imp.g_varchar2_table(395) := 'erations Analyst''; end case;'||wwv_flow.LF||
'        when 24 then case l_choice when 1 then return ''Product Marketin';
wwv_flow_imp.g_varchar2_table(396) := 'g Manager''; when 2 then return ''Demand Generation Manager''; when 3 then return ''Marketing Analyst''; ';
wwv_flow_imp.g_varchar2_table(397) := 'else return ''Brand Manager''; end case;'||wwv_flow.LF||
'        when 25 then case l_choice when 1 then return ''Busine';
wwv_flow_imp.g_varchar2_table(398) := 'ss Development Manager''; when 2 then return ''Partnerships Manager''; when 3 then return ''Alliance Dir';
wwv_flow_imp.g_varchar2_table(399) := 'ector''; else return ''Growth Strategy Manager''; end case;'||wwv_flow.LF||
'        when 26 then case l_choice when 1 t';
wwv_flow_imp.g_varchar2_table(400) := 'hen return ''Customer Success Manager''; when 2 then return ''Client Success Director''; when 3 then ret';
wwv_flow_imp.g_varchar2_table(401) := 'urn ''Adoption Specialist''; else return ''Renewal Manager''; end case;'||wwv_flow.LF||
'        when 27 then case l_choi';
wwv_flow_imp.g_varchar2_table(402) := 'ce when 1 then return ''Business Operations Manager''; when 2 then return ''Operations Analyst''; when 3';
wwv_flow_imp.g_varchar2_table(403) := ' then return ''Service Operations Lead''; else return ''Workforce Planning Analyst''; end case;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(404) := 'when 28 then case l_choice when 1 then return ''Procurement Manager''; when 2 then return ''Vendor Mana';
wwv_flow_imp.g_varchar2_table(405) := 'gement Analyst''; when 3 then return ''Sourcing Specialist''; else return ''Contract Operations Analyst''';
wwv_flow_imp.g_varchar2_table(406) := '; end case;'||wwv_flow.LF||
'        when 29 then case l_choice when 1 then return ''Corporate Communications Manager''';
wwv_flow_imp.g_varchar2_table(407) := '; when 2 then return ''Internal Communications Specialist''; when 3 then return ''Public Relations Mana';
wwv_flow_imp.g_varchar2_table(408) := 'ger''; else return ''Communications Analyst''; end case;'||wwv_flow.LF||
'        else case l_choice when 1 then return ';
wwv_flow_imp.g_varchar2_table(409) := '''Workplace Services Manager''; when 2 then return ''Facilities Coordinator''; when 3 then return ''Offic';
wwv_flow_imp.g_varchar2_table(410) := 'e Operations Specialist''; else return ''Real Estate Analyst''; end case;'||wwv_flow.LF||
'      end case;'||wwv_flow.LF||
'    end pick_';
wwv_flow_imp.g_varchar2_table(411) := 'job_title;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function resolve_cost_center_id ('||wwv_flow.LF||
'      p_cost_center_no in pls_integer'||wwv_flow.LF||
'    ) return';
wwv_flow_imp.g_varchar2_table(412) := ' number is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      if l_cost_center_id.exists(p_cost_center_no) then'||wwv_flow.LF||
'        if l_cost_cente';
wwv_flow_imp.g_varchar2_table(413) := 'r_id(p_cost_center_no) is not null then'||wwv_flow.LF||
'          return l_cost_center_id(p_cost_center_no);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(414) := ' end if;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      for i in 1..g_cost_center_names.count loop'||wwv_flow.LF||
'        if l_cost_center_id';
wwv_flow_imp.g_varchar2_table(415) := '.exists(i) then'||wwv_flow.LF||
'          if l_cost_center_id(i) is not null then'||wwv_flow.LF||
'            return l_cost_center_i';
wwv_flow_imp.g_varchar2_table(416) := 'd(i);'||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'      return null;'||wwv_flow.LF||
'    end resolve_cost_cen';
wwv_flow_imp.g_varchar2_table(417) := 'ter_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    if p_num_rows is null or p_num_rows < 0 then'||wwv_flow.LF||
'      raise_application_error(-200';
wwv_flow_imp.g_varchar2_table(418) := '03, ''seed_employees requires a non-negative row count.'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_country_name(1) := ''Uni';
wwv_flow_imp.g_varchar2_table(419) := 'ted States''; l_country_code(1) := ''us''; l_name_group(1) := ''NA''; l_country_weight(1) := 500;'||wwv_flow.LF||
'    l_c';
wwv_flow_imp.g_varchar2_table(420) := 'ountry_name(2) := ''Canada''; l_country_code(2) := ''ca''; l_name_group(2) := ''NA''; l_country_weight(2) ';
wwv_flow_imp.g_varchar2_table(421) := ':= 45;'||wwv_flow.LF||
'    l_country_name(3) := ''Mexico''; l_country_code(3) := ''mx''; l_name_group(3) := ''LA''; l_coun';
wwv_flow_imp.g_varchar2_table(422) := 'try_weight(3) := 45;'||wwv_flow.LF||
'    l_country_name(4) := ''Brazil''; l_country_code(4) := ''br''; l_name_group(4) :';
wwv_flow_imp.g_varchar2_table(423) := '= ''LA''; l_country_weight(4) := 45;'||wwv_flow.LF||
'    l_country_name(5) := ''United Kingdom''; l_country_code(5) := ''';
wwv_flow_imp.g_varchar2_table(424) := 'gb''; l_name_group(5) := ''WE''; l_country_weight(5) := 35;'||wwv_flow.LF||
'    l_country_name(6) := ''Ireland''; l_count';
wwv_flow_imp.g_varchar2_table(425) := 'ry_code(6) := ''ir''; l_name_group(6) := ''WE''; l_country_weight(6) := 10;'||wwv_flow.LF||
'    l_country_name(7) := ''Ge';
wwv_flow_imp.g_varchar2_table(426) := 'rmany''; l_country_code(7) := ''de''; l_name_group(7) := ''WE''; l_country_weight(7) := 30;'||wwv_flow.LF||
'    l_country';
wwv_flow_imp.g_varchar2_table(427) := '_name(8) := ''France''; l_country_code(8) := ''fr''; l_name_group(8) := ''WE''; l_country_weight(8) := 25;';
wwv_flow_imp.g_varchar2_table(428) := ''||wwv_flow.LF||
'    l_country_name(9) := ''Netherlands''; l_country_code(9) := ''nl''; l_name_group(9) := ''WE''; l_count';
wwv_flow_imp.g_varchar2_table(429) := 'ry_weight(9) := 15;'||wwv_flow.LF||
'    l_country_name(10) := ''Belgium''; l_country_code(10) := ''be''; l_name_group(10';
wwv_flow_imp.g_varchar2_table(430) := ') := ''WE''; l_country_weight(10) := 10;'||wwv_flow.LF||
'    l_country_name(11) := ''Luxembourg''; l_country_code(11) :=';
wwv_flow_imp.g_varchar2_table(431) := ' ''lu''; l_name_group(11) := ''WE''; l_country_weight(11) := 5;'||wwv_flow.LF||
'    l_country_name(12) := ''Switzerland'';';
wwv_flow_imp.g_varchar2_table(432) := ' l_country_code(12) := ''ch''; l_name_group(12) := ''WE''; l_country_weight(12) := 10;'||wwv_flow.LF||
'    l_country_nam';
wwv_flow_imp.g_varchar2_table(433) := 'e(13) := ''Austria''; l_country_code(13) := ''at''; l_name_group(13) := ''WE''; l_country_weight(13) := 10';
wwv_flow_imp.g_varchar2_table(434) := ';'||wwv_flow.LF||
'    l_country_name(14) := ''Spain''; l_country_code(14) := ''es''; l_name_group(14) := ''WE''; l_country';
wwv_flow_imp.g_varchar2_table(435) := '_weight(14) := 15;'||wwv_flow.LF||
'    l_country_name(15) := ''Portugal''; l_country_code(15) := ''pt''; l_name_group(15';
wwv_flow_imp.g_varchar2_table(436) := ') := ''WE''; l_country_weight(15) := 8;'||wwv_flow.LF||
'    l_country_name(16) := ''Italy''; l_country_code(16) := ''it'';';
wwv_flow_imp.g_varchar2_table(437) := ' l_name_group(16) := ''WE''; l_country_weight(16) := 15;'||wwv_flow.LF||
'    l_country_name(17) := ''Greece''; l_country';
wwv_flow_imp.g_varchar2_table(438) := '_code(17) := ''gr''; l_name_group(17) := ''GR''; l_country_weight(17) := 8;'||wwv_flow.LF||
'    l_country_name(18) := ''P';
wwv_flow_imp.g_varchar2_table(439) := 'oland''; l_country_code(18) := ''pl''; l_name_group(18) := ''EE''; l_country_weight(18) := 15;'||wwv_flow.LF||
'    l_coun';
wwv_flow_imp.g_varchar2_table(440) := 'try_name(19) := ''Czechia''; l_country_code(19) := ''cz''; l_name_group(19) := ''EE''; l_country_weight(19';
wwv_flow_imp.g_varchar2_table(441) := ') := 10;'||wwv_flow.LF||
'    l_country_name(20) := ''Romania''; l_country_code(20) := ''ro''; l_name_group(20) := ''EE''; ';
wwv_flow_imp.g_varchar2_table(442) := 'l_country_weight(20) := 12;'||wwv_flow.LF||
'    l_country_name(21) := ''Hungary''; l_country_code(21) := ''hu''; l_name_';
wwv_flow_imp.g_varchar2_table(443) := 'group(21) := ''EE''; l_country_weight(21) := 8;'||wwv_flow.LF||
'    l_country_name(22) := ''Sweden''; l_country_code(22)';
wwv_flow_imp.g_varchar2_table(444) := ' := ''se''; l_name_group(22) := ''WE''; l_country_weight(22) := 10;'||wwv_flow.LF||
'    l_country_name(23) := ''Norway''; ';
wwv_flow_imp.g_varchar2_table(445) := 'l_country_code(23) := ''no''; l_name_group(23) := ''WE''; l_country_weight(23) := 8;'||wwv_flow.LF||
'    l_country_name(';
wwv_flow_imp.g_varchar2_table(446) := '24) := ''Denmark''; l_country_code(24) := ''dk''; l_name_group(24) := ''WE''; l_country_weight(24) := 8;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(447) := '   l_country_name(25) := ''Finland''; l_country_code(25) := ''fi''; l_name_group(25) := ''WE''; l_country_';
wwv_flow_imp.g_varchar2_table(448) := 'weight(25) := 6;'||wwv_flow.LF||
'    l_country_name(26) := ''India''; l_country_code(26) := ''in''; l_name_group(26) := ';
wwv_flow_imp.g_varchar2_table(449) := '''IN''; l_country_weight(26) := 140;'||wwv_flow.LF||
'    l_country_name(27) := ''Singapore''; l_country_code(27) := ''sg''';
wwv_flow_imp.g_varchar2_table(450) := '; l_name_group(27) := ''SEA''; l_country_weight(27) := 10;'||wwv_flow.LF||
'    l_country_name(28) := ''Australia''; l_co';
wwv_flow_imp.g_varchar2_table(451) := 'untry_code(28) := ''au''; l_name_group(28) := ''NA''; l_country_weight(28) := 15;'||wwv_flow.LF||
'    l_country_name(29)';
wwv_flow_imp.g_varchar2_table(452) := ' := ''New Zealand''; l_country_code(29) := ''nz''; l_name_group(29) := ''NA''; l_country_weight(29) := 6;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(453) := '    l_country_name(30) := ''Japan''; l_country_code(30) := ''jp''; l_name_group(30) := ''JP''; l_country_w';
wwv_flow_imp.g_varchar2_table(454) := 'eight(30) := 15;'||wwv_flow.LF||
'    l_country_name(31) := ''South Korea''; l_country_code(31) := ''kr''; l_name_group(3';
wwv_flow_imp.g_varchar2_table(455) := '1) := ''KR''; l_country_weight(31) := 10;'||wwv_flow.LF||
'    l_country_name(32) := ''China''; l_country_code(32) := ''cn';
wwv_flow_imp.g_varchar2_table(456) := '''; l_name_group(32) := ''CN''; l_country_weight(32) := 20;'||wwv_flow.LF||
'    l_country_name(33) := ''Hong Kong''; l_co';
wwv_flow_imp.g_varchar2_table(457) := 'untry_code(33) := ''hk''; l_name_group(33) := ''CN''; l_country_weight(33) := 5;'||wwv_flow.LF||
'    l_country_name(34) ';
wwv_flow_imp.g_varchar2_table(458) := ':= ''Philippines''; l_country_code(34) := ''ph''; l_name_group(34) := ''SEA''; l_country_weight(34) := 20;';
wwv_flow_imp.g_varchar2_table(459) := ''||wwv_flow.LF||
'    l_country_name(35) := ''Malaysia''; l_country_code(35) := ''my''; l_name_group(35) := ''SEA''; l_coun';
wwv_flow_imp.g_varchar2_table(460) := 'try_weight(35) := 10;'||wwv_flow.LF||
'    l_country_name(36) := ''Israel''; l_country_code(36) := ''il''; l_name_group(3';
wwv_flow_imp.g_varchar2_table(461) := '6) := ''IL''; l_country_weight(36) := 8;'||wwv_flow.LF||
'    l_country_name(37) := ''United Arab Emirates''; l_country_c';
wwv_flow_imp.g_varchar2_table(462) := 'ode(37) := ''ae''; l_name_group(37) := ''AR''; l_country_weight(37) := 8;'||wwv_flow.LF||
'    l_country_name(38) := ''Sou';
wwv_flow_imp.g_varchar2_table(463) := 'th Africa''; l_country_code(38) := ''za''; l_name_group(38) := ''AF''; l_country_weight(38) := 12;'||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(464) := 'country_name(39) := ''Nigeria''; l_country_code(39) := ''ng''; l_name_group(39) := ''AF''; l_country_weigh';
wwv_flow_imp.g_varchar2_table(465) := 't(39) := 10;'||wwv_flow.LF||
'    l_country_name(40) := ''Kenya''; l_country_code(40) := ''ke''; l_name_group(40) := ''AF''';
wwv_flow_imp.g_varchar2_table(466) := '; l_country_weight(40) := 5;'||wwv_flow.LF||
'    l_country_name(41) := ''Egypt''; l_country_code(41) := ''eg''; l_name_g';
wwv_flow_imp.g_varchar2_table(467) := 'roup(41) := ''AR''; l_country_weight(41) := 8;'||wwv_flow.LF||
'    l_country_name(42) := ''Turkey''; l_country_code(42) ';
wwv_flow_imp.g_varchar2_table(468) := ':= ''tr''; l_name_group(42) := ''TR''; l_country_weight(42) := 12;'||wwv_flow.LF||
'    l_country_name(43) := ''Chile''; l_';
wwv_flow_imp.g_varchar2_table(469) := 'country_code(43) := ''cl''; l_name_group(43) := ''LA''; l_country_weight(43) := 8;'||wwv_flow.LF||
'    l_country_name(44';
wwv_flow_imp.g_varchar2_table(470) := ') := ''Argentina''; l_country_code(44) := ''ar''; l_name_group(44) := ''LA''; l_country_weight(44) := 8;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(471) := '   l_country_name(45) := ''Colombia''; l_country_code(45) := ''co''; l_name_group(45) := ''LA''; l_country';
wwv_flow_imp.g_varchar2_table(472) := '_weight(45) := 8;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_pool(''NA:01'') := ''James''; l_first_name_pool(''NA:02'') := ''Olivia''';
wwv_flow_imp.g_varchar2_table(473) := '; l_first_name_pool(''NA:03'') := ''Ethan''; l_first_name_pool(''NA:04'') := ''Grace''; l_first_name_pool(''N';
wwv_flow_imp.g_varchar2_table(474) := 'A:05'') := ''Noah'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:06'') := ''Claire''; l_first_name_pool(''NA:07'') := ''Liam''; ';
wwv_flow_imp.g_varchar2_table(475) := 'l_first_name_pool(''NA:08'') := ''Avery''; l_first_name_pool(''NA:09'') := ''Mason''; l_first_name_pool(''NA:';
wwv_flow_imp.g_varchar2_table(476) := '10'') := ''Chloe'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:11'') := ''Lucas''; l_first_name_pool(''NA:12'') := ''Maya''; l_';
wwv_flow_imp.g_varchar2_table(477) := 'first_name_pool(''NA:13'') := ''Owen''; l_first_name_pool(''NA:14'') := ''Nora''; l_first_name_pool(''NA:15'')';
wwv_flow_imp.g_varchar2_table(478) := ' := ''Henry'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:16'') := ''Leah''; l_first_name_pool(''NA:17'') := ''Caleb''; l_firs';
wwv_flow_imp.g_varchar2_table(479) := 't_name_pool(''NA:18'') := ''Emma''; l_first_name_pool(''NA:19'') := ''Dylan''; l_first_name_pool(''NA:20'') :=';
wwv_flow_imp.g_varchar2_table(480) := ' ''Zoe'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:21'') := ''Benjamin''; l_first_name_pool(''NA:22'') := ''Harper''; l_firs';
wwv_flow_imp.g_varchar2_table(481) := 't_name_pool(''NA:23'') := ''Jackson''; l_first_name_pool(''NA:24'') := ''Madison''; l_first_name_pool(''NA:25';
wwv_flow_imp.g_varchar2_table(482) := ''') := ''Carter'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:26'') := ''Ella''; l_first_name_pool(''NA:27'') := ''Logan''; l_f';
wwv_flow_imp.g_varchar2_table(483) := 'irst_name_pool(''NA:28'') := ''Abigail''; l_first_name_pool(''NA:29'') := ''Sebastian''; l_first_name_pool(''';
wwv_flow_imp.g_varchar2_table(484) := 'NA:30'') := ''Lily'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:31'') := ''Wyatt''; l_first_name_pool(''NA:32'') := ''Hannah''';
wwv_flow_imp.g_varchar2_table(485) := '; l_first_name_pool(''NA:33'') := ''Jack''; l_first_name_pool(''NA:34'') := ''Scarlett''; l_first_name_pool(';
wwv_flow_imp.g_varchar2_table(486) := '''NA:35'') := ''Samuel'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:36'') := ''Victoria''; l_first_name_pool(''NA:37'') := ''G';
wwv_flow_imp.g_varchar2_table(487) := 'rayson''; l_first_name_pool(''NA:38'') := ''Natalie''; l_first_name_pool(''NA:39'') := ''Isaac''; l_first_nam';
wwv_flow_imp.g_varchar2_table(488) := 'e_pool(''NA:40'') := ''Savannah'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:41'') := ''Alexander''; l_first_name_pool(''NA:';
wwv_flow_imp.g_varchar2_table(489) := '42'') := ''Emily''; l_first_name_pool(''NA:43'') := ''Michael''; l_first_name_pool(''NA:44'') := ''Sophia''; l_';
wwv_flow_imp.g_varchar2_table(490) := 'first_name_pool(''NA:45'') := ''David'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:46'') := ''Charlotte''; l_first_name_poo';
wwv_flow_imp.g_varchar2_table(491) := 'l(''NA:47'') := ''Joseph''; l_first_name_pool(''NA:48'') := ''Amelia''; l_first_name_pool(''NA:49'') := ''John''';
wwv_flow_imp.g_varchar2_table(492) := '; l_first_name_pool(''NA:50'') := ''Evelyn'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:51'') := ''Christopher''; l_first_n';
wwv_flow_imp.g_varchar2_table(493) := 'ame_pool(''NA:52'') := ''Sofia''; l_first_name_pool(''NA:53'') := ''Andrew''; l_first_name_pool(''NA:54'') := ';
wwv_flow_imp.g_varchar2_table(494) := '''Camila''; l_first_name_pool(''NA:55'') := ''Daniel'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:56'') := ''Elizabeth''; l_f';
wwv_flow_imp.g_varchar2_table(495) := 'irst_name_pool(''NA:57'') := ''Matthew''; l_first_name_pool(''NA:58'') := ''Penelope''; l_first_name_pool(''N';
wwv_flow_imp.g_varchar2_table(496) := 'A:59'') := ''Anthony''; l_first_name_pool(''NA:60'') := ''Layla'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:61'') := ''Joshu';
wwv_flow_imp.g_varchar2_table(497) := 'a''; l_first_name_pool(''NA:62'') := ''Mila''; l_first_name_pool(''NA:63'') := ''Ryan''; l_first_name_pool(''N';
wwv_flow_imp.g_varchar2_table(498) := 'A:64'') := ''Aria''; l_first_name_pool(''NA:65'') := ''Nathan'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:66'') := ''Elijah''';
wwv_flow_imp.g_varchar2_table(499) := '; l_first_name_pool(''NA:67'') := ''Luna''; l_first_name_pool(''NA:68'') := ''Thomas''; l_first_name_pool(''N';
wwv_flow_imp.g_varchar2_table(500) := 'A:69'') := ''Ellie''; l_first_name_pool(''NA:70'') := ''Charles'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:71'') := ''Audre';
wwv_flow_imp.g_varchar2_table(501) := 'y''; l_first_name_pool(''NA:72'') := ''Christian''; l_first_name_pool(''NA:73'') := ''Brooklyn''; l_first_nam';
wwv_flow_imp.g_varchar2_table(502) := 'e_pool(''NA:74'') := ''Jonathan''; l_first_name_pool(''NA:75'') := ''Paisley'';'||wwv_flow.LF||
'    l_first_name_pool(''NA:76';
wwv_flow_imp.g_varchar2_table(503) := ''') := ''Aaron''; l_first_name_pool(''NA:77'') := ''Skylar''; l_first_name_pool(''NA:78'') := ''Josiah''; l_fir';
wwv_flow_imp.g_varchar2_table(504) := 'st_name_pool(''NA:79'') := ''Kennedy''; l_first_name_pool(''NA:80'') := ''Allison'';'||wwv_flow.LF||
'    l_last_name_pool(''N';
wwv_flow_imp.g_varchar2_table(505) := 'A:01'') := ''Bennett''; l_last_name_pool(''NA:02'') := ''Carter''; l_last_name_pool(''NA:03'') := ''Dawson''; l';
wwv_flow_imp.g_varchar2_table(506) := '_last_name_pool(''NA:04'') := ''Ellis''; l_last_name_pool(''NA:05'') := ''Foster'';'||wwv_flow.LF||
'    l_last_name_pool(''NA';
wwv_flow_imp.g_varchar2_table(507) := ':06'') := ''Grant''; l_last_name_pool(''NA:07'') := ''Hayes''; l_last_name_pool(''NA:08'') := ''Jordan''; l_las';
wwv_flow_imp.g_varchar2_table(508) := 't_name_pool(''NA:09'') := ''Keller''; l_last_name_pool(''NA:10'') := ''Lawson'';'||wwv_flow.LF||
'    l_last_name_pool(''NA:11';
wwv_flow_imp.g_varchar2_table(509) := ''') := ''Morgan''; l_last_name_pool(''NA:12'') := ''Parker''; l_last_name_pool(''NA:13'') := ''Quinn''; l_last_';
wwv_flow_imp.g_varchar2_table(510) := 'name_pool(''NA:14'') := ''Reed''; l_last_name_pool(''NA:15'') := ''Sullivan'';'||wwv_flow.LF||
'    l_last_name_pool(''NA:16'')';
wwv_flow_imp.g_varchar2_table(511) := ' := ''Turner''; l_last_name_pool(''NA:17'') := ''Walker''; l_last_name_pool(''NA:18'') := ''Warren''; l_last_n';
wwv_flow_imp.g_varchar2_table(512) := 'ame_pool(''NA:19'') := ''Whitaker''; l_last_name_pool(''NA:20'') := ''Monroe'';'||wwv_flow.LF||
'    l_last_name_pool(''NA:21''';
wwv_flow_imp.g_varchar2_table(513) := ') := ''Adams''; l_last_name_pool(''NA:22'') := ''Allen''; l_last_name_pool(''NA:23'') := ''Baker''; l_last_nam';
wwv_flow_imp.g_varchar2_table(514) := 'e_pool(''NA:24'') := ''Bell''; l_last_name_pool(''NA:25'') := ''Cooper'';'||wwv_flow.LF||
'    l_last_name_pool(''NA:26'') := ''';
wwv_flow_imp.g_varchar2_table(515) := 'Davis''; l_last_name_pool(''NA:27'') := ''Evans''; l_last_name_pool(''NA:28'') := ''Franklin''; l_last_name_p';
wwv_flow_imp.g_varchar2_table(516) := 'ool(''NA:29'') := ''Gray''; l_last_name_pool(''NA:30'') := ''Harris'';'||wwv_flow.LF||
'    l_last_name_pool(''NA:31'') := ''Jen';
wwv_flow_imp.g_varchar2_table(517) := 'kins''; l_last_name_pool(''NA:32'') := ''Kelly''; l_last_name_pool(''NA:33'') := ''Martin''; l_last_name_pool';
wwv_flow_imp.g_varchar2_table(518) := '(''NA:34'') := ''Murphy''; l_last_name_pool(''NA:35'') := ''Phillips'';'||wwv_flow.LF||
'    l_last_name_pool(''NA:36'') := ''Ru';
wwv_flow_imp.g_varchar2_table(519) := 'ssell''; l_last_name_pool(''NA:37'') := ''Stewart''; l_last_name_pool(''NA:38'') := ''Watson''; l_last_name_p';
wwv_flow_imp.g_varchar2_table(520) := 'ool(''NA:39'') := ''Campbell''; l_last_name_pool(''NA:40'') := ''Douglas'';'||wwv_flow.LF||
'    l_last_name_pool(''NA:41'') :=';
wwv_flow_imp.g_varchar2_table(521) := ' ''Anderson''; l_last_name_pool(''NA:42'') := ''Barnes''; l_last_name_pool(''NA:43'') := ''Bradley''; l_last_n';
wwv_flow_imp.g_varchar2_table(522) := 'ame_pool(''NA:44'') := ''Bryant''; l_last_name_pool(''NA:45'') := ''Butler'';'||wwv_flow.LF||
'    l_last_name_pool(''NA:46'') ';
wwv_flow_imp.g_varchar2_table(523) := ':= ''Chapman''; l_last_name_pool(''NA:47'') := ''Clark''; l_last_name_pool(''NA:48'') := ''Coleman''; l_last_n';
wwv_flow_imp.g_varchar2_table(524) := 'ame_pool(''NA:49'') := ''Collins''; l_last_name_pool(''NA:50'') := ''Crawford'';'||wwv_flow.LF||
'    l_last_name_pool(''NA:51';
wwv_flow_imp.g_varchar2_table(525) := ''') := ''Daniels''; l_last_name_pool(''NA:52'') := ''Davidson''; l_last_name_pool(''NA:53'') := ''Dean''; l_las';
wwv_flow_imp.g_varchar2_table(526) := 't_name_pool(''NA:54'') := ''Dunn''; l_last_name_pool(''NA:55'') := ''Fisher'';'||wwv_flow.LF||
'    l_last_name_pool(''NA:56'')';
wwv_flow_imp.g_varchar2_table(527) := ' := ''Fletcher''; l_last_name_pool(''NA:57'') := ''Fowler''; l_last_name_pool(''NA:58'') := ''Gardner''; l_las';
wwv_flow_imp.g_varchar2_table(528) := 't_name_pool(''NA:59'') := ''Gibson''; l_last_name_pool(''NA:60'') := ''Graham'';'||wwv_flow.LF||
'    l_last_name_pool(''NA:61';
wwv_flow_imp.g_varchar2_table(529) := ''') := ''Griffin''; l_last_name_pool(''NA:62'') := ''Hamilton''; l_last_name_pool(''NA:63'') := ''Harper''; l_l';
wwv_flow_imp.g_varchar2_table(530) := 'ast_name_pool(''NA:64'') := ''Hawkins''; l_last_name_pool(''NA:65'') := ''Henderson'';'||wwv_flow.LF||
'    l_last_name_pool(';
wwv_flow_imp.g_varchar2_table(531) := '''NA:66'') := ''Holland''; l_last_name_pool(''NA:67'') := ''Holmes''; l_last_name_pool(''NA:68'') := ''Howard'';';
wwv_flow_imp.g_varchar2_table(532) := ' l_last_name_pool(''NA:69'') := ''Ingram''; l_last_name_pool(''NA:70'') := ''Johnston'';'||wwv_flow.LF||
'    l_last_name_poo';
wwv_flow_imp.g_varchar2_table(533) := 'l(''NA:71'') := ''Kennedy''; l_last_name_pool(''NA:72'') := ''Lambert''; l_last_name_pool(''NA:73'') := ''Lane''';
wwv_flow_imp.g_varchar2_table(534) := '; l_last_name_pool(''NA:74'') := ''Lawrence''; l_last_name_pool(''NA:75'') := ''Lyons'';'||wwv_flow.LF||
'    l_last_name_poo';
wwv_flow_imp.g_varchar2_table(535) := 'l(''NA:76'') := ''Newman''; l_last_name_pool(''NA:77'') := ''Nichols''; l_last_name_pool(''NA:78'') := ''Norris';
wwv_flow_imp.g_varchar2_table(536) := '''; l_last_name_pool(''NA:79'') := ''Oliver''; l_last_name_pool(''NA:80'') := ''Patterson'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_nam';
wwv_flow_imp.g_varchar2_table(537) := 'e_pool(''LA:01'') := ''Mateo''; l_first_name_pool(''LA:02'') := ''Camila''; l_first_name_pool(''LA:03'') := ''S';
wwv_flow_imp.g_varchar2_table(538) := 'antiago''; l_first_name_pool(''LA:04'') := ''Valentina''; l_first_name_pool(''LA:05'') := ''Diego'';'||wwv_flow.LF||
'    l_fi';
wwv_flow_imp.g_varchar2_table(539) := 'rst_name_pool(''LA:06'') := ''Mariana''; l_first_name_pool(''LA:07'') := ''Rafael''; l_first_name_pool(''LA:0';
wwv_flow_imp.g_varchar2_table(540) := '8'') := ''Lucia''; l_first_name_pool(''LA:09'') := ''Thiago''; l_first_name_pool(''LA:10'') := ''Juliana'';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(541) := ' l_first_name_pool(''LA:11'') := ''Andres''; l_first_name_pool(''LA:12'') := ''Fernanda''; l_first_name_pool';
wwv_flow_imp.g_varchar2_table(542) := '(''LA:13'') := ''Gabriel''; l_first_name_pool(''LA:14'') := ''Isabela''; l_first_name_pool(''LA:15'') := ''Brun';
wwv_flow_imp.g_varchar2_table(543) := 'o'';'||wwv_flow.LF||
'    l_first_name_pool(''LA:16'') := ''Renata''; l_first_name_pool(''LA:17'') := ''Felipe''; l_first_name';
wwv_flow_imp.g_varchar2_table(544) := '_pool(''LA:18'') := ''Carolina''; l_first_name_pool(''LA:19'') := ''Tomas''; l_first_name_pool(''LA:20'') := ''';
wwv_flow_imp.g_varchar2_table(545) := 'Daniela'';'||wwv_flow.LF||
'    l_last_name_pool(''LA:01'') := ''Almeida''; l_last_name_pool(''LA:02'') := ''Andrade''; l_last';
wwv_flow_imp.g_varchar2_table(546) := '_name_pool(''LA:03'') := ''Barbosa''; l_last_name_pool(''LA:04'') := ''Cabrera''; l_last_name_pool(''LA:05'') ';
wwv_flow_imp.g_varchar2_table(547) := ':= ''Cardoso'';'||wwv_flow.LF||
'    l_last_name_pool(''LA:06'') := ''Castillo''; l_last_name_pool(''LA:07'') := ''Duarte''; l_';
wwv_flow_imp.g_varchar2_table(548) := 'last_name_pool(''LA:08'') := ''Ferreira''; l_last_name_pool(''LA:09'') := ''Herrera''; l_last_name_pool(''LA:';
wwv_flow_imp.g_varchar2_table(549) := '10'') := ''Mendoza'';'||wwv_flow.LF||
'    l_last_name_pool(''LA:11'') := ''Navarro''; l_last_name_pool(''LA:12'') := ''Oliveir';
wwv_flow_imp.g_varchar2_table(550) := 'a''; l_last_name_pool(''LA:13'') := ''Paredes''; l_last_name_pool(''LA:14'') := ''Pereira''; l_last_name_pool';
wwv_flow_imp.g_varchar2_table(551) := '(''LA:15'') := ''Rojas'';'||wwv_flow.LF||
'    l_last_name_pool(''LA:16'') := ''Salazar''; l_last_name_pool(''LA:17'') := ''Silv';
wwv_flow_imp.g_varchar2_table(552) := 'a''; l_last_name_pool(''LA:18'') := ''Torres''; l_last_name_pool(''LA:19'') := ''Vargas''; l_last_name_pool(''';
wwv_flow_imp.g_varchar2_table(553) := 'LA:20'') := ''Velasquez'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_pool(''WE:01'') := ''Oliver''; l_first_name_pool(''WE:02'') := ''';
wwv_flow_imp.g_varchar2_table(554) := 'Amelia''; l_first_name_pool(''WE:03'') := ''Theo''; l_first_name_pool(''WE:04'') := ''Sophie''; l_first_name_';
wwv_flow_imp.g_varchar2_table(555) := 'pool(''WE:05'') := ''Felix'';'||wwv_flow.LF||
'    l_first_name_pool(''WE:06'') := ''Elise''; l_first_name_pool(''WE:07'') := ''';
wwv_flow_imp.g_varchar2_table(556) := 'Hugo''; l_first_name_pool(''WE:08'') := ''Clara''; l_first_name_pool(''WE:09'') := ''Leon''; l_first_name_poo';
wwv_flow_imp.g_varchar2_table(557) := 'l(''WE:10'') := ''Eva'';'||wwv_flow.LF||
'    l_first_name_pool(''WE:11'') := ''Oscar''; l_first_name_pool(''WE:12'') := ''Freya';
wwv_flow_imp.g_varchar2_table(558) := '''; l_first_name_pool(''WE:13'') := ''Max''; l_first_name_pool(''WE:14'') := ''Anna''; l_first_name_pool(''WE:';
wwv_flow_imp.g_varchar2_table(559) := '15'') := ''Louis'';'||wwv_flow.LF||
'    l_first_name_pool(''WE:16'') := ''Ingrid''; l_first_name_pool(''WE:17'') := ''Julian'';';
wwv_flow_imp.g_varchar2_table(560) := ' l_first_name_pool(''WE:18'') := ''Elena''; l_first_name_pool(''WE:19'') := ''Arthur''; l_first_name_pool(''W';
wwv_flow_imp.g_varchar2_table(561) := 'E:20'') := ''Nina'';'||wwv_flow.LF||
'    l_last_name_pool(''WE:01'') := ''Andersen''; l_last_name_pool(''WE:02'') := ''Beaumon';
wwv_flow_imp.g_varchar2_table(562) := 't''; l_last_name_pool(''WE:03'') := ''Becker''; l_last_name_pool(''WE:04'') := ''Berg''; l_last_name_pool(''WE';
wwv_flow_imp.g_varchar2_table(563) := ':05'') := ''Fischer'';'||wwv_flow.LF||
'    l_last_name_pool(''WE:06'') := ''Laurent''; l_last_name_pool(''WE:07'') := ''Lindbe';
wwv_flow_imp.g_varchar2_table(564) := 'rg''; l_last_name_pool(''WE:08'') := ''Moreau''; l_last_name_pool(''WE:09'') := ''Muller''; l_last_name_pool(';
wwv_flow_imp.g_varchar2_table(565) := '''WE:10'') := ''Schneider'';'||wwv_flow.LF||
'    l_last_name_pool(''WE:11'') := ''Schmitt''; l_last_name_pool(''WE:12'') := ''S';
wwv_flow_imp.g_varchar2_table(566) := 'vensson''; l_last_name_pool(''WE:13'') := ''Taylor''; l_last_name_pool(''WE:14'') := ''Weber''; l_last_name_p';
wwv_flow_imp.g_varchar2_table(567) := 'ool(''WE:15'') := ''Williams'';'||wwv_flow.LF||
'    l_last_name_pool(''WE:16'') := ''Bauer''; l_last_name_pool(''WE:17'') := ''';
wwv_flow_imp.g_varchar2_table(568) := 'Dubois''; l_last_name_pool(''WE:18'') := ''Hansen''; l_last_name_pool(''WE:19'') := ''Keller''; l_last_name_p';
wwv_flow_imp.g_varchar2_table(569) := 'ool(''WE:20'') := ''Rossi'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_pool(''EE:01'') := ''Aleksandra''; l_first_name_pool(''EE:02'')';
wwv_flow_imp.g_varchar2_table(570) := ' := ''Mateusz''; l_first_name_pool(''EE:03'') := ''Jakub''; l_first_name_pool(''EE:04'') := ''Zofia''; l_first';
wwv_flow_imp.g_varchar2_table(571) := '_name_pool(''EE:05'') := ''Tomasz'';'||wwv_flow.LF||
'    l_first_name_pool(''EE:06'') := ''Katarina''; l_first_name_pool(''EE';
wwv_flow_imp.g_varchar2_table(572) := ':07'') := ''Mihai''; l_first_name_pool(''EE:08'') := ''Ioana''; l_first_name_pool(''EE:09'') := ''Andrei''; l_f';
wwv_flow_imp.g_varchar2_table(573) := 'irst_name_pool(''EE:10'') := ''Elena'';'||wwv_flow.LF||
'    l_first_name_pool(''EE:11'') := ''Viktor''; l_first_name_pool(''E';
wwv_flow_imp.g_varchar2_table(574) := 'E:12'') := ''Daria''; l_first_name_pool(''EE:13'') := ''Pavel''; l_first_name_pool(''EE:14'') := ''Lenka''; l_f';
wwv_flow_imp.g_varchar2_table(575) := 'irst_name_pool(''EE:15'') := ''Marek'';'||wwv_flow.LF||
'    l_first_name_pool(''EE:16'') := ''Aneta''; l_first_name_pool(''EE';
wwv_flow_imp.g_varchar2_table(576) := ':17'') := ''Bogdan''; l_first_name_pool(''EE:18'') := ''Sorin''; l_first_name_pool(''EE:19'') := ''Emilia''; l_';
wwv_flow_imp.g_varchar2_table(577) := 'first_name_pool(''EE:20'') := ''Oskar'';'||wwv_flow.LF||
'    l_last_name_pool(''EE:01'') := ''Kowalski''; l_last_name_pool(''';
wwv_flow_imp.g_varchar2_table(578) := 'EE:02'') := ''Nowak''; l_last_name_pool(''EE:03'') := ''Zielinski''; l_last_name_pool(''EE:04'') := ''Horvat'';';
wwv_flow_imp.g_varchar2_table(579) := ' l_last_name_pool(''EE:05'') := ''Ionescu'';'||wwv_flow.LF||
'    l_last_name_pool(''EE:06'') := ''Popescu''; l_last_name_poo';
wwv_flow_imp.g_varchar2_table(580) := 'l(''EE:07'') := ''Novak''; l_last_name_pool(''EE:08'') := ''Prochazka''; l_last_name_pool(''EE:09'') := ''Szabo';
wwv_flow_imp.g_varchar2_table(581) := '''; l_last_name_pool(''EE:10'') := ''Varga'';'||wwv_flow.LF||
'    l_last_name_pool(''EE:11'') := ''Marin''; l_last_name_pool(';
wwv_flow_imp.g_varchar2_table(582) := '''EE:12'') := ''Petrov''; l_last_name_pool(''EE:13'') := ''Dimitrov''; l_last_name_pool(''EE:14'') := ''Kaczmar';
wwv_flow_imp.g_varchar2_table(583) := 'ek''; l_last_name_pool(''EE:15'') := ''Wozniak'';'||wwv_flow.LF||
'    l_last_name_pool(''EE:16'') := ''Dvorak''; l_last_name_';
wwv_flow_imp.g_varchar2_table(584) := 'pool(''EE:17'') := ''Stanescu''; l_last_name_pool(''EE:18'') := ''Balan''; l_last_name_pool(''EE:19'') := ''Jan';
wwv_flow_imp.g_varchar2_table(585) := 'kovic''; l_last_name_pool(''EE:20'') := ''Dragomir'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_pool(''GR:01'') := ''Nikos''; l_first';
wwv_flow_imp.g_varchar2_table(586) := '_name_pool(''GR:02'') := ''Eleni''; l_first_name_pool(''GR:03'') := ''Giorgos''; l_first_name_pool(''GR:04'') ';
wwv_flow_imp.g_varchar2_table(587) := ':= ''Sofia''; l_first_name_pool(''GR:05'') := ''Dimitris'';'||wwv_flow.LF||
'    l_first_name_pool(''GR:06'') := ''Katerina''; ';
wwv_flow_imp.g_varchar2_table(588) := 'l_first_name_pool(''GR:07'') := ''Andreas''; l_first_name_pool(''GR:08'') := ''Maria''; l_first_name_pool(''G';
wwv_flow_imp.g_varchar2_table(589) := 'R:09'') := ''Panagiotis''; l_first_name_pool(''GR:10'') := ''Ioanna'';'||wwv_flow.LF||
'    l_first_name_pool(''GR:11'') := ''K';
wwv_flow_imp.g_varchar2_table(590) := 'ostas''; l_first_name_pool(''GR:12'') := ''Theodora''; l_first_name_pool(''GR:13'') := ''Vasilis''; l_first_n';
wwv_flow_imp.g_varchar2_table(591) := 'ame_pool(''GR:14'') := ''Despina''; l_first_name_pool(''GR:15'') := ''Alexandros'';'||wwv_flow.LF||
'    l_first_name_pool(''G';
wwv_flow_imp.g_varchar2_table(592) := 'R:16'') := ''Foteini''; l_first_name_pool(''GR:17'') := ''Stavros''; l_first_name_pool(''GR:18'') := ''Niki''; ';
wwv_flow_imp.g_varchar2_table(593) := 'l_first_name_pool(''GR:19'') := ''Michalis''; l_first_name_pool(''GR:20'') := ''Agapi'';'||wwv_flow.LF||
'    l_last_name_poo';
wwv_flow_imp.g_varchar2_table(594) := 'l(''GR:01'') := ''Papadopoulos''; l_last_name_pool(''GR:02'') := ''Georgiou''; l_last_name_pool(''GR:03'') := ';
wwv_flow_imp.g_varchar2_table(595) := '''Nikolaidis''; l_last_name_pool(''GR:04'') := ''Pappas''; l_last_name_pool(''GR:05'') := ''Dimitriadis'';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(596) := ' l_last_name_pool(''GR:06'') := ''Konstantinou''; l_last_name_pool(''GR:07'') := ''Vasilakis''; l_last_name_';
wwv_flow_imp.g_varchar2_table(597) := 'pool(''GR:08'') := ''Theodorou''; l_last_name_pool(''GR:09'') := ''Angelopoulos''; l_last_name_pool(''GR:10'')';
wwv_flow_imp.g_varchar2_table(598) := ' := ''Karalis'';'||wwv_flow.LF||
'    l_last_name_pool(''GR:11'') := ''Stavridis''; l_last_name_pool(''GR:12'') := ''Ioannidis';
wwv_flow_imp.g_varchar2_table(599) := '''; l_last_name_pool(''GR:13'') := ''Christou''; l_last_name_pool(''GR:14'') := ''Manolis''; l_last_name_pool';
wwv_flow_imp.g_varchar2_table(600) := '(''GR:15'') := ''Spyridis'';'||wwv_flow.LF||
'    l_last_name_pool(''GR:16'') := ''Kouris''; l_last_name_pool(''GR:17'') := ''Ro';
wwv_flow_imp.g_varchar2_table(601) := 'ussos''; l_last_name_pool(''GR:18'') := ''Zervas''; l_last_name_pool(''GR:19'') := ''Makris''; l_last_name_po';
wwv_flow_imp.g_varchar2_table(602) := 'ol(''GR:20'') := ''Economou'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_pool(''IN:01'') := ''Aarav''; l_first_name_pool(''IN:02'') :=';
wwv_flow_imp.g_varchar2_table(603) := ' ''Ananya''; l_first_name_pool(''IN:03'') := ''Vihaan''; l_first_name_pool(''IN:04'') := ''Isha''; l_first_nam';
wwv_flow_imp.g_varchar2_table(604) := 'e_pool(''IN:05'') := ''Rohan'';'||wwv_flow.LF||
'    l_first_name_pool(''IN:06'') := ''Kavya''; l_first_name_pool(''IN:07'') :=';
wwv_flow_imp.g_varchar2_table(605) := ' ''Aditya''; l_first_name_pool(''IN:08'') := ''Meera''; l_first_name_pool(''IN:09'') := ''Arjun''; l_first_nam';
wwv_flow_imp.g_varchar2_table(606) := 'e_pool(''IN:10'') := ''Nisha'';'||wwv_flow.LF||
'    l_first_name_pool(''IN:11'') := ''Ishaan''; l_first_name_pool(''IN:12'') :';
wwv_flow_imp.g_varchar2_table(607) := '= ''Priya''; l_first_name_pool(''IN:13'') := ''Kabir''; l_first_name_pool(''IN:14'') := ''Diya''; l_first_name';
wwv_flow_imp.g_varchar2_table(608) := '_pool(''IN:15'') := ''Rahul'';'||wwv_flow.LF||
'    l_first_name_pool(''IN:16'') := ''Aditi''; l_first_name_pool(''IN:17'') := ';
wwv_flow_imp.g_varchar2_table(609) := '''Dev''; l_first_name_pool(''IN:18'') := ''Neha''; l_first_name_pool(''IN:19'') := ''Kiran''; l_first_name_poo';
wwv_flow_imp.g_varchar2_table(610) := 'l(''IN:20'') := ''Saanvi'';'||wwv_flow.LF||
'    l_last_name_pool(''IN:01'') := ''Bhat''; l_last_name_pool(''IN:02'') := ''Chatt';
wwv_flow_imp.g_varchar2_table(611) := 'erjee''; l_last_name_pool(''IN:03'') := ''Deshmukh''; l_last_name_pool(''IN:04'') := ''Iyer''; l_last_name_po';
wwv_flow_imp.g_varchar2_table(612) := 'ol(''IN:05'') := ''Joshi'';'||wwv_flow.LF||
'    l_last_name_pool(''IN:06'') := ''Kapoor''; l_last_name_pool(''IN:07'') := ''Kul';
wwv_flow_imp.g_varchar2_table(613) := 'karni''; l_last_name_pool(''IN:08'') := ''Malhotra''; l_last_name_pool(''IN:09'') := ''Menon''; l_last_name_p';
wwv_flow_imp.g_varchar2_table(614) := 'ool(''IN:10'') := ''Nair'';'||wwv_flow.LF||
'    l_last_name_pool(''IN:11'') := ''Patel''; l_last_name_pool(''IN:12'') := ''Redd';
wwv_flow_imp.g_varchar2_table(615) := 'y''; l_last_name_pool(''IN:13'') := ''Rao''; l_last_name_pool(''IN:14'') := ''Shah''; l_last_name_pool(''IN:15';
wwv_flow_imp.g_varchar2_table(616) := ''') := ''Sharma'';'||wwv_flow.LF||
'    l_last_name_pool(''IN:16'') := ''Singh''; l_last_name_pool(''IN:17'') := ''Srinivasan'';';
wwv_flow_imp.g_varchar2_table(617) := ' l_last_name_pool(''IN:18'') := ''Verma''; l_last_name_pool(''IN:19'') := ''Banerjee''; l_last_name_pool(''IN';
wwv_flow_imp.g_varchar2_table(618) := ':20'') := ''Mehta'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_pool(''SEA:01'') := ''Wei''; l_first_name_pool(''SEA:02'') := ''Jia''; l';
wwv_flow_imp.g_varchar2_table(619) := '_first_name_pool(''SEA:03'') := ''Mei''; l_first_name_pool(''SEA:04'') := ''Hana''; l_first_name_pool(''SEA:0';
wwv_flow_imp.g_varchar2_table(620) := '5'') := ''Amir'';'||wwv_flow.LF||
'    l_first_name_pool(''SEA:06'') := ''Nur''; l_first_name_pool(''SEA:07'') := ''Siti''; l_fi';
wwv_flow_imp.g_varchar2_table(621) := 'rst_name_pool(''SEA:08'') := ''Arif''; l_first_name_pool(''SEA:09'') := ''Daniel''; l_first_name_pool(''SEA:1';
wwv_flow_imp.g_varchar2_table(622) := '0'') := ''Liyana'';'||wwv_flow.LF||
'    l_first_name_pool(''SEA:11'') := ''Farah''; l_first_name_pool(''SEA:12'') := ''Paolo'';';
wwv_flow_imp.g_varchar2_table(623) := ' l_first_name_pool(''SEA:13'') := ''Maria''; l_first_name_pool(''SEA:14'') := ''Carlo''; l_first_name_pool(''';
wwv_flow_imp.g_varchar2_table(624) := 'SEA:15'') := ''Andrea'';'||wwv_flow.LF||
'    l_first_name_pool(''SEA:16'') := ''Miguel''; l_first_name_pool(''SEA:17'') := ''A';
wwv_flow_imp.g_varchar2_table(625) := 'ngela''; l_first_name_pool(''SEA:18'') := ''Rizal''; l_first_name_pool(''SEA:19'') := ''Aisha''; l_first_name';
wwv_flow_imp.g_varchar2_table(626) := '_pool(''SEA:20'') := ''Kenji'';'||wwv_flow.LF||
'    l_last_name_pool(''SEA:01'') := ''Ahmad''; l_last_name_pool(''SEA:02'') :=';
wwv_flow_imp.g_varchar2_table(627) := ' ''Chen''; l_last_name_pool(''SEA:03'') := ''Dela Cruz''; l_last_name_pool(''SEA:04'') := ''Goh''; l_last_name';
wwv_flow_imp.g_varchar2_table(628) := '_pool(''SEA:05'') := ''Hassan'';'||wwv_flow.LF||
'    l_last_name_pool(''SEA:06'') := ''Lim''; l_last_name_pool(''SEA:07'') := ';
wwv_flow_imp.g_varchar2_table(629) := '''Mendoza''; l_last_name_pool(''SEA:08'') := ''Ong''; l_last_name_pool(''SEA:09'') := ''Reyes''; l_last_name_p';
wwv_flow_imp.g_varchar2_table(630) := 'ool(''SEA:10'') := ''Santos'';'||wwv_flow.LF||
'    l_last_name_pool(''SEA:11'') := ''Tan''; l_last_name_pool(''SEA:12'') := ''T';
wwv_flow_imp.g_varchar2_table(631) := 'eo''; l_last_name_pool(''SEA:13'') := ''Villanueva''; l_last_name_pool(''SEA:14'') := ''Wong''; l_last_name_p';
wwv_flow_imp.g_varchar2_table(632) := 'ool(''SEA:15'') := ''Yusof'';'||wwv_flow.LF||
'    l_last_name_pool(''SEA:16'') := ''Abdullah''; l_last_name_pool(''SEA:17'') :';
wwv_flow_imp.g_varchar2_table(633) := '= ''Chua''; l_last_name_pool(''SEA:18'') := ''Navarro''; l_last_name_pool(''SEA:19'') := ''Rahman''; l_last_na';
wwv_flow_imp.g_varchar2_table(634) := 'me_pool(''SEA:20'') := ''Koh'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_pool(''CN:01'') := ''Wei''; l_first_name_pool(''CN:02'') := ';
wwv_flow_imp.g_varchar2_table(635) := '''Li''; l_first_name_pool(''CN:03'') := ''Jie''; l_first_name_pool(''CN:04'') := ''Xinyi''; l_first_name_pool(';
wwv_flow_imp.g_varchar2_table(636) := '''CN:05'') := ''Yuchen'';'||wwv_flow.LF||
'    l_first_name_pool(''CN:06'') := ''Meilin''; l_first_name_pool(''CN:07'') := ''Hao';
wwv_flow_imp.g_varchar2_table(637) := '''; l_first_name_pool(''CN:08'') := ''Qian''; l_first_name_pool(''CN:09'') := ''Jun''; l_first_name_pool(''CN:';
wwv_flow_imp.g_varchar2_table(638) := '10'') := ''Lin'';'||wwv_flow.LF||
'    l_first_name_pool(''CN:11'') := ''Zihan''; l_first_name_pool(''CN:12'') := ''Ming''; l_fi';
wwv_flow_imp.g_varchar2_table(639) := 'rst_name_pool(''CN:13'') := ''Rui''; l_first_name_pool(''CN:14'') := ''Yan''; l_first_name_pool(''CN:15'') := ';
wwv_flow_imp.g_varchar2_table(640) := '''Chen'';'||wwv_flow.LF||
'    l_first_name_pool(''CN:16'') := ''Lili''; l_first_name_pool(''CN:17'') := ''Wen''; l_first_name_';
wwv_flow_imp.g_varchar2_table(641) := 'pool(''CN:18'') := ''Shuo''; l_first_name_pool(''CN:19'') := ''Ning''; l_first_name_pool(''CN:20'') := ''Yue'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(642) := '    l_last_name_pool(''CN:01'') := ''Chen''; l_last_name_pool(''CN:02'') := ''Wang''; l_last_name_pool(''CN:0';
wwv_flow_imp.g_varchar2_table(643) := '3'') := ''Li''; l_last_name_pool(''CN:04'') := ''Zhang''; l_last_name_pool(''CN:05'') := ''Liu'';'||wwv_flow.LF||
'    l_last_na';
wwv_flow_imp.g_varchar2_table(644) := 'me_pool(''CN:06'') := ''Huang''; l_last_name_pool(''CN:07'') := ''Zhao''; l_last_name_pool(''CN:08'') := ''Wu'';';
wwv_flow_imp.g_varchar2_table(645) := ' l_last_name_pool(''CN:09'') := ''Zhou''; l_last_name_pool(''CN:10'') := ''Xu'';'||wwv_flow.LF||
'    l_last_name_pool(''CN:11';
wwv_flow_imp.g_varchar2_table(646) := ''') := ''Sun''; l_last_name_pool(''CN:12'') := ''Hu''; l_last_name_pool(''CN:13'') := ''Guo''; l_last_name_pool';
wwv_flow_imp.g_varchar2_table(647) := '(''CN:14'') := ''He''; l_last_name_pool(''CN:15'') := ''Gao'';'||wwv_flow.LF||
'    l_last_name_pool(''CN:16'') := ''Lin''; l_las';
wwv_flow_imp.g_varchar2_table(648) := 't_name_pool(''CN:17'') := ''Luo''; l_last_name_pool(''CN:18'') := ''Tang''; l_last_name_pool(''CN:19'') := ''De';
wwv_flow_imp.g_varchar2_table(649) := 'ng''; l_last_name_pool(''CN:20'') := ''Shen'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_pool(''JP:01'') := ''Haruto''; l_first_name_';
wwv_flow_imp.g_varchar2_table(650) := 'pool(''JP:02'') := ''Yui''; l_first_name_pool(''JP:03'') := ''Ren''; l_first_name_pool(''JP:04'') := ''Aoi''; l_';
wwv_flow_imp.g_varchar2_table(651) := 'first_name_pool(''JP:05'') := ''Sota'';'||wwv_flow.LF||
'    l_first_name_pool(''JP:06'') := ''Hina''; l_first_name_pool(''JP:';
wwv_flow_imp.g_varchar2_table(652) := '07'') := ''Kaito''; l_first_name_pool(''JP:08'') := ''Mei''; l_first_name_pool(''JP:09'') := ''Daiki''; l_first';
wwv_flow_imp.g_varchar2_table(653) := '_name_pool(''JP:10'') := ''Sakura'';'||wwv_flow.LF||
'    l_first_name_pool(''JP:11'') := ''Riku''; l_first_name_pool(''JP:12''';
wwv_flow_imp.g_varchar2_table(654) := ') := ''Mio''; l_first_name_pool(''JP:13'') := ''Yuto''; l_first_name_pool(''JP:14'') := ''Rin''; l_first_name_';
wwv_flow_imp.g_varchar2_table(655) := 'pool(''JP:15'') := ''Takumi'';'||wwv_flow.LF||
'    l_first_name_pool(''JP:16'') := ''Akari''; l_first_name_pool(''JP:17'') := ';
wwv_flow_imp.g_varchar2_table(656) := '''Hiroto''; l_first_name_pool(''JP:18'') := ''Nanami''; l_first_name_pool(''JP:19'') := ''Kota''; l_first_name';
wwv_flow_imp.g_varchar2_table(657) := '_pool(''JP:20'') := ''Miku'';'||wwv_flow.LF||
'    l_last_name_pool(''JP:01'') := ''Sato''; l_last_name_pool(''JP:02'') := ''Suz';
wwv_flow_imp.g_varchar2_table(658) := 'uki''; l_last_name_pool(''JP:03'') := ''Takahashi''; l_last_name_pool(''JP:04'') := ''Tanaka''; l_last_name_p';
wwv_flow_imp.g_varchar2_table(659) := 'ool(''JP:05'') := ''Watanabe'';'||wwv_flow.LF||
'    l_last_name_pool(''JP:06'') := ''Ito''; l_last_name_pool(''JP:07'') := ''Ya';
wwv_flow_imp.g_varchar2_table(660) := 'mamoto''; l_last_name_pool(''JP:08'') := ''Nakamura''; l_last_name_pool(''JP:09'') := ''Kobayashi''; l_last_n';
wwv_flow_imp.g_varchar2_table(661) := 'ame_pool(''JP:10'') := ''Kato'';'||wwv_flow.LF||
'    l_last_name_pool(''JP:11'') := ''Yoshida''; l_last_name_pool(''JP:12'') :';
wwv_flow_imp.g_varchar2_table(662) := '= ''Yamada''; l_last_name_pool(''JP:13'') := ''Sasaki''; l_last_name_pool(''JP:14'') := ''Yamaguchi''; l_last_';
wwv_flow_imp.g_varchar2_table(663) := 'name_pool(''JP:15'') := ''Matsumoto'';'||wwv_flow.LF||
'    l_last_name_pool(''JP:16'') := ''Inoue''; l_last_name_pool(''JP:17';
wwv_flow_imp.g_varchar2_table(664) := ''') := ''Kimura''; l_last_name_pool(''JP:18'') := ''Hayashi''; l_last_name_pool(''JP:19'') := ''Shimizu''; l_la';
wwv_flow_imp.g_varchar2_table(665) := 'st_name_pool(''JP:20'') := ''Mori'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_pool(''KR:01'') := ''Minjun''; l_first_name_pool(''KR:';
wwv_flow_imp.g_varchar2_table(666) := '02'') := ''Seoyeon''; l_first_name_pool(''KR:03'') := ''Jihoon''; l_first_name_pool(''KR:04'') := ''Haeun''; l_';
wwv_flow_imp.g_varchar2_table(667) := 'first_name_pool(''KR:05'') := ''Doyun'';'||wwv_flow.LF||
'    l_first_name_pool(''KR:06'') := ''Soojin''; l_first_name_pool(''';
wwv_flow_imp.g_varchar2_table(668) := 'KR:07'') := ''Hyunwoo''; l_first_name_pool(''KR:08'') := ''Jimin''; l_first_name_pool(''KR:09'') := ''Taehyun''';
wwv_flow_imp.g_varchar2_table(669) := '; l_first_name_pool(''KR:10'') := ''Yejun'';'||wwv_flow.LF||
'    l_first_name_pool(''KR:11'') := ''Eunji''; l_first_name_poo';
wwv_flow_imp.g_varchar2_table(670) := 'l(''KR:12'') := ''Seungmin''; l_first_name_pool(''KR:13'') := ''Hyejin''; l_first_name_pool(''KR:14'') := ''Joo';
wwv_flow_imp.g_varchar2_table(671) := 'nho''; l_first_name_pool(''KR:15'') := ''Nari'';'||wwv_flow.LF||
'    l_first_name_pool(''KR:16'') := ''Donghyun''; l_first_na';
wwv_flow_imp.g_varchar2_table(672) := 'me_pool(''KR:17'') := ''Yuna''; l_first_name_pool(''KR:18'') := ''Sangho''; l_first_name_pool(''KR:19'') := ''B';
wwv_flow_imp.g_varchar2_table(673) := 'ora''; l_first_name_pool(''KR:20'') := ''Jinwoo'';'||wwv_flow.LF||
'    l_last_name_pool(''KR:01'') := ''Kim''; l_last_name_po';
wwv_flow_imp.g_varchar2_table(674) := 'ol(''KR:02'') := ''Lee''; l_last_name_pool(''KR:03'') := ''Park''; l_last_name_pool(''KR:04'') := ''Choi''; l_la';
wwv_flow_imp.g_varchar2_table(675) := 'st_name_pool(''KR:05'') := ''Jung'';'||wwv_flow.LF||
'    l_last_name_pool(''KR:06'') := ''Kang''; l_last_name_pool(''KR:07'') ';
wwv_flow_imp.g_varchar2_table(676) := ':= ''Cho''; l_last_name_pool(''KR:08'') := ''Yoon''; l_last_name_pool(''KR:09'') := ''Jang''; l_last_name_pool';
wwv_flow_imp.g_varchar2_table(677) := '(''KR:10'') := ''Lim'';'||wwv_flow.LF||
'    l_last_name_pool(''KR:11'') := ''Han''; l_last_name_pool(''KR:12'') := ''Shin''; l_l';
wwv_flow_imp.g_varchar2_table(678) := 'ast_name_pool(''KR:13'') := ''Seo''; l_last_name_pool(''KR:14'') := ''Kwon''; l_last_name_pool(''KR:15'') := ''';
wwv_flow_imp.g_varchar2_table(679) := 'Hwang'';'||wwv_flow.LF||
'    l_last_name_pool(''KR:16'') := ''Ahn''; l_last_name_pool(''KR:17'') := ''Song''; l_last_name_poo';
wwv_flow_imp.g_varchar2_table(680) := 'l(''KR:18'') := ''Jeon''; l_last_name_pool(''KR:19'') := ''Hong''; l_last_name_pool(''KR:20'') := ''Moon'';'||wwv_flow.LF||
''||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(681) := ' l_first_name_pool(''IL:01'') := ''Noam''; l_first_name_pool(''IL:02'') := ''Yael''; l_first_name_pool(''IL:0';
wwv_flow_imp.g_varchar2_table(682) := '3'') := ''Eitan''; l_first_name_pool(''IL:04'') := ''Tamar''; l_first_name_pool(''IL:05'') := ''Lior'';'||wwv_flow.LF||
'    l_f';
wwv_flow_imp.g_varchar2_table(683) := 'irst_name_pool(''IL:06'') := ''Shira''; l_first_name_pool(''IL:07'') := ''Omer''; l_first_name_pool(''IL:08'')';
wwv_flow_imp.g_varchar2_table(684) := ' := ''Adi''; l_first_name_pool(''IL:09'') := ''Amit''; l_first_name_pool(''IL:10'') := ''Ronen'';'||wwv_flow.LF||
'    l_first_';
wwv_flow_imp.g_varchar2_table(685) := 'name_pool(''IL:11'') := ''Maya''; l_first_name_pool(''IL:12'') := ''Gal''; l_first_name_pool(''IL:13'') := ''Ta';
wwv_flow_imp.g_varchar2_table(686) := 'lia''; l_first_name_pool(''IL:14'') := ''Erez''; l_first_name_pool(''IL:15'') := ''Neta'';'||wwv_flow.LF||
'    l_first_name_p';
wwv_flow_imp.g_varchar2_table(687) := 'ool(''IL:16'') := ''Itai''; l_first_name_pool(''IL:17'') := ''Dana''; l_first_name_pool(''IL:18'') := ''Yonatan';
wwv_flow_imp.g_varchar2_table(688) := '''; l_first_name_pool(''IL:19'') := ''Roni''; l_first_name_pool(''IL:20'') := ''Sivan'';'||wwv_flow.LF||
'    l_last_name_pool';
wwv_flow_imp.g_varchar2_table(689) := '(''IL:01'') := ''Cohen''; l_last_name_pool(''IL:02'') := ''Levi''; l_last_name_pool(''IL:03'') := ''Mizrahi''; l';
wwv_flow_imp.g_varchar2_table(690) := '_last_name_pool(''IL:04'') := ''Peretz''; l_last_name_pool(''IL:05'') := ''Shalev'';'||wwv_flow.LF||
'    l_last_name_pool(''I';
wwv_flow_imp.g_varchar2_table(691) := 'L:06'') := ''Ben Ami''; l_last_name_pool(''IL:07'') := ''Barak''; l_last_name_pool(''IL:08'') := ''Friedman''; ';
wwv_flow_imp.g_varchar2_table(692) := 'l_last_name_pool(''IL:09'') := ''Golan''; l_last_name_pool(''IL:10'') := ''Hadad'';'||wwv_flow.LF||
'    l_last_name_pool(''IL';
wwv_flow_imp.g_varchar2_table(693) := ':11'') := ''Kaplan''; l_last_name_pool(''IL:12'') := ''Klein''; l_last_name_pool(''IL:13'') := ''Meir''; l_last';
wwv_flow_imp.g_varchar2_table(694) := '_name_pool(''IL:14'') := ''Nissim''; l_last_name_pool(''IL:15'') := ''Ohayon'';'||wwv_flow.LF||
'    l_last_name_pool(''IL:16''';
wwv_flow_imp.g_varchar2_table(695) := ') := ''Rosen''; l_last_name_pool(''IL:17'') := ''Shamir''; l_last_name_pool(''IL:18'') := ''Tal''; l_last_name';
wwv_flow_imp.g_varchar2_table(696) := '_pool(''IL:19'') := ''Weiss''; l_last_name_pool(''IL:20'') := ''Zohar'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_pool(''AR:01'') := ';
wwv_flow_imp.g_varchar2_table(697) := '''Omar''; l_first_name_pool(''AR:02'') := ''Layla''; l_first_name_pool(''AR:03'') := ''Karim''; l_first_name_p';
wwv_flow_imp.g_varchar2_table(698) := 'ool(''AR:04'') := ''Salma''; l_first_name_pool(''AR:05'') := ''Hadi'';'||wwv_flow.LF||
'    l_first_name_pool(''AR:06'') := ''Ma';
wwv_flow_imp.g_varchar2_table(699) := 'riam''; l_first_name_pool(''AR:07'') := ''Tarek''; l_first_name_pool(''AR:08'') := ''Lina''; l_first_name_poo';
wwv_flow_imp.g_varchar2_table(700) := 'l(''AR:09'') := ''Samir''; l_first_name_pool(''AR:10'') := ''Dalia'';'||wwv_flow.LF||
'    l_first_name_pool(''AR:11'') := ''You';
wwv_flow_imp.g_varchar2_table(701) := 'ssef''; l_first_name_pool(''AR:12'') := ''Noor''; l_first_name_pool(''AR:13'') := ''Rami''; l_first_name_pool';
wwv_flow_imp.g_varchar2_table(702) := '(''AR:14'') := ''Hana''; l_first_name_pool(''AR:15'') := ''Fadi'';'||wwv_flow.LF||
'    l_first_name_pool(''AR:16'') := ''Amal'';';
wwv_flow_imp.g_varchar2_table(703) := ' l_first_name_pool(''AR:17'') := ''Nabil''; l_first_name_pool(''AR:18'') := ''Rana''; l_first_name_pool(''AR:';
wwv_flow_imp.g_varchar2_table(704) := '19'') := ''Ziad''; l_first_name_pool(''AR:20'') := ''Huda'';'||wwv_flow.LF||
'    l_last_name_pool(''AR:01'') := ''Abdallah''; l';
wwv_flow_imp.g_varchar2_table(705) := '_last_name_pool(''AR:02'') := ''Al Hassan''; l_last_name_pool(''AR:03'') := ''Al Mansouri''; l_last_name_poo';
wwv_flow_imp.g_varchar2_table(706) := 'l(''AR:04'') := ''Al Sayed''; l_last_name_pool(''AR:05'') := ''Darwish'';'||wwv_flow.LF||
'    l_last_name_pool(''AR:06'') := ''';
wwv_flow_imp.g_varchar2_table(707) := 'Farouk''; l_last_name_pool(''AR:07'') := ''Haddad''; l_last_name_pool(''AR:08'') := ''Hamdan''; l_last_name_p';
wwv_flow_imp.g_varchar2_table(708) := 'ool(''AR:09'') := ''Khalil''; l_last_name_pool(''AR:10'') := ''Mansour'';'||wwv_flow.LF||
'    l_last_name_pool(''AR:11'') := ''';
wwv_flow_imp.g_varchar2_table(709) := 'Nassar''; l_last_name_pool(''AR:12'') := ''Rahman''; l_last_name_pool(''AR:13'') := ''Saleh''; l_last_name_po';
wwv_flow_imp.g_varchar2_table(710) := 'ol(''AR:14'') := ''Sami''; l_last_name_pool(''AR:15'') := ''Sharif'';'||wwv_flow.LF||
'    l_last_name_pool(''AR:16'') := ''Soli';
wwv_flow_imp.g_varchar2_table(711) := 'man''; l_last_name_pool(''AR:17'') := ''Yasin''; l_last_name_pool(''AR:18'') := ''Zaki''; l_last_name_pool(''A';
wwv_flow_imp.g_varchar2_table(712) := 'R:19'') := ''Mahmoud''; l_last_name_pool(''AR:20'') := ''Fawzi'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_pool(''TR:01'') := ''Emir''';
wwv_flow_imp.g_varchar2_table(713) := '; l_first_name_pool(''TR:02'') := ''Zeynep''; l_first_name_pool(''TR:03'') := ''Kerem''; l_first_name_pool(''';
wwv_flow_imp.g_varchar2_table(714) := 'TR:04'') := ''Elif''; l_first_name_pool(''TR:05'') := ''Mert'';'||wwv_flow.LF||
'    l_first_name_pool(''TR:06'') := ''Selin''; ';
wwv_flow_imp.g_varchar2_table(715) := 'l_first_name_pool(''TR:07'') := ''Can''; l_first_name_pool(''TR:08'') := ''Derya''; l_first_name_pool(''TR:09';
wwv_flow_imp.g_varchar2_table(716) := ''') := ''Arda''; l_first_name_pool(''TR:10'') := ''Ece'';'||wwv_flow.LF||
'    l_first_name_pool(''TR:11'') := ''Berk''; l_first';
wwv_flow_imp.g_varchar2_table(717) := '_name_pool(''TR:12'') := ''Asli''; l_first_name_pool(''TR:13'') := ''Deniz''; l_first_name_pool(''TR:14'') := ';
wwv_flow_imp.g_varchar2_table(718) := '''Burak''; l_first_name_pool(''TR:15'') := ''Ceren'';'||wwv_flow.LF||
'    l_first_name_pool(''TR:16'') := ''Onur''; l_first_na';
wwv_flow_imp.g_varchar2_table(719) := 'me_pool(''TR:17'') := ''Melis''; l_first_name_pool(''TR:18'') := ''Tolga''; l_first_name_pool(''TR:19'') := ''E';
wwv_flow_imp.g_varchar2_table(720) := 'sra''; l_first_name_pool(''TR:20'') := ''Kaan'';'||wwv_flow.LF||
'    l_last_name_pool(''TR:01'') := ''Yilmaz''; l_last_name_p';
wwv_flow_imp.g_varchar2_table(721) := 'ool(''TR:02'') := ''Kaya''; l_last_name_pool(''TR:03'') := ''Demir''; l_last_name_pool(''TR:04'') := ''Sahin''; ';
wwv_flow_imp.g_varchar2_table(722) := 'l_last_name_pool(''TR:05'') := ''Celik'';'||wwv_flow.LF||
'    l_last_name_pool(''TR:06'') := ''Aydin''; l_last_name_pool(''TR';
wwv_flow_imp.g_varchar2_table(723) := ':07'') := ''Arslan''; l_last_name_pool(''TR:08'') := ''Ozdemir''; l_last_name_pool(''TR:09'') := ''Koc''; l_las';
wwv_flow_imp.g_varchar2_table(724) := 't_name_pool(''TR:10'') := ''Kurt'';'||wwv_flow.LF||
'    l_last_name_pool(''TR:11'') := ''Aksoy''; l_last_name_pool(''TR:12'') ';
wwv_flow_imp.g_varchar2_table(725) := ':= ''Polat''; l_last_name_pool(''TR:13'') := ''Tas''; l_last_name_pool(''TR:14'') := ''Kaplan''; l_last_name_p';
wwv_flow_imp.g_varchar2_table(726) := 'ool(''TR:15'') := ''Erdem'';'||wwv_flow.LF||
'    l_last_name_pool(''TR:16'') := ''Guler''; l_last_name_pool(''TR:17'') := ''Tek';
wwv_flow_imp.g_varchar2_table(727) := 'in''; l_last_name_pool(''TR:18'') := ''Karaca''; l_last_name_pool(''TR:19'') := ''Bulut''; l_last_name_pool(''';
wwv_flow_imp.g_varchar2_table(728) := 'TR:20'') := ''Eren'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_pool(''AF:01'') := ''Thabo''; l_first_name_pool(''AF:02'') := ''Naledi';
wwv_flow_imp.g_varchar2_table(729) := '''; l_first_name_pool(''AF:03'') := ''Sipho''; l_first_name_pool(''AF:04'') := ''Lerato''; l_first_name_pool(';
wwv_flow_imp.g_varchar2_table(730) := '''AF:05'') := ''Ayanda'';'||wwv_flow.LF||
'    l_first_name_pool(''AF:06'') := ''Teboho''; l_first_name_pool(''AF:07'') := ''Chi';
wwv_flow_imp.g_varchar2_table(731) := 'nedu''; l_first_name_pool(''AF:08'') := ''Adaeze''; l_first_name_pool(''AF:09'') := ''Emeka''; l_first_name_p';
wwv_flow_imp.g_varchar2_table(732) := 'ool(''AF:10'') := ''Ifeoma'';'||wwv_flow.LF||
'    l_first_name_pool(''AF:11'') := ''Kofi''; l_first_name_pool(''AF:12'') := ''A';
wwv_flow_imp.g_varchar2_table(733) := 'ma''; l_first_name_pool(''AF:13'') := ''Kwame''; l_first_name_pool(''AF:14'') := ''Abena''; l_first_name_pool';
wwv_flow_imp.g_varchar2_table(734) := '(''AF:15'') := ''Amina'';'||wwv_flow.LF||
'    l_first_name_pool(''AF:16'') := ''Zuri''; l_first_name_pool(''AF:17'') := ''Kamau';
wwv_flow_imp.g_varchar2_table(735) := '''; l_first_name_pool(''AF:18'') := ''Wanjiku''; l_first_name_pool(''AF:19'') := ''Nia''; l_first_name_pool(''';
wwv_flow_imp.g_varchar2_table(736) := 'AF:20'') := ''Tendai'';'||wwv_flow.LF||
'    l_last_name_pool(''AF:01'') := ''Abara''; l_last_name_pool(''AF:02'') := ''Adeyemi';
wwv_flow_imp.g_varchar2_table(737) := '''; l_last_name_pool(''AF:03'') := ''Afolabi''; l_last_name_pool(''AF:04'') := ''Banda''; l_last_name_pool(''A';
wwv_flow_imp.g_varchar2_table(738) := 'F:05'') := ''Chukwu'';'||wwv_flow.LF||
'    l_last_name_pool(''AF:06'') := ''Dlamini''; l_last_name_pool(''AF:07'') := ''Eze''; ';
wwv_flow_imp.g_varchar2_table(739) := 'l_last_name_pool(''AF:08'') := ''Kamau''; l_last_name_pool(''AF:09'') := ''Kilonzo''; l_last_name_pool(''AF:1';
wwv_flow_imp.g_varchar2_table(740) := '0'') := ''Mensah'';'||wwv_flow.LF||
'    l_last_name_pool(''AF:11'') := ''Mokoena''; l_last_name_pool(''AF:12'') := ''Ndlovu''; ';
wwv_flow_imp.g_varchar2_table(741) := 'l_last_name_pool(''AF:13'') := ''Okafor''; l_last_name_pool(''AF:14'') := ''Otieno''; l_last_name_pool(''AF:1';
wwv_flow_imp.g_varchar2_table(742) := '5'') := ''Owusu'';'||wwv_flow.LF||
'    l_last_name_pool(''AF:16'') := ''Sibiya''; l_last_name_pool(''AF:17'') := ''Tadesse''; l';
wwv_flow_imp.g_varchar2_table(743) := '_last_name_pool(''AF:18'') := ''Wambui''; l_last_name_pool(''AF:19'') := ''Zulu''; l_last_name_pool(''AF:20'')';
wwv_flow_imp.g_varchar2_table(744) := ' := ''Nwosu'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- The original compact seed values remain above as fallback metadata.'||wwv_flow.LF||
'    -- The ';
wwv_flow_imp.g_varchar2_table(745) := 'active catalogs below replace compound-name construction with'||wwv_flow.LF||
'    -- standalone, country-appropriate';
wwv_flow_imp.g_varchar2_table(746) := ' names.'||wwv_flow.LF||
'    l_first_name_extension_pool(''NA:01'') := ''Anne''; l_first_name_extension_pool(''NA:02'') := ';
wwv_flow_imp.g_varchar2_table(747) := '''Marie''; l_first_name_extension_pool(''NA:03'') := ''Rose''; l_first_name_extension_pool(''NA:04'') := ''Ly';
wwv_flow_imp.g_varchar2_table(748) := 'nn''; l_first_name_extension_pool(''NA:05'') := ''Rae'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''NA:06'') := ''Mae';
wwv_flow_imp.g_varchar2_table(749) := '''; l_first_name_extension_pool(''NA:07'') := ''Jo''; l_first_name_extension_pool(''NA:08'') := ''Kate''; l_f';
wwv_flow_imp.g_varchar2_table(750) := 'irst_name_extension_pool(''NA:09'') := ''Jane''; l_first_name_extension_pool(''NA:10'') := ''Lee'';'||wwv_flow.LF||
'    l_fi';
wwv_flow_imp.g_varchar2_table(751) := 'rst_name_extension_pool(''NA:11'') := ''Brooke''; l_first_name_extension_pool(''NA:12'') := ''Paige''; l_fir';
wwv_flow_imp.g_varchar2_table(752) := 'st_name_extension_pool(''NA:13'') := ''Hope''; l_first_name_extension_pool(''NA:14'') := ''Skye''; l_first_n';
wwv_flow_imp.g_varchar2_table(753) := 'ame_extension_pool(''NA:15'') := ''Belle'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''NA:16'') := ''June''; l_first_';
wwv_flow_imp.g_varchar2_table(754) := 'name_extension_pool(''NA:17'') := ''Blair''; l_first_name_extension_pool(''NA:18'') := ''Riley''; l_first_na';
wwv_flow_imp.g_varchar2_table(755) := 'me_extension_pool(''NA:19'') := ''Taylor'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''NA:01'') := ''Anderson''; l_las';
wwv_flow_imp.g_varchar2_table(756) := 't_name_extension_pool(''NA:02'') := ''Brooks''; l_last_name_extension_pool(''NA:03'') := ''Collins''; l_last';
wwv_flow_imp.g_varchar2_table(757) := '_name_extension_pool(''NA:04'') := ''Edwards''; l_last_name_extension_pool(''NA:05'') := ''Franklin'';'||wwv_flow.LF||
'    l';
wwv_flow_imp.g_varchar2_table(758) := '_last_name_extension_pool(''NA:06'') := ''Harrison''; l_last_name_extension_pool(''NA:07'') := ''Johnson''; ';
wwv_flow_imp.g_varchar2_table(759) := 'l_last_name_extension_pool(''NA:08'') := ''Mitchell''; l_last_name_extension_pool(''NA:09'') := ''Nelson''; ';
wwv_flow_imp.g_varchar2_table(760) := 'l_last_name_extension_pool(''NA:10'') := ''Owens'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''NA:11'') := ''Peterson';
wwv_flow_imp.g_varchar2_table(761) := '''; l_last_name_extension_pool(''NA:12'') := ''Robinson''; l_last_name_extension_pool(''NA:13'') := ''Spence';
wwv_flow_imp.g_varchar2_table(762) := 'r''; l_last_name_extension_pool(''NA:14'') := ''Thompson''; l_last_name_extension_pool(''NA:15'') := ''Under';
wwv_flow_imp.g_varchar2_table(763) := 'wood'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''NA:16'') := ''Vaughn''; l_last_name_extension_pool(''NA:17'') := ''';
wwv_flow_imp.g_varchar2_table(764) := 'Wilson''; l_last_name_extension_pool(''NA:18'') := ''Young''; l_last_name_extension_pool(''NA:19'') := ''Zim';
wwv_flow_imp.g_varchar2_table(765) := 'merman'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_extension_pool(''LA:01'') := ''Maria''; l_first_name_extension_pool(''LA:02'') ';
wwv_flow_imp.g_varchar2_table(766) := ':= ''Jose''; l_first_name_extension_pool(''LA:03'') := ''Lucia''; l_first_name_extension_pool(''LA:04'') := ';
wwv_flow_imp.g_varchar2_table(767) := '''Elena''; l_first_name_extension_pool(''LA:05'') := ''Isabel'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''LA:06'') ';
wwv_flow_imp.g_varchar2_table(768) := ':= ''Sofia''; l_first_name_extension_pool(''LA:07'') := ''Rosa''; l_first_name_extension_pool(''LA:08'') := ';
wwv_flow_imp.g_varchar2_table(769) := '''Ana''; l_first_name_extension_pool(''LA:09'') := ''Carmen''; l_first_name_extension_pool(''LA:10'') := ''Pi';
wwv_flow_imp.g_varchar2_table(770) := 'lar'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''LA:11'') := ''Beatriz''; l_first_name_extension_pool(''LA:12'') :=';
wwv_flow_imp.g_varchar2_table(771) := ' ''Teresa''; l_first_name_extension_pool(''LA:13'') := ''Monica''; l_first_name_extension_pool(''LA:14'') :=';
wwv_flow_imp.g_varchar2_table(772) := ' ''Lorena''; l_first_name_extension_pool(''LA:15'') := ''Adriana'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''LA:16';
wwv_flow_imp.g_varchar2_table(773) := ''') := ''Alejandra''; l_first_name_extension_pool(''LA:17'') := ''Marisol''; l_first_name_extension_pool(''L';
wwv_flow_imp.g_varchar2_table(774) := 'A:18'') := ''Paola''; l_first_name_extension_pool(''LA:19'') := ''Catalina'';'||wwv_flow.LF||
'    l_last_name_extension_poo';
wwv_flow_imp.g_varchar2_table(775) := 'l(''LA:01'') := ''Garcia''; l_last_name_extension_pool(''LA:02'') := ''Gonzalez''; l_last_name_extension_poo';
wwv_flow_imp.g_varchar2_table(776) := 'l(''LA:03'') := ''Hernandez''; l_last_name_extension_pool(''LA:04'') := ''Jimenez''; l_last_name_extension_p';
wwv_flow_imp.g_varchar2_table(777) := 'ool(''LA:05'') := ''Lopez'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''LA:06'') := ''Martinez''; l_last_name_extensio';
wwv_flow_imp.g_varchar2_table(778) := 'n_pool(''LA:07'') := ''Morales''; l_last_name_extension_pool(''LA:08'') := ''Ortega''; l_last_name_extension';
wwv_flow_imp.g_varchar2_table(779) := '_pool(''LA:09'') := ''Ramirez''; l_last_name_extension_pool(''LA:10'') := ''Rivera'';'||wwv_flow.LF||
'    l_last_name_extens';
wwv_flow_imp.g_varchar2_table(780) := 'ion_pool(''LA:11'') := ''Rodriguez''; l_last_name_extension_pool(''LA:12'') := ''Romero''; l_last_name_exten';
wwv_flow_imp.g_varchar2_table(781) := 'sion_pool(''LA:13'') := ''Sanchez''; l_last_name_extension_pool(''LA:14'') := ''Santos''; l_last_name_extens';
wwv_flow_imp.g_varchar2_table(782) := 'ion_pool(''LA:15'') := ''Suarez'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''LA:16'') := ''Vega''; l_last_name_extens';
wwv_flow_imp.g_varchar2_table(783) := 'ion_pool(''LA:17'') := ''Villalobos''; l_last_name_extension_pool(''LA:18'') := ''Zamora''; l_last_name_exte';
wwv_flow_imp.g_varchar2_table(784) := 'nsion_pool(''LA:19'') := ''Navarro'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_extension_pool(''WE:01'') := ''Marie''; l_first_name';
wwv_flow_imp.g_varchar2_table(785) := '_extension_pool(''WE:02'') := ''Louise''; l_first_name_extension_pool(''WE:03'') := ''Anne''; l_first_name_e';
wwv_flow_imp.g_varchar2_table(786) := 'xtension_pool(''WE:04'') := ''Elise''; l_first_name_extension_pool(''WE:05'') := ''Sophie'';'||wwv_flow.LF||
'    l_first_nam';
wwv_flow_imp.g_varchar2_table(787) := 'e_extension_pool(''WE:06'') := ''Clara''; l_first_name_extension_pool(''WE:07'') := ''Lena''; l_first_name_e';
wwv_flow_imp.g_varchar2_table(788) := 'xtension_pool(''WE:08'') := ''Greta''; l_first_name_extension_pool(''WE:09'') := ''Heidi''; l_first_name_ext';
wwv_flow_imp.g_varchar2_table(789) := 'ension_pool(''WE:10'') := ''Lara'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''WE:11'') := ''Mara''; l_first_name_ext';
wwv_flow_imp.g_varchar2_table(790) := 'ension_pool(''WE:12'') := ''Anneliese''; l_first_name_extension_pool(''WE:13'') := ''Charlotte''; l_first_na';
wwv_flow_imp.g_varchar2_table(791) := 'me_extension_pool(''WE:14'') := ''Louisa''; l_first_name_extension_pool(''WE:15'') := ''Margot'';'||wwv_flow.LF||
'    l_firs';
wwv_flow_imp.g_varchar2_table(792) := 't_name_extension_pool(''WE:16'') := ''Matilda''; l_first_name_extension_pool(''WE:17'') := ''Theresa''; l_fi';
wwv_flow_imp.g_varchar2_table(793) := 'rst_name_extension_pool(''WE:18'') := ''Beatrice''; l_first_name_extension_pool(''WE:19'') := ''Helena'';'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(794) := '  l_last_name_extension_pool(''WE:01'') := ''Adler''; l_last_name_extension_pool(''WE:02'') := ''Baumann''; ';
wwv_flow_imp.g_varchar2_table(795) := 'l_last_name_extension_pool(''WE:03'') := ''Berger''; l_last_name_extension_pool(''WE:04'') := ''Braun''; l_l';
wwv_flow_imp.g_varchar2_table(796) := 'ast_name_extension_pool(''WE:05'') := ''Dietrich'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''WE:06'') := ''Engel''; ';
wwv_flow_imp.g_varchar2_table(797) := 'l_last_name_extension_pool(''WE:07'') := ''Hartmann''; l_last_name_extension_pool(''WE:08'') := ''Hoffmann''';
wwv_flow_imp.g_varchar2_table(798) := '; l_last_name_extension_pool(''WE:09'') := ''Jansen''; l_last_name_extension_pool(''WE:10'') := ''Kaiser'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(799) := '    l_last_name_extension_pool(''WE:11'') := ''Keller''; l_last_name_extension_pool(''WE:12'') := ''Kruger''';
wwv_flow_imp.g_varchar2_table(800) := '; l_last_name_extension_pool(''WE:13'') := ''Meyer''; l_last_name_extension_pool(''WE:14'') := ''Neumann''; ';
wwv_flow_imp.g_varchar2_table(801) := 'l_last_name_extension_pool(''WE:15'') := ''Richter'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''WE:16'') := ''Schulz';
wwv_flow_imp.g_varchar2_table(802) := '''; l_last_name_extension_pool(''WE:17'') := ''Wagner''; l_last_name_extension_pool(''WE:18'') := ''Zimmerma';
wwv_flow_imp.g_varchar2_table(803) := 'nn''; l_last_name_extension_pool(''WE:19'') := ''Fontaine'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_extension_pool(''EE:01'') :=';
wwv_flow_imp.g_varchar2_table(804) := ' ''Ania''; l_first_name_extension_pool(''EE:02'') := ''Kasia''; l_first_name_extension_pool(''EE:03'') := ''M';
wwv_flow_imp.g_varchar2_table(805) := 'arta''; l_first_name_extension_pool(''EE:04'') := ''Natalia''; l_first_name_extension_pool(''EE:05'') := ''D';
wwv_flow_imp.g_varchar2_table(806) := 'ominika'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''EE:06'') := ''Aleksy''; l_first_name_extension_pool(''EE:07'')';
wwv_flow_imp.g_varchar2_table(807) := ' := ''Piotr''; l_first_name_extension_pool(''EE:08'') := ''Michal''; l_first_name_extension_pool(''EE:09'') ';
wwv_flow_imp.g_varchar2_table(808) := ':= ''Lukas''; l_first_name_extension_pool(''EE:10'') := ''Petra'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''EE:11''';
wwv_flow_imp.g_varchar2_table(809) := ') := ''Klara''; l_first_name_extension_pool(''EE:12'') := ''Ivana''; l_first_name_extension_pool(''EE:13'') ';
wwv_flow_imp.g_varchar2_table(810) := ':= ''Hana''; l_first_name_extension_pool(''EE:14'') := ''Stefan''; l_first_name_extension_pool(''EE:15'') :=';
wwv_flow_imp.g_varchar2_table(811) := ' ''Milos'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''EE:16'') := ''Nikola''; l_first_name_extension_pool(''EE:17'')';
wwv_flow_imp.g_varchar2_table(812) := ' := ''Danilo''; l_first_name_extension_pool(''EE:18'') := ''Marina''; l_first_name_extension_pool(''EE:19'')';
wwv_flow_imp.g_varchar2_table(813) := ' := ''Tereza'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''EE:01'') := ''Adamczyk''; l_last_name_extension_pool(''EE:';
wwv_flow_imp.g_varchar2_table(814) := '02'') := ''Baran''; l_last_name_extension_pool(''EE:03'') := ''Czarnecki''; l_last_name_extension_pool(''EE:';
wwv_flow_imp.g_varchar2_table(815) := '04'') := ''Duda''; l_last_name_extension_pool(''EE:05'') := ''Grabowski'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''';
wwv_flow_imp.g_varchar2_table(816) := 'EE:06'') := ''Jablonski''; l_last_name_extension_pool(''EE:07'') := ''Kral''; l_last_name_extension_pool(''E';
wwv_flow_imp.g_varchar2_table(817) := 'E:08'') := ''Kucera''; l_last_name_extension_pool(''EE:09'') := ''Mazur''; l_last_name_extension_pool(''EE:1';
wwv_flow_imp.g_varchar2_table(818) := '0'') := ''Mihailov'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''EE:11'') := ''Rusu''; l_last_name_extension_pool(''EE';
wwv_flow_imp.g_varchar2_table(819) := ':12'') := ''Simic''; l_last_name_extension_pool(''EE:13'') := ''Stoyanov''; l_last_name_extension_pool(''EE:';
wwv_flow_imp.g_varchar2_table(820) := '14'') := ''Tomescu''; l_last_name_extension_pool(''EE:15'') := ''Urban'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''E';
wwv_flow_imp.g_varchar2_table(821) := 'E:16'') := ''Vacek''; l_last_name_extension_pool(''EE:17'') := ''Wrona''; l_last_name_extension_pool(''EE:18';
wwv_flow_imp.g_varchar2_table(822) := ''') := ''Yovanov''; l_last_name_extension_pool(''EE:19'') := ''Zoric'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_extension_pool(''G';
wwv_flow_imp.g_varchar2_table(823) := 'R:01'') := ''Alexia''; l_first_name_extension_pool(''GR:02'') := ''Anna''; l_first_name_extension_pool(''GR:';
wwv_flow_imp.g_varchar2_table(824) := '03'') := ''Christina''; l_first_name_extension_pool(''GR:04'') := ''Dimitra''; l_first_name_extension_pool(';
wwv_flow_imp.g_varchar2_table(825) := '''GR:05'') := ''Evangelia'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''GR:06'') := ''Fotis''; l_first_name_extension';
wwv_flow_imp.g_varchar2_table(826) := '_pool(''GR:07'') := ''Ioannis''; l_first_name_extension_pool(''GR:08'') := ''Konstantinos''; l_first_name_ex';
wwv_flow_imp.g_varchar2_table(827) := 'tension_pool(''GR:09'') := ''Leonidas''; l_first_name_extension_pool(''GR:10'') := ''Manos'';'||wwv_flow.LF||
'    l_first_na';
wwv_flow_imp.g_varchar2_table(828) := 'me_extension_pool(''GR:11'') := ''Marina''; l_first_name_extension_pool(''GR:12'') := ''Olga''; l_first_name';
wwv_flow_imp.g_varchar2_table(829) := '_extension_pool(''GR:13'') := ''Paraskevi''; l_first_name_extension_pool(''GR:14'') := ''Petros''; l_first_n';
wwv_flow_imp.g_varchar2_table(830) := 'ame_extension_pool(''GR:15'') := ''Spyridon'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''GR:16'') := ''Vasiliki''; l';
wwv_flow_imp.g_varchar2_table(831) := '_first_name_extension_pool(''GR:17'') := ''Yiannis''; l_first_name_extension_pool(''GR:18'') := ''Zoe''; l_f';
wwv_flow_imp.g_varchar2_table(832) := 'irst_name_extension_pool(''GR:19'') := ''Themis'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''GR:01'') := ''Alexiou'';';
wwv_flow_imp.g_varchar2_table(833) := ' l_last_name_extension_pool(''GR:02'') := ''Anastasiou''; l_last_name_extension_pool(''GR:03'') := ''Antono';
wwv_flow_imp.g_varchar2_table(834) := 'poulos''; l_last_name_extension_pool(''GR:04'') := ''Dimitropoulos''; l_last_name_extension_pool(''GR:05'')';
wwv_flow_imp.g_varchar2_table(835) := ' := ''Eleftheriou'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''GR:06'') := ''Fotiadis''; l_last_name_extension_pool';
wwv_flow_imp.g_varchar2_table(836) := '(''GR:07'') := ''Galanis''; l_last_name_extension_pool(''GR:08'') := ''Kallias''; l_last_name_extension_pool';
wwv_flow_imp.g_varchar2_table(837) := '(''GR:09'') := ''Karagiannis''; l_last_name_extension_pool(''GR:10'') := ''Kourtidis'';'||wwv_flow.LF||
'    l_last_name_exte';
wwv_flow_imp.g_varchar2_table(838) := 'nsion_pool(''GR:11'') := ''Mavridis''; l_last_name_extension_pool(''GR:12'') := ''Nikolaou''; l_last_name_ex';
wwv_flow_imp.g_varchar2_table(839) := 'tension_pool(''GR:13'') := ''Oikonomou''; l_last_name_extension_pool(''GR:14'') := ''Panagiotou''; l_last_na';
wwv_flow_imp.g_varchar2_table(840) := 'me_extension_pool(''GR:15'') := ''Raptis'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''GR:16'') := ''Sideris''; l_last';
wwv_flow_imp.g_varchar2_table(841) := '_name_extension_pool(''GR:17'') := ''Theodorakis''; l_last_name_extension_pool(''GR:18'') := ''Vrettos''; l_';
wwv_flow_imp.g_varchar2_table(842) := 'last_name_extension_pool(''GR:19'') := ''Xenakis'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_extension_pool(''IN:01'') := ''Anil'';';
wwv_flow_imp.g_varchar2_table(843) := ' l_first_name_extension_pool(''IN:02'') := ''Arnav''; l_first_name_extension_pool(''IN:03'') := ''Bhavna''; ';
wwv_flow_imp.g_varchar2_table(844) := 'l_first_name_extension_pool(''IN:04'') := ''Chaitanya''; l_first_name_extension_pool(''IN:05'') := ''Esha'';';
wwv_flow_imp.g_varchar2_table(845) := ''||wwv_flow.LF||
'    l_first_name_extension_pool(''IN:06'') := ''Gaurav''; l_first_name_extension_pool(''IN:07'') := ''Ishi';
wwv_flow_imp.g_varchar2_table(846) := 'ta''; l_first_name_extension_pool(''IN:08'') := ''Karan''; l_first_name_extension_pool(''IN:09'') := ''Laksh';
wwv_flow_imp.g_varchar2_table(847) := 'mi''; l_first_name_extension_pool(''IN:10'') := ''Manish'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''IN:11'') := ''';
wwv_flow_imp.g_varchar2_table(848) := 'Nandini''; l_first_name_extension_pool(''IN:12'') := ''Pooja''; l_first_name_extension_pool(''IN:13'') := ''';
wwv_flow_imp.g_varchar2_table(849) := 'Riya''; l_first_name_extension_pool(''IN:14'') := ''Sachin''; l_first_name_extension_pool(''IN:15'') := ''Sh';
wwv_flow_imp.g_varchar2_table(850) := 'reya'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''IN:16'') := ''Tanvi''; l_first_name_extension_pool(''IN:17'') := ';
wwv_flow_imp.g_varchar2_table(851) := '''Varun''; l_first_name_extension_pool(''IN:18'') := ''Vikram''; l_first_name_extension_pool(''IN:19'') := ''';
wwv_flow_imp.g_varchar2_table(852) := 'Yash'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''IN:01'') := ''Agarwal''; l_last_name_extension_pool(''IN:02'') := ';
wwv_flow_imp.g_varchar2_table(853) := '''Bansal''; l_last_name_extension_pool(''IN:03'') := ''Choudhary''; l_last_name_extension_pool(''IN:04'') :=';
wwv_flow_imp.g_varchar2_table(854) := ' ''Das''; l_last_name_extension_pool(''IN:05'') := ''Ghosh'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''IN:06'') := ''';
wwv_flow_imp.g_varchar2_table(855) := 'Gupta''; l_last_name_extension_pool(''IN:07'') := ''Jindal''; l_last_name_extension_pool(''IN:08'') := ''Kha';
wwv_flow_imp.g_varchar2_table(856) := 'nna''; l_last_name_extension_pool(''IN:09'') := ''Mishra''; l_last_name_extension_pool(''IN:10'') := ''Mukhe';
wwv_flow_imp.g_varchar2_table(857) := 'rjee'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''IN:11'') := ''Naidu''; l_last_name_extension_pool(''IN:12'') := ''P';
wwv_flow_imp.g_varchar2_table(858) := 'illai''; l_last_name_extension_pool(''IN:13'') := ''Prasad''; l_last_name_extension_pool(''IN:14'') := ''Set';
wwv_flow_imp.g_varchar2_table(859) := 'hi''; l_last_name_extension_pool(''IN:15'') := ''Thakur'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''IN:16'') := ''Tr';
wwv_flow_imp.g_varchar2_table(860) := 'ipathi''; l_last_name_extension_pool(''IN:17'') := ''Varma''; l_last_name_extension_pool(''IN:18'') := ''Yad';
wwv_flow_imp.g_varchar2_table(861) := 'av''; l_last_name_extension_pool(''IN:19'') := ''Zaveri'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_extension_pool(''SEA:01'') := ';
wwv_flow_imp.g_varchar2_table(862) := '''Adi''; l_first_name_extension_pool(''SEA:02'') := ''Budi''; l_first_name_extension_pool(''SEA:03'') := ''Ci';
wwv_flow_imp.g_varchar2_table(863) := 'tra''; l_first_name_extension_pool(''SEA:04'') := ''Dewi''; l_first_name_extension_pool(''SEA:05'') := ''Fai';
wwv_flow_imp.g_varchar2_table(864) := 'sal'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''SEA:06'') := ''Intan''; l_first_name_extension_pool(''SEA:07'') :=';
wwv_flow_imp.g_varchar2_table(865) := ' ''Joko''; l_first_name_extension_pool(''SEA:08'') := ''Putri''; l_first_name_extension_pool(''SEA:09'') := ';
wwv_flow_imp.g_varchar2_table(866) := '''Rani''; l_first_name_extension_pool(''SEA:10'') := ''Sari'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''SEA:11'') :';
wwv_flow_imp.g_varchar2_table(867) := '= ''Surya''; l_first_name_extension_pool(''SEA:12'') := ''Wira''; l_first_name_extension_pool(''SEA:13'') :=';
wwv_flow_imp.g_varchar2_table(868) := ' ''Yusuf''; l_first_name_extension_pool(''SEA:14'') := ''Lani''; l_first_name_extension_pool(''SEA:15'') := ';
wwv_flow_imp.g_varchar2_table(869) := '''Rina'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''SEA:16'') := ''Dimas''; l_first_name_extension_pool(''SEA:17'') ';
wwv_flow_imp.g_varchar2_table(870) := ':= ''Rizky''; l_first_name_extension_pool(''SEA:18'') := ''Taufik''; l_first_name_extension_pool(''SEA:19'')';
wwv_flow_imp.g_varchar2_table(871) := ' := ''Yani'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''SEA:01'') := ''Bakar''; l_last_name_extension_pool(''SEA:02''';
wwv_flow_imp.g_varchar2_table(872) := ') := ''Bautista''; l_last_name_extension_pool(''SEA:03'') := ''Cruz''; l_last_name_extension_pool(''SEA:04''';
wwv_flow_imp.g_varchar2_table(873) := ') := ''Fernandez''; l_last_name_extension_pool(''SEA:05'') := ''Flores'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''';
wwv_flow_imp.g_varchar2_table(874) := 'SEA:06'') := ''Garcia''; l_last_name_extension_pool(''SEA:07'') := ''Halim''; l_last_name_extension_pool(''S';
wwv_flow_imp.g_varchar2_table(875) := 'EA:08'') := ''Ibrahim''; l_last_name_extension_pool(''SEA:09'') := ''Ismail''; l_last_name_extension_pool(''';
wwv_flow_imp.g_varchar2_table(876) := 'SEA:10'') := ''Kwan'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''SEA:11'') := ''Lee''; l_last_name_extension_pool(''S';
wwv_flow_imp.g_varchar2_table(877) := 'EA:12'') := ''Liew''; l_last_name_extension_pool(''SEA:13'') := ''Malik''; l_last_name_extension_pool(''SEA:';
wwv_flow_imp.g_varchar2_table(878) := '14'') := ''Rahim''; l_last_name_extension_pool(''SEA:15'') := ''Singh'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''SE';
wwv_flow_imp.g_varchar2_table(879) := 'A:16'') := ''Syed''; l_last_name_extension_pool(''SEA:17'') := ''Wijaya''; l_last_name_extension_pool(''SEA:';
wwv_flow_imp.g_varchar2_table(880) := '18'') := ''Wong''; l_last_name_extension_pool(''SEA:19'') := ''Zain'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_extension_pool(''CN';
wwv_flow_imp.g_varchar2_table(881) := ':01'') := ''An''; l_first_name_extension_pool(''CN:02'') := ''Bo''; l_first_name_extension_pool(''CN:03'') :=';
wwv_flow_imp.g_varchar2_table(882) := ' ''Fang''; l_first_name_extension_pool(''CN:04'') := ''Hong''; l_first_name_extension_pool(''CN:05'') := ''Ji';
wwv_flow_imp.g_varchar2_table(883) := 'ng'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''CN:06'') := ''Lan''; l_first_name_extension_pool(''CN:07'') := ''Lei';
wwv_flow_imp.g_varchar2_table(884) := '''; l_first_name_extension_pool(''CN:08'') := ''Lian''; l_first_name_extension_pool(''CN:09'') := ''Min''; l_';
wwv_flow_imp.g_varchar2_table(885) := 'first_name_extension_pool(''CN:10'') := ''Ping'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''CN:11'') := ''Tao''; l_f';
wwv_flow_imp.g_varchar2_table(886) := 'irst_name_extension_pool(''CN:12'') := ''Tian''; l_first_name_extension_pool(''CN:13'') := ''Xin''; l_first_';
wwv_flow_imp.g_varchar2_table(887) := 'name_extension_pool(''CN:14'') := ''Xiu''; l_first_name_extension_pool(''CN:15'') := ''Yang'';'||wwv_flow.LF||
'    l_first_n';
wwv_flow_imp.g_varchar2_table(888) := 'ame_extension_pool(''CN:16'') := ''Yi''; l_first_name_extension_pool(''CN:17'') := ''Yao''; l_first_name_ext';
wwv_flow_imp.g_varchar2_table(889) := 'ension_pool(''CN:18'') := ''Zhen''; l_first_name_extension_pool(''CN:19'') := ''Zhu'';'||wwv_flow.LF||
'    l_last_name_exten';
wwv_flow_imp.g_varchar2_table(890) := 'sion_pool(''CN:01'') := ''Bai''; l_last_name_extension_pool(''CN:02'') := ''Cai''; l_last_name_extension_poo';
wwv_flow_imp.g_varchar2_table(891) := 'l(''CN:03'') := ''Cao''; l_last_name_extension_pool(''CN:04'') := ''Cui''; l_last_name_extension_pool(''CN:05';
wwv_flow_imp.g_varchar2_table(892) := ''') := ''Fan'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''CN:06'') := ''Fang''; l_last_name_extension_pool(''CN:07'') ';
wwv_flow_imp.g_varchar2_table(893) := ':= ''Feng''; l_last_name_extension_pool(''CN:08'') := ''Han''; l_last_name_extension_pool(''CN:09'') := ''Jia';
wwv_flow_imp.g_varchar2_table(894) := 'ng''; l_last_name_extension_pool(''CN:10'') := ''Ma'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''CN:11'') := ''Meng'';';
wwv_flow_imp.g_varchar2_table(895) := ' l_last_name_extension_pool(''CN:12'') := ''Qiao''; l_last_name_extension_pool(''CN:13'') := ''Qin''; l_last';
wwv_flow_imp.g_varchar2_table(896) := '_name_extension_pool(''CN:14'') := ''Tang''; l_last_name_extension_pool(''CN:15'') := ''Tian'';'||wwv_flow.LF||
'    l_last_n';
wwv_flow_imp.g_varchar2_table(897) := 'ame_extension_pool(''CN:16'') := ''Wei''; l_last_name_extension_pool(''CN:17'') := ''Xie''; l_last_name_exte';
wwv_flow_imp.g_varchar2_table(898) := 'nsion_pool(''CN:18'') := ''Yang''; l_last_name_extension_pool(''CN:19'') := ''Yu'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_extens';
wwv_flow_imp.g_varchar2_table(899) := 'ion_pool(''JP:01'') := ''Akira''; l_first_name_extension_pool(''JP:02'') := ''Ayaka''; l_first_name_extensio';
wwv_flow_imp.g_varchar2_table(900) := 'n_pool(''JP:03'') := ''Chihiro''; l_first_name_extension_pool(''JP:04'') := ''Emi''; l_first_name_extension_';
wwv_flow_imp.g_varchar2_table(901) := 'pool(''JP:05'') := ''Fumiko'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''JP:06'') := ''Kaori''; l_first_name_extensi';
wwv_flow_imp.g_varchar2_table(902) := 'on_pool(''JP:07'') := ''Kenji''; l_first_name_extension_pool(''JP:08'') := ''Makoto''; l_first_name_extensio';
wwv_flow_imp.g_varchar2_table(903) := 'n_pool(''JP:09'') := ''Naoki''; l_first_name_extension_pool(''JP:10'') := ''Natsuki'';'||wwv_flow.LF||
'    l_first_name_exte';
wwv_flow_imp.g_varchar2_table(904) := 'nsion_pool(''JP:11'') := ''Reika''; l_first_name_extension_pool(''JP:12'') := ''Shiori''; l_first_name_exten';
wwv_flow_imp.g_varchar2_table(905) := 'sion_pool(''JP:13'') := ''Shota''; l_first_name_extension_pool(''JP:14'') := ''Tomomi''; l_first_name_extens';
wwv_flow_imp.g_varchar2_table(906) := 'ion_pool(''JP:15'') := ''Yoko'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''JP:16'') := ''Yuki''; l_first_name_extens';
wwv_flow_imp.g_varchar2_table(907) := 'ion_pool(''JP:17'') := ''Yuna''; l_first_name_extension_pool(''JP:18'') := ''Masato''; l_first_name_extensio';
wwv_flow_imp.g_varchar2_table(908) := 'n_pool(''JP:19'') := ''Sayaka'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''JP:01'') := ''Abe''; l_last_name_extension';
wwv_flow_imp.g_varchar2_table(909) := '_pool(''JP:02'') := ''Fujii''; l_last_name_extension_pool(''JP:03'') := ''Fujita''; l_last_name_extension_po';
wwv_flow_imp.g_varchar2_table(910) := 'ol(''JP:04'') := ''Hasegawa''; l_last_name_extension_pool(''JP:05'') := ''Ishikawa'';'||wwv_flow.LF||
'    l_last_name_extens';
wwv_flow_imp.g_varchar2_table(911) := 'ion_pool(''JP:06'') := ''Kondo''; l_last_name_extension_pool(''JP:07'') := ''Maeda''; l_last_name_extension_';
wwv_flow_imp.g_varchar2_table(912) := 'pool(''JP:08'') := ''Maruyama''; l_last_name_extension_pool(''JP:09'') := ''Matsuda''; l_last_name_extension';
wwv_flow_imp.g_varchar2_table(913) := '_pool(''JP:10'') := ''Miyazaki'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''JP:11'') := ''Nishimura''; l_last_name_ex';
wwv_flow_imp.g_varchar2_table(914) := 'tension_pool(''JP:12'') := ''Ogawa''; l_last_name_extension_pool(''JP:13'') := ''Okada''; l_last_name_extens';
wwv_flow_imp.g_varchar2_table(915) := 'ion_pool(''JP:14'') := ''Shibata''; l_last_name_extension_pool(''JP:15'') := ''Takeda'';'||wwv_flow.LF||
'    l_last_name_ext';
wwv_flow_imp.g_varchar2_table(916) := 'ension_pool(''JP:16'') := ''Ueda''; l_last_name_extension_pool(''JP:17'') := ''Wada''; l_last_name_extension';
wwv_flow_imp.g_varchar2_table(917) := '_pool(''JP:18'') := ''Yokoyama''; l_last_name_extension_pool(''JP:19'') := ''Sakai'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_exte';
wwv_flow_imp.g_varchar2_table(918) := 'nsion_pool(''KR:01'') := ''Ara''; l_first_name_extension_pool(''KR:02'') := ''Daeun''; l_first_name_extensio';
wwv_flow_imp.g_varchar2_table(919) := 'n_pool(''KR:03'') := ''Eunchae''; l_first_name_extension_pool(''KR:04'') := ''Haejin''; l_first_name_extensi';
wwv_flow_imp.g_varchar2_table(920) := 'on_pool(''KR:05'') := ''Hyewon'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''KR:06'') := ''Jihye''; l_first_name_exte';
wwv_flow_imp.g_varchar2_table(921) := 'nsion_pool(''KR:07'') := ''Jisu''; l_first_name_extension_pool(''KR:08'') := ''Mirae''; l_first_name_extensi';
wwv_flow_imp.g_varchar2_table(922) := 'on_pool(''KR:09'') := ''Minseo''; l_first_name_extension_pool(''KR:10'') := ''Seunghyun'';'||wwv_flow.LF||
'    l_first_name_';
wwv_flow_imp.g_varchar2_table(923) := 'extension_pool(''KR:11'') := ''Soomin''; l_first_name_extension_pool(''KR:12'') := ''Taemin''; l_first_name_';
wwv_flow_imp.g_varchar2_table(924) := 'extension_pool(''KR:13'') := ''Woojin''; l_first_name_extension_pool(''KR:14'') := ''Yeeun''; l_first_name_e';
wwv_flow_imp.g_varchar2_table(925) := 'xtension_pool(''KR:15'') := ''Yeonwoo'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''KR:16'') := ''Youngjin''; l_first';
wwv_flow_imp.g_varchar2_table(926) := '_name_extension_pool(''KR:17'') := ''Yujin''; l_first_name_extension_pool(''KR:18'') := ''Eunseo''; l_first_';
wwv_flow_imp.g_varchar2_table(927) := 'name_extension_pool(''KR:19'') := ''Haneul'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''KR:01'') := ''Bae''; l_last_n';
wwv_flow_imp.g_varchar2_table(928) := 'ame_extension_pool(''KR:02'') := ''Baek''; l_last_name_extension_pool(''KR:03'') := ''Byun''; l_last_name_ex';
wwv_flow_imp.g_varchar2_table(929) := 'tension_pool(''KR:04'') := ''Chae''; l_last_name_extension_pool(''KR:05'') := ''Ha'';'||wwv_flow.LF||
'    l_last_name_extens';
wwv_flow_imp.g_varchar2_table(930) := 'ion_pool(''KR:06'') := ''Heo''; l_last_name_extension_pool(''KR:07'') := ''Joo''; l_last_name_extension_pool';
wwv_flow_imp.g_varchar2_table(931) := '(''KR:08'') := ''Ko''; l_last_name_extension_pool(''KR:09'') := ''Koo''; l_last_name_extension_pool(''KR:10'')';
wwv_flow_imp.g_varchar2_table(932) := ' := ''Nam'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''KR:11'') := ''No''; l_last_name_extension_pool(''KR:12'') := ''';
wwv_flow_imp.g_varchar2_table(933) := 'Oh''; l_last_name_extension_pool(''KR:13'') := ''Ryu''; l_last_name_extension_pool(''KR:14'') := ''Son''; l_l';
wwv_flow_imp.g_varchar2_table(934) := 'ast_name_extension_pool(''KR:15'') := ''Yang'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''KR:16'') := ''Yoo''; l_last';
wwv_flow_imp.g_varchar2_table(935) := '_name_extension_pool(''KR:17'') := ''Kwon''; l_last_name_extension_pool(''KR:18'') := ''Lim''; l_last_name_e';
wwv_flow_imp.g_varchar2_table(936) := 'xtension_pool(''KR:19'') := ''Bok'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_extension_pool(''IL:01'') := ''Avital''; l_first_name';
wwv_flow_imp.g_varchar2_table(937) := '_extension_pool(''IL:02'') := ''Bar''; l_first_name_extension_pool(''IL:03'') := ''Dalia''; l_first_name_ext';
wwv_flow_imp.g_varchar2_table(938) := 'ension_pool(''IL:04'') := ''Eden''; l_first_name_extension_pool(''IL:05'') := ''Hila'';'||wwv_flow.LF||
'    l_first_name_ext';
wwv_flow_imp.g_varchar2_table(939) := 'ension_pool(''IL:06'') := ''Ilan''; l_first_name_extension_pool(''IL:07'') := ''Lavi''; l_first_name_extensi';
wwv_flow_imp.g_varchar2_table(940) := 'on_pool(''IL:08'') := ''Meital''; l_first_name_extension_pool(''IL:09'') := ''Niv''; l_first_name_extension_';
wwv_flow_imp.g_varchar2_table(941) := 'pool(''IL:10'') := ''Or'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''IL:11'') := ''Ronit''; l_first_name_extension_p';
wwv_flow_imp.g_varchar2_table(942) := 'ool(''IL:12'') := ''Shani''; l_first_name_extension_pool(''IL:13'') := ''Shlomi''; l_first_name_extension_po';
wwv_flow_imp.g_varchar2_table(943) := 'ol(''IL:14'') := ''Talya''; l_first_name_extension_pool(''IL:15'') := ''Uriel'';'||wwv_flow.LF||
'    l_first_name_extension_';
wwv_flow_imp.g_varchar2_table(944) := 'pool(''IL:16'') := ''Yarden''; l_first_name_extension_pool(''IL:17'') := ''Yaara''; l_first_name_extension_p';
wwv_flow_imp.g_varchar2_table(945) := 'ool(''IL:18'') := ''Orit''; l_first_name_extension_pool(''IL:19'') := ''Shaked'';'||wwv_flow.LF||
'    l_last_name_extension_';
wwv_flow_imp.g_varchar2_table(946) := 'pool(''IL:01'') := ''Azulay''; l_last_name_extension_pool(''IL:02'') := ''Biton''; l_last_name_extension_poo';
wwv_flow_imp.g_varchar2_table(947) := 'l(''IL:03'') := ''Dahan''; l_last_name_extension_pool(''IL:04'') := ''Dayan''; l_last_name_extension_pool(''I';
wwv_flow_imp.g_varchar2_table(948) := 'L:05'') := ''Efrati'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''IL:06'') := ''Goldstein''; l_last_name_extension_po';
wwv_flow_imp.g_varchar2_table(949) := 'ol(''IL:07'') := ''Katz''; l_last_name_extension_pool(''IL:08'') := ''Mor''; l_last_name_extension_pool(''IL:';
wwv_flow_imp.g_varchar2_table(950) := '09'') := ''Ohana''; l_last_name_extension_pool(''IL:10'') := ''Shapira'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''I';
wwv_flow_imp.g_varchar2_table(951) := 'L:11'') := ''Stern''; l_last_name_extension_pool(''IL:12'') := ''Tzur''; l_last_name_extension_pool(''IL:13''';
wwv_flow_imp.g_varchar2_table(952) := ') := ''Vaknin''; l_last_name_extension_pool(''IL:14'') := ''Weiss''; l_last_name_extension_pool(''IL:15'') :';
wwv_flow_imp.g_varchar2_table(953) := '= ''Ben David'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''IL:16'') := ''Ben Shimon''; l_last_name_extension_pool(''';
wwv_flow_imp.g_varchar2_table(954) := 'IL:17'') := ''Sela''; l_last_name_extension_pool(''IL:18'') := ''Rosenberg''; l_last_name_extension_pool(''I';
wwv_flow_imp.g_varchar2_table(955) := 'L:19'') := ''Ben Zvi'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_extension_pool(''AR:01'') := ''Amina''; l_first_name_extension_po';
wwv_flow_imp.g_varchar2_table(956) := 'ol(''AR:02'') := ''Basma''; l_first_name_extension_pool(''AR:03'') := ''Farid''; l_first_name_extension_pool';
wwv_flow_imp.g_varchar2_table(957) := '(''AR:04'') := ''Hanan''; l_first_name_extension_pool(''AR:05'') := ''Imran'';'||wwv_flow.LF||
'    l_first_name_extension_po';
wwv_flow_imp.g_varchar2_table(958) := 'ol(''AR:06'') := ''Jamal''; l_first_name_extension_pool(''AR:07'') := ''Khaled''; l_first_name_extension_poo';
wwv_flow_imp.g_varchar2_table(959) := 'l(''AR:08'') := ''Laila''; l_first_name_extension_pool(''AR:09'') := ''Majid''; l_first_name_extension_pool(';
wwv_flow_imp.g_varchar2_table(960) := '''AR:10'') := ''Nadia'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''AR:11'') := ''Rasha''; l_first_name_extension_poo';
wwv_flow_imp.g_varchar2_table(961) := 'l(''AR:12'') := ''Samia''; l_first_name_extension_pool(''AR:13'') := ''Tariq''; l_first_name_extension_pool(';
wwv_flow_imp.g_varchar2_table(962) := '''AR:14'') := ''Walid''; l_first_name_extension_pool(''AR:15'') := ''Yasmin'';'||wwv_flow.LF||
'    l_first_name_extension_po';
wwv_flow_imp.g_varchar2_table(963) := 'ol(''AR:16'') := ''Zainab''; l_first_name_extension_pool(''AR:17'') := ''Salim''; l_first_name_extension_poo';
wwv_flow_imp.g_varchar2_table(964) := 'l(''AR:18'') := ''Hisham''; l_first_name_extension_pool(''AR:19'') := ''Maha'';'||wwv_flow.LF||
'    l_last_name_extension_po';
wwv_flow_imp.g_varchar2_table(965) := 'ol(''AR:01'') := ''Abbas''; l_last_name_extension_pool(''AR:02'') := ''Ali''; l_last_name_extension_pool(''AR';
wwv_flow_imp.g_varchar2_table(966) := ':03'') := ''Aziz''; l_last_name_extension_pool(''AR:04'') := ''Bakr''; l_last_name_extension_pool(''AR:05'') ';
wwv_flow_imp.g_varchar2_table(967) := ':= ''Bishara'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''AR:06'') := ''Eid''; l_last_name_extension_pool(''AR:07'') ';
wwv_flow_imp.g_varchar2_table(968) := ':= ''Fadel''; l_last_name_extension_pool(''AR:08'') := ''Habib''; l_last_name_extension_pool(''AR:09'') := ''';
wwv_flow_imp.g_varchar2_table(969) := 'Hamad''; l_last_name_extension_pool(''AR:10'') := ''Ibrahim'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''AR:11'') :=';
wwv_flow_imp.g_varchar2_table(970) := ' ''Ismail''; l_last_name_extension_pool(''AR:12'') := ''Jaber''; l_last_name_extension_pool(''AR:13'') := ''K';
wwv_flow_imp.g_varchar2_table(971) := 'assem''; l_last_name_extension_pool(''AR:14'') := ''Latif''; l_last_name_extension_pool(''AR:15'') := ''Mors';
wwv_flow_imp.g_varchar2_table(972) := 'i'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''AR:16'') := ''Qasim''; l_last_name_extension_pool(''AR:17'') := ''Rash';
wwv_flow_imp.g_varchar2_table(973) := 'ed''; l_last_name_extension_pool(''AR:18'') := ''Saad''; l_last_name_extension_pool(''AR:19'') := ''Taher'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(974) := ''||wwv_flow.LF||
'    l_first_name_extension_pool(''TR:01'') := ''Aylin''; l_first_name_extension_pool(''TR:02'') := ''Bahar';
wwv_flow_imp.g_varchar2_table(975) := '''; l_first_name_extension_pool(''TR:03'') := ''Cagla''; l_first_name_extension_pool(''TR:04'') := ''Ebru''; ';
wwv_flow_imp.g_varchar2_table(976) := 'l_first_name_extension_pool(''TR:05'') := ''Emine'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''TR:06'') := ''Fatma''';
wwv_flow_imp.g_varchar2_table(977) := '; l_first_name_extension_pool(''TR:07'') := ''Hakan''; l_first_name_extension_pool(''TR:08'') := ''Ilker''; ';
wwv_flow_imp.g_varchar2_table(978) := 'l_first_name_extension_pool(''TR:09'') := ''Leyla''; l_first_name_extension_pool(''TR:10'') := ''Murat'';'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(979) := '  l_first_name_extension_pool(''TR:11'') := ''Nazli''; l_first_name_extension_pool(''TR:12'') := ''Pinar''; ';
wwv_flow_imp.g_varchar2_table(980) := 'l_first_name_extension_pool(''TR:13'') := ''Sibel''; l_first_name_extension_pool(''TR:14'') := ''Sinan''; l_';
wwv_flow_imp.g_varchar2_table(981) := 'first_name_extension_pool(''TR:15'') := ''Tugba'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''TR:16'') := ''Umut''; l';
wwv_flow_imp.g_varchar2_table(982) := '_first_name_extension_pool(''TR:17'') := ''Yasemin''; l_first_name_extension_pool(''TR:18'') := ''Yusuf''; l';
wwv_flow_imp.g_varchar2_table(983) := '_first_name_extension_pool(''TR:19'') := ''Zehra'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''TR:01'') := ''Acar''; l';
wwv_flow_imp.g_varchar2_table(984) := '_last_name_extension_pool(''TR:02'') := ''Altun''; l_last_name_extension_pool(''TR:03'') := ''Aslan''; l_las';
wwv_flow_imp.g_varchar2_table(985) := 't_name_extension_pool(''TR:04'') := ''Bayram''; l_last_name_extension_pool(''TR:05'') := ''Bozkurt'';'||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(986) := 'last_name_extension_pool(''TR:06'') := ''Cakir''; l_last_name_extension_pool(''TR:07'') := ''Candan''; l_las';
wwv_flow_imp.g_varchar2_table(987) := 't_name_extension_pool(''TR:08'') := ''Dogan''; l_last_name_extension_pool(''TR:09'') := ''Duman''; l_last_na';
wwv_flow_imp.g_varchar2_table(988) := 'me_extension_pool(''TR:10'') := ''Ergin'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''TR:11'') := ''Gok''; l_last_name';
wwv_flow_imp.g_varchar2_table(989) := '_extension_pool(''TR:12'') := ''Gunes''; l_last_name_extension_pool(''TR:13'') := ''Kaya''; l_last_name_exte';
wwv_flow_imp.g_varchar2_table(990) := 'nsion_pool(''TR:14'') := ''Korkmaz''; l_last_name_extension_pool(''TR:15'') := ''Sari'';'||wwv_flow.LF||
'    l_last_name_ext';
wwv_flow_imp.g_varchar2_table(991) := 'ension_pool(''TR:16'') := ''Sezer''; l_last_name_extension_pool(''TR:17'') := ''Ucar''; l_last_name_extensio';
wwv_flow_imp.g_varchar2_table(992) := 'n_pool(''TR:18'') := ''Yildirim''; l_last_name_extension_pool(''TR:19'') := ''Yuksel'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_name_ex';
wwv_flow_imp.g_varchar2_table(993) := 'tension_pool(''AF:01'') := ''Abiola''; l_first_name_extension_pool(''AF:02'') := ''Aisha''; l_first_name_ext';
wwv_flow_imp.g_varchar2_table(994) := 'ension_pool(''AF:03'') := ''Binta''; l_first_name_extension_pool(''AF:04'') := ''Bongani''; l_first_name_ext';
wwv_flow_imp.g_varchar2_table(995) := 'ension_pool(''AF:05'') := ''Chisom'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''AF:06'') := ''Dineo''; l_first_name_';
wwv_flow_imp.g_varchar2_table(996) := 'extension_pool(''AF:07'') := ''Eshe''; l_first_name_extension_pool(''AF:08'') := ''Fatima''; l_first_name_ex';
wwv_flow_imp.g_varchar2_table(997) := 'tension_pool(''AF:09'') := ''Jabari''; l_first_name_extension_pool(''AF:10'') := ''Lerato'';'||wwv_flow.LF||
'    l_first_nam';
wwv_flow_imp.g_varchar2_table(998) := 'e_extension_pool(''AF:11'') := ''Mpho''; l_first_name_extension_pool(''AF:12'') := ''Nandi''; l_first_name_e';
wwv_flow_imp.g_varchar2_table(999) := 'xtension_pool(''AF:13'') := ''Sade''; l_first_name_extension_pool(''AF:14'') := ''Tariro''; l_first_name_ext';
wwv_flow_imp.g_varchar2_table(1000) := 'ension_pool(''AF:15'') := ''Tumelo'';'||wwv_flow.LF||
'    l_first_name_extension_pool(''AF:16'') := ''Yemi''; l_first_name_e';
wwv_flow_imp.g_varchar2_table(1001) := 'xtension_pool(''AF:17'') := ''Zanele''; l_first_name_extension_pool(''AF:18'') := ''Osei''; l_first_name_ext';
wwv_flow_imp.g_varchar2_table(1002) := 'ension_pool(''AF:19'') := ''Zuberi'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''AF:01'') := ''Adebayo''; l_last_name_';
wwv_flow_imp.g_varchar2_table(1003) := 'extension_pool(''AF:02'') := ''Akinyemi''; l_last_name_extension_pool(''AF:03'') := ''Balogun''; l_last_name';
wwv_flow_imp.g_varchar2_table(1004) := '_extension_pool(''AF:04'') := ''Diallo''; l_last_name_extension_pool(''AF:05'') := ''Diop'';'||wwv_flow.LF||
'    l_last_name';
wwv_flow_imp.g_varchar2_table(1005) := '_extension_pool(''AF:06'') := ''Fofana''; l_last_name_extension_pool(''AF:07'') := ''Kamara''; l_last_name_e';
wwv_flow_imp.g_varchar2_table(1006) := 'xtension_pool(''AF:08'') := ''Kone''; l_last_name_extension_pool(''AF:09'') := ''Mbeki''; l_last_name_extens';
wwv_flow_imp.g_varchar2_table(1007) := 'ion_pool(''AF:10'') := ''Mensah'';'||wwv_flow.LF||
'    l_last_name_extension_pool(''AF:11'') := ''Mugabe''; l_last_name_exte';
wwv_flow_imp.g_varchar2_table(1008) := 'nsion_pool(''AF:12'') := ''Nkrumah''; l_last_name_extension_pool(''AF:13'') := ''Sanogo''; l_last_name_exten';
wwv_flow_imp.g_varchar2_table(1009) := 'sion_pool(''AF:14'') := ''Sesay''; l_last_name_extension_pool(''AF:15'') := ''Sow'';'||wwv_flow.LF||
'    l_last_name_extensi';
wwv_flow_imp.g_varchar2_table(1010) := 'on_pool(''AF:16'') := ''Traore''; l_last_name_extension_pool(''AF:17'') := ''Touray''; l_last_name_extension';
wwv_flow_imp.g_varchar2_table(1011) := '_pool(''AF:18'') := ''Yeboah''; l_last_name_extension_pool(''AF:19'') := ''Zuberi'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- Load standalone';
wwv_flow_imp.g_varchar2_table(1012) := ', country-appropriate catalogs. The catalogs are'||wwv_flow.LF||
'    -- deliberately single-token; only the controll';
wwv_flow_imp.g_varchar2_table(1013) := 'ed interval logic in the'||wwv_flow.LF||
'    -- picker functions can introduce a hyphen.'||wwv_flow.LF||
'    -- Generated standalone';
wwv_flow_imp.g_varchar2_table(1014) := ' catalogs are inserted below.'||wwv_flow.LF||
'    l_first_name_catalog(14) := ''Thabo|Naledi|Sipho|Lerato|Ayanda|Tebo';
wwv_flow_imp.g_varchar2_table(1015) := 'ho|Chinedu|Adaeze|Emeka|Ifeoma|Kofi|Ama|Kwame|Abena|Amina|Zuri|Kamau|Wanjiku|Nia|Tendai|Abiola|Aisha';
wwv_flow_imp.g_varchar2_table(1016) := '|Binta|Bongani|Chisom|Dineo|Eshe|Fatima|Jabari|Mpho|Nandi|Sade|Tariro|Tumelo|Yemi|Zanele|Osei|Zuberi';
wwv_flow_imp.g_varchar2_table(1017) := '|John|Joseph|Peter|Brian|David|James|Samuel|Daniel|Stephen|Kelvin|Ibrahim|Mohamed|Dennis|Emmanuel|Pa';
wwv_flow_imp.g_varchar2_table(1018) := 'ul|Victor|Moses|Kevin|Wanjiru|Michael|Francis|Charles|Vincent|Alex|Simon|George|Otieno|Patrick|Evans';
wwv_flow_imp.g_varchar2_table(1019) := '|Collins|Kennedy|Mwangi|Isaac|Edwin|Ali|Erick|Felix|Joshua|Abdi|Martin|Robert|Amos|Denis|Hassan|Juli';
wwv_flow_imp.g_varchar2_table(1020) := 'us|Benson|Benard|Fredrick|Nicholas|Jackson|Samwel|Ian|Eric|Odhiambo|Maina|Richard|Ochieng|Antony|Jum';
wwv_flow_imp.g_varchar2_table(1021) := 'a|William|Philip|Samson|Shadrack|Ahmed|Joel|Wilson|Thomas|Hussein|Omondi|Onyango|Geoffrey|Bonface|Hi';
wwv_flow_imp.g_varchar2_table(1022) := 'llary|Jacob|Andrew|Gideon|Benjamin|Mark|Timothy|Adan|Sammy|Dominic|Wafula|Salim|Titus|Henry|Elijah|A';
wwv_flow_imp.g_varchar2_table(1023) := 'nthony|Edward|Josphat|Allan|Wambui|Stanley|Gilbert|Njoroge|Kyalo|Kariuki|Ismail|Christopher|Omar|Nje';
wwv_flow_imp.g_varchar2_table(1024) := 'ri|Mutua|Nelson|Ouma|Alfred|Clinton|Enock|Kenneth|Elvis|Duncan|Suleiman|Rashid|Dickson|Valentine|Law';
wwv_flow_imp.g_varchar2_table(1025) := 'rence|Wanjala|Muthoni|Solomon|Meshack|Caleb|Wambua|Simiyu|Abraham|Jeremiah|Boniface|Hamisi|Kibet|Gab';
wwv_flow_imp.g_varchar2_table(1026) := 'riel|Kimani|Raphael|Justus|Mutuku|Reuben|Derrick|Ezekiel|Njuguna|Ronald|Wekesa|Bernard|Lewis|Leonard';
wwv_flow_imp.g_varchar2_table(1027) := '|Silas|Festus|Jonathan|Godfrey|Geofrey|Said|Musyoka|Douglas|Dancan|Eliud|Kioko|Pius|Morris|Elias|Mac';
wwv_flow_imp.g_varchar2_table(1028) := 'haria|Musa|Mathew|Barasa|Fred|Frankline|Wairimu|Isaiah|Harrison|Mutinda|Newton|Osman|Wycliffe|Karanj';
wwv_flow_imp.g_varchar2_table(1029) := 'a|Mohammed|Yusuf|Nyambura|Owino|Wangui|Issa|Albert|Okoth|Jared|Job|Rodgers|Yussuf|Wangari|Derick|Joh';
wwv_flow_imp.g_varchar2_table(1030) := 'nson|Oduor|Oscar|Nickson|Wilfred|Kiprotich|Njoki|Wanyonyi|Nyongesa|Kinyua|Cyrus|Abubakar|Aron|Kipkoe';
wwv_flow_imp.g_varchar2_table(1031) := 'ch|Melvin|Gitonga|Walter|Kiptoo|Mbugua|Mohamud|Tonny|Waweru|Onesmus|Zakaria|Wesley|Ramadhan|Haron|Ch';
wwv_flow_imp.g_varchar2_table(1032) := 'ege|Daud|Ngugi|Tom|Mwendwa|Mike|Cosmas|Alvin|Steven|Kiprono|Njeru|Ezra|Muriithi|Abel|Davis|Mwende|Ma';
wwv_flow_imp.g_varchar2_table(1033) := 'urice|Mburu|Gerald|Kiprop|Ken|Musyoki|Irungu|Noah|Maxwell|Mwaura|Cheruiyot|Austine|Nyaga|Abdihakim|E';
wwv_flow_imp.g_varchar2_table(1034) := 'lisha|Kimutai|Gitau|Kiplagat|Laban|Kipkorir|Josephat|Muli|Yahya|Noor|Justine|Oliver|Steve|Issack|Mun';
wwv_flow_imp.g_varchar2_table(1035) := 'gai|Ndungu|Nathan|Harun|Augustine|Mutisya|Alexander|Eugene|Wachira|Ayub|Tony|Cornelius|Boaz|Mutunga|';
wwv_flow_imp.g_varchar2_table(1036) := 'Aden|Abdalla|Bakari|Mwaniki|Dan|Chris|Japheth|Philemon|Ng''''ang''''a|Benedict|Maxwel|Eugine|Raymond|Luc';
wwv_flow_imp.g_varchar2_table(1037) := 'as|Njenga|Japhet|Simion|Ernest|Ndung''''u|Munene|Murithi|Baraka|Humphrey|Mwanzia|Hosea|Nicholus|Calvin';
wwv_flow_imp.g_varchar2_table(1038) := '|Munyao|Kipruto|Linus|Reagan|Danson|Arnold|Robinson|Evance|Ismael|Sylvester|Charo|Musembi|Muriuki|Mu';
wwv_flow_imp.g_varchar2_table(1039) := 'ema|Idris|Willy|Riziki|Kinyanjui|Mugo|Teddy|Clement|Kilonzo|Peterson|Mwikali|Kiplangat|Kipngetich|Mu';
wwv_flow_imp.g_varchar2_table(1040) := 'mo|Kipchumba|Rotich|Feisal|Kuria|Wamalwa|Ambrose|Anderson|Alphonce|Jeff|Mulwa|Kipkemoi|Billy|Shem|Mu';
wwv_flow_imp.g_varchar2_table(1041) := 'chiri|Adam|Makau|Jack|Mueni|Kimathi|Frank|Koech|Fidelis|Jamal|Wainaina|Kipchirchir|Saidi|Makokha|Roy';
wwv_flow_imp.g_varchar2_table(1042) := '|Okumu|Hezron|Noel|Kassim|Micah|Tobias|Ndegwa|Kenedy|Hesbon|Muiruri|Amani|Lameck|Njagi|Kemboi|Katana';
wwv_flow_imp.g_varchar2_table(1043) := '|Elly|Erastus|Nicodemus|Mwangangi|Mutiso|Swaleh|Johnstone|Mugambi|Morgan|Nganga|Hamza|Omari|Levis|Go';
wwv_flow_imp.g_varchar2_table(1044) := 'dwin|Momanyi|Shaban|Korir|Daudi|Jimmy|Wanja|Jonah|Oluoch|Karimi|Abdul|Ndirangu|Odongo|Wanyama|Calvin';
wwv_flow_imp.g_varchar2_table(1045) := 'ce|Weldon|Opiyo|Wanjohi|Sifuna|Nuru|Gedion|Mustafa|Wycliff|Rama|Terry|Keneth|Langat|Githinji|Keith|D';
wwv_flow_imp.g_varchar2_table(1046) := 'ismas|Yunis|Zacharia|Josiah|Gregory|Muthui|Lucky|Joash|Isaack|Tyson|Mbithi|Jesse|Luka|Kipkirui|Pasca';
wwv_flow_imp.g_varchar2_table(1047) := 'l|Gibson|Nduku|Kiplimo|Joram|Njogu|Nyakundi|Njiru|Emanuel|Zakayo|Okello|Ryan|Maingi|Owuor|Murimi|Isa';
wwv_flow_imp.g_varchar2_table(1048) := 'ck|Zablon|Musau|Kelly|Abdallah|Rajab|Sila|Aggrey|Mumbi|Franklin|Phelix|Muturi|Kipkurui|Elphas|Mwiti|';
wwv_flow_imp.g_varchar2_table(1049) := 'Collince|Robin|Munyoki|Ephantus|Muia|Silvester|Gordon|Innocent|Kirui|Amin|Donald|Justin|Kinuthia|Kip';
wwv_flow_imp.g_varchar2_table(1050) := 'sang|Kiarie|Milton|Obed|Owen|Bramwel|Zachary|Nduta|Wambugu|Fidel|Aftin|Seth|Carlos|Mukhwana|Ndunge|C';
wwv_flow_imp.g_varchar2_table(1051) := 'leophas|Kimanzi|Mutie|Javan|Luke|Ondieki|Micheal|Elkana|Bahati|Nehemiah|Amon|Kanini|Makori|Musee|Aar';
wwv_flow_imp.g_varchar2_table(1052) := 'on|Kimeu|Phillip|Kipkosgei|Ronny|Nixon|Karani|Livingstone|Wesonga|Wangila|Marvin|Simeon|Liban|Dancun';
wwv_flow_imp.g_varchar2_table(1053) := '|Phineas|Kosgei|Bryan|Abednego|Masika|Nahashon|Athuman|Ngari|Nzioka|Stephene|Masinde|Athman|Mathias|';
wwv_flow_imp.g_varchar2_table(1054) := 'Vitalis|Bett|Mboya|Tsuma|Kipkemboi|Joe|Mutai|Mugendi|Kipngeno|Muthengi|Jairus|Nyamai|Kipyegon|Njue|G';
wwv_flow_imp.g_varchar2_table(1055) := 'athoni|Sam|Muthoka|Muthama|Rogers|Ngigi|Dalmas|Rono|Nderitu|Nzomo|Duke|Clifford|Bravin|Edgar|Washing';
wwv_flow_imp.g_varchar2_table(1056) := 'ton|Nyawira|Thuo|Willis|Oloo|Mary|Faith|Mercy|Sharon|Esther|Elizabeth|Jane|Grace|Ruth|Lucy|Caroline|';
wwv_flow_imp.g_varchar2_table(1057) := 'Christine|Nancy|Margaret|Ann|Lilian|Joyce|Purity|Eunice|Susan|Jackline|Rose|Beatrice|Diana|Cynthia|C';
wwv_flow_imp.g_varchar2_table(1058) := 'atherine|Brenda|Sarah|Naomi|Irene|Alice|Fatuma|Gladys|Agnes|Vivian|Lydia|Dorcas|Joan|Hellen|Janet|Pa';
wwv_flow_imp.g_varchar2_table(1059) := 'uline|Florence|Sheila|Maureen|Winnie|Joy|Emily|Miriam|Abigael|Halima|Judith|Damaris|Tabitha|Nafula|C';
wwv_flow_imp.g_varchar2_table(1060) := 'harity|Linet|Millicent|Leah|Anne|Martha|Josephine|Sylvia|Kemunto|Yvonne|Daisy|Nelly|Betty|Stella|Dor';
wwv_flow_imp.g_varchar2_table(1061) := 'een|Salome|Veronica|Judy|Fridah|Teresia|Monica|Atieno|Rebecca|Caren|Hannah|Carolyne|Moraa|Everlyne|J';
wwv_flow_imp.g_varchar2_table(1062) := 'uliet|Josphine|Monicah|Marion|Kerubo|Gloria|Irine|Winfred|Akinyi|Violet|Rosemary|Dorothy|Jacinta|Mar';
wwv_flow_imp.g_varchar2_table(1063) := 'iam|Achieng|Maurine|Nekesa|Linda|Regina|Rachael|Cecilia|Peris|Asha|Rael|Emmaculate|Patricia|Teresa|K';
wwv_flow_imp.g_varchar2_table(1064) := 'wamboka|Veronicah|Rehema|Doris|Pamela|Mildred|Celestine|Edith|Nanjala|Lydiah|Everline|Victoria|Zippo';
wwv_flow_imp.g_varchar2_table(1065) := 'rah|Annah|Khadija|Beth|Margret|Risper|Virginia|Deborah|Mercyline|Sophia|Ivy|Peninah|Beryl|Anna|Silvi';
wwv_flow_imp.g_varchar2_table(1066) := 'a|Jelagat|Winny|Serah|Maria|Naomy|Julia|Anyango|Angela|Magdaline|Sandra|Mirriam|Stacy|Immaculate|Hil';
wwv_flow_imp.g_varchar2_table(1067) := 'da|Mourine|Belinda|Loise|Tracy|Viola|Habiba|Milka|Emma|Neema|Evaline|Rahma|Moureen|Evalyne|Rukia|Ros';
wwv_flow_imp.g_varchar2_table(1068) := 'eline|Nyaboke|Loice|Norah|Rahab|Naliaka|Harriet|Moreen|Dorine|Selina|Getrude|Akoth|Karen|Rachel|Salm';
wwv_flow_imp.g_varchar2_table(1069) := 'a|Stellah|Priscilla|Phoebe|Joyline|Jebet|Rhoda|Saumu|Dorcus|Chebet|Racheal|Teresiah|Jeniffer|Jecinta';
wwv_flow_imp.g_varchar2_table(1070) := '|Juliana|Patience|Roselyne|Felister|Laura|Penina|Quinter|Sheilah|Rodah|Sabina|Valary|Bosibori|Prisca';
wwv_flow_imp.g_varchar2_table(1071) := '|Clare|Metrine|Jepkoech|Wendy|Dinah|Sally|Edna|Dianah|Consolata|Jerop|Lucia|Carol|Sofia|Lavender|Fan';
wwv_flow_imp.g_varchar2_table(1072) := 'cy|Jeruto|Priscah|Emilly|Phylis|Brendah|Velma|Angeline|Jemimah|Anita|Carren|Elosy|Naom|Lorna|Hadija|';
wwv_flow_imp.g_varchar2_table(1073) := 'Emmah|Prudence|Jemutai|Magdalene|Jepkorir|Annet|Nelima|Francisca|Gesare|Hawa|Rita|Linah|Hildah|Hafsa';
wwv_flow_imp.g_varchar2_table(1074) := '|Jepchumba|Jeptoo|Jesca|Jennifer|Jerotich|Jepchirchir|Jerono|Mwanamisi|Eva|Leila|Annastacia|Felistus';
wwv_flow_imp.g_varchar2_table(1075) := '|Vallary|Nyanchama|Lenah|Vicky|Phanice|Cherotich|Fiona|June|Evelyne|Jedidah|Jael|Maryann|Emmy|Zainab';
wwv_flow_imp.g_varchar2_table(1076) := '|Milkah|Frida|Jepkemoi|Sheilla|Lorine|Priscillah|Sylivia|Keziah|Jepkosgei|Anastacia|Janeth|Christabe';
wwv_flow_imp.g_varchar2_table(1077) := 'l|Kemuma|Mwanajuma|Claire|Clara|Philis|Lynn|Lillian|Morine|Dolphine|Melvine|Mitchelle|Makena|Flora|B';
wwv_flow_imp.g_varchar2_table(1078) := 'ridget|Sophy|Debora|Brigid|Phyllis|Edinah|Chepkemoi|Bridgit|Centrine|Maryanne|Sheillah|Jenipher|Bent';
wwv_flow_imp.g_varchar2_table(1079) := 'a|Lindah|Farida|Zainabu|Maimuna|Jamila|Felista|Natasha|Chelangat|Saida|Chepkorir|Bilha|Chepkoech|Rab';
wwv_flow_imp.g_varchar2_table(1080) := 'ecca|Milcah|Philomena|Eddah|Weddy|Sara|Laureen|Ivone|Nathaniel|Blessing|Hope|Peace|Comfort|Andile|Ba';
wwv_flow_imp.g_varchar2_table(1081) := 'ndile|Bhekani|Jabulani|Langalibalele|Lungile|Luyanda|Lwandile|Mandla|Mandlakhe|Mcebisi|Minenhle|Mlun';
wwv_flow_imp.g_varchar2_table(1082) := 'gisi|Mthokozisi|Mzamo|Nhlanhla|Njabulo|S''''fiso|Sandile|Sibonelo|Sibusiso|SimphiweyiNkosi|Siyabonga|S';
wwv_flow_imp.g_varchar2_table(1083) := 'phiwe|Thabani|Thalente|Thando|Vusumuzi|Zenzele|Amahle|Bhekisisa|Bhekizizwe|Bhekokwakhe|Busisiwe|Dumi';
wwv_flow_imp.g_varchar2_table(1084) := 'sani|Dumisile|Gugu|Gugulethu|Khanyisile|Londisizwe|Londiwe|Mnqobi|Ndumiso|Nkazimulo|Nobantu|Nobuhle|';
wwv_flow_imp.g_varchar2_table(1085) := 'Nokulunga|Nomagugu|Nomalanga|Nomasonto|Nomathalente|Nomathemba|Nomcebo|Nomthandazo|Nomusa|Nomvula|No';
wwv_flow_imp.g_varchar2_table(1086) := 'nhlanhla|Nonjabulo|Nothando|Noxolo|Nozibusiso|Nozizwe|Nqobizitha|Olwethu|Owethu|Sibongile|Sibusisiwe';
wwv_flow_imp.g_varchar2_table(1087) := '|Sihawukele|Silondile|Simphiwe|Siphesihle|Sithembiso|Thabisa|Thabisile|Thandazile|Thandeka|Thandiwe|';
wwv_flow_imp.g_varchar2_table(1088) := 'Thembeka|Thembekile|Thembile|Thembisile|Thuthukile|Zakhele|Zenzile|Zibuyile|Zinhle|Abdu|Aijuka|Amri|';
wwv_flow_imp.g_varchar2_table(1089) := 'Andwele|Angalia|Angavu|Anoni|Asani|Asanti|Athumani|Azizi|Bahari|Bale|Balinda|Beshte|Bibuwa|Boma|Cheu';
wwv_flow_imp.g_varchar2_table(1090) := unistr('si|Chuki|Dai|Duma|Dunia|\00CBakumbu|Ekundu|Eliakimu|Enzi|Fahari|Fanaka|Faraja|Hadithi|Hamis|Harambee|Hek');
wwv_flow_imp.g_varchar2_table(1091) := 'ima|Isaya|Ituri|Jalia|Jangwa|Jelani|Jua|Jumaane|Justiniani|Kaombwe|Kashangaki|Kenyangi|Khamani|Khami';
wwv_flow_imp.g_varchar2_table(1092) := 'si|Kiapo|Kiburi|Kijana|Kijani|Kimbilio|Kinubi|Kipenzi|Kiume|Kondo|Konradi|Kovu|Kurunzi|Kusiima|Makin';
wwv_flow_imp.g_varchar2_table(1093) := 'i|Makunga|Makuu|Matunda|Mavuno|Mohamedi|Mulele|Mwezi|Ngamia|Ngeni|Ntimi|Nuhu|Nuriat|Nwabudike|Osogo|';
wwv_flow_imp.g_varchar2_table(1094) := 'Pambe|Pelaji|Popobawa|Pumbaa|Rashidi|Reshoni|Risasi|Rua|Rubani|Ruhiu|Rungo|Sabari|Sadaka|Sadiki|Safa';
wwv_flow_imp.g_varchar2_table(1095) := 'ri|Samweli|Seif|Shida|Sifa|Siku|Takatifu|Thabiti|Tisa|Tufani|Tukufu|Ushindi|Usiku|Uzima|Wamwema|Yako';
wwv_flow_imp.g_varchar2_table(1096) := 'bo|Yohana|Yohane|Zahur|Zende|Zuba|Zuhri|Zwatie|Abigaili|Adhra|Adia|Adimu|Akumu|Almasi|Amondi|Anasa|A';
wwv_flow_imp.g_varchar2_table(1097) := 'rusi|Asali|Asatira|Asmini|Atiena|Busara|Chaniya|Chausiki|Chipukizi|Dainess|Dalili|Faisa|Farhiya|Fari';
wwv_flow_imp.g_varchar2_table(1098) := 'jika|Gethera|Goma|Haiba|Halisi|Hanja|Hashiki|Hatima|Hawehindi|Hidaya|Hodari|Humaiya|Imany|Imara|Itan';
wwv_flow_imp.g_varchar2_table(1099) := 'ya|Jahi|Jana|Jasiri|Jina|Kaluwa|Karama|Kaskazi|Kiah|Kibafupia|Kibibi|Kimya|Kinaya|Kiojah|Kipepeo|Kis';
wwv_flow_imp.g_varchar2_table(1100) := 'ima|Kiwara|Kuchanua|Kweli|Lailati|Laini|Madaha|Madini|Madoa|Mahali|Maisha|Majani|Maliza|Marini|Marja';
wwv_flow_imp.g_varchar2_table(1101) := 'ni|Maua|Misuli|Mkarkara|Mrihani|Muhima|Musila|Mwamini|Mwasaa|Najuma|Naki|Nashipie|Nasra|Nathari|Nayf';
wwv_flow_imp.g_varchar2_table(1102) := 'a|Nelah|Niara|Nigesa|Njozi|Nula|Nyasi|Nyoka|Nyoni|Nyota|Nyuki|Opwonya|Panya|Paskalia|Sadao|Safiri|Sa';
wwv_flow_imp.g_varchar2_table(1103) := 'rabi|Sarafina|Sauti|Serafina|Shani|Shawana|Skolastika|Sungara|Swala|Tambika|Tamu|Tuere|Udeera|Ujamaa';
wwv_flow_imp.g_varchar2_table(1104) := '|Umande|Umoja|Waceera|Waridi|Waseme|Yasinta|Zahnya|Zaituni|Zumaridi|Zuwena|Abayomi|Abiodun|Abiona|Ad';
wwv_flow_imp.g_varchar2_table(1105) := 'ebiyi|Adebowale|Adedayo|Adedeji|Adekitan|Adekola|Adekunle|Adeleke|Adeniyi|Adeolu|Adeoti|Aderopo|Ades';
wwv_flow_imp.g_varchar2_table(1106) := 'hina|Adesoji|Adetayo|Adeyi|Adigun|Afolarin|Ajala|Ajani|Akanmu|Akinkunmi|Akinlabi|Akinwale|Alade|Alam';
wwv_flow_imp.g_varchar2_table(1107) := 'u|Anjolaoluwa|Ayinde|Ayodeji|Ayodele|Babasola|Babatunji|Babawale|Damife|Demilade|Durodola|Ekundayo|E';
wwv_flow_imp.g_varchar2_table(1108) := 'supofo|Folu|Gbadebo|Gbolahan|Gbowoade|Ibidapo|Ige|Ikeoluwa|Inioluwa|Iseoluwa|Ishola|Juwon|Keji|Kolaw';
wwv_flow_imp.g_varchar2_table(1109) := 'ole|Korede|Leke|Lere|Niyilolawa|Oba|ObaniJesu|Ogooluwa|Oke|Oladare|Oladimeji|Olakunle|Olanrewaju|Ola';
wwv_flow_imp.g_varchar2_table(1110) := 'nsile|Olumorotimi|Oluwafemi|Oluwagbemiga|Oluwamumibori|Oluwamuyiwa|Oluwasanmi|Oluwasegun|Oluwole|Omo';
wwv_flow_imp.g_varchar2_table(1111) := 'bobola|Omotayo|Osunleke|Seye|Shekoni|Sijuade|Tade|Temidayo|Toki|Tokunbo|Tomori|Aanuoluwapo|Abebi|Abe';
wwv_flow_imp.g_varchar2_table(1112) := 'ni|Abosede|Adebukola|Adenike|Adepeju|Adesewa|Adesua|Adetoke|Adetoun|Adunni|Ajoke|Amoke|Amope|Arike|A';
wwv_flow_imp.g_varchar2_table(1113) := 'rinola|Asake|Atinuke|Awero|Ayinke|Ayoka|Bolatito|Boluwatife|Bunmi|Doyinsola|Eniola|Ewatomi|Fadekemi|';
wwv_flow_imp.g_varchar2_table(1114) := 'Faderera|Fehintola|Fibikemi|Fikayomi|Folashade|Ibironke|Iretioluwa|Iyabode|Iyadunni|Kikelomo|Modupe|';
wwv_flow_imp.g_varchar2_table(1115) := 'Mofifoluwa|Mojisola|Mojisoluwa|Moradeke|Morayo|Morenike|Morolake|Mosinmileoluwa|Mosunmola|Motunrayo|';
wwv_flow_imp.g_varchar2_table(1116) := 'Moyosore|Ninioluwa|Olajumoke|Olasunmbo|Ololade|Olufunke|Olufunmilayo|Oluwakemi|Omobolanle|Omodunni|O';
wwv_flow_imp.g_varchar2_table(1117) := 'molabake|Omolara|Omosalewa|Omotara|Omotola|Omotoun|Omowumi|Oreofe|Oyenike|Oyindasola|Radeke|Ronke|Se';
wwv_flow_imp.g_varchar2_table(1118) := 'gilola|Similoluwa|Simisola|Sowande|Subomi|Titilayo|Tolulope|Toluwanimi|Wuraola|Yejide|Yetunde|Yewand';
wwv_flow_imp.g_varchar2_table(1119) := 'e|Obinna|Ifeanyi|Uche|Chukwudi|Nnamdi|Ikenna|Ekene|Chibuzo|Ebuka|Nonso|Chukwuemeka|Somtochukwu|Uchen';
wwv_flow_imp.g_varchar2_table(1120) := 'na|Ifechukwu|Chigozie|Okechukwu|Kelechi|Chijioke|Chiamaka|Oluchi|Ngozi|Amarachi|Ifunanya|Chinelo|Oge';
wwv_flow_imp.g_varchar2_table(1121) := 'chi|Nneka|Obianuju|Ujunwa|Chidimma|Nkiruka|Onyinye|Chizoba|Chinyere|Kosisochukwu|Ozioma|Somadina'';'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1122) := '   l_last_name_catalog(14) := ''Abara|Adeyemi|Afolabi|Banda|Chukwu|Dlamini|Eze|Kamau|Kilonzo|Mensah|M';
wwv_flow_imp.g_varchar2_table(1123) := 'okoena|Ndlovu|Okafor|Otieno|Owusu|Sibiya|Tadesse|Wambui|Zulu|Nwosu|Adebayo|Akinyemi|Balogun|Diallo|D';
wwv_flow_imp.g_varchar2_table(1124) := 'iop|Fofana|Kamara|Kone|Mbeki|Mugabe|Nkrumah|Sanogo|Sesay|Sow|Traore|Touray|Yeboah|Zuberi|Mohamed|Mwa';
wwv_flow_imp.g_varchar2_table(1125) := 'ngi|Odhiambo|Maina|Ochieng|Ali|Omondi|Onyango|Juma|Hassan|Abdi|Atieno|Wanjiku|Njoroge|Njeri|Kariuki|';
wwv_flow_imp.g_varchar2_table(1126) := 'Akinyi|Wafula|Achieng|Muthoni|Ouma|Ahmed|Kimani|Hussein|Adan|Mutua|Abdullahi|Adhiambo|Cheruiyot|Njug';
wwv_flow_imp.g_varchar2_table(1127) := 'una|Kibet|Simiyu|Macharia|Wanjala|Barasa|Wambua|Wairimu|Chebet|Koech|Ibrahim|Omar|Nyambura|Rotich|Ka';
wwv_flow_imp.g_varchar2_table(1128) := 'ranja|Anyango|Wangui|Wekesa|Okoth|Langat|Chepkemoi|Mutuku|Owino|Wangari|Njoki|Awuor|Musyoka|Nyongesa';
wwv_flow_imp.g_varchar2_table(1129) := '|Cherotich|Wanyonyi|Chepkoech|Korir|Chelangat|Kiptoo|Mwendwa|Mbugua|Chege|Waweru|Kinyua|Ngugi|Kiprot';
wwv_flow_imp.g_varchar2_table(1130) := 'ich|Kipkoech|Oduor|Mburu|Akoth|Kirui|Mwende|Kioko|Gitonga|Rono|Auma|Mwaura|Muriithi|Gitau|Munene|Wac';
wwv_flow_imp.g_varchar2_table(1131) := 'hira|Irungu|Njeru|Kemboi|Mutai|Cherono|Kimutai|Ndungu|Nyaga|Mutinda|Ndung''''u|Chepkorir|Ng''''ang''''a|Ch';
wwv_flow_imp.g_varchar2_table(1132) := 'epkirui|Kiprono|Mungai|Bett|Muriuki|Mwenda|Yussuf|Njenga|Said|Osman|Kiprop|Mohamud|Kiplagat|Kipkorir';
wwv_flow_imp.g_varchar2_table(1133) := '|Awino|John|Mwaniki|Charo|Murithi|Mugo|Kosgei|Makokha|Kyalo|Karisa|Ngetich|Okumu|Kinyanjui|Chepngeti';
wwv_flow_imp.g_varchar2_table(1134) := 'ch|Peter|Maalim|Issack|Muli|Kazungu|Katana|Kimathi|Kiplangat|Wamalwa|Momanyi|Musyoki|Kuria|Mutisya|C';
wwv_flow_imp.g_varchar2_table(1135) := 'heptoo|Kipngetich|Wainaina|Chemutai|Muchiri|Nyakundi|Wanyama|Sheikh|Mohammed|Mugambi|Kipchumba|Nekes';
wwv_flow_imp.g_varchar2_table(1136) := 'a|Wanja|Moraa|Odongo|Opiyo|Noor|Kahindi|Muiruri|Chepngeno|Mutunga|Mueni|Njagi|Ndegwa|Karimi|Nganga|N';
wwv_flow_imp.g_varchar2_table(1137) := 'yabuto|Wanjohi|Kipruto|David|Aden|Musa|Chepkwony|Sang|Okello|Oluoch|Ndirangu|Munyao|Murimi|Mumo|Kipc';
wwv_flow_imp.g_varchar2_table(1138) := 'hirchir|Mwikali|Njogu|Makena|Owuor|Ngeno|Mukami|Kerubo|Githinji|Joseph|Kipkirui|Makau|Kendi|Mwanzia|';
wwv_flow_imp.g_varchar2_table(1139) := 'Ondieki|Mutheu|Mulwa|Muema|Cherop|Muturi|Kiarie|Musembi|Waithira|Mutiso|Kipkemoi|Karani|Mwita|Waithe';
wwv_flow_imp.g_varchar2_table(1140) := 'ra|Kirimi|Gatwiri|Wambugu|Mumbi|Ruto|Makori|Nanjala|Maingi|Chacha|Mwangangi|Muhumed|Nduta|Abdalla|Nj';
wwv_flow_imp.g_varchar2_table(1141) := 'iru|Wanjiru|Tanui|Nasimiyu|Lagat|Mwiti|Kinuthia|Kawira|Ogutu|Farah|Rutto|Guyo|Oloo|Musau|Chirchir|Ye';
wwv_flow_imp.g_varchar2_table(1142) := 'gon|Nduku|Salim|Kwamboka|Kinya|Were|Too|Mutuma|Odero|James|Abdirahman|Bakari|Mutwiri|Gakii|Omollo|Mb';
wwv_flow_imp.g_varchar2_table(1143) := 'ithi|Wesonga|Mboya|Kipsang|Muia|Masinde|Gathoni|Muthui|Kiplimo|Kipngeno|Kipkemboi|Paul|Thuo|Nkatha|W';
wwv_flow_imp.g_varchar2_table(1144) := 'asike|Ngigi|Kipyegon|Mokaya|Mutembei|Wandera|Nderitu|Mwai|Nyawira|Kimeu|Jepchirchir|Okeyo|Naliaka|Ch';
wwv_flow_imp.g_varchar2_table(1145) := 'epkurui|Maiyo|Jeptoo|Samuel|Bundi|Ngari|Mbogo|Kipkosgei|Kipkurui|Chelimo|Baya|Ngala|Waithaka|Omari|A';
wwv_flow_imp.g_varchar2_table(1146) := 'oko|Kimanzi|Ooko|Njue|Mutugi|Ndunge|Kenga|Jepkoech|Bosire|Wangechi|Ntinyari|Kathambi|Morara|Nzioka|S';
wwv_flow_imp.g_varchar2_table(1147) := 'ifuna|Kanini|Mukhwana|Njau|Mwirigi|Munga|Tsuma|Kirwa|Kigen|Mathenge|Daniel|Odiwuor|Kassim|Mutie|Oket';
wwv_flow_imp.g_varchar2_table(1148) := 'ch|Mose|Kithinji|Kathure|Gichuki|Oyugi|Chepchirchir|Tonui|Mutethia|Muthomi|Jemutai|Safari|Cheruto|Ek';
wwv_flow_imp.g_varchar2_table(1149) := 'ai|Wangeci|Biwott|Tarus|Koskei|Keter|Nyaboke|Muthee|Kamande|Masika|Khaemba|Njambi|Wangila|Jerop|Moga';
wwv_flow_imp.g_varchar2_table(1150) := 'ka|Issak|Odera|Kitsao|Dahir|Jebet|Muthoka|Haji|Muigai|Kanana|Ojwang|Waswa|Nzomo|Munyoki|Osoro|Kemei|';
wwv_flow_imp.g_varchar2_table(1151) := 'Kombo|Hamisi|Wanyoike|Chesang|Mugendi|Owiti|Jeruto|Jepchumba|Ronoh|Yego|Baraka|Wahome|Ireri|Ogola|Mb';
wwv_flow_imp.g_varchar2_table(1152) := 'ithe|Aluoch|Salat|Nkirote|Bii|Nyamai|Musyimi|Ndanu|Ismail|Mbuthia|Muendo|Ngure|Limo|Ochola|Moses|Rop';
wwv_flow_imp.g_varchar2_table(1153) := '|Nyokabi|Komen|Kihara|Mmbone|Mumbua|Murugi|Boru|Ndinda|Sikuku|Muthama|Kiragu|Jepkosgei|Mukiri|Alio|W';
wwv_flow_imp.g_varchar2_table(1154) := 'anjira|Mokua|Opondo|Wario|Muinde|Suleiman|Orina|Khisa|Ouko|Jepkemboi|Michael|Murage|Jerotich|Kibe|Gi';
wwv_flow_imp.g_varchar2_table(1155) := 'tari|Chepchumba|Ndolo|Simon|Mugure|Abdille|Abdallah|Odoyo|Wawira|Kaingu|Ombati|Muhonja|Muriungi|Kime';
wwv_flow_imp.g_varchar2_table(1156) := 'li|Stephen|Nelima|Musili|Jepkorir|Deng|Toroitich|Obonyo|Ndiritu|Omwenga|Bashir|Kalama|Sigei|Nabwire|';
wwv_flow_imp.g_varchar2_table(1157) := 'Kurgat|Maritim|Okinyi|Wamaitha|Emmanuel|Rashid|Mbuvi|Thuku|Sammy|Bahati|Obiero|Ndege|Koome|Masai|Gac';
wwv_flow_imp.g_varchar2_table(1158) := 'heri|Charles|Nthenya|Kinoti|Muteti|Shikuku|Francis|Mwanza|Omolo|Nzuki|Mutegi|Kiptanui|Nzioki|Ayuma|M';
wwv_flow_imp.g_varchar2_table(1159) := 'asha|Chumba|Jillo|Nduati|Kitheka|Jerono|Wayua|Mureithi|Ewoi|Muthini|Khalif|Sila|Mwihaki|Maroa|Ekiru|';
wwv_flow_imp.g_varchar2_table(1160) := 'Jelimo|Ngina|Ojiambo|Chengo|Kagendo|Gichuhi|Matheka|Mulei|Kangogo|Brian|George|Mulongo|Murigi|Kiptum';
wwv_flow_imp.g_varchar2_table(1161) := '|Kipyego|Ndambuki|Kandie|Muasya|Warui|Kipkogei|Chebii|Kombe|Jepleting|Adow|Ngatia|Musungu|Njihia|Nya';
wwv_flow_imp.g_varchar2_table(1162) := 'kio|Murunga|Amondi|Wamuyu|Abdikadir|Muindi|Mwalimu|Chelagat|Mutemi|Thomas|Ndwiga|Serem|Athman|Yusuf|';
wwv_flow_imp.g_varchar2_table(1163) := 'Mong''''are|Kimanthi|Nyang''''au|Adongo|Mulinge|Muya|Chemtai|Nyamweya|Syombua|Kalume|Miriti|Mahat|Bwire|';
wwv_flow_imp.g_varchar2_table(1164) := 'Kamene|Wanza|Muchui|Muoki|Ndichu|Yator|Kimaiyo|Ndunda|Gikonyo|Bosibori|Mwania|Muthuri|Ogolla|Thurani';
wwv_flow_imp.g_varchar2_table(1165) := 'ra|Musimbi|Wabwire|Nyaguthii|Munywoki|Muhia|Kadenge|Thoya|Keya|Okech|Kiio|Mongare|Mwongeli|Ongeri|On';
wwv_flow_imp.g_varchar2_table(1166) := 'songo|Kennedy|Mbatha|Joshua|Nyangau|Githaiga|Maithya|Edin|Kanyi|Kogo|Muchoki|Maloba|Isaac|Kimotho|Nd';
wwv_flow_imp.g_varchar2_table(1167) := 'iema|Muuo|Etyang|Kipkemei|Ngui|Julius|Njuki|Kipleting|Wabwile|Jepkirui|Sakwa|Kananu|Masila|Marwa|Mut';
wwv_flow_imp.g_varchar2_table(1168) := 'indi|Kundu|Amina|Kang''''ethe|Mwaka|Onyancha|Galgallo|Kaburu|Godana|Kilonzi|Bare|Muchai|Wasonga|Naibei';
wwv_flow_imp.g_varchar2_table(1169) := '|Ngumbao|Kiboi|Koros|Rioba|Philip|Nyambane|Muthiani|Ngunjiri|King''''ori|Ndiwa|Wangare|Esekon|Kivuva|K';
wwv_flow_imp.g_varchar2_table(1170) := 'obia|Akumu|Ramadhan|Esinyen|Apiyo|Kasyoka|Wako|Situma|Kadzo|Mbula|Gichuru|Oyoo|William|Gitahi|Nyamaw';
wwv_flow_imp.g_varchar2_table(1171) := 'i|Kibor|Nzau|Wawire|Ngei|Cheboi|Kagwiria|Okelo|Jimale|Moseti|Patrick|Martin|Kitur|Ogeto|Kiiru|Ogega|';
wwv_flow_imp.g_varchar2_table(1172) := 'Khamis|Mawira|Jepngetich|Nur|Boke|Maundu|Tuwei|Nyangweso|Wakhungu|Kungu|Wanjau|Ekal|Lumumba|Sitienei';
wwv_flow_imp.g_varchar2_table(1173) := '|Muraya|Kiilu|Nyamu|Orwa|Waruguru|Kimaru|Fondo|Muktar|Kangethe|Jepkogei|Nasambu|Ekeno|Ngige|Obuya|Ok';
wwv_flow_imp.g_varchar2_table(1174) := 'emwa|Robert|Robi|Matano|Mwongela|Mutia|Chumo|Karambu|Munyi|Sitati|Samson|Jacob|Gacheru|Cherutich|Abu';
wwv_flow_imp.g_varchar2_table(1175) := 'bakar|Chepkemboi|Abuga|Mangale|Muthike|Jackson|Mahamud|Mawia|Kimtai|Nyagaka|Wambura|Odira|Khamisi|Ku';
wwv_flow_imp.g_varchar2_table(1176) := 'rui|Murangiri|Kairu|Omwoyo|Mbae|Lelei|Issa|Kung''''u|Samoei|Obare|Theuri|Samwel|Wanga|Roba|Soita|Mbaab';
wwv_flow_imp.g_varchar2_table(1177) := 'u|Mwero|Ogada|Lewa|Kingori|Obara|Mutanu|Sawe|Murungi|Awinja|Nthiga|Siele|Baraza|Nzai|Mogire|Mwinzi|M';
wwv_flow_imp.g_varchar2_table(1178) := 'aluki|Muthengi|Bor|Galgalo|Mbiti|Mauti|Oginga|Dida|Nzilani|Micheni|Mitei|Munyua|Ogweno|Terer|Nafula|';
wwv_flow_imp.g_varchar2_table(1179) := 'Titus|Ekitela|Ambani|Amoit|Halake|Naserian|Cheyech|Mumbe|Gati|Maweu|Karuga|Ndoro|Ruwa|Mwadime|Duba|K';
wwv_flow_imp.g_varchar2_table(1180) := 'ageha|Muga|Krop|Daud|Nyanchama|Muchira|Akello|Emuria|Chesire|Musee|Njoka|Ondiek|Anyona|Zawadi|Huka|M';
wwv_flow_imp.g_varchar2_table(1181) := 'ahamed|Yakub|Kaberia|Kisilu|Thiong''''o|Busienei|Wavinya|Mwinyi|Ombui|Mukundi|Hillow|Keitany|Chomba|Bu';
wwv_flow_imp.g_varchar2_table(1182) := 'lle|Mwema|Karuri|Mwathi|Soi|Evans|Imali|Migwi|Ratemo|Mutio|Alex|Misiko|Oyaro|Abdulla|Benson|Kithome|';
wwv_flow_imp.g_varchar2_table(1183) := 'Mwamburi|Ngome|Ayieko|Okuku|Richard|Eyanae|Kabiru|Gichohi|Nyabuti|Abdow|Joel|Kitonga|Nyale|Towett|Ma';
wwv_flow_imp.g_varchar2_table(1184) := 'ti|Ekidor|Mutahi|Mmboga|Oduori|Changawa|Nyangaresi|Maranga|Kalekye|Wanje|Kiama|Muimi|Gicheru|Salah|E';
wwv_flow_imp.g_varchar2_table(1185) := 'regae|Jarso|Sande|Kakai|Swaleh|Chenangat|Ngao|Nyambu|Onditi|Bonaya|Nandwa|Chebon|Mwakio|Mnangat|Lema';
wwv_flow_imp.g_varchar2_table(1186) := 'yian|Erupe|Rugut|Mule|Gona|Maitha|Gachoki|Musila|Odinga|Dennis|Gichana|Chai|Muhoro|Jama|Nakhumicha|J';
wwv_flow_imp.g_varchar2_table(1187) := 'emeli|Mundia|Junior|Wamboi|Vaati|Fundi|Menza|Muchemi|Victor|Kituku|Kiogora|Makungu|Pkemoi|Jumba|Wech';
wwv_flow_imp.g_varchar2_table(1188) := 'uli|Moturi|Kajuju|Mayaka|Yatich|Mbaka|Kibiwott|Mucheru|Gure|Ngaruiya|Okongo|Munguti|Ngotho|Mamo|Muth';
wwv_flow_imp.g_varchar2_table(1189) := 'ami|Benard|Ondari|Otiende|Mzungu|Ombasa|Kimosop|Jelagat|Muchangi|Aloo|Abdiaziz|Andrew|Gedi|Matara|Ke';
wwv_flow_imp.g_varchar2_table(1190) := 'lvin|Mwendia|Karwitha|Apondi|Barongo|Chepkwemoi|Mukoya|Minayo|Masese|Ziro|Kwemoi|Wakio|Munyiva|Saidi';
wwv_flow_imp.g_varchar2_table(1191) := '|Chepkosgei|Yaa|Achola|Mambo|Jelle|Tirop|Mbui|Komora|Abdifatah|Mageto|Kamathi|Kanja|Gathogo|Mutune|W';
wwv_flow_imp.g_varchar2_table(1192) := 'abomba|Kiptui|Gatimu|Jomo|Meli|Dagane|Mutungi|Mumba|Weru|Kabui|Kaimenyi|Kimemia|Musya|Jepkemei|Saina';
wwv_flow_imp.g_varchar2_table(1193) := '|Kaloki|Elijah|Kibiwot|Kiti|Nzisa|Kiema|Mogeni|Wanjugu|Birgen|Shariff|Gachanja|Osiemo|Onyiego|Iminza';
wwv_flow_imp.g_varchar2_table(1194) := '|Muange|Musumba|Bore|Saruni|Mwololo|Abdinoor|Awadh|Jefwa|Lumbasi|Wangai|Nyoike|Wanzala|Saitoti|Adam|';
wwv_flow_imp.g_varchar2_table(1195) := 'Mogere|Benjamin|Kaari|Muraguri|Sidi|Nyawa|Kevin|Omweri|Maghanga|Nafuna|Angwenyi|Okonkwo|Olawale|Obi|';
wwv_flow_imp.g_varchar2_table(1196) := 'Abiola|Uche|Ogunleye|Nnamani|Adetokunbo|Ojo|Ekwueme|Oshodi|Akinwale|Obasanjo|Oyekan|Amahle|Andile|An';
wwv_flow_imp.g_varchar2_table(1197) := 'ele|Ayanda|Ayize|Bantwini|Bayeni|Bhedleni|Bele|Bhebhe|Bhejelibomvu|Bhembe|Bhengu|Bhensela|Bhovungana';
wwv_flow_imp.g_varchar2_table(1198) := '|Bhungane|Bikelwayo|Bikwayo|Binda|Biyase|Biyela|Blose|Bophela|Boyabenyathi|Bukhosini|Caluza|Cebisa|C';
wwv_flow_imp.g_varchar2_table(1199) := 'ebekhulu|Cenge|Chagwe|Chamane|Chibi|Chibini|Chiliza|Cibane|Chonco|Cwalile|Delwayo|Dikane|Dimba|Dimba';
wwv_flow_imp.g_varchar2_table(1200) := 'ne|Dimbani|Dinabantu|Dinangwe|Dindela|Dingila|Dindi|Dinwa|Dlabane|Dlabazane|Dladla|Dlakadla|Dlakela|';
wwv_flow_imp.g_varchar2_table(1201) := 'Dlamane|Dlambula|Dlamdaka|Dlamlenze|Dlangamandla|Dlawuza|Dlebenkomo|Dlodlo|Dlomo|Dludla|Dludlu|Dlung';
wwv_flow_imp.g_varchar2_table(1202) := 'wana|Doncabe|Donda|Dubandlela|Dubazane|Dube|Dukada|Duma|Dumakude|Dumisa|Dunge|Duyaza|Duze|Dwala|Fihl';
wwv_flow_imp.g_varchar2_table(1203) := 'ela|Fakazi|Fakude|Fanisa|Fenya|Gabadela|Gabela|Gabhezi|Gabhisa|Gadlela|Gazu|Galu|Gagashe|Gama|Gambu|';
wwv_flow_imp.g_varchar2_table(1204) := 'Gambuse|Gamede|Gasa|Gasela|Gatsheni|Gcaba|Gcaleka|Gcugcwa|Gcumisa|Gcwabe|Gcwensa|Gebashe|Gebhezi|Ged';
wwv_flow_imp.g_varchar2_table(1205) := 'eza|Gence|Gengeshe|Gigaba|Gina|Gininda|Goba|Gobhozi|Godide|Goje|Gotsholo|Gubeshe|Gubhela|Gubhuza|Gub';
wwv_flow_imp.g_varchar2_table(1206) := 'ulundu|Gugushe|Gule|Guliwe|Guma|Gumede|Gumbi|Gwacela|Gwagwa|Gwala|Gwamanda|Gwanyana|Gwija|Gxabhashe|';
wwv_flow_imp.g_varchar2_table(1207) := 'Hadebe|Hangala|Hhoyiyane|Hlabisa|Hlabangane|Hlatshwayo|Hlela|Hlengwa|Hlomuka|Hlongwa|Hlongwane|Hloph';
wwv_flow_imp.g_varchar2_table(1208) := 'e|Hlubi|Hlumakazi|Jali|Jamasijadu|Jamile|Jele|Jibela|Jili|Jiyane|Jobe|Jokiwe|Juqula|Khaba|Khabalidak';
wwv_flow_imp.g_varchar2_table(1209) := 'a|Khambule|Khanyeza|Khanyile|Khaphela|Khathi|Khathini|Khathide|Khawula|Kheswa|Khezokhulu|Kholose|Kho';
wwv_flow_imp.g_varchar2_table(1210) := 'mo|Khonjwayo|Khosini|Khoza|Khuba|Khubisa|Khuboni|Khukhuza|Khulu|Khuluse|Khumalo|Khumbuza|Khuyameni|K';
wwv_flow_imp.g_varchar2_table(1211) := 'huzwayo|Khwela|Khwane|Kubheka|Kunene|Kweyama|Lakaza|Lamula|Langa|Lange|Langeni|Lembede|Longode|Lubel';
wwv_flow_imp.g_varchar2_table(1212) := 'o|Ludonga|Lukhele|Luqe|Lutholoni|Luthuli|Luvuno|Lwandle|Mabanga|Mabaso|Mabhena|Mabhoko|Mabizela|Mabi';
wwv_flow_imp.g_varchar2_table(1213) := 'ka|Mabhodla|Mbutho|Mabuya|Mabuyakhulu|Mabuza|Macingwane|Made|Madela|Madi|Madiba|Madide|Madinane|Madl';
wwv_flow_imp.g_varchar2_table(1214) := 'ala|Madlanduna|Madondo|Madonsela|Mdotshana|Maduma|Maduna|Malembe|Madlula|Madziba|Mafobo|Mafulela|Maf';
wwv_flow_imp.g_varchar2_table(1215) := 'uleka|Magagula|Magubane|Magutshwa|Magwaza|Mageba|Mahaye|Mahamba|Mahlaba|Mahlalela|Mahlangu|Mahlase|M';
wwv_flow_imp.g_varchar2_table(1216) := 'ahlinza|Mahlobo|Mahulube|Majoka|Majola|Majozi|Makhanya|Makhaye|Makhathini|Makhaza|Makhedama|Makhoba|';
wwv_flow_imp.g_varchar2_table(1217) := 'Makhubo|Makhulukhulu|Makhunga|Malambule|Malevu|Malinga|Maluleka|Mamba|Manana|Mangcamane|Mantshinga|M';
wwv_flow_imp.g_varchar2_table(1218) := 'angede|Mangena|Mangethe|Manyoni|Mnqamu|Manqele|Mnquhe|Manzi|Manzini|Manzezulu|Maphalala|Maphindela|M';
wwv_flow_imp.g_varchar2_table(1219) := 'aphanga|Maphisa|Mapholoba|Maphumulo|Masango|Maseko|Mashaba|Mashasha|Mashinini|Mashimane|Mashiya|Masi';
wwv_flow_imp.g_varchar2_table(1220) := 'bekela|Masikane|Masina|Masinga|Masilela|Masondo|Masuku|Mathaba|Mathebela|Mathebula|Mathenjwa|Matheth';
wwv_flow_imp.g_varchar2_table(1221) := 'a|Mathula|Mathunjwa|Mathibela|Mathonsi|Mathwasa|Mavela|Mavundla|Mavuso|Mawanda|Mawewe|Mayeza|Mayise|';
wwv_flow_imp.g_varchar2_table(1222) := 'Mayisela|Mazalankosi|Mazibuko|Mazwi|Mbamali|Magoza|Magolwana|Magononde|Maziya|Mbanjwa|Mbatshazwa|Mag';
wwv_flow_imp.g_varchar2_table(1223) := 'ujwa|Mbembe|Mbekwa|Mbende|Mbeje|Mbhele|Mbhense|Mbhodwe|Mbhobho|Mbhulangwe|Mbili|Mbokazi|Mboko|Mbonam';
wwv_flow_imp.g_varchar2_table(1224) := 'bi|Mbongwa|Mbongwe|Mbotho|Mbonane|Mboyisa|Mbulazi|Mbulaze|Mbuli|Mbungela|Mbunjwa|Mbuyazi|Mbuyisa|Mbu';
wwv_flow_imp.g_varchar2_table(1225) := 'yise|Mcambe|Mcambi|Mcanco|Mcanyana|Mchunu|Mcoyi|Mcwaye|Mcusi|Mdaka|Mdakane|Mdladla|Mdlalose|Mdlanyok';
wwv_flow_imp.g_varchar2_table(1226) := 'a|Mdletshe|Mdlenevu|Mdluli|Mdlumbi|Mdonswa|Mdunge|Mehloluhlaza|Memela|Nenzi|Menziwa|Meyiwa|Mfeka|Mfu';
wwv_flow_imp.g_varchar2_table(1227) := 'si|Mgabhi|Mgabadeli|Mgasela|Mgazi|Mgcaleka|Mgenge|Mgobhozi|Mgilija|Mhayise|Mhlabandlovu|Mhlambo|Mhla';
wwv_flow_imp.g_varchar2_table(1228) := 'nga|Mhlangu|Mhlanya|Mhlongo|Mhlongwane|Mhlophe|Mhlungu|Mgwaba|Miya|Mjadu|Mjoli|Mjwara|Mkhabela|Mkhan';
wwv_flow_imp.g_varchar2_table(1229) := 'dlela|Mkhathini|Mkhatshwa|Mkhithi|Mkhize|Mkhokeleleki|Mkholo|Mkhumbuzi|Mkhungo|Mkhonza|Mkhwananzi|Ml';
wwv_flow_imp.g_varchar2_table(1230) := 'aba|Mlalane|Mlalazi|Mlambo|Mlangatshe|Mlangeni|Mlawula|Mlungisi|Mlungwana|Mlondo|Mlotshwa|Mncube|Mnc';
wwv_flow_imp.g_varchar2_table(1231) := 'wabe|Mncwanga|Mngadi|Mngoma|Mngomezulu|Mngwemkhulu|Mngwengwe|Mnguni|Mnikathi|Mnisi|Mnomiya|Mnqayi|Mq';
wwv_flow_imp.g_varchar2_table(1232) := 'ungebe|Mnyandu|Mnyoni|Mondise|Motha|Mnangwe|Mntambo|Mntimande|Mtolo|Mntungwa|Mnyamande|Mpangazitha|M';
wwv_flow_imp.g_varchar2_table(1233) := 'panza|Mphankomo|Mphahlwa|Mphazima|Mphephethwa|Mphemba|Mpila|Mpikela|Mpofana|Mpungose|Mpumuza|Mpunzan';
wwv_flow_imp.g_varchar2_table(1234) := 'a|Mqadi|Msane|Msani|Msamkhulu|Mshazi|Mshengu|Mshibe|Msibi|Mshikela|Mshikila|Mshiyane|Mseleku|Msimang';
wwv_flow_imp.g_varchar2_table(1235) := '|Msindazwe|Msokazi|Msomi|Msweli|Msuthu|Mthabela|Mthalane|Mthanti|Mthembu|Mthethwa|Mtimande|Mthimkhul';
wwv_flow_imp.g_varchar2_table(1236) := 'u|Mthinti|Mthiya|Mthiyane|Mthombeni|Mthonti|Mtshali|Mtumaseli|Mtuswa|Musi|Mvelase|Mveni|Mvubu|Mvuyan';
wwv_flow_imp.g_varchar2_table(1237) := 'a|Myeza|Mwandla|Mwelase|Myeni|Mzila|Mzileni|Mzilankatha|Mzimela|Mzizi|Mzobe|Mzolo|Mzomba|Mzoneli|Mzu';
wwv_flow_imp.g_varchar2_table(1238) := 'kase|Mzulwini|Nala|Nandisa|Ncala|Ncwaba|Ncwane|Ndandali|Ntenga|Ncama|Ngcamane|Ncanana|Ncongwane|Ncub';
wwv_flow_imp.g_varchar2_table(1239) := 'e|Ncusi|Ndaba|Ndabandaba|Ndabase|Ndabansele|Ndawo|Njomane|Nkundlande|Ndabezitha|Ndawonde|Ndima|Ndima';
wwv_flow_imp.g_varchar2_table(1240) := 'nde|Ndinisa|Ndiyema|Ndlala|Ndlandla|Ndlangamandla|Ndlanzi|Ndlanya|Ndlela|Ndlondlo|Ndosi|Ndondakusuka';
wwv_flow_imp.g_varchar2_table(1241) := ''';'||wwv_flow.LF||
'    l_first_name_catalog(13) := ''Emir|Zeynep|Kerem|Elif|Mert|Selin|Can|Derya|Arda|Ece|Berk|Asli|D';
wwv_flow_imp.g_varchar2_table(1242) := 'eniz|Burak|Ceren|Onur|Melis|Tolga|Esra|Kaan|Aylin|Bahar|Cagla|Ebru|Emine|Fatma|Hakan|Ilker|Leyla|Mur';
wwv_flow_imp.g_varchar2_table(1243) := unistr('at|Nazli|Pinar|Sibel|Sinan|Tugba|Umut|Yasemin|Yusuf|Zehra|Abdi\015F|Abdulbekir|Abdulgazi|Abdulkadir|Abdu');
wwv_flow_imp.g_varchar2_table(1244) := unistr('lmenaf|Abdulsemet|Abdurrahman|Abd\00FClahat|Abd\00FClcemal|Abd\00FClhadi|Abd\00FClkerim|Abd\00FClsamed|Abd\00FCrre\015Fit|Abid|A');
wwv_flow_imp.g_varchar2_table(1245) := unistr('buzar|Acar|Aclan|Adak|Adasal|Adlan|Ad\0131g\00FCn|Afer|Ahat|Ahsen|Akalan|Akar|Akatay|Akba\015F|Akbo\011Fa|Akcivan|Ak');
wwv_flow_imp.g_varchar2_table(1246) := unistr('dora|Akdurmu\015F|Akg\00F6l|Akif|Akkerman|Akmaner|Aksay|Aks\00F6\011F\00FCt|Aktem\00FCr|Akver|Ak\00E7abay|Ak\00E7asu|Ak\00F6z|Ak\0131nal|Ala');
wwv_flow_imp.g_varchar2_table(1247) := 'addin|Alaeddin|Alanalp|Alattin|Alcan|Alexandru|Aliabbas|Aliihsan|Aliseydi|Alkor|Almus|Alparslan|Alpc';
wwv_flow_imp.g_varchar2_table(1248) := unistr('an|Alpin|Alps\00FC|Alsoy|Alto\011Fan'';'||wwv_flow.LF||
'    l_last_name_catalog(13) := ''Yilmaz|Kaya|Demir|Sahin|Celik|Aydin|A');
wwv_flow_imp.g_varchar2_table(1249) := 'rslan|Ozdemir|Koc|Kurt|Aksoy|Polat|Tas|Kaplan|Erdem|Guler|Tekin|Karaca|Bulut|Eren|Acar|Altun|Aslan|B';
wwv_flow_imp.g_varchar2_table(1250) := unistr('ayram|Bozkurt|Cakir|Candan|Dogan|Duman|Ergin|Gok|Gunes|Korkmaz|Sari|Sezer|Ucar|Yildirim|Yuksel|Y\0131lma');
wwv_flow_imp.g_varchar2_table(1251) := unistr('z|Y\0131ld\0131r\0131m|T\00FCrk|Yorulmaz|Erdo\011Fan|\00C7orlu|Sakarya|Yaman|Man\00E7o|Aksu|Ak\00E7ay|Akar|Bilir|Bilgin|Y\00FCksel|Erasl');
wwv_flow_imp.g_varchar2_table(1252) := unistr('an|Han\00E7er|Hayrio\011Flu|\015Eama|Erg\00FCl|Arsoy|K\0131sak\00FCrek|G\00FClen|Seven|\015Eafak|Dumanl\0131|Erta\015F|G\00FC\00E7l\00FC|Soylu|Zorlu|F\0131r');
wwv_flow_imp.g_varchar2_table(1253) := unistr('at|Duran|Durmu\015F|Durdu|Zengin|Teveto\011Flu|Mans\0131z|\015Eener|\015Eensoy|\00DClker|Tarhan|Demirel'';'||wwv_flow.LF||
'    l_first_name_c');
wwv_flow_imp.g_varchar2_table(1254) := 'atalog(12) := ''Omar|Layla|Karim|Salma|Hadi|Mariam|Tarek|Lina|Samir|Dalia|Youssef|Noor|Rami|Hana|Fadi';
wwv_flow_imp.g_varchar2_table(1255) := '|Amal|Nabil|Rana|Ziad|Huda|Amina|Basma|Farid|Hanan|Imran|Jamal|Khaled|Laila|Majid|Nadia|Rasha|Samia|';
wwv_flow_imp.g_varchar2_table(1256) := 'Tariq|Walid|Yasmin|Zainab|Salim|Hisham|Maha'';'||wwv_flow.LF||
'    l_last_name_catalog(12) := ''Abdallah|Darwish|Farou';
wwv_flow_imp.g_varchar2_table(1257) := 'k|Haddad|Hamdan|Khalil|Mansour|Nassar|Rahman|Saleh|Sami|Sharif|Soliman|Yasin|Zaki|Mahmoud|Fawzi|Abba';
wwv_flow_imp.g_varchar2_table(1258) := 's|Ali|Aziz|Bakr|Bishara|Eid|Fadel|Habib|Hamad|Ibrahim|Ismail|Jaber|Kassem|Latif|Morsi|Qasim|Rashed|S';
wwv_flow_imp.g_varchar2_table(1259) := 'aad|Taher'';'||wwv_flow.LF||
'    l_first_name_catalog(11) := ''Noam|Yael|Eitan|Tamar|Lior|Shira|Omer|Adi|Amit|Ronen|Ma';
wwv_flow_imp.g_varchar2_table(1260) := 'ya|Gal|Talia|Erez|Neta|Itai|Dana|Yonatan|Roni|Sivan|Avital|Bar|Dalia|Eden|Hila|Ilan|Lavi|Meital|Niv|';
wwv_flow_imp.g_varchar2_table(1261) := 'Or|Ronit|Shani|Shlomi|Talya|Uriel|Yarden|Yaara|Orit|Shaked'';'||wwv_flow.LF||
'    l_last_name_catalog(11) := ''Cohen|L';
wwv_flow_imp.g_varchar2_table(1262) := 'evi|Mizrahi|Peretz|Shalev|Barak|Friedman|Golan|Hadad|Kaplan|Klein|Meir|Nissim|Ohayon|Rosen|Shamir|Ta';
wwv_flow_imp.g_varchar2_table(1263) := 'l|Weiss|Zohar|Azulay|Biton|Dahan|Dayan|Efrati|Goldstein|Katz|Mor|Ohana|Shapira|Stern|Tzur|Vaknin|Sel';
wwv_flow_imp.g_varchar2_table(1264) := 'a|Rosenberg'';'||wwv_flow.LF||
'    l_first_name_catalog(10) := ''Minjun|Seoyeon|Jihoon|Haeun|Doyun|Soojin|Hyunwoo|Jimi';
wwv_flow_imp.g_varchar2_table(1265) := 'n|Taehyun|Yejun|Eunji|Seungmin|Hyejin|Joonho|Nari|Donghyun|Yuna|Sangho|Bora|Jinwoo|Ara|Daeun|Eunchae';
wwv_flow_imp.g_varchar2_table(1266) := '|Haejin|Hyewon|Jihye|Jisu|Mirae|Minseo|Seunghyun|Soomin|Taemin|Woojin|Yeeun|Yeonwoo|Youngjin|Yujin|E';
wwv_flow_imp.g_varchar2_table(1267) := 'unseo|Haneul'';'||wwv_flow.LF||
'    l_last_name_catalog(10) := ''Kim|Lee|Park|Choi|Jung|Kang|Cho|Yoon|Jang|Lim|Han|Shi';
wwv_flow_imp.g_varchar2_table(1268) := 'n|Seo|Kwon|Hwang|Ahn|Song|Jeon|Hong|Moon|Bae|Baek|Byun|Chae|Ha|Heo|Joo|Ko|Koo|Nam|No|Oh|Ryu|Son|Yang';
wwv_flow_imp.g_varchar2_table(1269) := '|Yoo|Bok'';'||wwv_flow.LF||
'    l_first_name_catalog(9) := ''Haruto|Yui|Ren|Aoi|Sota|Hina|Kaito|Mei|Daiki|Sakura|Riku|';
wwv_flow_imp.g_varchar2_table(1270) := 'Mio|Yuto|Rin|Takumi|Akari|Hiroto|Nanami|Kota|Miku|Akira|Ayaka|Chihiro|Emi|Fumiko|Kaori|Kenji|Makoto|';
wwv_flow_imp.g_varchar2_table(1271) := 'Naoki|Natsuki|Reika|Shiori|Shota|Tomomi|Yoko|Yuki|Yuna|Masato|Sayaka'';'||wwv_flow.LF||
'    l_last_name_catalog(9) :=';
wwv_flow_imp.g_varchar2_table(1272) := ' ''Sato|Suzuki|Takahashi|Tanaka|Watanabe|Ito|Yamamoto|Nakamura|Kobayashi|Kato|Yoshida|Yamada|Sasaki|Y';
wwv_flow_imp.g_varchar2_table(1273) := 'amaguchi|Matsumoto|Inoue|Kimura|Hayashi|Shimizu|Mori|Abe|Fujii|Fujita|Hasegawa|Ishikawa|Kondo|Maeda|';
wwv_flow_imp.g_varchar2_table(1274) := 'Maruyama|Matsuda|Miyazaki|Nishimura|Ogawa|Okada|Shibata|Takeda|Ueda|Wada|Yokoyama|Sakai'';'||wwv_flow.LF||
'    l_firs';
wwv_flow_imp.g_varchar2_table(1275) := 't_name_catalog(8) := ''Wei|Li|Jie|Xinyi|Yuchen|Meilin|Hao|Qian|Jun|Lin|Zihan|Ming|Rui|Yan|Chen|Lili|W';
wwv_flow_imp.g_varchar2_table(1276) := 'en|Shuo|Ning|Yue|An|Bo|Fang|Hong|Jing|Lan|Lei|Lian|Min|Ping|Tao|Tian|Xin|Xiu|Yang|Yi|Yao|Zhen|Zhu'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1277) := '    l_last_name_catalog(8) := ''Chen|Wang|Li|Zhang|Liu|Huang|Zhao|Wu|Zhou|Xu|Sun|Hu|Guo|He|Gao|Lin|Lu';
wwv_flow_imp.g_varchar2_table(1278) := 'o|Tang|Deng|Shen|Bai|Cai|Cao|Cui|Fan|Fang|Feng|Han|Jiang|Ma|Meng|Qiao|Qin|Tian|Wei|Xie|Yang|Yu'';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(1279) := ' l_first_name_catalog(7) := ''Wei|Jia|Mei|Hana|Amir|Nur|Siti|Arif|Daniel|Liyana|Farah|Paolo|Maria|Car';
wwv_flow_imp.g_varchar2_table(1280) := 'lo|Andrea|Miguel|Angela|Rizal|Aisha|Kenji|Adi|Budi|Citra|Dewi|Faisal|Intan|Joko|Putri|Rani|Sari|Sury';
wwv_flow_imp.g_varchar2_table(1281) := 'a|Wira|Yusuf|Lani|Rina|Dimas|Rizky|Taufik|Yani|Abyasa|Ade|Adhiarja|Adiarja|Adika|Adikara|Adinata|Adi';
wwv_flow_imp.g_varchar2_table(1282) := 'tya|Agus|Ajiman|Ajimat|Ajimin|Ajiono|Akarsana|Alambana|Among|Anggabaya|Anom|Argono|Aris|Arta|Artanto';
wwv_flow_imp.g_varchar2_table(1283) := '|Artawan|Arsipatra|Asirwada|Asirwanda|Aslijan|Asmadi|Asman|Asmianto|Asmuni|Aswani|Atma|Atmaja|Bagas|';
wwv_flow_imp.g_varchar2_table(1284) := 'Bagiya|Bagus|Bagya|Bahuraksa|Bahuwarna|Bahuwirya|Bajragin|Bakda|Bakiadi|Bakianto|Bakidin|Bakijan|Bak';
wwv_flow_imp.g_varchar2_table(1285) := 'iman|Bakiono|Bakti|Baktiadi|Baktianto|Baktiono|Bala|Balamantri|Balangga|Balapati|Balidin|Balijan|Bam';
wwv_flow_imp.g_varchar2_table(1286) := 'bang|Banara|Banawa|Banawi|Bancar|Cagak|Cager|Cahyadi|Cahyanto|Cahya|Cahyo|Cahyono|Caket|Cakrabirawa|';
wwv_flow_imp.g_varchar2_table(1287) := 'Cakrabuana|Cakrajiya|Cakrawala|Cakrawangsa|Candra|Chandra|Candrakanta|Capa|Caraka|Carub|Catur|Catura';
wwv_flow_imp.g_varchar2_table(1288) := 'ngga|Cawisadi|Cawisono|Cawuk|Cayadi|Cecep|Cemani|Cemeti|Cemplunk|Cengkal|Cengkir|Dacin|Dadap|Dadi|Da';
wwv_flow_imp.g_varchar2_table(1289) := 'gel|Daliman|Dalimin|Daliono|Damar|Damu|Danang|Daniswara|Danu|Danuja|Dariati|Darijan|Darimin|Darmaji|';
wwv_flow_imp.g_varchar2_table(1290) := 'Darman|Darmana|Darmanto|Darsirah|Dartono|Daru|Daruna|Daryani|Dasa|Digdaya|Dimaz|Dipa|Dirja|Drajat|Dw';
wwv_flow_imp.g_varchar2_table(1291) := 'i|Dono|Dodo|Edi|Eka|Elon|Eluh|Eman|Emas|Embuh|Emong|Empluk|Endra|Enteng|Estiawan|Estiono|Eko|Edison|';
wwv_flow_imp.g_varchar2_table(1292) := 'Edward|Elvin|Erik|Emil|Ega|Emin|Eja|Gada|Gadang|Gaduh|Gaiman|Galak|Galang|Galar|Galih|Galiono|Galuh|';
wwv_flow_imp.g_varchar2_table(1293) := 'Galur|Gaman|Gamani|Gamanto|Gambira|Gamblang|Ganda|Gandewa|Gandi|Ganep|Gangsa|Gangsar|Ganjaran|Gantar';
wwv_flow_imp.g_varchar2_table(1294) := '|Gara|Garan|Garang|Garda|Gatot|Gatra|Gilang|Ghani|Gading|Hairyanto|Hardana|Hardi|Harimurti|Harja|Har';
wwv_flow_imp.g_varchar2_table(1295) := 'jasa|Harjaya|Harjo|Harsana|Harsanto|Harsaya|Hartaka|Hartana|Harto|Hasta|Heru|Himawan|Hadi|Halim|Hasi';
wwv_flow_imp.g_varchar2_table(1296) := 'm|Hasan|Hendra|Hendri|Heryanto|Hamzah|Hari|Imam|Indra|Irwan|Irsad|Ikhsan|Irfan|Ian|Ibrahim|Ibrani|Is';
wwv_flow_imp.g_varchar2_table(1297) := 'mail|Irnanto|Ilyas|Ibun|Ivan|Ikin|Ihsan|Jabal|Jaeman|Jaga|Jagapati|Jagaraga|Jail|Jaiman|Jaka|Jarwa|J';
wwv_flow_imp.g_varchar2_table(1298) := 'arwadi|Jarwi|Jasmani|Jaswadi|Jati|Jatmiko|Jaya|Jayadi|Jayeng|Jinawi|Jindra|Jumadi|Jumari|Jamal|Jamil';
wwv_flow_imp.g_varchar2_table(1299) := '|Jais|Jefri|Johan|Jono|Kacung|Kajen|Kambali|Kamidin|Kariman|Karja|Karma|Karman|Karna|Karsa|Karsana|K';
wwv_flow_imp.g_varchar2_table(1300) := 'arta|Kasiran|Kasusra|Kawaca|Kawaya|Kayun|Kemba|Kenari|Kenes|Kuncara|Kunthara|Kusuma|Kadir|Kala|Kalim';
wwv_flow_imp.g_varchar2_table(1301) := '|Kurnia|Kanda|Kardi|Karya|Kasim|Kairav|Kenzie|Kemal|Kamal|Koko|Labuh|Laksana|Lamar|Lanang|Langgeng|L';
wwv_flow_imp.g_varchar2_table(1302) := 'anjar|Lantar|Lega|Legawa|Lembah|Liman|Limar|Luhung|Lukita|Luluh|Lulut|Lurhur|Luwar|Luwes|Latif|Lasma';
wwv_flow_imp.g_varchar2_table(1303) := 'nto|Lukman|Luthfi|Leo|Luis|Lutfan|Lasmono|Laswi|Mahesa|Makara|Makuta|Manah|Maras|Margana|Mariadi|Mar';
wwv_flow_imp.g_varchar2_table(1304) := 'sudi|Martaka|Martana|Martani|Marwata|Maryadi|Maryanto|Mitra|Mujur|Mulya|Mulyanto|Mulyono|Mumpuni|Mun';
wwv_flow_imp.g_varchar2_table(1305) := 'i|Mursita|Murti|Mustika|Maman|Mahmud|Mahdi|Mahfud|Malik|Muhammad|Mustofa|Marsito|Mursinin|Nalar|Nara';
wwv_flow_imp.g_varchar2_table(1306) := 'di|Nardi|Niyaga|Nrima|Nugraha|Nyana|Narji|Nasab|Nasrullah|Nasim|Najib|Najam|Nyoman|Olga|Ozy|Omar|Opa';
wwv_flow_imp.g_varchar2_table(1307) := 'n|Oskar|Oman|Okto|Okta|Opung|Paiman|Panca|Pangeran|Pangestu|Pardi|Parman|Perkasa|Praba|Prabu|Prabawa';
wwv_flow_imp.g_varchar2_table(1308) := '|Prabowo|Prakosa|Pranata|Pranawa|Prasetya|Prasetyo|Prayitna|Prayoga|Prayogo|Purwadi|Purwa|Purwanto|P';
wwv_flow_imp.g_varchar2_table(1309) := 'anji|Pandu|Prima|Putu|Raden|Raditya|Raharja|Rama|Rangga|Reksa|Respati|Rusman|Rosman|Rahmat|Rahman|Re';
wwv_flow_imp.g_varchar2_table(1310) := 'ndy|Reza|Rizki|Ridwan|Rudi|Radit|Radika|Rafi|Rafid|Raihan|Salman|Saadat|Saiful|Slamet|Samsul|Soleh|S';
wwv_flow_imp.g_varchar2_table(1311) := 'imon|Sabar|Sabri|Sidiq|Satya|Setya|Saka|Sakti|Taswir|Tedi|Teddy|Taufan|Tomi|Tasnim|Teguh|Tasdik|Timb';
wwv_flow_imp.g_varchar2_table(1312) := 'ul|Tirta|Tirtayasa|Tri|Tugiman|Umar|Usman|Uda|Umay|Unggul|Utama|Umaya|Upik|Viktor|Vino|Vinsen|Vero|V';
wwv_flow_imp.g_varchar2_table(1313) := 'ega|Viman|Virman|Wahyu|Wisnu|Wadi|Wardi|Warji|Waluyo|Wakiman|Wage|Wardaya|Warsa|Warsita|Warta|Wasis|';
wwv_flow_imp.g_varchar2_table(1314) := 'Wawan|Xanana|Yahya|Yosef|Yono|Yoga|Agnes|Ajeng|Amalia|Anita|Ayu|Aisyah|Ana|Ami|Ani|Azalea|Aurora|Ali';
wwv_flow_imp.g_varchar2_table(1315) := 'ka|Anastasia|Amelia|Almira|Bella|Betania|Belinda|Cindy|Chelsea|Clara|Cornelia|Cinta|Cinthia|Ciaobell';
wwv_flow_imp.g_varchar2_table(1316) := 'a|Cici|Carla|Calista|Devi|Dian|Diah|Diana|Dina|Dinda|Dalima|Eva|Endah|Elisa|Eli|Ella|Ellis|Elma|Elvi';
wwv_flow_imp.g_varchar2_table(1317) := 'na|Fitria|Fitriani|Febi|Faizah|Farhunnisa|Fathonah|Gabriella|Gasti|Gawati|Genta|Ghaliyati|Gina|Gilda';
wwv_flow_imp.g_varchar2_table(1318) := '|Halima|Hesti|Hilda|Hafshah|Hamima|Hani|Hasna|Humaira|Ika|Indah|Irma|Icha|Ida|Ifa|Ilsa|Ina|Ira|Irian';
wwv_flow_imp.g_varchar2_table(1319) := 'a|Jamalia|Janet|Jane|Julia|Juli|Jessica|Jasmin|Jelita|Kamaria|Kamila|Kani|Karen|Karimah|Kartika|Kasi';
wwv_flow_imp.g_varchar2_table(1320) := 'yah|Keisha|Kezia|Kiandra|Kayla|Kania|Lala|Lalita|Latika|Laila|Laras|Lidya|Lili|Lintang|Mala|Maya|Mai';
wwv_flow_imp.g_varchar2_table(1321) := 'da|Maimunah|Melinda|Mila|Mutia|Michelle|Malika|Nadia|Nadine|Nabila|Natalia|Novi|Nova|Nurul|Nilam|Naj';
wwv_flow_imp.g_varchar2_table(1322) := 'wa|Olivia|Ophelia|Oni|Oliva|Padma|Paramita|Paris|Patricia|Paulin|Puput|Puji|Pia|Puspa|Puti|Padmi|Qor';
wwv_flow_imp.g_varchar2_table(1323) := 'i|Queen|Ratih|Ratna|Restu|Rini|Rika|Rahayu|Rahmi|Rachel|Raisa|Raina|Sarah|Siska|Suci|Syahrini|Septi|';
wwv_flow_imp.g_varchar2_table(1324) := 'Sadina|Safina|Sakura|Salimah|Salwa|Salsabila|Samiah|Shania|Sabrina|Silvia|Shakila|Talia|Tami|Tira|Ti';
wwv_flow_imp.g_varchar2_table(1325) := 'ara|Titin|Tania|Tina|Tantri|Tari|Titi|Uchita|Unjani|Ulya|Uli|Ulva|Umi|Usyi|Vanya|Vanesa|Vivi|Vera|Vi';
wwv_flow_imp.g_varchar2_table(1326) := 'cky|Victoria|Violet|Winda|Widya|Wulan|Wirda|Wani|Yessi|Yulia|Yuliana|Yuni|Yunita|Yance|Zahra|Zalindr';
wwv_flow_imp.g_varchar2_table(1327) := 'a|Zaenab|Zulfa|Zizi|Zulaikha|Zamira|Zelda|Zelaya|Aaron|Adam|Adrian|Alan|Albert|Alec|Alejandro|Alex|A';
wwv_flow_imp.g_varchar2_table(1328) := 'lexander|Alexis|Alfred|Allen|Alvin|Andre|Andres|Andrew|Angel|Anthony|Antonio|Arthur|Austin|Barry|Ben';
wwv_flow_imp.g_varchar2_table(1329) := 'jamin|Bernard|Bill|Billy|Blake|Bob|Bobby|Brad|Bradley|Brady|Brandon|Brendan|Brent|Brett|Brian|Bruce|';
wwv_flow_imp.g_varchar2_table(1330) := 'Bryan|Bryce|Caleb|Calvin|Cameron|Carl|Carlos|Casey|Cesar|Chad|Charles|Chase|Chris|Christian|Christop';
wwv_flow_imp.g_varchar2_table(1331) := 'her|Clarence|Clayton|Clifford|Clinton|Cody|Cole|Colin|Collin|Colton|Connor|Corey|Cory|Craig|Cristian';
wwv_flow_imp.g_varchar2_table(1332) := '|Curtis|Dakota|Dale|Dalton|Damon|Dan|Danny|Darin|Darius|Darrell|Darren|Darryl|Daryl|Dave|David|Dean|';
wwv_flow_imp.g_varchar2_table(1333) := 'Dennis|Derek|Derrick|Devin|Devon|Dillon|Dominic|Don|Donald|Douglas|Drew|Duane|Dustin|Dwayne|Dylan|Ea';
wwv_flow_imp.g_varchar2_table(1334) := 'rl|Eddie|Edgar|Eduardo|Edwin|Elijah|Eric|Ernest|Ethan|Eugene|Evan|Fernando|Francis|Francisco|Frank|F';
wwv_flow_imp.g_varchar2_table(1335) := 'ranklin|Fred|Frederick|Gabriel|Garrett|Gary|Gavin|Gene|Geoffrey|George|Gerald|Gilbert|Glen|Glenn|Gor';
wwv_flow_imp.g_varchar2_table(1336) := 'don|Grant|Greg|Gregg|Gregory|Guy|Harold|Harry|Hayden|Hector|Henry|Herbert|Howard|Hunter|Isaac|Isaiah';
wwv_flow_imp.g_varchar2_table(1337) := '|Jack|Jackson|Jacob|Jaime|Jake|James|Jamie|Jared|Jason|Javier|Jay|Jeff|Jeffery|Jeffrey|Jeremiah|Jere';
wwv_flow_imp.g_varchar2_table(1338) := 'my|Jermaine|Jerome|Jerry|Jesse|Jesus|Jim|Jimmy|Joe|Joel|John|Johnathan|Johnny|Jon|Jonathan|Jonathon|';
wwv_flow_imp.g_varchar2_table(1339) := 'Jordan|Jorge|Jose|Joseph|Joshua|Juan|Julian|Justin|Karl|Keith|Kelly|Kenneth|Kent|Kerry|Kevin|Kirk|Kr';
wwv_flow_imp.g_varchar2_table(1340) := 'istopher|Kurt|Kyle|Lance|Larry|Lawrence|Lee|Leon|Leonard|Leroy|Leslie|Levi|Logan|Lonnie|Louis|Lucas|';
wwv_flow_imp.g_varchar2_table(1341) := 'Luke|Manuel|Marc|Marco|Marcus|Mario|Mark|Martin|Marvin|Mason|Mathew|Matthew|Maurice|Max|Maxwell|Melv';
wwv_flow_imp.g_varchar2_table(1342) := 'in|Michael|Micheal|Mike|Mitchell|Nathan|Nathaniel|Neil|Nicholas|Nicolas|Noah|Norman|Oscar|Parker|Pat';
wwv_flow_imp.g_varchar2_table(1343) := 'rick|Paul|Pedro|Perry|Peter|Philip|Phillip|Preston|Ralph|Randall|Randy|Ray|Raymond|Reginald|Ricardo|';
wwv_flow_imp.g_varchar2_table(1344) := 'Richard|Rick|Rickey|Ricky|Riley|Robert|Roberto|Rodney|Roger|Ronald|Ronnie|Ross|Roy|Ruben|Russell|Rya';
wwv_flow_imp.g_varchar2_table(1345) := 'n|Samuel|Scott|Sean|Sergio|Seth|Shane|Shannon|Shaun|Shawn|Spencer|Stanley|Stephen|Steve|Steven|Stuar';
wwv_flow_imp.g_varchar2_table(1346) := 't|Tanner|Taylor|Terrance|Terrence|Terry|Theodore|Thomas|Tim|Timothy|Todd|Tom|Tommy|Tony|Tracy|Travis';
wwv_flow_imp.g_varchar2_table(1347) := '|Trevor|Tristan|Troy|Tyler|Tyrone|Vernon|Victor|Vincent|Walter|Warren|Wayne|Wesley|William|Willie|Wy';
wwv_flow_imp.g_varchar2_table(1348) := 'att|Xavier|Zachary|April|Abigail|Adriana|Adrienne|Aimee|Alejandra|Alexa|Alexandra|Alexandria|Alice|A';
wwv_flow_imp.g_varchar2_table(1349) := 'licia|Alisha|Alison|Allison|Alyssa|Amanda|Amber|Amy|Angelica|Angie|Ann|Anna|Anne|Annette|Ariana|Arie';
wwv_flow_imp.g_varchar2_table(1350) := 'l|Ashlee|Ashley|Audrey|Autumn|Bailey|Barbara|Becky|Beth|Bethany|Betty|Beverly|Bianca|Bonnie|Brandi|B';
wwv_flow_imp.g_varchar2_table(1351) := 'randy|Breanna|Brenda|Briana|Brianna|Bridget|Brittany|Brittney|Brooke|Caitlin|Caitlyn|Candace|Candice';
wwv_flow_imp.g_varchar2_table(1352) := '|Carly|Carmen|Carol|Caroline|Carolyn|Carrie|Cassandra|Cassidy|Cassie|Catherine|Cathy|Charlene|Charlo';
wwv_flow_imp.g_varchar2_table(1353) := 'tte|Chelsey|Cheryl|Cheyenne|Chloe|Christie|Christina|Christine|Christy|Claire|Claudia|Colleen|Connie';
wwv_flow_imp.g_varchar2_table(1354) := '|Courtney|Cristina|Crystal|Cynthia|Daisy|Dana|Danielle|Darlene|Dawn|Deanna|Debbie|Deborah|Debra|Deni';
wwv_flow_imp.g_varchar2_table(1355) := 'se|Desiree|Destiny|Diamond|Diane|Dominique|Donna|Doris|Dorothy|Ebony|Eileen|Elaine|Elizabeth|Ellen|E';
wwv_flow_imp.g_varchar2_table(1356) := 'mily|Emma|Erica|Erika|Erin|Evelyn|Faith|Felicia|Frances|Gabriela|Gabrielle|Gail|Glenda|Gloria|Grace|';
wwv_flow_imp.g_varchar2_table(1357) := 'Gwendolyn|Hailey|Haley|Hannah|Hayley|Heather|Heidi|Helen|Holly|Isabel|Isabella|Jackie|Jaclyn|Jacquel';
wwv_flow_imp.g_varchar2_table(1358) := 'ine|Jade|Janice|Jasmine|Jean|Jeanette|Jeanne|Jenna|Jennifer|Jenny|Jill|Jillian|Jo|Joan|Joann|Joanna|';
wwv_flow_imp.g_varchar2_table(1359) := 'Joanne|Jocelyn|Jodi|Jody|Joy|Joyce|Judith|Judy|Julie|Kaitlin'';'||wwv_flow.LF||
'    l_last_name_catalog(7) := ''Ahmad|';
wwv_flow_imp.g_varchar2_table(1360) := 'Chen|Goh|Hassan|Lim|Mendoza|Ong|Reyes|Santos|Tan|Teo|Villanueva|Wong|Yusof|Abdullah|Chua|Navarro|Rah';
wwv_flow_imp.g_varchar2_table(1361) := 'man|Koh|Bakar|Bautista|Cruz|Fernandez|Flores|Garcia|Halim|Ibrahim|Ismail|Kwan|Lee|Liew|Malik|Rahim|S';
wwv_flow_imp.g_varchar2_table(1362) := 'ingh|Syed|Wijaya|Zain|Adriansyah|Ardianto|Anggriawan|Budiman|Budiyanto|Damanik|Dongoran|Dabukke|Firm';
wwv_flow_imp.g_varchar2_table(1363) := 'ansyah|Firgantoro|Gunarto|Gunawan|Hardiansyah|Habibi|Hakim|Haryanto|Hidayat|Hidayanto|Hutagalung|Hut';
wwv_flow_imp.g_varchar2_table(1364) := 'apea|Hutasoit|Irawan|Iswahyudi|Kuswoyo|Januar|Jailani|Kurniawan|Kusumo|Latupono|Lazuardi|Maheswara|M';
wwv_flow_imp.g_varchar2_table(1365) := 'ahendra|Mustofa|Mansur|Mandala|Megantara|Maulana|Maryadi|Mangunsong|Manullang|Marpaung|Marbun|Narpat';
wwv_flow_imp.g_varchar2_table(1366) := 'i|Natsir|Nugroho|Najmudin|Nashiruddin|Nainggolan|Nababan|Napitupulu|Pangestu|Putra|Pranowo|Prabowo|P';
wwv_flow_imp.g_varchar2_table(1367) := 'ratama|Prasetya|Prasetyo|Pradana|Pradipta|Prakasa|Permadi|Prasasta|Prayoga|Ramadan|Rajasa|Rajata|Sap';
wwv_flow_imp.g_varchar2_table(1368) := 'tono|Santoso|Saputra|Saefullah|Setiawan|Suryono|Suwarno|Siregar|Sihombing|Salahudin|Samosir|Saragih|';
wwv_flow_imp.g_varchar2_table(1369) := 'Sihotang|Simanjuntak|Sinaga|Simbolon|Sitompul|Sitorus|Sirait|Situmorang|Tampubolon|Thamrin|Tamba|Tar';
wwv_flow_imp.g_varchar2_table(1370) := 'ihoran|Utama|Uwais|Wahyudin|Waluyo|Wibowo|Winarno|Wibisono|Widodo|Wacana|Waskita|Wasita|Zulkarnain|A';
wwv_flow_imp.g_varchar2_table(1371) := 'gustina|Andriani|Anggraini|Aryani|Astuti|Fujiati|Farida|Handayani|Hassanah|Hartati|Hasanah|Haryanti|';
wwv_flow_imp.g_varchar2_table(1372) := 'Hariyah|Hastuti|Halimah|Kusmawati|Kuswandari|Laksmiwati|Laksita|Lestari|Lailasari|Mandasari|Mardhiya';
wwv_flow_imp.g_varchar2_table(1373) := 'h|Mayasari|Melani|Mulyani|Maryati|Nurdiyanti|Novitasari|Nuraini|Nasyidah|Nasyiah|Namaga|Palastri|Pud';
wwv_flow_imp.g_varchar2_table(1374) := 'jiastuti|Puspasari|Puspita|Purwanti|Pratiwi|Purnawati|Pertiwi|Permata|Prastuti|Padmasari|Rahmawati|R';
wwv_flow_imp.g_varchar2_table(1375) := 'ahayu|Riyanti|Rahimah|Suartini|Sudiati|Suryatmi|Susanti|Safitri|Oktaviani|Utami|Usamah|Usada|Uyainah';
wwv_flow_imp.g_varchar2_table(1376) := '|Yuniar|Yuliarti|Yulianti|Yolanda|Wahyuni|Wijayanti|Widiastuti|Winarsih|Wulandari|Wastuti|Zulaika|Sm';
wwv_flow_imp.g_varchar2_table(1377) := 'ith|Johnson|Williams|Brown|Jones|Miller|Davis|Rodriguez|Wilson|Martinez|Anderson|Taylor|Thomas|Herna';
wwv_flow_imp.g_varchar2_table(1378) := 'ndez|Moore|Martin|Jackson|Thompson|White|Lopez|Gonzalez|Harris|Clark|Lewis|Robinson|Walker|Perez|Hal';
wwv_flow_imp.g_varchar2_table(1379) := 'l|Young|Allen|Sanchez|Wright|King|Scott|Green|Baker|Adams|Nelson|Hill|Ramirez|Campbell|Mitchell|Robe';
wwv_flow_imp.g_varchar2_table(1380) := 'rts|Carter|Phillips|Evans|Turner|Torres|Parker|Collins|Edwards|Stewart|Morris|Nguyen|Murphy|Rivera|C';
wwv_flow_imp.g_varchar2_table(1381) := 'ook|Rogers|Morgan|Peterson|Cooper|Reed|Bailey|Bell|Gomez|Kelly|Howard|Ward|Cox|Diaz|Richardson|Wood|';
wwv_flow_imp.g_varchar2_table(1382) := 'Watson|Brooks|Bennett|Gray|James|Hughes|Price|Myers|Long|Foster|Sanders|Ross|Morales|Powell|Sullivan';
wwv_flow_imp.g_varchar2_table(1383) := '|Russell|Ortiz|Jenkins|Gutierrez|Perry|Butler|Barnes|Fisher|Henderson|Coleman|Simmons|Patterson|Jord';
wwv_flow_imp.g_varchar2_table(1384) := 'an|Reynolds|Hamilton|Graham|Kim|Gonzales|Alexander|Ramos|Wallace|Griffin|West|Cole|Hayes|Chavez|Gibs';
wwv_flow_imp.g_varchar2_table(1385) := 'on|Bryant|Ellis|Stevens|Murray|Ford|Marshall|Owens|Mcdonald|Harrison|Ruiz|Kennedy|Wells|Alvarez|Wood';
wwv_flow_imp.g_varchar2_table(1386) := 's|Castillo|Olson|Webb|Washington|Tucker|Freeman|Burns|Henry|Vasquez|Snyder|Simpson|Crawford|Jimenez|';
wwv_flow_imp.g_varchar2_table(1387) := 'Porter|Mason|Shaw|Gordon|Wagner|Hunter|Romero|Hicks|Dixon|Hunt|Palmer|Robertson|Black|Holmes|Stone|M';
wwv_flow_imp.g_varchar2_table(1388) := 'eyer|Boyd|Mills|Warren|Fox|Rose|Rice|Moreno|Schmidt|Patel|Ferguson|Nichols|Herrera|Medina|Ryan|Weave';
wwv_flow_imp.g_varchar2_table(1389) := 'r|Daniels|Stephens|Gardner|Payne|Kelley|Dunn|Pierce|Arnold|Tran|Spencer|Peters|Hawkins|Grant|Hansen|';
wwv_flow_imp.g_varchar2_table(1390) := 'Castro|Hoffman|Hart|Elliott|Cunningham|Knight|Bradley|Carroll|Hudson|Duncan|Armstrong|Berry|Andrews|';
wwv_flow_imp.g_varchar2_table(1391) := 'Johnston|Ray|Lane|Riley|Carpenter|Perkins|Aguilar|Silva|Richards|Willis|Matthews|Chapman|Lawrence|Ga';
wwv_flow_imp.g_varchar2_table(1392) := 'rza|Vargas|Watkins|Wheeler|Larson|Carlson|Harper|George|Greene|Burke|Guzman|Morrison|Munoz|Jacobs|Ob';
wwv_flow_imp.g_varchar2_table(1393) := 'rien|Lawson|Franklin|Lynch|Bishop|Carr|Salazar|Austin|Mendez|Gilbert|Jensen|Williamson|Montgomery|Ha';
wwv_flow_imp.g_varchar2_table(1394) := 'rvey|Oliver|Howell|Dean|Hanson|Weber|Garrett|Sims|Burton|Fuller|Soto|Mccoy|Welch|Schultz|Walters|Rei';
wwv_flow_imp.g_varchar2_table(1395) := 'd|Fields|Walsh|Little|Fowler|Bowman|Davidson|May|Day|Schneider|Newman|Brewer|Lucas|Holland|Banks|Cur';
wwv_flow_imp.g_varchar2_table(1396) := 'tis|Pearson|Delgado|Valdez|Pena|Rios|Douglas|Sandoval|Barrett|Hopkins|Keller|Guerrero|Stanley|Bates|';
wwv_flow_imp.g_varchar2_table(1397) := 'Alvarado|Beck|Ortega|Wade|Estrada|Contreras|Barnett|Caldwell|Santiago|Lambert|Powers|Chambers|Nunez|';
wwv_flow_imp.g_varchar2_table(1398) := 'Craig|Leonard|Lowe|Rhodes|Byrd|Gregory|Shelton|Frazier|Becker|Maldonado|Fleming|Vega|Sutton|Cohen|Je';
wwv_flow_imp.g_varchar2_table(1399) := 'nnings|Parks|Mcdaniel|Watts|Barker|Norris|Vaughn|Vazquez|Holt|Schwartz|Steele|Benson|Neal|Dominguez|';
wwv_flow_imp.g_varchar2_table(1400) := 'Horton|Terry|Wolfe|Hale|Lyons|Graves|Haynes|Miles|Park|Warner|Padilla|Bush|Thornton|Mccarthy|Mann|Zi';
wwv_flow_imp.g_varchar2_table(1401) := 'mmerman|Erickson|Fletcher|Mckinney|Page|Dawson|Joseph|Marquez|Reeves|Klein|Espinoza|Baldwin|Moran|Lo';
wwv_flow_imp.g_varchar2_table(1402) := 've|Robbins|Higgins|Ball|Cortez|Le|Griffith|Bowen|Sharp|Cummings|Ramsey|Hardy|Swanson|Barber|Acosta|L';
wwv_flow_imp.g_varchar2_table(1403) := 'una|Chandler|Daniel|Blair|Cross|Simon|Dennis|Oconnor|Quinn|Gross|Moss|Fitzgerald|Doyle|Mclaughlin|Ro';
wwv_flow_imp.g_varchar2_table(1404) := 'jas|Rodgers|Stevenson|Yang|Figueroa|Harmon|Newton|Paul|Manning|Garner|Mcgee|Reese|Francis|Burgess|Ad';
wwv_flow_imp.g_varchar2_table(1405) := 'kins|Goodman|Curry|Brady|Christensen|Potter|Walton|Goodwin|Mullins|Molina|Webster|Fischer|Campos|Avi';
wwv_flow_imp.g_varchar2_table(1406) := 'la|Sherman|Todd|Chang|Blake|Malone|Wolf|Hodges|Juarez|Gill|Farmer|Hines|Gallagher|Duran|Hubbard|Cann';
wwv_flow_imp.g_varchar2_table(1407) := 'on|Miranda|Wang|Saunders|Tate|Mack|Hammond|Carrillo|Townsend|Wise|Ingram|Barton|Mejia|Ayala|Schroede';
wwv_flow_imp.g_varchar2_table(1408) := 'r|Hampton|Rowe|Parsons|Frank|Waters|Strickland|Osborne|Maxwell|Chan|Deleon|Norman|Harrington|Casey|P';
wwv_flow_imp.g_varchar2_table(1409) := 'atton|Logan|Bowers|Mueller|Glover|Floyd|Hartman|Buchanan|Cobb|French|Kramer|Mccormick|Clarke|Tyler|G';
wwv_flow_imp.g_varchar2_table(1410) := 'ibbs|Moody|Conner|Sparks|Mcguire|Leon|Bauer|Norton|Pope|Flynn|Hogan|Robles|Salinas|Yates|Lindsey|Llo';
wwv_flow_imp.g_varchar2_table(1411) := 'yd|Marsh|Mcbride|Owen|Solis|Pham|Lang|Pratt|Lara|Brock|Ballard|Trujillo|Shaffer|Drake|Roman|Aguirre|';
wwv_flow_imp.g_varchar2_table(1412) := 'Morton|Stokes|Lamb|Pacheco|Patrick|Cochran|Shepherd|Cain|Burnett|Hess|Li|Cervantes|Olsen|Briggs|Ocho';
wwv_flow_imp.g_varchar2_table(1413) := 'a|Cabrera|Velasquez|Montoya|Roth|Meyers|Cardenas|Fuentes|Weiss|Wilkins|Hoover|Nicholson|Underwood|Sh';
wwv_flow_imp.g_varchar2_table(1414) := 'ort|Carson|Morrow|Colon|Holloway|Summers|Bryan|Petersen|Mckenzie|Serrano|Wilcox|Carey|Clayton|Poole|';
wwv_flow_imp.g_varchar2_table(1415) := 'Calderon|Gallegos|Greer|Rivas|Guerra|Decker|Collier|Wall|Whitaker|Bass|Flowers|Davenport|Conley|Hous';
wwv_flow_imp.g_varchar2_table(1416) := 'ton|Huff|Copeland|Hood|Monroe|Massey|Roberson|Combs|Franco|Larsen|Pittman|Randall|Skinner|Wilkinson|';
wwv_flow_imp.g_varchar2_table(1417) := 'Kirby|Cameron|Bridges|Anthony|Richard|Kirk|Bruce|Singleton|Mathis|Bradford|Boone|Abbott|Charles|Alli';
wwv_flow_imp.g_varchar2_table(1418) := 'son|Sweeney|Atkinson|Horn|Jefferson|Rosales|York|Christian|Phelps|Farrell|Castaneda|Nash|Dickerson|B';
wwv_flow_imp.g_varchar2_table(1419) := 'ond|Wyatt|Foley|Chase|Gates|Vincent|Mathews|Hodge|Garrison|Trevino|Villarreal|Heath|Dalton|Valencia|';
wwv_flow_imp.g_varchar2_table(1420) := 'Callahan|Hensley|Atkins|Huffman|Roy|Boyer|Shields|Lin|Hancock|Grimes|Glenn|Cline|Delacruz|Camacho|Di';
wwv_flow_imp.g_varchar2_table(1421) := 'llon|Parrish|Oneill|Melton|Booth|Kane|Berg|Harrell|Pitts|Savage|Wiggins|Brennan|Salas|Marks|Russo|Sa';
wwv_flow_imp.g_varchar2_table(1422) := 'wyer|Baxter|Golden|Hutchinson|Liu|Walter|Mcdowell|Wiley|Rich|Humphrey|Johns|Koch|Suarez|Hobbs|Beard|';
wwv_flow_imp.g_varchar2_table(1423) := 'Gilmore|Ibarra|Keith|Macias|Khan|Andrade|Ware|Stephenson|Henson|Wilkerson|Dyer|Mcclure|Blackwell|Mer';
wwv_flow_imp.g_varchar2_table(1424) := 'cado|Tanner|Eaton|Clay|Barron|Beasley|Oneal|Small|Preston|Wu|Zamora|Macdonald|Vance|Snow|Mcclain|Sta';
wwv_flow_imp.g_varchar2_table(1425) := 'fford|Orozco|Barry|English|Shannon|Kline|Jacobson|Woodard|Huang|Kemp|Mosley|Prince|Merritt|Hurst|Roa';
wwv_flow_imp.g_varchar2_table(1426) := 'ch|Nolan|Lam|Yoder|Mccullough|Lester|Santana|Valenzuela|Winters|Barrera|Orr|Leach|Berger|Mckee|Stron';
wwv_flow_imp.g_varchar2_table(1427) := 'g|Conway|Stein|Whitehead|Bullock|Escobar|Knox|Meadows|Solomon|Velez|Odonnell|Kerr|Stout|Blankenship|';
wwv_flow_imp.g_varchar2_table(1428) := 'Browning|Kent|Lozano|Bartlett|Pruitt|Buck|Barr|Gaines|Durham|Gentry|Mcintyre|Sloan|Rocha|Melendez|He';
wwv_flow_imp.g_varchar2_table(1429) := 'rman|Sexton|Moon|Hendricks|Rangel|Stark|Lowery|Hardin|Hull|Sellers|Ellison|Calhoun|Gillespie|Mora|Kn';
wwv_flow_imp.g_varchar2_table(1430) := 'app|Mccall|Morse|Dorsey|Weeks|Nielsen|Livingston|Leblanc|Mclean|Bradshaw|Glass|Middleton|Buckley|Sch';
wwv_flow_imp.g_varchar2_table(1431) := 'aefer|Frost|Howe|House|Mcintosh|Ho|Pennington|Reilly|Hebert|Mcfarland|Hickman|Noble|Spears|Conrad|Ar';
wwv_flow_imp.g_varchar2_table(1432) := 'ias|Galvan|Velazquez|Huynh|Frederick|Randolph|Cantu|Fitzpatrick|Mahoney|Peck|Villa|Michael|Donovan|M';
wwv_flow_imp.g_varchar2_table(1433) := 'cconnell|Walls|Boyle|Mayer|Zuniga|Giles|Pineda|Pace|Hurley|Mays|Mcmillan|Crosby|Ayers|Case|Bentley|S';
wwv_flow_imp.g_varchar2_table(1434) := 'hepard|Everett|Pugh|David|Mcmahon|Dunlap|Bender|Hahn|Harding|Acevedo|Raymond|Blackburn|Duffy|Landry|';
wwv_flow_imp.g_varchar2_table(1435) := 'Dougherty|Shah|Potts|Arroyo|Valentine|Meza|Gould|Vaughan|Fry|Rush|Avery|Herring|Dodson|Clements|Samp';
wwv_flow_imp.g_varchar2_table(1436) := 'son|Tapia|Bean|Lynn|Crane|Farley|Cisneros|Benton|Ashley|Mckay|Finley|Best|Blevins|Friedman|Moses|Sos';
wwv_flow_imp.g_varchar2_table(1437) := 'a|Blanchard|Huber|Frye|Krueger|Bernard|Rosario|Rubio|Mullen|Benjamin|Haley|Chung|Moyer|Choi|Horne|Yu';
wwv_flow_imp.g_varchar2_table(1438) := '|Woodward|Ali|Nixon|Hayden|Rivers|Estes|Mccarty|Richmond|Stuart|Maynard|Brandt|Oconnell|Hanna|Sanfor';
wwv_flow_imp.g_varchar2_table(1439) := 'd|Sheppard|Church|Burch|Levy|Rasmussen|Coffey|Ponce|Faulkner|Donaldson|Schmitt|Novak|Costa|Montes|Bo';
wwv_flow_imp.g_varchar2_table(1440) := 'oker|Cordova|Waller|Arellano|Maddox|Mata|Bonilla|Stanton|Compton|Kaufman|Dudley|Mcpherson|Beltran|Di';
wwv_flow_imp.g_varchar2_table(1441) := 'ckson|Mccann|Villegas|Proctor|Hester|Cantrell|Daugherty|Cherry|Bray|Davila|Rowland|Madden|Levine|Spe';
wwv_flow_imp.g_varchar2_table(1442) := 'nce|Good|Irwin|Werner|Krause|Petty|Whitney|Baird|Hooper|Pollard|Zavala|Jarvis|Holden|Hendrix|Haas|Mc';
wwv_flow_imp.g_varchar2_table(1443) := 'grath|Bird|Lucero|Terrell|Riggs|Joyce|Rollins|Mercer|Galloway|Duke|Odom|Andersen|Downs|Hatfield|Beni';
wwv_flow_imp.g_varchar2_table(1444) := 'tez|Archer|Huerta|Travis|Mcneil|Hinton|Zhang|Hays|Mayo|Fritz|Branch|Mooney|Ewing|Ritter|Esparza|Frey';
wwv_flow_imp.g_varchar2_table(1445) := '|Braun|Gay|Riddle|Haney|Kaiser|Holder|Chaney|Mcknight|Gamble|Vang|Cooley|Carney|Cowan|Forbes|Ferrell';
wwv_flow_imp.g_varchar2_table(1446) := unistr('|Davies|Barajas|Shea|Osborn|Bright|Cuevas|Bolton|Murillo|Lutz|Duarte|Kidd|Key|Cooke|Nguy\1EC5n|Tr\1EA7n|L\00EA|P');
wwv_flow_imp.g_varchar2_table(1447) := unistr('h\1EA1m|V\0169|\0110\1EB7ng'';'||wwv_flow.LF||
'    l_first_name_catalog(6) := ''Aarav|Ananya|Vihaan|Isha|Rohan|Kavya|Aditya|Meera|Arju');
wwv_flow_imp.g_varchar2_table(1448) := 'n|Nisha|Ishaan|Priya|Kabir|Diya|Rahul|Aditi|Dev|Neha|Kiran|Saanvi|Anil|Arnav|Bhavna|Chaitanya|Esha|G';
wwv_flow_imp.g_varchar2_table(1449) := 'aurav|Ishita|Karan|Lakshmi|Manish|Nandini|Pooja|Riya|Sachin|Shreya|Tanvi|Varun|Vikram|Yash|Aadi|Aarn';
wwv_flow_imp.g_varchar2_table(1450) := 'av|Aarush|Aayush|Abdul|Abeer|Abhimanyu|Abhiram|Advaith|Advay|Advik|Agastya|Akshay|Alexander|Amol|Ana';
wwv_flow_imp.g_varchar2_table(1451) := 'y|Andrew|Anirudh|Anmol|Ansh|Anthony|Arin|Aryan|Atharv|Avi|Ayaan|Ayush|Ayushman|Azaan|Azad|Bachittar|';
wwv_flow_imp.g_varchar2_table(1452) := 'Bahadurjit|Bakhshi|Balendra|Balhaar|Baljiwan|Balvan|Balveer|Banjeet|Benjamin|Brijesh|Caleb|Chakradev';
wwv_flow_imp.g_varchar2_table(1453) := '|Chakradhar|Champak|Chanakya|Chandran|Chandresh|Charan|Charles|Chatresh|Chatura|Christopher|Daksh|Da';
wwv_flow_imp.g_varchar2_table(1454) := 'kshesh|Dalbir|Daniel|Darpan|Darsh|David|Devansh|Dhruv|Dominic|Ekalinga|Ekansh|Ekapad|Ekaraj|Ekavir|E';
wwv_flow_imp.g_varchar2_table(1455) := 'kbal|Elijah|Ethan|Falan|Faqid|Faraj|Faras|Farhan|Fariq|Faris|Finn|Fitan|Fiyaz|Frado|Frederick|Gabrie';
wwv_flow_imp.g_varchar2_table(1456) := 'l|Gagan|Gaurang|Gautam|Gavin|George|Girik|Girindra|Girish|Gopal|Gunbir|Guneet|Hardik|Harish|Harrison';
wwv_flow_imp.g_varchar2_table(1457) := '|Harsh|Harshil|Hemang|Henry|Hitesh|Hredhaan|Hritik|Ikbal|Imaran|Indrajit|Isaac|Isaiah|Ishwar|Jack|Ja';
wwv_flow_imp.g_varchar2_table(1458) := 'ckson|Jacob|Jagat|Jagdish|Jai|Jairaj|Jason|Jatin|Jeet|Jeremiah|Jonathan|Joshua|Kai|Kalpit|Kevin|Kiaa';
wwv_flow_imp.g_varchar2_table(1459) := 'n|Krish|Krishna|Laban|Laksh|Lakshit|Liam|Logan|Lohit|Lucky|Luke|Maanas|Maanav|Madhav|Manan|Manbir|Ma';
wwv_flow_imp.g_varchar2_table(1460) := 'nthan|Mason|Matthew|Max|Michael|Mitesh|Mohammed|Nachiket|Naksh|Nakul|Nathan|Nathaniel|Naveen|Neel|Ni';
wwv_flow_imp.g_varchar2_table(1461) := 'cholas|Nihal|Nitesh|Noah|Ojas|Oliver|Om|Omkaar|Onkar|Onveer|Orinder|Oscar|Owen|Parth|Patrick|Peter|P';
wwv_flow_imp.g_varchar2_table(1462) := 'ranav|Praneel|Pranit|Pratyush|Qabil|Qadim|Qarin|Qasim|Quincy|Rachit|Raghav|Ranbir|Ranveer|Rayaan|Reh';
wwv_flow_imp.g_varchar2_table(1463) := 'aan|Reyansh|Rishi|Robert|Ronith|Rudra|Rushil|Ryan|Sai|Saksham|Samaksh|Samar|Samarth|Samesh|Samuel|Sa';
wwv_flow_imp.g_varchar2_table(1464) := 'rthak|Sathvik|Shaurya|Shivansh|Siddharth|Simon|Tanay|Tanish|Tanveer|Tarak|Teerth|Tejas|Theodore|Thom';
wwv_flow_imp.g_varchar2_table(1465) := 'as|Timothy|Tristan|Udant|Udarsh|Umang|Upkaar|Utkarsh|Vedant|Veer|Victor|Vincent|Viraj|Vivaan|Wahab|W';
wwv_flow_imp.g_varchar2_table(1466) := 'arinder|Warjas|Wazir|William|Wriddhish|Wridesh|Wyatt|Xavier|Yagnesh|Yatan|Yatin|Yug|Yuvraj|Zaid|Zash';
wwv_flow_imp.g_varchar2_table(1467) := 'il|Zayan|Zayyan|Zehaan|Aachal|Aadhya|Aahana|Aarini|Aarna|Aashi|Abha|Advika|Adweta|Adya|Aishani|Alka|';
wwv_flow_imp.g_varchar2_table(1468) := 'Amaira|Amara|Amrita|Amruta|Anamika|Anika|Anita|Anjali|Anusha|Anvi|Anya|Aradhana|Arunima|Arya|Ati|Avn';
wwv_flow_imp.g_varchar2_table(1469) := 'i|Baghyawati|Barkha|Bhanumati|Bhavani|Bhavika|Bhavini|Bhavya|Bimala|Bina|Bishakha|Brinda|Chaaya|Chai';
wwv_flow_imp.g_varchar2_table(1470) := 'taly|Chakrika|Chaman|Chameli|Chanchal|Chandani|Charita|Charvi|Chasmum|Chavvi|Daksha|Dalaja|Damini|Da';
wwv_flow_imp.g_varchar2_table(1471) := 'myanti|Darika|Dayamai|Dayita|Deepa|Devika|Dhriti|Dipta|Divya|Edhitha|Eesha|Eiravati|Ekaja|Ekani|Ekan';
wwv_flow_imp.g_varchar2_table(1472) := 'ta|Ekantika|Ekiya|Ekta|Eshana|Eta|Falak|Falguni|Forum|Ganga|Garima|Gaurangi|Gauri|Gaurika|Gautami|Ga';
wwv_flow_imp.g_varchar2_table(1473) := 'yathri|Geetika|Hamsini|Harinakshi|Harini|Harita|Hema|Hemal|Hemangini|Hemani|Hiral|Idika|Ijaya|Ikshit';
wwv_flow_imp.g_varchar2_table(1474) := 'a|Inaya|Indali|Indira|Ira|Irya|Ishani|Ishanvi|Jagrati|Jagvi|Jalsa|Janaki|Janani|Januja|Janya|Jasmit|';
wwv_flow_imp.g_varchar2_table(1475) := 'Jeevika|Jhalak|Jyoti|Kala|Kamala|Kamya|Kashish|Kashvi|Keya|Krisha|Kritika|Ladli|Lajita|Lavanya|Leela';
wwv_flow_imp.g_varchar2_table(1476) := '|Leena|Lekha|Libni|Lila|Lipika|Lopa|Madhavi|Mahika|Manya|Maya|Megha|Meghana|Mekhala|Mitali|Mohini|Mu';
wwv_flow_imp.g_varchar2_table(1477) := 'gdha|Neelima|Netra|Nidhi|Nidra|Niharika|Nikita|Nilima|Nimrat|Nirja|Nitara|Odika|Oeshi|Ojasvi|Omaja|O';
wwv_flow_imp.g_varchar2_table(1478) := 'misha|Omya|Oni|Osha|Oviya|Pahal|Pallavi|Panini|Pavani|Prisha|Pushti|Qushi|Raagini|Rachana|Rachita|Ra';
wwv_flow_imp.g_varchar2_table(1479) := 'dha|Radhika|Rajata|Rajeshri|Raksha|Reva|Ria|Ridhi|Sachi|Sanaya|Sanya|Sara|Saumya|Shivani|Shravya|Siy';
wwv_flow_imp.g_varchar2_table(1480) := 'a|Sneha|Sudiksha|Suhani|Tamanna|Tanmayi|Tara|Tripti|Triveni|Triya|Turvi|Ubika|Ucchal|Udyati|Unnati|U';
wwv_flow_imp.g_varchar2_table(1481) := 'nni|Upadhriti|Upasna|Upma|Urishilla|Urmi|Urvashi|Urvi|Vaishnavi|Vamakshi|Vansha|Vanya|Varenya|Varsha';
wwv_flow_imp.g_varchar2_table(1482) := '|Vasana|Vasatika|Vasudha|Veda|Vedhika|Vedika|Vidhi|Vinaya|Vrinda|Vrishti|Vritti|Vyanjana|Waida|Wakee';
wwv_flow_imp.g_varchar2_table(1483) := 'ta|Warda|Warhi|Watika|Widisha|Wishi|Xalak|Xiti|Yachana|Yadavi|Yahvi|Yamini|Yashasvi|Yashawini|Yashic';
wwv_flow_imp.g_varchar2_table(1484) := 'a|Yashoda|Yashodhara|Yashvi|Yasti|Yauvani|Yochana|Yoshita|Yutika|Zaitra|Zansi|Zarna|Zilmil|Zinal'';'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1485) := '   l_last_name_catalog(6) := ''Bhat|Chatterjee|Deshmukh|Iyer|Joshi|Kapoor|Kulkarni|Malhotra|Menon|Nai';
wwv_flow_imp.g_varchar2_table(1486) := 'r|Patel|Reddy|Rao|Shah|Sharma|Singh|Srinivasan|Verma|Banerjee|Mehta|Agarwal|Bansal|Choudhary|Das|Gho';
wwv_flow_imp.g_varchar2_table(1487) := 'sh|Gupta|Jindal|Khanna|Mishra|Mukherjee|Naidu|Pillai|Prasad|Sethi|Thakur|Tripathi|Varma|Yadav|Zaveri';
wwv_flow_imp.g_varchar2_table(1488) := '|Acharya|Agate|Aggarwal|Agrawal|Ahluwalia|Ahuja|Amble|Anand|Andra|Anne|Apte|Arora|Arya|Atwal|Aurora|';
wwv_flow_imp.g_varchar2_table(1489) := 'Babu|Badal|Badami|Bahl|Bahri|Bail|Bains|Bajaj|Bajwa|Bakshi|Bal|Bala|Balakrishnan|Balan|Balasubramani';
wwv_flow_imp.g_varchar2_table(1490) := 'an|Balay|Bali|Bandi|Banik|Barad|Baral|Baria|Barman|Basak|Bassi|Basu|Bath|Batra|Batta|Bava|Bawa|Bedi|';
wwv_flow_imp.g_varchar2_table(1491) := 'Behl|Ben|Bera|Bhagat|Bhakta|Bhalla|Bhandari|Bhardwaj|Bhargava|Bhasin|Bhatia|Bhatnagar|Bhatt|Bhattach';
wwv_flow_imp.g_varchar2_table(1492) := 'aryya|Bhatti|Bhavsar|Bir|Biswas|Boase|Bobal|Bora|Borah|Borde|Borra|Bose|Brahmbhatt|Brar|Buch|Bumb|Bu';
wwv_flow_imp.g_varchar2_table(1493) := 'tala|Chacko|Chad|Chada|Chadha|Chahal|Chakrabarti|Chakraborty|Chana|Chand|Chanda|Chander|Chandra|Chan';
wwv_flow_imp.g_varchar2_table(1494) := 'dran|Char|Chaudhari|Chaudhary|Chaudhry|Chaudhuri|Chaudry|Chauhan|Chawla|Cheema|Cherian|Chhabra|Choks';
wwv_flow_imp.g_varchar2_table(1495) := unistr('hi|Chopra|Choudhry|Choudhury|Chowdhury|Comar|Contractor|D\2019Alia|Dada|Dalal|Dani|Dar|Dara|Dasgupta|Das');
wwv_flow_imp.g_varchar2_table(1496) := 'h|Dass|Date|Datta|Dave|Dayal|De|Deep|Deo|Deol|Desai|Deshpande|Devan|Devi|Dewan|Dey|Dhaliwal|Dhar|Dha';
wwv_flow_imp.g_varchar2_table(1497) := 'wan|Dhillon|Dhingra|Din|Divan|Dixit|Doctor|Dora|Doshi|Dua|Dube|Dubey|Dugal|Dugar|Dutt|Dutta|Dyal|Edw';
wwv_flow_imp.g_varchar2_table(1498) := 'in|Gaba|Gade|Gala|Gandhi|Ganesan|Ganesh|Ganguly|Gara|Garde|Garg|Gera|Ghose|Gill|Goda|Goel|Gokhale|Go';
wwv_flow_imp.g_varchar2_table(1499) := 'la|Gole|Golla|Gopal|Goswami|Gour|Goyal|Grewal|Grover|Guha|Gulati|Halder|Handa|Hans|Hari|Hayer|Hayre|';
wwv_flow_imp.g_varchar2_table(1500) := 'Hegde|Hora|Issac|Iyengar|Jaggi|Jain|Jani|Jayaraman|Jha|Jhaveri|Johal|Kadakia|Kade|Kakar|Kala|Kale|Ka';
null;
end;
/
begin
wwv_flow_imp.g_varchar2_table(1501) := 'lita|Kalla|Kamdar|Kanda|Kannan|Kant|Kapadia|Kapur|Kar|Kara|Karan|Kari|Karnik|Karpe|Kashyap|Kata|Kaul';
wwv_flow_imp.g_varchar2_table(1502) := '|Kaur|Keer|Khalsa|Khare|Khatri|Khosla|Khurana|Kibe|Kohli|Konda|Korpal|Koshy|Kota|Kothari|Krish|Krish';
wwv_flow_imp.g_varchar2_table(1503) := 'na|Krishnamurthy|Krishnan|Kumar|Kumer|Kunda|Kurian|Kuruvilla|Lad|Lal|Lala|Lall|Lalla|Lanka|Lata|Loke';
wwv_flow_imp.g_varchar2_table(1504) := '|Loyal|Luthra|Madan|Magar|Mahajan|Mahal|Maharaj|Majumdar|Mall|Mallick|Mammen|Mand|Manda|Mandal|Mande';
wwv_flow_imp.g_varchar2_table(1505) := 'r|Mane|Mangal|Mangat|Mani|Mann|Mannan|Manne|Master|Memon|Merchant|Minhas|Misra|Mistry|Mital|Mitra|Mi';
wwv_flow_imp.g_varchar2_table(1506) := 'ttal|Mitter|Modi|Mody|Mohan|Mohanty|Morar|More|Mukhopadhyay|Muni|Munshi|Murthy|Murty|Mutti|Nadig|Nad';
wwv_flow_imp.g_varchar2_table(1507) := 'karni|Nagar|Nagarajan|Nagi|Nagy|Naik|Nanda|Narain|Narang|Narasimhan|Narayan|Narayanan|Narula|Nataraj';
wwv_flow_imp.g_varchar2_table(1508) := 'an|Nath|Natt|Nayak|Nayar|Nazareth|Nigam|Nori|Oak|Om|Oommen|Oza|Padmanabhan|Pai|Pal|Palan|Pall|Palla|';
wwv_flow_imp.g_varchar2_table(1509) := 'Panchal|Pandey|Pandit|Pandya|Pant|Parekh|Parikh|Parmar|Parmer|Parsa|Pathak|Patil|Patla|Pau|Peri|Pill';
wwv_flow_imp.g_varchar2_table(1510) := 'ay|Pingle|Prabhakar|Prabhu|Pradhan|Prakash|Prashad|Puri|Purohit|Radhakrishnan|Raghavan|Rai|Raj|Raja|';
wwv_flow_imp.g_varchar2_table(1511) := 'Rajagopal|Rajagopalan|Rajan|Raju|Ram|Rama|Ramachandran|Ramakrishnan|Raman|Ramanathan|Ramaswamy|Rames';
wwv_flow_imp.g_varchar2_table(1512) := 'h|Rana|Randhawa|Ranganathan|Rastogi|Ratta|Rattan|Ratti|Rau|Raval|Ravel|Ravi|Ray|Rege|Rout|Roy|Sabhar';
wwv_flow_imp.g_varchar2_table(1513) := 'wal|Sachar|Sachdev|Sachdeva|Sagar|Saha|Sahni|Sahota|Saini|Salvi|Sama|Sami|Sampath|Samra|Sandal|Sandh';
wwv_flow_imp.g_varchar2_table(1514) := 'u|Sane|Sangha|Sanghvi|Sani|Sankar|Sankaran|Sant|Saraf|Saran|Sarin|Sarkar|Sarma|Sarna|Sarraf|Sastry|S';
wwv_flow_imp.g_varchar2_table(1515) := 'athe|Savant|Sawhney|Saxena|Sehgal|Sekhon|Sem|Sen|Sengupta|Seshadri|Seth|Setty|Sha|Shan|Shankar|Shank';
wwv_flow_imp.g_varchar2_table(1516) := 'er|Sharaf|Shenoy|Shere|Sheth|Shetty|Shroff|Shukla|Sibal|Sidhu|Singhal|Sinha|Sodhi|Solanki|Som|Soman|';
wwv_flow_imp.g_varchar2_table(1517) := 'Soni|Sood|Sridhar|Srinivas|Srivastava|Subramaniam|Subramanian|Sule|Sundaram|Sunder|Sur|Sura|Suresh|S';
wwv_flow_imp.g_varchar2_table(1518) := 'uri|Swaminathan|Swamy|Tailor|Tak|Talwar|Tandon|Taneja|Tank|Tara|Tata|Tella|Thaker|Thakkar|Thaman|Tiw';
wwv_flow_imp.g_varchar2_table(1519) := 'ari|Toor|Trivedi|Upadhyay|Uppal|Vaidya|Vala|Varghese|Varkey|Varty|Varughese|Vasa|Venkataraman|Venkat';
wwv_flow_imp.g_varchar2_table(1520) := 'esh|Vig|Virk|Viswanathan|Vohra|Vora|Vyas|Wable|Wadhwa|Wagle|Wali|Walia|Walla|Warrior|Wason|Yogi|Yoha';
wwv_flow_imp.g_varchar2_table(1521) := 'nnan|Zacharia|Zachariah'';'||wwv_flow.LF||
'    l_first_name_catalog(5) := ''Nikos|Eleni|Giorgos|Sofia|Dimitris|Katerin';
wwv_flow_imp.g_varchar2_table(1522) := 'a|Andreas|Maria|Panagiotis|Ioanna|Kostas|Theodora|Vasilis|Despina|Alexandros|Foteini|Stavros|Niki|Mi';
wwv_flow_imp.g_varchar2_table(1523) := 'chalis|Agapi|Alexia|Anna|Christina|Dimitra|Evangelia|Fotis|Ioannis|Konstantinos|Leonidas|Manos|Marin';
wwv_flow_imp.g_varchar2_table(1524) := 'a|Olga|Paraskevi|Petros|Spyridon|Vasiliki|Yiannis|Zoe|Themis'';'||wwv_flow.LF||
'    l_last_name_catalog(5) := ''Papado';
wwv_flow_imp.g_varchar2_table(1525) := 'poulos|Georgiou|Nikolaidis|Pappas|Dimitriadis|Konstantinou|Vasilakis|Theodorou|Angelopoulos|Karalis|';
wwv_flow_imp.g_varchar2_table(1526) := 'Stavridis|Ioannidis|Christou|Manolis|Spyridis|Kouris|Roussos|Zervas|Makris|Economou|Alexiou|Anastasi';
wwv_flow_imp.g_varchar2_table(1527) := 'ou|Antonopoulos|Dimitropoulos|Eleftheriou|Fotiadis|Galanis|Kallias|Karagiannis|Kourtidis|Mavridis|Ni';
wwv_flow_imp.g_varchar2_table(1528) := 'kolaou|Oikonomou|Panagiotou|Raptis|Sideris|Theodorakis|Vrettos|Xenakis'';'||wwv_flow.LF||
'    l_first_name_catalog(4)';
wwv_flow_imp.g_varchar2_table(1529) := unistr(' := ''Adam|Albert|Alexander|Alexandr|Ale\0161|Alois|Anton\00EDn|Arno\0161t|Artur|Bed\0159ich|Blahoslav|Bohumil|Bohum\00ED');
wwv_flow_imp.g_varchar2_table(1530) := unistr('r|Bohuslav|Boleslav|Bo\0159ivoj|B\0159etislav|Ctibor|Ctirad|Dalibor|Daniel|David|Denis|Dobroslav|Dominik|Dra');
wwv_flow_imp.g_varchar2_table(1531) := unistr('hoslav|Du\0161an|Eduard|Emil|Erik|Ferdinand|Felix|Filip|Franti\0161ek|Horym\00EDr|Hubert|Hynek|Ign\00E1c|Igor|Ivan|I');
wwv_flow_imp.g_varchar2_table(1532) := unistr('vo|Jakub|Jan|Jarom\00EDr|Jaroslav|Jind\0159ich|Ji\0159\00ED|Jon\00E1\0161|Josef|Jozef|J\00E1n|Kamil|Karel|Klement|Kry\0161tof|Ladisl');
wwv_flow_imp.g_varchar2_table(1533) := unistr('av|Leo\0161|Libor|Lubom\00EDr|Lubo\0161|Ludv\00EDk|Lud\011Bk|Luk\00E1\0161|Lum\00EDr|Marcel|Marek|Marian|Martin|Matou\0161|Maty\00E1\0161|Mat\011Bj|');
wwv_flow_imp.g_varchar2_table(1534) := unistr('Michael|Michal|Mikul\00E1\0161|Milan|Miloslav|Milo\0161|Miroslav|Mojm\00EDr|Norbert|Old\0159ich|Ond\0159ej|Otakar|Oto|Patrik');
wwv_flow_imp.g_varchar2_table(1535) := unistr('|Pavel|Peter|Petr|P\0159emysl|Radek|Radim|Radom\00EDr|Radoslav|Radovan|Ren\00E9|Richard|Robert|Robin|Roman|Rosti');
wwv_flow_imp.g_varchar2_table(1536) := unistr('slav|Rudolf|Samuel|Stanislav|Slavom\00EDr|Svatopluk|Svatoslav|\0160imon|Tade\00E1\0161|Teodor|Tom\00E1\0161|Vasyl|Viktor|Vil');
wwv_flow_imp.g_varchar2_table(1537) := unistr('\00E9m|Vladim\00EDr|Vladislav|Vlasta|Vlastimil|Vojt\011Bch|Vratislav|V\00E1clav|V\00EDt|V\00EDt\011Bzslav|Zbyn\011Bk|Zden\011Bk|Zikmund|');
wwv_flow_imp.g_varchar2_table(1538) := unistr('\0160tefan|\0160t\011Bp\00E1n|Ad\00E9la|Ag\00E1ta|Alena|Alexandra|Alice|Al\017Eb\011Bta|Anast\00E1zie|And\011Bla|Andrea|Aneta|Ane\017Eka|Anna|Ap');
wwv_flow_imp.g_varchar2_table(1539) := unistr('olena|Barbora|Blanka|Bla\017Eena|Bohumila|Bo\017Eena|Dagmar|Dana|Daniela|Danu\0161e|Denisa|Dita|Dominika|Dorota|');
wwv_flow_imp.g_varchar2_table(1540) := unistr('Drahom\00EDra|Drahoslava|Edita|Elena|Eli\0161ka|Ema|Emilie|Erika|Ester|Eva|Evel\00EDna|Franti\0161ka|Gabriela|Hana|H');
wwv_flow_imp.g_varchar2_table(1541) := unistr('elena|Hedvika|Ilona|Irena|Iva|Ivana|Iveta|Ivona|Jana|Jarmila|Jaroslava|Jind\0159i\0161ka|Jitka|Ji\0159ina|Johana');
wwv_flow_imp.g_varchar2_table(1542) := unistr('|Jolana|Judita|Julie|Kamila|Karol\00EDna|Kate\0159ina|Klaudie|Kl\00E1ra|Kristina|Krist\00FDna|Kv\011Bta|Kv\011Btoslava|Lada|');
wwv_flow_imp.g_varchar2_table(1543) := unistr('Ladislava|Lenka|Leona|Libu\0161e|Linda|Lucie|Ludmila|L\00FDdie|Magdalena|Magdal\00E9na|Mahulena|Marcela|Marie|Ma');
wwv_flow_imp.g_varchar2_table(1544) := unistr('rk\00E9ta|Marta|Martina|Michaela|Milada|Milena|Miloslava|Milu\0161e|Miroslava|Monika|M\00E1ria|Nad\011B\017Eda|Nat\00E1lie|N');
wwv_flow_imp.g_varchar2_table(1545) := unistr('ela|Nina|Nikol|Nikola|Nora|Olivie|Olga|Ot\00FDlie|Patricie|Pavla|Pavl\00EDna|Petra|Radka|Renata|Ren\00E1ta|Roman');
wwv_flow_imp.g_varchar2_table(1546) := unistr('a|R\016F\017Eena|Sabina|Simona|Silvie|Slav\011Bna|So\0148a|Stanislava|Sv\011Btlana|S\00E1ra|\0160\00E1rka|\0160t\011Bp\00E1nka|Tereza|Vanda|Vend');
wwv_flow_imp.g_varchar2_table(1547) := unistr('ula|Veronika|V\011Bra|Viktorie|Vilma|Vladim\00EDra|Zdenka|Zde\0148ka|Zora|Zuzana|Zdislava|\017Daneta|\017Dofie|Ada|Adela');
wwv_flow_imp.g_varchar2_table(1548) := '|Adelaida|Adelina|Adina|Adriana|Agata|Aglaia|Agripina|Aida|Alberta|Albertina|Alexandrina|Alida|Alina';
wwv_flow_imp.g_varchar2_table(1549) := unistr('|Alis|Alma|Amalia|Amanda|Amelia|Ana|Anabela|Anaida|Anamaria|Anastasia|Anca|Ancu\021Ba|Anda|Andra|Andrada');
wwv_flow_imp.g_varchar2_table(1550) := unistr('|Andreea|Anemona|Angela|Anghelina|Anica|Ani\0219oara|Antoaneta|Antonela|Antonia|Anu\021Ba|Ariadna|Ariana|Ari');
wwv_flow_imp.g_varchar2_table(1551) := unistr('na|Aristi\021Ba|Artemisa|Astrid|Atena|Augustina|Aura|Aurelia|Aureliana|Aurica|Aurora|Axenia|Beatrice|Bet');
wwv_flow_imp.g_varchar2_table(1552) := unistr('ina|Bianca|Blanduzia|Bogdana|Br\00E2ndu\0219a|Camelia|Carina|Carla|Carmen|Carmina|Carolina|Casandra|Casiana|');
wwv_flow_imp.g_varchar2_table(1553) := unistr('Caterina|Catinca|Catrina|Catrinel|C\0103t\0103lina|Cecilia|Celia|Cerasela|Cezara|Cipriana|Clara|Clarisa|Clau');
wwv_flow_imp.g_varchar2_table(1554) := unistr('dia|Clementina|Cleopatra|Codrina|Codru\021Ba|Constan\021Ba|Constantina|Consuela|Coralia|Corina|Cornelia|Cosm');
wwv_flow_imp.g_varchar2_table(1555) := unistr('ina|Crengu\021Ba|Crina|Cristina|Daciana|Dafina|Daiana|Dalia|Daria|Dariana|Delia|Demetra|Despina|Diana|Di');
wwv_flow_imp.g_varchar2_table(1556) := 'da|Didina|Dimitrina|Dina|Dochia|Doina|Domnica|Dora|Doriana|Dorina|Dorli|Draga|Dumitra|Dumitrana|Ecat';
wwv_flow_imp.g_varchar2_table(1557) := 'erina|Eftimia|Eleonora|Eliana|Elisabeta|Elisaveta|Eliza|Elodia|Elvira|Emanuela|Emilia|Erica|Estera|E';
wwv_flow_imp.g_varchar2_table(1558) := 'ufrosina|Eugenia|Eusebia|Evanghelina|Evelina|Fabia|Fabiana|Felicia|Filofteia|Fiona|Flavia|Floare|Flo';
wwv_flow_imp.g_varchar2_table(1559) := unistr('area|Flora|Floren\021Ba|Florentina|Floriana|Florica|Florina|Francesca|Frusina|Geanina|Gen\021Biana|Georgeta|');
wwv_flow_imp.g_varchar2_table(1560) := unistr('Georgia|Georgiana|Geta|Gherghina|Gianina|Gina|Giorgiana|Gra\021Biana|Gra\021Biela|Henrieta|Heracleea|Hortens');
wwv_flow_imp.g_varchar2_table(1561) := 'ia|Iasmina|Ica|Ileana|Ilinca|Ina|Ioana|Ioanina|Iolanda|Ionela|Ionelia|Iosefina|Iridenta|Irina|Iris|I';
wwv_flow_imp.g_varchar2_table(1562) := unistr('sabela|Iulia|Iuliana|Iustina|Izabela|Janeta|Janina|Jasmina|Jeana|Julia|Julieta|Larisa|Laura|Lauren\021Bi');
wwv_flow_imp.g_varchar2_table(1563) := unistr('a|Lavinia|L\0103cr\0103mioara|Leana|Lelia|Leontina|Leopoldina|Leti\021Bia|Lia|Liana|Lidia|Ligia|Lili|Liliana|Lio');
wwv_flow_imp.g_varchar2_table(1564) := unistr('ara|Livia|Loredana|Lorelei|Lorena|Luana|Lucia|Luciana|Lucre\021Bia|Ludovica|Luiza|Lumini\021Ba|Maia|Malvina|');
wwv_flow_imp.g_varchar2_table(1565) := 'Manuela|Mara|Marcheta|Marga|Margareta|Maria|Mariana|Maricica|Marilena|Marina|Marinela|Marioara|Matil';
wwv_flow_imp.g_varchar2_table(1566) := unistr('da|M\0103d\0103lina|M\0103lina|M\0103rioara|M\0103riuca|Melania|Melina|Mihaela|Mina|Minodora|Mioara|Mirabela|Mirela|Miro');
wwv_flow_imp.g_varchar2_table(1567) := unistr('na|Miruna|Mona|Monalisa|Monica|Nadia|Narcisa|Natalia|Nata\0219a|Nicoleta|Niculina|Nidia|Noemi|Norica|Oan');
wwv_flow_imp.g_varchar2_table(1568) := 'a|Octavia|Octaviana|Ofelia|Olimpia|Olivia|Ortansa|Otilia|Ozana|Pamela|Paraschiva|Patricia|Paula|Paul';
wwv_flow_imp.g_varchar2_table(1569) := unistr('ica|Paulina|Petronela|Petru\021Ba|Pompilia|Profira|Rada|Rafila|Raluca|Ramona|Rebeca|Rica|Roberta|Roberti');
wwv_flow_imp.g_varchar2_table(1570) := unistr('na|Rodica|Romani\021Ba|Romina|Roxana|Roxelana|Roza|Rozalia|Ruxanda|Ruxandra|Sabrina|Safta|Salomea|Sanda|');
wwv_flow_imp.g_varchar2_table(1571) := unistr('Saveta|Savina|S\00E2nziana|Semenica|Severina|Sidonia|Silvana|Silvia|Silviana|Simina|Smaranda|Sofia|Sonia');
wwv_flow_imp.g_varchar2_table(1572) := unistr('|Sorana|Sorina|Speran\021Ba|Stana|Stanca|Stela|Steliana|Stelu\021Ba|Suzana|Svetlana|\0218tefana|\0218tefania|Tamara|');
wwv_flow_imp.g_varchar2_table(1573) := unistr('Tania|Tatiana|Teea|Teodora|Teodosia|Teona|Tiberia|Timea|Tinca|Tincu\021Ba|Tudora|Tudori\021Ba|Tudosia|Valent');
wwv_flow_imp.g_varchar2_table(1574) := unistr('ina|Valeria|Vanesa|Varvara|Vasilica|Venera|Vera|Veronica|Veta|Vicen\021Bia|Victoria|Violeta|Viorela|Vior');
wwv_flow_imp.g_varchar2_table(1575) := unistr('ica|Virginia|Viviana|Vl\0103delina|Voichi\021Ba|Xenia|Zaharia|Zamfira|Zaraza|Zenobia|Zenovia|Zina|Zoe|Achim|');
wwv_flow_imp.g_varchar2_table(1576) := 'Adelin|Adi|Adonis|Adrian|Agnos|Aleodor|Alex|Alexandru|Alexe|Alin|Alistar|Amedeu|Amza|Anatolie|Andrei';
wwv_flow_imp.g_varchar2_table(1577) := '|Andrian|Angel|Anghel|Antim|Anton|Antonie|Antoniu|Arian|Aristide|Arsenie|Augustin|Aurel|Aurelian|Aur';
wwv_flow_imp.g_varchar2_table(1578) := unistr('ic\0103|Avram|Axinte|Barbu|Bartolomeu|Basarab|B\0103nel|Bebe|Beniamin|Benone|Bernard|Bogdan|Br\0103du\021B|Bucur|Cai');
wwv_flow_imp.g_varchar2_table(1579) := unistr('us|Camil|Cantemir|Carol|Casian|Cazimir|C\0103lin|C\0103t\0103lin|Cedrin|Cezar|Ciprian|Claudiu|Codin|Codrin|Codru');
wwv_flow_imp.g_varchar2_table(1580) := unistr('\021B|Constantin|Cornel|Corneliu|Corvin|Cosmin|Costache|Costel|Costin|Crin|Cristea|Cristian|Cristobal|Cr');
wwv_flow_imp.g_varchar2_table(1581) := unistr('istofor|Dacian|Damian|Dan|Darius|Decebal|Dinu|Dominic|Dorel|Dorian|Dorin|Dorinel|Doru|Drago\0219|Ducu|Du');
wwv_flow_imp.g_varchar2_table(1582) := unistr('mitru|Edgar|Edmond|Eftimie|Emanoil|Emanuel|Emanuil|Emilian|Eremia|Eric|Ernest|Eugen|Eusebiu|Eusta\021Biu');
wwv_flow_imp.g_varchar2_table(1583) := '|Fabian|Fiodor|Flaviu|Florea|Florentin|Florian|Florin|Francisc|Frederic|Gabi|Gabriel|Gelu|George|Geo';
wwv_flow_imp.g_varchar2_table(1584) := unistr('rgel|Georgian|Ghenadie|Gheorghe|Gheorghi\021B\0103|Ghi\021B\0103|Gic\0103|Gicu|Giorgian|Gra\021Bian|Gregorian|Grigore|Harala');
wwv_flow_imp.g_varchar2_table(1585) := unistr('mb|Haralambie|Hora\021Biu|Horea|Horia|Iacob|Iancu|Ianis|Ieremia|Ilarie|Ilarion|Ilie|Inocen\021Biu|Ioan|Ion|I');
wwv_flow_imp.g_varchar2_table(1586) := unistr('onel|Ionic\0103|Ionu\021B|Iosif|Irinel|Iulian|Iuliu|Iurie|Iustin|Iustinian|Jean|Jenel|Ladislau|Lasc\0103r|Lauren');
wwv_flow_imp.g_varchar2_table(1587) := unistr('\021Biu|Laurian|Laz\0103r|Leonard|Leontin|Leordean|Lic\0103|Liviu|Lorin|Luca|Lucen\021Biu|Lucian|Lucre\021Biu|Ludovic|Ma');
wwv_flow_imp.g_varchar2_table(1588) := unistr('nole|Marcu|Marin|Marius|Matei|Maxim|Maximilian|M\0103d\0103lin|Mihai|Mihail|Mihnea|Mircea|Miron|Mitic\0103|Mitru');
wwv_flow_imp.g_varchar2_table(1589) := unistr('\021B|Mugur|Mugurel|Nae|Narcis|Nechifor|Nelu|Nichifor|Nicoar\0103|Nicodim|Nicolae|Nicolaie|Nicu|Niculi\021B\0103|Nic');
wwv_flow_imp.g_varchar2_table(1590) := unistr('u\0219or|Nicu\021B\0103|Norman|Octav|Octavian|Octaviu|Olimpian|Olimpiu|Oliviu|Ovidiu|Pamfil|Panagachie|Panait|Pa');
wwv_flow_imp.g_varchar2_table(1591) := unistr('ul|P\0103tru|Petre|Petric\0103|Petri\0219or|Petru|Petru\021B|Ple\0219u|Pompiliu|Radu|Rafael|Rare\0219|Raul|R\0103ducu|R\0103zvan|Rel');
wwv_flow_imp.g_varchar2_table(1592) := 'u|Remus|Romeo|Romulus|Sabin|Sandu|Sava|Sebastian|Sergiu|Sever|Severin|Silvian|Silviu|Simi|Simion|Sin';
wwv_flow_imp.g_varchar2_table(1593) := unistr('ic\0103|Sorin|Stan|Stancu|Stelian|\0218erban|\0218tefan|Teofil|Teohari|Theodor|Tiberiu|Timotei|Titus|Todor|Toma|');
wwv_flow_imp.g_varchar2_table(1594) := unistr('Traian|Tudor|Valentin|Valeriu|Valter|Vasile|Vasilic\0103|Veniamin|Vicen\021Biu|Victor|Vincen\021Biu|Viorel|Visar');
wwv_flow_imp.g_varchar2_table(1595) := unistr('ion|Vlad|Vladimir|Vlaicu|Voicu|Zamfir|Zeno|Adolf|Adri\00E1n|Alan|Alb\00EDn|Alexej|Alfonz|Alfr\00E9d|Alojz|Ambr\00F3z');
wwv_flow_imp.g_varchar2_table(1596) := unistr('|Andrej|Ariel|Arnold|\00C1ron|Arp\00E1d|Atila|August\00EDn|Bartolomej|Belo|Be\0148adik|Benedikt|Benjam\00EDn|Bla\017Eej|Bohd');
wwv_flow_imp.g_varchar2_table(1597) := unistr('an|Bohu\0161|Bonif\00E1c|Boris|Branislav|Bruno|Bystr\00EDk|Cypri\00E1n|Cyril|D\00E1vid|Demeter|Dezider|Dion\00FDz|Drahom\00EDr|E');
wwv_flow_imp.g_varchar2_table(1598) := unistr('der|Edmund|Eli\00E1\0161|Erv\00EDn|Fedor|F\00E9lix|Flori\00E1n|Frederik|Fridrich|Ga\0161par|Gejza|Gregor|Gust\00E1v|Henrich|Herb');
wwv_flow_imp.g_varchar2_table(1599) := unistr('ert|Hugo|I\013Eja|Imrich|Izidor|Jarol\00EDm|Jergu\0161|J\00FAlius|Juraj|Karol|Kazim\00EDr|Kliment|Koloman|Kon\0161tant\00EDn|Kor');
wwv_flow_imp.g_varchar2_table(1600) := unistr('nel|Kristi\00E1n|Kri\0161tof|Kvetoslav|Leopold|Levoslav|\013Dubom\00EDr|\013Dubor|\013Duboslav|\013Dubo\0161|Ludolf|\013Dudomil|\013Dudov\00EDt|');
wwv_flow_imp.g_varchar2_table(1601) := unistr('Mari\00E1n|M\00E1rio|Maro\0161|Matej|Mat\00FA\0161|Maximili\00E1n|Medard|Melichar|Metod|M\00F3ric|Nathan|Oldrich|Oliver|Ondrej|O');
wwv_flow_imp.g_varchar2_table(1602) := unistr('sk\00E1r|Pankr\00E1c|Pavol|Pravoslav|Prokop|Rad\00FAz|Rastislav|R\00F3bert|Roland|Sebasti\00E1n|Sergej|Serv\00E1c|Sever\00EDn|Si');
wwv_flow_imp.g_varchar2_table(1603) := unistr('lvester|Sv\00E4topluk|Svetoz\00E1r|Tarz\00EDcius|Tibor|Tichom\00EDr|Timotej|Tobi\00E1\0161|Urban|Valent\00EDn|Val\00E9r|Vasil|Vavrin');
wwv_flow_imp.g_varchar2_table(1604) := unistr('ec|Vendel\00EDn|Viliam|Vincent|V\00ED\0165azoslav|Vojtech|Vratko|Zdenko|Zlatko|Zolt\00E1n|Zoran|\017Digmund|Adri\00E1na|Agne');
wwv_flow_imp.g_varchar2_table(1605) := unistr('sa|Aiko|Alana|Alb\00EDna|Alexia|Alica|Alojzia|Al\017Ebeta|Am\00E1lia|Angelika|Ant\00F3nia|Aur\00E9lia|Barbara|Be\00E1ta|Bert');
wwv_flow_imp.g_varchar2_table(1606) := unistr('a|Bianka|Bibi\00E1na|Bohdana|Bohuslava|Bo\017Eidara|Branislava|Brigita|Bronislava|Cec\00EDlia|Dagmara|Danica|Dar');
wwv_flow_imp.g_varchar2_table(1607) := unistr('ina|D\00E1\0161a|Dobromila|Dobroslava|Ela|Eleon\00F3ra|Elisa|Elv\00EDra|Em\00EDlia|Enna|Etela|Eug\00E9nia|Eul\00E1lia|Eunika|Fil');
wwv_flow_imp.g_varchar2_table(1608) := unistr('om\00E9na|Frederika|Gertr\00FAda|Gizela|Hedviga|Herm\00EDna|Hilda|Hortenzia|Ida|Ingrida|Irma|Ivica|Jarom\00EDra|Joze');
wwv_flow_imp.g_varchar2_table(1609) := unistr('f\00EDna|J\00FAlia|Juliana|Just\00EDna|Karina|Karla|Katar\00EDna|Klaudia|Korn\00E9lia|Krist\00EDna|Kvetoslava|Lea|Leopolda|L');
wwv_flow_imp.g_varchar2_table(1610) := unistr('esana|Lesia|Libu\0161a|L\00EDvia|Lolita|\013Dubica|\013Dubom\00EDra|\013Duboslava|\013Dudmila|\013Dudomila|Lujza|Luna|L\00FDdia|Malv\00EDna|');
wwv_flow_imp.g_varchar2_table(1611) := unistr('Margar\00E9ta|Margita|Marianna|Marika|Mar\00EDna|Mel\00E1nia|Milica|Milota|Miriama|Nade\017Eda|Nat\00E1lia|Nata\0161a|O\013Ega|O');
wwv_flow_imp.g_varchar2_table(1612) := unistr('l\00EDvia|Olympia|Ot\00EDlia|Oxana|Patr\00EDcia|Paul\00EDna|Perla|Petrana|Radoslava|Radovana|Rebeka|Reg\00EDna|Roz\00E1lia|R');
wwv_flow_imp.g_varchar2_table(1613) := unistr('u\017Eena|Sab\00EDna|Sandra|Saskia|Sid\00F3nia|Sl\00E1va|Sl\00E1vka|Slavom\00EDra|\0160arlota|\0160tef\00E1nia|Ter\00E9zia|Theodora|Ur\0161u\013Ea|V');
wwv_flow_imp.g_varchar2_table(1614) := unistr('alent\00EDna|Val\00E9ria|Viera|Vieroslava|Vikt\00F3ria|Viola|X\00E9nia|Zara|Zita|Zlatica|Zoja|\017Delm\00EDra|\017Dofia|Mateusz|');
wwv_flow_imp.g_varchar2_table(1615) := unistr('Bartek|Kacper|Micha\0142|Szymon|Antoni|Piotr|Maciej|Aleksander|Franciszek|Miko\0142aj|Stanis\0142aw|Wiktor|Krzys');
wwv_flow_imp.g_varchar2_table(1616) := unistr('ztof|Wojciech|Maksymilian|Dawid|Tomasz|Patryk|Oskar|Pawe\0142|Oliwier|Ignacy|\0141ukasz|Julian|Tymon|Krystia');
wwv_flow_imp.g_varchar2_table(1617) := unistr('n|Marcin|Mi\0142osz|Leon|Tymoteusz|Kajetan|Grzegorz|Rafa\0142|Eryk|Konrad|Ksawery|Nikodem|Przemys\0142aw|Borys|O');
wwv_flow_imp.g_varchar2_table(1618) := unistr('laf|Jerzy|Tadeusz|Andrzej|Witold|Iwo|Juliusz|B\0142a\017Cej|Cezary|Jeremi|Jacek|Konstanty|Ryszard|Stefan|Ale');
wwv_flow_imp.g_varchar2_table(1619) := unistr('ks|Gustaw|Rados\0142aw|J\0119drzej|Kazimierz|Arkadiusz|J\00F3zef|Natan|Cyprian|Mieszko|Nataniel|Maks|Maurycy|Olg');
wwv_flow_imp.g_varchar2_table(1620) := 'ierd|Dariusz|Mariusz|Fryderyk|Tobiasz|Ewa|Kalina|Klara|Urszula|Kaja|Kornelia|Justyna|Sara|Adrianna|A';
wwv_flow_imp.g_varchar2_table(1621) := unistr('niela|Agnieszka|R\00F3\017Ca|Marcelina|Roksana|Natasza|Malwina|Anastazja|Apolonia|Liwia|Ewelina|Julita|Inga|');
wwv_flow_imp.g_varchar2_table(1622) := unistr('Krystyna|Sylwia|Nicole|Anita|El\017Cbieta|Julianna|Tola|Gaja|L\00E1szl\00F3|Istv\00E1n|J\00F3zsef|J\00E1nos|S\00E1ndor|G\00E1bor|Fer');
wwv_flow_imp.g_varchar2_table(1623) := unistr('enc|Attila|P\00E9ter|Tam\00E1s|Zsolt|Andr\00E1s|Csaba|Imre|Lajos|Gy\00F6rgy|Bal\00E1zs|Gyula|Mih\00E1ly|K\00E1roly|D\00E1niel|\00C1d\00E1m|B');
wwv_flow_imp.g_varchar2_table(1624) := unistr('\00E9la|Kriszti\00E1n|Mikl\00F3s|Bence|M\00E1t\00E9|P\00E1l|Gerg\0151|Szabolcs|B\00E1lint|Levente|M\00E1rk|Rich\00E1rd|Antal|Gergely|\00C1kos|\00C1r');
wwv_flow_imp.g_varchar2_table(1625) := unistr('p\00E1d|M\00E1rton|G\00E9za|Krist\00F3f|Mil\00E1n|Barnab\00E1s|Jen\0151|K\00E1lm\00E1n|Marcell|M\00E1ty\00E1s|Ern\0151|Endre|Botond|Zsombor|Dezs\0151|Ol');
wwv_flow_imp.g_varchar2_table(1626) := unistr('iv\00E9r|N\00E1ndor|Szil\00E1rd|Benedek|Vilmos|Korn\00E9l|Zal\00E1n|D\00E9nes|Ott\00F3|Benj\00E1min|Bertalan|Kevin|Noel|Vince|Ervin|');
wwv_flow_imp.g_varchar2_table(1627) := unistr('Gy\0151z\0151|Zsigmond|Andor|Iv\00E1n|Szilveszter|Guszt\00E1v|Barna|\00C1bel|Hunor|Csongor|Elem\00E9r|Krisztofer|Bendeg\00FAz|Ti');
wwv_flow_imp.g_varchar2_table(1628) := unistr('vadar|Henrik|Erzs\00E9bet|Katalin|\00C9va|Zsuzsanna|Margit|Judit|\00C1gnes|Ildik\00F3|Krisztina|Ir\00E9n|Eszter|M\00F3nika|M');
wwv_flow_imp.g_varchar2_table(1629) := unistr('agdolna|Edit|Gabriella|Szilvia|Anik\00F3|M\00E1rta|T\00EDmea|Piroska|Ibolya|T\00FCnde|D\00F3ra|Zs\00F3fia|Gizella|Csilla|Nik');
wwv_flow_imp.g_varchar2_table(1630) := unistr('olett|Melinda|R\00E9ka|N\00F3ra|Adrienn|Vivien|Enik\0151|Bernadett|Rita|Brigitta|Edina|Hajnalka|Gy\00F6ngyi|Bogl\00E1rka');
wwv_flow_imp.g_varchar2_table(1631) := unistr('|Orsolya|Jol\00E1n|No\00E9mi|Etelka|Fanni|Borb\00E1la|Annam\00E1ria|Kitti|Ter\00E9z|Nikoletta|Emese|Lilla|Hanna|Aranka|K');
wwv_flow_imp.g_varchar2_table(1632) := unistr('inga|Anett|R\00F3za|Emma|Beatrix|Zsanett|R\00F3zsa|J\00E1zmin|Di\00E1na|Henrietta|Gy\00F6rgyi|Dorottya|Bettina|Mariann|V');
wwv_flow_imp.g_varchar2_table(1633) := unistr('ir\00E1g|Gr\00E9ta|Albina|Ane|Anka|Ankica|Antonija|An\0111a|An\0111ela|Bara|Barica|Biljana|Biserka|Bo\017Eica|Branka|Dan');
wwv_flow_imp.g_varchar2_table(1634) := 'ijela|Dragica|Elizabeta|Franciska|Fuma|Gordana|Ika|Ivanka|Ivka|Jadranka|Janja|Jasminka|Jasna|Jele|Je';
wwv_flow_imp.g_varchar2_table(1635) := 'lena|Josipa|Julijana|Kata|Katarina|Kate|Katica|Lana|Lara|Lidija|Ljiljana|Ljubica|Lucija|Maja|Manda|M';
wwv_flow_imp.g_varchar2_table(1636) := 'are|Marica|Marija|Marijana|Matea|Mateja|Matija|Mia|Milka|Mira|Mirjana|Nada|Nevenka|Nika|Nikolina|Roz';
wwv_flow_imp.g_varchar2_table(1637) := unistr('alija|Ru\017Ea|Ru\017Eica|Sanja|Slavica|Snje\017Eana|Tatjana|Tea|Terezija|Vesna|Zorka|\0110ur\0111ica|\0160tefanija|\0160tefica|');
wwv_flow_imp.g_varchar2_table(1638) := unistr('\017Deljka|Aldo|Alen|Andrija|Ante|Anto|Antonio|Antun|Bo\017Eo|Branko|Damir|Danijel|Dario|Darko|Davor|Dejan|D');
wwv_flow_imp.g_varchar2_table(1639) := unistr('ino|Domagoj|Dragan|Dragutin|Dra\017Een|Duje|Elvis|Fran|Franjo|Goran|Hrvoje|Ilija|Jakov|Janko|Josip|Joso|');
wwv_flow_imp.g_varchar2_table(1640) := unistr('Jozo|Jo\0161ko|Jure|Karlo|Kristijan|Lovre|Lovro|Luka|Marijan|Mario|Marko|Mate|Mateo|Mato|Mihael|Mijo|Mil');
wwv_flow_imp.g_varchar2_table(1641) := unistr('e|Mirko|Mislav|Mladen|Nenad|Niko|Nik\0161a|Pavao|Pero|Petar|Roko|Romano|Sa\0161a|Sini\0161a|Slavko|Stjepan|Tomis');
wwv_flow_imp.g_varchar2_table(1642) := unistr('lav|Tomo|Toni|Vedran|Vjekoslav|Vlado|Zdravko|Zvonko|\0110uro|\0160ime|\017Deljko'';'||wwv_flow.LF||
'    l_last_name_catalog(4) :=');
wwv_flow_imp.g_varchar2_table(1643) := unistr(' ''B\00E1rta|Barto\0161|Bedn\00E1\0159|Bene\0161|Beran|Ber\00E1nek|B\00EDlek|Bl\00E1ha|Bla\017Eek|Bro\017E|Bure\0161|\010Cech|\010Cerm\00E1k|\010Cern\00FD|Dole\017Eal|Do');
wwv_flow_imp.g_varchar2_table(1644) := unistr('st\00E1l|Du\0161ek|Dvo\0159\00E1k|Fiala|Fi\0161er|H\00E1jek|Havel|Havl\00ED\010Dek|Holub|Hor\00E1\010Dek|Hor\00E1k|Horv\00E1th|Hrub\00FD|Hru\0161ka|Janda|Ja');
wwv_flow_imp.g_varchar2_table(1645) := unistr('ro\0161|Jel\00EDnek|Je\017Eek|Kadlec|Ka\0161par|Kol\00E1\0159|Kone\010Dn\00FD|Kopeck\00FD|Kov\00E1\0159|Kr\00E1l|Kratochv\00EDl|Kraus|K\0159\00ED\017E|Kub\00ED\010Dek|Ku\010Der');
wwv_flow_imp.g_varchar2_table(1646) := unistr('a|Li\0161ka|Mach|Mach\00E1\010Dek|Mal\00FD|Marek|Mare\0161|Ma\0161ek|Mat\011Bjka|Matou\0161ek|Moravec|M\00FCller|Musil|Navr\00E1til|N\011Bmec|N\011B');
wwv_flow_imp.g_varchar2_table(1647) := unistr('me\010Dek|Nov\00E1k|Novotn\00FD|Pavl\00ED\010Dek|Pavl\00EDk|Pokorn\00FD|Pol\00E1k|Posp\00ED\0161il|Proch\00E1zka|Prokop|R\016F\017Ei\010Dka|\0158\00EDha|Sedl\00E1\010Dek|Se');
wwv_flow_imp.g_varchar2_table(1648) := unistr('dl\00E1k|Slav\00EDk|Soukup|Stan\011Bk|Stejskal|Strnad|Svoboda|S\00FDkora|\0160ev\010D\00EDk|\0160imek|\0160m\00EDd|\0160\0165astn\00FD|\0160t\011Bp\00E1nek|\0160vec|Tes');
wwv_flow_imp.g_varchar2_table(1649) := unistr('a\0159|Tich\00FD|Toman|T\016Fma|Urban|Vacek|Valenta|Van\011Bk|V\00E1vra|Vesel\00FD|V\00EDtek|Vl\010Dek|Zeman|\017D\00E1k|Barto\0161ov\00E1|B\00E1rtov\00E1|B');
wwv_flow_imp.g_varchar2_table(1650) := unistr('edn\00E1\0159ov\00E1|Bene\0161ov\00E1|Ber\00E1nkov\00E1|Beranov\00E1|B\00EDlkov\00E1|Bl\00E1hov\00E1|Bla\017Ekov\00E1|Bro\017Eov\00E1|Bure\0161ov\00E1|\010Cechov\00E1|\010Cerm\00E1kov\00E1|\010Cer');
wwv_flow_imp.g_varchar2_table(1651) := unistr('n\00E1|Dole\017Ealov\00E1|Dost\00E1lov\00E1|Du\0161kov\00E1|Dvo\0159\00E1kov\00E1|Fialov\00E1|Fi\0161erov\00E1|H\00E1jkov\00E1|Havl\00ED\010Dkov\00E1|Holubov\00E1|Hor\00E1\010Dkov\00E1|Hor');
wwv_flow_imp.g_varchar2_table(1652) := unistr('\00E1kov\00E1|Horv\00E1thov\00E1|Hrub\00E1|Hru\0161kov\00E1|Jandov\00E1|Jane\010Dkov\00E1|Jaro\0161ov\00E1|Jel\00EDnkov\00E1|Je\017Ekov\00E1|Kadlecov\00E1|Ka\0161parov\00E1|Kol');
wwv_flow_imp.g_varchar2_table(1653) := unistr('\00E1\0159ov\00E1|Kone\010Dn\00E1|Kopeck\00E1|Kov\00E1\0159ov\00E1|Kr\00E1lov\00E1|Kratochv\00EDlov\00E1|Krausov\00E1|Krej\010Dov\00E1|K\0159\00ED\017Eov\00E1|Kub\00ED\010Dkov\00E1|Ku\010Derov\00E1|Li');
wwv_flow_imp.g_varchar2_table(1654) := unistr('\0161kov\00E1|Mach\00E1\010Dkov\00E1|Machov\00E1|Mal\00E1|Mare\0161ov\00E1|Markov\00E1|Ma\0161kov\00E1|Mat\011Bjkov\00E1|Matou\0161kov\00E1|Moravcov\00E1|M\00FCllerov\00E1|Musi');
wwv_flow_imp.g_varchar2_table(1655) := unistr('lov\00E1|Navr\00E1tilov\00E1|N\011Bmcov\00E1|N\011Bme\010Dkov\00E1|Nov\00E1kov\00E1|Novotn\00E1|Pavl\00EDkov\00E1|Pe\0161kov\00E1|Petrov\00E1|Pokorn\00E1|Pol\00E1kov\00E1|Posp\00ED');
wwv_flow_imp.g_varchar2_table(1656) := unistr('\0161ilov\00E1|Proch\00E1zkov\00E1|R\016F\017Ei\010Dkov\00E1|\0158\00EDhov\00E1|Sedl\00E1\010Dkov\00E1|Sedl\00E1kov\00E1|Slav\00EDkov\00E1|Soukupov\00E1|Sta\0148kov\00E1|Stejskalov\00E1|St');
wwv_flow_imp.g_varchar2_table(1657) := unistr('rnadov\00E1|Svobodov\00E1|S\00FDkorov\00E1|\0160ev\010D\00EDkov\00E1|\0160imkov\00E1|\0160m\00EDdov\00E1|\0160\0165astn\00E1|\0160t\011Bp\00E1nkov\00E1|\0160vecov\00E1|Tich\00E1|Tomanov\00E1|T\016Fmov');
wwv_flow_imp.g_varchar2_table(1658) := unistr('\00E1|Urbanov\00E1|Vackov\00E1|Valentov\00E1|Va\0148kov\00E1|V\00E1vrov\00E1|Vesel\00E1|V\00EDtkov\00E1|Vl\010Dkov\00E1|Zemanov\00E1|\017D\00E1kov\00E1|Aanei|Ababei|Alb');
wwv_flow_imp.g_varchar2_table(1659) := 'u|Ardelean|Barbu|Cristea|Diaconescu|Diaconu|Dima|Dinu|Dobre|Dochioiu|Dumitrescu|Eftimie|Ene|Florea|G';
wwv_flow_imp.g_varchar2_table(1660) := unistr('eorgescu|Gheorghiu|Ionescu|Ioni\021B\0103|Manole|Marin|Mazilescu|Mocanu|Neme\0219|Nistor|Ni\021B\0103|Oprea|Pop|Popa|Pop');
wwv_flow_imp.g_varchar2_table(1661) := unistr('escu|Preda|Pu\0219ca\0219u|Stan|Stancu|Stoica|St\0103nescu|Suciu|Tabacu|Toma|Tomescu|Tudor|Voinea|Abrah\00E1m|Adam|A');
wwv_flow_imp.g_varchar2_table(1662) := unistr('damec|Achberger|Andr\00E1\0161|Andra\0161\00EDk|Andr\00E1\0161ik|Antal|Babjak|Babka|Ba\010Da|Bahna|Bahno|Bal\00E1\017E|B\00E1n|Ba\0148a|Ba\0148as|Ba');
wwv_flow_imp.g_varchar2_table(1663) := unistr('\0148o|Baran|Baranka|Barbora|Barok|Barto\0161\00EDk|Bartovi\010D|Ba\0161a|Ba\0161ka|Ba\0161ko|Ba\0161o|Bedn\00E1r|Bedn\00E1rik|Beka|Be\0148a|Be\0148');
wwv_flow_imp.g_varchar2_table(1664) := unistr('o|Be\0148u\0161|Be\0148u\0161ka|Bernard|Bernol\00E1k|Bez\00E1k|Bicek|Bielik|Bilek|Bilka|Bilko|Blaha|Blaho|Bla\017Eej|Bobula|Bobu');
wwv_flow_imp.g_varchar2_table(1665) := unistr('\013Ea|Bondra|Borek|Bor\00EDk|B\00F3rik|Borik|Boris|Bori\0161|Borka|Borko|Borovsk\00FD|Borov\00FD|Bos\00E1k|Bo\0161ka|Bo\0161\0148\00E1k|B\00F4rik|B');
wwv_flow_imp.g_varchar2_table(1666) := unistr('rezina|Brunovsk\00FD|Bru\0161ka|Bru\0161ko|Bukovsk\00FD|Capek|Capka|Capko|Centek|Cesnak|Cibula|Cibu\013Ea|Cibulka|Cibu\013Ek');
wwv_flow_imp.g_varchar2_table(1667) := unistr('a|Cig\00E1n|Cig\00E1\0148|Cig\00E1nik|C\00EDger|Cyprich|\010Capka|\010Capko|\010Capkovi\010D|\010Capla|\010Cap\013Ea|\010Caplovi\010D|\010Carnogursk\00FD|\010Cekovsk\00FD|\010C');
wwv_flow_imp.g_varchar2_table(1668) := unistr('ern\00EDk|\010Cernoch|\010Cerve\0148|\010Cerven\00FD|\010Cesnek|\010Ciernik|\010Cierny|\010Cobrda|\010Ea\010Fo|D\00E1n|Da\0148a|Danc\00E1k|Dan\010D\00E1k|Dan\010Diak|Danek|');
wwv_flow_imp.g_varchar2_table(1669) := unistr('Danko|Da\0148ko|Dano|Da\0148o|D\00E1vid|De\00E1k|Debn\00E1r|Dej|Dek\00FD\0161|Deve\010Dka|Dob\0161insk\00FD|Do\010Dolomansk\00FD|Dora|Dorka|Dorko|\010Eo');
wwv_flow_imp.g_varchar2_table(1670) := unistr('rko|Dorot|Dorota|Drajna|Drobn\00FD|Droppa|Drot\00E1r|Dubni\010Dka|Dubovsk\00FD|Duda|Dudek|Dudik|Dud\00EDk|Dudka|Dudko|Du');
wwv_flow_imp.g_varchar2_table(1671) := unistr('do|Dudok|Dula|Dulla|\010Eur\010Da|\010Eur\010Do|Durd\00EDk|\010Eurek|\010Eurica|\010Euri\0161|\010Eurka|\010Eurko|\010Eurkovi\010D|\010Eurkovsk\00FD|\010Euro|\010Eurovi');
wwv_flow_imp.g_varchar2_table(1672) := unistr('\010D|\010Eurovsk\00FD|Dus\00EDk|Duska|Dusko|Du\0161a|Du\0161i\010Dka|Du\0161ka|D\00FA\0161ka|Du\0161ko|\010Eu\0161ko|Dutka|\010Eutka|Dutko|Dvon\010D|Dvorsk\00FD|Dz');
wwv_flow_imp.g_varchar2_table(1673) := unistr('urjanin|Fabian|Fabi\00E1n|Fabu\0161|Fajnor|Farka\0161ovsk\00FD|Fa\0161iang|Fedor|Feldek|Fico|Filc|Filip|Filipek|Fil\00EDpek|');
wwv_flow_imp.g_varchar2_table(1674) := unistr('Filipko|Finka|Foga\0161|Forg\00E1\010D|Fra\0148a|Franek|Franka|Franko|Frano|Fra\0148o|Frimer|Ft\00E1\010Dnik|Ftorek|G\00E1l|Galik|Ga');
wwv_flow_imp.g_varchar2_table(1675) := unistr('l\00EDk|G\00E1lik|Ga\0161par|Ga\0161parovi\010D|Gavalier|Gavenda|Gavorn\00EDk|Ga\017Eo|Gocn\00EDk|Gregor|Gregu\0161|Gr\0148a|Grzn\00E1r|Habl\00E1k|H');
wwv_flow_imp.g_varchar2_table(1676) := unistr('ab\0161uda|Hagara|Hal\00E1k|Halu\0161ka|Hanak|Han\00E1k|Ha\0148ak|Ha\0148\00E1k|Hanek|Hanka|Hanko|Hanus|Hanusek|Han\00FAsek|Hanuska|');
wwv_flow_imp.g_varchar2_table(1677) := unistr('Han\00FAska|Hanu\0161ka|Hanzel|Harvan|Harv\00E1nek|Ha\0161\010D\00E1k|Havran|Havranka|Havranko|He\010Dko|Heretik|Hilmer|Hladk\00FD|H');
wwv_flow_imp.g_varchar2_table(1678) := unistr('lav\00E1\010D|Hlav\00E1\010Dik|Hlin\00EDk|Hlinka|Hod\017Ea|Hol\010D\00EDk|Holi\010D|Holi\010Dek|Hol\00ED\010Dek|Holi\010Dka|Hol\00EDk|Holubec|Holubek|Hol\00FAbe');
wwv_flow_imp.g_varchar2_table(1679) := unistr('k|Holubka|Holubko|Hol\00FAbok|Holuby|Ho\0161t\00E1k|Ho\0161\0165\00E1k|Hoza|Hra\0161ko|Hrdli\010Dka|Hrianka|Hric|Hrmo|Hrobo\0148|Hru\0161ovs');
wwv_flow_imp.g_varchar2_table(1680) := unistr('k\00FD|Huba|Hu\010Dko|Hud\00E1\010Dek|Hudec|Hupka|Hus|H\00FAs|Hus\00E1k|Hus\00E1r|Huska|H\00FAska|Hus\0165\00E1k|Hu\0161ek|H\00FA\0161ek|Hu\0161ka|H\00FA\0161ka|Hu\0161');
wwv_flow_imp.g_varchar2_table(1681) := unistr('o|Hu\0161t\00E1k|Hu\0161\0165\00E1k|Hutta|Chalupka|Chovan|Chovanec|Chrappa|Chud\00EDk|Ihna\010D\00E1k|Imrich|Iva\0161ka|Jakub|Jakuba|Jak');
wwv_flow_imp.g_varchar2_table(1682) := unistr('ub\010Dek|Jakub\010D\00EDk|Jakub\010Do|Jakubec|Jakubek|Jak\00FAbek|Jakub\00EDk|Jakubka|Jakubko|Jalovec|J\00E1n|Jan\00E1k|Jan\010Da|Jan\010De');
wwv_flow_imp.g_varchar2_table(1683) := unistr('k|Jan\010Do|Jane\010Dek|Jane\010Dka|Jane\010Dko|Janek|Jan\00EDk|Janka|Janko|Jano|J\00E1no|Jano\010Dko|Jano\0161|J\00E1no\0161|Jano\0161ek|J\00E1no\0161\00ED');
wwv_flow_imp.g_varchar2_table(1684) := unistr('k|Jano\0161ka|J\00E1no\0161ka|Jano\0161ko|J\00E1no\0161ko|Jano\0161o|Janto\0161ovi\010D|Jed\013Eovsk\00FD|Jendek|Jonata|Junas|Jun\00E1s|Jun\00E1\0161|Jur\00E1\0161|');
wwv_flow_imp.g_varchar2_table(1685) := unistr('Jur\010Da|Jur\010Dina|Jur\010Do|Jurek|Jur\00EDk|Jurina|Jurka|Jurko|Jurkovi\010D|Kali\0148\00E1k|Kalisk\00FD|Kaniak|K\00E1ra|Karul|Kavasc');
wwv_flow_imp.g_varchar2_table(1686) := unistr('h|Kazik|Kaz\00EDk|K\00E1zik|Kello|Kelo|Kendra|Ken\00ED\017E|Ker|Kisel|Kise\013E|Kisela|Kise\013Ea|Klapa\010D|Klap\00E1\010D|Klapka|Klapk');
wwv_flow_imp.g_varchar2_table(1687) := unistr('o|Klep\00E1\010D|Klima|Klim\00E1\010Dek|Klimek|Klimko|Klimkovi\010D|Klimo|Kli\017Ean|Kloko\010D|Klopa\010Dka|Kniha|Kobielsky|Kobiels');
wwv_flow_imp.g_varchar2_table(1688) := unistr('k\00FD|Koc|Koc\00E1k|Kocian|Kocka|Kocur|Koc\00FAr|Koc\00FArik|Ko\010D|Ko\010Di\0161|Ko\010Dka|Ko\010Dko|Kol\00E1r|Koles\00E1r|Koll\00E1r|Kolnik|Koln');
wwv_flow_imp.g_varchar2_table(1689) := unistr('\00EDk|Konopka|Kon\00F4pka|Konr\00E1d|Kopa|Koppa|Kor\010D\00E1k|Korec|Kostka|Kostrec|Kotian|Kotuli\010D|Kouba|Kov\00E1\010D|Kov\00E1\010Dik|');
wwv_flow_imp.g_varchar2_table(1690) := unistr('Kova\013E|Koval\010D\00EDk|Koza|Koz\00E1\010Dek|Koz\00E1\010Dik|Koz\00E1k|Kozmon|K\00F4stka|Kraj\010Di|Kraj\010D\00ED|Kraj\010D\00EDr|Kraj\010Do|Kraj\010Dovi\010D|Kraj\00ED');
wwv_flow_imp.g_varchar2_table(1691) := unistr('\010Dek|Kr\00E1\013E|Kr\00E1lik|Kr\00E1\013Eovi\010D|Kram\00E1r|Krasnohorsk\00FD|Kr\00E1snohorsk\00FD|Kri\0161tof|Kr\00ED\017E|Kri\017Ean|Kr\00ED\017Eik|Kropil\00E1k|Krot\00E1k');
wwv_flow_imp.g_varchar2_table(1692) := unistr('|Krupa|Kr\00FApa|Kuba|Kubec|Kubek|K\00FAbek|Kubi\010Dek|Kubi\010Dka|Kubi\010Dko|Kub\00EDk|Kubko|Kubo|Kuffa|Kuna|Kunda|Kunka|');
wwv_flow_imp.g_varchar2_table(1693) := unistr('Kupa|Kupka|Kupko|Kuruc|Kus|K\00FAs|Kuska|K\00FAska|K\00FA\0161|Ku\0161a|Ku\0161ka|Ku\0161n\00EDr|Ku\0161o|Kysel|Kyse\013E|Kysela|Kyse\013Ea|Labu');
wwv_flow_imp.g_varchar2_table(1694) := unistr('da|Laca|Lacka|Lacko|Laco|Laj\010D\00E1k|Laj\010Diak|Lama\010D|Lep\0161\00EDk|Lesn\00FD|Leto|Lipa|Lipka|Lipko|Lipt\00E1k|Lisick\00FD|L\00ED\0161k');
wwv_flow_imp.g_varchar2_table(1695) := unistr('a|Litva|Loj|Loja|Lojek|Lojka|Lojko|Lubina|Luk\00E1\010D|Luk\0161a|Lupt\00E1k|\013Dupt\00E1k|M\00E1c|Maca|Macek|Macka|M\00E1cka|Macko');
wwv_flow_imp.g_varchar2_table(1696) := unistr('|Mackovi\010D|Maco|Ma\010Dek|M\00E1\010Dek|M\00E1\010Dik|Ma\010Dko|Ma\010Dkovi\010D|Ma\010Do|Madar|Ma\010Far|Ma\010F\00E1r|Madara|Ma\010Fara|Ma\010Fari\010D|Madej|M');
wwv_flow_imp.g_varchar2_table(1697) := unistr('ag\00E1l|Machata|Machn\00E1\010D|Macho|Majdan|Majd\00E1n|Majesk\00FD|Mak|Mako|Makovec|Makovica|Makovick\00FD|Makov\00FD|Malachov');
wwv_flow_imp.g_varchar2_table(1698) := unistr('sk\00FD|Malina|Mal\00ED\0161ek|Mamojka|Marcin|Marcinek|Marcinko|Mare\010Dek|Margita|Mari\00E1n|Marko|Marko\0161|Markovi\010D|Mar');
wwv_flow_imp.g_varchar2_table(1699) := unistr('ku\0161|Maro\0161|Marta|Mart\00E1\0148|Mar\0165an|Martin|Martin\00E1k|Martin\010Dek|Martinec|Martinek|Martinka|Martinko|Martinko');
wwv_flow_imp.g_varchar2_table(1700) := unistr('vi\010D|Martinovi\010D|Mas\00E1r|Masarik|Masar\00EDk|Mas\00E1rik|Masaryk|Maslo|Masn\00FD|Matia\0161ko|Maur\00E9ry|Me\010Diar|Medveck\00FD|Me');
wwv_flow_imp.g_varchar2_table(1701) := unistr('dve\010F|Melichar|Melich\00E1r|Melich\00E1rek|Melicher|Melicher\010D\00EDk|Melicher\00EDk|Men\0161\00EDk|Mihalik|Mihal\00EDk|Mih\00E1lik|Mic');
wwv_flow_imp.g_varchar2_table(1702) := unistr('halech|Mich\00E1lech|Michalek|Mich\00E1lek|Michalica|Michal\00EDk|Mich\00E1lik|Michalka|Michalko|Mikl\00EDk|Miklo\0161|Miklo');
wwv_flow_imp.g_varchar2_table(1703) := unistr('\0161ko|Mikul\00E1k|Mikul\00EDk|Miku\0161|Mik\00FA\0161|Milota|Min\00E1\010D|Mistr\00EDk|Mi\0161\00EDk|Mlyn\00E1r|Mlyn\00E1rik|Moj\017Ei\0161|Mokro\0161|Mora|Morav\010D');
wwv_flow_imp.g_varchar2_table(1704) := unistr('\00EDk|Moric|M\00F3ric|Moty\010Dka|Motyka|Mraz|Mr\00E1z|Mrazek|Mr\00E1zik|Mr\00E1zka|Mrazko|Mr\00E1zko|Mucha|Murga\0161|Murin|Mur\00EDn|');
wwv_flow_imp.g_varchar2_table(1705) := unistr('Mydlo|N\00E1lepka|Navara|Nemec|Nitra|Ni\017Enansk\00FD|Ni\017En\00E1nsky|Ni\017E\0148ansk\00FD|Nota|Novota|N\00F4ta|Ob\0161ut|O\010Den\00E1\0161|Ondr\00E1\0161|');
wwv_flow_imp.g_varchar2_table(1706) := unistr('Ondr\00E1\0161ek|Ondra\0161\00EDk|Ondr\00E1\0161ik|Ondrejka|Ondrejko|Ondrejkovi\010D|Ondrus|Ondrusek|Ondru\0161|Ondru\0161ek|Ondr\00FA\0161ek|On');
wwv_flow_imp.g_varchar2_table(1707) := unistr('dru\0161ka|Ondru\0161ko|Oplu\0161til|Orl\00EDk|Ot\010Den\00E1\0161|Pajer|Pa\013Ea|Palka|Pa\013Eka|P\00E1lka|Palko|Pa\013Eko|Palkovi\010D|Palla|Pallo');
wwv_flow_imp.g_varchar2_table(1708) := unistr('|Palo|Pa\013Eo|Palov|Pa\013Eov|Palov\010D\00EDk|Pa\013Eov\010D\00EDk|Palovi\010D|Paluch|Pal\00FAch|Pa\013Euch|Pa\013E\00FAch|Pa\0161ek|Pa\0161ka|Pa\0161ko|Pa\00FAk|');
wwv_flow_imp.g_varchar2_table(1709) := unistr('Pauko|Pauli\010Dek|Paul\00ED\010Dek|Paulik|Paul\00EDk|Paulovi\010D|Pavel|Pavelek|Pavelka|Pavelko|Pavka|Pavko|Pavli\010Dek|Pa');
wwv_flow_imp.g_varchar2_table(1710) := unistr('vli\010Dko|Pavlik|Pavlikovsk\00FD|Pavlo|Pavlov|Pavlovi\010D|Pavol|Pavuk|Pav\00FAk|Pelik\00E1n|Pe\0161ka|Pe\0161ko|Petrovick\00FD|Pet');
wwv_flow_imp.g_varchar2_table(1711) := unistr('ru\0161ka|Pika|Pi\0161\00FAt|Plaucha|Plavec|Plavucha|Plekanec|Ple\0161ivec|Plch|Podhradsk\00FD|Podkonick\00FD|Poliak|Poll\00E1k|');
wwv_flow_imp.g_varchar2_table(1712) := unistr('Porubjak|Puklu\0161|Pup\00E1k|Pu\0161ka|Pu\0161k\00E1r|Rak|Rakovan|Repisk\00FD|Riha|Richard|Richt\00E1r|Ri\0161a|Ri\0161ka|Ri\0161ko|Ri\0161o|Ro');
wwv_flow_imp.g_varchar2_table(1713) := unistr('h\00E1\010D|Roh\00E1\010Dek|Roh\00E1\010Dik|Rojek|Rojka|Rojko|R\00F3m|Roman\010D\00EDk|Rosa|Rosina|Rub\00EDk|R\00FAfus|Rus|Rusko|Rusnak|Rusn\00E1k|R');
wwv_flow_imp.g_varchar2_table(1714) := unistr('us\0148ak|Rus\0148\00E1k|Ru\017Ei\010Dka|Ryb\00E1r|Ryb\00E1rik|Rybn\00ED\010Dek|Rys|R\00FDs|Ry\0161|Ry\0161a|Ry\0161ka|Ry\0161ko|Salaj|Salajka|Same\013E|S\00E1mel|S');
wwv_flow_imp.g_varchar2_table(1715) := unistr('\00E1me\013E|Samel|Samson|Samuel|Sanitra|Se\010D|Sedliak|Sekera|Seleck\00FD|Senko|Sidor|Simon|Skl\00E1r|Sklen\00E1r|Sklen\00E1ri');
wwv_flow_imp.g_varchar2_table(1716) := unistr('k|Sklenica|Skleni\010Dka|Sklenka|Skokan|Skuteck\00FD|Sla\0161\0165an|Slivka|Slivko|Sloboda|Slobodn\00EDk|Slota|Slov\00E1k|Sl');
wwv_flow_imp.g_varchar2_table(1717) := unistr('ovinec|Smrek|Sokol|Solej|Starosta|Stodola|Straka|Strnisko|Str\00FD\010Dek|Svrb\00EDk|\0160alajka|\0160arkan|\0160ebo|\0160idlo|\0160');
wwv_flow_imp.g_varchar2_table(1718) := unistr('ima|\0160im\00EDk|\0160imka|\0160imko|\0160imo|\0160imon|\0160imon\010Di\010D|\0160imonovi\010D|\0160kant\00E1r|\0160koviera|\0160kriniar|\0160kult\00E9ty|\0160lahor|\0160livka');
wwv_flow_imp.g_varchar2_table(1719) := unistr('|\0160majda|\0160olt\00E9s|\0160olt\00FDs|\0160pil\00E1r|\0160tefan|\0160tef\00E1nek|\0160tef\00E1nik|\0160tefanka|\0160tefanko|\0160tefanovi\010D|\0160tefunko|\0160trba|\0160u');
wwv_flow_imp.g_varchar2_table(1720) := unistr('lc|\0160u\0148avec|\0160urka|\0160v\00E1b|\0160v\00E1by|\0160vehla|Talpa\0161|\0164ap\00E1k|Tatar|Tat\00E1r|Tatarka|Tat\00E1rka|\0164a\017Ek\00FD|Thomka|Timek|Timka');
wwv_flow_imp.g_varchar2_table(1721) := unistr('|Timko|Tirp\00E1k|Toma\0148|Tomana|Tomanek|Tom\00E1nek|Toman\00EDk|Tom\00E1\0161|Toma\0161ek|Tom\00E1\0161ek|Tom\00E1\0161ik|Toma\0161ka|Tom\00E1\0161ka|Tom');
wwv_flow_imp.g_varchar2_table(1722) := unistr('a\0161ko|Tom\00E1\0161ko|Tome\010Dek|Tome\010Dka|Tome\010Dko|Tomek|Tomka|Tomko|Topo\013Esk\00FD|Trl\00EDk|Truben|Tup\00FD|Tur\010Dok|Uram|Urbl\00EDk');
wwv_flow_imp.g_varchar2_table(1723) := unistr('|Vajcik|Vajc\00EDk|Vajda|Valach|Valachovi\010D|Valent|Valent\00EDn|Val\00ED\010Dek|Valu\0161ek|Valu\0161ka|Vanek|Vaska|V\00E1ska|Vas');
wwv_flow_imp.g_varchar2_table(1724) := unistr('ko|Va\0161ek|Va\0161ka|Va\0161ko|Vavrinec|Vel\010F\00E1k|Vesel|Vetern\00EDk|Vicen|Vicena|Vi\0161\0148ovsk\00FD|Vlach|Vlachovi\010D|Vlk|Vlna|');
wwv_flow_imp.g_varchar2_table(1725) := unistr('Vlnka|Vojtek|Vojtka|Vojtko|Vozar|Voz\00E1r|Vrabec|Vrablec|Vydaren\00FD|Z\00E1borsk\00FD|Zachar|Zachara|Zacharia\0161|Zac');
wwv_flow_imp.g_varchar2_table(1726) := unistr('hari\00E1\0161|Zajac|Zigo|Zima|Zimka|Zubek|Z\00FAbek|Zubka|Zubko|Zubr\00EDk|Z\00FAbrik|\017Delezn\00EDk|\017Digmund|\017Digo|Abrah\00E1mov\00E1|');
wwv_flow_imp.g_varchar2_table(1727) := unistr('Adamov\00E1|Adamecov\00E1|Achbergerov\00E1|Andr\00E1\0161ov\00E1|Andra\0161\00EDkov\00E1|Andr\00E1\0161ikov\00E1|Antalov\00E1|Babjakov\00E1|Bahnov\00E1|Bal\00E1\017Eov\00E1');
wwv_flow_imp.g_varchar2_table(1728) := unistr('|B\00E1nov\00E1|Ba\0148asov\00E1|Baranov\00E1|Barankov\00E1|Barokov\00E1|Barto\0161\00EDkov\00E1|Bartovi\010Dov\00E1|Ba\0161ov\00E1|Ba\0161kov\00E1|Bedn\00E1rov\00E1|Bedn\00E1r');
wwv_flow_imp.g_varchar2_table(1729) := unistr('ikov\00E1|Be\0148ov\00E1|Be\0148u\0161ov\00E1|Be\0148u\0161kov\00E1|Bernardov\00E1|Bernol\00E1kov\00E1|Bez\00E1kov\00E1|Bicekov\00E1|Bielikov\00E1|Bilekov\00E1|Bilkov\00E1|');
wwv_flow_imp.g_varchar2_table(1730) := unistr('Blahov\00E1|Bla\017Eejov\00E1|Bobulov\00E1|Bobu\013Eov\00E1|Bondrov\00E1|Borekov\00E1|Bor\00EDkov\00E1|B\00F3rikov\00E1|Borikov\00E1|Borisov\00E1|Bori\0161ov\00E1|B');
wwv_flow_imp.g_varchar2_table(1731) := unistr('orkov\00E1|Bos\00E1kov\00E1|Bo\0161\0148\00E1kov\00E1|B\00F4rikov\00E1|Brezinov\00E1|Brunovsk\00E1|Bru\0161kov\00E1|Bukovsk\00E1|Capekov\00E1|Capkov\00E1|Centekov\00E1|');
wwv_flow_imp.g_varchar2_table(1732) := unistr('Cesnakov\00E1|Cibulov\00E1|Cibu\013Ekov\00E1|Cig\00E1nov\00E1|Cig\00E1\0148ov\00E1|Cig\00E1nikov\00E1|C\00EDgerov\00E1|Cyprichov\00E1|\010Capkov\00E1|\010Capkovi\010Dov\00E1|\010Ca');
wwv_flow_imp.g_varchar2_table(1733) := unistr('plovi\010Dov\00E1|\010Carnogursk\00E1|\010Cekovsk\00E1|\010Cern\00EDkov\00E1|\010Cernochov\00E1|\010Cerve\0148ov\00E1|\010Cesnekov\00E1|\010Ciernikov\00E1|\010Ciernaov\00E1|\010Cobrdov');
wwv_flow_imp.g_varchar2_table(1734) := unistr('\00E1|\010Ea\010Fov\00E1|D\00E1nov\00E1|Da\0148ov\00E1|Danc\00E1kov\00E1|Dan\010D\00E1kov\00E1|Dan\010Diakov\00E1|Danekov\00E1|Dankov\00E1|Da\0148kov\00E1|Danov\00E1|D\00E1vidov\00E1|De\00E1ko');
wwv_flow_imp.g_varchar2_table(1735) := unistr('v\00E1|Debn\00E1rov\00E1|Dek\00FD\0161ov\00E1|Deve\010Dkov\00E1|Dob\0161insk\00E1|Do\010Dolomansk\00E1|Dorov\00E1|Dorkov\00E1|\010Eorkov\00E1|Dorotov\00E1|Drajnov\00E1|Drob');
wwv_flow_imp.g_varchar2_table(1736) := unistr('n\00E1|Droppov\00E1|Drot\00E1rov\00E1|Dubovsk\00E1|Dudov\00E1|Dudekov\00E1|Dud\00EDkov\00E1|Dudkov\00E1|Dudokov\00E1|Dulov\00E1|Dullov\00E1|\010Eur\010Dov\00E1|Durd');
wwv_flow_imp.g_varchar2_table(1737) := unistr('\00EDkov\00E1|\010Eurekov\00E1|\010Euricov\00E1|\010Euri\0161ov\00E1|\010Eurkovi\010Dov\00E1|\010Eurkovsk\00E1|\010Eurov\00E1|\010Eurovi\010Dov\00E1|\010Eurovsk\00FDov\00E1|Dus\00EDkov\00E1|Duskov');
wwv_flow_imp.g_varchar2_table(1738) := unistr('\00E1|Du\0161ov\00E1|Du\0161ekov\00E1|Du\0161i\010Dkov\00E1|Dutkov\00E1|\010Eutkov\00E1|Dvon\010Dov\00E1|Dvorsk\00E1|Dzurjaninov\00E1|Fabianov\00E1|Fabi\00E1nov\00E1|Fabu\0161o');
wwv_flow_imp.g_varchar2_table(1739) := unistr('v\00E1|Fajnorov\00E1|Farka\0161ovsk\00E1|Fa\0161iangov\00E1|Fedorov\00E1|Feldekov\00E1|Ficov\00E1|Filcov\00E1|Filipov\00E1|Filipekov\00E1|Fil\00EDpekov\00E1');
wwv_flow_imp.g_varchar2_table(1740) := unistr('|Filipkov\00E1|Finkov\00E1|Foga\0161ov\00E1|Forg\00E1\010Dov\00E1|Fra\0148ov\00E1|Franekov\00E1|Frankov\00E1|Franov\00E1|Fra\0148v\00E1|Frimerov\00E1|Ft\00E1\010Dnikov\00E1');
wwv_flow_imp.g_varchar2_table(1741) := unistr('|Ftorekov\00E1|G\00E1lov\00E1|Galikov\00E1|Gal\00EDkov\00E1|G\00E1likov\00E1|Ga\0161parov\00E1|Ga\0161parovi\010Dov\00E1|Gavalierov\00E1|Gavendov\00E1|Gavorn\00EDko');
wwv_flow_imp.g_varchar2_table(1742) := unistr('v\00E1|Ga\017Eov\00E1|Gocn\00EDkov\00E1|Gregorov\00E1|Gregu\0161ov\00E1|Gr\0148ov\00E1|Grzn\00E1rov\00E1|Habl\00E1kov\00E1|Hab\0161udov\00E1|Hagarov\00E1|Hal\00E1kov\00E1|Halu\0161');
wwv_flow_imp.g_varchar2_table(1743) := unistr('kov\00E1|Hanakov\00E1|Han\00E1kov\00E1|Ha\0148akov\00E1|Ha\0148\00E1kov\00E1|Hanekov\00E1|Hankov\00E1|Hanusov\00E1|Hanusekov\00E1|Han\00FAsekov\00E1|Hanuskov\00E1|H');
wwv_flow_imp.g_varchar2_table(1744) := unistr('an\00FAskov\00E1|Hanu\0161kov\00E1|Hanzelov\00E1|Harvanov\00E1|Harv\00E1nekov\00E1|Ha\0161\010D\00E1kov\00E1|Havranov\00E1|Havrankov\00E1|He\010Dkov\00E1|Heretikov\00E1');
wwv_flow_imp.g_varchar2_table(1745) := unistr('|Hilmerov\00E1|Hladk\00E1|Hlav\00E1\010Dov\00E1|Hlav\00E1\010Dikov\00E1|Hlin\00EDkov\00E1|Hlinkov\00E1|Hod\017Eov\00E1|Hol\010D\00EDkov\00E1|Holi\010Dov\00E1|Holi\010Dekov\00E1|Hol');
wwv_flow_imp.g_varchar2_table(1746) := unistr('\00ED\010Dekov\00E1|Holi\010Dkov\00E1|Hol\00EDkov\00E1|Holubecov\00E1|Holubekov\00E1|Hol\00FAbekov\00E1|Holubkov\00E1|Ho\0161t\00E1kov\00E1|Ho\0161\0165\00E1kov\00E1|Hozov\00E1|Hra');
wwv_flow_imp.g_varchar2_table(1747) := unistr('\0161kov\00E1|Hrdli\010Dkov\00E1|Hriankov\00E1|Hricov\00E1|Hrmov\00E1|Hrobo\0148ov\00E1|Hru\0161ovsk\00E1|Hubov\00E1|Hu\010Dkov\00E1|Hud\00E1\010Dekov\00E1|Hudecov\00E1|Hup');
wwv_flow_imp.g_varchar2_table(1748) := unistr('kov\00E1|Husov\00E1|H\00FAsov\00E1|Hus\00E1kov\00E1|Hus\00E1rov\00E1|H\00FAskov\00E1|Hus\0165\00E1kov\00E1|Hu\0161ekov\00E1|H\00FA\0161ekov\00E1|Hu\0161ov\00E1|Hu\0161t\00E1kov\00E1|Hu\0161\0165\00E1kov\00E1|');
wwv_flow_imp.g_varchar2_table(1749) := unistr('Huttov\00E1|Chalupkov\00E1|Chovanov\00E1|Chovanecov\00E1|Chrappov\00E1|Chud\00EDkov\00E1|Ihna\010D\00E1kov\00E1|Imrichov\00E1|Iva\0161kov\00E1|Jakubov\00E1|');
wwv_flow_imp.g_varchar2_table(1750) := unistr('Jakub\010Dekov\00E1|Jakub\010D\00EDkov\00E1|Jakub\010Dov\00E1|Jakubecov\00E1|Jakubekov\00E1|Jak\00FAbekov\00E1|Jakub\00EDkov\00E1|Jakubkov\00E1|Jalovecov\00E1|J');
wwv_flow_imp.g_varchar2_table(1751) := unistr('\00E1nov\00E1|Jan\00E1kov\00E1|Jan\010Dov\00E1|Jan\010Dekov\00E1|Jane\010Dekov\00E1|Janekov\00E1|Jan\00EDkov\00E1|Jankov\00E1|Janov\00E1|Jano\010Dkov\00E1|Jano\0161ov\00E1|J\00E1no');
wwv_flow_imp.g_varchar2_table(1752) := unistr('\0161ov\00E1|Jano\0161ekov\00E1|J\00E1no\0161\00EDkov\00E1|Jano\0161kov\00E1|J\00E1no\0161kov\00E1|Janto\0161ovi\010Dov\00E1|Jed\013Eovsk\00E1|Jendekov\00E1|Jonatov\00E1|Junasov\00E1|J');
wwv_flow_imp.g_varchar2_table(1753) := unistr('un\00E1sov\00E1|Jun\00E1\0161ov\00E1|Jur\00E1\0161ov\00E1|Jur\010Dov\00E1|Jur\010Dinov\00E1|Jurekov\00E1|Jur\00EDkov\00E1|Jurinov\00E1|Jurkov\00E1|Jurkovi\010Dov\00E1|Kali\0148\00E1kov');
wwv_flow_imp.g_varchar2_table(1754) := unistr('\00E1|Kalisk\00E1|Kaniakov\00E1|K\00E1rov\00E1|Karulov\00E1|Kavaschov\00E1|Kazikov\00E1|Kaz\00EDkov\00E1|K\00E1zikov\00E1|Kellov\00E1|Kelov\00E1|Kendrov\00E1|Ke');
wwv_flow_imp.g_varchar2_table(1755) := unistr('n\00ED\017Eov\00E1|Kerov\00E1|Kiselov\00E1|Kise\013Eov\00E1|Klapa\010Dov\00E1|Klap\00E1\010Dov\00E1|Klapkov\00E1|Klep\00E1\010Dov\00E1|Klimov\00E1|Klim\00E1\010Dekov\00E1|Klimekov\00E1');
wwv_flow_imp.g_varchar2_table(1756) := unistr('|Klimkov\00E1|Klimkovi\010Dov\00E1|Kli\017Eanov\00E1|Kloko\010Dov\00E1|Klopa\010Dkov\00E1|Knihov\00E1|Kobielsk\00E1|Kocov\00E1|Koc\00E1kov\00E1|Kocianov\00E1|Ko');
wwv_flow_imp.g_varchar2_table(1757) := unistr('ckov\00E1|Koc\00FArov\00E1|Koc\00FArikov\00E1|Ko\010Dov\00E1|Ko\010Di\0161ov\00E1|Ko\010Dkov\00E1|Kol\00E1rov\00E1|Koles\00E1rov\00E1|Koll\00E1rov\00E1|Kolnikov\00E1|Koln\00EDkov\00E1|');
wwv_flow_imp.g_varchar2_table(1758) := unistr('Konopkov\00E1|Kon\00F4pkov\00E1|Konr\00E1dov\00E1|Kopov\00E1|Koppov\00E1|Kor\010D\00E1kov\00E1|Korecov\00E1|Kostkov\00E1|Kostrecov\00E1|Kotianov\00E1|Kotuli');
wwv_flow_imp.g_varchar2_table(1759) := unistr('\010Dov\00E1|Koubov\00E1|Kov\00E1\010Dov\00E1|Kov\00E1\010Dikov\00E1|Kova\013Eov\00E1|Koval\010D\00EDkov\00E1|Kozov\00E1|Koz\00E1\010Dekov\00E1|Koz\00E1\010Dikov\00E1|Koz\00E1kov\00E1|Kozmonov');
wwv_flow_imp.g_varchar2_table(1760) := unistr('\00E1|K\00F4stkov\00E1|Kraj\010Diov\00E1|Kraj\010D\00EDov\00E1|Kraj\010D\00EDrov\00E1|Kraj\010Dov\00E1|Kraj\010Dovi\010Dov\00E1|Kraj\00ED\010Dekov\00E1|Kr\00E1\013Eov\00E1|Kr\00E1likov\00E1|Kr\00E1\013Eov');
wwv_flow_imp.g_varchar2_table(1761) := unistr('i\010Dov\00E1|Kram\00E1rov\00E1|Krasnohorsk\00E1|Kr\00E1snohorsk\00E1|Kri\0161tofov\00E1|Kr\00ED\017Eov\00E1|Kri\017Eanov\00E1|Kr\00ED\017Eikov\00E1|Kropil\00E1kov\00E1|Krot\00E1ko');
wwv_flow_imp.g_varchar2_table(1762) := unistr('v\00E1|Krupov\00E1|Kr\00FApov\00E1|Kubov\00E1|Kubecov\00E1|Kubekov\00E1|K\00FAbekov\00E1|Kubi\010Dekov\00E1|Kub\00ED\010Dekov\00E1|Kubi\010Dkov\00E1|Kub\00EDkov\00E1|Kubkov');
wwv_flow_imp.g_varchar2_table(1763) := unistr('\00E1|Kuffov\00E1|Kunov\00E1|Kundov\00E1|Kunkov\00E1|Kupov\00E1|Kupkov\00E1|Kurucov\00E1|Kusov\00E1|K\00FAsov\00E1|Kuskov\00E1|K\00FAskov\00E1|K\00FA\0161ov\00E1|Ku\0161ov\00E1');
wwv_flow_imp.g_varchar2_table(1764) := unistr('|Ku\0161kov\00E1|Ku\0161n\00EDrov\00E1|Kyselov\00E1|Kyse\013Eov\00E1|Labudov\00E1|Lacov\00E1|Lackov\00E1|Laj\010D\00E1kov\00E1|Laj\010Diakov\00E1|Lama\010Dov\00E1|Lep\0161\00EDkov\00E1');
wwv_flow_imp.g_varchar2_table(1765) := unistr('|Lesn\00E1|Letov\00E1|Lipov\00E1|Lipkov\00E1|Lipt\00E1kov\00E1|Lisick\00E1|L\00ED\0161kov\00E1|Litvov\00E1|Lojov\00E1|Lojekov\00E1|Lojkov\00E1|Lubinov\00E1|Luk\00E1');
wwv_flow_imp.g_varchar2_table(1766) := unistr('\010Dov\00E1|Luk\0161ov\00E1|Lupt\00E1kov\00E1|\013Dupt\00E1kov\00E1|M\00E1cov\00E1|Macov\00E1|Macekov\00E1|Mackov\00E1|M\00E1ckov\00E1|Mackovi\010Dov\00E1|Ma\010Dekov\00E1|M\00E1\010Dekov');
wwv_flow_imp.g_varchar2_table(1767) := unistr('\00E1|M\00E1\010Dikov\00E1|Ma\010Dkov\00E1|Ma\010Dkovi\010Dov\00E1|Madarov\00E1|Ma\010Farov\00E1|Ma\010F\00E1rov\00E1|Ma\010Fari\010Dov\00E1|Madejov\00E1|Mag\00E1lov\00E1|Mach\00E1\010Dekov\00E1|M');
wwv_flow_imp.g_varchar2_table(1768) := unistr('achatov\00E1|Machn\00E1\010Dov\00E1|Majdanov\00E1|Majd\00E1nov\00E1|Majesk\00E1|Makov\00E1|Makovecov\00E1|Makovick\00E1|Malachovsk\00E1|Malinov\00E1|Mal');
wwv_flow_imp.g_varchar2_table(1769) := unistr('\00ED\0161ekov\00E1|Mamojkov\00E1|Marcinov\00E1|Marcinekov\00E1|Marcinkov\00E1|Mare\010Dekov\00E1|Marekov\00E1|Margitov\00E1|Mari\00E1nov\00E1|Marko\0161ov\00E1');
wwv_flow_imp.g_varchar2_table(1770) := unistr('|Markovi\010Dov\00E1|Marku\0161ov\00E1|Maro\0161ov\00E1|Martov\00E1|Mart\00E1\0148ov\00E1|Mar\0165anov\00E1|Martinov\00E1|Martin\00E1kov\00E1|Martin\010Dekov\00E1|Marti');
wwv_flow_imp.g_varchar2_table(1771) := unistr('necov\00E1|Martinekov\00E1|Martinkov\00E1|Martinkovi\010Dov\00E1|Martinovi\010Dov\00E1|Mas\00E1rov\00E1|Masarikov\00E1|Masar\00EDkov\00E1|Mas\00E1rikov\00E1');
wwv_flow_imp.g_varchar2_table(1772) := unistr('|Masarykov\00E1|Maslov\00E1|Masn\00E1|Matia\0161kov\00E1|Maur\00E9ryov\00E1|Me\010Diarov\00E1|Medveck\00E1|Medve\010Fov\00E1|Melicharov\00E1|Melich\00E1rov\00E1');
wwv_flow_imp.g_varchar2_table(1773) := unistr('|Melich\00E1rekov\00E1|Melicherov\00E1|Melicher\010D\00EDkov\00E1|Melicher\00EDkov\00E1|Men\0161\00EDkov\00E1|Mihalikov\00E1|Mihal\00EDkov\00E1|Mih\00E1likov\00E1|M');
wwv_flow_imp.g_varchar2_table(1774) := unistr('ichalechov\00E1|Mich\00E1lechov\00E1|Michalekov\00E1|Mich\00E1lekov\00E1|Michalicov\00E1|Michal\00EDkov\00E1|Mich\00E1likov\00E1|Michalkov\00E1|Mikl');
wwv_flow_imp.g_varchar2_table(1775) := unistr('\00EDkov\00E1|Miklo\0161ov\00E1|Miklo\0161kov\00E1|Mikul\00E1kov\00E1|Mikul\00EDkov\00E1|Miku\0161ov\00E1|Mik\00FA\0161ov\00E1|Milotov\00E1|Min\00E1\010Dov\00E1|Mistr\00EDkov\00E1|Mi\0161\00ED');
wwv_flow_imp.g_varchar2_table(1776) := unistr('kov\00E1|Mlyn\00E1rov\00E1|Mlyn\00E1rikov\00E1|Moj\017Ei\0161ov\00E1|Mokro\0161ov\00E1|Morov\00E1|Morav\010D\00EDkov\00E1|Moravecov\00E1|Moricov\00E1|M\00F3ricov\00E1|Moty\010D');
wwv_flow_imp.g_varchar2_table(1777) := unistr('kov\00E1|Motykov\00E1|Mrazov\00E1|Mr\00E1zov\00E1|Mrazekov\00E1|Mr\00E1zikov\00E1|Mr\00E1zkov\00E1|Mrazkov\00E1|Muchov\00E1|Murga\0161ov\00E1|Murinov\00E1|Mur\00EDn');
wwv_flow_imp.g_varchar2_table(1778) := unistr('ov\00E1|Mydlov\00E1|N\00E1lepkov\00E1|Navarov\00E1|Nemcov\00E1|Nitrov\00E1|Ni\017Enansk\00E1|Ni\017En\00E1nsk\00E1|Ni\017E\0148ansk\00E1|Notov\00E1|N\00F4tov\00E1|Ob\0161utov\00E1|');
wwv_flow_imp.g_varchar2_table(1779) := unistr('O\010Den\00E1\0161ov\00E1|Ondr\00E1\0161ov\00E1|Ondr\00E1\0161ekov\00E1|Ondra\0161\00EDkov\00E1|Ondr\00E1\0161ikov\00E1|Ondrejkov\00E1|Ondrejkovi\010Dov\00E1|Ondrusekov\00E1|Ondru\0161');
wwv_flow_imp.g_varchar2_table(1780) := unistr('ov\00E1|Ondru\0161ekov\00E1|Ondr\00FA\0161ekov\00E1|Ondru\0161kov\00E1|Oplu\0161tilov\00E1|Orl\00EDkov\00E1|Ot\010Den\00E1\0161ov\00E1|Pajerov\00E1|Pa\013Eov\00E1|Palkov\00E1|Pa\013Eko');
wwv_flow_imp.g_varchar2_table(1781) := unistr('v\00E1|Palkovi\010Dov\00E1|Pallov\00E1|Palov\00E1|Palovov\00E1|Pa\013Eovov\00E1|Palov\010D\00EDkov\00E1|Pa\013Eov\010D\00EDkov\00E1|Palovi\010Dov\00E1|Paluchov\00E1|Pal\00FAcho');
wwv_flow_imp.g_varchar2_table(1782) := unistr('v\00E1|Pa\FFFDuchov\00E1|Pa\013E\00FAchov\00E1|Pa\0161ekov\00E1|Pa\0161kov\00E1|Pa\00FAkov\00E1|Paukov\00E1|Pauli\010Dekov\00E1|Paul\00ED\010Dekov\00E1|Paulikov\00E1|Paul\00EDkov\00E1|');
wwv_flow_imp.g_varchar2_table(1783) := unistr('Paulovi\010Dov\00E1|Pavelov\00E1|Pavelekov\00E1|Pavelkov\00E1|Pavkov\00E1|Pavli\010Dekov\00E1|Pavl\00ED\010Dekov\00E1|Pavlikov\00E1|Pavlikovsk\00E1|Pavl');
wwv_flow_imp.g_varchar2_table(1784) := unistr('ov\00E1|Pavlovov\00E1|Pavlovi\010Dov\00E1|Pavolov\00E1|Pav\00FAkov\00E1|Pelik\00E1nov\00E1|Petrovick\00E1|Petru\0161kov\00E1|Pikov\00E1|Pi\0161\00FAtov\00E1|Plaucho');
wwv_flow_imp.g_varchar2_table(1785) := unistr('v\00E1|Plavecov\00E1|Plavuchov\00E1|Plekancov\00E1|Ple\0161ivcov\00E1|Plchov\00E1|Podhradsk\00E1|Podkonick\00E1|Poliakov\00E1|Poll\00E1kov\00E1|Poru');
wwv_flow_imp.g_varchar2_table(1786) := unistr('bjakov\00E1|Puklu\0161ov\00E1|Pup\00E1kov\00E1|Pu\0161kov\00E1|Pu\0161k\00E1rov\00E1|Rakov\00E1|Rakovanov\00E1|Repisk\00E1|Rihov\00E1|Richardov\00E1|Richt\00E1rov\00E1|');
wwv_flow_imp.g_varchar2_table(1787) := unistr('Ri\0161ov\00E1|Ri\0161kov\00E1|Roh\00E1\010Dov\00E1|Roh\00E1\010Dekov\00E1|Roh\00E1\010Dikov\00E1|Rojekov\00E1|Rojkov\00E1|R\00F3mov\00E1|Roman\010D\00EDkov\00E1|Rosov\00E1|Rosinov\00E1|Ru');
wwv_flow_imp.g_varchar2_table(1788) := unistr('b\00EDkov\00E1|R\00FAfusov\00E1|Rusov\00E1|Ruskov\00E1|Rusn\00E1kov\00E1|Rus\0148\00E1kov\00E1|Ru\017Ei\010Dkov\00E1|Ryb\00E1rov\00E1|Ryb\00E1rikov\00E1|Rybn\00ED\010Dekov\00E1|Rysov\00E1|');
wwv_flow_imp.g_varchar2_table(1789) := unistr('R\00FDsov\00E1|Ry\0161ov\00E1|Ry\0161kov\00E1|Salajov\00E1|Salajkov\00E1|Same\013Eov\00E1|S\00E1melov\00E1|S\00E1me\013Eov\00E1|Samelov\00E1|Samsonov\00E1|Samuelov\00E1|San');
wwv_flow_imp.g_varchar2_table(1790) := unistr('itrov\00E1|Se\010Dov\00E1|Sedliakov\00E1|Sekerov\00E1|Seleck\00E1|Senkov\00E1|Sidorov\00E1|Simonov\00E1|Skl\00E1rov\00E1|Sklen\00E1rov\00E1|Sklen\00E1rikov\00E1');
wwv_flow_imp.g_varchar2_table(1791) := unistr('|Sklenicov\00E1|Skleni\010Dkov\00E1|Sklenkov\00E1|Skokanov\00E1|Skuteck\00E1|Sla\0161\0165anov\00E1|Slivkov\00E1|Slobodov\00E1|Slobodn\00EDkov\00E1|Slot');
wwv_flow_imp.g_varchar2_table(1792) := unistr('ov\00E1|Slov\00E1kov\00E1|Slovinecov\00E1|Smrekov\00E1|Sokolov\00E1|Solejov\00E1|Starostov\00E1|Stodolov\00E1|Strakov\00E1|Strniskov\00E1|Str\00FD\010De');
wwv_flow_imp.g_varchar2_table(1793) := unistr('kov\00E1|Svrb\00EDkov\00E1|\0160alajkov\00E1|\0160arkanov\00E1|\0160ebov\00E1|\0160idlov\00E1|\0160imov\00E1|\0160imekov\00E1|\0160im\00EDkov\00E1|\0160imonov\00E1|\0160imon\010Di\010Dov\00E1|\0160imo');
wwv_flow_imp.g_varchar2_table(1794) := unistr('novi\010Dov\00E1|\0160kant\00E1rov\00E1|\0160kovierov\00E1|\0160kriniarov\00E1|\0160kult\00E9tyov\00E1|\0160lahorov\00E1|\0160livkov\00E1|\0160majdov\00E1|\0160olt\00E9sov\00E1|\0160olt\00FDso');
wwv_flow_imp.g_varchar2_table(1795) := unistr('v\00E1|\0160pil\00E1rov\00E1|\0160tefanov\00E1|\0160tef\00E1nekov\00E1|\0160tef\00E1nikov\00E1|\0160tefankov\00E1|\0160tefanovi\010Dov\00E1|\0160tefunkov\00E1|\0160trbov\00E1|\0160ulcov\00E1|\0160');
wwv_flow_imp.g_varchar2_table(1796) := unistr('u\0148avcov\00E1|\0160urkov\00E1|\0160v\00E1bov\00E1|\0160vehlov\00E1|Talpa\0161ov\00E1|\0164ap\00E1kov\00E1|Tatarov\00E1|Tat\00E1rov\00E1|Tatarkov\00E1|\0164a\017Ek\00E1|Timekov\00E1|Timk');
wwv_flow_imp.g_varchar2_table(1797) := unistr('ov\00E1|Tirp\00E1kov\00E1|Toma\0148ov\00E1|Tom\00E1nekov\00E1|Toman\00EDkov\00E1|Tom\00E1\0161ov\00E1|Toma\0161ekov\00E1|Tom\00E1\0161ekov\00E1|Tom\00E1\0161ikov\00E1|Toma\0161kov\00E1|Tom');
wwv_flow_imp.g_varchar2_table(1798) := unistr('\00E1\0161kov\00E1|Tome\010Dekov\00E1|Tome\010Dkov\00E1|Tomekov\00E1|Tomkov\00E1|Topo\013Esk\00E1|Trl\00EDkov\00E1|Trubenov\00E1|Tup\00E1|Tur\010Dokov\00E1|Uramov\00E1|Urbl');
wwv_flow_imp.g_varchar2_table(1799) := unistr('\00EDkov\00E1|Vajcikov\00E1|Vajc\00EDkov\00E1|Vajdov\00E1|Valachov\00E1|Valachovi\010Dov\00E1|Valent\00EDnov\00E1|Val\00ED\010Dekov\00E1|Valu\0161ekov\00E1|Valu\0161kov');
wwv_flow_imp.g_varchar2_table(1800) := unistr('\00E1|Vanekov\00E1|Vaskov\00E1|V\00E1skov\00E1|Va\0161ekov\00E1|Va\0161kov\00E1|Vavrinecov\00E1|Vel\010F\00E1kov\00E1|Veselov\00E1|Vetern\00EDkov\00E1|Vicenov\00E1|Vi\0161\0148');
wwv_flow_imp.g_varchar2_table(1801) := unistr('ovsk\00E1|Vlachov\00E1|Vlachovi\010Dov\00E1|Vlkov\00E1|Vlnov\00E1|Vlnkov\00E1|Vojtekov\00E1|Vojtkov\00E1|Voz\00E1rov\00E1|Vrabcov\00E1|Vrablecov\00E1|Vy');
wwv_flow_imp.g_varchar2_table(1802) := unistr('daren\00E1|Z\00E1borsk\00E1|Zacharov\00E1|Zacharia\0161ov\00E1|Zachari\00E1\0161ov\00E1|Zajacov\00E1|Zigov\00E1|Zimov\00E1|Zimkov\00E1|Zubekov\00E1|Z\00FAbekov\00E1');
wwv_flow_imp.g_varchar2_table(1803) := unistr('|Zubkov\00E1|Zubr\00EDkov\00E1|Z\00FAbrikov\00E1|\017Delezn\00EDkov\00E1|\017Digmundov\00E1|\017Digov\00E1|Doe|Nagy|Kov\00E1cs|T\00F3th|Szab\00F3|Varga|Kiss|Mol');
wwv_flow_imp.g_varchar2_table(1804) := unistr('n\00E1r|N\00E9meth|Farkas|Balogh|Papp|Tak\00E1cs|Juh\00E1sz|Lakatos|M\00E9sz\00E1ros|Ol\00E1h|R\00E1cz|Fekete|Szil\00E1gyi|T\00F6r\00F6k|Feh\00E9r|B');
wwv_flow_imp.g_varchar2_table(1805) := unistr('al\00E1zs|Kis|Sz\0171cs|Kocsis|Ors\00F3s|Pint\00E9r|Fodor|Szalai|Sipos|Magyar|Luk\00E1cs|Guly\00E1s|Bir\00F3|Kir\00E1ly|L\00E1szl\00F3|Katon');
wwv_flow_imp.g_varchar2_table(1806) := unistr('a|Jakab|Bogd\00E1n|Balog|S\00E1ndor|Boros|Fazekas|Kelemen|V\00E1radi|Somogyi|Orosz|F\00FCl\00F6p|Veres|Vincze|Heged\0171s|Bu');
wwv_flow_imp.g_varchar2_table(1807) := unistr('dai|Pap|B\00E1lint|P\00E1l|Ill\00E9s|Vass|Sz\0151ke|V\00F6r\00F6s|Bogn\00E1r|F\00E1bi\00E1n|Lengyel|Bodn\00E1r|Sz\00FCcs|Hajdu|Hal\00E1sz|J\00F3n\00E1s|M\00E1t\00E9');
wwv_flow_imp.g_varchar2_table(1808) := unistr('|Sz\00E9kely|Kozma|G\00E1sp\00E1r|P\00E1sztor|Bakos|Dud\00E1s|Major|Orb\00E1n|Heged\00FCs|Vir\00E1g|Barna|So\00F3s|Tam\00E1s|Nemes|Pataki|Ba');
wwv_flow_imp.g_varchar2_table(1809) := unistr('lla|Farag\00F3|Kerekes|Borb\00E9ly|Barta|P\00E9ter|Szekeres|Csonka|Mezei|M\00E1rton|S\00E1rk\00F6zi|Abi\010Di\0107|Abramovi\0107|Ad\017Eijev');
wwv_flow_imp.g_varchar2_table(1810) := unistr('i\0107|Akma\010Di\0107|Alkovi\0107|Amanovi\0107|Amid\017Ei\0107|Andra\0161ek|Andrija\0161evi\0107|Andrijevi\0107|Ani\010Di\0107|Anti\0107|Antolkovi\0107|Antoni\0107');
wwv_flow_imp.g_varchar2_table(1811) := unistr('|Babi\0107|Bajan|Baksa|Balatinac|Balin\010Di\0107|Bali\0107|Baljak|Ban|Bani\010Devi\0107|Banko|Banovac|Barac|Bara\0107|Barbieri|');
wwv_flow_imp.g_varchar2_table(1812) := unistr('Barbir|Barbi\0107|Bare\0161i\0107|Bari\0107|Bari\010Devi\0107|Bari\0161i\0107|Barkovi\0107|Barnaba|Baru\0161i\0107|Batrac|Batrnek|Bazjak|Ba\010Dak|B');
wwv_flow_imp.g_varchar2_table(1813) := unistr('a\010Di\0107|Ba\0161i\0107|Ba\0161nec|Bebi\0107|Begonja|Beleti\0107|Belo\0161evi\0107|Beni\0107|Ben\010Di\0107|Berakovi\0107|Bernardi\0107|Berto\0161a|Bezi\0107|Bij');
wwv_flow_imp.g_varchar2_table(1814) := unistr('eli\0107|Bingula|Birki\0107|Birti\0107|Bi\0107ani\0107|Bi\010Dak|Bi\010Dani\0107|Bjeli\0161|Blagai\0107|Bla\017Eevi\0107|Bla\017Ei\010Dko|Boban|Bobanovi\0107|Bo');
wwv_flow_imp.g_varchar2_table(1815) := unistr('gadi|Bogdan|Bogovi\0107|Bojani\0107|Boljkovac|Bol\010Devi\0107|Borak|Borojevi\0107|Boro\0161ak|Bosilj|Botica|Boti\0107|Bo\0161njak|B');
wwv_flow_imp.g_varchar2_table(1816) := unistr('o\0161njakovi\0107|Bo\017Eani\0107|Bo\017Eanovi\0107|Bo\017Eikovi\0107|Bo\017Ei\0107|Bo\017Ei\010Devi\0107|Bo\017Ei\010Dkovi\0107|Bradi\0107|Brajkovi\0107|Brali\0107|Brandi\0107|Br');
wwv_flow_imp.g_varchar2_table(1817) := unistr('ankovi\0107|Bra\010Dun|Brcko|Brezjan|Britvec|Brlas|Brlek|Brleti\0107|Bukvi\0107|Buljan|Bungi\0107|Buni\0107|Bun\010Di\0107|Buri\0107|Bur');
wwv_flow_imp.g_varchar2_table(1818) := unistr('\010Dul|Bur\0161i\0107|Butkovi\0107|Buzov|Bu\010Danac|Bu\010Dar|Bu\0161ljeta|Cafuk|Car|Cari\0107|Cestari\0107|Ciganovi\0107|Cik|Cindri\0107|Coli');
wwv_flow_imp.g_varchar2_table(1819) := unistr('\0107|Crevar|Crnekovi\0107|Crnkovi\0107|Cukon|Culi|Cveni\0107|Cvetkovi\0107|Cvetni\0107|Cvitan|Cvrtila|Dabo|Damijani\0107|Damjan');
wwv_flow_imp.g_varchar2_table(1820) := unistr('ovi\0107|Darojkovi\0107|Dautanec|Dautovi\0107|Debeli\0107|Dere\017Ei\0107|De\017Ee|Didovi\0107|Dizdar|Dobri\0107|Dolinar|Doli\0107|Dominikov');
wwv_flow_imp.g_varchar2_table(1821) := unistr('i\0107|Dominkovi\0107|Don\010Devi\0107|Dragi\010Devi\0107|Dragobratovi\0107|Dragojevi\0107|Drakuli\0107|Drandi\0107|Dra\017Ei\0107|Dretvi\0107|Dubove\010Dak');
wwv_flow_imp.g_varchar2_table(1822) := unistr('|Dujmovi\0107|Duki\0107|Duvan\010Di\0107|Dvojak|D\017Eapo|Erceg|Ercegovi\0107|Ergoti\0107|Er\0161ek|Eterovi\0107|Fabijani\0107|Ferenac|Filar');
wwv_flow_imp.g_varchar2_table(1823) := unistr('|Filipovi\0107|Filip\010Di\0107|Flego|Forjan|Frani\0107|Frani\010Devi\0107|Franji\0107|Franu\0161i\0107|Fri\0161\010Di\0107|Frketi\0107|Fu\010Dek|Gabud|Gale');
wwv_flow_imp.g_varchar2_table(1824) := unistr('\0161i\0107|Gali\0107|Galovi\0107|Gegi\0107|Gelemanovi\0107|Glasnovi\0107|Glavan|Glavor|Gligora|Godini\0107|Golubi\0107|Goti\0107|Govor\010Dinov');
wwv_flow_imp.g_varchar2_table(1825) := unistr('i\0107|Gracin|Grba|Grbac|Gredi\010Dak|Gregov|Grgi\0107|Grgurevi\0107|Grguri\0107|Grgurovac|Grubi\0161i\0107|Gr\017Eeti\0107|Gr\017Ein\010Di\0107|Gub');
wwv_flow_imp.g_varchar2_table(1826) := unistr('erovi\0107|Gudelj|Gulan|Gu\0161tin|Hadrovi\0107|Had\017Ei\0107|Halambek|Halapir|Han\017Eek|Harapin|Hardi|Herceg|Herout|He\0107im');
wwv_flow_imp.g_varchar2_table(1827) := unistr('ovi\0107|Hini\0107|Hodak|Horak|Horvat|Horvatek|Horvatinec|Horvati\0107|Hrabar|Hrani\0107|Hranj|Hrastinski|Hren|Hrvoj');
wwv_flow_imp.g_varchar2_table(1828) := unistr('i\0107|Hr\0161ak|Hr\017Eenjak|Huljev|Husnjak|Ignac|Iliji\0107|Ilinovi\0107|Ili\0107|Ivandi\0107|Ivanovi\0107|Ivan\010Dan|Iv\0161i\0107|Jagarinec');
wwv_flow_imp.g_varchar2_table(1829) := unistr('|Jage\010Di\0107|Jakopec|Jakopovi\0107|Jakovac|Jakovi\0107|Jakovljevi\0107|Jakupi\0107|Jaku\0161|Jasprica|Jelavi\0107|Jeli\0107|Jemri\0107|J');
wwv_flow_imp.g_varchar2_table(1830) := unistr('erkovi\0107|Jonji\0107|Josipovi\0107|Jovanovac|Jovanovi\0107|Jovi\0107|Jozi\0107|Jugovac|Juki\0107|Jureti\0107|Jure\0161ko|Juri\0107|Juri\0161i\0107');
wwv_flow_imp.g_varchar2_table(1831) := unistr('|Jurjevi\0107|Jurkovi\0107|Jurlina|Jur\010Di\0107|Kadija|Kahlina|Kalanjo\0161|Kalazi\0107|Kani\0161ki|Karagi\0107|Karamarko|Karlovi\0107');
wwv_flow_imp.g_varchar2_table(1832) := unistr('|Karmeli\0107|Karuza|Kati\0107|Kauzlari\0107|Kelekovi\0107|Kele\010Di\0107|Keli\0107|Kerekovi\0107|Kevo|Kinkela|Kirin\010Di\0107|Klanac|Klar');
wwv_flow_imp.g_varchar2_table(1833) := unistr('in|Klari\0107|Klasi\0107|Kligl|Knezovi\0107|Kne\017Eevi\0107|Kocijan\010Di\0107|Kokanovi\0107|Kokori\0107|Kolarec|Kolega|Koli\0107|Komar|Kom');
wwv_flow_imp.g_varchar2_table(1834) := unistr('ljenovi\0107|Kopjar|Kos|Kosanovi\0107|Kosi\0107|Kostani\0107|Kostelac|Kova\010D|Kova\010Dek|Kova\010Devi\0107|Kova\010Di\0107|Ko\0161ki|Ko\0161\010Devi\0107');
wwv_flow_imp.g_varchar2_table(1835) := unistr('|Krajcar|Kralj|Kraljevi\0107|Kralji\0107|Kramari\0107|Kresonja|Krpan|Krznari\0107|Kr\010Deli\0107|Kr\0161anac|Kr\017Eelj|Kujund\017Ei\0107|K');
wwv_flow_imp.g_varchar2_table(1836) := unistr('uku\010Dka|Kunac|Kupsjak|Kurtoi\0107|Kuve\017Edi\0107|Kuzmi\0107|Ku\010Di\0107|Ku\0161\010Devi\0107|Laba\0161|Labinjan|Ladavac|Lako\0161eljac|Lasi\0107|');
wwv_flow_imp.g_varchar2_table(1837) := unistr('Lazar|Legovi\0107|Lelas|Leni\0107|Le\0161i\0107|Le\0161kovi\0107|Le\0161\010Di\0107|Liber|Licul|Liovi\0107|Lisica|Ljubeti\0107|Ljubi\0107|Ljubi\010Di\0107|L');
wwv_flow_imp.g_varchar2_table(1838) := unistr('ojen|Lorencin|Lovri\0107|Luci\0107|Lukini\0107|Luki\0107|Luk\0161i\0107|Lu\010Di\0107|Macan|Maduni\0107|Magi\0107|Mahnet|Majdeni\0107|Majstorovi');
wwv_flow_imp.g_varchar2_table(1839) := unistr('\0107|Makovac|Maleti\0107|Malnar|Malo\010Da|Mami\0107|Mamula|Maras|Marasovi\0107|Mara\0161|Marde\0161i\0107|Mareti\0107|Marijanovi\0107|Mari');
wwv_flow_imp.g_varchar2_table(1840) := unistr('nkovi\0107|Marinovi\0107|Mari\0107|Mari\010Devi\0107|Marjanovi\0107|Markanjevi\0107|Markovac|Markovi\0107|Martini\0107|Martinovi\0107|Martin');
wwv_flow_imp.g_varchar2_table(1841) := unistr('\010Devi\0107|Marti\0107|Maru\0161i\0107|Mar\0161i\0107|Mar\017Ei\0107|Matahlija|Matana|Matas|Mate\0161a|Matija\0161|Matijevi\0107|Mati\0107|Matko|Matko');
wwv_flow_imp.g_varchar2_table(1842) := unistr('vi\0107|Matokanovi\0107|Matovina|Mato\0161evi\0107|Matulin|Matuli\0107|Mavra|Ma\0107e\0161i\0107|Meda\010D|Medi\0107|Medved|Mei\0107|Merka\0161|Mesa');
wwv_flow_imp.g_varchar2_table(1843) := unistr('ri\0107|Mesi\0107|Mihali\0107|Mihaljevi\0107|Mihel\010Di\0107|Mihi\0107|Miki\0107|Mikle\010Di\0107|Mikulandra|Mikulec|Mikul\010Di\0107|Milas|Milati\0107');
wwv_flow_imp.g_varchar2_table(1844) := unistr('|Mileti\0107|Milevoj'';'||wwv_flow.LF||
'    l_first_name_catalog(3) := ''Abbas|Abdul|Abdullah|Abraham|Abram|Achim|Ada|Adal');
wwv_flow_imp.g_varchar2_table(1845) := 'bert|Adam|Adelbert|Adem|Adolf|Adrian|Ahmad|Ahmed|Ahmet|Alan|Alban|Albert|Alberto|Albin|Albrecht|Aldo';
wwv_flow_imp.g_varchar2_table(1846) := '|Aleksandar|Aleksander|Aleksandr|Aleksej|Alessandro|Alex|Alexander|Alexandre|Alexandros|Alexei|Alexe';
wwv_flow_imp.g_varchar2_table(1847) := 'j|Alf|Alfons|Alfonso|Alfred|Alfredo|Ali|Alois|Aloys|Alwin|Amir|Anastasios|Anatol|Anatoli|Anatolij|An';
wwv_flow_imp.g_varchar2_table(1848) := unistr('dre|Andreas|Andree|Andrei|Andrej|Andres|Andrew|Andrey|Andrzej|Andr\00E9|Andy|Angelo|Anselm|Ansgar|Ante|A');
wwv_flow_imp.g_varchar2_table(1849) := 'nthony|Anto|Anton|Antonino|Antonio|Antonios|Antonius|Apostolos|Aribert|Arif|Armin|Arnd|Arndt|Arne|Ar';
wwv_flow_imp.g_varchar2_table(1850) := 'nfried|Arnim|Arno|Arnold|Arnulf|Arthur|Artur|Athanasios|Attila|August|Augustin|Axel|Aziz|Baldur|Balt';
wwv_flow_imp.g_varchar2_table(1851) := unistr('hasar|Baptist|Bartholom\00E4us|Bastian|Bayram|Bekir|Bela|Ben|Benedikt|Benjamin|Benno|Berend|Bernard|Bern');
wwv_flow_imp.g_varchar2_table(1852) := unistr('d|Berndt|Bernfried|Bernhard|Bernt|Bernward|Bert|Berthold|Bertold|Bertram|Birger|Bj\00F6rn|Bodo|Bogdan|Bo');
wwv_flow_imp.g_varchar2_table(1853) := 'ris|Branko|Brian|Bruno|Burckhard|Burghard|Burkard|Burkhard|Burkhardt|Calogero|Carl|Carlo|Carlos|Carm';
wwv_flow_imp.g_varchar2_table(1854) := 'elo|Carsten|Celal|Cemal|Cemil|Cengiz|Cetin|Charles|Christian|Christof|Christoph|Christopher|Christos';
wwv_flow_imp.g_varchar2_table(1855) := '|Claas|Claudio|Claudius|Claus|Clemens|Conrad|Constantin|Cord|Cornelius|Cosimo|Curt|Czeslaw|Dagobert|';
wwv_flow_imp.g_varchar2_table(1856) := 'Damian|Dan|Daniel|Daniele|Danilo|Danny|Darius|Dariusz|Darko|David|Denis|Dennis|Denny|Detlef|Detlev|D';
wwv_flow_imp.g_varchar2_table(1857) := 'iedrich|Dierk|Dieter|Diethard|Diethelm|Diether|Dietmar|Dietrich|Dimitri|Dimitrios|Dino|Dirk|Ditmar|D';
wwv_flow_imp.g_varchar2_table(1858) := 'ittmar|Dogan|Domenico|Dominic|Dominik|Donald|Dragan|Drago|Dursun|Dusan|Eberhard|Eberhardt|Eckard|Eck';
wwv_flow_imp.g_varchar2_table(1859) := 'art|Eckehard|Eckhard|Eckhardt|Eckhart|Edelbert|Edgar|Edmund|Eduard|Edward|Edwin|Egbert|Eggert|Egon|E';
wwv_flow_imp.g_varchar2_table(1860) := 'hrenfried|Ehrhard|Eitel|Ekkehard|Ekkehart|Ekrem|Elias|Elmar|Emanuel|Emil|Emin|Emmerich|Engelbert|Eng';
wwv_flow_imp.g_varchar2_table(1861) := 'in|Enno|Enrico|Enver|Ercan|Erdal|Erdogan|Erhard|Erhardt|Eric|Erich|Erik|Erkan|Ernest|Ernst|Erol|Erwi';
wwv_flow_imp.g_varchar2_table(1862) := 'n|Eugen|Evangelos|Ewald|Fabian|Falk|Falko|Faruk|Fatih|Fedor|Felix|Ferdi|Ferdinand|Ferenc|Fernando|Fi';
wwv_flow_imp.g_varchar2_table(1863) := 'lippo|Florian|Folker|Folkert|Francesco|Francis|Francisco|Franco|Franjo|Frank|Franz|Fred|Freddy|Frede';
wwv_flow_imp.g_varchar2_table(1864) := 'ric|Frederik|Fredi|Fredo|Fredy|Fridolin|Friedbert|Friedemann|Frieder|Friedhelm|Friedhold|Friedo|Frie';
wwv_flow_imp.g_varchar2_table(1865) := 'drich|Frithjof|Fritz|Gabor|Gabriel|Gaetano|Gebhard|Geert|Georg|George|Georgios|Gerald|Gerard|Gerd|Ge';
wwv_flow_imp.g_varchar2_table(1866) := 'reon|Gerfried|Gerhard|Gerhardt|Gerhart|German|Gernot|Gero|Gerold|Gerolf|Gert|Gerwin|Gilbert|Gino|Gio';
wwv_flow_imp.g_varchar2_table(1867) := 'rgio|Giovanni|Gisbert|Giuseppe|Goran|Gordon|Gottfried|Gotthard|Gotthilf|Gotthold|Gottlieb|Gottlob|Gr';
wwv_flow_imp.g_varchar2_table(1868) := unistr('egor|Grzegorz|Guenter|Guenther|Guido|Guiseppe|Gunar|Gundolf|Gunnar|Gunter|Gunther|Guntram|Gustav|G\00F6t');
wwv_flow_imp.g_varchar2_table(1869) := unistr('z|G\00FCnter|G\00FCnther|Hagen|Hajo|Hakan|Halil|Hannes|Hanni|Hanno|Hanns|Hans|Hansgeorg|Hansjoachim|Hansj\00F6rg');
wwv_flow_imp.g_varchar2_table(1870) := unistr('|Hansj\00FCrgen|Hanspeter|Harald|Hardy|Harm|Harold|Harri|Harro|Harry|Hartmut|Hartmuth|Hartwig|Hasan|Hass');
wwv_flow_imp.g_varchar2_table(1871) := 'an|Hasso|Heiko|Heimo|Heiner|Heinfried|Heini|Heino|Heinrich|Heinz|Helfried|Helge|Hellmut|Hellmuth|Hel';
wwv_flow_imp.g_varchar2_table(1872) := 'mar|Helmut|Helmuth|Hendrik|Henner|Henning|Henrik|Henry|Henryk|Herbert|Heribert|Hermann|Herrmann|Herw';
wwv_flow_imp.g_varchar2_table(1873) := unistr('ig|Hilmar|Hinrich|Holger|Holm|Horst|Hubert|Hubertus|Hugo|H\00FCseyin|Ian|Ibrahim|Ignatz|Ignaz|Igor|Ilhan');
wwv_flow_imp.g_varchar2_table(1874) := '|Ilias|Ilija|Ilja|Immo|Imre|Ingbert|Ingmar|Ingo|Ingolf|Ioannis|Isidor|Ismail|Ismet|Istvan|Ivan|Ivo|I';
wwv_flow_imp.g_varchar2_table(1875) := 'wan|Jacek|Jacob|Jakob|James|Jan|Janko|Jann|Janos|Janus|Janusz|Jaroslav|Jaroslaw|Jens|Jerzy|Jiri|Joac';
wwv_flow_imp.g_varchar2_table(1876) := 'him|Jobst|Jochem|Jochen|Joerg|Johan|Johann|Johannes|John|Jonas|Jonathan|Jorge|Jose|Josef|Joseph|Josi';
wwv_flow_imp.g_varchar2_table(1877) := unistr('p|Jost|Jos\00E9|Jovan|Jozef|Juan|Juergen|Julian|Julius|Juri|Jurij|Justus|J\00F6rg|J\00F6rgen|J\00F6rn|J\00FCrgen|Kamil|K');
wwv_flow_imp.g_varchar2_table(1878) := 'arl|Karlfried|Karlheinz|Karsten|Kasimir|Kaspar|Kazim|Kemal|Kenan|Kenneth|Kevin|Kilian|Klaas|Klaus|Kl';
wwv_flow_imp.g_varchar2_table(1879) := 'emens|Knud|Knut|Konrad|Konstantin|Konstantinos|Korbinian|Kornelius|Kristian|Krzysztof|Kunibert|Kuno|';
wwv_flow_imp.g_varchar2_table(1880) := 'Kurt|Ladislaus|Lambert|Lars|Laszlo|Laurenz|Leander|Leif|Leo|Leon|Leonard|Leonardo|Leonhard|Leonid|Le';
wwv_flow_imp.g_varchar2_table(1881) := 'opold|Leszek|Linus|Lorenz|Lorenzo|Lothar|Louis|Luciano|Ludger|Ludwig|Luigi|Luis|Lukas|Lutz|Magnus|Ma';
wwv_flow_imp.g_varchar2_table(1882) := 'hmoud|Mahmut|Maik|Malte|Manfred|Manuel|Marc|Marcel|Marco|Marcus|Marek|Marian|Marijan|Mario|Marius|Ma';
wwv_flow_imp.g_varchar2_table(1883) := unistr('riusz|Mark|Marko|Markus|Marten|Martin|Marvin|Massimo|Mathias|Mato|Matteo|Matthias|Matth\00E4us|Mattias|M');
wwv_flow_imp.g_varchar2_table(1884) := 'aurice|Maurizio|Max|Maxim|Maximilian|Mehdi|Mehmet|Meik|Meinhard|Meinolf|Meinrad|Mesut|Metin|Micha|Mi';
wwv_flow_imp.g_varchar2_table(1885) := 'chael|Michail|Michel|Miguel|Mijo|Mike|Mikhail|Milan|Milos|Miodrag|Mirco|Mirko|Miroslav|Miroslaw|Moha';
wwv_flow_imp.g_varchar2_table(1886) := 'med|Mohammad|Mohammed|Moritz|Muharrem|Murat|Mustafa|Muzaffer|Necati|Nick|Nico|Nicolai|Nicolas|Nicola';
wwv_flow_imp.g_varchar2_table(1887) := 'us|Niels|Niklas|Niko|Nikola|Nikolai|Nikolaj|Nikolaos|Nikolas|Nikolaus|Nils|Norbert|Norman|Nurettin|N';
wwv_flow_imp.g_varchar2_table(1888) := 'uri|Olaf|Ole|Oliver|Orhan|Ortwin|Oscar|Oskar|Osman|Oswald|Oswin|Otfried|Othmar|Otmar|Ottfried|Ottmar';
wwv_flow_imp.g_varchar2_table(1889) := '|Otto|Ottokar|Ottomar|Paolo|Pascal|Pasquale|Patric|Patrick|Patrik|Paul|Paulo|Pavel|Pawel|Pedro|Peer|';
wwv_flow_imp.g_varchar2_table(1890) := 'Pero|Petar|Peter|Petros|Philip|Philipp|Philippe|Phillip|Pierre|Pietro|Piotr|Pirmin|Pius|Rafael|Raik|';
wwv_flow_imp.g_varchar2_table(1891) := 'Raimund|Rainer|Ralf|Ralph|Ramazan|Ramon|Randolf|Raphael|Raymond|Raymund|Recep|Reginald|Reimar|Reimer';
wwv_flow_imp.g_varchar2_table(1892) := unistr('|Reimund|Reinald|Reiner|Reinhard|Reinhardt|Reinhart|Reinhold|Remo|Renato|Rene|Ren\00E9|Reza|Ricardo|Rich');
wwv_flow_imp.g_varchar2_table(1893) := 'ard|Rico|Rigo|Riza|Robby|Robert|Roberto|Robin|Rocco|Rochus|Roderich|Roger|Roland|Rolf|Roman|Romuald|';
wwv_flow_imp.g_varchar2_table(1894) := unistr('Ron|Ronald|Ronny|Rouven|Roy|Ruben|Rudi|Rudolf|Rudolph|Rupert|Ryszard|R\00FCdiger|Saban|Sabri|Sahin|Salih');
wwv_flow_imp.g_varchar2_table(1895) := '|Salvatore|Sami|Samir|Samuel|Sandor|Sandro|Sebastian|Sebastiano|Sedat|Selim|Senol|Sepp|Serge|Sergei|';
wwv_flow_imp.g_varchar2_table(1896) := 'Sergej|Sergio|Severin|Siegbert|Siegfried|Sieghard|Siegmar|Siegmund|Siegward|Sigfried|Sigismund|Sigma';
wwv_flow_imp.g_varchar2_table(1897) := 'r|Sigmund|Sigurd|Silvester|Silvio|Simon|Slavko|Slawomir|Slobodan|Stanislaus|Stanislav|Stanislaw|Stav';
wwv_flow_imp.g_varchar2_table(1898) := unistr('ros|Stefan|Stefano|Steffen|Stephan|Stephen|Steve|Steven|Stjepan|Sven|Swen|Sylvester|Sylvio|S\00F6nke|S\00F6r');
wwv_flow_imp.g_varchar2_table(1899) := unistr('en|S\00FCkr\00FC|S\00FCleyman|Tadeusz|Tassilo|Thadd\00E4us|Theo|Theobald|Theodor|Theodoros|Thies|Thilo|Thomas|Thoral');
wwv_flow_imp.g_varchar2_table(1900) := 'f|Thorben|Thorsten|Tibor|Till|Tillmann|Tilman|Tilmann|Tilo|Tim|Timm|Timo|Tino|Tobias|Tom|Tomas|Tomas';
wwv_flow_imp.g_varchar2_table(1901) := 'z|Tomislav|Toni|Tony|Toralf|Torben|Torsten|Traugott|Udo|Ulf|Uli|Ullrich|Ulrich|Urban|Urs|Utz|Uwe|Vad';
wwv_flow_imp.g_varchar2_table(1902) := 'im|Valentin|Valerij|Vassilios|Veit|Veli|Victor|Viktor|Vincent|Vincenzo|Vinko|Vinzenz|Vitali|Vito|Vit';
wwv_flow_imp.g_varchar2_table(1903) := 'torio|Vitus|Vladimir|Vlado|Volker|Volkhard|Volkmar|Waldemar|Walfried|Walter|Walther|Wenzel|Werner|Wi';
wwv_flow_imp.g_varchar2_table(1904) := 'eland|Wieslaw|Wigbert|Wilfried|Wilhelm|Willfried|Willi|William|Willibald|Willibert|Willy|Winfried|Wi';
wwv_flow_imp.g_varchar2_table(1905) := 'told|Wladimir|Wojciech|Woldemar|Wolf|Wolfgang|Wolfhard|Wolfram|Wulf|Xaver|Yilmaz|Yusuf|Zbigniew|Zdra';
wwv_flow_imp.g_varchar2_table(1906) := 'vko|Zeki|Zeljko|Zenon|Zlatko|Zoltan|Zoran|Adele|Adelgunde|Adelheid|Adelinde|Adeline|Adina|Adolfine|A';
wwv_flow_imp.g_varchar2_table(1907) := unistr('driana|Adriane|Aenne|\00C4nne|Agata|Agatha|Agathe|Agnes|Agnieszka|Albertine|Albina|Aleksandra|Alena|Alex');
wwv_flow_imp.g_varchar2_table(1908) := 'a|Alexandra|Alice|Alicia|Alicja|Alida|Alina|Aline|Alla|Alma|Almut|Almuth|Aloisia|Alwina|Alwine|Amali';
wwv_flow_imp.g_varchar2_table(1909) := 'a|Amalie|Amanda|Amelie|Ana|Anastasia|Andrea|Aneta|Anett|Anette|Angela|Angelica|Angelika|Angelina|Ang';
wwv_flow_imp.g_varchar2_table(1910) := 'elique|Anica|Anika|Anita|Anja|Anka|Anke|Ann|Anna|Annaliese|Annamaria|Anne|Annedore|Annegret|Annegret';
wwv_flow_imp.g_varchar2_table(1911) := 'e|Annekatrin|Anneke|Annelene|Anneli|Annelie|Annelies|Anneliese|Annelise|Annelore|Annemarie|Annemie|A';
wwv_flow_imp.g_varchar2_table(1912) := 'nnerose|Annett|Annette|Anni|Annie|Annika|Annita|Anny|Antje|Antoinette|Antonia|Antonie|Antonietta|Ant';
wwv_flow_imp.g_varchar2_table(1913) := 'onina|Apollonia|Ariane|Arzu|Asta|Astrid|Augusta|Auguste|Aurelia|Aynur|Ayse|Aysel|Ayten|Babett|Babett';
wwv_flow_imp.g_varchar2_table(1914) := 'e|Barbara|Beata|Beate|Beatrice|Beatrix|Belinda|Benita|Berit|Bernadette|Bernhardine|Berta|Bertha|Beti';
wwv_flow_imp.g_varchar2_table(1915) := 'na|Betti|Bettina|Betty|Bianca|Bianka|Birgid|Birgit|Birgitt|Birgitta|Birte|Birthe|Blanka|Bozena|Brank';
wwv_flow_imp.g_varchar2_table(1916) := unistr('a|Brigitta|Brigitte|Brit|Brita|Britt|Britta|Brunhild|Brunhilde|Bruni|B\00E4rbel|Camilla|Canan|Caren|Cari');
wwv_flow_imp.g_varchar2_table(1917) := 'n|Carina|Carla|Carmela|Carmen|Carmine|Carola|Carolin|Carolina|Caroline|Caterina|Catharina|Catherine|';
wwv_flow_imp.g_varchar2_table(1918) := 'Cathleen|Cathrin|Catrin|Cecilia|Centa|Chantal|Charlotte|Christa|Christel|Christiana|Christiane|Chris';
wwv_flow_imp.g_varchar2_table(1919) := unistr('tin|Christina|Christine|Christl|Cilli|Cilly|Cindy|Claire|Clara|Clarissa|Claudia|Cl\00E4re|Concetta|Conny');
wwv_flow_imp.g_varchar2_table(1920) := unistr('|Constance|Constanze|Cora|Cordula|Corina|Corinna|Corinne|Cornelia|Cosima|Cristina|Cynthia|C\00E4cilia|C\00E4');
wwv_flow_imp.g_varchar2_table(1921) := 'cilie|Dagmar|Dajana|Damaris|Dana|Danica|Daniela|Danielle|Danuta|Daria|Deborah|Delia|Denise|Desiree|D';
wwv_flow_imp.g_varchar2_table(1922) := 'iana|Diane|Dietlind|Dietlinde|Dina|Dolores|Donata|Dora|Doreen|Dorina|Doris|Dorit|Dorle|Dorota|Doroth';
wwv_flow_imp.g_varchar2_table(1923) := unistr('e|Dorothea|Dorothee|Dragica|Dunja|D\00F6rte|D\00F6rthe|Edda|Edelgard|Edeltraud|Edeltraut|Edeltrud|Edit|Edith');
wwv_flow_imp.g_varchar2_table(1924) := '|Editha|Ehrentraud|Eileen|Ekaterina|Elena|Eleni|Elenore|Eleonora|Eleonore|Elfi|Elfie|Elfriede|Elif|E';
wwv_flow_imp.g_varchar2_table(1925) := 'lisa|Elisabet|Elisabeth|Elise|Elizabeth|Elke|Ella|Ellen|Elli|Ellinor|Elly|Elma|Elsa|Elsbeth|Else|Elv';
wwv_flow_imp.g_varchar2_table(1926) := 'ira|Elwira|Elzbieta|Emilia|Emilie|Emine|Emma|Emmi|Emmy|Erdmute|Erica|Erika|Erna|Ernestine|Ester|Esth';
wwv_flow_imp.g_varchar2_table(1927) := 'er|Etta|Eugenia|Eugenie|Eva|Evamaria|Evangelia|Evelin|Eveline|Evelyn|Evelyne|Evi|Ewa|Fabienne|Fadime';
wwv_flow_imp.g_varchar2_table(1928) := '|Fanny|Fatima|Fatma|Felicia|Felicitas|Felizitas|Filiz|Flora|Florence|Florentine|Franca|Francesca|Fra';
wwv_flow_imp.g_varchar2_table(1929) := 'ncoise|Franka|Franziska|Frauke|Frederike|Freia|Freya|Frida|Frieda|Friedericke|Friederike|Friedhilde|';
wwv_flow_imp.g_varchar2_table(1930) := 'Friedl|Friedlinde|Gabi|Gabriela|Gabriele|Gabriella|Gaby|Galina|Genoveva|Georgia|Georgine|Geraldine|G';
wwv_flow_imp.g_varchar2_table(1931) := 'erda|Gerdi|Gerhild|Gerlind|Gerlinde|Gerta|Gerti|Gertraud|Gertraude|Gertraut|Gertrud|Gertrude|Gesa|Ge';
wwv_flow_imp.g_varchar2_table(1932) := 'sche|Gesine|Geza|Giesela|Gilda|Gina|Giovanna|Gisa|Gisela|Gislinde|Gitta|Gitte|Giuseppina|Gloria|Gord';
wwv_flow_imp.g_varchar2_table(1933) := 'ana|Grazyna|Greta|Gretchen|Grete|Gretel|Gretl|Grit|Gudrun|Gudula|Gunda|Gundel|Gundi|Gundula|Gunhild|';
wwv_flow_imp.g_varchar2_table(1934) := unistr('Gusti|G\00F6n\00FCl|G\00FClay|G\00FClsen|G\00FClten|Halina|Hanife|Hanna|Hannah|Hannchen|Hanne|Hannelore|Hanny|Harriet|Ha');
wwv_flow_imp.g_varchar2_table(1935) := 'tice|Hedda|Hedi|Hedwig|Hedy|Heide|Heidelinde|Heidelore|Heidemarie|Heiderose|Heidi|Heidrun|Heike|Hele';
wwv_flow_imp.g_varchar2_table(1936) := 'n|Helena|Helene|Helga|Hella|Helma|Helmtrud|Henni|Henny|Henri|Henriette|Henrike|Herlinde|Herma|Hermin';
wwv_flow_imp.g_varchar2_table(1937) := 'e|Herta|Hertha|Hilda|Hildburg|Hilde|Hildegard|Hildegart|Hildegund|Hildegunde|Hilma|Hiltraud|Hiltrud|';
wwv_flow_imp.g_varchar2_table(1938) := unistr('Hubertine|Hulda|H\00FClya|Ida|Ildiko|Ilka|Ilona|Ilonka|Ilse|Imelda|Imke|Ina|Ines|Inga|Inge|Ingeborg|Inge');
wwv_flow_imp.g_varchar2_table(1939) := 'burg|Ingelore|Ingetraud|Ingetraut|Ingrid|Ingried|Inka|Inken|Inna|Insa|Ira|Irena|Irene|Irina|Iris|Irm';
wwv_flow_imp.g_varchar2_table(1940) := 'a|Irmela|Irmengard|Irmgard|Irmhild|Irmi|Irmingard|Irmtraud|Irmtraut|Irmtrud|Isa|Isabel|Isabell|Isabe';
wwv_flow_imp.g_varchar2_table(1941) := 'lla|Isabelle|Isolde|Ivana|Ivanka|Ivonne|Iwona|Jacqueline|Jadwiga|Jana|Jane|Janet|Janett|Janette|Jani';
wwv_flow_imp.g_varchar2_table(1942) := 'n|Janina|Janine|Janna|Jaqueline|Jasmin|Jasmina|Jeanette|Jeannette|Jeannine|Jelena|Jennifer|Jenny|Jes';
wwv_flow_imp.g_varchar2_table(1943) := 'sica|Jessika|Jo|Joana|Joanna|Johanna|Johanne|Jolanda|Jolanta|Jolanthe|Josefa|Josefine|Josephine|Judi';
wwv_flow_imp.g_varchar2_table(1944) := 'th|Julia|Juliana|Juliane|Julie|Justina|Justine|Jutta|Karen|Karin|Karina|Karla|Karola|Karolin|Karolin';
wwv_flow_imp.g_varchar2_table(1945) := 'a|Karoline|Kata|Katalin|Katarina|Katarzyna|Katerina|Katharina|Katharine|Katherina|Kathi|Kathleen|Kat';
wwv_flow_imp.g_varchar2_table(1946) := unistr('hrin|Kathy|Kati|Katja|Katrin|Katy|Kerstin|Kira|Kirsten|Kirstin|Klara|Klaudia|Klothilde|Kl\00E4re|Konstan');
wwv_flow_imp.g_varchar2_table(1947) := 'ze|Kordula|Korinna|Kornelia|Kreszentia|Kreszenz|Kriemhild|Krista|Kristiane|Kristin|Kristina|Kristine';
wwv_flow_imp.g_varchar2_table(1948) := unistr('|Krystyna|Kunigunda|Kunigunde|K\00E4te|K\00E4the|K\00E4thi|Laila|Lara|Larissa|Laura|Lea|Leila|Lena|Lene|Leni|Leo');
wwv_flow_imp.g_varchar2_table(1949) := 'kadia|Leonie|Leonore|Leopoldine|Leyla|Lia|Liane|Lidia|Lidija|Lidwina|Liesa|Liesbeth|Lieschen|Liesel|';
wwv_flow_imp.g_varchar2_table(1950) := 'Lieselotte|Lili|Lilian|Liliana|Liliane|Lilija|Lilli|Lilly|Lilo|Lina|Linda|Lioba|Lisa|Lisbeth|Liselot';
wwv_flow_imp.g_varchar2_table(1951) := 'te|Lisette|Lissi|Lissy|Ljiljana|Ljubica|Ljudmila|Loni|Lore|Loretta|Lotte|Lotti|Louise|Lucia|Lucie|Lu';
wwv_flow_imp.g_varchar2_table(1952) := 'dmila|Ludmilla|Ludwina|Luisa|Luise|Luitgard|Luka|Luzia|Luzie|Lydia|Madeleine|Madlen|Magarete|Magda|M';
wwv_flow_imp.g_varchar2_table(1953) := 'agdalena|Magdalene|Magret|Magrit|Maike|Maja|Malgorzata|Mandy|Manja|Manuela|Mara|Marcella|Mareen|Mare';
wwv_flow_imp.g_varchar2_table(1954) := 'ike|Mareile|Maren|Marga|Margaret|Margareta|Margarete|Margaretha|Margarethe|Margarita|Margit|Margita|';
wwv_flow_imp.g_varchar2_table(1955) := 'Margitta|Margot|Margret|Margrit|Maria|Mariana|Marianna|Marianne|Marica|Marie|Mariechen|Mariele|Marie';
wwv_flow_imp.g_varchar2_table(1956) := 'luise|Marietta|Marija|Marika|Marina|Mariola|Marion|Marisa|Marit|Marita|Maritta|Marjan|Marleen|Marlen';
wwv_flow_imp.g_varchar2_table(1957) := '|Marlene|Marlies|Marliese|Marlis|Marta|Martha|Martina|Martine|Mary|Marzena|Mathilde|Maya|Mechthild|M';
wwv_flow_imp.g_varchar2_table(1958) := 'echthilde|Mechtild|Meike|Melanie|Melissa|Melita|Melitta|Meral|Mercedes|Meryem|Meta|Mia|Michaela|Mich';
wwv_flow_imp.g_varchar2_table(1959) := 'aele|Michelle|Milena|Milica|Milka|Mina|Minna|Mira|Mirella|Miriam|Mirja|Mirjam|Mirjana|Miroslawa|Mona';
wwv_flow_imp.g_varchar2_table(1960) := '|Monica|Monika|Monique|Monja|Myriam|Nada|Nadeschda|Nadeshda|Nadia|Nadin|Nadine|Nadja|Nancy|Natali|Na';
wwv_flow_imp.g_varchar2_table(1961) := 'talia|Natalie|Natalija|Natalja|Natascha|Nathalie|Nelli|Nelly|Nermin|Nevenka|Nicole|Nina|Nora|Norma|N';
wwv_flow_imp.g_varchar2_table(1962) := 'otburga|Nuran|Nuray|Nurten|Oda|Olav|Olena|Olga|Olivia|Ortrud|Ortrun|Ottilie|Oxana|Pamela|Paola|Pasca';
wwv_flow_imp.g_varchar2_table(1963) := 'le|Patricia|Patrizia|Paula|Paulina|Pauline|Peggy|Petra|Philomena|Pia|Polina|Priska|Rabea|Radmila|Rah';
wwv_flow_imp.g_varchar2_table(1964) := 'el|Raisa|Raissa|Ramona|Raphaela|Rebecca|Rebekka|Regina|Regine|Reingard|Reinhild|Reinhilde|Rena|Renat';
wwv_flow_imp.g_varchar2_table(1965) := 'a|Renate|Reni|Resi|Ria|Ricarda|Rita|Romana|Romy|Rosa|Rosalia|Rosalie|Rosalinde|Rose|Rosel|Roselinde|';
wwv_flow_imp.g_varchar2_table(1966) := 'Rosemarie|Rosi|Rosina|Rosita|Rosl|Rosmarie|Roswita|Roswitha|Rotraud|Rotraut|Ruth|Ruthild|Sabina|Sabi';
wwv_flow_imp.g_varchar2_table(1967) := 'ne|Sabrina|Samira|Sandra|Sandy|Sara|Sarah|Sarina|Saskia|Selma|Semra|Senta|Serpil|Sevim|Sibel|Sibilla';
wwv_flow_imp.g_varchar2_table(1968) := '|Sibille|Sibylla|Sibylle|Sieglinde|Siegrid|Siegried|Siegrun|Siglinde|Sigrid|Sigrun|Silja|Silke|Silva';
wwv_flow_imp.g_varchar2_table(1969) := unistr('|Silvana|Silvia|Simona|Simone|Sina|Sinaida|Slavica|Sofia|Sofie|Solveig|Song\00FCl|Sonia|Sonja|Sophia|Sop');
wwv_flow_imp.g_varchar2_table(1970) := 'hie|Stefani|Stefania|Stefanie|Steffi|Stella|Stephanie|Stilla|Susan|Susana|Susann|Susanna|Susanne|Sus';
wwv_flow_imp.g_varchar2_table(1971) := 'e|Susi|Suzanne|Svea|Svenja|Svetlana|Swantje|Swetlana|Sybilla|Sybille|Sylke|Sylvana|Sylvia|Sylvie|Syl';
wwv_flow_imp.g_varchar2_table(1972) := 'wia|Tabea|Tamara|Tania|Tanja|Tatiana|Tatjana|Telse|Teresa|Thea|Theda|Thekla|Theodora|Theres|Theresa|';
wwv_flow_imp.g_varchar2_table(1973) := unistr('Therese|Theresia|Tilly|Tina|Traude|Traudel|Traudl|Traute|Trude|Trudel|Trudi|T\00FClay|T\00FCrkan|Ulla|Ulrike');
wwv_flow_imp.g_varchar2_table(1974) := '|Undine|Ursel|Ursula|Urszula|Urte|Uschi|Uta|Ute|Valentina|Valentine|Valeri|Valeria|Valerie|Valeska|V';
wwv_flow_imp.g_varchar2_table(1975) := 'anessa|Vera|Verena|Veronica|Veronika|Veronique|Vesna|Victoria|Viktoria|Viola|Violetta|Virginia|Vivia';
wwv_flow_imp.g_varchar2_table(1976) := 'ne|Walburga|Waldtraut|Walentina|Walli|Wally|Waltraud|Waltraut|Waltrud|Wanda|Wencke|Wendelin|Wenke|We';
wwv_flow_imp.g_varchar2_table(1977) := 'ra|Wibke|Wiebke|Wilfriede|Wilhelmine|Wilma|Wiltrud|Xenia|Yasemin|Yasmin|Yvette|Yvonne|Zdenka|Zehra|Z';
wwv_flow_imp.g_varchar2_table(1978) := unistr('enta|Zeynep|Zita|Zofia|Adrien|Aim\00E9|Alain|Alphonse|Antoine|Beno\00EEt|Bertrand|Christophe|\00C9douard|\00C9mile|E');
wwv_flow_imp.g_varchar2_table(1979) := unistr('mmanuel|\00C9ric|\00C9tienne|Eug\00E8ne|Fran\00E7ois|Franck|Fr\00E9d\00E9ric|Georges|G\00E9rard|Gilles|Gr\00E9goire|Guillaume|Guy|Ho');
wwv_flow_imp.g_varchar2_table(1980) := unistr('nor\00E9|Hugues|Isaac|Jacques|Jean|J\00E9r\00F4me|Jules|Julien|Laurent|L\00E9on|Luc|Lucas|Matthieu|No\00EBl|Olivier|R\00E9my');
wwv_flow_imp.g_varchar2_table(1981) := unistr('|S\00E9bastien|St\00E9phane|Th\00E9odore|Th\00E9ophile|Thibaut|Thibault|Thierry|Timoth\00E9e|Tristan|Xavier|Yves|Zachari');
wwv_flow_imp.g_varchar2_table(1982) := unistr('e|Ad\00E9la\00EFde|Ad\00E8le|Adrienne|Agn\00E8s|Aim\00E9e|Alexandrie|Alix|Alexandria|Am\00E9lie|Ana\00EFs|Anastasie|Andr\00E9e|Anouk');
wwv_flow_imp.g_varchar2_table(1983) := unistr('|Arnaude|Audrey|Aur\00E9lie|Aurore|Capucine|C\00E9cile|C\00E9line|C\00E9lina|Christelle|Claudine|Cl\00E9mence|Colette|Do');
wwv_flow_imp.g_varchar2_table(1984) := unistr('roth\00E9e|\00C9dith|\00C9l\00E9onore|\00C9lisabeth|\00C9lise|\00C9lodie|\00C9milie|Emmanuelle|Fran\00E7oise|Fr\00E9d\00E9rique|Gabrielle|Genevi');
wwv_flow_imp.g_varchar2_table(1985) := unistr('\00E8ve|H\00E9l\00E8ne|Hortense|In\00E8s|Jeanne|Jos\00E9phine|Josette|Juliette|Laetitia|Laure|Laurence|Lorraine|Luce|Luc');
wwv_flow_imp.g_varchar2_table(1986) := unistr('y|Manon|Marcelle|Margaux|Margaud|Marguerite|Maggie|Marine|Marthe|Maryse|Mich\00E8le|Nath|No\00E9mi|Oc\00E9ane|Od');
wwv_flow_imp.g_varchar2_table(1987) := unistr('ette|Olivie|Paulette|P\00E9n\00E9lope|Philippine|Ren\00E9e|St\00E9phanie|Th\00E9r\00E8se|Val\00E9rie|V\00E9ronique|Victoire|Virginie');
wwv_flow_imp.g_varchar2_table(1988) := unistr('|Zo\00E9|Camille|Claude|Dominique|Achille|Adamo|Adelmo|Adriano|Agnolo|Agostino|Alberico|Alderano|Alessio');
wwv_flow_imp.g_varchar2_table(1989) := '|Alfio|Alphons|Amadeo|Amedeo|Amico|Amleto|Annibale|Ansaldo|Antonello|Armando|Arnaldo|Arnulfo|Arsenio';
wwv_flow_imp.g_varchar2_table(1990) := '|Arturo|Atenulf|Augusto|Azeglio|Baccio|Baldassare|Bartolomeo|Benedetto|Benito|Benvenuto|Beppe|Bernar';
wwv_flow_imp.g_varchar2_table(1991) := 'do|Biagio|Calcedonio|Camillo|Cesare|Cipriano|Cirillo|Ciro|Coluccio|Coriolano|Corrado|Costantino|Cost';
wwv_flow_imp.g_varchar2_table(1992) := 'anzo|Damiano|Dante|Dario|Delfino|Dionigi|Donatello|Donato|Durante|Edoardo|Elladio|Elmo|Emilio|Ennio|';
wwv_flow_imp.g_varchar2_table(1993) := 'Enzio|Enzo|Eraldo|Ermanno|Ermenegildo|Ermes|Ernesto|Ettore|Ezio|Fabio|Fabrizio|Fausto|Fedele|Federic';
wwv_flow_imp.g_varchar2_table(1994) := 'o|Federigo|Ferdinando|Fiorenzo|Fiorino|Flavio|Fulvio|Galasso|Gaspare|Gastone|Geronimo|Giacinto|Giaco';
wwv_flow_imp.g_varchar2_table(1995) := 'bbe|Giacomo|Giampaolo|Giampiero|Gian|Giancarlo|Gianfrancesco|Gianfranco|Gianluca|Gianluigi|Gianmarco';
wwv_flow_imp.g_varchar2_table(1996) := unistr('|Gianni|Gianpaolo|Gianpietro|Gilberto|Gioacchino|Gioachino|Gioele|Gioffre|Gionata|Giosu\00E8|Girolamo|Gi');
wwv_flow_imp.g_varchar2_table(1997) := 'uliano|Giulio|Giustino|Goffredo|Graziano|Greco|Guarino|Guglielmo|Gustavo|Ignazio|Ippazio|Jacopo|Lamb';
wwv_flow_imp.g_varchar2_table(1998) := 'erto|Lando|Laureano|Lazzaro|Leone|Leopoldo|Liberto|Livio|Lodovico|Luca|Luchino|Lucio|Ludovico|Marcan';
wwv_flow_imp.g_varchar2_table(1999) := 'tonio|Marcello|Mariano|Martino|Massimiliano|Mattia|Maurilio|Mauro|Michelangelo|Michele|Micheletto|Mi';
wwv_flow_imp.g_varchar2_table(2000) := unistr('chelotto|Milo|Nanni|Napoleone|Niccol\00F2|Nicola|Nicol\00F2|Nino|Orazio|Oreste|Orlando|Osvaldo|Ottavio|Otton');
wwv_flow_imp.g_varchar2_table(2001) := 'e|Panfilo|Paride|Pasqual|Patrizio|Pellegrino|Pier|Pierangelo|Piergiorgio|Piergiuseppe|Pierluigi|Pier';
wwv_flow_imp.g_varchar2_table(2002) := 'maria|Piero|Pierpaolo|Piersanti|Pompeo|Pomponio|Puccio|Raffaele|Raffaellino|Raffaello|Raimondo|Ranie';
wwv_flow_imp.g_varchar2_table(2003) := 'ri|Rembrandt|Renzo|Riccardo|Ricciotti|Rodolfo|Rolando|Romeo|Romolo|Ronaldo|Rosario|Ruggero|Ruggiero|';
wwv_flow_imp.g_varchar2_table(2004) := 'Sabatino|Salvi|Sante|Santino|Saverio|Sergius|Severino|Silvestro|Telemaco|Temistocle|Tiziano|Tonino|T';
wwv_flow_imp.g_varchar2_table(2005) := 'orquato|Tullio|Ubaldo|Uberto|Ugo|Ugolino|Umberto|Valerio|Venancio|Vincentio|Virgilio|Adelasia|Alessa';
wwv_flow_imp.g_varchar2_table(2006) := 'ndra|Alessia|Allegra|Annalisa|Annetta|Annunziata|Antonella|Aria|Aurora|Berenice|Cassandra|Chiara|Cle';
wwv_flow_imp.g_varchar2_table(2007) := 'lia|Donatella|Donna|Eleanora|Eliana|Evangelista|Fabia|Fabrizia|Federica|Fernanda|Fiamma|Filippa|Flav';
wwv_flow_imp.g_varchar2_table(2008) := 'ia|Fortunata|Gelsomina|Gemma|Germana|Giada|Gianna|Giorgia|Giulia|Giuliana|Giulietta|Graziella|Greca|';
wwv_flow_imp.g_varchar2_table(2009) := 'Griselda|Ilaria|Iolanda|Lauretta|Letizia|Liana|Licia|Lilla|Livia|Lolita|Loredana|Luciana|Lucrezia|Lu';
wwv_flow_imp.g_varchar2_table(2010) := 'dovica|Luigina|Margherita|Marissa|Matilda|Maura|Melania|Melina|Michela|Morena|Nedda|Nicoletta|Ninett';
wwv_flow_imp.g_varchar2_table(2011) := 'a|Ornella|Paloma|Paoletta|Pierina|Pina|Priscilla|Raffaella|Roberta|Romina|Rosaria|Rossana|Serafina|S';
wwv_flow_imp.g_varchar2_table(2012) := 'erena|Simonetta|Sole|Tiziana|Tonia|Vincenza|Viridiana|Vittoria|Zaira|Aaron|Abel|Aiden|Amin|Arie|Aron';
wwv_flow_imp.g_varchar2_table(2013) := '|Ayden|Ayoub|Bart|Bas|Bastiaan|Beau|Berat|Bilal|Bjorn|Boaz|Bradley|Bram|Brent|Bryan|Cas|Casper|Chris';
wwv_flow_imp.g_varchar2_table(2014) := unistr('|Colin|Collin|Cornelis|Daan|Dani|Dani\00EBl|Dave|Dean|Dex|Dion|Duuk|Dylan|Dylano|Emir|Faas|Fedde|Finn|Fl');
wwv_flow_imp.g_varchar2_table(2015) := 'oris|Gerrit|Giel|Gijs|Guus|Hamza|Hidde|Imran|Jack|Jake|Jamie|Jari|Jason|Jasper|Jay|Jayden|Jayson|Jel';
wwv_flow_imp.g_varchar2_table(2016) := unistr('le|Jelte|Jesper|Jesse|Jim|Jip|Job|Joep|Joey|Joost|Jordy|Joris|Jorn|Jort|Joshua|Jo\00EBl|Jurre|Justin|Kai');
wwv_flow_imp.g_varchar2_table(2017) := '|Kay|Keano|Kian|Kick|Koen|Kyan|Kyano|Laurens|Lenn|Levi|Lex|Liam|Loek|Luke|Luuk|Maarten|Mads|Marijn|M';
wwv_flow_imp.g_varchar2_table(2018) := 'arinus|Mart|Mason|Mathijs|Mats|Matthijs|Maurits|Mees|Melle|Merijn|Mick|Mika|Morris|Muhammed|Nathan|N';
wwv_flow_imp.g_varchar2_table(2019) := 'aud|Niek|Noah|Noud|Nout|Owen|Pepijn|Pieter|Pim|Quinn|Quinten|Raf|Ravi|Rayan|Rens|Rick|Rik|Riley|Roan';
wwv_flow_imp.g_varchar2_table(2020) := '|Rowan|Ryan|Sam|Sander|Sebastiaan|Sem|Senn|Senna|Sep|Seth|Siem|Sil|Sjoerd|Stan|Stef|Sten|Stijn|Teun|';
wwv_flow_imp.g_varchar2_table(2021) := 'Thijmen|Thijn|Thijs|Thom|Ties|Tijmen|Tijn|Tijs|Twan|Tycho|Tygo|Tyler|Valentijn|Vigo|Vince|Wesley|Wes';
wwv_flow_imp.g_varchar2_table(2022) := 'sel|Willem|Wout|Wouter|Xavi|Yassin|Youssef|Zakaria|Aaliyah|Alyssa|Amber|Amelia|Amina|Amira|Amy|Annab';
wwv_flow_imp.g_varchar2_table(2023) := unistr('el|Annemijn|Ashley|Aya|Aylin|Azra|Bente|Benthe|Bibi|Bo|Carlijn|Cato|Ceylin|Chlo\00E9|Chlo\00EB|Danique|Daphn');
wwv_flow_imp.g_varchar2_table(2024) := unistr('e|Demi|Dewi|Ecrin|Elin|Eline|Eliza|Elize|Emily|Esila|Esmee|Esm\00E9e|Evelien|Evie|Evy|Fabi\00EBnne|Fay|Faye|');
wwv_flow_imp.g_varchar2_table(2025) := 'Feline|Fem|Femke|Fenna|Fenne|Fien|Fiene|Fleur|Floor|Floortje|Frederique'';'||wwv_flow.LF||
'    l_last_name_catalog(3)';
wwv_flow_imp.g_varchar2_table(2026) := unistr(' := ''Ackermann|Adler|Adolph|Albers|Anders|Atzler|Aumann|Austerm\00FChle|Bachmann|B\00E4hr|B\00E4rer|Barkholz|Bar');
wwv_flow_imp.g_varchar2_table(2027) := 'th|Bauer|Baum|Becker|Beckmann|Beer|Beier|Bender|Benthin|Berger|Beyer|Bien|Biggen|Binner|Birnbaum|Blo';
wwv_flow_imp.g_varchar2_table(2028) := unistr('ch|Bl\00FCmel|Bohlander|Bonbach|Bolander|Bolnbach|Bolzmann|B\00F6rner|Bohnbach|Boucsein|Briemer|Bruder|Buchh');
wwv_flow_imp.g_varchar2_table(2029) := 'olz|Budig|Butte|Carsten|Caspar|Christoph|Cichorius|Conradi|Davids|Dehmel|Dietz|Dippel|Ditschlerin|Do';
wwv_flow_imp.g_varchar2_table(2030) := unistr('bes|D\00F6hn|D\00F6ring|D\00F6rr|D\00F6rschner|Dowerg|Drewes|Drub|Drubin|Eberhardt|Ebert|Eberth|Eckbauer|Ehlert|Eige');
wwv_flow_imp.g_varchar2_table(2031) := unistr('nwillig|Eimer|Ernst|Etzler|Etzold|Faust|Fechner|Fiebig|Finke|Fischer|Flantz|Fliegner|F\00F6rster|Franke|');
wwv_flow_imp.g_varchar2_table(2032) := unistr('Freudenberger|Fritsch|Fr\00F6hlich|Gehringer|Geisel|Geisler|Gei\00DFler|Gerlach|Gertz|Gierschner|Gie\00DF|Girsch');
wwv_flow_imp.g_varchar2_table(2033) := unistr('ner|Gnatz|Gorlitz|Gotthard|Graf|Gr\00F6ttner|Gude|Gunpf|Gumprich|Gute|Gutknecht|Haase|Haering|H\00E4nel|H\00E4ri');
wwv_flow_imp.g_varchar2_table(2034) := 'ng|Hahn|Hamann|Hande|Harloff|Hartmann|Hartung|Hauffer|Hecker|Heidrich|Hein|Heinrich|Heintze|Heinz|He';
wwv_flow_imp.g_varchar2_table(2035) := 'llwig|Henck|Hendriks|Henk|Henschel|Hentschel|Hering|Hermann|Herrmann|Hermighausen|Hertrampf|Heser|He';
wwv_flow_imp.g_varchar2_table(2036) := unistr('\00DF|Hesse|Hettner|Hethur|Heuser|Hiller|Heydrich|H\00F6fig|Hofmann|Holsten|Holt|Holzapfel|H\00F6lzenbecher|H\00F6rl');
wwv_flow_imp.g_varchar2_table(2037) := unistr('e|H\00F6vel|Hoffmann|Hornich|Hornig|H\00FCbel|Huhn|Jacob|J\00E4hn|J\00E4kel|J\00E4ntsch|Jessel|Jockel|Johann|Jopich|Junc');
wwv_flow_imp.g_varchar2_table(2038) := unistr('k|Juncken|Jungfer|Junitz|Junk|Junken|J\00FCttner|Kabus|Kade|K\00E4ster|Kallert|Kambs|Karge|Karz|Kaul|Kensy|K');
wwv_flow_imp.g_varchar2_table(2039) := unistr('eudel|Killer|Kitzmann|Klapp|Klemm|Klemt|Klingelh\00F6fer|Klotz|Knappe|Kobelt|Koch|K\00F6hler|K\00F6ster|Kohl|Kos');
wwv_flow_imp.g_varchar2_table(2040) := unistr('tolzin|Kramer|Kranz|Kraus|Krause|Kraushaar|Krebs|Krein|Kreusel|Kroker|Kruschwitz|Kuhl|K\00FChnert|Kusch|');
wwv_flow_imp.g_varchar2_table(2041) := unistr('Lachmann|Ladeck|Lange|Langern|Lehmann|Liebelt|Lindau|Lindner|Linke|L\00F6chel|L\00F6ffler|Loos|Lorch|Losekan');
wwv_flow_imp.g_varchar2_table(2042) := unistr('n|L\00F6wer|L\00FCbs|M\00E4lzer|Mangold|Mans|Margraf|Martin|Matth\00E4i|Meister|Mende|Mentzel|Metz|Meyer|Mielcarek|M');
wwv_flow_imp.g_varchar2_table(2043) := unistr('ies|Misicher|Mitschke|Mohaupt|Mosemann|M\00F6chlichen|Mude|M\00FChle|M\00FClichen|M\00FCller|Naser|Nerger|Nette|Neur');
wwv_flow_imp.g_varchar2_table(2044) := unistr('euther|Neusch\00E4fer|Niemeier|Noack|Nohlmans|Oderwald|Oestrovsky|Ortmann|Otto|Paffrath|P\00E4rtzelt|Patberg');
wwv_flow_imp.g_varchar2_table(2045) := unistr('|Pechel|Pergande|Peukert|Pieper|Plath|Pohl|P\00F6litz|Prei\00DF|Pruschke|Putz|R\00E4del|Radisch|Reichmann|Reinha');
wwv_flow_imp.g_varchar2_table(2046) := unistr('rdt|Reising|Renner|Reuter|Riehl|Ring|Ritter|Rogge|Rogner|Rohleder|R\00F6hrdanz|R\00F6hricht|Roht|R\00F6mer|R\00F6rri');
wwv_flow_imp.g_varchar2_table(2047) := unistr('cht|Rose|Rosemann|Rosenow|Roskoth|Rudolph|Ruppersberger|Ruppert|Rust|Sager|Salz|S\00E4uberlich|Sauer|Sch');
wwv_flow_imp.g_varchar2_table(2048) := unistr('aaf|Schacht|Sch\00E4fer|Scheel|Scheibe|Schenk|Scheuermann|Schinke|Schleich|Schlosser|Schmidt|Schmidtke|S');
wwv_flow_imp.g_varchar2_table(2049) := unistr('chmiedecke|Schmiedt|Sch\00F6nland|Scholl|Scholtz|Scholz|Schomber|Schottin|Schuchhardt|Sch\00FCler|Schulz|Sch');
wwv_flow_imp.g_varchar2_table(2050) := unistr('uster|Schweitzer|Schwital|Segebahn|Seifert|Seidel|Seip|Siering|S\00F6ding|S\00F6lzer|Sontag|Sorgatz|Speer|Sp');
wwv_flow_imp.g_varchar2_table(2051) := unistr('ie\00DF|Stadelmann|Stahr|Staude|Steckel|Steinberg|Steuer|Stey|Stiebitz|Stiffel|Stoll|Stolze|Striebitz|St');
wwv_flow_imp.g_varchar2_table(2052) := unistr('roh|Stumpf|S\00FC\00DFebier|T\00E4sche|Textor|Thanel|Thies|Tintzmann|Tlustek|Trapp|Trommler|Tr\00F6st|Trub|Tr\00FCb|Trub');
wwv_flow_imp.g_varchar2_table(2053) := unistr('in|Trupp|Tschentscher|Ullmann|Ullrich|Vogt|Vollbrecht|Wagenknecht|Wagner|W\00E4hner|Walter|Warmer|Weihma');
wwv_flow_imp.g_varchar2_table(2054) := unistr('nn|Weimer|Weinhage|Weinhold|Wei\00DF|Weitzel|Weller|Wende|Wernecke|Werner|Wesack|Wiek|Wieloch|Wilms|Wilm');
wwv_flow_imp.g_varchar2_table(2055) := unistr('sen|Winkler|Wirth|Wohlgemut|Wulf|Wulff|Zahn|Z\00E4nker|Ziegert|Zimmer|Zirme|Zobel|Zorbach|Bernard|Thomas');
wwv_flow_imp.g_varchar2_table(2056) := '|Robert|Petit|Dubois|Richard|Garcia|Durand|Moreau|Lefebvre|Simon|Laurent|Michel|Leroy|Martinez|David';
wwv_flow_imp.g_varchar2_table(2057) := unistr('|Fontaine|Morel|Fournier|Dupont|Bertrand|Lambert|Rousseau|Girard|Roux|Vincent|Lef\00E8vre|Boyer|Lopez|Bo');
wwv_flow_imp.g_varchar2_table(2058) := unistr('nnet|Andre|Fran\00E7ois|Mercier|Muller|Gu\00E9rin|Legrand|Sanchez|Garnier|Chevalier|Faure|Perez|Cl\00E9ment|Fern');
wwv_flow_imp.g_varchar2_table(2059) := unistr('andez|Blanc|Robin|Morin|Gauthier|Pereira|Perrin|Roussel|Henry|Duval|Gautier|Nicolas|Masson|Marie|No\00EB');
wwv_flow_imp.g_varchar2_table(2060) := unistr('l|Ferreira|Lemaire|Mathieu|Rivi\00E8re|Denis|Marchand|Rodriguez|Dumont|Payet|Lucas|Dufour|Joly|Blanchard');
wwv_flow_imp.g_varchar2_table(2061) := unistr('|Meunier|Rodrigues|Caron|G\00E9rard|Fernandes|Brunet|Barbier|Leroux|Renard|Goncalves|Gaillard|Brun|Roy|P');
wwv_flow_imp.g_varchar2_table(2062) := 'icard|Giraud|Roger|Schmitt|Colin|Arnaud|Vidal|Gonzalez|Lemoine|Roche|Aubert|Olivier|Leclercq|Pierre|';
wwv_flow_imp.g_varchar2_table(2063) := 'Philippe|Bourgeois|Renaud|Martins|Leclerc|Guillaume|Lacroix|Lecomte|Benoit|Fabre|Carpentier|Vasseur|';
wwv_flow_imp.g_varchar2_table(2064) := 'Louis|Hubert|Jean|Dumas|Rolland|Grondin|Rey|Huet|Gomez|Dupuis|Guillot|Moulin|Hoarau|Menard|Deschamps';
wwv_flow_imp.g_varchar2_table(2065) := '|Fleury|Adam|Boucher|Poirier|Bertin|Charles|Aubry|Royer|Dupuy|Maillard|Paris|Baron|Lopes|Guyot|Carre';
wwv_flow_imp.g_varchar2_table(2066) := unistr('|Jacquet|Renault|Herv\00E9|Charpentier|Klein|Cousin|Collet|L\00E9ger|Ribeiro|Hernandez|Bailly|Schneider|Ruiz');
wwv_flow_imp.g_varchar2_table(2067) := unistr('|Langlois|Bouvier|Gomes|Pr\00E9vost|Julien|Lebrun|Breton|Germain|Millet|Boulanger|R\00E9my|Daniel|Marques|Ma');
wwv_flow_imp.g_varchar2_table(2068) := unistr('illot|Leblanc|Barre|Perrot|L\00E9v\00EAque|Marty|Benard|Monnier|Hamon|Pelletier|Alves|\00C9tienne|Marchal|Poulai');
wwv_flow_imp.g_varchar2_table(2069) := unistr('n|Tessier|Lema\00EEtre|Guichard|Besson|Mallet|Hoareau|Gillet|Weber|Collin|Chevallier|Perrier|Michaud|Car');
wwv_flow_imp.g_varchar2_table(2070) := unistr('lier|Delaunay|Chauvin|Alexandre|Mar\00E9chal|Antoine|Lebon|Cordier|Lejeune|Bouchet|Pasquier|Legros|Delat');
wwv_flow_imp.g_varchar2_table(2071) := 'tre|Humbert|Briand|Lamy|Launay|Gilbert|Perret|Lesage|Gay|Nguyen|Navarro|Besnard|Pichon|Hebert|Cohen|';
wwv_flow_imp.g_varchar2_table(2072) := unistr('Pons|Lebreton|Sauvage|Pineau|Albert|Jacques|Pinto|Barthelemy|Turpin|Bigot|Leli\00E8vre|Georges|Reynaud|O');
wwv_flow_imp.g_varchar2_table(2073) := unistr('llivier|Martel|Voisin|Leduc|Guillet|Vall\00E9e|Coulon|Camus|Marin|Teixeira|Costa|Mahe|Didier|Charrier|Ga');
wwv_flow_imp.g_varchar2_table(2074) := unistr('udin|Bodin|Guillou|Gr\00E9goire|Gros|Blanchet|Buisson|Blondel|Paul|Dijoux|Barbe|Hardy|Laine|Evrard|Lapor');
wwv_flow_imp.g_varchar2_table(2075) := unistr('te|Rossi|Joubert|Regnier|Tanguy|Gimenez|Allard|Devaux|Morvan|L\00E9vy|Dias|Courtois|Lenoir|Berthelot|Pas');
wwv_flow_imp.g_varchar2_table(2076) := 'cal|Vaillant|Guilbert|Thibault|Moreno|Duhamel|Colas|Masse|Baudry|Bruneau|Verdier|Delorme|Blin|Guillo';
wwv_flow_imp.g_varchar2_table(2077) := 'n|Mary|Coste|Pruvost|Maury|Allain|Valentin|Godard|Joseph|Brunel|Marion|Texier|Seguin|Raynaud|Bourdon';
wwv_flow_imp.g_varchar2_table(2078) := '|Raymond|Bonneau|Chauvet|Maurice|Legendre|Loiseau|Ferrand|Toussaint|Techer|Lombard|Lefort|Couturier|';
wwv_flow_imp.g_varchar2_table(2079) := unistr('Bousquet|Diaz|Riou|Clerc|Weiss|Imbert|Jourdan|Delahaye|Gilles|Guibert|B\00E8gue|Descamps|Delmas|Peltier|');
wwv_flow_imp.g_varchar2_table(2080) := unistr('Dupr\00E9|Chartier|Martineau|Laroche|Leconte|Maillet|Parent|Labb\00E9|Potier|Bazin|Normand|Pottier|Torres|La');
wwv_flow_imp.g_varchar2_table(2081) := unistr('garde|Blot|Jacquot|Lemonnier|Grenier|Rocher|Bonnin|Boutin|Munoz|Neveu|Lacombe|Mend\00E8s|Delannoy|Auger|');
wwv_flow_imp.g_varchar2_table(2082) := 'Fouquet|Mace|Ramos|Pages|Petitjean|Chauveau|Foucher|Peron|Guyon|Gallet|Rousset|Traore|Bernier|Vallet';
wwv_flow_imp.g_varchar2_table(2083) := unistr('|Letellier|Bouvet|Hamel|Chr\00E9tien|Faivre|Boulay|Thierry|Samson|Ledoux|Salmon|Gosselin|Lecoq|Pires|Lel');
wwv_flow_imp.g_varchar2_table(2084) := 'eu|Diallo|Merle|Valette|Abatantuono|Abate|Abba|Abbagnale|Accardo|Acerbi|Adinolfi|Agazzi|Agnesi|Agost';
wwv_flow_imp.g_varchar2_table(2085) := unistr('inelli|Agostini|Ajello|Albertini|Alboni|Aldobrandi|Alfieri|Alfonsi|Alighieri|Almagi\00E0|Aloisio|Alonzi|');
wwv_flow_imp.g_varchar2_table(2086) := 'Altera|Amaldi|Amato|Ammaniti|Anastasi|Andreotti|Andreozzi|Angeli|Angiolello|Anguillara|Anguissola|An';
wwv_flow_imp.g_varchar2_table(2087) := 'ichini|Antelami|Antonacci|Antonelli|Antonello|Antonetti|Antonini|Antonioni|Antonucci|Aporti|Argan|Ar';
wwv_flow_imp.g_varchar2_table(2088) := 'gentero|Argenti|Argento|Argurio|Ariasso|Ariosto|Armani|Armellini|Asmundo|Asprucci|Aulenti|Avogadro|B';
wwv_flow_imp.g_varchar2_table(2089) := 'abati|Babato|Babbo|Bacosi|Badoer|Badoglio|Baggio|Baglioni|Bajamonti|Bajardi|Balbi|Balbo|Balla|Balote';
wwv_flow_imp.g_varchar2_table(2090) := 'lli|Bandello|Baracca|Barbarigo|Barberini|Barcaccia|Barcella|Barese|Baresi|Barillaro|Baroffio|Barozzi';
wwv_flow_imp.g_varchar2_table(2091) := '|Barracco|Barsanti|Bartoli|Barzini|Basadonna|Bassi|Basso|Bataglia|Battaglia|Battelli|Battisti|Bazzi|';
wwv_flow_imp.g_varchar2_table(2092) := unistr('Beccaria|Beccheria|Beffa|Belletini|Bellini|Bellocchio|Bellucci|Bell\00F2|Bembo|Benedetti|Benigni|Benussi');
wwv_flow_imp.g_varchar2_table(2093) := unistr('|Berengario|Bergoglio|Berlusconi|Bernardi|Bernardini|Bernetti|Bernini|Berr\00E8|Bersani|Bertoli|Bertoluc');
wwv_flow_imp.g_varchar2_table(2094) := 'ci|Bertoni|Bettin|Bettoni|Bevilacqua|Biagi|Biagiotti|Bianchi|Bianchini|Bignami|Bignardi|Binaghi|Bixi';
wwv_flow_imp.g_varchar2_table(2095) := unistr('o|Blasi|Boaga|Bocca|Boccaccio|Boccherini|Boccioni|Bocelli|Bodoni|Boezio|Boiardo|Boitani|Boito|Bold\00F9|');
wwv_flow_imp.g_varchar2_table(2096) := 'Bombieri|Bompiani|Bonanno|Bonatti|Bonaventura|Bondumier|Bongiorno|Bonino|Bonolis|Bonomo|Borghese|Bor';
wwv_flow_imp.g_varchar2_table(2097) := unistr('gia|Borrani|Borromeo|Borromini|Borroni|Borsellino|Borsiere|Borzom\00EC|Bosio|Bossi|Bosurgi|Botta|Bottaro');
wwv_flow_imp.g_varchar2_table(2098) := '|Botticelli|Bottigliero|Bova|Bragadin|Bragaglia|Bramante|Brambilla|Brancaccio|Branciforte|Brenna|Bre';
wwv_flow_imp.g_varchar2_table(2099) := 'sciani|Briccialdi|Brichese|Broggini|Broschi|Brugnaro|Brunelleschi|Brunello|Bruno|Bruscantini|Bulzoni';
wwv_flow_imp.g_varchar2_table(2100) := '|Buonauro|Burcardo|Buscetta|Busoni|Cabibbo|Caboto|Cabrini|Caccianemico|Caccioppoli|Cadorna|Caetani|C';
wwv_flow_imp.g_varchar2_table(2101) := 'afarchia|Caffarelli|Cagnin|Cagnotto|Cainero|Caironi|Calarco|Calbo|Calgari|Callegari|Callegaro|Calvo|';
wwv_flow_imp.g_varchar2_table(2102) := 'Camanni|Camicione|Camilleri|Camiscione|Cammarata|Campanella|Campano|Campise|Camuccini|Canali|Canetta';
wwv_flow_imp.g_varchar2_table(2103) := '|Canevascini|Canil|Cannizzaro|Canova|Cantimori|Capecchi|Capone|Cappelli|Capuana|Caracciolo|Cardano|C';
wwv_flow_imp.g_varchar2_table(2104) := 'arducci|Carfagna|Carli|Carnera|Carocci|Carosone|Carpaccio|Carriera|Carullo|Caruso|Casadei|Casagrande';
wwv_flow_imp.g_varchar2_table(2105) := unistr('|Casale|Casaleggio|Casalodi|Casarin|Casellati|Casini|Cassar\00E0|Castelli|Castellitto|Castiglione|Castio');
wwv_flow_imp.g_varchar2_table(2106) := 'ni|Catalano|Catenazzi|Cattaneo|Cavalcanti|Cavanna|Ceci|Celentano|Cendron|Ceravolo|Ceri|Cerquiglini|C';
wwv_flow_imp.g_varchar2_table(2107) := 'erutti|Cesaroni|Cesarotti|Ceschi|Chechi|Cheda|Cherubini|Chiappetta|Chiaramonte|Chiesa|Chigi|Chindamo';
wwv_flow_imp.g_varchar2_table(2108) := '|Chinnici|Chittolini|Ciampi|Cianciolo|Ciani|Cibin|Cicala|Cicilia|Cignaroli|Cilea|Cilibrasi|Cimarosa|';
wwv_flow_imp.g_varchar2_table(2109) := 'Cimini|Cipolla|Civaschi|Coardi|Cocci|Cociarelli|Colletti|Collina|Collodi|Columbo|Combi|Comboni|Comen';
wwv_flow_imp.g_varchar2_table(2110) := 'cini|Comeriato|Comisso|Comolli|Condoleo|Contarini|Conte|Conti|Contrafatto|Coppola|Corbo|Corcos|Corra';
wwv_flow_imp.g_varchar2_table(2111) := 'di|Correr|Cortese|Cossiga|Costalonga|Costanzi|Cremonesi|Crespi|Crisafulli|Crispi|Cristoforetti|Cuda|';
wwv_flow_imp.g_varchar2_table(2112) := unistr('Cugia|Cundari|Cuomo|Curatoli|Curci|Curiel|Cusano|Cutrufo|Cutuli|Cuzzocrea|Dalla|Dallap\00E9|Dallara|Dand');
wwv_flow_imp.g_varchar2_table(2113) := 'olo|Deledda|Delle|Dellucci|Depero|Desio|Detti|Dibiasi|Disdero|Doglioni|Donarelli|Donati|Donatoni|Don';
wwv_flow_imp.g_varchar2_table(2114) := unistr('ini|Don\00E0|Doria|Dossetti|Dossi|Dovara|Draghi|Druso|Dulbecco|Duodo|Durante|Duse|Eco|Einaudi|Emanuelli|');
wwv_flow_imp.g_varchar2_table(2115) := 'Emo|Endrizzi|Errani|Errigo|Esposito|Fabbri|Fabrizi|Faggiani|Fagiani|Fagotto|Falcone|Falier|Fallaci|F';
wwv_flow_imp.g_varchar2_table(2116) := 'alloppio|Fantini|Fantoni|Fantozzi|Fanucci|Faranda|Farina|Farinelli|Farnese|Fattori|Faugno|Favata|Fed';
wwv_flow_imp.g_varchar2_table(2117) := 'erici|Federico|Fermi|Ferrabosco|Ferragamo|Ferragni|Ferrante|Ferrara|Ferrari|Ferraris|Ferrata|Ferrazz';
wwv_flow_imp.g_varchar2_table(2118) := 'i|Ferretti|Ferrucci|Fibonacci|Ficino|Fieramosca|Filangieri|Filippelli|Filippini|Filogamo|Filzi|Finet';
wwv_flow_imp.g_varchar2_table(2119) := 'ti|Finotto|Finzi|Fioravanti|Fiorucci|Fischetti|Fittipaldi|Flaiano|Florio|Fo|Foa|Foconi|Fogazzaro|Fol';
wwv_flow_imp.g_varchar2_table(2120) := unistr('etti|Folliero|Fornaciari|Forza|Foscari|Fo\00E0|Fracci|Franceschi|Franscini|Franzese|Frescobaldi|Fusani|F');
wwv_flow_imp.g_varchar2_table(2121) := 'useli|Gabba|Gabbana|Gabrieli|Gadda|Gaggini|Gagliano|Gagliardi|Gaiatto|Gaito|Galeati|Galiazzo|Galilei';
wwv_flow_imp.g_varchar2_table(2122) := '|Galtarossa|Galuppi|Galvani|Gangemi|Gargallo|Garibaldi|Garobbio|Garozzo|Garrone|Garzoni|Gasperi|Gatt';
wwv_flow_imp.g_varchar2_table(2123) := 'o|Gelli|Gemito|Gentileschi|Gentili|Gentilini|Geraci|Germano|Giacconi|Giacometti|Giammusso|Gianetti|G';
wwv_flow_imp.g_varchar2_table(2124) := 'ianinazzi|Giannelli|Giannetti|Giannini|Giannone|Giannotti|Giannuzzi|Gianvecchio|Gibilisco|Gigli|Gila';
wwv_flow_imp.g_varchar2_table(2125) := 'rdoni|Ginese|Ginesio|Gioberti|Giolitti|Giorgetti|Giovine|Giradello|Giulietti|Giunti|Giusti|Goldoni|G';
wwv_flow_imp.g_varchar2_table(2126) := 'oldstein|Golgi|Golino|Gonzaga|Gori|Gottardi|Gotti|Govoni|Gozzano|Gozzi|Gradenigo|Gramsci|Granatelli|';
wwv_flow_imp.g_varchar2_table(2127) := 'Grassi|Grasso|Gravina|Greco|Greggio|Gregori|Gregorio|Gremese|Grifeo|Grimani|Grisoni|Gritti|Grossi|Gu';
wwv_flow_imp.g_varchar2_table(2128) := 'alandi|Gualtieri|Guarana|Guarato|Guariento|Guarneri|Gucci|Guglielmi|Guicciardini|Guidone|Guidotti|Gu';
wwv_flow_imp.g_varchar2_table(2129) := 'inizzelli|Gullotta|Gulotta|Gussoni|Iacobucci|Iacovelli|Iadanza|Iannelli|Iannotti|Iannucci|Iannuzzi|I';
wwv_flow_imp.g_varchar2_table(2130) := 'mpastato|Infantino|Innocenti|Interiano|Interminei|Interminelli|Inzaghi|Ioppi|Jacuzzi|Jilani|Jovinell';
wwv_flow_imp.g_varchar2_table(2131) := 'i|Juvara|Lamborghini|Lancisi|Lanfranchi|Lattuada|Legnante|Leonardi|Leoncavallo|Leone|Leonetti|Leopar';
wwv_flow_imp.g_varchar2_table(2132) := 'di|Lercari|Lerner|Letta|Lettiere|Ligorio|Liguori|Lippomano|Littizzetto|Liverotti|Lollobrigida|Lombar';
wwv_flow_imp.g_varchar2_table(2133) := 'di|Lombardo|Lombroso|Longhena|Lopresti|Loredan|Lovato|Lucarelli|Lucchesi|Lucciano|Luciani|Ludovisi|L';
wwv_flow_imp.g_varchar2_table(2134) := 'una|Lupo|Luria|Lussu|Luxardo|Luzi|Maccanelli|Maderna|Maderno|Maffei|Maggioli|Maglio|Magnani|Magrassi';
wwv_flow_imp.g_varchar2_table(2135) := '|Majewski|Majorana|Malacarne|Malaparte|Malatesta|Malenchini|Malipiero|Malpighi|Manacorda|Mancini|Man';
wwv_flow_imp.g_varchar2_table(2136) := 'noia|Manolesso|Mantegazza|Mantegna|Manunta|Manzoni|Marangoni|Marazzi|Marcacci|Marconi|Marenzio|Marin';
wwv_flow_imp.g_varchar2_table(2137) := 'etti|Marini|Marino|Marrone|Marsili|Martinelli|Martucci|Marzorati|Mascagni|Mascheroni|Maspero|Mastand';
wwv_flow_imp.g_varchar2_table(2138) := 'rea|Mastroianni|Mattarella|Matteotti|Mazzacurati|Mazzanti|Mazzeo|Mazzi|Mazzini|Mazzocchi|Medici|Meng';
wwv_flow_imp.g_varchar2_table(2139) := 'olo|Mennea|Mercadante|Mercalli|Mercantini|Mercati|Merisi|Metella|Meucci|Mezzetta|Micca|Michelangeli|';
wwv_flow_imp.g_varchar2_table(2140) := 'Micheletti|Migliaccio|Milanesi|Mimun|Miniati|Missoni|Moccia|Mocenigo|Modiano|Modigliani|Modugno|Mogh';
wwv_flow_imp.g_varchar2_table(2141) := 'erini|Molesini|Monaco|Mondadori|Mondaini|Monduzzi|Moneta|Monicelli|Montalcini|Montalti|Montanari|Mon';
wwv_flow_imp.g_varchar2_table(2142) := 'tanariello|Montanelli|Monte|Montecchi|Montesano|Montessori|Monteverdi|Monti|Morabito|Morandi|Morandi';
wwv_flow_imp.g_varchar2_table(2143) := 'ni|Morellato|Moresi|Moretti|Morgagni|Morlacchi|Morosini|Morpurgo|Morricone|Morrocco|Mortati|Morucci|';
wwv_flow_imp.g_varchar2_table(2144) := 'Moschino|Mozart|Munari|Muratori|Murialdo|Murri|Musatti|Muti|Naccari|Nadi|Napolitano|Natta|Navarria|N';
wwv_flow_imp.g_varchar2_table(2145) := 'avone|Necci|Nibali|Nicoletti|Nicolini|Nicolucci|Nievo|Niggli|Niscoromni|Nitti|Nitto|Nolcini|Nonis|No';
wwv_flow_imp.g_varchar2_table(2146) := 'rbiato|Nordio|Nosiglia|Notarbartolo|Novaro|Nugnes|Odescalchi|Offredi|Oliboni|Olivetti|Omma|Onio|Onis';
wwv_flow_imp.g_varchar2_table(2147) := 'to|Opizzi|Orengo|Orlando|Orsini|Ortese|Ortolani|Oscuro|Ossani|Ossola|Ostinelli|Ottino|Ovadia|Pace|Pa';
wwv_flow_imp.g_varchar2_table(2148) := 'celli|Pacetti|Pacillo|Pacomio|Padovano|Paganini|Pagliaro|Pagnotto|Palazzo|Palladio|Palmisano|Palombi';
wwv_flow_imp.g_varchar2_table(2149) := '|Paltrinieri|Palumbo|Panatta|Panicucci|Panzera|Paoletti|Paolini|Paolucci|Papafava|Papetti|Pareto|Par';
wwv_flow_imp.g_varchar2_table(2150) := 'ini|Parisi|Parmitano|Parpinel|Parri|Paruta|Pascarella|Pasolini|Pasqua|Passalacqua|Pastine|Pausini|Pa';
wwv_flow_imp.g_varchar2_table(2151) := 'vanello|Pavarotti|Pavone|Peano|Pederiva|Pedersoli|Pedrazzini|Pedroni|Pellegrini|Pelli|Pellico|Pennet';
wwv_flow_imp.g_varchar2_table(2152) := 'ta|Pepe|Peranda|Pergolesi|Perini|Perozzo|Persico|Pertile|Pertini|Peruzzi|Petralli|Petrassi|Petrocell';
wwv_flow_imp.g_varchar2_table(2153) := 'i|Petrucci|Petrucelli|Petruzzi|Pezzali|Piacentini|Piane|Piazzi|Piccinni|Piccio|Pietrangeli|Pigafetta';
wwv_flow_imp.g_varchar2_table(2154) := '|Pignatti|Pinamonte|Pincherle|Pininfarina|Piovani|Pirandello|Pirelli|Pisacane|Pisani|Pisano|Pisaroni';
wwv_flow_imp.g_varchar2_table(2155) := '|Pistoletto|Pizzamano|Pizzetti|Pizziol|Pizzo|Platini|Poerio|Polani|Polesel|Polizzi|Pometta|Pontecorv';
wwv_flow_imp.g_varchar2_table(2156) := 'o|Ponti|Porcellato|Porzio|Pozzecco|Prada|Praga|Pratesi|Prati|Priuli|Procacci|Prodi|Proietti|Pucci|Pu';
wwv_flow_imp.g_varchar2_table(2157) := 'ccini|Pugliese|Puglisi|Pulci|Quasimodo|Querini|Raimondi|Ramazzotti|Randazzo|Rapisardi|Rastelli|Rauri';
wwv_flow_imp.g_varchar2_table(2158) := 'ca|Ravaglioli|Redi|Regge|Renier|Rensi|Renzi|Respighi|Riccardi|Riccati|Ricci|Ricciardi|Ricolfi|Rienzo';
wwv_flow_imp.g_varchar2_table(2159) := '|Righi|Rinaldi|Rismondo|Ritacca|Rizzo|Rizzoli|Rocca|Roccabonella|Roero|Romagnoli|Romano|Romiti|Ronca';
wwv_flow_imp.g_varchar2_table(2160) := 'lli|Rosiello|Rosmini|Rosselli|Rossellini|Rossetti|Rossini|Roth|Rubbia|Ruberto|Ruffini|Ruggeri|Ruggie';
wwv_flow_imp.g_varchar2_table(2161) := 'ri|Russo|Rusticucci|Sabatini|Sabbatini|Saffi|Sagese|Sagnelli|Sagredo|Salandra|Salata|Salgari|Salieri';
wwv_flow_imp.g_varchar2_table(2162) := '|Salvemini|Salvini|Salvo|Samele|Sandi|Sanguineti|Sansoni|Santi|Santorio|Santoro|Sanudo|Saraceno|Sara';
wwv_flow_imp.g_varchar2_table(2163) := 'cino|Saragat|Satriani|Satta|Sauli|Sauro|Savorgnan|Sbarbaro|Scaduto|Scalera|Scalfaro|Scamarcio|Scando';
wwv_flow_imp.g_varchar2_table(2164) := 'ne|Scaramucci|Scarfoglio|Scarlatti|Scarpa|Scarpetta|Scarponi|Schiaparelli|Schiavo|Schiavone|Schicchi';
wwv_flow_imp.g_varchar2_table(2165) := unistr('|Scialpi|Scotti|Scotto|Seddio|Segni|Segr\00E8|Semitecolo|Serao|Serlupi|Sermonti|Serraglio|Sforza|Sgalamb');
wwv_flow_imp.g_varchar2_table(2166) := 'ro|Sgarbi|Sibilia|Siffredi|Silvestri|Simeoni|Sinisi|Sismondi|Smirnoff|Sobrero|Soderini|Soffici|Sokol';
wwv_flow_imp.g_varchar2_table(2167) := 'ov|Solari|Solimena|Sollima|Sommaruga|Sonnino|Soprano|Soranzo|Sordi|Sorrentino|Spadafora|Spallanzani|';
wwv_flow_imp.g_varchar2_table(2168) := 'Spanevello|Speri|Spinelli|Spinola|Squarcione|Sraffa|Staglieno|Stefanelli|Stein|Stoppani|Storladi|Str';
wwv_flow_imp.g_varchar2_table(2169) := 'adivari|Strangio|Stucchi|Surian|Tacchini|Taccola|Tafuri|Tagliafierro|Taliani|Taliercio|Tamborini|Tam';
wwv_flow_imp.g_varchar2_table(2170) := 'burello|Tamburi|Tamburini|Tanzini|Tarantini|Tarantino|Tarchetti|Tartaglia|Tartini|Tasca|Tasso|Tasson';
wwv_flow_imp.g_varchar2_table(2171) := 'i|Tebaldi|Tedesco|Telesio|Tencalla|Terragni|Tiepolo|Tirabassi|Togliatti|Tognazzi|Toldo|Tolentino|Tom';
wwv_flow_imp.g_varchar2_table(2172) := 'aselli|Tomasetti|Tomasini|Tomei|Tommaseo|Toninelli|Tonisto|Torlonia|Tornatore|Torricelli|Toscani|Tos';
wwv_flow_imp.g_varchar2_table(2173) := 'canini|Toselli|Tosi|Toso|Tosto|Totino|Tozzi|Tozzo|Traetta|Trapanese|Trapani|Travaglia|Travaglio|Trav';
wwv_flow_imp.g_varchar2_table(2174) := 'ersa|Travia|Trebbi|Treccani|Tremonti|Trentin|Trentini|Tresoldi|Treves|Trevisan|Trevisani|Trezzini|Tr';
wwv_flow_imp.g_varchar2_table(2175) := 'illini|Trincavelli|Trobbiani|Troisi|Trombetta|Tron|Tropea|Trotta|Trupiano|Trussardi|Turati|Turchetta';
wwv_flow_imp.g_varchar2_table(2176) := '|Turchi|Turci|Turrini|Tutino|Tuzzolino|Ubaldi|Udinese|Udinesi|Ughi|Ungaretti|Valentino|Valguarnera|V';
wwv_flow_imp.g_varchar2_table(2177) := 'alier|Valmarana|Vanvitelli|Varano|Vasari|Vattimo|Vecellio|Vecoli|Veltroni|Vendetti|Venditti|Venezian';
wwv_flow_imp.g_varchar2_table(2178) := 'o|Venier|Vento|Venturi|Vercelloni|Verdi|Verdone|Verga|Vergassola|Vergerio|Verri|Versace|Vespa|Vespuc';
wwv_flow_imp.g_varchar2_table(2179) := 'ci|Vezzali|Vianello|Vidoni|Vigliotti|Vigorelli|Villadicani|Villarosa|Viola|Virgilio|Visconti|Visinti';
wwv_flow_imp.g_varchar2_table(2180) := 'ni|Vismara|Vittadello|Vitturi|Vivaldi|Viviani|Volta|Volterra|Zabarella|Zaccagnini|Zaccardo|Zacchia|Z';
wwv_flow_imp.g_varchar2_table(2181) := 'acco|Zaguri|Zamengo|Zamorani|Zampa|Zanazzo|Zanichelli|Zanzi|Zarlino|Zecchini|Zeffirelli|Zetticci|Zia';
wwv_flow_imp.g_varchar2_table(2182) := 'ni|Zichichi|Zito|Zola|Zoppetti|Zoppetto|Aalts|Aarden|Aarts|Adelaar|Adriaansen|Adriaensdr|Adriaense|A';
wwv_flow_imp.g_varchar2_table(2183) := 'dryaens|Aeije|Aertsz|Alpaidis|Amalrada|Ansems|Appelman|Arens|Arent|Ariens|Arnold|Arts|Aschman|Backer';
wwv_flow_imp.g_varchar2_table(2184) := '|Bakker|Barents|Bartels|Bastiaanse|Bastiaense|Bave|Becht|Beekman|Beernink|Beijring|Bekbergen|Bellema';
wwv_flow_imp.g_varchar2_table(2185) := 'ns|Belpere|Beourgeois|Berends|Berendse|Bernaards|Bertho|Bezemer|Bierstraten|Bijlsma|Billung|Blaak|Bl';
wwv_flow_imp.g_varchar2_table(2186) := 'ees|Bleijenberg|Blewanus|Bloemendaal|Blokland|Blom|Blonk|Boddaugh|Boer|Boers|Boeser|Boetet|Bolkestei';
wwv_flow_imp.g_varchar2_table(2187) := 'jn|Booden|Boogaerts|Borman|Bos|Bosch|Bosman|Boudewijns|Bouhuizen|Bouthoorn|Bouwhuisen|Brandon|Brands';
wwv_flow_imp.g_varchar2_table(2188) := unistr('|Brandt|Bresse|Bres\00E9|Breugelensis|Briere|Brievingh|Brisee|Brizee|Broeckx|Broeders|Broek|Broekhoven|B');
wwv_flow_imp.g_varchar2_table(2189) := unistr('roeshart|Bronder|Brouwer|Bruggeman|Brugman|Brumleve|Bruynzeels|Bud|Buijs|Butselaar|B\00F6kenkamp|Cadefau');
wwv_flow_imp.g_varchar2_table(2190) := '|Cammel|Cant|Carnotte|Charon|Chevresson|Chotzen|Chrodtrud|Claassen|Claesdr|Claesner|Coenen|Coolen|Co';
wwv_flow_imp.g_varchar2_table(2191) := 'ret|Cornelisse|Cornelissen|Cornelisz|Corstiaens|Cosman|Courtier|Dachgelder|Dachgeldt|Dachgelt|Dekker';
wwv_flow_imp.g_varchar2_table(2192) := '|Demmendaal|Dennenberg|Diesbergen|Dijkman|Dijkstra|Dircken|Dirksen|Dirven|Doesburg|Doorhof|Doornhem|';
wwv_flow_imp.g_varchar2_table(2193) := 'Dorsman|Doyle|Draaisma|Dries|Driessen|Drysdale|Duivenvoorden|Eckhardt|Eelman|Eerden|Eijkelboom|Elber';
wwv_flow_imp.g_varchar2_table(2194) := 'ts|Elbertse|Ellis|Elsemulder|Elsenaar|Emmen|Engels|Erhout|Estey|Everde|Evers|Everts|Fechant|Feenstra';
wwv_flow_imp.g_varchar2_table(2195) := unistr('|Feltzer|Ferran|Fiere|Flink|Fortuyn|Frankhuizen|Fran\00E7oise|Fredriks|Fremie|Frerichs|Freshour|Friehus|');
wwv_flow_imp.g_varchar2_table(2196) := 'Furda|Galenzone|Galijn|Garret|Geerling|Geerts|Geertsen|Geldens|Gellemeyer|Gemen|Geneart|Genefaas|Ger';
wwv_flow_imp.g_varchar2_table(2197) := 'rits|Gerritse|Gerritsen|Gervais|Ghoerle|Giselmeyer|Glasses|Gnodde|Goderts|Goedhart|Goudriaan|Govarts';
wwv_flow_imp.g_varchar2_table(2198) := '|Greij|Groen|Groenendaal|Groenestein|Grondel|Groote|Gruijl|Guit|Haack|Haengreve|Hagendoorn|Hak|Hakke';
wwv_flow_imp.g_varchar2_table(2199) := 'r|Haneberg|Hanegraaff|Haring|Haselaar|Hazenveld|Heere|Heerkens|Heerschop|Hehl|Heijman|Heijmans|Heijm';
wwv_flow_imp.g_varchar2_table(2200) := 'en|Heinrichs|Hekker|Hellevoort|Helmerhorst|Hendricks|Hendrikse|Hermans|Hexspoor|Heymans|Heyne|Hoedem';
wwv_flow_imp.g_varchar2_table(2201) := 'akers|Hoeks|Hoekstra|Hoelen|Hoes|Hofman|Hollander|Holthuis|Hondeveld|Honing|Hoogers|Hoppenbrouwer|Ho';
wwv_flow_imp.g_varchar2_table(2202) := 'rrocks|Houdijk|Huberts|Huel|Huijben|Huijbrechts|Huijs|Huijzing|Huisman|Huls|Hulshouts|Hulskes|Hulst|';
wwv_flow_imp.g_varchar2_table(2203) := unistr('Huurdeman|H\00F6ning|Jaceps|Jacobi|Jacobs|Jans|Jansdr|Janse|Jansen|Jansse|Janssen|Janssens|Jdotte|Jeggij');
wwv_flow_imp.g_varchar2_table(2204) := '|Jekel|Jerusalem|Jochems|Jones|Jonker|Jonkman|Joosten|Jorlink|Jorrisen|Jurrijens|Kallen|Kalman|Kamp|';
wwv_flow_imp.g_varchar2_table(2205) := 'Kamper|Karels|Kas|Kathagen|Keijser|Keijzer|Keltenie|Kerkhof|Ketel|Ketting|Kirpenstein|Kisman|Kleibri';
wwv_flow_imp.g_varchar2_table(2206) := 'nk|Kleijse|Klerks|Kleybrink|Kloppert|Knoers|Knuf|Koeman|Kof|Kok|Kolen|Kolster|Koning|Konings|Koret|K';
wwv_flow_imp.g_varchar2_table(2207) := 'orsman|Korstman|Kort|Kortman|Kosten|Koster|Krabbe|Kremer|Kriens|Kronenberg|Kruns|Kuijpers|Kuilenburg';
wwv_flow_imp.g_varchar2_table(2208) := '|Kuiper|Kuipers|Kuit|Kunen|Kwaadland|Labado|Laffray|Lafleur|Lage|Lagerweij|Lambers|Lambregt|Lamore|L';
wwv_flow_imp.g_varchar2_table(2209) := 'amotte|Langevoort|Lankle|Lansink|Lathrope|Latier|Leene|Leguit|Lelijveld|Lemmens|Lensen|Lether|Levesq';
wwv_flow_imp.g_varchar2_table(2210) := 'ue|Lieshout|Ligtvoet|Lijn|Lind|Linschoten|Lips|Loep|Lommert|Lonen|Loreal|Lorreijn|Louws|Luboch|Luste';
wwv_flow_imp.g_varchar2_table(2211) := 'r|Lutterveld|Maas|Maaswinkel|Mahieu|Mallien|Mangel|Manne|Mansveld|Mansvelt|Marceron|Martens|Massa|Ma';
wwv_flow_imp.g_varchar2_table(2212) := 'ter|Mathol|Mathurin|Matthews|Meeres|Meeusen|Meijer|Meis|Melet|Mens|Mercks|Merckx|Merkx|Michiels|Mich';
wwv_flow_imp.g_varchar2_table(2213) := 'ielsen|Middelkoop|Mijsberg|Miltenburg|Miner|Moenen|Moensendijk|Moet|Mol|Molegraaf|Molen|Molenaar|Mom';
wwv_flow_imp.g_varchar2_table(2214) := 'berg|Mosley|Mudden|Muijs|Mulder|Mulders|Nedermeijer|Nek|Neuteboom|Neuzerling|Niermann|Nieuwstraten|N';
wwv_flow_imp.g_varchar2_table(2215) := 'ihoe|Nijman|Nollee|Noordijk|Oda|Oemencs|Oennen|Olthof|Olykan|Ooms|Oosterhek|Oosterhout|Oostveen|Opma';
wwv_flow_imp.g_varchar2_table(2216) := 'ns|Osterhoudt|Otte|Ouwel|Ouwerkerk|Overdijk|Overeem|Oversteeg|Paillet|Palman|Pasman|Passchiers|Pasto';
wwv_flow_imp.g_varchar2_table(2217) := 'ors|Pauwels|Peeters|Perck|Perkins|Peronne|Perrono|Persijn|Peters|Peterse|Phillipsen|Pierson|Pieters|';
wwv_flow_imp.g_varchar2_table(2218) := 'Pison|Poncelet|Ponci|Post|Postma|Potters|Pratt|Prins|Prinsen|Puig|Rackham|Rademaker|Ramaker|Recer|Re';
wwv_flow_imp.g_varchar2_table(2219) := 'cers|Rehorst|Reijers|Reimes|Rek|Remmers|Ridder|Riem|Rietveld|Rijcken|Rijks|Rijn|Rijntjes|Rippey|Rism';
wwv_flow_imp.g_varchar2_table(2220) := 'a|Roessink|Romijn|Roodesteijn|Room|Roose|Roosenboom|Rotteveel|Roukes|Rousselet|Rouwenhorst|Rouwhorst';
wwv_flow_imp.g_varchar2_table(2221) := '|Rubben|Ruijs|Rutten|Salet|Sam|Sanders|Sarneel|Sas|Saxo|Scardino|Schagen|Schakelaar|Scharroo|Schatte';
wwv_flow_imp.g_varchar2_table(2222) := 'leijn|Scheer|Scheffers|Schellekens|Schelvis|Schenkel|Scherms|Schiffer|Schilt|Schipper|Schokman|Schol';
wwv_flow_imp.g_varchar2_table(2223) := 'ten|Schotte|Schouten|Schrant|Schrik|Schroeff|Schulten|Schuurmans|Schuylenborch|Schwartsbach|Scuylenb';
wwv_flow_imp.g_varchar2_table(2224) := 'orchs|Segerszoen|Serra|Sestig|Shupe|Simonis|Simons|Sire|Sitters|Slaetsdochter|Slagmolen|Slingerland|';
wwv_flow_imp.g_varchar2_table(2225) := 'Smeets|Smit|Smith|Smits|Soos|Spaan|Spanhaak|Speijer|Spier|Spies|Spiker|Spreeuw|Sprong|Spruit|Spruyt|';
wwv_flow_imp.g_varchar2_table(2226) := 'Stamrood|Stange|Steenbakkers|Steenbeek|Steinmeiern|Sterkman|Stettyn|Stichter|Stinis|Stoffel|Stoffels';
wwv_flow_imp.g_varchar2_table(2227) := unistr('z|Stook'';'||wwv_flow.LF||
'    l_first_name_catalog(2) := ''Abel|Abelardo|Abigail|Abraham|Abril|Adalberto|Ad\00E1n|Adela|A');
wwv_flow_imp.g_varchar2_table(2228) := unistr('driana|Aida|Alejandra|Agust\00EDn|Alberto|Aldonza|Alicia|Alonso|Aldo|Alejandro|Alfonso|Alfredo|Alma|Alva');
wwv_flow_imp.g_varchar2_table(2229) := unistr('ro|Amalia|Amanda|Amador|Amelia|Ana|Anabel|Anel|Andrea|Andr\00E9s|\00C1ngel|\00C1ngela|Ang\00E9lica|Antonia|Antonio|A');
wwv_flow_imp.g_varchar2_table(2230) := unistr('raceli|Arcelia|Ariadna|Armando|Arturo|Asunci\00F3n|Augusto|Aurora|Aurelio|Barbara|Beatriz|Berta|Benito|B');
wwv_flow_imp.g_varchar2_table(2231) := unistr('enjam\00EDn|Bernardo|Bernab\00E9|Bianca|Blanca|Bruno|Camila|Camilo|Caridad|Carla|Carlos|Carlota|Carmen|Carol');
wwv_flow_imp.g_varchar2_table(2232) := unistr('ina|Catalina|C\00E9sar|Cecilia|Celia|Citlali|Clara|Claudia|Claudio|Clemente|Concepci\00F3n|Conchita|Cornelio');
wwv_flow_imp.g_varchar2_table(2233) := unistr('|Cristian|Cristal|Cristina|Cristobal|Cynthia|Dalia|Daniel|Daniela|Dar\00EDo|David|D\00E9bora|Delia|Diana|Die');
wwv_flow_imp.g_varchar2_table(2234) := 'go|Dolores|Dulce|Eduardo|Elena|Elias|Elisa|Eloisa|Elsa|Elvia|Elvira|Eloy|Emilia|Emiliano|Emilio|Enri';
wwv_flow_imp.g_varchar2_table(2235) := unistr('que|Eric|Ernesto|Esmeralda|Esteban|Estefan\00EDa|Estela|Esparta|Espartaco|Esperanza|Esther|Eugenia|Eugen');
wwv_flow_imp.g_varchar2_table(2236) := 'io|Eva|Evelio|Fabiola|Federico|Felipe|Fernando|Felix|Fidel|Flavio|Florencia|Francisco|Francisca|Frid';
wwv_flow_imp.g_varchar2_table(2237) := unistr('a|Gabino|Gabriela|Gabriel|Genaro|Georgina|Gerardo|Ger\00F3nimo|Germ\00E1n|Gilberto|Guillermina|Gloria|Gonzal');
wwv_flow_imp.g_varchar2_table(2238) := unistr('o|Graciela|Gregorio|Guillermo|Guadalupe|Gustavo|H\00E9ctor|Helena|Hermelinda|Hern\00E1n|Hilda|Homero|Horacio');
wwv_flow_imp.g_varchar2_table(2239) := unistr('|Hugo|Humberto|Ignacio|Ilse|Indira|In\00E9s|Irene|Irma|Itzel|Isaac|Isabel|Isabela|Israel|Iv\00E1n|Ivonne|Jac');
wwv_flow_imp.g_varchar2_table(2240) := unistr('into|Jacobo|Jaime|Javier|Jaqueline|Jer\00F3nimo|Jes\00FAs|Joaqu\00EDn|Jon\00E1s|Jorge|Jos|Jos\00E9|Josefina|Juan|Juana|J');
wwv_flow_imp.g_varchar2_table(2241) := 'udith|Julia|Julio|Laura|Leonardo|Leonel|Leonor|Karla|Karina|Leticia|Lorenzo|Lucas|Lilia|Liliana|Lind';
wwv_flow_imp.g_varchar2_table(2242) := unistr('a|Lorena|Lourdes|Luc\00EDa|Luisa|Luz|Luis|Magdalena|Manuel|Marcela|Marcos|Margarita|Mar\00EDa|Marisela|Maris');
wwv_flow_imp.g_varchar2_table(2243) := unistr('ol|Martha|Mayte|Mariano|Mariana|Mario|Mart\00EDn|Mateo|Mauro|Mauricio|Maximiliano|Mercedes|Micaela|Miner');
wwv_flow_imp.g_varchar2_table(2244) := unistr('va|Mitzy|Miguel|Miriam|Modesto|M\00F3nica|Nadia|Natalia|Natividad|Nancy|Nayeli|Nelly|Noelia|Noem\00ED|Norma|');
wwv_flow_imp.g_varchar2_table(2245) := unistr('Nicol\00E1s|Octavio|Ofelia|Olivia|\00D3liver|Olga|\00D3scar|Oswaldo|Omar|Pablo|Paola|Patricia|Pamela|Patricio|Pa');
wwv_flow_imp.g_varchar2_table(2246) := unistr('scual|Paulina|Pedro|Perla|Pilar|Porfirio|Rafa\00E9l|Ramiro|Ram\00F3n|Ra\00FAl|Raquel|Rebeca|Reina|Renato|Ren\00E9|Re');
wwv_flow_imp.g_varchar2_table(2247) := unistr('ynaldo|Ricardo|Roberto|Rodolfo|Roc\00EDo|Rodrigo|Rolando|Rosa|Rosalia|Rosario|Rub\00E9n|Rufino|Ruby|Salvador');
wwv_flow_imp.g_varchar2_table(2248) := unistr('|Salma|Samuel|Sandra|Santiago|Sara|Sessa|Sergio|Seraf\00EDn|Silvano|Silvia|Sof\00EDa|Socorro|Soledad|Sonia|S');
wwv_flow_imp.g_varchar2_table(2249) := unistr('usana|Tania|Teresa|Teodoro|Timoteo|Tom\00E1s|Trinidad|Ver\00F3nica|Vicente|Violeta|Uriel|\00DArsula|Vanesa|V\00EDcto');
wwv_flow_imp.g_varchar2_table(2250) := unistr('r|Victoria|Virginia|Wilfrido|Wendolin|Yeni|Yolanda|Yuridia|Zacar\00EDas|Zeferino|Zo\00E9|Aar\00F3n|Abilio|Adelar');
wwv_flow_imp.g_varchar2_table(2251) := unistr('do|Adolfo|Adri\00E1n|Agapito|Aitor|Albano|Albert|Albino|Alcides|Ale|Alejo|Alex|Amado|Amancio|Amando|Amar');
wwv_flow_imp.g_varchar2_table(2252) := unistr('o|Ambrosio|Amor|Am\00E9rico|Am\00EDlcar|Anacleto|Anastasio|Angelino|Anselmo|An\00EDbal|Apolinar|Ariel|Aristides|');
wwv_flow_imp.g_varchar2_table(2253) := unistr('Arsenio|Artemio|Asdrubal|Atilio|Aureliano|Baldomero|Balduino|Baltasar|Bartolom\00E9|Basilio|Baudelio|Bau');
wwv_flow_imp.g_varchar2_table(2254) := 'tista|Benigno|Bernardino|Berto|Blas|Bonifacio|Borja|Buenaventura|Calisto|Calixto|Candelario|Carlito|';
wwv_flow_imp.g_varchar2_table(2255) := unistr('Carmelo|Casemiro|Cayetano|Cebri\00E1n|Cecilio|Ceferino|Celestino|Celso|Cesar|Che|Chema|Chucho|Chus|Chuy|');
wwv_flow_imp.g_varchar2_table(2256) := unistr('Cipriano|Ciriaco|Cirino|Ciro|Cir\00EDaco|Cleto|Cl\00EDmaco|Conrado|Cosme|Crist\00F3bal|Cruz|Curro|Custodio|C\00E1ndi');
wwv_flow_imp.g_varchar2_table(2257) := unistr('do|Dami\00E1n|Dan|Dani|Danilo|Demetrio|Desiderio|Dimas|Dionisio|Domingo|Donato|Duilio|Edelmiro|Edgardo|E');
wwv_flow_imp.g_varchar2_table(2258) := unistr('dmundo|Edu|Efra\00EDn|Eladio|Eleuterio|Eligio|Eliseo|Elpidio|El\00EDas|Emigdio|Epifanio|Erasmo|Espiridi\00F3n|Eu');
wwv_flow_imp.g_varchar2_table(2259) := unistr('sebio|Eustaquio|Eutimio|Eutropio|Evaristo|Ezequiel|Fabio|Fabi\00E1n|Fabricio|Faustino|Fausto|Feliciano|F');
wwv_flow_imp.g_varchar2_table(2260) := unistr('erm\00EDn|Fito|Florencio|Florentino|Fortunato|Fulgencio|F\00E9lix|Galo|Gaspar|Gast\00F3n|Geraldo|Gervasio|Gil|Gl');
wwv_flow_imp.g_varchar2_table(2261) := 'auco|Godofredo|Goyo|Graciano|Guiomar|Haroldo|Hector|Heliodoro|Heraclio|Herberto|Heriberto|Hermenegil';
wwv_flow_imp.g_varchar2_table(2262) := unistr('do|Herminio|Hernando|Hilario|Hip\00F3lito|Ib\00E1n|Iker|Ildefonso|Inocencio|Isa\00EDas|Isidoro|Isidro|Ismael|Jaf');
wwv_flow_imp.g_varchar2_table(2263) := unistr('et|Javi|Jenaro|Jerem\00EDas|Joan|Joel|Jonatan|Jordi|Jord\00E1n|Jose|Josep|Josu\00E9|Juanito|Juli\00E1n|Kike|Lalo|Lea');
wwv_flow_imp.g_varchar2_table(2264) := unistr('ndro|Leocadio|Leoncio|Leopoldo|Le\00F3n|Lino|Lisandro|Lope|Loreto|Lucho|Luciano|Lucio|Lupe|Lu\00EDs|L\00E1zaro|M');
wwv_flow_imp.g_varchar2_table(2265) := unistr('acario|Manolo|Manu|Marc|Marcelino|Marcelo|Marcial|Marciano|Marcio|Marco|Marino|Martin|Mat\00EDas|Maxi|Ma');
wwv_flow_imp.g_varchar2_table(2266) := unistr('ximiano|Maximino|Melchor|Mohamed|Mois\00E9s|Moreno|M\00E1ximo|Nacho|Nacio|Nando|Narciso|Natalio|Natanael|Naz');
wwv_flow_imp.g_varchar2_table(2267) := unistr('aret|Nazario|Nicanor|Nico|Nicodemo|Nilo|Norberto|No\00E9|N\00E9stor|Olegario|Onofre|Osvaldo|Ovidio|Paco|Panc');
wwv_flow_imp.g_varchar2_table(2268) := unistr('ho|Pastor|Paulino|Pelayo|Pepe|Pepito|Plinio|Pl\00E1cido|Poncio|Primitivo|Prudencio|P\00E1nfilo|P\00EDo|Quique|Qu');
wwv_flow_imp.g_varchar2_table(2269) := unistr('irino|Rafa|Rafael|Raimundo|Reinaldo|Remigio|Reyes|Rico|Rogelio|Rold\00E1n|Rom\00E1n|Roque|Rosendo|Ruben|Rupe');
wwv_flow_imp.g_varchar2_table(2270) := unistr('rto|Ruy|R\00E9gulo|R\00F3mulo|Sabas|Salom\00F3n|Samu|Sancho|Sandalio|Santos|Saturnino|Sebastian|Sebasti\00E1n|Segism');
wwv_flow_imp.g_varchar2_table(2271) := unistr('undo|Seve|Severiano|Severino|Severo|Sigfrido|Silvestre|Silvio|Sim\00F3n|Sosimo|Tadeo|Telmo|Teo|Teobaldo|');
wwv_flow_imp.g_varchar2_table(2272) := unistr('Teodosio|Te\00F3filo|Tiburcio|Tito|Toni|Toribio|To\00F1o|Trist\00E1n|Ulises|Urbano|Valent\00EDn|Valerio|Valero|Vasco');
wwv_flow_imp.g_varchar2_table(2273) := unistr('|Vencesl\00E1s|Victor|Victoriano|Victorino|Vidal|Vinicio|Virgilio|Vito|Wilfredo|W\00E1lter|Xavier|Yago|\00C1lvar');
wwv_flow_imp.g_varchar2_table(2274) := unistr('o|\00C9dgar|\00CD\00F1igo|Abiga\00EDl|Adelaida|Adelia|Adelina|Adora|Adoraci\00F3n|Agustina|Ainara|Ainoa|Aitana|Alba|Albi');
wwv_flow_imp.g_varchar2_table(2275) := unistr('na|Alexandra|Almudena|Alondra|Amada|Amarilis|Amaya|Amparo|Am\00E9rica|Anastasia|Angelina|Angelita|Ani|An');
wwv_flow_imp.g_varchar2_table(2276) := unistr('ita|Anna|Anselma|Anunciaci\00F3n|Apolonia|Armida|Aroa|Ar\00E1nzazu|Ascensi\00F3n|Aura|Aurelia|Azahar|Azahara|Aze');
wwv_flow_imp.g_varchar2_table(2277) := unistr('neth|Azucena|Bego\00F1a|Belen|Bel\00E9n|Benigna|Benita|Bernarda|Bernardita|Bibiana|Bienvenida|Brunilda|Br\00EDgi');
wwv_flow_imp.g_varchar2_table(2278) := unistr('da|B\00E1rbara|Calista|Calixta|Candela|Candelaria|Candelas|Carina|Carmela|Carmelita|Carmina|Casandra|Cay');
wwv_flow_imp.g_varchar2_table(2279) := 'etana|Celestina|Charo|Chelo|Chita|Cintia|Clarisa|Clementina|Cloe|Clotilde|Concha|Constanza|Consuela|';
wwv_flow_imp.g_varchar2_table(2280) := unistr('Consuelo|Coral|Corona|Crescencia|Custodia|C\00E1ndida|Dafne|Dalila|Delfina|Dionisia|Dominga|Domitila|Dor');
wwv_flow_imp.g_varchar2_table(2281) := unistr('a|Dorita|Dorotea|Edelmira|Elba|Eli|Eliana|Eligia|Elisabet|Elodia|Elo\00EDsa|Ema|Emelina|Emiliana|Emma|Em');
wwv_flow_imp.g_varchar2_table(2282) := unistr('peratriz|Encarna|Encarnacion|Encarnaci\00F3n|Encarnita|Ester|Estrella|Etelvina|Eufemia|Eulalia|Eusebia|E');
wwv_flow_imp.g_varchar2_table(2283) := 'vangelina|Evelia|Evita|Fabiana|Fanny|Febe|Felicia|Feliciana|Felicidad|Felipa|Felisa|Fernanda|Fidela|';
wwv_flow_imp.g_varchar2_table(2284) := unistr('Filomena|Flavia|Flor|Flora|Florentina|Florina|Florinda|Fortunata|F\00E1tima|Gala|Gema|Genoveva|Gertrudis');
wwv_flow_imp.g_varchar2_table(2285) := unistr('|Gisela|Gracia|Graciana|Griselda|Hayd\00E9e|Herminia|Hortensia|Ignacia|Ileana|Imelda|Inmaculada|Iris|Isa');
wwv_flow_imp.g_varchar2_table(2286) := '|Isaura|Isidora|Itziar|Jacinta|Javiera|Jennifer|Jenny|Jessica|Jesusa|Jimena|Joaquina|Jordana|Josefa|';
wwv_flow_imp.g_varchar2_table(2287) := 'Jovita|Juanita|Juliana|Julie|Julieta|Lara|Leandra|Leire|Leocadia|Leyre|Lidia|Ligia|Lina|Loida|Lola|L';
wwv_flow_imp.g_varchar2_table(2288) := 'orenza|Luciana|Lucila|Luisina|Luna|Lupita|Macarena|Macaria|Maite|Malena|Mamen|Manola|Manuela|Manueli';
wwv_flow_imp.g_varchar2_table(2289) := 'ta|Mar|Marcia|Marianela|Maribel|Maricela|Maricruz|Marina|Marisa|Maristela|Marita|Marta|Martina|Marti';
wwv_flow_imp.g_varchar2_table(2290) := unistr('rio|Matilde|Maura|Melania|Melisa|Merche|Miguela|Milagros|Mireia|Mirta|Modesta|Montserrat|Morena|M\00E1xi');
wwv_flow_imp.g_varchar2_table(2291) := unistr('ma|Narcisa|Nayara|Nerea|Nereida|Nicolasa|Nidia|Nieves|Nilda|Noa|Nuria|Nydia|N\00E9lida|Obdulia|Octavia|O');
wwv_flow_imp.g_varchar2_table(2292) := unistr('dalis|Odalys|Olalla|Olimpia|Oriana|Otilia|Paca|Pac\00EDfica|Palmira|Paloma|Pascuala|Pastora|Paula|Paz|Pe');
wwv_flow_imp.g_varchar2_table(2293) := unistr('pita|Perlita|Petrona|Piedad|Pili|Primitiva|Priscila|Prudencia|Purificaci\00F3n|P\00EDa|Rafaela|Ramona|Regina');
wwv_flow_imp.g_varchar2_table(2294) := unistr('|Remedios|Renata|Reyna|Ricarda|Rita|Roberta|Rosalina|Rosalinda|Rosalva|Rosal\00EDa|Rosaura|Rosenda|Roxan');
wwv_flow_imp.g_varchar2_table(2295) := unistr('a|Rufina|Ruperta|Ruth|Sabina|Salom\00E9|Salud|Samanta|Sarita|Saturnina|Selena|Serafina|Sol|Soraya|Susani');
wwv_flow_imp.g_varchar2_table(2296) := unistr('ta|Tamara|Tatiana|Tecla|Teodora|Tere|Teresita|Te\00F3fila|Tomasa|Trini|Valentina|Valeria|Vera|Vicenta|Vi');
wwv_flow_imp.g_varchar2_table(2297) := unistr('lma|Visitaci\00F3n|Viviana|Ximena|Xiomara|Yaiza|Y\00E9sica|Y\00E9ssica|Zaida|Zaira|Zoraida|\00C1frica|\00C1gata|\00C1gueda|\00C1');
wwv_flow_imp.g_varchar2_table(2298) := unistr('mbar|\00C1ngeles|\00C1urea|\00CDngrid|Alexandre|Andr\00E9|Anthony|Antony|Ant\00F4nio|Apollo|Arthur|Asafe|Benicio|Benjami');
wwv_flow_imp.g_varchar2_table(2299) := unistr('m|Benjamin|Bento|Ben\00EDcio|Brayan|Breno|Bryan|Caio|Caleb|Calebe|Cau\00E3|Cau\00EA|Dante|Davi|Diogo|Dom|Emanuel');
wwv_flow_imp.g_varchar2_table(2300) := unistr('|Enrico|Enzo|Erick|Gael|Guilherme|Heitor|Henrique|Henry|Ian|Igor|Isaque|Joaquim|Jo\00E3o|Kaique|Kevin|Le');
wwv_flow_imp.g_varchar2_table(2301) := unistr('vi|Liam|Luan|Lucca|Luigi|L\00E9o|Mateus|Matheus|Mathias|Matteo|Murilo|Nathan|Nicolas|Noah|Oliver|Otto|Ot');
wwv_flow_imp.g_varchar2_table(2302) := unistr('\00E1vio|Paulo|Pietro|Rael|Raul|Ravi|Ravy|Renan|Rhavi|Ryan|Thales|Theo|Theodoro|Thiago|Thomas|Th\00E9o|Valen');
wwv_flow_imp.g_varchar2_table(2303) := unistr('tim|Vinicius|Vin\00EDcius|Vitor|Yan|Yuri|Agatha|Alana|Alexia|Alice|Allana|Al\00EDcia|Antonella|Ayla|Aylla|Be');
wwv_flow_imp.g_varchar2_table(2304) := unistr('lla|Brenda|Bruna|Caroline|Catarina|Cec\00EDlia|Clarice|Eduarda|Eloah|Elo\00E1|Emanuella|Emanuelly|Emilly|Eve');
wwv_flow_imp.g_varchar2_table(2305) := unistr('lyn|Gabrielly|Giovanna|Hadassa|Hellena|Heloisa|Helo\00EDsa|Isabella|Isabelly|Isadora|Isis|Jade|Joana|J\00FAl');
wwv_flow_imp.g_varchar2_table(2306) := unistr('ia|Kamilly|Larissa|Lav\00EDnia|La\00EDs|Let\00EDcia|Liz|Luana|Luara|Luiza|Lunna|Lu\00EDsa|L\00EDvia|Mait\00EA|Manuella|Maria');
wwv_flow_imp.g_varchar2_table(2307) := unistr('|Mariah|Mariane|Maya|Maysa|Melina|Melissa|Milena|Mirella|Nat\00E1lia|Nicole|Nina|Ol\00EDvia|Pietra|Sabrina|S');
wwv_flow_imp.g_varchar2_table(2308) := unistr('arah|Sofia|Sophia|Sophie|Stella|Stephany|Vit\00F3ria|Yasmin|Zoe|\00C1gatha|\00CDsis|Afonso|\00C2ngelo|Ant\00F3nio|Artur|');
wwv_flow_imp.g_varchar2_table(2309) := unistr('Brian|Cl\00E1udio|Cristiano|Denis|Dinis|Duarte|Edgar|Filipe|Frederico|F\00E1bio|Gon\00E7alo|Ivan|Ivo|K\00E9vim|Loure');
wwv_flow_imp.g_varchar2_table(2310) := unistr('n\00E7o|Luca|Martim|Matias|Micael|M\00E1rcio|M\00E1rio|Nelson|Nuno|Rui|R\00FAben|Sandro|Sebasti\00E3o|Sim\00E3o|S\00E9rgio|Tiago');
wwv_flow_imp.g_varchar2_table(2311) := unistr('|Tom\00E9|V\00EDtor|William|Wilson|Am\00E9lia|Andreia|\00C2ngela|Ariana|Benedita|Caetana|Carminho|Constan\00E7a|Em\00EDlia|E');
wwv_flow_imp.g_varchar2_table(2312) := unistr('rica|\00C9rica|Erika|Filipa|Iara|In\00EAs|Irina|\00CDris|J\00E9ssica|Kelly|Kyara|Lia|L\00FAcia|Madalena|Mafalda|Mara|Mar');
wwv_flow_imp.g_varchar2_table(2313) := unistr('garida|Mia|M\00E9lanie|Naiara|Nair|N\00E1dia|N\00FAria|Patr\00EDcia|Petra|Soraia|Vict\00F3ria|Yara|Elizabeth|Oscar|Kathe');
wwv_flow_imp.g_varchar2_table(2314) := unistr('rine|Gladys|Basti\00E1n|Anah\00ED|Karen|Jacqueline|Jonathan|Alexis|Christian|Franco|Jean|Ingrid|Segundo|Romi');
wwv_flow_imp.g_varchar2_table(2315) := 'na|Edith|Alexander|Richard|Cristopher|Orlando|Maritza|John|Michael|Vanessa|Alan|Angelo|Mariela|Myria';
wwv_flow_imp.g_varchar2_table(2316) := unistr('m|Yasna|Emily|Monserrat|Jeannette|Jocelyn|Christopher|Facundo|Freddy|Ana\00EDs|Walter|G\00E9nesis|Fresia|Bor');
wwv_flow_imp.g_varchar2_table(2317) := 'is|Solange|Robinson|Johanna|Jesus|Denisse|Dylan|Nataly|Ronald|Nora|Lilian|Erwin|Valeska|Hans|Sylvia|';
wwv_flow_imp.g_varchar2_table(2318) := unistr('Millaray|Michelle|Guido|Axel|Cristofer|A\00EDda|Doris|Giovanni|Catherine|Johan|Josue|Jhon|Matilda|Rigobe');
wwv_flow_imp.g_varchar2_table(2319) := 'rto|Yerko|Carol|Robert|Exequiel|Waldo|Lukas|Brandon|Fredy|Williams|Silvana|Paul|Marjorie|Magaly|Jair';
wwv_flow_imp.g_varchar2_table(2320) := 'o|Marlene|Mireya|Krishna|Nicol|Leslie|Jimmy|Yesenia|Dagoberto|Max|Wladimir|Milton|Braulio|Michel|Dom';
wwv_flow_imp.g_varchar2_table(2321) := unistr('inique|Edwin|Colomba|Edison|Pascal|Jeremy|Stephanie|Yessica|Erik|Johana|Lissette|\00CDtalo|Joseph|Mabel|');
wwv_flow_imp.g_varchar2_table(2322) := 'Byron|Karin|Santino|Geraldine|Darwin|Priscilla|Misael|Carola|Baltazar|Mayra|Danitza|Bayron|Rossana|S';
wwv_flow_imp.g_varchar2_table(2323) := unistr('amantha|Paolo|Arnoldo|Jazm\00EDn|Emmanuel|Scarlett|Damaris|Dilan|Lucy|Nibaldo|Vania|Cristhian|Zoila|John');
wwv_flow_imp.g_varchar2_table(2324) := unistr('ny|Yessenia|Ray\00E9n|Tiare|Danae|Elvis|Dayana|James|Katalina|Jacob|Vladimir|Thiare|Francesca|Herman|Arn');
wwv_flow_imp.g_varchar2_table(2325) := unistr('aldo|Sa\00FAl|Mary|Edward|Joselyn|Franklin|Marie|Jeanette|Roger|Ernestina|Juvenal|Dina|Joshua|Frank|L\00EDa|');
wwv_flow_imp.g_varchar2_table(2326) := unistr('Benedicto|Debora|Gerald|Lautaro|Corina|Gerson|Yaritza|Le\00F3nidas|Patrick|Alison|Celeste|Aylin|Emerson|');
wwv_flow_imp.g_varchar2_table(2327) := 'Danny|Cindy|Nolberto|Susan|Gino|Zunilda|Mirtha|Almendra|Andy|Kimberly|Demian|Piero|Kiara|Yonathan|Ag';
wwv_flow_imp.g_varchar2_table(2328) := 'ustin|Maira|Peter|Zulema|Tomas|Ida|Jhonny|Petronila|Uberlinda|Jason|Ayleen|Allison|Sixto|Franchesca|';
wwv_flow_imp.g_varchar2_table(2329) := 'Eleodoro|Aracely|Gilda|Maicol|Pascale|Washington|Aquiles|Luzmira|Yenny|Margot|Aliro|Natalie|Rosamel|';
wwv_flow_imp.g_varchar2_table(2330) := unistr('M\00EDa|Harold|Yenifer|Justo|Cinthia|Rafaella|Allan|Claudina|Edgard|Melanie|Daisy|Eliecer|Erna|Froil\00E1n|S');
wwv_flow_imp.g_varchar2_table(2331) := 'carlet|Steven|Nathaly|George|Mirna|Charles|Belisario|Valentino|Ada|Pierre|Makarena|Astrid|Junior|Gin';
wwv_flow_imp.g_varchar2_table(2332) := 'a|Celinda|Leontina|Clodomiro|Jenifer|Gary|Marilyn|Yohana|Alamiro|Grace|Edson|Ashley|Renzo|Janet|Nino';
wwv_flow_imp.g_varchar2_table(2333) := unistr('ska|Anahis|Anderson|Amaru|Edinson|Elcira|Delf\00EDn|Pabla|Maricel|Elisabeth|Matheo|Belarmino|Douglas|Nat');
wwv_flow_imp.g_varchar2_table(2334) := 'halie|Isolina|Alexi|Angie|Ethan|Fiorella|Elian|Mirko|Giselle|Yanet|Yoselin|Gumercindo|Andrew|Edita|M';
wwv_flow_imp.g_varchar2_table(2335) := unistr('il\00E1n|Nayareth|Stefano|Helen|Thom\00E1s|Vivian|Lucrecia|Neftal\00ED|Herminda|Wilmer|Heraldo|Scarleth|Monica|E');
wwv_flow_imp.g_varchar2_table(2336) := unistr('leazar|Marion|Ronny|Orfelina|Justin|Digna|Nahuel|Yasm\00EDn|Yordan|Marcelina|Jhonatan|Lisette|Tr\00E1nsito|K');
wwv_flow_imp.g_varchar2_table(2337) := 'atherinne|Amy|Galvarino|Ivette|Yanira|Aladino|Wenceslao|Nestor|Estefany|Francia|Yonatan|Ramon|Rudy|Y';
wwv_flow_imp.g_varchar2_table(2338) := 'eison|Yanina|Maikol|Bairon|Darling|Clorinda|Avelino|Betty|Jerson|Veronica|Andre|Tabita|Jeniffer|Armi';
wwv_flow_imp.g_varchar2_table(2339) := unistr('n|Cristi\00E1n|Dennis|Leyla|Gregory|Jefferson|Alejandrina|Jenniffer|Lionel|Rose|Willy|Albertina|Carlo|Lu');
wwv_flow_imp.g_varchar2_table(2340) := unistr('cinda|Rosalba|Marcel|Denise|Mery|Johann|Eulogio|Enriqueta|Katia|Lian|Evelin|Abd\00F3n|Harry|Alessandro|G');
wwv_flow_imp.g_varchar2_table(2341) := 'ricelda|Simon|Doralisa|Bladimir|Jonas|Cinthya|Cristhofer|Gisselle|Joao|Yesica|Franz|Scarlette|Jeison';
wwv_flow_imp.g_varchar2_table(2342) := '|Milovan|Daniella|Floridor|Tulio|Deyanira|Jair|Marlon|Karol|Samir|Leidy|Percy|Yuliana|Rony|Jerman|Na';
wwv_flow_imp.g_varchar2_table(2343) := 'tacha|Giovanny|Matthew|Marisel|Gian|Rocio|Jordan|Abner|Ariela|Alain|Nayaret|Yohan|Antonieta|Eithan|M';
wwv_flow_imp.g_varchar2_table(2344) := 'elany|Rudecindo|Magali|Mark|Norman|Yamilet|Fabrizio|Elia|Kurt|Lesly|Gianfranco|Deisy'';'||wwv_flow.LF||
'    l_last_na';
wwv_flow_imp.g_varchar2_table(2345) := unistr('me_catalog(2) := ''Abrego|Abreu|Acevedo|Acosta|Acu\00F1a|Adame|Aguayo|Aguilar|Aguilera|Aguirre|Alarc\00F3n|Al');
wwv_flow_imp.g_varchar2_table(2346) := unistr('ba|Alcala|Alc\00E1ntar|Alcaraz|Alejandro|Alem\00E1n|Alfaro|Almanza|Almaraz|Almonte|Alonso|Alonzo|Altamirano|');
wwv_flow_imp.g_varchar2_table(2347) := unistr('Alva|Alvarado|Alvarez|Amador|Amaya|Anaya|Anguiano|Angulo|Aparicio|Apodaca|Aponte|Arag\00F3n|Aranda|Arce|');
wwv_flow_imp.g_varchar2_table(2348) := unistr('Archuleta|Arellano|Arenas|Arevalo|Arguello|Arias|Armas|Armend\00E1riz|Armenta|Arredondo|Arreola|Arriaga|');
wwv_flow_imp.g_varchar2_table(2349) := unistr('Arroyo|Arteaga|\00C1valos|\00C1vila|Avil\00E9s|Ayala|Baca|Badillo|B\00E1ez|Baeza|Bahena|Balderas|Ballesteros|Ba\00F1uelo');
wwv_flow_imp.g_varchar2_table(2350) := unistr('s|Barajas|Barela|Barrag\00E1n|Barraza|Barrera|Barreto|Barrientos|Barrios|Batista|Becerra|Beltr\00E1n|Benavid');
wwv_flow_imp.g_varchar2_table(2351) := unistr('es|Benav\00EDdez|Ben\00EDtez|Berm\00FAdez|Bernal|Berr\00EDos|B\00E9tancourt|Blanco|Bonilla|Borrego|Botello|Bravo|Briones');
wwv_flow_imp.g_varchar2_table(2352) := unistr('|Brise\00F1o|Brito|Bueno|Burgos|Bustamante|Bustos|Caballero|Cab\00E1n|Cabrera|Cadena|Caldera|Calder\00F3n|Calvil');
wwv_flow_imp.g_varchar2_table(2353) := unistr('lo|Camacho|Camarillo|Campos|Canales|Candelaria|Cano|Cant\00FA|Caraballo|Carbajal|Cardenas|Cardona|Carmon');
wwv_flow_imp.g_varchar2_table(2354) := unistr('a|Carranza|Carrasco|Carre\00F3n|Carrera|Carrero|Carrillo|Carri\00F3n|Carvajal|Casanova|Casares|Cas\00E1rez|Casas');
wwv_flow_imp.g_varchar2_table(2355) := unistr('|Casillas|Casta\00F1eda|Castellanos|Castillo|Castro|Cavazos|Cazares|Ceballos|Cedillo|Ceja|Centeno|Cepeda');
wwv_flow_imp.g_varchar2_table(2356) := unistr('|Cervantes|Cerv\00E1ntez|Chac\00F3n|Chapa|Chavarr\00EDa|Ch\00E1vez|Cintr\00F3n|Cisneros|Collado|Collazo|Col\00F3n|Colunga|Co');
wwv_flow_imp.g_varchar2_table(2357) := unistr('ncepci\00F3n|Contreras|Cordero|C\00F3rdova|Cornejo|Corona|Coronado|Corral|Corrales|Correa|Cort\00E9s|Cortez|Cott');
wwv_flow_imp.g_varchar2_table(2358) := unistr('o|Covarrubias|Crespo|Cruz|Cuellar|Curiel|D\00E1vila|Delgadillo|Delgado|D\00EDaz|Dom\00EDnguez|Duarte|Due\00F1as|Dur\00E1');
wwv_flow_imp.g_varchar2_table(2359) := unistr('n|Echeverr\00EDa|Elizondo|Enr\00EDquez|Escalante|Escamilla|Escobar|Escobedo|Esparza|Espinal|Espino|Espinosa|');
wwv_flow_imp.g_varchar2_table(2360) := unistr('Espinoza|Esquibel|Esquivel|Est\00E9vez|Estrada|Fajardo|Far\00EDas|Feliciano|Fern\00E1ndez|Ferrer|Fierro|Figueroa');
wwv_flow_imp.g_varchar2_table(2361) := unistr('|Flores|Fl\00F3rez|Fonseca|Franco|Fr\00EDas|Fuentes|Gait\00E1n|Galarza|Galindo|Gallardo|Gallegos|Galv\00E1n|G\00E1lvez|G');
wwv_flow_imp.g_varchar2_table(2362) := unistr('amboa|Gamez|Gaona|Garay|Garc\00EDa|Garibay|Garica|Garrido|Garza|Gast\00E9lum|Gayt\00E1n|Gil|Gir\00F3n|God\00EDnez|Godoy|');
wwv_flow_imp.g_varchar2_table(2363) := unistr('G\00F3mez|Gonzales|Gonz\00E1lez|Gollum|Gracia|Granado|Granados|Griego|Grijalva|Guajardo|Guardado|Guerra|Guer');
wwv_flow_imp.g_varchar2_table(2364) := unistr('rero|Guevara|Guillen|Gurule|Guti\00E9rrez|Guzm\00E1n|Haro|Henr\00EDquez|Heredia|Hern\00E1dez|Hernandes|Hern\00E1ndez|Her');
wwv_flow_imp.g_varchar2_table(2365) := unistr('rera|Hidalgo|Hinojosa|Holgu\00EDn|Huerta|Hurtado|Ibarra|Iglesias|Irizarry|Jaime|Jaimes|J\00E1quez|Jaramillo|');
wwv_flow_imp.g_varchar2_table(2366) := unistr('Jasso|Jim\00E9nez|Jim\00EDnez|Ju\00E1rez|Jurado|Laboy|Lara|Laureano|Leal|Lebr\00F3n|Ledesma|Leiva|Lemus|Le\00F3n|Lerma|L');
wwv_flow_imp.g_varchar2_table(2367) := unistr('eyva|Lim\00F3n|Linares|Lira|Llamas|Loera|Lomeli|Longoria|L\00F3pez|Lovato|Loya|Lozada|Lozano|Lucero|Lucio|Lu');
wwv_flow_imp.g_varchar2_table(2368) := unistr('evano|Lugo|Luna|Mac\00EDas|Madera|Madrid|Madrigal|Maestas|Maga\00F1a|Malave|Maldonado|Manzanares|Mares|Mar\00EDn');
wwv_flow_imp.g_varchar2_table(2369) := unistr('|M\00E1rquez|Marrero|Marroqu\00EDn|Mart\00EDnez|Mascare\00F1as|Mata|Mateo|Mat\00EDas|Matos|Maya|Mayorga|Medina|Medrano|M');
wwv_flow_imp.g_varchar2_table(2370) := unistr('ej\00EDa|Mel\00E9ndez|Melgar|Mena|Menchaca|M\00E9ndez|Mendoza|Men\00E9ndez|Meraz|Mercado|Merino|Mesa|Meza|Miramontes');
wwv_flow_imp.g_varchar2_table(2371) := unistr('|Miranda|Mireles|Mojica|Molina|Mondrag\00F3n|Monroy|Montalvo|Monta\00F1ez|Monta\00F1o|Montemayor|Montenegro|Mont');
wwv_flow_imp.g_varchar2_table(2372) := unistr('ero|Montes|Montez|Montoya|Mora|Morales|Moreno|Mota|Moya|Mungu\00EDa|Mu\00F1iz|Mu\00F1oz|Murillo|Muro|N\00E1jera|Nara');
wwv_flow_imp.g_varchar2_table(2373) := unistr('njo|Narv\00E1ez|Nava|Navarrete|Navarro|Nazario|Negrete|Negr\00F3n|Nev\00E1rez|Nieto|Nieves|Ni\00F1o|Noriega|N\00FA\00F1ez|Oc');
wwv_flow_imp.g_varchar2_table(2374) := unistr('ampo|Ocasio|Ochoa|Ojeda|Olivares|Oliv\00E1rez|Olivas|Olivera|Olivo|Olmos|Olvera|Ontiveros|Oquendo|Ord\00F3\00F1e');
wwv_flow_imp.g_varchar2_table(2375) := unistr('z|Orellana|Ornelas|Orosco|Orozco|Orta|Ortega|Ortiz|Osorio|Otero|Ozuna|Pab\00F3n|Pacheco|Padilla|Padr\00F3n|P');
wwv_flow_imp.g_varchar2_table(2376) := unistr('\00E1ez|Palacios|Palomino|Palomo|Pantoja|Paredes|Parra|Partida|Pati\00F1o|Paz|Pedraza|Pedroza|Pelayo|Pe\00F1a|Pe');
wwv_flow_imp.g_varchar2_table(2377) := unistr('rales|Peralta|Perea|Peres|P\00E9rez|Pichardo|Pi\00F1a|Pineda|Pizarro|Polanco|Ponce|Porras|Portillo|Posada|Pr');
wwv_flow_imp.g_varchar2_table(2378) := unistr('ado|Preciado|Prieto|Puente|Puga|Pulido|Quesada|Quezada|Qui\00F1ones|Qui\00F1\00F3nez|Quintana|Quintanilla|Quinte');
wwv_flow_imp.g_varchar2_table(2379) := unistr('ro|Quiroz|Rael|Ram\00EDrez|Ram\00F3n|Ramos|Rangel|Rasc\00F3n|Raya|Razo|Regalado|Rend\00F3n|Renter\00EDa|Res\00E9ndez|Reyes|R');
wwv_flow_imp.g_varchar2_table(2380) := unistr('eyna|Reynoso|Rico|Rinc\00F3n|Riojas|R\00EDos|Rivas|Rivera|Rivero|Robledo|Robles|Rocha|Rodarte|Rodr\00EDgez|Rodr\00ED');
wwv_flow_imp.g_varchar2_table(2381) := unistr('guez|Rodr\00EDquez|Rojas|Rojo|Rold\00E1n|Rol\00F3n|Romero|Romo|Roque|Rosado|Rosales|Rosario|Rosas|Roybal|Rubio|R');
wwv_flow_imp.g_varchar2_table(2382) := unistr('uelas|Ruiz|Saavedra|S\00E1enz|Saiz|Salas|Salazar|Salcedo|Salcido|Salda\00F1a|Saldivar|Salgado|Salinas|Samani');
wwv_flow_imp.g_varchar2_table(2383) := unistr('ego|Sanabria|Sanches|S\00E1nchez|Sandoval|Santacruz|Santana|Santiago|Santill\00E1n|Sarabia|Sauceda|Saucedo|S');
wwv_flow_imp.g_varchar2_table(2384) := unistr('egovia|Segura|Sep\00FAlveda|Serna|Serrano|Serrato|Sevilla|Sierra|Sisneros|Solano|Sol\00EDs|Soliz|Solorio|Sol');
wwv_flow_imp.g_varchar2_table(2385) := unistr('orzano|Soria|Sosa|Sotelo|Soto|Su\00E1rez|Tafoya|Tamayo|Tamez|Tapia|Tejada|Tejeda|T\00E9llez|Tello|Ter\00E1n|Terr');
wwv_flow_imp.g_varchar2_table(2386) := unistr('azas|Tijerina|Tirado|Toledo|Toro|Torres|T\00F3rrez|Tovar|Trejo|Trevi\00F1o|Trujillo|Ulibarri|Ulloa|Urbina|Ur');
wwv_flow_imp.g_varchar2_table(2387) := unistr('e\00F1a|Ur\00EDas|Uribe|Urrutia|Vaca|Valadez|Vald\00E9s|Valdez|Valdivia|Valencia|Valent\00EDn|Valenzuela|Valladares|');
wwv_flow_imp.g_varchar2_table(2388) := unistr('Valle|Vallejo|Valles|Valverde|Vanegas|Varela|Vargas|V\00E1squez|V\00E1zquez|Vega|Vela|Velasco|Vel\00E1squez|Vel\00E1');
wwv_flow_imp.g_varchar2_table(2389) := unistr('zquez|V\00E9lez|V\00E9liz|Venegas|Vera|Verdugo|Verduzco|Vergara|Viera|Vigil|Villa|Villag\00F3mez|Villalobos|Vill');
wwv_flow_imp.g_varchar2_table(2390) := unistr('alpando|Villanueva|Villareal|Villarreal|Villase\00F1or|Villegas|Y\00E1\00F1ez|Ybarra|Zambrano|Zamora|Zamudio|Zap');
wwv_flow_imp.g_varchar2_table(2391) := unistr('ata|Zaragoza|Zarate|Zavala|Zayas|Zedillo|Zelaya|Zepeda|Z\00FA\00F1iga|Abad|Abascal|Abella|Abell\00E1n|Abril|Aced');
wwv_flow_imp.g_varchar2_table(2392) := unistr('o|Acero|Adadia|Ad\00E1n|Aguado|Agudo|Aguil\00F3|Agullo|Agust\00ED|Agust\00EDn|Alberdi|Albero|Alberola|Alberto|Alcald');
wwv_flow_imp.g_varchar2_table(2393) := unistr('e|Alcal\00E1|Alcolea|Alc\00E1ntara|Alc\00E1zar|Alegre|Alegria|Alemany|Alfonso|Aliaga|Aller|Almagro|Almansa|Almaz');
wwv_flow_imp.g_varchar2_table(2394) := unistr('\00E1n|Almeida|Alsina|Amat|Amig\00F3|Amo|Amor|Amores|Amor\00F3s|Andrade|Andres|Andreu|Andr\00E9s|Anglada|Anguita|Ant');
wwv_flow_imp.g_varchar2_table(2395) := unistr('\00F3n|Ant\00FAnez|Aragon\00E9s|Aramburu|Arana|Araujo|Arco|Arcos|Ariza|Ari\00F1o|Arjona|Armengol|Arnaiz|Arnal|Arnau|');
wwv_flow_imp.g_varchar2_table(2396) := unistr('Aroca|Arranz|Arregui|Arribas|Arrieta|Artigas|Ar\00E9valo|Asenjo|Asensio|Atienza|Ayll\00F3n|Ayuso|Azcona|Azna');
wwv_flow_imp.g_varchar2_table(2397) := unistr('r|Azorin|Bad\00EDa|Baena|Balaguer|Ballester|Baquero|Barba|Barbero|Barber\00E1|Barcel\00F3|Barco|Barral|Barranco|');
wwv_flow_imp.g_varchar2_table(2398) := unistr('Barreda|Barrena|Barriga|Barrio|Barros|Barroso|Bartolom\00E9|Bar\00F3|Bar\00F3n|Bas|Bastida|Batalla|Batlle|Bautis');
wwv_flow_imp.g_varchar2_table(2399) := unistr('ta|Bauz\00E0|Bayo|Bayona|Bay\00F3n|Ba\00F1os|Bejarano|Belda|Bellido|Bello|Belmonte|Beltran|Benavent|Benavente|Be');
wwv_flow_imp.g_varchar2_table(2400) := unistr('net|Benitez|Benito|Berenguer|Bermejo|Bermudez|Bernad|Bernat|Berrocal|Bertr\00E1n|Bilbao|Blanca|Blanch|Bl');
wwv_flow_imp.g_varchar2_table(2401) := unistr('anes|Blasco|Blazquez|Bl\00E1zquez|Boada|Boix|Bola\00F1os|Bonet|Borja|Borrell|Borr\00E1s|Bosch|Botella|Bou|Bru|Bu');
wwv_flow_imp.g_varchar2_table(2402) := unistr('end\00EDa|Busquets|B\00E1rcena|Cabanillas|Caba\00F1as|Cabello|Cabeza|Cabezas|Cabo|Cabrero|Cadenas|Cal|Calatayud|');
wwv_flow_imp.g_varchar2_table(2403) := unistr('Calderon|Calleja|Calvet|Calvo|Calzada|Camino|Campillo|Campo|Campoy|Camps|Canals|Canet|Cantero|Cant\00F3n');
wwv_flow_imp.g_varchar2_table(2404) := unistr('|Caparr\00F3s|Capdevila|Carbajo|Carballo|Carbonell|Carb\00F3|Carlos|Carnero|Caro|Carpio|Carreras|Carretero|C');
wwv_flow_imp.g_varchar2_table(2405) := unistr('arre\00F1o|Carro|Casado|Casal|Casals|Casanovas|Cases|Castej\00F3n|Castell|Castells|Castell\00F3|Castilla|Castril');
wwv_flow_imp.g_varchar2_table(2406) := unistr('lo|Catal\00E1|Catal\00E1n|Cazorla|Ca\00F1as|Ca\00F1ellas|Ca\00F1ete|Ca\00F1izares|Cerd\00E1|Cerd\00E1n|Cerezo|Cerro|Cervera|Chamorro');
wwv_flow_imp.g_varchar2_table(2407) := '|Chaparro|Chaves|Checa|Chico|Cid|Cifuentes|Clavero|Clemente|Cobo|Cobos|Coca|Codina|Coello|Coll|Colom';
wwv_flow_imp.g_varchar2_table(2408) := '|Coloma|Colomer|Comas|Company|Conde|Conesa|Corbacho|Corominas|Cortes|Cortina|Costa|Crespi|Criado|Cua';
wwv_flow_imp.g_varchar2_table(2409) := unistr('drado|Cuenca|Cuervo|Cuesta|Cueto|Cuevas|Cu\00E9llar|C\00E1ceres|C\00E1mara|C\00E1novas|C\00E1rdenas|C\00E9spedes|C\00F3rdoba|C\00F3z');
wwv_flow_imp.g_varchar2_table(2410) := unistr('ar|Dalmau|Daza|Diaz|Diego|Diez|Di\00E9guez|Domingo|Dominguez|Dom\00E9nech|Donaire|Donoso|Duque|Duran|D\00EDez|Ec');
wwv_flow_imp.g_varchar2_table(2411) := unistr('hevarr\00EDa|Egea|Elorza|El\00EDas|Escalona|Escolano|Escribano|Escriv\00E1|Escudero|Espada|Espa\00F1a|Espa\00F1ol|Espejo');
wwv_flow_imp.g_varchar2_table(2412) := unistr('|Esteban|Esteve|Estevez|Exposito|Exp\00F3sito|Fabra|Fabregat|Falc\00F3|Falc\00F3n|Farr\00E9|Feijoo|Feliu|Fernandez|F');
wwv_flow_imp.g_varchar2_table(2413) := unistr('errando|Ferrera|Ferreras|Ferrero|Ferr\00E1n|Ferr\00E1ndez|Ferr\00E1ndiz|Figueras|Figuerola|Fiol|Flor|Folch|Font|');
wwv_flow_imp.g_varchar2_table(2414) := unistr('Fortuny|Franch|Francisco|Frutos|Fuente|Fuertes|Fuster|F\00E1bregas|Gabald\00F3n|Galan|Galiano|Gallart|Galleg');
wwv_flow_imp.g_varchar2_table(2415) := unistr('o|Gallo|Galvez|Gal\00E1n|Garcia|Garc\00E9s|Gargallo|Garmendia|Garriga|Garz\00F3n|Gasc\00F3n|Gaya|Gelabert|Gibert|Gil');
wwv_flow_imp.g_varchar2_table(2416) := unistr('abert|Gimenez|Gimeno|Gim\00E9nez|Giner|Giralt|Girona|Gisbert|Goicoechea|Gomez|Gomila|Gomis|Gonzalez|Gonz');
wwv_flow_imp.g_varchar2_table(2417) := unistr('alo|Gordillo|Go\00F1i|Grande|Gras|Grau|Gual|Guardia|Guardiola|Guijarro|Guill\00E9n|Guitart|Gutierrez|Guzman|');
wwv_flow_imp.g_varchar2_table(2418) := unistr('G\00E1mez|G\00E1rate|Heras|Hernandez|Hernando|Herranz|Herrero|Hervia|Herv\00E1s|Hierro|Higueras|Hoyos|Hoz|Huerta');
wwv_flow_imp.g_varchar2_table(2419) := unistr('s|Huguet|Iba\00F1ez|Iborra|Ib\00E1\00F1ez|Iglesia|Infante|Iniesta|Iriarte|Isern|Izaguirre|Izquierdo|I\00F1iguez|Jara');
wwv_flow_imp.g_varchar2_table(2420) := unistr('|Jaume|Ja\00E9n|Jerez|Jimenez|Jord\00E1|Jord\00E1n|Jove|Jover|Juan|Juli\00E1|Juli\00E1n|J\00E1uregui|J\00F3dar|Lago|Laguna|Lamas');
wwv_flow_imp.g_varchar2_table(2421) := unistr('|Landa|Larra\00F1aga|Larrea|Lasa|Lastra|Leon|Lillo|Llabr\00E9s|Llad\00F3|Llano|Llanos|Lled\00F3|Llobet|Llopis|Lloren');
wwv_flow_imp.g_varchar2_table(2422) := unistr('s|Llorente|Lloret|Lluch|Lobato|Lobo|Lopez|Lorenzo|Losa|Losada|Lucas|Lucena|Luj\00E1n|Lumbreras|Luque|Luz');
wwv_flow_imp.g_varchar2_table(2423) := unistr('|Lu\00EDs|Machado|Macias|Maestre|Malo|Mancebo|Manj\00F3n|Manrique|Manso|Manuel|Manzano|Marco|Marcos|Marin|Ma');
wwv_flow_imp.g_varchar2_table(2424) := unistr('riscal|Mari\00F1o|Marquez|Marqu\00E9s|Marti|Martin|Martinez|Martorell|Mart\00ED|Mart\00EDn|Mar\00ED|Mas|Mascar\00F3|Matas|Ma');
wwv_flow_imp.g_varchar2_table(2425) := unistr('te|Mateos|Mateu|Mayo|Mayol|Mayoral|Maza|Melero|Mendez|Mendiz\00E1bal|Menendez|Mercader|Miguel|Milla|Mill');
wwv_flow_imp.g_varchar2_table(2426) := unistr('\00E1n|Mir|Miralles|Mir\00F3|Moles|Moliner|Molins|Moll|Monreal|Montalb\00E1n|Monta\00F1a|Montesinos|Montserrat|Moral');
wwv_flow_imp.g_varchar2_table(2427) := unistr('eda|Morante|Morata|Morcillo|Morell|Morera|Morillo|Mor\00E1n|Mosquera|Mulet|Mur|Murcia|M\00E1rmol|M\00EDnguez|M\00FAg');
wwv_flow_imp.g_varchar2_table(2428) := unistr('ica|M\00FA\00F1iz|Nadal|Navas|Nebot|Neira|Nevado|Nicolau|Nicol\00E1s|Nogueira|Noguera|Nogu\00E9s|Novoa|Nu\00F1ez|Oca\00F1a|O');
wwv_flow_imp.g_varchar2_table(2429) := unistr('liva|Oliver|Oliveras|Oliv\00E9|Oller|Olmedo|Olmo|Ortu\00F1o|Osuna|Pablo|Pag\00E8s|Palacio|Palau|Pallar\00E8s|Palma|P');
wwv_flow_imp.g_varchar2_table(2430) := unistr('almer|Palomar|Palomares|Paniagua|Pardo|Pareja|Parejo|Pascual|Pastor|Pav\00F3n|Pazos|Pedrero|Pedro|Pedros');
wwv_flow_imp.g_varchar2_table(2431) := unistr('a|Peinado|Peir\00F3|Pellicer|Pel\00E1ez|Pera|Peral|Pereira|Perell\00F3|Perera|Perez|Pe\00F1alver|Pe\00F1as|Pi|Pina|Pined');
wwv_flow_imp.g_varchar2_table(2432) := unistr('o|Pinilla|Pino|Pinto|Pintor|Piquer|Pi\00F1eiro|Pi\00F1ol|Pla|Plana|Planas|Plaza|Pol|Polo|Pomares|Pombo|Pons|');
wwv_flow_imp.g_varchar2_table(2433) := 'Pont|Porcel|Porta|Portero|Pou|Poza|Pozo|Pozuelo|Prada|Prat|Prats|Priego|Puerta|Puig|Pujadas|Pujol|Qu';
wwv_flow_imp.g_varchar2_table(2434) := unistr('ero|Querol|Quevedo|Quiroga|Quir\00F3s|Ramirez|Ramis|Real|Rebollo|Recio|Redondo|Reguera|Reig|Reina|Requen');
wwv_flow_imp.g_varchar2_table(2435) := 'a|Revilla|Rey|Riba|Ribas|Ribera|Ribes|Ricart|Riera|Rios|Ripoll|Riquelme|Rius|Roca|Rocamora|Roda|Rodr';
wwv_flow_imp.g_varchar2_table(2436) := unistr('igo|Rodriguez|Roig|Roldan|Roma|Roman|Romeu|Rom\00E1n|Ropero|Ros|Rosa|Rosell|Rosell\00F3|Rossell\00F3|Roura|Rovir');
wwv_flow_imp.g_varchar2_table(2437) := unistr('a|Royo|Rozas|Ruano|Rueda|R\00EDo|R\00F3denas|Sabater|Sacrist\00E1n|Saez|Sainz|Sala|Salamanca|Sales|Salmer\00F3n|Salo');
wwv_flow_imp.g_varchar2_table(2438) := unistr('m|Salvador|Salv\00E0|Samper|Sanchez|Sancho|Sanjuan|Sanmart\00EDn|Sanmiguel|Sans|Santamaria|Santamar\00EDa|Santos');
wwv_flow_imp.g_varchar2_table(2439) := unistr('|Sanz|Sarmiento|Sastre|Saura|Sebasti\00E1n|Seco|Sedano|Segarra|Segu\00ED|Serra|Sevillano|Silva|Sim\00F3|Sobrino|');
wwv_flow_imp.g_varchar2_table(2440) := unistr('Sola|Solana|Soler|Solera|Solsona|Sol\00E9|Somoza|Soriano|Suarez|Sureda|S\00E1ez|Taboada|Talavera|Tamarit|Tej');
wwv_flow_imp.g_varchar2_table(2441) := unistr('edor|Tejera|Tejero|Tena|Tenorio|Terr\00F3n|Teruel|Tolosa|Tomas|Tom\00E1s|Tom\00E9|Tormo|Torralba|Torre|Torrecill');
wwv_flow_imp.g_varchar2_table(2442) := unistr('a|Torrens|Torrent|Torrents|Torrijos|Trillo|Tudela|Tur|Ugarte|Uriarte|Ur\00EDa|Valbuena|Valc\00E1rcel|Valderr');
wwv_flow_imp.g_varchar2_table(2443) := unistr('ama|Valenciano|Valera|Valero|Vall|Valls|Vall\00E9s|Vaquero|Vara|Vazquez|Vendrell|Verdejo|Verd\00FA|Viana|Vic');
wwv_flow_imp.g_varchar2_table(2444) := 'ens|Vicente|Vidal|Vila|Vilalta|Vilanova|Vilaplana|Vilar|Villalba|Villalonga|Villar|Villaverde|Villen';
wwv_flow_imp.g_varchar2_table(2445) := unistr('a|Vives|Vizca\00EDno|Vi\00F1a|Vi\00F1as|Yuste|Zabala|Zabaleta|Zamorano|Zorrilla|Zurita|\00C1guila|\00C1lamo|\00C1lvarez|\00C1lva');
wwv_flow_imp.g_varchar2_table(2446) := unistr('ro|\00C1ngel|Albuquerque|Alves|Aparecida|Arag\00E3o|Ara\00FAjo|Azevedo|Barbosa|Borges|Caldeira|Camargo|Cardoso|C');
wwv_flow_imp.g_varchar2_table(2447) := unistr('arvalho|Cassiano|Cavalcante|Cavalcanti|Cirino|Correia|Costela|Cunha|C\00E2mara|Dias|Farias|Fernandes|Fer');
wwv_flow_imp.g_varchar2_table(2448) := unistr('reira|Foga\00E7a|Freitas|Gomes|Gon\00E7alves|Jesus|Le\00E3o|Lima|Lopes|Macedo|Marques|Martins|Melo|Mendes|Mendon');
wwv_flow_imp.g_varchar2_table(2449) := unistr('\00E7a|Monteiro|Moraes|Moreira|Moura|Nascimento|Novaes|Novais|Nunes|Oliveira|Peixoto|Pimenta|Pires|Porto');
wwv_flow_imp.g_varchar2_table(2450) := unistr('|Rezende|Ribeiro|Rodrigues|Sampaio|Silveira|Siqueira|Sousa|Souza|S\00E1|Teixeira|Vasconcelos|Vieira|Amar');
wwv_flow_imp.g_varchar2_table(2451) := unistr('al|Amorim|Anjos|Antunes|Assun\00E7\00E3o|Baptista|Branco|Carneiro|Coelho|Domingues|Esteves|Faria|Figueiredo|');
wwv_flow_imp.g_varchar2_table(2452) := unistr('Gaspar|Guerreiro|Henriques|Leite|Loureiro|Louren\00E7o|Magalh\00E3es|Maia|Matias|Morais|Neto|Neves|Paiva|Pin');
wwv_flow_imp.g_varchar2_table(2453) := unistr('heiro|Pinho|Reis|Sim\00F5es|Soares|Tavares|Valente|Vaz|Araya|Aravena|Lagos|Sanhueza|Poblete|Arriagada|Ce');
wwv_flow_imp.g_varchar2_table(2454) := unistr('rda|Arancibia|Troncoso|Inostroza|Villarroel|Concha|Barr\00EDa|Gajardo|Astudillo|Retamal|Ahumada|Valdeben');
wwv_flow_imp.g_varchar2_table(2455) := unistr('ito|Pavez|Jorquera|Moraga|C\00E1rcamo|Lobos|Araneda|Mansilla|Mancilla|Abarca|Mella|Gatica|Mardones|River');
wwv_flow_imp.g_varchar2_table(2456) := unistr('os|Albornoz|Cisternas|Vallejos|Gaete|Fuentealba|Manr\00EDquez|Rebolledo|Cofr\00E9|Oyarz\00FAn|Varas|Santib\00E1\00F1ez|B');
wwv_flow_imp.g_varchar2_table(2457) := unistr('arra|Fuenzalida|Opazo|Vilches|Santander|Roa|Montecinos|Parada|Meneses|Mamani|Cancino|Fa\00FAndez|Maturan');
wwv_flow_imp.g_varchar2_table(2458) := unistr('a|Oyarzo|Jofr\00E9|Tobar|Avenda\00F1o|Galaz|Urra|Olgu\00EDn|Riffo|Astorga|Hermosilla|Marchant|Bast\00EDas|Galleguill');
wwv_flow_imp.g_varchar2_table(2459) := 'os|Suazo|Monsalve|Rubilar|Candia|Almonacid|Lizama|Osses|Cartes|Loyola|Seguel|Norambuena|Mellado|Leyt';
wwv_flow_imp.g_varchar2_table(2460) := unistr('on|Cea|Hormaz\00E1bal|Mondaca|Past\00E9n|Brice\00F1o|Matus|Cisterna|Aedo|Bahamondes|Matamala|Elgueta|Barahona|Es');
wwv_flow_imp.g_varchar2_table(2461) := unistr('tay|Aburto|B\00F3rquez|\00D3rdenes|Lizana|Villagra|Alegr\00EDa|Maureira|Urz\00FAa|Oyarce|Olave|Ferrada|Bugue\00F1o|Vivan');
wwv_flow_imp.g_varchar2_table(2462) := unistr('co|Lorca|Vicencio|Lazo|Villagr\00E1n|Aros|Ar\00E1nguiz|Baez|Belmar|Machuca|Quinteros|Collao|Letelier|Quispe|');
wwv_flow_imp.g_varchar2_table(2463) := unistr('Marambio|Mej\00EDas|Saldivia|Armijo|Orrego|Parraguez|O\00F1ate|Iturra|Fredes|Jaque|Chand\00EDa'';'||wwv_flow.LF||
'    l_first_nam');
wwv_flow_imp.g_varchar2_table(2464) := 'e_catalog(1) := ''Aaron|Adam|Adrian|Alan|Albert|Alec|Alejandro|Alex|Alexander|Alexis|Alfred|Allen|Alv';
wwv_flow_imp.g_varchar2_table(2465) := 'in|Andre|Andres|Andrew|Angel|Anthony|Antonio|Arthur|Austin|Barry|Benjamin|Bernard|Bill|Billy|Blake|B';
wwv_flow_imp.g_varchar2_table(2466) := 'ob|Bobby|Brad|Bradley|Brady|Brandon|Brendan|Brent|Brett|Brian|Bruce|Bryan|Bryce|Caleb|Calvin|Cameron';
wwv_flow_imp.g_varchar2_table(2467) := '|Carl|Carlos|Casey|Cesar|Chad|Charles|Chase|Chris|Christian|Christopher|Clarence|Clayton|Clifford|Cl';
wwv_flow_imp.g_varchar2_table(2468) := 'inton|Cody|Cole|Colin|Collin|Colton|Connor|Corey|Cory|Craig|Cristian|Curtis|Dakota|Dale|Dalton|Damon';
wwv_flow_imp.g_varchar2_table(2469) := '|Dan|Daniel|Danny|Darin|Darius|Darrell|Darren|Darryl|Daryl|Dave|David|Dean|Dennis|Derek|Derrick|Devi';
wwv_flow_imp.g_varchar2_table(2470) := 'n|Devon|Dillon|Dominic|Don|Donald|Douglas|Drew|Duane|Dustin|Dwayne|Dylan|Earl|Eddie|Edgar|Eduardo|Ed';
wwv_flow_imp.g_varchar2_table(2471) := 'ward|Edwin|Elijah|Eric|Erik|Ernest|Ethan|Eugene|Evan|Fernando|Francis|Francisco|Frank|Franklin|Fred|';
wwv_flow_imp.g_varchar2_table(2472) := 'Frederick|Gabriel|Garrett|Gary|Gavin|Gene|Geoffrey|George|Gerald|Gilbert|Glen|Glenn|Gordon|Grant|Gre';
wwv_flow_imp.g_varchar2_table(2473) := 'g|Gregg|Gregory|Guy|Harold|Harry|Hayden|Hector|Henry|Herbert|Howard|Hunter|Ian|Isaac|Isaiah|Ivan|Jac';
wwv_flow_imp.g_varchar2_table(2474) := 'k|Jackson|Jacob|Jaime|Jake|James|Jamie|Jared|Jason|Javier|Jay|Jeff|Jeffery|Jeffrey|Jeremiah|Jeremy|J';
wwv_flow_imp.g_varchar2_table(2475) := 'ermaine|Jerome|Jerry|Jesse|Jesus|Jim|Jimmy|Joe|Joel|John|Johnathan|Johnny|Jon|Jonathan|Jonathon|Jord';
wwv_flow_imp.g_varchar2_table(2476) := 'an|Jorge|Jose|Joseph|Joshua|Juan|Julian|Justin|Karl|Keith|Kelly|Kenneth|Kent|Kerry|Kevin|Kirk|Kristo';
wwv_flow_imp.g_varchar2_table(2477) := 'pher|Kurt|Kyle|Lance|Larry|Lawrence|Lee|Leon|Leonard|Leroy|Leslie|Levi|Logan|Lonnie|Louis|Lucas|Luis';
wwv_flow_imp.g_varchar2_table(2478) := '|Luke|Malik|Manuel|Marc|Marco|Marcus|Mario|Mark|Martin|Marvin|Mason|Mathew|Matthew|Maurice|Max|Maxwe';
wwv_flow_imp.g_varchar2_table(2479) := 'll|Melvin|Michael|Micheal|Miguel|Mike|Mitchell|Nathan|Nathaniel|Neil|Nicholas|Nicolas|Noah|Norman|Om';
wwv_flow_imp.g_varchar2_table(2480) := 'ar|Oscar|Parker|Patrick|Paul|Pedro|Perry|Peter|Philip|Phillip|Preston|Ralph|Randall|Randy|Ray|Raymon';
wwv_flow_imp.g_varchar2_table(2481) := 'd|Reginald|Ricardo|Richard|Rick|Rickey|Ricky|Riley|Robert|Roberto|Rodney|Roger|Ronald|Ronnie|Ross|Ro';
wwv_flow_imp.g_varchar2_table(2482) := 'y|Ruben|Russell|Ryan|Samuel|Scott|Sean|Sergio|Seth|Shane|Shannon|Shaun|Shawn|Spencer|Stanley|Stephen';
wwv_flow_imp.g_varchar2_table(2483) := '|Steve|Steven|Stuart|Tanner|Taylor|Terrance|Terrence|Terry|Theodore|Thomas|Tim|Timothy|Todd|Tom|Tomm';
wwv_flow_imp.g_varchar2_table(2484) := 'y|Tony|Tracy|Travis|Trevor|Tristan|Troy|Tyler|Tyrone|Vernon|Victor|Vincent|Walter|Warren|Wayne|Wesle';
wwv_flow_imp.g_varchar2_table(2485) := 'y|William|Willie|Wyatt|Xavier|Zachary|April|Abigail|Adriana|Adrienne|Aimee|Alejandra|Alexa|Alexandra';
wwv_flow_imp.g_varchar2_table(2486) := '|Alexandria|Alice|Alicia|Alisha|Alison|Allison|Alyssa|Amanda|Amber|Amy|Ana|Andrea|Angela|Angelica|An';
wwv_flow_imp.g_varchar2_table(2487) := 'gie|Anita|Ann|Anna|Anne|Annette|Ariana|Ariel|Ashlee|Ashley|Audrey|Autumn|Bailey|Barbara|Becky|Belind';
wwv_flow_imp.g_varchar2_table(2488) := 'a|Beth|Bethany|Betty|Beverly|Bianca|Bonnie|Brandi|Brandy|Breanna|Brenda|Briana|Brianna|Bridget|Britt';
wwv_flow_imp.g_varchar2_table(2489) := 'any|Brittney|Brooke|Caitlin|Caitlyn|Candace|Candice|Carla|Carly|Carmen|Carol|Caroline|Carolyn|Carrie';
wwv_flow_imp.g_varchar2_table(2490) := '|Cassandra|Cassidy|Cassie|Catherine|Cathy|Charlene|Charlotte|Chelsea|Chelsey|Cheryl|Cheyenne|Chloe|C';
wwv_flow_imp.g_varchar2_table(2491) := 'hristie|Christina|Christine|Christy|Cindy|Claire|Claudia|Colleen|Connie|Courtney|Cristina|Crystal|Cy';
wwv_flow_imp.g_varchar2_table(2492) := 'nthia|Daisy|Dana|Danielle|Darlene|Dawn|Deanna|Debbie|Deborah|Debra|Denise|Desiree|Destiny|Diamond|Di';
wwv_flow_imp.g_varchar2_table(2493) := 'ana|Diane|Dominique|Donna|Doris|Dorothy|Ebony|Eileen|Elaine|Elizabeth|Ellen|Emily|Emma|Erica|Erika|E';
wwv_flow_imp.g_varchar2_table(2494) := 'rin|Evelyn|Faith|Felicia|Frances|Gabriela|Gabriella|Gabrielle|Gail|Gina|Glenda|Gloria|Grace|Gwendoly';
wwv_flow_imp.g_varchar2_table(2495) := 'n|Hailey|Haley|Hannah|Hayley|Heather|Heidi|Helen|Holly|Isabel|Isabella|Jackie|Jaclyn|Jacqueline|Jade';
wwv_flow_imp.g_varchar2_table(2496) := '|Jane|Janet|Janice|Jasmin|Jasmine|Jean|Jeanette|Jeanne|Jenna|Jennifer|Jenny|Jessica|Jill|Jillian|Jo|';
wwv_flow_imp.g_varchar2_table(2497) := 'Joan|Joann|Joanna|Joanne|Jocelyn|Jodi|Jody|Joy|Joyce|Judith|Judy|Julia|Julie|Kaitlin|Kaitlyn|Kara|Ka';
wwv_flow_imp.g_varchar2_table(2498) := 'ren|Kari|Karina|Karla|Katelyn|Katherine|Kathleen|Kathryn|Kathy|Katie|Katrina|Kayla|Kaylee|Kelli|Kell';
wwv_flow_imp.g_varchar2_table(2499) := 'ie|Kelsey|Kendra|Kerri|Kiara|Kim|Kimberly|Kirsten|Krista|Kristen|Kristi|Kristie|Kristin|Kristina|Kri';
wwv_flow_imp.g_varchar2_table(2500) := 'stine|Kristy|Krystal|Kylie|Lacey|Latasha|Latoya|Laura|Lauren|Laurie|Leah|Linda|Lindsay|Lindsey|Lisa|';
wwv_flow_imp.g_varchar2_table(2501) := 'Loretta|Lori|Lorraine|Lydia|Lynn|Mackenzie|Madeline|Madison|Makayla|Mallory|Mandy|Marcia|Margaret|Ma';
wwv_flow_imp.g_varchar2_table(2502) := 'ria|Mariah|Marie|Marilyn|Marisa|Marissa|Martha|Mary|Maureen|Mckenzie|Meagan|Megan|Meghan|Melanie|Mel';
wwv_flow_imp.g_varchar2_table(2503) := 'inda|Melissa|Melody|Mercedes|Meredith|Mia|Michaela|Michele|Michelle|Mikayla|Mindy|Miranda|Misty|Moll';
wwv_flow_imp.g_varchar2_table(2504) := 'y|Monica|Monique|Morgan|Nancy|Natalie|Natasha|Nichole|Nicole|Nina|Norma|Olivia|Paige|Pam|Pamela|Patr';
wwv_flow_imp.g_varchar2_table(2505) := 'icia|Patty|Paula|Peggy|Penny|Phyllis|Priscilla|Rachael|Rachel|Raven|Rebecca|Rebekah|Regina|Renee|Rho';
wwv_flow_imp.g_varchar2_table(2506) := 'nda|Rita|Roberta|Robin|Robyn|Rose|Ruth|Sabrina|Sally|Samantha|Sandra|Sandy|Sara|Sarah|Savannah|Selen';
wwv_flow_imp.g_varchar2_table(2507) := 'a|Shari|Sharon|Shawna|Sheena|Sheila|Shelby|Shelia|Shelley|Shelly|Sheri|Sherri|Sherry|Sheryl|Shirley|';
wwv_flow_imp.g_varchar2_table(2508) := 'Sierra|Sonia|Sonya|Sophia|Stacey|Stacie|Stacy|Stefanie|Stephanie|Sue|Summer|Susan|Suzanne|Sydney|Syl';
wwv_flow_imp.g_varchar2_table(2509) := 'via|Tabitha|Tamara|Tami|Tammie|Tammy|Tanya|Tara|Tasha|Teresa|Terri|Theresa|Tiffany|Tina|Toni|Tonya|T';
wwv_flow_imp.g_varchar2_table(2510) := 'racey|Traci|Tracie|Tricia|Valerie|Vanessa|Veronica|Vicki|Vickie|Victoria|Virginia|Wanda|Wendy|Whitne';
wwv_flow_imp.g_varchar2_table(2511) := 'y|Yesenia|Yolanda|Yvette|Yvonne|Zoe|Simon|Liam|Graham|Lewis|Nigel|Oliver|Terence|Malcolm|Callum|Gare';
wwv_flow_imp.g_varchar2_table(2512) := 'th|Kieran|Sam|Ben|Mohammed|Clive|Antony|Reece|Rhys|Allan|Charlie|Damian|Duncan|Conor|Garry|Elliot|Ab';
wwv_flow_imp.g_varchar2_table(2513) := 'dul|Martyn|Gerard|Iain|Josh|Stewart|Mohammad|Graeme|Elliott|Toby|Hugh|Mohamed|Declan|Leigh|Denis|Dam';
wwv_flow_imp.g_varchar2_table(2514) := 'ien|Owen|Nicola|Gemma|Sophie|Louise|Lucy|Clare|Gillian|Pauline|Lesley|Leanne|Georgia|Eleanor|Georgin';
wwv_flow_imp.g_varchar2_table(2515) := 'a|Lynne|Kirsty|Marion|Beverley|Rosemary|Kimberley|Carole|Fiona|Kate|Jodie|June|Lynda|Jayne|Marian|Ka';
wwv_flow_imp.g_varchar2_table(2516) := 'yleigh|Harriet|Ashleigh|Jemma|Francesca|Naomi|Hilary|Abbie|Katy|Irene|Rosie|Ellie|Sian|Josephine|Hol';
wwv_flow_imp.g_varchar2_table(2517) := 'lie|Hazel|Bethan|Amelia|Geraldine|Aidan|Aiden|Alistair|Angus|Archer|Archie|Arlo|Asher|Ashton|Beau|Be';
wwv_flow_imp.g_varchar2_table(2518) := 'auden|Bevan|Blair|Bodhi|Braxton|Brayden|Brendon|Brodie|Brooklyn|Campbell|Carter|Cohen|Cooper|Cruz|Da';
wwv_flow_imp.g_varchar2_table(2519) := 'rrin|Darryn|Desmond|Dion|Eli|Ezra|Felix|Finn|Fletcher|Flynn|Fraser|Grayson|Hamish|Harley|Harrison|Ha';
wwv_flow_imp.g_varchar2_table(2520) := 'rvey|Hudson|Hugo|Israel|Jakob|Jarrod|Jasper|Jaxon|Jayden|Josiah|Kaleb|Kane|Kayden|Keanu|Keegan|Kelvi';
wwv_flow_imp.g_varchar2_table(2521) := 'n|Kingston|Lachlan|Leo|Lincoln|Lloyd|Luca|Luka|Lukas|Mervyn|Micah|Murray|Nate|Neville|Nikau|Nixon|No';
wwv_flow_imp.g_varchar2_table(2522) := 'el|Phoenix|Quentin|Quinn|Regan|Reuben|Rex|Roman|Rory|Ryder|Sebastian|Shayne|Sione|Stefan|Taine|Theo|';
wwv_flow_imp.g_varchar2_table(2523) := 'Trent|Tyson|Vaughan|Warwick|Zac|Zane|Zion|Anaru|Ari|Ariki|Hemi|Hoani|Ihaia|Kahu|Kahurangi|Kauri|Mana';
wwv_flow_imp.g_varchar2_table(2524) := 'aki|Manaia|Manawa|Matiu|Mikaere|Niko|Nikora|Rawiri|Tai|Tama|Tamati|Tane|Tangaroa|Tiare|Wiremu|Aaliya';
wwv_flow_imp.g_varchar2_table(2525) := 'h|Abbey|Abby|Addison|Alana|Aleisha|Amaia|Anahera|Angelina|Anika|Annabelle|Arabella|Aria|Aroha|Aurora';
wwv_flow_imp.g_varchar2_table(2526) := '|Ava|Ayla|Bella|Billie|Britney|Bronwyn|Chantelle|Cherie|Clara|Dianne|Eden|Eilish|Elise|Ella|Elsie|Em';
wwv_flow_imp.g_varchar2_table(2527) := 'ilia|Esther|Eva|Evie|Florence|Frankie|Freya|Gaylene|Glenys|Harmony|Harper|Hope|Imogen|Indi|Indie|Isa';
wwv_flow_imp.g_varchar2_table(2528) := 'belle|Isla|Isobel|Ivy|Jan|Janette|Janine|Jessie|Jolene|Jorja|Justine|Karyn|Kay|Kaye|Keira|Khloe|Kiri';
wwv_flow_imp.g_varchar2_table(2529) := '|Kyla|Layla|Leonie|Libby|Lilly|Lily|Lois|Lola|Lucia|Luna|Lynette|Lynley|Lynnette|MacKenzie|Maddison|';
wwv_flow_imp.g_varchar2_table(2530) := 'Madeleine|Maia|Maree|Matilda|Maya|Mikaela|Mila|Millie|Mya|Nadine|Nevaeh|Ngaire|Niamh|Nikita|Nikki|Ol';
wwv_flow_imp.g_varchar2_table(2531) := 'ive|Paris|Payton|Penelope|Peyton|Philippa|Phoebe|Piper|Pippa|Poppy|Rachelle|Raewyn|Rochelle|Ruby|Sad';
wwv_flow_imp.g_varchar2_table(2532) := 'ie|Sasha|Scarlett|Shakira|Shania|Sharlene|Sheree|Shona|Sienna|Sinead|Skye|Skyla|Skylar|Sofia|Stella|';
wwv_flow_imp.g_varchar2_table(2533) := 'Tania|Tayla|Tegan|Tessa|Thea|Tiana|Tori|Trinity|Tyla|Vicky|Violet|Vivienne|Willow|Zara|Zoey|Ataahua|';
wwv_flow_imp.g_varchar2_table(2534) := 'Awhina|Hana|Hinewai|Huia|Kaia|Kora|Mahi|Maraea|Mareikura|Mereana|Miriama|Nia|Ria|Terina|Tia|Tui|Waim';
wwv_flow_imp.g_varchar2_table(2535) := 'arie|Wikitoria'';'||wwv_flow.LF||
'    l_last_name_catalog(1) := ''Smith|Johnson|Williams|Brown|Jones|Miller|Davis|Garc';
wwv_flow_imp.g_varchar2_table(2536) := 'ia|Rodriguez|Wilson|Martinez|Anderson|Taylor|Thomas|Hernandez|Moore|Martin|Jackson|Thompson|White|Lo';
wwv_flow_imp.g_varchar2_table(2537) := 'pez|Lee|Gonzalez|Harris|Clark|Lewis|Robinson|Walker|Perez|Hall|Young|Allen|Sanchez|Wright|King|Scott';
wwv_flow_imp.g_varchar2_table(2538) := '|Green|Baker|Adams|Nelson|Hill|Ramirez|Campbell|Mitchell|Roberts|Carter|Phillips|Evans|Turner|Torres';
wwv_flow_imp.g_varchar2_table(2539) := '|Parker|Collins|Edwards|Stewart|Flores|Morris|Nguyen|Murphy|Rivera|Cook|Rogers|Morgan|Peterson|Coope';
wwv_flow_imp.g_varchar2_table(2540) := 'r|Reed|Bailey|Bell|Gomez|Kelly|Howard|Ward|Cox|Diaz|Richardson|Wood|Watson|Brooks|Bennett|Gray|James';
wwv_flow_imp.g_varchar2_table(2541) := '|Reyes|Cruz|Hughes|Price|Myers|Long|Foster|Sanders|Ross|Morales|Powell|Sullivan|Russell|Ortiz|Jenkin';
wwv_flow_imp.g_varchar2_table(2542) := 's|Gutierrez|Perry|Butler|Barnes|Fisher|Henderson|Coleman|Simmons|Patterson|Jordan|Reynolds|Hamilton|';
wwv_flow_imp.g_varchar2_table(2543) := 'Graham|Kim|Gonzales|Alexander|Ramos|Wallace|Griffin|West|Cole|Hayes|Chavez|Gibson|Bryant|Ellis|Steve';
wwv_flow_imp.g_varchar2_table(2544) := 'ns|Murray|Ford|Marshall|Owens|Mcdonald|Harrison|Ruiz|Kennedy|Wells|Alvarez|Woods|Mendoza|Castillo|Ol';
wwv_flow_imp.g_varchar2_table(2545) := 'son|Webb|Washington|Tucker|Freeman|Burns|Henry|Vasquez|Snyder|Simpson|Crawford|Jimenez|Porter|Mason|';
wwv_flow_imp.g_varchar2_table(2546) := 'Shaw|Gordon|Wagner|Hunter|Romero|Hicks|Dixon|Hunt|Palmer|Robertson|Black|Holmes|Stone|Meyer|Boyd|Mil';
wwv_flow_imp.g_varchar2_table(2547) := 'ls|Warren|Fox|Rose|Rice|Moreno|Schmidt|Patel|Ferguson|Nichols|Herrera|Medina|Ryan|Fernandez|Weaver|D';
wwv_flow_imp.g_varchar2_table(2548) := 'aniels|Stephens|Gardner|Payne|Kelley|Dunn|Pierce|Arnold|Tran|Spencer|Peters|Hawkins|Grant|Hansen|Cas';
wwv_flow_imp.g_varchar2_table(2549) := 'tro|Hoffman|Hart|Elliott|Cunningham|Knight|Bradley|Carroll|Hudson|Duncan|Armstrong|Berry|Andrews|Joh';
wwv_flow_imp.g_varchar2_table(2550) := 'nston|Ray|Lane|Riley|Carpenter|Perkins|Aguilar|Silva|Richards|Willis|Matthews|Chapman|Lawrence|Garza';
wwv_flow_imp.g_varchar2_table(2551) := '|Vargas|Watkins|Wheeler|Larson|Carlson|Harper|George|Greene|Burke|Guzman|Morrison|Munoz|Jacobs|Obrie';
wwv_flow_imp.g_varchar2_table(2552) := 'n|Lawson|Franklin|Lynch|Bishop|Carr|Salazar|Austin|Mendez|Gilbert|Jensen|Williamson|Montgomery|Harve';
wwv_flow_imp.g_varchar2_table(2553) := 'y|Oliver|Howell|Dean|Hanson|Weber|Garrett|Sims|Burton|Fuller|Soto|Mccoy|Welch|Chen|Schultz|Walters|R';
wwv_flow_imp.g_varchar2_table(2554) := 'eid|Fields|Walsh|Little|Fowler|Bowman|Davidson|May|Day|Schneider|Newman|Brewer|Lucas|Holland|Wong|Ba';
wwv_flow_imp.g_varchar2_table(2555) := 'nks|Santos|Curtis|Pearson|Delgado|Valdez|Pena|Rios|Douglas|Sandoval|Barrett|Hopkins|Keller|Guerrero|';
wwv_flow_imp.g_varchar2_table(2556) := 'Stanley|Bates|Alvarado|Beck|Ortega|Wade|Estrada|Contreras|Barnett|Caldwell|Santiago|Lambert|Powers|C';
wwv_flow_imp.g_varchar2_table(2557) := 'hambers|Nunez|Craig|Leonard|Lowe|Rhodes|Byrd|Gregory|Shelton|Frazier|Becker|Maldonado|Fleming|Vega|S';
wwv_flow_imp.g_varchar2_table(2558) := 'utton|Cohen|Jennings|Parks|Mcdaniel|Watts|Barker|Norris|Vaughn|Vazquez|Holt|Schwartz|Steele|Benson|N';
wwv_flow_imp.g_varchar2_table(2559) := 'eal|Dominguez|Horton|Terry|Wolfe|Hale|Lyons|Graves|Haynes|Miles|Park|Warner|Padilla|Bush|Thornton|Mc';
wwv_flow_imp.g_varchar2_table(2560) := 'carthy|Mann|Zimmerman|Erickson|Fletcher|Mckinney|Page|Dawson|Joseph|Marquez|Reeves|Klein|Espinoza|Ba';
wwv_flow_imp.g_varchar2_table(2561) := 'ldwin|Moran|Love|Robbins|Higgins|Ball|Cortez|Le|Griffith|Bowen|Sharp|Cummings|Ramsey|Hardy|Swanson|B';
wwv_flow_imp.g_varchar2_table(2562) := 'arber|Acosta|Luna|Chandler|Daniel|Blair|Cross|Simon|Dennis|Oconnor|Quinn|Gross|Navarro|Moss|Fitzgera';
wwv_flow_imp.g_varchar2_table(2563) := 'ld|Doyle|Mclaughlin|Rojas|Rodgers|Stevenson|Singh|Yang|Figueroa|Harmon|Newton|Paul|Manning|Garner|Mc';
wwv_flow_imp.g_varchar2_table(2564) := 'gee|Reese|Francis|Burgess|Adkins|Goodman|Curry|Brady|Christensen|Potter|Walton|Goodwin|Mullins|Molin';
wwv_flow_imp.g_varchar2_table(2565) := 'a|Webster|Fischer|Campos|Avila|Sherman|Todd|Chang|Blake|Malone|Wolf|Hodges|Juarez|Gill|Farmer|Hines|';
wwv_flow_imp.g_varchar2_table(2566) := 'Gallagher|Duran|Hubbard|Cannon|Miranda|Wang|Saunders|Tate|Mack|Hammond|Carrillo|Townsend|Wise|Ingram';
wwv_flow_imp.g_varchar2_table(2567) := '|Barton|Mejia|Ayala|Schroeder|Hampton|Rowe|Parsons|Frank|Waters|Strickland|Osborne|Maxwell|Chan|Dele';
wwv_flow_imp.g_varchar2_table(2568) := 'on|Norman|Harrington|Casey|Patton|Logan|Bowers|Mueller|Glover|Floyd|Hartman|Buchanan|Cobb|French|Kra';
wwv_flow_imp.g_varchar2_table(2569) := 'mer|Mccormick|Clarke|Tyler|Gibbs|Moody|Conner|Sparks|Mcguire|Leon|Bauer|Norton|Pope|Flynn|Hogan|Robl';
wwv_flow_imp.g_varchar2_table(2570) := 'es|Salinas|Yates|Lindsey|Lloyd|Marsh|Mcbride|Owen|Solis|Pham|Lang|Pratt|Lara|Brock|Ballard|Trujillo|';
wwv_flow_imp.g_varchar2_table(2571) := 'Shaffer|Drake|Roman|Aguirre|Morton|Stokes|Lamb|Pacheco|Patrick|Cochran|Shepherd|Cain|Burnett|Hess|Li';
wwv_flow_imp.g_varchar2_table(2572) := '|Cervantes|Olsen|Briggs|Ochoa|Cabrera|Velasquez|Montoya|Roth|Meyers|Cardenas|Fuentes|Weiss|Wilkins|H';
wwv_flow_imp.g_varchar2_table(2573) := 'oover|Nicholson|Underwood|Short|Carson|Morrow|Colon|Holloway|Summers|Bryan|Petersen|Mckenzie|Serrano';
wwv_flow_imp.g_varchar2_table(2574) := '|Wilcox|Carey|Clayton|Poole|Calderon|Gallegos|Greer|Rivas|Guerra|Decker|Collier|Wall|Whitaker|Bass|F';
wwv_flow_imp.g_varchar2_table(2575) := 'lowers|Davenport|Conley|Houston|Huff|Copeland|Hood|Monroe|Massey|Roberson|Combs|Franco|Larsen|Pittma';
wwv_flow_imp.g_varchar2_table(2576) := 'n|Randall|Skinner|Wilkinson|Kirby|Cameron|Bridges|Anthony|Richard|Kirk|Bruce|Singleton|Mathis|Bradfo';
wwv_flow_imp.g_varchar2_table(2577) := 'rd|Boone|Abbott|Charles|Allison|Sweeney|Atkinson|Horn|Jefferson|Rosales|York|Christian|Phelps|Farrel';
wwv_flow_imp.g_varchar2_table(2578) := 'l|Castaneda|Nash|Dickerson|Bond|Wyatt|Foley|Chase|Gates|Vincent|Mathews|Hodge|Garrison|Trevino|Villa';
wwv_flow_imp.g_varchar2_table(2579) := 'rreal|Heath|Dalton|Valencia|Callahan|Hensley|Atkins|Huffman|Roy|Boyer|Shields|Lin|Hancock|Grimes|Gle';
wwv_flow_imp.g_varchar2_table(2580) := 'nn|Cline|Delacruz|Camacho|Dillon|Parrish|Oneill|Melton|Booth|Kane|Berg|Harrell|Pitts|Savage|Wiggins|';
wwv_flow_imp.g_varchar2_table(2581) := 'Brennan|Salas|Marks|Russo|Sawyer|Baxter|Golden|Hutchinson|Liu|Walter|Mcdowell|Wiley|Rich|Humphrey|Jo';
wwv_flow_imp.g_varchar2_table(2582) := 'hns|Koch|Suarez|Hobbs|Beard|Gilmore|Ibarra|Keith|Macias|Khan|Andrade|Ware|Stephenson|Henson|Wilkerso';
wwv_flow_imp.g_varchar2_table(2583) := 'n|Dyer|Mcclure|Blackwell|Mercado|Tanner|Eaton|Clay|Barron|Beasley|Oneal|Small|Preston|Wu|Zamora|Macd';
wwv_flow_imp.g_varchar2_table(2584) := 'onald|Vance|Snow|Mcclain|Stafford|Orozco|Barry|English|Shannon|Kline|Jacobson|Woodard|Huang|Kemp|Mos';
wwv_flow_imp.g_varchar2_table(2585) := 'ley|Prince|Merritt|Hurst|Villanueva|Roach|Nolan|Lam|Yoder|Mccullough|Lester|Santana|Valenzuela|Winte';
wwv_flow_imp.g_varchar2_table(2586) := 'rs|Barrera|Orr|Leach|Berger|Mckee|Strong|Conway|Stein|Whitehead|Bullock|Escobar|Knox|Meadows|Solomon';
wwv_flow_imp.g_varchar2_table(2587) := '|Velez|Odonnell|Kerr|Stout|Blankenship|Browning|Kent|Lozano|Bartlett|Pruitt|Buck|Barr|Gaines|Durham|';
wwv_flow_imp.g_varchar2_table(2588) := 'Gentry|Mcintyre|Sloan|Rocha|Melendez|Herman|Sexton|Moon|Hendricks|Rangel|Stark|Lowery|Hardin|Hull|Se';
wwv_flow_imp.g_varchar2_table(2589) := 'llers|Ellison|Calhoun|Gillespie|Mora|Knapp|Mccall|Morse|Dorsey|Weeks|Nielsen|Livingston|Leblanc|Mcle';
wwv_flow_imp.g_varchar2_table(2590) := 'an|Bradshaw|Glass|Middleton|Buckley|Schaefer|Frost|Howe|House|Mcintosh|Ho|Pennington|Reilly|Hebert|M';
wwv_flow_imp.g_varchar2_table(2591) := 'cfarland|Hickman|Noble|Spears|Conrad|Arias|Galvan|Velazquez|Huynh|Frederick|Randolph|Cantu|Fitzpatri';
wwv_flow_imp.g_varchar2_table(2592) := 'ck|Mahoney|Peck|Villa|Michael|Donovan|Mcconnell|Walls|Boyle|Mayer|Zuniga|Giles|Pineda|Pace|Hurley|Ma';
wwv_flow_imp.g_varchar2_table(2593) := 'ys|Mcmillan|Crosby|Ayers|Case|Bentley|Shepard|Everett|Pugh|David|Mcmahon|Dunlap|Bender|Hahn|Harding|';
wwv_flow_imp.g_varchar2_table(2594) := 'Acevedo|Raymond|Blackburn|Duffy|Landry|Dougherty|Bautista|Shah|Potts|Arroyo|Valentine|Meza|Gould|Vau';
wwv_flow_imp.g_varchar2_table(2595) := 'ghan|Fry|Rush|Avery|Herring|Dodson|Clements|Sampson|Tapia|Bean|Lynn|Crane|Farley|Cisneros|Benton|Ash';
wwv_flow_imp.g_varchar2_table(2596) := 'ley|Mckay|Finley|Best|Blevins|Friedman|Moses|Sosa|Blanchard|Huber|Frye|Krueger|Bernard|Rosario|Rubio';
wwv_flow_imp.g_varchar2_table(2597) := '|Mullen|Benjamin|Haley|Chung|Moyer|Choi|Horne|Yu|Woodward|Ali|Nixon|Hayden|Rivers|Estes|Mccarty|Rich';
wwv_flow_imp.g_varchar2_table(2598) := 'mond|Stuart|Maynard|Brandt|Oconnell|Hanna|Sanford|Sheppard|Church|Burch|Levy|Rasmussen|Coffey|Ponce|';
wwv_flow_imp.g_varchar2_table(2599) := 'Faulkner|Donaldson|Schmitt|Novak|Costa|Montes|Booker|Cordova|Waller|Arellano|Maddox|Mata|Bonilla|Sta';
wwv_flow_imp.g_varchar2_table(2600) := 'nton|Compton|Kaufman|Dudley|Mcpherson|Beltran|Dickson|Mccann|Villegas|Proctor|Hester|Cantrell|Daughe';
wwv_flow_imp.g_varchar2_table(2601) := 'rty|Cherry|Bray|Davila|Rowland|Madden|Levine|Spence|Good|Irwin|Werner|Krause|Petty|Whitney|Baird|Hoo';
wwv_flow_imp.g_varchar2_table(2602) := 'per|Pollard|Zavala|Jarvis|Holden|Hendrix|Haas|Mcgrath|Bird|Lucero|Terrell|Riggs|Joyce|Rollins|Mercer';
wwv_flow_imp.g_varchar2_table(2603) := '|Galloway|Duke|Odom|Andersen|Downs|Hatfield|Benitez|Archer|Huerta|Travis|Mcneil|Hinton|Zhang|Hays|Ma';
wwv_flow_imp.g_varchar2_table(2604) := 'yo|Fritz|Branch|Mooney|Ewing|Ritter|Esparza|Frey|Braun|Gay|Riddle|Haney|Kaiser|Holder|Chaney|Mcknigh';
wwv_flow_imp.g_varchar2_table(2605) := 't|Gamble|Vang|Cooley|Carney|Cowan|Forbes|Ferrell|Davies|Barajas|Shea|Osborn|Bright|Cuevas|Bolton|Mur';
wwv_flow_imp.g_varchar2_table(2606) := 'illo|Lutz|Duarte|Kidd|Key|Cooke|Winter|Metcalfe|Howells|Hartley|Tomlinson|Rees|Wallis|Barlow|Whiteho';
wwv_flow_imp.g_varchar2_table(2607) := 'use|Griffiths|Iqbal|O''''Neill|Lees|Browne|Dale|Connor|Daly|Burrows|Fraser|Marsden|Humphries|O''''Brien|';
wwv_flow_imp.g_varchar2_table(2608) := 'Lord|Akhtar|Birch|Kay|O''''Connor|Chamberlain|Thorpe|Dobson|Pritchard|Sharpe|Hussain|Hodgson|Parkes|Br';
wwv_flow_imp.g_varchar2_table(2609) := 'ookes|Herbert|Sinclair|McLean|Storey|Turnbull|Butcher|Godfrey|Dodd|Hargreaves|Connolly|Charlton|Hyde';
wwv_flow_imp.g_varchar2_table(2610) := '|McCarthy|Dickinson|North|Byrne|Ahmed|Gibbons|Rowley|Allan|Sanderson|Davison|Field|Pickering|Mahmood';
wwv_flow_imp.g_varchar2_table(2611) := '|Sykes|Parkin|Power|Nicholls|Morley|O''''Sullivan|Weston|Whittaker|Ashton|Kaur|Parry|Naylor|Humphreys|';
wwv_flow_imp.g_varchar2_table(2612) := 'Bevan|Doherty|Swift|Pearce|Mellor|John|Talbot|Bibi|Houghton|Mistry|Donnelly|Parkinson|Thomson|Miah|S';
wwv_flow_imp.g_varchar2_table(2613) := 'later|Knowles|Goddard|Hope|Rahman|Davey|Peacock|Read|Hilton|O''''Donnell|McKenzie|Greenwood|Coles|Fors';
wwv_flow_imp.g_varchar2_table(2614) := 'ter|Gough|Law|Cartwright|Finch|Smart|Bull|Gardiner|Chadwick|Begum|McDonald|Howarth|Hewitt|Hayward|Sc';
wwv_flow_imp.g_varchar2_table(2615) := 'hofield|Robson|Coates|MacDonald|McKay|Patchett|Boyce|Jamieson|Pedersen|Currie|McEwen|Wilton|Millar|C';
wwv_flow_imp.g_varchar2_table(2616) := 'resswell|Holdaway|Hodson|McCallum|Woolley|McLeod|Tapp|Cooksley|McGregor|McMillan|Dick|Greig|Forrest|';
wwv_flow_imp.g_varchar2_table(2617) := 'MacKenzie|Stratford|Watt|Andrew|Gore|Healy|Munro|Hills|Vercoe|Collis|Ritchie|Freeth|Nicol|Satherley|';
wwv_flow_imp.g_varchar2_table(2618) := 'Waugh|Coley|Herd|Beattie|Clifford|Costello|Hay|Jellyman|Joe|Johansen|Donald|Gilchrist|McIntosh|Paton';
wwv_flow_imp.g_varchar2_table(2619) := '|Robb|Rutherford|Pike|Drummond|Hickey|Judd|Kenny|Low|Marfell|O''''Leary|Ham|McIntyre|O''''Connell|Irelan';
wwv_flow_imp.g_varchar2_table(2620) := 'd|Perano|Sowman|Whyte|Eden|Hoare|MacKay|McKinnon|Mears|Prentice|Schwass|Simonsen|Wratt|Bishell|Chris';
wwv_flow_imp.g_varchar2_table(2621) := 'tiansen|Fulton|Hook|McGill|Rayner|Craven|Ellery|Findlay|Reardon|Tait|Flood|Gifford|Guy|Leslie|McMaho';
wwv_flow_imp.g_varchar2_table(2622) := 'n|McNabb|Paterson|Seymour|Trask|Wills|Dawick|Gledhill|Kendall|McCormick|McPherson|Shailer|Sheridan|S';
wwv_flow_imp.g_varchar2_table(2623) := 'immonds|Edmonds|Gunn|Laurenson|Manson|McGrath|McKenna|Muir|O''''Keefe|Searle|Stubbs|Furness|Jefferies|';
wwv_flow_imp.g_varchar2_table(2624) := 'Johnstone|Linton|Rowlands|Cragg|Gee|Gleeson|Gullery|Hadfield|Haines|Hepburn|Jeffries|MacPherson|McIs';
wwv_flow_imp.g_varchar2_table(2625) := 'aac|Millard|Prouse|Ramsay|Spelman|Waghorn|Aitken|Burrell|Burt|Funnell|Guthrie|Hogg|Lammas|McDowall|N';
wwv_flow_imp.g_varchar2_table(2626) := 'eilson|Rickard|Stratton|Strawbridge|Alve|Baldick|Bowden|Craw|Cumming|Drew|Fairhall|Gillies|Healey|La';
wwv_flow_imp.g_varchar2_table(2627) := 'ncaster|Mortimer|Sixtus|Aldridge|Allerby|Blick|Boon|Bowater|Broughan|Foote|Forsyth|Laing|McFarlane|M';
wwv_flow_imp.g_varchar2_table(2628) := 'cMurray|Monk|Procter|Southee|Stace|Webby|Arnott|Bary|Bassett|Claridge|Croad|Ewart|Fenton|Gibb|Huddle';
wwv_flow_imp.g_varchar2_table(2629) := 'ston|McLachlan|Middlemiss|Mudgway|Nicholas|Reader|Robert|Steer|Toms|Twidle|Way|Batchelar|Boniface|Bo';
wwv_flow_imp.g_varchar2_table(2630) := 'tham|Buick|Ching|Christie|Corlett|Coutts|Eglinton|Enright|Foot|Gaskin|Hardie|Hoskins|Learmonth|Mathe';
wwv_flow_imp.g_varchar2_table(2631) := 'son|McManaway|Meads|Meredith|Murdoch|Orchard|Perrin|Priest|Rossiter|Shand|Soper|Street|Aberhart|Berk';
wwv_flow_imp.g_varchar2_table(2632) := 'ahn|Burr|Cairns|Corbett|Dalziel|Esson|Farland|Guard|Hume|Irving|Jacques|Lyon'';'||wwv_flow.LF||
'    for i in 1..l_nam';
wwv_flow_imp.g_varchar2_table(2633) := 'e_group_count loop'||wwv_flow.LF||
'      l_first_name_pool_size_by_group(i) := load_name_catalog('||wwv_flow.LF||
'        l_first_na';
wwv_flow_imp.g_varchar2_table(2634) := 'me_catalog(i),'||wwv_flow.LF||
'        name_group_code(i),'||wwv_flow.LF||
'        l_first_name_pool'||wwv_flow.LF||
'      );'||wwv_flow.LF||
'      l_last_name_pool';
wwv_flow_imp.g_varchar2_table(2635) := '_size_by_group(i) := load_name_catalog('||wwv_flow.LF||
'        l_last_name_catalog(i),'||wwv_flow.LF||
'        name_group_code(i),'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2636) := '        l_last_name_pool'||wwv_flow.LF||
'      );'||wwv_flow.LF||
'      l_first_name_next(i) := 1;'||wwv_flow.LF||
'      l_last_name_next(i) := 1;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(2637) := '     reset_name_order(l_first_name_order, l_first_name_pool_size_by_group, i);'||wwv_flow.LF||
'      reset_name_orde';
wwv_flow_imp.g_varchar2_table(2638) := 'r(l_last_name_order, l_last_name_pool_size_by_group, i);'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    for i in 1..g_cost_cente';
wwv_flow_imp.g_varchar2_table(2639) := 'r_names.count loop'||wwv_flow.LF||
'      select min(cost_center_id)'||wwv_flow.LF||
'        into l_cost_center_id(i)'||wwv_flow.LF||
'        from eb';
wwv_flow_imp.g_varchar2_table(2640) := 'a_srch_txt_cost_centers'||wwv_flow.LF||
'       where cost_center_description = g_cost_center_names(i);'||wwv_flow.LF||
''||wwv_flow.LF||
'      if l_c';
wwv_flow_imp.g_varchar2_table(2641) := 'ost_center_id(i) is not null then'||wwv_flow.LF||
'        l_cost_center_count := l_cost_center_count + 1;'||wwv_flow.LF||
'      end ';
wwv_flow_imp.g_varchar2_table(2642) := 'if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_cost_center_count = 0 and p_num_rows > 0 then'||wwv_flow.LF||
'      raise_application_er';
wwv_flow_imp.g_varchar2_table(2643) := 'ror(-20004, ''seed_employees requires seeded cost centers. Run seed_cost_centers(30) first.'');'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(2644) := 'd if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    for i in 1..g_group_names.count loop'||wwv_flow.LF||
'      select min(group_id)'||wwv_flow.LF||
'        into l_group_id(i';
wwv_flow_imp.g_varchar2_table(2645) := ')'||wwv_flow.LF||
'        from eba_srch_txt_groups'||wwv_flow.LF||
'       where group_name = g_group_names(i);'||wwv_flow.LF||
''||wwv_flow.LF||
'      if l_group_id(';
wwv_flow_imp.g_varchar2_table(2646) := 'i) is not null then'||wwv_flow.LF||
'        l_group_count := l_group_count + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    for';
wwv_flow_imp.g_varchar2_table(2647) := ' i in 1..l_country_count loop'||wwv_flow.LF||
'      l_total_weight := l_total_weight + l_country_weight(i);'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(2648) := 'loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    for i in 1..l_country_count loop'||wwv_flow.LF||
'      l_country_target(i) := trunc(p_num_rows * l_countr';
wwv_flow_imp.g_varchar2_table(2649) := 'y_weight(i) / l_total_weight);'||wwv_flow.LF||
'      l_country_fraction(i) := (p_num_rows * l_country_weight(i) / l_';
wwv_flow_imp.g_varchar2_table(2650) := 'total_weight) - l_country_target(i);'||wwv_flow.LF||
'      l_assigned_rows := l_assigned_rows + l_country_target(i);';
wwv_flow_imp.g_varchar2_table(2651) := ''||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_remaining_rows := p_num_rows - l_assigned_rows;'||wwv_flow.LF||
'    while l_remaining_rows > 0';
wwv_flow_imp.g_varchar2_table(2652) := ' loop'||wwv_flow.LF||
'      l_best_country := 1;'||wwv_flow.LF||
'      l_best_fraction := -1;'||wwv_flow.LF||
''||wwv_flow.LF||
'      for i in 1..l_country_count loo';
wwv_flow_imp.g_varchar2_table(2653) := 'p'||wwv_flow.LF||
'        if l_country_fraction(i) > l_best_fraction then'||wwv_flow.LF||
'          l_best_country := i;'||wwv_flow.LF||
'          l';
wwv_flow_imp.g_varchar2_table(2654) := '_best_fraction := l_country_fraction(i);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'      l_country_target(l_b';
wwv_flow_imp.g_varchar2_table(2655) := 'est_country) := l_country_target(l_best_country) + 1;'||wwv_flow.LF||
'      l_country_fraction(l_best_country) := -1';
wwv_flow_imp.g_varchar2_table(2656) := ';'||wwv_flow.LF||
'      l_remaining_rows := l_remaining_rows - 1;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    for i in 1..l_country_count loo';
wwv_flow_imp.g_varchar2_table(2657) := 'p'||wwv_flow.LF||
'      if l_country_target(i) > 0 then'||wwv_flow.LF||
'        for j in 1..l_country_target(i) loop'||wwv_flow.LF||
'          l_seq';
wwv_flow_imp.g_varchar2_table(2658) := 'uence_no := l_sequence_no + 1;'||wwv_flow.LF||
'          l_employee_country(l_sequence_no) := i;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(2659) := '     end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_num_rows > 1 then'||wwv_flow.LF||
'      for i in reverse 2..p_num_rows loop'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2660) := '     l_swap_no := trunc(dbms_random.value(1, i + 1));'||wwv_flow.LF||
'        l_country_no := l_employee_country(i);';
wwv_flow_imp.g_varchar2_table(2661) := ''||wwv_flow.LF||
'        l_employee_country(i) := l_employee_country(l_swap_no);'||wwv_flow.LF||
'        l_employee_country(l_swap_n';
wwv_flow_imp.g_varchar2_table(2662) := 'o) := l_country_no;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_num_rows > 0 then'||wwv_flow.LF||
'      l_swap_no := 0;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(2663) := '    for i in 1..p_num_rows loop'||wwv_flow.LF||
'        if l_employee_country(i) = 1 then'||wwv_flow.LF||
'          l_swap_no := i;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2664) := '          exit;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if l_swap_no > 1 then'||wwv_flow.LF||
'        l_country_no :=';
wwv_flow_imp.g_varchar2_table(2665) := ' l_employee_country(1);'||wwv_flow.LF||
'        l_employee_country(1) := l_employee_country(l_swap_no);'||wwv_flow.LF||
'        l_em';
wwv_flow_imp.g_varchar2_table(2666) := 'ployee_country(l_swap_no) := l_country_no;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_num_rows > 0 then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2667) := '   for i in 1..p_num_rows loop'||wwv_flow.LF||
'        l_country_no := l_employee_country(i);'||wwv_flow.LF||
'        l_first_name :';
wwv_flow_imp.g_varchar2_table(2668) := '= pick_first_name(l_name_group(l_country_no));'||wwv_flow.LF||
'        l_last_name := pick_last_name(l_name_group(l_';
wwv_flow_imp.g_varchar2_table(2669) := 'country_no));'||wwv_flow.LF||
'        l_first_identifier := normalize_identifier(l_first_name);'||wwv_flow.LF||
'        l_last_ident';
wwv_flow_imp.g_varchar2_table(2670) := 'ifier := normalize_identifier(l_last_name);'||wwv_flow.LF||
'        l_cost_center_no := choose_cost_center(l_country';
wwv_flow_imp.g_varchar2_table(2671) := '_no);'||wwv_flow.LF||
'        l_city := pick_city(l_country_no);'||wwv_flow.LF||
'        l_region := pick_region(l_country_no);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(2672) := '    l_phone_country_code := pick_phone_country_code(l_country_no);'||wwv_flow.LF||
'        l_phone_number := to_char';
wwv_flow_imp.g_varchar2_table(2673) := '(trunc(dbms_random.value(100000000, 999999999)));'||wwv_flow.LF||
'        l_email := l_first_identifier || ''.'' || l_';
wwv_flow_imp.g_varchar2_table(2674) := 'last_identifier || ''.'' || to_char(i) || ''@example.invalid'';'||wwv_flow.LF||
'        l_user_id := l_first_identifier ';
wwv_flow_imp.g_varchar2_table(2675) := '|| ''.'' || l_last_identifier || to_char(i);'||wwv_flow.LF||
'        l_selected_manager_id := null;'||wwv_flow.LF||
'        l_employee';
wwv_flow_imp.g_varchar2_table(2676) := '_groups := null;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if i = 1 then'||wwv_flow.LF||
'          l_cost_center_no := 1;'||wwv_flow.LF||
'          l_job_title := ''C';
wwv_flow_imp.g_varchar2_table(2677) := 'hief Executive Officer'';'||wwv_flow.LF||
'          l_career_level := ''Executive'';'||wwv_flow.LF||
'          l_is_manager := true;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(2678) := '      else'||wwv_flow.LF||
'          l_job_title := pick_job_title(l_cost_center_no);'||wwv_flow.LF||
'          l_career_level := pi';
wwv_flow_imp.g_varchar2_table(2679) := 'ck_career_level(l_cost_center_no);'||wwv_flow.LF||
'          l_is_manager := false;'||wwv_flow.LF||
''||wwv_flow.LF||
'          if instr(l_job_title,';
wwv_flow_imp.g_varchar2_table(2680) := ' ''Manager'') > 0'||wwv_flow.LF||
'             or instr(l_job_title, ''Director'') > 0'||wwv_flow.LF||
'             or instr(l_job_title';
wwv_flow_imp.g_varchar2_table(2681) := ', ''Chief'') > 0'||wwv_flow.LF||
'             or instr(l_job_title, ''Lead'') > 0'||wwv_flow.LF||
'             or instr(l_job_title, ''Ar';
wwv_flow_imp.g_varchar2_table(2682) := 'chitect'') > 0 then'||wwv_flow.LF||
'            l_is_manager := true;'||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'          l_selected_manager';
wwv_flow_imp.g_varchar2_table(2683) := '_id := choose_manager_id(l_country_no);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_is_manager then'||wwv_flow.LF||
'          l_di';
wwv_flow_imp.g_varchar2_table(2684) := 'rect_reports := trunc(dbms_random.value(2, 13));'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'          l_direct_reports := 0;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(2685) := '   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        select'||wwv_flow.LF||
'          json_object('||wwv_flow.LF||
'            ''employee_number'' value i,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(2686) := ' ''country'' value l_country_name(l_country_no),'||wwv_flow.LF||
'            ''seed_source'' value ''demo_seed_data'''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(2687) := '        returning json'||wwv_flow.LF||
'          ),'||wwv_flow.LF||
'          json_array('||wwv_flow.LF||
'            ''seeded'','||wwv_flow.LF||
'            ''demo'','||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2688) := '            lower(l_name_group(l_country_no))'||wwv_flow.LF||
'            returning json'||wwv_flow.LF||
'          )'||wwv_flow.LF||
'        into l_';
wwv_flow_imp.g_varchar2_table(2689) := 'profile, l_tags'||wwv_flow.LF||
'        from sys.dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_is_manager then'||wwv_flow.LF||
'          l_manager_count := l_';
wwv_flow_imp.g_varchar2_table(2690) := 'manager_count + 1;'||wwv_flow.LF||
'          l_manager_id(l_manager_count) := l_employee_id;'||wwv_flow.LF||
'          l_manager_cou';
wwv_flow_imp.g_varchar2_table(2691) := 'ntry(l_manager_count) := l_country_no;'||wwv_flow.LF||
''||wwv_flow.LF||
'          if not l_manager_count_by_country.exists(l_country';
wwv_flow_imp.g_varchar2_table(2692) := '_no) then'||wwv_flow.LF||
'            l_manager_count_by_country(l_country_no) := 0;'||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
'          l_m';
wwv_flow_imp.g_varchar2_table(2693) := 'anager_count_by_country(l_country_no) :='||wwv_flow.LF||
'            l_manager_count_by_country(l_country_no) + 1;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(2694) := '         l_manager_by_country('||wwv_flow.LF||
'            ''C:'' || to_char(l_country_no) || '':'' ||'||wwv_flow.LF||
'            to_ch';
wwv_flow_imp.g_varchar2_table(2695) := 'ar(l_manager_count_by_country(l_country_no))'||wwv_flow.LF||
'          ) := l_employee_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'          l_region_no :=';
wwv_flow_imp.g_varchar2_table(2696) := ' region_index(l_country_no);'||wwv_flow.LF||
'          if not l_manager_count_by_region.exists(l_region_no) then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2697) := '         l_manager_count_by_region(l_region_no) := 0;'||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
'          l_manager_count_by';
wwv_flow_imp.g_varchar2_table(2698) := '_region(l_region_no) :='||wwv_flow.LF||
'            l_manager_count_by_region(l_region_no) + 1;'||wwv_flow.LF||
'          l_manager_';
wwv_flow_imp.g_varchar2_table(2699) := 'by_region('||wwv_flow.LF||
'            ''R:'' || to_char(l_region_no) || '':'' ||'||wwv_flow.LF||
'            to_char(l_manager_count_by';
wwv_flow_imp.g_varchar2_table(2700) := '_region(l_region_no))'||wwv_flow.LF||
'          ) := l_employee_id;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_group_count > 0 th';
wwv_flow_imp.g_varchar2_table(2701) := 'en'||wwv_flow.LF||
'          l_membership_count := trunc(dbms_random.value(0, 4));'||wwv_flow.LF||
'          if l_membership_count >';
wwv_flow_imp.g_varchar2_table(2702) := ' 0 then'||wwv_flow.LF||
'            for j in 1..l_membership_count loop'||wwv_flow.LF||
'              l_group_no := trunc(dbms_rando';
wwv_flow_imp.g_varchar2_table(2703) := 'm.value(1, l_group_count + 1));'||wwv_flow.LF||
'              l_employee_groups := l_employee_groups'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(2704) := '                 || case when l_employee_groups is not null then '','' end'||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(2705) := '     || l_group_id(l_group_no) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        c';
wwv_flow_imp.g_varchar2_table(2706) := 'reate_employee('||wwv_flow.LF||
'          p_first_name => l_first_name,'||wwv_flow.LF||
'          p_last_name => l_last_name,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(2707) := '    p_email => l_email,'||wwv_flow.LF||
'          p_user_id => l_user_id,'||wwv_flow.LF||
'          p_country => l_country_name(l_co';
wwv_flow_imp.g_varchar2_table(2708) := 'untry_no),'||wwv_flow.LF||
'          p_country_code => l_country_code( l_country_no ),'||wwv_flow.LF||
'          p_geographic_region';
wwv_flow_imp.g_varchar2_table(2709) := ' => l_region,'||wwv_flow.LF||
'          p_city => l_city,'||wwv_flow.LF||
'          p_career_level => l_career_level,'||wwv_flow.LF||
'          p_jo';
wwv_flow_imp.g_varchar2_table(2710) := 'b_title => l_job_title,'||wwv_flow.LF||
'          p_cost_center_id => resolve_cost_center_id(l_cost_center_no),'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(2711) := '      p_manager_id => l_selected_manager_id,'||wwv_flow.LF||
'          p_org_size => p_num_rows,'||wwv_flow.LF||
'          p_direct_';
wwv_flow_imp.g_varchar2_table(2712) := 'reports => l_direct_reports,'||wwv_flow.LF||
'          p_phone_country_code => l_phone_country_code,'||wwv_flow.LF||
'          p_pho';
wwv_flow_imp.g_varchar2_table(2713) := 'ne_number => l_phone_number,'||wwv_flow.LF||
'          p_profile => l_profile,'||wwv_flow.LF||
'          p_tags => l_tags,'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(2714) := ' p_employee_groups => ''['' || l_employee_groups || '']'','||wwv_flow.LF||
'          p_permalink => ''https://example.inv';
wwv_flow_imp.g_varchar2_table(2715) := 'alid/people/'' || to_char(i),'||wwv_flow.LF||
'          p_timezone => pick_timezone(l_country_no, l_city),'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(2716) := 'p_created_employee_id => l_employee_id'||wwv_flow.LF||
'        );'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  end seed_employees;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2717) := ''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  initialize_reference_data;'||wwv_flow.LF||
'end eba_search_text_data;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2243976003893122224)
,p_install_id=>wwv_flow_imp.id(2198361304136574490)
,p_name=>'eba_search_text_data body'
,p_sequence=>31
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
