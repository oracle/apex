prompt --application/deployment/install/install_eba_search_text_helper_spec
begin
--   Manifest
--     INSTALL: INSTALL-eba_search_text_helper spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_search_text_helper authid current_user is '||wwv_flow.LF||
' '||wwv_flow.LF||
'type t_config_column is r';
wwv_flow_imp.g_varchar2_table(2) := 'ecord( '||wwv_flow.LF||
'    expression              varchar2(4000), '||wwv_flow.LF||
'    --          '||wwv_flow.LF||
'    alias                   va';
wwv_flow_imp.g_varchar2_table(3) := 'rchar2(255), '||wwv_flow.LF||
'    pattern                 varchar2(255), '||wwv_flow.LF||
'    priority                pls_integer   ';
wwv_flow_imp.g_varchar2_table(4) := ' default 1, '||wwv_flow.LF||
'    --          '||wwv_flow.LF||
'    visible                 boolean        default false, '||wwv_flow.LF||
'    field_s';
wwv_flow_imp.g_varchar2_table(5) := 'earch            boolean        default true, '||wwv_flow.LF||
'    two_char_terms_enabled  boolean        default fa';
wwv_flow_imp.g_varchar2_table(6) := 'lse,         '||wwv_flow.LF||
'    ndata_search            boolean        default false, '||wwv_flow.LF||
'    sdata_search           ';
wwv_flow_imp.g_varchar2_table(7) := ' boolean        default false, '||wwv_flow.LF||
'    sdata_op                varchar2(255)  default ''='', '||wwv_flow.LF||
'    sdata_d';
wwv_flow_imp.g_varchar2_table(8) := 'atatype          varchar2(128)  default null, '||wwv_flow.LF||
'    --          '||wwv_flow.LF||
'    score_expr              varchar2';
wwv_flow_imp.g_varchar2_table(9) := '(4000) ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'type t_config_table is table of t_config_column index by varchar2(255); '||wwv_flow.LF||
' '||wwv_flow.LF||
'--==========';
wwv_flow_imp.g_varchar2_table(10) := '==================================================================== '||wwv_flow.LF||
'-- creates the Oracle Text Ind';
wwv_flow_imp.g_varchar2_table(11) := 'ex with all its preferences based on the '||wwv_flow.LF||
'-- passed configuration records. '||wwv_flow.LF||
'--======================';
wwv_flow_imp.g_varchar2_table(12) := '======================================================== '||wwv_flow.LF||
'procedure create_text_index( '||wwv_flow.LF||
'    p_table_';
wwv_flow_imp.g_varchar2_table(13) := 'name      in varchar2, '||wwv_flow.LF||
'    p_index_name      in varchar2, '||wwv_flow.LF||
'    p_index_column    in varchar2, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(14) := '-- '||wwv_flow.LF||
'    p_config          in t_config_table ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'--================================================';
wwv_flow_imp.g_varchar2_table(15) := '============================== '||wwv_flow.LF||
'-- drops the Oracle Text Index with all its preferences. '||wwv_flow.LF||
'--========';
wwv_flow_imp.g_varchar2_table(16) := '====================================================================== '||wwv_flow.LF||
'procedure drop_text_index( '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(17) := '    p_index_name      in varchar2 ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'--==========================================================';
wwv_flow_imp.g_varchar2_table(18) := '==================== '||wwv_flow.LF||
'-- creates the Oracle Text Index with all its preferences based on the '||wwv_flow.LF||
'-- pas';
wwv_flow_imp.g_varchar2_table(19) := 'sed configuration records. '||wwv_flow.LF||
'--======================================================================';
wwv_flow_imp.g_varchar2_table(20) := '======== '||wwv_flow.LF||
'function search_query( '||wwv_flow.LF||
'    p_table_name        in varchar2, '||wwv_flow.LF||
'    p_index_column      in v';
wwv_flow_imp.g_varchar2_table(21) := 'archar2, '||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    p_config            in t_config_table, '||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    p_search_expression in var';
wwv_flow_imp.g_varchar2_table(22) := 'char2 ) '||wwv_flow.LF||
'    return varchar2; '||wwv_flow.LF||
' '||wwv_flow.LF||
'--=================================================================';
wwv_flow_imp.g_varchar2_table(23) := '============= '||wwv_flow.LF||
'function get_config return eba_search_text_helper.t_config_table; '||wwv_flow.LF||
' '||wwv_flow.LF||
'--==============';
wwv_flow_imp.g_varchar2_table(24) := '================================================================ '||wwv_flow.LF||
'-- Returns a NAME search query on ';
wwv_flow_imp.g_varchar2_table(25) := 'the EBA_DEMO_IG_PEOPLE table, with the '||wwv_flow.LF||
'-- following configuration. '||wwv_flow.LF||
'-- '||wwv_flow.LF||
'-- eba_search_text_helper.s';
wwv_flow_imp.g_varchar2_table(26) := 'earch_query( '||wwv_flow.LF||
'--     p_table_name        => ''EBA_DEMO_IG_PEOPLE'', '||wwv_flow.LF||
'--     p_index_column      => ''NA';
wwv_flow_imp.g_varchar2_table(27) := 'ME'', '||wwv_flow.LF||
'--     p_search_expression => p_search_expression, '||wwv_flow.LF||
'--     p_config            => eba_search_t';
wwv_flow_imp.g_varchar2_table(28) := 'ext_helper.t_config_table( '||wwv_flow.LF||
'--                                ''NAME''    => eba_search_text_helper.t_';
wwv_flow_imp.g_varchar2_table(29) := 'config_column( '||wwv_flow.LF||
'--                                                  field_search => true, '||wwv_flow.LF||
'--       ';
wwv_flow_imp.g_varchar2_table(30) := '                                           ndata_search => true, '||wwv_flow.LF||
'--                                ';
wwv_flow_imp.g_varchar2_table(31) := '                  priority     => 1 ), '||wwv_flow.LF||
'--                                ''COUNTRY''  => eba_search_t';
wwv_flow_imp.g_varchar2_table(32) := 'ext_helper.t_config_column( '||wwv_flow.LF||
'--                                                  priority     => 2, ';
wwv_flow_imp.g_varchar2_table(33) := ''||wwv_flow.LF||
'--                                                  score_expr   => ''*0''), '||wwv_flow.LF||
'--                     ';
wwv_flow_imp.g_varchar2_table(34) := '           ''CATEGORY'' => eba_search_text_helper.t_config_column( '||wwv_flow.LF||
'--                                ';
wwv_flow_imp.g_varchar2_table(35) := '                  priority     => 2, '||wwv_flow.LF||
'--                                                  score_expr';
wwv_flow_imp.g_varchar2_table(36) := '   => ''*0'') ) ) ) '||wwv_flow.LF||
'--============================================================================== ';
wwv_flow_imp.g_varchar2_table(37) := ''||wwv_flow.LF||
'function get_name_search_query( '||wwv_flow.LF||
'    p_search_expression in varchar2 ) '||wwv_flow.LF||
'    return varchar2; '||wwv_flow.LF||
' '||wwv_flow.LF||
'end';
wwv_flow_imp.g_varchar2_table(38) := ' eba_search_text_helper;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2198362310767587211)
,p_install_id=>wwv_flow_imp.id(2198361304136574490)
,p_name=>'eba_search_text_helper spec'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
