prompt --application/deployment/install/install_eba_search_text_helper_body
begin
--   Manifest
--     INSTALL: INSTALL-eba_search_text_helper body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body eba_search_text_helper   '||wwv_flow.LF||
'is   '||wwv_flow.LF||
'    type t_existing_columns is table ';
wwv_flow_imp.g_varchar2_table(2) := 'of varchar2(255) index by varchar2(255);   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    LF               constant varchar2(1 char) := un';
wwv_flow_imp.g_varchar2_table(3) := 'istr(''\000a'');   '||wwv_flow.LF||
'    c_suffix_sg      constant varchar2(3)      := ''_SG'';   '||wwv_flow.LF||
'    c_suffix_uds     c';
wwv_flow_imp.g_varchar2_table(4) := 'onstant varchar2(4)      := ''_UDS'';   '||wwv_flow.LF||
'    c_suffix_ds      constant varchar2(3)      := ''_DS'';   '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(5) := '   c_suffix_lx      constant varchar2(3)      := ''_LX'';   '||wwv_flow.LF||
'    c_suffix_wl      constant varchar2(3)';
wwv_flow_imp.g_varchar2_table(6) := '      := ''_WL'';   '||wwv_flow.LF||
'    c_suffix_idx     constant varchar2(4)      := ''_IDX'';   '||wwv_flow.LF||
'    c_prefix_idx    ';
wwv_flow_imp.g_varchar2_table(7) := ' constant varchar2(3)      := ''FT_'';   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    c_suffix_f       constant varchar2(2)      := ''_F''; ';
wwv_flow_imp.g_varchar2_table(8) := '  '||wwv_flow.LF||
'    c_suffix_sd      constant varchar2(3)      := ''_SD'';   '||wwv_flow.LF||
'    c_suffix_nd      constant varchar';
wwv_flow_imp.g_varchar2_table(9) := '2(3)      := ''_ND'';   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    c_index_memory   constant varchar2(4)      := ''500M'';   '||wwv_flow.LF||
'  '||wwv_flow.LF||
'    c_cit';
wwv_flow_imp.g_varchar2_table(10) := 'ies_list    constant apex_t_varchar2  := apex_t_varchar2(  '||wwv_flow.LF||
'                                        ';
wwv_flow_imp.g_varchar2_table(11) := '              ''( Seattle | New York | Auckland | Pune | Turin | Barcelona | Alexandria | Chicago | U';
wwv_flow_imp.g_varchar2_table(12) := 'trecht | Santiago | Beijing | Izmir | Basel | Helsinki | Osaka | Tel Aviv | Mexico City | Melbourne ';
wwv_flow_imp.g_varchar2_table(13) := '| Davao City | Sao Paulo | Montreal | Monterrey | Singapore | Kowloon | Hyderabad | Dublin | Bengalu';
wwv_flow_imp.g_varchar2_table(14) := 'ru | Cape Town | Munich | Guadalajara | Johor Bahru | Istanbul | Bogota | Graz | Espoo | Tampere | V';
wwv_flow_imp.g_varchar2_table(15) := 'ienna | Manchester | Prague | Penang | Krakow | Shanghai | Toronto | Frankfurt | Toulouse | Kisumu )';
wwv_flow_imp.g_varchar2_table(16) := ''','||wwv_flow.LF||
'                                                      ''( Paris | Edinburgh | Geneva | Antwerp | M';
wwv_flow_imp.g_varchar2_table(17) := 'anila | Madrid | Rio de Janeiro | Nairobi | Lisbon | Giza | Ankara | Ghent | Galway | Cork | London ';
wwv_flow_imp.g_varchar2_table(18) := '| Stockholm | Ostrava | Vancouver | Trondheim | Shenzhen | Tampines | Brisbane | Nagoya | Berlin | C';
wwv_flow_imp.g_varchar2_table(19) := 'ordoba | Seoul | Port Harcourt | Wroclaw | Braga | Abu Dhabi | Incheon | Amsterdam | Malmo | Porto |';
wwv_flow_imp.g_varchar2_table(20) := ' Zurich | Gothenburg | Tokyo | Abuja | Brussels | Rome | Christchurch | Concepcion | Warsaw | Curiti';
wwv_flow_imp.g_varchar2_table(21) := 'ba | Dubai | Debrecen | Oslo | Sharjah )'','||wwv_flow.LF||
'                                                      ''( ';
wwv_flow_imp.g_varchar2_table(22) := 'Budapest | Aarhus | Cali | Szeged | Jurong East | Patras | Cluj-Napoca | Cebu City | Sha Tin | Durba';
wwv_flow_imp.g_varchar2_table(23) := 'n | Milan | Kuala Lumpur | Cairo | Jerusalem | Odense | Lyon | Esch-sur-Alzette | Haifa | Buenos Air';
wwv_flow_imp.g_varchar2_table(24) := 'es | Copenhagen | Luxembourg City | Valencia | Rotterdam | Lagos | Johannesburg | Bucharest | Salzbu';
wwv_flow_imp.g_varchar2_table(25) := 'rg | Timisoara | Sydney | Athens | Rosario | Wellington | Thessaloniki | Differdange | Busan | Hong ';
wwv_flow_imp.g_varchar2_table(26) := 'Kong | Valparaiso )'');'||wwv_flow.LF||
'    c_countries_list constant apex_t_varchar2  := apex_t_varchar2( '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(27) := '                                             ''( Poland | United States | India | France | United Ara';
wwv_flow_imp.g_varchar2_table(28) := 'b Emirates | Japan | Nigeria | South Africa | Luxembourg | Mexico | Denmark | Netherlands | Portugal';
wwv_flow_imp.g_varchar2_table(29) := ' | Greece | Switzerland | Sweden | Colombia | New Zealand | Germany | Canada | Malaysia | Brazil | H';
wwv_flow_imp.g_varchar2_table(30) := 'ungary | Israel | Australia | Finland | Spain | Italy | Czechia | United Kingdom | Ireland | Turkey ';
wwv_flow_imp.g_varchar2_table(31) := '| Egypt | China | Belgium | Argentina | Philippines | Singapore | Norway | Kenya | Romania | South K';
wwv_flow_imp.g_varchar2_table(32) := 'orea | Chile | Austria | Hong Kong )'' ); '||wwv_flow.LF||
''||wwv_flow.LF||
'--=======================================================';
wwv_flow_imp.g_varchar2_table(33) := '=======================   '||wwv_flow.LF||
'--   '||wwv_flow.LF||
'-- 1. G E N E R I C   H E L P E R   F U N C T I O N S   '||wwv_flow.LF||
'--   '||wwv_flow.LF||
'--==';
wwv_flow_imp.g_varchar2_table(34) := '============================================================================   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'--==============';
wwv_flow_imp.g_varchar2_table(35) := '================================================================   '||wwv_flow.LF||
'-- Returns the Oracle Text confi';
wwv_flow_imp.g_varchar2_table(36) := 'g record for this app.   '||wwv_flow.LF||
'--========================================================================';
wwv_flow_imp.g_varchar2_table(37) := '======   '||wwv_flow.LF||
'function get_config return eba_search_text_helper.t_config_table   '||wwv_flow.LF||
'is   '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'    ret';
wwv_flow_imp.g_varchar2_table(38) := 'urn eba_search_text_helper.t_config_table(   '||wwv_flow.LF||
'                ''NAME''            => eba_search_text_h';
wwv_flow_imp.g_varchar2_table(39) := 'elper.t_config_column(   '||wwv_flow.LF||
'                                         expression             => q''#FIRS';
wwv_flow_imp.g_varchar2_table(40) := 'T_NAME || '' '' || LAST_NAME#'',   '||wwv_flow.LF||
'                                         field_search           => ';
wwv_flow_imp.g_varchar2_table(41) := 'true,   '||wwv_flow.LF||
'                                         two_char_terms_enabled => true, '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(42) := '                        ndata_search           => true ),   '||wwv_flow.LF||
'                ''COUNTRY''         => eb';
wwv_flow_imp.g_varchar2_table(43) := 'a_search_text_helper.t_config_column(   '||wwv_flow.LF||
'                                         alias        => ''c';
wwv_flow_imp.g_varchar2_table(44) := 'ntry'',  '||wwv_flow.LF||
'                                         priority     => 4 ),   '||wwv_flow.LF||
'                ''PHONE_NUM';
wwv_flow_imp.g_varchar2_table(45) := 'BER''    => eba_search_text_helper.t_config_column(   '||wwv_flow.LF||
'                                         sdata';
wwv_flow_imp.g_varchar2_table(46) := '_search => true,   '||wwv_flow.LF||
'                                         sdata_op     => ''llike'',   '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(47) := '                              --   '||wwv_flow.LF||
'                                         field_search => false, ';
wwv_flow_imp.g_varchar2_table(48) := '  '||wwv_flow.LF||
'                                         priority     => 2,   '||wwv_flow.LF||
'                                  ';
wwv_flow_imp.g_varchar2_table(49) := '       pattern      => ''^[0-9]*$'',   '||wwv_flow.LF||
'                                         alias        => ''phon';
wwv_flow_imp.g_varchar2_table(50) := 'e'' ),   '||wwv_flow.LF||
'                ''EMAIL''           => eba_search_text_helper.t_config_column(   '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(51) := '                              sdata_search => true,   '||wwv_flow.LF||
'                                         --  ';
wwv_flow_imp.g_varchar2_table(52) := ' '||wwv_flow.LF||
'                                         field_search => false,   '||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(53) := '          pattern      => ''@example\.invalid$'',   '||wwv_flow.LF||
'                                         priority';
wwv_flow_imp.g_varchar2_table(54) := '     => 2,   '||wwv_flow.LF||
'                                         alias        => ''email'' ),   '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(55) := ' ''JOB_TITLE''       => eba_search_text_helper.t_config_column(   '||wwv_flow.LF||
'                                   ';
wwv_flow_imp.g_varchar2_table(56) := '      priority     => 3,   '||wwv_flow.LF||
'                                         score_expr   => ''*0.2'' ),   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(57) := '              ''CITY''            => eba_search_text_helper.t_config_column(   '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(58) := '                   score_expr   =>''*0.5'',   '||wwv_flow.LF||
'                                         alias        =';
wwv_flow_imp.g_varchar2_table(59) := '> ''city'',   '||wwv_flow.LF||
'                                         priority     => 1 ) );   '||wwv_flow.LF||
'end get_config;   '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(60) := '  '||wwv_flow.LF||
'--==============================================================================   '||wwv_flow.LF||
'-- Helper pro';
wwv_flow_imp.g_varchar2_table(61) := 'cedure to tokenize a string, respecting quotes.   '||wwv_flow.LF||
'--===============================================';
wwv_flow_imp.g_varchar2_table(62) := '===============================   '||wwv_flow.LF||
'function tokenize(   '||wwv_flow.LF||
'    p_string          in varchar2,   '||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(63) := '_token_quote     in varchar2 default ''"'',   '||wwv_flow.LF||
'    p_token_separator in varchar2 default '' '' )   '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(64) := 'return apex_t_varchar2   '||wwv_flow.LF||
'is   '||wwv_flow.LF||
'    l_value_len        pls_integer;   '||wwv_flow.LF||
'    l_char             varcha';
wwv_flow_imp.g_varchar2_table(65) := 'r2( 1 char );   '||wwv_flow.LF||
'    l_next_char        varchar2( 1 char );   '||wwv_flow.LF||
'    l_is_quoted        boolean;   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(66) := '  l_this_value       varchar2(32767);   '||wwv_flow.LF||
'    l_pos              simple_integer := 0;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    l_to';
wwv_flow_imp.g_varchar2_table(67) := 'kenized_values apex_t_varchar2 := apex_t_varchar2();   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    ------------------------------------';
wwv_flow_imp.g_varchar2_table(68) := '----------------------------------------   '||wwv_flow.LF||
'    procedure append_split_tokens(   '||wwv_flow.LF||
'        p_text in ';
wwv_flow_imp.g_varchar2_table(69) := 'varchar2 )   '||wwv_flow.LF||
'    is   '||wwv_flow.LF||
'        l_tokens apex_t_varchar2;   '||wwv_flow.LF||
'        l_index  pls_integer;   '||wwv_flow.LF||
'    be';
wwv_flow_imp.g_varchar2_table(70) := 'gin   '||wwv_flow.LF||
'        l_tokens := apex_string.split( p_text, p_token_separator );   '||wwv_flow.LF||
'        l_index  := l_';
wwv_flow_imp.g_varchar2_table(71) := 'tokens.first;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        while l_index is not null loop   '||wwv_flow.LF||
'            if l_tokens( l_index ) is';
wwv_flow_imp.g_varchar2_table(72) := ' not null then   '||wwv_flow.LF||
'                apex_string.push(   '||wwv_flow.LF||
'                    p_table => l_tokenized_va';
wwv_flow_imp.g_varchar2_table(73) := 'lues,   '||wwv_flow.LF||
'                    p_value => l_tokens( l_index ) );   '||wwv_flow.LF||
'            end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(74) := '     l_index := l_tokens.next( l_index );   '||wwv_flow.LF||
'        end loop;   '||wwv_flow.LF||
'    end append_split_tokens;   '||wwv_flow.LF||
'be';
wwv_flow_imp.g_varchar2_table(75) := 'gin   '||wwv_flow.LF||
'    --   '||wwv_flow.LF||
'    -- determine whether we have quotes and whether it is an even or an odd number ';
wwv_flow_imp.g_varchar2_table(76) := 'of quotes.   '||wwv_flow.LF||
'    --   '||wwv_flow.LF||
'    l_value_len := length( p_string );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    if    instr( p_string, p_t';
wwv_flow_imp.g_varchar2_table(77) := 'oken_quote ) = 0   '||wwv_flow.LF||
'       or mod( l_value_len - length( translate( p_string, ''x'' || p_token_quote, ';
wwv_flow_imp.g_varchar2_table(78) := '''x'' ) ), 2 ) = 1   '||wwv_flow.LF||
'    then   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'        -- we have no quotes, or an odd number of doub';
wwv_flow_imp.g_varchar2_table(79) := 'le-quotes. Tokenize without respecting quotes.   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'        append_split_tokens( p_strin';
wwv_flow_imp.g_varchar2_table(80) := 'g );   '||wwv_flow.LF||
'    else   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'        -- the number of double quotes is even, so we can tokenize';
wwv_flow_imp.g_varchar2_table(81) := ' the value while respecting the quotes for   '||wwv_flow.LF||
'        -- phrases.   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'        l_is_quot';
wwv_flow_imp.g_varchar2_table(82) := 'ed := false;   '||wwv_flow.LF||
'        l_pos       := 1;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        <<value_char_loop>>   '||wwv_flow.LF||
'        while l_pos ';
wwv_flow_imp.g_varchar2_table(83) := '<= l_value_len loop   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            l_char := substr( p_string, l_pos, 1 );   '||wwv_flow.LF||
'            if l_c';
wwv_flow_imp.g_varchar2_table(84) := 'har = p_token_quote then   '||wwv_flow.LF||
'                --   '||wwv_flow.LF||
'                -- get the next char to see whethe';
wwv_flow_imp.g_varchar2_table(85) := 'r we have an escaped quote ("")   '||wwv_flow.LF||
'                --   '||wwv_flow.LF||
'                l_next_char := substr( p_st';
wwv_flow_imp.g_varchar2_table(86) := 'ring, l_pos + 1, 1 );   '||wwv_flow.LF||
'                if l_next_char = p_token_quote then   '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(87) := 'l_this_value := l_this_value || l_char;   '||wwv_flow.LF||
'                    l_pos        := l_pos + 2;   '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(88) := '             continue value_char_loop;   '||wwv_flow.LF||
'                end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'                l_this_valu';
wwv_flow_imp.g_varchar2_table(89) := 'e := trim( both from l_this_value );   '||wwv_flow.LF||
'                if l_this_value is not null then   '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(90) := '            if l_is_quoted then   '||wwv_flow.LF||
'                        apex_string.push( l_tokenized_values, l_t';
wwv_flow_imp.g_varchar2_table(91) := 'his_value );   '||wwv_flow.LF||
'                    else   '||wwv_flow.LF||
'                        append_split_tokens( l_this_valu';
wwv_flow_imp.g_varchar2_table(92) := 'e );   '||wwv_flow.LF||
'                    end if;   '||wwv_flow.LF||
'                    l_this_value := null;   '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(93) := 'end if;   '||wwv_flow.LF||
'                l_is_quoted := not l_is_quoted;   '||wwv_flow.LF||
'            else   '||wwv_flow.LF||
'                l_';
wwv_flow_imp.g_varchar2_table(94) := 'this_value := l_this_value || l_char;   '||wwv_flow.LF||
'            end if;   '||wwv_flow.LF||
'            l_pos := l_pos + 1;   '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(95) := '       end loop value_char_loop;   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'        -- handle remaining text after the last qu';
wwv_flow_imp.g_varchar2_table(96) := 'ote   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'        l_this_value := trim( both from l_this_value );   '||wwv_flow.LF||
'        if l_this_va';
wwv_flow_imp.g_varchar2_table(97) := 'lue is not null then   '||wwv_flow.LF||
'            append_split_tokens( l_this_value );   '||wwv_flow.LF||
'        end if;   '||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(98) := 'nd if;   '||wwv_flow.LF||
'    return l_tokenized_values;   '||wwv_flow.LF||
'end tokenize;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'--=================================';
wwv_flow_imp.g_varchar2_table(99) := '=============================================   '||wwv_flow.LF||
'-- Helper procedure to clean column names for Oracl';
wwv_flow_imp.g_varchar2_table(100) := 'e Text section group   '||wwv_flow.LF||
'-- names. Only allow A-Z, 0-9 and underscore, and make column name upper cas';
wwv_flow_imp.g_varchar2_table(101) := 'e.   '||wwv_flow.LF||
'--==============================================================================   '||wwv_flow.LF||
'function c';
wwv_flow_imp.g_varchar2_table(102) := 'lean_column_name(   '||wwv_flow.LF||
'    p_column_name in varchar2 )   '||wwv_flow.LF||
'    return varchar2   '||wwv_flow.LF||
'is   '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'    re';
wwv_flow_imp.g_varchar2_table(103) := 'turn upper(   '||wwv_flow.LF||
'               regexp_replace(   '||wwv_flow.LF||
'                   p_column_name,   '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(104) := '     ''[^ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_$]'' ) );   '||wwv_flow.LF||
'end clean_column_';
wwv_flow_imp.g_varchar2_table(105) := 'name;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'--==============================================================================   '||wwv_flow.LF||
'-- ';
wwv_flow_imp.g_varchar2_table(106) := 'Helper procedure to execute (and log) dynamic PL/SQL.   '||wwv_flow.LF||
'--=========================================';
wwv_flow_imp.g_varchar2_table(107) := '=====================================   '||wwv_flow.LF||
'procedure do_execute(   '||wwv_flow.LF||
'    p_plsql         in clob,   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(108) := '  p_ignore_errors in boolean default false )   '||wwv_flow.LF||
'is   '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'    apex_debug.info( ''Executing PL/SQ';
wwv_flow_imp.g_varchar2_table(109) := 'L:'' );   '||wwv_flow.LF||
'    apex_debug.info( p_plsql );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    execute immediate p_plsql;   '||wwv_flow.LF||
'exception   '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(110) := 'when others then   '||wwv_flow.LF||
'        if not p_ignore_errors then   '||wwv_flow.LF||
'            raise;   '||wwv_flow.LF||
'        end if;   '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(111) := 'end do_execute;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'--===========================================================================';
wwv_flow_imp.g_varchar2_table(112) := '===   '||wwv_flow.LF||
'--   '||wwv_flow.LF||
'-- 2. C R E A T E   O R A C L E   T E X T   I N D E X   '||wwv_flow.LF||
'--   '||wwv_flow.LF||
'--======================';
wwv_flow_imp.g_varchar2_table(113) := '========================================================   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'--==================================';
wwv_flow_imp.g_varchar2_table(114) := '============================================   '||wwv_flow.LF||
'-- Cleans an already existing Text Index up and remo';
wwv_flow_imp.g_varchar2_table(115) := 'ves all dependent objects.   '||wwv_flow.LF||
'--====================================================================';
wwv_flow_imp.g_varchar2_table(116) := '==========   '||wwv_flow.LF||
'procedure cleanup_oracle_text(   '||wwv_flow.LF||
'    p_name_prefix in varchar2 )   '||wwv_flow.LF||
'is   '||wwv_flow.LF||
'    procedu';
wwv_flow_imp.g_varchar2_table(117) := 're drop_ctx_object(   '||wwv_flow.LF||
'        p_suffix in varchar2 )   '||wwv_flow.LF||
'    is   '||wwv_flow.LF||
'    begin   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        do_execu';
wwv_flow_imp.g_varchar2_table(118) := 'te(   '||wwv_flow.LF||
'            p_plsql         =>    ''begin ''   '||wwv_flow.LF||
'                               || ''ctxsys.ctx_d';
wwv_flow_imp.g_varchar2_table(119) := 'dl.drop_''   '||wwv_flow.LF||
'                               ||     case p_suffix   '||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(120) := '          when c_suffix_sg   '||wwv_flow.LF||
'                                          then ''section_group(group_na';
wwv_flow_imp.g_varchar2_table(121) := 'me => ''   '||wwv_flow.LF||
'                                          else ''preference(preference_name => ''   '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(122) := '                                end   '||wwv_flow.LF||
'                               || sys.dbms_assert.enquote_lit';
wwv_flow_imp.g_varchar2_table(123) := 'eral( sys.dbms_assert.enquote_name( p_name_prefix || p_suffix ) )   '||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(124) := '|| '');''   '||wwv_flow.LF||
'                               || ''end;'',   '||wwv_flow.LF||
'            p_ignore_errors => true );   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(125) := '  end drop_ctx_object;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'    do_execute(   '||wwv_flow.LF||
'        p_plsql         =>    ''drop index ';
wwv_flow_imp.g_varchar2_table(126) := '''   '||wwv_flow.LF||
'                           || sys.dbms_assert.enquote_name( p_name_prefix || c_suffix_idx ) || ';
wwv_flow_imp.g_varchar2_table(127) := ''' force'',   '||wwv_flow.LF||
'        p_ignore_errors => true );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    do_execute(   '||wwv_flow.LF||
'        p_plsql         =>';
wwv_flow_imp.g_varchar2_table(128) := '    ''drop procedure ''   '||wwv_flow.LF||
'                           || sys.dbms_assert.enquote_name( p_name_prefix |';
wwv_flow_imp.g_varchar2_table(129) := '| c_suffix_uds ),   '||wwv_flow.LF||
'        p_ignore_errors => true );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    drop_ctx_object( c_suffix_sg );  ';
wwv_flow_imp.g_varchar2_table(130) := ' '||wwv_flow.LF||
'    drop_ctx_object( c_suffix_ds );   '||wwv_flow.LF||
'    drop_ctx_object( c_suffix_lx );   '||wwv_flow.LF||
'    drop_ctx_object(';
wwv_flow_imp.g_varchar2_table(131) := ' c_suffix_wl );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'end cleanup_oracle_text;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'--===========================================';
wwv_flow_imp.g_varchar2_table(132) := '===================================   '||wwv_flow.LF||
'-- drops the Oracle Text Index with all its preferences.   '||wwv_flow.LF||
'-';
wwv_flow_imp.g_varchar2_table(133) := '-==============================================================================   '||wwv_flow.LF||
'procedure drop_te';
wwv_flow_imp.g_varchar2_table(134) := 'xt_index(   '||wwv_flow.LF||
'    p_index_name  in varchar2 )   '||wwv_flow.LF||
'is   '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'    cleanup_oracle_text( c_prefix_idx';
wwv_flow_imp.g_varchar2_table(135) := ' || p_index_name );   '||wwv_flow.LF||
'end drop_text_index;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'--===============================================';
wwv_flow_imp.g_varchar2_table(136) := '===============================   '||wwv_flow.LF||
'-- creates the Oracle Text Index with all its preferences based o';
wwv_flow_imp.g_varchar2_table(137) := 'n the   '||wwv_flow.LF||
'-- passed configuration records.   '||wwv_flow.LF||
'--=====================================================';
wwv_flow_imp.g_varchar2_table(138) := '=========================   '||wwv_flow.LF||
'procedure create_text_index(   '||wwv_flow.LF||
'    p_table_name      in varchar2,   '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(139) := '   --   '||wwv_flow.LF||
'    p_index_name      in varchar2,   '||wwv_flow.LF||
'    p_index_column    in varchar2,   '||wwv_flow.LF||
'    --   '||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(140) := '_config          in t_config_table )   '||wwv_flow.LF||
'is   '||wwv_flow.LF||
'    l_existing_columns t_existing_columns;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(141) := '--------------------------------------------------------------------------------------------------  ';
wwv_flow_imp.g_varchar2_table(142) := ' '||wwv_flow.LF||
'    procedure do_build_index   '||wwv_flow.LF||
'    is   '||wwv_flow.LF||
'        c_name_prefix    constant  varchar2(255) := c_pr';
wwv_flow_imp.g_varchar2_table(143) := 'efix_idx  || p_index_name;   '||wwv_flow.LF||
'        c_uds_proc_name  constant  varchar2(255) := c_name_prefix || c';
wwv_flow_imp.g_varchar2_table(144) := '_suffix_uds;   '||wwv_flow.LF||
'        c_ds_name        constant  varchar2(255) := c_name_prefix || c_suffix_ds;   ';
wwv_flow_imp.g_varchar2_table(145) := ''||wwv_flow.LF||
'        c_sg_name        constant  varchar2(255) := c_name_prefix || c_suffix_sg;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        l_';
wwv_flow_imp.g_varchar2_table(146) := 'uds_query                varchar2(32767);   '||wwv_flow.LF||
'        l_uds_xml                  varchar2(32767);   '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(147) := '        l_uds_sg                   varchar2(32767);   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        l_plsql                    varcha';
wwv_flow_imp.g_varchar2_table(148) := 'r2(32767);   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        l_column                   varchar2(128);   '||wwv_flow.LF||
'        l_text_column        ';
wwv_flow_imp.g_varchar2_table(149) := '      varchar2(128);   '||wwv_flow.LF||
'    begin   '||wwv_flow.LF||
'        cleanup_oracle_text( c_name_prefix );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        l_';
wwv_flow_imp.g_varchar2_table(150) := 'column := p_config.first;   '||wwv_flow.LF||
'        while l_column is not null loop   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            --   '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(151) := '      -- a config table might not exist in the table, but must have an expression, then.   '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(152) := '    --   '||wwv_flow.LF||
'            if     not l_existing_columns.exists( l_column )   '||wwv_flow.LF||
'               and p_confi';
wwv_flow_imp.g_varchar2_table(153) := 'g( l_column ).expression is null   '||wwv_flow.LF||
'            then   '||wwv_flow.LF||
'                l_column := p_config.next( l';
wwv_flow_imp.g_varchar2_table(154) := '_column );   '||wwv_flow.LF||
'                continue;   '||wwv_flow.LF||
'            end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            -- '||wwv_flow.LF||
'            --';
wwv_flow_imp.g_varchar2_table(155) := ' Clean Column name strips special characters from the actual column name. In special '||wwv_flow.LF||
'            --';
wwv_flow_imp.g_varchar2_table(156) := ' cases, there can be collisions, which we accept for the purpose of this demo app. '||wwv_flow.LF||
'            -- '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(157) := '            l_text_column := clean_column_name( l_column );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            --   '||wwv_flow.LF||
'            -- ';
wwv_flow_imp.g_varchar2_table(158) := 'Build Column List for the query within the UDS procedure   '||wwv_flow.LF||
'            --   '||wwv_flow.LF||
'            l_uds_quer';
wwv_flow_imp.g_varchar2_table(159) := 'y := l_uds_query   '||wwv_flow.LF||
'                        || case when l_uds_query is not null then '','' end   '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(160) := '                     || case when p_config( l_column ).expression is not null   '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(161) := '             then p_config( l_column ).expression || '' ''   '||wwv_flow.LF||
'                           end   '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(162) := '                  || sys.dbms_assert.enquote_name( l_column );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            --   '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(163) := '-- Build concatenation statements to put together the XML in the UDS   '||wwv_flow.LF||
'            -- procedure.   ';
wwv_flow_imp.g_varchar2_table(164) := ''||wwv_flow.LF||
'            --   '||wwv_flow.LF||
'            if p_config( l_column ).field_search then   '||wwv_flow.LF||
'                l_uds_xm';
wwv_flow_imp.g_varchar2_table(165) := 'l   := l_uds_xml   '||wwv_flow.LF||
'                            || case when l_uds_xml is not null then LF || ''||'' e';
wwv_flow_imp.g_varchar2_table(166) := 'nd   '||wwv_flow.LF||
'                            || ''''''<'' || l_text_column || c_suffix_f || ''>''''''   '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(167) := '              || ''|| replace(replace( l_row.'' || sys.dbms_assert.enquote_name( l_column ) || '', ''''>''';
wwv_flow_imp.g_varchar2_table(168) := '''), ''''<'''' )''    '||wwv_flow.LF||
'                            || ''|| ''''</'' || l_text_column || c_suffix_f || ''>'''''';  ';
wwv_flow_imp.g_varchar2_table(169) := ' '||wwv_flow.LF||
'            end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            if p_config( l_column ).ndata_search then   '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(170) := '  l_uds_xml   := l_uds_xml   '||wwv_flow.LF||
'                            || case when l_uds_xml is not null then LF';
wwv_flow_imp.g_varchar2_table(171) := ' || ''||'' end   '||wwv_flow.LF||
'                            || ''''''<'' || l_text_column || c_suffix_nd || ''>''''''   '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(172) := '                         || ''|| replace(replace(l_row.'' || sys.dbms_assert.enquote_name( l_column ) ';
wwv_flow_imp.g_varchar2_table(173) := '|| '', ''''>''''), ''''<'''' )''   '||wwv_flow.LF||
'                            || ''||''''</'' || l_text_column || c_suffix_nd ||';
wwv_flow_imp.g_varchar2_table(174) := ' ''>'''''';   '||wwv_flow.LF||
'            end if;   '||wwv_flow.LF||
'            if p_config( l_column ).sdata_search then   '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(175) := '       l_uds_xml   := l_uds_xml   '||wwv_flow.LF||
'                            || case when l_uds_xml is not null th';
wwv_flow_imp.g_varchar2_table(176) := 'en LF || ''||'' end   '||wwv_flow.LF||
'                            || ''''''<'' || l_text_column || c_suffix_sd || ''>''''''  ';
wwv_flow_imp.g_varchar2_table(177) := ' '||wwv_flow.LF||
'                            || ''|| replace(replace(l_row.'' || sys.dbms_assert.enquote_name( l_colu';
wwv_flow_imp.g_varchar2_table(178) := 'mn ) || '', ''''>''''), ''''<'''' )''    '||wwv_flow.LF||
'                            || ''||''''</'' || l_text_column || c_suffix';
wwv_flow_imp.g_varchar2_table(179) := '_sd || ''>'''''';   '||wwv_flow.LF||
'            end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            --   '||wwv_flow.LF||
'            -- Build ctx_ddl.add_*_sec';
wwv_flow_imp.g_varchar2_table(180) := 'tion statements   '||wwv_flow.LF||
'            --   '||wwv_flow.LF||
'            if p_config( l_column ).field_search then   '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(181) := '          l_uds_sg := l_uds_sg   '||wwv_flow.LF||
'                         || case when l_uds_sg is not null then LF';
wwv_flow_imp.g_varchar2_table(182) := ' end   '||wwv_flow.LF||
'                         || ''ctxsys.ctx_ddl.add_field_section(''   '||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(183) := '|| sys.dbms_assert.enquote_literal( sys.dbms_assert.enquote_name( c_sg_name ) )   '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(184) := '        || '','''''' || l_text_column || c_suffix_f || ''''''''   '||wwv_flow.LF||
'                         || '','''''' || l_te';
wwv_flow_imp.g_varchar2_table(185) := 'xt_column || c_suffix_f || ''''''''   '||wwv_flow.LF||
'                         || '','' || case when p_config( l_column )';
wwv_flow_imp.g_varchar2_table(186) := '.visible then ''true'' else ''false'' end   '||wwv_flow.LF||
'                         || '');'';   '||wwv_flow.LF||
'            end if;   ';
wwv_flow_imp.g_varchar2_table(187) := ''||wwv_flow.LF||
'   '||wwv_flow.LF||
'            if p_config( l_column ).ndata_search then   '||wwv_flow.LF||
'                l_uds_sg := l_uds_sg  ';
wwv_flow_imp.g_varchar2_table(188) := ' '||wwv_flow.LF||
'                         || case when l_uds_sg is not null then LF end   '||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(189) := ' || ''ctxsys.ctx_ddl.add_ndata_section(''   '||wwv_flow.LF||
'                         || sys.dbms_assert.enquote_liter';
wwv_flow_imp.g_varchar2_table(190) := 'al( sys.dbms_assert.enquote_name( c_sg_name ) )   '||wwv_flow.LF||
'                         || '',''''''  || l_text_colu';
wwv_flow_imp.g_varchar2_table(191) := 'mn || c_suffix_nd || ''''''''   '||wwv_flow.LF||
'                         || '',''''''  || l_text_column || c_suffix_nd || ''';
wwv_flow_imp.g_varchar2_table(192) := '''''''   '||wwv_flow.LF||
'                         || '');'';   '||wwv_flow.LF||
'            end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            if p_config( l_co';
wwv_flow_imp.g_varchar2_table(193) := 'lumn ).sdata_search then   '||wwv_flow.LF||
'                l_uds_sg := l_uds_sg   '||wwv_flow.LF||
'                         || case';
wwv_flow_imp.g_varchar2_table(194) := ' when l_uds_sg is not null then LF end   '||wwv_flow.LF||
'                         || ''ctxsys.ctx_ddl.add_sdata_sect';
wwv_flow_imp.g_varchar2_table(195) := 'ion(''   '||wwv_flow.LF||
'                         || sys.dbms_assert.enquote_literal( sys.dbms_assert.enquote_name( ';
wwv_flow_imp.g_varchar2_table(196) := 'c_sg_name ) )   '||wwv_flow.LF||
'                         || '','''''' || l_text_column || c_suffix_sd || ''''''''   '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(197) := '                   || '','''''' || l_text_column || c_suffix_sd || ''''''''   '||wwv_flow.LF||
'                         || ''';
wwv_flow_imp.g_varchar2_table(198) := ','''''' || nvl( replace( p_config( l_column ).sdata_datatype, '''''''', '''''''''''' ), ''VARCHAR2'' ) || ''''''''   '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(199) := '                        || '');'';   '||wwv_flow.LF||
'            end if;   '||wwv_flow.LF||
'            l_column := p_config.next( l_';
wwv_flow_imp.g_varchar2_table(200) := 'column );   '||wwv_flow.LF||
'        end loop;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'        -- Step 1: Create the UDS Procedure   '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(201) := '       --   '||wwv_flow.LF||
'        l_plsql := ''create or replace procedure '' || sys.dbms_assert.enquote_name( c_ud';
wwv_flow_imp.g_varchar2_table(202) := 's_proc_name ) || ''('' || LF   '||wwv_flow.LF||
'                || ''rid  in rowid,'' || LF   '||wwv_flow.LF||
'                || ''tlob ';
wwv_flow_imp.g_varchar2_table(203) := 'in out nocopy clob )'' || LF   '||wwv_flow.LF||
'                || ''is'' || LF   '||wwv_flow.LF||
'                || ''begin'' || LF   '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(204) := '                || ''for l_row in (''   '||wwv_flow.LF||
'                || ''select ''   '||wwv_flow.LF||
'                || l_uds_quer';
wwv_flow_imp.g_varchar2_table(205) := 'y   '||wwv_flow.LF||
'                || '' from ''   '||wwv_flow.LF||
'                || sys.dbms_assert.enquote_name( p_table_name ) ';
wwv_flow_imp.g_varchar2_table(206) := '  '||wwv_flow.LF||
'                || '' ''   '||wwv_flow.LF||
'                || ''where rowid = rid )'' || LF   '||wwv_flow.LF||
'                || ''l';
wwv_flow_imp.g_varchar2_table(207) := 'oop'' || LF   '||wwv_flow.LF||
'                || ''tlob := '' || l_uds_xml || '';'' || LF   '||wwv_flow.LF||
'                || ''end loo';
wwv_flow_imp.g_varchar2_table(208) := 'p;'' || LF   '||wwv_flow.LF||
'                || ''end '' || sys.dbms_assert.enquote_name( c_uds_proc_name ) || '';'';   ';
wwv_flow_imp.g_varchar2_table(209) := ''||wwv_flow.LF||
'   '||wwv_flow.LF||
'        do_execute( l_plsql );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'        -- Step 2: Create the UDS Preferenc';
wwv_flow_imp.g_varchar2_table(210) := 'e   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'        do_execute(   '||wwv_flow.LF||
'    ''begin   '||wwv_flow.LF||
'         ctxsys.ctx_ddl.create_preference(  ';
wwv_flow_imp.g_varchar2_table(211) := ' '||wwv_flow.LF||
'             preference_name => '' || sys.dbms_assert.enquote_literal( sys.dbms_assert.enquote_name';
wwv_flow_imp.g_varchar2_table(212) := '( c_name_prefix|| c_suffix_ds ) ) ||'',   '||wwv_flow.LF||
'             object_name     => ''''user_datastore'''' );   '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(213) := '  '||wwv_flow.LF||
'         ctxsys.ctx_ddl.set_attribute(   '||wwv_flow.LF||
'             preference_name => '' || sys.dbms_assert.en';
wwv_flow_imp.g_varchar2_table(214) := 'quote_literal( sys.dbms_assert.enquote_name( c_name_prefix|| c_suffix_ds ) ) ||'',   '||wwv_flow.LF||
'             at';
wwv_flow_imp.g_varchar2_table(215) := 'tribute_name  => ''''procedure'''',   '||wwv_flow.LF||
'             attribute_value => '' || sys.dbms_assert.enquote_lite';
wwv_flow_imp.g_varchar2_table(216) := 'ral( sys.dbms_assert.enquote_name( c_uds_proc_name ) ) || '');   '||wwv_flow.LF||
'    end;'');   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(217) := '      -- Step 3: Create the Section Group   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'        do_execute(   '||wwv_flow.LF||
'            p_plsq';
wwv_flow_imp.g_varchar2_table(218) := 'l =>    empty_clob()   '||wwv_flow.LF||
'                       || ''begin ''   '||wwv_flow.LF||
'                       ||     ''ctxsys.';
wwv_flow_imp.g_varchar2_table(219) := 'ctx_ddl.create_section_group(''   '||wwv_flow.LF||
'                       ||         ''group_name      => '' || sys.dbm';
wwv_flow_imp.g_varchar2_table(220) := 's_assert.enquote_literal( sys.dbms_assert.enquote_name( c_name_prefix|| c_suffix_sg ) ) || '',''   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(221) := '                     ||         ''group_type      => ''''xml_section_group'''');''   '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(222) := '   ||     l_uds_sg   '||wwv_flow.LF||
'                       || ''end;'');   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'        -- Step 4: Cre';
wwv_flow_imp.g_varchar2_table(223) := 'ate the Wordlist and Lexer Preferencews   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'        do_execute(   '||wwv_flow.LF||
'    ''begin   '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(224) := '   ctxsys.ctx_ddl.create_preference(   '||wwv_flow.LF||
'             preference_name => '' || sys.dbms_assert.enquote';
wwv_flow_imp.g_varchar2_table(225) := '_literal( sys.dbms_assert.enquote_name( c_name_prefix|| c_suffix_wl ) ) || '',   '||wwv_flow.LF||
'             object';
wwv_flow_imp.g_varchar2_table(226) := '_name     => ''''basic_wordlist'''' );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'         ctxsys.ctx_ddl.set_attribute(   '||wwv_flow.LF||
'             pre';
wwv_flow_imp.g_varchar2_table(227) := 'ference_name => '' || sys.dbms_assert.enquote_literal( sys.dbms_assert.enquote_name( c_name_prefix|| ';
wwv_flow_imp.g_varchar2_table(228) := 'c_suffix_wl ) ) || '',   '||wwv_flow.LF||
'             attribute_name  => ''''ndata_alternate_spelling'''',   '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(229) := '   attribute_value => ''''true'''' );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'         ctxsys.ctx_ddl.set_attribute(   '||wwv_flow.LF||
'             pref';
wwv_flow_imp.g_varchar2_table(230) := 'erence_name => '' || sys.dbms_assert.enquote_literal( sys.dbms_assert.enquote_name( c_name_prefix|| c';
wwv_flow_imp.g_varchar2_table(231) := '_suffix_wl ) ) || '',   '||wwv_flow.LF||
'             attribute_name  => ''''ndata_base_letter'''',   '||wwv_flow.LF||
'             attri';
wwv_flow_imp.g_varchar2_table(232) := 'bute_value => ''''true'''' );   '||wwv_flow.LF||
'    end;'');   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        do_execute(   '||wwv_flow.LF||
'    ''begin   '||wwv_flow.LF||
'         ctxsys';
wwv_flow_imp.g_varchar2_table(233) := '.ctx_ddl.create_preference(   '||wwv_flow.LF||
'             preference_name => '' || sys.dbms_assert.enquote_literal(';
wwv_flow_imp.g_varchar2_table(234) := ' sys.dbms_assert.enquote_name( c_name_prefix|| c_suffix_lx ) ) || '',   '||wwv_flow.LF||
'             object_name    ';
wwv_flow_imp.g_varchar2_table(235) := ' => ''''basic_lexer'''' );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'         ctxsys.ctx_ddl.set_attribute(   '||wwv_flow.LF||
'             preference_name';
wwv_flow_imp.g_varchar2_table(236) := ' => '' || sys.dbms_assert.enquote_literal( sys.dbms_assert.enquote_name( c_name_prefix|| c_suffix_lx ';
wwv_flow_imp.g_varchar2_table(237) := ') ) || '',   '||wwv_flow.LF||
'             attribute_name  => ''''mixed_case'''',   '||wwv_flow.LF||
'             attribute_value => ''''no';
wwv_flow_imp.g_varchar2_table(238) := ''''' );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'         ctxsys.ctx_ddl.set_attribute(   '||wwv_flow.LF||
'             preference_name => '' || sys.dbms';
wwv_flow_imp.g_varchar2_table(239) := '_assert.enquote_literal( sys.dbms_assert.enquote_name( c_name_prefix|| c_suffix_lx ) ) || '',   '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(240) := '         attribute_name  => ''''base_letter'''',   '||wwv_flow.LF||
'             attribute_value => ''''yes'''' );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(241) := '       ctxsys.ctx_ddl.set_attribute(   '||wwv_flow.LF||
'             preference_name => '' || sys.dbms_assert.enquote';
wwv_flow_imp.g_varchar2_table(242) := '_literal( sys.dbms_assert.enquote_name( c_name_prefix|| c_suffix_lx ) ) || '',   '||wwv_flow.LF||
'             attrib';
wwv_flow_imp.g_varchar2_table(243) := 'ute_name  => ''''base_letter_type'''',   '||wwv_flow.LF||
'             attribute_value => ''''generic'''' );   '||wwv_flow.LF||
'    end;''); ';
wwv_flow_imp.g_varchar2_table(244) := '  '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'        -- Step 5: Create the index   '||wwv_flow.LF||
'        --   '||wwv_flow.LF||
'        do_execute(   '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(245) := ' ''create index '' || sys.dbms_assert.enquote_name( c_name_prefix || c_suffix_idx )   '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(246) := '     || '' on ''   '||wwv_flow.LF||
'                    || sys.dbms_assert.enquote_name( p_table_name )   '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(247) := '         || ''('' || sys.dbms_assert.enquote_name( p_index_column ) || '')   '||wwv_flow.LF||
'    indextype is ctxsys.c';
wwv_flow_imp.g_varchar2_table(248) := 'ontext   '||wwv_flow.LF||
'    parameters(''''   '||wwv_flow.LF||
'      datastore      '' || c_name_prefix || c_suffix_ds || ''   '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(249) := 'section group  '' || c_name_prefix || c_suffix_sg || ''   '||wwv_flow.LF||
'      wordlist       '' || c_name_prefix || ';
wwv_flow_imp.g_varchar2_table(250) := 'c_suffix_wl || ''   '||wwv_flow.LF||
'      lexer          '' || c_name_prefix || c_suffix_lx || ''   '||wwv_flow.LF||
'      stoplist   ';
wwv_flow_imp.g_varchar2_table(251) := '    ctxsys.empty_stoplist   '||wwv_flow.LF||
'      sync           (on commit)   '||wwv_flow.LF||
'      memory '' || c_index_memory ||';
wwv_flow_imp.g_varchar2_table(252) := ' ''   '||wwv_flow.LF||
'    '''')'');   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    end do_build_index;   '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'    if p_index_name like ''%"%'' or p_inde';
wwv_flow_imp.g_varchar2_table(253) := 'x_name like ''%''''%'' then   '||wwv_flow.LF||
'        raise_application_error(-20001, ''Index name must not contain sing';
wwv_flow_imp.g_varchar2_table(254) := 'le or double quotes.'', true );   '||wwv_flow.LF||
'    end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    for i in (   '||wwv_flow.LF||
'        select column_name,  ';
wwv_flow_imp.g_varchar2_table(255) := ' '||wwv_flow.LF||
'               data_type   '||wwv_flow.LF||
'          from sys.user_tab_columns   '||wwv_flow.LF||
'         where table_name = p_t';
wwv_flow_imp.g_varchar2_table(256) := 'able_name )   '||wwv_flow.LF||
'    loop   '||wwv_flow.LF||
'        l_existing_columns( i.column_name ) := i.data_type;   '||wwv_flow.LF||
'    end lo';
wwv_flow_imp.g_varchar2_table(257) := 'op;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    if        l_existing_columns.count = 0   '||wwv_flow.LF||
'       or not l_existing_columns.exists( p_';
wwv_flow_imp.g_varchar2_table(258) := 'index_column )   '||wwv_flow.LF||
'    then   '||wwv_flow.LF||
'        raise_application_error(-20001, ''Table or index column does no';
wwv_flow_imp.g_varchar2_table(259) := 't exist.'', true );   '||wwv_flow.LF||
'    end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    do_build_index;   '||wwv_flow.LF||
'end create_text_index;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'--====';
wwv_flow_imp.g_varchar2_table(260) := '==========================================================================   '||wwv_flow.LF||
'--   '||wwv_flow.LF||
'-- 3. G E N E R ';
wwv_flow_imp.g_varchar2_table(261) := 'A T E   C O N T A I N S   Q U E R I E S   '||wwv_flow.LF||
'--   '||wwv_flow.LF||
'--=================================================';
wwv_flow_imp.g_varchar2_table(262) := '=============================   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'--=============================================================';
wwv_flow_imp.g_varchar2_table(263) := '=================   '||wwv_flow.LF||
'-- generate the CONTAINS query with progressive relaxation, based on user   '||wwv_flow.LF||
'--';
wwv_flow_imp.g_varchar2_table(264) := ' input and config record.   '||wwv_flow.LF||
'--=====================================================================';
wwv_flow_imp.g_varchar2_table(265) := '=========   '||wwv_flow.LF||
'function search_query(   '||wwv_flow.LF||
'    p_table_name        in varchar2,   '||wwv_flow.LF||
'    p_index_column   ';
wwv_flow_imp.g_varchar2_table(266) := '   in varchar2,   '||wwv_flow.LF||
'    --   '||wwv_flow.LF||
'    p_config            in t_config_table,   '||wwv_flow.LF||
'    --   '||wwv_flow.LF||
'    p_search_ex';
wwv_flow_imp.g_varchar2_table(267) := 'pression in varchar2 )   '||wwv_flow.LF||
'    return varchar2   '||wwv_flow.LF||
'is   '||wwv_flow.LF||
'    type t_query_part is table of varchar2(32';
wwv_flow_imp.g_varchar2_table(268) := '767) index by pls_integer;   '||wwv_flow.LF||
'    type t_combiners  is table of varchar2(3)     index by pls_integer';
wwv_flow_imp.g_varchar2_table(269) := ';   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    c_combiners            constant t_combiners := t_combiners( 1 => ''AND'', 2 => ''OR'' );   ';
wwv_flow_imp.g_varchar2_table(270) := ''||wwv_flow.LF||
'   '||wwv_flow.LF||
'    l_tokens                        apex_t_varchar2 := apex_t_varchar2();   '||wwv_flow.LF||
'    l_tokens_for_c';
wwv_flow_imp.g_varchar2_table(271) := 'olumn             apex_t_varchar2;   '||wwv_flow.LF||
'    l_generated_query               clob;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    l_exact_s';
wwv_flow_imp.g_varchar2_table(272) := 'earch                  t_query_part;   '||wwv_flow.LF||
'    l_ndata_search                  t_query_part;   '||wwv_flow.LF||
'    l_f';
wwv_flow_imp.g_varchar2_table(273) := 'uzzy_search                  t_query_part;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    l_highest_prio                  pls_integer :=';
wwv_flow_imp.g_varchar2_table(274) := ' 1;   '||wwv_flow.LF||
'    l_column                        varchar2(128);   '||wwv_flow.LF||
'    l_text_column                   var';
wwv_flow_imp.g_varchar2_table(275) := 'char2(128);   '||wwv_flow.LF||
'    l_idx                           pls_integer;   '||wwv_flow.LF||
'  '||wwv_flow.LF||
'    --------------------------';
wwv_flow_imp.g_varchar2_table(276) := '--------------------------------------------------   '||wwv_flow.LF||
'    function pre_process_search_string(  '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(277) := '    p_search_string in varchar2 )  '||wwv_flow.LF||
'        return varchar2  '||wwv_flow.LF||
'    is  '||wwv_flow.LF||
'        l_processed_search_st';
wwv_flow_imp.g_varchar2_table(278) := 'ring varchar2(32767) := '' '' || p_search_string || '' '';  '||wwv_flow.LF||
'    begin  '||wwv_flow.LF||
'        --  '||wwv_flow.LF||
'        -- If we d';
wwv_flow_imp.g_varchar2_table(279) := 'etect a city name (Munich, New York, etc.), treat that as a city and don''t even try to do name searc';
wwv_flow_imp.g_varchar2_table(280) := 'h for this.  '||wwv_flow.LF||
'        --  '||wwv_flow.LF||
'        for i in 1 .. c_cities_list.count loop  '||wwv_flow.LF||
'            l_processed_';
wwv_flow_imp.g_varchar2_table(281) := 'search_string := regexp_replace(   '||wwv_flow.LF||
'                      srcstr     => l_processed_search_string,  ';
wwv_flow_imp.g_varchar2_table(282) := ' '||wwv_flow.LF||
'                      pattern    => c_cities_list( i ),  '||wwv_flow.LF||
'                      replacestr => ''"ci';
wwv_flow_imp.g_varchar2_table(283) := 'ty:\1"'',  '||wwv_flow.LF||
'                      modifier   => ''i'' );  '||wwv_flow.LF||
'        end loop;  '||wwv_flow.LF||
'        for i in 1 .. c_';
wwv_flow_imp.g_varchar2_table(284) := 'countries_list.count loop  '||wwv_flow.LF||
'            l_processed_search_string := regexp_replace(   '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(285) := '          srcstr     => l_processed_search_string,   '||wwv_flow.LF||
'                      pattern    => c_countrie';
wwv_flow_imp.g_varchar2_table(286) := 's_list( i ),  '||wwv_flow.LF||
'                      replacestr => ''"cntry:\1"'',  '||wwv_flow.LF||
'                      modifier   ';
wwv_flow_imp.g_varchar2_table(287) := '=> ''i'' );  '||wwv_flow.LF||
'        end loop;  '||wwv_flow.LF||
' '||wwv_flow.LF||
'        return trim( l_processed_search_string );'||wwv_flow.LF||
'    end pre_proc';
wwv_flow_imp.g_varchar2_table(288) := 'ess_search_string;  '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    -----------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(289) := '-----   '||wwv_flow.LF||
'    procedure pre_process_tokens(   '||wwv_flow.LF||
'        p_tokens in out nocopy apex_t_varchar2 )   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(290) := '  is   '||wwv_flow.LF||
'    begin   '||wwv_flow.LF||
'        for i in 1 .. p_tokens.count loop   '||wwv_flow.LF||
'            l_column := p_config.f';
wwv_flow_imp.g_varchar2_table(291) := 'irst;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            while l_column is not null loop   '||wwv_flow.LF||
'                if     p_config( l_colum';
wwv_flow_imp.g_varchar2_table(292) := 'n ).alias is not null   '||wwv_flow.LF||
'                   and p_config( l_column ).pattern is not null   '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(293) := '           and regexp_like( p_tokens( i ), p_config( l_column ).pattern )   '||wwv_flow.LF||
'                   and ';
wwv_flow_imp.g_varchar2_table(294) := 'substr( p_tokens( i ), 1, length( p_config( l_column ).alias ) + 1 ) != p_config( l_column ).alias |';
wwv_flow_imp.g_varchar2_table(295) := '| '':''   '||wwv_flow.LF||
'                then   '||wwv_flow.LF||
'                    p_tokens( i ) := p_config( l_column ).alias || ';
wwv_flow_imp.g_varchar2_table(296) := ''':'' || p_tokens( i );   '||wwv_flow.LF||
'                end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'                l_column := p_config.next( l';
wwv_flow_imp.g_varchar2_table(297) := '_column );   '||wwv_flow.LF||
'            end loop;   '||wwv_flow.LF||
'        end loop;   '||wwv_flow.LF||
'    end pre_process_tokens;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(298) := '---------------------------------------------------------------------------   '||wwv_flow.LF||
'    function filter_t';
wwv_flow_imp.g_varchar2_table(299) := 'okens_for_column(   '||wwv_flow.LF||
'        p_original_tokens in apex_t_varchar2,   '||wwv_flow.LF||
'        p_column          in v';
wwv_flow_imp.g_varchar2_table(300) := 'archar2 )   '||wwv_flow.LF||
'        return apex_t_varchar2   '||wwv_flow.LF||
'    is   '||wwv_flow.LF||
'        l_return_tokens apex_t_varchar2 := ';
wwv_flow_imp.g_varchar2_table(301) := 'apex_t_varchar2();   '||wwv_flow.LF||
'        l_token         varchar2(32767);   '||wwv_flow.LF||
'        l_colon_pos     pls_intege';
wwv_flow_imp.g_varchar2_table(302) := 'r;   '||wwv_flow.LF||
'    begin   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        for t in 1 .. p_original_tokens.count loop   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            l_token';
wwv_flow_imp.g_varchar2_table(303) := ' := p_original_tokens( t );   '||wwv_flow.LF||
'            l_colon_pos := instr( l_token, '':'' );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(304) := 'if l_colon_pos > 0 then   '||wwv_flow.LF||
'                if p_config( p_column ).alias = substr( l_token, 1, l_col';
wwv_flow_imp.g_varchar2_table(305) := 'on_pos - 1 ) then   '||wwv_flow.LF||
'                    apex_string.push( l_return_tokens, trim(  substr( l_token, ';
wwv_flow_imp.g_varchar2_table(306) := 'l_colon_pos + 1 ) ) );   '||wwv_flow.LF||
'                end if;   '||wwv_flow.LF||
'            else   '||wwv_flow.LF||
'                if p_config';
wwv_flow_imp.g_varchar2_table(307) := '( p_column ).alias is null then   '||wwv_flow.LF||
'                    apex_string.push( l_return_tokens, l_token );';
wwv_flow_imp.g_varchar2_table(308) := '   '||wwv_flow.LF||
'                end if;   '||wwv_flow.LF||
'            end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        end loop;   '||wwv_flow.LF||
'        return l_retu';
wwv_flow_imp.g_varchar2_table(309) := 'rn_tokens;   '||wwv_flow.LF||
'    end filter_tokens_for_column;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    -----------------------------------------';
wwv_flow_imp.g_varchar2_table(310) := '-----------------------------------   '||wwv_flow.LF||
'    function generate_text_query_part(   '||wwv_flow.LF||
'        p_tokens   ';
wwv_flow_imp.g_varchar2_table(311) := '               in apex_t_varchar2,   '||wwv_flow.LF||
'        p_feature                 in varchar2,   '||wwv_flow.LF||
'        p_op';
wwv_flow_imp.g_varchar2_table(312) := 'erator                in varchar2,   '||wwv_flow.LF||
'        p_section                 in varchar2,   '||wwv_flow.LF||
'        p_sc';
wwv_flow_imp.g_varchar2_table(313) := 'ore                   in varchar2,   '||wwv_flow.LF||
'        p_two_char_terms_enabled  in boolean  default false, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(314) := '        p_combiner                in varchar2 default null )   '||wwv_flow.LF||
'        return varchar2   '||wwv_flow.LF||
'    is   ';
wwv_flow_imp.g_varchar2_table(315) := ''||wwv_flow.LF||
'        l_query      varchar2(32767);   '||wwv_flow.LF||
'        l_added_term varchar2(32767);'||wwv_flow.LF||
'   '||wwv_flow.LF||
'        --------';
wwv_flow_imp.g_varchar2_table(316) := '----------------------------------------------------------------   '||wwv_flow.LF||
'        function add_term_to_que';
wwv_flow_imp.g_varchar2_table(317) := 'ry_part(   '||wwv_flow.LF||
'            p_term in varchar2,   '||wwv_flow.LF||
'            p_pos  in pls_integer )   '||wwv_flow.LF||
'            re';
wwv_flow_imp.g_varchar2_table(318) := 'turn varchar2   '||wwv_flow.LF||
'        is   '||wwv_flow.LF||
'            l_cleaned_term varchar2(32767);  '||wwv_flow.LF||
'        begin   '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(319) := '      l_cleaned_term := ltrim( rtrim( regexp_replace( p_term, ''[][<>{}()/\|*&^#%$!?.,;=~+-]'' ) ) ); ';
wwv_flow_imp.g_varchar2_table(320) := '  '||wwv_flow.LF||
'  '||wwv_flow.LF||
'            if l_cleaned_term is null then   '||wwv_flow.LF||
'                return null;  '||wwv_flow.LF||
'            end i';
wwv_flow_imp.g_varchar2_table(321) := 'f;   '||wwv_flow.LF||
'            return case   '||wwv_flow.LF||
'                       when p_feature in ( ''EXACT'', ''FUZZY'' )   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(322) := '                     then    case    '||wwv_flow.LF||
'                                   when p_feature = ''EXACT''  '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(323) := '                                   then case '||wwv_flow.LF||
'                                            when p_two';
wwv_flow_imp.g_varchar2_table(324) := '_char_terms_enabled and length(l_cleaned_term) = 2 '||wwv_flow.LF||
'                                            then';
wwv_flow_imp.g_varchar2_table(325) := '        l_cleaned_term ||     ''%''   '||wwv_flow.LF||
'                                            else ''{'' || l_clean';
wwv_flow_imp.g_varchar2_table(326) := 'ed_term || ''}''   '||wwv_flow.LF||
'                                        end '||wwv_flow.LF||
'                                   wh';
wwv_flow_imp.g_varchar2_table(327) := 'en p_feature = ''FUZZY''   '||wwv_flow.LF||
'                                   then ''FUZZY({'' || l_cleaned_term || ''},';
wwv_flow_imp.g_varchar2_table(328) := '40,1000,W)''   '||wwv_flow.LF||
'                               end   '||wwv_flow.LF||
'                            --   '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(329) := '               -- term1 term2 term3 ... term8 term9 ... term 15   '||wwv_flow.LF||
'                            -- --';
wwv_flow_imp.g_varchar2_table(330) := '--- ----- -----     ----- -----     -------   '||wwv_flow.LF||
'                            --  *3.0  *2.3  *2.0 ... ';
wwv_flow_imp.g_varchar2_table(331) := '*0.3  *0.1  ...    *0.1   '||wwv_flow.LF||
'                            --   '||wwv_flow.LF||
'                            || coalesce';
wwv_flow_imp.g_varchar2_table(332) := '( p_score, case when p_pos > 8   '||wwv_flow.LF||
'                                                       then ''*0.1''';
wwv_flow_imp.g_varchar2_table(333) := '   '||wwv_flow.LF||
'                                                       when p_pos = 1   '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(334) := '                                then ''*3''   '||wwv_flow.LF||
'                                                       ';
wwv_flow_imp.g_varchar2_table(335) := 'else ''*'' || to_char( round( 3 - ( p_pos / 3 ), 1 ),   '||wwv_flow.LF||
'                                             ';
wwv_flow_imp.g_varchar2_table(336) := '                               ''0D0'',   '||wwv_flow.LF||
'                                                           ';
wwv_flow_imp.g_varchar2_table(337) := '                 ''nls_numeric_characters=''''.,'''''' )   '||wwv_flow.LF||
'                                              ';
wwv_flow_imp.g_varchar2_table(338) := '    end )   '||wwv_flow.LF||
'                            || '' within('' || p_section || '')''   '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(339) := '   --   '||wwv_flow.LF||
'                       when p_feature = ''NDATA''   '||wwv_flow.LF||
'                       then    ''NDATA( ''';
wwv_flow_imp.g_varchar2_table(340) := '   '||wwv_flow.LF||
'                            || p_section   '||wwv_flow.LF||
'                            || '',''   '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(341) := '              || l_cleaned_term  '||wwv_flow.LF||
'                            || '')''   '||wwv_flow.LF||
'                         -- ';
wwv_flow_imp.g_varchar2_table(342) := '  '||wwv_flow.LF||
'                       when p_feature = ''SDATA''   '||wwv_flow.LF||
'                       then    ''SDATA( ''   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(343) := '                          || p_section   '||wwv_flow.LF||
'                            || case p_operator   '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(344) := '                           when ''like''  then '' like '' || sys.dbms_assert.enquote_literal( ''%'' || p_t';
wwv_flow_imp.g_varchar2_table(345) := 'erm || ''%'') || '')''   '||wwv_flow.LF||
'                                   when ''rlike'' then '' like '' || sys.dbms_asse';
wwv_flow_imp.g_varchar2_table(346) := 'rt.enquote_literal(        p_term || ''%'') || '')''   '||wwv_flow.LF||
'                                   when ''llike'' ';
wwv_flow_imp.g_varchar2_table(347) := 'then '' like '' || sys.dbms_assert.enquote_literal( ''%'' || p_term       ) || '')''   '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(348) := '                 else                 '' = '' || sys.dbms_assert.enquote_literal(        p_term       ';
wwv_flow_imp.g_varchar2_table(349) := ') || '')''   '||wwv_flow.LF||
'                               end   '||wwv_flow.LF||
'                         --   '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(350) := '    else ''{'' || l_cleaned_term || ''}''   '||wwv_flow.LF||
'                   end;   '||wwv_flow.LF||
'        end add_term_to_query_pa';
wwv_flow_imp.g_varchar2_table(351) := 'rt;   '||wwv_flow.LF||
'    begin   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        for i in 1 .. p_tokens.count loop   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            if p_tokens( i ';
wwv_flow_imp.g_varchar2_table(352) := ') is not null then   '||wwv_flow.LF||
''||wwv_flow.LF||
'                l_added_term := add_term_to_query_part(   '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(353) := '                  p_term => p_tokens( i ),   '||wwv_flow.LF||
'                                    p_pos  => i );   '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(354) := '   '||wwv_flow.LF||
'               if      l_query is not null   '||wwv_flow.LF||
'                   and l_added_term is not null'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(355) := '                 and p_combiner is not null   '||wwv_flow.LF||
'                then   '||wwv_flow.LF||
'                    l_query :';
wwv_flow_imp.g_varchar2_table(356) := '= l_query   '||wwv_flow.LF||
'                            || '' ''   '||wwv_flow.LF||
'                            || p_combiner;   '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(357) := '             end if;  '||wwv_flow.LF||
''||wwv_flow.LF||
'                if l_added_term is not null then'||wwv_flow.LF||
''||wwv_flow.LF||
'                    l_quer';
wwv_flow_imp.g_varchar2_table(358) := 'y := l_query   '||wwv_flow.LF||
'                            || '' ''   '||wwv_flow.LF||
'                            || l_added_term;  ';
wwv_flow_imp.g_varchar2_table(359) := ' '||wwv_flow.LF||
''||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'       '||wwv_flow.LF||
'            end if;   '||wwv_flow.LF||
'        end loop;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        return co';
wwv_flow_imp.g_varchar2_table(360) := 'alesce( trim( l_query ), ''%'' );   '||wwv_flow.LF||
'    end generate_text_query_part;   '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'    if p_search_exp';
wwv_flow_imp.g_varchar2_table(361) := 'ression is null then   '||wwv_flow.LF||
'        apex_debug.info( ''empty query - return "%"'');  '||wwv_flow.LF||
'        return ''%''; ';
wwv_flow_imp.g_varchar2_table(362) := '  '||wwv_flow.LF||
'    end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    l_column := p_config.first;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    while l_column is not null loop   '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(363) := '        if l_highest_prio < nvl( p_config( l_column ).priority, 1 ) then   '||wwv_flow.LF||
'            l_highest_pr';
wwv_flow_imp.g_varchar2_table(364) := 'io := p_config( l_column ).priority;   '||wwv_flow.LF||
'        end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'        l_column := p_config.next( l_';
wwv_flow_imp.g_varchar2_table(365) := 'column );   '||wwv_flow.LF||
'    end loop;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    l_tokens := tokenize( pre_process_search_string( p_search_expr';
wwv_flow_imp.g_varchar2_table(366) := 'ession ) );   '||wwv_flow.LF||
'    pre_process_tokens( l_tokens );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    for p in 1 .. l_highest_prio loop   '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(367) := '  '||wwv_flow.LF||
'        for cmb in 1 .. c_combiners.count loop   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            l_idx := ( p - 1 ) * 2 + cmb;  ';
wwv_flow_imp.g_varchar2_table(368) := ' '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            l_fuzzy_search( l_idx ) := '''';   '||wwv_flow.LF||
'            l_exact_search( l_idx ) := '''';   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(369) := '          l_ndata_search( l_idx ) := '''';   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'            l_column := p_config.first;   '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(370) := '   while l_column is not null loop   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'                l_text_column := clean_column_name( l_colu';
wwv_flow_imp.g_varchar2_table(371) := 'mn );   '||wwv_flow.LF||
'                --   '||wwv_flow.LF||
'                -- does the column''s pririoty match the currently pro';
wwv_flow_imp.g_varchar2_table(372) := 'cessed priority?   '||wwv_flow.LF||
'                --   '||wwv_flow.LF||
'                if nvl( p_config( l_column ).priority, 1 )';
wwv_flow_imp.g_varchar2_table(373) := ' = p then   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'                    l_tokens_for_column := filter_tokens_for_column(   '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(374) := '                                    p_original_tokens => l_tokens,   '||wwv_flow.LF||
'                              ';
wwv_flow_imp.g_varchar2_table(375) := '                 p_column          => l_column );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'                    if      l_tokens_for_co';
wwv_flow_imp.g_varchar2_table(376) := 'lumn.count > 1   '||wwv_flow.LF||
'                       or ( l_tokens_for_column.count = 1 and cmb = 1 )   '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(377) := '             then   '||wwv_flow.LF||
'                        if p_config( l_column ).sdata_search then   '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(378) := '                  l_exact_search( l_idx ) := l_exact_search( l_idx )   '||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(379) := '                        || case when l_exact_search( l_idx ) is not null then '' AND '' end   '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(380) := '                                             || ''(''   '||wwv_flow.LF||
'                                             ';
wwv_flow_imp.g_varchar2_table(381) := '       || generate_text_query_part(   '||wwv_flow.LF||
'                                                           p_';
wwv_flow_imp.g_varchar2_table(382) := 'tokens   => l_tokens_for_column,   '||wwv_flow.LF||
'                                                           p_fea';
wwv_flow_imp.g_varchar2_table(383) := 'ture  => ''SDATA'',   '||wwv_flow.LF||
'                                                           p_operator => p_conf';
wwv_flow_imp.g_varchar2_table(384) := 'ig( l_column ).sdata_op,   '||wwv_flow.LF||
'                                                           p_score    =>';
wwv_flow_imp.g_varchar2_table(385) := ' p_config( l_column ).score_expr,   '||wwv_flow.LF||
'                                                           p_se';
wwv_flow_imp.g_varchar2_table(386) := 'ction  => l_text_column || c_suffix_sd,   '||wwv_flow.LF||
'                                                         ';
wwv_flow_imp.g_varchar2_table(387) := '  p_combiner => c_combiners( cmb ) )   '||wwv_flow.LF||
'                                                    || '')''; ';
wwv_flow_imp.g_varchar2_table(388) := '  '||wwv_flow.LF||
'                        end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'                        if p_config( l_column ).field_sear';
wwv_flow_imp.g_varchar2_table(389) := 'ch then   '||wwv_flow.LF||
'                            l_exact_search( l_idx ) := l_exact_search( l_idx )   '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(390) := '                                             || case when l_exact_search( l_idx ) is not null then ''';
wwv_flow_imp.g_varchar2_table(391) := ' AND '' end   '||wwv_flow.LF||
'                                                    || ''(''   '||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(392) := '                            || generate_text_query_part(   '||wwv_flow.LF||
'                                        ';
wwv_flow_imp.g_varchar2_table(393) := '                   p_tokens                 => l_tokens_for_column,   '||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(394) := '                              p_feature                => ''EXACT'',   '||wwv_flow.LF||
'                              ';
wwv_flow_imp.g_varchar2_table(395) := '                             p_two_char_terms_enabled => p_config( l_column ).two_char_terms_enabled';
wwv_flow_imp.g_varchar2_table(396) := ', '||wwv_flow.LF||
'                                                           p_operator               => null,   '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(397) := '                                                          p_score                  => p_config( l_co';
wwv_flow_imp.g_varchar2_table(398) := 'lumn ).score_expr,   '||wwv_flow.LF||
'                                                           p_section          ';
wwv_flow_imp.g_varchar2_table(399) := '      => l_text_column || c_suffix_f,   '||wwv_flow.LF||
'                                                           ';
wwv_flow_imp.g_varchar2_table(400) := 'p_combiner               => c_combiners( cmb ) )   '||wwv_flow.LF||
'                                                ';
wwv_flow_imp.g_varchar2_table(401) := '    || '')'';   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'                            l_fuzzy_search( l_idx ) := l_fuzzy_search( l_idx )   ';
wwv_flow_imp.g_varchar2_table(402) := ''||wwv_flow.LF||
'                                                    || case when l_fuzzy_search( l_idx ) is not nul';
wwv_flow_imp.g_varchar2_table(403) := 'l then '' AND '' end   '||wwv_flow.LF||
'                                                    || ''(''   '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(404) := '                                    || generate_text_query_part(   '||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(405) := '                           p_tokens   => l_tokens_for_column,   '||wwv_flow.LF||
'                                   ';
wwv_flow_imp.g_varchar2_table(406) := '                        p_feature  => ''FUZZY'',   '||wwv_flow.LF||
'                                                  ';
wwv_flow_imp.g_varchar2_table(407) := '         p_operator => null,   '||wwv_flow.LF||
'                                                           p_score  ';
wwv_flow_imp.g_varchar2_table(408) := '  => p_config( l_column ).score_expr,   '||wwv_flow.LF||
'                                                           ';
wwv_flow_imp.g_varchar2_table(409) := 'p_section  => l_text_column || c_suffix_f,   '||wwv_flow.LF||
'                                                      ';
wwv_flow_imp.g_varchar2_table(410) := '     p_combiner => c_combiners( cmb ) )   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'                                                    |';
wwv_flow_imp.g_varchar2_table(411) := '| '')'';   '||wwv_flow.LF||
'                        end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'                        if p_config( l_column ).nda';
wwv_flow_imp.g_varchar2_table(412) := 'ta_search then   '||wwv_flow.LF||
'                            l_ndata_search( l_idx ) := l_ndata_search( l_idx )   '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(413) := '                                                    || case when l_ndata_search( l_idx ) is not null';
wwv_flow_imp.g_varchar2_table(414) := ' then '' AND '' end   '||wwv_flow.LF||
'                                                    || ''(''   '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(415) := '                                   || generate_text_query_part(   '||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(416) := '                          p_tokens   => l_tokens_for_column,   '||wwv_flow.LF||
'                                    ';
wwv_flow_imp.g_varchar2_table(417) := '                       p_feature  => ''NDATA'',   '||wwv_flow.LF||
'                                                   ';
wwv_flow_imp.g_varchar2_table(418) := '        p_operator => null,   '||wwv_flow.LF||
'                                                           p_score   ';
wwv_flow_imp.g_varchar2_table(419) := ' => p_config( l_column ).score_expr,   '||wwv_flow.LF||
'                                                           p';
wwv_flow_imp.g_varchar2_table(420) := '_section  => l_text_column || c_suffix_nd,   '||wwv_flow.LF||
'                                                      ';
wwv_flow_imp.g_varchar2_table(421) := '     p_combiner => c_combiners( cmb ) )   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'                                                    |';
wwv_flow_imp.g_varchar2_table(422) := '| '')'';   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'                        elsif not p_config( l_column ).sdata_search then   '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(423) := '                  --   '||wwv_flow.LF||
'                            -- if a column does *not* have NDATA enabled, we';
wwv_flow_imp.g_varchar2_table(424) := ' need to add as normal FUZZY search,   '||wwv_flow.LF||
'                            -- as NDATA search is the next p';
wwv_flow_imp.g_varchar2_table(425) := 'rogressive relaxation level. Not adding the columns in   '||wwv_flow.LF||
'                            -- would yield';
wwv_flow_imp.g_varchar2_table(426) := ' in NDATA being searched without combining with filters for other columns   '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(427) := '     -- on that level.   '||wwv_flow.LF||
'                            -- However, for SDATA columns we''re not doing ';
wwv_flow_imp.g_varchar2_table(428) := 'this, as SDATA operators are typically   '||wwv_flow.LF||
'                            -- used exclusively.   '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(429) := '                      --   '||wwv_flow.LF||
'                            l_ndata_search( l_idx ) := l_ndata_search( l';
wwv_flow_imp.g_varchar2_table(430) := '_idx )   '||wwv_flow.LF||
'                                                    || case when l_ndata_search( l_idx ) i';
wwv_flow_imp.g_varchar2_table(431) := 's not null then '' AND '' end   '||wwv_flow.LF||
'                                                    || ''(''   '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(432) := '                                             || generate_text_query_part(   '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(433) := '                                    p_tokens   => l_tokens_for_column,   '||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(434) := '                                 p_feature  => ''FUZZY'',   '||wwv_flow.LF||
'                                         ';
wwv_flow_imp.g_varchar2_table(435) := '                  p_operator => null,   '||wwv_flow.LF||
'                                                           ';
wwv_flow_imp.g_varchar2_table(436) := 'p_score    => p_config( l_column ).score_expr,   '||wwv_flow.LF||
'                                                  ';
wwv_flow_imp.g_varchar2_table(437) := '         p_section  => l_text_column || c_suffix_f,   '||wwv_flow.LF||
'                                             ';
wwv_flow_imp.g_varchar2_table(438) := '              p_combiner => c_combiners( cmb ) )   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'                                            ';
wwv_flow_imp.g_varchar2_table(439) := '        || '')'';   '||wwv_flow.LF||
'                        end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'                    end if;   '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(440) := '     end if;   '||wwv_flow.LF||
'                l_column := p_config.next( l_column );   '||wwv_flow.LF||
'            end loop;   '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(441) := '       end loop;   '||wwv_flow.LF||
'    end loop;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    l_generated_query := to_clob( ''<query><textquery><progr';
wwv_flow_imp.g_varchar2_table(442) := 'ession>'' ); '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    for p in 1 .. l_exact_search.count loop   '||wwv_flow.LF||
'        l_generated_query := l_gener';
wwv_flow_imp.g_varchar2_table(443) := 'ated_query   '||wwv_flow.LF||
'                          || case when l_exact_search(p) is not null then ''<seq>'' || l';
wwv_flow_imp.g_varchar2_table(444) := '_exact_search(p) || ''</seq>'' end   '||wwv_flow.LF||
'                          || case when l_fuzzy_search(p) is not ';
wwv_flow_imp.g_varchar2_table(445) := 'null then ''<seq>'' || l_fuzzy_search(p) || ''</seq>'' end   '||wwv_flow.LF||
'                          || case when l_n';
wwv_flow_imp.g_varchar2_table(446) := 'data_search(p) is not null then ''<seq>'' || l_ndata_search(p) || ''</seq>'' end;   '||wwv_flow.LF||
'    end loop;   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(447) := ' '||wwv_flow.LF||
'    l_generated_query := l_generated_query || ''</progression></textquery></query>'';   '||wwv_flow.LF||
'  '||wwv_flow.LF||
'    if l';
wwv_flow_imp.g_varchar2_table(448) := '_generated_query = ''<query><textquery><progression></progression></textquery></query>'' then  '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(449) := '  return ''%'';  '||wwv_flow.LF||
'    end if;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'    if length( l_generated_query ) > 64000 THEN   '||wwv_flow.LF||
'        raise_';
wwv_flow_imp.g_varchar2_table(450) := 'application_error( -20001, ''TEXT Query is too long.'', true );   '||wwv_flow.LF||
'    end if;   '||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_genera';
wwv_flow_imp.g_varchar2_table(451) := 'ted_query;   '||wwv_flow.LF||
'end search_query;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'--===========================================================';
wwv_flow_imp.g_varchar2_table(452) := '===================   '||wwv_flow.LF||
'-- Returns the context query based on the config record.   '||wwv_flow.LF||
'--===============';
wwv_flow_imp.g_varchar2_table(453) := '===============================================================   '||wwv_flow.LF||
'function get_name_search_query(  ';
wwv_flow_imp.g_varchar2_table(454) := ' '||wwv_flow.LF||
'    p_search_expression in varchar2 )   '||wwv_flow.LF||
'    return varchar2   '||wwv_flow.LF||
'is   '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'    return search_q';
wwv_flow_imp.g_varchar2_table(455) := 'uery(   '||wwv_flow.LF||
'               p_table_name        => ''EMPLOYEES'',   '||wwv_flow.LF||
'               p_index_column      =>';
wwv_flow_imp.g_varchar2_table(456) := ' ''LAST_NAME'',   '||wwv_flow.LF||
'               p_search_expression => p_search_expression,   '||wwv_flow.LF||
'               p_conf';
wwv_flow_imp.g_varchar2_table(457) := 'ig            => get_config );   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'end get_name_search_query;   '||wwv_flow.LF||
'   '||wwv_flow.LF||
'end eba_search_text_helper;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(458) := '/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2198362493992589798)
,p_install_id=>wwv_flow_imp.id(2198361304136574490)
,p_name=>'eba_search_text_helper body'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
