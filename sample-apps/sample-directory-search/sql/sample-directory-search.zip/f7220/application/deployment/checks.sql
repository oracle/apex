prompt --application/deployment/checks
begin
--   Manifest
--     INSTALL CHECKS: 7220
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_check(
 p_id=>wwv_flow_imp.id(5966289148678885169)
,p_install_id=>wwv_flow_imp.id(2198361304136574490)
,p_name=>'Is Database 23ai or higher?'
,p_sequence=>10
,p_check_type=>'EXPRESSION'
,p_check_condition=>'sys.dbms_db_version.version >= 23'
,p_check_condition2=>'PLSQL'
,p_failure_message=>'Database Version must be at least 26ai.'
);
wwv_flow_imp_shared.create_install_check(
 p_id=>wwv_flow_imp.id(5972867039142014978)
,p_install_id=>wwv_flow_imp.id(2198361304136574490)
,p_name=>'Oracle TEXT available'
,p_sequence=>20
,p_check_type=>'FUNCTION_BODY'
,p_check_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    execute immediate ',
'         ''declare '' ',
'      || ''procedure do_txt_check ''',
'      || ''is ''',
'      || ''begin ''',
'      || ''ctx_ddl.create_preference(''''pref'''', ''''user_datastore'''');''',
'      || ''end do_txt_check;''',
'      || ''begin null; end;'';',
'',
'    return true;',
'exception',
'    when others then',
'        return false;',
'end;',
''))
,p_check_condition2=>'PLSQL'
,p_failure_message=>'Oracle TEXT is not available to this database schema. Check CTXAPP role.'
);
wwv_flow_imp.component_end;
end;
/
