prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7220
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7220
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    eba_search_text_helper.drop_text_index( p_index_name => ''EBA_SRCH_TXT_EMPS_FTIDX'' );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2) := '/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba_srch_txt_cost_centers cascade constraints'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba_srch_txt_groups cascad';
wwv_flow_imp.g_varchar2_table(3) := 'e constraints'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba_srch_txt_employees  cascade constraints'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop view eba_srch_txt_em';
wwv_flow_imp.g_varchar2_table(4) := 'ployee_org_v'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba_srch_txt_countries'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop package eba_search_text_data'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop packa';
wwv_flow_imp.g_varchar2_table(5) := 'ge eba_search_text_helper'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(2198361304136574490)
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_names_available=>'EBA_SEARCH_TEXT_DATA:EBA_SEARCH_TEXT_HELPER:EBA_SRCH_TXT_COUNTRIES:EBA_SRCH_TXT_EMPLOYEES:EBA_SRCH_TXT_GROUPS:EBA_SRCH_TXT_COST_CENTERS:EBA_SRCH_TXT_EMPLOYEE_ORG_V'
);
wwv_flow_imp.component_end;
end;
/
