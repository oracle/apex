prompt --application/pages/page_00204
begin
--   Manifest
--     PAGE: 00204
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>204
,p_name=>'Custom Result Row Template'
,p_alias=>'CUSTOM-RESULT-ROW-TEMPLATE'
,p_step_title=>'Custom Result Row Template'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-ResultsItem{',
'    background: white;',
'    border-radius: 25px;',
'    box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;',
'    color: #394e6a;',
'    padding: 0px;',
'}',
'.a-ResultItem-image{',
'    padding: 0px;',
'    background-color: powderblue;',
'    border-top-left-radius: 25px;',
'    border-bottom-left-radius: 25px;',
'    object-fit: fill;',
'}',
'.a-ResultsItem-content{',
'    display: flex;',
'    flex-direction: row;',
'    justify-content: space-between;',
'    margin: 1rem;',
'}',
'.a-ResultsItem-title{',
'    font-size: x-large;',
'}',
'.a-ResultsItem-title a{',
'    color: #021431;',
'}',
'',
'.a-ResultsItem-subTitle{',
'    padding: .5rem 0;',
'}',
'.a-ResultsItem-subTitle span{',
'    color: #021431;',
'}',
'',
'.a-ResultsItem-price{',
'    color: #056ac8;',
'    font-size: xx-large;',
'    font-weight: 700;',
'}'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'26'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4926797079432631008)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(4926226270960679507)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6602201656764167890)
,p_plug_name=>'Overview'
,p_static_id=>'overview'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page demonstrates how to change the default result row display template using HTML expressions and template directives. There are two approaches to achieve this:</p>',
'<ol>',
'<li>Changing the Search Configuration setting under <strong><em>Icon and Display &rarr; Default Result Row Template</em></strong>.</li>',
'<li>Changing the search region attributes under <strong><em>Custom Layout</em></strong>.</li>',
'</ol>',
'<p>Note that with the second approach, you cannot substitute the original column names directly, but rather the generic column names (such as <em>Primary Key</em>, <em>Title</em>, etc.).</p>',
'<p>To test this functionality, type a search query (such as "<strong>boy</strong>"). The associated search configurations (in this case, the <em>Products Search Configuration</em>) will be executed and all the relevant results will be displayed with '
||'the new result row template.</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2478649798671350517)
,p_plug_name=>'Search'
,p_static_id=>'search'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_landmark_type=>'search'
,p_landmark_label=>'Products'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4926797684123631009)
,p_plug_name=>'Search Results'
,p_static_id=>'search-results'
,p_region_template_options=>'#DEFAULT#:margin-top-sm'
,p_plug_template=>1557215235004102827
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_landmark_type=>'exclude_landmark'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'custom_layout', 'N',
  'lazy_loading', 'Y',
  'minimum_characters', '0',
  'no_query_entered_message', 'Enter a query to search for products.',
  'no_results_found_message', 'No products found.',
  'results_per_page', '15',
  'results_per_page_type', 'STATIC',
  'search_as_you_type', 'Y',
  'search_page_item', 'P204_SEARCH',
  'show_result_count', 'N',
  'use_pagination', 'Y')).to_clob
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(4114414848126279876)
,p_region_id=>wwv_flow_imp.id(4926797684123631009)
,p_search_config_id=>wwv_flow_imp.id(4926736690496452990)
,p_use_as_initial_result=>false
,p_display_sequence=>10
,p_name=>'Product Search Configuration Custom Display'
,p_static_id=>'product-search-configuration-custom-display'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2468375940510653045)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4926797079432631008)
,p_button_name=>'NEXT'
,p_static_id=>'next'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:206:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2468375631001651288)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4926797079432631008)
,p_button_name=>'PREV'
,p_static_id=>'prev'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Previous'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4114414205954279875)
,p_name=>'P204_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2478649798671350517)
,p_prompt=>'Search'
,p_placeholder=>'Enter your search term, e.g. ''boy'''
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_grid_label_column_span=>0
,p_field_template=>2042262243893469891
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_warn_on_unsaved_changes=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'SEARCH',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2474891519960109679)
,p_name=>'Enter key'
,p_static_id=>'enter-key'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P204_SEARCH'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.browserEvent.keyCode === 13',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2474891864628109679)
,p_event_id=>wwv_flow_imp.id(2474891519960109679)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-cancel-event'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp.component_end;
end;
/
