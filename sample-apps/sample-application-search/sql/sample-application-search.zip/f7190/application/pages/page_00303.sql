prompt --application/pages/page_00303
begin
--   Manifest
--     PAGE: 00303
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>303
,p_name=>'Highlight Results'
,p_alias=>'HIGHLIGHT-RESULTS'
,p_step_title=>'Highlight Results'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Setting card icon background to transparent ',
'   so that the icon color from the Search Configuration ',
'   renders correctly */',
':root {',
'    --a-cv-icon-background-color: transparent;',
'}',
'',
'/* Change card icon size */',
'.a-CardView-icon{',
'    font-size: xx-large !important;',
'}',
'',
'/* Highlighting search term style */',
'',
'mark{',
'    border: 1px solid black;',
'    padding: 1px 0;',
'}',
''))
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5744430416468235039)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(4926226270960679507)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6602203384777179011)
,p_plug_name=>'Overview'
,p_static_id=>'overview'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page demonstrates how to highlight search terms in search results using Application Search. To achieve this, you need to use the public <code>Search</code> function to perform a search with the desired search configuration(<em>Store search co'
||'nfiguration</em> and <em>Product search configuration</em>) and add the highlighting. The search results will be displayed with the search terms highlighted in the matching rows.</p>',
'<p>Simply start typing a search query(or "<strong>Red</strong>" for example), and the configured Search Configuration will be triggered to display relevant results with highlighted search terms.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2478651334887357380)
,p_plug_name=>'Search'
,p_static_id=>'search'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_landmark_type=>'search'
,p_landmark_label=>'Products and Stores'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5744126504364188658)
,p_plug_name=>'Search Results'
,p_static_id=>'search-results'
,p_region_template_options=>'t-CardsRegion--styleA'
,p_plug_template=>2076152157930740558
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with escaped_output as (',
'        select config_label,',
'               primary_key_1,',
'               apex_escape.html(title)       as title,',
'               apex_escape.html(subtitle)    as subtitle,',
'               apex_escape.html(description) as description,',
'               badge,',
'               icon_type,',
'               ''fa '' || icon_value           as icon_value',
'          from table(',
'                   apex_search.search(',
'                       p_search_static_ids => apex_t_varchar2( ''store'', ''product'' ),',
'                       p_search_expression => :P303_SEARCH,',
'                       p_apply_order_bys   => ''N'' ) ) )',
'select config_label,',
'       primary_key_1,',
'       replace( lower(title),       lower(apex_escape.html(:P303_SEARCH)), ''<mark>'' || lower(apex_escape.html(:P303_SEARCH)) || ''</mark>'' ) as title,',
'       replace( lower(subtitle),    lower(apex_escape.html(:P303_SEARCH)), ''<mark>'' || lower(apex_escape.html(:P303_SEARCH)) || ''</mark>'' ) as subtitle,',
'       replace( lower(description), lower(apex_escape.html(:P303_SEARCH)), ''<mark>'' || lower(apex_escape.html(:P303_SEARCH)) || ''</mark>'' ) as description,',
'       badge,',
'       icon_type,',
'       icon_value',
'  from escaped_output'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P303_SEARCH'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'No customers, products or stores found.'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(4114461621814319766)
,p_region_id=>wwv_flow_imp.id(5744126504364188658)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<div class="a-CardView-title">&TITLE!RAW.</div>'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'&SUBTITLE!RAW.'
,p_body_adv_formatting=>true
,p_body_html_expr=>'&DESCRIPTION!RAW.'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'ICON_VALUE'
,p_icon_position=>'START'
,p_badge_column_name=>'BADGE'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'PRIMARY_KEY_1'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2468379786806678790)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5744430416468235039)
,p_button_name=>'NEXT'
,p_static_id=>'next'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2468379427154676728)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5744430416468235039)
,p_button_name=>'PREV'
,p_static_id=>'prev'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Previous'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:302:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4114462468794319767)
,p_name=>'P303_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2478651334887357380)
,p_prompt=>'Search'
,p_placeholder=>'Enter your search term, e.g. ''red'''
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_grid_label_column_span=>0
,p_field_template=>2044213549383960320
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'SEARCH',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2464408167274141519)
,p_name=>'Enter key'
,p_static_id=>'enter-key'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P303_SEARCH'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.browserEvent.keyCode === 13',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2464408608343141520)
,p_event_id=>wwv_flow_imp.id(2464408167274141519)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-cancel-event'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4114463419336319768)
,p_name=>'Search'
,p_static_id=>'search'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P303_SEARCH'
,p_bind_type=>'bind'
,p_execution_type=>'THROTTLE'
,p_execution_time=>500
,p_execution_immediate=>false
,p_bind_event_type=>'keyup'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4114463932989319768)
,p_event_id=>wwv_flow_imp.id(4114463419336319768)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5744126504364188658)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
