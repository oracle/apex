prompt --application/deployment/install/install_data
begin
--   Manifest
--     INSTALL: INSTALL-data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '----------------------------------------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '---'||wwv_flow.LF||
'-- Load Data'||wwv_flow.LF||
'-----------------------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(3) := '--------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package eba_demo_search_data_pkg authid current_user is'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(4) := 'procedure clear_data;'||wwv_flow.LF||
'    -- clears all the data in the database tables'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure load_data;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(5) := '  -- loads data into the database tables'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure load_product_images(p_app_id in number, p_fi';
wwv_flow_imp.g_varchar2_table(6) := 'le_name in varchar2);'||wwv_flow.LF||
'    -- loads images into the eba_demo_search_products table'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure res';
wwv_flow_imp.g_varchar2_table(7) := 'et_data;'||wwv_flow.LF||
'    -- reset all the data in the database tables'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_demo_search_data_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create o';
wwv_flow_imp.g_varchar2_table(8) := 'r replace package body eba_demo_search_data_pkg is'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure clear_data is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        de';
wwv_flow_imp.g_varchar2_table(9) := 'lete from EBA_DEMO_SEARCH_CUSTOMERS;'||wwv_flow.LF||
'        delete from EBA_DEMO_SEARCH_STORES;'||wwv_flow.LF||
'        delete from';
wwv_flow_imp.g_varchar2_table(10) := ' EBA_DEMO_SEARCH_ORDERS;'||wwv_flow.LF||
'        delete from EBA_DEMO_SEARCH_ORDER_ITEMS;'||wwv_flow.LF||
'        delete from EBA_DE';
wwv_flow_imp.g_varchar2_table(11) := 'MO_SEARCH_PRODUCTS;'||wwv_flow.LF||
'    end clear_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure load_data is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        -- Customers d';
wwv_flow_imp.g_varchar2_table(12) := 'ata'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_ID,FULL_NAME,EMAIL_ADDRESS) values (1,''T';
wwv_flow_imp.g_varchar2_table(13) := 'ammy Bryant'',''tammy.bryant@internalmail'');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_I';
wwv_flow_imp.g_varchar2_table(14) := 'D,FULL_NAME,EMAIL_ADDRESS) values (2,''Roy White'',''roy.white@internalmail'');'||wwv_flow.LF||
'        Insert into EBA_';
wwv_flow_imp.g_varchar2_table(15) := 'DEMO_SEARCH_CUSTOMERS (CUSTOMER_ID,FULL_NAME,EMAIL_ADDRESS) values (3,''Gary Jenkins'',''gary.jenkins@i';
wwv_flow_imp.g_varchar2_table(16) := 'nternalmail'');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_ID,FULL_NAME,EMAIL_ADDRESS) v';
wwv_flow_imp.g_varchar2_table(17) := 'alues (4,''Victor Morris'',''victor.morris@internalmail'');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_CUSTOMER';
wwv_flow_imp.g_varchar2_table(18) := 'S (CUSTOMER_ID,FULL_NAME,EMAIL_ADDRESS) values (5,''Beverly Hughes'',''beverly.hughes@internalmail'');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(19) := '       Insert into EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_ID,FULL_NAME,EMAIL_ADDRESS) values (6,''Evelyn';
wwv_flow_imp.g_varchar2_table(20) := ' Torres'',''evelyn.torres@internalmail'');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_ID,F';
wwv_flow_imp.g_varchar2_table(21) := 'ULL_NAME,EMAIL_ADDRESS) values (7,''Carl Lee'',''carl.lee@internalmail'');'||wwv_flow.LF||
'        Insert into EBA_DEMO_';
wwv_flow_imp.g_varchar2_table(22) := 'SEARCH_CUSTOMERS (CUSTOMER_ID,FULL_NAME,EMAIL_ADDRESS) values (8,''Douglas Flores'',''douglas.flores@in';
wwv_flow_imp.g_varchar2_table(23) := 'ternalmail'');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_ID,FULL_NAME,EMAIL_ADDRESS) va';
wwv_flow_imp.g_varchar2_table(24) := 'lues (9,''Norma Robinson'',''norma.robinson@internalmail'');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_CUSTOME';
wwv_flow_imp.g_varchar2_table(25) := 'RS (CUSTOMER_ID,FULL_NAME,EMAIL_ADDRESS) values (10,''Gregory Sanchez'',''gregory.sanchez@internalmail''';
wwv_flow_imp.g_varchar2_table(26) := ');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_ID,FULL_NAME,EMAIL_ADDRESS) values (11,''J';
wwv_flow_imp.g_varchar2_table(27) := 'udy Evans'',''judy.evans@internalmail'');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_ID,FU';
wwv_flow_imp.g_varchar2_table(28) := 'LL_NAME,EMAIL_ADDRESS) values (12,''Jean Patterson'',''jean.patterson@internalmail'');'||wwv_flow.LF||
'        Insert in';
wwv_flow_imp.g_varchar2_table(29) := 'to EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_ID,FULL_NAME,EMAIL_ADDRESS) values (13,''Michelle Ramirez'',''mi';
wwv_flow_imp.g_varchar2_table(30) := 'chelle.ramirez@internalmail'');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_ID,FULL_NAME,';
wwv_flow_imp.g_varchar2_table(31) := 'EMAIL_ADDRESS) values (14,''Elizabeth Martinez'',''elizabeth.martinez@internalmail'');'||wwv_flow.LF||
'        Insert in';
wwv_flow_imp.g_varchar2_table(32) := 'to EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_ID,FULL_NAME,EMAIL_ADDRESS) values (15,''Walter Rogers'',''walte';
wwv_flow_imp.g_varchar2_table(33) := 'r.rogers@internalmail'');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_ID,FULL_NAME,EMAIL_';
wwv_flow_imp.g_varchar2_table(34) := 'ADDRESS) values (16,''Ralph Foster'',''ralph.foster@internalmail'');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH';
wwv_flow_imp.g_varchar2_table(35) := '_CUSTOMERS (CUSTOMER_ID,FULL_NAME,EMAIL_ADDRESS) values (17,''Tina Simmons'',''tina.simmons@internalmai';
wwv_flow_imp.g_varchar2_table(36) := 'l'');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_ID,FULL_NAME,EMAIL_ADDRESS) values (18,';
wwv_flow_imp.g_varchar2_table(37) := '''Peter Jones'',''peter.jones@internalmail'');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_I';
wwv_flow_imp.g_varchar2_table(38) := 'D,FULL_NAME,EMAIL_ADDRESS) values (19,''Kathryn Rogers'',''kathryn.rogers@internalmail'');'||wwv_flow.LF||
'        Inser';
wwv_flow_imp.g_varchar2_table(39) := 't into EBA_DEMO_SEARCH_CUSTOMERS (CUSTOMER_ID,FULL_NAME,EMAIL_ADDRESS) values (20,''Dennis Lopez'',''de';
wwv_flow_imp.g_varchar2_table(40) := 'nnis.lopez@internalmail'');'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Stores data'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_STORES (STORE';
wwv_flow_imp.g_varchar2_table(41) := '_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values (1,''Online'',''https://www.exam';
wwv_flow_imp.g_varchar2_table(42) := 'ple.com'',null,null,null);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_ADDRES';
wwv_flow_imp.g_varchar2_table(43) := 'S,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values (2,''San Francisco'',null,''Redwood Shores'||wwv_flow.LF||
'500 Oracle Par';
wwv_flow_imp.g_varchar2_table(44) := 'kway'||wwv_flow.LF||
'Redwood Shores, CA 94065'',37.529395,-122.267237);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_STORES (S';
wwv_flow_imp.g_varchar2_table(45) := 'TORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values (3,''Seattle'',null,''1501 F';
wwv_flow_imp.g_varchar2_table(46) := 'ourth Avenue'||wwv_flow.LF||
'Suite 1800'||wwv_flow.LF||
'Seattle, WA 98101'',47.6053,-122.33221);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_';
wwv_flow_imp.g_varchar2_table(47) := 'STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values (4,''New York Cit';
wwv_flow_imp.g_varchar2_table(48) := 'y'',null,''205 Lexington Ave'||wwv_flow.LF||
'7th Floor'||wwv_flow.LF||
'New York, NY 10016'',40.745216,-73.980518);'||wwv_flow.LF||
'        Insert into ';
wwv_flow_imp.g_varchar2_table(49) := 'EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values ';
wwv_flow_imp.g_varchar2_table(50) := '(5,''Chicago'',null,''233 South Wacker Dr.'||wwv_flow.LF||
'45th Floor'||wwv_flow.LF||
'Chicago, IL 60606'',41.878751,-87.636675);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(51) := ' Insert into EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGI';
wwv_flow_imp.g_varchar2_table(52) := 'TUDE) values (6,''London'',null,''One South Place'||wwv_flow.LF||
'London'||wwv_flow.LF||
'EC2M 2RB'',51.519281,-0.087296);'||wwv_flow.LF||
'        Insert';
wwv_flow_imp.g_varchar2_table(53) := ' into EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) v';
wwv_flow_imp.g_varchar2_table(54) := 'alues (7,''Bucharest'',null,''Floreasca Park'||wwv_flow.LF||
'43 Soseaua Pipera, corp B.'||wwv_flow.LF||
'Sector 2'||wwv_flow.LF||
'Bucharest , 014254'||wwv_flow.LF||
'RO''';
wwv_flow_imp.g_varchar2_table(55) := ',44.43225,26.10626);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,PHY';
wwv_flow_imp.g_varchar2_table(56) := 'SICAL_ADDRESS,LATITUDE,LONGITUDE) values (8,''Berlin'',null,''Behrenstrabe 42 (Humboldt Carre)'||wwv_flow.LF||
'10117 Be';
wwv_flow_imp.g_varchar2_table(57) := 'rlin'',52.5161,13.3873);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,';
wwv_flow_imp.g_varchar2_table(58) := 'PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values (9,''Utrecht'',null,''Hertogswetering 163-167, 3543 AS Utre';
wwv_flow_imp.g_varchar2_table(59) := 'cht, Netherlands'',52.103263,5.061644);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_NA';
wwv_flow_imp.g_varchar2_table(60) := 'ME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values (10,''Madrid'',null,''C/ Jose Echegaray 6B'||wwv_flow.LF||
'L';
wwv_flow_imp.g_varchar2_table(61) := 'as Rozas'||wwv_flow.LF||
'28230 Madrid'',40.4929,-3.8737);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_';
wwv_flow_imp.g_varchar2_table(62) := 'NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values (11,''Johannesburg'',null,''Woodmead North';
wwv_flow_imp.g_varchar2_table(63) := ' Office Park'||wwv_flow.LF||
'54 Maxwell Drive'||wwv_flow.LF||
'Jukskeiview, Sandton, 2196'',-26.044222,28.094662);'||wwv_flow.LF||
'        Insert into';
wwv_flow_imp.g_varchar2_table(64) := ' EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values';
wwv_flow_imp.g_varchar2_table(65) := ' (12,''Lagos'',null,''1391 Tiamiyu Savage St, Victoria Island, Lagos, Nigeria'',6.42806,3.42199);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(66) := '  Insert into EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONG';
wwv_flow_imp.g_varchar2_table(67) := 'ITUDE) values (13,''Bengaluru'',null,''193, Bannerghatta Main Rd, Industrial Area, Stage 2, BTM Layout,';
wwv_flow_imp.g_varchar2_table(68) := ' Bengaluru, Karnataka 560076, India'',12.8939,77.5978);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_STORES (S';
wwv_flow_imp.g_varchar2_table(69) := 'TORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values (14,''Mumbai'',null,''First ';
wwv_flow_imp.g_varchar2_table(70) := 'International Financial Center'||wwv_flow.LF||
'Unit No. 501, Level 5'||wwv_flow.LF||
'No. C54 & 55, G Block'||wwv_flow.LF||
'Bandra Kurla Complex'||wwv_flow.LF||
'CTS ';
wwv_flow_imp.g_varchar2_table(71) := 'No. 4207, Kolekalyan Village'||wwv_flow.LF||
'Mumbai - 400 051'||wwv_flow.LF||
'India'',19.069405,72.870143);'||wwv_flow.LF||
'        Insert into EBA_D';
wwv_flow_imp.g_varchar2_table(72) := 'EMO_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values (15,''';
wwv_flow_imp.g_varchar2_table(73) := 'New Dehli'',null,''F-01/02, First Floor'||wwv_flow.LF||
'Salcon Rasvillas'||wwv_flow.LF||
'D-1, District Centre,'||wwv_flow.LF||
'Saket, New Delhi - 1100';
wwv_flow_imp.g_varchar2_table(74) := '17'||wwv_flow.LF||
'India'',28.527693,77.220135);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_';
wwv_flow_imp.g_varchar2_table(75) := 'ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values (16,''Sydney'',null,''Riverside Corporate Park'||wwv_flow.LF||
'4 Ju';
wwv_flow_imp.g_varchar2_table(76) := 'lius Avenue'||wwv_flow.LF||
'North Ryde'||wwv_flow.LF||
'NSW 2113'',-33.797279,151.143826);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_STORES ';
wwv_flow_imp.g_varchar2_table(77) := '(STORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values (17,''Perth'',null,''Level';
wwv_flow_imp.g_varchar2_table(78) := ' 9'||wwv_flow.LF||
'225 St Georges Terrace'||wwv_flow.LF||
'Perth WA 6000'',-31.953715,115.851645);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH';
wwv_flow_imp.g_varchar2_table(79) := '_STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values (18,''Sao Paulo''';
wwv_flow_imp.g_varchar2_table(80) := ',null,''Rua Dr. Jose Aureo Bustamante,'||wwv_flow.LF||
'455 - Vila Cordeiro,'||wwv_flow.LF||
'CEP 04710-090 Sao Paulo'',-23.5475,-46.636';
wwv_flow_imp.g_varchar2_table(81) := '11);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LA';
wwv_flow_imp.g_varchar2_table(82) := 'TITUDE,LONGITUDE) values (19,''Buenos Aires'',null,''Juana Manso 1069, Buenos Aires, Argentina'',-34.610';
wwv_flow_imp.g_varchar2_table(83) := '16,-58.362867);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL';
wwv_flow_imp.g_varchar2_table(84) := '_ADDRESS,LATITUDE,LONGITUDE) values (20,''Mexico City'',null,''Montes Urales # 470 P3'||wwv_flow.LF||
'Col. Lomas de Cha';
wwv_flow_imp.g_varchar2_table(85) := 'pultepec'||wwv_flow.LF||
'Delegacion Miguel Hidalgo - C.P. 11000'',19.428489,-99.205745);'||wwv_flow.LF||
'        Insert into EBA_DEMO';
wwv_flow_imp.g_varchar2_table(86) := '_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGITUDE) values (21,''Bej';
wwv_flow_imp.g_varchar2_table(87) := 'ing'',null,''China, Beijing Shi, Haidian Qu, Dongbeiwang W Rd, 8, 100085'',40.0572,116.290061);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(88) := ' Insert into EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_ADDRESS,LATITUDE,LONGI';
wwv_flow_imp.g_varchar2_table(89) := 'TUDE) values (22,''Tokyo'',null,''2 Chome-5-? Kitaaoyama, Minato City, Tokyo 107-0061, Japan'',35.671534';
wwv_flow_imp.g_varchar2_table(90) := ',139.718584);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_STORES (STORE_ID,STORE_NAME,WEB_ADDRESS,PHYSICAL_A';
wwv_flow_imp.g_varchar2_table(91) := 'DDRESS,LATITUDE,LONGITUDE) values (23,''Tel Aviv'',null,''B, Aharon Bart St 18, Petah Tikva, 4951400, I';
wwv_flow_imp.g_varchar2_table(92) := 'srael'',32.100664,34.862138);'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Orders data'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORD';
wwv_flow_imp.g_varchar2_table(93) := 'ER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (453,to_timestamp(''23-JUL-22 12.13.03';
wwv_flow_imp.g_varchar2_table(94) := '.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),4,''COMPLETE'',4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDE';
wwv_flow_imp.g_varchar2_table(95) := 'RS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (506,to_timestamp(''07-AUG-22 1';
wwv_flow_imp.g_varchar2_table(96) := '0.56.44.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),4,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEAR';
wwv_flow_imp.g_varchar2_table(97) := 'CH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (513,to_timestamp(''09-A';
wwv_flow_imp.g_varchar2_table(98) := 'UG-22 08.00.22.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),15,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_';
wwv_flow_imp.g_varchar2_table(99) := 'DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (544,to_timest';
wwv_flow_imp.g_varchar2_table(100) := 'amp(''16-AUG-22 06.32.10.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),3,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert i';
wwv_flow_imp.g_varchar2_table(101) := 'nto EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (585,t';
wwv_flow_imp.g_varchar2_table(102) := 'o_timestamp(''26-AUG-22 11.02.38.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),4,''CANCELLED'',1);'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(103) := 'Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) value';
wwv_flow_imp.g_varchar2_table(104) := 's (608,to_timestamp(''01-SEP-22 08.01.41.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),3,''CANCELLED'',1);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(105) := '        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_I';
wwv_flow_imp.g_varchar2_table(106) := 'D) values (672,to_timestamp(''13-SEP-22 01.37.34.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),4,''COMPLET';
wwv_flow_imp.g_varchar2_table(107) := 'E'',4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,';
wwv_flow_imp.g_varchar2_table(108) := 'STORE_ID) values (687,to_timestamp(''17-SEP-22 12.09.10.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),16,';
wwv_flow_imp.g_varchar2_table(109) := '''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER';
wwv_flow_imp.g_varchar2_table(110) := '_STATUS,STORE_ID) values (707,to_timestamp(''20-SEP-22 06.12.35.000000000 PM'',''DD-MON-RR HH.MI.SSXFF ';
wwv_flow_imp.g_varchar2_table(111) := 'AM''),5,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_';
wwv_flow_imp.g_varchar2_table(112) := 'ID,ORDER_STATUS,STORE_ID) values (760,to_timestamp(''29-SEP-22 07.19.53.000000000 AM'',''DD-MON-RR HH.M';
wwv_flow_imp.g_varchar2_table(113) := 'I.SSXFF AM''),19,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,C';
wwv_flow_imp.g_varchar2_table(114) := 'USTOMER_ID,ORDER_STATUS,STORE_ID) values (761,to_timestamp(''29-SEP-22 08.35.11.000000000 AM'',''DD-MON';
wwv_flow_imp.g_varchar2_table(115) := '-RR HH.MI.SSXFF AM''),11,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_D';
wwv_flow_imp.g_varchar2_table(116) := 'ATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (765,to_timestamp(''29-SEP-22 09.36.52.000000000 PM';
wwv_flow_imp.g_varchar2_table(117) := ''',''DD-MON-RR HH.MI.SSXFF AM''),2,''COMPLETE'',2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,';
wwv_flow_imp.g_varchar2_table(118) := 'ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (766,to_timestamp(''30-SEP-22 12.38.08.00000';
wwv_flow_imp.g_varchar2_table(119) := '0000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),3,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (OR';
wwv_flow_imp.g_varchar2_table(120) := 'DER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (769,to_timestamp(''30-SEP-22 02.49.2';
wwv_flow_imp.g_varchar2_table(121) := '8.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),6,''REFUNDED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORD';
wwv_flow_imp.g_varchar2_table(122) := 'ERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (808,to_timestamp(''08-OCT-22 ';
wwv_flow_imp.g_varchar2_table(123) := '04.06.33.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),14,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_S';
wwv_flow_imp.g_varchar2_table(124) := 'EARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (832,to_timestamp(''1';
wwv_flow_imp.g_varchar2_table(125) := '2-OCT-22 11.16.40.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),3,''COMPLETE'',3);'||wwv_flow.LF||
'        Insert into EBA';
wwv_flow_imp.g_varchar2_table(126) := '_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (839,to_times';
wwv_flow_imp.g_varchar2_table(127) := 'tamp(''14-OCT-22 01.59.20.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),12,''COMPLETE'',12);'||wwv_flow.LF||
'        Insert';
wwv_flow_imp.g_varchar2_table(128) := ' into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (862';
wwv_flow_imp.g_varchar2_table(129) := ',to_timestamp(''19-OCT-22 02.34.20.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),7,''COMPLETE'',7);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(130) := ' Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) valu';
wwv_flow_imp.g_varchar2_table(131) := 'es (899,to_timestamp(''27-OCT-22 09.42.00.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),17,''CANCELLED'',1)';
wwv_flow_imp.g_varchar2_table(132) := ';'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE';
wwv_flow_imp.g_varchar2_table(133) := '_ID) values (920,to_timestamp(''30-OCT-22 05.59.30.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),4,''COMPL';
wwv_flow_imp.g_varchar2_table(134) := 'ETE'',4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATU';
wwv_flow_imp.g_varchar2_table(135) := 'S,STORE_ID) values (928,to_timestamp(''31-OCT-22 05.07.56.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),9';
wwv_flow_imp.g_varchar2_table(136) := ',''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDE';
wwv_flow_imp.g_varchar2_table(137) := 'R_STATUS,STORE_ID) values (943,to_timestamp(''03-NOV-22 04.41.53.000000000 PM'',''DD-MON-RR HH.MI.SSXFF';
wwv_flow_imp.g_varchar2_table(138) := ' AM''),10,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOME';
wwv_flow_imp.g_varchar2_table(139) := 'R_ID,ORDER_STATUS,STORE_ID) values (950,to_timestamp(''05-NOV-22 07.02.43.000000000 AM'',''DD-MON-RR HH';
wwv_flow_imp.g_varchar2_table(140) := '.MI.SSXFF AM''),7,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,';
wwv_flow_imp.g_varchar2_table(141) := 'CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (960,to_timestamp(''06-NOV-22 09.18.36.000000000 PM'',''DD-MO';
wwv_flow_imp.g_varchar2_table(142) := 'N-RR HH.MI.SSXFF AM''),11,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_';
wwv_flow_imp.g_varchar2_table(143) := 'DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (968,to_timestamp(''08-NOV-22 12.30.18.000000000 A';
wwv_flow_imp.g_varchar2_table(144) := 'M'',''DD-MON-RR HH.MI.SSXFF AM''),9,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID';
wwv_flow_imp.g_varchar2_table(145) := ',ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (972,to_timestamp(''09-NOV-22 02.12.47.0000';
wwv_flow_imp.g_varchar2_table(146) := '00000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),6,''COMPLETE'',6);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (O';
wwv_flow_imp.g_varchar2_table(147) := 'RDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (986,to_timestamp(''11-NOV-22 07.03.';
wwv_flow_imp.g_varchar2_table(148) := '57.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),10,''CANCELLED'',10);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH';
wwv_flow_imp.g_varchar2_table(149) := '_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (993,to_timestamp(''13-NOV';
wwv_flow_imp.g_varchar2_table(150) := '-22 10.16.45.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),8,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEM';
wwv_flow_imp.g_varchar2_table(151) := 'O_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1052,to_timestam';
wwv_flow_imp.g_varchar2_table(152) := 'p(''22-NOV-22 05.14.32.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),13,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert int';
wwv_flow_imp.g_varchar2_table(153) := 'o EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1058,to';
wwv_flow_imp.g_varchar2_table(154) := '_timestamp(''24-NOV-22 03.58.10.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),6,''CANCELLED'',6);'||wwv_flow.LF||
'        I';
wwv_flow_imp.g_varchar2_table(155) := 'nsert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values';
wwv_flow_imp.g_varchar2_table(156) := ' (1082,to_timestamp(''28-NOV-22 05.29.33.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),8,''CANCELLED'',8);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(157) := '        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_I';
wwv_flow_imp.g_varchar2_table(158) := 'D) values (1102,to_timestamp(''01-DEC-22 10.25.32.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),9,''COMPLE';
wwv_flow_imp.g_varchar2_table(159) := 'TE'',9);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS';
wwv_flow_imp.g_varchar2_table(160) := ',STORE_ID) values (1,to_timestamp(''25-FEB-22 02.24.33.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),3,''C';
wwv_flow_imp.g_varchar2_table(161) := 'ANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_';
wwv_flow_imp.g_varchar2_table(162) := 'STATUS,STORE_ID) values (3,to_timestamp(''02-MAR-22 12.21.18.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''';
wwv_flow_imp.g_varchar2_table(163) := '),18,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,';
wwv_flow_imp.g_varchar2_table(164) := 'ORDER_STATUS,STORE_ID) values (5,to_timestamp(''04-MAR-22 07.05.41.000000000 AM'',''DD-MON-RR HH.MI.SSX';
wwv_flow_imp.g_varchar2_table(165) := 'FF AM''),2,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOM';
wwv_flow_imp.g_varchar2_table(166) := 'ER_ID,ORDER_STATUS,STORE_ID) values (7,to_timestamp(''14-MAR-22 02.01.22.000000000 PM'',''DD-MON-RR HH.';
wwv_flow_imp.g_varchar2_table(167) := 'MI.SSXFF AM''),9,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,C';
wwv_flow_imp.g_varchar2_table(168) := 'USTOMER_ID,ORDER_STATUS,STORE_ID) values (17,to_timestamp(''19-MAR-22 08.51.57.000000000 PM'',''DD-MON-';
wwv_flow_imp.g_varchar2_table(169) := 'RR HH.MI.SSXFF AM''),16,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DAT';
wwv_flow_imp.g_varchar2_table(170) := 'ETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (20,to_timestamp(''21-MAR-22 11.11.43.000000000 PM'',''';
wwv_flow_imp.g_varchar2_table(171) := 'DD-MON-RR HH.MI.SSXFF AM''),3,''COMPLETE'',3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORD';
wwv_flow_imp.g_varchar2_table(172) := 'ER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (63,to_timestamp(''11-APR-22 07.21.35.000000000';
wwv_flow_imp.g_varchar2_table(173) := ' PM'',''DD-MON-RR HH.MI.SSXFF AM''),3,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_';
wwv_flow_imp.g_varchar2_table(174) := 'ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (78,to_timestamp(''17-APR-22 11.00.11.000';
wwv_flow_imp.g_varchar2_table(175) := '000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),20,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS ';
wwv_flow_imp.g_varchar2_table(176) := '(ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (79,to_timestamp(''18-APR-22 04.39';
wwv_flow_imp.g_varchar2_table(177) := '.13.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),14,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_';
wwv_flow_imp.g_varchar2_table(178) := 'ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (82,to_timestamp(''19-APR-2';
wwv_flow_imp.g_varchar2_table(179) := '2 01.24.05.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),13,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_';
wwv_flow_imp.g_varchar2_table(180) := 'SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (92,to_timestamp(''2';
wwv_flow_imp.g_varchar2_table(181) := '1-APR-22 09.25.03.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),17,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EB';
wwv_flow_imp.g_varchar2_table(182) := 'A_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (125,to_time';
wwv_flow_imp.g_varchar2_table(183) := 'stamp(''01-MAY-22 01.45.50.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),12,''CANCELLED'',1);'||wwv_flow.LF||
'        Inser';
wwv_flow_imp.g_varchar2_table(184) := 't into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (13';
wwv_flow_imp.g_varchar2_table(185) := '2,to_timestamp(''02-MAY-22 02.19.08.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),17,''COMPLETE'',1);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(186) := '   Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) va';
wwv_flow_imp.g_varchar2_table(187) := 'lues (159,to_timestamp(''11-MAY-22 01.56.08.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),1,''CANCELLED'',1';
wwv_flow_imp.g_varchar2_table(188) := ');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STOR';
wwv_flow_imp.g_varchar2_table(189) := 'E_ID) values (182,to_timestamp(''16-MAY-22 05.00.13.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),1,''COMP';
wwv_flow_imp.g_varchar2_table(190) := 'LETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STAT';
wwv_flow_imp.g_varchar2_table(191) := 'US,STORE_ID) values (196,to_timestamp(''19-MAY-22 05.57.59.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),';
wwv_flow_imp.g_varchar2_table(192) := '8,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,OR';
wwv_flow_imp.g_varchar2_table(193) := 'DER_STATUS,STORE_ID) values (201,to_timestamp(''20-MAY-22 12.52.12.000000000 AM'',''DD-MON-RR HH.MI.SSX';
wwv_flow_imp.g_varchar2_table(194) := 'FF AM''),1,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOME';
wwv_flow_imp.g_varchar2_table(195) := 'R_ID,ORDER_STATUS,STORE_ID) values (204,to_timestamp(''21-MAY-22 12.43.26.000000000 AM'',''DD-MON-RR HH';
wwv_flow_imp.g_varchar2_table(196) := '.MI.SSXFF AM''),6,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME';
wwv_flow_imp.g_varchar2_table(197) := ',CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (240,to_timestamp(''28-MAY-22 01.31.20.000000000 PM'',''DD-M';
wwv_flow_imp.g_varchar2_table(198) := 'ON-RR HH.MI.SSXFF AM''),8,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_';
wwv_flow_imp.g_varchar2_table(199) := 'DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (290,to_timestamp(''13-JUN-22 02.12.59.000000000 A';
wwv_flow_imp.g_varchar2_table(200) := 'M'',''DD-MON-RR HH.MI.SSXFF AM''),15,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_';
wwv_flow_imp.g_varchar2_table(201) := 'ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (298,to_timestamp(''14-JUN-22 09.34.20.00';
wwv_flow_imp.g_varchar2_table(202) := '0000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),3,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS ';
wwv_flow_imp.g_varchar2_table(203) := '(ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (306,to_timestamp(''16-JUN-22 04.2';
wwv_flow_imp.g_varchar2_table(204) := '4.36.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),5,''COMPLETE'',5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_';
wwv_flow_imp.g_varchar2_table(205) := 'ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (307,to_timestamp(''16-JUN-';
wwv_flow_imp.g_varchar2_table(206) := '22 05.31.39.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),3,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO';
wwv_flow_imp.g_varchar2_table(207) := '_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (331,to_timestamp(';
wwv_flow_imp.g_varchar2_table(208) := '''24-JUN-22 02.29.17.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),5,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into E';
wwv_flow_imp.g_varchar2_table(209) := 'BA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (349,to_tim';
wwv_flow_imp.g_varchar2_table(210) := 'estamp(''29-JUN-22 08.24.23.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),14,''COMPLETE'',1);'||wwv_flow.LF||
'        Inser';
wwv_flow_imp.g_varchar2_table(211) := 't into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (40';
wwv_flow_imp.g_varchar2_table(212) := '1,to_timestamp(''11-JUL-22 10.55.57.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),16,''CANCELLED'',1);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(213) := '    Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) v';
wwv_flow_imp.g_varchar2_table(214) := 'alues (430,to_timestamp(''17-JUL-22 08.56.02.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),8,''COMPLETE'',1';
wwv_flow_imp.g_varchar2_table(215) := ');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STOR';
wwv_flow_imp.g_varchar2_table(216) := 'E_ID) values (437,to_timestamp(''18-JUL-22 06.41.45.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),10,''CAN';
wwv_flow_imp.g_varchar2_table(217) := 'CELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_ST';
wwv_flow_imp.g_varchar2_table(218) := 'ATUS,STORE_ID) values (1111,to_timestamp(''03-DEC-22 12.42.17.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM';
wwv_flow_imp.g_varchar2_table(219) := '''),6,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,';
wwv_flow_imp.g_varchar2_table(220) := 'ORDER_STATUS,STORE_ID) values (1119,to_timestamp(''05-DEC-22 09.35.51.000000000 PM'',''DD-MON-RR HH.MI.';
wwv_flow_imp.g_varchar2_table(221) := 'SSXFF AM''),14,''CANCELLED'',14);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,C';
wwv_flow_imp.g_varchar2_table(222) := 'USTOMER_ID,ORDER_STATUS,STORE_ID) values (1121,to_timestamp(''05-DEC-22 11.25.14.000000000 PM'',''DD-MO';
wwv_flow_imp.g_varchar2_table(223) := 'N-RR HH.MI.SSXFF AM''),7,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_D';
wwv_flow_imp.g_varchar2_table(224) := 'ATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1169,to_timestamp(''15-DEC-22 04.16.06.000000000 A';
wwv_flow_imp.g_varchar2_table(225) := 'M'',''DD-MON-RR HH.MI.SSXFF AM''),14,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_';
wwv_flow_imp.g_varchar2_table(226) := 'ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1191,to_timestamp(''20-DEC-22 03.12.50.0';
wwv_flow_imp.g_varchar2_table(227) := '00000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),14,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDE';
wwv_flow_imp.g_varchar2_table(228) := 'RS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1195,to_timestamp(''21-DEC-22 ';
wwv_flow_imp.g_varchar2_table(229) := '06.46.35.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),15,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SE';
wwv_flow_imp.g_varchar2_table(230) := 'ARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1200,to_timestamp(''2';
wwv_flow_imp.g_varchar2_table(231) := '1-DEC-22 12.24.05.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),17,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EB';
wwv_flow_imp.g_varchar2_table(232) := 'A_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1260,to_tim';
wwv_flow_imp.g_varchar2_table(233) := 'estamp(''30-DEC-22 01.21.21.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),9,''CANCELLED'',9);'||wwv_flow.LF||
'        Inser';
wwv_flow_imp.g_varchar2_table(234) := 't into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (13';
wwv_flow_imp.g_varchar2_table(235) := '21,to_timestamp(''09-JAN-23 06.32.45.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),11,''CANCELLED'',1);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(236) := '     Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) ';
wwv_flow_imp.g_varchar2_table(237) := 'values (1348,to_timestamp(''13-JAN-23 08.57.23.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),18,''COMPLETE';
wwv_flow_imp.g_varchar2_table(238) := ''',18);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,';
wwv_flow_imp.g_varchar2_table(239) := 'STORE_ID) values (1363,to_timestamp(''16-JAN-23 10.00.07.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),19';
wwv_flow_imp.g_varchar2_table(240) := ',''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORD';
wwv_flow_imp.g_varchar2_table(241) := 'ER_STATUS,STORE_ID) values (1373,to_timestamp(''18-JAN-23 03.27.07.000000000 PM'',''DD-MON-RR HH.MI.SSX';
wwv_flow_imp.g_varchar2_table(242) := 'FF AM''),16,''CANCELLED'',16);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUST';
wwv_flow_imp.g_varchar2_table(243) := 'OMER_ID,ORDER_STATUS,STORE_ID) values (1390,to_timestamp(''21-JAN-23 04.51.37.000000000 AM'',''DD-MON-R';
wwv_flow_imp.g_varchar2_table(244) := 'R HH.MI.SSXFF AM''),1,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATET';
wwv_flow_imp.g_varchar2_table(245) := 'IME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1400,to_timestamp(''22-JAN-23 06.52.24.000000000 PM'',''';
wwv_flow_imp.g_varchar2_table(246) := 'DD-MON-RR HH.MI.SSXFF AM''),15,''COMPLETE'',15);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,O';
wwv_flow_imp.g_varchar2_table(247) := 'RDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1418,to_timestamp(''25-JAN-23 05.30.59.00000';
wwv_flow_imp.g_varchar2_table(248) := '0000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),13,''CANCELLED'',13);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS ';
wwv_flow_imp.g_varchar2_table(249) := '(ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1437,to_timestamp(''28-JAN-23 09.';
wwv_flow_imp.g_varchar2_table(250) := '08.42.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),16,''CANCELLED'',16);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEA';
wwv_flow_imp.g_varchar2_table(251) := 'RCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1439,to_timestamp(''29';
wwv_flow_imp.g_varchar2_table(252) := '-JAN-23 04.52.36.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),16,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EB';
wwv_flow_imp.g_varchar2_table(253) := 'A_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1448,to_tim';
wwv_flow_imp.g_varchar2_table(254) := 'estamp(''31-JAN-23 07.09.51.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),16,''CANCELLED'',1);'||wwv_flow.LF||
'        Inse';
wwv_flow_imp.g_varchar2_table(255) := 'rt into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1';
wwv_flow_imp.g_varchar2_table(256) := '450,to_timestamp(''31-JAN-23 07.56.41.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),6,''COMPLETE'',1);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(257) := '    Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) v';
wwv_flow_imp.g_varchar2_table(258) := 'alues (1451,to_timestamp(''31-JAN-23 08.10.59.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),16,''CANCELLED';
wwv_flow_imp.g_varchar2_table(259) := ''',16);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,';
wwv_flow_imp.g_varchar2_table(260) := 'STORE_ID) values (1455,to_timestamp(''01-FEB-23 03.40.10.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),4,';
wwv_flow_imp.g_varchar2_table(261) := '''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER';
wwv_flow_imp.g_varchar2_table(262) := '_STATUS,STORE_ID) values (1468,to_timestamp(''02-FEB-23 02.27.01.000000000 PM'',''DD-MON-RR HH.MI.SSXFF';
wwv_flow_imp.g_varchar2_table(263) := ' AM''),4,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_';
wwv_flow_imp.g_varchar2_table(264) := 'ID,ORDER_STATUS,STORE_ID) values (1471,to_timestamp(''02-FEB-23 07.29.40.000000000 PM'',''DD-MON-RR HH.';
wwv_flow_imp.g_varchar2_table(265) := 'MI.SSXFF AM''),14,''CANCELLED'',14);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIM';
wwv_flow_imp.g_varchar2_table(266) := 'E,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1483,to_timestamp(''04-FEB-23 08.09.09.000000000 AM'',''DD';
wwv_flow_imp.g_varchar2_table(267) := '-MON-RR HH.MI.SSXFF AM''),14,''COMPLETE'',14);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORD';
wwv_flow_imp.g_varchar2_table(268) := 'ER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1486,to_timestamp(''05-FEB-23 04.35.40.0000000';
wwv_flow_imp.g_varchar2_table(269) := '00 AM'',''DD-MON-RR HH.MI.SSXFF AM''),15,''COMPLETE'',15);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (OR';
wwv_flow_imp.g_varchar2_table(270) := 'DER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1491,to_timestamp(''05-FEB-23 09.16.';
wwv_flow_imp.g_varchar2_table(271) := '42.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),1,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_O';
wwv_flow_imp.g_varchar2_table(272) := 'RDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1498,to_timestamp(''06-FEB-';
wwv_flow_imp.g_varchar2_table(273) := '23 06.40.27.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),13,''COMPLETE'',13);'||wwv_flow.LF||
'        Insert into EBA_DEM';
wwv_flow_imp.g_varchar2_table(274) := 'O_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1513,to_timestam';
wwv_flow_imp.g_varchar2_table(275) := 'p(''09-FEB-23 05.17.37.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),20,''CANCELLED'',1);'||wwv_flow.LF||
'        Insert in';
wwv_flow_imp.g_varchar2_table(276) := 'to EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1520,t';
wwv_flow_imp.g_varchar2_table(277) := 'o_timestamp(''10-FEB-23 12.46.23.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),3,''CANCELLED'',1);'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(278) := 'Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) value';
wwv_flow_imp.g_varchar2_table(279) := 's (1525,to_timestamp(''11-FEB-23 02.22.05.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),10,''COMPLETE'',1);';
wwv_flow_imp.g_varchar2_table(280) := ''||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_';
wwv_flow_imp.g_varchar2_table(281) := 'ID) values (1543,to_timestamp(''13-FEB-23 12.54.09.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),8,''CANCE';
wwv_flow_imp.g_varchar2_table(282) := 'LLED'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STAT';
wwv_flow_imp.g_varchar2_table(283) := 'US,STORE_ID) values (1549,to_timestamp(''13-FEB-23 05.28.26.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM'')';
wwv_flow_imp.g_varchar2_table(284) := ',19,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,O';
wwv_flow_imp.g_varchar2_table(285) := 'RDER_STATUS,STORE_ID) values (1552,to_timestamp(''14-FEB-23 01.13.25.000000000 AM'',''DD-MON-RR HH.MI.S';
wwv_flow_imp.g_varchar2_table(286) := 'SXFF AM''),17,''CANCELLED'',17);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CU';
wwv_flow_imp.g_varchar2_table(287) := 'STOMER_ID,ORDER_STATUS,STORE_ID) values (1555,to_timestamp(''14-FEB-23 04.22.00.000000000 AM'',''DD-MON';
wwv_flow_imp.g_varchar2_table(288) := '-RR HH.MI.SSXFF AM''),7,''CANCELLED'',7);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DA';
wwv_flow_imp.g_varchar2_table(289) := 'TETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1560,to_timestamp(''14-FEB-23 06.38.06.000000000 PM';
wwv_flow_imp.g_varchar2_table(290) := ''',''DD-MON-RR HH.MI.SSXFF AM''),14,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID';
wwv_flow_imp.g_varchar2_table(291) := ',ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1561,to_timestamp(''14-FEB-23 09.01.04.000';
wwv_flow_imp.g_varchar2_table(292) := '000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),8,''COMPLETE'',8);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (';
wwv_flow_imp.g_varchar2_table(293) := 'ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1635,to_timestamp(''26-FEB-23 02.2';
wwv_flow_imp.g_varchar2_table(294) := '2.36.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),11,''CANCELLED'',11);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEAR';
wwv_flow_imp.g_varchar2_table(295) := 'CH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1637,to_timestamp(''26-';
wwv_flow_imp.g_varchar2_table(296) := 'FEB-23 03.21.00.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),12,''COMPLETE'',1);'||wwv_flow.LF||
'        Insert into EBA_';
wwv_flow_imp.g_varchar2_table(297) := 'DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1659,to_times';
wwv_flow_imp.g_varchar2_table(298) := 'tamp(''02-MAR-23 02.20.04.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),18,''CANCELLED'',18);'||wwv_flow.LF||
'        Inser';
wwv_flow_imp.g_varchar2_table(299) := 't into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (17';
wwv_flow_imp.g_varchar2_table(300) := '30,to_timestamp(''15-MAR-23 03.38.39.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),10,''COMPLETE'',10);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(301) := '     Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) ';
wwv_flow_imp.g_varchar2_table(302) := 'values (1731,to_timestamp(''16-MAR-23 09.57.43.000000000 AM'',''DD-MON-RR HH.MI.SSXFF AM''),19,''CANCELLE';
wwv_flow_imp.g_varchar2_table(303) := 'D'',19);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,ORDER_STATUS';
wwv_flow_imp.g_varchar2_table(304) := ',STORE_ID) values (1776,to_timestamp(''24-MAR-23 12.05.43.000000000 PM'',''DD-MON-RR HH.MI.SSXFF AM''),2';
wwv_flow_imp.g_varchar2_table(305) := '0,''COMPLETE'',20);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUSTOMER_ID,OR';
wwv_flow_imp.g_varchar2_table(306) := 'DER_STATUS,STORE_ID) values (1808,to_timestamp(''29-MAR-23 11.37.35.000000000 PM'',''DD-MON-RR HH.MI.SS';
wwv_flow_imp.g_varchar2_table(307) := 'XFF AM''),20,''CANCELLED'',20);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DATETIME,CUS';
wwv_flow_imp.g_varchar2_table(308) := 'TOMER_ID,ORDER_STATUS,STORE_ID) values (1817,to_timestamp(''31-MAR-23 10.58.36.000000000 AM'',''DD-MON-';
wwv_flow_imp.g_varchar2_table(309) := 'RR HH.MI.SSXFF AM''),8,''CANCELLED'',8);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDERS (ORDER_ID,ORDER_DAT';
wwv_flow_imp.g_varchar2_table(310) := 'ETIME,CUSTOMER_ID,ORDER_STATUS,STORE_ID) values (1890,to_timestamp(''15-APR-23 12.36.09.000000000 PM''';
wwv_flow_imp.g_varchar2_table(311) := ',''DD-MON-RR HH.MI.SSXFF AM''),7,''CANCELLED'',7);'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Products data'||wwv_flow.LF||
'        Insert into EBA_DEM';
wwv_flow_imp.g_varchar2_table(312) := 'O_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (16,''Women''''s Socks (G';
wwv_flow_imp.g_varchar2_table(313) := 'rey)'',39.89,null);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,';
wwv_flow_imp.g_varchar2_table(314) := 'PRODUCT_DETAILS) values (17,''Women''''s Sweater (Brown)'',24.46,utl_raw.cast_to_raw(''{"colour":"brown",';
wwv_flow_imp.g_varchar2_table(315) := '"gender":"Women''''s","brand":"KLUGGER","description":"Dolore adipisicing commodo consequat Lorem ut i';
wwv_flow_imp.g_varchar2_table(316) := 'ncididunt. Ullamco nulla qui qui pariatur qui officia adipisicing magna aliqua ex qui incididunt.","';
wwv_flow_imp.g_varchar2_table(317) := 'sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":7,"review":"Fugiat cillum anim in qui labo';
wwv_flow_imp.g_varchar2_table(318) := 'rum velit eu consectetur ad fugiat."},{"rating":6,"review":"Elit duis nostrud ad non enim elit molli';
wwv_flow_imp.g_varchar2_table(319) := 't deserunt."},{"rating":2,"review":"Amet anim mollit laboris deserunt deserunt laboris anim ad commo';
wwv_flow_imp.g_varchar2_table(320) := 'do dolor."},{"rating":7,"review":"Labore nulla ullamco aute labore esse do proident sit."},{"rating"';
wwv_flow_imp.g_varchar2_table(321) := ':5,"review":"Non amet cillum eu cillum cupidatat occaecat excepteur ad voluptate culpa id."},{"ratin';
wwv_flow_imp.g_varchar2_table(322) := 'g":4,"review":"Non aliqua nisi anim qui consectetur id dolore duis sint aliqua ea tempor laborum."},';
wwv_flow_imp.g_varchar2_table(323) := '{"rating":5,"review":"Elit ea Lorem duis amet."},{"rating":10,"review":"Aliqua velit nulla exercitat';
wwv_flow_imp.g_varchar2_table(324) := 'ion dolor minim ipsum culpa nostrud occaecat proident voluptate."},{"rating":3,"review":"Exercitatio';
wwv_flow_imp.g_varchar2_table(325) := 'n anim eu et veniam tempor ea."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PROD';
wwv_flow_imp.g_varchar2_table(326) := 'UCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (18,''Women''''s Jacket (Black)'',14.34,null);'||wwv_flow.LF||
'        Inser';
wwv_flow_imp.g_varchar2_table(327) := 't into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (19,''Men';
wwv_flow_imp.g_varchar2_table(328) := '''''s Coat (Red)'',28.21,utl_raw.cast_to_raw(''{"colour":"red","gender":"Men''''s","brand":"VELOS","descri';
wwv_flow_imp.g_varchar2_table(329) := 'ption":"Sint quis dolor in dolore sint elit ullamco ex magna laborum id eu. Magna fugiat qui pariatu';
wwv_flow_imp.g_varchar2_table(330) := 'r dolore ex est esse minim elit velit.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating":7';
wwv_flow_imp.g_varchar2_table(331) := ',"review":"Esse velit est cupidatat ea labore cupidatat ipsum ullamco cupidatat Lorem."}]}''));'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(332) := '   Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values ';
wwv_flow_imp.g_varchar2_table(333) := '(20,''Girl''''s Shorts (Green)'',38.34,utl_raw.cast_to_raw(''{"colour":"green","gender":"Girl''''s","brand"';
wwv_flow_imp.g_varchar2_table(334) := ':"TRASOLA","description":"These shorts are perfect for a day out at sea. Made with quick-drying and ';
wwv_flow_imp.g_varchar2_table(335) := 'breathable materials, they are comfortable to wear even in hot and humid conditions.","sizes":["1 Yr';
wwv_flow_imp.g_varchar2_table(336) := '","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Veniam consectetur e';
wwv_flow_imp.g_varchar2_table(337) := 'a nisi irure aute cillum."},{"rating":8,"review":"Consequat ex incididunt pariatur mollit magna inci';
wwv_flow_imp.g_varchar2_table(338) := 'didunt veniam pariatur aliqua ex exercitation aute mollit ullamco."},{"rating":4,"review":"Proident ';
wwv_flow_imp.g_varchar2_table(339) := 'tempor cupidatat ut cillum nisi sunt consectetur veniam dolore est ut."},{"rating":8,"review":"Deser';
wwv_flow_imp.g_varchar2_table(340) := 'unt amet quis do duis nulla officia anim sint do eiusmod exercitation."},{"rating":5,"review":"Anim ';
wwv_flow_imp.g_varchar2_table(341) := 'magna incididunt mollit deserunt proident veniam occaecat ex ut ex incididunt."},{"rating":4,"review';
wwv_flow_imp.g_varchar2_table(342) := '":"Consectetur cillum minim dolore cupidatat esse."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODU';
wwv_flow_imp.g_varchar2_table(343) := 'CTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (21,''Girl''''s Pyjamas (White)'',39.78,';
wwv_flow_imp.g_varchar2_table(344) := 'utl_raw.cast_to_raw(''{"colour":"black","gender":"Girl''''s","brand":"UTARIAN","description":"Fugiat ad';
wwv_flow_imp.g_varchar2_table(345) := 'ipisicing sunt ullamco est ea. Dolor excepteur sit ad eu.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr",';
wwv_flow_imp.g_varchar2_table(346) := '"7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Proident consequat consequat eu enim Lorem inci';
wwv_flow_imp.g_varchar2_table(347) := 'didunt ad amet excepteur tempor aliquip ad aliquip ea."},{"rating":7,"review":"Nulla sint anim aliqu';
wwv_flow_imp.g_varchar2_table(348) := 'a laboris sint eu adipisicing incididunt."},{"rating":10,"review":"Aliqua aliquip non commodo duis c';
wwv_flow_imp.g_varchar2_table(349) := 'onsequat ad nisi et magna."},{"rating":9,"review":"Tempor consequat Lorem ipsum proident do nisi est';
wwv_flow_imp.g_varchar2_table(350) := ' dolore."},{"rating":7,"review":"Pariatur amet laborum dolor dolore incididunt sint labore."},{"rati';
wwv_flow_imp.g_varchar2_table(351) := 'ng":10,"review":"Eu exercitation incididunt et est."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PROD';
wwv_flow_imp.g_varchar2_table(352) := 'UCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (22,''Men''''s Shorts (Black)'',10.33,u';
wwv_flow_imp.g_varchar2_table(353) := 'tl_raw.cast_to_raw(''{"colour":"black","gender":"Men''''s","brand":"TERSANKI","description":"Occaecat v';
wwv_flow_imp.g_varchar2_table(354) := 'eniam do aliqua irure consectetur ea fugiat aliqua qui ea veniam officia. Culpa officia Lorem dolor ';
wwv_flow_imp.g_varchar2_table(355) := 'ullamco culpa adipisicing qui exercitation labore minim exercitation sunt.","sizes":["XS","S","M","L';
wwv_flow_imp.g_varchar2_table(356) := '","XL","XXL"],"reviews":[{"rating":3,"review":"Consequat anim reprehenderit commodo non aliqua labor';
wwv_flow_imp.g_varchar2_table(357) := 'um aute."},{"rating":6,"review":"Labore cillum do qui magna culpa ea excepteur quis."},{"rating":1,"';
wwv_flow_imp.g_varchar2_table(358) := 'review":"Dolor amet quis ea magna."},{"rating":7,"review":"Minim sit nostrud anim nostrud excepteur ';
wwv_flow_imp.g_varchar2_table(359) := 'nostrud ea ex veniam consectetur elit."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT';
wwv_flow_imp.g_varchar2_table(360) := '_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (23,''Men''''s Pyjamas (Blue)'',48.39,utl_raw.cast_t';
wwv_flow_imp.g_varchar2_table(361) := 'o_raw(''{"colour":"blue","gender":"Men''''s","brand":"ADORNICA","description":"Irure amet Lorem consequ';
wwv_flow_imp.g_varchar2_table(362) := 'at aliquip officia dolore amet officia. Do elit laboris non dolore nostrud dolore cupidatat ea quis ';
wwv_flow_imp.g_varchar2_table(363) := 'aliquip ex aliquip non ex.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating":3,"review":"L';
wwv_flow_imp.g_varchar2_table(364) := 'aboris elit pariatur labore duis fugiat ad in nulla tempor."},{"rating":5,"review":"Voluptate minim ';
wwv_flow_imp.g_varchar2_table(365) := 'officia id excepteur."},{"rating":8,"review":"Eiusmod cupidatat et nisi ipsum non aliqua."},{"rating';
wwv_flow_imp.g_varchar2_table(366) := '":1,"review":"Aute veniam irure dolor laborum esse ut ex tempor non velit."},{"rating":2,"review":"N';
wwv_flow_imp.g_varchar2_table(367) := 'ostrud nostrud mollit incididunt et tempor excepteur sit ut id exercitation."},{"rating":6,"review":';
wwv_flow_imp.g_varchar2_table(368) := '"Labore tempor cillum laborum commodo et sit est qui aute enim id aute."}]}''));'||wwv_flow.LF||
'        Insert into ';
wwv_flow_imp.g_varchar2_table(369) := 'EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (24,''Boy''''s Swe';
wwv_flow_imp.g_varchar2_table(370) := 'ater (Red)'',9.8,utl_raw.cast_to_raw(''{"colour":"red","gender":"Boy''''s","brand":"PHARMEX","descriptio';
wwv_flow_imp.g_varchar2_table(371) := 'n":"Ex occaecat nulla esse duis nulla laboris aute. Commodo magna Lorem exercitation occaecat do ani';
wwv_flow_imp.g_varchar2_table(372) := 'm minim non ad non ex do nulla ad.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"re';
wwv_flow_imp.g_varchar2_table(373) := 'views":[{"rating":7,"review":"Ea reprehenderit occaecat commodo exercitation ut adipisicing laboris ';
wwv_flow_imp.g_varchar2_table(374) := 'adipisicing ex aute reprehenderit nisi sint qui."},{"rating":8,"review":"Qui anim sint dolore id dol';
wwv_flow_imp.g_varchar2_table(375) := 'or proident occaecat."},{"rating":5,"review":"Dolore fugiat mollit Lorem aliqua id consequat irure v';
wwv_flow_imp.g_varchar2_table(376) := 'eniam."},{"rating":2,"review":"Esse dolore occaecat consectetur sit sit labore exercitation sint occ';
wwv_flow_imp.g_varchar2_table(377) := 'aecat quis enim occaecat."},{"rating":4,"review":"Do commodo do laboris qui minim fugiat nisi nostru';
wwv_flow_imp.g_varchar2_table(378) := 'd elit."},{"rating":7,"review":"Pariatur eu non eiusmod ex dolor veniam."},{"rating":3,"review":"Mag';
wwv_flow_imp.g_varchar2_table(379) := 'na aliqua dolor sint anim aliquip officia officia esse labore do."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DE';
wwv_flow_imp.g_varchar2_table(380) := 'MO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (25,''Girl''''s Jeans (G';
wwv_flow_imp.g_varchar2_table(381) := 'rey)'',48.75,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Girl''''s","brand":"KINETICUT","descriptio';
wwv_flow_imp.g_varchar2_table(382) := 'n":"Ut aliqua nostrud exercitation cupidatat cupidatat in. Sit tempor eu cillum quis incididunt cons';
wwv_flow_imp.g_varchar2_table(383) := 'ectetur quis amet.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating';
wwv_flow_imp.g_varchar2_table(384) := '":2,"review":"Id consectetur minim anim nisi occaecat elit labore duis."},{"rating":5,"review":"Ut f';
wwv_flow_imp.g_varchar2_table(385) := 'ugiat qui velit fugiat nostrud ea dolor amet magna id pariatur."},{"rating":3,"review":"Labore labor';
wwv_flow_imp.g_varchar2_table(386) := 'um eiusmod qui minim exercitation."},{"rating":4,"review":"Excepteur ea mollit ad pariatur mollit ve';
wwv_flow_imp.g_varchar2_table(387) := 'niam."},{"rating":9,"review":"Consectetur aliquip deserunt fugiat excepteur elit occaecat culpa fugi';
wwv_flow_imp.g_varchar2_table(388) := 'at dolor in."},{"rating":1,"review":"Adipisicing adipisicing mollit reprehenderit ex nulla in ea ad ';
wwv_flow_imp.g_varchar2_table(389) := 'exercitation irure ullamco."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT';
wwv_flow_imp.g_varchar2_table(390) := '_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (26,''Girl''''s Hoodie (White)'',39.91,utl_raw.cast_to_raw(''{"c';
wwv_flow_imp.g_varchar2_table(391) := 'olour":"white","gender":"Girl''''s","brand":"PROXSOFT","description":"Aliquip culpa eu deserunt ex cul';
wwv_flow_imp.g_varchar2_table(392) := 'pa in laborum adipisicing. Amet et id minim esse ea non qui veniam.","sizes":["1 Yr","2 Yr","3-4 Yr"';
wwv_flow_imp.g_varchar2_table(393) := ',"5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":6,"review":"Commodo ut fugiat voluptate adipisici';
wwv_flow_imp.g_varchar2_table(394) := 'ng deserunt."},{"rating":4,"review":"Fugiat cupidatat amet fugiat cupidatat ea ea."},{"rating":7,"re';
wwv_flow_imp.g_varchar2_table(395) := 'view":"Incididunt ex enim commodo sit consequat enim."},{"rating":3,"review":"Ullamco in et aute lab';
wwv_flow_imp.g_varchar2_table(396) := 'oris cillum."},{"rating":3,"review":"Reprehenderit Lorem proident sit deserunt do tempor commodo vel';
wwv_flow_imp.g_varchar2_table(397) := 'it velit nulla ipsum."},{"rating":10,"review":"Dolore pariatur velit enim est culpa eiusmod cupidata';
wwv_flow_imp.g_varchar2_table(398) := 't deserunt esse elit exercitation sunt proident exercitation."},{"rating":2,"review":"Minim fugiat e';
wwv_flow_imp.g_varchar2_table(399) := 'lit aliquip nostrud velit reprehenderit cillum."},{"rating":4,"review":"Sint Lorem est laborum conse';
wwv_flow_imp.g_varchar2_table(400) := 'ctetur pariatur minim tempor ullamco Lorem est."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS';
wwv_flow_imp.g_varchar2_table(401) := ' (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (27,''Boy''''s Coat (Blue)'',10.24,utl_raw.';
wwv_flow_imp.g_varchar2_table(402) := 'cast_to_raw(''{"colour":"brown","gender":"Boy''''s","brand":"GRONK","description":"Quis aliquip fugiat ';
wwv_flow_imp.g_varchar2_table(403) := 'sunt qui eu velit aliqua sint eiusmod mollit id ad. Anim anim ipsum in reprehenderit amet amet conse';
wwv_flow_imp.g_varchar2_table(404) := 'ctetur incididunt qui cillum Lorem.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"r';
wwv_flow_imp.g_varchar2_table(405) := 'eviews":[{"rating":8,"review":"Sit id elit cupidatat aute consectetur esse proident aliqua ad volupt';
wwv_flow_imp.g_varchar2_table(406) := 'ate cillum Lorem."},{"rating":6,"review":"Enim enim fugiat consectetur ut sunt veniam ad sit minim a';
wwv_flow_imp.g_varchar2_table(407) := 'met Lorem veniam mollit."},{"rating":5,"review":"Dolor ipsum consectetur nostrud ex Lorem pariatur v';
wwv_flow_imp.g_varchar2_table(408) := 'oluptate."},{"rating":8,"review":"Commodo magna sint sint dolore aute anim laborum."},{"rating":4,"r';
wwv_flow_imp.g_varchar2_table(409) := 'eview":"Laboris amet proident occaecat dolore labore exercitation dolore sunt Lorem sunt anim."}]}'')';
wwv_flow_imp.g_varchar2_table(410) := ');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS)';
wwv_flow_imp.g_varchar2_table(411) := ' values (28,''Men''''s Hoodie (Red)'',24.71,utl_raw.cast_to_raw(''{"colour":"red","gender":"Men''''s","bran';
wwv_flow_imp.g_varchar2_table(412) := 'd":"FANGOLD","description":"Dolor irure dolore est ipsum nisi incididunt laboris culpa. Ullamco ad c';
wwv_flow_imp.g_varchar2_table(413) := 'upidatat sint culpa adipisicing pariatur.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating';
wwv_flow_imp.g_varchar2_table(414) := '":3,"review":"Proident aliqua aliquip aute quis cillum."},{"rating":5,"review":"Pariatur enim ipsum ';
wwv_flow_imp.g_varchar2_table(415) := 'aliqua Lorem eiusmod consequat cupidatat irure nulla sint fugiat veniam amet ipsum."},{"rating":10,"';
wwv_flow_imp.g_varchar2_table(416) := 'review":"Sint duis ipsum reprehenderit Lorem aute pariatur elit."},{"rating":4,"review":"Enim qui qu';
wwv_flow_imp.g_varchar2_table(417) := 'i consequat culpa ex velit sint excepteur ipsum in amet mollit mollit."},{"rating":10,"review":"Qui ';
wwv_flow_imp.g_varchar2_table(418) := 'velit reprehenderit fugiat adipisicing anim incididunt anim commodo occaecat consectetur in aute."}]';
wwv_flow_imp.g_varchar2_table(419) := '}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAI';
wwv_flow_imp.g_varchar2_table(420) := 'LS) values (29,''Boy''''s Shirt (Black)'',37.34,utl_raw.cast_to_raw(''{"colour":"black","gender":"Boy''''s"';
wwv_flow_imp.g_varchar2_table(421) := ',"brand":"SQUISH","description":"Pariatur nulla elit pariatur excepteur ullamco officia incididunt. ';
wwv_flow_imp.g_varchar2_table(422) := 'Aliquip quis aliquip cupidatat magna fugiat eiusmod pariatur excepteur tempor officia voluptate fugi';
wwv_flow_imp.g_varchar2_table(423) := 'at.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":5,"review":"N';
wwv_flow_imp.g_varchar2_table(424) := 'on esse labore ullamco laboris irure cupidatat ex proident eiusmod."},{"rating":10,"review":"Ea veli';
wwv_flow_imp.g_varchar2_table(425) := 't et mollit labore consequat."},{"rating":6,"review":"Labore sit pariatur Lorem ad sint consectetur ';
wwv_flow_imp.g_varchar2_table(426) := 'incididunt deserunt eiusmod sit nostrud dolore eiusmod sint."},{"rating":1,"review":"Id voluptate su';
wwv_flow_imp.g_varchar2_table(427) := 'nt amet laboris laborum ad dolor aliqua ipsum sint qui aute eu esse."},{"rating":5,"review":"Sint Lo';
wwv_flow_imp.g_varchar2_table(428) := 'rem dolore do ea."},{"rating":9,"review":"Quis pariatur consequat nisi labore Lorem elit in qui Lore';
wwv_flow_imp.g_varchar2_table(429) := 'm."},{"rating":2,"review":"Consectetur voluptate tempor ullamco voluptate labore sint."},{"rating":9';
wwv_flow_imp.g_varchar2_table(430) := ',"review":"Qui laboris tempor ullamco ullamco commodo sint occaecat Lorem."},{"rating":1,"review":"L';
wwv_flow_imp.g_varchar2_table(431) := 'aborum eu sit duis et culpa eu duis irure incididunt amet."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEAR';
wwv_flow_imp.g_varchar2_table(432) := 'CH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (30,''Women''''s Pyjamas (Grey)';
wwv_flow_imp.g_varchar2_table(433) := ''',28.59,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Women''''s","brand":"THREDZ","description":"Qu';
wwv_flow_imp.g_varchar2_table(434) := 'is aliqua eiusmod incididunt quis ut ea aliqua sunt veniam ut et cupidatat eiusmod. Sunt sunt duis e';
wwv_flow_imp.g_varchar2_table(435) := 'xcepteur excepteur do exercitation.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":1,"r';
wwv_flow_imp.g_varchar2_table(436) := 'eview":"Et anim culpa voluptate pariatur ullamco dolore ad aliquip."},{"rating":4,"review":"Nulla no';
wwv_flow_imp.g_varchar2_table(437) := 'n ea nisi nulla elit veniam duis."},{"rating":4,"review":"Lorem adipisicing deserunt duis id sint al';
wwv_flow_imp.g_varchar2_table(438) := 'iquip minim deserunt magna sunt magna laborum dolore."},{"rating":3,"review":"Officia amet magna eu ';
wwv_flow_imp.g_varchar2_table(439) := 'nulla dolore magna pariatur deserunt amet reprehenderit."},{"rating":3,"review":"Ad aliqua ex eu cil';
wwv_flow_imp.g_varchar2_table(440) := 'lum labore elit mollit reprehenderit anim."},{"rating":1,"review":"Duis excepteur magna aliqua qui o';
wwv_flow_imp.g_varchar2_table(441) := 'fficia ipsum sunt."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNI';
wwv_flow_imp.g_varchar2_table(442) := 'T_PRICE,PRODUCT_DETAILS) values (31,''Women''''s Skirt (Green)'',5.65,utl_raw.cast_to_raw(''{"colour":"gr';
wwv_flow_imp.g_varchar2_table(443) := 'een","gender":"Women''''s","brand":"ZIDANT","description":"Et est officia est amet est nisi sit veniam';
wwv_flow_imp.g_varchar2_table(444) := ' proident. Ullamco proident culpa velit proident quis dolore occaecat proident Lorem tempor.","sizes';
wwv_flow_imp.g_varchar2_table(445) := '":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PROD';
wwv_flow_imp.g_varchar2_table(446) := 'UCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (32,''Women''''s Jacket (Blue)'',37,utl_raw.cast_';
wwv_flow_imp.g_varchar2_table(447) := 'to_raw(''{"colour":"blue","gender":"Women''''s","brand":"ZOGAK","description":"Tempor ipsum duis aliqua';
wwv_flow_imp.g_varchar2_table(448) := ' veniam qui laboris et ut officia. Fugiat fugiat nisi labore excepteur ullamco excepteur veniam in i';
wwv_flow_imp.g_varchar2_table(449) := 'n et adipisicing sint.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":9,"review":"Sit a';
wwv_flow_imp.g_varchar2_table(450) := 'met id ut laborum in exercitation laborum Lorem fugiat ex."},{"rating":7,"review":"Nisi non mollit d';
wwv_flow_imp.g_varchar2_table(451) := 'olore id aute velit laboris consequat voluptate id."},{"rating":1,"review":"Nisi nisi fugiat non nis';
wwv_flow_imp.g_varchar2_table(452) := 'i amet esse."},{"rating":1,"review":"Laborum eiusmod id ipsum aliqua adipisicing cillum enim."},{"ra';
wwv_flow_imp.g_varchar2_table(453) := 'ting":8,"review":"Duis aliqua ut nulla proident voluptate incididunt elit est exercitation id aute."';
wwv_flow_imp.g_varchar2_table(454) := '},{"rating":4,"review":"Veniam labore exercitation eiusmod nisi mollit anim eu."},{"rating":6,"revie';
wwv_flow_imp.g_varchar2_table(455) := 'w":"Exercitation eu est irure velit pariatur."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (';
wwv_flow_imp.g_varchar2_table(456) := 'PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (33,''Boy''''s Pyjamas (Grey)'',23.32,utl_raw';
wwv_flow_imp.g_varchar2_table(457) := '.cast_to_raw(''{"colour":"grey","gender":"Boy''''s","brand":"RETRACK","description":"Sit consectetur Lo';
wwv_flow_imp.g_varchar2_table(458) := 'rem culpa ipsum ad ullamco ea aute qui ea. Laboris ipsum enim enim veniam.","sizes":["1 Yr","2 Yr","';
wwv_flow_imp.g_varchar2_table(459) := '3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Ut incididunt veniam ullamco v';
wwv_flow_imp.g_varchar2_table(460) := 'oluptate occaecat velit."},{"rating":5,"review":"Consectetur cupidatat voluptate dolore velit culpa ';
wwv_flow_imp.g_varchar2_table(461) := 'est id enim aute."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT';
wwv_flow_imp.g_varchar2_table(462) := '_PRICE,PRODUCT_DETAILS) values (34,''Women''''s Jeans (Red)'',7.18,utl_raw.cast_to_raw(''{"colour":"red",';
wwv_flow_imp.g_varchar2_table(463) := '"gender":"Women''''s","brand":"PANZENT","description":"Eiusmod culpa dolore occaecat excepteur esse ma';
wwv_flow_imp.g_varchar2_table(464) := 'gna fugiat dolore cupidatat laboris mollit culpa. Consequat dolor qui tempor sit minim sit excepteur';
wwv_flow_imp.g_varchar2_table(465) := ' enim excepteur aute minim.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":10,"review":';
wwv_flow_imp.g_varchar2_table(466) := '"Nulla enim cillum pariatur do consectetur et Lorem."},{"rating":1,"review":"Cupidatat fugiat incidi';
wwv_flow_imp.g_varchar2_table(467) := 'dunt fugiat eu."},{"rating":1,"review":"Ullamco eiusmod adipisicing fugiat reprehenderit mollit aliq';
wwv_flow_imp.g_varchar2_table(468) := 'uip."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUC';
wwv_flow_imp.g_varchar2_table(469) := 'T_DETAILS) values (35,''Girl''''s Dress (Red)'',49.12,utl_raw.cast_to_raw(''{"colour":"red","gender":"Gir';
wwv_flow_imp.g_varchar2_table(470) := 'l''''s","brand":"NIXELT","description":"Ipsum pariatur laborum nulla pariatur consequat consequat amet';
wwv_flow_imp.g_varchar2_table(471) := ' nisi. Ut in quis officia excepteur.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"';
wwv_flow_imp.g_varchar2_table(472) := 'reviews":[{"rating":10,"review":"Ut est anim sit nulla commodo velit occaecat amet mollit fugiat id.';
wwv_flow_imp.g_varchar2_table(473) := '"},{"rating":2,"review":"Eu quis ea anim incididunt nisi nisi velit velit labore do."},{"rating":9,"';
wwv_flow_imp.g_varchar2_table(474) := 'review":"Eu laborum laborum reprehenderit minim officia anim."},{"rating":8,"review":"Et consectetur';
wwv_flow_imp.g_varchar2_table(475) := ' labore ullamco occaecat cupidatat magna pariatur esse qui ut mollit ea cillum."},{"rating":4,"revie';
wwv_flow_imp.g_varchar2_table(476) := 'w":"Dolore culpa magna commodo aute do culpa non commodo qui id commodo consectetur exercitation."},';
wwv_flow_imp.g_varchar2_table(477) := '{"rating":6,"review":"Adipisicing laborum tempor sunt laboris et sint aute pariatur."},{"rating":9,"';
wwv_flow_imp.g_varchar2_table(478) := 'review":"Excepteur voluptate qui magna in cillum aliqua."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH';
wwv_flow_imp.g_varchar2_table(479) := '_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (36,''Women''''s Trousers (Blue)''';
wwv_flow_imp.g_varchar2_table(480) := ',29.51,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Women''''s","brand":"TROLLERY","description":"P';
wwv_flow_imp.g_varchar2_table(481) := 'roident sunt ipsum pariatur duis dolor eu dolore culpa ad aliquip elit. Mollit Lorem et aliquip comm';
wwv_flow_imp.g_varchar2_table(482) := 'odo est anim amet eiusmod amet dolore laborum tempor officia.","sizes":[0,2,4,6,8,10,12,14,16,18,20]';
wwv_flow_imp.g_varchar2_table(483) := ',"reviews":[{"rating":10,"review":"Consequat ut commodo irure sit elit anim amet eu est sunt tempor ';
wwv_flow_imp.g_varchar2_table(484) := 'non."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUC';
wwv_flow_imp.g_varchar2_table(485) := 'T_DETAILS) values (37,''Boy''''s Jeans (Blue)'',22.98,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Bo';
wwv_flow_imp.g_varchar2_table(486) := 'y''''s","brand":"AVIT","description":"Velit velit esse nulla minim minim laborum esse. Sint minim id a';
wwv_flow_imp.g_varchar2_table(487) := 'liquip amet fugiat dolor aliqua.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"revi';
wwv_flow_imp.g_varchar2_table(488) := 'ews":[]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUC';
wwv_flow_imp.g_varchar2_table(489) := 'T_DETAILS) values (38,''Girl''''s Pyjamas (Red)'',11,utl_raw.cast_to_raw(''{"colour":"red","gender":"Girl';
wwv_flow_imp.g_varchar2_table(490) := '''''s","brand":"EMTRAK","description":"Magna est occaecat consectetur ullamco mollit dolore aute irure';
wwv_flow_imp.g_varchar2_table(491) := ' consectetur nulla ipsum id elit occaecat. Amet Lorem sint nulla eiusmod commodo aliqua cillum anim ';
wwv_flow_imp.g_varchar2_table(492) := 'tempor tempor pariatur do nostrud minim.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr';
wwv_flow_imp.g_varchar2_table(493) := '"],"reviews":[{"rating":4,"review":"Consectetur velit adipisicing excepteur in excepteur sit excepte';
wwv_flow_imp.g_varchar2_table(494) := 'ur irure veniam velit."},{"rating":4,"review":"Consectetur exercitation exercitation irure commodo o';
wwv_flow_imp.g_varchar2_table(495) := 'fficia do adipisicing ullamco sit anim consequat."},{"rating":9,"review":"Minim occaecat sunt laboru';
wwv_flow_imp.g_varchar2_table(496) := 'm voluptate culpa enim elit."},{"rating":2,"review":"Reprehenderit labore incididunt ex ullamco nost';
wwv_flow_imp.g_varchar2_table(497) := 'rud cillum irure mollit dolore aliqua enim tempor aliquip laborum."},{"rating":2,"review":"Enim comm';
wwv_flow_imp.g_varchar2_table(498) := 'odo adipisicing consequat commodo."},{"rating":8,"review":"Sint ut cillum Lorem ut ad aliquip elit s';
wwv_flow_imp.g_varchar2_table(499) := 'unt labore laboris consequat Lorem aliqua occaecat."},{"rating":2,"review":"Et consectetur in offici';
wwv_flow_imp.g_varchar2_table(500) := 'a ullamco labore ea duis amet."},{"rating":8,"review":"Reprehenderit enim tempor proident commodo ex';
wwv_flow_imp.g_varchar2_table(501) := ' eu fugiat cupidatat exercitation culpa id adipisicing deserunt officia."}]}''));'||wwv_flow.LF||
'        Insert into';
wwv_flow_imp.g_varchar2_table(502) := ' EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (39,''Boy''''s Tr';
wwv_flow_imp.g_varchar2_table(503) := 'ousers (Blue)'',34.06,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Boy''''s","brand":"DIGINETIC","de';
wwv_flow_imp.g_varchar2_table(504) := 'scription":"Dolor aliqua minim nostrud non labore in ullamco mollit mollit sit non. Duis nulla exerc';
wwv_flow_imp.g_varchar2_table(505) := 'itation et adipisicing nostrud voluptate cupidatat eu reprehenderit.","sizes":["1 Yr","2 Yr","3-4 Yr';
wwv_flow_imp.g_varchar2_table(506) := '","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":6,"review":"Culpa id consequat cillum dolor."},{';
wwv_flow_imp.g_varchar2_table(507) := '"rating":8,"review":"Qui do quis magna nostrud exercitation enim aute dolore proident ipsum sint nos';
wwv_flow_imp.g_varchar2_table(508) := 'trud deserunt."},{"rating":9,"review":"Excepteur fugiat adipisicing laboris ea culpa cupidatat labor';
wwv_flow_imp.g_varchar2_table(509) := 'um occaecat nostrud."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,U';
wwv_flow_imp.g_varchar2_table(510) := 'NIT_PRICE,PRODUCT_DETAILS) values (40,''Girl''''s Pyjamas (Black)'',8.66,utl_raw.cast_to_raw(''{"colour":';
wwv_flow_imp.g_varchar2_table(511) := '"black","gender":"Girl''''s","brand":"ISOLOGICS","description":"Ex exercitation aliquip cillum adipisi';
wwv_flow_imp.g_varchar2_table(512) := 'cing cupidatat. Culpa labore eiusmod do ut ipsum incididunt ipsum labore.","sizes":["1 Yr","2 Yr","3';
wwv_flow_imp.g_varchar2_table(513) := '-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":6,"review":"Duis minim duis dolor laboris e';
wwv_flow_imp.g_varchar2_table(514) := 'iusmod consequat fugiat adipisicing ex non culpa Lorem proident qui."},{"rating":4,"review":"Veniam ';
wwv_flow_imp.g_varchar2_table(515) := 'tempor commodo aliqua sit ex mollit cillum aute officia fugiat tempor sunt nulla elit."},{"rating":1';
wwv_flow_imp.g_varchar2_table(516) := '0,"review":"Dolore officia aute magna eiusmod exercitation esse amet tempor."},{"rating":7,"review":';
wwv_flow_imp.g_varchar2_table(517) := '"Proident nisi voluptate ea esse exercitation ullamco consequat consectetur in enim amet adipisicing';
wwv_flow_imp.g_varchar2_table(518) := ' commodo nulla."},{"rating":4,"review":"Irure ullamco id adipisicing fugiat Lorem do non officia nis';
wwv_flow_imp.g_varchar2_table(519) := 'i sunt esse mollit consectetur."},{"rating":9,"review":"Laboris do elit dolor officia irure esse inc';
wwv_flow_imp.g_varchar2_table(520) := 'ididunt pariatur elit."},{"rating":1,"review":"Aliqua Lorem nostrud et reprehenderit exercitation ex';
wwv_flow_imp.g_varchar2_table(521) := 'ercitation nostrud consectetur dolor."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_';
wwv_flow_imp.g_varchar2_table(522) := 'ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (41,''Women''''s Dress (Black)'',10.11,utl_raw.cast_t';
wwv_flow_imp.g_varchar2_table(523) := 'o_raw(''{"colour":"black","gender":"Women''''s","brand":"NEOCENT","description":"Eu enim aliquip deseru';
wwv_flow_imp.g_varchar2_table(524) := 'nt est duis do sunt consequat sit sit labore nisi. Culpa mollit cupidatat Lorem et minim sit.","size';
wwv_flow_imp.g_varchar2_table(525) := 's":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":4,"review":"Ex culpa sint ad eu quis."},{"rati';
wwv_flow_imp.g_varchar2_table(526) := 'ng":4,"review":"Irure labore adipisicing velit sint sint."},{"rating":4,"review":"Ullamco dolore ad ';
wwv_flow_imp.g_varchar2_table(527) := 'qui consequat labore do cillum velit."},{"rating":5,"review":"Velit officia eiusmod proident dolore ';
wwv_flow_imp.g_varchar2_table(528) := 'occaecat eu eiusmod."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,U';
wwv_flow_imp.g_varchar2_table(529) := 'NIT_PRICE,PRODUCT_DETAILS) values (1,''Boy''''s Shirt (White)'',29.55,utl_raw.cast_to_raw(''{"colour":"wh';
wwv_flow_imp.g_varchar2_table(530) := 'ite","gender":"Boy''''s","brand":"COMTOURS","description":"Labore commodo velit cupidatat ullamco ea p';
wwv_flow_imp.g_varchar2_table(531) := 'roident velit sunt adipisicing. Esse tempor exercitation reprehenderit ullamco esse incididunt dolor';
wwv_flow_imp.g_varchar2_table(532) := 'e laboris Lorem ipsum fugiat ea.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"revi';
wwv_flow_imp.g_varchar2_table(533) := 'ews":[]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUC';
wwv_flow_imp.g_varchar2_table(534) := 'T_DETAILS) values (2,''Women''''s Shirt (Green)'',16.67,utl_raw.cast_to_raw(''{"colour":"green","gender":';
wwv_flow_imp.g_varchar2_table(535) := '"Women''''s","brand":"NIKE","description":"Excepteur anim adipisicing aliqua ad. Ex aliquip ad tempor ';
wwv_flow_imp.g_varchar2_table(536) := 'cupidatat dolore ipsum ex anim Lorem aute amet.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"';
wwv_flow_imp.g_varchar2_table(537) := 'rating":8,"review":"Laborum ipsum adipisicing magna nulla tempor incididunt."},{"rating":10,"review"';
wwv_flow_imp.g_varchar2_table(538) := ':"Cupidatat dolore nulla pariatur quis quis."},{"rating":9,"review":"Pariatur mollit dolor in deseru';
wwv_flow_imp.g_varchar2_table(539) := 'nt cillum consectetur."},{"rating":3,"review":"Dolore occaecat mollit id ad aliqua irure reprehender';
wwv_flow_imp.g_varchar2_table(540) := 'it amet eiusmod pariatur."},{"rating":10,"review":"Est pariatur et qui minim velit non consectetur s';
wwv_flow_imp.g_varchar2_table(541) := 'int fugiat ad."},{"rating":6,"review":"Et pariatur ipsum eu qui."},{"rating":6,"review":"Voluptate l';
wwv_flow_imp.g_varchar2_table(542) := 'abore irure cupidatat mollit irure quis fugiat enim laborum consectetur officia sunt."},{"rating":8,';
wwv_flow_imp.g_varchar2_table(543) := '"review":"Irure elit do et elit aute veniam proident sunt."},{"rating":8,"review":"Aute mollit proid';
wwv_flow_imp.g_varchar2_table(544) := 'ent id veniam occaecat dolore mollit dolore nostrud."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRO';
wwv_flow_imp.g_varchar2_table(545) := 'DUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (3,''Boy''''s Sweater (Green)'',44.17,';
wwv_flow_imp.g_varchar2_table(546) := 'utl_raw.cast_to_raw(''{"colour":"green","gender":"Boy''''s","brand":"KINETICA","description":"Occaecat ';
wwv_flow_imp.g_varchar2_table(547) := 'dolore in ut et ad pariatur laborum mollit nulla exercitation. Laboris esse tempor quis velit nostru';
wwv_flow_imp.g_varchar2_table(548) := 'd exercitation veniam reprehenderit minim minim exercitation.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 ';
wwv_flow_imp.g_varchar2_table(549) := 'Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":5,"review":"Sunt ad proident excepteur laboris officia ';
wwv_flow_imp.g_varchar2_table(550) := 'eu reprehenderit dolor nostrud elit nulla pariatur incididunt Lorem."},{"rating":2,"review":"Ullamco';
wwv_flow_imp.g_varchar2_table(551) := ' ad amet fugiat adipisicing."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUC';
wwv_flow_imp.g_varchar2_table(552) := 'T_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (4,''Boy''''s Trousers (White)'',43.71,utl_raw.cast_to_raw(''{"';
wwv_flow_imp.g_varchar2_table(553) := 'colour":"white","gender":"Boy''''s","brand":"INTERLOO","description":"Nostrud esse velit incididunt oc';
wwv_flow_imp.g_varchar2_table(554) := 'caecat ullamco dolor quis reprehenderit proident dolore deserunt tempor qui proident. Magna deserunt';
wwv_flow_imp.g_varchar2_table(555) := ' sit minim eu commodo minim labore occaecat ea id sint laborum.","sizes":["1 Yr","2 Yr","3-4 Yr","5-';
wwv_flow_imp.g_varchar2_table(556) := '6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Anim culpa qui est adipisicing qui dolore';
wwv_flow_imp.g_varchar2_table(557) := ' enim. Sint duis aute laborum nisi ut elit Lorem nisi proident consectetur."},{"rating":6,"review":"';
wwv_flow_imp.g_varchar2_table(558) := 'Reprehenderit ad ipsum sint mollit aliqua."},{"rating":4,"review":"Enim culpa reprehenderit non ulla';
wwv_flow_imp.g_varchar2_table(559) := 'mco non ex veniam. Sit do incididunt ullamco ad et et aliquip deserunt dolor officia nostrud ipsum o';
wwv_flow_imp.g_varchar2_table(560) := 'fficia nostrud. Lorem esse tempor aliqua ut quis occaecat."},{"rating":9,"review":"Pariatur sit dolo';
wwv_flow_imp.g_varchar2_table(561) := 'r dolor tempor commodo aute culpa sit."},{"rating":2,"review":"Sunt enim sunt occaecat exercitation ';
wwv_flow_imp.g_varchar2_table(562) := 'deserunt nisi anim mollit deserunt non laboris cillum."},{"rating":8,"review":"Exercitation et duis ';
wwv_flow_imp.g_varchar2_table(563) := 'quis minim id duis veniam occaecat amet cillum velit pariatur tempor. Culpa aliquip adipisicing aliq';
wwv_flow_imp.g_varchar2_table(564) := 'uip non minim occaecat eu nisi esse veniam eu aliqua."},{"rating":5,"review":"Culpa elit nulla dolor';
wwv_flow_imp.g_varchar2_table(565) := 'e mollit tempor mollit in. Voluptate deserunt eiusmod sint id excepteur eiusmod excepteur qui enim c';
wwv_flow_imp.g_varchar2_table(566) := 'upidatat. Nostrud enim anim commodo adipisicing nisi dolore commodo elit commodo aliqua aliquip labo';
wwv_flow_imp.g_varchar2_table(567) := 'rum."},{"rating":4,"review":"Exercitation sunt consequat anim nisi sunt cillum esse amet ut reprehen';
wwv_flow_imp.g_varchar2_table(568) := 'derit ea. Laborum labore ipsum consectetur ad excepteur proident fugiat consectetur eiusmod incididu';
wwv_flow_imp.g_varchar2_table(569) := 'nt officia enim ullamco."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NA';
wwv_flow_imp.g_varchar2_table(570) := 'ME,UNIT_PRICE,PRODUCT_DETAILS) values (5,''Girl''''s Shorts (Red)'',38.28,utl_raw.cast_to_raw(''{"colour"';
wwv_flow_imp.g_varchar2_table(571) := ':"red","gender":"Girl''''s","brand":"OZEAN","description":"These sea shorts are designed with quick-dr';
wwv_flow_imp.g_varchar2_table(572) := 'ying and breathable materials, making them the perfect choice for a day out on the water.","sizes":[';
wwv_flow_imp.g_varchar2_table(573) := '"1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_S';
wwv_flow_imp.g_varchar2_table(574) := 'EARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (6,''Boy''''s Socks (Grey)'',';
wwv_flow_imp.g_varchar2_table(575) := '19.16,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Boy''''s","brand":"GROK","description":"Pariatur';
wwv_flow_imp.g_varchar2_table(576) := ' elit adipisicing aute dolor sunt laborum ullamco aliqua exercitation consectetur. Lorem qui sint ul';
wwv_flow_imp.g_varchar2_table(577) := 'lamco sint commodo anim.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"';
wwv_flow_imp.g_varchar2_table(578) := 'rating":5,"review":"Ea eu sit est consectetur quis in dolor ut."},{"rating":6,"review":"In do cillum';
wwv_flow_imp.g_varchar2_table(579) := ' occaecat minim."},{"rating":6,"review":"Laborum laborum excepteur ipsum aliquip reprehenderit cillu';
wwv_flow_imp.g_varchar2_table(580) := 'm irure proident voluptate eiusmod in culpa."},{"rating":9,"review":"Exercitation magna proident non';
wwv_flow_imp.g_varchar2_table(581) := ' deserunt consectetur consectetur do ex sint id irure ipsum voluptate."},{"rating":7,"review":"Aliqu';
wwv_flow_imp.g_varchar2_table(582) := 'ip irure minim quis quis voluptate reprehenderit mollit dolore."},{"rating":1,"review":"Duis mollit ';
wwv_flow_imp.g_varchar2_table(583) := 'aute cillum aute culpa magna."},{"rating":9,"review":"Magna exercitation exercitation sit commodo pr';
wwv_flow_imp.g_varchar2_table(584) := 'oident fugiat occaecat ullamco voluptate do consectetur officia velit."},{"rating":7,"review":"Labor';
wwv_flow_imp.g_varchar2_table(585) := 'is nostrud et nulla tempor commodo non aute ipsum excepteur qui dolore enim."}]}''));'||wwv_flow.LF||
'        Insert ';
wwv_flow_imp.g_varchar2_table(586) := 'into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (7,''Boy''''s';
wwv_flow_imp.g_varchar2_table(587) := ' Socks (Black)'',19.58,utl_raw.cast_to_raw(''{"colour":"black","gender":"Boy''''s","brand":"ENERVATE","d';
wwv_flow_imp.g_varchar2_table(588) := 'escription":"Sit minim sunt nulla proident velit Lorem dolor. Aute reprehenderit laborum labore proi';
wwv_flow_imp.g_varchar2_table(589) := 'dent non esse nisi ex magna consectetur minim ex est.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8';
wwv_flow_imp.g_varchar2_table(590) := ' Yr","9-10 Yr"],"reviews":[{"rating":8,"review":"Laborum laboris eu occaecat amet adipisicing conseq';
wwv_flow_imp.g_varchar2_table(591) := 'uat veniam velit."},{"rating":2,"review":"Mollit fugiat commodo minim sint do irure duis quis ex min';
wwv_flow_imp.g_varchar2_table(592) := 'im ad."},{"rating":2,"review":"Sit duis aliquip proident et nostrud enim anim amet dolor consequat t';
wwv_flow_imp.g_varchar2_table(593) := 'empor culpa."},{"rating":3,"review":"Proident aute voluptate aute irure."},{"rating":2,"review":"Ex ';
wwv_flow_imp.g_varchar2_table(594) := 'excepteur duis irure veniam elit occaecat sit Lorem labore id minim tempor dolore officia."},{"ratin';
wwv_flow_imp.g_varchar2_table(595) := 'g":2,"review":"Amet fugiat commodo qui eiusmod dolore sint fugiat commodo elit qui esse in officia."';
wwv_flow_imp.g_varchar2_table(596) := '},{"rating":2,"review":"Dolor proident proident ad officia cillum dolor aute officia enim exercitati';
wwv_flow_imp.g_varchar2_table(597) := 'on."},{"rating":4,"review":"Dolor esse cupidatat eiusmod non veniam elit nostrud aliquip eu elit."}]';
wwv_flow_imp.g_varchar2_table(598) := '}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAI';
wwv_flow_imp.g_varchar2_table(599) := 'LS) values (8,''Boy''''s Coat (Brown)'',21.16,utl_raw.cast_to_raw(''{"colour":"brown","gender":"Boy''''s","';
wwv_flow_imp.g_varchar2_table(600) := 'brand":"KOFFEE","description":"Voluptate quis excepteur mollit id dolore. Sunt aliquip in magna ut i';
wwv_flow_imp.g_varchar2_table(601) := 'rure nostrud duis officia fugiat aute.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"]';
wwv_flow_imp.g_varchar2_table(602) := ',"reviews":[]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,';
wwv_flow_imp.g_varchar2_table(603) := 'PRODUCT_DETAILS) values (9,''Women''''s Jeans (Brown)'',29.49,utl_raw.cast_to_raw(''{"colour":"brown","ge';
wwv_flow_imp.g_varchar2_table(604) := 'nder":"Women''''s","brand":"PROTODYNE","description":"Est dolor tempor sint commodo irure sint ut dolo';
wwv_flow_imp.g_varchar2_table(605) := 'r proident enim Lorem. Pariatur deserunt nostrud quis minim non.","sizes":[0,2,4,6,8,10,12,14,16,18,';
wwv_flow_imp.g_varchar2_table(606) := '20],"reviews":[{"rating":2,"review":"Occaecat cupidatat in id elit magna Lorem esse ad magna labore ';
wwv_flow_imp.g_varchar2_table(607) := 'non qui magna."},{"rating":8,"review":"Cupidatat cupidatat laboris consectetur labore veniam aliqua ';
wwv_flow_imp.g_varchar2_table(608) := 'et incididunt duis sunt proident."},{"rating":2,"review":"Esse ipsum veniam ullamco irure ad minim m';
wwv_flow_imp.g_varchar2_table(609) := 'ollit consequat non dolor labore."},{"rating":1,"review":"Cillum ea minim voluptate id ut consectetu';
wwv_flow_imp.g_varchar2_table(610) := 'r commodo nostrud cillum eiusmod eiusmod dolore cillum veniam."},{"rating":5,"review":"Excepteur adi';
wwv_flow_imp.g_varchar2_table(611) := 'pisicing culpa dolor id et irure sint ex non nostrud velit pariatur esse quis."},{"rating":9,"review';
wwv_flow_imp.g_varchar2_table(612) := '":"Do fugiat aliqua sunt quis proident fugiat."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS ';
wwv_flow_imp.g_varchar2_table(613) := '(PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (10,''Women''''s Skirt (Red)'',30.69,utl_raw';
wwv_flow_imp.g_varchar2_table(614) := '.cast_to_raw(''{"colour":"green","gender":"Women''''s","brand":"FLYBOYZ","description":"Qui aliquip dol';
wwv_flow_imp.g_varchar2_table(615) := 'or aute labore amet nostrud deserunt nulla ut veniam id. Ut aute velit tempor anim ex sit nisi.","si';
wwv_flow_imp.g_varchar2_table(616) := 'zes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":7,"review":"Mollit consequat minim sit conse';
wwv_flow_imp.g_varchar2_table(617) := 'quat deserunt duis."},{"rating":8,"review":"Quis eu esse proident elit eu aliqua magna voluptate lab';
wwv_flow_imp.g_varchar2_table(618) := 'ore adipisicing voluptate ex do."},{"rating":6,"review":"Laborum nulla aliquip nulla adipisicing ali';
wwv_flow_imp.g_varchar2_table(619) := 'quip qui cupidatat aliquip in."},{"rating":3,"review":"Exercitation aute voluptate voluptate tempor ';
wwv_flow_imp.g_varchar2_table(620) := 'sit enim ut veniam do."},{"rating":8,"review":"Cillum cillum anim aliqua eu deserunt amet eu ut veni';
wwv_flow_imp.g_varchar2_table(621) := 'am in qui."},{"rating":7,"review":"Nostrud aliqua ullamco irure consectetur elit nisi eu elit repreh';
wwv_flow_imp.g_varchar2_table(622) := 'enderit ut."},{"rating":5,"review":"Irure nisi dolore dolore ut non ad minim pariatur."},{"rating":2';
wwv_flow_imp.g_varchar2_table(623) := ',"review":"Laboris aliqua sint est incididunt sunt non tempor irure reprehenderit labore."}]}''));'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(624) := '      Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) valu';
wwv_flow_imp.g_varchar2_table(625) := 'es (11,''Boy''''s Shorts (Blue)'',10.48,utl_raw.cast_to_raw(''{"colour":"blue","gender":"Boy''''s","brand":';
wwv_flow_imp.g_varchar2_table(626) := '"WRAPTURE","description":"Id sit adipisicing ea dolore fugiat laborum ut dolore. Reprehenderit aliqu';
wwv_flow_imp.g_varchar2_table(627) := 'a non adipisicing aliqua adipisicing aute ullamco consectetur est aliqua.","sizes":["1 Yr","2 Yr","3';
wwv_flow_imp.g_varchar2_table(628) := '-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Laborum labore exercitation cul';
wwv_flow_imp.g_varchar2_table(629) := 'pa sint cillum aute duis labore do excepteur."},{"rating":10,"review":"Do velit laborum adipisicing ';
wwv_flow_imp.g_varchar2_table(630) := 'velit."},{"rating":6,"review":"Culpa dolor aute adipisicing ad."},{"rating":6,"review":"Sit sunt eli';
wwv_flow_imp.g_varchar2_table(631) := 't proident fugiat consectetur id incididunt nulla nulla magna consectetur."},{"rating":6,"review":"A';
wwv_flow_imp.g_varchar2_table(632) := 'dipisicing ipsum eiusmod sint ullamco dolor irure qui officia."},{"rating":4,"review":"Ipsum commodo';
wwv_flow_imp.g_varchar2_table(633) := ' amet non ut labore."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,U';
wwv_flow_imp.g_varchar2_table(634) := 'NIT_PRICE,PRODUCT_DETAILS) values (12,''Boy''''s Socks (White)'',12.64,utl_raw.cast_to_raw(''{"colour":"g';
wwv_flow_imp.g_varchar2_table(635) := 'rey","gender":"Boy''''s","brand":"HANDSHAKE","description":"Tempor laborum voluptate mollit aliquip et';
wwv_flow_imp.g_varchar2_table(636) := ' tempor nostrud Lorem. Nostrud anim exercitation est fugiat elit est deserunt mollit exercitation.",';
wwv_flow_imp.g_varchar2_table(637) := '"sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":8,"review":"Quis c';
wwv_flow_imp.g_varchar2_table(638) := 'ulpa laborum ex magna."},{"rating":3,"review":"Culpa ullamco deserunt ex ea."},{"rating":3,"review":';
wwv_flow_imp.g_varchar2_table(639) := '"Fugiat ullamco reprehenderit tempor nulla ad fugiat qui excepteur sunt officia deserunt nulla."},{"';
wwv_flow_imp.g_varchar2_table(640) := 'rating":2,"review":"Mollit dolore magna magna veniam culpa ullamco tempor esse id in occaecat except';
wwv_flow_imp.g_varchar2_table(641) := 'eur ullamco ea."},{"rating":10,"review":"Culpa dolore enim consequat aliquip nulla ipsum."},{"rating';
wwv_flow_imp.g_varchar2_table(642) := '":2,"review":"Excepteur aliqua sunt exercitation mollit pariatur anim tempor."},{"rating":8,"review"';
wwv_flow_imp.g_varchar2_table(643) := ':"Proident culpa tempor dolore deserunt anim ea deserunt quis duis."},{"rating":8,"review":"Reprehen';
wwv_flow_imp.g_varchar2_table(644) := 'derit est do quis quis reprehenderit adipisicing qui Lorem mollit sit labore veniam."},{"rating":1,"';
wwv_flow_imp.g_varchar2_table(645) := 'review":"Mollit dolore ad laboris ut cillum velit in sint labore nulla Lorem minim."}]}''));'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(646) := 'Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (13';
wwv_flow_imp.g_varchar2_table(647) := ',''Boy''''s Hoodie (Grey)'',26.14,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Boy''''s","brand":"SUNCL';
wwv_flow_imp.g_varchar2_table(648) := 'IPSE","description":"Voluptate irure voluptate labore sint amet occaecat elit ea incididunt aliquip.';
wwv_flow_imp.g_varchar2_table(649) := ' Tempor laboris tempor tempor magna officia in aliqua consequat elit occaecat.","sizes":["1 Yr","2 Y';
wwv_flow_imp.g_varchar2_table(650) := 'r","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Fugiat officia nostrud cil';
wwv_flow_imp.g_varchar2_table(651) := 'lum duis consequat sunt culpa duis laborum reprehenderit laborum."},{"rating":10,"review":"Et do rep';
wwv_flow_imp.g_varchar2_table(652) := 'rehenderit do irure tempor id aliquip voluptate anim consequat amet sunt."},{"rating":3,"review":"Mi';
wwv_flow_imp.g_varchar2_table(653) := 'nim adipisicing dolore eiusmod laborum aliqua non Lorem laboris minim est cillum qui qui Lorem."},{"';
wwv_flow_imp.g_varchar2_table(654) := 'rating":4,"review":"Esse Lorem aute deserunt quis."},{"rating":1,"review":"Ex deserunt aliqua consec';
wwv_flow_imp.g_varchar2_table(655) := 'tetur elit cillum cillum ex et mollit sint."},{"rating":4,"review":"Magna esse ipsum ipsum irure off';
wwv_flow_imp.g_varchar2_table(656) := 'icia nostrud ad velit sit."},{"rating":8,"review":"Mollit et tempor esse fugiat fugiat ad voluptate ';
wwv_flow_imp.g_varchar2_table(657) := 'irure est sunt proident magna anim ex."},{"rating":4,"review":"Nulla nisi esse ut exercitation commo';
wwv_flow_imp.g_varchar2_table(658) := 'do irure non amet labore mollit et elit."},{"rating":1,"review":"Enim officia anim proident consequa';
wwv_flow_imp.g_varchar2_table(659) := 't."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_';
wwv_flow_imp.g_varchar2_table(660) := 'DETAILS) values (14,''Women''''s Skirt (Brown)'',13.97,utl_raw.cast_to_raw(''{"colour":"brown","gender":"';
wwv_flow_imp.g_varchar2_table(661) := 'Women''''s","brand":"ISOTRONIC","description":"Magna Lorem do ad incididunt qui magna irure commodo ni';
wwv_flow_imp.g_varchar2_table(662) := 'si. Dolore ipsum adipisicing magna ea ullamco Lorem officia culpa do laborum voluptate.","sizes":[0,';
wwv_flow_imp.g_varchar2_table(663) := '2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":1,"review":"Officia occaecat laboris magna sint temp';
wwv_flow_imp.g_varchar2_table(664) := 'or officia deserunt proident eu excepteur."},{"rating":2,"review":"Aliqua nisi sint enim ad mollit q';
wwv_flow_imp.g_varchar2_table(665) := 'ui."},{"rating":3,"review":"Fugiat excepteur eiusmod incididunt Lorem nostrud nostrud labore aute es';
wwv_flow_imp.g_varchar2_table(666) := 'se aliquip."},{"rating":8,"review":"Voluptate ad enim anim culpa veniam amet."},{"rating":3,"review"';
wwv_flow_imp.g_varchar2_table(667) := ':"Do cillum quis cillum Lorem tempor labore laboris."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRO';
wwv_flow_imp.g_varchar2_table(668) := 'DUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (15,''Girl''''s Coat (Blue)'',13.09,ut';
wwv_flow_imp.g_varchar2_table(669) := 'l_raw.cast_to_raw(''{"colour":"blue","gender":"Girl''''s","brand":"DECRATEX","description":"Proident ut';
wwv_flow_imp.g_varchar2_table(670) := ' officia non duis est eu aliquip culpa cupidatat est incididunt amet ipsum veniam. Aliqua ea cupidat';
wwv_flow_imp.g_varchar2_table(671) := 'at incididunt ad excepteur irure ad pariatur occaecat duis incididunt excepteur amet.","sizes":["1 Y';
wwv_flow_imp.g_varchar2_table(672) := 'r","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":8,"review":"Officia irure deser';
wwv_flow_imp.g_varchar2_table(673) := 'unt mollit Lorem dolor dolor minim deserunt."},{"rating":10,"review":"Aliqua nostrud dolore enim dol';
wwv_flow_imp.g_varchar2_table(674) := 'ore reprehenderit officia quis aliquip irure occaecat et."},{"rating":2,"review":"Consectetur conseq';
wwv_flow_imp.g_varchar2_table(675) := 'uat ut cupidatat et elit et cillum veniam exercitation Lorem culpa ipsum."},{"rating":9,"review":"Ni';
wwv_flow_imp.g_varchar2_table(676) := 'si tempor incididunt Lorem sit sit do mollit qui aliquip qui eu quis Lorem."},{"rating":9,"review":"';
wwv_flow_imp.g_varchar2_table(677) := 'Sunt nulla ad dolore fugiat cillum et."},{"rating":8,"review":"Incididunt nostrud officia sunt cupid';
wwv_flow_imp.g_varchar2_table(678) := 'atat culpa ex id ut."},{"rating":1,"review":"Deserunt sit officia enim adipisicing exercitation veli';
wwv_flow_imp.g_varchar2_table(679) := 't ipsum dolore laboris officia mollit ex esse et."},{"rating":3,"review":"Aliqua nulla laborum id mo';
wwv_flow_imp.g_varchar2_table(680) := 'llit irure incididunt aliqua mollit qui nostrud consectetur sint aliqua quis."}]}''));'||wwv_flow.LF||
'        Insert';
wwv_flow_imp.g_varchar2_table(681) := ' into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (42,''Boy''';
wwv_flow_imp.g_varchar2_table(682) := '''s Jeans (Black)'',16.64,utl_raw.cast_to_raw(''{"colour":"black","gender":"Boy''''s","brand":"EARTHMARK"';
wwv_flow_imp.g_varchar2_table(683) := ',"description":"Duis dolor est eu elit anim proident aliqua eu tempor. Est fugiat non ullamco et par';
wwv_flow_imp.g_varchar2_table(684) := 'iatur nulla exercitation eiusmod id officia minim.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr';
wwv_flow_imp.g_varchar2_table(685) := '","9-10 Yr"],"reviews":[{"rating":10,"review":"Anim aliquip id reprehenderit laboris."},{"rating":7,';
wwv_flow_imp.g_varchar2_table(686) := '"review":"Nostrud non cupidatat id eiusmod aliquip anim ullamco aliquip cupidatat excepteur dolor re';
wwv_flow_imp.g_varchar2_table(687) := 'prehenderit."},{"rating":6,"review":"Veniam consequat deserunt nostrud sunt est commodo sint eu fugi';
wwv_flow_imp.g_varchar2_table(688) := 'at ipsum deserunt aute elit est."},{"rating":9,"review":"Eiusmod excepteur ut ullamco eiusmod labore';
wwv_flow_imp.g_varchar2_table(689) := ' deserunt."},{"rating":5,"review":"Aute deserunt eu voluptate id irure aliquip duis sint proident do';
wwv_flow_imp.g_varchar2_table(690) := 'lore dolor."},{"rating":5,"review":"Dolore mollit quis elit qui voluptate ad culpa voluptate elit co';
wwv_flow_imp.g_varchar2_table(691) := 'nsectetur."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,';
wwv_flow_imp.g_varchar2_table(692) := 'PRODUCT_DETAILS) values (43,''Boy''''s Trousers (Black)'',39.32,utl_raw.cast_to_raw(''{"colour":"blue","g';
wwv_flow_imp.g_varchar2_table(693) := 'ender":"Boy''''s","brand":"PHOLIO","description":"Voluptate ex mollit enim minim nulla proident dolor ';
wwv_flow_imp.g_varchar2_table(694) := 'eu nostrud velit. Ex ullamco aute dolor duis elit elit.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7';
wwv_flow_imp.g_varchar2_table(695) := '-8 Yr","9-10 Yr"],"reviews":[{"rating":3,"review":"Labore non exercitation anim id deserunt excepteu';
wwv_flow_imp.g_varchar2_table(696) := 'r dolore sunt deserunt dolor."},{"rating":5,"review":"Laborum eiusmod mollit amet nulla ex esse culp';
wwv_flow_imp.g_varchar2_table(697) := 'a ut elit reprehenderit labore ex Lorem cupidatat."},{"rating":7,"review":"Reprehenderit dolore aute';
wwv_flow_imp.g_varchar2_table(698) := ' consectetur voluptate excepteur veniam nulla ad."},{"rating":5,"review":"Reprehenderit proident in ';
wwv_flow_imp.g_varchar2_table(699) := 'elit pariatur."},{"rating":8,"review":"Magna laborum ad deserunt voluptate enim excepteur enim dolor';
wwv_flow_imp.g_varchar2_table(700) := 'e veniam consequat officia anim dolore mollit."},{"rating":3,"review":"Elit et reprehenderit amet au';
wwv_flow_imp.g_varchar2_table(701) := 'te amet laboris minim irure sint."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,P';
wwv_flow_imp.g_varchar2_table(702) := 'RODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (44,''Women''''s Coat (Black)'',31.68,utl_raw.cast_to_raw';
wwv_flow_imp.g_varchar2_table(703) := '(''{"colour":"black","gender":"Women''''s","brand":"COMVEYOR","description":"Exercitation ut ad reprehe';
wwv_flow_imp.g_varchar2_table(704) := 'nderit sunt eiusmod sit. Qui nisi ut esse mollit nisi.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"revie';
wwv_flow_imp.g_varchar2_table(705) := 'ws":[{"rating":7,"review":"Ad consequat nisi est tempor nisi nulla veniam consectetur ad ut laborum ';
wwv_flow_imp.g_varchar2_table(706) := 'magna."},{"rating":8,"review":"Incididunt magna ipsum cupidatat elit eiusmod enim mollit eiusmod id ';
wwv_flow_imp.g_varchar2_table(707) := 'esse sit elit irure Lorem."},{"rating":7,"review":"Aute aliquip et esse consequat reprehenderit ipsu';
wwv_flow_imp.g_varchar2_table(708) := 'm ut."},{"rating":8,"review":"Consectetur commodo cupidatat nostrud qui labore magna duis sit."},{"r';
wwv_flow_imp.g_varchar2_table(709) := 'ating":8,"review":"Qui occaecat elit exercitation do est officia fugiat adipisicing velit occaecat d';
wwv_flow_imp.g_varchar2_table(710) := 'eserunt Lorem ex adipisicing."},{"rating":6,"review":"Velit est commodo esse sint id ullamco aute ut';
wwv_flow_imp.g_varchar2_table(711) := ' ut officia laboris irure in."},{"rating":10,"review":"Ad nulla labore cupidatat do laboris do elit ';
wwv_flow_imp.g_varchar2_table(712) := 'cupidatat excepteur occaecat cupidatat."},{"rating":5,"review":"Do esse magna occaecat non."},{"rati';
wwv_flow_imp.g_varchar2_table(713) := 'ng":10,"review":"Et sint qui tempor nostrud sunt sit duis dolor excepteur voluptate."}]}''));'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(714) := ' Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PRODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (4';
wwv_flow_imp.g_varchar2_table(715) := '5,''Men''''s Jeans (Grey)'',27.64,utl_raw.cast_to_raw(''{"colour":"grey","gender":"Men''''s","brand":"QNEKT';
wwv_flow_imp.g_varchar2_table(716) := '","description":"Dolore duis minim dolor est fugiat sit dolor nisi anim Lorem culpa id. Consequat la';
wwv_flow_imp.g_varchar2_table(717) := 'bore et reprehenderit pariatur culpa minim laboris pariatur esse aliquip.","sizes":["XS","S","M","L"';
wwv_flow_imp.g_varchar2_table(718) := ',"XL","XXL"],"reviews":[{"rating":7,"review":"Veniam qui ipsum consequat laboris ad aliquip est repr';
wwv_flow_imp.g_varchar2_table(719) := 'ehenderit esse sint cupidatat tempor."},{"rating":8,"review":"Ut anim anim ipsum ipsum irure."},{"ra';
wwv_flow_imp.g_varchar2_table(720) := 'ting":9,"review":"Non qui sunt ullamco deserunt sint."},{"rating":10,"review":"Nostrud fugiat velit ';
wwv_flow_imp.g_varchar2_table(721) := 'aliqua eu culpa do excepteur do."}]}''));'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_PRODUCTS (PRODUCT_ID,PR';
wwv_flow_imp.g_varchar2_table(722) := 'ODUCT_NAME,UNIT_PRICE,PRODUCT_DETAILS) values (46,''Girl''''s Trousers (Red)'',39.16,utl_raw.cast_to_raw';
wwv_flow_imp.g_varchar2_table(723) := '(''{"colour":"red","gender":"Girl''''s","brand":"OTHERSIDE","description":"Lorem officia laborum deseru';
wwv_flow_imp.g_varchar2_table(724) := 'nt veniam cillum anim adipisicing minim aute ad esse sint sit tempor. Magna enim proident eiusmod in';
wwv_flow_imp.g_varchar2_table(725) := 'cididunt adipisicing duis deserunt pariatur sint officia occaecat est minim ipsum.","sizes":["1 Yr",';
wwv_flow_imp.g_varchar2_table(726) := '"2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":9,"review":"Magna magna ullamco ip';
wwv_flow_imp.g_varchar2_table(727) := 'sum pariatur occaecat eiusmod amet ea sunt reprehenderit dolore aute voluptate."},{"rating":7,"revie';
wwv_flow_imp.g_varchar2_table(728) := 'w":"Eiusmod cupidatat cillum qui dolor consequat."},{"rating":4,"review":"Do proident cillum cupidat';
wwv_flow_imp.g_varchar2_table(729) := 'at laboris in cillum."},{"rating":5,"review":"Sunt eiusmod ea labore est sint adipisicing velit duis';
wwv_flow_imp.g_varchar2_table(730) := '."},{"rating":6,"review":"Ut consectetur ad magna officia ut aliqua deserunt magna."}]}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(731) := ' -- Order items data'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_';
wwv_flow_imp.g_varchar2_table(732) := 'ID,UNIT_PRICE,QUANTITY) values (349,1,11,30.69,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (';
wwv_flow_imp.g_varchar2_table(733) := 'ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (349,2,12,10.48,4);'||wwv_flow.LF||
'        Insert into';
wwv_flow_imp.g_varchar2_table(734) := ' EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (401,1,28';
wwv_flow_imp.g_varchar2_table(735) := ',10.24,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PR';
wwv_flow_imp.g_varchar2_table(736) := 'ICE,QUANTITY) values (401,2,12,10.48,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,L';
wwv_flow_imp.g_varchar2_table(737) := 'INE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (430,1,18,24.46,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_';
wwv_flow_imp.g_varchar2_table(738) := 'SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (430,2,15,13.97,5);';
wwv_flow_imp.g_varchar2_table(739) := ''||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTI';
wwv_flow_imp.g_varchar2_table(740) := 'TY) values (437,1,37,29.51,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_I';
wwv_flow_imp.g_varchar2_table(741) := 'D,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (437,2,20,28.21,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORD';
wwv_flow_imp.g_varchar2_table(742) := 'ER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (453,1,43,16.64,3);'||wwv_flow.LF||
'        I';
wwv_flow_imp.g_varchar2_table(743) := 'nsert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values';
wwv_flow_imp.g_varchar2_table(744) := ' (453,2,2,29.55,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_I';
wwv_flow_imp.g_varchar2_table(745) := 'D,UNIT_PRICE,QUANTITY) values (506,1,18,24.46,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (O';
wwv_flow_imp.g_varchar2_table(746) := 'RDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (506,2,21,38.34,3);'||wwv_flow.LF||
'        Insert into ';
wwv_flow_imp.g_varchar2_table(747) := 'EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (513,1,11,';
wwv_flow_imp.g_varchar2_table(748) := '30.69,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRI';
wwv_flow_imp.g_varchar2_table(749) := 'CE,QUANTITY) values (513,2,4,44.17,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LIN';
wwv_flow_imp.g_varchar2_table(750) := 'E_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (513,3,19,14.34,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SE';
wwv_flow_imp.g_varchar2_table(751) := 'ARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (544,1,37,29.51,5);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(752) := '       Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY';
wwv_flow_imp.g_varchar2_table(753) := ') values (544,2,6,38.28,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,P';
wwv_flow_imp.g_varchar2_table(754) := 'RODUCT_ID,UNIT_PRICE,QUANTITY) values (544,3,27,39.91,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_';
wwv_flow_imp.g_varchar2_table(755) := 'ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (585,1,29,24.71,3);'||wwv_flow.LF||
'        Inse';
wwv_flow_imp.g_varchar2_table(756) := 'rt into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (5';
wwv_flow_imp.g_varchar2_table(757) := '85,2,31,28.59,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,';
wwv_flow_imp.g_varchar2_table(758) := 'UNIT_PRICE,QUANTITY) values (585,3,37,29.51,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORD';
wwv_flow_imp.g_varchar2_table(759) := 'ER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (608,1,15,13.97,5);'||wwv_flow.LF||
'        Insert into EB';
wwv_flow_imp.g_varchar2_table(760) := 'A_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (608,2,23,10';
wwv_flow_imp.g_varchar2_table(761) := '.33,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE';
wwv_flow_imp.g_varchar2_table(762) := ',QUANTITY) values (608,3,35,7.18,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_';
wwv_flow_imp.g_varchar2_table(763) := 'ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (672,1,46,39.16,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEAR';
wwv_flow_imp.g_varchar2_table(764) := 'CH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (687,1,42,10.11,2);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(765) := '     Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) ';
wwv_flow_imp.g_varchar2_table(766) := 'values (687,2,13,12.64,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PR';
wwv_flow_imp.g_varchar2_table(767) := 'ODUCT_ID,UNIT_PRICE,QUANTITY) values (707,1,18,24.46,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_I';
wwv_flow_imp.g_varchar2_table(768) := 'TEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (760,1,46,39.16,5);'||wwv_flow.LF||
'        Inser';
wwv_flow_imp.g_varchar2_table(769) := 't into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (76';
wwv_flow_imp.g_varchar2_table(770) := '0,2,20,28.21,1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,U';
wwv_flow_imp.g_varchar2_table(771) := 'NIT_PRICE,QUANTITY) values (761,1,33,37,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_I';
wwv_flow_imp.g_varchar2_table(772) := 'D,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (761,2,2,29.55,2);'||wwv_flow.LF||
'        Insert into EBA_DEM';
wwv_flow_imp.g_varchar2_table(773) := 'O_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (765,1,34,23.32,5';
wwv_flow_imp.g_varchar2_table(774) := ');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUAN';
wwv_flow_imp.g_varchar2_table(775) := 'TITY) values (765,2,13,12.64,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM';
wwv_flow_imp.g_varchar2_table(776) := '_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (766,1,12,10.48,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_O';
wwv_flow_imp.g_varchar2_table(777) := 'RDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (769,1,42,10.11,2);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(778) := ' Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) valu';
wwv_flow_imp.g_varchar2_table(779) := 'es (808,1,39,11,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_I';
wwv_flow_imp.g_varchar2_table(780) := 'D,UNIT_PRICE,QUANTITY) values (808,2,13,12.64,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (O';
wwv_flow_imp.g_varchar2_table(781) := 'RDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1,1,33,37,4);'||wwv_flow.LF||
'        Insert into EBA_D';
wwv_flow_imp.g_varchar2_table(782) := 'EMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1,2,11,30.69,2';
wwv_flow_imp.g_varchar2_table(783) := ');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUAN';
wwv_flow_imp.g_varchar2_table(784) := 'TITY) values (3,1,41,8.66,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID';
wwv_flow_imp.g_varchar2_table(785) := ',PRODUCT_ID,UNIT_PRICE,QUANTITY) values (5,1,40,34.06,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_';
wwv_flow_imp.g_varchar2_table(786) := 'ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (5,2,32,5.65,3);'||wwv_flow.LF||
'        Insert ';
wwv_flow_imp.g_varchar2_table(787) := 'into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (7,1,';
wwv_flow_imp.g_varchar2_table(788) := '36,49.12,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_';
wwv_flow_imp.g_varchar2_table(789) := 'PRICE,QUANTITY) values (7,2,29,24.71,1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,L';
wwv_flow_imp.g_varchar2_table(790) := 'INE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (17,1,46,39.16,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_S';
wwv_flow_imp.g_varchar2_table(791) := 'EARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (17,2,26,48.75,4);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(792) := '       Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY';
wwv_flow_imp.g_varchar2_table(793) := ') values (20,1,27,39.91,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,P';
wwv_flow_imp.g_varchar2_table(794) := 'RODUCT_ID,UNIT_PRICE,QUANTITY) values (20,2,9,21.16,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_IT';
wwv_flow_imp.g_varchar2_table(795) := 'EMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (20,3,32,5.65,2);'||wwv_flow.LF||
'        Insert i';
wwv_flow_imp.g_varchar2_table(796) := 'nto EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (63,1,';
wwv_flow_imp.g_varchar2_table(797) := '7,19.16,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_P';
wwv_flow_imp.g_varchar2_table(798) := 'RICE,QUANTITY) values (63,2,24,48.39,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,L';
wwv_flow_imp.g_varchar2_table(799) := 'INE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (78,1,3,16.67,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SE';
wwv_flow_imp.g_varchar2_table(800) := 'ARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (78,2,35,7.18,1);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(801) := '     Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) ';
wwv_flow_imp.g_varchar2_table(802) := 'values (78,3,9,21.16,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PROD';
wwv_flow_imp.g_varchar2_table(803) := 'UCT_ID,UNIT_PRICE,QUANTITY) values (79,1,34,23.32,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEM';
wwv_flow_imp.g_varchar2_table(804) := 'S (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (79,2,8,19.58,4);'||wwv_flow.LF||
'        Insert int';
wwv_flow_imp.g_varchar2_table(805) := 'o EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (79,3,4,';
wwv_flow_imp.g_varchar2_table(806) := '44.17,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRI';
wwv_flow_imp.g_varchar2_table(807) := 'CE,QUANTITY) values (82,1,21,38.34,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LIN';
wwv_flow_imp.g_varchar2_table(808) := 'E_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (82,2,10,29.49,1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEA';
wwv_flow_imp.g_varchar2_table(809) := 'RCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (92,1,15,13.97,1);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(810) := '     Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) ';
wwv_flow_imp.g_varchar2_table(811) := 'values (125,1,22,39.78,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PR';
wwv_flow_imp.g_varchar2_table(812) := 'ODUCT_ID,UNIT_PRICE,QUANTITY) values (125,2,39,11,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEM';
wwv_flow_imp.g_varchar2_table(813) := 'S (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (132,1,11,30.69,4);'||wwv_flow.LF||
'        Insert i';
wwv_flow_imp.g_varchar2_table(814) := 'nto EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (132,2';
wwv_flow_imp.g_varchar2_table(815) := ',31,28.59,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT';
wwv_flow_imp.g_varchar2_table(816) := '_PRICE,QUANTITY) values (132,3,10,29.49,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_I';
wwv_flow_imp.g_varchar2_table(817) := 'D,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (159,1,8,19.58,2);'||wwv_flow.LF||
'        Insert into EBA_DEM';
wwv_flow_imp.g_varchar2_table(818) := 'O_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (182,1,23,10.33,4';
wwv_flow_imp.g_varchar2_table(819) := ');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUAN';
wwv_flow_imp.g_varchar2_table(820) := 'TITY) values (182,2,20,28.21,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM';
wwv_flow_imp.g_varchar2_table(821) := '_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (196,1,3,16.67,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_OR';
wwv_flow_imp.g_varchar2_table(822) := 'DER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (196,2,23,10.33,4);'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(823) := 'Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) value';
wwv_flow_imp.g_varchar2_table(824) := 's (201,1,19,14.34,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT';
wwv_flow_imp.g_varchar2_table(825) := '_ID,UNIT_PRICE,QUANTITY) values (201,2,36,49.12,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS ';
wwv_flow_imp.g_varchar2_table(826) := '(ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (204,1,33,37,4);'||wwv_flow.LF||
'        Insert into E';
wwv_flow_imp.g_varchar2_table(827) := 'BA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (204,2,12,1';
wwv_flow_imp.g_varchar2_table(828) := '0.48,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRIC';
wwv_flow_imp.g_varchar2_table(829) := 'E,QUANTITY) values (240,1,12,10.48,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LIN';
wwv_flow_imp.g_varchar2_table(830) := 'E_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (240,2,17,39.89,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SE';
wwv_flow_imp.g_varchar2_table(831) := 'ARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (290,1,11,30.69,4);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(832) := '       Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY';
wwv_flow_imp.g_varchar2_table(833) := ') values (290,2,27,39.91,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,';
wwv_flow_imp.g_varchar2_table(834) := 'PRODUCT_ID,UNIT_PRICE,QUANTITY) values (290,3,38,22.98,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER';
wwv_flow_imp.g_varchar2_table(835) := '_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (298,1,9,21.16,4);'||wwv_flow.LF||
'        Inse';
wwv_flow_imp.g_varchar2_table(836) := 'rt into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (2';
wwv_flow_imp.g_varchar2_table(837) := '98,2,43,16.64,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,';
wwv_flow_imp.g_varchar2_table(838) := 'UNIT_PRICE,QUANTITY) values (306,1,28,10.24,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORD';
wwv_flow_imp.g_varchar2_table(839) := 'ER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (307,1,38,22.98,4);'||wwv_flow.LF||
'        Insert into EB';
wwv_flow_imp.g_varchar2_table(840) := 'A_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (307,2,19,14';
wwv_flow_imp.g_varchar2_table(841) := '.34,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE';
wwv_flow_imp.g_varchar2_table(842) := ',QUANTITY) values (331,1,34,23.32,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE';
wwv_flow_imp.g_varchar2_table(843) := '_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1483,1,46,39.16,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SE';
wwv_flow_imp.g_varchar2_table(844) := 'ARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1483,2,23,10.33,3);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(845) := '        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTIT';
wwv_flow_imp.g_varchar2_table(846) := 'Y) values (1483,3,14,26.14,1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_I';
wwv_flow_imp.g_varchar2_table(847) := 'D,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1486,1,44,39.32,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_OR';
wwv_flow_imp.g_varchar2_table(848) := 'DER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1486,2,36,49.12,2);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(849) := ' Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) valu';
wwv_flow_imp.g_varchar2_table(850) := 'es (1486,3,14,26.14,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODU';
wwv_flow_imp.g_varchar2_table(851) := 'CT_ID,UNIT_PRICE,QUANTITY) values (1491,1,12,10.48,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITE';
wwv_flow_imp.g_varchar2_table(852) := 'MS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1498,1,16,13.09,2);'||wwv_flow.LF||
'        Insert';
wwv_flow_imp.g_varchar2_table(853) := ' into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (149';
wwv_flow_imp.g_varchar2_table(854) := '8,2,5,43.71,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UN';
wwv_flow_imp.g_varchar2_table(855) := 'IT_PRICE,QUANTITY) values (1513,1,36,49.12,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDE';
wwv_flow_imp.g_varchar2_table(856) := 'R_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1513,2,5,43.71,1);'||wwv_flow.LF||
'        Insert into EBA';
wwv_flow_imp.g_varchar2_table(857) := '_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1513,3,44,39';
wwv_flow_imp.g_varchar2_table(858) := '.32,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE';
wwv_flow_imp.g_varchar2_table(859) := ',QUANTITY) values (1520,1,13,12.64,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LIN';
wwv_flow_imp.g_varchar2_table(860) := 'E_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1520,2,46,27.64,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_S';
wwv_flow_imp.g_varchar2_table(861) := 'EARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1520,3,33,37,1);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(862) := '      Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY)';
wwv_flow_imp.g_varchar2_table(863) := ' values (1525,1,40,34.06,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,';
wwv_flow_imp.g_varchar2_table(864) := 'PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1525,2,17,39.89,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDE';
wwv_flow_imp.g_varchar2_table(865) := 'R_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1543,1,21,38.34,1);'||wwv_flow.LF||
'        I';
wwv_flow_imp.g_varchar2_table(866) := 'nsert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values';
wwv_flow_imp.g_varchar2_table(867) := ' (1543,2,26,48.75,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT';
wwv_flow_imp.g_varchar2_table(868) := '_ID,UNIT_PRICE,QUANTITY) values (1543,3,11,30.69,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS';
wwv_flow_imp.g_varchar2_table(869) := ' (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1549,1,14,26.14,2);'||wwv_flow.LF||
'        Insert i';
wwv_flow_imp.g_varchar2_table(870) := 'nto EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1549,';
wwv_flow_imp.g_varchar2_table(871) := '2,43,16.64,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNI';
wwv_flow_imp.g_varchar2_table(872) := 'T_PRICE,QUANTITY) values (1552,1,34,23.32,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER';
wwv_flow_imp.g_varchar2_table(873) := '_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1555,1,17,39.89,2);'||wwv_flow.LF||
'        Insert into EBA';
wwv_flow_imp.g_varchar2_table(874) := '_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1555,2,34,23';
wwv_flow_imp.g_varchar2_table(875) := '.32,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE';
wwv_flow_imp.g_varchar2_table(876) := ',QUANTITY) values (1560,1,8,19.58,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE';
wwv_flow_imp.g_varchar2_table(877) := '_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1560,2,21,38.34,1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SE';
wwv_flow_imp.g_varchar2_table(878) := 'ARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1561,1,43,16.64,1);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(879) := '        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTIT';
wwv_flow_imp.g_varchar2_table(880) := 'Y) values (1561,2,7,19.16,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID';
wwv_flow_imp.g_varchar2_table(881) := ',PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1635,1,15,13.97,1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORD';
wwv_flow_imp.g_varchar2_table(882) := 'ER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1635,2,4,44.17,4);'||wwv_flow.LF||
'        I';
wwv_flow_imp.g_varchar2_table(883) := 'nsert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values';
wwv_flow_imp.g_varchar2_table(884) := ' (1635,3,36,49.12,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT';
wwv_flow_imp.g_varchar2_table(885) := '_ID,UNIT_PRICE,QUANTITY) values (1637,1,25,9.8,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (';
wwv_flow_imp.g_varchar2_table(886) := 'ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1659,1,14,26.14,3);'||wwv_flow.LF||
'        Insert int';
wwv_flow_imp.g_varchar2_table(887) := 'o EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1730,1,';
wwv_flow_imp.g_varchar2_table(888) := '20,28.21,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_';
wwv_flow_imp.g_varchar2_table(889) := 'PRICE,QUANTITY) values (1730,2,11,30.69,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_I';
wwv_flow_imp.g_varchar2_table(890) := 'D,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1731,1,39,11,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO';
wwv_flow_imp.g_varchar2_table(891) := '_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1731,2,21,38.34,3';
wwv_flow_imp.g_varchar2_table(892) := ');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUAN';
wwv_flow_imp.g_varchar2_table(893) := 'TITY) values (1776,1,34,23.32,1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITE';
wwv_flow_imp.g_varchar2_table(894) := 'M_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1776,2,25,9.8,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_O';
wwv_flow_imp.g_varchar2_table(895) := 'RDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1776,3,20,28.21,2);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(896) := '  Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) val';
wwv_flow_imp.g_varchar2_table(897) := 'ues (1808,1,14,26.14,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PROD';
wwv_flow_imp.g_varchar2_table(898) := 'UCT_ID,UNIT_PRICE,QUANTITY) values (1817,1,34,23.32,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_IT';
wwv_flow_imp.g_varchar2_table(899) := 'EMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1817,2,42,10.11,4);'||wwv_flow.LF||
'        Inser';
wwv_flow_imp.g_varchar2_table(900) := 't into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (18';
wwv_flow_imp.g_varchar2_table(901) := '17,3,22,39.78,1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,';
wwv_flow_imp.g_varchar2_table(902) := 'UNIT_PRICE,QUANTITY) values (1890,1,2,29.55,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORD';
wwv_flow_imp.g_varchar2_table(903) := 'ER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1890,2,46,39.16,3);'||wwv_flow.LF||
'        Insert into E';
wwv_flow_imp.g_varchar2_table(904) := 'BA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (832,1,10,2';
wwv_flow_imp.g_varchar2_table(905) := '9.49,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRIC';
wwv_flow_imp.g_varchar2_table(906) := 'E,QUANTITY) values (832,2,9,21.16,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE';
wwv_flow_imp.g_varchar2_table(907) := '_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (839,1,38,22.98,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEA';
wwv_flow_imp.g_varchar2_table(908) := 'RCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (839,2,7,19.16,5);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(909) := '     Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) ';
wwv_flow_imp.g_varchar2_table(910) := 'values (862,1,23,10.33,1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PR';
wwv_flow_imp.g_varchar2_table(911) := 'ODUCT_ID,UNIT_PRICE,QUANTITY) values (862,2,33,37,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEM';
wwv_flow_imp.g_varchar2_table(912) := 'S (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (899,1,31,28.59,2);'||wwv_flow.LF||
'        Insert i';
wwv_flow_imp.g_varchar2_table(913) := 'nto EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (920,1';
wwv_flow_imp.g_varchar2_table(914) := ',41,8.66,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_';
wwv_flow_imp.g_varchar2_table(915) := 'PRICE,QUANTITY) values (920,2,4,44.17,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,';
wwv_flow_imp.g_varchar2_table(916) := 'LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (928,1,3,16.67,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_';
wwv_flow_imp.g_varchar2_table(917) := 'SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (928,2,12,10.48,4);';
wwv_flow_imp.g_varchar2_table(918) := ''||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTI';
wwv_flow_imp.g_varchar2_table(919) := 'TY) values (928,3,35,7.18,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID';
wwv_flow_imp.g_varchar2_table(920) := ',PRODUCT_ID,UNIT_PRICE,QUANTITY) values (943,1,6,38.28,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER';
wwv_flow_imp.g_varchar2_table(921) := '_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (950,1,22,39.78,3);'||wwv_flow.LF||
'        Ins';
wwv_flow_imp.g_varchar2_table(922) := 'ert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (';
wwv_flow_imp.g_varchar2_table(923) := '950,2,23,10.33,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID';
wwv_flow_imp.g_varchar2_table(924) := ',UNIT_PRICE,QUANTITY) values (960,1,26,48.75,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (OR';
wwv_flow_imp.g_varchar2_table(925) := 'DER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (960,2,43,16.64,3);'||wwv_flow.LF||
'        Insert into E';
wwv_flow_imp.g_varchar2_table(926) := 'BA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (960,3,24,4';
wwv_flow_imp.g_varchar2_table(927) := '8.39,1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRIC';
wwv_flow_imp.g_varchar2_table(928) := 'E,QUANTITY) values (968,1,30,37.34,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LIN';
wwv_flow_imp.g_varchar2_table(929) := 'E_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (968,2,13,12.64,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SE';
wwv_flow_imp.g_varchar2_table(930) := 'ARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (968,3,35,7.18,3);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(931) := '      Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY)';
wwv_flow_imp.g_varchar2_table(932) := ' values (972,1,27,39.91,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,P';
wwv_flow_imp.g_varchar2_table(933) := 'RODUCT_ID,UNIT_PRICE,QUANTITY) values (972,2,23,10.33,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_';
wwv_flow_imp.g_varchar2_table(934) := 'ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (986,1,12,10.48,3);'||wwv_flow.LF||
'        Inse';
wwv_flow_imp.g_varchar2_table(935) := 'rt into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (9';
wwv_flow_imp.g_varchar2_table(936) := '86,2,14,26.14,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,';
wwv_flow_imp.g_varchar2_table(937) := 'UNIT_PRICE,QUANTITY) values (993,1,35,7.18,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDE';
wwv_flow_imp.g_varchar2_table(938) := 'R_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (993,2,14,26.14,4);'||wwv_flow.LF||
'        Insert into EBA';
wwv_flow_imp.g_varchar2_table(939) := '_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (993,3,19,14.';
wwv_flow_imp.g_varchar2_table(940) := '34,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,';
wwv_flow_imp.g_varchar2_table(941) := 'QUANTITY) values (1052,1,36,49.12,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE';
wwv_flow_imp.g_varchar2_table(942) := '_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1052,2,33,37,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARC';
wwv_flow_imp.g_varchar2_table(943) := 'H_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1052,3,44,39.32,4);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(944) := '     Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) ';
wwv_flow_imp.g_varchar2_table(945) := 'values (1058,1,16,13.09,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,P';
wwv_flow_imp.g_varchar2_table(946) := 'RODUCT_ID,UNIT_PRICE,QUANTITY) values (1058,2,34,23.32,1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER';
wwv_flow_imp.g_varchar2_table(947) := '_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1058,3,2,29.55,1);'||wwv_flow.LF||
'        Ins';
wwv_flow_imp.g_varchar2_table(948) := 'ert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (';
wwv_flow_imp.g_varchar2_table(949) := '1082,1,22,39.78,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_I';
wwv_flow_imp.g_varchar2_table(950) := 'D,UNIT_PRICE,QUANTITY) values (1082,2,20,28.21,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (';
wwv_flow_imp.g_varchar2_table(951) := 'ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1102,1,10,29.49,3);'||wwv_flow.LF||
'        Insert int';
wwv_flow_imp.g_varchar2_table(952) := 'o EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1102,2,';
wwv_flow_imp.g_varchar2_table(953) := '39,11,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRI';
wwv_flow_imp.g_varchar2_table(954) := 'CE,QUANTITY) values (1102,3,14,26.14,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,L';
wwv_flow_imp.g_varchar2_table(955) := 'INE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1111,1,41,8.66,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_';
wwv_flow_imp.g_varchar2_table(956) := 'SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1111,2,13,12.64,1)';
wwv_flow_imp.g_varchar2_table(957) := ';'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANT';
wwv_flow_imp.g_varchar2_table(958) := 'ITY) values (1119,1,25,9.8,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_I';
wwv_flow_imp.g_varchar2_table(959) := 'D,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1119,2,9,21.16,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORD';
wwv_flow_imp.g_varchar2_table(960) := 'ER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1119,3,45,31.68,2);'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(961) := 'Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) value';
wwv_flow_imp.g_varchar2_table(962) := 's (1121,1,27,39.91,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUC';
wwv_flow_imp.g_varchar2_table(963) := 'T_ID,UNIT_PRICE,QUANTITY) values (1169,1,9,21.16,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS';
wwv_flow_imp.g_varchar2_table(964) := ' (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1169,2,22,39.78,5);'||wwv_flow.LF||
'        Insert i';
wwv_flow_imp.g_varchar2_table(965) := 'nto EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1191,';
wwv_flow_imp.g_varchar2_table(966) := '1,33,37,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_P';
wwv_flow_imp.g_varchar2_table(967) := 'RICE,QUANTITY) values (1191,2,40,34.06,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID';
wwv_flow_imp.g_varchar2_table(968) := ',LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1191,3,14,26.14,3);'||wwv_flow.LF||
'        Insert into EBA_DE';
wwv_flow_imp.g_varchar2_table(969) := 'MO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1195,1,13,12.64';
wwv_flow_imp.g_varchar2_table(970) := ',1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QU';
wwv_flow_imp.g_varchar2_table(971) := 'ANTITY) values (1200,1,19,14.34,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_I';
wwv_flow_imp.g_varchar2_table(972) := 'TEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1200,2,27,39.91,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEAR';
wwv_flow_imp.g_varchar2_table(973) := 'CH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1200,3,7,19.16,4);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(974) := '     Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) ';
wwv_flow_imp.g_varchar2_table(975) := 'values (1260,1,30,37.34,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,P';
wwv_flow_imp.g_varchar2_table(976) := 'RODUCT_ID,UNIT_PRICE,QUANTITY) values (1260,2,5,43.71,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_';
wwv_flow_imp.g_varchar2_table(977) := 'ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1321,1,43,16.64,2);'||wwv_flow.LF||
'        Ins';
wwv_flow_imp.g_varchar2_table(978) := 'ert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (';
wwv_flow_imp.g_varchar2_table(979) := '1321,2,37,29.51,1);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_I';
wwv_flow_imp.g_varchar2_table(980) := 'D,UNIT_PRICE,QUANTITY) values (1321,3,46,39.16,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (';
wwv_flow_imp.g_varchar2_table(981) := 'ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1348,1,31,28.59,2);'||wwv_flow.LF||
'        Insert int';
wwv_flow_imp.g_varchar2_table(982) := 'o EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1348,2,';
wwv_flow_imp.g_varchar2_table(983) := '23,10.33,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_';
wwv_flow_imp.g_varchar2_table(984) := 'PRICE,QUANTITY) values (1348,3,3,16.67,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID';
wwv_flow_imp.g_varchar2_table(985) := ',LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1363,1,11,30.69,4);'||wwv_flow.LF||
'        Insert into EBA_DE';
wwv_flow_imp.g_varchar2_table(986) := 'MO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1363,2,14,26.14';
wwv_flow_imp.g_varchar2_table(987) := ',2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QU';
wwv_flow_imp.g_varchar2_table(988) := 'ANTITY) values (1373,1,17,39.89,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_I';
wwv_flow_imp.g_varchar2_table(989) := 'TEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1373,2,29,24.71,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEAR';
wwv_flow_imp.g_varchar2_table(990) := 'CH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1390,1,12,10.48,2);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(991) := '      Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY)';
wwv_flow_imp.g_varchar2_table(992) := ' values (1390,2,28,10.24,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,';
wwv_flow_imp.g_varchar2_table(993) := 'PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1390,3,9,21.16,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER';
wwv_flow_imp.g_varchar2_table(994) := '_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1400,1,11,30.69,5);'||wwv_flow.LF||
'        In';
wwv_flow_imp.g_varchar2_table(995) := 'sert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values ';
wwv_flow_imp.g_varchar2_table(996) := '(1400,2,6,38.28,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_I';
wwv_flow_imp.g_varchar2_table(997) := 'D,UNIT_PRICE,QUANTITY) values (1418,1,31,28.59,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (';
wwv_flow_imp.g_varchar2_table(998) := 'ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1418,2,45,31.68,3);'||wwv_flow.LF||
'        Insert int';
wwv_flow_imp.g_varchar2_table(999) := 'o EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1437,1,';
wwv_flow_imp.g_varchar2_table(1000) := '3,16.67,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_P';
wwv_flow_imp.g_varchar2_table(1001) := 'RICE,QUANTITY) values (1439,1,46,27.64,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID';
wwv_flow_imp.g_varchar2_table(1002) := ',LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1439,2,9,21.16,3);'||wwv_flow.LF||
'        Insert into EBA_DEM';
wwv_flow_imp.g_varchar2_table(1003) := 'O_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1448,1,2,29.55,2';
wwv_flow_imp.g_varchar2_table(1004) := ');'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUAN';
wwv_flow_imp.g_varchar2_table(1005) := 'TITY) values (1450,1,4,44.17,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM';
wwv_flow_imp.g_varchar2_table(1006) := '_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1451,1,10,29.49,5);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_';
wwv_flow_imp.g_varchar2_table(1007) := 'ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1451,2,35,7.18,4);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(1008) := '  Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) val';
wwv_flow_imp.g_varchar2_table(1009) := 'ues (1455,1,45,31.68,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PROD';
wwv_flow_imp.g_varchar2_table(1010) := 'UCT_ID,UNIT_PRICE,QUANTITY) values (1455,2,23,10.33,3);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_IT';
wwv_flow_imp.g_varchar2_table(1011) := 'EMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1468,1,2,29.55,3);'||wwv_flow.LF||
'        Insert';
wwv_flow_imp.g_varchar2_table(1012) := ' into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (146';
wwv_flow_imp.g_varchar2_table(1013) := '8,2,45,31.68,4);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORDER_ID,LINE_ITEM_ID,PRODUCT_ID,U';
wwv_flow_imp.g_varchar2_table(1014) := 'NIT_PRICE,QUANTITY) values (1471,1,14,26.14,2);'||wwv_flow.LF||
'        Insert into EBA_DEMO_SEARCH_ORDER_ITEMS (ORD';
wwv_flow_imp.g_varchar2_table(1015) := 'ER_ID,LINE_ITEM_ID,PRODUCT_ID,UNIT_PRICE,QUANTITY) values (1471,2,6,38.28,3);'||wwv_flow.LF||
'        '||wwv_flow.LF||
'        commi';
wwv_flow_imp.g_varchar2_table(1016) := 't;'||wwv_flow.LF||
'    end load_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure load_product_images(p_app_id in number, p_file_name in varchar2';
wwv_flow_imp.g_varchar2_table(1017) := ') is'||wwv_flow.LF||
'        l_zip_file      blob;'||wwv_flow.LF||
'        l_files         apex_zip.t_files;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        selec';
wwv_flow_imp.g_varchar2_table(1018) := 't file_content'||wwv_flow.LF||
'        into l_zip_file'||wwv_flow.LF||
'        from APEX_APPLICATION_STATIC_FILES'||wwv_flow.LF||
'        where appl';
wwv_flow_imp.g_varchar2_table(1019) := 'ication_id = p_app_id and file_name = p_file_name;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        l_files := APEX_ZIP.get_files ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(1020) := '            p_zipped_blob => l_zip_file );'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        for i in 1 .. l_files.count loop'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(1021) := ' update eba_demo_search_products'||wwv_flow.LF||
'            set product_image = APEX_ZIP.get_file_content ('||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(1022) := '         p_zipped_blob => l_zip_file,'||wwv_flow.LF||
'                p_file_name   => l_files(i) )'||wwv_flow.LF||
'            wher';
wwv_flow_imp.g_varchar2_table(1023) := 'e product_id = substr(l_files(i),0,instr(l_files(i),''.''));'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'    end';
wwv_flow_imp.g_varchar2_table(1024) := ' load_product_images;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure reset_data is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        clear_data;'||wwv_flow.LF||
'        load_data;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1025) := '    end reset_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_demo_search_data_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_demo_search_data_pkg.reset_data;';
wwv_flow_imp.g_varchar2_table(1026) := ''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(4124165587129573207)
,p_install_id=>wwv_flow_imp.id(4926791174312313587)
,p_name=>'data'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
