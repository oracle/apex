prompt --application/deployment/install/install_install
begin
--   Manifest
--     INSTALL: INSTALL-install
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '----------------------------------------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '---'||wwv_flow.LF||
'-- Install Sample Dataset'||wwv_flow.LF||
'----------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(3) := '---------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Create tables'||wwv_flow.LF||
'CREATE TABLE  "EBA_DEMO_SEARCH_CUSTOMERS"   '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := '(	"CUSTOMER_ID" NUMBER DEFAULT ON NULL to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''),   ';
wwv_flow_imp.g_varchar2_table(5) := ''||wwv_flow.LF||
'	"FULL_NAME" VARCHAR2(255) NOT NULL ENABLE,   '||wwv_flow.LF||
'	"EMAIL_ADDRESS" VARCHAR2(255) NOT NULL ENABLE,   '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(6) := ' CONSTRAINT "EBA_DEMO_SEARCH_CUSTOMERS_PK" PRIMARY KEY ("CUSTOMER_ID")  '||wwv_flow.LF||
'  USING INDEX  ENABLE,   '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(7) := ' CONSTRAINT "EBA_DEMO_SEARCH_CUST_EMAIL_U" UNIQUE ("EMAIL_ADDRESS")  '||wwv_flow.LF||
'  USING INDEX  ENABLE  '||wwv_flow.LF||
'   )  ';
wwv_flow_imp.g_varchar2_table(8) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE TABLE  "EBA_DEMO_SEARCH_STORES"    '||wwv_flow.LF||
'   (	"STORE_ID" NUMBER DEFAULT ON NULL to_number(sys_';
wwv_flow_imp.g_varchar2_table(9) := 'guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''),   '||wwv_flow.LF||
'	"STORE_NAME" VARCHAR2(255) NOT NULL ENABLE,   '||wwv_flow.LF||
'	"WE';
wwv_flow_imp.g_varchar2_table(10) := 'B_ADDRESS" VARCHAR2(100),   '||wwv_flow.LF||
'	"PHYSICAL_ADDRESS" VARCHAR2(512),   '||wwv_flow.LF||
'	"LATITUDE" NUMBER,   '||wwv_flow.LF||
'	"LONGITUD';
wwv_flow_imp.g_varchar2_table(11) := 'E" NUMBER,   '||wwv_flow.LF||
'	"LOGO" BLOB,   '||wwv_flow.LF||
'	"LOGO_MIME_TYPE" VARCHAR2(512),   '||wwv_flow.LF||
'	"LOGO_FILENAME" VARCHAR2(512),  ';
wwv_flow_imp.g_varchar2_table(12) := ' '||wwv_flow.LF||
'	"LOGO_CHARSET" VARCHAR2(512),   '||wwv_flow.LF||
'	"LOGO_LAST_UPDATED" DATE,    '||wwv_flow.LF||
'	 CONSTRAINT "EBA_DEMO_SEARCH_STO';
wwv_flow_imp.g_varchar2_table(13) := 'RES_PK" PRIMARY KEY ("STORE_ID")  '||wwv_flow.LF||
'  USING INDEX  ENABLE,   '||wwv_flow.LF||
'	 CONSTRAINT "EBA_DEMO_SEARCH_STORE_NAM';
wwv_flow_imp.g_varchar2_table(14) := 'E_U" UNIQUE ("STORE_NAME")  '||wwv_flow.LF||
'  USING INDEX  ENABLE,   '||wwv_flow.LF||
'	 CONSTRAINT "EBA_DEMO_SEARCH_REQUIRED_ADR_C"';
wwv_flow_imp.g_varchar2_table(15) := ' CHECK (coalesce ( web_address, physical_address ) is not null) ENABLE  '||wwv_flow.LF||
'   )  '||wwv_flow.LF||
'/ '||wwv_flow.LF||
''||wwv_flow.LF||
' CREATE  TABLE  ';
wwv_flow_imp.g_varchar2_table(16) := '"EBA_DEMO_SEARCH_ORDERS"'||wwv_flow.LF||
'    (   "ORDER_ID" NUMBER DEFAULT ON NULL to_number(sys_guid(), ''XXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(17) := 'XXXXXXXXXXXXXXXXXXXXXX''),  '||wwv_flow.LF||
'	"ORDER_DATETIME" TIMESTAMP (6) NOT NULL ENABLE,  '||wwv_flow.LF||
'	"CUSTOMER_ID" NUMBER';
wwv_flow_imp.g_varchar2_table(18) := ' NOT NULL ENABLE,  '||wwv_flow.LF||
'	"ORDER_STATUS" VARCHAR2(10) NOT NULL ENABLE,  '||wwv_flow.LF||
'	"STORE_ID" NUMBER NOT NULL ENAB';
wwv_flow_imp.g_varchar2_table(19) := 'LE,'||wwv_flow.LF||
'	 CONSTRAINT "EBA_DEMO_SEARCH_ORDERS_PK" PRIMARY KEY ("ORDER_ID")  '||wwv_flow.LF||
'  USING INDEX  ENABLE,'||wwv_flow.LF||
'	 CON';
wwv_flow_imp.g_varchar2_table(20) := 'STRAINT "EBA_DEMO_SEARCH_ORDER_STATUS_C" CHECK (order_status in (''CANCELLED'',''COMPLETE'',''OPEN'',''PAID';
wwv_flow_imp.g_varchar2_table(21) := ''',''REFUNDED'',''SHIPPED'')) ENABLE'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE TABLE  "EBA_DEMO_SEARCH_PRODUCTS" '||wwv_flow.LF||
'   (	"PRODUCT_ID"';
wwv_flow_imp.g_varchar2_table(22) := ' NUMBER DEFAULT ON NULL to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''), '||wwv_flow.LF||
'	"PRODUCT_NAME" ';
wwv_flow_imp.g_varchar2_table(23) := 'VARCHAR2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'	"UNIT_PRICE" NUMBER(10,2), '||wwv_flow.LF||
'	"PRODUCT_DETAILS" BLOB, '||wwv_flow.LF||
'	"PRODUCT_IMA';
wwv_flow_imp.g_varchar2_table(24) := 'GE" BLOB, '||wwv_flow.LF||
'	"IMAGE_MIME_TYPE" VARCHAR2(512), '||wwv_flow.LF||
'	"IMAGE_FILENAME" VARCHAR2(512), '||wwv_flow.LF||
'	"IMAGE_CHARSET" VAR';
wwv_flow_imp.g_varchar2_table(25) := 'CHAR2(512), '||wwv_flow.LF||
'	"IMAGE_LAST_UPDATED" DATE,'||wwv_flow.LF||
'    "TEXT_INDEX_COLUMN" VARCHAR2(255),'||wwv_flow.LF||
'	 CONSTRAINT "EBA_DE';
wwv_flow_imp.g_varchar2_table(26) := 'MO_SEARCH_PRODUCTS_PK" PRIMARY KEY ("PRODUCT_ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_DEMO_SEA';
wwv_flow_imp.g_varchar2_table(27) := 'RCH_PRODUCT_JSON_C" CHECK (product_details is json) ENABLE'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE TABLE  "EBA_DEMO_SEARCH_OR';
wwv_flow_imp.g_varchar2_table(28) := 'DER_ITEMS"   '||wwv_flow.LF||
'   (	"ORDER_ID" NUMBER NOT NULL ENABLE,   '||wwv_flow.LF||
'	"LINE_ITEM_ID" NUMBER NOT NULL ENABLE,   '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(29) := '	"PRODUCT_ID" NUMBER NOT NULL ENABLE,   '||wwv_flow.LF||
'	"UNIT_PRICE" NUMBER(10,2) NOT NULL ENABLE,   '||wwv_flow.LF||
'	"QUANTITY" ';
wwv_flow_imp.g_varchar2_table(30) := 'NUMBER NOT NULL ENABLE,    '||wwv_flow.LF||
'	 CONSTRAINT "EBA_DEMO_SEARCH_ORDER_ITEMS_PK" PRIMARY KEY ("ORDER_ID", "';
wwv_flow_imp.g_varchar2_table(31) := 'LINE_ITEM_ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE,   '||wwv_flow.LF||
'	 CONSTRAINT "EBA_DEMO_SEARCH_ORD_ITEM_PRD_U" UNIQUE ("PROD';
wwv_flow_imp.g_varchar2_table(32) := 'UCT_ID", "ORDER_ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE  '||wwv_flow.LF||
'   )  '||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Add foreign key constraints'||wwv_flow.LF||
'ALTER TABLE  ';
wwv_flow_imp.g_varchar2_table(33) := '"EBA_DEMO_SEARCH_ORDERS" ADD CONSTRAINT "EBA_DEMO_SEARCH_ORD_CUST_ID_FK" FOREIGN KEY ("CUSTOMER_ID")';
wwv_flow_imp.g_varchar2_table(34) := '  '||wwv_flow.LF||
'	  REFERENCES  "EBA_DEMO_SEARCH_CUSTOMERS" ("CUSTOMER_ID") ON DELETE CASCADE ENABLE  '||wwv_flow.LF||
'/  '||wwv_flow.LF||
'ALTER T';
wwv_flow_imp.g_varchar2_table(35) := 'ABLE  "EBA_DEMO_SEARCH_ORDERS" ADD CONSTRAINT "EBA_DEMO_SEARCH_ORD_STR_ID_FK" FOREIGN KEY ("STORE_ID';
wwv_flow_imp.g_varchar2_table(36) := '")  '||wwv_flow.LF||
'	  REFERENCES  "EBA_DEMO_SEARCH_STORES" ("STORE_ID") ON DELETE CASCADE ENABLE  '||wwv_flow.LF||
'/  '||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABL';
wwv_flow_imp.g_varchar2_table(37) := 'E  "EBA_DEMO_SEARCH_ORDER_ITEMS" ADD CONSTRAINT "EBA_DEMO_SEARCH_ITEM_ORD_ID_FK" FOREIGN KEY ("ORDER';
wwv_flow_imp.g_varchar2_table(38) := '_ID")  '||wwv_flow.LF||
'	  REFERENCES  "EBA_DEMO_SEARCH_ORDERS" ("ORDER_ID") ON DELETE CASCADE ENABLE  '||wwv_flow.LF||
'/  '||wwv_flow.LF||
'ALTER TA';
wwv_flow_imp.g_varchar2_table(39) := 'BLE  "EBA_DEMO_SEARCH_ORDER_ITEMS" ADD CONSTRAINT "EBA_DEMO_SEARCH_ITEM_PRD_ID_FK" FOREIGN KEY ("PRO';
wwv_flow_imp.g_varchar2_table(40) := 'DUCT_ID")  '||wwv_flow.LF||
'	  REFERENCES  "EBA_DEMO_SEARCH_PRODUCTS" ("PRODUCT_ID") ON DELETE CASCADE ENABLE  '||wwv_flow.LF||
'/  '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(41) := ''||wwv_flow.LF||
'-- Create indexes'||wwv_flow.LF||
'CREATE INDEX  "EBA_DEMO_SEARCH_CUST_NAME_I" ON  "EBA_DEMO_SEARCH_CUSTOMERS" ("FUL';
wwv_flow_imp.g_varchar2_table(42) := 'L_NAME")  '||wwv_flow.LF||
'/'||wwv_flow.LF||
'CREATE INDEX  "EBA_DEMO_SEARCH_ORD_CUST_ID_I" ON  "EBA_DEMO_SEARCH_ORDERS" ("CUSTOMER_I';
wwv_flow_imp.g_varchar2_table(43) := 'D")  '||wwv_flow.LF||
'/  '||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX  "EBA_DEMO_SEARCH_ORD_STR_ID_I" ON  "EBA_DEMO_SEARCH_ORDERS" ("STORE_ID")  '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(44) := '/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Create views'||wwv_flow.LF||
'-- Create view to show order details along with customer and product info'||wwv_flow.LF||
'CREATE ';
wwv_flow_imp.g_varchar2_table(45) := 'OR REPLACE FORCE EDITIONABLE VIEW  "EBA_DEMO_SEARCH_CUST_ORD_PRD" ("ORDER_ID", "ORDER_STATUS", "ORDE';
wwv_flow_imp.g_varchar2_table(46) := 'R_DATETIME", "CUSTOMER_ID",  '||wwv_flow.LF||
'"EMAIL_ADDRESS", "FULL_NAME", "ORDER_TOTAL", "ITEMS") AS  '||wwv_flow.LF||
'select o.or';
wwv_flow_imp.g_varchar2_table(47) := 'der_id,'||wwv_flow.LF||
'      o.order_status,'||wwv_flow.LF||
'      o.order_datetime,'||wwv_flow.LF||
'      c.customer_id,'||wwv_flow.LF||
'      c.email_address,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(48) := '    c.full_name,'||wwv_flow.LF||
'      sum ( oi.quantity * oi.unit_price ) order_total,'||wwv_flow.LF||
'      listagg (p.product_nam';
wwv_flow_imp.g_varchar2_table(49) := 'e, '', '' on overflow truncate ''...'' with count)   '||wwv_flow.LF||
'         within group ( order by oi.line_item_id )';
wwv_flow_imp.g_varchar2_table(50) := ' items  '||wwv_flow.LF||
'from eba_demo_search_orders o  '||wwv_flow.LF||
'join eba_demo_search_order_items oi '||wwv_flow.LF||
'  on o.order_id = oi.o';
wwv_flow_imp.g_varchar2_table(51) := 'rder_id  '||wwv_flow.LF||
'join eba_demo_search_customers c'||wwv_flow.LF||
'  on o.customer_id = c.customer_id  '||wwv_flow.LF||
'join eba_demo_search';
wwv_flow_imp.g_varchar2_table(52) := '_products p'||wwv_flow.LF||
'  on oi.product_id = p.product_id'||wwv_flow.LF||
'group by o.order_id,'||wwv_flow.LF||
'        o.order_datetime,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(53) := ' o.order_status,'||wwv_flow.LF||
'        c.customer_id,'||wwv_flow.LF||
'        c.email_address,'||wwv_flow.LF||
'        c.full_name'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Create vi';
wwv_flow_imp.g_varchar2_table(54) := 'ew to show product order details '||wwv_flow.LF||
'CREATE OR REPLACE FORCE EDITIONABLE VIEW  "EBA_DEMO_SEARCH_PRD_ORD';
wwv_flow_imp.g_varchar2_table(55) := 'ERS" ("PRODUCT_NAME", "ORDER_STATUS", "TOTAL_SALES", "ORDER_COUNT") AS  '||wwv_flow.LF||
''||wwv_flow.LF||
' select p.product_name,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(56) := '     o.order_status,'||wwv_flow.LF||
'       sum ( oi.quantity * oi.unit_price ) total_sales,'||wwv_flow.LF||
'       count (*) order_';
wwv_flow_imp.g_varchar2_table(57) := 'count '||wwv_flow.LF||
'from eba_demo_search_orders o  '||wwv_flow.LF||
'join eba_demo_search_order_items oi '||wwv_flow.LF||
'  on o.order_id = oi.ord';
wwv_flow_imp.g_varchar2_table(58) := 'er_id  '||wwv_flow.LF||
'join eba_demo_search_customers c'||wwv_flow.LF||
'  on o.customer_id = c.customer_id  '||wwv_flow.LF||
'join eba_demo_search_p';
wwv_flow_imp.g_varchar2_table(59) := 'roducts p'||wwv_flow.LF||
'  on oi.product_id = p.product_id'||wwv_flow.LF||
'group by p.product_name  '||wwv_flow.LF||
',        o.order_status'||wwv_flow.LF||
'/  '||wwv_flow.LF||
''||wwv_flow.LF||
'-';
wwv_flow_imp.g_varchar2_table(60) := '- Create view to show product review details'||wwv_flow.LF||
'CREATE OR REPLACE FORCE EDITIONABLE VIEW  "EBA_DEMO_SEA';
wwv_flow_imp.g_varchar2_table(61) := 'RCH_PRD_REVIEWS" ("PRODUCT_NAME", "RATING", "AVG_RATING", "REVIEW") AS  '||wwv_flow.LF||
''||wwv_flow.LF||
' select p.product_name,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(62) := '     r.rating,'||wwv_flow.LF||
'       round (avg (r.rating) over (partition by product_name), 2) avg_rating,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(63) := 'r.review'||wwv_flow.LF||
'from eba_demo_search_products p,'||wwv_flow.LF||
'    json_table  '||wwv_flow.LF||
'       (p.product_details, ''$.reviews[*]''';
wwv_flow_imp.g_varchar2_table(64) := '  '||wwv_flow.LF||
'        columns ('||wwv_flow.LF||
'            rating number path ''$.rating'','||wwv_flow.LF||
'            review varchar2(4000) pa';
wwv_flow_imp.g_varchar2_table(65) := 'th ''$.review'')  '||wwv_flow.LF||
'       ) r'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Create view to show order details grouped by store'||wwv_flow.LF||
'CREATE OR REPLA';
wwv_flow_imp.g_varchar2_table(66) := 'CE FORCE EDITIONABLE VIEW  "EBA_DEMO_SEARCH_STR_ORDERS" ("TOTAL", "STORE_NAME", "ADDRESS", "LATITUDE';
wwv_flow_imp.g_varchar2_table(67) := '", "LONGITUDE", "ORDER_STATUS", "ORDER_COUNT", "TOTAL_SALES") AS   '||wwv_flow.LF||
''||wwv_flow.LF||
' select case  '||wwv_flow.LF||
'         groupin';
wwv_flow_imp.g_varchar2_table(68) := 'g_id ( store_name, order_status )  '||wwv_flow.LF||
'           when 1 then ''STORE TOTAL''  '||wwv_flow.LF||
'           when 2 then ''S';
wwv_flow_imp.g_varchar2_table(69) := 'TATUS TOTAL''  '||wwv_flow.LF||
'           when 3 then ''GRAND TOTAL''  '||wwv_flow.LF||
'       end total,'||wwv_flow.LF||
'	         s.store_name,'||wwv_flow.LF||
'	   ';
wwv_flow_imp.g_varchar2_table(70) := '      coalesce ( s.web_address, s.physical_address ) address,'||wwv_flow.LF||
'	         s.latitude,'||wwv_flow.LF||
'	         s.long';
wwv_flow_imp.g_varchar2_table(71) := 'itude,'||wwv_flow.LF||
'	         o.order_status,'||wwv_flow.LF||
'	         count ( distinct o.order_id ) order_count,'||wwv_flow.LF||
'	         sum ';
wwv_flow_imp.g_varchar2_table(72) := '( oi.quantity * oi.unit_price ) total_sales  '||wwv_flow.LF||
'from eba_demo_search_stores s  '||wwv_flow.LF||
'join eba_demo_search_o';
wwv_flow_imp.g_varchar2_table(73) := 'rders o '||wwv_flow.LF||
'  on s.store_id = o.store_id '||wwv_flow.LF||
'join eba_demo_search_order_items oi '||wwv_flow.LF||
'  on o.order_id = oi.ord';
wwv_flow_imp.g_varchar2_table(74) := 'er_id '||wwv_flow.LF||
'group by grouping sets (  (s.store_name, coalesce(s.web_address,s.physical_address), s.latitu';
wwv_flow_imp.g_varchar2_table(75) := 'de, s.longitude) ,'||wwv_flow.LF||
'							 (s.store_name, coalesce(s.web_address,s.physical_address), s.latitude, s.';
wwv_flow_imp.g_varchar2_table(76) := 'longitude, o.order_status),'||wwv_flow.LF||
'							  o.order_status ,'||wwv_flow.LF||
'							 ()  '||wwv_flow.LF||
'                       )'||wwv_flow.LF||
'/ '||wwv_flow.LF||
''||wwv_flow.LF||
'-- C';
wwv_flow_imp.g_varchar2_table(77) := 'reate view to show order details grouped by store and status'||wwv_flow.LF||
'CREATE OR REPLACE FORCE EDITIONABLE VIE';
wwv_flow_imp.g_varchar2_table(78) := 'W  "EBA_DEMO_SEARCH_STR_ORD_STAT" ("STORE_NAME", "ADDRESS", "LATITUDE", "LONGITUDE", "ORDER_STATUS",';
wwv_flow_imp.g_varchar2_table(79) := ' "ORDER_COUNT", "TOTAL_SALES") AS   '||wwv_flow.LF||
''||wwv_flow.LF||
' select s.store_name,'||wwv_flow.LF||
'        coalesce ( s.web_address, s.phys';
wwv_flow_imp.g_varchar2_table(80) := 'ical_address ) address,'||wwv_flow.LF||
'        s.latitude,'||wwv_flow.LF||
'        s.longitude,'||wwv_flow.LF||
'        o.order_status,'||wwv_flow.LF||
'        cou';
wwv_flow_imp.g_varchar2_table(81) := 'nt ( distinct o.order_id ) order_count,'||wwv_flow.LF||
'        sum ( oi.quantity * oi.unit_price ) total_sales '||wwv_flow.LF||
'fro';
wwv_flow_imp.g_varchar2_table(82) := 'm eba_demo_search_stores s'||wwv_flow.LF||
'join eba_demo_search_orders o '||wwv_flow.LF||
'  on s.store_id = o.store_id'||wwv_flow.LF||
'join eba_demo';
wwv_flow_imp.g_varchar2_table(83) := '_search_order_items oi '||wwv_flow.LF||
'  on o.order_id = oi.order_id'||wwv_flow.LF||
'group by  s.store_name, coalesce ( s.web_addre';
wwv_flow_imp.g_varchar2_table(84) := 'ss, s.physical_address ), s.latitude, s.longitude, o.order_status'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------------------';
wwv_flow_imp.g_varchar2_table(85) := '------------------------------------------------------------------------'||wwv_flow.LF||
'-- Application specific obj';
wwv_flow_imp.g_varchar2_table(86) := 'ects'||wwv_flow.LF||
'-----------------------------------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(87) := '--------'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Track Web Credetiels'||wwv_flow.LF||
'create table eba_demo_search_web_creds('||wwv_flow.LF||
'    credential_static_id v';
wwv_flow_imp.g_varchar2_table(88) := 'archar2(50) unique not null enable'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Sync Text Index '||wwv_flow.LF||
'create or replace trigger text_index_pen';
wwv_flow_imp.g_varchar2_table(89) := 'ding'||wwv_flow.LF||
'    before update on eba_demo_search_products'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    :new.text_index_column';
wwv_flow_imp.g_varchar2_table(90) := ' := nvl(to_number(:old.text_index_column)+1, ''0'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger text_index_pending enable;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(91) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Error handling function'||wwv_flow.LF||
'create or replace function eba_demo_search_error_handling( p_error in a';
wwv_flow_imp.g_varchar2_table(92) := 'pex_error.t_error )'||wwv_flow.LF||
'    return apex_error.t_error_result'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_result          apex_error.t_error';
wwv_flow_imp.g_varchar2_table(93) := '_result;'||wwv_flow.LF||
'    l_message varchar2(255);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_result := apex_error.init_error_result ('||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(94) := '           p_error => p_error );'||wwv_flow.LF||
'                    '||wwv_flow.LF||
'    l_message := APEX_ERROR.GET_FIRST_ORA_ERRO';
wwv_flow_imp.g_varchar2_table(95) := 'R_TEXT (p_error,false);'||wwv_flow.LF||
'    if p_error.ora_sqlcode = -20999 and l_message like ''%401%'' then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(96) := 'l_result.message := ''Incorrect credentials. Please navigate to "Manage Web Credentials" under "Admin';
wwv_flow_imp.g_varchar2_table(97) := 'istration" and provide a valid API Key.'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_result;'||wwv_flow.LF||
'end eba_demo_search_erro';
wwv_flow_imp.g_varchar2_table(98) := 'r_handling;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(4124165423114569274)
,p_install_id=>wwv_flow_imp.id(4926791174312313587)
,p_name=>'install'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
