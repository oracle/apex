prompt --application/deployment/install/install_oracle_text_helper_package_compiles_without_oracle_text
begin
--   Manifest
--     INSTALL: INSTALL-Oracle TEXT helper package (compiles without Oracle Text)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '----------------------------------------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '---'||wwv_flow.LF||
'-- Oracle TEXT helper package'||wwv_flow.LF||
'------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(3) := '-------------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package eba_demo_search_text_pkg authid cur';
wwv_flow_imp.g_varchar2_table(4) := 'rent_user is'||wwv_flow.LF||
'    function text_is_available return boolean;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    procedure products_ds_procedure';
wwv_flow_imp.g_varchar2_table(5) := '(p_rid  in  rowid,p_tlob in out nocopy varchar2);'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    procedure create_text_preferences;'||wwv_flow.LF||
'    pr';
wwv_flow_imp.g_varchar2_table(6) := 'ocedure drop_text_preferences;'||wwv_flow.LF||
'    procedure create_text_index;'||wwv_flow.LF||
'    procedure drop_text_index;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '    procedure init_oracle_text;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function convert_text_query( p_enduser_query in varchar2 ) retu';
wwv_flow_imp.g_varchar2_table(8) := 'rn varchar2;'||wwv_flow.LF||
'end eba_demo_search_text_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package body eba_demo_search_text_pk';
wwv_flow_imp.g_varchar2_table(9) := 'g is'||wwv_flow.LF||
'    procedure execute_sql('||wwv_flow.LF||
'        p_sql         in varchar2, '||wwv_flow.LF||
'        p_throw_error in boolean';
wwv_flow_imp.g_varchar2_table(10) := ' default true'||wwv_flow.LF||
'    ) is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        execute immediate p_sql;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'        when others ';
wwv_flow_imp.g_varchar2_table(11) := 'then '||wwv_flow.LF||
'            if p_throw_error then raise; end if;'||wwv_flow.LF||
'    end execute_sql;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    procedure produ';
wwv_flow_imp.g_varchar2_table(12) := 'cts_ds_procedure (p_rid  in  rowid,p_tlob in out nocopy varchar2) is'||wwv_flow.LF||
'        type t_product_details ';
wwv_flow_imp.g_varchar2_table(13) := 'is record ('||wwv_flow.LF||
'            product_id   number,'||wwv_flow.LF||
'            product_name varchar2(200),'||wwv_flow.LF||
'            col';
wwv_flow_imp.g_varchar2_table(14) := 'our       varchar2(200),'||wwv_flow.LF||
'            gender       varchar2(200),'||wwv_flow.LF||
'            brand        varchar2(2';
wwv_flow_imp.g_varchar2_table(15) := '00),'||wwv_flow.LF||
'            description  varchar2(2000)'||wwv_flow.LF||
'        );'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_product t_product_details;'||wwv_flow.LF||
'    be';
wwv_flow_imp.g_varchar2_table(16) := 'gin'||wwv_flow.LF||
'        select p.product_id,'||wwv_flow.LF||
'            p.product_name,'||wwv_flow.LF||
'            j.colour,'||wwv_flow.LF||
'            j.gen';
wwv_flow_imp.g_varchar2_table(17) := 'der,'||wwv_flow.LF||
'            j.brand,'||wwv_flow.LF||
'            j.description'||wwv_flow.LF||
'        into l_product'||wwv_flow.LF||
'        from eba_demo_sea';
wwv_flow_imp.g_varchar2_table(18) := 'rch_products p,'||wwv_flow.LF||
'            json_table(product_details, ''$'''||wwv_flow.LF||
'                columns ('||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(19) := '      colour      varchar2(200) path ''$.colour'','||wwv_flow.LF||
'                    gender      varchar2(200) path ';
wwv_flow_imp.g_varchar2_table(20) := '''$.gender'','||wwv_flow.LF||
'                    brand       varchar2(200) path ''$.brand'','||wwv_flow.LF||
'                    descri';
wwv_flow_imp.g_varchar2_table(21) := 'ption varchar2(2000) path ''$.description'''||wwv_flow.LF||
'                )'||wwv_flow.LF||
'            ) j'||wwv_flow.LF||
'        where p.rowid = ';
wwv_flow_imp.g_varchar2_table(22) := 'p_rid;'||wwv_flow.LF||
''||wwv_flow.LF||
'        select xmlforest( '||wwv_flow.LF||
'                   l_product.product_name as name, '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(23) := '      l_product.colour       as colour, '||wwv_flow.LF||
'                   l_product.gender       as gender,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(24) := '             l_product.brand        as brand, '||wwv_flow.LF||
'                   l_product.description  as descript';
wwv_flow_imp.g_varchar2_table(25) := 'ion ).getstringval() '||wwv_flow.LF||
'        into p_tlob '||wwv_flow.LF||
'        from sys.dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'    end products_ds_procedure;'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(26) := '   function text_is_available return boolean '||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_dummy number;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        selec';
wwv_flow_imp.g_varchar2_table(27) := 't 1 into l_dummy '||wwv_flow.LF||
'          from sys.all_objects'||wwv_flow.LF||
'         where owner       = ''CTXSYS'' '||wwv_flow.LF||
'           a';
wwv_flow_imp.g_varchar2_table(28) := 'nd object_name = ''CTX_DDL'' '||wwv_flow.LF||
'           and rownum      = 1;'||wwv_flow.LF||
''||wwv_flow.LF||
'        return true;'||wwv_flow.LF||
'    exception '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(29) := '     when NO_DATA_FOUND then return false;'||wwv_flow.LF||
'    end text_is_available;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure init_oracle_tex';
wwv_flow_imp.g_varchar2_table(30) := 't is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        if text_is_available then'||wwv_flow.LF||
'            create_text_preferences;'||wwv_flow.LF||
'            cr';
wwv_flow_imp.g_varchar2_table(31) := 'eate_text_index;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end init_oracle_text;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure drop_text_index is '||wwv_flow.LF||
'    be';
wwv_flow_imp.g_varchar2_table(32) := 'gin'||wwv_flow.LF||
'        execute_sql( q''#drop index eba_demo_search_products_ctx force#'' );'||wwv_flow.LF||
'    end drop_text_ind';
wwv_flow_imp.g_varchar2_table(33) := 'ex;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure drop_text_preferences is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        execute_sql( q''#begin ctx_ddl.drop_pre';
wwv_flow_imp.g_varchar2_table(34) := 'ference( ''EBA_DEMO_SEARCH_LX_PREF''); end;#'', false ); '||wwv_flow.LF||
'        execute_sql( q''#begin ctx_ddl.drop_pr';
wwv_flow_imp.g_varchar2_table(35) := 'eference( ''EBA_DEMO_SEARCH_DS_PREF''); end;#'',false); '||wwv_flow.LF||
'        execute_sql( q''#begin ctx_ddl.drop_sec';
wwv_flow_imp.g_varchar2_table(36) := 'tion_group( ''EBA_DEMO_SEARCH_SG_PREF''); end;#'', false ); '||wwv_flow.LF||
'    end drop_text_preferences;'||wwv_flow.LF||
''||wwv_flow.LF||
'    proced';
wwv_flow_imp.g_varchar2_table(37) := 'ure create_text_preferences is'||wwv_flow.LF||
''||wwv_flow.LF||
'    begin'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Datastore Preference        '||wwv_flow.LF||
'        '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(38) := 'execute_sql(q''# '||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            ctx_ddl.create_preference('||wwv_flow.LF||
'                preference_nam';
wwv_flow_imp.g_varchar2_table(39) := 'e  => ''EBA_DEMO_SEARCH_DS_PREF'','||wwv_flow.LF||
'                object_name      => ''USER_DATASTORE'''||wwv_flow.LF||
'            );';
wwv_flow_imp.g_varchar2_table(40) := ''||wwv_flow.LF||
'        '||wwv_flow.LF||
'            ctx_ddl.set_attribute('||wwv_flow.LF||
'                preference_name  => ''EBA_DEMO_SEARCH_DS';
wwv_flow_imp.g_varchar2_table(41) := '_PREF'','||wwv_flow.LF||
'                attribute_name   => ''PROCEDURE'','||wwv_flow.LF||
'                attribute_value  => ''eba_de';
wwv_flow_imp.g_varchar2_table(42) := 'mo_search_text_pkg.products_ds_procedure'''||wwv_flow.LF||
'            );'||wwv_flow.LF||
''||wwv_flow.LF||
'            ctx_ddl.set_attribute('||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(43) := '         preference_name  => ''EBA_DEMO_SEARCH_DS_PREF'','||wwv_flow.LF||
'                attribute_name   => ''OUTPUT_';
wwv_flow_imp.g_varchar2_table(44) := 'TYPE'','||wwv_flow.LF||
'                attribute_value  => ''VARCHAR2'''||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        end;#'', false'||wwv_flow.LF||
'        )';
wwv_flow_imp.g_varchar2_table(45) := '; '||wwv_flow.LF||
'        '||wwv_flow.LF||
'        execute_sql(q''# '||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            ctx_ddl.create_section_group('||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(46) := '         group_name       => ''EBA_DEMO_SEARCH_SG_PREF'','||wwv_flow.LF||
'                group_type       => ''XML_SEC';
wwv_flow_imp.g_varchar2_table(47) := 'TION_GROUP'''||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'            ctx_ddl.add_field_section('||wwv_flow.LF||
'                group_nam';
wwv_flow_imp.g_varchar2_table(48) := 'e       => ''EBA_DEMO_SEARCH_SG_PREF'','||wwv_flow.LF||
'                section_name     => ''NAME'','||wwv_flow.LF||
'                ta';
wwv_flow_imp.g_varchar2_table(49) := 'g              => ''NAME'','||wwv_flow.LF||
'                visible          => true'||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(50) := '   ctx_ddl.add_field_section('||wwv_flow.LF||
'                group_name       => ''EBA_DEMO_SEARCH_SG_PREF'','||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(51) := '         section_name     => ''COLOUR'','||wwv_flow.LF||
'                tag              => ''COLOUR'','||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(52) := ' visible          => true'||wwv_flow.LF||
'            );'||wwv_flow.LF||
''||wwv_flow.LF||
'            ctx_ddl.add_field_section('||wwv_flow.LF||
'                gro';
wwv_flow_imp.g_varchar2_table(53) := 'up_name       => ''EBA_DEMO_SEARCH_SG_PREF'','||wwv_flow.LF||
'                section_name     => ''GENDER'','||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(54) := '      tag              => ''GENDER'','||wwv_flow.LF||
'                visible          => true'||wwv_flow.LF||
'            );'||wwv_flow.LF||
''||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(55) := '     ctx_ddl.add_field_section('||wwv_flow.LF||
'                group_name       => ''EBA_DEMO_SEARCH_SG_PREF'','||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(56) := '           section_name     => ''BRAND'','||wwv_flow.LF||
'                tag              => ''BRAND'','||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(57) := ' visible          => true'||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'            ctx_ddl.add_field_section('||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(58) := '     group_name       => ''EBA_DEMO_SEARCH_SG_PREF'','||wwv_flow.LF||
'                section_name     => ''DESCRIPTION';
wwv_flow_imp.g_varchar2_table(59) := ''','||wwv_flow.LF||
'                tag              => ''DESCRIPTION'','||wwv_flow.LF||
'                visible          => true'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(60) := '       );'||wwv_flow.LF||
'        end;#'', false'||wwv_flow.LF||
'        ); '||wwv_flow.LF||
'        '||wwv_flow.LF||
'        execute_sql(q''# '||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(61) := '    ctx_ddl.create_preference('||wwv_flow.LF||
'                preference_name  => ''EBA_DEMO_SEARCH_LX_PREF'','||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(62) := '          object_name      => ''BASIC_LEXER'''||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'            ctx_ddl.set_attribut';
wwv_flow_imp.g_varchar2_table(63) := 'e('||wwv_flow.LF||
'                preference_name  => ''EBA_DEMO_SEARCH_LX_PREF'','||wwv_flow.LF||
'                attribute_name   =';
wwv_flow_imp.g_varchar2_table(64) := '> ''MIXED_CASE'','||wwv_flow.LF||
'                attribute_value  => ''NO'''||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'            ctx_ddl';
wwv_flow_imp.g_varchar2_table(65) := '.set_attribute('||wwv_flow.LF||
'                preference_name  => ''EBA_DEMO_SEARCH_LX_PREF'','||wwv_flow.LF||
'                attri';
wwv_flow_imp.g_varchar2_table(66) := 'bute_name   => ''BASE_LETTER'','||wwv_flow.LF||
'                attribute_value  => ''YES'''||wwv_flow.LF||
'            );'||wwv_flow.LF||
'            c';
wwv_flow_imp.g_varchar2_table(67) := 'tx_ddl.set_attribute('||wwv_flow.LF||
'                preference_name  => ''EBA_DEMO_SEARCH_LX_PREF'','||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(68) := ' attribute_name   => ''BASE_LETTER_TYPE'','||wwv_flow.LF||
'                attribute_value  => ''GENERIC'''||wwv_flow.LF||
'            )';
wwv_flow_imp.g_varchar2_table(69) := ';'||wwv_flow.LF||
'        end;#'', false'||wwv_flow.LF||
'        ); '||wwv_flow.LF||
'    end create_text_preferences;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure create_text_inde';
wwv_flow_imp.g_varchar2_table(70) := 'x is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        execute immediate '||wwv_flow.LF||
'q''#create index eba_demo_search_products_ctx on eba_demo_s';
wwv_flow_imp.g_varchar2_table(71) := 'earch_products (text_index_column)'||wwv_flow.LF||
'   indextype is ctxsys.context parameters ( ''section group  EBA_D';
wwv_flow_imp.g_varchar2_table(72) := 'EMO_SEARCH_SG_PREF'||wwv_flow.LF||
'                                             datastore      EBA_DEMO_SEARCH_DS_PR';
wwv_flow_imp.g_varchar2_table(73) := 'EF'||wwv_flow.LF||
'                                             lexer          EBA_DEMO_SEARCH_LX_PREF'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(74) := '                                stoplist       ctxsys.empty_stoplist'||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(75) := '              memory         100M'||wwv_flow.LF||
'                                             sync           (on co';
wwv_flow_imp.g_varchar2_table(76) := 'mmit)'')#'';'||wwv_flow.LF||
'    end create_text_index;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function convert_text_query(p_enduser_query in varchar2) ';
wwv_flow_imp.g_varchar2_table(77) := 'return varchar2 is'||wwv_flow.LF||
'        c_xml    constant varchar2(32767) := ''<query><textquery><progression>'' ||';
wwv_flow_imp.g_varchar2_table(78) := ''||wwv_flow.LF||
'                                            ''<seq> #search# </seq>'' ||'||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(79) := '                ''<seq> ?#search# </seq>'' ||'||wwv_flow.LF||
'                                            ''<seq> #sear';
wwv_flow_imp.g_varchar2_table(80) := 'ch#% </seq>'' ||'||wwv_flow.LF||
'                                            ''<seq> %#search#% </seq>'' ||'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(81) := '                                 ''</progression></textquery></query>'';'||wwv_flow.LF||
'        l_search varchar2(327';
wwv_flow_imp.g_varchar2_table(82) := '67) := p_enduser_query;'||wwv_flow.LF||
''||wwv_flow.LF||
'        function preprocess_search_query(p_search_query in varchar2) return';
wwv_flow_imp.g_varchar2_table(83) := ' varchar2 is'||wwv_flow.LF||
'            l_tokens      apex_t_varchar2;'||wwv_flow.LF||
'            l_token       varchar2(32767);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(84) := '           l_is_keyword  boolean;'||wwv_flow.LF||
'            l_expression  varchar2(32767);'||wwv_flow.LF||
'        '||wwv_flow.LF||
'            pr';
wwv_flow_imp.g_varchar2_table(85) := 'ocedure append_to_expression( p_expression in out nocopy varchar2, p_token in varchar2, p_is_last_or';
wwv_flow_imp.g_varchar2_table(86) := '_first in boolean ) is'||wwv_flow.LF||
'                l_is_keyword boolean;'||wwv_flow.LF||
'                l_token      varchar2(3';
wwv_flow_imp.g_varchar2_table(87) := '2767);'||wwv_flow.LF||
'            begin'||wwv_flow.LF||
'                l_is_keyword := lower(p_token) in (''and'', ''or'');'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(88) := '      l_token      := regexp_replace(p_token, ''[^[:alnum:]]'');'||wwv_flow.LF||
''||wwv_flow.LF||
'                l_expression := l_ex';
wwv_flow_imp.g_varchar2_table(89) := 'pression ||'||wwv_flow.LF||
'                    case '||wwv_flow.LF||
'                    when not l_is_keyword or (l_is_keyword and';
wwv_flow_imp.g_varchar2_table(90) := ' not p_is_last_or_first) then'||wwv_flow.LF||
'                        case '||wwv_flow.LF||
'                        when l_token is ';
wwv_flow_imp.g_varchar2_table(91) := 'not null then'||wwv_flow.LF||
'                            case '||wwv_flow.LF||
'                            when l_expression is not';
wwv_flow_imp.g_varchar2_table(92) := ' null then '' '''||wwv_flow.LF||
'                            end'||wwv_flow.LF||
'                            || case '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(93) := '                when not l_is_keyword then ''{'''||wwv_flow.LF||
'                            end'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(94) := '       || l_token'||wwv_flow.LF||
'                            || case '||wwv_flow.LF||
'                                when not l_is';
wwv_flow_imp.g_varchar2_table(95) := '_keyword then ''}'''||wwv_flow.LF||
'                            end'||wwv_flow.LF||
'                        end'||wwv_flow.LF||
'                    en';
wwv_flow_imp.g_varchar2_table(96) := 'd;'||wwv_flow.LF||
'            end append_to_expression;'||wwv_flow.LF||
''||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            -- split the search query into t';
wwv_flow_imp.g_varchar2_table(97) := 'okens'||wwv_flow.LF||
'            l_tokens := apex_string.split(p_search_query, '' '');'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- loop over the ';
wwv_flow_imp.g_varchar2_table(98) := 'tokens and append processed token to expression'||wwv_flow.LF||
'            for i in 1 .. l_tokens.count'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(99) := ' loop'||wwv_flow.LF||
'                pragma inline(append_to_expression, ''yes'');'||wwv_flow.LF||
'                append_to_expressi';
wwv_flow_imp.g_varchar2_table(100) := 'on('||wwv_flow.LF||
'                    p_expression       => l_expression,'||wwv_flow.LF||
'                    p_token            =';
wwv_flow_imp.g_varchar2_table(101) := '> l_tokens(i),'||wwv_flow.LF||
'                    p_is_last_or_first => i = l_tokens.count or i = 1'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(102) := ' );'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'            return l_expression;'||wwv_flow.LF||
'        end preprocess_search_query;'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(103) := '  begin'||wwv_flow.LF||
'        l_search := preprocess_search_query(l_search);'||wwv_flow.LF||
'        '||wwv_flow.LF||
'        return replace(c_xml';
wwv_flow_imp.g_varchar2_table(104) := ', ''#search#'', l_search);'||wwv_flow.LF||
'    end convert_text_query;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_demo_search_text_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba';
wwv_flow_imp.g_varchar2_table(105) := '_demo_search_text_pkg.init_oracle_text;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(4124165888443597712)
,p_install_id=>wwv_flow_imp.id(4926791174312313587)
,p_name=>'Oracle TEXT helper package (compiles without Oracle Text)'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
