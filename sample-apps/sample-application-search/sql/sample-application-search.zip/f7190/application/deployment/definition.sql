prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7190
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '----------------------------------------------------------------'||wwv_flow.LF||
'-- Remove Oracle Text objects'||wwv_flow.LF||
'-----';
wwv_flow_imp.g_varchar2_table(2) := '-----------------------------------------------------------'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_demo_search_text_pkg.drop_';
wwv_flow_imp.g_varchar2_table(3) := 'text_preferences;'||wwv_flow.LF||
'    eba_demo_search_text_pkg.drop_text_index;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop package eba_demo_search';
wwv_flow_imp.g_varchar2_table(4) := '_text_pkg;'||wwv_flow.LF||
'----------------------------------------------------------------'||wwv_flow.LF||
'-- Remove packages'||wwv_flow.LF||
'-----';
wwv_flow_imp.g_varchar2_table(5) := '-----------------------------------------------------------'||wwv_flow.LF||
'drop package eba_demo_search_data_pkg;'||wwv_flow.LF||
'-';
wwv_flow_imp.g_varchar2_table(6) := '---------------------------------------------------------------'||wwv_flow.LF||
'-- Remove functions'||wwv_flow.LF||
'----------------';
wwv_flow_imp.g_varchar2_table(7) := '------------------------------------------------'||wwv_flow.LF||
'drop function eba_demo_search_error_handling;'||wwv_flow.LF||
'-----';
wwv_flow_imp.g_varchar2_table(8) := '-----------------------------------------------------------'||wwv_flow.LF||
'-- Remove views'||wwv_flow.LF||
'------------------------';
wwv_flow_imp.g_varchar2_table(9) := '----------------------------------------'||wwv_flow.LF||
'drop view eba_demo_search_cust_ord_prd;'||wwv_flow.LF||
'drop view eba_demo_';
wwv_flow_imp.g_varchar2_table(10) := 'search_prd_orders;'||wwv_flow.LF||
'drop view eba_demo_search_prd_reviews;'||wwv_flow.LF||
'drop view eba_demo_search_str_orders;'||wwv_flow.LF||
'drop';
wwv_flow_imp.g_varchar2_table(11) := ' view eba_demo_search_str_ord_stat;'||wwv_flow.LF||
'----------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(12) := ''||wwv_flow.LF||
'-- Remove Tables'||wwv_flow.LF||
'---------------------------------------------------------------'||wwv_flow.LF||
'drop table eba_dem';
wwv_flow_imp.g_varchar2_table(13) := 'o_search_customers    cascade constraints purge;'||wwv_flow.LF||
'drop table eba_demo_search_stores    cascade constr';
wwv_flow_imp.g_varchar2_table(14) := 'aints purge;'||wwv_flow.LF||
'drop table eba_demo_search_orders    cascade constraints purge;'||wwv_flow.LF||
'drop table eba_demo_sea';
wwv_flow_imp.g_varchar2_table(15) := 'rch_order_items    cascade constraints purge;'||wwv_flow.LF||
'drop table eba_demo_search_products    cascade constra';
wwv_flow_imp.g_varchar2_table(16) := 'ints purge;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba_demo_search_web_creds cascade constraints purge;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(4926791174312313587)
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
