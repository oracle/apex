prompt --application/shared_components/user_interface/lovs/product_colors
begin
--   Manifest
--     PRODUCT COLORS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(4931562962575070113)
,p_lov_name=>'PRODUCT COLORS'
,p_static_id=>'product-colors'
,p_lov_query=>'select distinct json_value(product_details,''$.colour'') product_color from eba_demo_search_products'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'PRODUCT_COLOR'
,p_display_column_name=>'PRODUCT_COLOR'
,p_version_scn=>'1089051718'
);
wwv_flow_imp.component_end;
end;
/
