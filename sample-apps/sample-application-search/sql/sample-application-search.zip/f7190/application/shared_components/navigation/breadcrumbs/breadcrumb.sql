prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(4926226270960679507)
,p_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2469494379256695441)
,p_short_name=>'Administration'
,p_static_id=>'administration'
,p_link=>'f?p=&APP_ID.:500:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4114378707377219710)
,p_short_name=>'Advanced'
,p_static_id=>'advanced'
,p_link=>'f?p=&APP_ID.:300:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2469506578993742073)
,p_parent_id=>wwv_flow_imp.id(2469494379256695441)
,p_short_name=>'Application Theme Style'
,p_static_id=>'application-theme-style'
,p_link=>'f?p=&APP_ID.:502:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>502
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4114372273210205027)
,p_short_name=>'Basics'
,p_static_id=>'basics'
,p_link=>'f?p=&APP_ID.:100:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4114449505383309686)
,p_parent_id=>wwv_flow_imp.id(4114378707377219710)
,p_short_name=>'Cards Region'
,p_static_id=>'cards-region'
,p_link=>'f?p=&APP_ID.:301:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>301
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4114415734353279877)
,p_parent_id=>wwv_flow_imp.id(4114375227202211404)
,p_short_name=>'Custom Result Row Template'
,p_static_id=>'custom-result-row-template'
,p_link=>'f?p=&APP_ID.:204:&SESSION.::&DEBUG.:::'
,p_page_id=>204
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4114437373533297114)
,p_parent_id=>wwv_flow_imp.id(4114375227202211404)
,p_short_name=>'Filter Search Configurations'
,p_static_id=>'filter-search-configurations'
,p_link=>'f?p=&APP_ID.:206:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>206
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4114463266173319768)
,p_parent_id=>wwv_flow_imp.id(4114378707377219710)
,p_short_name=>'Highlight Results'
,p_static_id=>'highlight-results'
,p_link=>'f?p=&APP_ID.:303:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>303
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4926226471272679507)
,p_short_name=>'Home'
,p_static_id=>'home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4114402334889254885)
,p_parent_id=>wwv_flow_imp.id(4114375227202211404)
,p_short_name=>'Link Search Result to Form'
,p_static_id=>'link-search-result-to-form'
,p_link=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:::'
,p_page_id=>202
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2469500447775729892)
,p_parent_id=>wwv_flow_imp.id(2469494379256695441)
,p_short_name=>'Manage Sample Data'
,p_static_id=>'manage-sample-data'
,p_link=>'f?p=&APP_ID.:501:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>501
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4114456110241314955)
,p_parent_id=>wwv_flow_imp.id(4114378707377219710)
,p_short_name=>'Map Region'
,p_static_id=>'map-region'
,p_link=>'f?p=&APP_ID.:302:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>302
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4114389740235239445)
,p_parent_id=>wwv_flow_imp.id(4114372273210205027)
,p_short_name=>'Multiple Search Configurations'
,p_static_id=>'multiple-search-configurations'
,p_link=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:::'
,p_page_id=>102
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4114444246472302567)
,p_parent_id=>wwv_flow_imp.id(4114375227202211404)
,p_short_name=>'Multiple Search Regions'
,p_static_id=>'multiple-search-regions'
,p_link=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.:::'
,p_page_id=>207
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4114381830134224300)
,p_short_name=>'Oracle Text'
,p_static_id=>'oracle-text'
,p_link=>'f?p=&APP_ID.:400:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>400
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4116086700697535758)
,p_parent_id=>wwv_flow_imp.id(4114372273210205027)
,p_short_name=>'REST Data Source'
,p_static_id=>'rest-data-source'
,p_link=>'f?p=&APP_ID.:103:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>103
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4114398802526249660)
,p_parent_id=>wwv_flow_imp.id(4114375227202211404)
,p_short_name=>'Search Query Prefix'
,p_static_id=>'search-query-prefix'
,p_link=>'f?p=&APP_ID.:201:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4114385214312232857)
,p_parent_id=>wwv_flow_imp.id(4114372273210205027)
,p_short_name=>'Single Search Configuration'
,p_static_id=>'single-search-configuration'
,p_link=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.:::'
,p_page_id=>101
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4115309760868002350)
,p_parent_id=>wwv_flow_imp.id(4114381830134224300)
,p_short_name=>'Standard'
,p_static_id=>'standard'
,p_link=>'f?p=&APP_ID.:401:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>401
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4115312913478033653)
,p_parent_id=>wwv_flow_imp.id(4114381830134224300)
,p_short_name=>'Text Index Function'
,p_static_id=>'text-index-function'
,p_link=>'f?p=&APP_ID.:402:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>402
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4114375227202211404)
,p_short_name=>'Use Cases'
,p_static_id=>'use-cases'
,p_link=>'f?p=&APP_ID.:200:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2470249397643673114)
,p_parent_id=>wwv_flow_imp.id(2469494379256695441)
,p_short_name=>'Web Credentials Settings'
,p_static_id=>'web-credentials-settings'
,p_link=>'f?p=&APP_ID.:503:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>503
);
wwv_flow_imp.component_end;
end;
/
