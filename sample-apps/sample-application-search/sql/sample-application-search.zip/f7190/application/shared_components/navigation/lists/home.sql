prompt --application/shared_components/navigation/lists/home
begin
--   Manifest
--     LIST: Home
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4932607112620170165)
,p_name=>'Home'
,p_static_id=>'home'
,p_version_scn=>'1089051718'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4932607992987170167)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Advanced'
,p_static_id=>'advanced'
,p_list_item_link_target=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-rocket'
,p_list_text_01=>'Explore advanced Application Search variations: Highlight search results, Integrate your Search Configurations with APEX regions like Maps, Cards ...'
,p_translate_list_text_y_n=>'Y'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4932607292079170166)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Basics'
,p_static_id=>'basics'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layers'
,p_list_text_01=>'Create Search Configurations based on Local data source, REST Enabled SQL Service, REST Data Source ... And integrate it with Search regions.'
,p_translate_list_text_y_n=>'Y'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4114481473569591735)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Oracle Text'
,p_static_id=>'oracle-text'
,p_list_item_link_target=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-server-search'
,p_list_text_01=>'Leverage to Oracle Text advanced searching capabilities: Keyword searching, Fuzzy search and much more.'
,p_translate_list_text_y_n=>'Y'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4932607674043170167)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Use Cases'
,p_static_id=>'use-cases'
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-puzzle-piece'
,p_list_text_01=>'Explore different use case of the Search Configuration: prefix searching, link search result to from ...'
,p_translate_list_text_y_n=>'Y'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
