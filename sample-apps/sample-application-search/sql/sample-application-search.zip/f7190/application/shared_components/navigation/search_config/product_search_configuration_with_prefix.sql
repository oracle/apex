prompt --application/shared_components/navigation/search_config/product_search_configuration_with_prefix
begin
--   Manifest
--     SEARCH CONFIG: Product Search Configuration With Prefix
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(4926482310239149400)
,p_label=>'Product Search Configuration With Prefix'
,p_static_id=>'product_prefix'
,p_search_prefix=>'prod'
,p_search_type=>'SIMPLE'
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_query_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.product_id, ',
'       p.product_name, ',
'       ''$'' || p.unit_price unit_price,',
'       j.description,',
'       j.gender, ',
'       j.colour,',
'       j.brand',
'  from eba_demo_search_products p,',
'       json_table (',
'           p.product_details, ',
'           ''$'' ',
'           columns ( ',
'               description varchar2(4000) path ''$.description'',',
'               colour      varchar2(4000) path ''$.colour'',',
'               gender      varchar2(4000) path ''$.gender'',',
'               brand       varchar2(4000) path ''$.brand'')) j'))
,p_searchable_columns=>'PRODUCT_NAME:DESCRIPTION:GENDER:COLOUR:BRAND'
,p_return_max_results=>5
,p_pk_column_name=>'PRODUCT_ID'
,p_title_column_name=>'PRODUCT_NAME'
,p_subtitle_column_name=>'BRAND'
,p_description_column_name=>'DESCRIPTION'
,p_badge_column_name=>'UNIT_PRICE'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-package u-color-1-text'
,p_version_scn=>'1089051725'
);
wwv_flow_imp.component_end;
end;
/
