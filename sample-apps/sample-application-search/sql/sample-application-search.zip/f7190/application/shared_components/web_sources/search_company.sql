prompt --application/shared_components/web_sources/search_company
begin
--   Manifest
--     WEB SOURCE: Search Company
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(4926473197786594308)
,p_name=>'Search Company'
,p_static_id=>'Search_Company'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(4926471852584594307)
,p_remote_server_id=>2443353624720510492
,p_url_path_prefix=>'search/company'
,p_credential_id=>2466974836178351259
,p_pass_ecid=>true
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fixed_page_size', '20',
  'index_of_first_page', '1',
  'page_number_url_parameter', 'page',
  'pagination_type', 'PAGE_NUMBER_FIXED_SIZE')).to_clob
,p_version_scn=>'1089051718'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(4926473780540594309)
,p_web_src_module_id=>wwv_flow_imp.id(4926473197786594308)
,p_name=>'query'
,p_static_id=>'query'
,p_param_type=>'QUERY_STRING'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_default_value_type=>'STATIC'
,p_value=>'Netflix'
,p_is_query_param=>true
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(4926471852584594307)
,p_name=>'Search Company'
,p_format=>'JSON'
,p_row_selector=>'results'
,p_use_raw_json_selectors=>false
,p_is_single_row=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(4926472031640594307)
,p_data_profile_id=>wwv_flow_imp.id(4926471852584594307)
,p_name=>'ID'
,p_static_id=>'id'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'NUMBER'
,p_selector=>'id'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(4926472656686594308)
,p_data_profile_id=>wwv_flow_imp.id(4926471852584594307)
,p_name=>'LOGO_PATH'
,p_static_id=>'logo-path'
,p_sequence=>3
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_selector=>'logo_path'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(4926472334437594307)
,p_data_profile_id=>wwv_flow_imp.id(4926471852584594307)
,p_name=>'NAME'
,p_static_id=>'name'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_selector=>'name'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(4926472900450594308)
,p_data_profile_id=>wwv_flow_imp.id(4926471852584594307)
,p_name=>'ORIGIN_COUNTRY'
,p_static_id=>'origin-country'
,p_sequence=>4
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_selector=>'origin_country'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(4926473436343594308)
,p_web_src_module_id=>wwv_flow_imp.id(4926473197786594308)
,p_static_id=>'get'
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_legacy_ords_fixed_page_size=>20
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
