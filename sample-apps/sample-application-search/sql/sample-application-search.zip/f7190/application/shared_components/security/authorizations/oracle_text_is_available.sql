prompt --application/shared_components/security/authorizations/oracle_text_is_available
begin
--   Manifest
--     SECURITY SCHEME: Oracle Text is available
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(2464364414900478475)
,p_name=>'Oracle Text is available'
,p_static_id=>'oracle-text-is-available'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'plsql_function_body', 'return eba_demo_search_text_pkg.text_is_available;')).to_clob
,p_error_message=>'Oracle Text is not available in this workspace.'
,p_version_scn=>'1089051718'
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
