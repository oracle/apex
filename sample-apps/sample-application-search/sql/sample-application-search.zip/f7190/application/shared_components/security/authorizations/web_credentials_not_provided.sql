prompt --application/shared_components/security/authorizations/web_credentials_not_provided
begin
--   Manifest
--     SECURITY SCHEME: Web Credentials not provided
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(2470272831299674587)
,p_name=>'Web Credentials not provided'
,p_static_id=>'web-credentials-not-provided'
,p_scheme_type=>'NATIVE_NOT_EXISTS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'sql_query', 'select * from eba_demo_search_web_creds where credential_static_id = ''tmdb_api_key''')).to_clob
,p_error_message=>'Required web credentials are not provided.'
,p_version_scn=>'1089051718'
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
