prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 7190
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>768993839755884678
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(4909078651182717015)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(4908926595943716914)
,p_default_dialog_template=>wwv_flow_imp.id(4908921413143716911)
,p_error_template=>wwv_flow_imp.id(4908911419303716904)
,p_printer_friendly_template=>wwv_flow_imp.id(4908926595943716914)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(4908911419303716904)
,p_default_button_template=>wwv_flow_imp.id(4909075602567717012)
,p_default_region_template=>wwv_flow_imp.id(4909002691680716965)
,p_default_chart_template=>wwv_flow_imp.id(4909002691680716965)
,p_default_form_template=>wwv_flow_imp.id(4909002691680716965)
,p_default_reportr_template=>wwv_flow_imp.id(4909002691680716965)
,p_default_tabform_template=>wwv_flow_imp.id(4909002691680716965)
,p_default_wizard_template=>wwv_flow_imp.id(4909002691680716965)
,p_default_menur_template=>wwv_flow_imp.id(4909015154819716972)
,p_default_listr_template=>wwv_flow_imp.id(4909002691680716965)
,p_default_irr_template=>wwv_flow_imp.id(4908992978698716959)
,p_default_report_template=>wwv_flow_imp.id(4909040683393716988)
,p_default_label_template=>wwv_flow_imp.id(4909073124878717010)
,p_default_menu_template=>wwv_flow_imp.id(4909077186804717013)
,p_default_calendar_template=>wwv_flow_imp.id(4909077329262717013)
,p_default_list_template=>wwv_flow_imp.id(4909056994882716999)
,p_default_nav_list_template=>wwv_flow_imp.id(4909068808947717007)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(4909068808947717007)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(4909063415336717004)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(4908939491593716923)
,p_default_dialogr_template=>wwv_flow_imp.id(4908936732543716922)
,p_default_option_label=>wwv_flow_imp.id(4909073124878717010)
,p_default_required_label=>wwv_flow_imp.id(4909074471772717011)
,p_default_navbar_list_template=>wwv_flow_imp.id(4909063059635717003)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/23.1/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
