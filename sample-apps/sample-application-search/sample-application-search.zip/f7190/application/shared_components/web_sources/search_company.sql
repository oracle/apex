prompt --application/shared_components/web_sources/search_company
begin
--   Manifest
--     WEB SOURCE: Search Company
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>768993839755884678
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(4909147002427631695)
,p_name=>'Search Company'
,p_static_id=>'Search_Company'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(4909145657225631694)
,p_remote_server_id=>wwv_flow_imp.id(2426027429361547879)
,p_url_path_prefix=>'search/company'
,p_credential_id=>wwv_flow_imp.id(2449648640819388646)
,p_pass_ecid=>true
,p_attribute_01=>'PAGE_NUMBER_FIXED_SIZE'
,p_attribute_04=>'page'
,p_attribute_05=>'1'
,p_attribute_06=>'20'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(4909147585181631696)
,p_web_src_module_id=>wwv_flow_imp.id(4909147002427631695)
,p_name=>'query'
,p_param_type=>'QUERY_STRING'
,p_is_required=>false
,p_value=>'Netflix'
,p_is_query_param=>true
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(4909147240984631695)
,p_web_src_module_id=>wwv_flow_imp.id(4909147002427631695)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_legacy_ords_fixed_page_size=>20
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
