prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4926226735445679509)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089051718
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4926436950610679655)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4926447622669994991)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Basics'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layers'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4114382983378232853)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Single Search Configuration'
,p_list_item_link_target=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(4926447622669994991)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'101'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4114386965427239442)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Multiple Search Configurations'
,p_list_item_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(4926447622669994991)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'102'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4116085796175535757)
,p_list_item_display_sequence=>260
,p_list_item_link_text=>'REST Data Source'
,p_list_item_link_target=>'f?p=&APP_ID.:103:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_imp.id(4926447622669994991)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'103'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4926481723217114626)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Use Cases'
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-puzzle-piece'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4114396000649249657)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Search Query Prefix'
,p_list_item_link_target=>'f?p=&APP_ID.:201:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_imp.id(4926481723217114626)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'201'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4114465929575329676)
,p_list_item_display_sequence=>175
,p_list_item_link_text=>'Link Search Result To Form'
,p_list_item_link_target=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(4926481723217114626)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4114413472102279874)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Custom Result Row Template'
,p_list_item_link_target=>'f?p=&APP_ID.:204:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(4926481723217114626)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'204'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4114433735222297110)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>'Filter Search Configurations'
,p_list_item_link_target=>'f?p=&APP_ID.:206:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_imp.id(4926481723217114626)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'206'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4114440560745302563)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'Multiple Search Regions'
,p_list_item_link_target=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(4926481723217114626)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'207'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4114377362358219709)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Advanced'
,p_list_item_link_target=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-rocket'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'300'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4114447177755309683)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>'Cards Region'
,p_list_item_link_target=>'f?p=&APP_ID.:301:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_imp.id(4114377362358219709)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'301'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4114452080434314950)
,p_list_item_display_sequence=>220
,p_list_item_link_text=>'Map Region'
,p_list_item_link_target=>'f?p=&APP_ID.:302:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_imp.id(4114377362358219709)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'302'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4114460985866319765)
,p_list_item_display_sequence=>230
,p_list_item_link_text=>'Highlight Results'
,p_list_item_link_target=>'f?p=&APP_ID.:303:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_imp.id(4114377362358219709)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'303'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4114380786931224299)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Oracle Text'
,p_list_item_link_target=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-server-search'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'400'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4115308863954002348)
,p_list_item_display_sequence=>240
,p_list_item_link_text=>'Standard'
,p_list_item_link_target=>'f?p=&APP_ID.:401:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_imp.id(4114380786931224299)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'401'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4115312104054033652)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>'Text Index Function'
,p_list_item_link_target=>'f?p=&APP_ID.:402:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_imp.id(4114380786931224299)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'402'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2469492938693695430)
,p_list_item_display_sequence=>270
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gear'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'500,501,502,503'
);
wwv_flow_imp.component_end;
end;
/
