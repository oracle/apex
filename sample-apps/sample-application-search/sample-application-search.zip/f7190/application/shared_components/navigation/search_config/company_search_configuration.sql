prompt --application/shared_components/navigation/search_config/company_search_configuration
begin
--   Manifest
--     SEARCH CONFIG: Company Search Configuration
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(4926475344312628959)
,p_label=>'Company Search Configuration'
,p_static_id=>'company'
,p_search_type=>'SIMPLE'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(4926473197786594308)
,p_function_body_language=>'PLSQL'
,p_pk_column_name=>'ID'
,p_title_column_name=>'NAME'
,p_subtitle_column_name=>'ORIGIN_COUNTRY'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:105:&APP_SESSION.::&DEBUG.::P105_ID:&ID.'
,p_icon_source_type=>'URL'
,p_icon_image_url=>'&LOGO_PATH.'
,p_icon_css_classes=>'fa-video-camera'
,p_version_scn=>1089051725
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(4926475653417628959)
,p_web_src_param_id=>wwv_flow_imp.id(4926473780540594309)
,p_search_config_id=>wwv_flow_imp.id(4926475344312628959)
,p_value_type=>'STATIC'
,p_value=>'Netflix'
);
wwv_flow_imp.component_end;
end;
/
