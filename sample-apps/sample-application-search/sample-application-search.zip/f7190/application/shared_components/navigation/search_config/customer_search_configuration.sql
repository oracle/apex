prompt --application/shared_components/navigation/search_config/customer_search_configuration
begin
--   Manifest
--     SEARCH CONFIG: Customer Search Configuration
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(4926488019013271954)
,p_label=>'Customer Search Configuration'
,p_static_id=>'customer'
,p_search_type=>'SIMPLE'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_DEMO_SEARCH_CUSTOMERS'
,p_searchable_columns=>'FULL_NAME:EMAIL_ADDRESS'
,p_return_max_results=>5
,p_pk_column_name=>'CUSTOMER_ID'
,p_title_column_name=>'FULL_NAME'
,p_description_column_name=>'EMAIL_ADDRESS'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:203:&APP_SESSION.::&DEBUG.:203:P203_CUSTOMER_ID:&CUSTOMER_ID.'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-user u-color-10-text'
,p_version_scn=>1089051725
);
wwv_flow_imp.component_end;
end;
/
