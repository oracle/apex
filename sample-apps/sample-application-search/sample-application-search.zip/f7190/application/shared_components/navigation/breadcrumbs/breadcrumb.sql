prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>847720286407121424
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(4139906235845832216)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1683174344141848150)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:500:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1683180412660882601)
,p_parent_id=>wwv_flow_imp.id(1683174344141848150)
,p_short_name=>'Manage Sample Data'
,p_link=>'f?p=&APP_ID.:501:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>501
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1683186543878894782)
,p_parent_id=>wwv_flow_imp.id(1683174344141848150)
,p_short_name=>'Application Theme Style'
,p_link=>'f?p=&APP_ID.:502:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>502
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1683929362528825823)
,p_parent_id=>wwv_flow_imp.id(1683174344141848150)
,p_short_name=>'Web Credentials Settings'
,p_link=>'f?p=&APP_ID.:503:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>503
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328052238095357736)
,p_short_name=>'Basics'
,p_link=>'f?p=&APP_ID.:100:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328055192087364113)
,p_short_name=>'Use Cases'
,p_link=>'f?p=&APP_ID.:200:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328058672262372419)
,p_short_name=>'Advanced'
,p_link=>'f?p=&APP_ID.:300:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328061795019377009)
,p_short_name=>'Oracle Text'
,p_link=>'f?p=&APP_ID.:400:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>400
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328065179197385566)
,p_parent_id=>wwv_flow_imp.id(3328052238095357736)
,p_short_name=>'Single Search Configuration'
,p_link=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.:::'
,p_page_id=>101
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328069705120392154)
,p_parent_id=>wwv_flow_imp.id(3328052238095357736)
,p_short_name=>'Multiple Search Configurations'
,p_link=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:::'
,p_page_id=>102
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328078767411402369)
,p_parent_id=>wwv_flow_imp.id(3328055192087364113)
,p_short_name=>'Search Query Prefix'
,p_link=>'f?p=&APP_ID.:201:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328082299774407594)
,p_parent_id=>wwv_flow_imp.id(3328055192087364113)
,p_short_name=>'Link Search Result to Form'
,p_link=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:::'
,p_page_id=>202
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328095699238432586)
,p_parent_id=>wwv_flow_imp.id(3328055192087364113)
,p_short_name=>'Custom Result Row Template'
,p_link=>'f?p=&APP_ID.:204:&SESSION.::&DEBUG.:::'
,p_page_id=>204
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328117338418449823)
,p_parent_id=>wwv_flow_imp.id(3328055192087364113)
,p_short_name=>'Filter Search Configurations'
,p_link=>'f?p=&APP_ID.:206:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>206
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328124211357455276)
,p_parent_id=>wwv_flow_imp.id(3328055192087364113)
,p_short_name=>'Multiple Search Regions'
,p_link=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.:::'
,p_page_id=>207
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328129470268462395)
,p_parent_id=>wwv_flow_imp.id(3328058672262372419)
,p_short_name=>'Cards Region'
,p_link=>'f?p=&APP_ID.:301:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>301
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328136075126467664)
,p_parent_id=>wwv_flow_imp.id(3328058672262372419)
,p_short_name=>'Map Region'
,p_link=>'f?p=&APP_ID.:302:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>302
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328143231058472477)
,p_parent_id=>wwv_flow_imp.id(3328058672262372419)
,p_short_name=>'Highlight Results'
,p_link=>'f?p=&APP_ID.:303:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>303
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328989725753155059)
,p_parent_id=>wwv_flow_imp.id(3328061795019377009)
,p_short_name=>'Standard'
,p_link=>'f?p=&APP_ID.:401:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>401
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3328992878363186362)
,p_parent_id=>wwv_flow_imp.id(3328061795019377009)
,p_short_name=>'Text Index Function'
,p_link=>'f?p=&APP_ID.:402:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>402
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3329766665582688467)
,p_parent_id=>wwv_flow_imp.id(3328052238095357736)
,p_short_name=>'REST Data Source'
,p_link=>'f?p=&APP_ID.:103:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>103
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4139906436157832216)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp.component_end;
end;
/
