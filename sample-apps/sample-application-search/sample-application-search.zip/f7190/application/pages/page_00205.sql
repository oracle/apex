prompt --application/pages/page_00205
begin
--   Manifest
--     PAGE: 00205
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>205
,p_name=>'Product Details'
,p_alias=>'PRODUCT-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Product Details'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.rating{',
'    display: flex;',
'    align-items: center;',
'    justify-content: space-between;',
'    font: bold;',
'    color: #fff !important;',
'    background-color: #5B5B59!important;',
'}',
'.star{',
'    /* color: gold!important; */',
'    margin: 0!important;',
'    color: gold !important;',
'}',
''))
,p_step_template=>2100407606326202693
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4926823978020042268)
,p_plug_name=>'Product Details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select product_id,',
'       product_name,',
'       unit_price,',
'       json_value(product_details, ''$.description'') as description,',
'       product_image,',
'       image_mime_type,',
'       image_filename,',
'       image_charset,',
'       image_last_updated',
'  from eba_demo_search_products'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_landmark_label=>'Product details'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4116139883109046675)
,p_plug_name=>'Left'
,p_parent_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>4
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4116139945080046676)
,p_plug_name=>'Right'
,p_parent_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4116140153227046678)
,p_plug_name=>'Reviews'
,p_parent_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>100
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.review, ',
'       r.rating',
'  from eba_demo_search_products p, ',
'       json_table(',
'           p.product_details, ',
'           ''$.reviews[*]'' ',
'            columns (',
'                rating number        path ''$.rating'',',
'                review varchar2(200) path ''$.review'') ) r',
'where product_id = :P205_PRODUCT_ID'))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'P205_PRODUCT_ID'
,p_plug_query_num_rows=>15
,p_plug_query_no_data_found=>'No reviews found!'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'list_view_features', 'ADVANCED_FORMATTING',
  'text_formatting', wwv_flow_string.join(wwv_flow_t_varchar2(
    '&REVIEW.',
    '<div class="ui-li-count rating">',
    '    <span class="fa fa-star star"></span>',
    '    &RATING./10',
    '</div>')))).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4114419864477290433)
,p_name=>'P205_PRODUCT_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_item_source_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_source=>'PRODUCT_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4114420289159290434)
,p_name=>'P205_PRODUCT_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4116139945080046676)
,p_item_source_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_prompt=>'Product Name'
,p_source=>'PRODUCT_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4114420668511290434)
,p_name=>'P205_UNIT_PRICE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4116139945080046676)
,p_item_source_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_prompt=>'Unit Price'
,p_source=>'UNIT_PRICE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4114421050636290434)
,p_name=>'P205_DESCRIPTION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4116139945080046676)
,p_item_source_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_prompt=>'Description'
,p_source=>'DESCRIPTION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4114421825338290435)
,p_name=>'P205_PRODUCT_IMAGE'
,p_source_data_type=>'BLOB'
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4116139883109046675)
,p_item_source_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_source=>'PRODUCT_IMAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'alternative_text_column', 'PRODUCT_NAME',
  'based_on', 'DB_COLUMN',
  'blob_last_updated_column', 'IMAGE_LAST_UPDATED',
  'filename_column', 'IMAGE_FILENAME',
  'mime_type_column', 'IMAGE_MIME_TYPE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4114422283185290435)
,p_name=>'P205_IMAGE_MIME_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_item_source_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_source=>'IMAGE_MIME_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4114422677932290436)
,p_name=>'P205_IMAGE_FILENAME'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_item_source_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_source=>'IMAGE_FILENAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4114423062080290436)
,p_name=>'P205_IMAGE_CHARSET'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_item_source_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_source=>'IMAGE_CHARSET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4114423471005290436)
,p_name=>'P205_IMAGE_LAST_UPDATED'
,p_source_data_type=>'DATE'
,p_is_query_only=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_item_source_plug_id=>wwv_flow_imp.id(4926823978020042268)
,p_source=>'IMAGE_LAST_UPDATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4114427284498290439)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(4926823978020042268)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Product Details'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>4097101089139327826
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4114426855038290439)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(4926823978020042268)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Product Details'
,p_internal_uid=>4097100659679327826
);
wwv_flow_imp.component_end;
end;
/
