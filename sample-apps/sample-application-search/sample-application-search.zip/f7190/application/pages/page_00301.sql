prompt --application/pages/page_00301
begin
--   Manifest
--     PAGE: 00301
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>301
,p_name=>'Cards Region'
,p_alias=>'CARDS-REGION'
,p_step_title=>'Cards Region'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Setting card icon background to transparent ',
'   so that the icon color from the Search Configuration ',
'   renders correctly */',
':root {',
'    --a-cv-icon-background-color: transparent;',
'}',
'',
'/* Change card icon size */',
'.a-CardView-icon{',
'    font-size: xx-large !important;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2478650765634354216)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_landmark_type=>'search'
,p_landmark_label=>'Products, Stores and Customers'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6562352980917067141)
,p_plug_name=>'Search Results'
,p_region_template_options=>'t-CardsRegion--styleA'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select config_label,',
'       primary_key_1,',
'       title,',
'       subtitle,',
'       description,',
'       icon_type,',
'       ''fa '' || icon_value as icon_value,',
'       case config_label ',
'           when ''Store Search Configuration''    then ''Store''',
'           when ''Product Search Configuration''  then ''Product''',
'           when ''Customer Search Configuration'' then ''Customer''',
'       end tag',
'  from table(',
'           apex_search.search(',
'               p_search_static_ids => apex_t_varchar2( ''store'', ''product'', ''customer'' ),',
'               p_search_expression => :P301_SEARCH,',
'               p_apply_order_bys   => ''N'') )'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P301_SEARCH'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'No customers, products or stores found.'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(4114447877536309684)
,p_region_id=>wwv_flow_imp.id(6562352980917067141)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITLE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'SUBTITLE'
,p_body_adv_formatting=>false
,p_body_column_name=>'DESCRIPTION'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'ICON_VALUE'
,p_icon_position=>'START'
,p_badge_column_name=>'TAG'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'PRIMARY_KEY_1'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4111881246307284895)
,p_card_id=>wwv_flow_imp.id(4114447877536309684)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Edit'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:304:&SESSION.::&DEBUG.:304:P304_CONFIG,P304_STORE_ID,P304_CUSTOMER_ID,P304_PRODUCT_ID:&CONFIG_LABEL.,&PRIMARY_KEY_1.,&PRIMARY_KEY_1.,&PRIMARY_KEY_1.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-edit'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6562656893021113522)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(4926226270960679507)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6602202829625175801)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page shows you how to use the <em>Cards region</em> to display search results.</p>',
'<p>You can use the <code>search</code> function to connect the Cards region to the Search Configuration to programmatically retrieve search results.</p>',
'<p>This example uses the following <code>search</code> function:</p>',
'<pre style="max-width: 100%; overflow: auto">apex_search.search (',
'      p_search_static_ids      in apex_t_varchar2,',
'      p_search_expression      in varchar2,',
'      p_apply_order_bys        in varchar2           default ''Y'',',
'      --',
'      p_return_total_row_count in varchar2           default ''N'' )',
'      return apex_search_result_table pipelined;',
'</pre>',
'<p>The <code>search</code> function requires the specification of search configurations to be used for the search, along with the search query. It returns relevant search results which can then be rendered on components such as the Cards region.</p>',
'<p>To test the functionality, type a search query (such as "<strong>red</strong>") and all relevant results from the <em>Customer search configuration</em>, <em>Store search configuration</em>, and <em>Product search configuration</em> will be displa'
||'yed in the Cards region.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2468378094280668885)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6562656893021113522)
,p_button_name=>'PREV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Previous'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2468378399253670628)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6562656893021113522)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:302:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4114448649058309686)
,p_name=>'P301_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2478650765634354216)
,p_prompt=>'Search'
,p_placeholder=>'Enter your search term, e.g. ''red'''
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_grid_label_column_span=>0
,p_field_template=>2040785906935475274
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'SEARCH',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4114449686785309687)
,p_name=>'search'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P301_SEARCH'
,p_bind_type=>'bind'
,p_execution_type=>'THROTTLE'
,p_execution_time=>500
,p_execution_immediate=>false
,p_bind_event_type=>'keyup'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4114450125317309687)
,p_event_id=>wwv_flow_imp.id(4114449686785309687)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6562352980917067141)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4111881350414284896)
,p_name=>'Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(6562352980917067141)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4111881410321284897)
,p_event_id=>wwv_flow_imp.id(4111881350414284896)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6562352980917067141)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2457701993510262146)
,p_name=>'Enter key'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P301_SEARCH'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.browserEvent.keyCode === 13',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2457702047220262147)
,p_event_id=>wwv_flow_imp.id(2457701993510262146)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp.component_end;
end;
/
