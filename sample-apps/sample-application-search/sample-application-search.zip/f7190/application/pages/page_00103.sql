prompt --application/pages/page_00103
begin
--   Manifest
--     PAGE: 00103
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>103
,p_name=>'REST Data Source'
,p_alias=>'REST-DATA-SOURCE'
,p_step_title=>'REST Data Source'
,p_error_handling_function=>'eba_demo_search_error_handling'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'26'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2478648483567346602)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_required_role=>'!'||wwv_flow_imp.id(2470272831299674587)
,p_landmark_type=>'search'
,p_landmark_label=>'Movies and Companies'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4116086302726535758)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(4926226270960679507)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4116086827503535758)
,p_plug_name=>'Search Results'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1555738898046108210
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_plug_required_role=>'!'||wwv_flow_imp.id(2470272831299674587)
,p_landmark_type=>'exclude_landmark'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'custom_layout', 'Y',
  'lazy_loading', 'Y',
  'no_query_entered_message', 'Enter a query to search for movies or companies.',
  'no_results_found_message', 'No movies or companies found.',
  'overall_sort', 'TITLE',
  'result_row_template', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<div class="a-ResultsItem&RESULT_CSS_CLASSES!ATTR.">',
    '  {if ?ICON_VALUE/}',
    '    {case ICON_TYPE/}',
    '      {when INITIALS/}',
    '        <div class="a-ResultsItem-initials u-color-var">&ICON_VALUE.</div>',
    '      {when URL/}',
    '        <div class="a-ResultsItem-image"><img src="https://image.tmdb.org/t/p/w500&ICON_VALUE!ATTR." style="max-width:70px"  alt="&TITLE!ATTR." role="presentation" loading="lazy" /></div>',
    '      {when CLASS/}',
    '        <div class="a-ResultsItem-icon u-color-var"><span class="fa &ICON_VALUE!ATTR." aria-hidden="true"></span></div>',
    '    {endcase/}',
    '    {else/}',
    '        <div class="a-ResultsItem-image"><img src="#APP_FILES#image_not_found.png" style="max-width:70px"  alt="&TITLE!ATTR." role="presentation" loading="lazy" /></div>',
    '  {endif/}',
    '  <div class="a-ResultsItem-content">',
    '    <div class="a-ResultsItem-header">',
    '      {if ?LINK/}',
    '        <span class="a-ResultsItem-title"><a href="&LINK!ATTR.">&TITLE.</a></span>',
    '      {else/}',
    '        <span class="a-ResultsItem-title">&TITLE.</span>',
    '      {endif/}',
    '      {if ?BADGE/}<span class="a-ResultsItem-badge" >&BADGE.</span>{endif/}',
    '    </div>',
    '    {if ?SUBTITLE/}<div class="a-ResultsItem-subTitle">&SUBTITLE.</div>{endif/}',
    '    {if ?DESCRIPTION/}<div class="a-ResultsItem-description">&DESCRIPTION.</div>{endif/}',
    '    {if ?RELEASEDATE/}<div class="a-ResultsItem-misc">Release Date: &RELEASEDATE.</div>{endif/}',
    '')),
  'results_per_page', '15',
  'results_per_page_type', 'STATIC',
  'search_as_you_type', 'N',
  'search_page_item', 'P103_SEARCH',
  'show_result_count', 'N',
  'sort_direction', 'DESC',
  'use_pagination', 'Y')).to_clob
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(4116087320429535759)
,p_region_id=>wwv_flow_imp.id(4116086827503535758)
,p_search_config_id=>wwv_flow_imp.id(4926475344312628959)
,p_use_as_initial_result=>false
,p_max_results=>5
,p_display_sequence=>10
,p_name=>'Company Search Configuration'
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(4116087881561535759)
,p_region_id=>wwv_flow_imp.id(4116086827503535758)
,p_search_config_id=>wwv_flow_imp.id(4926474508594611497)
,p_use_as_initial_result=>false
,p_max_results=>5
,p_display_sequence=>20
,p_name=>'Movie Search Configuration'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5774234653640091699)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page demonstrates how to use a <strong>REST Data Source</strong> as the data source for a Search Configuration. The Search Region is configured with two Search Configurations: <strong>Company Search Configuration</strong> (which uses the Comp'
||'anies REST Data Source) and <strong>Movie Search Configuration</strong> (which uses the Movies REST Data Source).</p>',
'<p>To perform a search, simply enter your search term into the search box (e.g., "<strong>Netflix</strong>") and press <em>&crarr;Enter</em>. The search configurations will execute, and all relevant results for companies and movies will be displayed.'
||'</p>'))
,p_plug_required_role=>'!'||wwv_flow_imp.id(2470272831299674587)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6116682211372455826)
,p_plug_name=>'Web Credentials not provided'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'This page relies on a REST Data Source. You need to provide your own API key for <strong>themoviedb.org</strong>.'
,p_plug_required_role=>wwv_flow_imp.id(2470272831299674587)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2468373282883635572)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4116086302726535758)
,p_button_name=>'PREV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Previous'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2470270482657605607)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6116682211372455826)
,p_button_name=>'PROVIDE_CREDENTIALS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Provide Credentials'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:503:&SESSION.::&DEBUG.:503::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2468373536957637290)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4116086302726535758)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4116088357311535760)
,p_name=>'P103_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2478648483567346602)
,p_prompt=>'Search'
,p_placeholder=>'Enter your search term, e.g. ''Netflix'''
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_grid_label_column_span=>0
,p_field_template=>2040785906935475274
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_warn_on_unsaved_changes=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'SEARCH',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp.component_end;
end;
/
