prompt --application/pages/page_00401
begin
--   Manifest
--     PAGE: 00401
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>15069106866551867
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>401
,p_name=>'Standard'
,p_alias=>'STANDARD'
,p_step_title=>'Standard'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'26'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2478651649030358724)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_required_role=>wwv_flow_imp.id(2464364414900478475)
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from user_indexes',
'where index_name=''EBA_DEMO_SEARCH_PRODUCTS_CTX'''))
,p_landmark_type=>'search'
,p_landmark_label=>'Products'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4115309318684002349)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(4926226270960679507)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4115309944131002350)
,p_plug_name=>'Search Results'
,p_region_template_options=>'t-ResultsRegion--iconMd'
,p_plug_template=>1555738898046108210
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_plug_required_role=>wwv_flow_imp.id(2464364414900478475)
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from user_indexes',
'where index_name=''EBA_DEMO_SEARCH_PRODUCTS_CTX'''))
,p_landmark_type=>'exclude_landmark'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'custom_layout', 'N',
  'lazy_loading', 'Y',
  'minimum_characters', '0',
  'no_query_entered_message', 'Enter a query to search for products.',
  'no_results_found_message', 'No products found.',
  'results_per_page', '15',
  'results_per_page_type', 'STATIC',
  'search_as_you_type', 'Y',
  'search_page_item', 'P401_SEARCH',
  'show_result_count', 'N',
  'use_pagination', 'Y')).to_clob
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(4115310504805002351)
,p_region_id=>wwv_flow_imp.id(4115309944131002350)
,p_search_config_id=>wwv_flow_imp.id(4115308399795990590)
,p_use_as_initial_result=>false
,p_display_sequence=>10
,p_name=>'Product Search Configuration Oracle Text'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5280451716648816448)
,p_plug_name=>'Oracle Text is not available'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Oracle Text is not available in your workspace. Contact your database administrator to get the <strong>CTXAPP</strong> role granted using the following SQL statement.</p>',
'<pre>grant CTXAPP to #OWNER#;</pre>',
'<p>Then log out and back into the application and revisit this page. </p>'))
,p_plug_required_role=>'!'||wwv_flow_imp.id(2464364414900478475)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5280452369251818938)
,p_plug_name=>'Oracle Text Index does not exist'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<p>Oracle Text is available in your workspace, but the Full Text index does not exist yet.</p>'
,p_plug_required_role=>wwv_flow_imp.id(2464364414900478475)
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from user_indexes',
'where index_name=''EBA_DEMO_SEARCH_PRODUCTS_CTX'''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6602203660966182335)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page demonstrates how to use Oracle Text with Application Search to perform full-text search using linguistic features. An Oracle Text index has been created on your table <em>EBA_DEMO_SEARCH_PRODUCTS</em>. Please refer to the Oracle Text App'
||'lication Developer''s Guide for more information.</p>',
'<p>To configure Oracle Text, in <em>Page Designer,</em> navigate to the <em>Shared Components</em> section, select the <em>Search Configuration</em> referenced by the <em>Search region</em>, and click on "<em>Edit Component</em>" to access the config'
||'uration settings. In the "<em>Index Column Name</em>" attribute, select the table column for which the Oracle Text index has been created.</p>',
'<p>In this example, Oracle Text is configured to search the "<em>Product name</em>" column and "<em>Colour</em>", "<em>Brand</em>", "<em>Gender</em>" and "<em>Description</em>" properties of the JSON column "<em>Product Details</em>". To perform a se'
||'arch, simply type your query (or use one of the examples below), and your query will be automatically processed and translated into Oracle Text query syntax to find <em>exact matches</em>.</p>',
'<p>Query Examples:</p>',
'<ul>',
'<li><em>men</em></li>',
'<li><em>men </em>and<em> red</em></li>',
'<li><em>men </em>or<em> boy</em></li>',
'</ul>'))
,p_plug_required_role=>wwv_flow_imp.id(2464364414900478475)
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from user_indexes',
'where index_name=''EBA_DEMO_SEARCH_PRODUCTS_CTX'''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2464378837553520035)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5280452369251818938)
,p_button_name=>'CREATE_TEXT_INDEX'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Oracle Text index'
,p_button_position=>'NEXT'
,p_security_scheme=>wwv_flow_imp.id(2464364414900478475)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2468380656785685701)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4115309318684002349)
,p_button_name=>'PREV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Previous'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2468380947930687473)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(4115309318684002349)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:402:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4115310978245002351)
,p_name=>'P401_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2478651649030358724)
,p_prompt=>'Search'
,p_placeholder=>'Enter your search term, e.g. ''men and red'''
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_grid_label_column_span=>0
,p_field_template=>2040785906935475274
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_warn_on_unsaved_changes=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'SEARCH',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2474894574475119501)
,p_name=>'Enter key'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P401_SEARCH'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.browserEvent.keyCode === 13',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2474894964729119501)
,p_event_id=>wwv_flow_imp.id(2474894574475119501)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2457701665130262143)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Oracle Text Index'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    eba_demo_search_text_pkg.drop_text_preferences;',
'    eba_demo_search_text_pkg.create_text_preferences;',
'    eba_demo_search_text_pkg.create_text_index;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_security_scheme=>wwv_flow_imp.id(2464364414900478475)
,p_internal_uid=>2440375469771299530
);
wwv_flow_imp.component_end;
end;
/
