prompt --application/pages/page_00101
begin
--   Manifest
--     PAGE: 00101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>606771879342696406
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>101
,p_name=>'Single Search Configuration'
,p_alias=>'SINGLE-SEARCH-CONFIGURATION'
,p_step_title=>'Single Search Configuration'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'26'
,p_last_updated_by=>'YASSINE'
,p_last_upd_yyyymmddhh24miss=>'20230905163712'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2211982463276419911)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(5515774571023413371)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_landmark_type=>'search'
,p_landmark_label=>'Products'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4707756095269566277)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(5515774571023413371)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page demonstrates how to configure and use the <em>Application Search</em> functionality in your application using the <strong>Search Configuration</strong> component.</p>',
'<p>In this example, the Search Configuration is based on a <em>local data source</em> (<strong>EBA_DEMO_SEARCH_PRODUCTS</strong> table) with the following searchable columns: <strong>Product name</strong>, <strong>description</strong>, <strong>brand<'
||'/strong>, <strong>colour</strong>, and <strong>gender</strong>.</p>',
'<p>To search, start typing your query (e.g., "<strong>red</strong>"), the result will update as you type and you will receive a list of all products that contain the word "<strong>red</strong>" within the searchable columns.</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4712054538775592227)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(5515787034162413378)
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(5515671954944413300)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(5515849066147413419)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6333447743122532879)
,p_plug_name=>'Search Results'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(5515771879136413369)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_landmark_type=>'exclude_landmark'
,p_attribute_02=>'N'
,p_attribute_04=>'Y'
,p_attribute_05=>'P101_SEARCH'
,p_attribute_06=>'N'
,p_attribute_11=>'Y'
,p_attribute_12=>'0'
,p_attribute_13=>'Enter a query to search for products.'
,p_attribute_14=>'15'
,p_attribute_15=>'Y'
,p_attribute_16=>'No products found.'
,p_attribute_17=>'STATIC'
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(4703830006336966649)
,p_region_id=>wwv_flow_imp.id(6333447743122532879)
,p_search_config_id=>wwv_flow_imp.id(5515887851535638674)
,p_use_as_initial_result=>false
,p_display_sequence=>10
,p_name=>'Product Search Configuration'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3057817778860362532)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4712054538775592227)
,p_button_name=>'PREV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(5515846799598413417)
,p_button_image_alt=>'Previous'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3057818034470364389)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4712054538775592227)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(5515846799598413417)
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4703829299684966647)
,p_name=>'P101_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2211982463276419911)
,p_prompt=>'Search'
,p_placeholder=>'Enter your search term, e.g. ''red'''
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(5515844727676413416)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'SEARCH'
,p_attribute_05=>'BOTH'
,p_show_quick_picks=>'Y'
,p_quick_pick_label_01=>'red'
,p_quick_pick_value_01=>'red'
,p_quick_pick_label_02=>'jeans'
,p_quick_pick_value_02=>'jeans'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3064332666664833457)
,p_name=>'Enter key'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P101_SEARCH'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.browserEvent.keyCode === 13',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3064333022371833466)
,p_event_id=>wwv_flow_imp.id(3064332666664833457)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1443401167266732025)
,p_name=>'Apply Quick Pick'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P101_SEARCH'
,p_condition_element=>'P101_SEARCH'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1443401484865732029)
,p_event_id=>wwv_flow_imp.id(1443401167266732025)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6333447743122532879)
);
wwv_flow_imp.component_end;
end;
/
