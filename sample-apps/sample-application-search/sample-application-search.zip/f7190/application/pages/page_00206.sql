prompt --application/pages/page_00206
begin
--   Manifest
--     PAGE: 00206
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>2257088492410746
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>206
,p_name=>'Filter Search Configurations'
,p_alias=>'FILTER-SEARCH-CONFIGURATIONS'
,p_step_title=>'Filter Search Configurations'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'26'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1535149751993774335)
,p_plug_name=>'Search Results Container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(4911193821036127668)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2463581008708800124)
,p_plug_name=>'Search'
,p_parent_plug_id=>wwv_flow_imp.id(1535149751993774335)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(4911259780173127711)
,p_plug_display_sequence=>30
,p_landmark_type=>'search'
,p_landmark_label=>'Products and Stores'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4911804035577989383)
,p_plug_name=>'Search Results'
,p_parent_plug_id=>wwv_flow_imp.id(1535149751993774335)
,p_region_template_options=>'t-ResultsRegion--iconMd'
,p_plug_template=>wwv_flow_imp.id(4911257088286127709)
,p_plug_display_sequence=>50
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_ajax_items_to_submit=>'P206_CHECK_GRP'
,p_landmark_type=>'exclude_landmark'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'custom_layout', 'N',
  'lazy_loading', 'Y',
  'minimum_characters', '0',
  'no_query_entered_message', 'Enter a query to search for products or stores.',
  'no_results_found_message', 'No products or stores found.',
  'results_per_page', '15',
  'results_per_page_type', 'STATIC',
  'search_as_you_type', 'Y',
  'search_page_item', 'P206_SEARCH',
  'show_result_count', 'N',
  'use_pagination', 'Y')).to_clob
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(4099367384272745246)
,p_region_id=>wwv_flow_imp.id(4911804035577989383)
,p_search_config_id=>wwv_flow_imp.id(4911381012958816148)
,p_use_as_initial_result=>false
,p_display_sequence=>10
,p_name=>'Store Search Configuration'
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>':P206_CHECK_GRP like ''%S%'''
,p_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(4099366851224745245)
,p_region_id=>wwv_flow_imp.id(4911804035577989383)
,p_search_config_id=>wwv_flow_imp.id(4911380632574778422)
,p_use_as_initial_result=>false
,p_display_sequence=>20
,p_name=>'Product Search Configuration'
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>':P206_CHECK_GRP like ''%P%'''
,p_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4911803386534989382)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(4911272243312127718)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(4911157164094127640)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(4911334275297127759)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6587133137431617359)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(4911259780173127711)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page demonstrates how to refine search results using <em>filters</em> to narrow down the results.</p>',
'<p>In this example, you can check the <strong>Stores checkbox</strong> to show only the results from the <em>Store Search Configuration,</em> or check the <strong>Products checkbox</strong> to show only the results from the <em>Product Search Configu'
||'ration</em>.</p>',
'<p>To test this functionality, start typing your search term (or "<strong>Sea</strong>" for example) and try filtering the results.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2453307159381103456)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4911803386534989382)
,p_button_name=>'PREV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(4911332008748127757)
,p_button_image_alt=>'Previous'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:204:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2453307502141105427)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4911803386534989382)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(4911332008748127757)
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2442633154237710282)
,p_name=>'P206_CHECK_GRP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2463581008708800124)
,p_item_default=>'P:S'
,p_prompt=>'Search Within'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Search Products;P,Search Stores;S'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(4911329936826127756)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4099365366257745244)
,p_name=>'P206_SEARCH'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2463581008708800124)
,p_prompt=>'Search'
,p_placeholder=>'Enter your search term, e.g. ''Sea'''
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(4911329936826127756)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2442633292761710283)
,p_name=>'Check'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P206_CHECK_GRP'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2442633344612710284)
,p_event_id=>wwv_flow_imp.id(2442633292761710283)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4911804035577989383)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2459823175242559442)
,p_name=>'Enter key'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P206_SEARCH'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.browserEvent.keyCode === 13',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2459823599222559442)
,p_event_id=>wwv_flow_imp.id(2459823175242559442)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp.component_end;
end;
/
