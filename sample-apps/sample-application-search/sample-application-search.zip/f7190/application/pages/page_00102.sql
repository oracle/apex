prompt --application/pages/page_00102
begin
--   Manifest
--     PAGE: 00102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>2257088492410746
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>102
,p_name=>'Multiple Search Configurations'
,p_alias=>'MULTIPLE-SEARCH-CONFIGURATIONS'
,p_step_title=>'Multiple Search Configurations'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'26'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2463579090627793207)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(4911259780173127711)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_landmark_type=>'search'
,p_landmark_label=>'Products and Stores'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4911415023359946321)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(4911272243312127718)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(4911157164094127640)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(4911334275297127759)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4911415597917946322)
,p_plug_name=>'Search Results'
,p_region_template_options=>'t-ResultsRegion--iconMd'
,p_plug_template=>wwv_flow_imp.id(4911257088286127709)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_landmark_type=>'exclude_landmark'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'custom_layout', 'N',
  'lazy_loading', 'Y',
  'minimum_characters', '0',
  'no_query_entered_message', 'Enter a query to search for products or stores.',
  'no_results_found_message', 'No products or stores found.',
  'overall_sort', 'TITLE',
  'results_per_page', '15',
  'results_per_page_type', 'STATIC',
  'search_as_you_type', 'Y',
  'search_page_item', 'P102_SEARCH',
  'show_result_count', 'N',
  'sort_direction', 'DESC',
  'use_pagination', 'Y')).to_clob
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(4099319758481687577)
,p_region_id=>wwv_flow_imp.id(4911415597917946322)
,p_search_config_id=>wwv_flow_imp.id(4911381012958816148)
,p_use_as_initial_result=>false
,p_display_sequence=>10
,p_name=>'Store Search Configuration'
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(4099319210524687576)
,p_region_id=>wwv_flow_imp.id(4911415597917946322)
,p_search_config_id=>wwv_flow_imp.id(4911380632574778422)
,p_use_as_initial_result=>false
,p_display_sequence=>20
,p_name=>'Product Search Configuration'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4931201924812613178)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(4911259780173127711)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page demonstrates how to use the <strong>Search Region</strong>, which can reference multiple Search Configurations, enabling searches across multiple data sources simultaneously.</p>',
'<p>In this example, two Search Configurations have been created: <strong>Product Search Configuration</strong>&nbsp;and <strong>Store Search Configuration</strong>. These configurations are referenced in the Search region as search sources.</p>',
'<p>To perform a search, simply type your query into the query box (e.g., "<strong>Sea</strong>"). The associated search configurations will then be executed, returning all relevant results displayed in the Search region.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2453303555654080435)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4911415023359946321)
,p_button_name=>'PREV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(4911332008748127757)
,p_button_image_alt=>'Previous'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2453303875224081943)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4911415023359946321)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(4911332008748127757)
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4099318519605687576)
,p_name=>'P102_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2463579090627793207)
,p_prompt=>'Search'
,p_placeholder=>'Enter your search term, e.g. ''Sea'''
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(4911329936826127756)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'SEARCH'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2459818647760549536)
,p_name=>'Enter key'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P102_SEARCH'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.browserEvent.keyCode === 13',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2459819070059549537)
,p_event_id=>wwv_flow_imp.id(2459818647760549536)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp.component_end;
end;
/
