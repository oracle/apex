prompt --workspace/credentials/tmdb_api_key
begin
--   Manifest
--     CREDENTIAL: TMDb API Key
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7190
,p_default_id_offset=>768993839755884678
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(2449648640819388646)
,p_name=>'TMDb API Key'
,p_static_id=>'tmdb_api_key'
,p_authentication_type=>'HTTP_QUERY_STRING'
,p_valid_for_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://api.themoviedb.org/3/',
''))
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
