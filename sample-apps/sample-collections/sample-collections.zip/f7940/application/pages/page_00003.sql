prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(1121389871104511367)
,p_name=>'Modify Collection'
,p_alias=>'MODIFY-COLLECTION'
,p_step_title=>'Modify Collection'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_api.id(1774844326834936459)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210301103343'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1318677074012387622)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1774862430658936498)
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1318675881153380306)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1774883299498936583)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1713164352515995054)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1774849216241936469)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>Use this page to add members (records) into your collection. Note that this application does not use all of the fields available in APEX collections.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8866776014061211253)
,p_plug_name=>'Collection'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1774859855390936493)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_column_width=>'valign=top'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8866777310827212764)
,p_plug_name=>'Member Attributes'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(1774859855390936493)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8866793219358220219)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(1318677074012387622)
,p_button_name=>'Cancel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1774883187200936581)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8866957797229934597)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1318677074012387622)
,p_button_name=>'Add_Member_Add_Another'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1774883187200936581)
,p_button_image_alt=>'Add Member & Add Another'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8866814719751248727)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(1318677074012387622)
,p_button_name=>'Add_Member'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1774883187200936581)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Member'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8866974021171969857)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8866776014061211253)
,p_button_name=>'Truncate_Collection'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1774883187200936581)
,p_button_image_alt=>'Truncate Collection'
,p_button_position=>'REGION_TEMPLATE_EDIT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8866981399831973146)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8866776014061211253)
,p_button_name=>'Delete_Collection'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>wwv_flow_api.id(1774883187200936581)
,p_button_image_alt=>'Delete Collection'
,p_button_position=>'REGION_TEMPLATE_EDIT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8866993113814986607)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8866776014061211253)
,p_button_name=>'Resequence'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1774883187200936581)
,p_button_image_alt=>'Resequence'
,p_button_position=>'REGION_TEMPLATE_EDIT'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8866958213645934607)
,p_branch_action=>'3'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_STEP'
,p_branch_when_button_id=>wwv_flow_api.id(8866957797229934597)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8866796421813222882)
,p_branch_action=>'1'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_STEP'
,p_branch_sequence=>20
,p_branch_comment=>'Created 16-JUL-2002 15:56 by JOEL'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8396234424309594330)
,p_name=>'P3_DATE_ATTR1'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(8866777310827212764)
,p_prompt=>'Date Attribute 1'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'Y'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8396234715436601231)
,p_name=>'P3_DATE_ATTR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(8866777310827212764)
,p_prompt=>'Date Attribute 2'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'Y'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8396234922709603275)
,p_name=>'P3_DATE_ATTR3'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(8866777310827212764)
,p_prompt=>'Date Attribute 3'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'Y'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8429614647541691269)
,p_name=>'P3_NUM_ATTR1'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(8866777310827212764)
,p_prompt=>'Numeric Attribute 1'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'Y'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8429614845977691270)
,p_name=>'P3_NUM_ATTR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(8866777310827212764)
,p_prompt=>'Numeric Attribute 2'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'Y'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8429615034731691270)
,p_name=>'P3_NUM_ATTR3'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(8866777310827212764)
,p_prompt=>'Numeric Attribute 3'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'Y'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8866786406082214991)
,p_name=>'P3_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8866776014061211253)
,p_prompt=>'Collection Name'
,p_source=>'P2_NAME'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8866800010599228047)
,p_name=>'P3_ATTR1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(8866777310827212764)
,p_prompt=>'Character Attribute 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8866802306501230000)
,p_name=>'P3_ATTR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(8866777310827212764)
,p_prompt=>'Character Attribute 2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8866804601756232157)
,p_name=>'P3_ATTR3'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(8866777310827212764)
,p_prompt=>'Character Attribute 3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8866806897443234127)
,p_name=>'P3_ATTR4'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(8866777310827212764)
,p_prompt=>'Character Attribute 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8866809193346236003)
,p_name=>'P3_ATTR5'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(8866777310827212764)
,p_prompt=>'Character Attribute 5'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(8867000613690995552)
,p_validation_name=>'Collection Name not null'
,p_validation_sequence=>10
,p_validation=>'P3_NAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Collection name cannot be null'
,p_validation_condition=>':REQUEST in (''Truncate_Collection'',''Delete_Collection'',''Resequence'',''Add_Member'',''Add_Member_Add_Another'')'
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_associated_item=>wwv_flow_api.id(8866786406082214991)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8866821999791263447)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add Member'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--',
'-- This application uses the Application Level Date format to control the default date format for the application.',
'-- Without this, then you would need to specify explict date format masks in the TO_DATE conversions.',
'apex_collection.add_member(',
'    p_collection_name => :P3_NAME,',
'    p_c001            => :P3_ATTR1,',
'    p_c002            => :P3_ATTR2,',
'    p_c003            => :P3_ATTR3,',
'    p_c004            => :P3_ATTR4,',
'    p_c005            => :P3_ATTR5,',
'    p_n001            => :P3_NUM_ATTR1,',
'    p_n002            => :P3_NUM_ATTR2,',
'    p_n003            => :P3_NUM_ATTR3,',
'    p_d001            => to_date(:P3_DATE_ATTR1),',
'    p_d002            => to_date(:P3_DATE_ATTR2),',
'    p_d003            => to_date(:P3_DATE_ATTR3),',
'    p_generate_md5    => ''YES'' );',
'commit;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error adding member to collection <b>&P3_NAME.</b>.'
,p_process_when=>':REQUEST in (''Add_Member'',''Add_Member_Add_Another'')'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'SQL'
,p_process_success_message=>'Successfully added member to collection <b>&P3_NAME.</b>.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8867114121497204602)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Resequence'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_collection.resequence_collection(',
'    p_collection_name => :P3_NAME );',
'commit;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error resequencing members in collection <b>&P3_NAME.</b>.'
,p_process_when_button_id=>wwv_flow_api.id(8866993113814986607)
,p_process_success_message=>'Successfully resequenced members in collection <b>&P3_NAME.</b>.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8867118501872213764)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Collection'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_collection.delete_collection(',
'    p_collection_name => :P3_NAME );',
'--',
'commit;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error deleting collection <b>&P3_NAME.</b>.'
,p_process_when_button_id=>wwv_flow_api.id(8866981399831973146)
,p_process_success_message=>'Successfully deleted collection <b>&P3_NAME.</b>.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8867181195690657249)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Truncate Collection'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_collection.truncate_collection(',
'    p_collection_name => :P3_NAME );',
'--',
'commit;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error truncating collection <b>&P3_NAME.</b>.'
,p_process_when_button_id=>wwv_flow_api.id(8866974021171969857)
,p_process_success_message=>'Successfully truncated collection <b>&P3_NAME.</b>.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7960446708983693505)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Cache'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
