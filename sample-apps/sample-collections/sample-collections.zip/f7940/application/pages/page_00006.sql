prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Data Synchronization'
,p_alias=>'EMP'
,p_step_title=>'Data Synchronization'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(1774844326834936459)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20221011155744'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1318677957866392433)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1774862430658936498)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(1318675881153380306)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(1774883299498936583)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2532921754471244952)
,p_plug_name=>'Container'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(1774859855390936493)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1320262356690406695)
,p_plug_name=>'EBA_DEMO_CS_EMP table SQL Source'
,p_parent_plug_id=>wwv_flow_imp.id(2532921754471244952)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(1774855849259936482)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.DISPLAY_SOURCE'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'emp_table'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(8867311097445884349)
,p_name=>'EBA_DEMO_CS_EMP table'
,p_region_name=>'emp_table'
,p_parent_plug_id=>wwv_flow_imp.id(2532921754471244952)
,p_template=>wwv_flow_imp.id(1774859855390936493)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select empno, ename, job, mgr, hiredate, sal, comm, deptno',
'  from eba_demo_cs_emp'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(1774869560539936527)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_ignore_pagination=>0
,p_query_num_rows_type=>'ROWS_X_TO_Y_OF_Z'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'F'
,p_query_asc_image=>'blue_arrow_down.gif'
,p_query_desc_image=>'blue_arrow_up.gif'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8789915888382584100)
,p_query_column_id=>1
,p_column_alias=>'EMPNO'
,p_column_display_sequence=>1
,p_column_heading=>'EmpNo'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8789915976622584100)
,p_query_column_id=>2
,p_column_alias=>'ENAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8789916071544584100)
,p_query_column_id=>3
,p_column_alias=>'JOB'
,p_column_display_sequence=>3
,p_column_heading=>'Job'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8789916188087584100)
,p_query_column_id=>4
,p_column_alias=>'MGR'
,p_column_display_sequence=>4
,p_column_heading=>'Manager'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8789916289253584100)
,p_query_column_id=>5
,p_column_alias=>'HIREDATE'
,p_column_display_sequence=>5
,p_column_heading=>'Hire&nbsp;Date'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8789916377423584100)
,p_query_column_id=>6
,p_column_alias=>'SAL'
,p_column_display_sequence=>6
,p_column_heading=>'Salary'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8789916463263584100)
,p_query_column_id=>7
,p_column_alias=>'COMM'
,p_column_display_sequence=>7
,p_column_heading=>'Commission'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8789916558856584101)
,p_query_column_id=>8
,p_column_alias=>'DEPTNO'
,p_column_display_sequence=>8
,p_column_heading=>'DeptNo'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(8867323199158898707)
,p_name=>'EMP Collection'
,p_region_name=>'emp_collection'
,p_template=>wwv_flow_imp.id(1774859855390936493)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select seq_id editlink,',
'    seq_id, ',
'    n001, ',
'    n002, ',
'    n003, ',
'    n004, ',
'    d001, ',
'    c001, ',
'    c002, ',
'    c003, ',
'    c004 status',
'from apex_collections',
'where collection_name = ''EMPCOLLECTION''',
''))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(1774869560539936527)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_ignore_pagination=>0
,p_query_num_rows_type=>'ROWS_X_TO_Y_OF_Z'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'F'
,p_query_asc_image=>'blue_arrow_down.gif'
,p_query_desc_image=>'blue_arrow_up.gif'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8789916662580584112)
,p_query_column_id=>1
,p_column_alias=>'EDITLINK'
,p_column_display_sequence=>1
,p_column_heading=>'Action'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:7:P7_SEQ,P7_STATUS:#SEQ_ID#,#STATUS#'
,p_column_linktext=>'Edit'
,p_column_link_attr=>'class="t-Button t-Button--warning"'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8789916760475584113)
,p_query_column_id=>2
,p_column_alias=>'SEQ_ID'
,p_column_display_sequence=>2
,p_column_heading=>'Sequence'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8430611147996219687)
,p_query_column_id=>3
,p_column_alias=>'N001'
,p_column_display_sequence=>3
,p_column_heading=>'EmpNo'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8430611221291219688)
,p_query_column_id=>4
,p_column_alias=>'N002'
,p_column_display_sequence=>8
,p_column_heading=>'Salary'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8430611334392219688)
,p_query_column_id=>5
,p_column_alias=>'N003'
,p_column_display_sequence=>9
,p_column_heading=>'Commission'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8430611420069219688)
,p_query_column_id=>6
,p_column_alias=>'N004'
,p_column_display_sequence=>10
,p_column_heading=>'DeptNo'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8396259517972510109)
,p_query_column_id=>7
,p_column_alias=>'D001'
,p_column_display_sequence=>7
,p_column_heading=>'Hire Date'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8789916864274584113)
,p_query_column_id=>8
,p_column_alias=>'C001'
,p_column_display_sequence=>4
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8789916979756584113)
,p_query_column_id=>9
,p_column_alias=>'C002'
,p_column_display_sequence=>5
,p_column_heading=>'Job'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8789917073866584113)
,p_query_column_id=>10
,p_column_alias=>'C003'
,p_column_display_sequence=>6
,p_column_heading=>'Manager'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8789917684623584113)
,p_query_column_id=>11
,p_column_alias=>'STATUS'
,p_column_display_sequence=>11
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(1330719884636063179)
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'NO'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1320262062513404081)
,p_plug_name=>'EMP Collection SQL Source'
,p_parent_plug_id=>wwv_flow_imp.id(8867323199158898707)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_region_attributes=>'style="margin-left: 8px;"'
,p_plug_template=>wwv_flow_imp.id(1774855849259936482)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.DISPLAY_SOURCE'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'emp_collection'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8867561809411547367)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(1124325436919460426)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This use case populates an Oracle APEX collection from a sample Employees table, the user updates the collection, and then synchroniz',
'es the data in the collection with the base table.  To use this example, please follow the instructions below.</p>',
'<ol>',
'<li>Populate the collection from the EBA_DEMO_CS_EMP table',
'<li>Add, Delete, and Update members in the collection',
'<li>Synchronize the members of the collection with the EBA_DEMO_CS_EMP table by clicking the "Apply Collection" button',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_column_width=>'valign=top'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8867339210509922427)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8867323199158898707)
,p_button_name=>'Populate'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1774883187200936581)
,p_button_image_alt=>'Populate Collection from EBA_DEMO_CS_EMP '
,p_button_position=>'EDIT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8867458202330279669)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8867323199158898707)
,p_button_name=>'Add_Member'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1774883187200936581)
,p_button_image_alt=>'Add Member'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:RP,7::'
,p_button_condition=>'apex_collection.collection_exists(''EMPCOLLECTION'')'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8867390012596998747)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(8867323199158898707)
,p_button_name=>'Apply_Collection'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1774883187200936581)
,p_button_image_alt=>'Apply Collection'
,p_button_position=>'EDIT'
,p_button_condition=>'apex_collection.collection_exists(''EMPCOLLECTION'')'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8867390395168998749)
,p_branch_name=>'Go To Page 6'
,p_branch_action=>'6'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_STEP'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8867343607316940563)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Populate'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_rowxml varchar2(4000);',
'begin',
'if apex_collection.collection_exists( ''EMPCollection'') = TRUE then',
'    --',
'    apex_collection.delete_collection(',
'        p_collection_name => ''EMPCollection'' );',
'end if;',
'--',
'apex_collection.create_collection_from_query2(',
'    p_collection_name => ''EMPCollection'',',
'    p_query           => ''select empno, sal, comm, deptno, null, hiredate, null, null, null, null, ename, job, mgr, ''''O'''' original_flag from eba_demo_cs_emp order by ename'',',
'    p_generate_md5    => ''YES'');',
'--',
'for c1 in (select n001 empno, seq_id',
'             from apex_collections',
'            where collection_name = ''EMPCOLLECTION''',
'           order by seq_id) loop',
'    ',
'    l_rowxml := dbms_xmlgen.getxml( ''select * from eba_demo_cs_emp where empno = '' || c1.empno );',
'    apex_collection.update_member_attribute( ',
'        p_collection_name => ''EMPCollection'',',
'        p_seq             => c1.seq_id,',
'        p_xmltype_number  => 1,',
'        p_xmltype_value   => XMLType(l_rowxml));',
'end loop;',
'--',
'commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(8867339210509922427)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8867535412695485016)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Apply changes to EBA_DEMO_CS_EMP table'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--',
'-- Loop through all the members of the collection.  For those that are still',
'-- marked as Original, they have not changed, so no changes need to be applied.',
'-- For those marked as updated, deleted, or new, issue the appropriate DML',
'-- against the SCOTT.EMP table.',
'--',
'for c1 in (select c001, c002, c003, c004, d001, n001, n002, n003, n004',
'             from apex_collections',
'            where collection_name = ''EMPCOLLECTION'') loop',
'    if c1.c004 = ''N'' then',
'        insert into eba_demo_cs_emp (empno, ename, job, mgr, hiredate, sal, comm, deptno)',
'        values (c1.n001, c1.c001, c1.c002, c1.c003, c1.d001, c1.n002, c1.n003, c1.n004 );',
'',
'    elsif c1.c004 = ''U'' then',
'        update eba_demo_cs_emp',
'           set ename    = c1.c001,',
'               job      = c1.c002,',
'               mgr      = c1.c003,',
'               hiredate = c1.d001,',
'               sal      = c1.n002,',
'               comm     = c1.n003,',
'               deptno   = c1.n004',
'         where empno = c1.n001;',
'',
'    elsif c1.c004 = ''D'' then',
'        delete from eba_demo_cs_emp',
'         where empno = c1.n001;',
'',
'    end if;',
'end loop;',
'--',
'-- Clear the contents of the collection',
'--',
'apex_collection.delete_collection( p_collection_name => ''EMPCOLLECTION'' );',
'--',
'commit;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error applying changes to the database table.'
,p_process_when_button_id=>wwv_flow_imp.id(8867390012596998747)
,p_process_success_message=>'Successfully applied changes to the database table.'
);
wwv_flow_imp.component_end;
end;
/
