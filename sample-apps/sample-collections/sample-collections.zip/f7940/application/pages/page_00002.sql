prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Create Collection'
,p_alias=>'CREATE-COLLECTION'
,p_page_mode=>'MODAL'
,p_step_title=>'Create Collection'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(1774846340824936463)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'16'
,p_last_upd_yyyymmddhh24miss=>'20230110134707'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1713164201739995053)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(1774849395965936471)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8866716089470964392)
,p_plug_name=>'Collection'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1774849216241936469)
,p_plug_display_sequence=>10
,p_plug_column_width=>'valign=top'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8866728403268979008)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1713164201739995053)
,p_button_name=>'Create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1774883187200936581)
,p_button_image_alt=>'Create Collection'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8866731010540981114)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1713164201739995053)
,p_button_name=>'Create_Replace'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1774883187200936581)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create/Replace Collection'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8866723014911972908)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1713164201739995053)
,p_button_name=>'Cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1774883187200936581)
,p_button_image_alt=>'Cancel'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8866723400571972910)
,p_branch_action=>'3'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_STEP'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8866718417709966497)
,p_name=>'P2_NAME'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8866716089470964392)
,p_prompt=>'Collection Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_imp.id(274822744073356429)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8866745713371998896)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_collection.create_collection( p_collection_name => :P2_NAME );',
'commit;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error creating collection <b>&P2_NAME.</b>.'
,p_process_when_button_id=>wwv_flow_imp.id(8866728403268979008)
,p_process_success_message=>'Successfully created collection <b>&P2_NAME.</b>.'
,p_internal_uid=>8866745713371998896
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1156315145607388521)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create on Return Key Submit'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_collection.create_collection( p_collection_name => :P2_NAME );',
'commit;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error creating collection <b>&P2_NAME.</b>.'
,p_process_when=>'P2_NAME'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'Successfully created collection <b>&P2_NAME.</b>.'
,p_internal_uid=>1156315145607388521
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8866750420045010910)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create/Replace'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_collection.create_or_truncate_collection( p_collection_name => :P2_NAME );',
'commit;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error creating/replacing collection <b>&P2_NAME.</b>.'
,p_process_when_button_id=>wwv_flow_imp.id(8866731010540981114)
,p_process_success_message=>'Successfully created/replaced collection <b>&P2_NAME.</b>.'
,p_internal_uid=>8866750420045010910
);
wwv_flow_imp.component_end;
end;
/
