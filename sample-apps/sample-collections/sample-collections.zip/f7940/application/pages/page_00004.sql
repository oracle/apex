prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(1121389871104511367)
,p_name=>'Modify Collection Member'
,p_alias=>'MODIFY-COLLECTION-MEMBER'
,p_page_mode=>'MODAL'
,p_step_title=>'Modify Collection Member'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_api.id(1774846340824936463)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210301103343'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1713164403465995055)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1774849216241936469)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<p>Use this page to modify a member of the collection.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1713164471262995056)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_api.id(1774849395965936471)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8867020310875012064)
,p_plug_name=>'Collection Member'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:t-Region--hideHeader:t-Region--noBorder'
,p_plug_template=>wwv_flow_api.id(1774859855390936493)
,p_plug_display_sequence=>30
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8867102496481180374)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(1713164471262995056)
,p_button_name=>'Delete_Member'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>wwv_flow_api.id(1774883187200936581)
,p_button_image_alt=>'Delete Member'
,p_button_position=>'NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8867057500403039552)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(1713164471262995056)
,p_button_name=>'Update_Member'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1774883187200936581)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update Member'
,p_button_position=>'NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8867052915163034328)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1713164471262995056)
,p_button_name=>'Cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(1774883187200936581)
,p_button_image_alt=>'Cancel'
,p_button_position=>'PREVIOUS'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(8867053307023034330)
,p_branch_action=>'1'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_STEP'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8396237331806662669)
,p_name=>'P4_DATE_ATTR1'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(8867020310875012064)
,p_prompt=>'Date Attribute 1'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8396237612198666519)
,p_name=>'P4_DATE_ATTR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(8867020310875012064)
,p_prompt=>'Date Attribute 2'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8396237822933669574)
,p_name=>'P4_DATE_ATTR3'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(8867020310875012064)
,p_prompt=>'Date Attribute 3'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8430615644870493172)
,p_name=>'P4_NUM_ATTR1'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(8867020310875012064)
,p_prompt=>'Numeric Attribute 1'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8430615925954497108)
,p_name=>'P4_NUM_ATTR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(8867020310875012064)
,p_prompt=>'Numeric Attribute 2'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8430616131495498701)
,p_name=>'P4_NUM_ATTR3'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(8867020310875012064)
,p_prompt=>'Numeric Attribute 3'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8430616951496523431)
,p_name=>'P4_XMLTYPE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(8867020310875012064)
,p_prompt=>'XMLType'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(1774882318212936569)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Enter a well-formed XML fragment or document.'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8867022603111015641)
,p_name=>'P4_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(8867020310875012064)
,p_prompt=>'Name'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8867028297504018253)
,p_name=>'P4_SEQ'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(8867020310875012064)
,p_prompt=>'Sequence'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8867034219704023197)
,p_name=>'P4_ATTR1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(8867020310875012064)
,p_prompt=>'Character Attribute 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8867038216038024836)
,p_name=>'P4_ATTR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(8867020310875012064)
,p_prompt=>'Character Attribute 2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8867040512803026350)
,p_name=>'P4_ATTR3'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(8867020310875012064)
,p_prompt=>'Character Attribute 3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8867044509784027757)
,p_name=>'P4_ATTR4'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(8867020310875012064)
,p_prompt=>'Character Attribute 4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8867047306118029408)
,p_name=>'P4_ATTR5'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(8867020310875012064)
,p_prompt=>'Character Attribute 5'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_api.id(1774882198755936568)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(229026122705043465)
,p_name=>'Cancel Modal'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(8867052915163034328)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(229026220236043466)
,p_event_id=>wwv_flow_api.id(229026122705043465)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8867096911004118350)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Populate form'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--',
'-- Given the values supplied for collection name and sequence,',
'-- fetch the values from the Collections database view',
'-- and populate the items on the page',
'--',
'for c1 in ( select c001, c002, c003, c004, c005, n001, n002, n003, d001, d002, d003, xmltype001',
'              from apex_collections',
'             where collection_name = :P4_NAME',
'               and seq_id = :P4_SEQ ) loop',
'    :P4_ATTR1 := c1.c001;',
'    :P4_ATTR2 := c1.c002;',
'    :P4_ATTR3 := c1.c003;',
'    :P4_ATTR4 := c1.c004;',
'    :P4_ATTR5 := c1.c005;',
'    :P4_NUM_ATTR1 := c1.n001;',
'    :P4_NUM_ATTR2 := c1.n002;',
'    :P4_NUM_ATTR3 := c1.n003;',
'    :P4_DATE_ATTR1 := c1.d001;',
'    :P4_DATE_ATTR2 := c1.d002;',
'    :P4_DATE_ATTR3 := c1.d003;',
'    if c1.xmltype001 is not null then',
'        :P4_XMLTYPE   := xmltype.extract(c1.xmltype001,''/'').getstringval();',
'    end if;',
'  ',
'    exit;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8867072410838057677)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update Member'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_xmltype xmltype := null;',
'begin',
'    if :P4_XMLTYPE is not null then',
'        l_xmltype := xmltype( :P4_XMLTYPE );',
'    end if;',
'    --',
'    --',
'    -- This application uses the Application Level Date format to control the default date format for the application.',
'    -- Without this, then you would need to specify explict date format masks in the TO_DATE conversions.',
'    --',
'    apex_collection.update_member(',
'        p_collection_name => :P4_NAME,',
'        p_seq             => :P4_SEQ,',
'        p_c001            => :P4_ATTR1,',
'        p_c002            => :P4_ATTR2,',
'        p_c003            => :P4_ATTR3,',
'        p_c004            => :P4_ATTR4,',
'        p_c005            => :P4_ATTR5,',
'        p_n001            => :P4_NUM_ATTR1,',
'        p_n002            => :P4_NUM_ATTR2,',
'        p_n003            => :P4_NUM_ATTR3,',
'        p_d001            => to_date(:P4_DATE_ATTR1),',
'        p_d002            => to_date(:P4_DATE_ATTR2),',
'        p_d003            => to_date(:P4_DATE_ATTR3),',
'        p_xmltype001      => l_xmltype );',
'    commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error updating member <b>&P4_SEQ.</b> in collection <b>&P4_NAME.</b>.'
,p_process_when_button_id=>wwv_flow_api.id(8867057500403039552)
,p_process_success_message=>'Successfully updated member <b>&P4_SEQ.</b> in collection <b>&P4_NAME.</b>.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(8867105393702187191)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Member'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_collection.delete_member(',
'    p_collection_name => :P4_NAME,',
'    p_seq             => :P4_SEQ );',
'--',
'commit;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error deleting member <b>&P4_SEQ.</b> in collection <b>&P4_NAME.</b>.'
,p_process_when_button_id=>wwv_flow_api.id(8867102496481180374)
,p_process_success_message=>'Successfully deleted member <b>&P4_SEQ.</b> in collection <b>&P4_NAME.</b>.'
);
wwv_flow_api.component_end;
end;
/
