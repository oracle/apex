prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>12
,p_user_interface_id=>wwv_flow_api.id(1121389871104511367)
,p_tab_set=>'TS1'
,p_name=>'Sample Collections - API Examples'
,p_alias=>'SAMPLE-COLLECTIONS-API-EXAMPLES'
,p_step_title=>'Sample Collections - API Syntax'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_step_template=>wwv_flow_api.id(1774844326834936459)
,p_page_template_options=>'#DEFAULT#'
,p_nav_list_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210922145247'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1299653654729546636)
,p_plug_name=>'apex_collection.create_or_truncate_collection'
,p_plug_template=>wwv_flow_api.id(1774859855390936493)
,p_plug_display_sequence=>20
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>apex_collection.create_or_truncate_collection( p_collection_name => :P2_NAME );',
'commit;</pre>'))
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1299654061318624260)
,p_plug_name=>'apex_collection.add_member'
,p_plug_template=>wwv_flow_api.id(1774859855390936493)
,p_plug_display_sequence=>30
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'--',
'-- This application uses the Application Level Date format to control the default date format for the application.',
'-- Without this, then you would need to specify explict date format masks in the TO_DATE conversions.',
'--',
'apex_collection.add_member(',
'    p_collection_name => :P3_NAME,',
'    p_c001            => :P3_ATTR1,',
'    p_c002            => :P3_ATTR2,',
'    p_c003            => :P3_ATTR3,',
'    p_c004            => :P3_ATTR4,',
'    p_c005            => :P3_ATTR5,',
'    p_n001            => :P3_NUM_ATTR1,',
'    p_n002            => :P3_NUM_ATTR2,',
'    p_n003            => :P3_NUM_ATTR3,',
'    p_d001            => to_date(:P3_DATE_ATTR1),',
'    p_d002            => to_date(:P3_DATE_ATTR2),',
'    p_d003            => to_date(:P3_DATE_ATTR3),',
'    p_generate_md5    => ''YES'' );',
'commit;',
'</pre>'))
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1299654458332632867)
,p_plug_name=>'apex_collection.resequence_collection'
,p_plug_template=>wwv_flow_api.id(1774859855390936493)
,p_plug_display_sequence=>40
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>apex_collection.resequence_collection(',
'    p_collection_name => :P3_NAME );',
'commit;',
'</pre>'))
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1299654782227639702)
,p_plug_name=>'apex_collection.delete_collection'
,p_plug_template=>wwv_flow_api.id(1774859855390936493)
,p_plug_display_sequence=>50
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>apex_collection.delete_collection(',
'    p_collection_name => :P3_NAME );',
'--',
'commit;',
'</pre>'))
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1299655264004643973)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1774849216241936469)
,p_plug_display_sequence=>10
,p_plug_new_grid_column=>false
,p_plug_source=>'<p>This page lists some of the PL/SQL page processes used in this demonstration application.</p>'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1299656971754655691)
,p_plug_name=>'apex_collection.truncate_collection'
,p_plug_template=>wwv_flow_api.id(1774859855390936493)
,p_plug_display_sequence=>60
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>apex_collection.truncate_collection (',
'    p_collection_name => :P3_NAME );',
'--',
'commit;',
'</pre>'))
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1299657968252701919)
,p_plug_name=>'apex_collections'
,p_plug_template=>wwv_flow_api.id(1774859855390936493)
,p_plug_display_sequence=>70
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>select seq_id editlink,',
'    seq_id, ',
'    n001, ',
'    n002, ',
'    n003, ',
'    n004, ',
'    d001, ',
'    c001, ',
'    c002, ',
'    c003, ',
'    c004 status',
'from apex_collections',
'where collection_name = ''EMPCOLLECTION''',
'</pre>'))
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1318679280376398958)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1774862430658936498)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1318675881153380306)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(1774883299498936583)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1330859070390380808)
,p_plug_name=>'apex_collection.create_collection_from_query2'
,p_plug_template=>wwv_flow_api.id(1774859855390936493)
,p_plug_display_sequence=>80
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>apex_collection.create_collection_from_query2(',
'    p_collection_name => ''EMPCollection'',',
'    p_query           => ''select empno, sal, comm, deptno, null, hiredate, null, null, null, null, ename, job, mgr, ''''O'''' original_flag from eba_demo_cs_emp order by ename'',',
'    p_generate_md5    => ''YES'');',
'</pre>'))
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1330859360478387467)
,p_plug_name=>'apex_collection.update_member_attribute'
,p_plug_template=>wwv_flow_api.id(1774859855390936493)
,p_plug_display_sequence=>90
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'for c1 in (select n001 empno, seq_id',
'             from apex_collections',
'            where collection_name = ''EMPCOLLECTION''',
'           order by seq_id) loop',
'    ',
'    l_rowxml := dbms_xmlgen.getxml( ''select * from eba_demo_cs_emp where empno = '' || c1.empno );',
'    apex_collection.update_member_attribute( ',
'        p_collection_name => ''EMPCollection'',',
'        p_seq             => c1.seq_id,',
'        p_xmltype_number  => 1,',
'        p_xmltype_value   => XMLType(l_rowxml));',
'end loop;',
'</pre>'))
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_api.component_end;
end;
/
