prompt --application/shared_components/navigation/lists/collection_examples
begin
--   Manifest
--     LIST: Collection Examples
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7940
,p_default_id_offset=>10243121705511410
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1328912986526782911)
,p_name=>'Collection Examples'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089080320
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1328913183281782911)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Basic Collections'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-archive'
,p_list_text_01=>'Creating a Basic Collection.  Create a user defined collection name on a simple Employee table structure.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1328913481305782911)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Data Synchronization'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-spinner'
,p_list_text_01=>'Populate a collection from a sample Employees table, update the collection, and then synchronize the data in the collection with the base table.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1328918277078843503)
,p_list_item_display_sequence=>22
,p_list_item_link_text=>'API Examples'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-keyboard-o'
,p_list_text_01=>'View Oracle APEX API examples which you can use in your own application.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
