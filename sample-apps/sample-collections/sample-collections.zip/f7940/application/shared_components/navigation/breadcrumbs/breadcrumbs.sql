prompt --application/shared_components/navigation/breadcrumbs/breadcrumbs
begin
--   Manifest
--     MENU: breadcrumbs
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_menu(
 p_id=>wwv_flow_api.id(1318675881153380306)
,p_name=>'breadcrumbs'
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1318676266481382465)
,p_parent_id=>0
,p_short_name=>'Basic Collections'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1318676652269384290)
,p_short_name=>'Home'
,p_link=>'f?p=&FLOW_ID.:100:&SESSION.'
,p_page_id=>100
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1318677376398387629)
,p_parent_id=>wwv_flow_api.id(1318676266481382465)
,p_short_name=>'Modify Collection'
,p_link=>'f?p=&FLOW_ID.:3:&SESSION.'
,p_page_id=>3
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1318677755387389868)
,p_parent_id=>wwv_flow_api.id(1318676266481382465)
,p_short_name=>'Create Collection'
,p_link=>'f?p=&FLOW_ID.:2:&SESSION.'
,p_page_id=>2
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1318678260345392434)
,p_parent_id=>0
,p_short_name=>'Data Synchronization'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1318678659118394461)
,p_parent_id=>wwv_flow_api.id(1318678260345392434)
,p_short_name=>'Add/Edit Collection Member'
,p_link=>'f?p=&FLOW_ID.:7:&SESSION.'
,p_page_id=>7
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1318679572741398959)
,p_short_name=>'API Examples'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1318681558562411746)
,p_parent_id=>wwv_flow_api.id(1318682253032415084)
,p_short_name=>'Reset Data'
,p_link=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:::'
,p_page_id=>39
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1318682253032415084)
,p_short_name=>'Administration'
,p_link=>'f?p=&FLOW_ID.:35:&SESSION.'
,p_page_id=>35
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1850843065443002597)
,p_parent_id=>wwv_flow_api.id(1318682253032415084)
,p_short_name=>'Remove Collections'
,p_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:::'
,p_page_id=>36
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2127153303359260920)
,p_parent_id=>wwv_flow_api.id(1318682253032415084)
,p_short_name=>'Application Theme Style'
,p_link=>'f?p=&APP_ID.:5:&SESSION.'
,p_page_id=>5
);
wwv_flow_api.component_end;
end;
/
