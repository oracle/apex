prompt --application/shared_components/navigation/breadcrumbs/breadcrumbs
begin
--   Manifest
--     MENU: breadcrumbs
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7940
,p_default_id_offset=>10243121705511410
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(1328919002858891716)
,p_name=>'breadcrumbs'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1328919388186893875)
,p_short_name=>'Basic Collections'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1328919773974895700)
,p_short_name=>'Home'
,p_link=>'f?p=&FLOW_ID.:100:&SESSION.'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1328920498103899039)
,p_parent_id=>wwv_flow_imp.id(1328919388186893875)
,p_short_name=>'Modify Collection'
,p_link=>'f?p=&FLOW_ID.:3:&SESSION.'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1328920877092901278)
,p_parent_id=>wwv_flow_imp.id(1328919388186893875)
,p_short_name=>'Create Collection'
,p_link=>'f?p=&FLOW_ID.:2:&SESSION.'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1328921382050903844)
,p_short_name=>'Data Synchronization'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1328921780823905871)
,p_parent_id=>wwv_flow_imp.id(1328921382050903844)
,p_short_name=>'Add/Edit Collection Member'
,p_link=>'f?p=&FLOW_ID.:7:&SESSION.'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1328922694446910369)
,p_short_name=>'API Examples'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1328924680267923156)
,p_parent_id=>wwv_flow_imp.id(1328925374737926494)
,p_short_name=>'Reset Data'
,p_link=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:::'
,p_page_id=>39
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1328925374737926494)
,p_short_name=>'Administration'
,p_link=>'f?p=&FLOW_ID.:35:&SESSION.'
,p_page_id=>35
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1861086187148514007)
,p_parent_id=>wwv_flow_imp.id(1328925374737926494)
,p_short_name=>'Remove Collections'
,p_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:::'
,p_page_id=>36
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2137396425064772330)
,p_parent_id=>wwv_flow_imp.id(1328925374737926494)
,p_short_name=>'Application Theme Style'
,p_link=>'f?p=&APP_ID.:5:&SESSION.'
,p_page_id=>5
);
wwv_flow_imp.component_end;
end;
/
