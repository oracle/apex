prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 7940
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000CF49444154584763F4F10BF8CF30808071D401A321301A02B84220CAE22D03A1FC79E50917C3BF870C0CDA7FBF11CCC8ABD884';
wwv_flow_imp.g_varchar2_table(2) := 'B1AAC1990D3717DC2268E8D263820C7F0F313044FC794F506D308F1A690E08337949D0D02B4FB92121F0E72B41B56BB9C44973C068148C46C1682EB0B4B661F8FF1F7F51F4E4F16386273F3819FE8BA913CC868C573791960D0B4BCB091A7AECC8618663';
wwv_flow_imp.g_varchar2_table(3) := '1F841818750308AA655A95429A034CCD2D081A0A0B817FA2D84B396403586F6E23CD01A351301A05A3B980601EA49282D18EC968088C8600007225D6414DFBBED30000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(530959858754834174)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
