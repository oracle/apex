prompt --application/shared_components/security/authentications/apex_auth
begin
--   Manifest
--     AUTHENTICATION: APEX Auth
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7940
,p_default_id_offset=>10243121705511410
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(8717194286867881603)
,p_name=>'APEX Auth'
,p_scheme_type=>'NATIVE_APEX_ACCOUNTS'
,p_invalid_session_type=>'URL'
,p_invalid_session_url=>'f?p=&APP_ID.:101:&SESSION.'
,p_logout_url=>'f?p=&APP_ID.:101'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>186686443
);
wwv_flow_imp.component_end;
end;
/
