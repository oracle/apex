prompt --application/shared_components/navigation/lists/admin_options
begin
--   Manifest
--     LIST: admin options
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7940
,p_default_id_offset=>10243121705511410
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1328904589802670247)
,p_name=>'admin options'
,p_static_id=>'admin-options'
,p_version_scn=>'1089080320'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1328905080465670253)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Remove Collections'
,p_static_id=>'remove-collections'
,p_list_item_link_target=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-ban'
,p_list_text_01=>'This application creates Oracle APEX collections.  Use this link to drop all collections resetting this application to factory defaults.'
,p_list_text_02=>'formIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1328904786536670252)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Reset Data'
,p_static_id=>'reset-data'
,p_list_item_link_target=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-refresh'
,p_list_text_01=>'This application uses the sample EBA_DEMO_CS_EMP table, use this link to reset the table to the original specification.'
,p_list_text_02=>'formIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2137402756393786313)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Theme Style'
,p_static_id=>'theme-style'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-desktop'
,p_list_text_01=>'Change user interface theme style for all users.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
