prompt --application/deployment/install/upgrade_create_eba_demo_cs_emp_table
begin
--   Manifest
--     INSTALL: UPGRADE-Create EBA_DEMO_CS_EMP Table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7940
,p_default_id_offset=>10243121705511410
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop table eba_demo_cs_emp cascade constraints'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_cs_emp ('||wwv_flow.LF||
'    empno     NUMBE';
wwv_flow_imp.g_varchar2_table(2) := 'R(4) not null'||wwv_flow.LF||
'                          constraint eba_demo_cs_emp_pk'||wwv_flow.LF||
'                          prim';
wwv_flow_imp.g_varchar2_table(3) := 'ary key,'||wwv_flow.LF||
'    ename     VARCHAR2(10),'||wwv_flow.LF||
'    job       VARCHAR2(9),'||wwv_flow.LF||
'    mgr       NUMBER(4),'||wwv_flow.LF||
'    hiredat';
wwv_flow_imp.g_varchar2_table(4) := 'e  DATE,'||wwv_flow.LF||
'    sal       NUMBER(7),'||wwv_flow.LF||
'    comm      NUMBER(7),'||wwv_flow.LF||
'    deptno    NUMBER(2)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index';
wwv_flow_imp.g_varchar2_table(5) := ' eba_demo_cs_emp_1 ON eba_demo_cs_emp (MGR)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'create index eba_demo_cs_emp_2 ON eba_demo_cs_emp';
wwv_flow_imp.g_varchar2_table(6) := ' (DEPTNO)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7839';
wwv_flow_imp.g_varchar2_table(7) := ',''KING'',''PRESIDENT'',null,to_date(''17-11-81'',''DD-MM-RR''),5000,null,10);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (';
wwv_flow_imp.g_varchar2_table(8) := 'EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7698,''BLAKE'',''MANAGER'',7839,to_date(''01-05-81''';
wwv_flow_imp.g_varchar2_table(9) := ',''DD-MM-RR''),2850,null,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTN';
wwv_flow_imp.g_varchar2_table(10) := 'O) values (7782,''CLARK'',''MANAGER'',7839,to_date(''09-06-81'',''DD-MM-RR''),2450,null,10);'||wwv_flow.LF||
'insert into eba';
wwv_flow_imp.g_varchar2_table(11) := '_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7566,''JONES'',''MANAGER'',7839,to_d';
wwv_flow_imp.g_varchar2_table(12) := 'ate(''02-04-81'',''DD-MM-RR''),2975,null,20);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,';
wwv_flow_imp.g_varchar2_table(13) := 'SAL,COMM,DEPTNO) values (7788,''SCOTT'',''ANALYST'',7566,to_date(''09-12-82'',''DD-MM-RR''),3000,null,20);'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(14) := 'nsert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7902,''FORD'',''ANALY';
wwv_flow_imp.g_varchar2_table(15) := 'ST'',7566,to_date(''03-12-81'',''DD-MM-RR''),3000,null,20);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,';
wwv_flow_imp.g_varchar2_table(16) := 'MGR,HIREDATE,SAL,COMM,DEPTNO) values (7369,''SMITH'',''CLERK'',7902,to_date(''17-12-80'',''DD-MM-RR''),800,n';
wwv_flow_imp.g_varchar2_table(17) := 'ull,20);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7499,''AL';
wwv_flow_imp.g_varchar2_table(18) := 'LEN'',''SALESMAN'',7698,to_date(''20-02-81'',''DD-MM-RR''),1600,300,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO';
wwv_flow_imp.g_varchar2_table(19) := ',ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7521,''WARD'',''SALESMAN'',7698,to_date(''22-02-81'',''DD-';
wwv_flow_imp.g_varchar2_table(20) := 'MM-RR''),1250,500,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) val';
wwv_flow_imp.g_varchar2_table(21) := 'ues (7654,''MARTIN'',''SALESMAN'',7698,to_date(''28-09-81'',''DD-MM-RR''),1250,1400,30);'||wwv_flow.LF||
'insert into eba_dem';
wwv_flow_imp.g_varchar2_table(22) := 'o_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7844,''TURNER'',''SALESMAN'',7698,to_dat';
wwv_flow_imp.g_varchar2_table(23) := 'e(''08-09-81'',''DD-MM-RR''),1500,0,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,C';
wwv_flow_imp.g_varchar2_table(24) := 'OMM,DEPTNO) values (7876,''ADAMS'',''CLERK'',7788,to_date(''12-01-83'',''DD-MM-RR''),1100,null,20);'||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(25) := 'nto eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7900,''JAMES'',''CLERK'',7698';
wwv_flow_imp.g_varchar2_table(26) := ',to_date(''03-12-81'',''DD-MM-RR''),950,null,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIRED';
wwv_flow_imp.g_varchar2_table(27) := 'ATE,SAL,COMM,DEPTNO) values (7934,''MILLER'',''CLERK'',7782,to_date(''23-01-82'',''DD-MM-RR''),1300,null,10)';
wwv_flow_imp.g_varchar2_table(28) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'commit;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1328896976511306874)
,p_install_id=>wwv_flow_imp.id(8030913513064973089)
,p_name=>'Create EBA_DEMO_CS_EMP Table'
,p_sequence=>20
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>'select table_name from user_tables where table_name = ''EBA_DEMO_CS_EMP'''
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
