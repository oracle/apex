prompt --application/deployment/install/install_create_eba_demo_cs_emp_table
begin
--   Manifest
--     INSTALL: INSTALL-Create EBA_DEMO_CS_EMP table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7940
,p_default_id_offset=>10243121705511410
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_demo_cs_emp ('||wwv_flow.LF||
'    empno     NUMBER(4) not null'||wwv_flow.LF||
'                          constraint';
wwv_flow_imp.g_varchar2_table(2) := ' eba_demo_cs_emp_pk'||wwv_flow.LF||
'                          primary key,'||wwv_flow.LF||
'    ename     VARCHAR2(10),'||wwv_flow.LF||
'    job      ';
wwv_flow_imp.g_varchar2_table(3) := ' VARCHAR2(9),'||wwv_flow.LF||
'    mgr       NUMBER(4),'||wwv_flow.LF||
'    hiredate  DATE,'||wwv_flow.LF||
'    sal       NUMBER(7),'||wwv_flow.LF||
'    comm      NU';
wwv_flow_imp.g_varchar2_table(4) := 'MBER(7),'||wwv_flow.LF||
'    deptno    NUMBER(2)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_cs_emp_idx1 ON eba_demo_cs_emp (MGR)'||wwv_flow.LF||
'/'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(5) := '   '||wwv_flow.LF||
'create index eba_demo_cs_emp_idx2 ON eba_demo_cs_emp (DEPTNO)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'delete from eba_demo_cs_emp;'||wwv_flow.LF||
''||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(6) := 'nsert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7839,''KING'',''PRESI';
wwv_flow_imp.g_varchar2_table(7) := 'DENT'',null,to_date(''17-11-81'',''DD-MM-RR''),5000,null,10);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JO';
wwv_flow_imp.g_varchar2_table(8) := 'B,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7698,''BLAKE'',''MANAGER'',7839,to_date(''01-05-81'',''DD-MM-RR''),2';
wwv_flow_imp.g_varchar2_table(9) := '850,null,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (778';
wwv_flow_imp.g_varchar2_table(10) := '2,''CLARK'',''MANAGER'',7839,to_date(''09-06-81'',''DD-MM-RR''),2450,null,10);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (';
wwv_flow_imp.g_varchar2_table(11) := 'EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7566,''JONES'',''MANAGER'',7839,to_date(''02-04-81''';
wwv_flow_imp.g_varchar2_table(12) := ',''DD-MM-RR''),2975,null,20);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTN';
wwv_flow_imp.g_varchar2_table(13) := 'O) values (7788,''SCOTT'',''ANALYST'',7566,to_date(''09-12-82'',''DD-MM-RR''),3000,null,20);'||wwv_flow.LF||
'insert into eba';
wwv_flow_imp.g_varchar2_table(14) := '_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7902,''FORD'',''ANALYST'',7566,to_da';
wwv_flow_imp.g_varchar2_table(15) := 'te(''03-12-81'',''DD-MM-RR''),3000,null,20);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,S';
wwv_flow_imp.g_varchar2_table(16) := 'AL,COMM,DEPTNO) values (7369,''SMITH'',''CLERK'',7902,to_date(''17-12-80'',''DD-MM-RR''),800,null,20);'||wwv_flow.LF||
'inser';
wwv_flow_imp.g_varchar2_table(17) := 't into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7499,''ALLEN'',''SALESMAN';
wwv_flow_imp.g_varchar2_table(18) := ''',7698,to_date(''20-02-81'',''DD-MM-RR''),1600,300,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR';
wwv_flow_imp.g_varchar2_table(19) := ',HIREDATE,SAL,COMM,DEPTNO) values (7521,''WARD'',''SALESMAN'',7698,to_date(''22-02-81'',''DD-MM-RR''),1250,5';
wwv_flow_imp.g_varchar2_table(20) := '00,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7654,''MAR';
wwv_flow_imp.g_varchar2_table(21) := 'TIN'',''SALESMAN'',7698,to_date(''28-09-81'',''DD-MM-RR''),1250,1400,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPN';
wwv_flow_imp.g_varchar2_table(22) := 'O,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7844,''TURNER'',''SALESMAN'',7698,to_date(''08-09-81'',''';
wwv_flow_imp.g_varchar2_table(23) := 'DD-MM-RR''),1500,0,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) va';
wwv_flow_imp.g_varchar2_table(24) := 'lues (7876,''ADAMS'',''CLERK'',7788,to_date(''12-01-83'',''DD-MM-RR''),1100,null,20);'||wwv_flow.LF||
'insert into eba_demo_c';
wwv_flow_imp.g_varchar2_table(25) := 's_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7900,''JAMES'',''CLERK'',7698,to_date(''03-1';
wwv_flow_imp.g_varchar2_table(26) := '2-81'',''DD-MM-RR''),950,null,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,D';
wwv_flow_imp.g_varchar2_table(27) := 'EPTNO) values (7934,''MILLER'',''CLERK'',7782,to_date(''23-01-82'',''DD-MM-RR''),1300,null,10);'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1328896383176289879)
,p_install_id=>wwv_flow_imp.id(8030913513064973089)
,p_name=>'Create EBA_DEMO_CS_EMP table'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
