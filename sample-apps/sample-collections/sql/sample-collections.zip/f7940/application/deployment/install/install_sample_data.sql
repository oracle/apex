prompt --application/deployment/install/install_sample_data
begin
--   Manifest
--     INSTALL: INSTALL-Sample Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7940
,p_default_id_offset=>10243121705511410
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace procedure eba_demo_cs_emp_data'||wwv_flow.LF||
'as'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'delete from eba_demo_cs_emp;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(2) := ' eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7839,''KING'',''PRESIDENT'',null';
wwv_flow_imp.g_varchar2_table(3) := ',to_date(''17-11-81'',''DD-MM-RR''),5000,null,10);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIRE';
wwv_flow_imp.g_varchar2_table(4) := 'DATE,SAL,COMM,DEPTNO) values (7698,''BLAKE'',''MANAGER'',7839,to_date(''01-05-81'',''DD-MM-RR''),2850,null,3';
wwv_flow_imp.g_varchar2_table(5) := '0);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7782,''CLARK'',';
wwv_flow_imp.g_varchar2_table(6) := '''MANAGER'',7839,to_date(''09-06-81'',''DD-MM-RR''),2450,null,10);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAM';
wwv_flow_imp.g_varchar2_table(7) := 'E,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7566,''JONES'',''MANAGER'',7839,to_date(''02-04-81'',''DD-MM-RR';
wwv_flow_imp.g_varchar2_table(8) := '''),2975,null,20);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ';
wwv_flow_imp.g_varchar2_table(9) := '(7788,''SCOTT'',''ANALYST'',7566,to_date(''09-12-82'',''DD-MM-RR''),3000,null,20);'||wwv_flow.LF||
'insert into eba_demo_cs_e';
wwv_flow_imp.g_varchar2_table(10) := 'mp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7902,''FORD'',''ANALYST'',7566,to_date(''03-12-';
wwv_flow_imp.g_varchar2_table(11) := '81'',''DD-MM-RR''),3000,null,20);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DE';
wwv_flow_imp.g_varchar2_table(12) := 'PTNO) values (7369,''SMITH'',''CLERK'',7902,to_date(''17-12-80'',''DD-MM-RR''),800,null,20);'||wwv_flow.LF||
'insert into eba';
wwv_flow_imp.g_varchar2_table(13) := '_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7499,''ALLEN'',''SALESMAN'',7698,to_';
wwv_flow_imp.g_varchar2_table(14) := 'date(''20-02-81'',''DD-MM-RR''),1600,300,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,';
wwv_flow_imp.g_varchar2_table(15) := 'SAL,COMM,DEPTNO) values (7521,''WARD'',''SALESMAN'',7698,to_date(''22-02-81'',''DD-MM-RR''),1250,500,30);'||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(16) := 'sert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7654,''MARTIN'',''SALE';
wwv_flow_imp.g_varchar2_table(17) := 'SMAN'',7698,to_date(''28-09-81'',''DD-MM-RR''),1250,1400,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JO';
wwv_flow_imp.g_varchar2_table(18) := 'B,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7844,''TURNER'',''SALESMAN'',7698,to_date(''08-09-81'',''DD-MM-RR'')';
wwv_flow_imp.g_varchar2_table(19) := ',1500,0,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7876';
wwv_flow_imp.g_varchar2_table(20) := ',''ADAMS'',''CLERK'',7788,to_date(''12-01-83'',''DD-MM-RR''),1100,null,20);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMP';
wwv_flow_imp.g_varchar2_table(21) := 'NO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7900,''JAMES'',''CLERK'',7698,to_date(''03-12-81'',''DD-';
wwv_flow_imp.g_varchar2_table(22) := 'MM-RR''),950,null,30);'||wwv_flow.LF||
'insert into eba_demo_cs_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) val';
wwv_flow_imp.g_varchar2_table(23) := 'ues (7934,''MILLER'',''CLERK'',7782,to_date(''23-01-82'',''DD-MM-RR''),1300,null,10);'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_demo_cs_emp_d';
wwv_flow_imp.g_varchar2_table(24) := 'ata;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1330546281643241260)
,p_install_id=>wwv_flow_imp.id(8030913513064973089)
,p_name=>'Sample Data'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
