prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'Store Regions'
,p_alias=>'STORE-REGIONS'
,p_step_title=>'Store Regions'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(39780858241780598888)
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38796923071441504088)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(44425078801060133467)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38796922059318504052)
,p_plug_name=>'Store Regions'
,p_static_id=>'store-regions'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id, ',
'       region_name, ',
'       is_default, ',
'       stores, ',
'       sales_trailing_30_days, ',
'       sales_prior_30_days,',
'       --',
'       -- sales trend',
'       --',
'       nvl(sales_trailing_30_days,0) - nvl(sales_prior_30_days,0) sales_trend,',
'       --',
'       -- sales trend percentage accounting for divide by zero errors',
'       --',
'       decode(nvl(sales_prior_30_days,0),0,null,',
'          round(nvl(sales_trailing_30_days,0) / nvl(sales_prior_30_days,0),2)) sales_trend_percentage,',
'       --',
'       -- average sales per store',
'       --',
'       to_number(decode(stores,0,0,sales_trailing_30_days/stores)) avg_store_sales',
'from (',
'--',
'-- inline view',
'--',
'select r.ID, ',
'       r.REGION_NAME,',
'       decode(r.is_default_yn,''Y'',''Yes'',''No'') is_default,',
'       --',
'       nvl((select count(*) ',
'            from #OWNER#.OOW_DEMO_STORES s ',
'            where s.region_id = r.id),0) stores,',
'       --',
'       -- sales in the last 30 days',
'       --',
'       (select sum(QUANTITY*ITEM_PRICE) qp ',
'        from #OWNER#.OOW_DEMO_SALES_HISTORY h ',
'        where DATE_OF_SALE > sysdate - 30 and ',
'              h.store_id in (select id from OOW_DEMO_STORES s where s.region_id = r.id)) sales_trailing_30_days,',
'        --',
'        -- sales in the prior 30 days',
'        --',
'        (select sum(QUANTITY*ITEM_PRICE) qp ',
'        from #OWNER#.OOW_DEMO_SALES_HISTORY h ',
'        where DATE_OF_SALE > sysdate - 60 and ',
'              date_of_sale < sysdate - 30 and',
'              h.store_id in (select id from OOW_DEMO_STORES s where s.region_id = r.id)) sales_prior_30_days',
'from #OWNER#.OOW_DEMO_REGIONS r',
') ilv',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_ai_enabled=>true
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(38796922262101504052)
,p_max_row_count=>'100000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_internal_uid=>2708389615873260088
,p_ai_search_mode=>'A'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39058949910624172172)
,p_db_column_name=>'AVG_STORE_SALES'
,p_display_order=>36
,p_column_identifier=>'J'
,p_column_label=>'Average Sales per Store'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38796922378309504057)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38799600446522208310)
,p_db_column_name=>'IS_DEFAULT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Is Default'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38796922451794504087)
,p_db_column_name=>'REGION_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Region'
,p_column_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:RP,:P15_REGION_ID:#ID#'
,p_column_linktext=>'#REGION_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39577068166954410178)
,p_db_column_name=>'SALES_PRIOR_30_DAYS'
,p_display_order=>46
,p_column_identifier=>'K'
,p_column_label=>'Sales Prior 30 Days'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39058949721219172170)
,p_db_column_name=>'SALES_TRAILING_30_DAYS'
,p_display_order=>26
,p_column_identifier=>'H'
,p_column_label=>'Sales Trailing 30 Days'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39577068243819410179)
,p_db_column_name=>'SALES_TREND'
,p_display_order=>56
,p_column_identifier=>'L'
,p_column_label=>'Sales Trend'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(21327934770196015311)
,p_db_column_name=>'SALES_TREND_PERCENTAGE'
,p_display_order=>66
,p_column_identifier=>'O'
,p_column_label=>'Sales Trend Percentage'
,p_column_html_expression=>'#SALES_TREND_PERCENTAGE#%'
,p_column_type=>'STRING'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'S999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39058949636652172169)
,p_db_column_name=>'STORES'
,p_display_order=>16
,p_column_identifier=>'G'
,p_column_label=>'Stores'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(38796923847328504220)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'27083913'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'REGION_NAME:STORES:SALES_TRAILING_30_DAYS:SALES_PRIOR_30_DAYS:SALES_TREND:AVG_STORE_SALES'
,p_sort_column_1=>'AVG_STORE_SALES'
,p_sort_direction_1=>'DESC'
,p_sum_columns_on_break=>'SALES_TRAILING_30_DAYS:STORES:SALES_PRIOR_30_DAYS:SALES_TREND'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38796922978981504088)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(38796923071441504088)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconRight'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Add Region'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:9::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38797257953365897711)
,p_button_sequence=>4
,p_button_plug_id=>wwv_flow_imp.id(38796922059318504052)
,p_button_name=>'RESET_REPORT'
,p_static_id=>'reset-report'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:8,RIR::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39055568930761580307)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38796923071441504088)
,p_button_name=>'up'
,p_static_id=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp.component_end;
end;
/
