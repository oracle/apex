prompt --application/shared_components/navigation/lists/application_actions
begin
--   Manifest
--     LIST: Application Actions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(38797542156837024721)
,p_name=>'Application Actions'
,p_static_id=>'application-actions'
,p_version_scn=>'SH256:pUJ4rpNIgcBPDKYI0rdCB01f_HsOMfIWWK3AsGzQJt8'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39055515224605557951)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Administration'
,p_static_id=>'administration'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user'
,p_list_text_01=>'Run reports to analyze sales history data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38815934152278216742)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Analysis Reports'
,p_static_id=>'analysis-reports'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Run reports to analyze sales history data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38815933856416066603)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Generate Transactions'
,p_static_id=>'generate-transactions'
,p_list_item_link_target=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gears'
,p_list_text_01=>'Generate sale transactions'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38797547355714043269)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Products'
,p_static_id=>'products'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-package'
,p_list_text_01=>'Identify product items available for sale at one or more stores'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38797544865972036835)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Regions'
,p_static_id=>'regions'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-globe'
,p_list_text_01=>'Each store is mapped to a geographic region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38800518273725068239)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Sales Dashboard'
,p_static_id=>'sales-dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-line-chart'
,p_list_text_01=>'Analysis dashboard of sales data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(13900537631378623805)
,p_list_item_display_sequence=>56
,p_list_item_link_text=>'Sales History'
,p_static_id=>'sales-history'
,p_list_item_link_target=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:RP,51:::'
,p_list_item_icon=>'fa-credit-card'
,p_list_text_01=>'Identify product items available for sale at one or more stores'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38797542376290024722)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Stores'
,p_static_id=>'stores'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-shopping-bag'
,p_list_text_01=>'Identify attributes, products sold, discounts and geographic region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
