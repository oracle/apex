prompt --application/deployment/install/install_scope
begin
--   Manifest
--     INSTALL: INSTALL-scope
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'rem ALTER SESSION SET PLSCOPE_SETTINGS = ''IDENTIFIERS:NONE'';';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38818969277946368401)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'scope'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
