prompt --application/deployment/install/install_oow_demo_gen_data_pkg_spec
begin
--   Manifest
--     INSTALL: INSTALL-oow_demo_gen_data_pkg SPEC
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package oow_demo_gen_data_pkg'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    g_i               number := null;'||wwv_flow.LF||
'    g_store';
wwv_flow_imp.g_varchar2_table(2) := '_count     integer := null;'||wwv_flow.LF||
'    g_transaction     varchar2(255) := null;'||wwv_flow.LF||
'    g_item_id         numbe';
wwv_flow_imp.g_varchar2_table(3) := 'r := null;'||wwv_flow.LF||
'    g_qty             number := null;'||wwv_flow.LF||
'    g_price           number := null;'||wwv_flow.LF||
'    g_progres';
wwv_flow_imp.g_varchar2_table(4) := 's        number := 0;'||wwv_flow.LF||
'    g_context         varchar2(4000) := null;'||wwv_flow.LF||
'    g_insert_count    integer :=';
wwv_flow_imp.g_varchar2_table(5) := ' 0;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'function generate_transaction '||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure oow_demo_gen_sales_data ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(6) := 'p_days      in number default 90, -- 365'||wwv_flow.LF||
'    p_orders    in number default 50, -- 50'||wwv_flow.LF||
'    p_truncate ';
wwv_flow_imp.g_varchar2_table(7) := ' in varchar2 default ''Y'','||wwv_flow.LF||
'    p_max_stores in number default 500,'||wwv_flow.LF||
'    p_max_rows   in number default';
wwv_flow_imp.g_varchar2_table(8) := ' 0'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure exec_100_transactions;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure exec_n_transactions ('||wwv_flow.LF||
'    P_transactions in numbe';
wwv_flow_imp.g_varchar2_table(9) := 'r default 1'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38815917878008306323)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'oow_demo_gen_data_pkg SPEC'
,p_sequence=>170
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(37108481140110249821)
,p_script_id=>wwv_flow_imp.id(38815917878008306323)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'OOW_DEMO_GEN_DATA_PKG'
);
wwv_flow_imp.component_end;
end;
/
