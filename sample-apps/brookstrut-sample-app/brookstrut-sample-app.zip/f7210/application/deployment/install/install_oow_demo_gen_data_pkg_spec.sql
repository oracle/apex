prompt --application/deployment/install/install_oow_demo_gen_data_pkg_spec
begin
--   Manifest
--     INSTALL: INSTALL-oow_demo_gen_data_pkg SPEC
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(25539825751647766471)
,p_install_id=>wwv_flow_imp.id(25524424439166384136)
,p_name=>'oow_demo_gen_data_pkg SPEC'
,p_sequence=>170
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package oow_demo_gen_data_pkg',
'is',
'    g_i               number := null;',
'    g_store_count     integer := null;',
'    g_transaction     varchar2(255) := null;',
'    g_item_id         number := null;',
'    g_qty             number := null;',
'    g_price           number := null;',
'    g_progress        number := 0;',
'    g_context         varchar2(4000) := null;',
'    g_insert_count    integer := 0;',
'    ',
'function generate_transaction ',
'    return number;',
'',
'procedure oow_demo_gen_sales_data (',
'    p_days      in number default 90, -- 365',
'    p_orders    in number default 50, -- 500',
'    p_truncate  in varchar2 default ''Y'',',
'    p_max_stores in number default 500,',
'    p_max_rows   in number default 0',
');',
'',
'procedure exec_100_transactions;',
'',
'procedure exec_n_transactions (',
'    P_transactions in number default 1',
');',
'',
'end;',
'/',
'',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(23832389013749709969)
,p_script_id=>wwv_flow_imp.id(25539825751647766471)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'OOW_DEMO_GEN_DATA_PKG'
,p_last_updated_on=>to_date('20141219062103','YYYYMMDDHH24MISS')
,p_created_on=>to_date('20141219062103','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
