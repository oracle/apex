prompt --application/deployment/install/install_history
begin
--   Manifest
--     INSTALL: INSTALL-history
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38743051025792587866)
,p_install_id=>wwv_flow_imp.id(38742994623120425165)
,p_name=>'history'
,p_sequence=>100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE  OOW_DEMO_SALES_HISTORY (',
'    ID             NUMBER, ',
'    STORE_ID       NUMBER NOT NULL ENABLE, ',
'    PRODUCT_ID     NUMBER NOT NULL ENABLE, ',
'    DATE_OF_SALE   TIMESTAMP (6) WITH LOCAL TIME ZONE, ',
'    QUANTITY       NUMBER DEFAULT 1, ',
'    TRANSACTION_ID VARCHAR2(30), ',
'    ITEM_PRICE     NUMBER, ',
'    created_on     timestamp with local time zone,',
'    sales_data     varchar2(4000),',
'    CONSTRAINT OOW_DEMO_SALES_HISTORY_PK PRIMARY KEY (ID) ENABLE',
'   );',
'',
'CREATE OR REPLACE TRIGGER BIU_OOW_DEMO_SALES_HIST ',
'BEFORE INSERT OR UPDATE ON OOW_DEMO_SALES_HISTORY ',
'FOR EACH ROW',
'BEGIN',
'   if :new.ID is null then',
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;',
'   end if;',
'   if inserting then ',
'      :new.created_on := localtimestamp; ',
'      ',
'      if :new.sales_data is null then',
'         :new.sales_data := ',
'             ''{"ID" :"''||:new.id||''" ,''||',
'             ''"STORE_ID":''||:new.STORE_ID||'',''||',
'             ''"PRODUCT_ID":''||:new.PRODUCT_ID||'',''||',
'             ''"DATE_OF_SALE":"''||to_char(:new.DATE_OF_SALE,''YYYY-MM-DD"T"HH24:MI:SS".OZ"'')||''",''||',
'             ''"QUANTITY":''||:new.QUANTITY||'',''||',
'             ''"TRANSACTION_ID":"''||:new.TRANSACTION_ID||''",''||',
'             ''"ITEM_PRICE":''||:new.ITEM_PRICE||'',''||',
'             ''"CREATED_ON":"''||to_char(:new.DATE_OF_SALE,''YYYY-MM-DD"T"HH24:MI:SS".OZ"'')||''"''||',
'             ''}'';',
'      end if; ',
'   end if;',
'END;',
'/',
'show errors'))
);
wwv_flow_imp.component_end;
end;
/
