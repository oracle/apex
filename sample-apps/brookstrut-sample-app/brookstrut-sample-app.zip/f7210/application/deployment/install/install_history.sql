prompt --application/deployment/install/install_history
begin
--   Manifest
--     INSTALL: INSTALL-history
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE  OOW_DEMO_SALES_HISTORY ('||wwv_flow.LF||
'    ID             NUMBER, '||wwv_flow.LF||
'    STORE_ID       NUMBER NOT NUL';
wwv_flow_imp.g_varchar2_table(2) := 'L ENABLE, '||wwv_flow.LF||
'    PRODUCT_ID     NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'    DATE_OF_SALE   TIMESTAMP (6) WITH LOCAL T';
wwv_flow_imp.g_varchar2_table(3) := 'IME ZONE, '||wwv_flow.LF||
'    QUANTITY       NUMBER DEFAULT 1, '||wwv_flow.LF||
'    TRANSACTION_ID VARCHAR2(30), '||wwv_flow.LF||
'    ITEM_PRICE   ';
wwv_flow_imp.g_varchar2_table(4) := '  NUMBER, '||wwv_flow.LF||
'    created_on     timestamp with local time zone,'||wwv_flow.LF||
'    sales_data     varchar2(4000),'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(5) := ' CONSTRAINT OOW_DEMO_SALES_HISTORY_PK PRIMARY KEY (ID) ENABLE'||wwv_flow.LF||
'   );'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER BIU_O';
wwv_flow_imp.g_varchar2_table(6) := 'OW_DEMO_SALES_HIST '||wwv_flow.LF||
'BEFORE INSERT OR UPDATE ON OOW_DEMO_SALES_HISTORY '||wwv_flow.LF||
'FOR EACH ROW'||wwv_flow.LF||
'BEGIN'||wwv_flow.LF||
'   if :new';
wwv_flow_imp.g_varchar2_table(7) := '.ID is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id f';
wwv_flow_imp.g_varchar2_table(8) := 'rom dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then '||wwv_flow.LF||
'      :new.created_on := localtimestamp; '||wwv_flow.LF||
'      '||wwv_flow.LF||
'      if';
wwv_flow_imp.g_varchar2_table(9) := ' :new.sales_data is null then'||wwv_flow.LF||
'         :new.sales_data := '||wwv_flow.LF||
'             ''{"ID" :"''||:new.id||''" ,''||';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
'             ''"STORE_ID":''||:new.STORE_ID||'',''||'||wwv_flow.LF||
'             ''"PRODUCT_ID":''||:new.PRODUCT_ID||'',''';
wwv_flow_imp.g_varchar2_table(11) := '||'||wwv_flow.LF||
'             ''"DATE_OF_SALE":"''||to_char(:new.DATE_OF_SALE,''YYYY-MM-DD"T"HH24:MI:SS".OZ"'')||''",''|';
wwv_flow_imp.g_varchar2_table(12) := '|'||wwv_flow.LF||
'             ''"QUANTITY":''||:new.QUANTITY||'',''||'||wwv_flow.LF||
'             ''"TRANSACTION_ID":"''||:new.TRANSACTI';
wwv_flow_imp.g_varchar2_table(13) := 'ON_ID||''",''||'||wwv_flow.LF||
'             ''"ITEM_PRICE":''||:new.ITEM_PRICE||'',''||'||wwv_flow.LF||
'             ''"CREATED_ON":"''||to';
wwv_flow_imp.g_varchar2_table(14) := '_char(:new.DATE_OF_SALE,''YYYY-MM-DD"T"HH24:MI:SS".OZ"'')||''"''||'||wwv_flow.LF||
'             ''}'';'||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'   e';
wwv_flow_imp.g_varchar2_table(15) := 'nd if;'||wwv_flow.LF||
'END;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38800572968199086689)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'history'
,p_sequence=>100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
