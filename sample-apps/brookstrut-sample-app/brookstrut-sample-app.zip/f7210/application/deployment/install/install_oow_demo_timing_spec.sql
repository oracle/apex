prompt --application/deployment/install/install_oow_demo_timing_spec
begin
--   Manifest
--     INSTALL: INSTALL-oow_demo_timing spec 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package oow_demo_timing'||wwv_flow.LF||
'as'||wwv_flow.LF||
'    g_timestamp timestamp;'||wwv_flow.LF||
'    procedure start_timer;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(2) := '   function get_elap return number;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40236839915653584748)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'oow_demo_timing spec '
,p_sequence=>220
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
