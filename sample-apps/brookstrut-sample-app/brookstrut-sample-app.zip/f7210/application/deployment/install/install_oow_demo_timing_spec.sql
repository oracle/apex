prompt --application/deployment/install/install_oow_demo_timing_spec
begin
--   Manifest
--     INSTALL: INSTALL-oow_demo_timing spec 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1867060655981638216
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40160586515129907053)
,p_install_id=>wwv_flow_imp.id(38724263165003246293)
,p_name=>'oow_demo_timing spec '
,p_sequence=>220
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package oow_demo_timing',
'as',
'    g_timestamp timestamp;',
'    procedure start_timer;',
'    function get_elap return number;',
'end;',
'/',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
