prompt --application/deployment/install/install_create_biu_oow_demo_sales_hist_trigger
begin
--   Manifest
--     INSTALL: INSTALL-Create BIU_OOW_DEMO_SALES_HIST trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE OR REPLACE TRIGGER BIU_OOW_DEMO_SALES_HIST '||wwv_flow.LF||
'BEFORE INSERT OR UPDATE ON OOW_DEMO_SALES_HISTORY';
wwv_flow_imp.g_varchar2_table(2) := ' '||wwv_flow.LF||
'FOR EACH ROW'||wwv_flow.LF||
'BEGIN'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(3) := 'XXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then '||wwv_flow.LF||
'      :new.created_on := l';
wwv_flow_imp.g_varchar2_table(4) := 'ocaltimestamp; '||wwv_flow.LF||
'      '||wwv_flow.LF||
'      if :new.sales_data is null then'||wwv_flow.LF||
'         :new.sales_data := '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(5) := '   ''{"ID" :"''||:new.id||''" ,''||'||wwv_flow.LF||
'             ''"STORE_ID":''||:new.STORE_ID||'',''||'||wwv_flow.LF||
'             ''"PROD';
wwv_flow_imp.g_varchar2_table(6) := 'UCT_ID":''||:new.PRODUCT_ID||'',''||'||wwv_flow.LF||
'             ''"DATE_OF_SALE":"''||to_char(:new.DATE_OF_SALE,''YYYY-M';
wwv_flow_imp.g_varchar2_table(7) := 'M-DD"T"HH24:MI:SS".OZ"'')||''",''||'||wwv_flow.LF||
'             ''"QUANTITY":''||:new.QUANTITY||'',''||'||wwv_flow.LF||
'             ''"TRA';
wwv_flow_imp.g_varchar2_table(8) := 'NSACTION_ID":"''||:new.TRANSACTION_ID||''",''||'||wwv_flow.LF||
'             ''"ITEM_PRICE":''||:new.ITEM_PRICE||'',''||'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(9) := '           ''"CREATED_ON":"''||to_char(:new.DATE_OF_SALE,''YYYY-MM-DD"T"HH24:MI:SS".OZ"'')||''"''||'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(10) := '       ''}'';'||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'END;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(15080110157302051384)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'Create BIU_OOW_DEMO_SALES_HIST trigger'
,p_sequence=>250
,p_script_type=>'INSTALL'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>'select null from all_triggers where trigger_name = ''BIU_OOW_DEMO_SALES_HIST'';'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
