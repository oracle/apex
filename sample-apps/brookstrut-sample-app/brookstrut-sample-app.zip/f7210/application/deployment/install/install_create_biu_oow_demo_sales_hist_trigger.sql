prompt --application/deployment/install/install_create_biu_oow_demo_sales_hist_trigger
begin
--   Manifest
--     INSTALL: INSTALL-Create BIU_OOW_DEMO_SALES_HIST trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1804018030941511532)
,p_install_id=>wwv_flow_imp.id(25524424439166384136)
,p_name=>'Create BIU_OOW_DEMO_SALES_HIST trigger'
,p_sequence=>270
,p_script_type=>'INSTALL'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>'select null from all_triggers where trigger_name = ''BIU_OOW_DEMO_SALES_HIST'';'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE TRIGGER BIU_OOW_DEMO_SALES_HIST ',
'BEFORE INSERT OR UPDATE ON OOW_DEMO_SALES_HISTORY ',
'FOR EACH ROW',
'BEGIN',
'   if :new.ID is null then',
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;',
'   end if;',
'   if inserting then ',
'      :new.created_on := localtimestamp; ',
'      ',
'      if :new.sales_data is null then',
'         :new.sales_data := ',
'             ''{"ID" :"''||:new.id||''" ,''||',
'             ''"STORE_ID":''||:new.STORE_ID||'',''||',
'             ''"PRODUCT_ID":''||:new.PRODUCT_ID||'',''||',
'             ''"DATE_OF_SALE":"''||to_char(:new.DATE_OF_SALE,''YYYY-MM-DD"T"HH24:MI:SS".OZ"'')||''",''||',
'             ''"QUANTITY":''||:new.QUANTITY||'',''||',
'             ''"TRANSACTION_ID":"''||:new.TRANSACTION_ID||''",''||',
'             ''"ITEM_PRICE":''||:new.ITEM_PRICE||'',''||',
'             ''"CREATED_ON":"''||to_char(:new.DATE_OF_SALE,''YYYY-MM-DD"T"HH24:MI:SS".OZ"'')||''"''||',
'             ''}'';',
'      end if; ',
'   end if;',
'END;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
