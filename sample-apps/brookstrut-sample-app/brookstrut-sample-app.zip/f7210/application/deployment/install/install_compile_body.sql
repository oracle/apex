prompt --application/deployment/install/install_compile_body
begin
--   Manifest
--     INSTALL: INSTALL-compile body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(25549598545198115424)
,p_install_id=>wwv_flow_imp.id(25524424439166384136)
,p_name=>'compile body'
,p_sequence=>210
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    oow_demo_event_pkg.log (p_event_name => ''compile package body oow_demo_gen_data_pkg'', p_error_message => null);',
'end;',
'/',
'    ',
'    ',
'alter package oow_demo_gen_data_pkg compile body;',
'',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
