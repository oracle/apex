prompt --application/deployment/install/install_create_indexes
begin
--   Manifest
--     INSTALL: INSTALL-create indexes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38800555177147285018)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'create indexes'
,p_sequence=>130
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create index OOW_DEMO_STORE_PRODUCTS_i1 on OOW_DEMO_STORE_PRODUCTS (store_id);',
'create index OOW_DEMO_STORE_PRODUCTS_i2 on OOW_DEMO_STORE_PRODUCTS (item_id);',
'create index oow_demo_sales_history_i1 on oow_demo_sales_history (store_id);',
'create index oow_demo_sales_history_i2 on oow_demo_sales_history (product_id);',
'    '))
);
wwv_flow_imp.component_end;
end;
/
