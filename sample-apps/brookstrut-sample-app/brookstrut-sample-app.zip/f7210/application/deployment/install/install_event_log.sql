prompt --application/deployment/install/install_event_log
begin
--   Manifest
--     INSTALL: INSTALL-event log
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38761447005064860779)
,p_install_id=>wwv_flow_imp.id(38742994623120425165)
,p_name=>'event log'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table oow_demo_event_log (',
'    id            number',
'                  constraint oow_demo_event_log_pk',
'                  primary key,',
'    log_seq       number not null,',
'    event_type    varchar2(255) not null',
'                  constraint oow_demo_event_event_type_ck',
'                  check (event_type in (',
'                  ''MESSAGE'',',
'                  ''WARNING'',',
'                  ''ERROR'')),',
'    event_name    varchar2(255),',
'    event_detail  varchar2(4000),',
'    error_message varchar2(4000),',
'    error_trace   clob,',
'    created_by    varchar2(255),',
'    created_on    timestamp with local time zone,',
'    a1            varchar2(4000),',
'    a2            varchar2(4000)',
');',
'',
'create or replace trigger biu_oow_demo_event_log',
'before insert or update on oow_demo_event_log',
'for each row',
'begin',
'   if :new.id is null then',
'       select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;',
'  end if;',
'  if :new.event_type is null then',
'     if :new.error_message is not null then',
'        :new.event_type := ''ERROR'';',
'     else',
'        :new.event_type := ''MESSAGE'';',
'     end if;',
'  end if;',
'  if inserting then ',
'      :new.log_seq := oow_demo_seq.nextval;',
'      :new.created_on := localtimestamp;',
'      :new.created_by := nvl(v(''APP_USER''),user);',
'  end if;',
'end;',
'/',
'show errors',
'',
'   ',
''))
);
wwv_flow_imp.component_end;
end;
/
