prompt --application/deployment/install/install_event_log
begin
--   Manifest
--     INSTALL: INSTALL-event log
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table oow_demo_event_log ('||wwv_flow.LF||
'    id            number'||wwv_flow.LF||
'                  constraint oow_demo_eve';
wwv_flow_imp.g_varchar2_table(2) := 'nt_log_pk'||wwv_flow.LF||
'                  primary key,'||wwv_flow.LF||
'    log_seq       number not null,'||wwv_flow.LF||
'    event_type    varcha';
wwv_flow_imp.g_varchar2_table(3) := 'r2(255) not null'||wwv_flow.LF||
'                  constraint oow_demo_event_event_type_ck'||wwv_flow.LF||
'                  check (';
wwv_flow_imp.g_varchar2_table(4) := 'event_type in ('||wwv_flow.LF||
'                  ''MESSAGE'','||wwv_flow.LF||
'                  ''WARNING'','||wwv_flow.LF||
'                  ''ERROR'')';
wwv_flow_imp.g_varchar2_table(5) := '),'||wwv_flow.LF||
'    event_name    varchar2(255),'||wwv_flow.LF||
'    event_detail  varchar2(4000),'||wwv_flow.LF||
'    error_message varchar2(400';
wwv_flow_imp.g_varchar2_table(6) := '0),'||wwv_flow.LF||
'    error_trace   clob,'||wwv_flow.LF||
'    created_by    varchar2(255),'||wwv_flow.LF||
'    created_on    timestamp with local ';
wwv_flow_imp.g_varchar2_table(7) := 'time zone,'||wwv_flow.LF||
'    a1            varchar2(4000),'||wwv_flow.LF||
'    a2            varchar2(4000)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace ';
wwv_flow_imp.g_varchar2_table(8) := 'trigger biu_oow_demo_event_log'||wwv_flow.LF||
'before insert or update on oow_demo_event_log'||wwv_flow.LF||
'for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   i';
wwv_flow_imp.g_varchar2_table(9) := 'f :new.id is null then'||wwv_flow.LF||
'       select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :';
wwv_flow_imp.g_varchar2_table(10) := 'new.id from dual;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'  if :new.event_type is null then'||wwv_flow.LF||
'     if :new.error_message is not null';
wwv_flow_imp.g_varchar2_table(11) := ' then'||wwv_flow.LF||
'        :new.event_type := ''ERROR'';'||wwv_flow.LF||
'     else'||wwv_flow.LF||
'        :new.event_type := ''MESSAGE'';'||wwv_flow.LF||
'     end i';
wwv_flow_imp.g_varchar2_table(12) := 'f;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'  if inserting then '||wwv_flow.LF||
'      :new.log_seq := oow_demo_seq.nextval;'||wwv_flow.LF||
'      :new.created_on ';
wwv_flow_imp.g_varchar2_table(13) := ':= localtimestamp;'||wwv_flow.LF||
'      :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(14) := '  '||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38818968947471359602)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'event log'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
