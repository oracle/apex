prompt --application/deployment/install/install_summary
begin
--   Manifest
--     INSTALL: INSTALL-summary
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'declare'||wwv_flow.LF||
'    c integer;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select count(*) into c from OOW_DEMO_ITEMS;'||wwv_flow.LF||
'    oow_demo_event_pkg.';
wwv_flow_imp.g_varchar2_table(2) := 'log (p_event_name => ''OOW_DEMO_ITEMS row count'', p_event_detail => to_char(c,''999G999G990''));'||wwv_flow.LF||
'except';
wwv_flow_imp.g_varchar2_table(3) := 'ion when others then'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_ITEMS row count'', p_error';
wwv_flow_imp.g_varchar2_table(4) := '_message => sqlerrm);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    c integer;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select count(*) into c from OOW_D';
wwv_flow_imp.g_varchar2_table(5) := 'EMO_REGIONS;'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_REGIONS row count'', p_event_detai';
wwv_flow_imp.g_varchar2_table(6) := 'l => to_char(c,''999G999G990''));'||wwv_flow.LF||
'exception when others then'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name ';
wwv_flow_imp.g_varchar2_table(7) := '=> ''OOW_DEMO_REGIONS row count'', p_error_message => sqlerrm);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    c integer;'||wwv_flow.LF||
'beg';
wwv_flow_imp.g_varchar2_table(8) := 'in'||wwv_flow.LF||
'    select count(*) into c from OOW_DEMO_STORES;'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''OOW';
wwv_flow_imp.g_varchar2_table(9) := '_DEMO_STORES row count'', p_event_detail => to_char(c,''999G999G990''));'||wwv_flow.LF||
'exception when others then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(10) := ' oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_STORES row count'', p_error_message => sqlerrm);'||wwv_flow.LF||
'e';
wwv_flow_imp.g_varchar2_table(11) := 'nd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    c integer;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select count(*) into c from OOW_DEMO_STORE_PRODUCTS;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(12) := ' oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_STORE_PRODUCTS row count'', p_event_detail => to_c';
wwv_flow_imp.g_varchar2_table(13) := 'har(c,''999G999G990''));'||wwv_flow.LF||
'exception when others then'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''OOW_D';
wwv_flow_imp.g_varchar2_table(14) := 'EMO_STORE_PRODUCTS row count'', p_error_message => sqlerrm);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    c integer;'||wwv_flow.LF||
'begin';
wwv_flow_imp.g_varchar2_table(15) := ''||wwv_flow.LF||
'    select count(*) into c from OOW_DEMO_SALES_HISTORY;'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name =>';
wwv_flow_imp.g_varchar2_table(16) := ' ''OOW_DEMO_SALES_HISTORY row count'', p_event_detail => to_char(c,''999G999G990''));'||wwv_flow.LF||
'exception when oth';
wwv_flow_imp.g_varchar2_table(17) := 'ers then'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_SALES_HISTORY row count'', p_error_mes';
wwv_flow_imp.g_varchar2_table(18) := 'sage => sqlerrm);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38819565346974548754)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'summary'
,p_sequence=>210
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
