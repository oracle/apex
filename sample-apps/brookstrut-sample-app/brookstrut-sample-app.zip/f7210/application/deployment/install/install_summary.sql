prompt --application/deployment/install/install_summary
begin
--   Manifest
--     INSTALL: INSTALL-summary
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38747582868563656959)
,p_install_id=>wwv_flow_imp.id(38728534087116032193)
,p_name=>'summary'
,p_sequence=>210
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    c integer;',
'begin',
'    select count(*) into c from OOW_DEMO_ITEMS;',
'    oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_ITEMS row count'', p_event_detail => to_char(c,''999G999G990''));',
'exception when others then',
'    oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_ITEMS row count'', p_error_message => sqlerrm);',
'end;',
'/',
'    ',
'declare',
'    c integer;',
'begin',
'    select count(*) into c from OOW_DEMO_REGIONS;',
'    oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_REGIONS row count'', p_event_detail => to_char(c,''999G999G990''));',
'exception when others then',
'    oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_REGIONS row count'', p_error_message => sqlerrm);',
'end;',
'/',
'    ',
'declare',
'    c integer;',
'begin',
'    select count(*) into c from OOW_DEMO_STORES;',
'    oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_STORES row count'', p_event_detail => to_char(c,''999G999G990''));',
'exception when others then',
'    oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_STORES row count'', p_error_message => sqlerrm);',
'end;',
'/',
'    ',
'declare',
'    c integer;',
'begin',
'    select count(*) into c from OOW_DEMO_STORE_PRODUCTS;',
'    oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_STORE_PRODUCTS row count'', p_event_detail => to_char(c,''999G999G990''));',
'exception when others then',
'    oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_STORE_PRODUCTS row count'', p_error_message => sqlerrm);',
'end;',
'/',
'    ',
'declare',
'    c integer;',
'begin',
'    select count(*) into c from OOW_DEMO_SALES_HISTORY;',
'    oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_SALES_HISTORY row count'', p_event_detail => to_char(c,''999G999G990''));',
'exception when others then',
'    oow_demo_event_pkg.log (p_event_name => ''OOW_DEMO_SALES_HISTORY row count'', p_error_message => sqlerrm);',
'end;',
'/',
'',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
