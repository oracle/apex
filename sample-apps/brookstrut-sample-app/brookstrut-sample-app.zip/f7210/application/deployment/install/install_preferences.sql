prompt --application/deployment/install/install_preferences
begin
--   Manifest
--     INSTALL: INSTALL-Preferences
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'   execute immediate ''drop table OOW_DEMO_PREFERENCES cascade constraints'';'||wwv_flow.LF||
'exception when oth';
wwv_flow_imp.g_varchar2_table(2) := 'ers then'||wwv_flow.LF||
'    if sqlcode <> -942 then /* ORA-00942: table already exists - see bug 18386198  */'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(3) := '   raise;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table oow_demo_preferences ('||wwv_flow.LF||
'    id                      numbe';
wwv_flow_imp.g_varchar2_table(4) := 'r              not null'||wwv_flow.LF||
'                                                constraint oow_demo_preferen';
wwv_flow_imp.g_varchar2_table(5) := 'ces_pk'||wwv_flow.LF||
'                                                primary key,'||wwv_flow.LF||
'    preference_name         varc';
wwv_flow_imp.g_varchar2_table(6) := 'har2(255)       not null'||wwv_flow.LF||
'                                                constraint oow_demo_prefs_p';
wwv_flow_imp.g_varchar2_table(7) := 'refname_ck'||wwv_flow.LF||
'                                                check (upper(preference_name)=preference_';
wwv_flow_imp.g_varchar2_table(8) := 'name),'||wwv_flow.LF||
'    preference_value        varchar2(255)       not null,'||wwv_flow.LF||
'    created_by              varchar';
wwv_flow_imp.g_varchar2_table(9) := '2(255)       not null,'||wwv_flow.LF||
'    created_on              timestamp with local time zone,'||wwv_flow.LF||
'    updated_by   ';
wwv_flow_imp.g_varchar2_table(10) := '           varchar2(255),'||wwv_flow.LF||
'    updated_on              timestamp with local time zone )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create uniq';
wwv_flow_imp.g_varchar2_table(11) := 'ue index oow_demo_preferences_uk on oow_demo_preferences (preference_name);'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace tri';
wwv_flow_imp.g_varchar2_table(12) := 'gger oow_demo_preferences_biu'||wwv_flow.LF||
'before insert or update on oow_demo_preferences'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin';
wwv_flow_imp.g_varchar2_table(13) := ''||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'       select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(14) := 'XXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := n';
wwv_flow_imp.g_varchar2_table(15) := 'vl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created_on := localtimestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(16) := '        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated_on := localtimestamp;'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(17) := 'nd if;'||wwv_flow.LF||
'    :new.preference_name := upper(:new.preference_name);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger oow_demo_prefer';
wwv_flow_imp.g_varchar2_table(18) := 'ences_biu enable;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(36713232547110154512)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'Preferences'
,p_sequence=>60
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
