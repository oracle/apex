prompt --application/deployment/install/install_regions
begin
--   Manifest
--     INSTALL: INSTALL-regions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''create table OOW_DEMO_REGIONS'', p_error_message =';
wwv_flow_imp.g_varchar2_table(2) := '> null);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE TABLE  OOW_DEMO_REGIONS ('||wwv_flow.LF||
'    ID                 NUMBER, '||wwv_flow.LF||
'    ROW_VERSION_NU';
wwv_flow_imp.g_varchar2_table(3) := 'MBER NUMBER,'||wwv_flow.LF||
'    REGION_NAME        VARCHAR2(255),'||wwv_flow.LF||
'    REGION_ZOOM        VARCHAR2(50),'||wwv_flow.LF||
'    REGION_L';
wwv_flow_imp.g_varchar2_table(4) := 'AT         NUMBER(9,6),'||wwv_flow.LF||
'    REGION_LNG         NUMBER(9,6),'||wwv_flow.LF||
'    REGION_COLOR       VARCHAR2(7),'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(5) := 'IS_DEFAULT_YN      VARCHAR2(1), '||wwv_flow.LF||
'    CONSTRAINT OOW_DEMO_REGIONS_PK PRIMARY KEY (ID) ENABLE'||wwv_flow.LF||
'   );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(6) := 'CREATE OR REPLACE TRIGGER BIU_OOW_DEMO_REGIONS'||wwv_flow.LF||
'BEFORE INSERT OR UPDATE ON OOW_DEMO_REGIONS'||wwv_flow.LF||
'FOR EACH ';
wwv_flow_imp.g_varchar2_table(7) := 'ROW'||wwv_flow.LF||
'BEGIN'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(8) := 'XXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(9) := '  elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end i';
wwv_flow_imp.g_varchar2_table(10) := 'f;'||wwv_flow.LF||
'END;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38800572375687079404)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'regions'
,p_sequence=>80
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
