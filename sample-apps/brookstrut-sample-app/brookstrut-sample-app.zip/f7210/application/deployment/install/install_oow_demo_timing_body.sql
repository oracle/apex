prompt --application/deployment/install/install_oow_demo_timing_body
begin
--   Manifest
--     INSTALL: INSTALL-oow_demo_timing body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body oow_demo_timing'||wwv_flow.LF||
'as'||wwv_flow.LF||
'procedure start_timer'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    g_timestamp := ';
wwv_flow_imp.g_varchar2_table(2) := 'systimestamp;'||wwv_flow.LF||
'end start_timer;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_elap return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    return extract (second ';
wwv_flow_imp.g_varchar2_table(3) := 'from (systimestamp - g_timestamp) );'||wwv_flow.LF||
'end get_elap;'||wwv_flow.LF||
'end oow_demo_timing;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13953744712245198561)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'oow_demo_timing body'
,p_sequence=>230
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
