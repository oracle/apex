prompt --application/deployment/install/install_oow_demo_timing_body
begin
--   Manifest
--     INSTALL: INSTALL-oow_demo_timing body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13881762233834306766)
,p_install_id=>wwv_flow_imp.id(38728534087116032193)
,p_name=>'oow_demo_timing body'
,p_sequence=>230
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package body oow_demo_timing',
'as',
'procedure start_timer',
'is',
'begin',
'    g_timestamp := systimestamp;',
'end start_timer;',
'',
'function get_elap return number',
'is',
'begin',
'    return extract (second from (systimestamp - g_timestamp) );',
'end get_elap;',
'end oow_demo_timing;',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
