prompt --application/deployment/install/install_items
begin
--   Manifest
--     INSTALL: INSTALL-items
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(25524479940322536909)
,p_install_id=>wwv_flow_imp.id(25524424439166384136)
,p_name=>'items'
,p_sequence=>70
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    oow_demo_event_pkg.log (p_event_name => ''create table OOW_DEMO_ITEMS'', p_error_message => null);',
'end;',
'/',
'',
'CREATE TABLE  OOW_DEMO_ITEMS (',
'    ID                 NUMBER, ',
'    ROW_VERSION_NUMBER NUMBER, ',
'    TYPE               VARCHAR2(255) NOT NULL ENABLE, ',
'    ITEM_NAME          VARCHAR2(60) NOT NULL ENABLE, ',
'    ITEM_DESC          VARCHAR2(255), ',
'    MSRP               NUMBER DEFAULT 1 NOT NULL ENABLE, ',
'    CONSTRAINT OOW_DEMO_ITEMS_PK PRIMARY KEY (ID) ENABLE',
'   );',
'',
'',
'CREATE OR REPLACE TRIGGER BIU_OOW_DEMO_ITEMS',
'BEFORE INSERT OR UPDATE ON OOW_DEMO_ITEMS',
'FOR EACH ROW',
'BEGIN',
'   if :new.ID is null then',
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;',
'   end if;',
'   if inserting then',
'       :new.row_version_number := 1;',
'   elsif updating then',
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;',
'   end if;',
'END;',
'/',
'show errors',
''))
);
wwv_flow_imp.component_end;
end;
/
