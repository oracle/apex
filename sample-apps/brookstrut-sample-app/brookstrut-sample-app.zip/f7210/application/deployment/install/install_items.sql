prompt --application/deployment/install/install_items
begin
--   Manifest
--     INSTALL: INSTALL-items
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''create table OOW_DEMO_ITEMS'', p_error_message => ';
wwv_flow_imp.g_varchar2_table(2) := 'null);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE TABLE  OOW_DEMO_ITEMS ('||wwv_flow.LF||
'    ID                 NUMBER, '||wwv_flow.LF||
'    ROW_VERSION_NUMBER';
wwv_flow_imp.g_varchar2_table(3) := ' NUMBER, '||wwv_flow.LF||
'    ITEM_TYPE          VARCHAR2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'    ITEM_NAME          VARCHAR2(60)';
wwv_flow_imp.g_varchar2_table(4) := ' NOT NULL ENABLE, '||wwv_flow.LF||
'    ITEM_DESC          VARCHAR2(255), '||wwv_flow.LF||
'    MSRP               NUMBER DEFAULT 1 NO';
wwv_flow_imp.g_varchar2_table(5) := 'T NULL ENABLE, '||wwv_flow.LF||
'    CONSTRAINT OOW_DEMO_ITEMS_PK PRIMARY KEY (ID) ENABLE'||wwv_flow.LF||
'   );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE T';
wwv_flow_imp.g_varchar2_table(6) := 'RIGGER BIU_OOW_DEMO_ITEMS'||wwv_flow.LF||
'BEFORE INSERT OR UPDATE ON OOW_DEMO_ITEMS'||wwv_flow.LF||
'FOR EACH ROW'||wwv_flow.LF||
'BEGIN'||wwv_flow.LF||
'   if :new.ID';
wwv_flow_imp.g_varchar2_table(7) := ' is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from';
wwv_flow_imp.g_varchar2_table(8) := ' dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(9) := '      :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'END;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38800572066683076761)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'items'
,p_sequence=>70
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
