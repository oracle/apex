prompt --application/deployment/install/install_scope
begin
--   Manifest
--     INSTALL: INSTALL-scope
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38746986799535476606)
,p_install_id=>wwv_flow_imp.id(38728534087116032193)
,p_name=>'scope'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>'rem ALTER SESSION SET PLSCOPE_SETTINGS = ''IDENTIFIERS:NONE'';'
);
wwv_flow_imp.component_end;
end;
/
