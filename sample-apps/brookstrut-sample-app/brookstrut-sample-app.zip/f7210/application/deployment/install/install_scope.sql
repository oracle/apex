prompt --application/deployment/install/install_scope
begin
--   Manifest
--     INSTALL: INSTALL-scope
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(25542877151585828549)
,p_install_id=>wwv_flow_imp.id(25524424439166384136)
,p_name=>'scope'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>'rem ALTER SESSION SET PLSCOPE_SETTINGS = ''IDENTIFIERS:NONE'';'
);
wwv_flow_imp.component_end;
end;
/
