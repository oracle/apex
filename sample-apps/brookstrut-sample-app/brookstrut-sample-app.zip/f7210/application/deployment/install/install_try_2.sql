prompt --application/deployment/install/install_try_2
begin
--   Manifest
--     INSTALL: INSTALL-try 2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(25549159025188014992)
,p_install_id=>wwv_flow_imp.id(25524424439166384136)
,p_name=>'try 2'
,p_sequence=>220
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    c number := 0;',
'    t varchar2(32767) := null;',
'begin',
'    oow_demo_event_pkg.log (p_event_name => ''Validate Sales History'', p_error_message => null);',
'    select count(*) into c from OOW_DEMO_SALES_HISTORY;',
'    oow_demo_event_pkg.log (p_event_name => ''Sales History Row Count = ''||c, p_error_message => null);',
'    if c = 0 then',
'       oow_demo_event_pkg.log (p_event_name => ''transaction generation starting, attempt 2'', p_error_message => null);',
'       oow_demo_gen_data_pkg.oow_demo_gen_sales_data (',
'         p_days      =>365,',
'         p_orders    => 5,',
'         p_truncate  =>''N'');',
'    oow_demo_event_pkg.log (p_event_name => ''transaction generation completed'', p_error_message => null);',
'    end if;',
'exception when others then',
'    --t := dbms_utility.format_error_backtrace;',
'    oow_demo_event_pkg.log (p_event_name => ''error gennerating data'', p_error_message => sqlerrm, p_error_trace=>t);',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
