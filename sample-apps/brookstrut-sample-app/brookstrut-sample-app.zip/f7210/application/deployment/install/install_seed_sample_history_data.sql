prompt --application/deployment/install/install_seed_sample_history_data
begin
--   Manifest
--     INSTALL: INSTALL-seed sample history data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'declare'||wwv_flow.LF||
'    t varchar(32767) := null;'||wwv_flow.LF||
'    s number := 5000;'||wwv_flow.LF||
'    o number := 5;'||wwv_flow.LF||
'    d number := 365;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2) := 'begin'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''transaction generation starting, attempt 1'', p_er';
wwv_flow_imp.g_varchar2_table(3) := 'ror_message => null);'||wwv_flow.LF||
'    oow_demo_gen_data_pkg.oow_demo_gen_sales_data ('||wwv_flow.LF||
'        p_days      => d,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(4) := '        p_orders    => o,'||wwv_flow.LF||
'        p_truncate  =>''N'','||wwv_flow.LF||
'        p_max_rows  => s);'||wwv_flow.LF||
'    oow_demo_event_p';
wwv_flow_imp.g_varchar2_table(5) := 'kg.log (p_event_name => ''transaction generation completed'', p_error_message => null);'||wwv_flow.LF||
'exception when';
wwv_flow_imp.g_varchar2_table(6) := ' others then'||wwv_flow.LF||
'    --t := dbms_utility.format_error_backtrace;'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_nam';
wwv_flow_imp.g_varchar2_table(7) := 'e => ''error gennerating data'', p_error_message => sqlerrm, p_error_trace=>t);'||wwv_flow.LF||
'    raise;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38816561456376231976)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'seed sample history data'
,p_sequence=>200
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
