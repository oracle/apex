prompt --application/deployment/install/install_seed_sample_history_data
begin
--   Manifest
--     INSTALL: INSTALL-seed sample history data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38759039513969733153)
,p_install_id=>wwv_flow_imp.id(38742994623120425165)
,p_name=>'seed sample history data'
,p_sequence=>200
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    t varchar(32767) := null;',
'    s number := 5000;',
'    o number := 5;',
'    d number := 365;',
'begin',
'    oow_demo_event_pkg.log (p_event_name => ''transaction generation starting, attempt 1'', p_error_message => null);',
'    oow_demo_gen_data_pkg.oow_demo_gen_sales_data (',
'        p_days      => d,',
'        p_orders    => o,',
'        p_truncate  =>''N'',',
'        p_max_rows  => s);',
'    oow_demo_event_pkg.log (p_event_name => ''transaction generation completed'', p_error_message => null);',
'exception when others then',
'    --t := dbms_utility.format_error_backtrace;',
'    oow_demo_event_pkg.log (p_event_name => ''error gennerating data'', p_error_message => sqlerrm, p_error_trace=>t);',
'    raise;',
'end;',
'/',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
