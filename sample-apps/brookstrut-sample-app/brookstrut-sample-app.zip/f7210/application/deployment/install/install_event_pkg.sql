prompt --application/deployment/install/install_event_pkg
begin
--   Manifest
--     INSTALL: INSTALL-event pkg
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38761448108143908941)
,p_install_id=>wwv_flow_imp.id(38742994623120425165)
,p_name=>'event pkg'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package oow_demo_event_pkg',
'as',
'procedure log (',
'    p_event_name    in varchar2,',
'    p_event_type    in varchar2 default null,',
'    p_event_detail  in varchar2 default null,',
'    p_error_message in varchar2 default null,',
'    p_error_trace   in varchar2 default null,',
'    p_a1            in varchar2 default null,',
'    p_a2            in varchar2 default null',
'    );',
'end;',
'/',
'show errors',
'    ',
' ',
'create or replace package body oow_demo_event_pkg',
'as',
'procedure log (',
'    p_event_name    in varchar2,',
'    p_event_type    in varchar2 default null,',
'    p_event_detail  in varchar2 default null,',
'    p_error_message in varchar2 default null,',
'    p_error_trace   in varchar2 default null,',
'    p_a1            in varchar2 default null,',
'    p_a2            in varchar2 default null',
')',
'is',
'begin',
'  ',
'    insert into oow_demo_event_log ',
'        (event_type, event_name, event_detail, error_message, error_trace, a1, a2) values',
'        (p_event_type, p_event_name, p_event_detail, p_error_message, p_error_trace, p_a1, p_a2);',
'    commit;',
'end log;',
'end oow_demo_event_pkg;',
'/',
'show errors',
'',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(37050958984846750961)
,p_script_id=>wwv_flow_imp.id(38761448108143908941)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'OOW_DEMO_EVENT_PKG'
);
wwv_flow_imp.component_end;
end;
/
