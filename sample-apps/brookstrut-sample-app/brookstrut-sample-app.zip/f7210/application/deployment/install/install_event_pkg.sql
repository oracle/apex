prompt --application/deployment/install/install_event_pkg
begin
--   Manifest
--     INSTALL: INSTALL-event pkg
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package oow_demo_event_pkg'||wwv_flow.LF||
'as'||wwv_flow.LF||
'procedure log ('||wwv_flow.LF||
'    p_event_name    in varchar2,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2) := ' p_event_type    in varchar2 default null,'||wwv_flow.LF||
'    p_event_detail  in varchar2 default null,'||wwv_flow.LF||
'    p_error';
wwv_flow_imp.g_varchar2_table(3) := '_message in varchar2 default null,'||wwv_flow.LF||
'    p_error_trace   in varchar2 default null,'||wwv_flow.LF||
'    p_a1           ';
wwv_flow_imp.g_varchar2_table(4) := ' in varchar2 default null,'||wwv_flow.LF||
'    p_a2            in varchar2 default null'||wwv_flow.LF||
'    );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(5) := '  '||wwv_flow.LF||
' '||wwv_flow.LF||
'create or replace package body oow_demo_event_pkg'||wwv_flow.LF||
'as'||wwv_flow.LF||
'procedure log ('||wwv_flow.LF||
'    p_event_name    in var';
wwv_flow_imp.g_varchar2_table(6) := 'char2,'||wwv_flow.LF||
'    p_event_type    in varchar2 default null,'||wwv_flow.LF||
'    p_event_detail  in varchar2 default null,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(7) := '   p_error_message in varchar2 default null,'||wwv_flow.LF||
'    p_error_trace   in varchar2 default null,'||wwv_flow.LF||
'    p_a1 ';
wwv_flow_imp.g_varchar2_table(8) := '           in varchar2 default null,'||wwv_flow.LF||
'    p_a2            in varchar2 default null'||wwv_flow.LF||
')'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(9) := 'insert into oow_demo_event_log '||wwv_flow.LF||
'        (event_type, event_name, event_detail, error_message, error_';
wwv_flow_imp.g_varchar2_table(10) := 'trace, a1, a2) values'||wwv_flow.LF||
'        (p_event_type, p_event_name, p_event_detail, p_error_message, p_error_';
wwv_flow_imp.g_varchar2_table(11) := 'trace, p_a1, p_a2);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end log;'||wwv_flow.LF||
'end oow_demo_event_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38818970050550407764)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'event pkg'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(37108480927253249784)
,p_script_id=>wwv_flow_imp.id(38818970050550407764)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'OOW_DEMO_EVENT_PKG'
);
wwv_flow_imp.component_end;
end;
/
