prompt --application/deployment/install/install_products
begin
--   Manifest
--     INSTALL: INSTALL-products
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE  OOW_DEMO_STORE_PRODUCTS ('||wwv_flow.LF||
'    ID                 NUMBER, '||wwv_flow.LF||
'    ROW_VERSION_NUMBER NUMBE';
wwv_flow_imp.g_varchar2_table(2) := 'R, '||wwv_flow.LF||
'    STORE_ID           NUMBER, '||wwv_flow.LF||
'    ITEM_ID            NUMBER, '||wwv_flow.LF||
'    SALE_START_DATE    DATE, '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(3) := '  DISCOUNT_PCT       NUMBER, '||wwv_flow.LF||
'    SALE_END_DATE      DATE, '||wwv_flow.LF||
'    ITEM_PRICE         NUMBER,'||wwv_flow.LF||
'    CONST';
wwv_flow_imp.g_varchar2_table(4) := 'RAINT OOW_DEMO_STORE_PRODUCTS_PK PRIMARY KEY (ID) ENABLE'||wwv_flow.LF||
'   );'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER BIU_OOW_DE';
wwv_flow_imp.g_varchar2_table(5) := 'MO_STORE_PRODUCTS'||wwv_flow.LF||
'BEFORE INSERT OR UPDATE ON OOW_DEMO_STORE_PRODUCTS'||wwv_flow.LF||
'FOR EACH ROW'||wwv_flow.LF||
'BEGIN'||wwv_flow.LF||
'   if :new.I';
wwv_flow_imp.g_varchar2_table(6) := 'D is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id fro';
wwv_flow_imp.g_varchar2_table(7) := 'm dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(8) := '       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'END;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(9) := ''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38800573277549089345)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'products'
,p_sequence=>110
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
