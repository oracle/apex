prompt --application/deployment/install/install_products
begin
--   Manifest
--     INSTALL: INSTALL-products
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38717017704494300011)
,p_install_id=>wwv_flow_imp.id(38716960992472134654)
,p_name=>'products'
,p_sequence=>110
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE  OOW_DEMO_STORE_PRODUCTS (',
'    ID                 NUMBER, ',
'    ROW_VERSION_NUMBER NUMBER, ',
'    STORE_ID           NUMBER, ',
'    ITEM_ID            NUMBER, ',
'    SALE_START_DATE    DATE, ',
'    DISCOUNT_PCT       NUMBER, ',
'    SALE_END_DATE      DATE, ',
'    ITEM_PRICE         NUMBER,',
'    CONSTRAINT OOW_DEMO_STORE_PRODUCTS_PK PRIMARY KEY (ID) ENABLE',
'   );',
'',
'CREATE OR REPLACE TRIGGER BIU_OOW_DEMO_STORE_PRODUCTS',
'BEFORE INSERT OR UPDATE ON OOW_DEMO_STORE_PRODUCTS',
'FOR EACH ROW',
'BEGIN',
'   if :new.ID is null then',
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;',
'   end if;',
'   if inserting then',
'       :new.row_version_number := 1;',
'   elsif updating then',
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;',
'   end if;',
'END;',
'/',
'show errors',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
