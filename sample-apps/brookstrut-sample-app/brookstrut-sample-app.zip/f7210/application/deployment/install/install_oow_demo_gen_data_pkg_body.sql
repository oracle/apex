prompt --application/deployment/install/install_oow_demo_gen_data_pkg_body
begin
--   Manifest
--     INSTALL: INSTALL-oow_demo_gen_data_pkg BODY
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body oow_demo_gen_data_pkg'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    g_last_history_id number;'||wwv_flow.LF||
''||wwv_flow.LF||
'    '||wwv_flow.LF||
'function';
wwv_flow_imp.g_varchar2_table(2) := ' generate_transaction '||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    oow_demo_gen_sales_data ('||wwv_flow.LF||
'       p_days => 1,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(3) := '       p_orders => 1,'||wwv_flow.LF||
'       p_truncate => ''N'','||wwv_flow.LF||
'       p_max_stores => 1'||wwv_flow.LF||
'       );'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    r';
wwv_flow_imp.g_varchar2_table(4) := 'eturn g_last_history_id;'||wwv_flow.LF||
'end generate_transaction;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- G E N   S A L E S   D A T A'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure';
wwv_flow_imp.g_varchar2_table(5) := ' oow_demo_gen_sales_data ('||wwv_flow.LF||
'    p_days       in number   default 90, '||wwv_flow.LF||
'    p_orders     in number   de';
wwv_flow_imp.g_varchar2_table(6) := 'fault 50, '||wwv_flow.LF||
'    p_truncate   in varchar2 default ''Y'','||wwv_flow.LF||
'    p_max_stores in number   default 500,'||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(7) := '_max_rows   in number   default 0'||wwv_flow.LF||
')'||wwv_flow.LF||
'as'||wwv_flow.LF||
'    cursor log_csr is'||wwv_flow.LF||
'        select owner, start_time, to_ch';
wwv_flow_imp.g_varchar2_table(8) := 'ar(start_time,''YYYY.MM.DD HH24:MI:SS'') start_txt'||wwv_flow.LF||
'        from oow_demo_hist_gen_log'||wwv_flow.LF||
'        where st';
wwv_flow_imp.g_varchar2_table(9) := 'art_time is not null'||wwv_flow.LF||
'            and end_time is null;'||wwv_flow.LF||
'    log_rec            log_csr%ROWTYPE;'||wwv_flow.LF||
'    l';
wwv_flow_imp.g_varchar2_table(10) := '_log_id           number;'||wwv_flow.LF||
'    l_date             timestamp with local time zone;'||wwv_flow.LF||
'    l_transaction  ';
wwv_flow_imp.g_varchar2_table(11) := '    varchar2(30);'||wwv_flow.LF||
'    l_order            number;'||wwv_flow.LF||
'    i                  number;'||wwv_flow.LF||
'    l_qty           ';
wwv_flow_imp.g_varchar2_table(12) := '   number;'||wwv_flow.LF||
'    l_item_price       number;'||wwv_flow.LF||
'    l_app_user         varchar(255);'||wwv_flow.LF||
'    l_history_id     ';
wwv_flow_imp.g_varchar2_table(13) := '  number;'||wwv_flow.LF||
'    l_max_stores       number;'||wwv_flow.LF||
'    l_store_count      integer := 0;'||wwv_flow.LF||
'    l_product_count   ';
wwv_flow_imp.g_varchar2_table(14) := ' integer := 0;'||wwv_flow.LF||
'    x                  number;'||wwv_flow.LF||
'    l_app_session      varchar2(255);'||wwv_flow.LF||
'    l_error_trac';
wwv_flow_imp.g_varchar2_table(15) := 'e      varchar2(32767);'||wwv_flow.LF||
'    l_continue         boolean := true;'||wwv_flow.LF||
'    l_max_rows         integer := 0;';
wwv_flow_imp.g_varchar2_table(16) := ''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- initialize variables'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_max_rows     := nvl(p_max_rows,0);'||wwv_flow.LF||
'    g_inse';
wwv_flow_imp.g_varchar2_table(17) := 'rt_count := 0;'||wwv_flow.LF||
'    g_progress     := 1;'||wwv_flow.LF||
'    l_max_stores   := nvl(p_max_stores,100);'||wwv_flow.LF||
'    l_app_user ';
wwv_flow_imp.g_varchar2_table(18) := '    := v(''APP_USER'');'||wwv_flow.LF||
'    l_app_session  := v(''APP_SESSION'');'||wwv_flow.LF||
'    g_progress     := 2;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(19) := '- insert history log which gets updated later'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    g_progress := 3;'||wwv_flow.LF||
'    insert into oow_demo_h';
wwv_flow_imp.g_varchar2_table(20) := 'ist_gen_log ( owner, start_time, num_days, max_orders )'||wwv_flow.LF||
'    values ( l_app_user, localtimestamp, p_d';
wwv_flow_imp.g_varchar2_table(21) := 'ays, p_orders )'||wwv_flow.LF||
'    returning id into l_log_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- Truncate sales history table if reque';
wwv_flow_imp.g_varchar2_table(22) := 'sted'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if nvl(p_truncate,''N'') = ''Y'' then'||wwv_flow.LF||
'        oow_demo_event_pkg.log(p_event_name => ''ab';
wwv_flow_imp.g_varchar2_table(23) := 'out to truncate oow_demo_sales_history table'');'||wwv_flow.LF||
'        execute immediate ''truncate table oow_demo_s';
wwv_flow_imp.g_varchar2_table(24) := 'ales_history'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    x := round(dbms_random.value(1,4));'||wwv_flow.LF||
'    g_progress := 4;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(25) := '  -- loop over days requested (p_days)'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for i in 1..greatest(p_days,1) loop'||wwv_flow.LF||
'        g_prog';
wwv_flow_imp.g_varchar2_table(26) := 'ress := 5;'||wwv_flow.LF||
'        g_context := ''i=''||i;'||wwv_flow.LF||
'        l_date := localtimestamp - numtodsinterval(i-1,''day';
wwv_flow_imp.g_varchar2_table(27) := ''');'||wwv_flow.LF||
'        '||wwv_flow.LF||
'        g_i := i;'||wwv_flow.LF||
'        -- walk every store for the date'||wwv_flow.LF||
'        l_store_count := 0;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(28) := ''||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- loop over open stores'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        for s in (select id, region_id, deco';
wwv_flow_imp.g_varchar2_table(29) := 'de(x,1,n1,2,n2,3,n3,4,n4,id) x'||wwv_flow.LF||
'                  from oow_demo_stores'||wwv_flow.LF||
'                  where STORE_';
wwv_flow_imp.g_varchar2_table(30) := 'OPEN_DATE <= l_date '||wwv_flow.LF||
'                  order by 3) loop'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            -- audit'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(31) := '    --'||wwv_flow.LF||
'            g_progress := 6;'||wwv_flow.LF||
'            g_context := ''i=''||i||'', store_id=''||s.id;'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(32) := '   --'||wwv_flow.LF||
'            -- increment store counter'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            l_store_count := l_store_cou';
wwv_flow_imp.g_varchar2_table(33) := 'nt + i;'||wwv_flow.LF||
'            g_store_count := l_store_count;'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            -- max stores default';
wwv_flow_imp.g_varchar2_table(34) := 's to 1'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            if l_store_count > l_max_stores then '||wwv_flow.LF||
'                exit; '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(35) := '       end if;'||wwv_flow.LF||
'            g_last_history_id := null;'||wwv_flow.LF||
'            -- make 0 to p_orders 500 orders f';
wwv_flow_imp.g_varchar2_table(36) := 'or this date in the store'||wwv_flow.LF||
'            g_transaction := null;'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            -- generate ';
wwv_flow_imp.g_varchar2_table(37) := 'transactions, between zero and p_orders '||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            for l_order in 1..greatest(round';
wwv_flow_imp.g_varchar2_table(38) := '(dbms_random.value(0,p_orders)),1) loop'||wwv_flow.LF||
'                g_progress := 7;'||wwv_flow.LF||
'                g_context :';
wwv_flow_imp.g_varchar2_table(39) := '= ''i=''||i||'', store_id=''||s.id||'', l_order_id=''||l_order;'||wwv_flow.LF||
'                -- something unique for a ';
wwv_flow_imp.g_varchar2_table(40) := 'transaction id'||wwv_flow.LF||
'                l_transaction := to_char(l_date,''YYYYMMDD'') || ''-''|| l_order ;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(41) := '          g_transaction := l_transaction;'||wwv_flow.LF||
'                -- add a weight to sales items to give a h';
wwv_flow_imp.g_varchar2_table(42) := 'igher chance they are sold'||wwv_flow.LF||
'                g_item_id := null;'||wwv_flow.LF||
'                --'||wwv_flow.LF||
'                -- ';
wwv_flow_imp.g_varchar2_table(43) := 'loop over store products, not all products are sold in all stores'||wwv_flow.LF||
'                --'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(44) := ' for p in (select id, item_id, item_price,'||wwv_flow.LF||
'                            case when l_date between sale';
wwv_flow_imp.g_varchar2_table(45) := '_start_date and sale_end_date then 3'||wwv_flow.LF||
'                            else 1 end weight'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(46) := '       from oow_demo_store_products'||wwv_flow.LF||
'                        where store_id = s.id '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(47) := '       ) loop'||wwv_flow.LF||
'                    g_progress := 8;'||wwv_flow.LF||
'                    l_product_count := l_product_';
wwv_flow_imp.g_varchar2_table(48) := 'count + 1;'||wwv_flow.LF||
'                    g_context := ''i=''||i||'', store_id=''||s.id||'', l_order_id=''||l_order||';
wwv_flow_imp.g_varchar2_table(49) := ''', product_id=''||p.id||'', l_product_count=''||l_product_count;'||wwv_flow.LF||
'                    if p_orders = 1 an';
wwv_flow_imp.g_varchar2_table(50) := 'd l_product_count > 1 then exit; end if;'||wwv_flow.LF||
'                    g_item_id := p.item_id;'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(51) := '     -- for none sale items a 50/50 on sale'||wwv_flow.LF||
'                    -- for sale items its 3/4 chance'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(52) := '                 -- for one transaction orders buy 1 anyway'||wwv_flow.LF||
'                    g_qty := null;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(53) := '               g_price := null;'||wwv_flow.LF||
'                    g_progress := 8;'||wwv_flow.LF||
'                    if ( round(';
wwv_flow_imp.g_varchar2_table(54) := 'dbms_random.value(0,p.weight)) != 0 ) or (p_days = 1 and p_orders = 1) then'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(55) := '-- pick how many to buy'||wwv_flow.LF||
'                        l_qty := greatest(round(dbms_random.value(1,10)),1);';
wwv_flow_imp.g_varchar2_table(56) := ''||wwv_flow.LF||
'                        g_qty := l_qty;'||wwv_flow.LF||
'                        -- if store discount price null, us';
wwv_flow_imp.g_varchar2_table(57) := 'e msrp price'||wwv_flow.LF||
'                        if p.item_price is null then'||wwv_flow.LF||
'                            for c1';
wwv_flow_imp.g_varchar2_table(58) := ' in (select msrp from oow_demo_items where id = p.item_id) loop'||wwv_flow.LF||
'                                l_it';
wwv_flow_imp.g_varchar2_table(59) := 'em_price := c1.msrp;'||wwv_flow.LF||
'                            end loop;'||wwv_flow.LF||
'                        else'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(60) := '                l_item_price := p.item_price;'||wwv_flow.LF||
'                        end if;'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(61) := '  g_price := l_item_price;'||wwv_flow.LF||
'                        -- order it up'||wwv_flow.LF||
'                        g_progress';
wwv_flow_imp.g_varchar2_table(62) := ' := 9;'||wwv_flow.LF||
'                        insert into oow_demo_sales_history('||wwv_flow.LF||
'                            store';
wwv_flow_imp.g_varchar2_table(63) := '_id,product_id,date_of_sale,quantity,transaction_id,item_price)'||wwv_flow.LF||
'                        values'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(64) := '                       (s.id,p.item_id,l_date,l_qty,l_transaction,l_item_price)'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(65) := '    returning id into g_last_history_id;'||wwv_flow.LF||
'                        g_insert_count := g_insert_count +1';
wwv_flow_imp.g_varchar2_table(66) := ';'||wwv_flow.LF||
'                        if l_max_rows != 0 and g_insert_count >= nvl(l_max_rows,5000) then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(67) := '                     l_continue := false;'||wwv_flow.LF||
'                        end if;'||wwv_flow.LF||
'                    end if';
wwv_flow_imp.g_varchar2_table(68) := ';'||wwv_flow.LF||
'                    if not l_continue then exit; end if;'||wwv_flow.LF||
'                end loop;'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(69) := ' commit;'||wwv_flow.LF||
'                g_progress := 10;'||wwv_flow.LF||
'                if not l_continue then exit; end if;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(70) := '        end loop;'||wwv_flow.LF||
'            if not l_continue then exit; end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        if not ';
wwv_flow_imp.g_varchar2_table(71) := 'l_continue then exit; end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    g_progress := 100;'||wwv_flow.LF||
'    update oow_demo_hist_gen_log';
wwv_flow_imp.g_varchar2_table(72) := ''||wwv_flow.LF||
'    set end_time = localtimestamp, row_count = g_insert_count'||wwv_flow.LF||
'    where id = l_log_id;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(73) := ''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'    oow_demo_event_pkg.log ('||wwv_flow.LF||
'        p_event_name => ''error executin';
wwv_flow_imp.g_varchar2_table(74) := 'g oow_demo_gen_sales_data'', '||wwv_flow.LF||
'        p_error_message => sqlerrm, '||wwv_flow.LF||
'        p_error_trace => l_error_t';
wwv_flow_imp.g_varchar2_table(75) := 'race, '||wwv_flow.LF||
'        p_a1=>g_progress, '||wwv_flow.LF||
'        p_a2=>g_context);'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        if l_log_id is not nu';
wwv_flow_imp.g_varchar2_table(76) := 'll then'||wwv_flow.LF||
'            update oow_demo_hist_gen_log'||wwv_flow.LF||
'            set end_time = localtimestamp, row_coun';
wwv_flow_imp.g_varchar2_table(77) := 't = g_insert_count'||wwv_flow.LF||
'            where id = l_log_id;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        raise;'||wwv_flow.LF||
'end oo';
wwv_flow_imp.g_varchar2_table(78) := 'w_demo_gen_sales_data;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure exec_100_transactions'||wwv_flow.LF||
'is'||wwv_flow.LF||
'   x number;'||wwv_flow.LF||
'   l_found boolean;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'f';
wwv_flow_imp.g_varchar2_table(79) := 'or i in 1..100 loop'||wwv_flow.LF||
'   x :=  generate_transaction;'||wwv_flow.LF||
''||wwv_flow.LF||
'   l_found := false;'||wwv_flow.LF||
'   for c1 in (select id,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(80) := '                   store_id, '||wwv_flow.LF||
'                     created_on,'||wwv_flow.LF||
'                     product_id, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(81) := '                  quantity, '||wwv_flow.LF||
'                     item_price,'||wwv_flow.LF||
'                     date_of_sale,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(82) := '                  (select store_name '||wwv_flow.LF||
'                      from OOW_demo_stores s '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(83) := '      where s.id = h.store_id) store,'||wwv_flow.LF||
'                     (select item_Name from OOW_demo_items i'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(84) := '                     where i.id = h.product_id) product'||wwv_flow.LF||
'              from oow_demo_sales_history h'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(85) := '              where id = x) loop'||wwv_flow.LF||
'     sys.htp.p(''Transaction: ''||to_char(i));'||wwv_flow.LF||
'     sys.htp.p(''<br>ID';
wwv_flow_imp.g_varchar2_table(86) := ': ''||apex_escape.html(c1.id));'||wwv_flow.LF||
'     sys.htp.p(''<br>Store: ''||apex_escape.html(c1.store));'||wwv_flow.LF||
'     sys.h';
wwv_flow_imp.g_varchar2_table(87) := 'tp.p(''<br>Product: ''||apex_escape.html(c1.product));'||wwv_flow.LF||
'     sys.htp.p(''<br>Date of Sale: ''||to_char(c1';
wwv_flow_imp.g_varchar2_table(88) := '.date_of_sale,''DD-MM-YYYY HH24:MI:SS''));'||wwv_flow.LF||
'     sys.htp.p(''<br>Date of Posting: ''||to_char(c1.created_';
wwv_flow_imp.g_varchar2_table(89) := 'on,''DD-MM-YYYY HH24:MI:SS''));'||wwv_flow.LF||
'     sys.htp.p(''<br>Quantity: ''||to_char(c1.quantity,''999G999G999G990''';
wwv_flow_imp.g_varchar2_table(90) := '));'||wwv_flow.LF||
'     sys.htp.p(''<br>Price: ''||to_char(c1.item_price,''$999G999G999G990D00''));'||wwv_flow.LF||
'     sys.htp.p(''<br';
wwv_flow_imp.g_varchar2_table(91) := '>Sale: ''||to_char(c1.item_price * c1.quantity,''$999G999G999G990D00''));'||wwv_flow.LF||
'     l_found := true;'||wwv_flow.LF||
'   end ';
wwv_flow_imp.g_varchar2_table(92) := 'loop;'||wwv_flow.LF||
'     if not l_found then '||wwv_flow.LF||
'         sys.htp.p(''Transaction: ''||to_char(i));'||wwv_flow.LF||
'         sys.htp.p(';
wwv_flow_imp.g_varchar2_table(93) := '''<br>Day loop: ''||oow_demo_gen_data_pkg.g_i);'||wwv_flow.LF||
'         sys.htp.p(''<br>Store loop: ''||oow_demo_gen_da';
wwv_flow_imp.g_varchar2_table(94) := 'ta_pkg.g_store_count);'||wwv_flow.LF||
'         sys.htp.p(''<br>Item ID: ''||oow_demo_gen_data_pkg.g_item_id);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(95) := '  sys.htp.p(''<br>Quantity: ''||oow_demo_gen_data_pkg.g_qty);'||wwv_flow.LF||
'         sys.htp.p(''<br>Attempted Transa';
wwv_flow_imp.g_varchar2_table(96) := 'ction: ''||apex_escape.html(oow_demo_gen_data_pkg.g_transaction));'||wwv_flow.LF||
'         sys.htp.p(''<br>Order requ';
wwv_flow_imp.g_varchar2_table(97) := 'est did not result in order being processed'');'||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     sys.htp.p(''<hr>'');'||wwv_flow.LF||
'end loop;'||wwv_flow.LF||
'commit';
wwv_flow_imp.g_varchar2_table(98) := ';'||wwv_flow.LF||
'end exec_100_transactions;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure exec_n_transactions ('||wwv_flow.LF||
'    P_transactions in number default 1';
wwv_flow_imp.g_varchar2_table(99) := ''||wwv_flow.LF||
')'||wwv_flow.LF||
'is'||wwv_flow.LF||
'   x number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for i in 1..P_transactions loop'||wwv_flow.LF||
'        x := generate_transaction;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(100) := 'end loop;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end exec_n_transactions;'||wwv_flow.LF||
''||wwv_flow.LF||
'end oow_demo_gen_data_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40267886220742663228)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'oow_demo_gen_data_pkg BODY'
,p_sequence=>180
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
