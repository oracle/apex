prompt --application/deployment/install/install_sequence
begin
--   Manifest
--     INSTALL: INSTALL-sequence
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38746987298627485835)
,p_install_id=>wwv_flow_imp.id(38728534087116032193)
,p_name=>'sequence'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>'create sequence oow_demo_seq;'
);
wwv_flow_imp.component_end;
end;
/
