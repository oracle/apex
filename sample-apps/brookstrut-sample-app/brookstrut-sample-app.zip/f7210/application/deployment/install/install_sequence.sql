prompt --application/deployment/install/install_sequence
begin
--   Manifest
--     INSTALL: INSTALL-sequence
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38735414203983588296)
,p_install_id=>wwv_flow_imp.id(38716960992472134654)
,p_name=>'sequence'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>'create sequence oow_demo_seq;'
);
wwv_flow_imp.component_end;
end;
/
