prompt --application/deployment/install/install_oow_demo_sample_data_body
begin
--   Manifest
--     INSTALL: INSTALL-oow_demo_sample_data BODY
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body oow_demo_sample_data '||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure load '||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    load_regions;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2) := '    load_items;'||wwv_flow.LF||
'    load_stores;'||wwv_flow.LF||
'    load_store_products;'||wwv_flow.LF||
'end load;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- R E G I O N S'||wwv_flow.LF||
'--'||wwv_flow.LF||
'procedu';
wwv_flow_imp.g_varchar2_table(3) := 're load_regions'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''insert oow_demo_regions begin''';
wwv_flow_imp.g_varchar2_table(4) := ', p_error_message => null);'||wwv_flow.LF||
'    insert into oow_demo_regions'||wwv_flow.LF||
'    (id, region_name, region_zoom, regi';
wwv_flow_imp.g_varchar2_table(5) := 'on_lat, region_lng, region_color, is_default_yn )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, ''San Francisco'', 11, 37.8, -122';
wwv_flow_imp.g_varchar2_table(6) := '.4, ''#FE523A'', null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_regions'||wwv_flow.LF||
'    (id, region_name, region_zoo';
wwv_flow_imp.g_varchar2_table(7) := 'm, region_lat, region_lng, region_color, is_default_yn )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (2, ''Boston Area'', 10, 42.32';
wwv_flow_imp.g_varchar2_table(8) := '4789, -71.083448, ''#598BC9'', ''Y'');'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_regions'||wwv_flow.LF||
'    (id, region_nam';
wwv_flow_imp.g_varchar2_table(9) := 'e, region_zoom, region_lat, region_lng, region_color, is_default_yn )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (3, ''Chicago Ar';
wwv_flow_imp.g_varchar2_table(10) := 'ea'', 11, 41.95, -87.8, ''#169928'', null);'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''insert oow_dem';
wwv_flow_imp.g_varchar2_table(11) := 'o_regions end'', p_error_message => null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''';
wwv_flow_imp.g_varchar2_table(12) := 'insert oow_demo_regions begin'', p_error_message => null);'||wwv_flow.LF||
'    insert into oow_demo_regions'||wwv_flow.LF||
'    (id, ';
wwv_flow_imp.g_varchar2_table(13) := 'region_name, region_zoom, region_lat, region_lng, region_color, is_default_yn )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (4, ''';
wwv_flow_imp.g_varchar2_table(14) := 'San Diego'', 11, 32.8, -117.4, ''#FE523A'', null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end load_regions;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- P R O D U C T ';
wwv_flow_imp.g_varchar2_table(15) := 'S'||wwv_flow.LF||
'--'||wwv_flow.LF||
'procedure load_items'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''insert  oow_demo_ite';
wwv_flow_imp.g_varchar2_table(16) := 'ms begin'', p_error_message => null);'||wwv_flow.LF||
'    insert into oow_demo_items '||wwv_flow.LF||
'    (id, item_type, item_name, ';
wwv_flow_imp.g_varchar2_table(17) := 'msrp, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, ''Food'', ''Coconut Water'', 7.5, ''Refreshing Coconut Water from Nut';
wwv_flow_imp.g_varchar2_table(18) := 'tyH2O'');'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_items '||wwv_flow.LF||
'    (id, item_type, item_name, msrp, item_desc';
wwv_flow_imp.g_varchar2_table(19) := ')'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (2, ''Food'', ''Free range Beef'', 25, ''Home, home on that free range'');'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(20) := '   insert into oow_demo_items '||wwv_flow.LF||
'    (id, item_type, item_name, msrp, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (3, ''S';
wwv_flow_imp.g_varchar2_table(21) := 'oap'', ''Dr. Bronners Liquid Soap'', 4.99, ''One world - Now!'');'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_i';
wwv_flow_imp.g_varchar2_table(22) := 'tems '||wwv_flow.LF||
'    (id, item_type, item_name, msrp, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (4, ''Soap'', ''Aloe Vera Pure'', 3';
wwv_flow_imp.g_varchar2_table(23) := '.25, ''Gentlest on your skin'');'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_items '||wwv_flow.LF||
'    (id, item_type, item';
wwv_flow_imp.g_varchar2_table(24) := '_name, msrp, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (5, ''Food'', ''Macademia nuts'', 9.99, ''Fresh from the Hawaiian ';
wwv_flow_imp.g_varchar2_table(25) := 'Islands'');'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_items '||wwv_flow.LF||
'    (id, item_type, item_name, msrp, item_de';
wwv_flow_imp.g_varchar2_table(26) := 'sc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (6, ''Food'', ''Rea-Dee Protein Bars'', 11.99, ''Make you strong like ox.'');'||wwv_flow.LF||
'    commi';
wwv_flow_imp.g_varchar2_table(27) := 't;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_items '||wwv_flow.LF||
'    (id, item_type, item_name, msrp, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (';
wwv_flow_imp.g_varchar2_table(28) := '7, ''Miscellaneous'', ''Tennis Balls'', 6, ''Can of 3'');'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''ins';
wwv_flow_imp.g_varchar2_table(29) := 'ert  oow_demo_items end'', p_error_message => null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_items ';
wwv_flow_imp.g_varchar2_table(30) := ''||wwv_flow.LF||
'    (id, item_type, item_name, msrp, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (8, ''Miscellaneous'', ''Toothpaste'', 6';
wwv_flow_imp.g_varchar2_table(31) := ', ''With whitening boost'');'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''insert  oow_demo_items end'',';
wwv_flow_imp.g_varchar2_table(32) := ' p_error_message => null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_items '||wwv_flow.LF||
'    (id, item_type, item';
wwv_flow_imp.g_varchar2_table(33) := '_name, msrp, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (9, ''Fruit'', ''Apples'', 3.75, ''Farmfresh, bag of 12'');'||wwv_flow.LF||
'    oow';
wwv_flow_imp.g_varchar2_table(34) := '_demo_event_pkg.log (p_event_name => ''insert  oow_demo_items end'', p_error_message => null);'||wwv_flow.LF||
'    com';
wwv_flow_imp.g_varchar2_table(35) := 'mit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_items '||wwv_flow.LF||
'    (id, item_type, item_name, msrp, item_desc)'||wwv_flow.LF||
'    values';
wwv_flow_imp.g_varchar2_table(36) := ''||wwv_flow.LF||
'    (10, ''Fruit'', ''Oranges'', 4.55, ''Choice bag of 8'');'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ';
wwv_flow_imp.g_varchar2_table(37) := '''insert  oow_demo_items end'', p_error_message => null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_it';
wwv_flow_imp.g_varchar2_table(38) := 'ems '||wwv_flow.LF||
'    (id, item_type, item_name, msrp, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (11, ''Fruit'', ''Blueberries'', 4.1';
wwv_flow_imp.g_varchar2_table(39) := '5, ''Medium box of 80'');'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''insert  oow_demo_items end'', p_';
wwv_flow_imp.g_varchar2_table(40) := 'error_message => null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_items '||wwv_flow.LF||
'    (id, item_type, item_na';
wwv_flow_imp.g_varchar2_table(41) := 'me, msrp, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (12, ''Fruit'', ''Bananas'', 3.65, ''1 lbs'');'||wwv_flow.LF||
'    oow_demo_event_pkg.';
wwv_flow_imp.g_varchar2_table(42) := 'log (p_event_name => ''insert  oow_demo_items end'', p_error_message => null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert';
wwv_flow_imp.g_varchar2_table(43) := ' into oow_demo_items '||wwv_flow.LF||
'    (id, item_type, item_name, msrp, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (13, ''Fruit'', ''';
wwv_flow_imp.g_varchar2_table(44) := 'Lemons'', 2.87, ''Zesty 1 lbs bag'');'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''insert  oow_demo_ite';
wwv_flow_imp.g_varchar2_table(45) := 'ms end'', p_error_message => null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_items '||wwv_flow.LF||
'    (id, item_ty';
wwv_flow_imp.g_varchar2_table(46) := 'pe, item_name, msrp, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (14, ''Fruit'', ''Grapes'', 3.88, ''1/2 lbs'');'||wwv_flow.LF||
'    oow_dem';
wwv_flow_imp.g_varchar2_table(47) := 'o_event_pkg.log (p_event_name => ''insert  oow_demo_items end'', p_error_message => null);'||wwv_flow.LF||
'    commit;';
wwv_flow_imp.g_varchar2_table(48) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_items '||wwv_flow.LF||
'    (id, item_type, item_name, msrp, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (15';
wwv_flow_imp.g_varchar2_table(49) := ', ''Snacks'', ''Super Tasty Chocolate Bar'', 1.99, ''2 Oz'');'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ';
wwv_flow_imp.g_varchar2_table(50) := '''insert  oow_demo_items end'', p_error_message => null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_it';
wwv_flow_imp.g_varchar2_table(51) := 'ems '||wwv_flow.LF||
'    (id, item_type, item_name, msrp, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (16, ''Snacks'', ''Peanut Butter Ba';
wwv_flow_imp.g_varchar2_table(52) := 'r'', 1.59, ''1.5 Oz'');'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''insert  oow_demo_items end'', p_err';
wwv_flow_imp.g_varchar2_table(53) := 'or_message => null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_items '||wwv_flow.LF||
'    (id, item_type, item_name, msr';
wwv_flow_imp.g_varchar2_table(54) := 'p, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (17, ''Snacks'', ''Chocolate Covered Peanuts'', 16.99, ''2 lbs'');'||wwv_flow.LF||
'    oow_de';
wwv_flow_imp.g_varchar2_table(55) := 'mo_event_pkg.log (p_event_name => ''insert  oow_demo_items end'', p_error_message => null);'||wwv_flow.LF||
'    commit';
wwv_flow_imp.g_varchar2_table(56) := ';'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_items '||wwv_flow.LF||
'    (id, item_type, item_name, msrp, item_desc)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(57) := '  (18, ''Snacks'', ''Orange Twist Bar'', 1.79, ''2 Oz'');'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''ins';
wwv_flow_imp.g_varchar2_table(58) := 'ert  oow_demo_items end'', p_error_message => null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end load_items;'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- S T O R E S'||wwv_flow.LF||
'-';
wwv_flow_imp.g_varchar2_table(59) := '-'||wwv_flow.LF||
'procedure load_stores'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''insert oow_demo_stores';
wwv_flow_imp.g_varchar2_table(60) := ' begin'', p_error_message => null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_stores'||wwv_flow.LF||
'    (id, store_name, store_type,';
wwv_flow_imp.g_varchar2_table(61) := ' store_address, store_city, store_state, store_zip, region_id, store_lat, store_lng, store_open_date';
wwv_flow_imp.g_varchar2_table(62) := ')'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, ''All U Can Eat'', ''Branch'', ''1000 California St'', ''San Francisco'', ''CA'', ''94108''';
wwv_flow_imp.g_varchar2_table(63) := ', 1, 37.79226, -122.411397, to_date(''23-08-2010'', ''DD-MM-YYYY''));'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_d';
wwv_flow_imp.g_varchar2_table(64) := 'emo_stores'||wwv_flow.LF||
'    (id, store_name, store_type, store_address, store_city, store_state, store_zip, regio';
wwv_flow_imp.g_varchar2_table(65) := 'n_id, store_lat, store_lng, store_open_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (2, ''Holistic Foods of San Francicso'', ''';
wwv_flow_imp.g_varchar2_table(66) := 'Branch'', ''1221 Fell St'', ''San Francisco'', ''CA'', ''94117'', 1, 37.773862, -122.438354, to_date(''04-02-2';
wwv_flow_imp.g_varchar2_table(67) := '011'', ''DD-MM-YYYY''));'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_stores'||wwv_flow.LF||
'    (id, store_name, store_type, ';
wwv_flow_imp.g_varchar2_table(68) := 'store_address, store_city, store_state, store_zip, region_id, store_lat, store_lng, store_open_date)';
wwv_flow_imp.g_varchar2_table(69) := ''||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (3, ''Moscone Store'', ''Branch'', ''800 Howard St'', ''San Francisco'', ''CA'', ''94103'',  1, ';
wwv_flow_imp.g_varchar2_table(70) := '37.783197, -122.403445, to_date(''11-06-2011'', ''DD-MM-YYYY''));'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_';
wwv_flow_imp.g_varchar2_table(71) := 'stores'||wwv_flow.LF||
'    (id, store_name, store_type, store_address, store_city, store_state, store_zip, region_id';
wwv_flow_imp.g_varchar2_table(72) := ', store_lat, store_lng, store_open_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (4, ''Holistic Foods - Sacramento St.'', ''Flag';
wwv_flow_imp.g_varchar2_table(73) := 'ship'', ''1 Sacramento Street'', ''San Francisco'', ''CA'', ''94108'',  1, 37.793025, -122.409409, to_date(''0';
wwv_flow_imp.g_varchar2_table(74) := '4-01-2007'', ''DD-MM-YYYY''));'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_stores'||wwv_flow.LF||
'    (id, store_name, store_';
wwv_flow_imp.g_varchar2_table(75) := 'type, store_address, store_city, store_state, store_zip, region_id, store_lat, store_lng, store_open';
wwv_flow_imp.g_varchar2_table(76) := '_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (5, ''Mission Eats of San Francicso'', ''Branch'', ''154 Lombard St'', ''San Francisc';
wwv_flow_imp.g_varchar2_table(77) := 'o'', ''CA'', ''94111'',  1, 37.80445, -122.404178, to_date(''04-01-2010'', ''DD-MM-YYYY''));'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(78) := ' insert into oow_demo_stores'||wwv_flow.LF||
'    (id, store_name, store_type, store_address, store_city, store_state';
wwv_flow_imp.g_varchar2_table(79) := ', store_zip, region_id, store_lat, store_lng, store_open_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (6, ''Holistic Foods - ';
wwv_flow_imp.g_varchar2_table(80) := 'Hayes'', ''Flagship'', ''301 Hayes St'', ''San Francisco'', ''CA'', ''94102'',  1, 37.776981, -122.421451, to_d';
wwv_flow_imp.g_varchar2_table(81) := 'ate(''04-05-2009'', ''DD-MM-YYYY''));'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_stores'||wwv_flow.LF||
'    (id, store_name, ';
wwv_flow_imp.g_varchar2_table(82) := 'store_type, store_address, store_city, store_state, store_zip, region_id, store_lat, store_lng, stor';
wwv_flow_imp.g_varchar2_table(83) := 'e_open_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (7, ''Stop and Buy'', ''Flagship'', ''12 Main St'', ''Cambridge'', ''MA'', ''02142''';
wwv_flow_imp.g_varchar2_table(84) := ',  2, 42.361811, -71.080314, to_date(''04-01-2010'', ''DD-MM-YYYY''));'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_';
wwv_flow_imp.g_varchar2_table(85) := 'demo_stores'||wwv_flow.LF||
'    (id, store_name, store_type, store_address, store_city, store_state, store_zip, regi';
wwv_flow_imp.g_varchar2_table(86) := 'on_id, store_lat, store_lng, store_open_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (8, ''Big Yellow Dog'', ''Branch'', ''987 We';
wwv_flow_imp.g_varchar2_table(87) := 'st St'', ''Boston'', ''MA'', ''02136'',  2, 42.271113, -71.131913, sysdate-2);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(88) := ' oow_demo_stores'||wwv_flow.LF||
'    (id, store_name, store_type, store_address, store_city, store_state, store_zip,';
wwv_flow_imp.g_varchar2_table(89) := ' region_id, store_lat, store_lng, store_open_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (9, ''Holistic Foods - Lexington'', ';
wwv_flow_imp.g_varchar2_table(90) := '''Branch'', ''187 Massachusetts Ave'', ''Lexington'', ''MA'', ''02421'', 2, 42.426179, -71.196743, to_date(''04';
wwv_flow_imp.g_varchar2_table(91) := '-04-2011'', ''DD-MM-YYYY''));'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_stores'||wwv_flow.LF||
'    (id, store_name, store_t';
wwv_flow_imp.g_varchar2_table(92) := 'ype, store_address, store_city, store_state, store_zip, region_id, store_lat, store_lng, store_open_';
wwv_flow_imp.g_varchar2_table(93) := 'date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (10, ''Big Grab'', ''Branch'', ''5500 Pearl St'', ''Rosemont'', ''IL'', ''60018'', 3, 41.97';
wwv_flow_imp.g_varchar2_table(94) := '8683, -87.872729, to_date(''04-07-2011'', ''DD-MM-YYYY''));'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_stores';
wwv_flow_imp.g_varchar2_table(95) := ''||wwv_flow.LF||
'    (id, store_name, store_type, store_address, store_city, store_state, store_zip, region_id, stor';
wwv_flow_imp.g_varchar2_table(96) := 'e_lat, store_lng, store_open_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (11, ''Central Supply'', ''Branch'', ''5100 W Harrison ';
wwv_flow_imp.g_varchar2_table(97) := 'St'', ''Chicago'', ''IL'', ''60644'',3, 41.872867, -87.752103, to_date(''27-03-2002'', ''DD-MM-YYYY''));'||wwv_flow.LF||
'    co';
wwv_flow_imp.g_varchar2_table(98) := 'mmit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_stores'||wwv_flow.LF||
'    (id, store_name, store_type, store_address, store_city, s';
wwv_flow_imp.g_varchar2_table(99) := 'tore_state, store_zip, region_id, store_lat, store_lng, store_open_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (12, ''The Wa';
wwv_flow_imp.g_varchar2_table(100) := 'rehouse'', ''Flagship'', ''4015 N Western Ave'', ''Chicago'', ''IL'', ''60618'', 3, 41.954396, -87.688393, sysd';
wwv_flow_imp.g_varchar2_table(101) := 'ate-70);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_stores'||wwv_flow.LF||
'    (id, store_name, store_type, store_address';
wwv_flow_imp.g_varchar2_table(102) := ', store_city, store_state, store_zip, region_id, store_lat, store_lng, store_open_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(103) := '   (13, ''Big Al'', ''Branch'', ''640 S Clark St'', ''Chicago'', ''IL'', ''60605'', 3, 41.873792, -87.630648, sy';
wwv_flow_imp.g_varchar2_table(104) := 'sdate-28);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_stores'||wwv_flow.LF||
'    (id, store_name, store_type, store_a';
wwv_flow_imp.g_varchar2_table(105) := 'ddress, store_city, store_state, store_zip, region_id, store_lat, store_lng, store_open_date)'||wwv_flow.LF||
'    va';
wwv_flow_imp.g_varchar2_table(106) := 'lues'||wwv_flow.LF||
'    (14, ''Oracle Arena'', ''Branch'', ''7000 Coliseum Way'', ''Oakland'', ''CA'', ''94621'', 1, 37.750277,';
wwv_flow_imp.g_varchar2_table(107) := ' -122.202862, sysdate-365);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_stores'||wwv_flow.LF||
'    (id, store_name, store_';
wwv_flow_imp.g_varchar2_table(108) := 'type, store_address, store_city, store_state, store_zip, region_id, store_lat, store_lng, store_open';
wwv_flow_imp.g_varchar2_table(109) := '_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (15, ''Oracle Eats'', ''Flagship'', ''9890 Towne Centre Dr'', ''San Diego'', ''CA'', ''92';
wwv_flow_imp.g_varchar2_table(110) := '121'', 4, 32.715736, -117.161087, sysdate-400);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name';
wwv_flow_imp.g_varchar2_table(111) := ' => ''insert oow_demo_stores end'', p_error_message => null);'||wwv_flow.LF||
'end load_stores;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure load_store_p';
wwv_flow_imp.g_varchar2_table(112) := 'roducts'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''insert oow_demo_store_products begin'',';
wwv_flow_imp.g_varchar2_table(113) := ' p_error_message => null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- Store 1 --'||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store';
wwv_flow_imp.g_varchar2_table(114) := '_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, 1, 1, 8, ';
wwv_flow_imp.g_varchar2_table(115) := 'null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, ';
wwv_flow_imp.g_varchar2_table(116) := 'item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (2, 1, 2, 30, null, null, n';
wwv_flow_imp.g_varchar2_table(117) := 'ull);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, d';
wwv_flow_imp.g_varchar2_table(118) := 'iscount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (6, 1, 3, null, null, null, null);'||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(119) := 'ommit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct';
wwv_flow_imp.g_varchar2_table(120) := ', sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (3, 1, 4, 3.75, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(121) := ' insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_star';
wwv_flow_imp.g_varchar2_table(122) := 't_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (4, 1, 5, 12.50, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert in';
wwv_flow_imp.g_varchar2_table(123) := 'to oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sa';
wwv_flow_imp.g_varchar2_table(124) := 'le_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (5, 1, 6, 14.95, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_dem';
wwv_flow_imp.g_varchar2_table(125) := 'o_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_dat';
wwv_flow_imp.g_varchar2_table(126) := 'e)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (105, 1, 7, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_sto';
wwv_flow_imp.g_varchar2_table(127) := 're_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(128) := '  values'||wwv_flow.LF||
'    (54, 1, 8, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_product';
wwv_flow_imp.g_varchar2_table(129) := 's'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(130) := '   (110, 1, 9, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id';
wwv_flow_imp.g_varchar2_table(131) := ', store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (130, ';
wwv_flow_imp.g_varchar2_table(132) := '1, 10, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_';
wwv_flow_imp.g_varchar2_table(133) := 'id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (120, 1, 11, n';
wwv_flow_imp.g_varchar2_table(134) := 'ull, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item';
wwv_flow_imp.g_varchar2_table(135) := '_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (200, 1, 12, null, nul';
wwv_flow_imp.g_varchar2_table(136) := 'l, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id,';
wwv_flow_imp.g_varchar2_table(137) := ' item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (74, 1, 15, null, null, nu';
wwv_flow_imp.g_varchar2_table(138) := 'll, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_pri';
wwv_flow_imp.g_varchar2_table(139) := 'ce, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (75, 1, 16, null, null, null, null)';
wwv_flow_imp.g_varchar2_table(140) := ';'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, disco';
wwv_flow_imp.g_varchar2_table(141) := 'unt_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (80, 1, 17, null, null, null, null);'||wwv_flow.LF||
'    com';
wwv_flow_imp.g_varchar2_table(142) := 'mit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, ';
wwv_flow_imp.g_varchar2_table(143) := 'sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (81, 1, 18, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(144) := ''||wwv_flow.LF||
'    -- Store 2 --'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, ';
wwv_flow_imp.g_varchar2_table(145) := 'discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (8, 2, 1, null, 15, to_date(''04-02-2011';
wwv_flow_imp.g_varchar2_table(146) := ''', ''DD-MM-YYYY''), to_date(''04-02-2011'', ''DD-MM-YYYY'')+7);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_stor';
wwv_flow_imp.g_varchar2_table(147) := 'e_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(148) := ' values'||wwv_flow.LF||
'    (7, 2, 4, 4.25, 20, to_date(''04-02-2011'', ''DD-MM-YYYY''), to_date(''04-02-2011'', ''DD-MM-YY';
wwv_flow_imp.g_varchar2_table(149) := 'YY'')+4);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price';
wwv_flow_imp.g_varchar2_table(150) := ', discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (106, 2, 7, null, null, null, null);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(151) := '    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discoun';
wwv_flow_imp.g_varchar2_table(152) := 't_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (111, 2, 9, null, null, null, null);'||wwv_flow.LF||
'    commi';
wwv_flow_imp.g_varchar2_table(153) := 't;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sa';
wwv_flow_imp.g_varchar2_table(154) := 'le_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (140, 2, 10, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(155) := 'insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start';
wwv_flow_imp.g_varchar2_table(156) := '_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (122, 2, 11, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert i';
wwv_flow_imp.g_varchar2_table(157) := 'nto oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, s';
wwv_flow_imp.g_varchar2_table(158) := 'ale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (123, 2, 12, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_';
wwv_flow_imp.g_varchar2_table(159) := 'demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_';
wwv_flow_imp.g_varchar2_table(160) := 'date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (70, 2, 13, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_stor';
wwv_flow_imp.g_varchar2_table(161) := 'e_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(162) := ' values'||wwv_flow.LF||
'    (71, 2, 14, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'     '||wwv_flow.LF||
'    insert into oow_demo_store_pr';
wwv_flow_imp.g_varchar2_table(163) := 'oducts'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    val';
wwv_flow_imp.g_varchar2_table(164) := 'ues'||wwv_flow.LF||
'    (78, 2, 15, null, null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store';
wwv_flow_imp.g_varchar2_table(165) := '_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (79, 2, 16, n';
wwv_flow_imp.g_varchar2_table(166) := 'ull, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item';
wwv_flow_imp.g_varchar2_table(167) := '_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (82, 2, 17, null, null';
wwv_flow_imp.g_varchar2_table(168) := ', null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, disc';
wwv_flow_imp.g_varchar2_table(169) := 'ount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (83, 2, 18, null, null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(170) := 'ommit;'||wwv_flow.LF||
'   '||wwv_flow.LF||
'    -- Store 3 --'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, it';
wwv_flow_imp.g_varchar2_table(171) := 'em_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (12, 3, 2, 20, null, to_date(';
wwv_flow_imp.g_varchar2_table(172) := '''11-06-2011'', ''DD-MM-YYYY''), to_date(''11-06-2011'', ''DD-MM-YYYY'')+5);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oo';
wwv_flow_imp.g_varchar2_table(173) := 'w_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_en';
wwv_flow_imp.g_varchar2_table(174) := 'd_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (9, 3, 3, null, 15, to_date(''11-06-2011'', ''DD-MM-YYYY''), to_date(''11-06-2011''';
wwv_flow_imp.g_varchar2_table(175) := ', ''DD-MM-YYYY'')+5);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id,';
wwv_flow_imp.g_varchar2_table(176) := ' item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (10, 3, 5, null, 15, to_da';
wwv_flow_imp.g_varchar2_table(177) := 'te(''11-06-2011'', ''DD-MM-YYYY''), to_date(''11-06-2011'', ''DD-MM-YYYY'')+5);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(178) := ' oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale';
wwv_flow_imp.g_varchar2_table(179) := '_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (11, 3, 6, null, 15, to_date(''11-06-2011'', ''DD-MM-YYYY''), to_date(''11-06-2';
wwv_flow_imp.g_varchar2_table(180) := '011'', ''DD-MM-YYYY'')+5);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item';
wwv_flow_imp.g_varchar2_table(181) := '_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (107, 3, 7, null, null';
wwv_flow_imp.g_varchar2_table(182) := ', null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item';
wwv_flow_imp.g_varchar2_table(183) := '_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (112, 3, 9, null, null, null, n';
wwv_flow_imp.g_varchar2_table(184) := 'ull);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, d';
wwv_flow_imp.g_varchar2_table(185) := 'iscount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (133, 3, 10, null, null, null, null);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(186) := '  commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, disco';
wwv_flow_imp.g_varchar2_table(187) := 'unt_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (76, 3, 15, null, null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    in';
wwv_flow_imp.g_varchar2_table(188) := 'sert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_d';
wwv_flow_imp.g_varchar2_table(189) := 'ate, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (77, 3, 16, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(190) := ' oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale';
wwv_flow_imp.g_varchar2_table(191) := '_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (182, 3, 17, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_dem';
wwv_flow_imp.g_varchar2_table(192) := 'o_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_dat';
wwv_flow_imp.g_varchar2_table(193) := 'e)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (183, 3, 18, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'   '||wwv_flow.LF||
'    -- Store 4 --'||wwv_flow.LF||
'    insert';
wwv_flow_imp.g_varchar2_table(194) := ' into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date,';
wwv_flow_imp.g_varchar2_table(195) := ' sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (13, 4, 1, 8.95, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_';
wwv_flow_imp.g_varchar2_table(196) := 'demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_';
wwv_flow_imp.g_varchar2_table(197) := 'date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (14, 4, 5, 8.50, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store';
wwv_flow_imp.g_varchar2_table(198) := '_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(199) := 'values'||wwv_flow.LF||
'    (15, 4, 6, 9.99, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(200) := '    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(201) := ' (72, 4, 13, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, ';
wwv_flow_imp.g_varchar2_table(202) := 'store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (73, 4, ';
wwv_flow_imp.g_varchar2_table(203) := '14, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id,';
wwv_flow_imp.g_varchar2_table(204) := ' item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (84, 4, 17, null,';
wwv_flow_imp.g_varchar2_table(205) := ' null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id,';
wwv_flow_imp.g_varchar2_table(206) := ' item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (85, 4, 18, null, null, nu';
wwv_flow_imp.g_varchar2_table(207) := 'll, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    -- Store 5 --'||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store';
wwv_flow_imp.g_varchar2_table(208) := '_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (16, 5, 4, nu';
wwv_flow_imp.g_varchar2_table(209) := 'll, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_';
wwv_flow_imp.g_varchar2_table(210) := 'id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (17, 5, 5, null, 10, to';
wwv_flow_imp.g_varchar2_table(211) := '_date(''04-01-2010'', ''DD-MM-YYYY''), to_date(''04-01-2010'', ''DD-MM-YYYY'')+4);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert i';
wwv_flow_imp.g_varchar2_table(212) := 'nto oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, s';
wwv_flow_imp.g_varchar2_table(213) := 'ale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (18, 6, 1, 7.35, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_de';
wwv_flow_imp.g_varchar2_table(214) := 'mo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_da';
wwv_flow_imp.g_varchar2_table(215) := 'te)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (86, 6, 17, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_';
wwv_flow_imp.g_varchar2_table(216) := 'products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    v';
wwv_flow_imp.g_varchar2_table(217) := 'alues'||wwv_flow.LF||
'    (87, 6, 18, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    -- Store 7 --'||wwv_flow.LF||
'    insert into oo';
wwv_flow_imp.g_varchar2_table(218) := 'w_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_en';
wwv_flow_imp.g_varchar2_table(219) := 'd_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (19, 7, 1, 7.75, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_sto';
wwv_flow_imp.g_varchar2_table(220) := 're_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(221) := '  values'||wwv_flow.LF||
'    (20, 7, 2, 27, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(222) := '    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(223) := ' (21, 7, 7, 5.50, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, s';
wwv_flow_imp.g_varchar2_table(224) := 'tore_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (88, 7, 1';
wwv_flow_imp.g_varchar2_table(225) := '7, null, null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, ite';
wwv_flow_imp.g_varchar2_table(226) := 'm_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (89, 7, 18, null, null, null, ';
wwv_flow_imp.g_varchar2_table(227) := 'null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    -- Store 8 --'||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id,';
wwv_flow_imp.g_varchar2_table(228) := ' item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (22, 8, 1, 8.5, n';
wwv_flow_imp.g_varchar2_table(229) := 'ull, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, i';
wwv_flow_imp.g_varchar2_table(230) := 'tem_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (23, 8, 2, 26, null, null, n';
wwv_flow_imp.g_varchar2_table(231) := 'ull);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, d';
wwv_flow_imp.g_varchar2_table(232) := 'iscount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (24, 8, 3, 5.99, null, null, null);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(233) := 'commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pc';
wwv_flow_imp.g_varchar2_table(234) := 't, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (25, 8, 4, 3.50, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(235) := '   insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_st';
wwv_flow_imp.g_varchar2_table(236) := 'art_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (26, 8, 5,10.99, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert ';
wwv_flow_imp.g_varchar2_table(237) := 'into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, ';
wwv_flow_imp.g_varchar2_table(238) := 'sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (27, 8, 6, 12.99, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_';
wwv_flow_imp.g_varchar2_table(239) := 'demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_';
wwv_flow_imp.g_varchar2_table(240) := 'date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (28, 8, 7, 7, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_pr';
wwv_flow_imp.g_varchar2_table(241) := 'oducts'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    val';
wwv_flow_imp.g_varchar2_table(242) := 'ues'||wwv_flow.LF||
'    (90, 8, 17, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(243) := '  (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (';
wwv_flow_imp.g_varchar2_table(244) := '91, 8, 18, null, null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'  '||wwv_flow.LF||
'    '||wwv_flow.LF||
'    -- Store 9 --'||wwv_flow.LF||
'    insert into oow_demo_';
wwv_flow_imp.g_varchar2_table(245) := 'store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)';
wwv_flow_imp.g_varchar2_table(246) := ''||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (29, 9, 2, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_prod';
wwv_flow_imp.g_varchar2_table(247) := 'ucts'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    value';
wwv_flow_imp.g_varchar2_table(248) := 's'||wwv_flow.LF||
'    (30, 9, 3, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (';
wwv_flow_imp.g_varchar2_table(249) := 'id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (31,';
wwv_flow_imp.g_varchar2_table(250) := ' 9, 4, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_';
wwv_flow_imp.g_varchar2_table(251) := 'id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (32, 9, 5, nul';
wwv_flow_imp.g_varchar2_table(252) := 'l, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, it';
wwv_flow_imp.g_varchar2_table(253) := 'em_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (53, 9, 8, null, nul';
wwv_flow_imp.g_varchar2_table(254) := 'l, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, dis';
wwv_flow_imp.g_varchar2_table(255) := 'count_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (92, 9, 17, null, null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(256) := 'insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start';
wwv_flow_imp.g_varchar2_table(257) := '_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (93, 9, 18, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    -- St';
wwv_flow_imp.g_varchar2_table(258) := 'ore 10 --'||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_p';
wwv_flow_imp.g_varchar2_table(259) := 'ct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (33, 10, 1, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(260) := ''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_';
wwv_flow_imp.g_varchar2_table(261) := 'start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (34, 10 , 4, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ins';
wwv_flow_imp.g_varchar2_table(262) := 'ert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_da';
wwv_flow_imp.g_varchar2_table(263) := 'te, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (35, 10, 5, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into ';
wwv_flow_imp.g_varchar2_table(264) := 'oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_';
wwv_flow_imp.g_varchar2_table(265) := 'end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (36, 10, 7, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo';
wwv_flow_imp.g_varchar2_table(266) := '_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date';
wwv_flow_imp.g_varchar2_table(267) := ')'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (94, 8, 17, null, null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (';
wwv_flow_imp.g_varchar2_table(268) := 'id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (95,';
wwv_flow_imp.g_varchar2_table(269) := ' 8, 18, null, null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    '||wwv_flow.LF||
'    -- Store 11 --'||wwv_flow.LF||
'    insert into oow_demo_stor';
wwv_flow_imp.g_varchar2_table(270) := 'e_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(271) := ' values'||wwv_flow.LF||
'    (37, 11, 1, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_product';
wwv_flow_imp.g_varchar2_table(272) := 's'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(273) := '   (38, 11, 4, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id';
wwv_flow_imp.g_varchar2_table(274) := ', store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (39, 1';
wwv_flow_imp.g_varchar2_table(275) := '1, 5, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_i';
wwv_flow_imp.g_varchar2_table(276) := 'd, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (40, 11, 7, nul';
wwv_flow_imp.g_varchar2_table(277) := 'l, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, it';
wwv_flow_imp.g_varchar2_table(278) := 'em_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (55, 11, 8, null, nu';
wwv_flow_imp.g_varchar2_table(279) := 'll, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    -- Store 12 --'||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id';
wwv_flow_imp.g_varchar2_table(280) := ', store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (41, 1';
wwv_flow_imp.g_varchar2_table(281) := '2, 2, 23.95, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_';
wwv_flow_imp.g_varchar2_table(282) := 'id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (42, 12, 4, 2.';
wwv_flow_imp.g_varchar2_table(283) := '95, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_';
wwv_flow_imp.g_varchar2_table(284) := 'id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (43, 12, 6, 9.95, null,';
wwv_flow_imp.g_varchar2_table(285) := ' null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_';
wwv_flow_imp.g_varchar2_table(286) := 'price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (44, 12, 7, 4.95, null, null, nu';
wwv_flow_imp.g_varchar2_table(287) := 'll);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price';
wwv_flow_imp.g_varchar2_table(288) := ', discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (59, 12, 9, null, null, null, null);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(289) := ''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_';
wwv_flow_imp.g_varchar2_table(290) := 'start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (96, 12, 17, null, null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow';
wwv_flow_imp.g_varchar2_table(291) := '_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end';
wwv_flow_imp.g_varchar2_table(292) := '_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (97, 12, 18, null, null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'  '||wwv_flow.LF||
'    '||wwv_flow.LF||
'    -- Store 13 --';
wwv_flow_imp.g_varchar2_table(293) := ''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_';
wwv_flow_imp.g_varchar2_table(294) := 'start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (45, 13, 1, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    inse';
wwv_flow_imp.g_varchar2_table(295) := 'rt into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_dat';
wwv_flow_imp.g_varchar2_table(296) := 'e, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (46, 13, 2, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into o';
wwv_flow_imp.g_varchar2_table(297) := 'ow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_e';
wwv_flow_imp.g_varchar2_table(298) := 'nd_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (47, 13, 5, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_de';
wwv_flow_imp.g_varchar2_table(299) := 'mo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_da';
wwv_flow_imp.g_varchar2_table(300) := 'te)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (56, 13, 8, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_';
wwv_flow_imp.g_varchar2_table(301) := 'products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    v';
wwv_flow_imp.g_varchar2_table(302) := 'alues'||wwv_flow.LF||
'    (98, 13, 17, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products';
wwv_flow_imp.g_varchar2_table(303) := ''||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(304) := '  (99, 13, 18, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    -- Store 14 --'||wwv_flow.LF||
'    insert into oow_demo';
wwv_flow_imp.g_varchar2_table(305) := '_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date';
wwv_flow_imp.g_varchar2_table(306) := ')'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (48, 14, 1, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_pr';
wwv_flow_imp.g_varchar2_table(307) := 'oducts'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    val';
wwv_flow_imp.g_varchar2_table(308) := 'ues'||wwv_flow.LF||
'    (49, 14, 2, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(309) := '  (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (';
wwv_flow_imp.g_varchar2_table(310) := '50, 14, 5, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id';
wwv_flow_imp.g_varchar2_table(311) := ', store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (51, 1';
wwv_flow_imp.g_varchar2_table(312) := '4, 6, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, sto';
wwv_flow_imp.g_varchar2_table(313) := 're_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (52, 14, 7,';
wwv_flow_imp.g_varchar2_table(314) := ' null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id';
wwv_flow_imp.g_varchar2_table(315) := ', item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (57, 14, 8, null';
wwv_flow_imp.g_varchar2_table(316) := ', null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, ite';
wwv_flow_imp.g_varchar2_table(317) := 'm_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (58, 14, 9, null, nul';
wwv_flow_imp.g_varchar2_table(318) := 'l, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'     insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id';
wwv_flow_imp.g_varchar2_table(319) := ', item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (60, 14, 10, null, null, ';
wwv_flow_imp.g_varchar2_table(320) := 'null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, it';
wwv_flow_imp.g_varchar2_table(321) := 'em_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (61, 14, 11, null, null, null';
wwv_flow_imp.g_varchar2_table(322) := ', null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price';
wwv_flow_imp.g_varchar2_table(323) := ', discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (62, 14, 12, null, null, null, null);';
wwv_flow_imp.g_varchar2_table(324) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale';
wwv_flow_imp.g_varchar2_table(325) := '_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (100, 14, 17, null, null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into o';
wwv_flow_imp.g_varchar2_table(326) := 'ow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_e';
wwv_flow_imp.g_varchar2_table(327) := 'nd_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (101, 14, 18, null, null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'   -- Store 15 --'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(328) := 'nsert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_';
wwv_flow_imp.g_varchar2_table(329) := 'date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (63, 15, 1, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert int';
wwv_flow_imp.g_varchar2_table(330) := 'o oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sal';
wwv_flow_imp.g_varchar2_table(331) := 'e_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (64, 15, 2, null, null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_dem';
wwv_flow_imp.g_varchar2_table(332) := 'o_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_dat';
wwv_flow_imp.g_varchar2_table(333) := 'e)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (65, 15, 5, null, null, null, null);'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(334) := '    (id, store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(335) := ' (66, 15, 6, null, null, null, null);'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id';
wwv_flow_imp.g_varchar2_table(336) := ', item_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (67, 15, 7, null';
wwv_flow_imp.g_varchar2_table(337) := ', null, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, ite';
wwv_flow_imp.g_varchar2_table(338) := 'm_id, item_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (68, 15, 8, null, nul';
wwv_flow_imp.g_varchar2_table(339) := 'l, null, null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, ite';
wwv_flow_imp.g_varchar2_table(340) := 'm_price, discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (69, 15, 12, null, null, null,';
wwv_flow_imp.g_varchar2_table(341) := ' null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price,';
wwv_flow_imp.g_varchar2_table(342) := ' discount_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (102, 15, 17, null, null, null, null);';
wwv_flow_imp.g_varchar2_table(343) := ''||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into oow_demo_store_products'||wwv_flow.LF||
'    (id, store_id, item_id, item_price, discou';
wwv_flow_imp.g_varchar2_table(344) := 'nt_pct, sale_start_date, sale_end_date)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (103, 15, 18, null, null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(345) := 'ommit;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''insert oow_demo_store_products end'', p_erro';
wwv_flow_imp.g_varchar2_table(346) := 'r_message => null);'||wwv_flow.LF||
'end load_store_products;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure remove '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        delete from oow';
wwv_flow_imp.g_varchar2_table(347) := '_demo_sales_history where store_id < 100 or product_id < 100;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'        delete from oo';
wwv_flow_imp.g_varchar2_table(348) := 'w_demo_store_products where id < 200;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'        delete from oow_demo_stores where id <';
wwv_flow_imp.g_varchar2_table(349) := ' 200;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'        delete from oow_demo_items where id < 200;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'        del';
wwv_flow_imp.g_varchar2_table(350) := 'ete from oow_demo_regions where id < 200;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'exception'||wwv_flow.LF||
'        when others then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(351) := ' if sqlcode <> -2292 then'||wwv_flow.LF||
'            raise;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'end remove;'||wwv_flow.LF||
''||wwv_flow.LF||
'function is_loaded return ';
wwv_flow_imp.g_varchar2_table(352) := 'boolean is'||wwv_flow.LF||
'        l_cnt number := 0;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'        select count(*) into l_cnt from oow_demo_regions';
wwv_flow_imp.g_varchar2_table(353) := ' where id < 200;'||wwv_flow.LF||
'        if l_cnt > 0 then return true; end if;'||wwv_flow.LF||
'        select count(*) into l_cnt f';
wwv_flow_imp.g_varchar2_table(354) := 'rom oow_demo_items where id < 200;'||wwv_flow.LF||
'        if l_cnt > 0 then return true; end if;'||wwv_flow.LF||
'        select cou';
wwv_flow_imp.g_varchar2_table(355) := 'nt(*) into l_cnt from oow_demo_stores where id < 200;'||wwv_flow.LF||
'        if l_cnt > 0 then return true; end if;';
wwv_flow_imp.g_varchar2_table(356) := ''||wwv_flow.LF||
'        select count(*) into l_cnt from oow_demo_store_products where id < 200;'||wwv_flow.LF||
'        if l_cnt > ';
wwv_flow_imp.g_varchar2_table(357) := '0 then return true; end if;'||wwv_flow.LF||
'        return false;'||wwv_flow.LF||
'end is_loaded;'||wwv_flow.LF||
''||wwv_flow.LF||
'end oow_demo_sample_data;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show e';
wwv_flow_imp.g_varchar2_table(358) := 'rrors'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40267602270076563159)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'oow_demo_sample_data BODY'
,p_sequence=>160
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
