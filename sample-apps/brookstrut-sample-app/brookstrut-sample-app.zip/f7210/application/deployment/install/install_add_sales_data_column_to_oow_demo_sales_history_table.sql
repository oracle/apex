prompt --application/deployment/install/install_add_sales_data_column_to_oow_demo_sales_history_table
begin
--   Manifest
--     INSTALL: INSTALL-Add SALES_DATA column to OOW_DEMO_SALES_HISTORY table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'alter table oow_demo_sales_history add sales_data varchar2(4000);'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(15080109617613029428)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'Add SALES_DATA column to OOW_DEMO_SALES_HISTORY table'
,p_sequence=>240
,p_script_type=>'INSTALL'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>'select null from all_tab_columns where table_name = ''OOW_DEMO_SALES_HISTORY'' and column_name = ''SALES_DATA'';'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
