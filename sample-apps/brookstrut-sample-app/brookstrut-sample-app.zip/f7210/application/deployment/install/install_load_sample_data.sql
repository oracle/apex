prompt --application/deployment/install/install_load_sample_data
begin
--   Manifest
--     INSTALL: INSTALL-Load Sample Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''load sample data starting'', p_error_message => nu';
wwv_flow_imp.g_varchar2_table(2) := 'll);'||wwv_flow.LF||
'    oow_demo_sample_data.load;'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''load sample data co';
wwv_flow_imp.g_varchar2_table(3) := 'mpleted'', p_error_message => null);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'exception when others then'||wwv_flow.LF||
'    oow_demo_event_pkg.lo';
wwv_flow_imp.g_varchar2_table(4) := 'g (p_event_name => ''error loading sample data'', p_error_message => sqlerrm);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for j';
wwv_flow_imp.g_varchar2_table(5) := ' in 1..4 loop'||wwv_flow.LF||
'    for c1 in (select count(*) c from oow_demo_regions) loop'||wwv_flow.LF||
'        if c1.c = 0 then ';
wwv_flow_imp.g_varchar2_table(6) := ''||wwv_flow.LF||
'            begin'||wwv_flow.LF||
'               oow_demo_event_pkg.log (p_event_name => ''retry loading regions ''||';
wwv_flow_imp.g_varchar2_table(7) := 'j, p_error_message => null);'||wwv_flow.LF||
'               oow_demo_sample_data.load_regions;'||wwv_flow.LF||
'            exception';
wwv_flow_imp.g_varchar2_table(8) := ' when others then'||wwv_flow.LF||
'               oow_demo_event_pkg.log (p_event_name => ''error loading regions ''||j';
wwv_flow_imp.g_varchar2_table(9) := ', p_error_message => sqlerrm);'||wwv_flow.LF||
'            end;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(10) := 'begin'||wwv_flow.LF||
'    for j in 1..4 loop'||wwv_flow.LF||
'    for c1 in (select count(*) c from oow_demo_items) loop'||wwv_flow.LF||
'        if c';
wwv_flow_imp.g_varchar2_table(11) := '1.c = 0 then '||wwv_flow.LF||
'            begin'||wwv_flow.LF||
'               oow_demo_event_pkg.log (p_event_name => ''retry loadin';
wwv_flow_imp.g_varchar2_table(12) := 'g items ''||j, p_error_message => null);'||wwv_flow.LF||
'               oow_demo_sample_data.load_items;'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(13) := 'exception when others then'||wwv_flow.LF||
'               oow_demo_event_pkg.log (p_event_name => ''error loading ite';
wwv_flow_imp.g_varchar2_table(14) := 'ms ''||j, p_error_message => sqlerrm);'||wwv_flow.LF||
'            end;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'e';
wwv_flow_imp.g_varchar2_table(15) := 'nd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for j in 1..4 loop'||wwv_flow.LF||
'    for c1 in (select count(*) c from oow_demo_stores) loop'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(16) := '    if c1.c = 0 then '||wwv_flow.LF||
'            begin'||wwv_flow.LF||
'               oow_demo_event_pkg.log (p_event_name => ''retr';
wwv_flow_imp.g_varchar2_table(17) := 'y loading stores ''||j, p_error_message => null);'||wwv_flow.LF||
'               oow_demo_sample_data.load_stores;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(18) := '          exception when others then'||wwv_flow.LF||
'               oow_demo_event_pkg.log (p_event_name => ''error l';
wwv_flow_imp.g_varchar2_table(19) := 'oading stores ''||j, p_error_message => sqlerrm);'||wwv_flow.LF||
'            end;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(20) := 'end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for j in 1..4 loop'||wwv_flow.LF||
'    for c1 in (select count(*) c from oow_demo_store_';
wwv_flow_imp.g_varchar2_table(21) := 'products) loop'||wwv_flow.LF||
'        if c1.c = 0 then '||wwv_flow.LF||
'            begin'||wwv_flow.LF||
'               oow_demo_event_pkg.log (p_';
wwv_flow_imp.g_varchar2_table(22) := 'event_name => ''retry loading products ''||j, p_error_message => null);'||wwv_flow.LF||
'               oow_demo_sample';
wwv_flow_imp.g_varchar2_table(23) := '_data.load_store_products;'||wwv_flow.LF||
'            exception when others then'||wwv_flow.LF||
'               oow_demo_event_pkg.';
wwv_flow_imp.g_varchar2_table(24) := 'log (p_event_name => ''error loading products ''||j, p_error_message => sqlerrm);'||wwv_flow.LF||
'            end;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(25) := '     end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38801578977814101845)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'Load Sample Data'
,p_sequence=>190
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
