prompt --application/deployment/install/install_load_sample_data
begin
--   Manifest
--     INSTALL: INSTALL-Load Sample Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1867060655981638216
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38725325577290424150)
,p_install_id=>wwv_flow_imp.id(38724263165003246293)
,p_name=>'Load Sample Data'
,p_sequence=>190
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    oow_demo_event_pkg.log (p_event_name => ''load sample data starting'', p_error_message => null);',
'    oow_demo_sample_data.load;',
'    oow_demo_event_pkg.log (p_event_name => ''load sample data completed'', p_error_message => null);',
'    commit;',
'exception when others then',
'    oow_demo_event_pkg.log (p_event_name => ''error loading sample data'', p_error_message => sqlerrm);',
'end;',
'/',
'',
'begin',
'    for j in 1..4 loop',
'    for c1 in (select count(*) c from oow_demo_regions) loop',
'        if c1.c = 0 then ',
'            begin',
'               oow_demo_event_pkg.log (p_event_name => ''retry loading regions ''||j, p_error_message => null);',
'               oow_demo_sample_data.load_regions;',
'            exception when others then',
'               oow_demo_event_pkg.log (p_event_name => ''error loading regions ''||j, p_error_message => sqlerrm);',
'            end;',
'        end if;',
'    end loop;',
'    end loop;',
'end;',
'/',
'',
'begin',
'    for j in 1..4 loop',
'    for c1 in (select count(*) c from oow_demo_items) loop',
'        if c1.c = 0 then ',
'            begin',
'               oow_demo_event_pkg.log (p_event_name => ''retry loading items ''||j, p_error_message => null);',
'               oow_demo_sample_data.load_items;',
'            exception when others then',
'               oow_demo_event_pkg.log (p_event_name => ''error loading items ''||j, p_error_message => sqlerrm);',
'            end;',
'        end if;',
'    end loop;',
'    end loop;',
'end;',
'/',
'',
'begin',
'    for j in 1..4 loop',
'    for c1 in (select count(*) c from oow_demo_stores) loop',
'        if c1.c = 0 then ',
'            begin',
'               oow_demo_event_pkg.log (p_event_name => ''retry loading stores ''||j, p_error_message => null);',
'               oow_demo_sample_data.load_stores;',
'            exception when others then',
'               oow_demo_event_pkg.log (p_event_name => ''error loading stores ''||j, p_error_message => sqlerrm);',
'            end;',
'        end if;',
'    end loop;',
'    end loop;',
'end;',
'/',
'',
'begin',
'    for j in 1..4 loop',
'    for c1 in (select count(*) c from oow_demo_store_products) loop',
'        if c1.c = 0 then ',
'            begin',
'               oow_demo_event_pkg.log (p_event_name => ''retry loading products ''||j, p_error_message => null);',
'               oow_demo_sample_data.load_store_products;',
'            exception when others then',
'               oow_demo_event_pkg.log (p_event_name => ''error loading products ''||j, p_error_message => sqlerrm);',
'            end;',
'        end if;',
'    end loop;',
'    end loop;',
'end;',
'/',
'    ',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
