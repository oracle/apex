prompt --application/deployment/install/install_oow_demo_sample_data_spec
begin
--   Manifest
--     INSTALL: INSTALL-oow_demo_sample_data SPEC
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38717026500629262619)
,p_install_id=>wwv_flow_imp.id(38716960992472134654)
,p_name=>'oow_demo_sample_data SPEC'
,p_sequence=>150
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package oow_demo_sample_data as',
'    procedure load;',
'    procedure remove;',
'    function is_loaded return boolean;',
'    procedure load_regions;',
'    procedure load_items;',
'    procedure load_stores;',
'    procedure load_store_products;',
'end oow_demo_sample_data;',
'/',
'show errors',
'    ',
'',
'',
'',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(37024925452491460468)
,p_script_id=>wwv_flow_imp.id(38717026500629262619)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'OOW_DEMO_SAMPLE_DATA'
,p_last_updated_on=>to_date('20141219062103','YYYYMMDDHH24MISS')
,p_created_on=>to_date('20141219062103','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
