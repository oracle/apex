prompt --application/deployment/install/install_oow_demo_sample_data_spec
begin
--   Manifest
--     INSTALL: INSTALL-oow_demo_sample_data SPEC
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package oow_demo_sample_data as'||wwv_flow.LF||
'    procedure load;'||wwv_flow.LF||
'    procedure remove;'||wwv_flow.LF||
'    func';
wwv_flow_imp.g_varchar2_table(2) := 'tion is_loaded return boolean;'||wwv_flow.LF||
'    procedure load_regions;'||wwv_flow.LF||
'    procedure load_items;'||wwv_flow.LF||
'    procedure l';
wwv_flow_imp.g_varchar2_table(3) := 'oad_stores;'||wwv_flow.LF||
'    procedure load_store_products;'||wwv_flow.LF||
'end oow_demo_sample_data;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'    '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38800582073684051953)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'oow_demo_sample_data SPEC'
,p_sequence=>150
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(37108481025546249802)
,p_script_id=>wwv_flow_imp.id(38800582073684051953)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'OOW_DEMO_SAMPLE_DATA'
);
wwv_flow_imp.component_end;
end;
/
