prompt --application/deployment/install/install_oow_demo_sample_data_spec
begin
--   Manifest
--     INSTALL: INSTALL-oow_demo_sample_data SPEC
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38743060131277553130)
,p_install_id=>wwv_flow_imp.id(38742994623120425165)
,p_name=>'oow_demo_sample_data SPEC'
,p_sequence=>150
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package oow_demo_sample_data as',
'    procedure load;',
'    procedure remove;',
'    function is_loaded return boolean;',
'    procedure load_regions;',
'    procedure load_items;',
'    procedure load_stores;',
'    procedure load_store_products;',
'end oow_demo_sample_data;',
'/',
'show errors',
'    ',
'',
'',
'',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(37050959083139750979)
,p_script_id=>wwv_flow_imp.id(38743060131277553130)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'OOW_DEMO_SAMPLE_DATA'
);
wwv_flow_imp.component_end;
end;
/
