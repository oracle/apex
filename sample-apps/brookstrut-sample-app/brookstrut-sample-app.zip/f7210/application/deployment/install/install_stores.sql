prompt --application/deployment/install/install_stores
begin
--   Manifest
--     INSTALL: INSTALL-stores
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE  OOW_DEMO_STORES ('||wwv_flow.LF||
'    ID                   NUMBER, '||wwv_flow.LF||
'    ROW_VERSION_NUMBER   NUMBER, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2) := '    STORE_NAME           VARCHAR2(255), '||wwv_flow.LF||
'    STORE_TYPE           VARCHAR2(50), '||wwv_flow.LF||
'    STORE_ADDRESS  ';
wwv_flow_imp.g_varchar2_table(3) := '      VARCHAR2(255), '||wwv_flow.LF||
'    STORE_OPEN_DATE      timestamp with local time zone,'||wwv_flow.LF||
'    STORE_CITY       ';
wwv_flow_imp.g_varchar2_table(4) := '    VARCHAR2(50), '||wwv_flow.LF||
'    STORE_STATE          VARCHAR2(50), '||wwv_flow.LF||
'    region_id            number,'||wwv_flow.LF||
'    STOR';
wwv_flow_imp.g_varchar2_table(5) := 'E_ZIP            VARCHAR2(12), '||wwv_flow.LF||
'    STORE_LAT            NUMBER(9,6), '||wwv_flow.LF||
'    STORE_LNG            NUMB';
wwv_flow_imp.g_varchar2_table(6) := 'ER(9,6), '||wwv_flow.LF||
'    n1                   number,'||wwv_flow.LF||
'    n2                   number,'||wwv_flow.LF||
'    n3                  ';
wwv_flow_imp.g_varchar2_table(7) := ' number,'||wwv_flow.LF||
'    n4                   number,'||wwv_flow.LF||
'    CONSTRAINT OOW_DEMO_STORES_PK PRIMARY KEY (ID) ENABLE'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(8) := '   );'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER BIU_OOW_DEMO_STORES'||wwv_flow.LF||
'BEFORE INSERT OR UPDATE ON OOW_DEMO_STORES'||wwv_flow.LF||
'FOR ';
wwv_flow_imp.g_varchar2_table(9) := 'EACH ROW'||wwv_flow.LF||
'BEGIN'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(10) := 'XXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.row_version_number :=';
wwv_flow_imp.g_varchar2_table(11) := ' 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(12) := 'end if;'||wwv_flow.LF||
'   if :new.n1 is null then'||wwv_flow.LF||
'     :new.n1 := round(dbms_random.value(1,1000000));'||wwv_flow.LF||
'   end if;  ';
wwv_flow_imp.g_varchar2_table(13) := ' '||wwv_flow.LF||
'   if :new.n2 is null then'||wwv_flow.LF||
'     :new.n2 := round(dbms_random.value(1,1000000));'||wwv_flow.LF||
'   end if;   '||wwv_flow.LF||
'   i';
wwv_flow_imp.g_varchar2_table(14) := 'f :new.n3 is null then'||wwv_flow.LF||
'     :new.n3 := round(dbms_random.value(1,1000000));'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.n4';
wwv_flow_imp.g_varchar2_table(15) := ' is null then'||wwv_flow.LF||
'     :new.n4 := round(dbms_random.value(1,1000000));'||wwv_flow.LF||
'   end if;   '||wwv_flow.LF||
'END;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38800572650191081462)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'stores'
,p_sequence=>90
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
