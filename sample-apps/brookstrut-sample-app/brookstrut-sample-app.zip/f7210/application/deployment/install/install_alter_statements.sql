prompt --application/deployment/install/install_alter_statements
begin
--   Manifest
--     INSTALL: INSTALL-alter statements
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'ALTER TABLE  OOW_DEMO_STORE_PRODUCTS ADD CONSTRAINT OOW_DEMO_STORE_PRODUCTS_FK1 FOREIGN KEY (ITEM_ID';
wwv_flow_imp.g_varchar2_table(2) := ')'||wwv_flow.LF||
'      REFERENCES  OOW_DEMO_ITEMS (ID) ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TABLE  OOW_DEMO_STORE_PRODUCTS ADD CONSTRAINT';
wwv_flow_imp.g_varchar2_table(3) := ' OOW_DEMO_STORE_PRODUCTS_FK2 FOREIGN KEY (STORE_ID)'||wwv_flow.LF||
'      REFERENCES  OOW_DEMO_STORES (ID) ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(4) := 'ALTER TABLE  OOW_DEMO_SALES_HISTORY ADD CONSTRAINT OOW_DEMO_SALES_HISTORY_FK1 FOREIGN KEY (STORE_ID)';
wwv_flow_imp.g_varchar2_table(5) := ''||wwv_flow.LF||
'      REFERENCES  OOW_DEMO_STORES (ID) ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TABLE  OOW_DEMO_SALES_HISTORY ADD CONSTRAINT ';
wwv_flow_imp.g_varchar2_table(6) := 'OOW_DEMO_SALES_HISTORY_FK2 FOREIGN KEY (PRODUCT_ID)'||wwv_flow.LF||
'      REFERENCES  OOW_DEMO_ITEMS (ID) ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38800516770720925454)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'alter statements'
,p_sequence=>120
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
