prompt --application/deployment/install/install_alter_statements
begin
--   Manifest
--     INSTALL: INSTALL-alter statements
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38742994828314426631)
,p_install_id=>wwv_flow_imp.id(38742994623120425165)
,p_name=>'alter statements'
,p_sequence=>120
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ALTER TABLE  OOW_DEMO_STORE_PRODUCTS ADD CONSTRAINT OOW_DEMO_STORE_PRODUCTS_FK1 FOREIGN KEY (ITEM_ID)',
'      REFERENCES  OOW_DEMO_ITEMS (ID) ENABLE',
'/',
'ALTER TABLE  OOW_DEMO_STORE_PRODUCTS ADD CONSTRAINT OOW_DEMO_STORE_PRODUCTS_FK2 FOREIGN KEY (STORE_ID)',
'      REFERENCES  OOW_DEMO_STORES (ID) ENABLE',
'/',
'ALTER TABLE  OOW_DEMO_SALES_HISTORY ADD CONSTRAINT OOW_DEMO_SALES_HISTORY_FK1 FOREIGN KEY (STORE_ID)',
'      REFERENCES  OOW_DEMO_STORES (ID) ENABLE',
'/',
'ALTER TABLE  OOW_DEMO_SALES_HISTORY ADD CONSTRAINT OOW_DEMO_SALES_HISTORY_FK2 FOREIGN KEY (PRODUCT_ID)',
'      REFERENCES  OOW_DEMO_ITEMS (ID) ENABLE',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
