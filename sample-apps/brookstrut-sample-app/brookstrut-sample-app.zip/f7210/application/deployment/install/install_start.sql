prompt --application/deployment/install/install_start
begin
--   Manifest
--     INSTALL: INSTALL-start
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''install supporting objects start'', p_error_messag';
wwv_flow_imp.g_varchar2_table(2) := 'e => null);'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''APEX Session ID=''||v(''APP_SESSION''));'||wwv_flow.LF||
'    f';
wwv_flow_imp.g_varchar2_table(3) := 'or c1 in (select owner, application_id from APEX_APPLICATIONS where upper(application_name) like ''%B';
wwv_flow_imp.g_varchar2_table(4) := 'ROOKSTRUT%'') loop'||wwv_flow.LF||
'        oow_demo_event_pkg.log (p_event_name => ''APEX application id=''||c1.applica';
wwv_flow_imp.g_varchar2_table(5) := 'tion_id||'', parsing schema=''||c1.owner);'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    oow_demo_event_pkg.log ';
wwv_flow_imp.g_varchar2_table(6) := '(p_event_name => ''purge recyclebin'', p_error_message => null);'||wwv_flow.LF||
'    execute immediate ''purge recycleb';
wwv_flow_imp.g_varchar2_table(7) := 'in'';'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''completed call to purge recyclebin'', p_error_messa';
wwv_flow_imp.g_varchar2_table(8) := 'ge => null);'||wwv_flow.LF||
'exception when others then'||wwv_flow.LF||
'    oow_demo_event_pkg.log (p_event_name => ''error purging r';
wwv_flow_imp.g_varchar2_table(9) := 'ecycle bin'', p_error_message => sqlerrm);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38819164561856477310)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'start'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
