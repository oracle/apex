prompt --application/deployment/install/install_start
begin
--   Manifest
--     INSTALL: INSTALL-start
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38747182083445585515)
,p_install_id=>wwv_flow_imp.id(38728534087116032193)
,p_name=>'start'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    oow_demo_event_pkg.log (p_event_name => ''install supporting objects start'', p_error_message => null);',
'    oow_demo_event_pkg.log (p_event_name => ''APEX Session ID=''||v(''APP_SESSION''));',
'    for c1 in (select owner, application_id from APEX_APPLICATIONS where upper(application_name) like ''%BROOKSTRUT%'') loop',
'        oow_demo_event_pkg.log (p_event_name => ''APEX application id=''||c1.application_id||'', parsing schema=''||c1.owner);',
'    end loop;',
'end;',
'/',
'    ',
'begin',
'    oow_demo_event_pkg.log (p_event_name => ''purge recyclebin'', p_error_message => null);',
'    execute immediate ''purge recyclebin'';',
'    oow_demo_event_pkg.log (p_event_name => ''completed call to purge recyclebin'', p_error_message => null);',
'exception when others then',
'    oow_demo_event_pkg.log (p_event_name => ''error purging recycle bin'', p_error_message => sqlerrm);',
'end;',
'/',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
