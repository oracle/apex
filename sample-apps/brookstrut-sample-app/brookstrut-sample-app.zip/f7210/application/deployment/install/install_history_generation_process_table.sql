prompt --application/deployment/install/install_history_generation_process_table
begin
--   Manifest
--     INSTALL: INSTALL-History Generation Process table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table oow_demo_hist_gen_log ('||wwv_flow.LF||
'    id             number,'||wwv_flow.LF||
'    APP_SESSION_ID varchar2(255),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(2) := '  owner          varchar2(255) not null,'||wwv_flow.LF||
'    num_days       number,'||wwv_flow.LF||
'    max_orders     number,'||wwv_flow.LF||
'    s';
wwv_flow_imp.g_varchar2_table(3) := 'tart_time     timestamp with local time zone,'||wwv_flow.LF||
'    end_time       timestamp with local time zone,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := ' row_count      number,'||wwv_flow.LF||
'    constraint oow_demo_hist_gen_log_pk primary key ( id )'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'create or';
wwv_flow_imp.g_varchar2_table(5) := ' replace trigger bi_oow_demo_hist_gen_log'||wwv_flow.LF||
'    before insert or update on oow_demo_hist_gen_log'||wwv_flow.LF||
'for e';
wwv_flow_imp.g_varchar2_table(6) := 'ach row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_cnt number := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        select to_number';
wwv_flow_imp.g_varchar2_table(7) := '(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.owner ';
wwv_flow_imp.g_varchar2_table(8) := ':= nvl(apex_application.g_user,user);'||wwv_flow.LF||
'    :new.APP_SESSION_ID := v(''APP_SESSION'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    --if inserti';
wwv_flow_imp.g_varchar2_table(9) := 'ng then'||wwv_flow.LF||
'    --    select count(*) into l_cnt from oow_demo_hist_gen_log where start_time is not null';
wwv_flow_imp.g_varchar2_table(10) := ' and end_time is null;'||wwv_flow.LF||
'    --    if l_cnt > 0 then'||wwv_flow.LF||
'    --        raise_application_error(-20222,''Sal';
wwv_flow_imp.g_varchar2_table(11) := 'es history generation already in progress.'');'||wwv_flow.LF||
'    --    end if;'||wwv_flow.LF||
'    --end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38801075546957739887)
,p_install_id=>wwv_flow_imp.id(38800516565526923988)
,p_name=>'History Generation Process table'
,p_sequence=>140
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
