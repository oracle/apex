prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7210
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1867060655981638216
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(38724263165003246293)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table OOW_DEMO_ITEMS cascade constraints;',
'drop table OOW_DEMO_REGIONS cascade constraints;',
'drop table OOW_DEMO_STORES cascade constraints;',
'drop table OOW_DEMO_STORE_PRODUCTS cascade constraints;',
'drop table OOW_DEMO_PREFERENCES cascade constraints;',
'drop table OOW_DEMO_SALES_HISTORY cascade constraints;',
'drop table oow_demo_hist_gen_log cascade constraints;',
'drop table oow_demo_event_log cascade constraints;',
'drop package oow_demo_gen_data_pkg;',
'drop package OOW_DEMO_EVENT_PKG;',
'drop package oow_demo_timing;',
'drop sequence oow_demo_seq;',
'---',
'',
'begin',
'    wwv_flow_api.create_or_remove_file( ',
'        p_location => ''APPLICATION'',',
'        p_name     => ''app_icon.png'',',
'        p_mode     => ''REMOVE'',',
'        p_type     => ''IMAGE'');',
'',
'    wwv_flow_api.create_or_remove_file( ',
'        p_location => ''APPLICATION'',',
'        p_name     => ''blue_marker.png'',',
'        p_mode     => ''REMOVE'',',
'        p_type     => ''IMAGE'');',
'',
'    wwv_flow_api.create_or_remove_file( ',
'        p_location => ''APPLICATION'',',
'        p_name     => ''red_marker.png'',',
'        p_mode     => ''REMOVE'',',
'        p_type     => ''IMAGE'');',
'',
'    wwv_flow_api.create_or_remove_file( ',
'        p_location => ''APPLICATION'',',
'        p_name     => ''excanvas.min.js'',',
'        p_mode     => ''REMOVE'',',
'        p_type     => ''STATIC'');',
'',
'    wwv_flow_api.create_or_remove_file( ',
'        p_location => ''APPLICATION'',',
'        p_name     => ''jquery.flot.min.js'',',
'        p_mode     => ''REMOVE'',',
'        p_type     => ''STATIC'');',
'',
'    wwv_flow_api.create_or_remove_file( ',
'        p_location => ''APPLICATION'',',
'        p_name     => ''jquery.flot.resize.js'',',
'        p_mode     => ''REMOVE'',',
'        p_type     => ''STATIC'');',
'',
'    wwv_flow_api.create_or_remove_file( ',
'        p_location => ''APPLICATION'',',
'        p_name     => ''jquery.flot.selection.js'',',
'        p_mode     => ''REMOVE'',',
'        p_type     => ''STATIC'');',
'end;',
'/',
'',
'drop package oow_demo_sample_data;',
'',
''))
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'OOW_DEMO_ITEMS:OOW_DEMO_REGIONS:OOW_DEMO_STORES:OOW_DEMO_STORE_PRODUCTS:OOW_DEMO_SALES_HISTORY:OOW_DEMO_HIST_GEN_LOG:OOW_DEMO_PREFERENCES:OOW_DEMO_EVENT_LOG:OOW_DEMO_SAMPLE_DATA:OOW_DEMO_EVENT_PKG:OOW_DEMO_SEQ'
);
wwv_flow_imp.component_end;
end;
/
