prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7210
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop table OOW_DEMO_ITEMS cascade constraints;'||wwv_flow.LF||
'drop table OOW_DEMO_REGIONS cascade constraints;'||wwv_flow.LF||
'drop';
wwv_flow_imp.g_varchar2_table(2) := ' table OOW_DEMO_STORES cascade constraints;'||wwv_flow.LF||
'drop table OOW_DEMO_STORE_PRODUCTS cascade constraints;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(3) := 'drop table OOW_DEMO_PREFERENCES cascade constraints;'||wwv_flow.LF||
'drop table OOW_DEMO_SALES_HISTORY cascade const';
wwv_flow_imp.g_varchar2_table(4) := 'raints;'||wwv_flow.LF||
'drop table oow_demo_hist_gen_log cascade constraints;'||wwv_flow.LF||
'drop table oow_demo_event_log cascade ';
wwv_flow_imp.g_varchar2_table(5) := 'constraints;'||wwv_flow.LF||
'drop package oow_demo_gen_data_pkg;'||wwv_flow.LF||
'drop package OOW_DEMO_EVENT_PKG;'||wwv_flow.LF||
'drop package oow_d';
wwv_flow_imp.g_varchar2_table(6) := 'emo_timing;'||wwv_flow.LF||
'drop sequence oow_demo_seq;'||wwv_flow.LF||
'---'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(7) := 'p_location => ''APPLICATION'','||wwv_flow.LF||
'        p_name     => ''app_icon.png'','||wwv_flow.LF||
'        p_mode     => ''REMOVE'','||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(8) := '       p_type     => ''IMAGE'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'        p_location => ''APPL';
wwv_flow_imp.g_varchar2_table(9) := 'ICATION'','||wwv_flow.LF||
'        p_name     => ''blue_marker.png'','||wwv_flow.LF||
'        p_mode     => ''REMOVE'','||wwv_flow.LF||
'        p_type   ';
wwv_flow_imp.g_varchar2_table(10) := '  => ''IMAGE'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'        p_location => ''APPLICATION'','||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(11) := '  p_name     => ''red_marker.png'','||wwv_flow.LF||
'        p_mode     => ''REMOVE'','||wwv_flow.LF||
'        p_type     => ''IMAGE'');'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(12) := '   wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'        p_location => ''APPLICATION'','||wwv_flow.LF||
'        p_name     => ''';
wwv_flow_imp.g_varchar2_table(13) := 'excanvas.min.js'','||wwv_flow.LF||
'        p_mode     => ''REMOVE'','||wwv_flow.LF||
'        p_type     => ''STATIC'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    wwv_flow_api';
wwv_flow_imp.g_varchar2_table(14) := '.create_or_remove_file( '||wwv_flow.LF||
'        p_location => ''APPLICATION'','||wwv_flow.LF||
'        p_name     => ''jquery.flot.min';
wwv_flow_imp.g_varchar2_table(15) := '.js'','||wwv_flow.LF||
'        p_mode     => ''REMOVE'','||wwv_flow.LF||
'        p_type     => ''STATIC'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    wwv_flow_api.create_or_r';
wwv_flow_imp.g_varchar2_table(16) := 'emove_file( '||wwv_flow.LF||
'        p_location => ''APPLICATION'','||wwv_flow.LF||
'        p_name     => ''jquery.flot.resize.js'','||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(17) := '     p_mode     => ''REMOVE'','||wwv_flow.LF||
'        p_type     => ''STATIC'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_fil';
wwv_flow_imp.g_varchar2_table(18) := 'e( '||wwv_flow.LF||
'        p_location => ''APPLICATION'','||wwv_flow.LF||
'        p_name     => ''jquery.flot.selection.js'','||wwv_flow.LF||
'        p';
wwv_flow_imp.g_varchar2_table(19) := '_mode     => ''REMOVE'','||wwv_flow.LF||
'        p_type     => ''STATIC'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop package oow_demo_sample_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(38800516565526923988)
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'OOW_DEMO_ITEMS:OOW_DEMO_REGIONS:OOW_DEMO_STORES:OOW_DEMO_STORE_PRODUCTS:OOW_DEMO_SALES_HISTORY:OOW_DEMO_HIST_GEN_LOG:OOW_DEMO_PREFERENCES:OOW_DEMO_EVENT_LOG:OOW_DEMO_SAMPLE_DATA:OOW_DEMO_EVENT_PKG:OOW_DEMO_SEQ'
);
wwv_flow_imp.component_end;
end;
/
