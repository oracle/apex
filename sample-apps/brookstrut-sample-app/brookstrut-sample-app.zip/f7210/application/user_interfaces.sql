prompt --application/user_interfaces
begin
--   Manifest
--     USER INTERFACES: 7210
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_user_interface(
 p_id=>wwv_flow_imp.id(7210)
,p_theme_id=>42
,p_home_url=>'f?p=&APP_ID.:1:&SESSION.'
,p_theme_style_by_user_pref=>false
,p_navigation_list_id=>wwv_flow_imp.id(37089869070663300309)
,p_navigation_list_position=>'SIDE'
,p_navigation_list_template_id=>wwv_flow_imp.id(36225993430875977719)
,p_nav_list_template_options=>'#DEFAULT#:js-defaultCollapsed:js-navCollapsed--hidden:t-TreeNav--classic'
,p_include_legacy_javascript=>'18'
,p_include_jquery_migrate=>true
,p_nav_bar_type=>'LIST'
,p_nav_bar_list_id=>wwv_flow_imp.id(37090172740503394686)
,p_nav_bar_list_template_id=>wwv_flow_imp.id(36225992979255977719)
);
wwv_flow_imp.component_end;
end;
/
