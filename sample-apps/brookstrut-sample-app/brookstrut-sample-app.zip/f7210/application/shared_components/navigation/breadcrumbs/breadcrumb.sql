prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(44425078801060133467)
,p_name=>' Breadcrumb'
,p_static_id=>'breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(41394273170680409774)
,p_short_name=>'About'
,p_static_id=>'about'
,p_link=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:::'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38799637755924488010)
,p_short_name=>'Activity Calendar'
,p_static_id=>'activity-calendar'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38799602747028283236)
,p_short_name=>'Administration'
,p_static_id=>'administration'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38819360363287490277)
,p_short_name=>'Event Log'
,p_static_id=>'event-log'
,p_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38815919677468328318)
,p_short_name=>'Generate Transaction'
,p_static_id=>'generate-transaction'
,p_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:::'
,p_page_id=>29
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38815915171956290116)
,p_short_name=>'Generate Transactions'
,p_static_id=>'generate-transactions'
,p_link=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_page_id=>28
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(44425079212908133470)
,p_short_name=>'Home'
,p_static_id=>'home'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38828616454275541665)
,p_short_name=>'Load Data Results'
,p_static_id=>'load-data-results'
,p_link=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:::'
,p_page_id=>41
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(39062624477654562292)
,p_short_name=>'&P15_REGION_NAME. Region'
,p_static_id=>'p15-region-name-region'
,p_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13957199773808152256)
,p_short_name=>'&P18_PROCUCT_NAME.'
,p_static_id=>'p18-procuct-name'
,p_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38799092163178965207)
,p_short_name=>'&P3_STORE_NAME.'
,p_static_id=>'p3-store-name'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24561032197579029248)
,p_short_name=>'Page Views'
,p_static_id=>'page-views'
,p_link=>'f?p=&APP_ID.:39:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>39
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38797100756667725412)
,p_parent_id=>wwv_flow_imp.id(38797100467661725411)
,p_short_name=>'Product'
,p_static_id=>'product'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38815909259202675770)
,p_short_name=>'Product Availability by Store'
,p_static_id=>'product-availability-by-store'
,p_link=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:::'
,p_page_id=>27
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38797100467661725411)
,p_short_name=>'Products'
,p_static_id=>'products'
,p_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:RP::'
,p_page_id=>11
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(37354791650993392091)
,p_parent_id=>wwv_flow_imp.id(38799092163178965207)
,p_short_name=>'Recent Sales'
,p_static_id=>'recent-sales'
,p_link=>'f?p=&APP_ID.:43:&SESSION.::&DEBUG.:::'
,p_page_id=>43
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38796923758361504089)
,p_parent_id=>wwv_flow_imp.id(38796923467860504088)
,p_short_name=>'Region'
,p_static_id=>'region'
,p_link=>'f?p=&FLOW_ID.:9:&SESSION.'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38796923467860504088)
,p_short_name=>'Regions'
,p_static_id=>'regions'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38962022914601585784)
,p_short_name=>'Remove Transaction History'
,p_static_id=>'remove-transaction-history'
,p_link=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:::'
,p_page_id=>26
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38800557359298323758)
,p_short_name=>'Reports'
,p_static_id=>'reports'
,p_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38828606754855401852)
,p_short_name=>'Reset Sample Data'
,p_static_id=>'reset-sample-data'
,p_link=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:::'
,p_page_id=>40
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38815878062833500909)
,p_short_name=>'Sales by Product and Region by Week'
,p_static_id=>'sales-by-product-and-region-by-week'
,p_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::'
,p_page_id=>25
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38800561774769352177)
,p_short_name=>'Sales by Region by Week'
,p_static_id=>'sales-by-region-by-week'
,p_link=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:::'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38815895859160613053)
,p_short_name=>'Sales by Store by Day'
,p_static_id=>'sales-by-store-by-day'
,p_link=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::'
,p_page_id=>20
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38800517851982041323)
,p_short_name=>'Sales Dashboard'
,p_static_id=>'sales-dashboard'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13900425544307197707)
,p_short_name=>'Sales History'
,p_static_id=>'sales-history'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13958927452620645550)
,p_short_name=>'Sales History'
,p_static_id=>'sales-history-2'
,p_link=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:::'
,p_page_id=>38
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13960057732186873183)
,p_short_name=>'Sales History'
,p_static_id=>'sales-history-3'
,p_link=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:RP::'
,p_page_id=>50
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13960096372110897856)
,p_short_name=>'Sales History'
,p_static_id=>'sales-history-4'
,p_link=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:::'
,p_page_id=>51
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13960207577638948445)
,p_short_name=>'Sales History'
,p_static_id=>'sales-history-5'
,p_link=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.:::'
,p_page_id=>45
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13960625825448065187)
,p_short_name=>'Sales History'
,p_static_id=>'sales-history-6'
,p_link=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:::'
,p_page_id=>46
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14282435006807447948)
,p_short_name=>'Sales History'
,p_static_id=>'sales-history-7'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14284110287584997944)
,p_short_name=>'Sales History'
,p_static_id=>'sales-history-8'
,p_link=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:::'
,p_page_id=>42
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38800519459860080764)
,p_short_name=>'Sales History'
,p_static_id=>'sales-history-9'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38801563673004652054)
,p_parent_id=>wwv_flow_imp.id(38799602747028283236)
,p_short_name=>'Sales History Generation Log'
,p_static_id=>'sales-history-generation-log'
,p_link=>'f?p=&APP_ID.:24:&SESSION.'
,p_page_id=>24
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38797116761968296176)
,p_short_name=>'Store'
,p_static_id=>'store'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(41305530756112818856)
,p_short_name=>'Store Locations Map'
,p_static_id=>'store-locations-map'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38796830576292623486)
,p_short_name=>'Stores'
,p_static_id=>'stores'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38816036646850066404)
,p_short_name=>'Table Counts'
,p_static_id=>'table-counts'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38799626174661461243)
,p_short_name=>'Top Users'
,p_static_id=>'top-users'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38815924862624842319)
,p_short_name=>'Transaction'
,p_static_id=>'transaction'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38815929669437883019)
,p_short_name=>'Transaction Details'
,p_static_id=>'transaction-details'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38816051855945291868)
,p_short_name=>'Transaction Log'
,p_static_id=>'transaction-log'
,p_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
,p_page_id=>33
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38816380963041194556)
,p_short_name=>'Transaction Summary by Hour'
,p_static_id=>'transaction-summary-by-hour'
,p_link=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:::'
,p_page_id=>35
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38816376169673119535)
,p_short_name=>'Transaction Summary by Minute'
,p_static_id=>'transaction-summary-by-minute'
,p_link=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:::'
,p_page_id=>34
);
wwv_flow_imp.component_end;
end;
/
