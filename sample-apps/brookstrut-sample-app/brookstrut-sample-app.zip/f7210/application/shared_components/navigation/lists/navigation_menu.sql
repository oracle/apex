prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(37104329606667693281)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>37167692709710
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(37104329763417693281)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'1,14'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(37104329828435693281)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-line-chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(37104330060650693281)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Stores [&STORES.]'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cart-full'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6,7,3,43'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(37104330107425693281)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Products [&PRODUCTS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-archive'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'11,12'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(37104330360734693281)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Transactions'
,p_list_item_link_target=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-credit-card'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'28,29,30,31,33,34,35'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(37104330420566693281)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Reports'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'19,20,22,25,20,26,27,32,36,37,38,2,23,42'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(37104330510326693281)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gear'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4,8,9,13,15,16,17,24,21,,40,41,42,45,23,39'
);
wwv_flow_imp.component_end;
end;
/
