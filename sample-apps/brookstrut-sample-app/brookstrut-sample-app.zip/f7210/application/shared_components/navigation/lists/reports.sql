prompt --application/shared_components/navigation/lists/reports
begin
--   Manifest
--     LIST: reports
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(38743036909899835744)
,p_name=>'reports'
,p_list_status=>'PUBLIC'
,p_version_scn=>37167692709710
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38743042529863907797)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Sales by Region by Week'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-dollar'
,p_list_text_01=>'Weekly sales metrics by region'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38758357824786022528)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Sales by Product and Region by Week'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-dollar'
,p_list_text_01=>'Interactive report of weekly sales metrics by product by region'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38758374125404117383)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Sales by Store by Day'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'View monthly calendar of sales by store by day'
,p_list_text_02=>'calendarIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38758388803847180347)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Products Available by Store'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-archive'
,p_list_text_01=>'View percentages of products available at each store'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38758516106258623888)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Table Row Counts'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>'View a list of the database tables used by this demonstration system and the current row counts.'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
