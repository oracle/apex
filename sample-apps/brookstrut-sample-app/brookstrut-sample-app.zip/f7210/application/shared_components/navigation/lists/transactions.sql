prompt --application/shared_components/navigation/lists/transactions
begin
--   Manifest
--     LIST: Transactions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(38743935798128433089)
,p_name=>'Transactions'
,p_list_status=>'PUBLIC'
,p_version_scn=>37167692709710
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38744045175086030589)
,p_list_item_display_sequence=>1
,p_list_item_link_text=>'Reset Sample Data'
,p_list_item_link_target=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'Reset sales history to t-shirt sizes'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38743935988119433089)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Generate Transaction on Button Click'
,p_list_item_link_target=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'Generate one transaction for a random product from a random store.  Press button complete transaction.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38743942579838957684)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Generate Transaction on Page Load'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'Generate one transaction by loading the page.  Includes option to automatically resubmit page via javascript.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38743948194955028230)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Generate 100 Transactions on Page Load'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'Generate 100 transactions.  Click button to generate another 100 transactions.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38890166310850703356)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>'Remove Transaction History'
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-trash-o'
,p_list_text_01=>'Remove transaction history.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
