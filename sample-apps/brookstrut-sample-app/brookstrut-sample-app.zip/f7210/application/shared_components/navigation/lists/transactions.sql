prompt --application/shared_components/navigation/lists/transactions
begin
--   Manifest
--     LIST: Transactions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(25539826150178785032)
,p_name=>'Transactions'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(25539935527136382532)
,p_list_item_display_sequence=>1
,p_list_item_link_text=>'Reset Sample Data'
,p_list_item_link_target=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'Reset sales history to t-shirt sizes'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(25539826340169785032)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Generate Transaction on Button Click'
,p_list_item_link_target=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'Generate one transaction for a random product from a random store.  Press button complete transaction.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(25539832931889309627)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Generate Transaction on Page Load'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'Generate one transaction by loading the page.  Includes option to automatically resubmit page via javascript.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(25539838547005380173)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Generate 100 Transactions on Page Load'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'Generate one transaction by loading the page.  Refresh browser page to generate a second transaction.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(25686056662901055299)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>'Remove Transaction History'
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-trash-o'
,p_list_text_01=>'Generate one transaction by loading the page.  Refresh browser page to generate a second transaction.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
