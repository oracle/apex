prompt --application/shared_components/navigation/lists/transactions
begin
--   Manifest
--     LIST: Transactions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(38815918276539324884)
,p_name=>'Transactions'
,p_static_id=>'transactions'
,p_version_scn=>'37167692709710'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38815930673365920025)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Generate 100 Transactions on Page Load'
,p_static_id=>'generate-100-transactions-on-page-load'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'Generate 100 transactions.  Click button to generate another 100 transactions.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38815918466530324884)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Generate Transaction on Button Click'
,p_static_id=>'generate-transaction-on-button-click'
,p_list_item_link_target=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'Generate one transaction for a random product from a random store.  Press button complete transaction.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38815925058249849479)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Generate Transaction on Page Load'
,p_static_id=>'generate-transaction-on-page-load'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'Generate one transaction by loading the page.  Includes option to automatically resubmit page via javascript.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38962148789261595151)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>'Remove Transaction History'
,p_static_id=>'remove-transaction-history'
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-trash-o'
,p_list_text_01=>'Remove transaction history.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38816027653496922384)
,p_list_item_display_sequence=>1
,p_list_item_link_text=>'Reset Sample Data'
,p_static_id=>'reset-sample-data'
,p_list_item_link_target=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'Reset sales history to t-shirt sizes'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
