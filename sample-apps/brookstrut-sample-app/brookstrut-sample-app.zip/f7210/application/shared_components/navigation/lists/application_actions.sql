prompt --application/shared_components/navigation/lists/application_actions
begin
--   Manifest
--     LIST: Application Actions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(38740020214430525898)
,p_name=>'Application Actions'
,p_list_status=>'PUBLIC'
,p_version_scn=>37167692709710
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38742996331318569416)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Sales Dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-line-chart'
,p_list_text_01=>'Analysis dashboard of sales data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38741469125096285597)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Store Locations Map'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:10:::'
,p_list_item_icon=>'fa-map-o'
,p_list_text_01=>'Set production promotions by store using map interface.'
,p_required_patch=>wwv_flow_imp.id(38758409817425540301)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38740022923565538012)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Regions'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-globe'
,p_list_text_01=>'Each store is mapped to a geographic region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38740020433883525899)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Stores'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-shopping-bag'
,p_list_text_01=>'Identify attributes, products sold, discounts and geographic region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38740025413307544446)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Products'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-package'
,p_list_text_01=>'Identify product items available for sale at one or more stores'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(13843015688972124982)
,p_list_item_display_sequence=>56
,p_list_item_link_text=>'Sales History'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RP,2:::'
,p_list_item_icon=>'fa-credit-card'
,p_list_text_01=>'Identify product items available for sale at one or more stores'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38758411914009567780)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Generate Transactions'
,p_list_item_link_target=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gears'
,p_list_text_01=>'Generate sale transactions'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38758412209871717919)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Analysis Reports'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Run reports to analyze sales history data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38997993282199059128)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user'
,p_list_text_01=>'Run reports to analyze sales history data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
