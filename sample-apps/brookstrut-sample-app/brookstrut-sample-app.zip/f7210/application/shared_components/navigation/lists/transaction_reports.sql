prompt --application/shared_components/navigation/lists/transaction_reports
begin
--   Manifest
--     LIST: Transaction Reports
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(38744072578601886146)
,p_name=>'Transaction Reports'
,p_list_status=>'PUBLIC'
,p_version_scn=>37167692709710
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38744072787205886146)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Transactions Log'
,p_list_item_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Report listing each call made to the transaction generator.'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38744395896357298172)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'API Calls Per Minute'
,p_list_item_link_target=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Summary report of API calls summarized by minute.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38744399095103307309)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'API Calls Per Hour'
,p_list_item_link_target=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Summary report of API calls summarized by hour.'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
