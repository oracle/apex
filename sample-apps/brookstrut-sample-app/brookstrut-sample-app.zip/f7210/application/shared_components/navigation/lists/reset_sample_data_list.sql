prompt --application/shared_components/navigation/lists/reset_sample_data_list
begin
--   Manifest
--     LIST: reset sample data LIST
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(38756625989246527187)
,p_name=>'reset sample data LIST'
,p_list_status=>'PUBLIC'
,p_version_scn=>37167692709710
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38756626171673527190)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Reset Data to S'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''S'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 500 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38756626497129527197)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Reset Data to M'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''M'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 1,000 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38756626778998527197)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Reset Data to L'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''L'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 5,000 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38756627068905527197)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Reset Data to XL'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''XL'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 25,000 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38757191768014957408)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Reset Data to 2XL'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''XXL'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 50,000 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39966038814723800783)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Reset Data to 3XL'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''XXXL'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 100,000 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39966061527851817296)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Reset Data to 4XL'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''4XL'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 1,000,000 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39966099271007789123)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Reset Data to 5XL'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''5XL'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 5,000,000 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
