prompt --application/shared_components/navigation/lists/reset_sample_data_list
begin
--   Manifest
--     LIST: reset sample data LIST
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(38745052894602629648)
,p_name=>'reset sample data LIST'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38745053077029629651)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Reset Data to S'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''S'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 500 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38745053402485629658)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Reset Data to M'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''M'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 1,000 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38745053684354629658)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Reset Data to L'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''L'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 5,000 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38745053974261629658)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Reset Data to XL'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''XL'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 25,000 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38745618673371059869)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Reset Data to 2XL'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''XXL'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 50,000 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39954465720079903244)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Reset Data to 3XL'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''XXXL'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 100,000 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39954488433207919757)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Reset Data to 4XL'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''4XL'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 1,000,000 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39954526176363891584)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Reset Data to 5XL'
,p_list_item_link_target=>'javascript:$s(''P40_SIZE'',''5XL'');apex.submit({showWait:true});'
,p_list_item_icon=>'fa-cog'
,p_list_text_01=>'Truncate existing sales history data and generate 5,000,000 rows of sales history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
