prompt --application/shared_components/user_interface/lovs/regions
begin
--   Manifest
--     REGIONS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38796925058372554770)
,p_lov_name=>'REGIONS'
,p_static_id=>'regions'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select region_name, id ',
'from OOW_DEMO_REGIONS ',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'37167692709758'
);
wwv_flow_imp.component_end;
end;
/
