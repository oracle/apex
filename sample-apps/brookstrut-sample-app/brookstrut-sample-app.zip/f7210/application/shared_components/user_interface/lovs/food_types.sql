prompt --application/shared_components/user_interface/lovs/food_types
begin
--   Manifest
--     FOOD TYPES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(36641848082217986806)
,p_lov_name=>'FOOD TYPES'
,p_lov_query=>'.'||wwv_flow_imp.id(36641848082217986806)||'.'
,p_location=>'STATIC'
,p_version_scn=>37167692709758
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(36641848287239986810)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Food'
,p_lov_return_value=>'Food'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(36641848569102986813)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Drink'
,p_lov_return_value=>'Drink'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(36641848897453986814)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Soap'
,p_lov_return_value=>'Soap'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(36641849193389986814)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Miscellaneous'
,p_lov_return_value=>'Miscellaneous'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13854880796186950046)
,p_lov_disp_sequence=>50
,p_lov_disp_value=>'Snacks'
,p_lov_return_value=>'Snacks'
);
wwv_flow_imp.component_end;
end;
/
