prompt --application/shared_components/user_interface/lovs/food_types
begin
--   Manifest
--     FOOD TYPES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(36713830560628878601)
,p_lov_name=>'FOOD TYPES'
,p_static_id=>'food-types'
,p_lov_query=>'.'||wwv_flow_imp.id(36713830560628878601)||'.'
,p_location=>'STATIC'
,p_version_scn=>'37167692709758'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(36713831047513878608)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Drink'
,p_lov_return_value=>'Drink'
,p_static_id=>'drink'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(36713830765650878605)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Food'
,p_lov_return_value=>'Food'
,p_static_id=>'food'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(36713831671800878609)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Miscellaneous'
,p_lov_return_value=>'Miscellaneous'
,p_static_id=>'miscellaneous'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13926863274597841841)
,p_lov_disp_sequence=>50
,p_lov_disp_value=>'Snacks'
,p_lov_return_value=>'Snacks'
,p_static_id=>'snacks'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(36713831375864878609)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Soap'
,p_lov_return_value=>'Soap'
,p_static_id=>'soap'
);
wwv_flow_imp.component_end;
end;
/
