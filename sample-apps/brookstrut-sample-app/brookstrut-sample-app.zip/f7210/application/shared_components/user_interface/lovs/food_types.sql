prompt --application/shared_components/user_interface/lovs/food_types
begin
--   Manifest
--     FOOD TYPES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1867060655981638216
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(36637577160105200906)
,p_lov_name=>'FOOD TYPES'
,p_lov_query=>'.'||wwv_flow_imp.id(36637577160105200906)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(36637577365127200910)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Food'
,p_lov_return_value=>'Food'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(36637577646990200913)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Drink'
,p_lov_return_value=>'Drink'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(36637577975341200914)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Soap'
,p_lov_return_value=>'Soap'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(36637578271277200914)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Miscellaneous'
,p_lov_return_value=>'Miscellaneous'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13850609874074164146)
,p_lov_disp_sequence=>50
,p_lov_disp_value=>'Snacks'
,p_lov_return_value=>'Snacks'
);
wwv_flow_imp.component_end;
end;
/
