prompt --application/shared_components/user_interface/lovs/items
begin
--   Manifest
--     ITEMS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38796130547313021455)
,p_lov_name=>'ITEMS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select item_name d, id r',
'from   OOW_DEMO_items ',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>37167692709758
);
wwv_flow_imp.component_end;
end;
/
