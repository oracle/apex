prompt --application/shared_components/user_interface/lovs/truncation_options
begin
--   Manifest
--     TRUNCATION OPTIONS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38758395106727789769)
,p_lov_name=>'TRUNCATION OPTIONS'
,p_lov_query=>'.'||wwv_flow_imp.id(38758395106727789769)||'.'
,p_location=>'STATIC'
,p_version_scn=>37167692709758
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38758395304104789771)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Retain existing history and generate additional history'
,p_lov_return_value=>'N'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38758395503975789772)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Truncate existing sales history and generate new history'
,p_lov_return_value=>'Y'
);
wwv_flow_imp.component_end;
end;
/
