prompt --application/shared_components/user_interface/lovs/truncation_options
begin
--   Manifest
--     TRUNCATION OPTIONS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38732361476079499258)
,p_lov_name=>'TRUNCATION OPTIONS'
,p_lov_query=>'.'||wwv_flow_imp.id(38732361476079499258)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38732361673456499260)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Retain existing history and generate additional history'
,p_lov_return_value=>'N'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38732361873327499261)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Truncate existing sales history and generate new history'
,p_lov_return_value=>'Y'
);
wwv_flow_imp.component_end;
end;
/
