prompt --application/shared_components/user_interface/lovs/auto_refresh
begin
--   Manifest
--     AUTO REFRESH
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38744051697547058956)
,p_lov_name=>'AUTO REFRESH'
,p_lov_query=>'.'||wwv_flow_imp.id(38744051697547058956)||'.'
,p_location=>'STATIC'
,p_version_scn=>37167692709754
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38744208772181120908)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Every Second'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38744051868907058957)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Every 5 seconds'
,p_lov_return_value=>'5'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38744052079492058957)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Every 10 seconds'
,p_lov_return_value=>'10'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38744052300047058957)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Every 30 seconds'
,p_lov_return_value=>'30'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38744052772052061080)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Every 1 minute'
,p_lov_return_value=>'40'
);
wwv_flow_imp.component_end;
end;
/
