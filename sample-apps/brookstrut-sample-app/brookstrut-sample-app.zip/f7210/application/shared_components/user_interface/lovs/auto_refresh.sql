prompt --application/shared_components/user_interface/lovs/auto_refresh
begin
--   Manifest
--     AUTO REFRESH
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38758512233551451928)
,p_lov_name=>'AUTO REFRESH'
,p_lov_query=>'.'||wwv_flow_imp.id(38758512233551451928)||'.'
,p_location=>'STATIC'
,p_version_scn=>37167692709754
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38758669308185513880)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Every Second'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38758512404911451929)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Every 5 seconds'
,p_lov_return_value=>'5'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38758512615496451929)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Every 10 seconds'
,p_lov_return_value=>'10'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38758512836051451929)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Every 30 seconds'
,p_lov_return_value=>'30'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38758513308056454052)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Every 1 minute'
,p_lov_return_value=>'40'
);
wwv_flow_imp.component_end;
end;
/
