prompt --application/shared_components/user_interface/lovs/auto_refresh
begin
--   Manifest
--     AUTO REFRESH
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38816034175957950751)
,p_lov_name=>'AUTO REFRESH'
,p_static_id=>'auto-refresh'
,p_lov_query=>'.'||wwv_flow_imp.id(38816034175957950751)||'.'
,p_location=>'STATIC'
,p_version_scn=>'37167692709754'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38816035250462952875)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Every 1 minute'
,p_lov_return_value=>'40'
,p_static_id=>'every-1-minute'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38816034557902950752)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Every 10 seconds'
,p_lov_return_value=>'10'
,p_static_id=>'every-10-seconds'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38816034778457950752)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Every 30 seconds'
,p_lov_return_value=>'30'
,p_static_id=>'every-30-seconds'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38816034347317950752)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Every 5 seconds'
,p_lov_return_value=>'5'
,p_static_id=>'every-5-seconds'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38816191250592012703)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Every Second'
,p_lov_return_value=>'1'
,p_static_id=>'every-second'
);
wwv_flow_imp.component_end;
end;
/
