prompt --application/shared_components/user_interface/lovs/auto_refresh
begin
--   Manifest
--     AUTO REFRESH
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(25539942049597410899)
,p_lov_name=>'AUTO REFRESH'
,p_lov_query=>'.'||wwv_flow_imp.id(25539942049597410899)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(25540099124231472851)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Every Second'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(25539942220957410900)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Every 5 seconds'
,p_lov_return_value=>'5'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(25539942431542410900)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Every 10 seconds'
,p_lov_return_value=>'10'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(25539942652097410900)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Every 30 seconds'
,p_lov_return_value=>'30'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(25539943124102413023)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Every 1 minute'
,p_lov_return_value=>'40'
);
wwv_flow_imp.component_end;
end;
/
