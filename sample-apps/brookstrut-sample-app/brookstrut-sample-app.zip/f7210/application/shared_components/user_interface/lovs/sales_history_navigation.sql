prompt --application/shared_components/user_interface/lovs/sales_history_navigation
begin
--   Manifest
--     SALES HISTORY NAVIGATION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1867060655981638216
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13883133630914513292)
,p_lov_name=>'SALES HISTORY NAVIGATION'
,p_lov_query=>'.'||wwv_flow_imp.id(13883133630914513292)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13883134315716513295)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Classic Report'
,p_lov_return_value=>'50'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13883135482107513296)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Interactive Report'
,p_lov_return_value=>'51'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14206891750862828885)
,p_lov_disp_sequence=>25
,p_lov_disp_value=>'Interactive Grid'
,p_lov_return_value=>'23'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13883133872219513294)
,p_lov_disp_sequence=>27
,p_lov_disp_value=>'Faceted Classic Report'
,p_lov_return_value=>'13'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14207886420500327674)
,p_lov_disp_sequence=>28
,p_lov_disp_value=>'Faceted Calendar'
,p_lov_return_value=>'42'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13883134660776513295)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Faceted Content Row'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13883135059711513296)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Faceted Content Row with Menus'
,p_lov_return_value=>'38'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13884164567686817978)
,p_lov_disp_sequence=>50
,p_lov_disp_value=>'Smart Search with Classic Cards'
,p_lov_return_value=>'46'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13883640744740697836)
,p_lov_disp_sequence=>60
,p_lov_disp_value=>'Smart Search Content Row with Menu'
,p_lov_return_value=>'45'
);
wwv_flow_imp.component_end;
end;
/
