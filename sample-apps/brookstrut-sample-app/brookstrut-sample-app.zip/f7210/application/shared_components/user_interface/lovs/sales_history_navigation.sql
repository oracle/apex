prompt --application/shared_components/user_interface/lovs/sales_history_navigation
begin
--   Manifest
--     SALES HISTORY NAVIGATION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13887404553027299192)
,p_lov_name=>'SALES HISTORY NAVIGATION'
,p_lov_query=>'.'||wwv_flow_imp.id(13887404553027299192)||'.'
,p_location=>'STATIC'
,p_version_scn=>37167692709758
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13887405237829299195)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Classic Report'
,p_lov_return_value=>'50'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13887406404220299196)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Interactive Report'
,p_lov_return_value=>'51'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14211162672975614785)
,p_lov_disp_sequence=>25
,p_lov_disp_value=>'Interactive Grid'
,p_lov_return_value=>'23'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13887404794332299194)
,p_lov_disp_sequence=>27
,p_lov_disp_value=>'Faceted Classic Report'
,p_lov_return_value=>'13'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14212157342613113574)
,p_lov_disp_sequence=>28
,p_lov_disp_value=>'Faceted Calendar'
,p_lov_return_value=>'42'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13887405582889299195)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Faceted Content Row'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13887405981824299196)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Faceted Content Row with Menus'
,p_lov_return_value=>'38'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13888435489799603878)
,p_lov_disp_sequence=>50
,p_lov_disp_value=>'Smart Search with Classic Cards'
,p_lov_return_value=>'46'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13887911666853483736)
,p_lov_disp_sequence=>60
,p_lov_disp_value=>'Smart Search Content Row with Menu'
,p_lov_return_value=>'45'
);
wwv_flow_imp.component_end;
end;
/
