prompt --application/shared_components/user_interface/lovs/oow_demo_stores_store_name
begin
--   Manifest
--     OOW_DEMO_STORES.STORE_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.13'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1472955480067066
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(27761041502503794633)
,p_lov_name=>'OOW_DEMO_STORES.STORE_NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'OOW_DEMO_STORES'
,p_return_column_name=>'ID'
,p_display_column_name=>'STORE_NAME'
,p_default_sort_column_name=>'STORE_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>37167692709758
);
wwv_flow_imp.component_end;
end;
/
