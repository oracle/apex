prompt --application/shared_components/user_interface/lovs/popularity_view_options_p2
begin
--   Manifest
--     POPULARITY VIEW OPTIONS P2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(37344126081428993370)
,p_lov_name=>'POPULARITY VIEW OPTIONS P2'
,p_static_id=>'popularity-view-options-p'
,p_lov_query=>'.'||wwv_flow_imp.id(37344126081428993370)||'.'
,p_location=>'STATIC'
,p_version_scn=>'37167692709758'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(37344126426437993373)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Bubbles'
,p_lov_return_value=>'B'
,p_static_id=>'bubbles'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(37344126749290993375)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Interactive Report'
,p_lov_return_value=>'IR'
,p_static_id=>'interactive-report'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(37344127161431993375)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Treemap'
,p_lov_return_value=>'T'
,p_static_id=>'treemap'
);
wwv_flow_imp.component_end;
end;
/
