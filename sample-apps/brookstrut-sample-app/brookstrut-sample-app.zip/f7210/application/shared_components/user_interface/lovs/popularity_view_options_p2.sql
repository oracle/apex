prompt --application/shared_components/user_interface/lovs/popularity_view_options_p2
begin
--   Manifest
--     POPULARITY VIEW OPTIONS P2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(37260570508374204036)
,p_lov_name=>'POPULARITY VIEW OPTIONS P2'
,p_lov_query=>'.'||wwv_flow_imp.id(37260570508374204036)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(37260570853383204039)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Bubbles'
,p_lov_return_value=>'B'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(37260571176236204041)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Interactive Report'
,p_lov_return_value=>'IR'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(37260571588377204041)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Treemap'
,p_lov_return_value=>'T'
);
wwv_flow_imp.component_end;
end;
/
