prompt --application/shared_components/user_interface/lovs/popularity_view_options_p2
begin
--   Manifest
--     POPULARITY VIEW OPTIONS P2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(37272143603018101575)
,p_lov_name=>'POPULARITY VIEW OPTIONS P2'
,p_lov_query=>'.'||wwv_flow_imp.id(37272143603018101575)||'.'
,p_location=>'STATIC'
,p_version_scn=>37167692709758
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(37272143948027101578)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Bubbles'
,p_lov_return_value=>'B'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(37272144270880101580)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Interactive Report'
,p_lov_return_value=>'IR'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(37272144683021101580)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Treemap'
,p_lov_return_value=>'T'
);
wwv_flow_imp.component_end;
end;
/
