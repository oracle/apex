prompt --application/shared_components/user_interface/lovs/store_type
begin
--   Manifest
--     STORE TYPE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38713374704691969712)
,p_lov_name=>'STORE TYPE'
,p_lov_query=>'.'||wwv_flow_imp.id(38713374704691969712)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38713374882257969712)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Flagship'
,p_lov_return_value=>'Flagship'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38713375095079969715)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Branch'
,p_lov_return_value=>'Branch'
);
wwv_flow_imp.component_end;
end;
/
