prompt --application/shared_components/user_interface/lovs/store_type
begin
--   Manifest
--     STORE TYPE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38739408335340260223)
,p_lov_name=>'STORE TYPE'
,p_lov_query=>'.'||wwv_flow_imp.id(38739408335340260223)||'.'
,p_location=>'STATIC'
,p_version_scn=>37167692709758
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38739408512906260223)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Flagship'
,p_lov_return_value=>'Flagship'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38739408725728260226)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Branch'
,p_lov_return_value=>'Branch'
);
wwv_flow_imp.component_end;
end;
/
