prompt --application/shared_components/user_interface/lovs/oow_demo_items_type
begin
--   Manifest
--     OOW_DEMO_ITEMS.TYPE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(27761041721470794635)
,p_lov_name=>'OOW_DEMO_ITEMS.TYPE'
,p_static_id=>'oow-demo-items-type'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'OOW_DEMO_ITEMS'
,p_return_column_name=>'ID'
,p_display_column_name=>'TYPE'
,p_default_sort_column_name=>'TYPE'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'37167692709758'
);
wwv_flow_imp.component_end;
end;
/
