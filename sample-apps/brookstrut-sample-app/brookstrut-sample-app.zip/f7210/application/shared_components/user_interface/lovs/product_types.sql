prompt --application/shared_components/user_interface/lovs/product_types
begin
--   Manifest
--     PRODUCT_TYPES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(25523512328958756125)
,p_lov_name=>'PRODUCT_TYPES'
,p_lov_query=>'.'||wwv_flow_imp.id(25523512328958756125)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(25523512626061756129)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Drink'
,p_lov_return_value=>'Drink'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(25523512838124756129)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Food'
,p_lov_return_value=>'Food'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(25523513042366756129)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Miscellaneous'
,p_lov_return_value=>'Miscellaneous'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(25523513233914756129)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Soap'
,p_lov_return_value=>'Soap'
);
wwv_flow_imp.component_end;
end;
/
