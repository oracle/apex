prompt --application/shared_components/user_interface/lovs/product_types
begin
--   Manifest
--     PRODUCT_TYPES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38727621976908404182)
,p_lov_name=>'PRODUCT_TYPES'
,p_lov_query=>'.'||wwv_flow_imp.id(38727621976908404182)||'.'
,p_location=>'STATIC'
,p_version_scn=>37167692709758
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38727622274011404186)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Drink'
,p_lov_return_value=>'Drink'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38727622486074404186)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Food'
,p_lov_return_value=>'Food'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38727622690316404186)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Miscellaneous'
,p_lov_return_value=>'Miscellaneous'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(38727622881864404186)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Soap'
,p_lov_return_value=>'Soap'
);
wwv_flow_imp.component_end;
end;
/
