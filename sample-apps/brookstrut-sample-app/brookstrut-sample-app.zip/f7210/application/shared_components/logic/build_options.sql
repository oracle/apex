prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 7210
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(25539839633471499272)
,p_build_option_name=>'Maps'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>1
,p_build_option_comment=>'Show store locations on a map.  Including provides the ability to show store locations on a map.  Excluding removes this capability from users.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(27927985052968813437)
,p_build_option_name=>'Feature: Theme Style Selection'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>1
,p_feature_identifier=>'APPLICATION_THEME_STYLE_SELECTION'
,p_build_option_comment=>'Allow administrators to select a default color scheme (theme style) for the application. Administrators can also choose to allow end users to choose their own theme style. '
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(27929903027852463549)
,p_build_option_name=>'Feature: Configuration Options'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>1
,p_feature_identifier=>'APPLICATION_CONFIGURATION'
,p_build_option_comment=>'Allow application administrators to enable or disable specific functionality, associated with an Oracle APEX build option, from within the application.'
);
wwv_flow_imp.component_end;
end;
/
