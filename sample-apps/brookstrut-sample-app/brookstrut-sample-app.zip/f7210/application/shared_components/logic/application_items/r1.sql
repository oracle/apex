prompt --application/shared_components/logic/application_items/r1
begin
--   Manifest
--     APPLICATION ITEM: R1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(38816923155168269462)
,p_name=>'R1'
,p_protection_level=>'S'
,p_escape_on_http_output=>'N'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
