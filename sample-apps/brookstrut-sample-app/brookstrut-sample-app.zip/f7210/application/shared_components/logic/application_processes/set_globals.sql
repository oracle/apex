prompt --application/shared_components/logic/application_processes/set_globals
begin
--   Manifest
--     APPLICATION PROCESS: set globals
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(37268343332337426401)
,p_process_sequence=>1
,p_process_point=>'AFTER_HEADER'
,p_process_name=>'set globals'
,p_static_id=>'set-globals'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(*) into :STORES from oow_demo_stores;',
'',
'select count(*) into :PRODUCTS from oow_demo_items;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
