prompt --application/shared_components/plugins/region_type/com_oracle_apex_d3_line
begin
--   Manifest
--     PLUGIN: COM.ORACLE.APEX.D3.LINE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(37188309159362658648)
,p_plugin_type=>'REGION TYPE'
,p_name=>'COM.ORACLE.APEX.D3.LINE'
,p_display_name=>'D3 Line Chart'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('REGION TYPE','COM.ORACLE.APEX.D3.LINE'),'')
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/d3/3.5.5/d3.min.js',
'#IMAGE_PREFIX#plugins/com.oracle.apex.d3/d3.oracle.js',
'#IMAGE_PREFIX#plugins/com.oracle.apex.d3/oracle.jql.js',
'#IMAGE_PREFIX#plugins/com.oracle.apex.d3.tooltip/d3.oracle.tooltip.js',
'#IMAGE_PREFIX#plugins/com.oracle.apex.d3.ary/d3.oracle.ary.js',
'#IMAGE_PREFIX#plugins/com.oracle.apex.d3.linechart/1.0/d3.oracle.linechart.js',
'#PLUGIN_FILES#com.oracle.apex.d3.linechart.js'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#plugins/com.oracle.apex.d3.tooltip/d3.oracle.tooltip.css',
'#IMAGE_PREFIX#plugins/com.oracle.apex.d3.ary/d3.oracle.ary.css',
'#IMAGE_PREFIX#plugins/com.oracle.apex.d3.linechart/1.0/d3.oracle.linechart.css'))
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function render ',
'(',
'    p_region                in  apex_plugin.t_region,',
'    p_plugin                in  apex_plugin.t_plugin,',
'    p_is_printer_friendly   in  boolean ',
')',
'return apex_plugin.t_region_render_result',
'is',
'    -- Assign readable names to plugin attributes. Omit data attributes, they''ll be handled in ajax function.',
'    -- Dimensions',
'    c_height_mode           constant varchar2(200)  := p_region.attribute_09;',
'    c_min_height            constant number         := nvl(p_region.attribute_17, 100);',
'    c_max_height            constant number         := nvl(p_region.attribute_18, 500);',
'',
'    -- Axis titles',
'    c_x_axis_title          constant varchar2(200)  := p_region.attribute_03;',
'    c_y_axis_title          constant varchar2(200)  := p_region.attribute_04;',
'',
'    -- Axis grid',
'    c_x_axis_grid           constant boolean        := instr('':'' || p_region.attribute_21 || '':'', '':X:'') > 0;',
'    c_y_axis_grid           constant boolean        := instr('':'' || p_region.attribute_21 || '':'', '':Y:'') > 0;',
'',
'    -- Line interpolation',
'    c_line_interpolation    constant varchar2(200)  := p_region.attribute_08;',
'',
'    -- Tooltip configuration',
'    c_show_tooltip          constant boolean        := p_region.attribute_16 is not null;',
'    c_series_tooltip        constant boolean        := instr('':'' || p_region.attribute_16 || '':'', '':SERIES:'') > 0;',
'    c_x_tooltip             constant boolean        := instr('':'' || p_region.attribute_16 || '':'', '':X:'') > 0;',
'    c_y_tooltip             constant boolean        := instr('':'' || p_region.attribute_16 || '':'', '':Y:'') > 0;',
'    c_custom_tooltip        constant boolean        := instr('':'' || p_region.attribute_16 || '':'', '':CUSTOM:'') > 0;',
'',
'    -- Legend',
'    c_show_legend           constant boolean        := p_region.attribute_25 is not null;',
'    c_legend_position       constant varchar2(200)  := p_region.attribute_25;',
'',
'    -- Display modes',
'    c_x_data_type           constant varchar2(200)  := p_region.attribute_05;',
'    c_x_value_template      constant varchar2(200)  := nvl(p_region.attribute_06, p_region.attribute_07);',
'    c_y_value_template      constant varchar2(200)  := nvl(p_region.attribute_10, p_region.attribute_11);',
'    c_x_tick_interval       constant varchar2(200)  := nvl(p_region.attribute_12, ''auto'');',
'    c_responsive            constant boolean        := p_plugin.attribute_05 = ''Y'';',
'    c_transitions           constant boolean        := p_plugin.attribute_06 = ''Y'';',
'    c_display               constant varchar2(200)  := p_region.attribute_20;',
'',
'    -- Colors',
'    c_color_scheme          constant varchar2(200)  := p_region.attribute_13;',
'    l_colors                varchar2(200)           := p_region.attribute_14;',
'',
'    -- Aspect ratios',
'    c_min_ar                constant number         := nvl( apex_plugin_util.get_attribute_as_number(p_plugin.attribute_02, ''Min Aspect Ratio''), 1.333);',
'    c_max_ar                constant number         := nvl( apex_plugin_util.get_attribute_as_number(p_plugin.attribute_01, ''Max Aspect Ratio''), 3);',
'    c_threshold             constant number         := p_plugin.attribute_03;',
'    c_threshold_of          constant varchar2(200)  := p_plugin.attribute_04;',
'begin',
'    -- Add placeholder div',
'    sys.htp.p (',
'        ''<div class="a-D3LineChart" id="'' || p_region.static_id || ''_region">'' ||',
'            ''<div class="a-D3LineChart-container" id="'' || p_region.static_id || ''_chart"></div>'' ||',
'        ''</div>'' );',
'',
'    -- Color scheme',
'    case c_color_scheme',
'        when ''MODERN'' then',
'            l_colors := ''#FF3B30:#FF9500:#FFCC00:#4CD964:#34AADC:#007AFF:#5856D6:#FF2D55:#8E8E93:#C7C7CC'';',
'        when ''MODERN2'' then',
'            l_colors := ''#1ABC9C:#2ECC71:#4AA3DF:#9B59B6:#3D566E:#F1C40F:#E67E22:#E74C3C'';',
'        when ''SOLAR'' then',
'            l_colors := ''#B58900:#CB4B16:#DC322F:#D33682:#6C71C4:#268BD2:#2AA198:#859900'';',
'        when ''METRO'' then',
'            l_colors := ''#E61400:#19A2DE:#319A31:#EF9608:#8CBE29:#A500FF:#00AAAD:#FF0094:#9C5100:#E671B5'';',
'        else',
'            null;',
'    end case;    ',
'',
'    -- Build the initial chart. Data will be loaded with ajax.',
'    apex_javascript.add_onload_code (',
'        p_code => ''com_oracle_apex_d3_linechart('' ||',
'            apex_javascript.add_value(p_region.static_id) ||',
'            ''{'' ||',
'                apex_javascript.add_attribute(''chartRegionId'',  p_region.static_id || ''_chart'') ||',
'                apex_javascript.add_attribute(''xAxisTitle'',     c_x_axis_title) || ',
'                apex_javascript.add_attribute(''yAxisTitle'',     c_y_axis_title) || ',
'                apex_javascript.add_attribute(''showTooltip'',    c_show_tooltip) || ',
'                apex_javascript.add_attribute(''tooltipSeries'',  c_series_tooltip) || ',
'                apex_javascript.add_attribute(''tooltipX'',       c_x_tooltip) || ',
'                apex_javascript.add_attribute(''tooltipY'',       c_y_tooltip) || ',
'                apex_javascript.add_attribute(''tooltipCustom'',  c_custom_tooltip) ||',
'                apex_javascript.add_attribute(''responsive'',     c_responsive) || ',
'                apex_javascript.add_attribute(''transitions'',    c_transitions) || ',
'                apex_javascript.add_attribute(''xDataType'',      c_x_data_type) || ',
'                apex_javascript.add_attribute(''display'',        c_display) || ',
'                apex_javascript.add_attribute(''xValueTemplate'', c_x_value_template) || ',
'                apex_javascript.add_attribute(''yValueTemplate'', c_y_value_template) || ',
'                apex_javascript.add_attribute(''xTickInterval'',  c_x_tick_interval) || ',
'                apex_javascript.add_attribute(''showLegend'',     c_show_legend) || ',
'                apex_javascript.add_attribute(''legendPosition'', c_legend_position) || ',
'                apex_javascript.add_attribute(''colors'',         l_colors) || ',
'                apex_javascript.add_attribute(''xGrid'',          c_x_axis_grid) || ',
'                apex_javascript.add_attribute(''yGrid'',          c_y_axis_grid) || ',
'                apex_javascript.add_attribute(''interpolation'',  c_line_interpolation) ||',
'                apex_javascript.add_attribute(''heightMode'',     c_height_mode) ||',
'                apex_javascript.add_attribute(''minHeight'',      c_min_height) || ',
'                apex_javascript.add_attribute(''maxHeight'',      c_max_height) || ',
'                apex_javascript.add_attribute(''threshold'',      c_threshold) || ',
'                apex_javascript.add_attribute(''thresholdOf'',    c_threshold_of) || ',
'                apex_javascript.add_attribute(''minAR'',          c_min_ar) ||',
'                apex_javascript.add_attribute(''maxAR'',          c_max_ar) ||',
'                apex_javascript.add_attribute(''noDataFoundMessage'', p_region.no_data_found_message) || ',
'                apex_javascript.add_attribute(''pageItems'',      apex_plugin_util.page_item_names_to_jquery(p_region.ajax_items_to_submit)) ||',
'                apex_javascript.add_attribute(''ajaxIdentifier'', apex_plugin.get_ajax_identifier, false, false) ||',
'            ''});'' );',
'    return null;',
'end;',
'',
'function ajax',
'(',
'    p_region    in  apex_plugin.t_region,',
'    p_plugin    in  apex_plugin.t_plugin ',
')',
'return apex_plugin.t_region_ajax_result',
'is',
'    -- It''s better to have named variables instead of using the generic ones, ',
'    -- makes the code more readable. ',
'',
'    -- Column names',
'    c_x_column              constant varchar2(255) := p_region.attribute_01;',
'    c_y_column              constant varchar2(255) := p_region.attribute_02;',
'    c_series_column         constant varchar2(255) := p_region.attribute_23;',
'    c_tooltip_column        constant varchar2(255) := p_region.attribute_15;',
'    c_link_template         constant varchar2(255) := p_region.attribute_19;',
'',
'    -- X Column data type',
'    c_x_data_type           constant varchar2(200)  := p_region.attribute_05;',
'',
'    -- Series name, for single series configuration',
'    c_series_name           constant varchar2(200) := p_region.attribute_24;',
'    c_use_sql_color         constant boolean       := p_region.attribute_13 = ''COLUMN'';',
'',
'    -- Column numbers for fetching',
'    l_x_column_no           pls_integer;',
'    l_y_column_no           pls_integer;',
'    l_series_column_no      pls_integer;',
'    l_tooltip_column_no     pls_integer;',
'    l_column_value_list     apex_plugin_util.t_column_value_list2;',
'',
'    -- Holders for row data',
'    l_x                     number;',
'    l_x_date                varchar2(200);',
'    l_y                     number;',
'    l_series                varchar2(4000);',
'    l_color                 varchar2(4000);',
'    l_tooltip               varchar2(4000);',
'    l_link                  varchar2(4000);',
'',
'begin',
'',
'    apex_json.initialize_output (',
'        p_http_cache => false );',
'',
'    apex_json.open_object;',
'',
'    -- First, we must get the color mapping if the color scheme requires it.',
'    if c_use_sql_color then',
'        l_column_value_list := apex_plugin_util.get_data2 (',
'            p_sql_statement     => p_region.attribute_23,',
'            p_min_columns       => 2,',
'            p_max_columns       => 2,',
'            p_component_name    => p_region.name );',
'',
'        apex_json.open_array(''colors'');',
'        for l_row_num in 1 .. l_column_value_list(1).value_list.count loop',
'            -- Series, optional',
'            l_series := apex_plugin_util.get_value_as_varchar2 (',
'                p_data_type => l_column_value_list(1).data_type,',
'                p_value     => l_column_value_list(1).value_list(l_row_num) );',
'            l_color := apex_plugin_util.get_value_as_varchar2 (',
'                p_data_type => l_column_value_list(2).data_type,',
'                p_value     => l_column_value_list(2).value_list(l_row_num) );',
'            ',
'            apex_json.open_object;',
'            apex_json.write(''series'', l_series);',
'            apex_json.write(''color'', l_color);',
'            apex_json.close_object();',
'',
'        end loop;',
'        apex_json.close_array;',
'',
'        l_series := null;',
'    end if;',
'',
'    -- Then, we get the actual data points.',
'    l_column_value_list := apex_plugin_util.get_data2 (',
'        p_sql_statement     => p_region.source,',
'        p_min_columns       => 2,',
'        p_max_columns       => 5,',
'        p_component_name    => p_region.name );',
'',
'    -- Get the actual column # for faster access and also verify that the data type',
'    -- of the column matches with what we are looking for',
'    IF c_x_data_type = ''NUMBER'' THEN',
'        l_x_column_no := apex_plugin_util.get_column_no (',
'            p_attribute_label       => ''x column'',',
'            p_column_alias          => c_x_column,',
'            p_column_value_list     => l_column_value_list,',
'            p_is_required           => true,',
'            p_data_type             => apex_plugin_util.c_data_type_varchar2 );',
'    ELSIF c_x_data_type = ''TIMESTAMP'' THEN',
'        l_x_column_no := apex_plugin_util.get_column_no (',
'            p_attribute_label       => ''x column'',',
'            p_column_alias          => c_x_column,',
'            p_column_value_list     => l_column_value_list,',
'            p_is_required           => true,',
'            p_data_type             => apex_plugin_util.c_data_type_timestamp );',
'    ELSIF c_x_data_type = ''TIMESTAMP_TZ'' THEN',
'        l_x_column_no := apex_plugin_util.get_column_no (',
'            p_attribute_label       => ''x column'',',
'            p_column_alias          => c_x_column,',
'            p_column_value_list     => l_column_value_list,',
'            p_is_required           => true,',
'            p_data_type             => apex_plugin_util.c_data_type_timestamp_tz );',
'    ELSIF c_x_data_type = ''TIMESTAMP_LTZ'' THEN',
'        l_x_column_no := apex_plugin_util.get_column_no (',
'            p_attribute_label       => ''x column'',',
'            p_column_alias          => c_x_column,',
'            p_column_value_list     => l_column_value_list,',
'            p_is_required           => true,',
'            p_data_type             => apex_plugin_util.c_data_type_timestamp_ltz );',
'    ELSE',
'        l_x_column_no := apex_plugin_util.get_column_no (',
'            p_attribute_label       => ''x column'',',
'            p_column_alias          => c_x_column,',
'            p_column_value_list     => l_column_value_list,',
'            p_is_required           => true,',
'            p_data_type             => apex_plugin_util.c_data_type_date );',
'    END IF;',
'',
'    l_y_column_no := apex_plugin_util.get_column_no (',
'        p_attribute_label       => ''y column'',',
'        p_column_alias          => c_y_column,',
'        p_column_value_list     => l_column_value_list,',
'        p_is_required           => true,',
'        p_data_type             => apex_plugin_util.c_data_type_number );',
'',
'    l_series_column_no := apex_plugin_util.get_column_no (',
'        p_attribute_label       => ''series column'',',
'        p_column_alias          => c_series_column,',
'        p_column_value_list     => l_column_value_list,',
'        p_is_required           => false,',
'        p_data_type             => apex_plugin_util.c_data_type_varchar2 );',
'',
'    l_tooltip_column_no := apex_plugin_util.get_column_no (',
'        p_attribute_label       => ''tooltip column'',',
'        p_column_alias          => c_tooltip_column,',
'        p_column_value_list     => l_column_value_list,',
'        p_is_required           => false,',
'        p_data_type             => apex_plugin_util.c_data_type_varchar2 );',
'',
'    --sys.htp.prn(''"data":['');',
'    apex_json.open_array(''data'');',
'',
'    -- Fetch data',
'    for l_row_num in 1 .. l_column_value_list(1).value_list.count loop',
'        begin',
'            apex_plugin_util.set_component_values (',
'                p_column_value_list => l_column_value_list,',
'                p_row_num => l_row_num ',
'            );',
'',
'            -- X is a string, number or date required',
'            if l_x_column_no is not null then',
'                ',
'                IF c_x_data_type = ''NUMBER'' THEN',
'                    l_x := l_column_value_list(l_x_column_no).value_list(l_row_num).number_value;',
'                ELSIF c_x_data_type = ''TIMESTAMP'' THEN',
'                    l_x_date := to_char(l_column_value_list(l_x_column_no).value_list(l_row_num).timestamp_value, ''DY MON DD YYYY HH24:MI:SS TZH:TZM''); ',
'                ELSIF c_x_data_type = ''TIMESTAMP_TZ'' THEN',
'                    l_x_date := to_char(l_column_value_list(l_x_column_no).value_list(l_row_num).timestamp_tz_value, ''DY MON DD YYYY HH24:MI:SS TZH:TZM'');',
'                ELSIF c_x_data_type = ''TIMESTAMP_LTZ'' THEN',
'                    l_x_date := to_char(l_column_value_list(l_x_column_no).value_list(l_row_num).timestamp_ltz_value, ''DY MON DD YYYY HH24:MI:SS'');',
'                ELSE',
'                    l_x_date := to_char(l_column_value_list(l_x_column_no).value_list(l_row_num).date_value, ''DY MON DD YYYY HH24:MI:SS'');',
'                END IF;',
'',
'',
'            end if;',
'',
'            -- Y is a number, required',
'            l_y := l_column_value_list(l_y_column_no).value_list(l_row_num).number_value;',
'',
'            -- Series, optional',
'            if l_series_column_no is not null then',
'                l_series := apex_plugin_util.get_value_as_varchar2 (',
'                    p_data_type => l_column_value_list(l_series_column_no).data_type,',
'                    p_value     => l_column_value_list(l_series_column_no).value_list(l_row_num) );',
'            end if;',
'',
'            -- Tooltip, optional',
'            if l_tooltip_column_no is not null then',
'                l_tooltip := apex_plugin_util.get_value_as_varchar2 (',
'                    p_data_type => l_column_value_list(l_tooltip_column_no).data_type,',
'                    p_value     => l_column_value_list(l_tooltip_column_no).value_list(l_row_num) );',
'            end if;',
'',
'            -- Link, optional',
'            if c_link_template is not null then',
'                l_link := apex_util.prepare_url (',
'                    apex_plugin_util.replace_substitutions (',
'                        p_value  => c_link_template,',
'                        p_escape => false ) );',
'            end if;',
'',
'            apex_json.open_object;',
'            apex_json.write(''series'', nvl(l_series, c_series_name));',
'            apex_json.write(''tooltip'', l_tooltip);',
'            apex_json.write(''link'', l_link);',
'             IF c_x_data_type = ''NUMBER'' THEN',
'                apex_json.write(''x'', l_x);',
'            ELSE',
'                apex_json.write(''x'', l_x_date);',
'            END IF;',
'            apex_json.write(''y'', l_y);',
'            apex_json.close_object;',
'',
'            apex_plugin_util.clear_component_values;',
'',
'        exception when others then',
'            apex_plugin_util.clear_component_values;',
'            raise;',
'        end;',
'    end loop;',
'    apex_json.close_array;',
'    apex_json.close_object;',
'',
'    return null;',
'end;'))
,p_api_version=>1
,p_render_function=>'render'
,p_ajax_function=>'ajax'
,p_standard_attributes=>'SOURCE_SQL:AJAX_ITEMS_TO_SUBMIT:NO_DATA_FOUND_MESSAGE'
,p_substitute_attributes=>false
,p_subscribe_plugin_settings=>true
,p_help_text=>'Data Driven Documents (D3) Line Chart provides dynamic and interactive bar charts for data visualization, using Scalable Vector Graphics (SVG), JavaScript, HTML5, and Cascading Style Sheets (CSS3) standards.'
,p_version_identifier=>'5.0.1'
,p_about_url=>'http://apex.oracle.com/plugins'
,p_files_version=>66
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522308550773920510)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'APPLICATION'
,p_attribute_sequence=>1
,p_display_sequence=>520
,p_prompt=>'Maximum Aspect Ratio'
,p_attribute_type=>'NUMBER'
,p_is_required=>true
,p_is_common=>false
,p_show_in_wizard=>false
,p_default_value=>'3'
,p_display_length=>5
,p_is_translatable=>false
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Enter the maximum aspect ratio that charts use to recommend a height. A maximum aspect ratio of 3 means that the chart''s width should be no greater than 3 times its height. </p>',
'<p>Note: This setting can be overridden by the ''Maximum Height'' setting on the region.</p>'))
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522308948415920510)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'APPLICATION'
,p_attribute_sequence=>2
,p_display_sequence=>510
,p_prompt=>'Minimum Aspect Ratio'
,p_attribute_type=>'NUMBER'
,p_is_required=>true
,p_is_common=>false
,p_show_in_wizard=>false
,p_default_value=>'1.333'
,p_display_length=>5
,p_is_translatable=>false
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Enter the minimum aspect ratio that charts use to recommend a height. A minimum aspect ratio of 1.333 means that the chart''s width should be no less than 1.333 times its height. </p>',
'<p>Note: This setting can be overridden by the ''Minimum Height'' setting on the region.</p>'))
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522309342136920510)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'APPLICATION'
,p_attribute_sequence=>3
,p_display_sequence=>550
,p_prompt=>'Responsive Behavior Threshold'
,p_attribute_type=>'INTEGER'
,p_is_required=>true
,p_is_common=>false
,p_show_in_wizard=>false
,p_default_value=>'480'
,p_display_length=>5
,p_max_length=>5
,p_unit=>'px'
,p_is_translatable=>false
,p_help_text=>'Enter the threshold (in pixels) at which the responsive behavior will be activated.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522309713359920510)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'APPLICATION'
,p_attribute_sequence=>4
,p_display_sequence=>540
,p_prompt=>'Responsive Behavior Measure'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_is_common=>false
,p_show_in_wizard=>false
,p_default_value=>'WINDOW'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_help_text=>'Select whether the responsive behavior threshold will be compared to the window or the region width.'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522310124907920511)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522309713359920510)
,p_display_sequence=>10
,p_display_value=>'Window'
,p_return_value=>'WINDOW'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522310664081920511)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522309713359920510)
,p_display_sequence=>20
,p_display_value=>'Region'
,p_return_value=>'REGION'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522311067992920512)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'APPLICATION'
,p_attribute_sequence=>5
,p_display_sequence=>530
,p_prompt=>'Responsive Behavior'
,p_attribute_type=>'CHECKBOX'
,p_is_required=>false
,p_default_value=>'Y'
,p_is_translatable=>false
,p_help_text=>'Select whether responsive behavior is enabled for the chart.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522311543305920512)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'APPLICATION'
,p_attribute_sequence=>6
,p_display_sequence=>560
,p_prompt=>'Enable Transitions'
,p_attribute_type=>'CHECKBOX'
,p_is_required=>false
,p_is_common=>false
,p_show_in_wizard=>false
,p_default_value=>'Y'
,p_is_translatable=>false
,p_help_text=>'Select whether transitions are enabled for the chart.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522311910200920512)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_prompt=>'X Values Column'
,p_attribute_type=>'REGION SOURCE COLUMN'
,p_is_required=>true
,p_column_data_types=>'NUMBER:DATE:TIMESTAMP'
,p_is_translatable=>false
,p_help_text=>'Select the column from the region SQL Query that holds the X-axis values for the chart.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522312279681920513)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_prompt=>'Y Values Column'
,p_attribute_type=>'REGION SOURCE COLUMN'
,p_is_required=>true
,p_column_data_types=>'NUMBER'
,p_is_translatable=>false
,p_help_text=>'Select the column from the region SQL Query that holds the Y-axis values for the chart.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522312718721920513)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>70
,p_prompt=>'X-Axis Title'
,p_attribute_type=>'TEXT'
,p_is_required=>false
,p_display_length=>20
,p_is_translatable=>true
,p_help_text=>'Enter the label for the X-axis.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522313091393920513)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>80
,p_prompt=>'Y-Axis Title'
,p_attribute_type=>'TEXT'
,p_is_required=>false
,p_display_length=>20
,p_is_translatable=>true
,p_help_text=>'Enter the label for the Y-axis.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522313532070920513)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>5
,p_display_sequence=>90
,p_prompt=>'X-Axis Data Type'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'NUMBER'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_help_text=>'Select the data type for the X-axis.'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522313893584920514)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522313532070920513)
,p_display_sequence=>10
,p_display_value=>'Number'
,p_return_value=>'NUMBER'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522314374101920514)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522313532070920513)
,p_display_sequence=>20
,p_display_value=>'Date'
,p_return_value=>'DATE'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522314915432920514)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522313532070920513)
,p_display_sequence=>30
,p_display_value=>'Timestamp'
,p_return_value=>'TIMESTAMP'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522315455183920515)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522313532070920513)
,p_display_sequence=>40
,p_display_value=>'Timestamp with Time Zone'
,p_return_value=>'TIMESTAMP_TZ'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522315901080920515)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522313532070920513)
,p_display_sequence=>50
,p_display_value=>'Timestamp with Local Time Zone'
,p_return_value=>'TIMESTAMP_LTZ'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522316450493920515)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>6
,p_display_sequence=>110
,p_prompt=>'X-Axis Value Format Mask'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>false
,p_is_common=>false
,p_show_in_wizard=>false
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_null_text=>'Custom'
,p_help_text=>'Select the data format mask for the X-axis.'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522316852578920516)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>30
,p_display_value=>'14,435'
,p_return_value=>',.0f'
,p_help_text=>'Comma-separated thousands, integers'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522317318438920516)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>40
,p_display_value=>'14435'
,p_return_value=>'.0f'
,p_help_text=>'Integer'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522317830814920516)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>60
,p_display_value=>'14,435.49'
,p_return_value=>',.2f'
,p_help_text=>'Comma-separated thousands, 2 decimals'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522318355309920517)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>70
,p_display_value=>'14435.49'
,p_return_value=>'.2f'
,p_help_text=>'2 decimals'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522318842033920517)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>71
,p_display_value=>'14.4k'
,p_return_value=>'.3s'
,p_help_text=>'Precision 3, SI suffixes'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522319345820920517)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>80
,p_display_value=>'$14,435'
,p_return_value=>'$,.0f'
,p_help_text=>'Currency, comma-separated thousands, integer'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522319807504920517)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>90
,p_display_value=>'$14435'
,p_return_value=>'$.0f'
,p_help_text=>'Currency, integer'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522320326128920518)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>99
,p_display_value=>'$14,435.49'
,p_return_value=>'$,.2f'
,p_help_text=>'Currency, comma-separated thousands, 2 decimals'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522320814236920518)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>100
,p_display_value=>'$14435.49'
,p_return_value=>'$.2f'
,p_help_text=>'Currency, 2 decimals'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522321328864920518)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>120
,p_display_value=>'$14.4k'
,p_return_value=>'$.3s'
,p_help_text=>'Currency, precison 3, SI suffixes'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522321822114920519)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>130
,p_display_value=>'23:45:12'
,p_return_value=>'%X'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522322302722920519)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>140
,p_display_value=>'12/24/2000'
,p_return_value=>'%x'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522322835354920519)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>150
,p_display_value=>'Mon Jan 5 23:45:12 2000'
,p_return_value=>'%c'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522323351035920520)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>160
,p_display_value=>'12 Jan 2000'
,p_return_value=>'%e %b %Y'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522323773876920520)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>170
,p_display_value=>'Day'
,p_return_value=>'%A'
,p_help_text=>'Full weekday name'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522324302120920520)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>180
,p_display_value=>'Month'
,p_return_value=>'%B'
,p_help_text=>'Full month name'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522324853905920521)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_display_sequence=>190
,p_display_value=>'Year'
,p_return_value=>'%Y'
,p_help_text=>'Full year'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522325357287920521)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>7
,p_display_sequence=>120
,p_prompt=>'X-Axis Custom Value Format Mask'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_is_common=>false
,p_show_in_wizard=>false
,p_default_value=>'FRIENDLY'
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(35522316450493920515)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'NULL'
,p_examples=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ul>',
'<li><b>,d</b> = 14,435</li>',
'<li><b>d</b> = 14435</li>',
'<li><b>,.2f</b> = 14,435.49</li>',
'<li><b>.2f</b> = 14435.49</li>',
'<li><b>.3s</b> = 14.4k</li>',
'<li><b>$,d</b> = $14,435</li>',
'<li><b>$d</b> = $14435</li>',
'<li><b>$,.2f</b> = $14,435.49</li>',
'<li><b>$.2f</b> = $14435.49</li>',
'<li><b>$.3s</b> = $14.4k</li>',
'<li><b>n" ft."</b> = 14435.49 ft. **</li>',
'<li><b>"[["$.3s"]]"</b> = [[$14.4k]] **</li>',
'<li>Refer to https://github.com/mbostock/d3/wiki/Formatting#d3_format for the full syntax specification</li>',
'</ul>',
'<br/>',
'** You may use leading and trailing double-quoted literals, but this feature is not part of the standard D3 specification'))
,p_help_text=>'Enter the D3 format string used to format the X-axis values on axes, tooltips and legends. Use <pre>FRIENDLY</pre> to utilize sensible formatting defaults for your data.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522325743681920521)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>8
,p_display_sequence=>220
,p_prompt=>'Line Interpolation'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'linear'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_help_text=>'Select how the curvature of the line is fitted for the chart.'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522326077496920521)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522325743681920521)
,p_display_sequence=>10
,p_display_value=>'Linear'
,p_return_value=>'linear'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522326590538920522)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522325743681920521)
,p_display_sequence=>20
,p_display_value=>'Step Before'
,p_return_value=>'step-before'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522327091274920522)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522325743681920521)
,p_display_sequence=>30
,p_display_value=>'Step After'
,p_return_value=>'step-after'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522327637484920522)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522325743681920521)
,p_display_sequence=>40
,p_display_value=>'Cardinal'
,p_return_value=>'cardinal'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522328160341920523)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522325743681920521)
,p_display_sequence=>50
,p_display_value=>'Monotone'
,p_return_value=>'monotone'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522328646039920523)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>9
,p_display_sequence=>230
,p_prompt=>'Height Measure'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'LINES'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_help_text=>'Select how the minimum and maximum height of the chart is calculated.'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522329000974920523)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522328646039920523)
,p_display_sequence=>10
,p_display_value=>'Chart Lines Only'
,p_return_value=>'LINES'
,p_help_text=>'Applied to the height of the chart lines only.'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522329533546920524)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522328646039920523)
,p_display_sequence=>20
,p_display_value=>'Include Labels'
,p_return_value=>'CHART'
,p_help_text=>'Applies to the total chart including the labels.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522330064413920524)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>10
,p_display_sequence=>130
,p_prompt=>'Y-Axis Value Format Mask'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>false
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_null_text=>'Custom'
,p_help_text=>'Select the data format mask for the Y-axis.'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522330448591920524)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522330064413920524)
,p_display_sequence=>10
,p_display_value=>'14,435'
,p_return_value=>',.0f'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522330930605920525)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522330064413920524)
,p_display_sequence=>20
,p_display_value=>'14435'
,p_return_value=>'.0f'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522331409471920525)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522330064413920524)
,p_display_sequence=>30
,p_display_value=>'14,435.49'
,p_return_value=>',.2f'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522331880975920525)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522330064413920524)
,p_display_sequence=>40
,p_display_value=>'14435.49'
,p_return_value=>'.2f'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522332403888920526)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522330064413920524)
,p_display_sequence=>50
,p_display_value=>'14.4k'
,p_return_value=>'.3s'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522332875327920526)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522330064413920524)
,p_display_sequence=>60
,p_display_value=>'$14,435'
,p_return_value=>'$,.0f'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522333431398920526)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522330064413920524)
,p_display_sequence=>70
,p_display_value=>'$14435'
,p_return_value=>'$.0f'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522333961960920527)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522330064413920524)
,p_display_sequence=>80
,p_display_value=>'$14,435.49'
,p_return_value=>'$,.2f'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522334452496920527)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522330064413920524)
,p_display_sequence=>90
,p_display_value=>'$14435.49'
,p_return_value=>'$.2f'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522334923677920527)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522330064413920524)
,p_display_sequence=>100
,p_display_value=>'$14.4k'
,p_return_value=>'$.3s'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522335449471920528)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>11
,p_display_sequence=>140
,p_prompt=>'Y-Axis Custom Value Format Mask'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_default_value=>'FRIENDLY'
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(35522330064413920524)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'NULL'
,p_examples=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ul>',
'<li><b>,d</b> = 14,435</li>',
'<li><b>d</b> = 14435</li>',
'<li><b>,.2f</b> = 14,435.49</li>',
'<li><b>.2f</b> = 14435.49</li>',
'<li><b>.3s</b> = 14.4k</li>',
'<li><b>$,d</b> = $14,435</li>',
'<li><b>$d</b> = $14435</li>',
'<li><b>$,.2f</b> = $14,435.49</li>',
'<li><b>$.2f</b> = $14435.49</li>',
'<li><b>$.3s</b> = $14.4k</li>',
'<li><b>n" ft."</b> = 14435.49 ft. **</li>',
'<li><b>"[["$.3s"]]"</b> = [[$14.4k]] **</li>',
'<li>Refer to https://github.com/mbostock/d3/wiki/Formatting#d3_format for the full syntax specification</li>',
'</ul>',
'<br/>',
'** You may use leading and trailing double-quoted literals, but this feature is not part of the standard D3 specification'))
,p_help_text=>'Enter the D3 format string used to format the Y-axis values on axes, tooltips and legends. Use <pre>FRIENDLY</pre> to utilize sensible formatting defaults for your data.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522335781587920528)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>12
,p_display_sequence=>100
,p_prompt=>'X-Axis Tick Interval'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>false
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(35522313532070920513)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'IN_LIST'
,p_depending_on_expression=>'DATE,TIMESTAMP,TIMESTAMP_TZ,TIMESTAMP_LTZ'
,p_lov_type=>'STATIC'
,p_null_text=>'Auto'
,p_help_text=>'Select the timeframe displayed on the X-axis for date type columns.'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522341728206920532)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522335781587920528)
,p_display_sequence=>10
,p_display_value=>'Second'
,p_return_value=>'SECOND'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522342251779920532)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522335781587920528)
,p_display_sequence=>20
,p_display_value=>'Minute'
,p_return_value=>'MINUTE'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522342729729920532)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522335781587920528)
,p_display_sequence=>30
,p_display_value=>'Hour'
,p_return_value=>'HOUR'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522336189632920528)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522335781587920528)
,p_display_sequence=>40
,p_display_value=>'Day'
,p_return_value=>'DAY'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522336733128920528)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522335781587920528)
,p_display_sequence=>50
,p_display_value=>'Week'
,p_return_value=>'WEEK'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522337223739920529)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522335781587920528)
,p_display_sequence=>60
,p_display_value=>'Sunday'
,p_return_value=>'SUNDAY'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522337697002920529)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522335781587920528)
,p_display_sequence=>70
,p_display_value=>'Monday'
,p_return_value=>'MONDAY'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522338180172920529)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522335781587920528)
,p_display_sequence=>80
,p_display_value=>'Tuesday'
,p_return_value=>'TUESDAY'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522338741324920530)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522335781587920528)
,p_display_sequence=>90
,p_display_value=>'Wednesday'
,p_return_value=>'WEDNESDAY'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522339216979920530)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522335781587920528)
,p_display_sequence=>100
,p_display_value=>'Thursday'
,p_return_value=>'THURSDAY'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522339731016920530)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522335781587920528)
,p_display_sequence=>110
,p_display_value=>'Friday'
,p_return_value=>'FRIDAY'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522340219756920531)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522335781587920528)
,p_display_sequence=>120
,p_display_value=>'Saturday'
,p_return_value=>'SATURDAY'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522340712055920531)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522335781587920528)
,p_display_sequence=>130
,p_display_value=>'Month'
,p_return_value=>'MONTH'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522341236277920531)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522335781587920528)
,p_display_sequence=>140
,p_display_value=>'Year'
,p_return_value=>'YEAR'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522343176489920533)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>13
,p_display_sequence=>190
,p_prompt=>'Color Scheme'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>false
,p_is_common=>false
,p_show_in_wizard=>false
,p_default_value=>'MODERN'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_null_text=>'Theme Default'
,p_help_text=>'<p>Select the color scheme used to render the chart.</p>'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522343595889920533)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522343176489920533)
,p_display_sequence=>10
,p_display_value=>'Modern'
,p_return_value=>'MODERN'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522344070595920533)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522343176489920533)
,p_display_sequence=>20
,p_display_value=>'Modern 2'
,p_return_value=>'MODERN2'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522344590974920534)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522343176489920533)
,p_display_sequence=>30
,p_display_value=>'Solar'
,p_return_value=>'SOLAR'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522345094490920534)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522343176489920533)
,p_display_sequence=>40
,p_display_value=>'Metro'
,p_return_value=>'METRO'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522345625233920534)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522343176489920533)
,p_display_sequence=>50
,p_display_value=>'SQL Query'
,p_return_value=>'COLUMN'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522346093659920535)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522343176489920533)
,p_display_sequence=>60
,p_display_value=>'Custom'
,p_return_value=>'CUSTOM'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522346663277920535)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>14
,p_display_sequence=>200
,p_prompt=>'Colors'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_is_common=>false
,p_show_in_wizard=>false
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(35522343176489920533)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'CUSTOM'
,p_examples=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<dl>',
'  <dt>Hexadecimal (hex) notation</dt><dd><pre>#FF3377</pre>;</dd>',
'  <dt>RGB color notation  (red,green,blue)</dt><dd><pre>rgba(0,25,47,0.5)</pre>; or </dd>',
'  <dt>RGBA color notation (red,green,blue,alpha)</dt><dd><pre>rgba(0,25,47,0.5)</pre>; or </dd>',
'  <dt>HTML colors</dt><dd><pre>blue</pre>.</dd>',
'</dl>'))
,p_help_text=>'<p>Enter a colon-separated list of color strings for the custom colors to be used in the chart.</p>'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522347016489920535)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>15
,p_display_sequence=>160
,p_prompt=>'Tooltip Column'
,p_attribute_type=>'REGION SOURCE COLUMN'
,p_is_required=>true
,p_is_common=>false
,p_show_in_wizard=>false
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(35522347370486920535)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'IN_LIST'
,p_depending_on_expression=>'SERIES:X:Y:CUSTOM,SERIES:X:CUSTOM,SERIES:Y:CUSTOM,X:Y:CUSTOM,SERIES:CUSTOM,X:CUSTOM,Y:CUSTOM,CUSTOM'
,p_help_text=>'Enter the column from the region SQL Query that holds the custom tooltip values.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522347370486920535)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>16
,p_display_sequence=>150
,p_prompt=>'Tooltips'
,p_attribute_type=>'CHECKBOXES'
,p_is_required=>false
,p_is_common=>false
,p_show_in_wizard=>false
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Check which attributes are shown on the tooltip for each data point. The ''Custom column'' option allows you to specify text for each individual data point as an additional column in the region SQL Query.</p>',
'<p>Note: Leave all options unchecked to disable the tooltip.</p>'))
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522347857550920536)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522347370486920535)
,p_display_sequence=>0
,p_display_value=>'Show series name'
,p_return_value=>'SERIES'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522348288004920536)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522347370486920535)
,p_display_sequence=>10
,p_display_value=>'Show X value'
,p_return_value=>'X'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522348779587920536)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522347370486920535)
,p_display_sequence=>20
,p_display_value=>'Show Y value'
,p_return_value=>'Y'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522349294599920537)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522347370486920535)
,p_display_sequence=>30
,p_display_value=>'Custom column'
,p_return_value=>'CUSTOM'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522349790727920537)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>17
,p_display_sequence=>240
,p_prompt=>'Minimum Height'
,p_attribute_type=>'INTEGER'
,p_is_required=>false
,p_is_common=>false
,p_show_in_wizard=>false
,p_display_length=>5
,p_unit=>'px'
,p_is_translatable=>false
,p_help_text=>'Enter the minimum height, in pixels, of the chart. Chart width will adapt to the size of the region.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522350169799920537)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>18
,p_display_sequence=>250
,p_prompt=>'Maximum Height'
,p_attribute_type=>'INTEGER'
,p_is_required=>false
,p_is_common=>false
,p_show_in_wizard=>false
,p_display_length=>5
,p_unit=>'px'
,p_is_translatable=>false
,p_help_text=>'The maximum height, in pixels, of the chart. Chart width will adapt to the size of the region.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522350600552920538)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>19
,p_display_sequence=>30
,p_prompt=>'Link Target'
,p_attribute_type=>'LINK'
,p_is_required=>false
,p_is_translatable=>false
,p_examples=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Example 1: URL to navigate to page 10 and set P10_EMPNO to the EMPNO value of the clicked entry.',
'<pre>f?p=&amp;APP_ID.:10:&amp;APP_SESSION.::&amp;DEBUG.:RP,10:P10_EMPNO:&amp;EMPNO.</pre>',
'</p>',
'<p>Example 2: Display the EMPNO value of the clicked entry in a JavaScript alert',
'<pre>javascript:alert(''current empno: &amp;EMPNO.'');</pre>',
'</p>'))
,p_help_text=>'<p>Enter a target page to be called when the user clicks a chart entry.</p>'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522351006427920538)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>20
,p_display_sequence=>40
,p_prompt=>'Display'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'OVERLAP'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_help_text=>'Select how the line chart data is displayed.'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522351379924920538)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522351006427920538)
,p_display_sequence=>10
,p_display_value=>'Overlap'
,p_return_value=>'OVERLAP'
,p_is_quick_pick=>true
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522351964007920539)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522351006427920538)
,p_display_sequence=>20
,p_display_value=>'Stacked'
,p_return_value=>'STACKED'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522352392736920539)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>21
,p_display_sequence=>180
,p_prompt=>'Show Grid Lines'
,p_attribute_type=>'CHECKBOXES'
,p_is_required=>false
,p_is_common=>false
,p_show_in_wizard=>false
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_help_text=>'Check the axes to display grid lines for that axis.'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522352818860920539)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522352392736920539)
,p_display_sequence=>10
,p_display_value=>'X-Axis'
,p_return_value=>'X'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522353290710920539)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522352392736920539)
,p_display_sequence=>20
,p_display_value=>'Y-Axis'
,p_return_value=>'Y'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522353863978920540)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>22
,p_display_sequence=>210
,p_prompt=>'Color SQL Query'
,p_attribute_type=>'SQL'
,p_is_required=>true
,p_is_common=>false
,p_show_in_wizard=>false
,p_sql_min_column_count=>2
,p_sql_max_column_count=>2
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(35522343176489920533)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'COLUMN'
,p_examples=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>select ''SALES'', rgb(0,255,0)',
'from dual',
'UNION',
'select ''RESEARCH'', rgba(0,25,47,0.5)',
'from dual;</pre>'))
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Enter a SQL Query that maps a series name to an RGB color. The first column must contain the series names (and those values must match the ones returned from the region SQL) and the second column must have the RGB or RGBA color notation for the serie'
||'s. ',
'Both columns must be VARCHAR2.'))
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522354173493920540)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>23
,p_display_sequence=>60
,p_prompt=>'Multiple Series Column'
,p_attribute_type=>'REGION SOURCE COLUMN'
,p_is_required=>false
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
,p_help_text=>'Select the column from the region SQL Query that defines the multiple series for the chart. The values from this column will become the labels for the series.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522354619889920540)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>24
,p_display_sequence=>50
,p_prompt=>'Single Series Name'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_is_translatable=>true
,p_depending_on_attribute_id=>wwv_flow_imp.id(35522354173493920540)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'NULL'
,p_help_text=>'Enter the name of the single data series which is shown on the legend.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35522355024977920541)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>25
,p_display_sequence=>170
,p_prompt=>'Legend'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>false
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_null_text=>'No Legend'
,p_help_text=>'Select where the legend is displayed on the chart.'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522355409743920541)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522355024977920541)
,p_display_sequence=>10
,p_display_value=>'Above chart'
,p_return_value=>'TOP'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35522355965813920541)
,p_plugin_attribute_id=>wwv_flow_imp.id(35522355024977920541)
,p_display_sequence=>20
,p_display_value=>'Below chart'
,p_return_value=>'BOTTOM'
);
wwv_flow_imp_shared.create_plugin_std_attribute(
 p_id=>wwv_flow_imp.id(22471443851558934933)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_name=>'SOURCE_SQL'
,p_sql_min_column_count=>2
,p_sql_max_column_count=>5
);
wwv_flow_imp_shared.create_plugin_event(
 p_id=>wwv_flow_imp.id(40431728039796579639)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_name=>'elapsedtimefetched'
,p_display_name=>'Elapsed Time Fetched'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2F2A0D0A202A204433204C696E6520436861727420506C75672D696E2076312E30202D20687474703A2F2F617065782E6F7261636C652E636F6D2F706C7567696E730D0A202A0D0A202A204261736564206F6E20443320687474703A2F2F7777772E6433';
wwv_flow_imp.g_varchar2_table(2) := '6A732E6F72672F0D0A202A0D0A202A2F0D0A2866756E6374696F6E28207574696C2C207365727665722C20242C2064332029207B0D0A0D0A20202020766172204C4547454E445F434F4C554D4E5F5749445448203D203230302C0D0A2020202043495243';
wwv_flow_imp.g_varchar2_table(3) := '4C455F455850414E53494F4E5F464143544F52203D20322C0D0A20202020504F494E545F5452414E534954494F4E5F4455524154494F4E203D203230302C0D0A2020202043484152545F4C494E455F434C415353203D2027612D44334C696E6543686172';
wwv_flow_imp.g_varchar2_table(4) := '742D6C696E65272C0D0A2020202043484152545F415245415F434C415353203D2027612D44334C696E6543686172742D61726561272C0D0A2020202043484152545F504F494E545F434F4E5441494E45525F434C415353203D2027612D44334C696E6543';
wwv_flow_imp.g_varchar2_table(5) := '686172742D706F696E74436F6E7461696E6572272C0D0A2020202049455F55505F544F5F3130203D202F4D534945205C642F2E74657374286E6176696761746F722E757365724167656E74292C0D0A2020202049455F31315F414E445F5550203D202F54';
wwv_flow_imp.g_varchar2_table(6) := '726964656E745C2F283F3A5B372D395D7C5C647B322C7D295C2E2E2A72763A285C642B292F2E65786563286E6176696761746F722E757365724167656E74293B0D0A202020200D0A202020207661722049535F4945203D2049455F55505F544F5F313020';
wwv_flow_imp.g_varchar2_table(7) := '7C7C2049455F31315F414E445F55503B0D0A0D0A202020202F2A2A0D0A20202020202A20496E697469616C697A6174696F6E2066756E6374696F6E0D0A20202020202A2040706172616D207B537472696E677D2070526567696F6E49640D0A2020202020';
wwv_flow_imp.g_varchar2_table(8) := '2A2040706172616D207B4F626A6563747D20704F7074696F6E730D0A20202020202A0D0A20202020202A2F0D0A20202020636F6D5F6F7261636C655F617065785F64335F6C696E656368617274203D2066756E6374696F6E282070526567696F6E49642C';
wwv_flow_imp.g_varchar2_table(9) := '20704F7074696F6E732029207B0D0A0D0A20202020202020202F2F2767272070726566697820746F2073686F7720746861742074686973207661726961626C657320636F72726573706F6E6420746F206120676C6F62616C20636F6E7465787420696E73';
wwv_flow_imp.g_varchar2_table(10) := '6964652074686520706C7567696E0D0A20202020202020207661722067526567696F6E242C0D0A202020202020202020202020674368617274242C0D0A20202020202020202020202067546F6F6C746970242C0D0A202020202020202020202020674C65';
wwv_flow_imp.g_varchar2_table(11) := '67656E64242C0D0A202020202020202020202020674F7074696F6E732C0D0A202020202020202020202020674C696E6543686172742C0D0A20202020202020202020202067446174612C0D0A20202020202020202020202067436F6C6F724D617070696E';
wwv_flow_imp.g_varchar2_table(12) := '672C0D0A202020202020202020202020675856616C7565466F726D61747465722C0D0A202020202020202020202020675956616C7565466F726D61747465722C0D0A20202020202020202020202067486173486F6F6B65644576656E7473203D2066616C';
wwv_flow_imp.g_varchar2_table(13) := '73652C0D0A20202020202020202020202067466F6375736564506F696E742C0D0A20202020202020202020202067486F7665726564506F696E742C0D0A202020202020202020202020674172792C0D0A20202020202020202020202067436C6173735363';
wwv_flow_imp.g_varchar2_table(14) := '616C652C0D0A2020202020202020202020206749734B6579446F776E5472696767657265642C0D0A2020202020202020202020206743757272656E745365726965732C0D0A202020202020202020202020675365726965732C0D0A202020202020202020';
wwv_flow_imp.g_varchar2_table(15) := '2020206753657269657353656C656374696F6E2C0D0A202020202020202020202020674F626A656374496E6465782C0D0A202020202020202020202020675469636B496E74657276616C46756E6374696F6E2C0D0A20202020202020202020202067546F';
wwv_flow_imp.g_varchar2_table(16) := '6F6C746970436F6C6F722C0D0A20202020202020202020202067546F6F6C74697047656E657261746F723B0D0A0D0A20202020202020202F2A0D0A2020202020202020202A20476574732070726F7065722066756E6374696F6E20746F20666F726D6174';
wwv_flow_imp.g_varchar2_table(17) := '206E756D657269632076616C7565730D0A2020202020202020202A2040706172616D207B537472696E677D2076616C756554656D706C61746520436F6E7461696E732074686520737472696E672074686174206973206265696E67207573656420617320';
wwv_flow_imp.g_varchar2_table(18) := '726567756C61722065787072657373696F6E206F72207468652027667269656E646C7927206F7074696F6E0D0A2020202020202020202A204072657475726E207B46756E6374696F6E7D2046756E6374696F6E20746F20666F726D6174206E756D657269';
wwv_flow_imp.g_varchar2_table(19) := '632076616C75650D0A2020202020202020202A0D0A2020202020202020202A2F0D0A202020202020202066756E6374696F6E205F6E756D65726963466F726D6174282076616C756554656D706C61746520297B0D0A202020202020202020202020696620';
wwv_flow_imp.g_varchar2_table(20) := '282076616C756554656D706C61746520262620282076616C756554656D706C6174652E746F4C6F776572436173652829203D3D3D2027667269656E646C7927292029207B0D0A2020202020202020202020202020202072657475726E2064332E6F726163';
wwv_flow_imp.g_varchar2_table(21) := '6C652E666E6628293B0D0A2020202020202020202020207D20656C736520696620282076616C756554656D706C6174652026262076616C756554656D706C6174652E6C656E677468203E20302029207B0D0A202020202020202020202020202020207661';
wwv_flow_imp.g_varchar2_table(22) := '722066697865645265676578203D202F285E225B5E225D2A22292F3B0D0A2020202020202020202020202020202076617220666F726D6174507265666978203D2027273B0D0A2020202020202020202020202020202076617220666F726D617453756666';
wwv_flow_imp.g_varchar2_table(23) := '6978203D2027273B0D0A0D0A202020202020202020202020202020206966202820666978656452656765782E74657374282076616C756554656D706C61746520292029207B0D0A2020202020202020202020202020202020202020666F726D6174507265';
wwv_flow_imp.g_varchar2_table(24) := '666978203D20666978656452656765782E65786563282076616C756554656D706C61746520295B305D3B0D0A2020202020202020202020202020202020202020666F726D6174507265666978203D20666F726D61745072656669782E7375627374722820';
wwv_flow_imp.g_varchar2_table(25) := '312C20666F726D61745072656669782E6C656E677468202D203220293B0D0A202020202020202020202020202020202020202076616C756554656D706C617465203D2076616C756554656D706C6174652E7265706C616365282066697865645265676578';
wwv_flow_imp.g_varchar2_table(26) := '2C20272720293B0D0A202020202020202020202020202020207D0D0A2020202020202020202020202020202066697865645265676578203D202F28225B5E225D2A2224292F3B0D0A20202020202020202020202020202020696620282066697865645265';
wwv_flow_imp.g_varchar2_table(27) := '6765782E74657374282076616C756554656D706C61746520292029207B0D0A2020202020202020202020202020202020202020666F726D6174537566666978203D20666978656452656765782E65786563282076616C756554656D706C61746520295B30';
wwv_flow_imp.g_varchar2_table(28) := '5D3B0D0A2020202020202020202020202020202020202020666F726D6174537566666978203D20666F726D61745375666669782E7375627374722820312C20666F726D61745375666669782E6C656E677468202D203220293B0D0A202020202020202020';
wwv_flow_imp.g_varchar2_table(29) := '202020202020202020202076616C756554656D706C617465203D2076616C756554656D706C6174652E7265706C6163652820666978656452656765782C20272720293B0D0A202020202020202020202020202020207D0D0A202020202020202020202020';
wwv_flow_imp.g_varchar2_table(30) := '20202020766172206433666F726D617474696E67203D2064332E666F726D6174282076616C756554656D706C61746520293B0D0A2020202020202020202020202020202072657475726E2066756E6374696F6E2829207B0D0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(31) := '20202020202020202072657475726E20666F726D6174507265666978202B206433666F726D617474696E672E6170706C7928746869732C20617267756D656E747329202B20666F726D61745375666669783B0D0A20202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(32) := '7D3B0D0A2020202020202020202020207D20656C7365207B0D0A2020202020202020202020202020202072657475726E2066756E6374696F6E285F7829207B2072657475726E205F783B207D0D0A2020202020202020202020207D0D0A20202020202020';
wwv_flow_imp.g_varchar2_table(33) := '207D0D0A0D0A20202020202020202F2A0D0A2020202020202020202A20476574732070726F7065722066756E6374696F6E20746F20666F726D617420646174652076616C7565730D0A2020202020202020202A2040706172616D207B537472696E677D20';
wwv_flow_imp.g_varchar2_table(34) := '76616C756554656D706C61746520436F6E7461696E732074686520737472696E672074686174206973206265696E67207573656420617320726567756C61722065787072657373696F6E206F72207468652027667269656E646C7927206F7074696F6E0D';
wwv_flow_imp.g_varchar2_table(35) := '0A2020202020202020202A204072657475726E207B44332046756E6374696F6E7D2046756E6374696F6E20746F20666F726D617420646174652076616C75650D0A2020202020202020202A0D0A2020202020202020202A2F0D0A20202020202020206675';
wwv_flow_imp.g_varchar2_table(36) := '6E6374696F6E205F64617465466F726D6174282076616C756554656D706C61746520297B0D0A202020202020202020202020696620282076616C756554656D706C61746520262620282076616C756554656D706C6174652E746F4C6F7765724361736528';
wwv_flow_imp.g_varchar2_table(37) := '29203D3D3D2027667269656E646C7927292029207B0D0A202020202020202020202020202020206966202820675469636B496E74657276616C46756E6374696F6E203D3D3D2064332E74696D652E7365636F6E6420297B0D0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(38) := '20202020202020202072657475726E2064332E666F726D6174282725483A254D3A255327293B0D0A202020202020202020202020202020207D656C73652069662820675469636B496E74657276616C46756E6374696F6E203D3D3D2064332E74696D652E';
wwv_flow_imp.g_varchar2_table(39) := '6D696E75746520297B0D0A202020202020202020202020202020202020202072657475726E2064332E666F726D6174282725483A254D3A255327293B0D0A202020202020202020202020202020207D656C73652069662820675469636B496E7465727661';
wwv_flow_imp.g_varchar2_table(40) := '6C46756E6374696F6E203D3D3D2064332E74696D652E686F757220297B0D0A202020202020202020202020202020202020202072657475726E2064332E666F726D6174282725483A254D3A255327293B0D0A202020202020202020202020202020207D65';
wwv_flow_imp.g_varchar2_table(41) := '6C73652069662820675469636B496E74657276616C46756E6374696F6E203D3D3D2064332E74696D652E6D6F6E746820297B0D0A202020202020202020202020202020202020202072657475726E2064332E666F726D61742827256220255927293B0D0A';
wwv_flow_imp.g_varchar2_table(42) := '202020202020202020202020202020207D656C73652069662820675469636B496E74657276616C46756E6374696F6E203D3D3D2064332E74696D652E7965617220297B0D0A202020202020202020202020202020202020202072657475726E2064332E66';
wwv_flow_imp.g_varchar2_table(43) := '6F726D61742827255927293B0D0A202020202020202020202020202020207D656C7365207B0D0A20202020202020202020202020202020202020202F2F4461797320616E64207765656B7320696E74657276616C730D0A20202020202020202020202020';
wwv_flow_imp.g_varchar2_table(44) := '2020202020202072657475726E2064332E74696D652E666F726D61742827256220256420255927293B0D0A202020202020202020202020202020207D0D0A2020202020202020202020207D656C7365207B0D0A2020202020202020202020202020202072';
wwv_flow_imp.g_varchar2_table(45) := '657475726E2064332E74696D652E666F726D61742876616C756554656D706C617465293B0D0A2020202020202020202020207D0D0A20202020202020207D0D0A0D0A20202020202020202F2A0D0A2020202020202020202A20496E697469616C697A6573';
wwv_flow_imp.g_varchar2_table(46) := '20746F6F6C746970207769746820736F6D652061747472696275746573200D0A2020202020202020202A0D0A2020202020202020202A2F0D0A202020202020202066756E6374696F6E205F696E697469616C697A65546F6F6C74697028297B0D0A202020';
wwv_flow_imp.g_varchar2_table(47) := '20202020202020202067546F6F6C74697047656E657261746F72203D2064332E6F7261636C652E746F6F6C74697028290D0A20202020202020202020202020202020202020202E6163636573736F7273287B0D0A20202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(48) := '20202020202020206C6162656C203A2028704F7074696F6E732E746F6F6C74697058207C7C20704F7074696F6E732E746F6F6C74697053657269657329203F0D0A2020202020202020202020202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(49) := '2066756E6374696F6E2820642029207B0D0A202020202020202020202020202020202020202020202020202020202020202020202020202020206966202820704F7074696F6E732E746F6F6C746970582026262021704F7074696F6E732E746F6F6C7469';
wwv_flow_imp.g_varchar2_table(50) := '7053657269657329207B0D0A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202072657475726E20704F7074696F6E732E7844617461547970652E746F4C6F776572436173652829203D3D3D20';
wwv_flow_imp.g_varchar2_table(51) := '276E756D62657227203F20675856616C7565466F726D617474657228642E7829203A20675856616C7565466F726D6174746572286E6577204461746528642E7829293B0D0A20202020202020202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(52) := '2020202020202020207D20656C736520696620282021704F7074696F6E732E746F6F6C7469705820262620704F7074696F6E732E746F6F6C74697053657269657329207B0D0A202020202020202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(53) := '202020202020202020202020202072657475726E20642E7365726965733B0D0A202020202020202020202020202020202020202020202020202020202020202020202020202020207D20656C7365207B0D0A202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(54) := '202020202020202020202020202020202020202020202020202076617220666F726D61747465645856616C7565203D20704F7074696F6E732E7844617461547970652E746F4C6F776572436173652829203D3D3D20276E756D62657227203F2067585661';
wwv_flow_imp.g_varchar2_table(55) := '6C7565466F726D617474657228642E7829203A20675856616C7565466F726D6174746572286E6577204461746528642E7829293B0D0A20202020202020202020202020202020202020202020202020202020202020202020202020202020202020207265';
wwv_flow_imp.g_varchar2_table(56) := '7475726E20642E736572696573202B2027202827202B20666F726D61747465645856616C7565202B202729273B0D0A202020202020202020202020202020202020202020202020202020202020202020202020202020207D0D0A20202020202020202020';
wwv_flow_imp.g_varchar2_table(57) := '20202020202020202020202020202020202020202020202020207D203A206E756C6C2C0D0A20202020202020202020202020202020202020202020202076616C7565203A20704F7074696F6E732E746F6F6C74697059203F2066756E6374696F6E282064';
wwv_flow_imp.g_varchar2_table(58) := '2029207B2072657475726E20642E793B207D203A206E756C6C2C0D0A202020202020202020202020202020202020202020202020636F6C6F72203A2066756E6374696F6E2829207B2072657475726E2067546F6F6C746970436F6C6F72207D2C0D0A2020';
wwv_flow_imp.g_varchar2_table(59) := '20202020202020202020202020202020202020202020636F6E74656E74203A2066756E6374696F6E2820642029207B0D0A2020202020202020202020202020202020202020202020202020202072657475726E20642E746F6F6C7469703B0D0A20202020';
wwv_flow_imp.g_varchar2_table(60) := '20202020202020202020202020202020202020207D0D0A20202020202020202020202020202020202020207D290D0A20202020202020202020202020202020202020202E666F726D617474657273287B0D0A202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(61) := '20202020202076616C7565203A20675956616C7565466F726D61747465720D0A20202020202020202020202020202020202020207D290D0A20202020202020202020202020202020202020202E7472616E736974696F6E73287B0D0A2020202020202020';
wwv_flow_imp.g_varchar2_table(62) := '202020202020202020202020202020656E61626C65203A2066616C73650D0A20202020202020202020202020202020202020207D292020200D0A20202020202020202020202020202020202020202E73796D626F6C282027636972636C652720293B0D0A';
wwv_flow_imp.g_varchar2_table(63) := '20202020202020207D0D0A0D0A20202020202020202F2A0D0A2020202020202020202A20496E697469616C697A6573204C6567656E64207769746820736F6D65206174747269627574657320616E6420706F736974696F6E20746865206C6567656E6420';
wwv_flow_imp.g_varchar2_table(64) := '6F6E20746F70206F7220626F74746F6D0D0A2020202020202020202A206163636F7264696E6720746F206174747269627574652073656E7420627920757365720D0A2020202020202020202A0D0A2020202020202020202A2F0D0A202020202020202066';
wwv_flow_imp.g_varchar2_table(65) := '756E6374696F6E205F696E697469616C697A654C6567656E6428297B0D0A2020202020202020202020202F2F20544F444F20496E766F6B652064332E6F7261636C652E61727928290D0A20202020202020202020202067417279203D2064332E6F726163';
wwv_flow_imp.g_varchar2_table(66) := '6C652E61727928290D0A202020202020202020202020202020202E686964655469746C6528207472756520290D0A202020202020202020202020202020202E73686F7756616C7565282066616C736520290D0A202020202020202020202020202020202E';
wwv_flow_imp.g_varchar2_table(67) := '6C656674436F6C6F7228207472756520290D0A202020202020202020202020202020202E6E756D6265724F66436F6C756D6E7328203320290D0A202020202020202020202020202020202E6163636573736F7273287B0D0A202020202020202020202020';
wwv_flow_imp.g_varchar2_table(68) := '2020202020202020636F6C6F723A20674C696E6543686172742E6163636573736F7273282027636F6C6F722720292C0D0A20202020202020202020202020202020202020206C6162656C3A20674C696E6543686172742E6163636573736F727328202773';
wwv_flow_imp.g_varchar2_table(69) := '65726965732720290D0A202020202020202020202020202020207D293B0D0A0D0A202020202020202020202020674C6567656E6424203D20242820273C6469763E2720293B0D0A0D0A2020202020202020202020206966202820704F7074696F6E732E6C';
wwv_flow_imp.g_varchar2_table(70) := '6567656E64506F736974696F6E203D3D3D27544F50272029207B0D0A20202020202020202020202020202020674368617274242E6265666F72652820674C6567656E642420293B0D0A2020202020202020202020207D20656C7365207B0D0A2020202020';
wwv_flow_imp.g_varchar2_table(71) := '2020202020202020202020674368617274242E61667465722820674C6567656E642420293B0D0A2020202020202020202020207D0D0A20202020202020207D0D0A0D0A20202020202020202F2A0D0A2020202020202020202A204945204D616E6970756C';
wwv_flow_imp.g_varchar2_table(72) := '6174696F6E206F662042426F780D0A2020202020202020202A2040706172616D207B4F626A6563747D206F626A65637420444F4D20656C656D656E740D0A2020202020202020202A2040706172616D207B4F626A6563747D20746F6F6C74697053656C65';
wwv_flow_imp.g_varchar2_table(73) := '6374696F6E20443320656C656D656E740D0A2020202020202020202A2040706172616D207B4F626A6563747D206420443320656C656D656E740D0A2020202020202020202A2F0D0A202020202020202066756E6374696F6E205F64657461636828206262';
wwv_flow_imp.g_varchar2_table(74) := '6F782029207B0D0A20202020202020202020202072657475726E207B0D0A2020202020202020202020202020202078203A2062626F782E782C0D0A2020202020202020202020202020202079203A2062626F782E792C0D0A202020202020202020202020';
wwv_flow_imp.g_varchar2_table(75) := '202020207769647468203A2062626F782E77696474682C0D0A20202020202020202020202020202020686569676874203A2062626F782E6865696768740D0A2020202020202020202020207D3B0D0A20202020202020207D0D0A0D0A2020202020202020';
wwv_flow_imp.g_varchar2_table(76) := '2F2A0D0A2020202020202020202A2053686F77732074686520746F6F6C7469700D0A2020202020202020202A2040706172616D207B4F626A6563747D206F626A65637420444F4D20656C656D656E740D0A2020202020202020202A2040706172616D207B';
wwv_flow_imp.g_varchar2_table(77) := '4F626A6563747D20746F6F6C74697053656C656374696F6E20443320656C656D656E740D0A2020202020202020202A2040706172616D207B4F626A6563747D206420443320656C656D656E740D0A2020202020202020202A2F0D0A202020202020202066';
wwv_flow_imp.g_varchar2_table(78) := '756E6374696F6E205F73686F77546F6F6C74697028206F626A6563742C20746F6F6C74697053656C656374696F6E2C206420297B0D0A2020202020202020202020202F2F4D616B65206749734B6579446F776E5472696767657265642066616C73652074';
wwv_flow_imp.g_varchar2_table(79) := '6F206D616B6520737572652074686174207468697320636F6465206973206265696E6720657865637574656420616E642061766F696420636F6E666C6963747320666F72206F74686572206576656E747320746861742073686F772074686520746F6F6C';
wwv_flow_imp.g_varchar2_table(80) := '74697020746F6F0D0A2020202020202020202020206749734B6579446F776E547269676765726564203D2066616C73653B0D0A20202020202020202020202067546F6F6C746970436F6C6F72203D2077696E646F772E676574436F6D7075746564537479';
wwv_flow_imp.g_varchar2_table(81) := '6C6528206F626A65637420292E67657450726F706572747956616C756528202766696C6C2720293B0D0A0D0A2020202020202020202020202F2F546F6F6C74697020696E697469616C697A6174696F6E0D0A202020202020202020202020746F6F6C7469';
wwv_flow_imp.g_varchar2_table(82) := '7053656C656374696F6E0D0A202020202020202020202020202020202E646174756D28206420290D0A202020202020202020202020202020202E63616C6C282067546F6F6C74697047656E657261746F7220293B0D0A2020202020202020202020206754';
wwv_flow_imp.g_varchar2_table(83) := '6F6F6C746970242E73746F7028292E66616465496E2820704F7074696F6E732E7472616E736974696F6E73203F20313030203A203020293B0D0A0D0A2020202020202020202020202F2F476574206F6666736574206F662063757272656E7420706F696E';
wwv_flow_imp.g_varchar2_table(84) := '7420616E6420706F736974696F6E207468652063757272656E7420746F6F6C7469700D0A202020202020202020202020766172206F6666203D202428206F626A65637420292E6F666673657428293B0D0A0D0A2020202020202020202020207661722072';
wwv_flow_imp.g_varchar2_table(85) := '4F6666203D202428206F626A65637420292E6F666673657428293B0D0A20202020202020202020202076617220634F6666203D20674368617274242E6F666673657428293B0D0A2020202020202020202020207661722072426F78203D205F6465746163';
wwv_flow_imp.g_varchar2_table(86) := '6828206F626A6563742E67657442426F78282920293B0D0A20202020202020202020202067546F6F6C746970242E706F736974696F6E287B0D0A202020202020202020202020202020206D793A202763656E74657220626F74746F6D2D35272C0D0A2020';
wwv_flow_imp.g_varchar2_table(87) := '20202020202020202020202020206F663A20674368617274242C0D0A2020202020202020202020202020202061743A20276C6566742B27202B0D0A20202020202020202020202020202020202020204D6174682E726F756E642820724F66662E6C656674';
wwv_flow_imp.g_varchar2_table(88) := '202D20634F66662E6C656674202B2072426F782E7769647468202F20322029202B0D0A20202020202020202020202020202020202020202720746F702B27202B0D0A20202020202020202020202020202020202020202820724F66662E746F70202D2063';
wwv_flow_imp.g_varchar2_table(89) := '4F66662E746F7020292C0D0A2020202020202020202020202020202077697468696E3A2067526567696F6E242C0D0A20202020202020202020202020202020636F6C6C6973696F6E3A202766697420666974270D0A2020202020202020202020207D293B';
wwv_flow_imp.g_varchar2_table(90) := '0D0A20202020202020207D0D0A0D0A20202020202020202F2A0D0A2020202020202020202A2046696C74657273207468652064617461206F626A6563742073656E742066726F6D2073657276657220746F20676574207468652067726F7570696E677320';
wwv_flow_imp.g_varchar2_table(91) := '6F66207365726965730D0A2020202020202020202A204072657475726E207B4F626A6563747D2046696C746572656420646174610D0A2020202020202020202A2F0D0A202020202020202066756E6374696F6E205F676574536572696573446174612864';
wwv_flow_imp.g_varchar2_table(92) := '617461297B0D0A20202020202020202020202072657475726E206F7261636C652E6A716C28290D0A202020202020202020202020202020202E73656C65637428205B66756E6374696F6E28726F7773297B2072657475726E20674C696E6543686172742E';
wwv_flow_imp.g_varchar2_table(93) := '6163636573736F72732827636F6C6F72272928726F77735B305D293B207D2C2027636F6C6F72275D20290D0A202020202020202020202020202020202E66726F6D28206461746120290D0A202020202020202020202020202020202E67726F75705F6279';
wwv_flow_imp.g_varchar2_table(94) := '28205B66756E6374696F6E28726F77297B2072657475726E20726F772E7365726965733B207D2C2027736572696573275D202928293B0D0A20202020202020207D0D0A0D0A20202020202020202F2A0D0A2020202020202020202A2041737369676E2074';
wwv_flow_imp.g_varchar2_table(95) := '68656D6520726F6C6C657220636C617373657320746F20636861727420656C656D656E74732028446F74732C204C696E657320616E64204172656173290D0A2020202020202020202A2040706172616D207B4F626A6563747D2063686172742044332065';
wwv_flow_imp.g_varchar2_table(96) := '6C656D656E740D0A2020202020202020202A200D0A2020202020202020202A2F0D0A202020202020202066756E6374696F6E205F61737369676E5468656D65526F6C6C6572436C61737365732820636861727420297B0D0A202020202020202020202020';
wwv_flow_imp.g_varchar2_table(97) := '63686172742E73656C656374416C6C2820272E27202B2043484152545F504F494E545F434F4E5441494E45525F434C415353202B20272D646F742720290D0A202020202020202020202020202020202E656163682866756E6374696F6E202829207B0D0A';
wwv_flow_imp.g_varchar2_table(98) := '202020202020202020202020202020202020202064332E73656C65637428207468697320290D0A2020202020202020202020202020202020202020202020202E636C6173736564282027752D436F6C6F722D27202B2067436C6173735363616C65282067';
wwv_flow_imp.g_varchar2_table(99) := '4C696E6543686172742E6163636573736F72732820277365726965732720292E6170706C792820746869732C20617267756D656E747320292029202B20272D42472D2D66696C6C272C207472756520290D0A202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(100) := '2020202020202E636C6173736564282027752D436F6C6F722D27202B2067436C6173735363616C652820674C696E6543686172742E6163636573736F72732820277365726965732720292E6170706C792820746869732C20617267756D656E7473202920';
wwv_flow_imp.g_varchar2_table(101) := '29202B20272D42472D2D6272272C207472756520290D0A202020202020202020202020202020207D290D0A202020202020202020202020202020202E636C61737365642820272E27202B2043484152545F504F494E545F434F4E5441494E45525F434C41';
wwv_flow_imp.g_varchar2_table(102) := '5353202B20272D646F74272C2066756E6374696F6E202820642029207B2072657475726E202820642E6C696E6B20262620642E6C696E6B2E6C656E677468203E203120293B207D20293B0D0A0D0A20202020202020202020202063686172742E73656C65';
wwv_flow_imp.g_varchar2_table(103) := '6374416C6C2820272E27202B2043484152545F415245415F434C41535320290D0A202020202020202020202020202020202E656163682866756E6374696F6E202829207B0D0A202020202020202020202020202020202020202064332E73656C65637428';
wwv_flow_imp.g_varchar2_table(104) := '207468697320290D0A2020202020202020202020202020202020202020202020202E636C6173736564282027752D436F6C6F722D27202B2067436C6173735363616C652820674C696E6543686172742E6163636573736F72732820277365726965732720';
wwv_flow_imp.g_varchar2_table(105) := '292E6170706C792820746869732C20617267756D656E747320292029202B20272D42472D2D66696C6C272C207472756520290D0A202020202020202020202020202020207D290D0A0D0A20202020202020202020202063686172742E73656C656374416C';
wwv_flow_imp.g_varchar2_table(106) := '6C2820272E272B2043484152545F4C494E455F434C41535320290D0A202020202020202020202020202020202E656163682866756E6374696F6E202829207B0D0A202020202020202020202020202020202020202064332E73656C656374282074686973';
wwv_flow_imp.g_varchar2_table(107) := '20290D0A2020202020202020202020202020202020202020202020202E636C6173736564282027752D436F6C6F722D27202B2067436C6173735363616C652820674C696E6543686172742E6163636573736F72732820277365726965732720292E617070';
wwv_flow_imp.g_varchar2_table(108) := '6C792820746869732C20617267756D656E747320292029202B20272D42472D2D6272272C207472756520290D0A202020202020202020202020202020207D290D0A20202020202020207D0D0A0D0A20202020202020202F2A0D0A2020202020202020202A';
wwv_flow_imp.g_varchar2_table(109) := '205768656E20746865206C656674206B65792069732070726573736564206368616E67652074686520666F63757320706F696E7420746F207468652070726576696F757320706F696E7420696E2061207365726965732C0D0A2020202020202020202A20';
wwv_flow_imp.g_varchar2_table(110) := '69662074686520666F637573206973206F6E2074686520666972737420706F696E7420696E207468652073657269657320616E6420746865206C656674206172726F7720697320707265737365642C2074686520666F63757320676F657320746F207468';
wwv_flow_imp.g_varchar2_table(111) := '65206C61737420706F696E7420696E20746865207365726965730D0A2020202020202020202A205768656E20746865207269676874206B65792069732070726573736564206368616E67652074686520666F63757320706F696E7420746F20746865206E';
wwv_flow_imp.g_varchar2_table(112) := '65787420706F696E7420696E2061207365726965732C0D0A2020202020202020202A2069662074686520666F637573206973206F6E20746865206C61737420706F696E7420696E207468652073657269657320616E642074686520726967687420617272';
wwv_flow_imp.g_varchar2_table(113) := '6F7720697320707265737365642C2074686520666F63757320676F657320746F2074686520666972737420706F696E7420696E20746865207365726965730D0A2020202020202020202A2040706172616D207B4F626A6563747D206368617274506F696E';
wwv_flow_imp.g_varchar2_table(114) := '74446F74436C61737320443320656C656D656E740D0A2020202020202020202A2040706172616D207B4F626A6563747D206F626A65637420444F4D20656C656D656E740D0A2020202020202020202A2040706172616D207B4E756D6265727D206B657920';
wwv_flow_imp.g_varchar2_table(115) := '4B657920636F6465206F66206C6566742833372920616E6420726967687428333929206B6579730D0A2020202020202020202A200D0A2020202020202020202A2F0D0A202020202020202066756E6374696F6E205F6C65667452696768744172726F774B';
wwv_flow_imp.g_varchar2_table(116) := '6579416374696F6E28206368617274506F696E74446F74436C6173732C206F626A6563742C206B657920297B0D0A2020202020202020202020206749734B6579446F776E547269676765726564203D20747275653B0D0A2020202020202020202020202F';
wwv_flow_imp.g_varchar2_table(117) := '2F496620746865206C656674206B657920776173207072657373656420676F207468652070726576696F757320706F696E740D0A202020202020202020202020696628206B6579203D3D3D20333720297B0D0A2020202020202020202020202020202069';
wwv_flow_imp.g_varchar2_table(118) := '662028202167466F6375736564506F696E742029207B0D0A202020202020202020202020202020202020202067466F6375736564506F696E74203D2024286F626A6563742E717565727953656C6563746F72416C6C286368617274506F696E74446F7443';
wwv_flow_imp.g_varchar2_table(119) := '6C61737329292E6C61737428292E666F63757328293B0D0A20202020202020202020202020202020202020202F2F67466F6375736564506F696E74203D2024286F626A656374292E66696E64286368617274506F696E74446F74436C617373292E6C6173';
wwv_flow_imp.g_varchar2_table(120) := '7428292E666F63757328293B0D0A20202020202020202020202020202020202020202F2F67466F6375736564506F696E74203D202428206368617274506F696E74446F74436C6173732C206743686172742420292E6C61737428292E666F63757328293B';
wwv_flow_imp.g_varchar2_table(121) := '2020202020200D0A202020202020202020202020202020207D20656C736520696620282067466F6375736564506F696E742E7072657628292E6C656E677468203E20302029207B0D0A202020202020202020202020202020202020202067466F63757365';
wwv_flow_imp.g_varchar2_table(122) := '64506F696E742E626C757228293B0D0A202020202020202020202020202020202020202067466F6375736564506F696E74203D2067466F6375736564506F696E742E7072657628292E666F63757328293B0D0A202020202020202020202020202020207D';
wwv_flow_imp.g_varchar2_table(123) := '20656C7365207B0D0A202020202020202020202020202020202020202067466F6375736564506F696E742E626C757228293B0D0A202020202020202020202020202020202020202067466F6375736564506F696E74203D20242867466F6375736564506F';
wwv_flow_imp.g_varchar2_table(124) := '696E742E706172656E7428292E67657428203020292E717565727953656C6563746F72416C6C286368617274506F696E74446F74436C61737329292E6C61737428292E666F63757328293B0D0A20202020202020202020202020202020202020202F2F67';
wwv_flow_imp.g_varchar2_table(125) := '466F6375736564506F696E74203D2067466F6375736564506F696E742E706172656E7428292E66696E64286368617274506F696E74446F74436C617373292E6C61737428292E666F63757328293B0D0A2020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(126) := '2F2F67466F6375736564506F696E74203D202428206368617274506F696E74446F74436C6173732C2067466F6375736564506F696E742E706172656E74282920292E6C61737428292E666F63757328293B0D0A202020202020202020202020202020207D';
wwv_flow_imp.g_varchar2_table(127) := '0D0A2020202020202020202020202F2F496620746865207269676874206B657920776173207072657373656420676F20746865206E65787420706F696E740D0A2020202020202020202020207D656C736520696628206B6579203D3D3D20333920297B0D';
wwv_flow_imp.g_varchar2_table(128) := '0A2020202020202020202020202020202069662028202167466F6375736564506F696E742029207B0D0A202020202020202020202020202020202020202067466F6375736564506F696E74203D2024286F626A6563742E717565727953656C6563746F72';
wwv_flow_imp.g_varchar2_table(129) := '416C6C286368617274506F696E74446F74436C61737329292E666972737428292E666F63757328293B0D0A20202020202020202020202020202020202020202F2F67466F6375736564506F696E74203D2024286F626A656374292E66696E642820636861';
wwv_flow_imp.g_varchar2_table(130) := '7274506F696E74446F74436C61737320292E666972737428292E666F63757328293B0D0A20202020202020202020202020202020202020202F2F67466F6375736564506F696E74203D202428206368617274506F696E74446F74436C6173732C20674368';
wwv_flow_imp.g_varchar2_table(131) := '6172742420292E666972737428292E666F63757328293B2020200D0A202020202020202020202020202020207D20656C736520696620282067466F6375736564506F696E742E6E65787428292E6C656E677468203E20302029207B0D0A20202020202020';
wwv_flow_imp.g_varchar2_table(132) := '2020202020202020202020202067466F6375736564506F696E742E626C757228293B0D0A202020202020202020202020202020202020202067466F6375736564506F696E74203D2067466F6375736564506F696E742E6E65787428292E666F6375732829';
wwv_flow_imp.g_varchar2_table(133) := '3B0D0A202020202020202020202020202020207D20656C7365207B0D0A202020202020202020202020202020202020202067466F6375736564506F696E742E626C757228293B0D0A202020202020202020202020202020202020202067466F6375736564';
wwv_flow_imp.g_varchar2_table(134) := '506F696E74203D20242867466F6375736564506F696E742E706172656E7428292E67657428203020292E717565727953656C6563746F72416C6C286368617274506F696E74446F74436C61737329292E666972737428292E666F63757328293B0D0A2020';
wwv_flow_imp.g_varchar2_table(135) := '2020202020202020202020202020202020202F2F67466F6375736564506F696E74203D2067466F6375736564506F696E742E706172656E7428292E66696E6428206368617274506F696E74446F74436C61737320292E666972737428292E666F63757328';
wwv_flow_imp.g_varchar2_table(136) := '293B0D0A20202020202020202020202020202020202020202F2F67466F6375736564506F696E74203D202428206368617274506F696E74446F74436C6173732C2067466F6375736564506F696E742E706172656E74282920292E666972737428292E666F';
wwv_flow_imp.g_varchar2_table(137) := '63757328293B0D0A202020202020202020202020202020207D0D0A2020202020202020202020207D0D0A20202020202020207D0D0A0D0A20202020202020202F2A0D0A2020202020202020202A205768656E20746865207570206B657920697320707265';
wwv_flow_imp.g_varchar2_table(138) := '73736564206368616E67652074686520666F63757320706F696E7420746F2074686520706F696E74207468617420686173207468652073616D6520582076616C756520696E207468652070726576696F7573207365726965732C0D0A2020202020202020';
wwv_flow_imp.g_varchar2_table(139) := '202A2069662074686520666F637573206973206F6E20746865206C6173742073657269657320616E6420746865207570206172726F7720697320707265737365642C2074686520666F63757320676F657320746F20746865206669727374207365726965';
wwv_flow_imp.g_varchar2_table(140) := '730D0A2020202020202020202A205768656E2074686520646F776E206B65792069732070726573736564206368616E67652074686520666F63757320706F696E7420746F2074686520706F696E74207468617420686173207468652073616D6520582076';
wwv_flow_imp.g_varchar2_table(141) := '616C756520696E20746865206E657874207365726965732C0D0A2020202020202020202A2069662074686520666F637573206973206F6E207468652066697273742073657269657320616E642074686520646F776E206172726F77206973207072657373';
wwv_flow_imp.g_varchar2_table(142) := '65642C2074686520666F63757320676F657320746F20746865206C617374207365726965730D0A2020202020202020202A2040706172616D207B4F626A6563747D20746F6F6C74697053656C656374696F6E20443320656C656D656E740D0A2020202020';
wwv_flow_imp.g_varchar2_table(143) := '202020202A2040706172616D207B4F626A6563747D206420443320656C656D656E740D0A2020202020202020202A2040706172616D207B4E756D6265727D206B6579204B657920636F6465206F662075702833382920616E6420646F776E28343029206B';
wwv_flow_imp.g_varchar2_table(144) := '6579730D0A2020202020202020202A0D0A2020202020202020202A2F0D0A202020202020202066756E6374696F6E205F7570446F776E4172726F774B6579416374696F6E28206368617274506F696E74446F74436C6173732C206F626A6563742C206B65';
wwv_flow_imp.g_varchar2_table(145) := '7920297B0D0A2020202020202020202020206749734B6579446F776E547269676765726564203D20747275653B0D0A0D0A2020202020202020202020202F2F496620746865726520617265206E6F20666F637573656420706F696E74732C20666F637573';
wwv_flow_imp.g_varchar2_table(146) := '206F6E2074686520666972737420706F696E74206F6620746865206669727374207365726965730D0A2020202020202020202020202F2F496620746865726520697320616C7265616479206120666F637573656420706F696E7420636865636B20776869';
wwv_flow_imp.g_varchar2_table(147) := '6368206F6E6520697320746865206F6E6520746F206765742074686520666F6375730D0A20202020202020202020202069662028202167466F6375736564506F696E7420297B0D0A2020202020202020202020202020202067466F6375736564506F696E';
wwv_flow_imp.g_varchar2_table(148) := '742E626C757228293B0D0A2020202020202020202020202020202067466F6375736564506F696E74203D2024286F626A6563742E717565727953656C6563746F72416C6C286368617274506F696E74446F74436C61737329292E666972737428292E666F';
wwv_flow_imp.g_varchar2_table(149) := '63757328293B0D0A2020202020202020202020207D656C73657B0D0A202020202020202020202020202020202F2F476574207468652070726F70657220696E64657820746F20626520666F63757365640D0A202020202020202020202020202020202F2F';
wwv_flow_imp.g_varchar2_table(150) := '496620746865207570206172726F77207761732070726573736564207265647563652074686520696E6465780D0A20202020202020202020202020202020696628206B6579203D3D3D20333820297B0D0A20202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(151) := '206966202820674F626A656374496E646578203D3D3D203020297B2F2F674F626A656374496E646578206861732074686520696E6465782076616C7565206F662074686520656C656D656E7420696E206F6E652073657269657320746861742068617320';
wwv_flow_imp.g_varchar2_table(152) := '74686520666F6375732065672E28496620746865207365636F6E64206461746120706F696E7420696E20612073657269657320697320666F6375732D2D3E20674F626A656374496E646578203D2031290D0A202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(153) := '202020202020674F626A656374496E646578203D20675365726965732E6C656E677468202D20313B0D0A20202020202020202020202020202020202020207D656C73657B0D0A202020202020202020202020202020202020202020202020674F626A6563';
wwv_flow_imp.g_varchar2_table(154) := '74496E6465782D2D3B0D0A20202020202020202020202020202020202020207D0D0A202020202020202020202020202020202F2F4966207468652075646F776E206172726F7720776173207072657373656420696E6372656173652074686520696E6465';
wwv_flow_imp.g_varchar2_table(155) := '780D0A202020202020202020202020202020207D656C736520696628206B6579203D3D3D20343020297B0D0A20202020202020202020202020202020202020206966202820674F626A656374496E646578203D3D3D20675365726965732E6C656E677468';
wwv_flow_imp.g_varchar2_table(156) := '202D203120297B0D0A2020202020202020202020202020202020202020202020674F626A656374496E646578203D20303B200D0A20202020202020202020202020202020202020207D656C73657B0D0A2020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(157) := '20202020674F626A656374496E6465782B2B3B0D0A20202020202020202020202020202020202020207D0D0A202020202020202020202020202020207D0D0A202020202020202020202020202020202F2F546F20676574207468652073616D6520706F69';
wwv_flow_imp.g_varchar2_table(158) := '6E7420696E207468652070726576696F75732073657269657320776520617373756D652074686174206265747765656E2073657269657320616C6C2074686520706F696E747320736861726520616E20582076616C75650D0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(159) := '20202020202F2F46697273742077652073656C6563742074686520782076616C7565206F662074686520666F637573656420706F696E740D0A20202020202020202020202020202020766172207856616C75654F66646F74546F426553656C6563746564';
wwv_flow_imp.g_varchar2_table(160) := '203D202064332E73656C656374282067466F6375736564506F696E742E67657428302920292E646174756D28292E783B0D0A202020202020202020202020202020202F2F47657420616C6C2074686520706F696E7420696E207468652073657269657320';
wwv_flow_imp.g_varchar2_table(161) := '7468617420697320676F696E6720746F20686176652074686520666F6375730D0A2020202020202020202020202020202076617220646F747353656C656374696F6E203D206753657269657353656C656374696F6E0D0A20202020202020202020202020';
wwv_flow_imp.g_varchar2_table(162) := '20202020202020202020202020202020202020202020202E66696C7465722866756E6374696F6E20286429207B2072657475726E20642E736572696573203D3D3D20675365726965735B674F626A656374496E6465785D2E7365726965733B207D290D0A';
wwv_flow_imp.g_varchar2_table(163) := '2020202020202020202020202020202020202020202020202020202020202020202020202E73656C656374416C6C286368617274506F696E74446F74436C617373293B0D0A0D0A202020202020202020202020202020202F2F53656C6563742074686520';
wwv_flow_imp.g_varchar2_table(164) := '706F696E74207468617420686173207468652073616D6520582076616C75652C2074686520726573756C7420697320616E206F626A6563742074686174206E6565647320746F20626520616363657373656420746F206765742074686520782076616C75';
wwv_flow_imp.g_varchar2_table(165) := '652C0D0A202020202020202020202020202020202F2F74686174206973202D2D3E205B305D5B305D0D0A2020202020202020202020202020202076617220646F7453656C6563746564203D20646F747353656C656374696F6E0D0A202020202020202020';
wwv_flow_imp.g_varchar2_table(166) := '2020202020202020202020202020202020202020202020202020202E66696C7465722866756E6374696F6E20286429207B2072657475726E20642E78203D3D3D207856616C75654F66646F74546F426553656C65637465643B207D295B305D5B305D3B0D';
wwv_flow_imp.g_varchar2_table(167) := '0A0D0A202020202020202020202020202020202F2F496620776520666F756E642061206D6174636820666F637573207468617420706F696E742C206966206E6F7420666F637573206F6E2074686520666972737420706F696E74206F6620746865207365';
wwv_flow_imp.g_varchar2_table(168) := '726965730D0A2020202020202020202020202020202069662820646F7453656C656374656420297B0D0A202020202020202020202020202020202020202067466F6375736564506F696E742E626C757228293B0D0A202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(169) := '202020202067466F6375736564506F696E74203D20242820646F7453656C656374656420292E666F63757328293B0D0A202020202020202020202020202020207D656C73657B0D0A202020202020202020202020202020202020202067466F6375736564';
wwv_flow_imp.g_varchar2_table(170) := '506F696E742E626C757228293B0D0A202020202020202020202020202020202020202067466F6375736564506F696E74203D20242820646F747353656C656374696F6E5B305D5B305D20292E666972737428292E666F63757328293B0D0A202020202020';
wwv_flow_imp.g_varchar2_table(171) := '202020202020202020207D2020202020202020202020200D0A2020202020202020202020207D0D0A20202020202020207D0D0A0D0A202020202020202066756E6374696F6E205F6164644B6579426F617264537570706F727428297B0D0A202020202020';
wwv_flow_imp.g_varchar2_table(172) := '202020202020766172206368617274506F696E74446F74436C617373203D20272E27202B2043484152545F504F494E545F434F4E5441494E45525F434C415353202B20272D646F74273B200D0A202020202020202020202020766172206973466F637573';
wwv_flow_imp.g_varchar2_table(173) := '6564203D2066616C73653B0D0A20202020202020202020202076617220737667203D2024282027737667272C206743686172742420292E666972737428290D0A202020202020202020202020202020202E61747472282027746162696E646578272C2030';
wwv_flow_imp.g_varchar2_table(174) := '20290D0A202020202020202020202020202020202E6F6E282027666F637573696E272C2066756E6374696F6E2829207B0D0A20202020202020202020202020202020202020206973466F6375736564203D20747275653B0D0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(175) := '20202020207D290D0A202020202020202020202020202020202E6F6E2820276B6579646F776E272C2066756E6374696F6E20286529207B0D0A2020202020202020202020202020202020202020737769746368202820652E77686963682029207B0D0A20';
wwv_flow_imp.g_varchar2_table(176) := '2020202020202020202020202020202020202020202020636173652033373A0D0A202020202020202020202020202020202020202020202020202020202F2F4C454654204152524F5720505245535345440D0A2020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(177) := '20202020202020202020205F6C65667452696768744172726F774B6579416374696F6E286368617274506F696E74446F74436C6173732C20746869732C20652E7768696368293B0D0A202020202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(178) := '20627265616B3B0D0A202020202020202020202020202020202020202020202020636173652033383A0D0A202020202020202020202020202020202020202020202020202020202F2F5550204152524F5720505245535345440D0A202020202020202020';
wwv_flow_imp.g_varchar2_table(179) := '202020202020202020202020202020202020205F7570446F776E4172726F774B6579416374696F6E286368617274506F696E74446F74436C6173732C20746869732C20652E7768696368293B0D0A20202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(180) := '202020202020627265616B3B0D0A202020202020202020202020202020202020202020202020636173652033393A0D0A202020202020202020202020202020202020202020202020202020202F2F5249474854204152524F5720505245535345440D0A20';
wwv_flow_imp.g_varchar2_table(181) := '2020202020202020202020202020202020202020202020202020205F6C65667452696768744172726F774B6579416374696F6E286368617274506F696E74446F74436C6173732C20746869732C20652E7768696368293B0D0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(182) := '2020202020202020202020202020202020627265616B3B0D0A202020202020202020202020202020202020202020202020636173652034303A0D0A202020202020202020202020202020202020202020202020202020202F2F444F574E204152524F5720';
wwv_flow_imp.g_varchar2_table(183) := '505245535345440D0A202020202020202020202020202020202020202020202020202020205F7570446F776E4172726F774B6579416374696F6E286368617274506F696E74446F74436C6173732C20746869732C20652E7768696368293B0D0A20202020';
wwv_flow_imp.g_varchar2_table(184) := '202020202020202020202020202020202020202020202020627265616B3B0D0A20202020202020202020202020202020202020207D0D0A202020202020202020202020202020207D290D0A202020202020202020202020202020202E6F6E282027666F63';
wwv_flow_imp.g_varchar2_table(185) := '75736F7574272C2066756E6374696F6E20286529207B0D0A2020202020202020202020202020202020202020696620282024282027636972636C653A666F6375732C207376673A666F637573272C206743686172742420292E6C656E677468203D3D3D20';
wwv_flow_imp.g_varchar2_table(186) := '302029207B0D0A2020202020202020202020202020202020202020202020206973466F6375736564203D2066616C73653B0D0A2020202020202020202020202020202020202020202020207661722073656C66203D20746869733B0D0A20202020202020';
wwv_flow_imp.g_varchar2_table(187) := '202020202020202020202020202020202064332E73656C6563742820674368617274242E67657428302920290D0A202020202020202020202020202020202020202020202020202020202E73656C656374416C6C28206368617274506F696E74446F7443';
wwv_flow_imp.g_varchar2_table(188) := '6C61737320290D0A202020202020202020202020202020202020202020202020202020202E617474722820276F706163697479272C203120293B0D0A202020202020202020202020202020202020202020202020696620282049535F49452029207B0D0A';
wwv_flow_imp.g_varchar2_table(189) := '2020202020202020202020202020202020202020202020202020202076617220636861727453656C656374696F6E203D202064332E73656C6563742820674368617274242E67657428302920293B0D0A2020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(190) := '202020202020202076617220666F637573436C617373203D20704F7074696F6E732E646973706C61792E746F4C6F776572436173652829203D3D3D2027737461636B656427203F20272D2D666164652D737461636B656427203A20272D2D66616465273B';
wwv_flow_imp.g_varchar2_table(191) := '0D0A20202020202020202020202020202020202020202020202020202020636861727453656C656374696F6E0D0A20202020202020202020202020202020202020202020202020202020202020202E73656C656374416C6C2820272E272B43484152545F';
wwv_flow_imp.g_varchar2_table(192) := '4C494E455F434C41535320290D0A20202020202020202020202020202020202020202020202020202020202020202E636C6173736564282043484152545F4C494E455F434C415353202B20666F637573436C6173732C2066616C7365293B0D0A0D0A2020';
wwv_flow_imp.g_varchar2_table(193) := '2020202020202020202020202020202020202020202020202020636861727453656C656374696F6E0D0A20202020202020202020202020202020202020202020202020202020202020202E73656C656374416C6C2820272E272B43484152545F41524541';
wwv_flow_imp.g_varchar2_table(194) := '5F434C41535320290D0A20202020202020202020202020202020202020202020202020202020202020202E636C6173736564282043484152545F415245415F434C415353202B20666F637573436C6173732C2066616C7365293B0D0A0D0A202020202020';
wwv_flow_imp.g_varchar2_table(195) := '20202020202020202020202020202020202020202020636861727453656C656374696F6E0D0A20202020202020202020202020202020202020202020202020202020202020202E73656C656374416C6C2820272E272B43484152545F504F494E545F434F';
wwv_flow_imp.g_varchar2_table(196) := '4E5441494E45525F434C41535320290D0A20202020202020202020202020202020202020202020202020202020202020202E636C6173736564282043484152545F504F494E545F434F4E5441494E45525F434C415353202B20666F637573436C6173732C';
wwv_flow_imp.g_varchar2_table(197) := '2066616C7365293B0D0A0D0A2020202020202020202020202020202020202020202020202020202064332E73656C656374282067466F6375736564506F696E742E67657428302920290D0A20202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(198) := '202020202020202E7472616E736974696F6E28292E6475726174696F6E2820504F494E545F5452414E534954494F4E5F4455524154494F4E20290D0A20202020202020202020202020202020202020202020202020202020202020202E61747472282272';
wwv_flow_imp.g_varchar2_table(199) := '222C2066756E6374696F6E2864297B2072657475726E20642E247261646975733B207D293B0D0A2020202020202020202020202020202020202020202020202020202067466F6375736564506F696E74203D206E756C6C3B0D0A20202020202020202020';
wwv_flow_imp.g_varchar2_table(200) := '20202020202020202020202020202020202067546F6F6C746970242E6869646528293B0D0A2020202020202020202020202020202020202020202020207D0D0A0D0A20202020202020202020202020202020202020207D0D0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(201) := '20202020207D293B0D0A202020202020202020202020202020200D0A202020202020202020202020242820646F63756D656E7420292E6F6E2820276B6579646F776E272C2066756E6374696F6E20286529207B0D0A202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(202) := '2069662028206973466F637573656420262620652E7768696368203E3D20333720262620652E7768696368203C3D2034302029207B0D0A2020202020202020202020202020202020202020652E70726576656E7444656661756C7428293B0D0A20202020';
wwv_flow_imp.g_varchar2_table(203) := '2020202020202020202020207D0D0A2020202020202020202020207D293B0D0A20202020202020202020202067486173486F6F6B65644576656E7473203D20747275653B0D0A20202020202020207D0D0A0D0A20202020202020202F2A0D0A2020202020';
wwv_flow_imp.g_varchar2_table(204) := '202020202A20496E697469616C697A6174696F6E2066756E6374696F6E20666F722074686520706C7567696E0D0A2020202020202020202A2040706172616D207B537472696E677D2070526567696F6E496420436F6E7461696E7320746865206964206F';
wwv_flow_imp.g_varchar2_table(205) := '662074686520726567696F6E20746861742077696C6C20636F6E7461696E2074686520706C7567696E0D0A2020202020202020202A2040706172616D207B4F626A6563747D20704F7074696F6E73204F626A656374207468617420686176652074686520';
wwv_flow_imp.g_varchar2_table(206) := '617474726962757465732076616C756573206F662074686520706C7567696E0D0A2020202020202020202A0D0A2020202020202020202A2F0D0A202020202020202066756E6374696F6E205F696E6974282070526567696F6E49642C20704F7074696F6E';
wwv_flow_imp.g_varchar2_table(207) := '732029207B0D0A202020202020202020202020674F7074696F6E73203D20704F7074696F6E733B0D0A0D0A2020202020202020202020202F2F2046696E64206F757220726567696F6E20616E642063686172742044495620636F6E7461696E6572730D0A';
wwv_flow_imp.g_varchar2_table(208) := '20202020202020202020202067526567696F6E24203D20242820272327202B207574696C2E657363617065435353282070526567696F6E496420292C20617065782E6750616765436F6E746578742420293B0D0A20202020202020202020202067436861';
wwv_flow_imp.g_varchar2_table(209) := '727424203D20242820272327202B207574696C2E6573636170654353532820704F7074696F6E732E6368617274526567696F6E496420292C20617065782E6750616765436F6E746578742420293B0D0A0D0A2020202020202020202020202F2F49662075';
wwv_flow_imp.g_varchar2_table(210) := '7365722073656E647320637573746F6D20636F6C6F7220737472696E6720646566696E652061207363616C650D0A20202020202020202020202076617220636F6C6F725363616C65203D20704F7074696F6E732E636F6C6F7273203F202064332E736361';
wwv_flow_imp.g_varchar2_table(211) := '6C652E6F7264696E616C28292E72616E67652820704F7074696F6E732E636F6C6F72732E73706C69742820273A2720292029203A20756E646566696E65643B0D0A0D0A2020202020202020202020202F2A0D0A202020202020202020202020202A205468';
wwv_flow_imp.g_varchar2_table(212) := '65205820417869732063616E206265206569746865722061206E756D65726963206F72206461746574696D652076616C75650D0A202020202020202020202020202A204966207468652075736572207069636B7320746865206E756D6265722076616C75';
wwv_flow_imp.g_varchar2_table(213) := '652061737369676E2074686520666F726D617474657220776974682061206E756D657269632074656D706C6174650D0A202020202020202020202020202A204966207468652075736572207069636B732061206461746574696D652076616C7565206173';
wwv_flow_imp.g_varchar2_table(214) := '7369676E2074686520666F726D61747465722077697468207468652070726F7065722074656D706C6174650D0A202020202020202020202020202A2F0D0A20202020202020202020202069662820704F7074696F6E732E7844617461547970652E746F4C';
wwv_flow_imp.g_varchar2_table(215) := '6F776572436173652829203D3D3D20276E756D6265722720297B0D0A20202020202020202020202020202020675856616C7565466F726D6174746572203D205F6E756D65726963466F726D617428704F7074696F6E732E7856616C756554656D706C6174';
wwv_flow_imp.g_varchar2_table(216) := '65293B0D0A2020202020202020202020207D656C73657B0D0A20202020202020202020202020202020675856616C7565466F726D6174746572203D205F64617465466F726D617428704F7074696F6E732E7856616C756554656D706C617465293B0D0A20';
wwv_flow_imp.g_varchar2_table(217) := '20202020202020202020207D0D0A0D0A2020202020202020202020202F2F446566696E65205363616C6520746F207069636B206E756D62657273207768656E2061737369676E696E67207468656D6520726F6C6C657220636C61737365730D0A20202020';
wwv_flow_imp.g_varchar2_table(218) := '202020202020202067436C6173735363616C65203D2064332E7363616C652E6F7264696E616C28290D0A202020202020202020202020202020202E72616E6765282064332E72616E67652820312C203136202920293B0D0A0D0A20202020202020202020';
wwv_flow_imp.g_varchar2_table(219) := '20202F2F446566696E652066756E6374696F6E20746F20666F726D6174205920417869730D0A202020202020202020202020675956616C7565466F726D6174746572203D205F6E756D65726963466F726D617428704F7074696F6E732E7956616C756554';
wwv_flow_imp.g_varchar2_table(220) := '656D706C617465293B0D0A0D0A2020202020202020202020202F2F5069636B2058204178697320696E74657276616C0D0A2020202020202020202020207377697463682028704F7074696F6E732E785469636B496E74657276616C297B0D0A2020202020';
wwv_flow_imp.g_varchar2_table(221) := '20202020202020202020206361736520275345434F4E44273A0D0A2020202020202020202020202020202020202020675469636B496E74657276616C46756E6374696F6E203D2064332E74696D652E7365636F6E643B0D0A202020202020202020202020';
wwv_flow_imp.g_varchar2_table(222) := '20202020627265616B3B0D0A202020202020202020202020202020206361736520274D494E555445273A0D0A2020202020202020202020202020202020202020675469636B496E74657276616C46756E6374696F6E203D2064332E74696D652E6D696E75';
wwv_flow_imp.g_varchar2_table(223) := '74653B0D0A20202020202020202020202020202020627265616B3B0D0A20202020202020202020202020202020636173652027484F5552273A0D0A2020202020202020202020202020202020202020675469636B496E74657276616C46756E6374696F6E';
wwv_flow_imp.g_varchar2_table(224) := '203D2064332E74696D652E686F75723B0D0A20202020202020202020202020202020627265616B3B0D0A20202020202020202020202020202020636173652027444159273A0D0A2020202020202020202020202020202020202020675469636B496E7465';
wwv_flow_imp.g_varchar2_table(225) := '7276616C46756E6374696F6E203D2064332E74696D652E6461793B0D0A20202020202020202020202020202020627265616B3B0D0A202020202020202020202020202020206361736520275745454B273A0D0A2020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(226) := '202020675469636B496E74657276616C46756E6374696F6E203D2064332E74696D652E7765656B3B0D0A20202020202020202020202020202020627265616B3B0D0A2020202020202020202020202020202063617365202753554E444159273A0D0A2020';
wwv_flow_imp.g_varchar2_table(227) := '202020202020202020202020202020202020675469636B496E74657276616C46756E6374696F6E203D2064332E74696D652E73756E6461793B0D0A20202020202020202020202020202020627265616B3B0D0A2020202020202020202020202020202063';
wwv_flow_imp.g_varchar2_table(228) := '61736520274D4F4E444159273A0D0A2020202020202020202020202020202020202020675469636B496E74657276616C46756E6374696F6E203D2064332E74696D652E6D6F6E6461793B0D0A20202020202020202020202020202020627265616B3B0D0A';
wwv_flow_imp.g_varchar2_table(229) := '2020202020202020202020202020202063617365202754554553444159273A0D0A2020202020202020202020202020202020202020675469636B496E74657276616C46756E6374696F6E203D2064332E74696D652E747565736461793B0D0A2020202020';
wwv_flow_imp.g_varchar2_table(230) := '2020202020202020202020627265616B3B0D0A202020202020202020202020202020206361736520275745444E4553444159273A0D0A2020202020202020202020202020202020202020675469636B496E74657276616C46756E6374696F6E203D206433';
wwv_flow_imp.g_varchar2_table(231) := '2E74696D652E7765646E65736461793B0D0A20202020202020202020202020202020627265616B3B0D0A202020202020202020202020202020206361736520275448555253444159273A0D0A202020202020202020202020202020202020202067546963';
wwv_flow_imp.g_varchar2_table(232) := '6B496E74657276616C46756E6374696F6E203D2064332E74696D652E74687572736461793B0D0A20202020202020202020202020202020627265616B3B0D0A20202020202020202020202020202020636173652027465249444159273A0D0A2020202020';
wwv_flow_imp.g_varchar2_table(233) := '202020202020202020202020202020675469636B496E74657276616C46756E6374696F6E203D2064332E74696D652E6672696461793B0D0A20202020202020202020202020202020627265616B3B0D0A2020202020202020202020202020202063617365';
wwv_flow_imp.g_varchar2_table(234) := '20275341545552444159273A0D0A2020202020202020202020202020202020202020675469636B496E74657276616C46756E6374696F6E203D2064332E74696D652E73617475726461793B0D0A20202020202020202020202020202020627265616B3B0D';
wwv_flow_imp.g_varchar2_table(235) := '0A202020202020202020202020202020206361736520274D4F4E5448273A0D0A2020202020202020202020202020202020202020675469636B496E74657276616C46756E6374696F6E203D2064332E74696D652E6D6F6E74683B0D0A2020202020202020';
wwv_flow_imp.g_varchar2_table(236) := '2020202020202020627265616B3B0D0A2020202020202020202020202020202063617365202759454152273A0D0A2020202020202020202020202020202020202020675469636B496E74657276616C46756E6374696F6E203D2064332E74696D652E7965';
wwv_flow_imp.g_varchar2_table(237) := '61723B0D0A20202020202020202020202020202020627265616B3B0D0A2020202020202020202020202020202064656661756C743A0D0A2020202020202020202020202020202020202020675469636B496E74657276616C46756E6374696F6E203D2027';
wwv_flow_imp.g_varchar2_table(238) := '6175746F273B0D0A2020202020202020202020207D0D0A0D0A2020202020202020202020202F2F20496E697469616C697A652063686172742067656E657261746F72207769746820706C7567696E207661726961626C65730D0A20202020202020202020';
wwv_flow_imp.g_varchar2_table(239) := '2020674C696E654368617274203D2064332E6F7261636C652E6C696E65636861727428290D0A202020202020202020202020202020202E6D617267696E2820276C656674272C20276175746F2720290D0A202020202020202020202020202020202E6D61';
wwv_flow_imp.g_varchar2_table(240) := '7267696E2820277269676874272C20276175746F2720290D0A202020202020202020202020202020202E6D617267696E282027626F74746F6D272C20276175746F2720290D0A202020202020202020202020202020202F2F5365742074696D6520646174';
wwv_flow_imp.g_varchar2_table(241) := '61206163636F7264696E6720746F2074686520747970652073657420696E2074686520617474726962757465730D0A202020202020202020202020202020202E74696D65446174612820704F7074696F6E732E7844617461547970652E746F4C6F776572';
wwv_flow_imp.g_varchar2_table(242) := '436173652829203D3D3D20276461746527207C7C20704F7074696F6E732E7844617461547970652E746F4C6F776572436173652829203D3D3D202774696D657374616D7027207C7C20704F7074696F6E732E7844617461547970652E746F4C6F77657243';
wwv_flow_imp.g_varchar2_table(243) := '6173652829203D3D3D202774696D657374616D705F747A27207C7C20704F7074696F6E732E7844617461547970652E746F4C6F776572436173652829203D3D3D202774696D657374616D705F6C747A27290D0A202020202020202020202020202020202E';
wwv_flow_imp.g_varchar2_table(244) := '6163636573736F7273282027636F6C6F72272C2066756E6374696F6E2820642029207B0D0A20202020202020202020202020202020202020202F2F2049662074686520636F6C6F7220736368656D65206973207374617469632C2075736520443320636F';
wwv_flow_imp.g_varchar2_table(245) := '6C6F72207363616C652E204F74686572776973652C2073656520696620746865726527732061206D617070696E6720666F7220746865207365726965732E0D0A20202020202020202020202020202020202020202F2F204661696C696E6720746861742C';
wwv_flow_imp.g_varchar2_table(246) := '2069742077696C6C2066616C6C206261636B20746F204353532E0D0A20202020202020202020202020202020202020207661722073203D20674C696E6543686172742E6163636573736F72732820277365726965732720292E6170706C79282074686973';
wwv_flow_imp.g_varchar2_table(247) := '2C20617267756D656E747320293B0D0A202020202020202020202020202020202020202072657475726E20636F6C6F725363616C65203F20636F6C6F725363616C652820732029203A20282067436F6C6F724D617070696E675B2073205D207C7C206E75';
wwv_flow_imp.g_varchar2_table(248) := '6C6C20293B0D0A202020202020202020202020202020207D290D0A202020202020202020202020202020202E6865696768744D6F646528202820704F7074696F6E732E6865696768744D6F6465207C7C202763686172742720292E746F4C6F7765724361';
wwv_flow_imp.g_varchar2_table(249) := '7365282920290D0A202020202020202020202020202020202E78466F726D617474657228675856616C7565466F726D6174746572290D0A202020202020202020202020202020202E6C696E65496E746572706F6C6174696F6E28704F7074696F6E732E69';
wwv_flow_imp.g_varchar2_table(250) := '6E746572706F6C6174696F6E290D0A202020202020202020202020202020202E7472616E736974696F6E73282027656E61626C65272C202121704F7074696F6E732E7472616E736974696F6E7320290D0A202020202020202020202020202020202E646F';
wwv_flow_imp.g_varchar2_table(251) := '7452616469757328276D6178272C20322E35290D0A202020202020202020202020202020202E646F7452616469757328276D696E272C2031290D0A202020202020202020202020202020202E646F74526164697573282773697A65272C20276175746F27';
wwv_flow_imp.g_varchar2_table(252) := '290D0A202020202020202020202020202020202E646F74526164697573282773706163696E67272C20302E36290D0A202020202020202020202020202020202E6163636573736F72732820276B6579272C2066756E6374696F6E2820642029207B0D0A20';
wwv_flow_imp.g_varchar2_table(253) := '2020202020202020202020202020202020202072657475726E202820747970656F6620642E7365726965732029202B20273A27202B20642E736572696573202B20277C7C27202B202820747970656F6620642E782029202B20273A27202B20642E783B0D';
wwv_flow_imp.g_varchar2_table(254) := '0A202020202020202020202020202020207D290D0A202020202020202020202020202020202E7841786973287B0D0A20202020202020202020202020202020202020207469746C653A20704F7074696F6E732E78417869735469746C65207C7C2027272C';
wwv_flow_imp.g_varchar2_table(255) := '0D0A2020202020202020202020202020202020202020666F726D61747465723A20675856616C7565466F726D61747465722C0D0A2020202020202020202020202020202020202020677269643A20704F7074696F6E732E78477269642C0D0A2020202020';
wwv_flow_imp.g_varchar2_table(256) := '2020202020202020202020202020207469636B73496E74657276616C3A20675469636B496E74657276616C46756E6374696F6E2C0D0A20202020202020202020202020202020202020207469636B73496E74657276616C537465703A20310D0A20202020';
wwv_flow_imp.g_varchar2_table(257) := '2020202020202020202020207D290D0A202020202020202020202020202020202E7941786973287B0D0A20202020202020202020202020202020202020207469746C65203A20704F7074696F6E732E79417869735469746C65207C7C2027272C0D0A2020';
wwv_flow_imp.g_varchar2_table(258) := '202020202020202020202020202020202020666F726D6174746572203A20675956616C7565466F726D61747465720D0A202020202020202020202020202020207D290D0A0D0A2020202020202020202020202F2F57696E646F7720726573697A65206861';
wwv_flow_imp.g_varchar2_table(259) := '6E646C65720D0A202020202020202020202020242877696E646F77292E6F6E28226170657877696E646F77726573697A6564222C2066756E6374696F6E2829207B0D0A20202020202020202020202020205F64726177286744617461293B0D0A20202020';
wwv_flow_imp.g_varchar2_table(260) := '20202020202020207D293B0D0A0D0A2020202020202020202020206966202820704F7074696F6E732E73686F774C6567656E642029207B0D0A202020202020202020202020202020205F696E697469616C697A654C6567656E6428293B0D0A2020202020';
wwv_flow_imp.g_varchar2_table(261) := '202020202020207D0D0A0D0A2020202020202020202020202F2F2043726561746520746F6F6C74697020636F6E7461696E657220616E642062696E64206E6563657373617279206576656E74730D0A2020202020202020202020206966202820704F7074';
wwv_flow_imp.g_varchar2_table(262) := '696F6E732E73686F77546F6F6C7469702029207B0D0A202020202020202020202020202020205F696E697469616C697A65546F6F6C74697028293B0D0A202020202020202020202020202020200D0A202020202020202020202020202020202F2F437265';
wwv_flow_imp.g_varchar2_table(263) := '61746520444F4D20656C656D656E74207468617420636F6E7461696E732074686520746F6F6C7469700D0A2020202020202020202020202020202067546F6F6C74697024203D20242820273C6469763E2720290D0A202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(264) := '20202020202E616464436C617373282027612D44334C696E6543686172742D746F6F6C74697020612D4433546F6F6C7469702720290D0A20202020202020202020202020202020202020202E617070656E64546F28206743686172742420290D0A202020';
wwv_flow_imp.g_varchar2_table(265) := '20202020202020202020202020202020202E6869646528293B0D0A0D0A202020202020202020202020202020202F2F4465636C617265207468652070726F70657220636C617373206163636F7264696E6720746F2063686172742074797065206F662064';
wwv_flow_imp.g_varchar2_table(266) := '6973706C61790D0A2020202020202020202020202020202076617220666F637573436C617373203D20704F7074696F6E732E646973706C61792E746F4C6F776572436173652829203D3D3D2027737461636B656427203F20272D2D666164652D73746163';
wwv_flow_imp.g_varchar2_table(267) := '6B656427203A20272D2D66616465273B0D0A0D0A202020202020202020202020202020202F2F53656C6563746F727320666F7220656C656D656E74730D0A2020202020202020202020202020202076617220636861727453656C656374696F6E203D2020';
wwv_flow_imp.g_varchar2_table(268) := '64332E73656C6563742820674368617274242E67657428302920293B0D0A2020202020202020202020202020202076617220746F6F6C74697053656C656374696F6E203D2064332E73656C656374282067546F6F6C746970242E67657428302920293B0D';
wwv_flow_imp.g_varchar2_table(269) := '0A0D0A0D0A202020202020202020202020202020202F2A0D0A20202020202020202020202020202020202A2041737369676E206F6E20656E7465722065666665637420746F20706F696E7420696E2063686172740D0A2020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(270) := '2020202A2040706172616D207B4F626A6563747D206F626A65637420444F4D20656C656D656E740D0A20202020202020202020202020202020202A0D0A20202020202020202020202020202020202A2F0D0A202020202020202020202020202020206675';
wwv_flow_imp.g_varchar2_table(271) := '6E6374696F6E205F706F696E74456E7465724576656E7428206F626A65637420297B0D0A20202020202020202020202020202020202020202F2F4F6E206D6F75736520686F766572206F6E206120706F696E742C20686964652074686520746F6F6C7469';
wwv_flow_imp.g_varchar2_table(272) := '7020616E642061737369676E207468697320656C656D656E74206173207468652063757272656E7420686F766572656420706F696E740D0A202020202020202020202020202020202020202067546F6F6C746970242E73746F7028292E66616465496E28';
wwv_flow_imp.g_varchar2_table(273) := '20704F7074696F6E732E7472616E736974696F6E73203F20313030203A203020293B0D0A202020202020202020202020202020202020202067486F7665726564506F696E74203D206F626A6563743B0D0A202020202020202020202020202020207D0D0A';
wwv_flow_imp.g_varchar2_table(274) := '0D0A202020202020202020202020202020202F2A0D0A20202020202020202020202020202020202A2041737369676E206F6E20666F6375732065666665637420746F20706F696E7420696E2063686172740D0A2020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(275) := '2A2040706172616D207B4F626A6563747D206F626A65637420444F4D20656C656D656E740D0A20202020202020202020202020202020202A2040706172616D207B4F626A6563747D206420443320656C656D656E740D0A20202020202020202020202020';
wwv_flow_imp.g_varchar2_table(276) := '202020202A2040706172616D207B4F626A6563747D20636861727453656C656374696F6E20443320656C656D656E740D0A20202020202020202020202020202020202A2040706172616D207B537472696E677D20666F637573436C61737320436C617373';
wwv_flow_imp.g_varchar2_table(277) := '20746F2061737369676E206F6E20666F6375730D0A20202020202020202020202020202020202A2F0D0A2020202020202020202020202020202066756E6374696F6E205F706F696E74466F6375734576656E7428206F626A6563742C20642C20666F6375';
wwv_flow_imp.g_varchar2_table(278) := '73436C61737320297B0D0A20202020202020202020202020202020202020202F2F4F6E20706F696E7420666F6375732C2061737369676E207468697320656C656D656E74206173207468652063757272656E7420666F637573656420706F696E740D0A20';
wwv_flow_imp.g_varchar2_table(279) := '202020202020202020202020202020202020202F2F67466F6375736564506F696E74203D202428206F626A65637420293B0D0A0D0A20202020202020202020202020202020202020202F2F496E6372656D656E7420636972636C65207261646975730D0A';
wwv_flow_imp.g_varchar2_table(280) := '202020202020202020202020202020202020202064332E73656C65637428206F626A65637420290D0A2020202020202020202020202020202020202020202020202E7472616E736974696F6E28292E6475726174696F6E2820504F494E545F5452414E53';
wwv_flow_imp.g_varchar2_table(281) := '4954494F4E5F4455524154494F4E20290D0A2020202020202020202020202020202020202020202020202E61747472282272222C20642E24726164697573202A20434952434C455F455850414E53494F4E5F464143544F52293B0D0A0D0A202020202020';
wwv_flow_imp.g_varchar2_table(282) := '20202020202020202020202020202F2F41737369676E207468697320736572696573206173207468652063757272656E74207365726965730D0A20202020202020202020202020202020202020206743757272656E74536572696573203D20642E736572';
wwv_flow_imp.g_varchar2_table(283) := '6965733B0D0A0D0A20202020202020202020202020202020202020202F2F41737369676E2074686520666F63757320636C61737320746F20746865206C696E652C206172656120616E6420706F696E7420636F6E7461696E657220746F20746865206375';
wwv_flow_imp.g_varchar2_table(284) := '7272656E74207365726965730D0A2020202020202020202020202020202020202020636861727453656C656374696F6E0D0A2020202020202020202020202020202020202020202020202E73656C656374416C6C2820272E27202B2043484152545F4C49';
wwv_flow_imp.g_varchar2_table(285) := '4E455F434C41535320290D0A2020202020202020202020202020202020202020202020202E736F72742866756E6374696F6E20286429207B0D0A2020202020202020202020202020202020202020202020202020202069662028642E7365726965732021';
wwv_flow_imp.g_varchar2_table(286) := '3D3D206743757272656E74536572696573292072657475726E202D313B0D0A20202020202020202020202020202020202020202020202020202020656C73652072657475726E20313B0D0A2020202020202020202020202020202020202020202020207D';
wwv_flow_imp.g_varchar2_table(287) := '290D0A2020202020202020202020202020202020202020202020202E636C6173736564282043484152545F4C494E455F434C415353202B20666F637573436C6173732C2066756E6374696F6E286429207B0D0A2020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(288) := '202020202020202020202072657475726E20642E73657269657320213D3D206743757272656E745365726965733B0D0A2020202020202020202020202020202020202020202020207D293B0D0A0D0A202020202020202020202020202020202020202063';
wwv_flow_imp.g_varchar2_table(289) := '6861727453656C656374696F6E0D0A2020202020202020202020202020202020202020202020202E73656C656374416C6C2820272E27202B2043484152545F415245415F434C41535320290D0A2020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(290) := '202E636C6173736564282043484152545F415245415F434C415353202B20666F637573436C6173732C2066756E6374696F6E286429207B0D0A2020202020202020202020202020202020202020202020202020202072657475726E20642E736572696573';
wwv_flow_imp.g_varchar2_table(291) := '20213D3D206743757272656E745365726965733B0D0A2020202020202020202020202020202020202020202020207D293B0D0A0D0A2020202020202020202020202020202020202020636861727453656C656374696F6E0D0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(292) := '202020202020202020202020202E73656C656374416C6C2820272E27202B2043484152545F504F494E545F434F4E5441494E45525F434C41535320290D0A2020202020202020202020202020202020202020202020202E736F72742866756E6374696F6E';
wwv_flow_imp.g_varchar2_table(293) := '20286429207B0D0A2020202020202020202020202020202020202020202020202020202069662028642E73657269657320213D3D206743757272656E74536572696573292072657475726E202D313B0D0A20202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(294) := '202020202020202020656C73652072657475726E20313B0D0A2020202020202020202020202020202020202020202020207D290D0A2020202020202020202020202020202020202020202020202E636C6173736564282043484152545F504F494E545F43';
wwv_flow_imp.g_varchar2_table(295) := '4F4E5441494E45525F434C415353202B20666F637573436C6173732C2066756E6374696F6E286429207B0D0A2020202020202020202020202020202020202020202020202020202072657475726E20642E73657269657320213D3D206743757272656E74';
wwv_flow_imp.g_varchar2_table(296) := '5365726965733B0D0A2020202020202020202020202020202020202020202020207D293B0D0A202020202020202020202020202020207D0D0A0D0A202020202020202020202020202020202F2A0D0A20202020202020202020202020202020202A204173';
wwv_flow_imp.g_varchar2_table(297) := '7369676E206F6E20686F7665722065666665637420746F20706F696E7420696E2063686172740D0A20202020202020202020202020202020202A2040706172616D207B4F626A6563747D206F626A65637420444F4D20656C656D656E740D0A2020202020';
wwv_flow_imp.g_varchar2_table(298) := '2020202020202020202020202A2040706172616D207B4F626A6563747D206420443320656C656D656E740D0A20202020202020202020202020202020202A2040706172616D207B4F626A6563747D20746F6F6C74697053656C656374696F6E2044332065';
wwv_flow_imp.g_varchar2_table(299) := '6C656D656E740D0A20202020202020202020202020202020202A2040706172616D207B537472696E677D20666F637573436C61737320436C61737320746F2061737369676E206F6E20666F6375730D0A20202020202020202020202020202020202A0D0A';
wwv_flow_imp.g_varchar2_table(300) := '20202020202020202020202020202020202A2F0D0A2020202020202020202020202020202066756E6374696F6E205F706F696E744F7665724576656E7428206F626A6563742C20642C20666F637573436C61737320297B0D0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(301) := '2020202020202020202F2F52656D6F766520666F63757320656666656374206966207468657265206973206120666F637573656420706F696E740D0A20202020202020202020202020202020202020206966282067466F6375736564506F696E7420297B';
wwv_flow_imp.g_varchar2_table(302) := '0D0A20202020202020202020202020202020202020202020202067466F6375736564506F696E742E626C757228293B0D0A20202020202020202020202020202020202020207D0D0A0D0A202020202020202020202020202020202020202064332E73656C';
wwv_flow_imp.g_varchar2_table(303) := '65637428206F626A65637420290D0A2020202020202020202020202020202020202020202020202E7472616E736974696F6E28292E6475726174696F6E2820504F494E545F5452414E534954494F4E5F4455524154494F4E20290D0A2020202020202020';
wwv_flow_imp.g_varchar2_table(304) := '202020202020202020202020202020202E61747472282272222C20642E24726164697573202A20434952434C455F455850414E53494F4E5F464143544F52293B0D0A0D0A202020202020202020202020202020202020202067486F7665726564506F696E';
wwv_flow_imp.g_varchar2_table(305) := '74203D206F626A6563743B0D0A202020202020202020202020202020202020202067546F6F6C746970436F6C6F72203D2077696E646F772E676574436F6D70757465645374796C6528206F626A65637420292E67657450726F706572747956616C756528';
wwv_flow_imp.g_varchar2_table(306) := '202766696C6C2720293B0D0A0D0A2020202020202020202020202020202020202020746F6F6C74697053656C656374696F6E0D0A2020202020202020202020202020202020202020202020202E646174756D28206420290D0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(307) := '202020202020202020202020202E63616C6C282067546F6F6C74697047656E657261746F7220293B0D0A0D0A202020202020202020202020202020202020202069662028202167546F6F6C746970242E697328273A76697369626C6527292029207B0D0A';
wwv_flow_imp.g_varchar2_table(308) := '20202020202020202020202020202020202020202020202067546F6F6C746970242E66616465496E28293B0D0A20202020202020202020202020202020202020207D0D0A0D0A202020202020202020202020202020202020202067546F6F6C746970242E';
wwv_flow_imp.g_varchar2_table(309) := '706F736974696F6E287B0D0A2020202020202020202020202020202020202020202020206D793A20276C6566742B32302063656E746572272C0D0A2020202020202020202020202020202020202020202020206F663A2064332E6576656E742C0D0A2020';
wwv_flow_imp.g_varchar2_table(310) := '2020202020202020202020202020202020202020202061743A202772696768742063656E746572272C0D0A20202020202020202020202020202020202020202020202077697468696E3A2067526567696F6E242C0D0A2020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(311) := '20202020202020202020636F6C6C6973696F6E3A2027666C697020666974270D0A20202020202020202020202020202020202020207D293B0D0A202020202020202020202020202020207D0D0A0D0A202020202020202020202020202020202F2A0D0A20';
wwv_flow_imp.g_varchar2_table(312) := '202020202020202020202020202020202A2041737369676E206C6561766520656666656374206F6E20706F696E7420696E2063686172742C206869646520746F6F6C74697020616E642067657420726164697573206261636B20746F20697473206F7269';
wwv_flow_imp.g_varchar2_table(313) := '67696E616C2073697A650D0A20202020202020202020202020202020202A2040706172616D207B4F626A6563747D206F626A65637420444F4D20656C656D656E740D0A20202020202020202020202020202020202A2040706172616D207B4F626A656374';
wwv_flow_imp.g_varchar2_table(314) := '7D206420443320656C656D656E740D0A20202020202020202020202020202020202A0D0A20202020202020202020202020202020202A2F0D0A2020202020202020202020202020202066756E6374696F6E205F706F696E744C656176654576656E742820';
wwv_flow_imp.g_varchar2_table(315) := '6F626A6563742C206420297B0D0A202020202020202020202020202020202020202067486F7665726564506F696E74203D206E756C6C3B0D0A202020202020202020202020202020202020202067546F6F6C746970242E73746F7028292E666164654F75';
wwv_flow_imp.g_varchar2_table(316) := '742820704F7074696F6E732E7472616E736974696F6E73203F20313030203A203020293B0D0A0D0A202020202020202020202020202020202020202064332E73656C65637428206F626A65637420290D0A20202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(317) := '20202020202E7472616E736974696F6E28292E6475726174696F6E2820504F494E545F5452414E534954494F4E5F4455524154494F4E20290D0A2020202020202020202020202020202020202020202020202E61747472282272222C20642E2472616469';
wwv_flow_imp.g_varchar2_table(318) := '7573293B0D0A202020202020202020202020202020207D0D0A0D0A202020202020202020202020202020202F2A0D0A20202020202020202020202020202020202A2041737369676E206F6E20626C75722065666665637420746F20706F696E7420696E20';
wwv_flow_imp.g_varchar2_table(319) := '63686172742C2072656D6F766520666F63757320636C61737365732C206869646520746F6F6C74697020616E64207265646566696E6520676C6F62616C207661726961626C65730D0A20202020202020202020202020202020202A2040706172616D207B';
wwv_flow_imp.g_varchar2_table(320) := '4F626A6563747D206F626A65637420444F4D20656C656D656E740D0A20202020202020202020202020202020202A2040706172616D207B4F626A6563747D2064204433206F626A6563740D0A20202020202020202020202020202020202A204070617261';
wwv_flow_imp.g_varchar2_table(321) := '6D207B4F626A6563747D20636861727453656C656374696F6E20443320656C656D656E740D0A20202020202020202020202020202020202A2040706172616D207B537472696E677D20666F637573436C61737320436C61737320746F2061737369676E20';
wwv_flow_imp.g_varchar2_table(322) := '6F6E20666F6375730D0A20202020202020202020202020202020202A200D0A20202020202020202020202020202020202A2F0D0A2020202020202020202020202020202066756E6374696F6E205F706F696E74426C75724576656E7428206F626A656374';
wwv_flow_imp.g_varchar2_table(323) := '2C20642C20666F637573436C61737320297B0D0A20202020202020202020202020202020202020202F2F67466F6375736564506F696E74203D206E756C6C3B0D0A202020202020202020202020202020202020202069662028202167486F766572656450';
wwv_flow_imp.g_varchar2_table(324) := '6F696E742029207B0D0A20202020202020202020202020202020202020202020202067546F6F6C746970242E73746F7028292E666164654F75742820704F7074696F6E732E7472616E736974696F6E73203F20313030203A203020293B0D0A2020202020';
wwv_flow_imp.g_varchar2_table(325) := '2020202020202020202020202020207D0D0A0D0A2020202020202020202020202020202020202020636861727453656C656374696F6E0D0A2020202020202020202020202020202020202020202020202E73656C656374416C6C2820272E272B43484152';
wwv_flow_imp.g_varchar2_table(326) := '545F4C494E455F434C41535320290D0A2020202020202020202020202020202020202020202020202E636C6173736564282043484152545F4C494E455F434C415353202B20666F637573436C6173732C2066616C7365293B0D0A0D0A2020202020202020';
wwv_flow_imp.g_varchar2_table(327) := '202020202020202020202020636861727453656C656374696F6E0D0A2020202020202020202020202020202020202020202020202E73656C656374416C6C2820272E272B43484152545F415245415F434C41535320290D0A202020202020202020202020';
wwv_flow_imp.g_varchar2_table(328) := '2020202020202020202020202E636C6173736564282043484152545F415245415F434C415353202B20666F637573436C6173732C2066616C7365293B0D0A0D0A2020202020202020202020202020202020202020636861727453656C656374696F6E0D0A';
wwv_flow_imp.g_varchar2_table(329) := '2020202020202020202020202020202020202020202020202E73656C656374416C6C2820272E272B43484152545F504F494E545F434F4E5441494E45525F434C41535320290D0A2020202020202020202020202020202020202020202020202E636C6173';
wwv_flow_imp.g_varchar2_table(330) := '736564282043484152545F504F494E545F434F4E5441494E45525F434C415353202B20666F637573436C6173732C2066616C7365293B0D0A0D0A202020202020202020202020202020202020202064332E73656C65637428206F626A65637420290D0A20';
wwv_flow_imp.g_varchar2_table(331) := '20202020202020202020202020202020202020202020202E7472616E736974696F6E28292E6475726174696F6E2820504F494E545F5452414E534954494F4E5F4455524154494F4E20290D0A202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(332) := '2E61747472282272222C20642E24726164697573293B0D0A202020202020202020202020202020207D0D0A0D0A202020202020202020202020202020202F2F42696E64206576656E74206566666563747320746F2074686520706F696E747320696E2074';
wwv_flow_imp.g_varchar2_table(333) := '68652067726170680D0A20202020202020202020202020202020674C696E6543686172740D0A20202020202020202020202020202020202020202E6F6E282027706F696E74656E746572272C2066756E6374696F6E2820642029207B0D0A202020202020';
wwv_flow_imp.g_varchar2_table(334) := '2020202020202020202020202020202020205F706F696E74456E7465724576656E742874686973293B0D0A20202020202020202020202020202020202020207D290D0A20202020202020202020202020202020202020202E6F6E282027706F696E74666F';
wwv_flow_imp.g_varchar2_table(335) := '637573272C2066756E6374696F6E2820642029207B0D0A2020202020202020202020202020202020202020202020205F706F696E74466F6375734576656E7428746869732C20642C20666F637573436C617373293B0D0A0D0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(336) := '202020202020202020202020202F2A0D0A202020202020202020202020202020202020202020202020202A20436865636B206966207468652063757272656E7420686F766572656420706F696E7420697320646966666572656E74207468616E20746865';
wwv_flow_imp.g_varchar2_table(337) := '206F626A656374207468617420747269676765726564207468697320706F696E74666F637573206576656E74200D0A202020202020202020202020202020202020202020202020202A206F7220696620746865206B657920646F776E206576656E742077';
wwv_flow_imp.g_varchar2_table(338) := '6173207472696767657265642C2073686F772074686520746F6F6C7469700D0A202020202020202020202020202020202020202020202020202A2F0D0A202020202020202020202020202020202020202020202020696628207468697320213D3D206748';
wwv_flow_imp.g_varchar2_table(339) := '6F7665726564506F696E74207C7C206749734B6579446F776E54726967676572656420297B0D0A202020202020202020202020202020202020202020202020202020205F73686F77546F6F6C74697028746869732C20746F6F6C74697053656C65637469';
wwv_flow_imp.g_varchar2_table(340) := '6F6E2C2064293B0D0A2020202020202020202020202020202020202020202020207D0D0A20202020202020202020202020202020202020207D290D0A20202020202020202020202020202020202020202E6F6E282027706F696E746F766572272C206675';
wwv_flow_imp.g_varchar2_table(341) := '6E6374696F6E2820642029207B0D0A2020202020202020202020202020202020202020202020205F706F696E744F7665724576656E7428746869732C20642C20666F637573436C617373293B0D0A20202020202020202020202020202020202020207D29';
wwv_flow_imp.g_varchar2_table(342) := '0D0A20202020202020202020202020202020202020202E6F6E282027706F696E746C65617665272C2066756E6374696F6E2820642029207B0D0A2020202020202020202020202020202020202020202020205F706F696E744C656176654576656E742874';
wwv_flow_imp.g_varchar2_table(343) := '6869732C2064293B0D0A20202020202020202020202020202020202020207D290D0A20202020202020202020202020202020202020202E6F6E282027706F696E74626C7572272C2066756E6374696F6E2820642029207B0D0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(344) := '202020202020202020202020205F706F696E74426C75724576656E7428746869732C20642C20666F637573436C617373293B0D0A20202020202020202020202020202020202020207D293B0D0A2020202020202020202020207D0D0A0D0A202020202020';
wwv_flow_imp.g_varchar2_table(345) := '2020202020202F2A200D0A202020202020202020202020202A2042696E64206576656E742068616E646C657220746F20746865206170657872656672657368206576656E7420666F7220746865206D61696E20726567696F6E20656C656D656E742E0D0A';
wwv_flow_imp.g_varchar2_table(346) := '202020202020202020202020202A2044796E616D696320616374696F6E732063616E207468656E20726566726573682074686520636861727420766961207468652027526566726573682720616374696F6E2E0D0A202020202020202020202020202A0D';
wwv_flow_imp.g_varchar2_table(347) := '0A202020202020202020202020202A20576520696D6D6564696174656C79207472696767657220746865206576656E7420697420746F206C6F61642074686520696E697469616C20636861727420646174612E0D0A202020202020202020202020202A2F';
wwv_flow_imp.g_varchar2_table(348) := '0D0A20202020202020202020202067526567696F6E240D0A202020202020202020202020202020202E6F6E2820226170657872656672657368222C205F7265667265736820290D0A202020202020202020202020202020202E7472696767657228202261';
wwv_flow_imp.g_varchar2_table(349) := '706578726566726573682220293B0D0A20202020202020207D0D0A0D0A20202020202020202F2A2A0D0A2020202020202020202A2043616C63756C61746573207265636F6D6D656E6465642068656967687420746F207072657365727665206173706563';
wwv_flow_imp.g_varchar2_table(350) := '7420726174696F6E0D0A2020202020202020202A204072657475726E207B4E756D6265727D205265636F6D6D656E64656420686569676874200D0A2020202020202020202A2F0D0A202020202020202066756E6374696F6E205F7265636F6D6D656E6465';
wwv_flow_imp.g_varchar2_table(351) := '644865696768742829207B0D0A202020202020202020202020766172206D696E4152203D20674F7074696F6E732E6D696E41523B0D0A202020202020202020202020766172206D61784152203D20674F7074696F6E732E6D617841523B0D0A2020202020';
wwv_flow_imp.g_varchar2_table(352) := '202020202020207661722077203D20674368617274242E776964746828293B0D0A2020202020202020202020207661722068203D2028674368617274242E6865696768742829203D3D3D203029203F2028772F6D6178415229203A20674368617274242E';
wwv_flow_imp.g_varchar2_table(353) := '68656967687428293B0D0A202020202020202020202020766172206172203D20772F683B0D0A202020202020202020202020696620286172203C206D696E415229207B0D0A2020202020202020202020202020202068203D20772F6D61784152202B2031';
wwv_flow_imp.g_varchar2_table(354) := '3B0D0A2020202020202020202020207D20656C736520696620286172203E206D6178415229207B0D0A2020202020202020202020202020202068203D20772F6D696E4152202D20313B0D0A2020202020202020202020207D0D0A20202020202020202020';
wwv_flow_imp.g_varchar2_table(355) := '202072657475726E204D6174682E6D617828674F7074696F6E732E6D696E4865696768742C204D6174682E6D696E28674F7074696F6E732E6D61784865696768742C206829293B0D0A20202020202020207D0D0A0D0A20202020202020202F2A2A0D0A20';
wwv_flow_imp.g_varchar2_table(356) := '20202020202020202A2052656E646572206368617274206F6E63652065766572797468696E6720697320696E697469616C697A656420696E205F696E69740D0A2020202020202020202A200D0A2020202020202020202A2F0D0A20202020202020206675';
wwv_flow_imp.g_varchar2_table(357) := '6E6374696F6E205F64726177282070446174612029207B0D0A2020202020202020202020202F2A0D0A202020202020202020202020202A2052656E6465727320746865206C6567656E642063616C63756C6174696E6720746865206E756D626572206F66';
wwv_flow_imp.g_varchar2_table(358) := '20636F6C756D6E7320746F2073686F772077697468207468652077696474682074686174206973206265696E67207061737365640D0A202020202020202020202020202A2040706172616D207B4E756D6265727D2077696474680D0A2020202020202020';
wwv_flow_imp.g_varchar2_table(359) := '20202020202A200D0A202020202020202020202020202A2F0D0A20202020202020202020202066756E6374696F6E205F72656E6465724C6567656E642820776964746820297B0D0A20202020202020202020202020202020674172792E6E756D6265724F';
wwv_flow_imp.g_varchar2_table(360) := '66436F6C756D6E7328204D6174682E6D617828204D6174682E666C6F6F7228207769647468202F204C4547454E445F434F4C554D4E5F574944544820292C2031202920293B0D0A0D0A2020202020202020202020202020202064332E73656C6563742820';
wwv_flow_imp.g_varchar2_table(361) := '674C6567656E64242E67657428302920290D0A20202020202020202020202020202020202020202E646174756D28206753657269657320290D0A20202020202020202020202020202020202020202E63616C6C28206741727920290D0A20202020202020';
wwv_flow_imp.g_varchar2_table(362) := '202020202020202020202020202E73656C656374416C6C2820272E612D443343686172744C6567656E642D6974656D2720290D0A20202020202020202020202020202020202020202E656163682866756E6374696F6E2028642C206929207B0D0A202020';
wwv_flow_imp.g_varchar2_table(363) := '20202020202020202020202020202020202020202064332E73656C65637428207468697320290D0A202020202020202020202020202020202020202020202020202020202E73656C656374416C6C2820272E612D443343686172744C6567656E642D6974';
wwv_flow_imp.g_varchar2_table(364) := '656D2D636F6C6F722720290D0A202020202020202020202020202020202020202020202020202020202E656163682866756E6374696F6E2829207B0D0A20202020202020202020202020202020202020202020202020202020202020207661722073656C';
wwv_flow_imp.g_varchar2_table(365) := '66203D2064332E73656C65637428207468697320293B0D0A202020202020202020202020202020202020202020202020202020202020202076617220636F6C6F72436C617373203D2073656C662E61747472282027636C6173732720292E6D6174636828';
wwv_flow_imp.g_varchar2_table(366) := '2F752D436F6C6F722D5C642B2D42472D2D62672F6729207C7C205B5D3B0D0A2020202020202020202020202020202020202020202020202020202020202020666F7220287661722069203D20636F6C6F72436C6173732E6C656E677468202D20313B2069';
wwv_flow_imp.g_varchar2_table(367) := '203E3D20303B20692D2D29207B0D0A20202020202020202020202020202020202020202020202020202020202020202020202073656C662E636C61737365642820636F6C6F72436C6173735B695D2C2066616C736520293B0D0A20202020202020202020';
wwv_flow_imp.g_varchar2_table(368) := '202020202020202020202020202020202020202020207D3B0D0A202020202020202020202020202020202020202020202020202020202020202073656C662E636C6173736564282027752D436F6C6F722D27202B2067436C6173735363616C652820642E';
wwv_flow_imp.g_varchar2_table(369) := '7365726965732029202B20272D42472D2D6267272C207472756520293B0D0A202020202020202020202020202020202020202020202020202020207D290D0A20202020202020202020202020202020202020207D293B0D0A202020202020202020202020';
wwv_flow_imp.g_varchar2_table(370) := '7D0D0A0D0A0D0A2020202020202020202020202F2F437265617465207265666572656E636520636F7079206F662070446174610D0A2020202020202020202020206744617461203D2070446174613B0D0A0D0A2020202020202020202020202F2F437265';
wwv_flow_imp.g_varchar2_table(371) := '61746520636F6C6F72206D617070696E67206F626A6563742069662074686520646174612073656E74206861766520636F6C6F727320696E666F726D6174696F6E0D0A20202020202020202020202067436F6C6F724D617070696E67203D207B7D3B0D0A';
wwv_flow_imp.g_varchar2_table(372) := '20202020202020202020202069662820674461746120297B0D0A20202020202020202020202020202020696620282067446174612E636F6C6F72732029207B0D0A2020202020202020202020202020202020202020666F7220287661722069203D206744';
wwv_flow_imp.g_varchar2_table(373) := '6174612E636F6C6F72732E6C656E677468202D20313B2069203E3D20303B20692D2D29207B0D0A20202020202020202020202020202020202020202020202067436F6C6F724D617070696E675B2067446174612E636F6C6F72735B695D2E736572696573';
wwv_flow_imp.g_varchar2_table(374) := '205D203D2067446174612E636F6C6F72735B695D2E636F6C6F723B0D0A20202020202020202020202020202020202020207D3B0D0A202020202020202020202020202020207D0D0A2020202020202020202020207D0D0A0D0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(375) := '202F2F44657465726D696E6520776964746820616E64207468726573686F6C64206F66207468652063686172206163636F7264696E6720746F207468652077696E646F772077696474680D0A2020202020202020202020207661722077203D2067436861';
wwv_flow_imp.g_varchar2_table(376) := '7274242E776964746828293B0D0A202020202020202020202020766172207468726573686F6C6457203D202820704F7074696F6E732E7468726573686F6C644F66203D3D3D202757494E444F57272029203F2024282077696E646F7720292E7769647468';
wwv_flow_imp.g_varchar2_table(377) := '2829203A20674368617274242E776964746828293B0D0A2020202020202020202020200D0A202020202020202020202020674C696E6543686172742E776964746828207720290D0A2020202020202020202020202020202020202020202020202E646973';
wwv_flow_imp.g_varchar2_table(378) := '706C61792820704F7074696F6E732E646973706C61792E746F4C6F77657243617365282920293B0D0A0D0A202020202020202020202020766172207468726573686F6C6444656661756C74203D20704F7074696F6E732E7468726573686F6C64207C7C20';
wwv_flow_imp.g_varchar2_table(379) := '3438303B0D0A0D0A2020202020202020202020202F2F536574206175746F6D61746963207469636B7320666F722074686520592041786973206F6620746865206368617274200D0A2020202020202020202020202F2F696620746865207468726573686F';
wwv_flow_imp.g_varchar2_table(380) := '6C642073657420627920746865206174747269627574652073656E7420697320626967676572207468616E20746865207468726573686F6C642074686174207468652077696E646F772063616E20686F6C6420616E64207468650D0A2020202020202020';
wwv_flow_imp.g_varchar2_table(381) := '202020202F2F726573706F6E73697665206265686176696F72206973207365742066726F6D2074686520726573706F6E73697665206174747269627574650D0A20202020202020202020202069662028207468726573686F6C6457203C20746872657368';
wwv_flow_imp.g_varchar2_table(382) := '6F6C6444656661756C7420262620704F7074696F6E732E726573706F6E736976652029207B0D0A20202020202020202020202020202020674C696E6543686172742E7941786973287B0D0A20202020202020202020202020202020202020207469636B73';
wwv_flow_imp.g_varchar2_table(383) := '3A20276175746F270D0A202020202020202020202020202020207D293B0D0A2020202020202020202020207D0D0A0D0A2020202020202020202020202F2F41737369676E20612070726F7065722068656967687420746F20746865206C696E6520636861';
wwv_flow_imp.g_varchar2_table(384) := '7274207468617420636F72726573706F6E647320746F2061206365727461696E2061737065637420726174696F0D0A202020202020202020202020674C696E6543686172740D0A202020202020202020202020202020202E68656967687428205F726563';
wwv_flow_imp.g_varchar2_table(385) := '6F6D6D656E646564486569676874282920293B0D0A0D0A2020202020202020202020202F2F46696C746572206461746120746F20676574206172726179206F6620746865207365726965732074686174206744617461206861730D0A2020202020202020';
wwv_flow_imp.g_varchar2_table(386) := '2020202067536572696573203D205F676574536572696573446174612867446174612E64617461293B0D0A0D0A2020202020202020202020202F2F43726561746520616E642072656E6465722063686172740D0A20202020202020202020202076617220';
wwv_flow_imp.g_varchar2_table(387) := '6368617274203D2064332E73656C6563742820674368617274242E67657428302920290D0A202020202020202020202020202020202E646174756D282067446174612E6461746120290D0A202020202020202020202020202020202E63616C6C2820674C';
wwv_flow_imp.g_varchar2_table(388) := '696E65436861727420293B0D0A0D0A2020202020202020202020202F2F41737369676E207468656D6520726F6C6C657220636C617373657320746F2063686172740D0A2020202020202020202020205F61737369676E5468656D65526F6C6C6572436C61';
wwv_flow_imp.g_varchar2_table(389) := '73736573286368617274293B0D0A0D0A2020202020202020202020206966202820704F7074696F6E732E73686F774C6567656E642029207B0D0A202020202020202020202020202020205F72656E6465724C6567656E642877293B0D0A20202020202020';
wwv_flow_imp.g_varchar2_table(390) := '20202020207D0D0A0D0A2020202020202020202020206753657269657353656C656374696F6E203D2064332E73656C6563742820674368617274242E67657428302920290D0A202020202020202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(391) := '20202E73656C656374416C6C2820272E27202B2043484152545F504F494E545F434F4E5441494E45525F434C41535320293B0D0A202020202020202020202020674F626A656374496E646578203D20303B0D0A0D0A202020202020202020202020696620';
wwv_flow_imp.g_varchar2_table(392) := '28202167486173486F6F6B65644576656E74732029207B0D0A202020202020202020202020202020205F6164644B6579426F617264537570706F727428293B0D0A202020202020202020202020202020202F2F49662063757272656E742062726F777365';
wwv_flow_imp.g_varchar2_table(393) := '7220697320496E7465726E6574204578706C6F7265720D0A20202020202020202020202020202020696620282049535F49452029207B0D0A202020202020202020202020202020202020202024282027636972636C65272C206743686172742420290D0A';
wwv_flow_imp.g_varchar2_table(394) := '2020202020202020202020202020202020202020202020202E6F6E282027666F637573272C2066756E6374696F6E28297B0D0A20202020202020202020202020202020202020202020202020202020674C696E6543686172742E6F6E282027706F696E74';
wwv_flow_imp.g_varchar2_table(395) := '666F6375732720292E63616C6C2820746869732C2064332E73656C65637428207468697320292E646174756D282920293B0D0A2020202020202020202020202020202020202020202020207D290D0A202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(396) := '2020202E6F6E282027626C7572272C2066756E6374696F6E28297B0D0A20202020202020202020202020202020202020202020202020202020636F6E736F6C652E6C6F672827626C757227293B0D0A202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(397) := '20202020202020674C696E6543686172742E6F6E282027706F696E74626C75722720292E63616C6C2820746869732C2064332E73656C65637428207468697320292E646174756D282920293B0D0A20202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(398) := '20207D293B0D0A202020202020202020202020202020207D0D0A2020202020202020202020207D0D0A20202020202020207D0D0A0D0A20202020202020202F2A2A0D0A202020202020202020202A20457865637574657320617065782073657276657220';
wwv_flow_imp.g_varchar2_table(399) := '706C7567696E2066756E6374696F6E616C69746965730D0A202020202020202020202A200D0A202020202020202020202A2F0D0A202020202020202066756E6374696F6E205F726566726573682829207B0D0A2020202020202020202020207661722073';
wwv_flow_imp.g_varchar2_table(400) := '7461727454696D65203D20446174652E6E6F7728293B0D0A0D0A202020202020202020202020202020207365727665722E706C7567696E2820674F7074696F6E732E616A61784964656E7469666965722C0D0A202020202020202020202020202020207B';
wwv_flow_imp.g_varchar2_table(401) := '0D0A2020202020202020202020202020202020202020706167654974656D733A20674F7074696F6E732E706167654974656D730D0A202020202020202020202020202020207D2C207B0D0A20202020202020202020202020202020202020207265667265';
wwv_flow_imp.g_varchar2_table(402) := '73684F626A6563743A2067526567696F6E242C0D0A2020202020202020202020202020202020202020737563636573733A2020202020202066756E6374696F6E286461746129207B0D0A2020202020202020202020202020202020202020202020207661';
wwv_flow_imp.g_varchar2_table(403) := '7220746F74616C54696D65203D20446174652E6E6F772829202D20737461727454696D653B0D0A2020202020202020202020202020202020202020202020200D0A2020202020202020202020202020202020202020202020205F64726177286461746129';
wwv_flow_imp.g_varchar2_table(404) := '3B0D0A0D0A20202020202020202020202020202020202020202020202067526567696F6E242E747269676765722827656C617073656474696D6566657463686564272C207B656C617073656454696D654D733A20746F74616C54696D657D293B0D0A2020';
wwv_flow_imp.g_varchar2_table(405) := '2020202020202020202020202020202020207D2C0D0A20202020202020202020202020202020202020206C6F6164696E67496E64696361746F723A202020202020202020674368617274242C0D0A20202020202020202020202020202020202020206C6F';
wwv_flow_imp.g_varchar2_table(406) := '6164696E67496E64696361746F72506F736974696F6E3A2022617070656E64220D0A202020202020202020202020202020207D293B0D0A0D0A20202020202020207D0D0A20202020202020205F696E6974282070526567696F6E49642C20704F7074696F';
wwv_flow_imp.g_varchar2_table(407) := '6E7320293B0D0A202020207D3B0D0A0D0A7D292820617065782E7574696C2C20617065782E7365727665722C20617065782E6A51756572792C20643320293B';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(40402272706097954338)
,p_plugin_id=>wwv_flow_imp.id(37188309159362658648)
,p_file_name=>'com.oracle.apex.d3.linechart.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
