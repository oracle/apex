prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7210
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(40701644573702766027)
,p_name=>'ADMINISTRATION'
,p_message_text=>'Administration'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(40701648675434766569)
,p_name=>'HELP'
,p_message_text=>'Help'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(37344677054142502860)
,p_name=>'HELP_SIDEBAR'
,p_message_text=>'<h1 class="appNameHeader"> <img src="%0f_spacer.gif" class="appIcon %1" alt="" /> %2 </h1> <ul class="vapList"> <li> <span class="vLabel">App Version</span> <span class="vValue">%3</span> </li> <li> <span class="vLabel">Pages</span> <span class="vVal'
||'ue">%4</span> </li> <li> <span class="vLabel">Vendor</span> <span class="vValue">%5 </span> </li> </ul>'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(40701652778204767309)
,p_name=>'LOGOUT'
,p_message_text=>'Logout'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(36673752374752567935)
,p_name=>'N_DAY'
,p_message_text=>'%0 day'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(36673752573027568774)
,p_name=>'N_DAYS'
,p_message_text=>'%0 days'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(36673752770007570187)
,p_name=>'N_HOUR'
,p_message_text=>'%0 hour'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(36673752967204571413)
,p_name=>'N_HOURS'
,p_message_text=>'%0 hours'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(36673753163969572973)
,p_name=>'N_MINUTES'
,p_message_text=>'%0 minutes'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(36673753361381574116)
,p_name=>'N_WEEK'
,p_message_text=>'%0 week'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(36673753558146575683)
,p_name=>'N_WEEKS'
,p_message_text=>'%0 weeks'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(40829375459873540408)
,p_name=>'USER'
,p_message_text=>'User'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
