prompt --application/pages/page_00040
begin
--   Manifest
--     PAGE: 00040
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1867060655981638216
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>40
,p_name=>'Reset Sample Data'
,p_alias=>'RESET-SAMPLE-DATA'
,p_step_title=>'Reset Sample Data'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(39705658119970958190)
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>'<p>Select a data reset option.  Clicking the link will immedatly truncate all existing data and generate new data.</p>'
,p_page_component_map=>'17'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20230329140204'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38752353076270724155)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36221633771453191739)
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44348825400536455772)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(36221729672514191835)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38752356453864741297)
,p_plug_name=>'Manage Sample Data'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36221590537326191705)
,p_plug_display_sequence=>11
,p_list_id=>wwv_flow_imp.id(38752355067133741287)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(36221709352423191806)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38983888261782301864)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38752353076270724155)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(36221727379520191830)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(39961863368741015476)
,p_branch_name=>'Go to page 41'
,p_branch_action=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:RP:P41_SIZE:&P40_SIZE.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39961863470391015477)
,p_name=>'P40_SIZE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38752356453864741297)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
