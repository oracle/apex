prompt --application/pages/page_00030
begin
--   Manifest
--     PAGE: 00030
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.13'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1472955480067066
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>30
,p_name=>'Transaction'
,p_step_title=>'Transaction'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'<p>Loading the page will cause a transaction to be completed.  Reload the page to generate another transaction.  Pressing the button will not post the page simply reload the page.</p>'
,p_page_component_map=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38815924470546842309)
,p_plug_name=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44425078801060133467)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38815925272448853570)
,p_plug_name=>'Generate One Transaction on Page Load'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38815925650538853571)
,p_plug_name=>'show last generation'
,p_parent_plug_id=>wwv_flow_imp.id(38815925272448853570)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    x number;',
'begin',
'   begin',
'       x := oow_demo_gen_data_pkg.generate_transaction;',
'       sys.htp.p(''<br><strong>Transaction</strong> "''||x||''" completed'');',
'   exception when others then',
'       sys.htp.p(''<br>unexpected error: ''|| apex_escape.html( sqlerrm ));',
'   end;',
'',
'   for c1 in (select id,',
'                     store_id, ',
'                     created_on,',
'                     product_id, ',
'                     quantity, ',
'                     item_price,',
'                     date_of_sale,',
'                     (select store_name ',
'                      from OOW_demo_stores s ',
'                      where s.id = h.store_id) store,',
'                     (select item_Name from OOW_demo_items i',
'                      where i.id = h.product_id) product,',
'                     SALES_DATA ',
'              from oow_demo_sales_history h',
'              where id = x) loop',
'     sys.htp.p(''<br /><strong>ID</strong>: ''||apex_escape.html(c1.id));',
'     sys.htp.p(''<br /><strong>Store</strong>: ''||apex_escape.html(c1.store));',
'     sys.htp.p(''<br /><strong>Product</strong>: ''||apex_escape.html(c1.product));',
'     sys.htp.p(''<br /><strong>Date of Sale</strong>: ''||to_char(c1.date_of_sale,''DD-MON-YYYY HH24:MI:SS''));',
'     sys.htp.p(''<br /><strong>Date of Posting</strong>: ''||to_char(c1.created_on,''DD-MON-YYYY HH24:MI:SS''));',
'',
'     sys.htp.p(''<br /><strong>Quantity</strong>: ''||to_char(c1.quantity,''999G999G999G990''));',
'     sys.htp.p(''<br /><strong>Price</strong>: ''||to_char(c1.item_price,''$999G999G999G990D00''));',
'     sys.htp.p(''<br /><strong>Sale</strong>: ''||to_char(c1.item_price * c1.quantity,''$999G999G999G990D00''));',
'   end loop;',
'',
'exception when others then',
'  sys.htp.prn( apex_escape.html( sqlerrm ) );',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38815927064576872731)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(38815924470546842309)
,p_button_name=>'refresh_page'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Refresh Page'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39065574909259736240)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38815924470546842309)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38815925473214853571)
,p_name=>'P30_TRANSACTION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38815925272448853570)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38816033148290895481)
,p_name=>'P30_AUTOREFRESH'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(38815925272448853570)
,p_prompt=>'Auto-Refresh'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'AUTO REFRESH'
,p_lov=>'.'||wwv_flow_imp.id(38816034175957950751)||'.'
,p_tag_css_classes=>'mnw180'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '5',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38816033275649903352)
,p_name=>'Set Auto-Refresh'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P30_AUTOREFRESH'
,p_condition_element=>'P30_AUTOREFRESH'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38816033761581908770)
,p_event_id=>wwv_flow_imp.id(38816033275649903352)
,p_event_result=>'TRUE'
,p_action_sequence=>5
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P30_AUTOREFRESH'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38816033551236903353)
,p_event_id=>wwv_flow_imp.id(38816033275649903352)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'setTimeout("location.reload(true);",1000 * $v(''P30_AUTOREFRESH''));'
);
wwv_flow_imp.component_end;
end;
/
