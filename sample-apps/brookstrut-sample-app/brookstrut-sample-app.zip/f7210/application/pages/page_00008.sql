prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'Store Regions'
,p_alias=>'STORE-REGIONS'
,p_step_title=>'Store Regions'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(26504766115420059036)
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'18'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20240104213104'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25520829932957964200)
,p_plug_name=>'Store Regions'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(23021775374292329568)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id, ',
'       region_name, ',
'       is_default, ',
'       stores, ',
'       sales_trailing_30_days, ',
'       sales_prior_30_days,',
'       nvl(sales_trailing_30_days,0) - nvl(sales_prior_30_days,0) sales_trend,',
'       decode(nvl(sales_prior_30_days,0),0,null,',
'          round(nvl(sales_trailing_30_days,0) / nvl(sales_prior_30_days,0),2)) sales_trend_percentage,',
'       to_number(decode(stores,0,0,sales_trailing_30_days/stores)) avg_store_sales,',
'       REGION_LAT,',
'       REGION_LNG',
'from (',
'--',
'-- inline view',
'--',
'select r.ID, ',
'       r.REGION_NAME,',
'       decode(r.is_default_yn,''Y'',''Yes'',''No'') is_default,',
'       --',
'       nvl((select count(*) ',
'            from #OWNER#.OOW_DEMO_STORES s ',
'            where s.region_id = r.id),0) stores,',
'       --',
'       (select sum(QUANTITY*ITEM_PRICE) qp ',
'        from #OWNER#.OOW_DEMO_SALES_HISTORY h ',
'        where DATE_OF_SALE > sysdate - 30 and ',
'              h.store_id in (select id from OOW_DEMO_STORES s where s.region_id = r.id)) sales_trailing_30_days,',
'        --',
'        (select sum(QUANTITY*ITEM_PRICE) qp ',
'        from #OWNER#.OOW_DEMO_SALES_HISTORY h ',
'        where DATE_OF_SALE > sysdate - 60 and ',
'              date_of_sale < sysdate - 30 and',
'              h.store_id in (select id from OOW_DEMO_STORES s where s.region_id = r.id)) sales_prior_30_days,',
'        --',
'        REGION_LAT,',
'        REGION_LNG',
'from #OWNER#.OOW_DEMO_REGIONS r',
') ilv',
'  '))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(25520830135740964200)
,p_name=>'Map Regions'
,p_max_row_count=>'100000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_owner=>'MIKE'
,p_internal_uid=>2708389615873260088
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(25520830251948964205)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(25520830325433964235)
,p_db_column_name=>'REGION_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Region'
,p_column_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:RP,:P15_REGION_ID:#ID#'
,p_column_linktext=>'#REGION_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(25523508320161668458)
,p_db_column_name=>'IS_DEFAULT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Is Default'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(25782857510291632317)
,p_db_column_name=>'STORES'
,p_display_order=>16
,p_column_identifier=>'G'
,p_column_label=>'Stores'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(25782857594858632318)
,p_db_column_name=>'SALES_TRAILING_30_DAYS'
,p_display_order=>26
,p_column_identifier=>'H'
,p_column_label=>'Sales Trailing 30 Days'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(25782857784263632320)
,p_db_column_name=>'AVG_STORE_SALES'
,p_display_order=>36
,p_column_identifier=>'J'
,p_column_label=>'Average Sales per Store'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26300976040593870326)
,p_db_column_name=>'SALES_PRIOR_30_DAYS'
,p_display_order=>46
,p_column_identifier=>'K'
,p_column_label=>'Sales Prior 30 Days'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26300976117458870327)
,p_db_column_name=>'SALES_TREND'
,p_display_order=>56
,p_column_identifier=>'L'
,p_column_label=>'Sales Trend'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8051842643835475459)
,p_db_column_name=>'SALES_TREND_PERCENTAGE'
,p_display_order=>66
,p_column_identifier=>'O'
,p_column_label=>'Sales Trend Percentage'
,p_column_html_expression=>'#SALES_TREND_PERCENTAGE#%'
,p_column_type=>'STRING'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'S999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7387293769763372407)
,p_db_column_name=>'REGION_LAT'
,p_display_order=>76
,p_column_identifier=>'M'
,p_column_label=>'Region Lat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7387293922625372408)
,p_db_column_name=>'REGION_LNG'
,p_display_order=>86
,p_column_identifier=>'N'
,p_column_label=>'Region Lng'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(25520831720967964368)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'27083913'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'REGION_NAME:STORES:SALES_TRAILING_30_DAYS:SALES_PRIOR_30_DAYS:SALES_TREND:AVG_STORE_SALES:'
,p_sort_column_1=>'AVG_STORE_SALES'
,p_sort_direction_1=>'DESC'
,p_sum_columns_on_break=>'SALES_TRAILING_30_DAYS:STORES:SALES_PRIOR_30_DAYS:SALES_TREND'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25520830945080964236)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(23021795045616329582)
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(31148986674699593615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(23021890946677329678)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25520830852620964236)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(25520830945080964236)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(23021889439521329676)
,p_button_image_alt=>'Add Region'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:9::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25521165827005357859)
,p_button_sequence=>4
,p_button_plug_id=>wwv_flow_imp.id(25520829932957964200)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(23021889439521329676)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:8,RIR::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25779476804401040455)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(25520830945080964236)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(23021888653683329673)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp.component_end;
end;
/
