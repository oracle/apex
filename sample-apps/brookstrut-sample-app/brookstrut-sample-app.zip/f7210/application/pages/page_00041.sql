prompt --application/pages/page_00041
begin
--   Manifest
--     PAGE: 00041
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1867060655981638216
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>41
,p_tab_set=>'TS1'
,p_name=>'Load Data'
,p_step_title=>'Load Data'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_nav_list_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20240310193039'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(13877665512803010921)
,p_name=>'Summary'
,p_template=>wwv_flow_imp.id(36221589052025191704)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo-item--stacked:t-ContextualInfo-label--stacked'
,p_display_point=>'REGION_POSITION_01'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'select max(created_on) last_order from OOW_DEMO_SALES_HISTORY'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(36221680368335191776)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13877665574775010922)
,p_query_column_id=>1
,p_column_alias=>'LAST_ORDER'
,p_column_display_sequence=>10
,p_column_heading=>'Last Order'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38752362775604863969)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36221633771453191739)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44348825400536455772)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(36221729672514191835)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38752363170915865378)
,p_plug_name=>'Hidden Items'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36221590537326191705)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(39500816335493732498)
,p_name=>'Results'
,p_template=>wwv_flow_imp.id(36221590537326191705)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--cols t-BadgeList--3cols'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    (select count(*) c from OOW_DEMO_SALES_HISTORY) rows_generated,',
'    (select count(distinct STORE_ID) from OOW_DEMO_SALES_HISTORY) distinct_stores,',
'    (select count(distinct PRODUCT_ID) from OOW_DEMO_SALES_HISTORY) distinct_products,',
'    :P41_SIZE requested_size,',
'    to_number(:P41_ROWS) rows_requested,',
'    :P41_ORDERS requested_orders,',
'    to_number(:P41_LOAD_TIME) load_time_milliseconds,',
'    to_number(:P41_LOAD_TIME) / 1000 load_time_seconds,',
'    to_number(:P41_ROWS) / (to_number(:P41_LOAD_TIME) / 1000) rows_per_second',
'from dual'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(36221675033197191772)
,p_query_num_rows=>4
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39500816392302732499)
,p_query_column_id=>1
,p_column_alias=>'ROWS_GENERATED'
,p_column_display_sequence=>40
,p_column_heading=>'Rows Generated'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13877665322359010919)
,p_query_column_id=>2
,p_column_alias=>'DISTINCT_STORES'
,p_column_display_sequence=>60
,p_column_heading=>'Distinct Stores'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13877665364090010920)
,p_query_column_id=>3
,p_column_alias=>'DISTINCT_PRODUCTS'
,p_column_display_sequence=>70
,p_column_heading=>'Distinct Products'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39500816469460732500)
,p_query_column_id=>4
,p_column_alias=>'REQUESTED_SIZE'
,p_column_display_sequence=>20
,p_column_heading=>'Requested Size'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39500816571170732501)
,p_query_column_id=>5
,p_column_alias=>'ROWS_REQUESTED'
,p_column_display_sequence=>30
,p_column_heading=>'Rows Requested'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39500816699435732502)
,p_query_column_id=>6
,p_column_alias=>'REQUESTED_ORDERS'
,p_column_display_sequence=>50
,p_column_heading=>'Requested Orders'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39500817463903732510)
,p_query_column_id=>7
,p_column_alias=>'LOAD_TIME_MILLISECONDS'
,p_column_display_sequence=>80
,p_column_heading=>'Load Time Milliseconds'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39500817563808732511)
,p_query_column_id=>8
,p_column_alias=>'LOAD_TIME_SECONDS'
,p_column_display_sequence=>90
,p_column_heading=>'Load Time Seconds'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990D0'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39500817671738732512)
,p_query_column_id=>9
,p_column_alias=>'ROWS_PER_SECOND'
,p_column_display_sequence=>100
,p_column_heading=>'Rows Loaded Per Second'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13177261195337766062)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38752362775604863969)
,p_button_name=>'Reload'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(36221728165358191833)
,p_button_image_alt=>'Reload Data'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39726865990390122667)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38752362775604863969)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(36221727379520191830)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38752363567845892926)
,p_name=>'P41_SIZE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38752363170915865378)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39500815946813732495)
,p_name=>'P41_ROWS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(38752363170915865378)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39500816130949732496)
,p_name=>'P41_DAYS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(38752363170915865378)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39500816207595732497)
,p_name=>'P41_ORDERS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(38752363170915865378)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39500817406142732509)
,p_name=>'P41_LOAD_TIME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(38752363170915865378)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39500816793223732503)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'setup and truncate'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    s number := 0;',
'    o number := 0;',
'    d number := 0;',
'    t1 timestamp;',
'    t2 timestamp;',
'begin',
'    if :P41_SIZE = ''S'' then ',
'       s := 500; -- max',
'       d := 365; -- days',
'       o := 2; -- orders',
'    elsif :P41_SIZE = ''M'' then ',
'       s := 1000;',
'       d := 365;',
'       o := 3;',
'    elsif :P41_SIZE = ''L'' then ',
'       s := 5000;',
'       d := 365;',
'       o := 5;',
'    elsif :P41_SIZE = ''XL'' then ',
'       s := 25000;',
'       d := 365;',
'       o := 25;',
'    elsif :P41_SIZE = ''XXL'' then ',
'       s := 50000;',
'       d := 365;',
'       o := 50;',
'    elsif :P41_SIZE = ''XXXL'' then ',
'       s := 100000;',
'       d := 365;',
'       o := 100;',
'    elsif :P41_SIZE = ''4XL'' then ',
'       s := 1000000;',
'       d := 365;',
'       o := 100;',
'    elsif :P41_SIZE = ''5XL'' then ',
'       s := 5000000;',
'       d := 365;',
'       o := 100;',
'    end if;',
'    :P41_ROWS := s;',
'    :P41_ORDERS := o;',
'    :P41_DAYS := d;',
'',
'    execute immediate ''truncate table OOW_DEMO_SALES_HISTORY'';',
'   ',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>17354507511770098988
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39500816920180732504)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Generate Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    t1 timestamp := systimestamp;',
'    t2 timestamp;',
'',
'begin',
'    oow_demo_gen_data_pkg.oow_demo_gen_sales_data (',
'          p_days      => :P41_DAYS,',
'          p_orders    => :P41_ORDERS,',
'          p_truncate  =>''N'',',
'          p_max_rows  => :P41_ROWS);',
'    t2 := systimestamp;',
'    for c1 in (',
'        select',
'           extract( day from diff )*24*60*60*1000 +',
'           extract( hour from diff )*60*60*1000 +',
'           extract( minute from diff )*60*1000 +',
'           round(extract( second from diff )*1000) total_milliseconds',
'        from (select t2 - t1 diff from dual)',
'    ) loop',
'    :P41_LOAD_TIME := c1.total_milliseconds;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>17354507638727098989
);
wwv_flow_imp.component_end;
end;
/
