prompt --application/pages/page_00041
begin
--   Manifest
--     PAGE: 00041
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>41
,p_name=>'Load Data'
,p_step_title=>'Load Data'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38828616176128541664)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(44425078801060133467)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38828616571439543073)
,p_plug_name=>'Hidden Items'
,p_static_id=>'hidden-items'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(39577069736017410193)
,p_name=>'Results'
,p_static_id=>'results'
,p_template=>3372714138756020509
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--cols t-BadgeList--3cols'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    (select count(*) c from OOW_DEMO_SALES_HISTORY) rows_generated,',
'    (select count(distinct STORE_ID) from OOW_DEMO_SALES_HISTORY) distinct_stores,',
'    (select count(distinct PRODUCT_ID) from OOW_DEMO_SALES_HISTORY) distinct_products,',
'    :P41_SIZE requested_size,',
'    to_number(:P41_ROWS) rows_requested,',
'    :P41_ORDERS requested_orders,',
'    to_number(:P41_LOAD_TIME) load_time_milliseconds,',
'    to_number(:P41_LOAD_TIME) / 1000 load_time_seconds,',
'    to_number(:P41_ROWS) / (to_number(:P41_LOAD_TIME) / 1000) rows_per_second',
'from dual'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2106120299521025145
,p_query_num_rows=>4
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13953918764613688615)
,p_query_column_id=>3
,p_column_alias=>'DISTINCT_PRODUCTS'
,p_column_display_sequence=>70
,p_column_heading=>'Distinct Products'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13953918722882688614)
,p_query_column_id=>2
,p_column_alias=>'DISTINCT_STORES'
,p_column_display_sequence=>60
,p_column_heading=>'Distinct Stores'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39577070864427410205)
,p_query_column_id=>7
,p_column_alias=>'LOAD_TIME_MILLISECONDS'
,p_column_display_sequence=>80
,p_column_heading=>'Load Time Milliseconds'
,p_column_format=>'999G999G999G999G999G999G990'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39577070964332410206)
,p_query_column_id=>8
,p_column_alias=>'LOAD_TIME_SECONDS'
,p_column_display_sequence=>90
,p_column_heading=>'Load Time Seconds'
,p_column_format=>'999G999G999G999G999G999G990D0'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39577070099959410197)
,p_query_column_id=>6
,p_column_alias=>'REQUESTED_ORDERS'
,p_column_display_sequence=>50
,p_column_heading=>'Requested Orders'
,p_column_format=>'999G999G999G999G999G999G990'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39577069869984410195)
,p_query_column_id=>4
,p_column_alias=>'REQUESTED_SIZE'
,p_column_display_sequence=>20
,p_column_heading=>'Requested Size'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39577069792826410194)
,p_query_column_id=>1
,p_column_alias=>'ROWS_GENERATED'
,p_column_display_sequence=>40
,p_column_heading=>'Rows Generated'
,p_column_format=>'999G999G999G999G999G999G990'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39577071072262410207)
,p_query_column_id=>9
,p_column_alias=>'ROWS_PER_SECOND'
,p_column_display_sequence=>100
,p_column_heading=>'Rows Loaded Per Second'
,p_column_format=>'999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39577069971694410196)
,p_query_column_id=>5
,p_column_alias=>'ROWS_REQUESTED'
,p_column_display_sequence=>30
,p_column_heading=>'Rows Requested'
,p_column_format=>'999G999G999G999G999G999G990'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(13953918913326688616)
,p_name=>'Summary'
,p_static_id=>'summary'
,p_template=>4502917002193490937
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo-item--stacked:t-ContextualInfo-label--stacked'
,p_display_point=>'REGION_POSITION_01'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'select max(created_on) last_order from OOW_DEMO_SALES_HISTORY'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2117249020861433971
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13953918975298688617)
,p_query_column_id=>1
,p_column_alias=>'LAST_ORDER'
,p_column_display_sequence=>10
,p_column_heading=>'Last Order'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13253514595861443757)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38828616176128541664)
,p_button_name=>'Reload'
,p_static_id=>'reload'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Reload Data'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39803119390913800362)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38828616176128541664)
,p_button_name=>'up'
,p_static_id=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39577069531473410191)
,p_name=>'P41_DAYS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(38828616571439543073)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39577070806666410204)
,p_name=>'P41_LOAD_TIME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(38828616571439543073)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39577069608119410192)
,p_name=>'P41_ORDERS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(38828616571439543073)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39577069347337410190)
,p_name=>'P41_ROWS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(38828616571439543073)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38828616968369570621)
,p_name=>'P41_SIZE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38828616571439543073)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39577070320704410199)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Generate Data'
,p_static_id=>'generate-data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    t1 timestamp := systimestamp;',
'    t2 timestamp;',
'',
'begin',
'    oow_demo_gen_data_pkg.oow_demo_gen_sales_data (',
'          p_days      => :P41_DAYS,',
'          p_orders    => :P41_ORDERS,',
'          p_truncate  =>''N'',',
'          p_max_rows  => :P41_ROWS);',
'    t2 := systimestamp;',
'    for c1 in (',
'        select',
'           extract( day from diff )*24*60*60*1000 +',
'           extract( hour from diff )*60*60*1000 +',
'           extract( minute from diff )*60*1000 +',
'           round(extract( second from diff )*1000) total_milliseconds',
'        from (select t2 - t1 diff from dual)',
'    ) loop',
'    :P41_LOAD_TIME := c1.total_milliseconds;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>17354507638727098989
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39577070193747410198)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'setup and truncate'
,p_static_id=>'setup-and-truncate'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    s number := 0;',
'    o number := 0;',
'    d number := 0;',
'    t1 timestamp;',
'    t2 timestamp;',
'begin',
'    if :P41_SIZE = ''S'' then ',
'       s := 500; -- max',
'       d := 365; -- days',
'       o := 2; -- orders',
'    elsif :P41_SIZE = ''M'' then ',
'       s := 1000;',
'       d := 365;',
'       o := 3;',
'    elsif :P41_SIZE = ''L'' then ',
'       s := 5000;',
'       d := 365;',
'       o := 5;',
'    elsif :P41_SIZE = ''XL'' then ',
'       s := 25000;',
'       d := 365;',
'       o := 25;',
'    elsif :P41_SIZE = ''XXL'' then ',
'       s := 50000;',
'       d := 365;',
'       o := 50;',
'    elsif :P41_SIZE = ''XXXL'' then ',
'       s := 100000;',
'       d := 365;',
'       o := 100;',
'    elsif :P41_SIZE = ''4XL'' then ',
'       s := 1000000;',
'       d := 365;',
'       o := 100;',
'    elsif :P41_SIZE = ''5XL'' then ',
'       s := 5000000;',
'       d := 365;',
'       o := 100;',
'    end if;',
'    :P41_ROWS := s;',
'    :P41_ORDERS := o;',
'    :P41_DAYS := d;',
'',
'    execute immediate ''truncate table OOW_DEMO_SALES_HISTORY'';',
'   ',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>17354507511770098988
);
wwv_flow_imp.component_end;
end;
/
