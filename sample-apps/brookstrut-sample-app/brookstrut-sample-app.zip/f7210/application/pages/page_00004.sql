prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Administration'
,p_alias=>'SETTINGS'
,p_step_title=>'Administration'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(39697203715304422150)
,p_page_css_classes=>'rw-pillar--sienna'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'06'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20231214225151'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38716046889499493900)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36214331598922080100)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44341523228005344133)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(36214427499983080196)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38716051683372516412)
,p_plug_name=>'Administration and Settings'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36214288364795080066)
,p_plug_display_sequence=>10
,p_list_id=>wwv_flow_imp.id(38716050283434516409)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(36214407179892080167)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38971963458080772026)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38716046889499493900)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(36214425206989080191)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp.component_end;
end;
/
