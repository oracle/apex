prompt --application/pages/page_00051
begin
--   Manifest
--     PAGE: 00051
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>51
,p_name=>'Sales History Interactive Report'
,p_alias=>'SALES-HISTORY-CLASSIC-IR'
,p_step_title=>'Sales History IR'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(39697161046911420840)
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'25'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20240313211211'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49213243512333924355)
,p_plug_name=>'Timer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36214288364795080066)
,p_plug_display_sequence=>30
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   x clob;',
'begin',
'    x := to_char(oow_demo_timing.get_elap,''99G9990D000'')||'' seconds'';',
'    return x;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(62749638186305185143)
,p_plug_name=>'Sales History'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36214311927598080086)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    h.ID            id,',
'    r.REGION_NAME   region,',
'    s.store_name    store,',
'    i.item_Name     product,',
'    h.DATE_OF_SALE,',
'    to_char(h.DATE_OF_SALE,''YYYY.MM'') the_month,',
'    h.QUANTITY,',
'    h.TRANSACTION_ID,',
'    h.ITEM_PRICE,',
'    h.QUANTITY * h.ITEM_PRICE sale,',
'    i.id product_id,',
'    s.id store_id',
'from #OWNER#.OOW_DEMO_SALES_HISTORY h,',
'     #OWNER#.OOW_DEMO_REGIONS r,',
'     #OWNER#.OOW_DEMO_STORES s,',
'     #OWNER#.OOW_DEMO_STORE_PRODUCTS p,',
'     #OWNER#.OOW_DEMO_ITEMS i',
'where s.region_id = r.id and',
'      h.store_id = s.id and',
'      p.ITEM_ID = h.PRODUCT_ID and',
'      p.item_id = i.id',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Sales History'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(13873963355513450498)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MIKE'
,p_internal_uid=>12014204872062923921
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13873963475145450499)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Transaction Line Item ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13873963572426450500)
,p_db_column_name=>'REGION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Region'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13873963592253450501)
,p_db_column_name=>'STORE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Store'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13873963686041450502)
,p_db_column_name=>'PRODUCT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Product'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13873963803328450503)
,p_db_column_name=>'DATE_OF_SALE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Date of Sale'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13873963891969450504)
,p_db_column_name=>'THE_MONTH'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'The Month'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13873964058364450505)
,p_db_column_name=>'QUANTITY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Quantity'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13873964117902450506)
,p_db_column_name=>'TRANSACTION_ID'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Transaction ID'
,p_column_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:RP,36:P36_TRANSACTION_ENTRY_ID:#ID#'
,p_column_linktext=>'#TRANSACTION_ID#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13873964186621450507)
,p_db_column_name=>'ITEM_PRICE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Item Price'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13873964293898450508)
,p_db_column_name=>'SALE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Sale'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13873965041065450515)
,p_db_column_name=>'PRODUCT_ID'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Product Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13873965179829450516)
,p_db_column_name=>'STORE_ID'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Store Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(13876541041690108677)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'120167826'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100
,p_report_columns=>'TRANSACTION_ID:REGION:STORE:PRODUCT:DATE_OF_SALE:THE_MONTH:QUANTITY:ITEM_PRICE:SALE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(62749777546706765490)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36214331598922080100)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44341523228005344133)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(36214427499983080196)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(62991387094640520158)
,p_plug_name=>'Facets'
,p_region_name=>'active_facets'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_plug_template=>wwv_flow_imp.id(36214288364795080066)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13876262712602532289)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(62749777546706765490)
,p_button_name=>'reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(36214425992827080194)
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:RP,51::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13876263175123532289)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(62749777546706765490)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(36214425206989080191)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(13876266667252532295)
,p_branch_name=>'branch to requested page'
,p_branch_action=>'f?p=&APP_ID.:&P51_NAVIGATION.:&SESSION.::&DEBUG.:RP,&P51_NAVIGATION.::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37906644341515344212)
,p_name=>'P51_NAVIGATION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(62749777546706765490)
,p_item_display_point=>'NEXT'
,p_item_default=>'&APP_PAGE_ID.'
,p_prompt=>'Navigation'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'SALES HISTORY NAVIGATION'
,p_lov=>'.'||wwv_flow_imp.id(13875831458383401653)||'.'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(36214423164959080184)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13876265585320532293)
,p_name=>'on report view change'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P51_NAVIGATION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13876266092279532294)
,p_event_id=>wwv_flow_imp.id(13876265585320532293)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13876265263348532293)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'start timer'
,p_process_sql_clob=>'oow_demo_timing.START_TIMER;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>12016506779898005716
);
wwv_flow_imp.component_end;
end;
/
