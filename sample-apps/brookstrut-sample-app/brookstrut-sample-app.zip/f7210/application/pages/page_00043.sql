prompt --application/pages/page_00043
begin
--   Manifest
--     PAGE: 00043
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>43
,p_name=>'Recent Sales'
,p_step_title=>'Recent Sales'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'18'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20231214224516'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24078699142074852238)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(23021795045616329582)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(31148986674699593615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(23021890946677329678)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24078699798043852240)
,p_plug_name=>'Recent Sales'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(23021775374292329568)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with',
'    the_products as (',
'        select sp.store_id, sp.id product_id, i.item_name',
'        from oow_demo_store_products sp, oow_demo_items i',
'        where i.id = sp.item_id)',
'select p.item_name product_name,',
'       h.quantity units_sold,',
'       h.item_price total_sale,',
'       h.date_of_sale sold_on',
'from oow_demo_sales_history h, the_products p',
'where h.product_id = p.product_id',
'and h.store_id = :p3_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(24078699814028852240)
,p_name=>'Recent Sales'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'CBCHO'
,p_internal_uid=>1906164400115129281
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24078700247315852243)
,p_db_column_name=>'PRODUCT_NAME'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Product Name'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24078700644895852246)
,p_db_column_name=>'UNITS_SOLD'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Units Sold'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24078701071050852246)
,p_db_column_name=>'TOTAL_SALE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Total Sale'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24078701424862852246)
,p_db_column_name=>'SOLD_ON'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Sold On'
,p_column_type=>'DATE'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(24078721541858878116)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'19061862'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PRODUCT_NAME:UNITS_SOLD:TOTAL_SALE:SOLD_ON'
,p_sort_column_1=>'SOLD_ON'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'UNITS_SOLD:TOTAL_SALE'
);
wwv_flow_imp.component_end;
end;
/
