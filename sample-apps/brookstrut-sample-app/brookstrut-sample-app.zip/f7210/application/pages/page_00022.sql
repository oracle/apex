prompt --application/pages/page_00022
begin
--   Manifest
--     PAGE: 00022
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1867060655981638216
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>22
,p_name=>'Sales by Store by Week'
,p_step_title=>'Sales by Store by Week'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(39704463219442532479)
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20230329134935'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38724308061003674482)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36221633771453191739)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44348825400536455772)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(36221729672514191835)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38724308449751684682)
,p_plug_name=>'Sales by Region by Week'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36221614100129191725)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    yyyy_ww yyyy_w,',
'    sum(decode(x.region_id,1,units_sold,0)) r1_units,',
'    sum(decode(x.region_id,2,units_sold,0)) r2_units,',
'    sum(decode(x.region_id,3,units_sold,0)) r3_units,',
'    sum(decode(x.region_id,1,total_sale,0)) r1_total_sale,',
'    sum(decode(x.region_id,2,total_sale,0)) r2_total_sale,',
'    sum(decode(x.region_id,3,total_sale,0)) r3_total_sale',
'from',
'(',
'select (select region_id ',
'        from OOW_DEMO_STORES s ',
'        where s.id = sh.store_id) region_id, ',
'       to_char(sh.date_of_sale, ''YYYY.WW'') yyyy_ww,',
'       sum(sh.item_price * sh.QUANTITY) total_sale,',
'       sum(sh.quantity) units_sold',
'from OOW_DEMO_SALES_HISTORY sh',
'group by sh.store_id, to_char(sh.date_of_sale, ''YYYY.WW'')',
') x',
'group by yyyy_ww'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(38724308565426684682)
,p_name=>'Sales by Store by Week'
,p_max_row_count=>'100000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'MIKE'
,p_internal_uid=>2712029319722118413
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38724308973943684684)
,p_db_column_name=>'YYYY_W'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Week'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38724316960216293279)
,p_db_column_name=>'R1_UNITS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'&R1. Units'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38724317063639293279)
,p_db_column_name=>'R2_UNITS'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'&R2. Units'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38724317353851293280)
,p_db_column_name=>'R1_TOTAL_SALE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'&R1. Total Sale'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'$999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38724317451310293280)
,p_db_column_name=>'R2_TOTAL_SALE'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'&R2. Total Sale'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'$999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38724801660117686008)
,p_db_column_name=>'R3_UNITS'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'&R3. Units'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38724801771943686008)
,p_db_column_name=>'R3_TOTAL_SALE'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'&R3. Total Sale'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'$999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(38724309277802692783)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'27120301'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'YYYY_W:R1_UNITS:R1_TOTAL_SALE:R2_UNITS:R2_TOTAL_SALE::R3_UNITS:R3_TOTAL_SALE'
,p_sort_column_1=>'YYYY_W'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'TOTAL_SALE'
,p_sort_direction_2=>'DESC'
,p_sum_columns_on_break=>'PRODUCT_SALES'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38724310160403706695)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38724308449751684682)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(36221728165358191833)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:RP,22,RIR::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38985731664297435729)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38724308061003674482)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(36221727379520191830)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38740670558023611721)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set regions'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   i integer := 0;',
'begin',
'',
'for c1 in (select region_name from OOW_DEMO_REGIONS order by id) loop',
'   i := i + 1;',
'   if i = 1 then :R1 := c1.region_name; end if;',
'   if i = 2 then :R2 := c1.region_name; end if;',
'   if i = 3 then :R3 := c1.region_name; end if;',
'   if i = 4 then :R4 := c1.region_name; end if;',
'   if i = 5 then :R5 := c1.region_name; end if;',
'end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>16594361276569978206
);
wwv_flow_imp.component_end;
end;
/
