prompt --application/pages/page_00033
begin
--   Manifest
--     PAGE: 00033
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>33
,p_name=>'Transaction Log'
,p_step_title=>'Transaction Log'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(39708734141555318379)
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38744069100158400072)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36225904693565977639)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44353096322649241672)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(36226000594626977735)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38744070170534751348)
,p_plug_name=>'Transaction Generation Log'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36225885022241977625)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id, owner, num_days, max_orders, end_time, end_time_since, elapsed_seconds, row_count,',
'       to_number(decode (elapsed_seconds,null,null,row_count/elapsed_seconds)) rows_per_second',
'from (',
'select',
'    ID,',
'    OWNER,',
'    NUM_DAYS,',
'    MAX_ORDERS,',
'    START_TIME,',
'    END_TIME,',
'    END_TIME end_time_since,',
'    (extract(SECOND FROM end_time-start_time)) +',
'    (extract(MINUTE FROM end_time-start_time) * 60) +',
'    (extract(HOUR FROM end_time-start_time) *3600 ) elapsed_seconds,',
'    row_count',
'from OOW_DEMO_HIST_GEN_LOG) base_query'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(38744070283003751349)
,p_name=>'Transaction Generation Log'
,p_max_row_count=>'100000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_owner=>'MIKE'
,p_internal_uid=>2727520115186399180
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38744070480837751353)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38744070594640751354)
,p_db_column_name=>'OWNER'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38744070699783751354)
,p_db_column_name=>'NUM_DAYS'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Num Days'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38744070799269751354)
,p_db_column_name=>'MAX_ORDERS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Max Orders'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38744070999501751355)
,p_db_column_name=>'END_TIME'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'End Time'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38744205990731965358)
,p_db_column_name=>'ELAPSED_SECONDS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Elapsed Seconds'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38755888582230273775)
,p_db_column_name=>'ROW_COUNT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'New Rows'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(22489325438955928218)
,p_db_column_name=>'ROWS_PER_SECOND'
,p_display_order=>18
,p_column_identifier=>'J'
,p_column_label=>'Rows Per Second'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13181530554117551946)
,p_db_column_name=>'END_TIME_SINCE'
,p_display_order=>28
,p_column_identifier=>'K'
,p_column_label=>'Last Action'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(38744071070880751507)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'27275210'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'OWNER:NUM_DAYS:MAX_ORDERS:END_TIME:ELAPSED_SECONDS:ROW_COUNT:ROWS_PER_SECOND:END_TIME_SINCE:'
,p_sort_column_1=>'END_TIME_SINCE'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'START_TIME'
,p_sort_direction_2=>'DESC'
,p_sum_columns_on_break=>'ROW_COUNT:ELAPSED_SECONDS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38744390390461220817)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38744070170534751348)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(36225999087470977733)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:33,RIR::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38994159685103862333)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38744069100158400072)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(36225998301632977730)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp.component_end;
end;
/
