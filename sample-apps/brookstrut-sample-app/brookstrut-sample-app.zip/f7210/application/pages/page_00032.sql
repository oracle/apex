prompt --application/pages/page_00032
begin
--   Manifest
--     PAGE: 00032
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>32
,p_name=>'Table Counts'
,p_step_title=>'Table Counts'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(39708734141555318379)
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38744053874113174604)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36225904693565977639)
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44353096322649241672)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(36226000594626977735)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(39505088692014518413)
,p_name=>'Row Counts'
,p_template=>wwv_flow_imp.id(36225859974137977604)
,p_display_sequence=>21
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--fixed:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'   to_char((select count(*) from OOW_DEMO_HIST_GEN_LOG),''999G999G999G999G990'')    HIST_GEN_LOG,',
'   to_char((select count(*) from OOW_DEMO_ITEMS),''999G999G999G999G990'')           ITEMS,',
'   to_char((select count(*) from OOW_DEMO_REGIONS),''999G999G999G999G990'')         REGIONS,',
'   to_char((select count(*) from OOW_DEMO_SALES_HISTORY),''999G999G999G999G990'')   SALES_HISTORY,',
'   to_char((select count(*) from OOW_DEMO_STORE_PRODUCTS),''999G999G999G999G990'')  STORE_PRODUCTS,',
'   to_char((select count(*) from OOW_DEMO_STORES),''999G999G999G999G990'')          STORES',
'from dual '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(36225945955309977672)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39756938833277082192)
,p_query_column_id=>1
,p_column_alias=>'HIST_GEN_LOG'
,p_column_display_sequence=>10
,p_column_heading=>'Hist Gen Log'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39756938936109082193)
,p_query_column_id=>2
,p_column_alias=>'ITEMS'
,p_column_display_sequence=>20
,p_column_heading=>'Items'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39756939050115082194)
,p_query_column_id=>3
,p_column_alias=>'REGIONS'
,p_column_display_sequence=>30
,p_column_heading=>'Regions'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39756939135904082195)
,p_query_column_id=>4
,p_column_alias=>'SALES_HISTORY'
,p_column_display_sequence=>40
,p_column_heading=>'Sales History'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39756939206362082196)
,p_query_column_id=>5
,p_column_alias=>'STORE_PRODUCTS'
,p_column_display_sequence=>50
,p_column_heading=>'Store Products'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39756939338503082197)
,p_query_column_id=>6
,p_column_alias=>'STORES'
,p_column_display_sequence=>60
,p_column_heading=>'Stores'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38990258508987628025)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38744053874113174604)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(36225998301632977730)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp.component_end;
end;
/
