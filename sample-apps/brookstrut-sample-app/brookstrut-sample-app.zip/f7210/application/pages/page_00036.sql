prompt --application/pages/page_00036
begin
--   Manifest
--     PAGE: 00036
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>36
,p_name=>'Transaction Detail'
,p_alias=>'TRANSACTION-DETAIL'
,p_page_mode=>'MODAL'
,p_step_title=>'Transaction Detail'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(36214250762102080003)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'SHAKEEB'
,p_last_upd_yyyymmddhh24miss=>'20240404225717'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(14208046840972753280)
,p_name=>'Transaction Line Items'
,p_template=>wwv_flow_imp.id(36214319171477080091)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    h.id,',
'    h.store_id stores_ID,',
'    (select store_name from #OWNER#.oow_demo_stores s where s.id = h.store_id) store,',
'    p.item_id  product_ID,',
'    (select item_name from OOW_DEMO_ITEMS p where p.id = h.product_id) product,',
'    h.QUANTITY,',
'    h.ITEM_PRICE,',
'    h.QUANTITY * h.ITEM_PRICE Transaction_amount',
'from OOW_DEMO_SALES_HISTORY h,',
'     OOW_DEMO_STORE_PRODUCTS p',
'where ',
'      p.ITEM_ID = h.PRODUCT_ID and',
'      h.ID = :P36_TRANSACTION_ENTRY_ID',
' ',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(36214379195858080137)
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14208048130381753293)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>110
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14208047298645753285)
,p_query_column_id=>2
,p_column_alias=>'STORES_ID'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14208047404366753286)
,p_query_column_id=>3
,p_column_alias=>'STORE'
,p_column_display_sequence=>50
,p_column_heading=>'Store'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14208047539841753287)
,p_query_column_id=>4
,p_column_alias=>'PRODUCT_ID'
,p_column_display_sequence=>60
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14208047679573753288)
,p_query_column_id=>5
,p_column_alias=>'PRODUCT'
,p_column_display_sequence=>70
,p_column_heading=>'Product'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14208047684200753289)
,p_query_column_id=>6
,p_column_alias=>'QUANTITY'
,p_column_display_sequence=>80
,p_column_heading=>'Quantity'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14208047819262753290)
,p_query_column_id=>7
,p_column_alias=>'ITEM_PRICE'
,p_column_display_sequence=>90
,p_column_heading=>'Item Price'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14208047120723753283)
,p_query_column_id=>8
,p_column_alias=>'TRANSACTION_AMOUNT'
,p_column_display_sequence=>100
,p_column_heading=>'Transaction Amount'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(27677485550572005066)
,p_name=>'Transaction Detail'
,p_template=>wwv_flow_imp.id(36214288364795080066)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--fixed'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    count(distinct h.store_id) stores,',
'    count(distinct p.item_id)  products,',
'    sum(h.QUANTITY * h.ITEM_PRICE) Transaction_amount,',
'    count(*) line_items',
'from #OWNER#.OOW_DEMO_SALES_HISTORY h,',
'     #OWNER#.OOW_DEMO_STORE_PRODUCTS p',
'where ',
'      p.ITEM_ID = h.PRODUCT_ID and',
'      h.ID = :P36_TRANSACTION_ENTRY_ID',
' ',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(36214372860666080133)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27445545229537135799)
,p_query_column_id=>1
,p_column_alias=>'STORES'
,p_column_display_sequence=>10
,p_column_heading=>'Stores'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27445545736512135804)
,p_query_column_id=>2
,p_column_alias=>'PRODUCTS'
,p_column_display_sequence=>60
,p_column_heading=>'Products'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27445545620355135803)
,p_query_column_id=>3
,p_column_alias=>'TRANSACTION_AMOUNT'
,p_column_display_sequence=>80
,p_column_heading=>'Transaction Amount'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27445545464913135802)
,p_query_column_id=>4
,p_column_alias=>'LINE_ITEMS'
,p_column_display_sequence=>70
,p_column_heading=>'Line Items'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14208046656272753278)
,p_name=>'P36_TRANSACTION_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(27677485550572005066)
,p_prompt=>'Transaction ID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(36214423435943080187)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27445543898855135786)
,p_name=>'P36_TRANSACTION_ENTRY_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(27677485550572005066)
,p_prompt=>'Transaction Line Item ID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(36214423435943080187)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27445544215258135789)
,p_name=>'P36_TRANSACTION_DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(27677485550572005066)
,p_prompt=>'Transaction Date'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(36214423435943080187)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(27445544296519135790)
,p_computation_sequence=>10
,p_computation_item=>'P36_TRANSACTION_DATE'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(DATE_OF_SALE,''DD-MON-YYYY HH24:MI:SS'') TRANSACTION_DATE',
'from   OOW_DEMO_SALES_HISTORY',
'where  ID = :P36_TRANSACTION_ENTRY_ID'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(14208046697145753279)
,p_computation_sequence=>20
,p_computation_item=>'P36_TRANSACTION_ID'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select transaction_id',
'from   OOW_DEMO_SALES_HISTORY',
'where  ID = :P36_TRANSACTION_ENTRY_ID'))
);
wwv_flow_imp.component_end;
end;
/
