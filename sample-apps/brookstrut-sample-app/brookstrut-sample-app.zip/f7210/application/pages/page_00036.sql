prompt --application/pages/page_00036
begin
--   Manifest
--     PAGE: 00036
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>36
,p_name=>'Transaction Detail'
,p_alias=>'TRANSACTION-DETAIL'
,p_page_mode=>'MODAL'
,p_step_title=>'Transaction Detail'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(14291602414027542614)
,p_name=>'Transaction Line Items'
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    h.id,',
'    h.store_id stores_ID,',
'    (select store_name from #OWNER#.oow_demo_stores s where s.id = h.store_id) store,',
'    p.item_id  product_ID,',
'    (select item_name from OOW_DEMO_ITEMS p where p.id = h.product_id) product,',
'    h.QUANTITY,',
'    h.ITEM_PRICE,',
'    h.QUANTITY * h.ITEM_PRICE Transaction_amount',
'from OOW_DEMO_SALES_HISTORY h,',
'     OOW_DEMO_STORE_PRODUCTS p',
'where ',
'      p.ITEM_ID = h.PRODUCT_ID and',
'      h.ID = :P36_TRANSACTION_ENTRY_ID',
' ',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14291603703436542627)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>110
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14291602871700542619)
,p_query_column_id=>2
,p_column_alias=>'STORES_ID'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14291602977421542620)
,p_query_column_id=>3
,p_column_alias=>'STORE'
,p_column_display_sequence=>50
,p_column_heading=>'Store'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14291603112896542621)
,p_query_column_id=>4
,p_column_alias=>'PRODUCT_ID'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14291603252628542622)
,p_query_column_id=>5
,p_column_alias=>'PRODUCT'
,p_column_display_sequence=>70
,p_column_heading=>'Product'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14291603257255542623)
,p_query_column_id=>6
,p_column_alias=>'QUANTITY'
,p_column_display_sequence=>80
,p_column_heading=>'Quantity'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14291603392317542624)
,p_query_column_id=>7
,p_column_alias=>'ITEM_PRICE'
,p_column_display_sequence=>90
,p_column_heading=>'Item Price'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14291602693778542617)
,p_query_column_id=>8
,p_column_alias=>'TRANSACTION_AMOUNT'
,p_column_display_sequence=>100
,p_column_heading=>'Transaction Amount'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(27761041123626794400)
,p_name=>'Transaction Detail'
,p_template=>3371237801798025892
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--fixed'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    count(distinct h.store_id) stores,',
'    count(distinct p.item_id)  products,',
'    sum(h.QUANTITY * h.ITEM_PRICE) Transaction_amount,',
'    count(*) line_items',
'from #OWNER#.OOW_DEMO_SALES_HISTORY h,',
'     #OWNER#.OOW_DEMO_STORE_PRODUCTS p',
'where ',
'      p.ITEM_ID = h.PRODUCT_ID and',
'      h.ID = :P36_TRANSACTION_ENTRY_ID',
' ',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2104643962563030528
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27529100802591925133)
,p_query_column_id=>1
,p_column_alias=>'STORES'
,p_column_display_sequence=>10
,p_column_heading=>'Stores'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27529101309566925138)
,p_query_column_id=>2
,p_column_alias=>'PRODUCTS'
,p_column_display_sequence=>60
,p_column_heading=>'Products'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27529101193409925137)
,p_query_column_id=>3
,p_column_alias=>'TRANSACTION_AMOUNT'
,p_column_display_sequence=>80
,p_column_heading=>'Transaction Amount'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27529101037967925136)
,p_query_column_id=>4
,p_column_alias=>'LINE_ITEMS'
,p_column_display_sequence=>70
,p_column_heading=>'Line Items'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14291602229327542612)
,p_name=>'P36_TRANSACTION_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(27761041123626794400)
,p_prompt=>'Transaction ID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27529099471909925120)
,p_name=>'P36_TRANSACTION_ENTRY_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(27761041123626794400)
,p_prompt=>'Transaction Line Item ID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27529099788312925123)
,p_name=>'P36_TRANSACTION_DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(27761041123626794400)
,p_prompt=>'Transaction Date'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(27529099869573925124)
,p_computation_sequence=>10
,p_computation_item=>'P36_TRANSACTION_DATE'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(DATE_OF_SALE,''DD-MON-YYYY HH24:MI:SS'') TRANSACTION_DATE',
'from   OOW_DEMO_SALES_HISTORY',
'where  ID = :P36_TRANSACTION_ENTRY_ID'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(14291602270200542613)
,p_computation_sequence=>20
,p_computation_item=>'P36_TRANSACTION_ID'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select transaction_id',
'from   OOW_DEMO_SALES_HISTORY',
'where  ID = :P36_TRANSACTION_ENTRY_ID'))
);
wwv_flow_imp.component_end;
end;
/
