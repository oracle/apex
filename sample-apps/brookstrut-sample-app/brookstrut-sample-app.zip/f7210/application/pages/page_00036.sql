prompt --application/pages/page_00036
begin
--   Manifest
--     PAGE: 00036
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>36
,p_name=>'Transaction Detail'
,p_alias=>'TRANSACTION-DETAIL'
,p_page_mode=>'MODAL'
,p_step_title=>'Transaction Detail &P36_TRANSACTION_ID.'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20230626223030'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(14484948997266254548)
,p_name=>'Transaction Detail'
,p_template=>wwv_flow_imp.id(23021782618171329573)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--dash:t-BadgeList--fixed'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    count(distinct h.store_id) stores,',
'    count(distinct p.item_id) products,',
'    sum(h.QUANTITY * h.ITEM_PRICE) Transaction_amount,',
'    count(*) line_items',
'',
'from #OWNER#.OOW_DEMO_SALES_HISTORY h,',
'     #OWNER#.OOW_DEMO_STORE_PRODUCTS p',
'where ',
'      p.ITEM_ID = h.PRODUCT_ID and',
'      h.transaction_ID = :P36_TRANSACTION_ID',
' ',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(23021836307360329615)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14253008676231385281)
,p_query_column_id=>1
,p_column_alias=>'STORES'
,p_column_display_sequence=>10
,p_column_heading=>'Stores'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14253009183206385286)
,p_query_column_id=>2
,p_column_alias=>'PRODUCTS'
,p_column_display_sequence=>60
,p_column_heading=>'Products'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14253009067049385285)
,p_query_column_id=>3
,p_column_alias=>'TRANSACTION_AMOUNT'
,p_column_display_sequence=>80
,p_column_heading=>'Transaction Amount'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14253008911607385284)
,p_query_column_id=>4
,p_column_alias=>'LINE_ITEMS'
,p_column_display_sequence=>70
,p_column_heading=>'Line Items'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14253007345549385268)
,p_name=>'P36_TRANSACTION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(14484948997266254548)
,p_prompt=>'Transaction ID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(23021886882637329669)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14253007661952385271)
,p_name=>'P36_TRANSACTION_DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(14484948997266254548)
,p_prompt=>'Transaction Date'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(23021886882637329669)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(14253007743213385272)
,p_computation_sequence=>10
,p_computation_item=>'P36_TRANSACTION_DATE'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(DATE_OF_SALE,''DD-MON-YYYY HH24:MI:SS'') TRANSACTION_DATE',
'from   OOW_DEMO_SALES_HISTORY',
'where  TRANSACTION_ID = :P36_TRANSACTION_ID'))
);
wwv_flow_imp.component_end;
end;
/
