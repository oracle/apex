prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Store'
,p_step_title=>'Store'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(39723191654621710346)
,p_javascript_file_urls=>'https://maps.googleapis.com/maps/api/js?key=&P7_MAPS_API_KEY.&amp;sensor=false'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message = ''"DELETE_CONFIRM_MSG"'';',
'',
'var g_initialAddress = "";',
'var g_addrFieldMap = {',
'    "route": "P7_STORE_ADDRESS",',
'    "sublocality": "P7_STORE_CITY",',
'    "locality": "P7_STORE_CITY",',
'    "administrative_area_level_1": "P7_STORE_STATE",',
'    "postal_code": "P7_STORE_ZIP"',
'};',
'',
'function getAddressString() {',
'    var addr = $v("P7_STORE_ADDRESS") + ", " + $v("P7_STORE_CITY") + ", " + $v("P7_STORE_STATE") + ", " + $v("P7_STORE_ZIP");',
'    return addr;',
'}',
'',
'function updateAddress(result, updateLoc) {',
'    var i, type, value, field, loc, lat, lng, stnum, address, subloc, city,',
'        ok = true,',
'        comps = result.address_components;',
'',
'    for (i = 0; i < comps.length; i++) {',
'        type = comps[i].types[0];',
'        value = comps[i][type == "administrative_area_level_1" ? "short_name" : "long_name"];',
'        if (type == "street_number") {',
'            stnum = value;',
'        } else if (type == "route") {',
'            address = value;',
'        } else if (type == "sublocality") {',
'            subloc = value;',
'        } else if (type == "locality") {',
'            city = value;',
'        } else {',
'            field = g_addrFieldMap[type];',
'            if (field) {',
'                $s(field, value);',
'            }',
'        }',
'    }',
'    if (stnum && address) {',
'        address = stnum + " " + address;',
'    }',
'    if (address) {',
'        field = g_addrFieldMap["route"];',
'        if (field) {',
'            $s(field, address);',
'        }',
'    }',
'    if (subloc) {',
'        city = subloc;',
'    }',
'    if (city) {',
'        field = g_addrFieldMap["locality"];',
'        if (field) {',
'            $s(field, city);',
'        }',
'    }',
'    if (!address || $v("P7_STORE_ADDRESS") === "" || $v("P7_STORE_CITY") === "" || $v("P7_STORE_STATE") === "" || $v("P7_STORE_ZIP") === "") {',
'        ok = false;',
'    }',
'',
'    if (updateLoc) {',
'        loc = result.geometry.location;',
'        lat = loc.lat();',
'        lng = loc.lng();',
'        $s("P7_STORE_LAT", lat);',
'        $s("P7_STORE_LNG", lng);',
'    }',
'    return ok;',
'}',
'',
'function validateAddressAndSubmit(action) {',
'    var gc,',
'        curAddr = getAddressString(),',
'        lat = $v("P7_STORE_LAT"),',
'        lng = $v("P7_STORE_LNG");',
'',
'    // don''t check addresses if there is no API key or required fields are missing (let the server validate), or have lat, lng and no address change',
'    // do check if missing lat or lag or the address has been edited',
'    if ($v("P7_MAPS_API_KEY") !== "" && ',
'          $v("P7_STORE_ADDRESS") !== "" && ',
'          $v("P7_STORE_CITY") !== "" && ',
'          $v("P7_STORE_NAME") !== "" && ',
'          (lat === "" || lng === "" || curAddr !== g_initialAddress)) {',
'',
'        apex.jQuery("#storeForm h1").first().append("<span id=''checking'' style=''padding-left: 40px;''>- Validating Address - </span>");',
'        apex.jQuery(".addressCheckMessage").hide();',
'',
'        gc = new google.maps.Geocoder();',
'        gc.geocode({',
'            address: curAddr',
'        }, function (results, status) {',
'            var i, choices;',
'',
'            apex.jQuery("#checking").remove();',
'            if (status === google.maps.GeocoderStatus.OK) {',
'                if (results.length === 1) {',
'                    if (updateAddress(results[0], true)) {',
'                        apex.submit(action);',
'                        return;',
'                    } else {',
'                        apex.jQuery("#incomplete").show();',
'                    }',
'                } else {',
'                    choices = "";',
'                    for (i = 0; i < results.length; i++) {',
'                        choices += "<li><input id=''addrChoices_" + i + ',
'                                   "'' type=radio name=''addrchoice''><label for=''addrChoices_" + i + "''>" + ',
'                                   results[i].formatted_address + "</label></li>";',
'                    }',
'                    apex.jQuery("#addrChoices").html(choices).off("change").on("change", function (evt) {',
'                        var i = evt.target.id;',
'                        i = i.split("_")[1];',
'                        updateAddress(results[i], false);',
'                    });',
'                    apex.jQuery("#multiple").show();',
'                }',
'            } else {',
'                switch (status) {',
'                case google.maps.GeocoderStatus.ZERO_RESULTS:',
'                    apex.jQuery("#notfound").show();',
'                    break;',
'                case google.maps.GeocoderStatus.OVER_QUERY_LIMIT:',
'                    apex.jQuery("#overlimit").show();',
'                    break;',
'                default:',
'                    apex.jQuery("#checkfailed").show();',
'                }',
'            }',
'            openModal("adrchkres");',
'        });',
'    } else {',
'        apex.submit(action);',
'    }',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function ($) {',
'    g_initialAddress = getAddressString();',
'})(apex.jQuery);'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.addressCheckMessage {',
'  display: none;',
'}',
'#adrchkres {',
'  width: 80%;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36890747225036914915)
,p_plug_name=>'Address Validation'
,p_region_name=>'adrchkres'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36901780019210866313)
,p_plug_name=>'Incomplete address'
,p_region_name=>'incomplete'
,p_parent_plug_id=>wwv_flow_imp.id(36890747225036914915)
,p_region_css_classes=>'addressCheckMessage'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<p>Not a complete address</p>'
,p_translate_title=>'N'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36901780333193879807)
,p_plug_name=>'Multiple addresses'
,p_region_name=>'multiple'
,p_parent_plug_id=>wwv_flow_imp.id(36890747225036914915)
,p_region_css_classes=>'addressCheckMessage'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Multiple results found. Choose one of the following.</p>',
'<ul id="addrChoices">',
'</ul>',
''))
,p_translate_title=>'N'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36901795905115344754)
,p_plug_name=>'Not Found'
,p_region_name=>'notfound'
,p_parent_plug_id=>wwv_flow_imp.id(36890747225036914915)
,p_region_css_classes=>'addressCheckMessage'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Address not found. Enter a correct address and try again.</p>',
''))
,p_translate_title=>'N'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36901796818190367470)
,p_plug_name=>'Over Limit'
,p_region_name=>'overlimit'
,p_parent_plug_id=>wwv_flow_imp.id(36890747225036914915)
,p_region_css_classes=>'addressCheckMessage'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>80
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Over limit try again later.</p>',
''))
,p_translate_title=>'N'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36901797708624374198)
,p_plug_name=>'Check Failed'
,p_region_name=>'checkfailed'
,p_parent_plug_id=>wwv_flow_imp.id(36890747225036914915)
,p_region_css_classes=>'addressCheckMessage'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>90
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Failed to check address.</p>',
''))
,p_translate_title=>'N'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38739589826282797330)
,p_plug_name=>'Store'
,p_region_name=>'storeForm'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38739594510200797353)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44367556858653634644)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38739590131847797332)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(38739594510200797353)
,p_button_name=>'SAVE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P7_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38739590412219797332)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38739594510200797353)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:&LAST_VIEW.:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(36890754215938555759)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(36890747225036914915)
,p_button_name=>'CLOSE'
,p_button_static_id=>'adrchkclose'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'OK'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38739590005336797332)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(38739594510200797353)
,p_button_name=>'CREATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Add Store'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P7_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-plus'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38739590232030797332)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(38739594510200797353)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P7_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(38739591015524797335)
,p_branch_action=>'f?p=&APP_ID.:6:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36901710429773828195)
,p_name=>'P7_MAPS_API_KEY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(38739589826282797330)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38739591233201797340)
,p_name=>'P7_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38739589826282797330)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38739591426603797347)
,p_name=>'P7_STORE_NAME'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(38739589826282797330)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Store Name'
,p_source=>'STORE_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38739591630913797349)
,p_name=>'P7_STORE_TYPE'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(38739589826282797330)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Store Type'
,p_source=>'STORE_TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'STORE TYPE'
,p_lov=>'.'||wwv_flow_imp.id(38739408335340260223)||'.'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Value -'
,p_cHeight=>1
,p_tag_css_classes=>'mnw180'
,p_begin_on_new_line=>'N'
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38739591832097797349)
,p_name=>'P7_STORE_ADDRESS'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(38739589826282797330)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Address'
,p_source=>'STORE_ADDRESS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38739592022689797349)
,p_name=>'P7_STORE_CITY'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(38739589826282797330)
,p_use_cache_before_default=>'NO'
,p_prompt=>'City'
,p_source=>'STORE_CITY'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>50
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38739592234310797349)
,p_name=>'P7_STORE_STATE'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(38739589826282797330)
,p_use_cache_before_default=>'NO'
,p_prompt=>'State'
,p_source=>'STORE_STATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>50
,p_begin_on_new_line=>'N'
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38739592430223797349)
,p_name=>'P7_STORE_ZIP'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(38739589826282797330)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Zip'
,p_source=>'STORE_ZIP'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>12
,p_begin_on_new_line=>'N'
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38739592613342797349)
,p_name=>'P7_STORE_LAT'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(38739589826282797330)
,p_use_cache_before_default=>'NO'
,p_source=>'STORE_LAT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38739592821011797350)
,p_name=>'P7_STORE_LNG'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(38739589826282797330)
,p_use_cache_before_default=>'NO'
,p_source=>'STORE_LNG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38739597606345839265)
,p_name=>'P7_STORE_ITEMS'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(38739589826282797330)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Store Inventory'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_vc_arr2   apex_application_global.vc_arr2;',
'begin',
'    select item_id',
'    bulk collect into l_vc_arr2 ',
'    from OOW_DEMO_STORE_PRODUCTS',
'    where store_id = :P7_ID;',
' ',
'    return apex_util.table_to_string ( l_vc_arr2 ); ',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select item_name, id',
'from OOW_DEMO_items i',
'order by upper(item_name)'))
,p_cHeight=>10
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38743031213007760952)
,p_name=>'P7_STORE_OPEN_DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(38739589826282797330)
,p_use_cache_before_default=>'NO'
,p_item_default=>'select sysdate from dual'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Store Opened On'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'STORE_OPEN_DATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'navigation_list_for', 'NONE',
  'show', 'button',
  'show_other_months', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38743043118398951778)
,p_name=>'P7_REGION_ID'
,p_is_required=>true
,p_item_sequence=>55
,p_item_plug_id=>wwv_flow_imp.id(38739589826282797330)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Region'
,p_source=>'REGION_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select region_name, id from oow_demo_regions order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Value -'
,p_cHeight=>1
,p_tag_css_classes=>'mnw180'
,p_begin_on_new_line=>'N'
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(36861940419549126788)
,p_validation_name=>'P7_STORE_NAME Not Null'
,p_validation_sequence=>10
,p_validation=>'return trim(:P7_STORE_NAME) is not null'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'CREATE,SAVE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(38739591426603797347)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(36890741235883539577)
,p_validation_name=>'P7_STORE_ADDRESS Not Null'
,p_validation_sequence=>20
,p_validation=>'return trim(:P7_STORE_ADDRESS) is not null'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'CREATE,SAVE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(38739591832097797349)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(36890741422728545662)
,p_validation_name=>'P7_STORE_CITY Not Null'
,p_validation_sequence=>30
,p_validation=>'return trim(:P7_STORE_CITY) is not null'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'CREATE,SAVE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(38739592022689797349)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38739595526599807302)
,p_name=>'CheckSave'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38739590131847797332)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38739595804668807303)
,p_event_id=>wwv_flow_imp.id(38739595526599807302)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_STORE_LAT,P7_STORE_LNG'
,p_attribute_01=>'validateAddressAndSubmit("SAVE");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38739596005605810662)
,p_name=>'CheckCreate'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38739590005336797332)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38739596330103810662)
,p_event_id=>wwv_flow_imp.id(38739596005605810662)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_STORE_LAT,P7_STORE_LNG'
,p_attribute_01=>'validateAddressAndSubmit("CREATE");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(36901798718714405518)
,p_name=>'Close Dialog'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(36890754215938555759)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36901799015509405525)
,p_event_id=>wwv_flow_imp.id(36901798718714405518)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'closeModal();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38739594022126797352)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from OOW_DEMO_STORES'
,p_attribute_02=>'OOW_DEMO_STORES'
,p_attribute_03=>'P7_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_internal_uid=>16574553282555984965
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38739594229609797353)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of OOW_DEMO_STORES'
,p_attribute_02=>'OOW_DEMO_STORES'
,p_attribute_03=>'P7_ID'
,p_attribute_04=>'ID'
,p_attribute_09=>'P7_ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_process_success_message=>'Action Processed.'
,p_return_key_into_item1=>'P7_ID'
,p_internal_uid=>16574553490038984966
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38739597925045844735)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Inventory'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'	l_inv apex_application_global.vc_arr2; ',
'begin ',
'	-- convert the colon separated string into an array ',
'	l_inv := apex_util.string_to_table(:P7_STORE_ITEMS);',
'',
'	delete from OOW_DEMO_STORE_PRODUCTS where store_id = :P7_ID;',
'	for i in 1..l_inv.count loop ',
'		insert into OOW_DEMO_STORE_PRODUCTS (store_id, item_id)',
'		values( :P7_ID, l_inv(i) );',
'	end loop; ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P7_STORE_ITEMS'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'Inventory updated.'
,p_internal_uid=>16574557185475032348
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38739594435510797353)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(38739590232030797332)
,p_internal_uid=>16574553695939984966
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(36901710133410820125)
,p_process_sequence=>50
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Populate Google Maps API Key'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    select preference_value',
'      into :P7_MAPS_API_KEY',
'      from oow_demo_preferences',
'     where preference_name = ''GOOGLE_MAPS_API_KEY'';',
'exception',
'    when no_data_found then',
'        :P7_MAPS_API_KEY := null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>14736669393840007738
);
wwv_flow_imp.component_end;
end;
/
