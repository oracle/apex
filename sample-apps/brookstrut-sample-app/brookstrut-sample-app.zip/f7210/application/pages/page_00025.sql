prompt --application/pages/page_00025
begin
--   Manifest
--     PAGE: 00025
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>25
,p_name=>'Sales by Product and Store by Week'
,p_step_title=>'Sales by Product and Store by Week'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(39780716619966210174)
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38815877661373500903)
,p_plug_name=>'breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(44425078801060133467)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38815876249360500897)
,p_plug_name=>'Sales by Product Region by Week'
,p_static_id=>'sales-by-product-region-by-week'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    product_id,',
'    (select item_name from oow_demo_items i where i.id = x.product_id) product,',
'    yyyy_ww yyyy_w,',
'    sum(decode(x.region_id,1,units_sold,0)) r1_units,',
'    sum(decode(x.region_id,2,units_sold,0)) r2_units,',
'    sum(decode(x.region_id,3,units_sold,0)) r3_units,',
'    sum(decode(x.region_id,1,total_sale,0)) r1_total_sale,',
'    sum(decode(x.region_id,2,total_sale,0)) r2_total_sale,',
'    sum(decode(x.region_id,3,total_sale,0)) r3_total_sale',
'from',
'(',
'select (select region_id ',
'        from OOW_DEMO_STORES s ',
'        where s.id = sh.store_id) region_id, ',
'       sh.product_id,',
'       to_char(sh.date_of_sale, ''YYYY.WW'') yyyy_ww,',
'       sum(sh.item_price * sh.QUANTITY) total_sale,',
'       sum(sh.quantity) units_sold',
'from     OOW_DEMO_SALES_HISTORY sh',
'group by sh.product_id, ',
'         sh.store_id, ',
'         to_char(sh.date_of_sale, ''YYYY.WW'')',
') x',
'group by product_id, yyyy_ww'))
,p_plug_source_type=>'NATIVE_IR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(38815876467161500898)
,p_max_row_count=>'100000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_internal_uid=>2727343820933256934
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38815893849624573108)
,p_db_column_name=>'PRODUCT'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Product'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38815893577066562088)
,p_db_column_name=>'PRODUCT_ID'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Product ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38815876852752500900)
,p_db_column_name=>'R1_TOTAL_SALE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'&R1. Total Sale'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'$999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38815876653302500900)
,p_db_column_name=>'R1_UNITS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'&R1. Units'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38815876957838500900)
,p_db_column_name=>'R2_TOTAL_SALE'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'&R2. Total Sale'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'$999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38815876748463500900)
,p_db_column_name=>'R2_UNITS'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'&R2. Units'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38815877171587500900)
,p_db_column_name=>'R3_TOTAL_SALE'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'&R3. Total Sale'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'$999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38815877069777500900)
,p_db_column_name=>'R3_UNITS'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'&R3. Units'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38815876547309500900)
,p_db_column_name=>'YYYY_W'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Week'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(38815877272183500901)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'27273447'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1000
,p_report_columns=>'PRODUCT:YYYY_W:R1_UNITS:R1_TOTAL_SALE:R2_UNITS:R2_TOTAL_SALE:R3_UNITS:R3_TOTAL_SALE:TOTAL_UNITS'
,p_sort_column_1=>'YYYY_W'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'PRODUCT'
,p_sort_direction_2=>'ASC'
,p_break_on=>'YYYY_W'
,p_break_enabled_on=>'YYYY_W'
,p_sum_columns_on_break=>'PRODUCT_SALES:TOTAL_UNITS:R3_TOTAL_SALE:R3_UNITS:R2_TOTAL_SALE:R2_UNITS:R1_TOTAL_SALE:R1_UNITS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38815877473799500902)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38815876249360500897)
,p_button_name=>'RESET_REPORT'
,p_static_id=>'reset-report'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:RP,25,RIR::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39061873670383506388)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38815877661373500903)
,p_button_name=>'up'
,p_static_id=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38816924254868297763)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set region names'
,p_static_id=>'set-region-names'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   i integer := 0;',
'begin',
'',
'for c1 in (select region_name from OOW_DEMO_REGIONS order by id) loop',
'   i := i + 1;',
'   if i = 1 then :R1 := c1.region_name; end if;',
'   if i = 2 then :R2 := c1.region_name; end if;',
'   if i = 3 then :R3 := c1.region_name; end if;',
'   if i = 4 then :R4 := c1.region_name; end if;',
'   if i = 5 then :R5 := c1.region_name; end if;',
'end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>16594361572890986553
);
wwv_flow_imp.component_end;
end;
/
