prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7210
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39780759288359211484)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39781911520494635885)
,p_group_name=>'Data Generation'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39780858241780598888)
,p_group_name=>'Regions'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39780716619966210174)
,p_group_name=>'Reporting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39780713597028209169)
,p_group_name=>'Stores'
);
wwv_flow_imp.component_end;
end;
/
