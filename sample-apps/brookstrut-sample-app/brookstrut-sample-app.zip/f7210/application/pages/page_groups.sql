prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7210
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1867060655981638216
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39704505887835533789)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39705658119970958190)
,p_group_name=>'Data Generation'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39704604841256921193)
,p_group_name=>'Regions'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39704463219442532479)
,p_group_name=>'Reporting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39704460196504531474)
,p_group_name=>'Stores'
);
wwv_flow_imp.component_end;
end;
/
