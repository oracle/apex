prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7210
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39708776809948319689)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39709929042083744090)
,p_group_name=>'Data Generation'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39708875763369707093)
,p_group_name=>'Regions'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39708734141555318379)
,p_group_name=>'Reporting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39708731118617317374)
,p_group_name=>'Stores'
);
wwv_flow_imp.component_end;
end;
/
