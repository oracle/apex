prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7210
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>43061406402105851
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39780759288359211484)
,p_group_name=>'Administration'
,p_static_id=>'administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39781911520494635885)
,p_group_name=>'Data Generation'
,p_static_id=>'data-generation'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39780858241780598888)
,p_group_name=>'Regions'
,p_static_id=>'regions'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39780716619966210174)
,p_group_name=>'Reporting'
,p_static_id=>'reporting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(39780713597028209169)
,p_group_name=>'Stores'
,p_static_id=>'stores'
);
wwv_flow_imp.component_end;
end;
/
