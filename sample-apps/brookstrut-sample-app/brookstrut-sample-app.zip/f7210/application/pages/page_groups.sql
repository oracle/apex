prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7210
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(26504667161998671632)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(26505819394134096033)
,p_group_name=>'Data Generation'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(26504766115420059036)
,p_group_name=>'Regions'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(26504624493605670322)
,p_group_name=>'Reporting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(26504621470667669317)
,p_group_name=>'Stores'
);
wwv_flow_imp.component_end;
end;
/
