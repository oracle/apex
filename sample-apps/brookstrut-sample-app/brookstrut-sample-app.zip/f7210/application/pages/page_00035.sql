prompt --application/pages/page_00035
begin
--   Manifest
--     PAGE: 00035
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1867060655981638216
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>35
,p_tab_set=>'TS1'
,p_name=>'Transaction Summary by Hour'
,p_step_title=>'Transaction Summary by Hour'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_nav_list_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20230329135855'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38740125661586516855)
,p_plug_name=>'Transaction Generation Log Summarized by Hour'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36221614100129191725)
,p_plug_display_sequence=>11
,p_plug_display_point=>'BODY_3'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    count(distinct OWNER) owners,',
'    sum(NUM_DAYS) total_days,',
'    sum(MAX_ORDERS) total_orders,',
'    sum(num_days*max_orders) orders_xactions_attempted,',
'    count(*) api_invocations,',
'    sum(num_days*max_orders)/3600 orders_ps,',
'    count(*)/3600 api_ps,',
'    to_char(start_time,''YYYY.MM.DD HH24'')',
'    the_minute',
'from OOW_DEMO_HIST_GEN_LOG',
'group by to_char(start_time,''YYYY.MM.DD HH24'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(38740125855331516859)
,p_name=>'Transaction Generation Log'
,p_max_row_count=>'100000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#menu/pencil16x16.gif" alt="" />'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'MIKE'
,p_internal_uid=>2727846609626950590
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38740125976018516859)
,p_db_column_name=>'OWNERS'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Submitting Users'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38740126050829516859)
,p_db_column_name=>'TOTAL_DAYS'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Total Days'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38740126154902516859)
,p_db_column_name=>'TOTAL_ORDERS'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Total Orders'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38740126266215516859)
,p_db_column_name=>'API_INVOCATIONS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'API Invocations'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38740126356646516859)
,p_db_column_name=>'THE_MINUTE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Hour'
,p_column_type=>'STRING'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38740126462592516859)
,p_db_column_name=>'ORDERS_XACTIONS_ATTEMPTED'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Order Transactions Attempted'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(35587469570135654017)
,p_db_column_name=>'ORDERS_PS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Orders / second'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D0000'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(35587470238465654019)
,p_db_column_name=>'API_PS'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'API calls / second'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990D0000'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(38740126570895516861)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'27278474'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'THE_MINUTE:OWNERS:API_INVOCATIONS:ORDERS_XACTIONS_ATTEMPTED:ORDERS_PS:API_PS'
,p_sort_column_1=>'THE_MINUTE'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'START_TIME'
,p_sort_direction_2=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38740127166922516861)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36221633771453191739)
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44348825400536455772)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(36221729672514191835)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38740126750542516861)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38740125661586516855)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(36221728165358191833)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:35,RIR::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38989965237441696512)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38740127166922516861)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(36221727379520191830)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp.component_end;
end;
/
