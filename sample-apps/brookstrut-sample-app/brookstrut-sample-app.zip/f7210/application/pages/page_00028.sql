prompt --application/pages/page_00028
begin
--   Manifest
--     PAGE: 00028
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>28
,p_name=>'Generate Transactions'
,p_alias=>'GENERATE-TRANSACTIONS'
,p_step_title=>'Generate Transactions'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(39698355947439846551)
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'06'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20240310211853'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38732359305723500781)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36214331598922080100)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44341523228005344133)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(36214427499983080196)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38732363180397535552)
,p_plug_name=>'Generate Transactions'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--featured force-fa-lg:t-Cards--displayIcons:t-Cards--3cols:t-Cards--animColorFill'
,p_plug_template=>wwv_flow_imp.id(36214286879494080065)
,p_plug_display_sequence=>20
,p_list_id=>wwv_flow_imp.id(38732362703484535550)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(36214401568812080162)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38969795749352950306)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38732359305723500781)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(36214425206989080191)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(36780197602766599898)
,p_computation_sequence=>10
,p_computation_item=>'LAST_VIEW'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'&APP_PAGE_ID.'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38732635193336218497)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'clear cache for transaction page'
,p_attribute_01=>'CLEAR_CACHE_FOR_PAGES'
,p_attribute_04=>'30'
,p_internal_uid=>16593628084413696621
);
wwv_flow_imp.component_end;
end;
/
