prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>20
,p_name=>'Sales by Store by Day'
,p_step_title=>'Sales by Store by Day'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(26504624493605670322)
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'08'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20230329135023'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25539803435401073200)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(23021795045616329582)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(31148986674699593615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(23021890946677329678)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25539805036695131745)
,p_plug_name=>'Sales by Store by Day'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(23021751811489329548)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select (select store_name from oow_demo_stores s where s.id = sh.store_id)||'' - ''||',
'        to_char(sum(sh.item_price * sh.QUANTITY),''$999G999G999G999G990'')||',
'       ''(''||count(*)||'')'' sales,',
'       sh.store_id,',
'       trunc(sh.date_of_sale) sale_date,',
'       sum(sh.quantity) units_sold',
'from OOW_DEMO_SALES_HISTORY sh',
'group by sh.store_id, trunc(sh.date_of_sale)'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_attribute_01=>'SALE_DATE'
,p_attribute_03=>'SALES'
,p_attribute_09=>'list:navigation'
,p_attribute_10=>'CSV'
,p_attribute_13=>'N'
,p_attribute_17=>'Y'
,p_attribute_19=>'Y'
,p_attribute_21=>'10'
,p_attribute_22=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25785801867097968098)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(25539803435401073200)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(23021888653683329673)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp.component_end;
end;
/
