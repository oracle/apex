prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_tab_set=>'TS1'
,p_name=>'Store'
,p_step_title=>'Store'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style type="text/css">',
'section#editProduct.uRegion div.uRegionContent table.formlayout {margin-left: 20px;}',
'section#addProduct.uRegion div.uRegionContent table.formlayout {margin-left: 20px;}',
'</style>'))
,p_step_template=>4072355960268175073
,p_page_template_options=>'#DEFAULT#'
,p_nav_list_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38741569914139466378)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44367556858653634644)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(38741576312138697744)
,p_name=>'Store Products'
,p_template=>4072358936313175081
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    i.item_name product,',
'    i.item_type,',
'    i.item_desc,',
'    i.msrp,',
'    s.ID,',
'    s.STORE_ID,',
'    s.ITEM_ID,',
'    s.SALE_START_DATE,',
'    s.DISCOUNT_PCT,',
'    s.SALE_END_DATE,',
'    nvl(s.ITEM_PRICE,i.msrp) item_price,',
'    nvl(s.item_price,i.msrp) - (nvl(s.item_price,i.msrp) * nvl(s.discount_pct,0) * .01) sale_price,',
'    i.id product_id',
'from OOW_DEMO_STORE_PRODUCTS s,',
'    OOW_DEMO_items i',
'where s.store_id = :P3_ID',
'    and i.id = s.item_id',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>1000
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38741577604304704961)
,p_query_column_id=>1
,p_column_alias=>'PRODUCT'
,p_column_display_sequence=>20
,p_column_heading=>'Product'
,p_column_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:RP,18:P18_ID:#PRODUCT_ID#'
,p_column_linktext=>'#PRODUCT#'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14581085802477101)
,p_query_column_id=>2
,p_column_alias=>'ITEM_TYPE'
,p_column_display_sequence=>140
,p_column_heading=>'Item Type'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38742046306082537825)
,p_query_column_id=>3
,p_column_alias=>'ITEM_DESC'
,p_column_display_sequence=>120
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38742046732373582177)
,p_query_column_id=>4
,p_column_alias=>'MSRP'
,p_column_display_sequence=>130
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38741576634573697746)
,p_query_column_id=>5
,p_column_alias=>'ID'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38741576714234697746)
,p_query_column_id=>6
,p_column_alias=>'STORE_ID'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38741576813202697746)
,p_query_column_id=>7
,p_column_alias=>'ITEM_ID'
,p_column_display_sequence=>70
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38741576926875697746)
,p_query_column_id=>8
,p_column_alias=>'SALE_START_DATE'
,p_column_display_sequence=>90
,p_column_heading=>'Promo Start'
,p_column_format=>'DD-MON-YYYY'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38741577033683697746)
,p_query_column_id=>9
,p_column_alias=>'DISCOUNT_PCT'
,p_column_display_sequence=>80
,p_column_heading=>'Discount %'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38741577121376697746)
,p_query_column_id=>10
,p_column_alias=>'SALE_END_DATE'
,p_column_display_sequence=>100
,p_column_heading=>'Promo End'
,p_column_format=>'DD-MON-YYYY'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38741577204479697746)
,p_query_column_id=>11
,p_column_alias=>'ITEM_PRICE'
,p_column_display_sequence=>30
,p_column_heading=>'Suggested Price'
,p_column_format=>'999G999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38741578222227729058)
,p_query_column_id=>12
,p_column_alias=>'SALE_PRICE'
,p_column_display_sequence=>40
,p_column_heading=>'Sale Price'
,p_column_format=>'999G999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13896399027626189814)
,p_query_column_id=>13
,p_column_alias=>'PRODUCT_ID'
,p_column_display_sequence=>10
,p_column_heading=>'Edit'
,p_column_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:RP,12:P12_ID:#PRODUCT_ID#'
,p_column_linktext=>'<span class="fa fa-edit" aria-hidden="true"></span>'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(39519549404160911387)
,p_name=>'Store Performance'
,p_template=>4072358936313175081
,p_display_sequence=>5
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select store_name, ',
'       STORE_OPEN_DATE,',
'       sysdate - cast(STORE_OPEN_DATE as date)  days_open,',
'       sales_trailing_30_days, ',
'       sales_prior_30_days, ',
'       nvl(sales_trailing_30_days,0) - nvl(sales_prior_30_days,0) sales_trend,',
'       first_sale,',
'       most_recent_sale,',
'       sysdate - cast(first_sale as date) days_since_first_sale',
'from (',
'select s.STORE_OPEN_DATE,',
'       s.store_name,',
'       (select sum(QUANTITY*ITEM_PRICE) qp ',
'        from #OWNER#.OOW_DEMO_SALES_HISTORY h ',
'        where DATE_OF_SALE > sysdate - 30 and ',
'              h.store_id = :P3_ID) sales_trailing_30_days,',
'        (select sum(QUANTITY*ITEM_PRICE) qp ',
'        from #OWNER#.OOW_DEMO_SALES_HISTORY h ',
'        where DATE_OF_SALE > sysdate - 60 and ',
'              date_of_sale < sysdate - 30 and',
'              h.store_id  = :P3_ID) sales_prior_30_days,',
'        (select min(DATE_OF_SALE) from #OWNER#.OOW_DEMO_SALES_HISTORY h where store_id = :P3_ID) first_sale,',
'        (select max(DATE_OF_SALE) from #OWNER#.OOW_DEMO_SALES_HISTORY h where store_id = :P3_ID) most_recent_sale',
'from #OWNER#.OOW_DEMO_STORES s',
'where id = :P3_ID',
') x',
'',
'  '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39771397564181475146)
,p_query_column_id=>1
,p_column_alias=>'STORE_NAME'
,p_column_display_sequence=>10
,p_column_heading=>'Store Name'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39771398180777475152)
,p_query_column_id=>2
,p_column_alias=>'STORE_OPEN_DATE'
,p_column_display_sequence=>20
,p_column_heading=>'Store Open Date'
,p_column_format=>'fmDay, fmDD fmMonth, YYYY'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39771398271079475153)
,p_query_column_id=>3
,p_column_alias=>'DAYS_OPEN'
,p_column_display_sequence=>30
,p_column_heading=>'Days Open'
,p_column_format=>'999G999G999G999G999G999G990'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39519549975184911392)
,p_query_column_id=>4
,p_column_alias=>'SALES_TRAILING_30_DAYS'
,p_column_display_sequence=>40
,p_column_heading=>'Sales Trailing 30 Days'
,p_column_format=>'FML999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39519550059831911393)
,p_query_column_id=>5
,p_column_alias=>'SALES_PRIOR_30_DAYS'
,p_column_display_sequence=>50
,p_column_heading=>'Sales Prior 30 Days'
,p_column_format=>'FML999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39771397919844475150)
,p_query_column_id=>6
,p_column_alias=>'SALES_TREND'
,p_column_display_sequence=>60
,p_column_heading=>'Sales Trend'
,p_column_format=>'FML999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39771397625606475147)
,p_query_column_id=>7
,p_column_alias=>'FIRST_SALE'
,p_column_display_sequence=>70
,p_column_heading=>'First Sale'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39771397997179475151)
,p_query_column_id=>8
,p_column_alias=>'MOST_RECENT_SALE'
,p_column_display_sequence=>80
,p_column_heading=>'Most Recent Sale'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39771397804096475149)
,p_query_column_id=>9
,p_column_alias=>'DAYS_SINCE_FIRST_SALE'
,p_column_display_sequence=>90
,p_column_heading=>'Days Since First Sale'
,p_column_format=>'999G999G999G999G999G999G990'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38741578610152753876)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(38741569914139466378)
,p_button_name=>'EDIT_STORE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Edit Store'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:7:P7_ID:&P3_ID.'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39006564120263146554)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38741569914139466378)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(38742078822469714779)
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_comment=>'Created 13-SEP-2012 12:08 by ALLAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36969289998905437095)
,p_name=>'P3_STORE_NAME'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38741572430810476010)
,p_name=>'P3_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38742033130736288337)
,p_name=>'P3_PRODUCT_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(39001430416520673374)
,p_computation_sequence=>10
,p_computation_item=>'P3_STORE_NAME'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select store_name ||'' - ''||',
'STORE_ADDRESS || '' ''||',
'STORE_CITY||'', ''||',
'STORE_STATE ||'' ''||',
'STORE_ZIP x',
'from #OWNER#.oow_demo_stores s where s.id = :P3_ID'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38742123913792611101)
,p_name=>'Change price'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_ADD_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38742124224014611102)
,p_event_id=>wwv_flow_imp.id(38742123913792611101)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_ADD_PRICE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select msrp from OOW_DEMO_items where id = :P3_ADD_ID;'
,p_attribute_07=>'P3_ADD_ID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38742120524986122306)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update Product'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Update the product price info for this store',
'update',
'    OOW_DEMO_STORE_PRODUCTS',
'set',
'    item_price = :P3_EDIT_PRICE,',
'    discount_pct = :P3_EDIT_DISCOUNT,',
'    sale_start_date = :P3_EDIT_PROMO_START,',
'    sale_end_date = :P3_EDIT_PROMO_END',
'where',
'    item_id = :P3_PRODUCT_ID',
'and',
'    store_id = :P3_ID;',
'',
':P3_PRODUCT_ID := null;',
':P3_EDIT_PRICE := null;',
':P3_EDIT_DISCOUNT := null;',
':P3_EDIT_PROMO_START := null;',
':P3_EDIT_PROMO_END := null;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'update error #SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Product updated.'
,p_internal_uid=>16577079785415309919
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38742072605781530142)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add Product'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into OOW_DEMO_STORE_PRODUCTS',
'(store_id, item_id, item_price, discount_pct, sale_start_date, sale_end_date)',
'values',
'(:P3_ID, :P3_ADD_ID, :P3_ADD_PRICE, :P3_ADD_DISCOUNT, :P3_ADD_PROMO_START, :P3_ADD_PROMO_END);'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Product added.'
,p_internal_uid=>16577031866210717755
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38744409204491587619)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'delete product'
,p_process_sql_clob=>'delete from OOW_DEMO_STORE_PRODUCTS where item_id = :P3_PRODUCT_ID and store_id = :P3_ID;'
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Unable to remove the product.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Product removed.'
,p_internal_uid=>16579368464920775232
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13900629195742891122)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'start timer'
,p_process_sql_clob=>'oow_demo_timing.start_timer;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>12014837081644074034
);
wwv_flow_imp.component_end;
end;
/
