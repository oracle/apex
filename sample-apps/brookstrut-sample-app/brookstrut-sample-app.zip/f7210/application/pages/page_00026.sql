prompt --application/pages/page_00026
begin
--   Manifest
--     PAGE: 00026
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>14460536004392972
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>26
,p_name=>'Remove Transaction History'
,p_alias=>'REMOVE-TRANSACTION-HISTORY'
,p_step_title=>'Remove Transaction History'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(39724389578088137062)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36969289574409437090)
,p_plug_name=>'Tranaction Count'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--accessibleHeading'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    r clob;',
'    c int;',
'begin',
'    for c1 in (select count(*) c from oow_demo_sales_history) loop',
'        c := c1.c;',
'    end loop;',
'    return ''<font size="+10">Transaction Count: ''||to_char(nvl(c,0),''FM999G999G999G999G990'')||'' </font>'';',
'end;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38904500514669086960)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44367556858653634644)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(36969289134526437086)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(36969289574409437090)
,p_button_name=>'Remove_transactions'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Remove History'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_confirm_message=>'Please confirm you wish to remove all existing transaction history'
,p_icon_css_classes=>'fa-trash'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(36969289338528437088)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38904500514669086960)
,p_button_name=>'Cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39008300206133855442)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38904500514669086960)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(36969289493124437089)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'remove_transactions'
,p_process_sql_clob=>'execute immediate ''truncate table oow_demo_sales_history'';'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(36969289134526437086)
,p_internal_uid=>14804248753553624702
);
wwv_flow_imp.component_end;
end;
/
