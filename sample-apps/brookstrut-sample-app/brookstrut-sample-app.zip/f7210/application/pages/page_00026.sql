prompt --application/pages/page_00026
begin
--   Manifest
--     PAGE: 00026
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1859758483450526577
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>26
,p_name=>'Remove Transaction History'
,p_alias=>'REMOVE-TRANSACTION-HISTORY'
,p_step_title=>'Remove Transaction History'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(39698355947439846551)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20230329140515'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36943255943761146579)
,p_plug_name=>'Tranaction Count'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--accessibleHeading'
,p_plug_template=>wwv_flow_imp.id(36214281726136080053)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    r clob;',
'    c int;',
'begin',
'    for c1 in (select count(*) c from oow_demo_sales_history) loop',
'        c := c1.c;',
'    end loop;',
'    return ''<font size="+10">Transaction Count: ''||to_char(nvl(c,0),''FM999G999G999G999G990'')||'' </font>'';',
'end;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38878466884020796449)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36214331598922080100)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44341523228005344133)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(36214427499983080196)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(36943255503878146575)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(36943255943761146579)
,p_button_name=>'Remove_transactions'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(36214425992827080194)
,p_button_image_alt=>'Remove History'
,p_button_position=>'CLOSE'
,p_confirm_message=>'Please confirm you wish to remove all existing transaction history'
,p_icon_css_classes=>'fa-trash'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(36943255707880146577)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38878466884020796449)
,p_button_name=>'Cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(36214425866256080194)
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38982266575485564931)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38878466884020796449)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(36214425206989080191)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(36943255862476146578)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'remove_transactions'
,p_process_sql_clob=>'execute immediate ''truncate table oow_demo_sales_history'';'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(36943255503878146575)
,p_internal_uid=>14804248753553624702
);
wwv_flow_imp.component_end;
end;
/
