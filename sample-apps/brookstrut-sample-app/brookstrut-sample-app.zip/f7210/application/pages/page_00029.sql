prompt --application/pages/page_00029
begin
--   Manifest
--     PAGE: 00029
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>4270922112785900
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>29
,p_name=>'Generate Transaction'
,p_step_title=>'Generate Transaction'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(39709929042083744090)
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>'<p>Click the button to generate a transaction.  A dynamic action will generate a transaction and refresh a transaction details report.</p>'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(13973090050998845352)
,p_name=>'Transaction Details'
,p_template=>wwv_flow_imp.id(36225861459438977605)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       created_on,',
'       store_id, ',
'       product_id, ',
'       quantity, ',
'       item_price,',
'       quantity * item_price as sale_amount,',
'       date_of_sale,',
'       --',
'       -- store name',
'       --',
'       (select store_name ',
'        from OOW_demo_stores s ',
'        where s.id = h.store_id) store,',
'       --',
'       -- product',
'       --',
'       (select item_Name ',
'        from OOW_demo_items i',
'        where i.id = h.product_id) product',
'       --',
'from oow_demo_sales_history h',
'where id = :P29_TRANSACTION_ID'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(36225954886666977679)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13973090095040845353)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Transaction ID'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13973090192258845354)
,p_query_column_id=>2
,p_column_alias=>'CREATED_ON'
,p_column_display_sequence=>20
,p_column_heading=>'Created On'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13973090371208845355)
,p_query_column_id=>3
,p_column_alias=>'STORE_ID'
,p_column_display_sequence=>30
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13973090385798845356)
,p_query_column_id=>4
,p_column_alias=>'PRODUCT_ID'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13973090508244845357)
,p_query_column_id=>5
,p_column_alias=>'QUANTITY'
,p_column_display_sequence=>50
,p_column_heading=>'Quantity'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13973090641253845358)
,p_query_column_id=>6
,p_column_alias=>'ITEM_PRICE'
,p_column_display_sequence=>60
,p_column_heading=>'Item Price'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13973090706468845359)
,p_query_column_id=>7
,p_column_alias=>'SALE_AMOUNT'
,p_column_display_sequence=>70
,p_column_heading=>'Sale Amount'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13973090778333845360)
,p_query_column_id=>8
,p_column_alias=>'DATE_OF_SALE'
,p_column_display_sequence=>80
,p_column_heading=>'Date Of Sale'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON-YYYY HH24:MI:SS'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13973091068028845362)
,p_query_column_id=>9
,p_column_alias=>'STORE'
,p_column_display_sequence=>100
,p_column_heading=>'Store'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13973091120513845363)
,p_query_column_id=>10
,p_column_alias=>'PRODUCT'
,p_column_display_sequence=>110
,p_column_heading=>'Product'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38743936883557436522)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(36225904693565977639)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44353096322649241672)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(36226000594626977735)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38743937798951442770)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(38743936883557436522)
,p_button_name=>'GENERATE_TRANSACTION'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(36225999087470977733)
,p_button_image_alt=>'Generate Transaction'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13973091470606845366)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(38743936883557436522)
,p_button_name=>'reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(36225999087470977733)
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:RP,29::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38993520437358830107)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38743936883557436522)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(36225998301632977730)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(38743938279128455970)
,p_branch_action=>'f?p=&APP_ID.:29:&SESSION.:SHOW_SALE:&DEBUG.:::'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(38743937798951442770)
,p_branch_sequence=>10
,p_branch_comment=>'Created 25-OCT-2012 15:37 by MIKE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13973091348273845365)
,p_name=>'P29_TRANSACTION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13973090050998845352)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13973089594699845348)
,p_name=>'generate sale'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38743937798951442770)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13973089746361845349)
,p_event_id=>wwv_flow_imp.id(13973089594699845348)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P29_TRANSACTION_ID := oow_demo_gen_data_pkg.generate_transaction;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13973091217979845364)
,p_event_id=>wwv_flow_imp.id(13973089594699845348)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13973090050998845352)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38743937972202453998)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'generate transaction'
,p_process_sql_clob=>':P29_TRANSACTION_ID := oow_demo_gen_data_pkg.generate_transaction;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(38743937798951442770)
,p_process_success_message=>'Action Processed'
,p_internal_uid=>16593357768636034583
);
wwv_flow_imp.component_end;
end;
/
