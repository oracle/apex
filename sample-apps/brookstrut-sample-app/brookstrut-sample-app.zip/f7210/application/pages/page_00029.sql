prompt --application/pages/page_00029
begin
--   Manifest
--     PAGE: 00029
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7210
,p_default_id_offset=>1788986565153693458
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>29
,p_name=>'Generate Transaction'
,p_step_title=>'Generate Transaction'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(26505819394134096033)
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>'<p>Click the button to generate a transaction.  Clicking the button will post the page, perform a transaction and direct back to this  page showing the completed transaction.</p>'
,p_page_component_map=>'03'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20230329140259'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25539827235607788465)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(23021795045616329582)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(31148986674699593615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(23021890946677329678)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25539829135942828205)
,p_plug_name=>'Transaction Summary'
,p_icon_css_classes=>'fa-gear'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(23021822428326329601)
,p_plug_display_sequence=>30
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P29_TRANSACTION_ID is not null then',
'   for c1 in (select id,',
'                     created_on,',
'                     store_id, ',
'                     product_id, ',
'                     quantity, ',
'                     item_price,',
'                     date_of_sale,',
'                     (select store_name ',
'                      from OOW_demo_stores s ',
'                      where s.id = h.store_id) store,',
'                     (select item_Name from OOW_demo_items i',
'                      where i.id = h.product_id) product',
'              from oow_demo_sales_history h',
'              where id = :P29_TRANSACTION_ID) loop',
'     sys.htp.p(''<font size="+2">'');',
'     sys.htp.p(''<br /><strong>ID</strong>: ''||apex_escape.html(c1.id));',
'     sys.htp.p(''<br /><strong>Store</strong>: ''||apex_escape.html(c1.store));',
'     sys.htp.p(''<br /><strong>Product</strong>: ''||apex_escape.html(c1.product));',
'     sys.htp.p(''<br /><strong>Date of Sale</strong>: ''||to_char(c1.date_of_sale,''DD-MON-YYYY HH24:MI:SS''));',
'     sys.htp.p(''<br /><strong>Date of Posting</strong>: ''||to_char(c1.created_on,''DD-MON-YYYY HH24:MI:SS''));',
'     sys.htp.p(''<br /><strong>Quantity</strong>: ''||to_char(c1.quantity,''999G999G999G990''));',
'     sys.htp.p(''<br /><strong>Price</strong>: ''||to_char(c1.item_price,''$999G999G999G990D00''));',
'     sys.htp.p(''<br /><strong>Sale</strong>: ''||to_char(c1.item_price * c1.quantity,''$999G999G999G990D00''));',
'     sys.htp.p(''</font>'');',
'',
'   end loop;',
'   :P29_TRANSACTION_ID := null;',
'end if;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'NEVER'
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(26300976227391870328)
,p_name=>'CR'
,p_template=>wwv_flow_imp.id(23021751811489329548)
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'                     created_on,',
'                     store_id, ',
'                     product_id, ',
'                     quantity, ',
'                     item_price,',
'                     date_of_sale,',
'                     (select store_name ',
'                      from OOW_demo_stores s ',
'                      where s.id = h.store_id) store,',
'                     (select item_Name from OOW_demo_items i',
'                      where i.id = h.product_id) product',
'              from oow_demo_sales_history h',
'              where id = :P29_TRANSACTION_ID'))
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(23021845238717329622)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(26300976340362870329)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'ID'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(26300976416401870330)
,p_query_column_id=>2
,p_column_alias=>'CREATED_ON'
,p_column_display_sequence=>20
,p_column_heading=>'Created On'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(26300976599631870331)
,p_query_column_id=>3
,p_column_alias=>'STORE_ID'
,p_column_display_sequence=>30
,p_column_heading=>'Store ID'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(26300976695368870332)
,p_query_column_id=>4
,p_column_alias=>'PRODUCT_ID'
,p_column_display_sequence=>40
,p_column_heading=>'Product ID'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(26300976740692870333)
,p_query_column_id=>5
,p_column_alias=>'QUANTITY'
,p_column_display_sequence=>50
,p_column_heading=>'Quantity'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(26300976854480870334)
,p_query_column_id=>6
,p_column_alias=>'ITEM_PRICE'
,p_column_display_sequence=>60
,p_column_heading=>'Item Price'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(26300976919827870335)
,p_query_column_id=>7
,p_column_alias=>'DATE_OF_SALE'
,p_column_display_sequence=>70
,p_column_heading=>'Date of Sale'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(26300977053504870336)
,p_query_column_id=>8
,p_column_alias=>'STORE'
,p_column_display_sequence=>80
,p_column_heading=>'Store'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(26300977156702870337)
,p_query_column_id=>9
,p_column_alias=>'PRODUCT'
,p_column_display_sequence=>90
,p_column_heading=>'Product'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25539828151001794713)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(25539827235607788465)
,p_button_name=>'GENERATE_TRANSACTION'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(23021889439521329676)
,p_button_image_alt=>'Generate Transaction'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25789410789409182050)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(25539827235607788465)
,p_button_name=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(23021888653683329673)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(25539828631178807913)
,p_branch_action=>'f?p=&APP_ID.:29:&SESSION.:SHOW_SALE:&DEBUG.:::'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(25539828151001794713)
,p_branch_sequence=>10
,p_branch_comment=>'Created 25-OCT-2012 15:37 by MIKE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25539828945030811878)
,p_name=>'P29_TRANSACTION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(26300976227391870328)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(25539828324252805941)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'generate transaction'
,p_process_sql_clob=>':P29_TRANSACTION_ID := oow_demo_gen_data_pkg.generate_transaction;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(25539828151001794713)
,p_process_success_message=>'Action Processed'
,p_internal_uid=>16593357768636034583
);
wwv_flow_imp.component_end;
end;
/
