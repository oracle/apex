prompt --application/pages/page_00503
begin
--   Manifest
--     PAGE: 00503
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>503
,p_name=>'JSON and Workflow'
,p_alias=>'JSON-AND-WORKFLOW'
,p_step_title=>'JSON and Workflow'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(12731586493424370)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(296294739627363832671)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(296295315947355646367)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(296395028238350359830)
,p_plug_name=>'Start Workflow'
,p_title=>'1. Start Workflow'
,p_icon_css_classes=>'fa-number-1'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:t-Alert--accessibleHeading:js-headingLevel-2:t-Form--standardPadding:margin-bottom-sm'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'Please enter the order details and launch the workflow'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(296395286403682242238)
,p_plug_name=>'Button'
,p_parent_plug_id=>wwv_flow_imp.id(296395028238350359830)
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_landmark_type=>'exclude_landmark'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(296395029081990359838)
,p_plug_name=>'Workflow Console'
,p_title=>'2. Workflow Console'
,p_icon_css_classes=>'fa-number-2'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:t-Alert--accessibleHeading:js-headingLevel-2:t-Form--standardPadding:margin-bottom-md'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'After launching the process you can open the workflow console for more details about the workflow </br>',
''))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(296395286087830242235)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'  This page demonstrates how to use Oracle APEX <strong>Workflow Designer</strong> ',
'  to orchestrate an order placement pipeline. By submitting the form, the workflow ',
'  validates the customer and store, fetches product pricing, creates order records, ',
'  determines the shipping method, enriches the order metadata, and sends an order confirmation email.',
'</p>',
'',
'<p>',
'  To get started, complete and submit the order form to trigger the workflow. ',
'  You can then use the <strong>Open Workflow Console</strong> button to inspect each workflow step, status, and variable value.',
'</p>',
'',
'<p>',
'  <strong>Note:</strong> Since customer data is randomly generated, enter ',
'  <strong>your own email address</strong> in the Email field to receive the order confirmation email.',
'</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(296293737583331419832)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(296395286403682242238)
,p_button_name=>'START_WORKFLOW'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Start Workflow'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(296293738400770419832)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(296395029081990359838)
,p_button_name=>'Open_Workflow_Console'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Open Workflow Console'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:504:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(296294739763014832672)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(296294739627363832671)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(296294739820547832673)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(296294739627363832671)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:502:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38627226581172195935)
,p_name=>'P503_DEFAULT_ADDRESS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(296395028238350359830)
,p_prompt=>'Use customer''s address as delivery address'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128233967183436329547)
,p_name=>'P503_PRODUCT_ID'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(296395028238350359830)
,p_prompt=>'Product'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'PRODUCTS'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Product -'
,p_cHeight=>1
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128233967292612329548)
,p_name=>'P503_QUANTITY'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(296395028238350359830)
,p_prompt=>'Quantity'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128234030902708619953)
,p_name=>'P503_PAYMENT_METHOD'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(296395028238350359830)
,p_prompt=>'Payment Method'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'PAYMENT METHOD'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct payment_method  ',
'  from #APEX$SOURCE_DATA#'))
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128234031161634619955)
,p_name=>'P503_STREET'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(296395028238350359830)
,p_prompt=>'Street'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128234031324904619957)
,p_name=>'P503_CITY'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(296395028238350359830)
,p_prompt=>'City'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128234031552380619959)
,p_name=>'P503_STATE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(296395028238350359830)
,p_prompt=>'State'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128234031633398619960)
,p_name=>'P503_COUNTRY'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(296395028238350359830)
,p_prompt=>'Country'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128234031703119619961)
,p_name=>'P503_POSTAL_CODE'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(296395028238350359830)
,p_prompt=>'Postal Code'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128234345534926635046)
,p_name=>'P503_EMAIL_ADDRESS'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(296395028238350359830)
,p_prompt=>'Email Address'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(296293588338477758485)
,p_name=>'P503_CUSTOMER_ID'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(296395028238350359830)
,p_prompt=>'Customer'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'CUSTOMERS'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Customer -'
,p_cHeight=>1
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(296293588506516758487)
,p_name=>'P503_STORE_ID'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(296395028238350359830)
,p_prompt=>'Store'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'STORES'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Store -'
,p_cHeight=>1
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(296395030294326359835)
,p_name=>'P503_WF_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(296395028238350359830)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(392721819444613465)
,p_name=>'Fetch Customer Email'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P503_CUSTOMER_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(392721881386613466)
,p_event_id=>wwv_flow_imp.id(392721819444613465)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P503_EMAIL_ADDRESS'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select email_address',
'  from eba_demo_json_customers',
' where customer_id = :P503_CUSTOMER_ID',
''))
,p_attribute_07=>'P503_CUSTOMER_ID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(392722202500613469)
,p_name=>'DA - Toggle Shipment Address Fields'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P503_DEFAULT_ADDRESS'
,p_condition_element=>'P503_DEFAULT_ADDRESS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Y'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(73648999223575)
,p_event_id=>wwv_flow_imp.id(392722202500613469)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P503_STREET,P503_CITY,P503_STATE,P503_COUNTRY,P503_POSTAL_CODE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(73756446223576)
,p_event_id=>wwv_flow_imp.id(392722202500613469)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P503_STREET,P503_CITY,P503_STATE,P503_COUNTRY,P503_POSTAL_CODE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(392889412270913058)
,p_name=>'DA - Show Email and Store'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P503_CUSTOMER_ID'
,p_condition_element=>'P503_CUSTOMER_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(392889437325913059)
,p_event_id=>wwv_flow_imp.id(392889412270913058)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Show Email'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P503_EMAIL_ADDRESS'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(392890453298913069)
,p_event_id=>wwv_flow_imp.id(392889412270913058)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P503_EMAIL_ADDRESS,P503_STORE_ID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(392889569052913060)
,p_event_id=>wwv_flow_imp.id(392889412270913058)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_name=>' Show Store'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P503_STORE_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(392889633123913061)
,p_name=>'DA - Hide Fields on Load'
,p_event_sequence=>70
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(392889797824913062)
,p_event_id=>wwv_flow_imp.id(392889633123913061)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P503_EMAIL_ADDRESS,P503_STORE_ID,P503_PRODUCT_ID,P503_QUANTITY,P503_PAYMENT_METHOD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(392889859268913063)
,p_name=>'DA - Show Product'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P503_STORE_ID'
,p_condition_element=>'P503_STORE_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(392889996782913064)
,p_event_id=>wwv_flow_imp.id(392889859268913063)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Show Product'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P503_PRODUCT_ID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(392890329685913068)
,p_event_id=>wwv_flow_imp.id(392889859268913063)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P503_PRODUCT_ID,P503_QUANTITY,P503_PAYMENT_METHOD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(392890603968913070)
,p_name=>'DA - Show Quantity , Payment Method and switch button'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P503_PRODUCT_ID'
,p_condition_element=>'P503_PRODUCT_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(392890869759913073)
,p_event_id=>wwv_flow_imp.id(392890603968913070)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Hide Quantity , Payment Method and and switch button'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P503_QUANTITY,P503_PAYMENT_METHOD,P503_DEFAULT_ADDRESS'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(392890812707913072)
,p_event_id=>wwv_flow_imp.id(392890603968913070)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_name=>'Show Quantity , Payment Method and switch button'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P503_QUANTITY,P503_PAYMENT_METHOD,P503_DEFAULT_ADDRESS'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(296293740295337419834)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_WORKFLOW'
,p_process_name=>'Start a new workflow'
,p_attribute_01=>'START'
,p_attribute_02=>wwv_flow_imp.id(128233967803689329553)
,p_attribute_04=>'P503_WF_ID'
,p_process_error_message=>'Error'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Workflow started'
,p_internal_uid=>6137831472528791
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(128234029734559619941)
,p_page_process_id=>wwv_flow_imp.id(296293740295337419834)
,p_workflow_variable_id=>wwv_flow_imp.id(128233967874739329554)
,p_page_id=>503
,p_value_type=>'ITEM'
,p_value=>'P503_CUSTOMER_ID'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(128234029866504619942)
,p_page_process_id=>wwv_flow_imp.id(296293740295337419834)
,p_workflow_variable_id=>wwv_flow_imp.id(128233968043509329555)
,p_page_id=>503
,p_value_type=>'ITEM'
,p_value=>'P503_PRODUCT_ID'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(128234029968342619943)
,p_page_process_id=>wwv_flow_imp.id(296293740295337419834)
,p_workflow_variable_id=>wwv_flow_imp.id(128233968082061329556)
,p_page_id=>503
,p_value_type=>'ITEM'
,p_value=>'P503_QUANTITY'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(128234030056550619944)
,p_page_process_id=>wwv_flow_imp.id(296293740295337419834)
,p_workflow_variable_id=>wwv_flow_imp.id(128233968219881329557)
,p_page_id=>503
,p_value_type=>'ITEM'
,p_value=>'P503_STORE_ID'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(128234067043780739235)
,p_page_process_id=>wwv_flow_imp.id(296293740295337419834)
,p_workflow_variable_id=>wwv_flow_imp.id(128234030167881619945)
,p_page_id=>503
,p_value_type=>'ITEM'
,p_value=>'P503_PAYMENT_METHOD'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(128234069767073763494)
,p_page_process_id=>wwv_flow_imp.id(296293740295337419834)
,p_workflow_variable_id=>wwv_flow_imp.id(128234030340412619947)
,p_page_id=>503
,p_value_type=>'ITEM'
,p_value=>'P503_STREET'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(128234070421722763495)
,p_page_process_id=>wwv_flow_imp.id(296293740295337419834)
,p_workflow_variable_id=>wwv_flow_imp.id(128234030437557619948)
,p_page_id=>503
,p_value_type=>'ITEM'
,p_value=>'P503_CITY'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(128234071249485763496)
,p_page_process_id=>wwv_flow_imp.id(296293740295337419834)
,p_workflow_variable_id=>wwv_flow_imp.id(128234030495353619949)
,p_page_id=>503
,p_value_type=>'ITEM'
,p_value=>'P503_STATE'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(128234072045382763496)
,p_page_process_id=>wwv_flow_imp.id(296293740295337419834)
,p_workflow_variable_id=>wwv_flow_imp.id(128234030605504619950)
,p_page_id=>503
,p_value_type=>'ITEM'
,p_value=>'P503_COUNTRY'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(128234072807953763496)
,p_page_process_id=>wwv_flow_imp.id(296293740295337419834)
,p_workflow_variable_id=>wwv_flow_imp.id(128234030708273619951)
,p_page_id=>503
,p_value_type=>'ITEM'
,p_value=>'P503_POSTAL_CODE'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(128234471432052685434)
,p_page_process_id=>wwv_flow_imp.id(296293740295337419834)
,p_workflow_variable_id=>wwv_flow_imp.id(128234345768585635048)
,p_page_id=>503
,p_value_type=>'ITEM'
,p_value=>'P503_EMAIL_ADDRESS'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(637104400796030719)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CLEAR_FORM_ITEMS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  :P503_CUSTOMER_ID      := null;',
'  :P503_STORE_ID         := null;',
'  :P503_PRODUCT_ID       := null;',
'  :P503_QUANTITY         := 1;',
'  :P503_PAYMENT_METHOD   := ''Card'';',
'  :P503_STREET           := null;',
'  :P503_CITY             := null;',
'  :P503_STATE            := null;',
'  :P503_COUNTRY          := null;',
'  :P503_POSTAL_CODE      := null;',
'  :P503_DEFAULT_ADDRESS  := ''Y'';',
'  :P503_EMAIL_ADDRESS    := null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>9599173390718216
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(737154309520057)
,p_process_sequence=>5
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fetch Customer Address'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  select json_value(customer_metadata, ''$.address.street'')          as street,',
'         json_value(customer_metadata, ''$.address.city'')            as city,',
'         json_value(customer_metadata, ''$.address.state_province'')  as state,',
'         json_value(customer_metadata, ''$.address.country'')         as country,',
'         json_value(customer_metadata, ''$.address.postal_code'')     as postal_code',
'    into :P503_STREET,',
'         :P503_CITY,',
'         :P503_STATE,',
'         :P503_COUNTRY,',
'         :P503_POSTAL_CODE',
'    from eba_demo_json_customers',
'   where customer_id = :P503_CUSTOMER_ID;',
'exception',
'   when no_data_found then',
'      null;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P503_DEFAULT_ADDRESS = ''Y''',
'and :P503_CUSTOMER_ID is not null'))
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>13539640835675303
);
wwv_flow_imp.component_end;
end;
/
