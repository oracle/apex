prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7230
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(296295321451259646379)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12730301217410334)
,p_group_name=>'Data Presentation'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12730181107406482)
,p_group_name=>'Duality View'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12729572774398483)
,p_group_name=>'JSON Sources'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12732622639801678)
,p_group_name=>'SQL/JSON Functions'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12731586493424370)
,p_group_name=>'Use Cases'
);
wwv_flow_imp.component_end;
end;
/
