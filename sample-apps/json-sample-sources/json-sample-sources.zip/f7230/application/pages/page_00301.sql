prompt --application/pages/page_00301
begin
--   Manifest
--     PAGE: 00301
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>301
,p_name=>'JSON_TABLE'
,p_alias=>'JSON-TABLE'
,p_step_title=>'JSON_TABLE'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(12732622639801678)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(296291459790246406712)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(296295315947355646367)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(296291460555343406717)
,p_plug_name=>'JSON_TABLE'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select      o.order_id,',
'            o.order_status,',
'            c.full_name,',
'            c.email_address,',
'            j.shipment_method,',
'            j.shipment_status,',
'            j.estimated_delivery,',
'            j.payment_method,',
'            j.payment_status,',
'            j.street,',
'            j.city,',
'            j.state_province,',
'            j.country,',
'            j.postal_code,',
'            j.notes',
'from        eba_demo_json_orders           o,',
'            eba_demo_json_customers        c,',
'            json_table(o.order_metadata, ''$''',
'                        columns (',
'                            shipment_method         varchar2(20)    path ''$.shipment.method'',',
'                            shipment_status         varchar2(20)    path ''$.shipment.status'',',
'                            estimated_delivery      date            path ''$.shipment.estimated_delivery'',',
'                            payment_method          varchar2(20)    path ''$.payment.method'',',
'                            payment_status          varchar2(20)    path ''$.payment.status'',',
'                            street                  varchar2(100)   path ''$.delivery_address.street'',',
'                            city                    varchar2(100)   path ''$.delivery_address.city'',',
'                            state_province          varchar2(100)   path ''$.delivery_address.state_province'',',
'                            country                 varchar2(50)    path ''$.delivery_address.country'',',
'                            postal_code             varchar2(20)    path ''$.delivery_address.postal_code'',',
'                            notes                   varchar2(200)   path ''$.notes''',
'                        )',
'                    ) j',
'where       o.customer_id = c.customer_id',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'JSON_TABLE'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(296291460587562406717)
,p_name=>'JSON_TABLE'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ORACLE'
,p_internal_uid=>3858123697515674
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296291461268306406719)
,p_db_column_name=>'ORDER_ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Order ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296291461684996406720)
,p_db_column_name=>'FULL_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Full Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'Y'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296291462107884406720)
,p_db_column_name=>'EMAIL_ADDRESS'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Email Address'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(566762340955876125)
,p_db_column_name=>'ORDER_STATUS'
,p_display_order=>13
,p_column_identifier=>'O'
,p_column_label=>'Order Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296291462539826406721)
,p_db_column_name=>'SHIPMENT_METHOD'
,p_display_order=>23
,p_column_identifier=>'D'
,p_column_label=>'Shipment Method'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296291462948243406721)
,p_db_column_name=>'SHIPMENT_STATUS'
,p_display_order=>33
,p_column_identifier=>'E'
,p_column_label=>'Shipment Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296291463304415406721)
,p_db_column_name=>'ESTIMATED_DELIVERY'
,p_display_order=>43
,p_column_identifier=>'F'
,p_column_label=>'Estimated Delivery'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296291463753523406721)
,p_db_column_name=>'PAYMENT_METHOD'
,p_display_order=>53
,p_column_identifier=>'G'
,p_column_label=>'Payment Method'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296291464163378406722)
,p_db_column_name=>'PAYMENT_STATUS'
,p_display_order=>63
,p_column_identifier=>'H'
,p_column_label=>'Payment Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(566762212466876124)
,p_db_column_name=>'STREET'
,p_display_order=>73
,p_column_identifier=>'N'
,p_column_label=>'Street'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296291464490218406722)
,p_db_column_name=>'CITY'
,p_display_order=>83
,p_column_identifier=>'I'
,p_column_label=>'City'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296291464893153406722)
,p_db_column_name=>'STATE_PROVINCE'
,p_display_order=>93
,p_column_identifier=>'J'
,p_column_label=>'State Province'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296291465297785406723)
,p_db_column_name=>'COUNTRY'
,p_display_order=>103
,p_column_identifier=>'K'
,p_column_label=>'Country'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296291465752011406723)
,p_db_column_name=>'POSTAL_CODE'
,p_display_order=>113
,p_column_identifier=>'L'
,p_column_label=>'Postal Code'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296291466098752406723)
,p_db_column_name=>'NOTES'
,p_display_order=>123
,p_column_identifier=>'M'
,p_column_label=>'Notes'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(296291466977920411194)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'38646'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FULL_NAME:ORDER_STATUS:SHIPMENT_METHOD:SHIPMENT_STATUS:ESTIMATED_DELIVERY:PAYMENT_METHOD:PAYMENT_STATUS:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(296291579027833882587)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'This page demonstrates the use of the <strong>JSON_TABLE</strong> function in Oracle APEX to transform JSON data into relational columns. Based on the <strong>EBA_DEMO_JSON_ORDERS</strong> table, it extracts structured information from the <strong>or'
||'der_metadata</strong> JSON field, enabling seamless querying and reporting alongside customer data.',
'</p>',
'',
'<p>',
'To get started, explore the Interactive Report to see how JSON attributes are extracted into relational columns for filtering, sorting, and reporting purposes.',
'</p>',
'',
'<p>',
'To view the SQL query used in this example, open the Page Designer for this page and navigate to <strong>SQL Query</strong> under the source section of the Interactive Report region.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(296292464477192899573)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(296291459790246406712)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:302:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(296292464621638899574)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(296291459790246406712)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp.component_end;
end;
/
