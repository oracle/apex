prompt --application/pages/page_00404
begin
--   Manifest
--     PAGE: 00404
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>404
,p_name=>'Map'
,p_alias=>'MAP'
,p_step_title=>'Map'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(12730301217410334)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1622958387331656)
,p_name=>'Raw JSON Document'
,p_region_name=>'raw_json_dialog'
,p_template=>2672673746673652531
,p_display_sequence=>90
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  select json_serialize(',
'             json_transform(',
'                 data,',
'                 remove ''$._metadata''',
'             )',
'             pretty',
'         ) as json_content',
'    from eba_demo_json_stores_dv',
'   where json_value(data, ''$._id'') = :P404_STORE_ID;',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P404_STORE_ID'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1626245081331689)
,p_query_column_id=>1
,p_column_alias=>'JSON_CONTENT'
,p_column_display_sequence=>10
,p_column_heading=>'Json Content'
,p_column_html_expression=>'<pre>#JSON_CONTENT#</pre>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1625176912331678)
,p_plug_name=>'Stores Report'
,p_region_name=>'stores_report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select json_value(data,''$._id'')                            as store_id,',
'       json_value(data,''$.storeName'')                      as store_name,',
'       json_value(data,''$.country'')                        as country,',
'       json_value(data,''$.address'')                        as physical_address',
'  from eba_demo_json_stores_dv',
' where to_number(json_value(data,''$.location.latitude''))',
'       between nvl(:P404_MIN_LAT,-90)  and nvl(:P404_MAX_LAT,90)',
'   and to_number(json_value(data,''$.location.longitude''))',
'       between nvl(:P404_MIN_LON,-180) and nvl(:P404_MAX_LON,180)'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P404_MIN_LAT,P404_MAX_LAT,P404_MIN_LON,P404_MAX_LON'
,p_plug_query_num_rows=>8
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'DESCRIPTION', '&PHYSICAL_ADDRESS.',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'MISC', '&COUNTRY.',
  'REMOVE_PADDING', 'N',
  'TITLE', '&STORE_NAME.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1625750275331684)
,p_name=>'STORE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STORE_ID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1625867363331685)
,p_name=>'STORE_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STORE_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1625978370331686)
,p_name=>'COUNTRY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COUNTRY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1626104350331687)
,p_name=>'PHYSICAL_ADDRESS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PHYSICAL_ADDRESS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(393451835660022536)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'This page provides an interactive map view of store locations using the <strong>EBA_DEMO_JSON_STORE_DV</strong> Duality View. The map displays store records with color-coded pins based on country code, making it easy to distinguish locations at a gla'
||'nce. On the right, a classic report shows the stores currently visible on the map, updating dynamically as users zoom in and out to focus on specific regions. This layout combines geographic exploration with a synchronized list view for a clear and p'
||'ractical store lookup experience.',
'</p>',
'',
'<p>',
'To get started, navigate the map by zooming or panning to explore store locations in different regions. ',
'The report on the right updates automatically to display only the stores currently visible on the map.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(597902763780976045)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(296295315947355646367)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(597903410389976046)
,p_plug_name=>'Map'
,p_region_name=>'stores_map'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>20
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(597903882837976046)
,p_region_id=>wwv_flow_imp.id(597903410389976046)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_init_zoomlevel_static=>'2'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'RECTANGLE_ZOOM:SCALE_BAR'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(597904318981976046)
,p_map_region_id=>wwv_flow_imp.id(597903882837976046)
,p_name=>'Stores'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'DUALITY_VIEW'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       apex_metadata_etag,',
'       apex_metadata_asof,',
'       country,',
'       storename,',
'       country_code,',
'       case when lower(country_code) = ''us'' then ''red'' when lower(country_code) = ''in'' then ''green'' else ''blue'' end as pin_color,',
'       address,',
'       location_latitude,',
'       location_longitude',
'  from #APEX$SOURCE_DATA#'))
,p_document_source_id=>wwv_flow_imp.id(607855591485602045)
,p_source_post_processing=>'SQL'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LOCATION_LONGITUDE'
,p_latitude_column=>'LOCATION_LATITUDE'
,p_fill_color=>'&PIN_COLOR.'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&STORENAME.</strong><br>',
'&ADDRESS.<br>&COUNTRY_CODE.<br>'))
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(597906694565996339)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(597902763780976045)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:405:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(597906734298996340)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(597902763780976045)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:408:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1623111172331657)
,p_name=>'P404_STORE_ID'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(1622958387331656)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(597905800392996330)
,p_name=>'P404_MIN_LAT'
,p_item_sequence=>50
,p_item_default=>'-90'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(597905851049996331)
,p_name=>'P404_MAX_LAT'
,p_item_sequence=>60
,p_item_default=>'90'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(597905922328996332)
,p_name=>'P404_MIN_LON'
,p_item_sequence=>70
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-180',
''))
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(597906071379996333)
,p_name=>'P404_MAX_LON'
,p_item_sequence=>80
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'180',
''))
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(597861597903507858)
,p_name=>'Map Bounds Changed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(597903410389976046)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapchanged'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(597861608220507859)
,p_event_id=>wwv_flow_imp.id(597861597903507858)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Retrieve Map Bounds'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let map = apex.region("stores_map").call("getMapObject");',
'let bounds = map.getBounds();',
'apex.item("P404_MIN_LAT").setValue(bounds.getSouth());',
'apex.item("P404_MAX_LAT").setValue(bounds.getNorth());',
'apex.item("P404_MIN_LON").setValue(bounds.getWest());',
'apex.item("P404_MAX_LON").setValue(bounds.getEast());'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(73878596223577)
,p_event_id=>wwv_flow_imp.id(597861597903507858)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Report'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1625176912331678)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1624291722331669)
,p_name=>'Show JSON'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P404_STORE_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1624865478331675)
,p_event_id=>wwv_flow_imp.id(1624291722331669)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1622958387331656)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1624472645331671)
,p_event_id=>wwv_flow_imp.id(1624291722331669)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1622958387331656)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1626948446331696)
,p_name=>'View Store JSON'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.viewbutton'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#stores_report'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1627041248331697)
,p_event_id=>wwv_flow_imp.id(1626948446331696)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P404_STORE_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.dataset.storeId'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(1626190116331688)
,p_region_id=>wwv_flow_imp.id(1625176912331678)
,p_position_id=>362316004162771045
,p_display_sequence=>10
,p_template_id=>362316605839802174
,p_label=>'View'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_link_attributes=>'data-store-id="&STORE_ID."'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa fa-eye'
,p_action_css_classes=>'viewbutton'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp.component_end;
end;
/
