prompt --application/deployment/install/install_create_sequences
begin
--   Manifest
--     INSTALL: INSTALL-create sequences
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(296295620141247110267)
,p_install_id=>wwv_flow_imp.id(296295828950238257576)
,p_name=>'create sequences'
,p_sequence=>5
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- ===========================================================================',
'--  Sequence Definitions',
'-- ===========================================================================',
'begin',
'    execute immediate ''',
'        create sequence eba_demo_json_customers_seq',
'            minvalue 1',
'            maxvalue 9999999999999999999999999999',
'            increment by 1 ',
'            start with 21 ',
'            cache 20',
'            noorder',
'            nocycle',
'            nokeep',
'            noscale',
'            global',
'    '';',
'exception',
'    when others then',
'        if sqlcode = -955 then',
'            null; ',
'        else',
'            raise;',
'        end if;',
'end;',
'/',
'',
'begin',
'    execute immediate ''',
'        create sequence eba_demo_json_products_seq',
'            minvalue 1',
'            maxvalue 9999999999999999999999999999',
'            increment by 1 ',
'            start with 47 ',
'            cache 20',
'            noorder',
'            nocycle',
'            nokeep',
'            noscale',
'            global',
'    '';',
'exception',
'    when others then',
'        if sqlcode = -955 then',
'            null; ',
'        else',
'            raise;',
'        end if;',
'end;',
'/',
'',
'begin',
'    execute immediate ''',
'        create sequence eba_demo_json_orders_seq ',
'            minvalue 1',
'            maxvalue 9999999999999999999999999999',
'            increment by 1 ',
'            start with 1891 ',
'            cache 20',
'            noorder',
'            nocycle',
'            nokeep',
'            noscale',
'            global',
'    '';',
'exception',
'    when others then',
'        if sqlcode = -955 then',
'            null; ',
'        else',
'            raise;',
'        end if;',
'end;',
'/',
'',
'begin',
'    execute immediate ''',
'        create sequence eba_demo_json_stores_seq ',
'            minvalue 1',
'            maxvalue 9999999999999999999999999999',
'            increment by 1 ',
'            start with 24 ',
'            cache 20',
'            noorder',
'            nocycle',
'            nokeep',
'            noscale',
'            global',
'    '';',
'exception',
'    when others then',
'        if sqlcode = -955 then',
'            null; ',
'        else',
'            raise;',
'        end if;',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
