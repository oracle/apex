prompt --application/deployment/install/install_load_data
begin
--   Manifest
--     INSTALL: INSTALL- Load Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(296292070758789073769)
,p_install_id=>wwv_flow_imp.id(296295828950238257576)
,p_name=>' Load Data'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-------------------------------------------------------------------------------------------------------',
'-- Load Data',
'-------------------------------------------------------------------------------------------------------',
'',
'create or replace package eba_demo_json_data_pkg authid current_user is',
'    -- clears all the data in the database tables',
'    procedure clear_data;',
'    -- loads data into the database tables',
'    procedure load_data;',
'    -- loads images into the eba_demo_json_products table',
'    procedure load_product_images(p_app_id in number, p_file_name in varchar2);',
'    -- reset all the data in the database tables',
'    procedure reset_data;',
'',
'end eba_demo_json_data_pkg;',
'/',
'',
'create or replace package body eba_demo_json_data_pkg is',
'',
'    procedure clear_data is',
'    begin',
'        delete from eba_demo_json_stores;',
'        delete from eba_demo_json_products;',
'        delete from eba_demo_json_customers;',
'        delete from eba_demo_json_orders;',
'        delete from eba_demo_json_order_items;',
'        delete from eba_demo_json_support_ticket;',
'    end clear_data;',
'',
'    procedure load_data is',
'    begin',
'        -- Customers data',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (1,''Tammy Bryant'',''tammy.bryant@example.com'',34.0522,-118.2437,json (''{"birth_year":1992,"gender":"Female","loyalty_ti'
||'er":"Silver","preferred_lang":"French","subscribed":"false","signup_channel":"Mobile","address":{"street":"101 Oak Ave","city":"Los Angeles","state_province":"California","postal_code":"90001","country":"USA"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (2,''Roy White'',''roy.white@example.com'',41.8781,-87.6298,json (''{"birth_year":1988,"gender":"Male","loyalty_tier":"Gold'
||'","preferred_lang":"Spanish","subscribed":"false","signup_channel":"Store","address":{"street":"202 Maple Rd","city":"Chicago","state_province":"Illinois","postal_code":"60601","country":"USA"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (3,''Gary Jenkins'',''gary.jenkins@example.com'',29.7604,-95.3698,json (''{"birth_year":1979,"gender":"Male","loyalty_tier"'
||':"Platinum","preferred_lang":"English","subscribed":"true","signup_channel":"Referral","address":{"street":"303 Cedar Blvd","city":"Houston","state_province":"Texas","postal_code":"77001","country":"USA"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (4,''Victor Morris'',''victor.morris@example.com'',33.4484,-112.0740,json (''{"birth_year":1995,"gender":"Male","loyalty_ti'
||'er":"Bronze","preferred_lang":"French","subscribed":"false","signup_channel":"Web","address":{"street":"404 Pine Dr","city":"Phoenix","state_province":"Arizona","postal_code":"85001","country":"USA"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (5,''Beverly Hughes'',''beverly.hughes@example.com'',39.9526,-75.1652,json (''{"birth_year":1985,"gender":"Female","loyalty'
||'_tier":"Silver","preferred_lang":"Spanish","subscribed":"false","signup_channel":"Mobile","address":{"street":"505 Main St","city":"Philadelphia","state_province":"Pennsylvania","postal_code":"19103","country":"USA"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (6,''Evelyn Torres'',''evelyn.torres@example.com'',29.4241,-98.4936,json (''{"birth_year":1990,"gender":"Female","loyalty_t'
||'ier":"Gold","preferred_lang":"English","subscribed":"true","signup_channel":"Store","address":{"street":"606 Oak Ave","city":"San Antonio","state_province":"Texas","postal_code":"78205","country":"USA"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (7,''Carl Lee'',''carl.lee@example.com'',32.7157,-117.1611,json (''{"birth_year":1982,"gender":"Male","loyalty_tier":"Bronz'
||'e","preferred_lang":"French","subscribed":"false","signup_channel":"Referral","address":{"street":"707 Maple Rd","city":"San Diego","state_province":"California","postal_code":"92101","country":"USA"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (8,''Douglas Flores'',''douglas.flores@example.com'',32.7767,-96.7970,json (''{"birth_year":1975,"gender":"Male","loyalty_t'
||'ier":"Silver","preferred_lang":"Spanish","subscribed":"false","signup_channel":"Web","address":{"street":"808 Cedar Blvd","city":"Dallas","state_province":"Texas","postal_code":"75201","country":"USA"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (9,''Norma Robinson'',''norma.robinson@example.com'',37.7749,-122.4194,json (''{"birth_year":1987,"gender":"Female","loyalt'
||'y_tier":"Gold","preferred_lang":"English","subscribed":"true","signup_channel":"Mobile","address":{"street":"909 Pine Dr","city":"San Francisco","state_province":"California","postal_code":"94103","country":"USA"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (10,''Gregory Sanchez'',''gregory.sanchez@example.com'',47.6062,-122.3321,json (''{"birth_year":1980,"gender":"Male","loyal'
||'ty_tier":"Platinum","preferred_lang":"French","subscribed":"false","signup_channel":"Store","address":{"street":"1010 Main St","city":"Seattle","state_province":"Washington","postal_code":"98101","country":"USA"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (11,''Judy Evans'',''judy.evans@example.com'',39.7392,-104.9903,json (''{"birth_year":1993,"gender":"Female","loyalty_tier"'
||':"Bronze","preferred_lang":"Spanish","subscribed":"false","signup_channel":"Referral","address":{"street":"1111 Oak Ave","city":"Denver","state_province":"Colorado","postal_code":"80202","country":"USA"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (12,''Jean Patterson'',''jean.patterson@example.com'',42.3601,-71.0589,json (''{"birth_year":1986,"gender":"Female","loyalt'
||'y_tier":"Silver","preferred_lang":"English","subscribed":"true","signup_channel":"Web","address":{"street":"1212 Maple Rd","city":"Boston","state_province":"Massachusetts","postal_code":"02108","country":"USA"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (13,''Michelle Ramirez'',''michelle.ramirez@example.com'',25.7617,-80.1918,json (''{"birth_year":1991,"gender":"Female","lo'
||'yalty_tier":"Gold","preferred_lang":"French","subscribed":"false","signup_channel":"Mobile","address":{"street":"1313 Cedar Blvd","city":"Miami","state_province":"Florida","postal_code":"33101","country":"USA"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (14,''Elizabeth Martinez'',''elizabeth.martinez@example.com'',43.6532,-79.3832,json (''{"birth_year":1984,"gender":"Female"'
||',"loyalty_tier":"Platinum","preferred_lang":"Spanish","subscribed":"false","signup_channel":"Store","address":{"street":"1414 Pine Dr","city":"Toronto","state_province":"Ontario","postal_code":"M5H 2N2","country":"Canada"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (15,''Walter Rogers'',''walter.rogers@example.com'',45.5017,-73.5673,json (''{"birth_year":1978,"gender":"Male","loyalty_ti'
||'er":"Bronze","preferred_lang":"English","subscribed":"true","signup_channel":"Web","address":{"street":"1515 Main St","city":"Montreal","state_province":"Quebec","postal_code":"H2Y 1C6","country":"Canada"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (16,''Ralph Foster'',''ralph.foster@example.com'',49.2827,-123.1207,json (''{"birth_year":1983,"gender":"Male","loyalty_tie'
||'r":"Silver","preferred_lang":"French","subscribed":"false","signup_channel":"Referral","address":{"street":"1616 Oak Ave","city":"Vancouver","state_province":"British Columbia","postal_code":"V5K 0A1","country":"Canada"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (17,''Tina Simmons'',''tina.simmons@example.com'',51.0447,-114.0719,json (''{"birth_year":1994,"gender":"Female","loyalty_t'
||'ier":"Gold","preferred_lang":"Spanish","subscribed":"false","signup_channel":"Mobile","address":{"street":"1717 Maple Rd","city":"Calgary","state_province":"Alberta","postal_code":"T2P 1J9","country":"Canada"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (18,''Peter Jones'',''peter.jones@example.com'',45.4215,-75.6972,json (''{"birth_year":1981,"gender":"Male","loyalty_tier":'
||'"Platinum","preferred_lang":"English","subscribed":"true","signup_channel":"Store","address":{"street":"1818 Cedar Blvd","city":"Ottawa","state_province":"Ontario","postal_code":"K1A 0B1","country":"Canada"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (19,''Kathryn Rogers'',''kathryn.rogers@example.com'',53.5461,-113.4938,json (''{"birth_year":1989,"gender":"Female","loyal'
||'ty_tier":"Silver","preferred_lang":"French","subscribed":"false","signup_channel":"Referral","address":{"street":"1919 Pine Dr","city":"Edmonton","state_province":"Alberta","postal_code":"T5J 0N3","country":"Canada"}}''));',
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (20,''Dennis Lopez'',''dennis.lopez@example.com'',40.7128,-74.0060,json (''{"birth_year":1977,"gender":"Male","loyalty_tier'
||'":"Bronze","preferred_lang":"Spanish","subscribed":"true","signup_channel":"Web","address":{"street":"2020 Main St","city":"New York","state_province":"New York","postal_code":"10001","country":"USA"}}''));',
'       -- Stores data',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (1, ''Online'', ''https://www.example.com'', ''Oracle Parkway, Redwood Shores'', 39.5, -112.3, ''US'',''USA'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (2, ''San Francisco'', null, ''Oracle Parkway, Redwood Shores'', 37.529395, -122.267237, ''US'',''USA'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (3, ''Seattle'', null, ''1501 Fourth Avenue Suite 1800 Seattle, WA 98101'', 47.6053, -122.33221, ''US'',''USA'')'
||';',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (4, ''New York City'', null, ''205 Lexington Ave 7th Floor New York, NY 10016'', 40.745216, -73.980518, ''US'''
||',''USA'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (5, ''Chicago'', null, ''233 South Wacker Dr. 45th Floor Chicago, IL 60606'', 41.878751, -87.636675, ''US'',''U'
||'SA'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (6, ''London'', null, ''One South Place London EC2M 2RB'', 51.519281, -0.087296, ''GB'',''United kingdom'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (7, ''Bucharest'', null, ''Floreasca Park 43 Soseaua Pipera, corp B. Sector 2 Bucharest, 014254 RO'', 44.432'
||'25, 26.10626, ''RO'',''Romania'');',
unistr('        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (8, ''Berlin'', null, ''Behrenstrasse 42 (Humboldt Carr\00E9) 10117 Berlin'', 52.5161, 13.3873, ''DE'',''Germany'');'),
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (9, ''Utrecht'', null, ''Hertogswetering 163-167, 3543 AS Utrecht, Netherlands'', 52.103263, 5.061644, ''NL'','
||'''Netherlands'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (10, ''Madrid'', null, ''C/ Jose Echegaray 6B Las Rozas 28230 Madrid'', 40.4929, -3.8737, ''ES'',''Spain'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (11, ''Johannesburg'', null, ''Woodmead North Office Park 54 Maxwell Drive Jukskeiview, Sandton, 2196'', -26'
||'.044222, 28.094662, ''ZA'',''South Africa'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (12, ''Lagos'', null, ''1391 Tiamiyu Savage St, Victoria Island, Lagos, Nigeria'', 6.42806, 3.42199, ''NG'',''N'
||'igeria'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (13, ''Bengaluru'', null, ''193, Bannerghatta Main Rd, Industrial Area, Stage 2, BTM Layout, Bengaluru, Kar'
||'nataka 560076, India'', 12.8939, 77.5978, ''IN'',''India'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (14, ''Mumbai'', null, ''First International Financial Center Unit No. 501, Level 5 No. C54 & 55, G Block B'
||'andra Kurla Complex CTS No. 4207, Kolekalyan Village Mumbai - 400 051 India'', 19.069405, 72.870143, ''IN'',''India'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (15, ''New Delhi'', null, ''F-01/02, First Floor Salcon Rasvillas D-1, District Centre, Saket, New Delhi - '
||'110017 India'', 28.527693, 77.220135, ''IN'',''India'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (16, ''Sydney'', null, ''Riverside Corporate Park 4 Julius Avenue North Ryde NSW 2113'', -33.797279, 151.143'
||'826, ''AU'',''Australia'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (17, ''Perth'', null, ''Level 9 225 St Georges Terrace Perth WA 6000'', -31.953715, 115.851645, ''AU'',''Austra'
||'lia'');',
unistr('        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (18, ''Sao Paulo'', null, ''Rua Dr. Jos\00E9 \00C1ureo Bustamante, 455 - Vila Cordeiro, CEP 04710-090 Sao Paulo'', -')
||'23.5475, -46.63611, ''BR'',''Brazil'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (19, ''Buenos Aires'', null, ''Juana Manso 1069, Buenos Aires, Argentina'', -34.61016, -58.362867, ''AR'',''Arg'
||'entine'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (20, ''Mexico City'', null, ''Montes Urales # 470 P3 Col. Lomas de Chapultepec Delegacion Miguel Hidalgo - '
||'C.P. 11000'', 19.428489, -99.205745, ''MX'',''Mexico'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (21, ''Beijing'', null, ''China, Beijing Shi, Haidian Qu, Dongbeiwang W Rd, 8, 100085'', 40.0572, 116.290061'
||', ''CN'',''China'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (22, ''Tokyo'', null, ''2 Chome-5-? Kitaaoyama, Minato City, Tokyo 107-0061, Japan'', 35.671534, 139.718584,'
||' ''JP'',''Japan'');',
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, country) values (23, ''Tel Aviv'', null, ''B, Aharon Bart St 18, Petah Tikva, 4951400, Israel'', 32.100664, 34.862138, ''IL'','
||'''Israel'');',
'       --Orders data',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (453,to_timestamp(''23-JUL-25 12.13.03.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),4,''Complete'',4,json'
||' (''{"shipment": {"method": "Express","status": "Processing","estimated_delivery": "2025-07-27"},"payment": {"method": "Card","status": "Paid"},"delivery_address": {"street": "553 Main St","city": "Miami","state_province": "Florida","country": "USA","'
||'postal_code": "33101"},"notes": "call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (506,to_timestamp(''07-AUG-25 10.56.44.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),4,''Complete'',1,json'
||' (''{"shipment": {"method": "Standard","status": "Delivered","estimated_delivery": "2025-08-09"},"payment": {"method": "Paypal","status": "Paid"},"delivery_address": {"street": "606 Main St","city": "San Antonio","state_province": "Texas","country": "'
||'USA","postal_code": "78201"},"notes": "hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (513,to_timestamp(''09-AUG-25 08.00.22.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),15,''Cancelled'',1,js'
||'on (''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-08-13"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"613 Main St","city":"Miami","state_province":"Florida","country":"USA","postal_cod'
||'e":"33101"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (544,to_timestamp(''16-AUG-25 06.32.10.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Open'',1,json(''{"'
||'shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-08-21"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"644 Main St","city":"Phoenix","state_province":"Arizona","country":"USA","posta'
||'l_code":"85001"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (585,to_timestamp(''26-AUG-25 11.02.38.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),4,''Paid'',1,json(''{"'
||'shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-08-27"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"685 Main St","city":"Philadelphia","state_province":"Pennsylvania","country":"USA","posta'
||'l_code":"19101"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (608,to_timestamp(''01-SEP-25 08.01.41.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Open'',1,json (''{'
||'"shipment": {"method": "Standard","status": "Delivered","estimated_delivery": "2025-09-05"},"payment": {"method": "Paypal","status": "Paid"},"delivery_address": {"street": "708 Main St","city": "Dallas","state_province": "Texas","country": "USA","pos'
||'tal_code": "75201"},"notes": "leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (672,to_timestamp(''13-SEP-25 01.37.34.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),4,''Complete'',4,json'
||' (''{"shipment": {"method": "Standard","status": "Processing","estimated_delivery": "2025-09-16"},"payment": {"method": "Card","status": "Paid"},"delivery_address": {"street": "772 Main St","city": "Boston","state_province": "Massachusetts","country":'
||' "USA","postal_code": "02108"},"notes": "leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (687,to_timestamp(''17-SEP-25 12.09.10.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),16,''Complete'',1,jso'
||'n(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-09-20"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"787 Main St","city":"San Diego","state_province":"California","country":"USA","posta'
||'l_code":"92101"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (707,to_timestamp(''20-SEP-25 06.12.35.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),5,''Paid'',1,json(''{"'
||'shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-09-23"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"807 Main St","city":"San Diego","state_province":"California","country":"USA","postal_co'
||'de":"92101"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (760,to_timestamp(''29-SEP-25 07.19.53.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),19,''Complete'',1,jso'
||'n(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-09-30"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"860 Main St","city":"New York","state_province":"New York","country":"USA"'
||',"postal_code":"10001"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (761,to_timestamp(''29-SEP-25 08.35.11.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),11,''Open'',1,json(''{'
||'"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-10-01"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"861 Main St","city":"Los Angeles","state_province":"California","country":"USA","postal'
||'_code":"90001"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (765,to_timestamp(''29-SEP-25 09.36.52.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),2,''Complete'',2,json'
||'(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-09-30"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"865 Main St","city":"Philadelphia","state_province":"Pennsylvania","country":"USA","p'
||'ostal_code":"19101"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (766,to_timestamp(''30-SEP-25 12.38.08.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Complete'',1,json'
||'(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-10-02"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"866 Main St","city":"San Antonio","state_province":"Texas","country":"USA",'
||'"postal_code":"78201"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (769,to_timestamp(''30-SEP-25 02.49.28.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),6,''Refunded'',1,json'
||'(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-10-05"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"869 Main St","city":"San Francisco","state_province":"California","country":'
||'"USA","postal_code":"94102"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (808,to_timestamp(''08-OCT-25 04.06.33.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),14,''Paid'',1,json(''{'
||'"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-10-12"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"908 Main St","city":"Dallas","state_province":"Texas","country":"USA","postal_'
||'code":"75201"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (832,to_timestamp(''12-OCT-25 11.16.40.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Complete'',3,json'
||'(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-10-15"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"932 Main St","city":"Boston","state_province":"Massachusetts","country":"US'
||'A","postal_code":"02108"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (839,to_timestamp(''14-OCT-25 01.59.20.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),12,''Complete'',12,js'
||'on(''{"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-10-19"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"939 Main St","city":"Edmonton","state_province":"Alberta","country":"Canada","post'
||'al_code":"T5J 0N3"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (862,to_timestamp(''19-OCT-25 02.34.20.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),7,''Complete'',7,json'
||'(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-10-22"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"962 Main St","city":"Chicago","state_province":"Illinois","country":"USA","'
||'postal_code":"60601"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (899,to_timestamp(''27-OCT-25 09.42.00.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),17,''Cancelled'',1,js'
||'on(''{"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-11-01"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"999 Main St","city":"Edmonton","state_province":"Alberta","country":"Canada","post'
||'al_code":"T5J 0N3"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (920,to_timestamp(''30-OCT-25 05.59.30.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),4,''Complete'',4,json'
||'(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-10-31"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"120 Main St","city":"New York","state_province":"New York","country":"USA","postal_'
||'code":"10001"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (928,to_timestamp(''31-OCT-25 05.07.56.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),9,''Complete'',1,json'
||'(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-11-04"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"128 Main St","city":"Dallas","state_province":"Texas","country":"USA","post'
||'al_code":"75201"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (943,to_timestamp(''03-NOV-25 04.41.53.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),10,''Open'',1,json(''{'
||'"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-11-07"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"143 Main St","city":"Houston","state_province":"Texas","country":"USA","postal_'
||'code":"77001"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (950,to_timestamp(''05-NOV-25 07.02.43.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),7,''Complete'',1,json'
||'(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-11-06"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"150 Main St","city":"Seattle","state_province":"Washington","country":"USA","postal'
||'_code":"98101"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (960,to_timestamp(''06-NOV-25 09.18.36.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),11,''Open'',1,json(''{'
||'"shipment":{"method":"Standard","status":"Processing","estimated_delivery":"2025-11-07"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"160 Main St","city":"New York","state_province":"New York","country":"USA","postal_code'
||'":"10001"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (968,to_timestamp(''08-NOV-25 12.30.18.'))
);
wwv_flow_imp_shared.append_to_install_script(
 p_id=>wwv_flow_imp.id(296292070758789073769)
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),9,''Complete'',1,json(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-11-12"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"str'
||'eet":"168 Main St","city":"Dallas","state_province":"Texas","country":"USA","postal_code":"75201"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (972,to_timestamp(''09-NOV-25 02.12.47.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),6,''Refunded'',6,json'
||'(''{"shipment":{"method":"Standard","status":"Processing","estimated_delivery":"2025-11-12"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"172 Main St","city":"Boston","state_province":"Massachusetts","country":"USA","posta'
||'l_code":"02108"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (986,to_timestamp(''11-NOV-25 07.03.57.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),10,''Open'',10,json('''
||'{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-11-13"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"186 Main St","city":"San Antonio","state_province":"Texas","country":"USA","postal_co'
||'de":"78201"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (993,to_timestamp(''13-NOV-25 10.16.45.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),8,''Paid'',1,json(''{"'
||'shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-11-17"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"193 Main St","city":"Miami","state_province":"Florida","country":"USA","postal_code":"331'
||'01"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1052,to_timestamp(''22-NOV-25 05.14.32.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),13,''Complete'',1,js'
||'on(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-11-25"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"252 Main St","city":"Boston","state_province":"Massachusetts","country":"USA","po'
||'stal_code":"02108"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1058,to_timestamp(''24-NOV-25 03.58.10.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),6,''Cancelled'',6,js'
||'on(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-11-28"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"258 Main St","city":"Ottawa","state_province":"Ontario","country":"Canada","posta'
||'l_code":"K1A 0B1"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1082,to_timestamp(''28-NOV-25 05.29.33.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),8,''Cancelled'',8,js'
||'on(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-12-01"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"282 Main St","city":"Chicago","state_province":"Illinois","country":"USA","postal'
||'_code":"60601"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1102,to_timestamp(''01-DEC-25 10.25.32.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),9,''Complete'',9,jso'
||'n(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-12-04"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"302 Main St","city":"Chicago","state_province":"Illinois","country":"USA",'
||'"postal_code":"60601"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1,to_timestamp(''25-FEB-25 02.24.33.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Open'',1,json(''{"sh'
||'ipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-02-27"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"101 Main St","city":"Los Angeles","state_province":"California","country":"USA","p'
||'ostal_code":"90001"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (3,to_timestamp(''02-MAR-25 12.21.18.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),18,''Complete'',1,json('
||'''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-03-06"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"103 Main St","city":"Houston","state_province":"Texas","country":"USA","postal_code":"'
||'77001"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (5,to_timestamp(''04-MAR-25 07.05.41.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),2,''Paid'',1,json(''{"sh'
||'ipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-03-05"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"105 Main St","city":"Philadelphia","state_province":"Pennsylvania","country":"USA","postal'
||'_code":"19101"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (7,to_timestamp(''14-MAR-25 02.01.22.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),9,''Refunded'',1,json('''
||'{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-03-17"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"107 Main St","city":"San Diego","state_province":"California","country":"USA",'
||'"postal_code":"92101"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (17,to_timestamp(''19-MAR-25 08.51.57.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),16,''Refunded'',1,json'
||'(''{"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-03-22"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"117 Main St","city":"Calgary","state_province":"Alberta","country":"Canada","postal_'
||'code":"T2P 1J9"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (20,to_timestamp(''21-MAR-25 11.11.43.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Complete'',3,json('
||'''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-03-22"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"120 Main St","city":"New York","state_province":"New York","country":"USA","postal_c'
||'ode":"10001"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (63,to_timestamp(''11-APR-25 07.21.35.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Complete'',1,json('
||'''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-04-15"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"163 Main St","city":"Houston","state_province":"Texas","country":"USA","postal_code":"'
||'77001"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (78,to_timestamp(''17-APR-25 11.00.11.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),20,''Refunded'',1,json'
||'(''{"shipment":{"method":"Standard","status":"Processing","estimated_delivery":"2025-04-21"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"178 Main St","city":"Ottawa","state_province":"Ontario","country":"Canada","postal_c'
||'ode":"K1A 0B1"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (79,to_timestamp(''18-APR-25 04.39.13.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),14,''Complete'',1,json'
||'(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-04-23"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"179 Main St","city":"Edmonton","state_province":"Alberta","country":"Canada"'
||',"postal_code":"T5J 0N3"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (82,to_timestamp(''19-APR-25 01.24.05.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),13,''Open'',1,json(''{"'
||'shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-04-22"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"182 Main St","city":"Chicago","state_province":"Illinois","country":"USA","post'
||'al_code":"60601"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (92,to_timestamp(''21-APR-25 09.25.03.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),17,''Complete'',1,json'
||'(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-04-24"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"192 Main St","city":"Boston","state_province":"Massachusetts","country":"USA","post'
||'al_code":"02108"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (125,to_timestamp(''01-MAY-25 01.45.50.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),12,''Paid'',1,json(''{'
||'"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-05-02"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"225 Main St","city":"Philadelphia","state_province":"Pennsylvania","country":"USA","pos'
||'tal_code":"19101"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (132,to_timestamp(''02-MAY-25 02.19.08.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),17,''Complete'',1,jso'
||'n(''{"shipment":{"method":"Standard","status":"Processing","estimated_delivery":"2025-05-05"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"232 Main St","city":"Boston","state_province":"Massachusetts","country":"USA","post'
||'al_code":"02108"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (159,to_timestamp(''11-MAY-25 01.56.08.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),1,''Open'',1,json(''{"'
||'shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-05-16"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"259 Main St","city":"Edmonton","state_province":"Alberta","country":"Canada","postal_code'
||'":"T5J 0N3"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (182,to_timestamp(''16-MAY-25 05.00.13.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),1,''Complete'',1,json'
||'(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-05-19"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"282 Main St","city":"Chicago","state_province":"Illinois","country":"USA","postal_c'
||'ode":"60601"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (196,to_timestamp(''19-MAY-25 05.57.59.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),8,''Cancelled'',1,jso'
||'n(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-05-21"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"296 Main St","city":"Vancouver","state_province":"British Columbia","count'
||'ry":"Canada","postal_code":"V5K 0A1"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (201,to_timestamp(''20-MAY-25 12.52.12.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),1,''Refunded'',1,json'
||'(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-05-22"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"301 Main St","city":"Los Angeles","state_province":"California","country":"USA","post'
||'al_code":"90001"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (204,to_timestamp(''21-MAY-25 12.43.26.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),6,''Cancelled'',1,jso'
||'n(''{"shipment":{"method":"Standard","status":"Processing","estimated_delivery":"2025-05-26"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"304 Main St","city":"Phoenix","state_province":"Arizona","country":"USA","postal_co'
||'de":"85001"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (240,to_timestamp(''28-MAY-25 01.31.20.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),8,''Cancelled'',1,jso'
||'n(''{"shipment":{"method":"Standard","status":"Processing","estimated_delivery":"2025-05-29"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"340 Main St","city":"New York","state_province":"New York","country":"USA","postal_'
||'code":"10001"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (290,to_timestamp(''13-JUN-25 02.12.59.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),15,''Cancelled'',1,js'
||'on(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-06-14"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"390 Main St","city":"Seattle","state_province":"Washington","country":"USA","post'
||'al_code":"98101"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (298,to_timestamp(''14-JUN-25 09.34.20.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Complete'',1,json'
||'(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-06-18"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"398 Main St","city":"Ottawa","state_province":"Ontario","country":"Canada",'
||'"postal_code":"K1A 0B1"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (306,to_timestamp(''16-JUN-25 04.24.36.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),5,''Paid'',5,json(''{"'
||'shipment":{"method":"Standard","status":"Processing","estimated_delivery":"2025-06-18"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"406 Main St","city":"San Antonio","state_province":"Texas","country":"USA","postal_code"'
||':"78201"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (307,to_timestamp(''16-JUN-25 05.31.39.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Cancelled'',1,jso'
||'n(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-06-19"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"407 Main St","city":"San Diego","state_province":"California","country":"US'
||'A","postal_code":"92101"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (331,to_timestamp(''24-JUN-25 02.29.17.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),5,''Complete'',1,json'
||'(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-06-26"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"431 Main St","city":"Denver","state_province":"Colorado","country":"USA","po'
||'stal_code":"80201"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (349,to_timestamp(''29-JUN-25 08.24.23.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),14,''Complete'',1,jso'
||'n(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-07-04"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"449 Main St","city":"San Francisco","state_province":"California","country"'
||':"USA","postal_code":"94102"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (401,to_timestamp(''11-JUL-25 10.55.57.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),16,''Open'',1,json(''{'
||'"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-07-13"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"501 Main St","city":"Los Angeles","state_province":"California","country":"USA","postal'
||'_code":"90001"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (430,to_timestamp(''17-JUL-25 08.56.02.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),8,''Complete'',1,json'
||'(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-07-18"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"530 Main St","city":"Seattle","state_province":"Washington","country":"USA"'
||',"postal_code":"98101"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (437,to_timestamp(''18-JUL-25 06.41.45.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),10,''Cancelled'',1,js'
||'on(''{"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-07-21"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"537 Main St","city":"Calgary","state_province":"Alberta","country":"Canada","posta'
||'l_code":"T2P 1J9"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1111,to_timestamp(''03-DEC-25 12.42.17.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),6,''Refunded'',1,jso'
||'n(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-12-05"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"311 Main St","city":"Denver","state_province":"Colorado","country":"USA","p'
||'ostal_code":"80201"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1119,to_timestamp(''05-DEC-25 09.35.51.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),14,''Cancelled'',14,'
||'json(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-12-10"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"319 Main St","city":"Edmonton","state_province":"Alberta","country":"Canada","pos'
||'tal_code":"T5J 0N3"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1121,to_timestamp(''05-DEC-25 11.25.14.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),7,''Cancelled'',1,js'
||'on(''{"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-12-07"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"321 Main St","city":"Los Angeles","state_province":"California","country":"USA","p'
||'ostal_code":"90001"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1169,to_timestamp(''15-DEC-25 04.16.06.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),14,''Paid'',1,json('''
||'{"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-12-20"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"369 Main St","city":"San Francisco","state_province":"California","country":"USA","pos'
||'tal_code":"94102"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1191,to_timestamp(''20-DEC-25 03.12.50.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),14,''Paid'',1,json('''
||'{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-12-22"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"391 Main St","city":"Denver","state_province":"Colorado","country":"USA","postal_code":'
||'"80201"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1195,to_timestamp(''21-DEC-25 06.46.35.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),15,''Complete'',1,js'
||'on(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-12-22"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"395 Main St","city":"Montreal","state_province":"Quebec","country":"Canada'
||'","postal_code":"H2X 1Y4"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1200,to_timestamp(''21-DEC-25 12.24.05.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),17,''Open'',1,json('''
||'{"shipment":{"method":"Standard","status":"Processing","estimated_delivery":"2025-12-22"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"400 Main St","city":"New York","state_province":"New York","country":"USA","postal_cod'
||'e":"10001"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1260,to_timestamp(''30-DEC-25 01.21.21.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),9,''Cancelled'',9,js'
||'on(''{"shipment":{"method":"Standard","status":"Processing","estimated_delivery":"2025-12-31"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"460 Main St","city":"New York","state_province":"New York","country":"USA","postal'
||'_code":"10001"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1321,to_timestamp(''09-JAN-25 06.32.45.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),11,''Open'',1,json('''
||'{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-01-11"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"521 Main St","city":"Los Angeles","state_province":"California","country":"USA'
||'","postal_code":"90001"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1348,to_timestamp(''13-JAN-25 08.57.23.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),18,''Complete'',18,j'
||'son(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-01-17"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"548 Main St","city":"Dallas","state_province":"Texas","country":"USA","p'
||'ostal_code":"75201"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1363,to_timestamp(''16-JAN-25 10.00.07.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),19,''Cancelled'',1,j'
||'son(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-01-20"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"563 Main St","city":"Houston","state_province":"Texas","country":"USA","p'
||'ostal_code":"77001"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1373,to_timestamp(''18-JAN-25 03.27.07.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),16,''Cancelled'',16,'
||'json(''{"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-01-22"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"573 Main St","city":"Miami","state_province":"Florida","country":"USA","postal_c'
||'ode":"33101"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1390,to_timestamp(''21-JAN-25 04.51.37.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),1,''Complete'',1,jso'
||'n(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-01-22"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"590 Main St","city":"Seattle","state_province":"Washington","country":"USA'
||'","postal_code":"98101"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1400,to_timestamp(''22-JAN-25 06.52.24.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),15,''Complete'',15,j'
||'son(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-01-23"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"600 Main St","city":"New York","state_province":"New York","country":"USA","post'
||'al_code":"10001"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1418,to_timestamp(''25-JAN-25 05.30.59.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),13,''Cancelled'',13,'
||'json(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-01-29"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"618 Main St","city":"Ottawa","state_province":"Ontario","country":"Canada","pos'
||'tal_code":"K1A 0B1"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1437,to_timestamp(''28-JAN-25 09.08.42.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),16,''Cancelled'',16,'
||'json(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-01-31"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"637 Main St","city":"Calgary","state_province":"Alberta","country":"Canada","post'
||'al_code":"T2P 1J9"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1439,to_timestamp(''29-JAN-25 04.52.36.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),16,''Paid'',1,json('''
||'{"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-02-03"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"639 Main St","city":"Edmonton","state_province":"Alberta","country":"Canada","postal_c'
||'ode":"T5J 0N3"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1448,to_timestamp(''31-JAN-25 07.09.51.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),16,''Open'',1,json('''
||'{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-02-04"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"648 Main St","city":"Dallas","state_province":"Texas","country":"USA","postal_code":"'
||'75201"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1450,to_timestamp(''31-JAN-25 07.56.41.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),6,''Complete'',1,jso'
||'n(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-02-01"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"650 Main St","city":"Seattle","state_province":"Washington","country":"USA'
||'","postal_code":"98101"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) value'))
);
wwv_flow_imp_shared.append_to_install_script(
 p_id=>wwv_flow_imp.id(296292070758789073769)
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
's (1451,to_timestamp(''31-JAN-25 08.10.59.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),16,''Paid'',16,json(''{"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-02-02"},"payment":{"method":"Paypal","st'
||'atus":"Paid"},"delivery_address":{"street":"651 Main St","city":"Denver","state_province":"Colorado","country":"USA","postal_code":"80201"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1455,to_timestamp(''01-FEB-25 03.40.10.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),4,''Complete'',1,jso'
||'n(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-02-02"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"655 Main St","city":"Montreal","state_province":"Quebec","country":"Canada","postal_'
||'code":"H2X 1Y4"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1468,to_timestamp(''02-FEB-25 02.27.01.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),4,''Complete'',1,jso'
||'n(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-02-06"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"668 Main St","city":"Dallas","state_province":"Texas","country":"USA","pos'
||'tal_code":"75201"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1471,to_timestamp(''02-FEB-25 07.29.40.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),14,''Paid'',14,json('
||'''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-02-04"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"671 Main St","city":"Denver","state_province":"Colorado","country":"USA","pos'
||'tal_code":"80201"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1483,to_timestamp(''04-FEB-25 08.09.09.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),14,''Refunded'',14,j'
||'son(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-02-08"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"683 Main St","city":"Houston","state_province":"Texas","country":"USA","p'
||'ostal_code":"77001"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1486,to_timestamp(''05-FEB-25 04.35.40.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),15,''Complete'',15,j'
||'son(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-02-07"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"686 Main St","city":"San Antonio","state_province":"Texas","country":"US'
||'A","postal_code":"78201"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1491,to_timestamp(''05-FEB-25 09.16.42.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),1,''Open'',1,json(''{'
||'"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-02-07"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"691 Main St","city":"Denver","state_province":"Colorado","country":"USA","postal_code":"'
||'80201"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1498,to_timestamp(''06-FEB-25 06.40.27.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),13,''Complete'',13,j'
||'son(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-02-10"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"698 Main St","city":"Ottawa","state_province":"Ontario","country":"Canad'
||'a","postal_code":"K1A 0B1"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1513,to_timestamp(''09-FEB-25 05.17.37.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),20,''Cancelled'',1,j'
||'son(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-02-13"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"713 Main St","city":"Miami","state_province":"Florida","country":"USA","p'
||'ostal_code":"33101"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1520,to_timestamp(''10-FEB-25 12.46.23.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Cancelled'',1,js'
||'on(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-02-11"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"720 Main St","city":"New York","state_province":"New York","country":"USA","posta'
||'l_code":"10001"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1525,to_timestamp(''11-FEB-25 02.22.05.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),10,''Complete'',1,js'
||'on(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-02-12"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"725 Main St","city":"Philadelphia","state_province":"Pennsylvania","countr'
||'y":"USA","postal_code":"19101"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1543,to_timestamp(''13-FEB-25 12.54.09.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),8,''Open'',1,json(''{'
||'"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-02-17"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"743 Main St","city":"Houston","state_province":"Texas","country":"USA","postal_'
||'code":"77001"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1549,to_timestamp(''13-FEB-25 05.28.26.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),19,''Refunded'',1,js'
||'on(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-02-18"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"749 Main St","city":"San Francisco","state_province":"California","country'
||'":"USA","postal_code":"94102"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1552,to_timestamp(''14-FEB-25 01.13.25.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),17,''Cancelled'',17,'
||'json(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-02-17"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"752 Main St","city":"Boston","state_province":"Massachusetts","country"'
||':"USA","postal_code":"02108"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1555,to_timestamp(''14-FEB-25 04.22.00.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),7,''Cancelled'',7,js'
||'on(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-02-15"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"755 Main St","city":"Montreal","state_province":"Quebec","country":"Canada'
||'","postal_code":"H2X 1Y4"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1560,to_timestamp(''14-FEB-25 06.38.06.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),14,''Complete'',1,js'
||'on(''{"shipment":{"method":"Standard","status":"Processing","estimated_delivery":"2025-02-15"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"760 Main St","city":"New York","state_province":"New York","country":"USA","postal'
||'_code":"10001"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1561,to_timestamp(''14-FEB-25 09.01.04.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),8,''Complete'',8,jso'
||'n(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-02-16"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"761 Main St","city":"Los Angeles","state_province":"California","country":"'
||'USA","postal_code":"90001"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1635,to_timestamp(''26-FEB-25 02.22.36.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),11,''Cancelled'',11,'
||'json(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-02-27"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"835 Main St","city":"Montreal","state_province":"Quebec","country":"Canada","post'
||'al_code":"H2X 1Y4"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1637,to_timestamp(''26-FEB-25 03.21.00.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),12,''Complete'',1,js'
||'on(''{"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-03-01"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"837 Main St","city":"Calgary","state_province":"Alberta","country":"Canada","posta'
||'l_code":"T2P 1J9"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1659,to_timestamp(''02-MAR-25 02.20.04.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),18,''Cancelled'',18,'
||'json(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-03-07"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"859 Main St","city":"Edmonton","state_province":"Alberta","country":"Canada","pos'
||'tal_code":"T5J 0N3"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1730,to_timestamp(''15-MAR-25 03.38.39.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),10,''Refunded'',10,j'
||'son(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-03-16"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"930 Main St","city":"Seattle","state_province":"Washington","country":"USA","pos'
||'tal_code":"98101"},"notes":"hand to recipient"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1731,to_timestamp(''16-MAR-25 09.57.43.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),19,''Cancelled'',19,'
||'json(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-03-18"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"931 Main St","city":"Denver","state_province":"Colorado","country":"USA","postal_'
||'code":"80201"},"notes":null}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1776,to_timestamp(''24-MAR-25 12.05.43.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),20,''Complete'',20,j'
||'son(''{"shipment":{"method":"Standard","status":"Processing","estimated_delivery":"2025-03-26"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"976 Main St","city":"Vancouver","state_province":"British Columbia","country":"Ca'
||'nada","postal_code":"V5K 0A1"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1808,to_timestamp(''29-MAR-25 11.37.35.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),20,''Refunded'',20,j'
||'son(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-04-02"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"108 Main St","city":"Dallas","state_province":"Texas","country":"USA","postal_co'
||'de":"75201"},"notes":"leave at door"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1817,to_timestamp(''31-MAR-25 10.58.36.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),8,''Cancelled'',8,js'
||'on(''{"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-04-03"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"117 Main St","city":"Calgary","state_province":"Alberta","country":"Canada","posta'
||'l_code":"T2P 1J9"},"notes":"call on arrival"}''));',
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1890,to_timestamp(''15-APR-25 12.36.09.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),7,''Refunded'',7,jso'
||'n(''{"shipment":{"method":"Standard","status":"Processing","estimated_delivery":"2025-04-16"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"190 Main St","city":"Seattle","state_province":"Washington","country":"USA","postal'
||'_code":"98101"},"notes":"hand to recipient"}''));',
'       --Products data',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (16,''Women''''s Socks (Grey)'',39.89,null);',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (17,''Women''''s Sweater (Brown)'',24.46,json(''{"colour":"brown","gender":"Women''''s","brand":"KLUGGER","description":"Dolore adipisicing commodo conseq'
||'uat Lorem ut incididunt. Ullamco nulla qui qui pariatur qui officia adipisicing magna aliqua ex qui incididunt.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":7,"review":"Fugiat cillum anim in qui laborum velit eu consectetur ad fugiat."'
||'},{"rating":6,"review":"Elit duis nostrud ad non enim elit mollit deserunt."},{"rating":2,"review":"Amet anim mollit laboris deserunt deserunt laboris anim ad commodo dolor."},{"rating":7,"review":"Labore nulla ullamco aute labore esse do proident si'
||'t."},{"rating":5,"review":"Non amet cillum eu cillum cupidatat occaecat excepteur ad voluptate culpa id."},{"rating":4,"review":"Non aliqua nisi anim qui consectetur id dolore duis sint aliqua ea tempor laborum."},{"rating":5,"review":"Elit ea Lorem '
||'duis amet."},{"rating":10,"review":"Aliqua velit nulla exercitation dolor minim ipsum culpa nostrud occaecat proident voluptate."},{"rating":3,"review":"Exercitation anim eu et veniam tempor ea."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (18,''Women''''s Jacket (Black)'',14.34,null);',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (19,''Men''''s Coat (Red)'',28.21,json(''{"colour":"red","gender":"Men''''s","brand":"VELOS","description":"Sint quis dolor in dolore sint elit ullamco ex'
||' magna laborum id eu. Magna fugiat qui pariatur dolore ex est esse minim elit velit.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating":7,"review":"Esse velit est cupidatat ea labore cupidatat ipsum ullamco cupidatat Lorem."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (20,''Girl''''s Shorts (Green)'',38.34,json(''{"colour":"green","gender":"Girl''''s","brand":"TRASOLA","description":"These shorts are perfect for a day o'
||'ut at sea. Made with quick-drying and breathable materials, they are comfortable to wear even in hot and humid conditions.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Veniam consectetur ea nisi irure'
||' aute cillum."},{"rating":8,"review":"Consequat ex incididunt pariatur mollit magna incididunt veniam pariatur aliqua ex exercitation aute mollit ullamco."},{"rating":4,"review":"Proident tempor cupidatat ut cillum nisi sunt consectetur veniam dolore'
||' est ut."},{"rating":8,"review":"Deserunt amet quis do duis nulla officia anim sint do eiusmod exercitation."},{"rating":5,"review":"Anim magna incididunt mollit deserunt proident veniam occaecat ex ut ex incididunt."},{"rating":4,"review":"Consectet'
||'ur cillum minim dolore cupidatat esse."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (21,''Girl''''s Pyjamas (White)'',39.78,json(''{"colour":"black","gender":"Girl''''s","brand":"UTARIAN","description":"Fugiat adipisicing sunt ullamco est'
||' ea. Dolor excepteur sit ad eu.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Proident consequat consequat eu enim Lorem incididunt ad amet excepteur tempor aliquip ad aliquip ea."},{"rating":7,"review'
||'":"Nulla sint anim aliqua laboris sint eu adipisicing incididunt."},{"rating":10,"review":"Aliqua aliquip non commodo duis consequat ad nisi et magna."},{"rating":9,"review":"Tempor consequat Lorem ipsum proident do nisi est dolore."},{"rating":7,"re'
||'view":"Pariatur amet laborum dolor dolore incididunt sint labore."},{"rating":10,"review":"Eu exercitation incididunt et est."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (22,''Men''''s Shorts (Black)'',10.33,json(''{"colour":"black","gender":"Men''''s","brand":"TERSANKI","description":"Occaecat veniam do aliqua irure conse'
||'ctetur ea fugiat aliqua qui ea veniam officia. Culpa officia Lorem dolor ullamco culpa adipisicing qui exercitation labore minim exercitation sunt.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating":3,"review":"Consequat anim reprehenderit c'
||'ommodo non aliqua laborum aute."},{"rating":6,"review":"Labore cillum do qui magna culpa ea excepteur quis."},{"rating":1,"review":"Dolor amet quis ea magna."},{"rating":7,"review":"Minim sit nostrud anim nostrud excepteur nostrud ea ex veniam consec'
||'tetur elit."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (23,''Men''''s Pyjamas (Blue)'',48.39,json(''{"colour":"blue","gender":"Men''''s","brand":"ADORNICA","description":"Irure amet Lorem consequat aliquip off'
||'icia dolore amet officia. Do elit laboris non dolore nostrud dolore cupidatat ea quis aliquip ex aliquip non ex.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating":3,"review":"Laboris elit pariatur labore duis fugiat ad in nulla tempor."},{"'
||'rating":5,"review":"Voluptate minim officia id excepteur."},{"rating":8,"review":"Eiusmod cupidatat et nisi ipsum non aliqua."},{"rating":1,"review":"Aute veniam irure dolor laborum esse ut ex tempor non velit."},{"rating":2,"review":"Nostrud nostrud'
||' mollit incididunt et tempor excepteur sit ut id exercitation."},{"rating":6,"review":"Labore tempor cillum laborum commodo et sit est qui aute enim id aute."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (24,''Boy''''s Sweater (Red)'',9.8,json(''{"colour":"red","gender":"Boy''''s","brand":"PHARMEX","description":"Ex occaecat nulla esse duis nulla laboris a'
||'ute. Commodo magna Lorem exercitation occaecat do anim minim non ad non ex do nulla ad.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Ea reprehenderit occaecat commodo exercitation ut adipisicing labor'
||'is adipisicing ex aute reprehenderit nisi sint qui."},{"rating":8,"review":"Qui anim sint dolore id dolor proident occaecat."},{"rating":5,"review":"Dolore fugiat mollit Lorem aliqua id consequat irure veniam."},{"rating":2,"review":"Esse dolore occa'
||'ecat consectetur sit sit labore exercitation sint occaecat quis enim occaecat."},{"rating":4,"review":"Do commodo do laboris qui minim fugiat nisi nostrud elit."},{"rating":7,"review":"Pariatur eu non eiusmod ex dolor veniam."},{"rating":3,"review":"'
||'Magna aliqua dolor sint anim aliquip officia officia esse labore do."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (25,''Girl''''s Jeans (Grey)'',48.75,json(''{"colour":"grey","gender":"Girl''''s","brand":"KINETICUT","description":"Ut aliqua nostrud exercitation cupida'
||'tat cupidatat in. Sit tempor eu cillum quis incididunt consectetur quis amet.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":2,"review":"Id consectetur minim anim nisi occaecat elit labore duis."},{"rating":5,"revi'
||'ew":"Ut fugiat qui velit fugiat nostrud ea dolor amet magna id pariatur."},{"rating":3,"review":"Labore laborum eiusmod qui minim exercitation."},{"rating":4,"review":"Excepteur ea mollit ad pariatur mollit veniam."},{"rating":9,"review":"Consectetur'
||' aliquip deserunt fugiat excepteur elit occaecat culpa fugiat dolor in."},{"rating":1,"review":"Adipisicing adipisicing mollit reprehenderit ex nulla in ea ad exercitation irure ullamco."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (26,''Girl''''s Hoodie (White)'',39.91,json(''{"colour":"white","gender":"Girl''''s","brand":"PROXSOFT","description":"Aliquip culpa eu deserunt ex culpa '
||'in laborum adipisicing. Amet et id minim esse ea non qui veniam.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":6,"review":"Commodo ut fugiat voluptate adipisicing deserunt."},{"rating":4,"review":"Fugiat cupidatat'
||' amet fugiat cupidatat ea ea."},{"rating":7,"review":"Incididunt ex enim commodo sit consequat enim."},{"rating":3,"review":"Ullamco in et aute laboris cillum."},{"rating":3,"review":"Reprehenderit Lorem proident sit deserunt do tempor commodo velit '
||'velit nulla ipsum."},{"rating":10,"review":"Dolore pariatur velit enim est culpa eiusmod cupidatat deserunt esse elit exercitation sunt proident exercitation."},{"rating":2,"review":"Minim fugiat elit aliquip nostrud velit reprehenderit cillum."},{"r'
||'ating":4,"review":"Sint Lorem est laborum consectetur pariatur minim tempor ullamco Lorem est."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (27,''Boy''''s Coat (Blue)'',10.24,json(''{"colour":"brown","gender":"Boy''''s","brand":"GRONK","description":"Quis aliquip fugiat sunt qui eu velit aliqu'
||'a sint eiusmod mollit id ad. Anim anim ipsum in reprehenderit amet amet consectetur incididunt qui cillum Lorem.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":8,"review":"Sit id elit cupidatat aute consectetur ess'
||'e proident aliqua ad voluptate cillum Lorem."},{"rating":6,"review":"Enim enim fugiat consectetur ut sunt veniam ad sit minim amet Lorem veniam mollit."},{"rating":5,"review":"Dolor ipsum consectetur nostrud ex Lorem pariatur voluptate."},{"rating":8'
||',"review":"Commodo magna sint sint dolore aute anim laborum."},{"rating":4,"review":"Laboris amet proident occaecat dolore labore exercitation dolore sunt Lorem sunt anim."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (28,''Men''''s Hoodie (Red)'',24.71,json(''{"colour":"red","gender":"Men''''s","brand":"FANGOLD","description":"Dolor irure dolore est ipsum nisi incididu'
||'nt laboris culpa. Ullamco ad cupidatat sint culpa adipisicing pariatur.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating":3,"review":"Proident aliqua aliquip aute quis cillum."},{"rating":5,"review":"Pariatur enim ipsum aliqua Lorem eiusmod'
||' consequat cupidatat irure nulla sint fugiat veniam amet ipsum."},{"rating":10,"review":"Sint duis ipsum reprehenderit Lorem aute pariatur elit."},{"rating":4,"review":"Enim qui qui consequat culpa ex velit sint excepteur ipsum in amet mollit mollit.'
||'"},{"rating":10,"review":"Qui velit reprehenderit fugiat adipisicing anim incididunt anim commodo occaecat consectetur in aute."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (29,''Boy''''s Shirt (Black)'',37.34,json(''{"colour":"black","gender":"Boy''''s","brand":"SQUISH","description":"Pariatur nulla elit pariatur excepteur u'
||'llamco officia incididunt. Aliquip quis aliquip cupidatat magna fugiat eiusmod pariatur excepteur tempor officia voluptate fugiat.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":5,"review":"Non esse labore ullamco '
||'laboris irure cupidatat ex proident eiusmod."},{"rating":10,"review":"Ea velit et mollit labore consequat."},{"rating":6,"review":"Labore sit pariatur Lorem ad sint consectetur incididunt deserunt eiusmod sit nostrud dolore eiusmod sint."},{"rating":'
||'1,"review":"Id voluptate sunt amet laboris laborum ad dolor aliqua ipsum sint qui aute eu esse."},{"rating":5,"review":"Sint Lorem dolore do ea."},{"rating":9,"review":"Quis pariatur consequat nisi labore Lorem elit in qui Lorem."},{"rating":2,"revie'
||'w":"Consectetur voluptate tempor ullamco voluptate labore sint."},{"rating":9,"review":"Qui laboris tempor ullamco ullamco commodo sint occaecat Lorem."},{"rating":1,"review":"Laborum eu sit duis et culpa eu duis irure incididunt amet."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (30,''Women''''s Pyjamas (Grey)'',28.59,json(''{"colour":"grey","gender":"Women''''s","brand":"THREDZ","description":"Quis aliqua eiusmod incididunt quis '
||'ut ea aliqua sunt veniam ut et cupidatat eiusmod. Sunt sunt duis excepteur excepteur do exercitation.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":1,"review":"Et anim culpa voluptate pariatur ullamco dolore ad aliquip."},{"rating":4,"r'
||'eview":"Nulla non ea nisi nulla elit veniam duis."},{"rating":4,"review":"Lorem adipisicing deserunt duis id sint aliquip minim deserunt magna sunt magna laborum dolore."},{"rating":3,"review":"Officia amet magna eu nulla dolore magna pariatur deseru'
||'nt amet reprehenderit."},{"rating":3,"review":"Ad aliqua ex eu cillum labore elit mollit reprehenderit anim."},{"rating":1,"review":"Duis excepteur magna aliqua qui officia ipsum sunt."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (31,''Women''''s Skirt (Green)'',5.65,json(''{"colour":"green","gender":"Women''''s","brand":"ZIDANT","description":"Et est officia est amet est nisi sit '
||'veniam proident. Ullamco proident culpa velit proident quis dolore occaecat proident Lorem tempor.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (32,''Women''''s Jacket (Blue)'',37,json(''{"colour":"blue","gender":"Women''''s","brand":"ZOGAK","description":"Tempor ipsum duis aliqua veniam qui labor'
||'is et ut officia. Fugiat fugiat nisi labore excepteur ullamco excepteur veniam in in et adipisicing sint.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":9,"review":"Sit amet id ut laborum in exercitation laborum Lorem fugiat ex."},{"rati'
||'ng":7,"review":"Nisi non mollit dolore id aute velit laboris consequat voluptate id."},{"rating":1,"review":"Nisi nisi fugiat non nisi amet esse."},{"rating":1,"review":"Laborum eiusmod id ipsum aliqua adipisicing cillum enim."},{"rating":8,"review":'
||'"Duis aliqua ut nulla proident voluptate incididunt elit est exercitation id aute."},{"rating":4,"review":"Veniam labore exercitation eiusmod nisi mollit anim eu."},{"rating":6,"review":"Exercitation eu est irure velit pariatur."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (33,''Boy''''s Pyjamas (Grey)'',23.32,json(''{"colour":"grey","gender":"Boy''''s","brand":"RETRACK","description":"Sit consectetur Lorem culpa ipsum ad ul'
||'lamco ea aute qui ea. Laboris ipsum enim enim veniam.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Ut incididunt veniam ullamco voluptate occaecat velit."},{"rating":5,"review":"Consectetur cupidatat '
||'voluptate dolore velit culpa est id enim aute."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (34,''Women''''s Jeans (Red)'',7.18,json(''{"colour":"red","gender":"Women''''s","brand":"PANZENT","description":"Eiusmod culpa dolore occaecat excepteur '
||'esse magna fugiat dolore cupidatat laboris mollit culpa. Consequat dolor qui tempor sit minim sit excepteur enim excepteur aute minim.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":10,"review":"Nulla enim cillum pariatur do consectetur '
||'et Lorem."},{"rating":1,"review":"Cupidatat fugiat incididunt fugiat eu."},{"rating":1,"review":"Ullamco eiusmod adipisicing fugiat reprehenderit mollit aliquip."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (35,''Girl''''s Dress (Red)'',49.12,json(''{"colour":"red","gender":"Girl''''s","brand":"NIXELT","description":"Ipsum pariatur laborum nulla pariatur cons'
||'equat consequat amet nisi. Ut in quis officia excepteur.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":10,"review":"Ut est anim sit nulla commodo velit occaecat amet mollit fugiat id."},{"rating":2,"review":"Eu qu'
||'is ea anim incididunt nisi nisi velit ve'))
);
wwv_flow_imp_shared.append_to_install_script(
 p_id=>wwv_flow_imp.id(296292070758789073769)
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'lit labore do."},{"rating":9,"review":"Eu laborum laborum reprehenderit minim officia anim."},{"rating":8,"review":"Et consectetur labore ullamco occaecat cupidatat magna pariatur esse qui ut mollit ea cillum."},{"rating":4,"review":"Dolore culpa mag'
||'na commodo aute do culpa non commodo qui id commodo consectetur exercitation."},{"rating":6,"review":"Adipisicing laborum tempor sunt laboris et sint aute pariatur."},{"rating":9,"review":"Excepteur voluptate qui magna in cillum aliqua."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (36,''Women''''s Trousers (Blue)'',29.51,json(''{"colour":"blue","gender":"Women''''s","brand":"TROLLERY","description":"Proident sunt ipsum pariatur duis'
||' dolor eu dolore culpa ad aliquip elit. Mollit Lorem et aliquip commodo est anim amet eiusmod amet dolore laborum tempor officia.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":10,"review":"Consequat ut commodo irure sit elit anim amet e'
||'u est sunt tempor non."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (37,''Boy''''s Jeans (Blue)'',22.98,json(''{"colour":"blue","gender":"Boy''''s","brand":"AVIT","description":"Velit velit esse nulla minim minim laborum e'
||'sse. Sint minim id aliquip amet fugiat dolor aliqua.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (38,''Girl''''s Pyjamas (Red)'',11,json(''{"colour":"red","gender":"Girl''''s","brand":"EMTRAK","description":"Magna est occaecat consectetur ullamco moll'
||'it dolore aute irure consectetur nulla ipsum id elit occaecat. Amet Lorem sint nulla eiusmod commodo aliqua cillum anim tempor tempor pariatur do nostrud minim.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":4,"rev'
||'iew":"Consectetur velit adipisicing excepteur in excepteur sit excepteur irure veniam velit."},{"rating":4,"review":"Consectetur exercitation exercitation irure commodo officia do adipisicing ullamco sit anim consequat."},{"rating":9,"review":"Minim '
||'occaecat sunt laborum voluptate culpa enim elit."},{"rating":2,"review":"Reprehenderit labore incididunt ex ullamco nostrud cillum irure mollit dolore aliqua enim tempor aliquip laborum."},{"rating":2,"review":"Enim commodo adipisicing consequat comm'
||'odo."},{"rating":8,"review":"Sint ut cillum Lorem ut ad aliquip elit sunt labore laboris consequat Lorem aliqua occaecat."},{"rating":2,"review":"Et consectetur in officia ullamco labore ea duis amet."},{"rating":8,"review":"Reprehenderit enim tempor'
||' proident commodo ex eu fugiat cupidatat exercitation culpa id adipisicing deserunt officia."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (39,''Boy''''s Trousers (Blue)'',34.06,json(''{"colour":"blue","gender":"Boy''''s","brand":"DIGINETIC","description":"Dolor aliqua minim nostrud non labor'
||'e in ullamco mollit mollit sit non. Duis nulla exercitation et adipisicing nostrud voluptate cupidatat eu reprehenderit.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":6,"review":"Culpa id consequat cillum dolor."}'
||',{"rating":8,"review":"Qui do quis magna nostrud exercitation enim aute dolore proident ipsum sint nostrud deserunt."},{"rating":9,"review":"Excepteur fugiat adipisicing laboris ea culpa cupidatat laborum occaecat nostrud."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (40,''Girl''''s Pyjamas (Black)'',8.66,json(''{"colour":"black","gender":"Girl''''s","brand":"ISOLOGICS","description":"Ex exercitation aliquip cillum adi'
||'pisicing cupidatat. Culpa labore eiusmod do ut ipsum incididunt ipsum labore.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":6,"review":"Duis minim duis dolor laboris eiusmod consequat fugiat adipisicing ex non cul'
||'pa Lorem proident qui."},{"rating":4,"review":"Veniam tempor commodo aliqua sit ex mollit cillum aute officia fugiat tempor sunt nulla elit."},{"rating":10,"review":"Dolore officia aute magna eiusmod exercitation esse amet tempor."},{"rating":7,"revi'
||'ew":"Proident nisi voluptate ea esse exercitation ullamco consequat consectetur in enim amet adipisicing commodo nulla."},{"rating":4,"review":"Irure ullamco id adipisicing fugiat Lorem do non officia nisi sunt esse mollit consectetur."},{"rating":9,'
||'"review":"Laboris do elit dolor officia irure esse incididunt pariatur elit."},{"rating":1,"review":"Aliqua Lorem nostrud et reprehenderit exercitation exercitation nostrud consectetur dolor."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (41,''Women''''s Dress (Black)'',10.11,json(''{"colour":"black","gender":"Women''''s","brand":"NEOCENT","description":"Eu enim aliquip deserunt est duis d'
||'o sunt consequat sit sit labore nisi. Culpa mollit cupidatat Lorem et minim sit.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":4,"review":"Ex culpa sint ad eu quis."},{"rating":4,"review":"Irure labore adipisicing velit sint sint."},{"r'
||'ating":4,"review":"Ullamco dolore ad qui consequat labore do cillum velit."},{"rating":5,"review":"Velit officia eiusmod proident dolore occaecat eu eiusmod."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (1,''Boy''''s Shirt (White)'',29.55,json(''{"colour":"white","gender":"Boy''''s","brand":"COMTOURS","description":"Labore commodo velit cupidatat ullamco '
||'ea proident velit sunt adipisicing. Esse tempor exercitation reprehenderit ullamco esse incididunt dolore laboris Lorem ipsum fugiat ea.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (2,''Women''''s Shirt (Green)'',16.67,json(''{"colour":"green","gender":"Women''''s","brand":"NIKE","description":"Excepteur anim adipisicing aliqua ad. E'
||'x aliquip ad tempor cupidatat dolore ipsum ex anim Lorem aute amet.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":8,"review":"Laborum ipsum adipisicing magna nulla tempor incididunt."},{"rating":10,"review":"Cupidatat dolore nulla paria'
||'tur quis quis."},{"rating":9,"review":"Pariatur mollit dolor in deserunt cillum consectetur."},{"rating":3,"review":"Dolore occaecat mollit id ad aliqua irure reprehenderit amet eiusmod pariatur."},{"rating":10,"review":"Est pariatur et qui minim vel'
||'it non consectetur sint fugiat ad."},{"rating":6,"review":"Et pariatur ipsum eu qui."},{"rating":6,"review":"Voluptate labore irure cupidatat mollit irure quis fugiat enim laborum consectetur officia sunt."},{"rating":8,"review":"Irure elit do et eli'
||'t aute veniam proident sunt."},{"rating":8,"review":"Aute mollit proident id veniam occaecat dolore mollit dolore nostrud."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (3,''Boy''''s Sweater (Green)'',44.17,json(''{"colour":"green","gender":"Boy''''s","brand":"KINETICA","description":"Occaecat dolore in ut et ad pariatur '
||'laborum mollit nulla exercitation. Laboris esse tempor quis velit nostrud exercitation veniam reprehenderit minim minim exercitation.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":5,"review":"Sunt ad proident exce'
||'pteur laboris officia eu reprehenderit dolor nostrud elit nulla pariatur incididunt Lorem."},{"rating":2,"review":"Ullamco ad amet fugiat adipisicing."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (4,''Boy''''s Trousers (White)'',43.71,json(''{"colour":"white","gender":"Boy''''s","brand":"INTERLOO","description":"Nostrud esse velit incididunt occaec'
||'at ullamco dolor quis reprehenderit proident dolore deserunt tempor qui proident. Magna deserunt sit minim eu commodo minim labore occaecat ea id sint laborum.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"revi'
||'ew":"Anim culpa qui est adipisicing qui dolore enim. Sint duis aute laborum nisi ut elit Lorem nisi proident consectetur."},{"rating":6,"review":"Reprehenderit ad ipsum sint mollit aliqua."},{"rating":4,"review":"Enim culpa reprehenderit non ullamco '
||'non ex veniam. Sit do incididunt ullamco ad et et aliquip deserunt dolor officia nostrud ipsum officia nostrud. Lorem esse tempor aliqua ut quis occaecat."},{"rating":9,"review":"Pariatur sit dolor dolor tempor commodo aute culpa sit."},{"rating":2,"'
||'review":"Sunt enim sunt occaecat exercitation deserunt nisi anim mollit deserunt non laboris cillum."},{"rating":8,"review":"Exercitation et duis quis minim id duis veniam occaecat amet cillum velit pariatur tempor. Culpa aliquip adipisicing aliquip '
||'non minim occaecat eu nisi esse veniam eu aliqua."},{"rating":5,"review":"Culpa elit nulla dolore mollit tempor mollit in. Voluptate deserunt eiusmod sint id excepteur eiusmod excepteur qui enim cupidatat. Nostrud enim anim commodo adipisicing nisi d'
||'olore commodo elit commodo aliqua aliquip laborum."},{"rating":4,"review":"Exercitation sunt consequat anim nisi sunt cillum esse amet ut reprehenderit ea. Laborum labore ipsum consectetur ad excepteur proident fugiat consectetur eiusmod incididunt o'
||'fficia enim ullamco."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (5,''Girl''''s Shorts (Red)'',38.28,json(''{"colour":"red","gender":"Girl''''s","brand":"OZEAN","description":"These sea shorts are designed with quick-dr'
||'ying and breathable materials, making them the perfect choice for a day out on the water.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (6,''Boy''''s Socks (Grey)'',19.16,json(''{"colour":"grey","gender":"Boy''''s","brand":"GROK","description":"Pariatur elit adipisicing aute dolor sunt lab'
||'orum ullamco aliqua exercitation consectetur. Lorem qui sint ullamco sint commodo anim.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":5,"review":"Ea eu sit est consectetur quis in dolor ut."},{"rating":6,"review":'
||'"In do cillum occaecat minim."},{"rating":6,"review":"Laborum laborum excepteur ipsum aliquip reprehenderit cillum irure proident voluptate eiusmod in culpa."},{"rating":9,"review":"Exercitation magna proident non deserunt consectetur consectetur do '
||'ex sint id irure ipsum voluptate."},{"rating":7,"review":"Aliquip irure minim quis quis voluptate reprehenderit mollit dolore."},{"rating":1,"review":"Duis mollit aute cillum aute culpa magna."},{"rating":9,"review":"Magna exercitation exercitation s'
||'it commodo proident fugiat occaecat ullamco voluptate do consectetur officia velit."},{"rating":7,"review":"Laboris nostrud et nulla tempor commodo non aute ipsum excepteur qui dolore enim."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (7,''Boy''''s Socks (Black)'',19.58,json(''{"colour":"black","gender":"Boy''''s","brand":"ENERVATE","description":"Sit minim sunt nulla proident velit Lor'
||'em dolor. Aute reprehenderit laborum labore proident non esse nisi ex magna consectetur minim ex est.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":8,"review":"Laborum laboris eu occaecat amet adipisicing consequa'
||'t veniam velit."},{"rating":2,"review":"Mollit fugiat commodo minim sint do irure duis quis ex minim ad."},{"rating":2,"review":"Sit duis aliquip proident et nostrud enim anim amet dolor consequat tempor culpa."},{"rating":3,"review":"Proident aute v'
||'oluptate aute irure."},{"rating":2,"review":"Ex excepteur duis irure veniam elit occaecat sit Lorem labore id minim tempor dolore officia."},{"rating":2,"review":"Amet fugiat commodo qui eiusmod dolore sint fugiat commodo elit qui esse in officia."},'
||'{"rating":2,"review":"Dolor proident proident ad officia cillum dolor aute officia enim exercitation."},{"rating":4,"review":"Dolor esse cupidatat eiusmod non veniam elit nostrud aliquip eu elit."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (8,''Boy''''s Coat (Brown)'',21.16,json(''{"colour":"brown","gender":"Boy''''s","brand":"KOFFEE","description":"Voluptate quis excepteur mollit id dolore.'
||' Sunt aliquip in magna ut irure nostrud duis officia fugiat aute.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (9,''Women''''s Jeans (Brown)'',29.49,json(''{"colour":"brown","gender":"Women''''s","brand":"PROTODYNE","description":"Est dolor tempor sint commodo irur'
||'e sint ut dolor proident enim Lorem. Pariatur deserunt nostrud quis minim non.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":2,"review":"Occaecat cupidatat in id elit magna Lorem esse ad magna labore non qui magna."},{"rating":8,"review'
||'":"Cupidatat cupidatat laboris consectetur labore veniam aliqua et incididunt duis sunt proident."},{"rating":2,"review":"Esse ipsum veniam ullamco irure ad minim mollit consequat non dolor labore."},{"rating":1,"review":"Cillum ea minim voluptate id'
||' ut consectetur commodo nostrud cillum eiusmod eiusmod dolore cillum veniam."},{"rating":5,"review":"Excepteur adipisicing culpa dolor id et irure sint ex non nostrud velit pariatur esse quis."},{"rating":9,"review":"Do fugiat aliqua sunt quis proide'
||'nt fugiat."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (10,''Women''''s Skirt (Red)'',30.69,json(''{"colour":"green","gender":"Women''''s","brand":"FLYBOYZ","description":"Qui aliquip dolor aute labore amet no'
||'strud deserunt nulla ut veniam id. Ut aute velit tempor anim ex sit nisi.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":7,"review":"Mollit consequat minim sit consequat deserunt duis."},{"rating":8,"review":"Quis eu esse proident elit e'
||'u aliqua magna voluptate labore adipisicing voluptate ex do."},{"rating":6,"review":"Laborum nulla aliquip nulla adipisicing aliquip qui cupidatat aliquip in."},{"rating":3,"review":"Exercitation aute voluptate voluptate tempor sit enim ut veniam do.'
||'"},{"rating":8,"review":"Cillum cillum anim aliqua eu deserunt amet eu ut veniam in qui."},{"rating":7,"review":"Nostrud aliqua ullamco irure consectetur elit nisi eu elit reprehenderit ut."},{"rating":5,"review":"Irure nisi dolore dolore ut non ad m'
||'inim pariatur."},{"rating":2,"review":"Laboris aliqua sint est incididunt sunt non tempor irure reprehenderit labore."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (11,''Boy''''s Shorts (Blue)'',10.48,json(''{"colour":"blue","gender":"Boy''''s","brand":"WRAPTURE","description":"Id sit adipisicing ea dolore fugiat lab'
||'orum ut dolore. Reprehenderit aliqua non adipisicing aliqua adipisicing aute ullamco consectetur est aliqua.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Laborum labore exercitation culpa sint cillum '
||'aute duis labore do excepteur."},{"rating":10,"review":"Do velit laborum adipisicing velit."},{"rating":6,"review":"Culpa dolor aute adipisicing ad."},{"rating":6,"review":"Sit sunt elit proident fugiat consectetur id incididunt nulla nulla magna con'
||'sectetur."},{"rating":6,"review":"Adipisicing ipsum eiusmod sint ullamco dolor irure qui officia."},{"rating":4,"review":"Ipsum commodo amet non ut labore."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (12,''Boy''''s Socks (White)'',12.64,json(''{"colour":"grey","gender":"Boy''''s","brand":"HANDSHAKE","description":"Tempor laborum voluptate mollit aliqui'
||'p et tempor nostrud Lorem. Nostrud anim exercitation est fugiat elit est deserunt mollit exercitation.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":8,"review":"Quis culpa laborum ex magna."},{"rating":3,"review":'
||'"Culpa ullamco deserunt ex ea."},{"rating":3,"review":"Fugiat ullamco reprehenderit tempor nulla ad fugiat qui excepteur sunt officia deserunt nulla."},{"rating":2,"review":"Mollit dolore magna magna veniam culpa ullamco tempor esse id in occaecat ex'
||'cepteur ullamco ea."},{"rating":10,"review":"Culpa dolore enim consequat aliquip nulla ipsum."},{"rating":2,"review":"Excepteur aliqua sunt exercitation mollit pariatur anim tempor."},{"rating":8,"review":"Proident culpa tempor dolore deserunt anim e'
||'a deserunt quis duis."},{"rating":8,"review":"Reprehenderit est do quis quis reprehenderit adipisicing qui Lorem mollit sit labore veniam."},{"rating":1,"review":"Mollit dolore ad laboris ut cillum velit in sint labore nulla Lorem minim."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (13,''Boy''''s Hoodie (Grey)'',26.14,json(''{"colour":"grey","gender":"Boy''''s","brand":"SUNCLIPSE","description":"Voluptate irure voluptate labore sint '
||'amet occaecat elit ea incididunt aliquip. Tempor laboris tempor tempor magna officia in aliqua consequat elit occaecat.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Fugiat officia nostrud cillum duis '
||'consequat sunt culpa duis laborum reprehenderit laborum."},{"rating":10,"review":"Et do reprehenderit do irure tempor id aliquip voluptate anim consequat amet sunt."},{"rating":3,"review":"Minim adipisicing dolore eiusmod laborum aliqua non Lorem lab'
||'oris minim est cillum qui qui Lorem."},{"rating":4,"review":"Esse Lorem aute deserunt quis."},{"rating":1,"review":"Ex deserunt aliqua consectetur elit cillum cillum ex et mollit sint."},{"rating":4,"review":"Magna esse ipsum ipsum irure officia nost'
||'rud ad velit sit."},{"rating":8,"review":"Mollit et tempor esse fugiat fugiat ad voluptate irure est sunt proident magna anim ex."},{"rating":4,"review":"Nulla nisi esse ut exercitation commodo irure non amet labore mollit et elit."},{"rating":1,"rev'
||'iew":"Enim officia anim proident consequat."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (14,''Women''''s Skirt (Brown)'',13.97,json(''{"colour":"brown","gender":"Women''''s","brand":"ISOTRONIC","description":"Magna Lorem do ad incididunt qui '
||'magna irure commodo nisi. Dolore ipsum adipisicing magna ea ullamco Lorem officia culpa do laborum voluptate.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":1,"review":"Officia occaecat laboris magna sint tempor officia deserunt proident'
||' eu excepteur."},{"rating":2,"review":"Aliqua nisi sint enim ad mollit qui."},{"rating":3,"review":"Fugiat excepteur eiusmod incididunt Lorem nostrud nostrud labore aute esse aliquip."},{"rating":8,"review":"Voluptate ad enim anim culpa veniam amet."'
||'},{"rating":3,"review":"Do cillum quis cillum Lorem tempor labore laboris."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (15,''Girl''''s Coat (Blue)'',13.09,json(''{"colour":"blue","gender":"Girl''''s","brand":"DECRATEX","description":"Proident ut officia non duis est eu ali'
||'quip culpa cupidatat est incididunt amet ipsum veniam. Aliqua ea cupidatat incididunt ad excepteur irure ad pariatur occaecat duis incididunt excepteur amet.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":8,"review'
||'":"Officia irure deserunt mollit Lorem dolor dolor minim deserunt."},{"rating":10,"review":"Aliqua nostrud dolore enim dolore reprehenderit officia quis aliquip irure occaecat et."},{"rating":2,"review":"Consectetur consequat ut cupidatat et elit et '
||'cillum veniam exercitation Lorem culpa ipsum."},{"rating":9,"review":"Nisi tempor incididunt Lorem sit sit do mollit qui aliquip qui eu quis Lorem."},{"rating":9,"review":"Sunt nulla ad dolore fugiat cillum et."},{"rating":8,"review":"Incididunt nost'
||'rud officia sunt cupidatat culpa ex id ut."},{"rating":1,"review":"Deserunt sit officia enim adipisicing exercitation velit ipsum dolore laboris officia mollit ex esse et."},{"rating":3,"review":"Aliqua nulla laborum id mollit irure incididunt aliqua'
||' mollit qui nostrud consectetur sint aliqua quis."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (42,''Boy''''s Jeans (Black)'',16.64,json(''{"colour":"black","gender":"Boy''''s","brand":"EARTHMARK","description":"Duis dolor est eu elit anim proident '
||'aliqua eu tempor. Est fugiat non ullamco et pariatur nulla exercitation eiusmod id officia minim.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":10,"review":"Anim aliquip id reprehenderit laboris."},{"rating":7,"re'
||'view":"Nostrud non cupidatat id eiusmod aliquip anim ullamco aliquip cupidatat excepteur dolor reprehenderit."},{"rating":6,"review":"Veniam consequat deserunt nostrud sunt est commodo sint eu fugiat ipsum deserunt aute elit est."},{"rating":9,"revie'
||'w":"Eiusmod excepteur ut ullamco eiusmod labore deserunt."},{"rating":5,"review":"Aute deserunt eu voluptate id irure aliquip duis sint proident dolore dolor."},{"rating":5,"review":"Dolore mollit quis elit qui voluptate ad culpa voluptate elit conse'
||'ctetur."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (43,''Boy''''s Trousers (Black)'',39.32,json(''{"colour":"blue","gender":"Boy''''s","brand":"PHOLIO","description":"Voluptate ex mollit enim minim nulla p'
||'roident dolor eu nostrud velit. Ex ullamco aute dolor duis elit elit.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":3,"review":"Labore non exercitation anim id deserunt excepteur dolore sunt deserunt dolor."},{"ra'
||'ting":5,"review":"Laborum eiusmod mollit amet nulla ex esse culpa ut elit reprehenderit labore ex Lorem cupidatat."},{"rating":7,"review":"Reprehenderit dolore aute consectetur voluptate excepteur veniam nulla ad."},{"rating":5,"review":"Reprehenderi'
||'t proident in elit pariatur."},{"rating":8,"review":"Magna laborum ad deserunt voluptate enim excepteur enim dolore veniam consequat officia anim dolore mollit."},{"rating":3,"review":"Elit et reprehenderit amet aute amet laboris minim irure sint."}]'
||'}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (44,''Women''''s Coat (Black)'',31.68,json(''{"colour":"black","gender":"Women''''s","brand":"COMVEYOR","description":"Exercitation ut ad reprehenderit su'
||'nt eiusmod sit. Qui nisi ut esse mollit nisi.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":7,"review":"Ad consequat nisi est tempor nisi nulla veniam consectetur ad ut laborum magna."},{"rating":8,"review":"Incididunt magna ipsum cupid'
||'atat elit eiusmod enim mollit eiusmod id esse sit elit irure Lorem."},{"rating":7,"review":"Aute aliquip et esse consequat reprehenderit ipsum ut."},{"rating":8,"review":"Consectetur commodo cupidatat nostrud qui labore magna duis sit."},{"rating":8,'
||'"review":"Qui occaecat elit exercitation do est officia fugiat adipisicing velit occaecat deserunt Lorem ex adipisicing."},{"rating":6,"review":"Velit est commodo esse sint id ullamco aute ut ut officia laboris irure in."},{"rating":10,"review":"Ad n'
||'ulla labore cupidatat do laboris do elit cupidatat excepteur occaecat cupidatat."},{"rating":5,"review":"Do esse magna occaecat non."},{"rating":10,"review":"Et sint qui tempor nostrud sunt sit duis dolor excepteur voluptate."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (45,''Men''''s Jeans (Grey)'',27.64,json(''{"colour":"grey","gender":"Men''''s","brand":"QNEKT","description":"Dolore duis minim dolor est fugiat sit dolo'
||'r nisi anim Lorem culpa id. Consequat labore et reprehenderit pariatur culpa minim laboris pariatur esse aliquip.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating":7,"review":"Veniam qui ipsum consequat laboris ad aliquip est reprehenderit '
||'esse sint cupidatat tempor."},{"rating":8,"review":"Ut anim anim ipsum ipsum irure."},{"rating":9,"review":"Non qui sunt ullamco deserunt sint."},{"rating":10,"review":"Nostrud fugiat velit aliqua eu culpa do excepteur do."}]}''));',
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (46,''Girl''''s Trousers (Red)'',39.16,json(''{"colour":"red","gender":"Girl''''s","brand":"OTHERSIDE","description":"Lorem officia laborum deserunt venia'
||'m cillum anim adipisicing minim aute ad esse sint sit tempor. Magna enim proident eiusmod incididunt adipisicing duis deserunt pariatur sint officia occaecat est minim ipsum.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"'
||'rating":9,"review":"Magna magna ullamco ipsum pariatur occaecat eiusmod amet ea sunt reprehenderit dolore aute voluptate."},{"rating":7,"review":"Eiusmod cupidatat cillum qui dolor consequat."},{"rating":4,"review":"Do proident cillum cupidatat labor'
||'is in cillum."},{"rating":5,"review":"Sunt eiusmod ea labore est sint adipisicing velit duis."},{"rating":6,"review":"Ut consectetur ad magna officia ut aliqua deserunt magna."}]}''));',
'',
'        -- Order items data',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (349,1,11,30.69,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (349,2,12,10.48,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (401,1,28,10.24,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (401,2,12,10.48,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (430,1,18,24.46,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (430,2,15,13.97,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (437,1,37,29.51,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (437,2,20,28.21,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (453,1,43,16.64,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (453,2,2,29.55,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (506,1,18,24.46,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (506,2,21,38.34,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (513,1,11,30.69,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (513,2,4,44.17,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (513,3,19,14.34,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (544,1,37,29.51,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (544,2,6,38.28,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (544,3,27,39.91,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (585,1,29,24.71,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (585,2,31,28.59,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (585,3,37,29.51,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (608,1,15,13.97,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (608,2,23,10.33,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (608,3,35,7.18,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (672,1,46,39.16,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (687,1,42,10.11,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (687,2,13,12.64,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (707,1,18,24.46,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (760,1,46,39.16,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (760,2,20,28.21,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (761,1,33,37,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (761,2,2,29.55,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (765,1,34,23.32,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (765,2,13,12.64,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (766,1,12,10.48,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (769,1,42,10.11,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,'))
);
wwv_flow_imp_shared.append_to_install_script(
 p_id=>wwv_flow_imp.id(296292070758789073769)
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'quantity) values (808,1,39,11,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (808,2,13,12.64,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1,1,33,37,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1,2,11,30.69,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (3,1,41,8.66,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (5,1,40,34.06,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (5,2,32,5.65,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (7,1,36,49.12,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (7,2,29,24.71,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (17,1,46,39.16,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (17,2,26,48.75,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (20,1,27,39.91,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (20,2,9,21.16,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (20,3,32,5.65,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (63,1,7,19.16,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (63,2,24,48.39,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (78,1,3,16.67,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (78,2,35,7.18,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (78,3,9,21.16,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (79,1,34,23.32,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (79,2,8,19.58,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (79,3,4,44.17,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (82,1,21,38.34,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (82,2,10,29.49,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (92,1,15,13.97,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (125,1,22,39.78,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (125,2,39,11,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (132,1,11,30.69,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (132,2,31,28.59,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (132,3,10,29.49,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (159,1,8,19.58,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (182,1,23,10.33,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (182,2,20,28.21,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (196,1,3,16.67,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (196,2,23,10.33,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (201,1,19,14.34,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (201,2,36,49.12,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (204,1,33,37,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (204,2,12,10.48,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (240,1,12,10.48,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (240,2,17,39.89,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (290,1,11,30.69,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (290,2,27,39.91,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (290,3,38,22.98,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (298,1,9,21.16,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (298,2,43,16.64,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (306,1,28,10.24,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (307,1,38,22.98,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (307,2,19,14.34,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (331,1,34,23.32,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1483,1,46,39.16,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1483,2,23,10.33,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1483,3,14,26.14,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1486,1,44,39.32,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1486,2,36,49.12,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1486,3,14,26.14,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1491,1,12,10.48,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1498,1,16,13.09,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1498,2,5,43.71,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1513,1,36,49.12,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1513,2,5,43.71,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1513,3,44,39.32,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1520,1,13,12.64,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1520,2,46,27.64,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1520,3,33,37,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1525,1,40,34.06,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1525,2,17,39.89,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1543,1,21,38.34,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1543,2,26,48.75,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1543,3,11,30.69,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1549,1,14,26.14,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1549,2,43,16.64,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1552,1,34,23.32,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1555,1,17,39.89,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1555,2,34,23.32,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1560,1,8,19.58,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1560,2,21,38.34,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1561,1,43,16.64,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1561,2,7,19.16,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1635,1,15,13.97,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1635,2,4,44.17,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1635,3,36,49.12,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1637,1,25,9.8,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1659,1,14,26.14,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1730,1,20,28.21,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1730,2,11,30.69,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1731,1,39,11,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1731,2,21,38.34,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1776,1,34,23.32,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1776,2,25,9.8,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1776,3,20,28.21,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1808,1,14,26.14,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1817,1,34,23.32,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1817,2,42,10.11,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1817,3,22,39.78,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1890,1,2,29.55,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1890,2,46,39.16,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (832,1,10,29.49,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (832,2,9,21.16,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (839,1,38,22.98,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (839,2,7,19.16,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (862,1,23,10.33,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (862,2,33,37,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (899,1,31,28.59,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (920,1,41,8.66,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (920,2,4,44.17,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (928,1,3,16.67,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (928,2,12,10.48,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (928,3,35,7.18,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (943,1,6,38.28,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (950,1,22,39.78,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (950,2,23,10.33,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (960,1,26,48.75,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (960,2,43,16.64,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (960,3,24,48.39,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (968,1,30,37.34,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (968,2,13,12.64,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (968,3,35,7.18,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (972,1,27,39.91,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (972,2,23,10.33,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (986,1,12,10.48,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (986,2,14,26.14,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (993,1,35,7.18,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (993,2,14,26.14,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (993,3,19,14.34,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1052,1,36,49.12,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1052,2,33,37,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1052,3,44,39.32,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1058,1,16,13.09,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1058,2,34,23.32,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1058,3,2,29.55,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1082,1,22,39.78,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1082,2,20,28.21,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1102,1,10,29.49,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1102,2,39,11,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1102,3,14,26.14,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1111,1,41,8.66,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1111,2,13,12.64,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1119,1,25,9.8,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1119,2,9,21.16,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1119,3,45,31.68,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1121,1,27,39.91,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1169,1,9,21.16,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1169,2,22,39.78,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1191,1,33,37,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1191,2,40,34.06,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1191,3,14,26.14,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1195,1,13,12.64,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1200,1,19,14.34,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1200,2,27,39.91,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1200,3,7,19.16,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1260,1,30,37.34,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1260,2,5,43.71,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1321,1,43,16.64,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1321,2,37,29.51,1);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1321,3,46,39.16,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1348,1,31,28.59,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1348,2,23,10.33,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1348,3,3,16.67,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1363,1,11,30.69,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1363,2,14,26.14,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1373,1,17,39.89,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1373,2,29,24.71,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1390,1,12,10.48,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1390,2,28,10.24,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1390,3,9,21.16,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1400,1,11,30.69,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1400,2,6,38.28,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1418,1,31,28.59,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1418,2,45,31.68,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1437,1,3,16.67,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1439,1,46,27.64,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1439,2,9,21.16,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1448,1,2,29.55,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1450,1,4,44.17,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1451,1,10,29.49,5);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1451,2,35,7.18,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1455,1,45,31.68,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1455,2,23,10.33,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1468,1,2,29.55,3);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1468,2,45,31.68,4);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1471,1,14,26.14,2);',
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1471,2,6,38.28,3);',
'',
'        -- Support Ticket data',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 1,"title": "Wrong item delivered","description": "I ordered a Boy''''s Trousers but received jeans instead.","status": "Open","priority": "High","created_at": "2025-01-'
||'10","updated_at": "2025-01-11","customer_id": 4,"concern": {"order_id": 453,"product_id": 43,"store_id": 4},"comments": [{"comment_id": 1,"author": "agent","message": "We are looking into this issue.","created_at": "2025-01-10"},{"comment_id": 2,"aut'
||'hor": "Victor Morris","message": "Please hurry, I need it urgently.","created_at": "2025-01-11"}],"resolution": null}''));',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 2,"title": "Product damaged on arrival","description": "The pyjamas has a hole in it.","status": "Resolved","priority": "Medium","created_at": "2025-02-14","updated_a'
||'t": "2025-02-16","customer_id": 4,"concern": {"order_id": 506,"product_id": 21,"store_id": 1},"comments": [{"comment_id": 3,"author": "agent","message": "Replacement has been shipped.","created_at": "2025-02-15"}],"resolution": "Replacement product s'
||'ent to customer on 2025-02-15."}''));',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 3,"title": "Store location incorrect on website","description": "The address listed for the store is wrong.","status": "Pending","priority": "Low","created_at": "2025'
||'-03-01","updated_at": "2025-03-01","customer_id": 3,"concern": {"order_id": 544,"product_id": 37,"store_id": 1},"comments": [],"resolution": null}''));',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 4,"title": "Order never arrived","description": "My order was marked as delivered but I never received it.","status": "Open","priority": "High","created_at": "2025-03'
||'-05","updated_at": "2025-03-06","customer_id": 15,"concern": {"order_id": 513,"product_id": 4,"store_id": 1},"comments": [{"comment_id": 4,"author": "agent","message": "We have contacted the delivery team.","created_at": "2025-03-06"}],"resolution": '
||'null}''));',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 5,"title": "Refund not processed","description": "I returned the item 2 weeks ago but still no refund.","status": "Pending","priority": "High","created_at": "2025-03-'
||'08","updated_at": "2025-03-09","customer_id": 4,"concern": {"order_id": 672,"product_id": 46,"store_id": 4},"comments": [{"comment_id": 5,"author": "agent","message": "Refund request has been escalated to finance team.","created_at": "2025-03-08"},{"'
||'comment_id": 6,"author": "Victor Morris","message": "This is taking too long, very disappointed.","created_at": "2025-03-09"}],"resolution": null}''));',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 6,"title": "Incorrect charge on my account","description": "I was charged twice for the same order.","status": "Open","priority": "High","created_at": "2025-01-15","u'
||'pdated_at": "2025-01-16","customer_id": 15,"concern": {"order_id": 1400,"product_id": 11,"store_id": 15},"comments": [{"comment_id": 7,"author": "agent","message": "We are verifying the payment records.","created_at": "2025-01-15"},{"comment_id": 8,"'
||'author": "Walter Rogers","message": "Please resolve this ASAP.","created_at": "2025-01-16"}],"resolution": null}''));',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 7,"title": "Product not as described","description": "The socks I received is much different than shown on the website.","status": "Resolved","priority": "Medium","cr'
||'eated_at": "2025-01-20","updated_at": "2025-01-25","customer_id": 8,"concern": {"order_id": 1561,"product_id": 7,"store_id": 8},"comments": [{"comment_id": 9,"author": "agent","message": "We apologize for the inconvenience, a return label has been se'
||'nt.","created_at": "2025-01-21"},{"comment_id": 10,"author": "Douglas Flores","message": "Thank you, I have shipped it back.","created_at": "2025-01-23"},{"comment_id": 11,"author": "agent","message": "Return received, full refund processed.","create'
||'d_at": "2025-01-25"}],"resolution": "Full refund issued on 2025-01-25."}''));',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 8,"title": "App crashes when viewing order history","description": "Every time I open my order history the app freezes and crashes.","status": "Pending","priority": "'
||'Medium","created_at": "2025-01-28","updated_at": "2025-01-29","customer_id": 9,"concern": {"order_id": 1102,"product_id": null,"store_id": null},"comments": [{"comment_id": 12,"author": "agent","message": "Our technical team is investigating the issu'
||'e.","created_at": "2025-01-29"}],"resolution": null}''));',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 9,"title": "Missing items in order","description": "My order contained 3 items but only 2 were delivered.","status": "Open","priority": "High","created_at": "2025-02-'
||'02","updated_at": "2025-02-03","customer_id": 5,"concern": {"order_id": 306,"product_id": 28,"store_id": 5},"comments": [{"comment_id": 13,"author": "agent","message": "We are checking with the warehouse team.","created_at": "2025-02-02"},{"comment_i'
||'d": 14,"author": "Beverly Hughes","message": "Still waiting for an update.","created_at": "2025-02-03"}],"resolution": null}''));',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 10,"title": "Delivery address was wrong","description": "My package was delivered to the wrong address.","status": "Resolved","priority": "High","created_at": "2025-0'
||'2-05","updated_at": "2025-02-08","customer_id": 13,"concern": {"order_id": 1052,"product_id": 21,"store_id": 13},"comments": [{"comment_id": 15,"author": "agent_jones","message": "We have contacted the courier to retrieve the package.","created_at": '
||'"2025-02-06"},{"comment_id": 16,"author": "agent_jones","message": "Package has been retrieved and will be redelivered.","created_at": "2025-02-07"},{"comment_id": 17,"author": "Michelle Ramirez","message": "Package received, thank you!","created_at"'
||': "2025-02-08"}],"resolution": "Package successfully redelivered on 2025-02-08."}''));',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 11,"title": "Cannot apply discount code","description": "The promo code SAVE20 is not working at checkout.","status": "Pending","priority": "Low","created_at": "2025-'
||'02-10","updated_at": "2025-02-10","customer_id": 17,"concern": {"order_id": 92,"product_id": 15,"store_id": 1},"comments": [{"comment_id": 18,"author": "agent","message": "We are verifying the promo code'))
);
wwv_flow_imp_shared.append_to_install_script(
 p_id=>wwv_flow_imp.id(296292070758789073769)
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' validity.","created_at": "2025-02-10"}],"resolution": null}''));',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 12,"title": "Item out of stock after purchase","description": "I paid for an item that was then cancelled due to being out of stock.","status": "Resolved","priority":'
||' "Medium","created_at": "2025-02-18","updated_at": "2025-02-20","customer_id": 20,"concern": {"order_id": 1776,"product_id": 34,"store_id": 20},"comments": [{"comment_id": 19,"author": "agent","message": "We sincerely apologize, a full refund has bee'
||'n initiated.","created_at": "2025-02-19"},{"comment_id": 20,"author": "Dennis Lopez","message": "Refund received, thank you.","created_at": "2025-02-20"}],"resolution": "Full refund processed on 2025-02-19."}''));',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 13,"title": "Store staff was rude","description": "The staff at Beijing store were very unhelpful and dismissive.","status": "Pending","priority": "Low","created_at":'
||' "2025-02-22","updated_at": "2025-02-22","customer_id": 13,"concern": {"order_id": null,"product_id": null,"store_id": 21},"comments": [{"comment_id": 21,"author": "agent","message": "We apologize for the experience, this has been escalated to the st'
||'ore manager.","created_at": "2025-02-22"}],"resolution": null}''));',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 14,"title": "Warranty claim rejected unfairly","description": "My product broke within the warranty period but the claim was rejected.","status": "Open","priority": "'
||'High","created_at": "2025-03-02","updated_at": "2025-03-03","customer_id": 4,"concern": {"order_id": 920,"product_id": 41,"store_id": 4},"comments": [{"comment_id": 22,"author": "agent","message": "We are reviewing the warranty claim details.","creat'
||'ed_at": "2025-03-02"},{"comment_id": 23,"author": "Victor Morris","message": "I have photos of the defect, where can I send them?","created_at": "2025-03-03"},{"comment_id": 24,"author": "agent","message": "Please send them to support@store.com.","cr'
||'eated_at": "2025-03-03"}],"resolution": null}''));',
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 15,"title": "Subscription not cancelled","description": "I requested cancellation of my subscription last month but was still charged.","status": "Open","priority": "'
||'High","created_at": "2025-03-10","updated_at": "2025-03-11","customer_id": 15,"concern": {"order_id": 513,"product_id": null,"store_id": 1},"comments": [{"comment_id": 25,"author": "agent","message": "We are checking your cancellation request status.'
||'","created_at": "2025-03-10"},{"comment_id": 26,"author": "Walter Rogers","message": "I have the cancellation email as proof.","created_at": "2025-03-11"}],"resolution": null}''));',
'',
'        commit;',
'    end load_data;',
'',
'    procedure load_product_images(p_app_id in number, p_file_name in varchar2) is',
'        l_zip_file      blob;',
'        l_files         apex_zip.t_files;',
'    begin',
'        select file_content',
'        into l_zip_file',
'        from APEX_APPLICATION_STATIC_FILES',
'        where application_id = p_app_id and file_name = p_file_name;',
'    ',
'        l_files := APEX_ZIP.get_files (',
'                p_zipped_blob => l_zip_file );',
'    ',
'        for i in 1 .. l_files.count loop',
'            update eba_demo_json_products',
'            set product_image = APEX_ZIP.get_file_content (',
'                p_zipped_blob => l_zip_file,',
'                p_file_name   => l_files(i) )',
'            where product_id = substr(l_files(i),0,instr(l_files(i),''.''));',
'        end loop;',
'        commit;',
'    end load_product_images;',
'',
'    procedure reset_data is',
'    begin',
'        clear_data;',
'        load_data;',
'    end reset_data;',
'',
'end eba_demo_json_data_pkg;',
'/',
'',
'begin',
'    eba_demo_json_data_pkg.reset_data;',
'end;',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
