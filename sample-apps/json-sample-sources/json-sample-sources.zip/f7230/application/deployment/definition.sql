prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7230
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(296295828950238257576)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- ===========================================================================',
'-- Remove PL/SQL package',
'-- ===========================================================================',
'drop package eba_demo_json_data_pkg;',
'',
'-- ===========================================================================',
'-- Remove tables',
'-- ===========================================================================',
'drop table eba_demo_json_stores          cascade constraints purge;',
'drop table eba_demo_json_products        cascade constraints purge;',
'drop table eba_demo_json_customers       cascade constraints purge;',
'drop table eba_demo_json_orders          cascade constraints purge;',
'drop table eba_demo_json_order_items     cascade constraints purge;',
'',
'-- Remove json collection',
'drop table eba_demo_json_support_ticket  cascade constraints purge;',
'',
'-- Remove duality views',
'drop json relational duality view eba_demo_json_stores_dv;',
'drop json relational duality view eba_demo_json_customer_orders_dv;',
'',
'',
'-- ===========================================================================',
'-- Remove sequences',
'-- ===========================================================================',
'',
'drop sequence eba_demo_json_customers_seq ;',
'drop sequence eba_demo_json_orders_seq ;',
'drop sequence eba_demo_json_stores_seq ;',
'drop sequence eba_demo_json_products_seq ;',
''))
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
);
wwv_flow_imp.component_end;
end;
/
