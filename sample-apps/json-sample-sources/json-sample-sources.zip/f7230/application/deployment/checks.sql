prompt --application/deployment/checks
begin
--   Manifest
--     INSTALL CHECKS: 7230
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_check(
 p_id=>wwv_flow_imp.id(1072166106137609)
,p_install_id=>wwv_flow_imp.id(296295828950238257576)
,p_name=>'Require Oracle AI Database 26ai or later'
,p_sequence=>10
,p_check_type=>'EXPRESSION'
,p_check_condition=>'sys.dbms_db_version.version >= 23'
,p_check_condition2=>'PLSQL'
,p_failure_message=>'This sample application requires Oracle Database 26ai or later.'
);
wwv_flow_imp.component_end;
end;
/
