prompt --application/shared_components/logic/application_processes/load_products_images
begin
--   Manifest
--     APPLICATION PROCESS: Load Products Images
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(393291387870508047)
,p_process_sequence=>1
,p_process_point=>'ON_NEW_INSTANCE'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Products Images'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    eba_demo_json_data_pkg.load_product_images(:APP_ID,''product_images.zip'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'select * from eba_demo_json_products where product_image is not null'
,p_process_when_type=>'NOT_EXISTS'
,p_version_scn=>73549138
);
wwv_flow_imp.component_end;
end;
/
