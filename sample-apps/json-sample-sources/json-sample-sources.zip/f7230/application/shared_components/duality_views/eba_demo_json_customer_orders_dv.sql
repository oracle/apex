prompt --application/shared_components/duality_views/eba_demo_json_customer_orders_dv
begin
--   Manifest
--     DOCUMENT SOURCE: eba_demo_json_customer_orders_dv
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_document_source(
 p_id=>wwv_flow_imp.id(128250832382027732072)
,p_name=>'eba_demo_json_customer_orders_dv'
,p_static_id=>'eba_demo_json_customer_orders_dv'
,p_document_source_type=>'DUALITY_VIEW'
,p_location=>'LOCAL'
,p_object_name=>'EBA_DEMO_JSON_CUSTOMER_ORDERS_DV'
,p_data_profile_id=>wwv_flow_imp.id(128250832454639732072)
,p_version_scn=>36573452
);
wwv_flow_imp.component_end;
end;
/
