prompt --application/shared_components/navigation/search_config/product_search
begin
--   Manifest
--     SEARCH CONFIG: Product Search
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(16200977314371829)
,p_label=>'Product Search'
,p_static_id=>'product_search'
,p_search_type=>'SIMPLE'
,p_location=>'JSON_COLLECTION'
,p_document_source_id=>wwv_flow_imp.id(296295019465326886274)
,p_query_where=>'1=1'
,p_source_post_processing=>'WHERE_ORDER_BY_CLAUSE'
,p_searchable_columns=>'BRAND:COLOUR:GENDER:DESCRIPTION:PRODUCT_NAME:IMAGE_FILENAME:IMAGE_CHARSET:IMAGE_LAST_UPDATED:SIZES:REVIEWS'
,p_pk_column_name=>'PRODUCT_ID'
,p_title_column_name=>'PRODUCT_NAME'
,p_subtitle_column_name=>'BRAND'
,p_description_column_name=>'DESCRIPTION'
,p_badge_column_name=>'UNIT_PRICE'
,p_custom_01_column_name=>'COLOUR'
,p_custom_02_column_name=>'GENDER'
,p_icon_source_type=>'BLOB'
,p_icon_blob_column_name=>'PRODUCT_IMAGE'
,p_icon_mimetype_column_name=>'IMAGE_MIME_TYPE'
,p_version_scn=>143404845
);
wwv_flow_imp.component_end;
end;
/
