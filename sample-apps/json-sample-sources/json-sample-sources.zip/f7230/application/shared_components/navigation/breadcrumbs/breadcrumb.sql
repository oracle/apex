prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(296295315947355646367)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(393036864254551142)
,p_parent_id=>wwv_flow_imp.id(296294866749719776301)
,p_short_name=>'Faceted Search'
,p_link=>'f?p=&APP_ID.:403:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>403
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(577932495279179175)
,p_parent_id=>wwv_flow_imp.id(296294866749719776301)
,p_short_name=>'Search Page'
,p_link=>'f?p=&APP_ID.:408:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>408
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(578150120319713068)
,p_parent_id=>wwv_flow_imp.id(296294869854753792069)
,p_short_name=>'JSON_TRANSFORM'
,p_link=>'f?p=&APP_ID.:302:&SESSION.::&DEBUG.:::'
,p_page_id=>302
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(597903209183976046)
,p_parent_id=>wwv_flow_imp.id(296294866749719776301)
,p_short_name=>'Map'
,p_link=>'f?p=&APP_ID.:404:&SESSION.::&DEBUG.:::'
,p_page_id=>404
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(617779938982870793)
,p_parent_id=>wwv_flow_imp.id(296294866749719776301)
,p_short_name=>'Master Detail'
,p_link=>'f?p=&APP_ID.:405:&SESSION.::&DEBUG.:::'
,p_page_id=>405
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296291364970147888031)
,p_parent_id=>wwv_flow_imp.id(296294840187043729822)
,p_short_name=>'Table with JSON Column'
,p_link=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.:::'
,p_page_id=>101
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296291365540379891661)
,p_parent_id=>wwv_flow_imp.id(296294840187043729822)
,p_short_name=>'JSON Collection Table'
,p_link=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:::'
,p_page_id=>102
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296291365840123894165)
,p_parent_id=>wwv_flow_imp.id(296294840187043729822)
,p_short_name=>'Post Processing'
,p_link=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:::'
,p_page_id=>103
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296291475935699474537)
,p_parent_id=>wwv_flow_imp.id(296294869854753792069)
,p_short_name=>'JSON_TABLE'
,p_link=>'f?p=&APP_ID.:301:&SESSION.::&DEBUG.:::'
,p_page_id=>301
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296291759339807534172)
,p_parent_id=>wwv_flow_imp.id(296294866749719776301)
,p_short_name=>'Interactive Grid'
,p_link=>'f?p=&APP_ID.:401:&SESSION.::&DEBUG.:::'
,p_page_id=>401
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296291759556573545434)
,p_parent_id=>wwv_flow_imp.id(296294882395182812067)
,p_short_name=>'Data Loading'
,p_link=>'f?p=&APP_ID.:502:&SESSION.::&DEBUG.:::'
,p_page_id=>502
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296291761407480601509)
,p_parent_id=>wwv_flow_imp.id(296294866749719776301)
,p_short_name=>'Charts from JSON'
,p_link=>'f?p=&APP_ID.:402:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>402
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296292057664130811229)
,p_parent_id=>wwv_flow_imp.id(296292046937095767865)
,p_short_name=>'Reset Data'
,p_link=>'f?p=&APP_ID.:602:&SESSION.::&DEBUG.:::'
,p_page_id=>602
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296293619509953373824)
,p_parent_id=>wwv_flow_imp.id(296293838147813938814)
,p_short_name=>'Workflow Console'
,p_link=>'f?p=&APP_ID.:504:&SESSION.::&DEBUG.:::'
,p_page_id=>504
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296293838147813938814)
,p_parent_id=>wwv_flow_imp.id(296294882395182812067)
,p_short_name=>'JSON and Workflow'
,p_link=>'f?p=&APP_ID.:503:&SESSION.::&DEBUG.:::'
,p_page_id=>503
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296295316149024646368)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(597856073878478573)
,p_option_sequence=>20
,p_short_name=>'Duality View'
,p_link=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_page_id=>200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296294840187043729822)
,p_option_sequence=>30
,p_short_name=>'JSON Sources'
,p_link=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296294866749719776301)
,p_option_sequence=>40
,p_short_name=>'Data Presentation'
,p_link=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.:::'
,p_page_id=>400
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296294882395182812067)
,p_option_sequence=>50
,p_short_name=>'Use Cases'
,p_link=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.:::'
,p_page_id=>500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296294869854753792069)
,p_option_sequence=>60
,p_short_name=>'SQL/JSON Functions'
,p_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:::'
,p_page_id=>300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(296292046937095767865)
,p_option_sequence=>70
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:600:&SESSION.::&DEBUG.:::'
,p_page_id=>600
);
wwv_flow_imp.component_end;
end;
/
