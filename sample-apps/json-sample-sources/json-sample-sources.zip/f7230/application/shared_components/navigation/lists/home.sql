prompt --application/shared_components/navigation/lists/home
begin
--   Manifest
--     LIST: Home
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(296296063074826623658)
,p_name=>'Home'
,p_list_status=>'PUBLIC'
,p_version_scn=>73698254
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296063237751623668)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'JSON Sources'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-json-o'
,p_list_text_01=>'Demonstrates how to work with JSON data stored in Oracle tables and collections.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296064455511623671)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Data Presentation'
,p_list_item_link_target=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bar-chart'
,p_list_text_01=>'Highlights different ways to visualize and interact with data in APEX.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296064814918623671)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Use Cases'
,p_list_item_link_target=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-missile'
,p_list_text_01=>'Provides practical examples of real-world JSON and APEX implementations.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296063671668623670)
,p_list_item_display_sequence=>55
,p_list_item_link_text=>'Duality View'
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-exchange'
,p_list_text_01=>'Showcases bidirectional synchronization between relational data and JSON using duality views.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296064075289623671)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'SQL/JSON Functions'
,p_list_item_link_target=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_list_text_01=>'Explores built-in SQL functions for querying and transforming JSON data manually.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
