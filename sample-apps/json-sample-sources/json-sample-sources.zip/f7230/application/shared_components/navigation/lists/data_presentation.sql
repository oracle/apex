prompt --application/shared_components/navigation/lists/data_presentation
begin
--   Manifest
--     LIST: Data Presentation
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(296296080833441846098)
,p_name=>'Data Presentation'
,p_list_status=>'PUBLIC'
,p_version_scn=>95636792
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296081051724846099)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Interactive Grid'
,p_list_item_link_target=>'f?p=&APP_ID.:401:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-grid-3x'
,p_list_text_01=>'Provides an editable grid interface for managing structured and JSON-based data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296081824642846099)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Charts from JSON'
,p_list_item_link_target=>'f?p=&APP_ID.:402:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bar-chart'
,p_list_text_01=>'Visualizes JSON data using dynamic charts and graphical components.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296082247889846099)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Faceted Search'
,p_list_item_link_target=>'f?p=&APP_ID.:403:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-server-search'
,p_list_text_01=>'Enables advanced filtering and search capabilities across JSON datasets.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(577941527793252939)
,p_list_item_display_sequence=>45
,p_list_item_link_text=>'Search Page'
,p_list_item_link_target=>'f?p=&APP_ID.:408:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_text_01=>'Searches JSON-based product data instantly using Standard Search Configuration.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296082665874846099)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Map'
,p_list_item_link_target=>'f?p=&APP_ID.:404:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-marker'
,p_list_text_01=>'Displays location-based data using map visualization integrated with JSON data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296083159018850415)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Master Detail'
,p_list_item_link_target=>'f?p=&APP_ID.:405:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header-sidebar-left'
,p_list_text_01=>'Shows relationships between datasets with synchronized master-detail views.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
