prompt --application/shared_components/json_source/eba_demo_json_customers
begin
--   Manifest
--     DOCUMENT SOURCE: EBA_DEMO_JSON_CUSTOMERS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_document_source(
 p_id=>wwv_flow_imp.id(637094877665027065)
,p_name=>'EBA_DEMO_JSON_CUSTOMERS'
,p_static_id=>'eba_demo_json_customers'
,p_document_source_type=>'JSON_TABLE'
,p_location=>'LOCAL'
,p_object_name=>'EBA_DEMO_JSON_CUSTOMERS'
,p_data_profile_id=>wwv_flow_imp.id(637094936585027065)
,p_version_scn=>41429520
);
wwv_flow_imp.component_end;
end;
/
