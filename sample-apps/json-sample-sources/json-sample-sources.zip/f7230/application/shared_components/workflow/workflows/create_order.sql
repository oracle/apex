prompt --application/shared_components/workflow/workflows/create_order
begin
--   Manifest
--     WORKFLOW: Create Order
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_workflow(
 p_id=>wwv_flow_imp.id(128233967803689329553)
,p_name=>'Create Order'
,p_static_id=>'ORDER_PLACEMENT_WORKFLOW_1'
,p_title=>'Create Order'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128233967874739329554)
,p_workflow_id=>wwv_flow_imp.id(128233967803689329553)
,p_label=>'P_CUSTOMER_ID'
,p_static_id=>'P_CUSTOMER_ID'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_is_required=>false
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128233968043509329555)
,p_workflow_id=>wwv_flow_imp.id(128233967803689329553)
,p_label=>'P_PRODUCT_ID'
,p_static_id=>'P_PRODUCT_ID'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_is_required=>false
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128233968082061329556)
,p_workflow_id=>wwv_flow_imp.id(128233967803689329553)
,p_label=>'P_QUANTITY'
,p_static_id=>'P_QUANTITY'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_is_required=>false
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128233968219881329557)
,p_workflow_id=>wwv_flow_imp.id(128233967803689329553)
,p_label=>'P_STORE_ID'
,p_static_id=>'P_STORE_ID'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_is_required=>false
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234030167881619945)
,p_workflow_id=>wwv_flow_imp.id(128233967803689329553)
,p_label=>'P_PAYMENT_METHOD'
,p_static_id=>'P_PAYMENT_METHOD'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234030340412619947)
,p_workflow_id=>wwv_flow_imp.id(128233967803689329553)
,p_label=>'P_STREET'
,p_static_id=>'P_STREET'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234030437557619948)
,p_workflow_id=>wwv_flow_imp.id(128233967803689329553)
,p_label=>'P_CITY'
,p_static_id=>'P_CITY'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234030495353619949)
,p_workflow_id=>wwv_flow_imp.id(128233967803689329553)
,p_label=>'P_STATE'
,p_static_id=>'P_STATE'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234030605504619950)
,p_workflow_id=>wwv_flow_imp.id(128233967803689329553)
,p_label=>'P_COUNTRY'
,p_static_id=>'P_COUNTRY'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234030708273619951)
,p_workflow_id=>wwv_flow_imp.id(128233967803689329553)
,p_label=>'P_POSTAL_CODE'
,p_static_id=>'P_POSTAL_CODE'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234345768585635048)
,p_workflow_id=>wwv_flow_imp.id(128233967803689329553)
,p_label=>'P_EMAIL_ADDRESS'
,p_static_id=>'P_EMAIL_ADDRESS'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_workflow_version(
 p_id=>wwv_flow_imp.id(128233968310468329558)
,p_workflow_id=>wwv_flow_imp.id(128233967803689329553)
,p_version=>'1.0'
,p_state=>'DEVELOPMENT'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(402922564334502994)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_label=>'V_PRODUCT_NAME'
,p_static_id=>'V_PRODUCT_NAME'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234028719078619931)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_label=>'V_CUSTOMER_NAME'
,p_static_id=>'V_CUSTOMER_NAME'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234028797587619932)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_label=>'V_ESTIMATED_DELIVERY'
,p_static_id=>'V_ESTIMATED_DELIVERY'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234028900515619933)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_label=>'V_LOYALTY_TIER'
,p_static_id=>'V_LOYALTY_TIER'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234028979757619934)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_label=>'V_ORDER_ID'
,p_static_id=>'V_ORDER_ID'
,p_direction=>'VARIABLE'
,p_data_type=>'NUMBER'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234029101208619935)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_label=>'V_SHIPMENT_METHOD'
,p_static_id=>'V_SHIPMENT_METHOD'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234029241751619936)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_label=>'V_STORE_NAME'
,p_static_id=>'V_STORE_NAME'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234029282313619937)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_label=>'V_TOTAL_AMOUNT'
,p_static_id=>'V_TOTAL_AMOUNT'
,p_direction=>'VARIABLE'
,p_data_type=>'NUMBER'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(128234029451259619938)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_label=>'V_UNIT_PRICE'
,p_static_id=>'V_UNIT_PRICE'
,p_direction=>'VARIABLE'
,p_data_type=>'NUMBER'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(128233968460871329559)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_name=>'Start'
,p_static_id=>'New'
,p_display_sequence=>10
,p_activity_type=>'NATIVE_WORKFLOW_START'
,p_diagram=>'{"position":{"x":570,"y":970},"z":1}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(128233968584372329561)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_name=>'Fetch Customer and Store Details'
,p_static_id=>'New_1'
,p_display_sequence=>20
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  -- Customer',
'  begin',
'    select c.full_name,',
'           json_value(c.customer_metadata, ''$.loyalty_tier'')',
'      into :V_CUSTOMER_NAME,',
'           :V_LOYALTY_TIER',
'      from eba_demo_json_customers c',
'     where c.customer_id = :P_CUSTOMER_ID;',
'  exception',
'    when no_data_found then',
'      raise_application_error(',
'        -20001,',
'        ''Customer '' || :P_CUSTOMER_ID || '' not found.''',
'      );',
'  end;',
'',
'  -- Store',
'  begin',
'    select s.store_name',
'      into :V_STORE_NAME',
'      from eba_demo_json_stores s',
'     where s.store_id = :P_STORE_ID;',
'  exception',
'    when no_data_found then',
'      raise_application_error(',
'        -20002,',
'        ''Store '' || :P_STORE_ID || '' not found.''',
'      );',
'  end;',
'',
'end;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":660,"y":970},"z":2}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(128233968801176329563)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_name=>'End'
,p_static_id=>'New_2'
,p_display_sequence=>30
,p_activity_type=>'NATIVE_WORKFLOW_END'
,p_attribute_01=>'COMPLETED'
,p_diagram=>'{"position":{"x":1830,"y":840},"z":3}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(128233969116482329566)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_name=>'Fetch Product and Calculate Order Amount'
,p_static_id=>'New_4'
,p_display_sequence=>50
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  select p.unit_price,',
'         p.product_name',
'    into :V_UNIT_PRICE,',
'         :V_PRODUCT_NAME',
'    from eba_demo_json_products p',
'   where p.product_id = :P_PRODUCT_ID;',
'',
'  :V_TOTAL_AMOUNT := :V_UNIT_PRICE * :P_QUANTITY;',
'',
'exception',
'  when no_data_found then',
'    raise_application_error(',
'      -20003,',
'      ''Product '' || :P_PRODUCT_ID || '' not found.''',
'    );',
'end;',
''))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":660,"y":830},"z":5}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(128234027394727619918)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_name=>'Create Order'
,p_static_id=>'New_5'
,p_display_sequence=>60
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  -- Insert order',
'  insert into eba_demo_json_orders (',
'    order_datetime,',
'    customer_id,',
'    order_status,',
'    store_id,',
'    order_metadata',
'  ) values (',
'    systimestamp,',
'    :P_CUSTOMER_ID,',
'    ''Open'',',
'    :P_STORE_ID,',
'    json_object(',
'      ''shipment'' value json_object(',
'        ''method''             value ''Pending'',',
'        ''status''             value ''Processing'',',
'        ''estimated_delivery'' value null',
'      ),',
'      ''payment'' value json_object(',
'        ''method'' value :P_PAYMENT_METHOD,',
'        ''status'' value ''Paid''',
'      ),',
'      ''delivery_address'' value json_object(',
'        ''street''         value :P_STREET,',
'        ''city''           value :P_CITY,',
'        ''state_province'' value :P_STATE,',
'        ''country''        value :P_COUNTRY,',
'        ''postal_code''    value :P_POSTAL_CODE',
'      ) null on null',
'    )',
'  )',
'  returning order_id into :V_ORDER_ID;',
'',
'  -- Insert order item',
'  insert into eba_demo_json_order_items (',
'    order_id,',
'    line_item_id,',
'    product_id,',
'    unit_price,',
'    quantity',
'  ) values (',
'    :V_ORDER_ID,',
'    1,',
'    :P_PRODUCT_ID,',
'    :V_UNIT_PRICE,',
'    :P_QUANTITY',
'  );',
'',
'end;',
''))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":950,"y":830},"z":6}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(128234027789012619922)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_name=>'Shipping Decision'
,p_static_id=>'New_7'
,p_display_sequence=>80
,p_activity_type=>'NATIVE_WORKFLOW_SWITCH'
,p_attribute_01=>'CHECK_WF_VARIABLE'
,p_attribute_10=>'V_LOYALTY_TIER'
,p_diagram=>'{"position":{"x":1240,"y":830},"z":8}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(128234028087957619925)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_name=>'Express Shipping'
,p_static_id=>'New_8'
,p_display_sequence=>90
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  :V_SHIPMENT_METHOD    := ''Express'';',
'  :V_ESTIMATED_DELIVERY := to_char(sysdate + 1, ''YYYY-MM-DD'');',
'',
'  update eba_demo_json_orders',
'     set order_status   = ''Paid'',',
'         order_metadata = json_mergepatch(',
'                            order_metadata,',
'                            json_object(',
'                              ''shipment'' value json_object(',
'                                ''method''             value ''Express'',',
'                                ''status''             value ''Shipped'',',
'                                ''estimated_delivery'' value :V_ESTIMATED_DELIVERY',
'                              )',
'                            )',
'                          )',
'   where order_id = :V_ORDER_ID;',
'end;',
''))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":1240,"y":710},"z":9}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(128234028372176619927)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_name=>'Standard Shipping'
,p_static_id=>'New_9'
,p_display_sequence=>100
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  :V_SHIPMENT_METHOD    := ''Standard'';',
'  :V_ESTIMATED_DELIVERY := to_char(sysdate + 3, ''YYYY-MM-DD'');',
'',
'  update eba_demo_json_orders',
'     set order_status   = ''Paid'',',
'         order_metadata = json_mergepatch(',
'                            order_metadata,',
'                            json_object(',
'                              ''shipment'' value json_object(',
'                                ''method''             value ''Standard'',',
'                                ''status''             value ''Shipped'',',
'                                ''estimated_delivery'' value :V_ESTIMATED_DELIVERY',
'                              )',
'                            )',
'                          )',
'   where order_id = :V_ORDER_ID;',
'end;',
''))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":1240,"y":930},"z":10}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(128234028523444619929)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_name=>'Send Email to Customer'
,p_static_id=>'New_10'
,p_display_sequence=>110
,p_activity_type=>'NATIVE_SEND_EMAIL'
,p_attribute_01=>'&P_EMAIL_ADDRESS.'
,p_attribute_02=>'&P_EMAIL_ADDRESS.'
,p_attribute_10=>'N'
,p_attribute_11=>wwv_flow_imp.id(403951483086125277)
,p_attribute_12=>'{"ORDER_ID":"&V_ORDER_ID.","SHIPMENT_METHOD":"&V_SHIPMENT_METHOD.","ESTIMATED_DELIVERY":"&V_ESTIMATED_DELIVERY.","CUSTOMER_NAME":"&V_CUSTOMER_NAME.","STORE_NAME":"&V_STORE_NAME.","PRODUCT_NAME":"&V_PRODUCT_NAME.","QUANTITY":"&P_QUANTITY.","UNIT_PRICE'
||'":"&V_UNIT_PRICE.","TOTAL_AMOUNT":"&V_TOTAL_AMOUNT.","LOYALTY_TIER":"&V_LOYALTY_TIER.","PAYMENT_METHOD":"&P_PAYMENT_METHOD.","STREET":"&P_STREET.","CITY":"&P_CITY.","STATE":"&P_STATE.","POSTAL_CODE":"&P_POSTAL_CODE.","COUNTRY":"&P_COUNTRY."}'
,p_diagram=>'{"position":{"x":1560,"y":840},"z":11}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(128233968483523329560)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(128233968460871329559)
,p_to_activity_id=>wwv_flow_imp.id(128233968584372329561)
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":12,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(128233968709469329562)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(128233968584372329561)
,p_to_activity_id=>wwv_flow_imp.id(128233969116482329566)
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":13,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(128234027363837619917)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(128233969116482329566)
,p_to_activity_id=>wwv_flow_imp.id(128234027394727619918)
,p_diagram=>'{"source":{},"target":{"args":{"dx":"50%","dy":"50%","rotate":true},"name":"topLeft"},"vertices":[],"z":15,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(128234027544553619919)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(128234027394727619918)
,p_to_activity_id=>wwv_flow_imp.id(128234027789012619922)
,p_diagram=>'{"source":{},"target":{"args":{"dx":"50%","dy":"50%","rotate":true},"name":"topLeft"},"vertices":[],"z":16,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(128234027881757619923)
,p_name=>'Express'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(128234027789012619922)
,p_to_activity_id=>wwv_flow_imp.id(128234028087957619925)
,p_condition_type=>'EQUALS'
,p_condition_expr1=>'Platinum'
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":21,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(128234027980075619924)
,p_name=>'Standard'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(128234027789012619922)
,p_to_activity_id=>wwv_flow_imp.id(128234028372176619927)
,p_condition_type=>'NOT_EQUALS'
,p_condition_expr1=>'Platinum'
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":22,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(128234028257751619926)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(128234028087957619925)
,p_to_activity_id=>wwv_flow_imp.id(128234028523444619929)
,p_diagram=>'{"source":{},"target":{"args":{"dx":"50%","dy":"50%","rotate":true},"name":"topLeft"},"vertices":[],"z":18,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(128234028431787619928)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(128234028372176619927)
,p_to_activity_id=>wwv_flow_imp.id(128234028523444619929)
,p_diagram=>'{"source":{},"target":{"args":{"dx":"50%","dy":"50%","rotate":true},"name":"topLeft"},"vertices":[],"z":19,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(128234028613503619930)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(128234028523444619929)
,p_to_activity_id=>wwv_flow_imp.id(128233968801176329563)
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":20,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_participant(
 p_id=>wwv_flow_imp.id(128234029559087619939)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_participant_type=>'ADMIN'
,p_name=>'Admin'
,p_identity_type=>'USER'
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'v(''APP_USER'')'
);
wwv_flow_imp_shared.create_workflow_participant(
 p_id=>wwv_flow_imp.id(128234029612593619940)
,p_workflow_version_id=>wwv_flow_imp.id(128233968310468329558)
,p_participant_type=>'OWNER'
,p_name=>'Owner'
,p_identity_type=>'USER'
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'v(''APP_USER'')'
);
wwv_flow_imp.component_end;
end;
/
