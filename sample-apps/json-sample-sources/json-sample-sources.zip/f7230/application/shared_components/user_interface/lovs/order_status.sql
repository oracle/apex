prompt --application/shared_components/user_interface/lovs/order_status
begin
--   Manifest
--     ORDER STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(128234460322408176876)
,p_lov_name=>'ORDER STATUS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct order_status',
'  from #APEX$SOURCE_DATA#'))
,p_location=>'JSON_COLLECTION'
,p_document_source_id=>wwv_flow_imp.id(296291624904214376496)
,p_source_post_processing=>'SQL'
,p_return_column_name=>'ORDER_STATUS'
,p_display_column_name=>'ORDER_STATUS'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>56862728
);
wwv_flow_imp.component_end;
end;
/
