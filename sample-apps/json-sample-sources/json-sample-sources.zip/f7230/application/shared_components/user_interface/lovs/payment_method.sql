prompt --application/shared_components/user_interface/lovs/payment_method
begin
--   Manifest
--     PAYMENT METHOD
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(128234079508712808063)
,p_lov_name=>'PAYMENT METHOD'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct payment_method  ',
'  from #APEX$SOURCE_DATA#'))
,p_location=>'JSON_COLLECTION'
,p_document_source_id=>wwv_flow_imp.id(296291624904214376496)
,p_source_post_processing=>'SQL'
,p_return_column_name=>'PAYMENT_METHOD'
,p_display_column_name=>'PAYMENT_METHOD'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>56863839
);
wwv_flow_imp.component_end;
end;
/
