prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7230
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.18'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(556715286511925682)
,p_name=>'MANY_ORDERS_UPDATED'
,p_message_text=>'Customer address saved. Shipment address updated for %0 orders.'
,p_version_scn=>54143067
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(556714860257920821)
,p_name=>'NO_ORDER_UPDATED'
,p_message_text=>'Customer address saved. No orders required shipment update.'
,p_version_scn=>54142562
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(556715082100922677)
,p_name=>'ONE_ORDER_UPDATED'
,p_message_text=>'Customer address saved. Shipment address updated for 1 order.'
,p_version_scn=>54142716
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(403946977814979889)
,p_name=>'SEARCH_INDEX_NOT_CREATED'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Search index could not be created in this environment. ',
'You can continue using the application without search functionality.'))
,p_version_scn=>55791380
);
wwv_flow_imp.component_end;
end;
/
