prompt --application/shared_components/user_interface/lovs/products
begin
--   Manifest
--     PRODUCTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(393507103741914471)
,p_lov_name=>'PRODUCTS'
,p_static_id=>'products'
,p_location=>'JSON_COLLECTION'
,p_document_source_id=>wwv_flow_imp.id(296295019465326886274)
,p_return_column_name=>'PRODUCT_ID'
,p_display_column_name=>'PRODUCT_NAME'
,p_default_sort_column_name=>'PRODUCT_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'64441727'
);
wwv_flow_imp.component_end;
end;
/
