prompt --application/shared_components/user_interface/lovs/customers
begin
--   Manifest
--     CUSTOMERS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(393503562070880862)
,p_lov_name=>'CUSTOMERS'
,p_static_id=>'customers'
,p_location=>'JSON_COLLECTION'
,p_document_source_id=>wwv_flow_imp.id(637094877665027065)
,p_return_column_name=>'CUSTOMER_ID'
,p_display_column_name=>'FULL_NAME'
,p_default_sort_column_name=>'FULL_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'64436855'
);
wwv_flow_imp.component_end;
end;
/
