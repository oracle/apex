prompt --application/shared_components/navigation/lists/sql_json_functions
begin
--   Manifest
--     LIST: SQL/JSON Functions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(296296077080306690447)
,p_name=>'SQL/JSON Functions'
,p_static_id=>'sql-json-functions'
,p_version_scn=>'25580513'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296077196898690448)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'JSON_TABLE'
,p_static_id=>'json-table'
,p_list_item_link_target=>'f?p=&APP_ID.:301:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>'Converts JSON data into relational rows and columns for easy querying.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296077595896690448)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'JSON_TRANSFORM'
,p_static_id=>'json-transform'
,p_list_item_link_target=>'f?p=&APP_ID.:302:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-edit'
,p_list_text_01=>'Demonstrates how to update and manipulate JSON documents directly in SQL.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
