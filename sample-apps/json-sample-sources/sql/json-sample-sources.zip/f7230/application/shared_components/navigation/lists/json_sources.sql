prompt --application/shared_components/navigation/lists/json_sources
begin
--   Manifest
--     LIST: JSON Sources
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(296296073529006670657)
,p_name=>'JSON Sources'
,p_static_id=>'json-sources'
,p_version_scn=>'25649343'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296073720400670658)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'JSON Collection Table'
,p_static_id=>'json-collection-table'
,p_list_item_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-brackets'
,p_list_text_01=>'Shows how to use JSON collections to manage JSON data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296074559029670658)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Post Processing'
,p_static_id=>'post-processing'
,p_list_item_link_target=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-recycle'
,p_list_text_01=>'Demonstrates transforming JSON data after retrieval using local processing logic.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296074118528670658)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'Table with JSON Column'
,p_static_id=>'table-with-json-column'
,p_list_item_link_target=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database-file'
,p_list_text_01=>'Demonstrates storing and querying JSON data within relational table columns.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
