prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(296295316446572646368)
,p_name=>'Navigation Menu'
,p_static_id=>'navigation-menu'
,p_version_scn=>'112642746'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296292045221443767860)
,p_list_item_display_sequence=>230
,p_list_item_link_text=>'Administration'
,p_static_id=>'administration'
,p_list_item_link_target=>'f?p=&APP_ID.:600:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-wrench'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'600'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295335229830803867)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Charts from JSON'
,p_static_id=>'charts-from-json'
,p_list_item_link_target=>'f?p=&APP_ID.:402:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296295332539725663716)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295664147127178094)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Data Loading'
,p_static_id=>'data-loading'
,p_list_item_link_target=>'f?p=&APP_ID.:502:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296295332830774666643)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295332539725663716)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Data Presentation'
,p_static_id=>'data-presentation'
,p_list_item_link_target=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bar-chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295331922269658243)
,p_list_item_display_sequence=>65
,p_list_item_link_text=>'Duality View'
,p_static_id=>'duality-view'
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-exchange'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295335553677807967)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Faceted Search'
,p_static_id=>'faceted-search'
,p_list_item_link_target=>'f?p=&APP_ID.:403:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296295332539725663716)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295328145318646390)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_static_id=>'home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295334632050710046)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Interactive Grid'
,p_static_id=>'interactive-grid'
,p_list_item_link_target=>'f?p=&APP_ID.:401:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296295332539725663716)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295336480940821348)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'JSON and Workflow'
,p_static_id=>'json-and-workflow'
,p_list_item_link_target=>'f?p=&APP_ID.:503:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296295332830774666643)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295333413312692587)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'JSON Collection Table'
,p_static_id=>'json-collection-table'
,p_list_item_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296295331620021654651)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295331620021654651)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'JSON Sources'
,p_static_id=>'json-sources'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-json-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295334028673701525)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'JSON_TABLE'
,p_static_id=>'json-table'
,p_list_item_link_target=>'f?p=&APP_ID.:301:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296295332257829660835)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295334343363705344)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'JSON_TRANSFORM'
,p_static_id=>'json-transform'
,p_list_item_link_target=>'f?p=&APP_ID.:302:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296295332257829660835)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295335833820810768)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Map'
,p_static_id=>'map'
,p_list_item_link_target=>'f?p=&APP_ID.:404:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296295332539725663716)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295337968329860689)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>'Master Detail'
,p_static_id=>'master-detail'
,p_list_item_link_target=>'f?p=&APP_ID.:405:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296295332539725663716)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295336130596816779)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Post Processing'
,p_static_id=>'post-processing'
,p_list_item_link_target=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296295331620021654651)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296292055754737811227)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>'Reset Data'
,p_static_id=>'reset-data'
,p_list_item_link_target=>'f?p=&APP_ID.:602:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296292045221443767860)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'602'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(577929261507179160)
,p_list_item_display_sequence=>155
,p_list_item_link_text=>'Search Page'
,p_static_id=>'search-page'
,p_list_item_link_target=>'f?p=&APP_ID.:408:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296295332539725663716)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'408'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295332257829660835)
,p_list_item_display_sequence=>225
,p_list_item_link_text=>'SQL/JSON Functions'
,p_static_id=>'sql-json-functions'
,p_list_item_link_target=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295333770488696030)
,p_list_item_display_sequence=>75
,p_list_item_link_text=>'Table with JSON Column'
,p_static_id=>'table-with-json-column'
,p_list_item_link_target=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296295331620021654651)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1500860725179587)
,p_list_item_display_sequence=>245
,p_list_item_link_text=>'Theme Style Selection'
,p_static_id=>'theme-style-selection'
,p_list_item_link_target=>'f?p=&APP_ID.:601:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(296292045221443767860)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296295332830774666643)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Use Cases'
,p_static_id=>'use-cases'
,p_list_item_link_target=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-missile'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
