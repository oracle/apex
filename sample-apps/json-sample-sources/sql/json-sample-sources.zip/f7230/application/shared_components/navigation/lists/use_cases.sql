prompt --application/shared_components/navigation/lists/use_cases
begin
--   Manifest
--     LIST: Use Cases
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(296296086670210882391)
,p_name=>'Use Cases'
,p_static_id=>'use-cases'
,p_version_scn=>'102324570'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296086863192882392)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'Data Loading'
,p_static_id=>'data-loading'
,p_list_item_link_target=>'f?p=&APP_ID.:502:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-upload'
,p_list_text_01=>'Allows importing and processing external data into JSON formats.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(296296087219769882392)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'JSON and Workflow'
,p_static_id=>'json-and-workflow'
,p_list_item_link_target=>'f?p=&APP_ID.:503:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-workflow'
,p_list_text_01=>'Demonstrates integrating JSON data within business workflows and processes.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
