prompt --application/pages/page_00303
begin
--   Manifest
--     PAGE: 00303
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>303
,p_name=>'Edit Customer''s Address'
,p_alias=>'EDIT-CUSTOMER-S-ADDRESS'
,p_page_mode=>'MODAL'
,p_step_title=>'Edit Customer''s Address'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(12732622639801678)
,p_step_template=>1664614232864994871
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_dialog_chained=>'N'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(578136540010713062)
,p_plug_name=>'Buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2129856781885180476
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(578124887145713058)
,p_plug_name=>'Edit Customer''s Address'
,p_static_id=>'edit-customer-s-address'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>'JSON_COLLECTION'
,p_document_source_id=>wwv_flow_imp.id(637094877665027065)
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(578136869167713062)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(578136540010713062)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(578138725527713063)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(578136540010713062)
,p_button_name=>'SAVE'
,p_static_id=>'save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P303_CUSTOMER_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(578127716141713059)
,p_name=>'P303_ADDRESS_CITY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_item_source_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_prompt=>'City'
,p_source=>'ADDRESS_CITY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(578128504653713059)
,p_name=>'P303_ADDRESS_COUNTRY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_item_source_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_prompt=>'Country'
,p_source=>'ADDRESS_COUNTRY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(578128911427713060)
,p_name=>'P303_ADDRESS_POSTAL_CODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_item_source_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_prompt=>'Postal Code'
,p_source=>'ADDRESS_POSTAL_CODE'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(578129272476713060)
,p_name=>'P303_ADDRESS_STATE_PROVINCE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_item_source_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_prompt=>'State Province'
,p_source=>'ADDRESS_STATE_PROVINCE'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(578128087993713059)
,p_name=>'P303_ADDRESS_STREET'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_item_source_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_prompt=>'Street'
,p_source=>'ADDRESS_STREET'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(578125270910713058)
,p_name=>'P303_CUSTOMER_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_item_source_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_source=>'CUSTOMER_ID'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(578125698748713058)
,p_name=>'P303_FULL_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_item_source_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_prompt=>'Full Name'
,p_source=>'FULL_NAME'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(124782901270696656)
,p_name=>'P303_OLD_ADDRESS'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(578124887145713058)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(578137020678713062)
,p_name=>'Cancel Dialog'
,p_static_id=>'cancel-dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(578136869167713062)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(578137782137713063)
,p_event_id=>wwv_flow_imp.id(578137020678713062)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-dialog-cancel'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(578140364468713064)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_static_id=>'close-dialog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'Y')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(578138725527713063)
,p_internal_uid=>10716598599814414
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(124782985372696657)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get old customer address'
,p_static_id=>'get-old-customer-address'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    select json_query(customer_metadata, ''$.address'')',
'      into :P303_OLD_ADDRESS',
'      from eba_demo_json_customers',
'     where customer_id = :P303_CUSTOMER_ID;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(578138725527713063)
,p_internal_uid=>11886679244269335
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(578139555658713063)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(578124887145713058)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Edit Customer''s Address'
,p_static_id=>'initialize-form-edit-customer-s-address'
,p_internal_uid=>10715789789814413
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(577502112971849072)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'JSON TRANSFORM process for order_metadata'
,p_static_id=>'json-transform-process-for-order-metadata'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_rows_updated number;',
'begin',
'    update eba_demo_json_orders o',
'       set o.order_metadata =',
'           json_transform( -- Updates specific attributes inside the JSON document',
'               o.order_metadata,',
'               set ''$.delivery_address.street''         = :P303_ADDRESS_STREET,',
'               set ''$.delivery_address.city''           = :P303_ADDRESS_CITY,',
'               set ''$.delivery_address.state_province'' = :P303_ADDRESS_STATE_PROVINCE,',
'               set ''$.delivery_address.country''        = :P303_ADDRESS_COUNTRY,',
'               set ''$.delivery_address.postal_code''    = :P303_ADDRESS_POSTAL_CODE',
'           )',
'     where o.customer_id = :P303_CUSTOMER_ID',
'       and o.order_status in (''Open'', ''Paid'')',
'       and json_equal( -- Compares two JSON documents for structural equality',
'             json_query(o.order_metadata, ''$.delivery_address''), -- Extracts the delivery_address object from the JSON document',
'             :P303_OLD_ADDRESS',
'           );',
'',
'    l_rows_updated := SQL%ROWCOUNT;',
'',
'    apex_application.g_print_success_message :=',
'        case',
'            when l_rows_updated = 0 then',
'                apex_lang.message(''NO_ORDER_UPDATED'')',
'            when l_rows_updated = 1 then',
'                apex_lang.message(''ONE_ORDER_UPDATED'')',
'            else',
'                apex_lang.message(''MANY_ORDERS_UPDATED'', l_rows_updated)',
'        end;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(578138725527713063)
,p_internal_uid=>10078347102950422
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(578139875890713063)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(578124887145713058)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Edit Customer''s Address'
,p_static_id=>'process-form-edit-customer-s-address'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'prevent_lost_updates', 'Y',
  'return_primary_keys_after_insert', 'Y',
  'target_type', 'REGION_SOURCE')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(578138725527713063)
,p_process_success_message=>'  '
,p_internal_uid=>10716110021814413
);
wwv_flow_imp.component_end;
end;
/
