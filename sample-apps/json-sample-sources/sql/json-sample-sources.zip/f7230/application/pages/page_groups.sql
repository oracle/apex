prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7230
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(296295321451259646379)
,p_group_name=>'Administration'
,p_static_id=>'administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12730301217410334)
,p_group_name=>'Data Presentation'
,p_static_id=>'data-presentation'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12730181107406482)
,p_group_name=>'Duality View'
,p_static_id=>'duality-view'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12729572774398483)
,p_group_name=>'JSON Sources'
,p_static_id=>'json-sources'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12732622639801678)
,p_group_name=>'SQL/JSON Functions'
,p_static_id=>'sql-json-functions'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12731586493424370)
,p_group_name=>'Use Cases'
,p_static_id=>'use-cases'
);
wwv_flow_imp.component_end;
end;
/
