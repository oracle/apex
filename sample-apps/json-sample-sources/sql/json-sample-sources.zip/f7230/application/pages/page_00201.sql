prompt --application/pages/page_00201
begin
--   Manifest
--     PAGE: 00201
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>201
,p_name=>'Create/Edit Store'
,p_alias=>'CREATE-EDIT-STORE'
,p_page_mode=>'MODAL'
,p_step_title=>'Create/Edit Store'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(12730181107406482)
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(597861007943507853)
,p_plug_name=>'Buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(597864606490534848)
,p_plug_name=>'Edit/Create Store'
,p_static_id=>'edit-create-store'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>'DUALITY_VIEW'
,p_document_source_id=>wwv_flow_imp.id(607855591485602045)
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(597869818045534850)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(597861007943507853)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:200:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(597871248642534851)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(597861007943507853)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P201_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(597870457928534850)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(597861007943507853)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P201_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(75372240223592)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_button_name=>'GEOCODE_ADDRESS'
,p_static_id=>'geocode-address'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Find Location'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-map-marker'
,p_grid_column_css_classes=>'u-textEnd'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(597870865455534851)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(597861007943507853)
,p_button_name=>'SAVE'
,p_static_id=>'save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P201_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(597871595257534851)
,p_branch_action=>'f?p=&APP_ID.:200:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(597866584035534849)
,p_name=>'P201_ADDRESS'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_item_source_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_prompt=>'Address'
,p_source=>'ADDRESS'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>512
,p_cHeight=>4
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(597865392735534848)
,p_name=>'P201_COUNTRY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_item_source_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_source=>'COUNTRY'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(597866175478534849)
,p_name=>'P201_COUNTRY_CODE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_item_source_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_prompt=>'Country'
,p_source=>'COUNTRY_CODE'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'COUNTRIES'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Country -'
,p_cHeight=>1
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_quick_pick_type=>'STATIC'
,p_quick_pick_label_01=>'USA'
,p_quick_pick_value_01=>'US'
,p_quick_pick_label_02=>'Spain'
,p_quick_pick_value_02=>'ES'
,p_quick_pick_label_03=>'Germany'
,p_quick_pick_value_03=>'DE'
,p_quick_pick_label_04=>'India'
,p_quick_pick_value_04=>'IN'
,p_quick_pick_label_05=>'Australia'
,p_quick_pick_value_05=>'AU'
,p_quick_pick_label_06=>'Brazil'
,p_quick_pick_value_06=>'BR'
,p_quick_pick_label_07=>'Mexico'
,p_quick_pick_value_07=>'MX'
,p_quick_pick_label_08=>'China'
,p_quick_pick_value_08=>'CN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(597858630477507829)
,p_name=>'P201_GEOCODED_ADDRESS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_prompt=>'Geocoded Address'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_GEOCODED_ADDRESS'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'address_item', 'P201_ADDRESS',
  'country_item', 'P201_COUNTRY_CODE',
  'country_type', 'ITEM',
  'structured_address', 'N',
  'trigger_geocoding', 'DYNAMIC_ACTION')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(597865063691534848)
,p_name=>'P201_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_item_source_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_source=>'ID'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(597866908942534849)
,p_name=>'P201_LOCATION_LATITUDE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_item_source_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_source=>'LOCATION_LATITUDE'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(597867369057534849)
,p_name=>'P201_LOCATION_LONGITUDE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_item_source_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_source=>'LOCATION_LONGITUDE'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(597865721782534848)
,p_name=>'P201_STORENAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_item_source_plug_id=>wwv_flow_imp.id(597864606490534848)
,p_prompt=>'Store Name'
,p_source=>'STORENAME'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(597861128490507854)
,p_computation_sequence=>10
,p_computation_item=>'P201_COUNTRY'
,p_static_id=>'p201-country'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct country',
'  from eba_demo_json_stores',
' where country_code = :P201_COUNTRY_CODE'))
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(597859133546507834)
,p_validation_name=>'lat_not_null'
,p_static_id=>'lat-not-null'
,p_validation_sequence=>20
,p_validation=>':P201_LOCATION_LATITUDE is not null'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Latitude can''t be null!'
,p_associated_item=>wwv_flow_imp.id(597866908942534849)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(597859095715507833)
,p_validation_name=>'long_not_null'
,p_static_id=>'long-not-null'
,p_validation_sequence=>10
,p_validation=>':P201_LOCATION_LONGITUDE is not null'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Longitude can''t be null!'
,p_associated_item=>wwv_flow_imp.id(597867369057534849)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75485371223593)
,p_name=>'Find Location'
,p_static_id=>'find-location'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(75372240223592)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75572774223594)
,p_event_id=>wwv_flow_imp.id(75485371223593)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-geocoding-trigger'
,p_action=>'NATIVE_GEOCODING_TRIGGER'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P201_GEOCODED_ADDRESS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(597859282576507835)
,p_name=>'set _latitude_value'
,p_static_id=>'set-latitude-value'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P201_GEOCODED_ADDRESS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_GEOCODED_ADDRESS|ITEM TYPE|apexgeocoderselection'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(597859394342507836)
,p_event_id=>wwv_flow_imp.id(597859282576507835)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P201_LOCATION_LATITUDE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_expression', 'this.data ? this.data.latitude : null',
  'suppress_change_event', 'N',
  'type', 'JAVASCRIPT_EXPRESSION')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(597859421016507837)
,p_name=>'set _longitude_value'
,p_static_id=>'set-longitude-value'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P201_GEOCODED_ADDRESS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_GEOCODED_ADDRESS|ITEM TYPE|apexgeocoderselection'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(597859583313507838)
,p_event_id=>wwv_flow_imp.id(597859421016507837)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P201_LOCATION_LONGITUDE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_expression', 'this.data ? this.data.longitude : null',
  'suppress_change_event', 'N',
  'type', 'JAVASCRIPT_EXPRESSION')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(597859698715507839)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_static_id=>'close-dialog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'Y')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE,UPDATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>10030597370461914
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(597861409232507857)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Display Geocodded Address'
,p_static_id=>'display-geocodded-address'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P201_ID is not null',
'   and :P201_LOCATION_LATITUDE is not null',
'   and :P201_LOCATION_LONGITUDE is not null',
'then',
'  :P201_GEOCODED_ADDRESS :=',
'      ''{"type":"Point","coordinates":[''',
'      || apex_json.stringify(to_number( :P201_LOCATION_LONGITUDE))',
'      || '',''',
'      || apex_json.stringify(to_number( :P201_LOCATION_LATITUDE))',
'      || '']}'';',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>10032307887461932
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(597872009011534851)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(597864606490534848)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Edit/Create Store'
,p_static_id=>'initialize-form-edit-create-store'
,p_internal_uid=>10042907666488926
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(597872490180534851)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(597864606490534848)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Edit/Create Store'
,p_static_id=>'process-form-edit-create-store'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'prevent_lost_updates', 'Y',
  'return_primary_keys_after_insert', 'Y',
  'target_type', 'REGION_SOURCE')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10043388835488926
);
wwv_flow_imp.component_end;
end;
/
