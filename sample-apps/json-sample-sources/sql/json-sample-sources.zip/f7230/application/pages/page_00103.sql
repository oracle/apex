prompt --application/pages/page_00103
begin
--   Manifest
--     PAGE: 00103
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>103
,p_name=>'Post Processing'
,p_alias=>'POST-PROCESSING'
,p_step_title=>'Post Processing'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(12729572774398483)
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(296295087503409455122)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(296295315947355646367)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(296291578791496882585)
,p_plug_name=>'Overview'
,p_static_id=>'overview'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'This page demonstrates post-processing of JSON data in Oracle APEX using SQL and derived columns. Based on the <strong>EBA_DEMO_JSON_SUPPORT_TICKET</strong> source, it enriches the dataset by joining related tables and computing additional fields suc'
||'h as <strong>customer name</strong>, <strong>store name</strong>, and a dynamic <strong>status flag</strong> for enhanced data analysis.',
'</p>',
'',
'<p>',
'To get started, explore the report data and review how the original JSON ticket information is enhanced with additional relational and computed values. ',
'You can sort, filter, and analyze the derived columns to better understand how SQL post-processing can extend JSON-based datasets in Oracle APEX.',
'</p>',
'',
'<p>',
'<strong>Note:</strong> To see the SQL post-processing query, open the Page Designer for this page and review the query in the <strong>Local Post Processing</strong> section in the right panel.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(296292461834220899546)
,p_plug_name=>'Post Processing'
,p_static_id=>'post-processing'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_location=>'JSON_COLLECTION'
,p_document_source_id=>wwv_flow_imp.id(296294017053623558661)
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.ticket_id,',
'       t.title,',
'       t.description,',
'       t.status,',
'       t.priority,',
'       t.created_at2       as created_at,',
'       c.full_name         as customer_name,',
'       s.store_name        as store_name,',
'       case ',
'           when t.status   = ''Open'' ',
'            and t.priority = ''High'' ',
'            and t.created_at2 < sysdate - 7 ',
'           then ''Overdue'' ',
'           else t.status ',
'       end                 as status_flag',
'  from #APEX$SOURCE_DATA#  t,',
'       eba_demo_json_customers c,',
'       eba_demo_json_stores    s',
' where t.customer_id        = c.customer_id',
'   and t.concern_store_id   = s.store_id',
' order by case t.priority',
'             when ''High''   then 3',
'             when ''Medium'' then 2',
'             else 1',
'         end desc,',
'         t.created_at2 desc',
'',
''))
,p_source_post_processing=>'SQL'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(296292461885202899547)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_internal_uid=>4859421338008504
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296292463533645899563)
,p_db_column_name=>'CREATED_AT'
,p_display_order=>150
,p_column_identifier=>'F'
,p_column_label=>'Creation Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296292463584429899564)
,p_db_column_name=>'CUSTOMER_NAME'
,p_display_order=>160
,p_column_identifier=>'G'
,p_column_label=>'Customer Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296292463280931899561)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>140
,p_column_identifier=>'E'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296292462708643899555)
,p_db_column_name=>'PRIORITY'
,p_display_order=>80
,p_column_identifier=>'C'
,p_column_label=>'Priority'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296292462259613899550)
,p_db_column_name=>'STATUS'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296292463821569899566)
,p_db_column_name=>'STATUS_FLAG'
,p_display_order=>180
,p_column_identifier=>'I'
,p_column_label=>'Status Flag'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296292463681881899565)
,p_db_column_name=>'STORE_NAME'
,p_display_order=>170
,p_column_identifier=>'H'
,p_column_label=>'Store Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296292462835589899556)
,p_db_column_name=>'TICKET_ID'
,p_display_order=>90
,p_column_identifier=>'D'
,p_column_label=>'Ticket ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(296292462155082899549)
,p_db_column_name=>'TITLE'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Title'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'Y'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(296292479321873910556)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'48769'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TITLE:STATUS:PRIORITY:TICKET_ID:DESCRIPTION:CREATED_AT:CUSTOMER_NAME:STORE_NAME:STATUS_FLAG'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(63058783023472041)
,p_report_id=>wwv_flow_imp.id(296292479321873910556)
,p_static_id=>'ir-condition'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STORE_NAME'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("STORE_NAME" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#e8e8e8'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(63059164257472041)
,p_report_id=>wwv_flow_imp.id(296292479321873910556)
,p_static_id=>'ir-condition-2'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS_FLAG'
,p_operator=>'='
,p_expr=>'Resolved'
,p_condition_sql=>' (case when ("STATUS_FLAG" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''Resolved''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#d0f1cc'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(63059579257472041)
,p_report_id=>wwv_flow_imp.id(296292479321873910556)
,p_static_id=>'ir-condition-3'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS_FLAG'
,p_operator=>'='
,p_expr=>'Pending'
,p_condition_sql=>' (case when ("STATUS_FLAG" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''Pending''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#fff5ce'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(63059969061472042)
,p_report_id=>wwv_flow_imp.id(296292479321873910556)
,p_static_id=>'ir-condition-4'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS_FLAG'
,p_operator=>'='
,p_expr=>'Overdue'
,p_condition_sql=>' (case when ("STATUS_FLAG" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''Overdue''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#ffd6d2'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(63060359649472042)
,p_report_id=>wwv_flow_imp.id(296292479321873910556)
,p_static_id=>'ir-condition-5'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'CUSTOMER_NAME'
,p_operator=>'is not null'
,p_condition_sql=>' (case when ("CUSTOMER_NAME" is not null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#e8e8e8'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(296292464017741899568)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(296295087503409455122)
,p_button_name=>'NEXT'
,p_static_id=>'next'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(296292464242242899570)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(296295087503409455122)
,p_button_name=>'PREVIOUS'
,p_static_id=>'previous'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp.component_end;
end;
/
