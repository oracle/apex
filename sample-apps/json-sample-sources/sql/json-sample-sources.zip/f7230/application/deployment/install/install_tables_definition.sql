prompt --application/deployment/install/install_tables_definition
begin
--   Manifest
--     INSTALL: INSTALL-Tables Definition
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- ==========================================================================='||wwv_flow.LF||
'-- table definitions'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2) := '-- ==========================================================================='||wwv_flow.LF||
'create table eba_demo';
wwv_flow_imp.g_varchar2_table(3) := '_json_customers ('||wwv_flow.LF||
'    customer_id       number default eba_demo_json_customers_seq.nextval not null ';
wwv_flow_imp.g_varchar2_table(4) := 'enable, '||wwv_flow.LF||
'	full_name         varchar2(255)                                      not null enable, '||wwv_flow.LF||
'	em';
wwv_flow_imp.g_varchar2_table(5) := 'ail_address     varchar2(255)                                      not null enable, '||wwv_flow.LF||
'	customer_metad';
wwv_flow_imp.g_varchar2_table(6) := 'ata json, '||wwv_flow.LF||
'	latitude          number, '||wwv_flow.LF||
'	longitude         number, '||wwv_flow.LF||
'	constraint eba_demo_json_custome';
wwv_flow_imp.g_varchar2_table(7) := 'rs_pk'||wwv_flow.LF||
'        primary key (customer_id)'||wwv_flow.LF||
'        using index  enable,'||wwv_flow.LF||
'    constraint eba_demo_json_cu';
wwv_flow_imp.g_varchar2_table(8) := 'stomers_email_u '||wwv_flow.LF||
'        unique (email_address)'||wwv_flow.LF||
'        using index  enable'||wwv_flow.LF||
'   );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table  eb';
wwv_flow_imp.g_varchar2_table(9) := 'a_demo_json_stores ('||wwv_flow.LF||
'    store_id          number default eba_demo_json_stores_seq.nextval not null ';
wwv_flow_imp.g_varchar2_table(10) := 'enable,  '||wwv_flow.LF||
'	store_name        varchar2(255)                                   not null enable,   '||wwv_flow.LF||
'	we';
wwv_flow_imp.g_varchar2_table(11) := 'b_address       varchar2(100),   '||wwv_flow.LF||
'	physical_address  varchar2(512),   '||wwv_flow.LF||
'	latitude          number,   ';
wwv_flow_imp.g_varchar2_table(12) := ''||wwv_flow.LF||
'	longitude         number, '||wwv_flow.LF||
'    country_code      varchar2(2)                                     n';
wwv_flow_imp.g_varchar2_table(13) := 'ot null,'||wwv_flow.LF||
'    country           varchar2(255),'||wwv_flow.LF||
'	logo              blob,   '||wwv_flow.LF||
'	logo_mime_type    varchar';
wwv_flow_imp.g_varchar2_table(14) := '2(512),   '||wwv_flow.LF||
'	logo_filename     varchar2(512),   '||wwv_flow.LF||
'	logo_charset      varchar2(512),   '||wwv_flow.LF||
'	logo_last_upda';
wwv_flow_imp.g_varchar2_table(15) := 'ted date, '||wwv_flow.LF||
'	 constraint eba_demo_json_stores_pk'||wwv_flow.LF||
'        primary key (store_id)  '||wwv_flow.LF||
'        using index';
wwv_flow_imp.g_varchar2_table(16) := '  enable,   '||wwv_flow.LF||
'	 constraint eba_demo_json_store_name_u '||wwv_flow.LF||
'        unique (store_name)  '||wwv_flow.LF||
'        using in';
wwv_flow_imp.g_varchar2_table(17) := 'dex  enable,   '||wwv_flow.LF||
'	 constraint eba_demo_json_required_adr_c '||wwv_flow.LF||
'        check (coalesce ( web_address, ph';
wwv_flow_imp.g_varchar2_table(18) := 'ysical_address ) is not null) enable  '||wwv_flow.LF||
'   );  '||wwv_flow.LF||
' '||wwv_flow.LF||
''||wwv_flow.LF||
' create  table eba_demo_json_orders ('||wwv_flow.LF||
'    order_id';
wwv_flow_imp.g_varchar2_table(19) := '       number default eba_demo_json_orders_seq.nextval not null enable,   '||wwv_flow.LF||
'	order_datetime timestamp';
wwv_flow_imp.g_varchar2_table(20) := ' (6)                                   not null enable,  '||wwv_flow.LF||
'	customer_id    number                    ';
wwv_flow_imp.g_varchar2_table(21) := '                      not null enable,  '||wwv_flow.LF||
'	order_status   varchar2(10)                               ';
wwv_flow_imp.g_varchar2_table(22) := '     not null enable,  '||wwv_flow.LF||
'	store_id       number                                          not null ena';
wwv_flow_imp.g_varchar2_table(23) := 'ble,'||wwv_flow.LF||
'    order_metadata json, '||wwv_flow.LF||
'	 constraint eba_demo_json_orders_pk '||wwv_flow.LF||
'        primary key (order_id) ';
wwv_flow_imp.g_varchar2_table(24) := ' '||wwv_flow.LF||
'        using index  enable,'||wwv_flow.LF||
'	 constraint eba_demo_json_order_status_c '||wwv_flow.LF||
'        check (order_statu';
wwv_flow_imp.g_varchar2_table(25) := 's in (''Cancelled'',''Complete'',''Open'',''Paid'',''Refunded'')) enable'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_json_pr';
wwv_flow_imp.g_varchar2_table(26) := 'oducts ('||wwv_flow.LF||
'    product_id         number default eba_demo_json_products_seq.nextval not null enable,  ';
wwv_flow_imp.g_varchar2_table(27) := ''||wwv_flow.LF||
'	product_name       varchar2(255)                                     not null enable, '||wwv_flow.LF||
'	unit_price';
wwv_flow_imp.g_varchar2_table(28) := '         number(10,2), '||wwv_flow.LF||
'	product_details    json, '||wwv_flow.LF||
'	product_image      blob, '||wwv_flow.LF||
'	image_mime_type    va';
wwv_flow_imp.g_varchar2_table(29) := 'rchar2(512), '||wwv_flow.LF||
'	image_filename     varchar2(512), '||wwv_flow.LF||
'	image_charset      varchar2(512), '||wwv_flow.LF||
'	image_last_up';
wwv_flow_imp.g_varchar2_table(30) := 'dated date,'||wwv_flow.LF||
'	 constraint eba_demo_json_products_pk '||wwv_flow.LF||
'        primary key (product_id)'||wwv_flow.LF||
'        using i';
wwv_flow_imp.g_varchar2_table(31) := 'ndex  enable, '||wwv_flow.LF||
'	 constraint eba_demo_json_product_json_c '||wwv_flow.LF||
'        check (product_details is json) en';
wwv_flow_imp.g_varchar2_table(32) := 'able'||wwv_flow.LF||
'   );'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_json_order_items (	'||wwv_flow.LF||
'    order_id     number         not null enabl';
wwv_flow_imp.g_varchar2_table(33) := 'e,   '||wwv_flow.LF||
'	line_item_id number         not null enable,   '||wwv_flow.LF||
'	product_id   number         not null enable,';
wwv_flow_imp.g_varchar2_table(34) := '   '||wwv_flow.LF||
'	unit_price   number(10,2)   not null enable,   '||wwv_flow.LF||
'	quantity     number         not null enable,  ';
wwv_flow_imp.g_varchar2_table(35) := '  '||wwv_flow.LF||
'	 constraint eba_demo_json_order_items_pk '||wwv_flow.LF||
'        primary key (order_id, line_item_id)'||wwv_flow.LF||
'        u';
wwv_flow_imp.g_varchar2_table(36) := 'sing index  enable,   '||wwv_flow.LF||
'	 constraint eba_demo_json_ord_item_prd_u'||wwv_flow.LF||
'        unique (product_id, order_i';
wwv_flow_imp.g_varchar2_table(37) := 'd)'||wwv_flow.LF||
'        using index  enable  '||wwv_flow.LF||
'   );'||wwv_flow.LF||
''||wwv_flow.LF||
'-- JSON Collection'||wwv_flow.LF||
''||wwv_flow.LF||
'create json collection table eba_demo_js';
wwv_flow_imp.g_varchar2_table(38) := 'on_support_ticket;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Add foreign key constraints'||wwv_flow.LF||
'alter table  eba_demo_json_orders '||wwv_flow.LF||
'    add constr';
wwv_flow_imp.g_varchar2_table(39) := 'aint eba_demo_json_order_customer_id_fk'||wwv_flow.LF||
'        foreign key (customer_id)  '||wwv_flow.LF||
'	    references  eba_dem';
wwv_flow_imp.g_varchar2_table(40) := 'o_json_customers (customer_id) '||wwv_flow.LF||
'        on delete cascade enable;  '||wwv_flow.LF||
''||wwv_flow.LF||
'alter table  eba_demo_json_orde';
wwv_flow_imp.g_varchar2_table(41) := 'rs '||wwv_flow.LF||
'    add constraint eba_demo_json_order_store_id_fk '||wwv_flow.LF||
'        foreign key (store_id)  '||wwv_flow.LF||
'	    refere';
wwv_flow_imp.g_varchar2_table(42) := 'nces  eba_demo_json_stores (store_id)'||wwv_flow.LF||
'        on delete cascade enable;  '||wwv_flow.LF||
''||wwv_flow.LF||
'alter table  eba_demo_jso';
wwv_flow_imp.g_varchar2_table(43) := 'n_order_items '||wwv_flow.LF||
'    add constraint eba_demo_json_item_order_id_fk'||wwv_flow.LF||
'        foreign key (order_id)  '||wwv_flow.LF||
'	 ';
wwv_flow_imp.g_varchar2_table(44) := '   references  eba_demo_json_orders (order_id)'||wwv_flow.LF||
'        on delete cascade enable;'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table  eba_d';
wwv_flow_imp.g_varchar2_table(45) := 'emo_json_order_items '||wwv_flow.LF||
'    add constraint eba_demo_json_item_product_id_fk '||wwv_flow.LF||
'        foreign key (prod';
wwv_flow_imp.g_varchar2_table(46) := 'uct_id)  '||wwv_flow.LF||
'	    references  eba_demo_json_products (product_id)'||wwv_flow.LF||
'        on delete cascade enable;  '||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(47) := ''||wwv_flow.LF||
'-- Create indexes'||wwv_flow.LF||
'create index eba_demo_json_customer_name_i '||wwv_flow.LF||
'    on  eba_demo_json_customers (full';
wwv_flow_imp.g_varchar2_table(48) := '_name);'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_json_order_customer_id_i '||wwv_flow.LF||
'    on  eba_demo_json_orders (customer_id);';
wwv_flow_imp.g_varchar2_table(49) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'create index  eba_demo_json_order_store_id_i '||wwv_flow.LF||
'    on  eba_demo_json_orders (store_id);  '||wwv_flow.LF||
''||wwv_flow.LF||
'-- Creat';
wwv_flow_imp.g_varchar2_table(50) := 'e Duality Views'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace force editionable json relational duality view eba_demo_json_stor';
wwv_flow_imp.g_varchar2_table(51) := 'es_dv as '||wwv_flow.LF||
'  select json {'||wwv_flow.LF||
'           ''_id''          : s.store_id,'||wwv_flow.LF||
'           ''storeName''    : s.stor';
wwv_flow_imp.g_varchar2_table(52) := 'e_name,'||wwv_flow.LF||
'           ''address''      : s.physical_address,'||wwv_flow.LF||
'           ''location''     : {'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(53) := '''latitude''  : s.latitude,'||wwv_flow.LF||
'              ''longitude'' : s.longitude'||wwv_flow.LF||
'           },'||wwv_flow.LF||
'           ''country_';
wwv_flow_imp.g_varchar2_table(54) := 'code'' : s.country_code,'||wwv_flow.LF||
'           ''country''      : s.country'||wwv_flow.LF||
'         }'||wwv_flow.LF||
'    from eba_demo_json_stor';
wwv_flow_imp.g_varchar2_table(55) := 'es s '||wwv_flow.LF||
' with insert update delete nocheck;'||wwv_flow.LF||
''||wwv_flow.LF||
'  create or replace force editionable json relational dua';
wwv_flow_imp.g_varchar2_table(56) := 'lity view eba_demo_json_customer_orders_dv as '||wwv_flow.LF||
'  select json {'||wwv_flow.LF||
'           ''_id''                     ';
wwv_flow_imp.g_varchar2_table(57) := '   : c.customer_id,'||wwv_flow.LF||
'           ''full_name''                  : c.full_name,'||wwv_flow.LF||
'           ''email_address';
wwv_flow_imp.g_varchar2_table(58) := '''              : c.email_address,'||wwv_flow.LF||
'           ''orders'' : ['||wwv_flow.LF||
'             select json {'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(59) := '        ''order_id''       : o.order_id,'||wwv_flow.LF||
'                       ''order_datetime'' : o.order_datetime,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(60) := '                      ''order_status''   : o.order_status,'||wwv_flow.LF||
'                       ''store_id''       : o';
wwv_flow_imp.g_varchar2_table(61) := '.store_id'||wwv_flow.LF||
'                     }'||wwv_flow.LF||
'               from eba_demo_json_orders o'||wwv_flow.LF||
'              with inser';
wwv_flow_imp.g_varchar2_table(62) := 't update delete'||wwv_flow.LF||
'              where o.customer_id = c.customer_id'||wwv_flow.LF||
'           ]'||wwv_flow.LF||
'         }'||wwv_flow.LF||
'    from e';
wwv_flow_imp.g_varchar2_table(63) := 'ba_demo_json_customers c'||wwv_flow.LF||
' with insert update delete nocheck;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- ==================================';
wwv_flow_imp.g_varchar2_table(64) := '========================================='||wwv_flow.LF||
'--  triggers'||wwv_flow.LF||
'-- ==========================================';
wwv_flow_imp.g_varchar2_table(65) := '================================='||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_demo_json_customers_bir'||wwv_flow.LF||
'before inse';
wwv_flow_imp.g_varchar2_table(66) := 'rt on eba_demo_json_customers'||wwv_flow.LF||
'for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.customer_id is null then'||wwv_flow.LF||
'        :new.c';
wwv_flow_imp.g_varchar2_table(67) := 'ustomer_id := eba_demo_json_customers_seq.nextval;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba';
wwv_flow_imp.g_varchar2_table(68) := '_demo_json_orders_bir'||wwv_flow.LF||
'before insert on eba_demo_json_orders'||wwv_flow.LF||
'for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.order_id ';
wwv_flow_imp.g_varchar2_table(69) := 'is null then'||wwv_flow.LF||
'        :new.order_id := eba_demo_json_orders_seq.nextval;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or';
wwv_flow_imp.g_varchar2_table(70) := ' replace trigger eba_demo_json_stores_bir'||wwv_flow.LF||
'before insert on eba_demo_json_stores'||wwv_flow.LF||
'for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(71) := '   if :new.store_id is null then'||wwv_flow.LF||
'        :new.store_id := eba_demo_json_stores_seq.nextval;'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(72) := 'if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger eba_demo_json_products_bir'||wwv_flow.LF||
'before insert on eba_demo_json_produ';
wwv_flow_imp.g_varchar2_table(73) := 'cts'||wwv_flow.LF||
'for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.product_id is null then'||wwv_flow.LF||
'        :new.product_id := eba_demo_json_';
wwv_flow_imp.g_varchar2_table(74) := 'products_seq.nextval;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(296292070496967066705)
,p_install_id=>wwv_flow_imp.id(296295828950238257576)
,p_name=>'Tables Definition'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
