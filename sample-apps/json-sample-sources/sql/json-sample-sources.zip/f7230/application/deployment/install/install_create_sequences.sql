prompt --application/deployment/install/install_create_sequences
begin
--   Manifest
--     INSTALL: INSTALL-create sequences
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- ==========================================================================='||wwv_flow.LF||
'--  Sequence Definiti';
wwv_flow_imp.g_varchar2_table(2) := 'ons'||wwv_flow.LF||
'-- ==========================================================================='||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    execute';
wwv_flow_imp.g_varchar2_table(3) := ' immediate '''||wwv_flow.LF||
'        create sequence eba_demo_json_customers_seq'||wwv_flow.LF||
'            minvalue 1'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(4) := 'maxvalue 9999999999999999999999999999'||wwv_flow.LF||
'            increment by 1 '||wwv_flow.LF||
'            start with 21 '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(5) := '     cache 20'||wwv_flow.LF||
'            noorder'||wwv_flow.LF||
'            nocycle'||wwv_flow.LF||
'            nokeep'||wwv_flow.LF||
'            noscale'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(6) := '     global'||wwv_flow.LF||
'    '';'||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        if sqlcode = -955 then'||wwv_flow.LF||
'            null; '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '        else'||wwv_flow.LF||
'            raise;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    execute immediate '''||wwv_flow.LF||
'        create';
wwv_flow_imp.g_varchar2_table(8) := ' sequence eba_demo_json_products_seq'||wwv_flow.LF||
'            minvalue 1'||wwv_flow.LF||
'            maxvalue 9999999999999999999';
wwv_flow_imp.g_varchar2_table(9) := '999999999'||wwv_flow.LF||
'            increment by 1 '||wwv_flow.LF||
'            start with 47 '||wwv_flow.LF||
'            cache 20'||wwv_flow.LF||
'            no';
wwv_flow_imp.g_varchar2_table(10) := 'order'||wwv_flow.LF||
'            nocycle'||wwv_flow.LF||
'            nokeep'||wwv_flow.LF||
'            noscale'||wwv_flow.LF||
'            global'||wwv_flow.LF||
'    '';'||wwv_flow.LF||
'exception';
wwv_flow_imp.g_varchar2_table(11) := ''||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        if sqlcode = -955 then'||wwv_flow.LF||
'            null; '||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            rai';
wwv_flow_imp.g_varchar2_table(12) := 'se;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    execute immediate '''||wwv_flow.LF||
'        create sequence eba_demo_json_orde';
wwv_flow_imp.g_varchar2_table(13) := 'rs_seq '||wwv_flow.LF||
'            minvalue 1'||wwv_flow.LF||
'            maxvalue 9999999999999999999999999999'||wwv_flow.LF||
'            increme';
wwv_flow_imp.g_varchar2_table(14) := 'nt by 1 '||wwv_flow.LF||
'            start with 1891 '||wwv_flow.LF||
'            cache 20'||wwv_flow.LF||
'            noorder'||wwv_flow.LF||
'            nocycle'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(15) := '           nokeep'||wwv_flow.LF||
'            noscale'||wwv_flow.LF||
'            global'||wwv_flow.LF||
'    '';'||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(16) := '   if sqlcode = -955 then'||wwv_flow.LF||
'            null; '||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            raise;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(17) := ''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    execute immediate '''||wwv_flow.LF||
'        create sequence eba_demo_json_stores_seq '||wwv_flow.LF||
'            minvalu';
wwv_flow_imp.g_varchar2_table(18) := 'e 1'||wwv_flow.LF||
'            maxvalue 9999999999999999999999999999'||wwv_flow.LF||
'            increment by 1 '||wwv_flow.LF||
'            start ';
wwv_flow_imp.g_varchar2_table(19) := 'with 24 '||wwv_flow.LF||
'            cache 20'||wwv_flow.LF||
'            noorder'||wwv_flow.LF||
'            nocycle'||wwv_flow.LF||
'            nokeep'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(20) := ' noscale'||wwv_flow.LF||
'            global'||wwv_flow.LF||
'    '';'||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        if sqlcode = -955 then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(21) := '         null; '||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            raise;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(296295620141247110267)
,p_install_id=>wwv_flow_imp.id(296295828950238257576)
,p_name=>'create sequences'
,p_sequence=>5
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
