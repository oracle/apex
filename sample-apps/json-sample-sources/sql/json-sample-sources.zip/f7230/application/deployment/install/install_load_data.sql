prompt --application/deployment/install/install_load_data
begin
--   Manifest
--     INSTALL: INSTALL- Load Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '----------------------------------------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '---'||wwv_flow.LF||
'-- Load Data'||wwv_flow.LF||
'-----------------------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(3) := '--------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package eba_demo_json_data_pkg authid current_user is'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(4) := ' clears all the data in the database tables'||wwv_flow.LF||
'    procedure clear_data;'||wwv_flow.LF||
'    -- loads data into the dat';
wwv_flow_imp.g_varchar2_table(5) := 'abase tables'||wwv_flow.LF||
'    procedure load_data;'||wwv_flow.LF||
'    -- loads images into the eba_demo_json_products table'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(6) := 'procedure load_product_images(p_app_id in number, p_file_name in varchar2);'||wwv_flow.LF||
'    -- reset all the dat';
wwv_flow_imp.g_varchar2_table(7) := 'a in the database tables'||wwv_flow.LF||
'    procedure reset_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_demo_json_data_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace';
wwv_flow_imp.g_varchar2_table(8) := ' package body eba_demo_json_data_pkg is'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure clear_data is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        delete from e';
wwv_flow_imp.g_varchar2_table(9) := 'ba_demo_json_stores;'||wwv_flow.LF||
'        delete from eba_demo_json_products;'||wwv_flow.LF||
'        delete from eba_demo_json_c';
wwv_flow_imp.g_varchar2_table(10) := 'ustomers;'||wwv_flow.LF||
'        delete from eba_demo_json_orders;'||wwv_flow.LF||
'        delete from eba_demo_json_order_items;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(11) := '       delete from eba_demo_json_support_ticket;'||wwv_flow.LF||
'    end clear_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure load_data is'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(12) := ' begin'||wwv_flow.LF||
'        -- Customers data'||wwv_flow.LF||
'        insert into eba_demo_json_customers (customer_id, full_name';
wwv_flow_imp.g_varchar2_table(13) := ', email_address, latitude,  longitude, customer_metadata) values (1,''Tammy Bryant'',''tammy.bryant@exa';
wwv_flow_imp.g_varchar2_table(14) := 'mple.com'',34.0522,-118.2437,json (''{"birth_year":1992,"gender":"Female","loyalty_tier":"Silver","pre';
wwv_flow_imp.g_varchar2_table(15) := 'ferred_lang":"French","subscribed":"false","signup_channel":"Mobile","address":{"street":"101 Oak Av';
wwv_flow_imp.g_varchar2_table(16) := 'e","city":"Los Angeles","state_province":"California","postal_code":"90001","country":"USA"}}''));'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(17) := '      insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitu';
wwv_flow_imp.g_varchar2_table(18) := 'de, customer_metadata) values (2,''Roy White'',''roy.white@example.com'',41.8781,-87.6298,json (''{"birth';
wwv_flow_imp.g_varchar2_table(19) := '_year":1988,"gender":"Male","loyalty_tier":"Gold","preferred_lang":"Spanish","subscribed":"false","s';
wwv_flow_imp.g_varchar2_table(20) := 'ignup_channel":"Store","address":{"street":"202 Maple Rd","city":"Chicago","state_province":"Illinoi';
wwv_flow_imp.g_varchar2_table(21) := 's","postal_code":"60601","country":"USA"}}''));'||wwv_flow.LF||
'        insert into eba_demo_json_customers (customer';
wwv_flow_imp.g_varchar2_table(22) := '_id, full_name, email_address, latitude,  longitude, customer_metadata) values (3,''Gary Jenkins'',''ga';
wwv_flow_imp.g_varchar2_table(23) := 'ry.jenkins@example.com'',29.7604,-95.3698,json (''{"birth_year":1979,"gender":"Male","loyalty_tier":"P';
wwv_flow_imp.g_varchar2_table(24) := 'latinum","preferred_lang":"English","subscribed":"true","signup_channel":"Referral","address":{"stre';
wwv_flow_imp.g_varchar2_table(25) := 'et":"303 Cedar Blvd","city":"Houston","state_province":"Texas","postal_code":"77001","country":"USA"';
wwv_flow_imp.g_varchar2_table(26) := '}}''));'||wwv_flow.LF||
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,';
wwv_flow_imp.g_varchar2_table(27) := '  longitude, customer_metadata) values (4,''Victor Morris'',''victor.morris@example.com'',33.4484,-112.0';
wwv_flow_imp.g_varchar2_table(28) := '740,json (''{"birth_year":1995,"gender":"Male","loyalty_tier":"Bronze","preferred_lang":"French","sub';
wwv_flow_imp.g_varchar2_table(29) := 'scribed":"false","signup_channel":"Web","address":{"street":"404 Pine Dr","city":"Phoenix","state_pr';
wwv_flow_imp.g_varchar2_table(30) := 'ovince":"Arizona","postal_code":"85001","country":"USA"}}''));'||wwv_flow.LF||
'        insert into eba_demo_json_cust';
wwv_flow_imp.g_varchar2_table(31) := 'omers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (5,''Be';
wwv_flow_imp.g_varchar2_table(32) := 'verly Hughes'',''beverly.hughes@example.com'',39.9526,-75.1652,json (''{"birth_year":1985,"gender":"Fema';
wwv_flow_imp.g_varchar2_table(33) := 'le","loyalty_tier":"Silver","preferred_lang":"Spanish","subscribed":"false","signup_channel":"Mobile';
wwv_flow_imp.g_varchar2_table(34) := '","address":{"street":"505 Main St","city":"Philadelphia","state_province":"Pennsylvania","postal_co';
wwv_flow_imp.g_varchar2_table(35) := 'de":"19103","country":"USA"}}''));'||wwv_flow.LF||
'        insert into eba_demo_json_customers (customer_id, full_nam';
wwv_flow_imp.g_varchar2_table(36) := 'e, email_address, latitude,  longitude, customer_metadata) values (6,''Evelyn Torres'',''evelyn.torres@';
wwv_flow_imp.g_varchar2_table(37) := 'example.com'',29.4241,-98.4936,json (''{"birth_year":1990,"gender":"Female","loyalty_tier":"Gold","pre';
wwv_flow_imp.g_varchar2_table(38) := 'ferred_lang":"English","subscribed":"true","signup_channel":"Store","address":{"street":"606 Oak Ave';
wwv_flow_imp.g_varchar2_table(39) := '","city":"San Antonio","state_province":"Texas","postal_code":"78205","country":"USA"}}''));'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(40) := 'insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, cu';
wwv_flow_imp.g_varchar2_table(41) := 'stomer_metadata) values (7,''Carl Lee'',''carl.lee@example.com'',32.7157,-117.1611,json (''{"birth_year":';
wwv_flow_imp.g_varchar2_table(42) := '1982,"gender":"Male","loyalty_tier":"Bronze","preferred_lang":"French","subscribed":"false","signup_';
wwv_flow_imp.g_varchar2_table(43) := 'channel":"Referral","address":{"street":"707 Maple Rd","city":"San Diego","state_province":"Californ';
wwv_flow_imp.g_varchar2_table(44) := 'ia","postal_code":"92101","country":"USA"}}''));'||wwv_flow.LF||
'        insert into eba_demo_json_customers (custome';
wwv_flow_imp.g_varchar2_table(45) := 'r_id, full_name, email_address, latitude,  longitude, customer_metadata) values (8,''Douglas Flores'',';
wwv_flow_imp.g_varchar2_table(46) := '''douglas.flores@example.com'',32.7767,-96.7970,json (''{"birth_year":1975,"gender":"Male","loyalty_tie';
wwv_flow_imp.g_varchar2_table(47) := 'r":"Silver","preferred_lang":"Spanish","subscribed":"false","signup_channel":"Web","address":{"stree';
wwv_flow_imp.g_varchar2_table(48) := 't":"808 Cedar Blvd","city":"Dallas","state_province":"Texas","postal_code":"75201","country":"USA"}}';
wwv_flow_imp.g_varchar2_table(49) := '''));'||wwv_flow.LF||
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  ';
wwv_flow_imp.g_varchar2_table(50) := 'longitude, customer_metadata) values (9,''Norma Robinson'',''norma.robinson@example.com'',37.7749,-122.4';
wwv_flow_imp.g_varchar2_table(51) := '194,json (''{"birth_year":1987,"gender":"Female","loyalty_tier":"Gold","preferred_lang":"English","su';
wwv_flow_imp.g_varchar2_table(52) := 'bscribed":"true","signup_channel":"Mobile","address":{"street":"909 Pine Dr","city":"San Francisco",';
wwv_flow_imp.g_varchar2_table(53) := '"state_province":"California","postal_code":"94103","country":"USA"}}''));'||wwv_flow.LF||
'        insert into eba_de';
wwv_flow_imp.g_varchar2_table(54) := 'mo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) v';
wwv_flow_imp.g_varchar2_table(55) := 'alues (10,''Gregory Sanchez'',''gregory.sanchez@example.com'',47.6062,-122.3321,json (''{"birth_year":198';
wwv_flow_imp.g_varchar2_table(56) := '0,"gender":"Male","loyalty_tier":"Platinum","preferred_lang":"French","subscribed":"false","signup_c';
wwv_flow_imp.g_varchar2_table(57) := 'hannel":"Store","address":{"street":"1010 Main St","city":"Seattle","state_province":"Washington","p';
wwv_flow_imp.g_varchar2_table(58) := 'ostal_code":"98101","country":"USA"}}''));'||wwv_flow.LF||
'        insert into eba_demo_json_customers (customer_id, ';
wwv_flow_imp.g_varchar2_table(59) := 'full_name, email_address, latitude,  longitude, customer_metadata) values (11,''Judy Evans'',''judy.eva';
wwv_flow_imp.g_varchar2_table(60) := 'ns@example.com'',39.7392,-104.9903,json (''{"birth_year":1993,"gender":"Female","loyalty_tier":"Bronze';
wwv_flow_imp.g_varchar2_table(61) := '","preferred_lang":"Spanish","subscribed":"false","signup_channel":"Referral","address":{"street":"1';
wwv_flow_imp.g_varchar2_table(62) := '111 Oak Ave","city":"Denver","state_province":"Colorado","postal_code":"80202","country":"USA"}}''));';
wwv_flow_imp.g_varchar2_table(63) := ''||wwv_flow.LF||
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latitude,  long';
wwv_flow_imp.g_varchar2_table(64) := 'itude, customer_metadata) values (12,''Jean Patterson'',''jean.patterson@example.com'',42.3601,-71.0589,';
wwv_flow_imp.g_varchar2_table(65) := 'json (''{"birth_year":1986,"gender":"Female","loyalty_tier":"Silver","preferred_lang":"English","subs';
wwv_flow_imp.g_varchar2_table(66) := 'cribed":"true","signup_channel":"Web","address":{"street":"1212 Maple Rd","city":"Boston","state_pro';
wwv_flow_imp.g_varchar2_table(67) := 'vince":"Massachusetts","postal_code":"02108","country":"USA"}}''));'||wwv_flow.LF||
'        insert into eba_demo_json';
wwv_flow_imp.g_varchar2_table(68) := '_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) values (';
wwv_flow_imp.g_varchar2_table(69) := '13,''Michelle Ramirez'',''michelle.ramirez@example.com'',25.7617,-80.1918,json (''{"birth_year":1991,"gen';
wwv_flow_imp.g_varchar2_table(70) := 'der":"Female","loyalty_tier":"Gold","preferred_lang":"French","subscribed":"false","signup_channel":';
wwv_flow_imp.g_varchar2_table(71) := '"Mobile","address":{"street":"1313 Cedar Blvd","city":"Miami","state_province":"Florida","postal_cod';
wwv_flow_imp.g_varchar2_table(72) := 'e":"33101","country":"USA"}}''));'||wwv_flow.LF||
'        insert into eba_demo_json_customers (customer_id, full_name';
wwv_flow_imp.g_varchar2_table(73) := ', email_address, latitude,  longitude, customer_metadata) values (14,''Elizabeth Martinez'',''elizabeth';
wwv_flow_imp.g_varchar2_table(74) := '.martinez@example.com'',43.6532,-79.3832,json (''{"birth_year":1984,"gender":"Female","loyalty_tier":"';
wwv_flow_imp.g_varchar2_table(75) := 'Platinum","preferred_lang":"Spanish","subscribed":"false","signup_channel":"Store","address":{"stree';
wwv_flow_imp.g_varchar2_table(76) := 't":"1414 Pine Dr","city":"Toronto","state_province":"Ontario","postal_code":"M5H 2N2","country":"Can';
wwv_flow_imp.g_varchar2_table(77) := 'ada"}}''));'||wwv_flow.LF||
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, latit';
wwv_flow_imp.g_varchar2_table(78) := 'ude,  longitude, customer_metadata) values (15,''Walter Rogers'',''walter.rogers@example.com'',45.5017,-';
wwv_flow_imp.g_varchar2_table(79) := '73.5673,json (''{"birth_year":1978,"gender":"Male","loyalty_tier":"Bronze","preferred_lang":"English"';
wwv_flow_imp.g_varchar2_table(80) := ',"subscribed":"true","signup_channel":"Web","address":{"street":"1515 Main St","city":"Montreal","st';
wwv_flow_imp.g_varchar2_table(81) := 'ate_province":"Quebec","postal_code":"H2Y 1C6","country":"Canada"}}''));'||wwv_flow.LF||
'        insert into eba_demo';
wwv_flow_imp.g_varchar2_table(82) := '_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata) val';
wwv_flow_imp.g_varchar2_table(83) := 'ues (16,''Ralph Foster'',''ralph.foster@example.com'',49.2827,-123.1207,json (''{"birth_year":1983,"gende';
wwv_flow_imp.g_varchar2_table(84) := 'r":"Male","loyalty_tier":"Silver","preferred_lang":"French","subscribed":"false","signup_channel":"R';
wwv_flow_imp.g_varchar2_table(85) := 'eferral","address":{"street":"1616 Oak Ave","city":"Vancouver","state_province":"British Columbia","';
wwv_flow_imp.g_varchar2_table(86) := 'postal_code":"V5K 0A1","country":"Canada"}}''));'||wwv_flow.LF||
'        insert into eba_demo_json_customers (custome';
wwv_flow_imp.g_varchar2_table(87) := 'r_id, full_name, email_address, latitude,  longitude, customer_metadata) values (17,''Tina Simmons'',''';
wwv_flow_imp.g_varchar2_table(88) := 'tina.simmons@example.com'',51.0447,-114.0719,json (''{"birth_year":1994,"gender":"Female","loyalty_tie';
wwv_flow_imp.g_varchar2_table(89) := 'r":"Gold","preferred_lang":"Spanish","subscribed":"false","signup_channel":"Mobile","address":{"stre';
wwv_flow_imp.g_varchar2_table(90) := 'et":"1717 Maple Rd","city":"Calgary","state_province":"Alberta","postal_code":"T2P 1J9","country":"C';
wwv_flow_imp.g_varchar2_table(91) := 'anada"}}''));'||wwv_flow.LF||
'        insert into eba_demo_json_customers (customer_id, full_name, email_address, lat';
wwv_flow_imp.g_varchar2_table(92) := 'itude,  longitude, customer_metadata) values (18,''Peter Jones'',''peter.jones@example.com'',45.4215,-75';
wwv_flow_imp.g_varchar2_table(93) := '.6972,json (''{"birth_year":1981,"gender":"Male","loyalty_tier":"Platinum","preferred_lang":"English"';
wwv_flow_imp.g_varchar2_table(94) := ',"subscribed":"true","signup_channel":"Store","address":{"street":"1818 Cedar Blvd","city":"Ottawa",';
wwv_flow_imp.g_varchar2_table(95) := '"state_province":"Ontario","postal_code":"K1A 0B1","country":"Canada"}}''));'||wwv_flow.LF||
'        insert into eba_';
wwv_flow_imp.g_varchar2_table(96) := 'demo_json_customers (customer_id, full_name, email_address, latitude,  longitude, customer_metadata)';
wwv_flow_imp.g_varchar2_table(97) := ' values (19,''Kathryn Rogers'',''kathryn.rogers@example.com'',53.5461,-113.4938,json (''{"birth_year":198';
wwv_flow_imp.g_varchar2_table(98) := '9,"gender":"Female","loyalty_tier":"Silver","preferred_lang":"French","subscribed":"false","signup_c';
wwv_flow_imp.g_varchar2_table(99) := 'hannel":"Referral","address":{"street":"1919 Pine Dr","city":"Edmonton","state_province":"Alberta","';
wwv_flow_imp.g_varchar2_table(100) := 'postal_code":"T5J 0N3","country":"Canada"}}''));'||wwv_flow.LF||
'        insert into eba_demo_json_customers (custome';
wwv_flow_imp.g_varchar2_table(101) := 'r_id, full_name, email_address, latitude,  longitude, customer_metadata) values (20,''Dennis Lopez'',''';
wwv_flow_imp.g_varchar2_table(102) := 'dennis.lopez@example.com'',40.7128,-74.0060,json (''{"birth_year":1977,"gender":"Male","loyalty_tier":';
wwv_flow_imp.g_varchar2_table(103) := '"Bronze","preferred_lang":"Spanish","subscribed":"true","signup_channel":"Web","address":{"street":"';
wwv_flow_imp.g_varchar2_table(104) := '2020 Main St","city":"New York","state_province":"New York","postal_code":"10001","country":"USA"}}''';
wwv_flow_imp.g_varchar2_table(105) := '));'||wwv_flow.LF||
'       -- Stores data'||wwv_flow.LF||
'        insert into eba_demo_json_stores (store_id, store_name, web_addres';
wwv_flow_imp.g_varchar2_table(106) := 's, physical_address, latitude, longitude, country_code, country) values (1, ''Online'', ''https://www.e';
wwv_flow_imp.g_varchar2_table(107) := 'xample.com'', ''Oracle Parkway, Redwood Shores'', 39.5, -112.3, ''US'',''USA'');'||wwv_flow.LF||
'        insert into eba_de';
wwv_flow_imp.g_varchar2_table(108) := 'mo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_co';
wwv_flow_imp.g_varchar2_table(109) := 'de, country) values (2, ''San Francisco'', null, ''Oracle Parkway, Redwood Shores'', 37.529395, -122.267';
wwv_flow_imp.g_varchar2_table(110) := '237, ''US'',''USA'');'||wwv_flow.LF||
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physi';
wwv_flow_imp.g_varchar2_table(111) := 'cal_address, latitude, longitude, country_code, country) values (3, ''Seattle'', null, ''1501 Fourth Av';
wwv_flow_imp.g_varchar2_table(112) := 'enue Suite 1800 Seattle, WA 98101'', 47.6053, -122.33221, ''US'',''USA'');'||wwv_flow.LF||
'        insert into eba_demo_j';
wwv_flow_imp.g_varchar2_table(113) := 'son_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, ';
wwv_flow_imp.g_varchar2_table(114) := 'country) values (4, ''New York City'', null, ''205 Lexington Ave 7th Floor New York, NY 10016'', 40.7452';
wwv_flow_imp.g_varchar2_table(115) := '16, -73.980518, ''US'',''USA'');'||wwv_flow.LF||
'        insert into eba_demo_json_stores (store_id, store_name, web_add';
wwv_flow_imp.g_varchar2_table(116) := 'ress, physical_address, latitude, longitude, country_code, country) values (5, ''Chicago'', null, ''233';
wwv_flow_imp.g_varchar2_table(117) := ' South Wacker Dr. 45th Floor Chicago, IL 60606'', 41.878751, -87.636675, ''US'',''USA'');'||wwv_flow.LF||
'        insert ';
wwv_flow_imp.g_varchar2_table(118) := 'into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude,';
wwv_flow_imp.g_varchar2_table(119) := ' country_code, country) values (6, ''London'', null, ''One South Place London EC2M 2RB'', 51.519281, -0.';
wwv_flow_imp.g_varchar2_table(120) := '087296, ''GB'',''United kingdom'');'||wwv_flow.LF||
'        insert into eba_demo_json_stores (store_id, store_name, web_';
wwv_flow_imp.g_varchar2_table(121) := 'address, physical_address, latitude, longitude, country_code, country) values (7, ''Bucharest'', null,';
wwv_flow_imp.g_varchar2_table(122) := ' ''Floreasca Park 43 Soseaua Pipera, corp B. Sector 2 Bucharest, 014254 RO'', 44.43225, 26.10626, ''RO''';
wwv_flow_imp.g_varchar2_table(123) := ',''Romania'');'||wwv_flow.LF||
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_a';
wwv_flow_imp.g_varchar2_table(124) := 'ddress, latitude, longitude, country_code, country) values (8, ''Berlin'', null, ''Behrenstrasse 42 (Hu';
wwv_flow_imp.g_varchar2_table(125) := unistr('mboldt Carr\00E9) 10117 Berlin'', 52.5161, 13.3873, ''DE'',''Germany'');'||wwv_flow.LF||
'        insert into eba_demo_json_st');
wwv_flow_imp.g_varchar2_table(126) := 'ores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, countr';
wwv_flow_imp.g_varchar2_table(127) := 'y) values (9, ''Utrecht'', null, ''Hertogswetering 163-167, 3543 AS Utrecht, Netherlands'', 52.103263, 5';
wwv_flow_imp.g_varchar2_table(128) := '.061644, ''NL'',''Netherlands'');'||wwv_flow.LF||
'        insert into eba_demo_json_stores (store_id, store_name, web_ad';
wwv_flow_imp.g_varchar2_table(129) := 'dress, physical_address, latitude, longitude, country_code, country) values (10, ''Madrid'', null, ''C/';
wwv_flow_imp.g_varchar2_table(130) := ' Jose Echegaray 6B Las Rozas 28230 Madrid'', 40.4929, -3.8737, ''ES'',''Spain'');'||wwv_flow.LF||
'        insert into eba';
wwv_flow_imp.g_varchar2_table(131) := '_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country';
wwv_flow_imp.g_varchar2_table(132) := '_code, country) values (11, ''Johannesburg'', null, ''Woodmead North Office Park 54 Maxwell Drive Juksk';
wwv_flow_imp.g_varchar2_table(133) := 'eiview, Sandton, 2196'', -26.044222, 28.094662, ''ZA'',''South Africa'');'||wwv_flow.LF||
'        insert into eba_demo_js';
wwv_flow_imp.g_varchar2_table(134) := 'on_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_code, c';
wwv_flow_imp.g_varchar2_table(135) := 'ountry) values (12, ''Lagos'', null, ''1391 Tiamiyu Savage St, Victoria Island, Lagos, Nigeria'', 6.4280';
wwv_flow_imp.g_varchar2_table(136) := '6, 3.42199, ''NG'',''Nigeria'');'||wwv_flow.LF||
'        insert into eba_demo_json_stores (store_id, store_name, web_add';
wwv_flow_imp.g_varchar2_table(137) := 'ress, physical_address, latitude, longitude, country_code, country) values (13, ''Bengaluru'', null, ''';
wwv_flow_imp.g_varchar2_table(138) := '193, Bannerghatta Main Rd, Industrial Area, Stage 2, BTM Layout, Bengaluru, Karnataka 560076, India''';
wwv_flow_imp.g_varchar2_table(139) := ', 12.8939, 77.5978, ''IN'',''India'');'||wwv_flow.LF||
'        insert into eba_demo_json_stores (store_id, store_name, w';
wwv_flow_imp.g_varchar2_table(140) := 'eb_address, physical_address, latitude, longitude, country_code, country) values (14, ''Mumbai'', null';
wwv_flow_imp.g_varchar2_table(141) := ', ''First International Financial Center Unit No. 501, Level 5 No. C54 & 55, G Block Bandra Kurla Com';
wwv_flow_imp.g_varchar2_table(142) := 'plex CTS No. 4207, Kolekalyan Village Mumbai - 400 051 India'', 19.069405, 72.870143, ''IN'',''India'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(143) := '        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, latit';
wwv_flow_imp.g_varchar2_table(144) := 'ude, longitude, country_code, country) values (15, ''New Delhi'', null, ''F-01/02, First Floor Salcon R';
wwv_flow_imp.g_varchar2_table(145) := 'asvillas D-1, District Centre, Saket, New Delhi - 110017 India'', 28.527693, 77.220135, ''IN'',''India'')';
wwv_flow_imp.g_varchar2_table(146) := ';'||wwv_flow.LF||
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_address, lat';
wwv_flow_imp.g_varchar2_table(147) := 'itude, longitude, country_code, country) values (16, ''Sydney'', null, ''Riverside Corporate Park 4 Jul';
wwv_flow_imp.g_varchar2_table(148) := 'ius Avenue North Ryde NSW 2113'', -33.797279, 151.143826, ''AU'',''Australia'');'||wwv_flow.LF||
'        insert into eba_';
wwv_flow_imp.g_varchar2_table(149) := 'demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, country_';
wwv_flow_imp.g_varchar2_table(150) := 'code, country) values (17, ''Perth'', null, ''Level 9 225 St Georges Terrace Perth WA 6000'', -31.953715';
wwv_flow_imp.g_varchar2_table(151) := ', 115.851645, ''AU'',''Australia'');'||wwv_flow.LF||
'        insert into eba_demo_json_stores (store_id, store_name, web';
wwv_flow_imp.g_varchar2_table(152) := '_address, physical_address, latitude, longitude, country_code, country) values (18, ''Sao Paulo'', nul';
wwv_flow_imp.g_varchar2_table(153) := unistr('l, ''Rua Dr. Jos\00E9 \00C1ureo Bustamante, 455 - Vila Cordeiro, CEP 04710-090 Sao Paulo'', -23.5475, -46.6361');
wwv_flow_imp.g_varchar2_table(154) := '1, ''BR'',''Brazil'');'||wwv_flow.LF||
'        insert into eba_demo_json_stores (store_id, store_name, web_address, phys';
wwv_flow_imp.g_varchar2_table(155) := 'ical_address, latitude, longitude, country_code, country) values (19, ''Buenos Aires'', null, ''Juana M';
wwv_flow_imp.g_varchar2_table(156) := 'anso 1069, Buenos Aires, Argentina'', -34.61016, -58.362867, ''AR'',''Argentine'');'||wwv_flow.LF||
'        insert into e';
wwv_flow_imp.g_varchar2_table(157) := 'ba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, count';
wwv_flow_imp.g_varchar2_table(158) := 'ry_code, country) values (20, ''Mexico City'', null, ''Montes Urales # 470 P3 Col. Lomas de Chapultepec';
wwv_flow_imp.g_varchar2_table(159) := ' Delegacion Miguel Hidalgo - C.P. 11000'', 19.428489, -99.205745, ''MX'',''Mexico'');'||wwv_flow.LF||
'        insert into';
wwv_flow_imp.g_varchar2_table(160) := ' eba_demo_json_stores (store_id, store_name, web_address, physical_address, latitude, longitude, cou';
wwv_flow_imp.g_varchar2_table(161) := 'ntry_code, country) values (21, ''Beijing'', null, ''China, Beijing Shi, Haidian Qu, Dongbeiwang W Rd, ';
wwv_flow_imp.g_varchar2_table(162) := '8, 100085'', 40.0572, 116.290061, ''CN'',''China'');'||wwv_flow.LF||
'        insert into eba_demo_json_stores (store_id, ';
wwv_flow_imp.g_varchar2_table(163) := 'store_name, web_address, physical_address, latitude, longitude, country_code, country) values (22, ''';
wwv_flow_imp.g_varchar2_table(164) := 'Tokyo'', null, ''2 Chome-5-? Kitaaoyama, Minato City, Tokyo 107-0061, Japan'', 35.671534, 139.718584, ''';
wwv_flow_imp.g_varchar2_table(165) := 'JP'',''Japan'');'||wwv_flow.LF||
'        insert into eba_demo_json_stores (store_id, store_name, web_address, physical_';
wwv_flow_imp.g_varchar2_table(166) := 'address, latitude, longitude, country_code, country) values (23, ''Tel Aviv'', null, ''B, Aharon Bart S';
wwv_flow_imp.g_varchar2_table(167) := 't 18, Petah Tikva, 4951400, Israel'', 32.100664, 34.862138, ''IL'',''Israel'');'||wwv_flow.LF||
'       --Orders data'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(168) := '    insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,orde';
wwv_flow_imp.g_varchar2_table(169) := 'r_metadata) values (453,to_timestamp(''23-JUL-25 12.13.03.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''n';
wwv_flow_imp.g_varchar2_table(170) := 'ls_date_language=english''),4,''Complete'',4,json (''{"shipment": {"method": "Express","status": "Proces';
wwv_flow_imp.g_varchar2_table(171) := 'sing","estimated_delivery": "2025-07-27"},"payment": {"method": "Card","status": "Paid"},"delivery_a';
wwv_flow_imp.g_varchar2_table(172) := 'ddress": {"street": "553 Main St","city": "Miami","state_province": "Florida","country": "USA","post';
wwv_flow_imp.g_varchar2_table(173) := 'al_code": "33101"},"notes": "call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_i';
wwv_flow_imp.g_varchar2_table(174) := 'd,order_datetime,customer_id,order_status,store_id,order_metadata) values (506,to_timestamp(''07-AUG-';
wwv_flow_imp.g_varchar2_table(175) := '25 10.56.44.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),4,''Complete'',1,jso';
wwv_flow_imp.g_varchar2_table(176) := 'n (''{"shipment": {"method": "Standard","status": "Delivered","estimated_delivery": "2025-08-09"},"pa';
wwv_flow_imp.g_varchar2_table(177) := 'yment": {"method": "Paypal","status": "Paid"},"delivery_address": {"street": "606 Main St","city": "';
wwv_flow_imp.g_varchar2_table(178) := 'San Antonio","state_province": "Texas","country": "USA","postal_code": "78201"},"notes": "hand to re';
wwv_flow_imp.g_varchar2_table(179) := 'cipient"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_st';
wwv_flow_imp.g_varchar2_table(180) := 'atus,store_id,order_metadata) values (513,to_timestamp(''09-AUG-25 08.00.22.000000000 AM'',''DD-MON-RR ';
wwv_flow_imp.g_varchar2_table(181) := 'HH.MI.SS.FF AM'',''nls_date_language=english''),15,''Cancelled'',1,json (''{"shipment":{"method":"Express"';
wwv_flow_imp.g_varchar2_table(182) := ',"status":"Processing","estimated_delivery":"2025-08-13"},"payment":{"method":"Card","status":"Paid"';
wwv_flow_imp.g_varchar2_table(183) := '},"delivery_address":{"street":"613 Main St","city":"Miami","state_province":"Florida","country":"US';
wwv_flow_imp.g_varchar2_table(184) := 'A","postal_code":"33101"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (o';
wwv_flow_imp.g_varchar2_table(185) := 'rder_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (544,to_timestamp(''1';
wwv_flow_imp.g_varchar2_table(186) := '6-AUG-25 06.32.10.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Open'',1,j';
wwv_flow_imp.g_varchar2_table(187) := 'son(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-08-21"},"payment';
wwv_flow_imp.g_varchar2_table(188) := '":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"644 Main St","city":"P';
wwv_flow_imp.g_varchar2_table(189) := 'hoenix","state_province":"Arizona","country":"USA","postal_code":"85001"},"notes":"leave at door"}'')';
wwv_flow_imp.g_varchar2_table(190) := ');'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_';
wwv_flow_imp.g_varchar2_table(191) := 'id,order_metadata) values (585,to_timestamp(''26-AUG-25 11.02.38.000000000 AM'',''DD-MON-RR HH.MI.SS.FF';
wwv_flow_imp.g_varchar2_table(192) := ' AM'',''nls_date_language=english''),4,''Paid'',1,json(''{"shipment":{"method":"Express","status":"Process';
wwv_flow_imp.g_varchar2_table(193) := 'ing","estimated_delivery":"2025-08-27"},"payment":{"method":"Card","status":"Paid"},"delivery_addres';
wwv_flow_imp.g_varchar2_table(194) := 's":{"street":"685 Main St","city":"Philadelphia","state_province":"Pennsylvania","country":"USA","po';
wwv_flow_imp.g_varchar2_table(195) := 'stal_code":"19101"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_i';
wwv_flow_imp.g_varchar2_table(196) := 'd,order_datetime,customer_id,order_status,store_id,order_metadata) values (608,to_timestamp(''01-SEP-';
wwv_flow_imp.g_varchar2_table(197) := '25 08.01.41.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Open'',1,json (''';
wwv_flow_imp.g_varchar2_table(198) := '{"shipment": {"method": "Standard","status": "Delivered","estimated_delivery": "2025-09-05"},"paymen';
wwv_flow_imp.g_varchar2_table(199) := 't": {"method": "Paypal","status": "Paid"},"delivery_address": {"street": "708 Main St","city": "Dall';
wwv_flow_imp.g_varchar2_table(200) := 'as","state_province": "Texas","country": "USA","postal_code": "75201"},"notes": "leave at door"}''));';
wwv_flow_imp.g_varchar2_table(201) := ''||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id';
wwv_flow_imp.g_varchar2_table(202) := ',order_metadata) values (672,to_timestamp(''13-SEP-25 01.37.34.000000000 AM'',''DD-MON-RR HH.MI.SS.FF A';
wwv_flow_imp.g_varchar2_table(203) := 'M'',''nls_date_language=english''),4,''Complete'',4,json (''{"shipment": {"method": "Standard","status": "';
wwv_flow_imp.g_varchar2_table(204) := 'Processing","estimated_delivery": "2025-09-16"},"payment": {"method": "Card","status": "Paid"},"deli';
wwv_flow_imp.g_varchar2_table(205) := 'very_address": {"street": "772 Main St","city": "Boston","state_province": "Massachusetts","country"';
wwv_flow_imp.g_varchar2_table(206) := ': "USA","postal_code": "02108"},"notes": "leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orde';
wwv_flow_imp.g_varchar2_table(207) := 'rs (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (687,to_timesta';
wwv_flow_imp.g_varchar2_table(208) := 'mp(''17-SEP-25 12.09.10.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),16,''Com';
wwv_flow_imp.g_varchar2_table(209) := 'plete'',1,json(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-09-2';
wwv_flow_imp.g_varchar2_table(210) := '0"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"787 Main St","city":"S';
wwv_flow_imp.g_varchar2_table(211) := 'an Diego","state_province":"California","country":"USA","postal_code":"92101"},"notes":null}''));'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(212) := '     insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,ord';
wwv_flow_imp.g_varchar2_table(213) := 'er_metadata) values (707,to_timestamp(''20-SEP-25 06.12.35.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''';
wwv_flow_imp.g_varchar2_table(214) := 'nls_date_language=english''),5,''Paid'',1,json(''{"shipment":{"method":"Express","status":"Delivered","e';
wwv_flow_imp.g_varchar2_table(215) := 'stimated_delivery":"2025-09-23"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"';
wwv_flow_imp.g_varchar2_table(216) := 'street":"807 Main St","city":"San Diego","state_province":"California","country":"USA","postal_code"';
wwv_flow_imp.g_varchar2_table(217) := ':"92101"},"notes":null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,custom';
wwv_flow_imp.g_varchar2_table(218) := 'er_id,order_status,store_id,order_metadata) values (760,to_timestamp(''29-SEP-25 07.19.53.000000000 A';
wwv_flow_imp.g_varchar2_table(219) := 'M'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),19,''Complete'',1,json(''{"shipment":{"metho';
wwv_flow_imp.g_varchar2_table(220) := 'd":"Standard","status":"Shipped","estimated_delivery":"2025-09-30"},"payment":{"method":"Cash on del';
wwv_flow_imp.g_varchar2_table(221) := 'ivery","status":"Paid"},"delivery_address":{"street":"860 Main St","city":"New York","state_province';
wwv_flow_imp.g_varchar2_table(222) := '":"New York","country":"USA","postal_code":"10001"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        insert into';
wwv_flow_imp.g_varchar2_table(223) := ' eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) val';
wwv_flow_imp.g_varchar2_table(224) := 'ues (761,to_timestamp(''29-SEP-25 08.35.11.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_languag';
wwv_flow_imp.g_varchar2_table(225) := 'e=english''),11,''Open'',1,json(''{"shipment":{"method":"Express","status":"Delivered","estimated_delive';
wwv_flow_imp.g_varchar2_table(226) := 'ry":"2025-10-01"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"861 Ma';
wwv_flow_imp.g_varchar2_table(227) := 'in St","city":"Los Angeles","state_province":"California","country":"USA","postal_code":"90001"},"no';
wwv_flow_imp.g_varchar2_table(228) := 'tes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,custom';
wwv_flow_imp.g_varchar2_table(229) := 'er_id,order_status,store_id,order_metadata) values (765,to_timestamp(''29-SEP-25 09.36.52.000000000 P';
wwv_flow_imp.g_varchar2_table(230) := 'M'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),2,''Complete'',2,json(''{"shipment":{"method';
wwv_flow_imp.g_varchar2_table(231) := '":"Express","status":"Processing","estimated_delivery":"2025-09-30"},"payment":{"method":"Card","sta';
wwv_flow_imp.g_varchar2_table(232) := 'tus":"Paid"},"delivery_address":{"street":"865 Main St","city":"Philadelphia","state_province":"Penn';
wwv_flow_imp.g_varchar2_table(233) := 'sylvania","country":"USA","postal_code":"19101"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into ';
wwv_flow_imp.g_varchar2_table(234) := 'eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) valu';
wwv_flow_imp.g_varchar2_table(235) := 'es (766,to_timestamp(''30-SEP-25 12.38.08.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language';
wwv_flow_imp.g_varchar2_table(236) := '=english''),3,''Complete'',1,json(''{"shipment":{"method":"Standard","status":"Shipped","estimated_deliv';
wwv_flow_imp.g_varchar2_table(237) := 'ery":"2025-10-02"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"stre';
wwv_flow_imp.g_varchar2_table(238) := 'et":"866 Main St","city":"San Antonio","state_province":"Texas","country":"USA","postal_code":"78201';
wwv_flow_imp.g_varchar2_table(239) := '"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetim';
wwv_flow_imp.g_varchar2_table(240) := 'e,customer_id,order_status,store_id,order_metadata) values (769,to_timestamp(''30-SEP-25 02.49.28.000';
wwv_flow_imp.g_varchar2_table(241) := '000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),6,''Refunded'',1,json(''{"shipment":';
wwv_flow_imp.g_varchar2_table(242) := '{"method":"Express","status":"Shipped","estimated_delivery":"2025-10-05"},"payment":{"method":"Cash ';
wwv_flow_imp.g_varchar2_table(243) := 'on delivery","status":"Paid"},"delivery_address":{"street":"869 Main St","city":"San Francisco","sta';
wwv_flow_imp.g_varchar2_table(244) := 'te_province":"California","country":"USA","postal_code":"94102"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(245) := '    insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,orde';
wwv_flow_imp.g_varchar2_table(246) := 'r_metadata) values (808,to_timestamp(''08-OCT-25 04.06.33.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''n';
wwv_flow_imp.g_varchar2_table(247) := 'ls_date_language=english''),14,''Paid'',1,json(''{"shipment":{"method":"Standard","status":"Shipped","es';
wwv_flow_imp.g_varchar2_table(248) := 'timated_delivery":"2025-10-12"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_ad';
wwv_flow_imp.g_varchar2_table(249) := 'dress":{"street":"908 Main St","city":"Dallas","state_province":"Texas","country":"USA","postal_code';
wwv_flow_imp.g_varchar2_table(250) := '":"75201"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_dat';
wwv_flow_imp.g_varchar2_table(251) := 'etime,customer_id,order_status,store_id,order_metadata) values (832,to_timestamp(''12-OCT-25 11.16.40';
wwv_flow_imp.g_varchar2_table(252) := '.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Complete'',3,json(''{"shipme';
wwv_flow_imp.g_varchar2_table(253) := 'nt":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-10-15"},"payment":{"method":"';
wwv_flow_imp.g_varchar2_table(254) := 'Cash on delivery","status":"Paid"},"delivery_address":{"street":"932 Main St","city":"Boston","state';
wwv_flow_imp.g_varchar2_table(255) := '_province":"Massachusetts","country":"USA","postal_code":"02108"},"notes":"leave at door"}''));'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(256) := '   insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order';
wwv_flow_imp.g_varchar2_table(257) := '_metadata) values (839,to_timestamp(''14-OCT-25 01.59.20.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nl';
wwv_flow_imp.g_varchar2_table(258) := 's_date_language=english''),12,''Complete'',12,json(''{"shipment":{"method":"Express","status":"Delivered';
wwv_flow_imp.g_varchar2_table(259) := '","estimated_delivery":"2025-10-19"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address';
wwv_flow_imp.g_varchar2_table(260) := '":{"street":"939 Main St","city":"Edmonton","state_province":"Alberta","country":"Canada","postal_co';
wwv_flow_imp.g_varchar2_table(261) := 'de":"T5J 0N3"},"notes":null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,c';
wwv_flow_imp.g_varchar2_table(262) := 'ustomer_id,order_status,store_id,order_metadata) values (862,to_timestamp(''19-OCT-25 02.34.20.000000';
wwv_flow_imp.g_varchar2_table(263) := '000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),7,''Complete'',7,json(''{"shipment":{"m';
wwv_flow_imp.g_varchar2_table(264) := 'ethod":"Standard","status":"Shipped","estimated_delivery":"2025-10-22"},"payment":{"method":"Cash on';
wwv_flow_imp.g_varchar2_table(265) := ' delivery","status":"Paid"},"delivery_address":{"street":"962 Main St","city":"Chicago","state_provi';
wwv_flow_imp.g_varchar2_table(266) := 'nce":"Illinois","country":"USA","postal_code":"60601"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
'        inse';
wwv_flow_imp.g_varchar2_table(267) := 'rt into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metada';
wwv_flow_imp.g_varchar2_table(268) := 'ta) values (899,to_timestamp(''27-OCT-25 09.42.00.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_';
wwv_flow_imp.g_varchar2_table(269) := 'language=english''),17,''Cancelled'',1,json(''{"shipment":{"method":"Express","status":"Delivered","esti';
wwv_flow_imp.g_varchar2_table(270) := 'mated_delivery":"2025-11-01"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"str';
wwv_flow_imp.g_varchar2_table(271) := 'eet":"999 Main St","city":"Edmonton","state_province":"Alberta","country":"Canada","postal_code":"T5';
wwv_flow_imp.g_varchar2_table(272) := 'J 0N3"},"notes":null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer';
wwv_flow_imp.g_varchar2_table(273) := '_id,order_status,store_id,order_metadata) values (920,to_timestamp(''30-OCT-25 05.59.30.000000000 PM''';
wwv_flow_imp.g_varchar2_table(274) := ',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),4,''Complete'',4,json(''{"shipment":{"method":';
wwv_flow_imp.g_varchar2_table(275) := '"Standard","status":"Delivered","estimated_delivery":"2025-10-31"},"payment":{"method":"Paypal","sta';
wwv_flow_imp.g_varchar2_table(276) := 'tus":"Paid"},"delivery_address":{"street":"120 Main St","city":"New York","state_province":"New York';
wwv_flow_imp.g_varchar2_table(277) := '","country":"USA","postal_code":"10001"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_j';
wwv_flow_imp.g_varchar2_table(278) := 'son_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (928,to';
wwv_flow_imp.g_varchar2_table(279) := '_timestamp(''31-OCT-25 05.07.56.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english'')';
wwv_flow_imp.g_varchar2_table(280) := ',9,''Complete'',1,json(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025';
wwv_flow_imp.g_varchar2_table(281) := '-11-04"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"128 M';
wwv_flow_imp.g_varchar2_table(282) := 'ain St","city":"Dallas","state_province":"Texas","country":"USA","postal_code":"75201"},"notes":"lea';
wwv_flow_imp.g_varchar2_table(283) := 've at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order';
wwv_flow_imp.g_varchar2_table(284) := '_status,store_id,order_metadata) values (943,to_timestamp(''03-NOV-25 04.41.53.000000000 PM'',''DD-MON-';
wwv_flow_imp.g_varchar2_table(285) := 'RR HH.MI.SS.FF AM'',''nls_date_language=english''),10,''Open'',1,json(''{"shipment":{"method":"Express","s';
wwv_flow_imp.g_varchar2_table(286) := 'tatus":"Shipped","estimated_delivery":"2025-11-07"},"payment":{"method":"Cash on delivery","status":';
wwv_flow_imp.g_varchar2_table(287) := '"Paid"},"delivery_address":{"street":"143 Main St","city":"Houston","state_province":"Texas","countr';
wwv_flow_imp.g_varchar2_table(288) := 'y":"USA","postal_code":"77001"},"notes":null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id';
wwv_flow_imp.g_varchar2_table(289) := ',order_datetime,customer_id,order_status,store_id,order_metadata) values (950,to_timestamp(''05-NOV-2';
wwv_flow_imp.g_varchar2_table(290) := '5 07.02.43.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),7,''Complete'',1,json';
wwv_flow_imp.g_varchar2_table(291) := '(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-11-06"},"payment"';
wwv_flow_imp.g_varchar2_table(292) := ':{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"150 Main St","city":"Seattle","st';
wwv_flow_imp.g_varchar2_table(293) := 'ate_province":"Washington","country":"USA","postal_code":"98101"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(294) := '       insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,o';
wwv_flow_imp.g_varchar2_table(295) := 'rder_metadata) values (960,to_timestamp(''06-NOV-25 09.18.36.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM''';
wwv_flow_imp.g_varchar2_table(296) := ',''nls_date_language=english''),11,''Open'',1,json(''{"shipment":{"method":"Standard","status":"Processin';
wwv_flow_imp.g_varchar2_table(297) := 'g","estimated_delivery":"2025-11-07"},"payment":{"method":"Card","status":"Paid"},"delivery_address"';
wwv_flow_imp.g_varchar2_table(298) := ':{"street":"160 Main St","city":"New York","state_province":"New York","country":"USA","postal_code"';
wwv_flow_imp.g_varchar2_table(299) := ':"10001"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_date';
wwv_flow_imp.g_varchar2_table(300) := 'time,customer_id,order_status,store_id,order_metadata) values (968,to_timestamp(''08-NOV-25 12.30.18.';
wwv_flow_imp.g_varchar2_table(301) := '000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),9,''Complete'',1,json(''{"shipmen';
wwv_flow_imp.g_varchar2_table(302) := 't":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-11-12"},"payment":{"method":';
wwv_flow_imp.g_varchar2_table(303) := '"Paypal","status":"Paid"},"delivery_address":{"street":"168 Main St","city":"Dallas","state_province';
wwv_flow_imp.g_varchar2_table(304) := '":"Texas","country":"USA","postal_code":"75201"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        insert into eb';
wwv_flow_imp.g_varchar2_table(305) := 'a_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values';
wwv_flow_imp.g_varchar2_table(306) := ' (972,to_timestamp(''09-NOV-25 02.12.47.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=e';
wwv_flow_imp.g_varchar2_table(307) := 'nglish''),6,''Refunded'',6,json(''{"shipment":{"method":"Standard","status":"Processing","estimated_deli';
wwv_flow_imp.g_varchar2_table(308) := 'very":"2025-11-12"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"172 Ma';
wwv_flow_imp.g_varchar2_table(309) := 'in St","city":"Boston","state_province":"Massachusetts","country":"USA","postal_code":"02108"},"note';
wwv_flow_imp.g_varchar2_table(310) := 's":"leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_i';
wwv_flow_imp.g_varchar2_table(311) := 'd,order_status,store_id,order_metadata) values (986,to_timestamp(''11-NOV-25 07.03.57.000000000 PM'',''';
wwv_flow_imp.g_varchar2_table(312) := 'DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),10,''Open'',10,json(''{"shipment":{"method":"Sta';
wwv_flow_imp.g_varchar2_table(313) := 'ndard","status":"Delivered","estimated_delivery":"2025-11-13"},"payment":{"method":"Paypal","status"';
wwv_flow_imp.g_varchar2_table(314) := ':"Paid"},"delivery_address":{"street":"186 Main St","city":"San Antonio","state_province":"Texas","c';
wwv_flow_imp.g_varchar2_table(315) := 'ountry":"USA","postal_code":"78201"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
'        insert into eba_demo_j';
wwv_flow_imp.g_varchar2_table(316) := 'son_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (993,to';
wwv_flow_imp.g_varchar2_table(317) := '_timestamp(''13-NOV-25 10.16.45.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english'')';
wwv_flow_imp.g_varchar2_table(318) := ',8,''Paid'',1,json(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-1';
wwv_flow_imp.g_varchar2_table(319) := '1-17"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"193 Main St","city"';
wwv_flow_imp.g_varchar2_table(320) := ':"Miami","state_province":"Florida","country":"USA","postal_code":"33101"},"notes":"call on arrival"';
wwv_flow_imp.g_varchar2_table(321) := '}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,sto';
wwv_flow_imp.g_varchar2_table(322) := 're_id,order_metadata) values (1052,to_timestamp(''22-NOV-25 05.14.32.000000000 PM'',''DD-MON-RR HH.MI.S';
wwv_flow_imp.g_varchar2_table(323) := 'S.FF AM'',''nls_date_language=english''),13,''Complete'',1,json(''{"shipment":{"method":"Standard","status';
wwv_flow_imp.g_varchar2_table(324) := '":"Delivered","estimated_delivery":"2025-11-25"},"payment":{"method":"Paypal","status":"Paid"},"deli';
wwv_flow_imp.g_varchar2_table(325) := 'very_address":{"street":"252 Main St","city":"Boston","state_province":"Massachusetts","country":"US';
wwv_flow_imp.g_varchar2_table(326) := 'A","postal_code":"02108"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (ord';
wwv_flow_imp.g_varchar2_table(327) := 'er_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1058,to_timestamp(''24';
wwv_flow_imp.g_varchar2_table(328) := '-NOV-25 03.58.10.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),6,''Cancelled''';
wwv_flow_imp.g_varchar2_table(329) := ',6,json(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-11-28"},"p';
wwv_flow_imp.g_varchar2_table(330) := 'ayment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"258 Main St","city":"Ottaw';
wwv_flow_imp.g_varchar2_table(331) := 'a","state_province":"Ontario","country":"Canada","postal_code":"K1A 0B1"},"notes":"hand to recipient';
wwv_flow_imp.g_varchar2_table(332) := '"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,st';
wwv_flow_imp.g_varchar2_table(333) := 'ore_id,order_metadata) values (1082,to_timestamp(''28-NOV-25 05.29.33.000000000 AM'',''DD-MON-RR HH.MI.';
wwv_flow_imp.g_varchar2_table(334) := 'SS.FF AM'',''nls_date_language=english''),8,''Cancelled'',8,json(''{"shipment":{"method":"Standard","statu';
wwv_flow_imp.g_varchar2_table(335) := 's":"Delivered","estimated_delivery":"2025-12-01"},"payment":{"method":"Paypal","status":"Paid"},"del';
wwv_flow_imp.g_varchar2_table(336) := 'ivery_address":{"street":"282 Main St","city":"Chicago","state_province":"Illinois","country":"USA",';
wwv_flow_imp.g_varchar2_table(337) := '"postal_code":"60601"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (or';
wwv_flow_imp.g_varchar2_table(338) := 'der_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1102,to_timestamp(''0';
wwv_flow_imp.g_varchar2_table(339) := '1-DEC-25 10.25.32.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),9,''Complete''';
wwv_flow_imp.g_varchar2_table(340) := ',9,json(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-12-04"},"pay';
wwv_flow_imp.g_varchar2_table(341) := 'ment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"302 Main St","city';
wwv_flow_imp.g_varchar2_table(342) := '":"Chicago","state_province":"Illinois","country":"USA","postal_code":"60601"},"notes":"hand to reci';
wwv_flow_imp.g_varchar2_table(343) := 'pient"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_stat';
wwv_flow_imp.g_varchar2_table(344) := 'us,store_id,order_metadata) values (1,to_timestamp(''25-FEB-25 02.24.33.000000000 AM'',''DD-MON-RR HH.M';
wwv_flow_imp.g_varchar2_table(345) := 'I.SS.FF AM'',''nls_date_language=english''),3,''Open'',1,json(''{"shipment":{"method":"Express","status":"';
wwv_flow_imp.g_varchar2_table(346) := 'Shipped","estimated_delivery":"2025-02-27"},"payment":{"method":"Cash on delivery","status":"Paid"},';
wwv_flow_imp.g_varchar2_table(347) := '"delivery_address":{"street":"101 Main St","city":"Los Angeles","state_province":"California","count';
wwv_flow_imp.g_varchar2_table(348) := 'ry":"USA","postal_code":"90001"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_or';
wwv_flow_imp.g_varchar2_table(349) := 'ders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (3,to_timesta';
wwv_flow_imp.g_varchar2_table(350) := 'mp(''02-MAR-25 12.21.18.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),18,''Com';
wwv_flow_imp.g_varchar2_table(351) := 'plete'',1,json(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-03-0';
wwv_flow_imp.g_varchar2_table(352) := '6"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"103 Main St","city":"H';
wwv_flow_imp.g_varchar2_table(353) := 'ouston","state_province":"Texas","country":"USA","postal_code":"77001"},"notes":null}''));'||wwv_flow.LF||
'        in';
wwv_flow_imp.g_varchar2_table(354) := 'sert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_meta';
wwv_flow_imp.g_varchar2_table(355) := 'data) values (5,to_timestamp(''04-MAR-25 07.05.41.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_';
wwv_flow_imp.g_varchar2_table(356) := 'language=english''),2,''Paid'',1,json(''{"shipment":{"method":"Express","status":"Delivered","estimated_';
wwv_flow_imp.g_varchar2_table(357) := 'delivery":"2025-03-05"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"';
wwv_flow_imp.g_varchar2_table(358) := '105 Main St","city":"Philadelphia","state_province":"Pennsylvania","country":"USA","postal_code":"19';
wwv_flow_imp.g_varchar2_table(359) := '101"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_dateti';
wwv_flow_imp.g_varchar2_table(360) := 'me,customer_id,order_status,store_id,order_metadata) values (7,to_timestamp(''14-MAR-25 02.01.22.0000';
wwv_flow_imp.g_varchar2_table(361) := '00000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),9,''Refunded'',1,json(''{"shipment":{';
wwv_flow_imp.g_varchar2_table(362) := '"method":"Express","status":"Shipped","estimated_delivery":"2025-03-17"},"payment":{"method":"Cash o';
wwv_flow_imp.g_varchar2_table(363) := 'n delivery","status":"Paid"},"delivery_address":{"street":"107 Main St","city":"San Diego","state_pr';
wwv_flow_imp.g_varchar2_table(364) := 'ovince":"California","country":"USA","postal_code":"92101"},"notes":null}''));'||wwv_flow.LF||
'        insert into eb';
wwv_flow_imp.g_varchar2_table(365) := 'a_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values';
wwv_flow_imp.g_varchar2_table(366) := ' (17,to_timestamp(''19-MAR-25 08.51.57.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=en';
wwv_flow_imp.g_varchar2_table(367) := 'glish''),16,''Refunded'',1,json(''{"shipment":{"method":"Express","status":"Delivered","estimated_delive';
wwv_flow_imp.g_varchar2_table(368) := 'ry":"2025-03-22"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"117 Ma';
wwv_flow_imp.g_varchar2_table(369) := 'in St","city":"Calgary","state_province":"Alberta","country":"Canada","postal_code":"T2P 1J9"},"note';
wwv_flow_imp.g_varchar2_table(370) := 's":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer';
wwv_flow_imp.g_varchar2_table(371) := '_id,order_status,store_id,order_metadata) values (20,to_timestamp(''21-MAR-25 11.11.43.000000000 PM'',';
wwv_flow_imp.g_varchar2_table(372) := '''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Complete'',3,json(''{"shipment":{"method":"';
wwv_flow_imp.g_varchar2_table(373) := 'Standard","status":"Delivered","estimated_delivery":"2025-03-22"},"payment":{"method":"Paypal","stat';
wwv_flow_imp.g_varchar2_table(374) := 'us":"Paid"},"delivery_address":{"street":"120 Main St","city":"New York","state_province":"New York"';
wwv_flow_imp.g_varchar2_table(375) := ',"country":"USA","postal_code":"10001"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_js';
wwv_flow_imp.g_varchar2_table(376) := 'on_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (63,to_t';
wwv_flow_imp.g_varchar2_table(377) := 'imestamp(''11-APR-25 07.21.35.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3';
wwv_flow_imp.g_varchar2_table(378) := ',''Complete'',1,json(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025';
wwv_flow_imp.g_varchar2_table(379) := '-04-15"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"163 Main St","cit';
wwv_flow_imp.g_varchar2_table(380) := 'y":"Houston","state_province":"Texas","country":"USA","postal_code":"77001"},"notes":null}''));'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(381) := '   insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order';
wwv_flow_imp.g_varchar2_table(382) := '_metadata) values (78,to_timestamp(''17-APR-25 11.00.11.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls';
wwv_flow_imp.g_varchar2_table(383) := '_date_language=english''),20,''Refunded'',1,json(''{"shipment":{"method":"Standard","status":"Processing';
wwv_flow_imp.g_varchar2_table(384) := '","estimated_delivery":"2025-04-21"},"payment":{"method":"Card","status":"Paid"},"delivery_address":';
wwv_flow_imp.g_varchar2_table(385) := '{"street":"178 Main St","city":"Ottawa","state_province":"Ontario","country":"Canada","postal_code":';
wwv_flow_imp.g_varchar2_table(386) := '"K1A 0B1"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order';
wwv_flow_imp.g_varchar2_table(387) := '_datetime,customer_id,order_status,store_id,order_metadata) values (79,to_timestamp(''18-APR-25 04.39';
wwv_flow_imp.g_varchar2_table(388) := '.13.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),14,''Complete'',1,json(''{"sh';
wwv_flow_imp.g_varchar2_table(389) := 'ipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-04-23"},"payment":{"method';
wwv_flow_imp.g_varchar2_table(390) := '":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"179 Main St","city":"Edmonton","';
wwv_flow_imp.g_varchar2_table(391) := 'state_province":"Alberta","country":"Canada","postal_code":"T5J 0N3"},"notes":null}''));'||wwv_flow.LF||
'        inse';
wwv_flow_imp.g_varchar2_table(392) := 'rt into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metada';
wwv_flow_imp.g_varchar2_table(393) := 'ta) values (82,to_timestamp(''19-APR-25 01.24.05.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_l';
wwv_flow_imp.g_varchar2_table(394) := 'anguage=english''),13,''Open'',1,json(''{"shipment":{"method":"Standard","status":"Shipped","estimated_d';
wwv_flow_imp.g_varchar2_table(395) := 'elivery":"2025-04-22"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"';
wwv_flow_imp.g_varchar2_table(396) := 'street":"182 Main St","city":"Chicago","state_province":"Illinois","country":"USA","postal_code":"60';
wwv_flow_imp.g_varchar2_table(397) := '601"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_date';
wwv_flow_imp.g_varchar2_table(398) := 'time,customer_id,order_status,store_id,order_metadata) values (92,to_timestamp(''21-APR-25 09.25.03.0';
wwv_flow_imp.g_varchar2_table(399) := '00000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),17,''Complete'',1,json(''{"shipmen';
wwv_flow_imp.g_varchar2_table(400) := 't":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-04-24"},"payment":{"method":';
wwv_flow_imp.g_varchar2_table(401) := '"Paypal","status":"Paid"},"delivery_address":{"street":"192 Main St","city":"Boston","state_province';
wwv_flow_imp.g_varchar2_table(402) := '":"Massachusetts","country":"USA","postal_code":"02108"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        insert';
wwv_flow_imp.g_varchar2_table(403) := ' into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata';
wwv_flow_imp.g_varchar2_table(404) := ') values (125,to_timestamp(''01-MAY-25 01.45.50.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_la';
wwv_flow_imp.g_varchar2_table(405) := 'nguage=english''),12,''Paid'',1,json(''{"shipment":{"method":"Express","status":"Delivered","estimated_d';
wwv_flow_imp.g_varchar2_table(406) := 'elivery":"2025-05-02"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"2';
wwv_flow_imp.g_varchar2_table(407) := '25 Main St","city":"Philadelphia","state_province":"Pennsylvania","country":"USA","postal_code":"191';
wwv_flow_imp.g_varchar2_table(408) := '01"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetim';
wwv_flow_imp.g_varchar2_table(409) := 'e,customer_id,order_status,store_id,order_metadata) values (132,to_timestamp(''02-MAY-25 02.19.08.000';
wwv_flow_imp.g_varchar2_table(410) := '000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),17,''Complete'',1,json(''{"shipment"';
wwv_flow_imp.g_varchar2_table(411) := ':{"method":"Standard","status":"Processing","estimated_delivery":"2025-05-05"},"payment":{"method":"';
wwv_flow_imp.g_varchar2_table(412) := 'Card","status":"Paid"},"delivery_address":{"street":"232 Main St","city":"Boston","state_province":"';
wwv_flow_imp.g_varchar2_table(413) := 'Massachusetts","country":"USA","postal_code":"02108"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(414) := 'to eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) v';
wwv_flow_imp.g_varchar2_table(415) := 'alues (159,to_timestamp(''11-MAY-25 01.56.08.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_langu';
wwv_flow_imp.g_varchar2_table(416) := 'age=english''),1,''Open'',1,json(''{"shipment":{"method":"Express","status":"Processing","estimated_deli';
wwv_flow_imp.g_varchar2_table(417) := 'very":"2025-05-16"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"259 Ma';
wwv_flow_imp.g_varchar2_table(418) := 'in St","city":"Edmonton","state_province":"Alberta","country":"Canada","postal_code":"T5J 0N3"},"not';
wwv_flow_imp.g_varchar2_table(419) := 'es":null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_st';
wwv_flow_imp.g_varchar2_table(420) := 'atus,store_id,order_metadata) values (182,to_timestamp(''16-MAY-25 05.00.13.000000000 PM'',''DD-MON-RR ';
wwv_flow_imp.g_varchar2_table(421) := 'HH.MI.SS.FF AM'',''nls_date_language=english''),1,''Complete'',1,json(''{"shipment":{"method":"Standard","';
wwv_flow_imp.g_varchar2_table(422) := 'status":"Delivered","estimated_delivery":"2025-05-19"},"payment":{"method":"Paypal","status":"Paid"}';
wwv_flow_imp.g_varchar2_table(423) := ',"delivery_address":{"street":"282 Main St","city":"Chicago","state_province":"Illinois","country":"';
wwv_flow_imp.g_varchar2_table(424) := 'USA","postal_code":"60601"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_order';
wwv_flow_imp.g_varchar2_table(425) := 's (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (196,to_timestam';
wwv_flow_imp.g_varchar2_table(426) := 'p(''19-MAY-25 05.57.59.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),8,''Cance';
wwv_flow_imp.g_varchar2_table(427) := 'lled'',1,json(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-05-21"}';
wwv_flow_imp.g_varchar2_table(428) := ',"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"296 Main St",';
wwv_flow_imp.g_varchar2_table(429) := '"city":"Vancouver","state_province":"British Columbia","country":"Canada","postal_code":"V5K 0A1"},"';
wwv_flow_imp.g_varchar2_table(430) := 'notes":"leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,custom';
wwv_flow_imp.g_varchar2_table(431) := 'er_id,order_status,store_id,order_metadata) values (201,to_timestamp(''20-MAY-25 12.52.12.000000000 A';
wwv_flow_imp.g_varchar2_table(432) := 'M'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),1,''Refunded'',1,json(''{"shipment":{"method';
wwv_flow_imp.g_varchar2_table(433) := '":"Express","status":"Processing","estimated_delivery":"2025-05-22"},"payment":{"method":"Card","sta';
wwv_flow_imp.g_varchar2_table(434) := 'tus":"Paid"},"delivery_address":{"street":"301 Main St","city":"Los Angeles","state_province":"Calif';
wwv_flow_imp.g_varchar2_table(435) := 'ornia","country":"USA","postal_code":"90001"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba';
wwv_flow_imp.g_varchar2_table(436) := '_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values ';
wwv_flow_imp.g_varchar2_table(437) := '(204,to_timestamp(''21-MAY-25 12.43.26.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=en';
wwv_flow_imp.g_varchar2_table(438) := 'glish''),6,''Cancelled'',1,json(''{"shipment":{"method":"Standard","status":"Processing","estimated_deli';
wwv_flow_imp.g_varchar2_table(439) := 'very":"2025-05-26"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"304 Ma';
wwv_flow_imp.g_varchar2_table(440) := 'in St","city":"Phoenix","state_province":"Arizona","country":"USA","postal_code":"85001"},"notes":"l';
wwv_flow_imp.g_varchar2_table(441) := 'eave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,ord';
wwv_flow_imp.g_varchar2_table(442) := 'er_status,store_id,order_metadata) values (240,to_timestamp(''28-MAY-25 01.31.20.000000000 PM'',''DD-MO';
wwv_flow_imp.g_varchar2_table(443) := 'N-RR HH.MI.SS.FF AM'',''nls_date_language=english''),8,''Cancelled'',1,json(''{"shipment":{"method":"Stand';
wwv_flow_imp.g_varchar2_table(444) := 'ard","status":"Processing","estimated_delivery":"2025-05-29"},"payment":{"method":"Card","status":"P';
wwv_flow_imp.g_varchar2_table(445) := 'aid"},"delivery_address":{"street":"340 Main St","city":"New York","state_province":"New York","coun';
wwv_flow_imp.g_varchar2_table(446) := 'try":"USA","postal_code":"10001"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_ord';
wwv_flow_imp.g_varchar2_table(447) := 'ers (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (290,to_timest';
wwv_flow_imp.g_varchar2_table(448) := 'amp(''13-JUN-25 02.12.59.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),15,''Ca';
wwv_flow_imp.g_varchar2_table(449) := 'ncelled'',1,json(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-06';
wwv_flow_imp.g_varchar2_table(450) := '-14"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"390 Main St","city';
wwv_flow_imp.g_varchar2_table(451) := '":"Seattle","state_province":"Washington","country":"USA","postal_code":"98101"},"notes":"hand to re';
wwv_flow_imp.g_varchar2_table(452) := 'cipient"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_st';
wwv_flow_imp.g_varchar2_table(453) := 'atus,store_id,order_metadata) values (298,to_timestamp(''14-JUN-25 09.34.20.000000000 AM'',''DD-MON-RR ';
wwv_flow_imp.g_varchar2_table(454) := 'HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Complete'',1,json(''{"shipment":{"method":"Standard","';
wwv_flow_imp.g_varchar2_table(455) := 'status":"Shipped","estimated_delivery":"2025-06-18"},"payment":{"method":"Cash on delivery","status"';
wwv_flow_imp.g_varchar2_table(456) := ':"Paid"},"delivery_address":{"street":"398 Main St","city":"Ottawa","state_province":"Ontario","coun';
wwv_flow_imp.g_varchar2_table(457) := 'try":"Canada","postal_code":"K1A 0B1"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
'        insert into eba_demo';
wwv_flow_imp.g_varchar2_table(458) := '_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (306,';
wwv_flow_imp.g_varchar2_table(459) := 'to_timestamp(''16-JUN-25 04.24.36.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english';
wwv_flow_imp.g_varchar2_table(460) := '''),5,''Paid'',5,json(''{"shipment":{"method":"Standard","status":"Processing","estimated_delivery":"202';
wwv_flow_imp.g_varchar2_table(461) := '5-06-18"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"406 Main St","ci';
wwv_flow_imp.g_varchar2_table(462) := 'ty":"San Antonio","state_province":"Texas","country":"USA","postal_code":"78201"},"notes":"hand to r';
wwv_flow_imp.g_varchar2_table(463) := 'ecipient"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_s';
wwv_flow_imp.g_varchar2_table(464) := 'tatus,store_id,order_metadata) values (307,to_timestamp(''16-JUN-25 05.31.39.000000000 PM'',''DD-MON-RR';
wwv_flow_imp.g_varchar2_table(465) := ' HH.MI.SS.FF AM'',''nls_date_language=english''),3,''Cancelled'',1,json(''{"shipment":{"method":"Express",';
wwv_flow_imp.g_varchar2_table(466) := '"status":"Shipped","estimated_delivery":"2025-06-19"},"payment":{"method":"Cash on delivery","status';
wwv_flow_imp.g_varchar2_table(467) := '":"Paid"},"delivery_address":{"street":"407 Main St","city":"San Diego","state_province":"California';
wwv_flow_imp.g_varchar2_table(468) := '","country":"USA","postal_code":"92101"},"notes":null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders ';
wwv_flow_imp.g_varchar2_table(469) := '(order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (331,to_timestamp(';
wwv_flow_imp.g_varchar2_table(470) := '''24-JUN-25 02.29.17.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),5,''Complet';
wwv_flow_imp.g_varchar2_table(471) := 'e'',1,json(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-06-26"},"pa';
wwv_flow_imp.g_varchar2_table(472) := 'yment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"431 Main St","cit';
wwv_flow_imp.g_varchar2_table(473) := 'y":"Denver","state_province":"Colorado","country":"USA","postal_code":"80201"},"notes":null}''));'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(474) := '     insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,ord';
wwv_flow_imp.g_varchar2_table(475) := 'er_metadata) values (349,to_timestamp(''29-JUN-25 08.24.23.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''';
wwv_flow_imp.g_varchar2_table(476) := 'nls_date_language=english''),14,''Complete'',1,json(''{"shipment":{"method":"Express","status":"Shipped"';
wwv_flow_imp.g_varchar2_table(477) := ',"estimated_delivery":"2025-07-04"},"payment":{"method":"Cash on delivery","status":"Paid"},"deliver';
wwv_flow_imp.g_varchar2_table(478) := 'y_address":{"street":"449 Main St","city":"San Francisco","state_province":"California","country":"U';
wwv_flow_imp.g_varchar2_table(479) := 'SA","postal_code":"94102"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (';
wwv_flow_imp.g_varchar2_table(480) := 'order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (401,to_timestamp(''';
wwv_flow_imp.g_varchar2_table(481) := '11-JUL-25 10.55.57.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),16,''Open'',1';
wwv_flow_imp.g_varchar2_table(482) := ',json(''{"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-07-13"},"paym';
wwv_flow_imp.g_varchar2_table(483) := 'ent":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"501 Main St","city":"Los Ange';
wwv_flow_imp.g_varchar2_table(484) := 'les","state_province":"California","country":"USA","postal_code":"90001"},"notes":"call on arrival"}';
wwv_flow_imp.g_varchar2_table(485) := '''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,stor';
wwv_flow_imp.g_varchar2_table(486) := 'e_id,order_metadata) values (430,to_timestamp(''17-JUL-25 08.56.02.000000000 AM'',''DD-MON-RR HH.MI.SS.';
wwv_flow_imp.g_varchar2_table(487) := 'FF AM'',''nls_date_language=english''),8,''Complete'',1,json(''{"shipment":{"method":"Standard","status":"';
wwv_flow_imp.g_varchar2_table(488) := 'Shipped","estimated_delivery":"2025-07-18"},"payment":{"method":"Cash on delivery","status":"Paid"},';
wwv_flow_imp.g_varchar2_table(489) := '"delivery_address":{"street":"530 Main St","city":"Seattle","state_province":"Washington","country":';
wwv_flow_imp.g_varchar2_table(490) := '"USA","postal_code":"98101"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orde';
wwv_flow_imp.g_varchar2_table(491) := 'rs (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (437,to_timesta';
wwv_flow_imp.g_varchar2_table(492) := 'mp(''18-JUL-25 06.41.45.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),10,''Can';
wwv_flow_imp.g_varchar2_table(493) := 'celled'',1,json(''{"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-07-2';
wwv_flow_imp.g_varchar2_table(494) := '1"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"537 Main St","city":';
wwv_flow_imp.g_varchar2_table(495) := '"Calgary","state_province":"Alberta","country":"Canada","postal_code":"T2P 1J9"},"notes":"call on ar';
wwv_flow_imp.g_varchar2_table(496) := 'rival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_stat';
wwv_flow_imp.g_varchar2_table(497) := 'us,store_id,order_metadata) values (1111,to_timestamp(''03-DEC-25 12.42.17.000000000 PM'',''DD-MON-RR H';
wwv_flow_imp.g_varchar2_table(498) := 'H.MI.SS.FF AM'',''nls_date_language=english''),6,''Refunded'',1,json(''{"shipment":{"method":"Express","st';
wwv_flow_imp.g_varchar2_table(499) := 'atus":"Shipped","estimated_delivery":"2025-12-05"},"payment":{"method":"Cash on delivery","status":"';
wwv_flow_imp.g_varchar2_table(500) := 'Paid"},"delivery_address":{"street":"311 Main St","city":"Denver","state_province":"Colorado","count';
wwv_flow_imp.g_varchar2_table(501) := 'ry":"USA","postal_code":"80201"},"notes":null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_i';
wwv_flow_imp.g_varchar2_table(502) := 'd,order_datetime,customer_id,order_status,store_id,order_metadata) values (1119,to_timestamp(''05-DEC';
wwv_flow_imp.g_varchar2_table(503) := '-25 09.35.51.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),14,''Cancelled'',14';
wwv_flow_imp.g_varchar2_table(504) := ',json(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-12-10"},"pay';
wwv_flow_imp.g_varchar2_table(505) := 'ment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"319 Main St","city":"Edmonton"';
wwv_flow_imp.g_varchar2_table(506) := ',"state_province":"Alberta","country":"Canada","postal_code":"T5J 0N3"},"notes":null}''));'||wwv_flow.LF||
'        in';
wwv_flow_imp.g_varchar2_table(507) := 'sert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_meta';
wwv_flow_imp.g_varchar2_table(508) := 'data) values (1121,to_timestamp(''05-DEC-25 11.25.14.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_da';
wwv_flow_imp.g_varchar2_table(509) := 'te_language=english''),7,''Cancelled'',1,json(''{"shipment":{"method":"Express","status":"Delivered","es';
wwv_flow_imp.g_varchar2_table(510) := 'timated_delivery":"2025-12-07"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"s';
wwv_flow_imp.g_varchar2_table(511) := 'treet":"321 Main St","city":"Los Angeles","state_province":"California","country":"USA","postal_code';
wwv_flow_imp.g_varchar2_table(512) := '":"90001"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_d';
wwv_flow_imp.g_varchar2_table(513) := 'atetime,customer_id,order_status,store_id,order_metadata) values (1169,to_timestamp(''15-DEC-25 04.16';
wwv_flow_imp.g_varchar2_table(514) := '.06.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),14,''Paid'',1,json(''{"shipme';
wwv_flow_imp.g_varchar2_table(515) := 'nt":{"method":"Express","status":"Delivered","estimated_delivery":"2025-12-20"},"payment":{"method":';
wwv_flow_imp.g_varchar2_table(516) := '"Paypal","status":"Paid"},"delivery_address":{"street":"369 Main St","city":"San Francisco","state_p';
wwv_flow_imp.g_varchar2_table(517) := 'rovince":"California","country":"USA","postal_code":"94102"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(518) := 'insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_me';
wwv_flow_imp.g_varchar2_table(519) := 'tadata) values (1191,to_timestamp(''20-DEC-25 03.12.50.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_';
wwv_flow_imp.g_varchar2_table(520) := 'date_language=english''),14,''Paid'',1,json(''{"shipment":{"method":"Express","status":"Processing","est';
wwv_flow_imp.g_varchar2_table(521) := 'imated_delivery":"2025-12-22"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"stre';
wwv_flow_imp.g_varchar2_table(522) := 'et":"391 Main St","city":"Denver","state_province":"Colorado","country":"USA","postal_code":"80201"}';
wwv_flow_imp.g_varchar2_table(523) := ',"notes":null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,ord';
wwv_flow_imp.g_varchar2_table(524) := 'er_status,store_id,order_metadata) values (1195,to_timestamp(''21-DEC-25 06.46.35.000000000 AM'',''DD-M';
wwv_flow_imp.g_varchar2_table(525) := 'ON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),15,''Complete'',1,json(''{"shipment":{"method":"Expr';
wwv_flow_imp.g_varchar2_table(526) := 'ess","status":"Shipped","estimated_delivery":"2025-12-22"},"payment":{"method":"Cash on delivery","s';
wwv_flow_imp.g_varchar2_table(527) := 'tatus":"Paid"},"delivery_address":{"street":"395 Main St","city":"Montreal","state_province":"Quebec';
wwv_flow_imp.g_varchar2_table(528) := '","country":"Canada","postal_code":"H2X 1Y4"},"notes":null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_or';
wwv_flow_imp.g_varchar2_table(529) := 'ders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1200,to_time';
wwv_flow_imp.g_varchar2_table(530) := 'stamp(''21-DEC-25 12.24.05.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),17,''';
wwv_flow_imp.g_varchar2_table(531) := 'Open'',1,json(''{"shipment":{"method":"Standard","status":"Processing","estimated_delivery":"2025-12-2';
wwv_flow_imp.g_varchar2_table(532) := '2"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"400 Main St","city":"N';
wwv_flow_imp.g_varchar2_table(533) := 'ew York","state_province":"New York","country":"USA","postal_code":"10001"},"notes":"leave at door"}';
wwv_flow_imp.g_varchar2_table(534) := '''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,stor';
wwv_flow_imp.g_varchar2_table(535) := 'e_id,order_metadata) values (1260,to_timestamp(''30-DEC-25 01.21.21.000000000 PM'',''DD-MON-RR HH.MI.SS';
wwv_flow_imp.g_varchar2_table(536) := '.FF AM'',''nls_date_language=english''),9,''Cancelled'',9,json(''{"shipment":{"method":"Standard","status"';
wwv_flow_imp.g_varchar2_table(537) := ':"Processing","estimated_delivery":"2025-12-31"},"payment":{"method":"Card","status":"Paid"},"delive';
wwv_flow_imp.g_varchar2_table(538) := 'ry_address":{"street":"460 Main St","city":"New York","state_province":"New York","country":"USA","p';
wwv_flow_imp.g_varchar2_table(539) := 'ostal_code":"10001"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id';
wwv_flow_imp.g_varchar2_table(540) := ',order_datetime,customer_id,order_status,store_id,order_metadata) values (1321,to_timestamp(''09-JAN-';
wwv_flow_imp.g_varchar2_table(541) := '25 06.32.45.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),11,''Open'',1,json(''';
wwv_flow_imp.g_varchar2_table(542) := '{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-01-11"},"payment":{"me';
wwv_flow_imp.g_varchar2_table(543) := 'thod":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"521 Main St","city":"Los Ang';
wwv_flow_imp.g_varchar2_table(544) := 'eles","state_province":"California","country":"USA","postal_code":"90001"},"notes":"call on arrival"';
wwv_flow_imp.g_varchar2_table(545) := '}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,sto';
wwv_flow_imp.g_varchar2_table(546) := 're_id,order_metadata) values (1348,to_timestamp(''13-JAN-25 08.57.23.000000000 PM'',''DD-MON-RR HH.MI.S';
wwv_flow_imp.g_varchar2_table(547) := 'S.FF AM'',''nls_date_language=english''),18,''Complete'',18,json(''{"shipment":{"method":"Standard","statu';
wwv_flow_imp.g_varchar2_table(548) := 's":"Shipped","estimated_delivery":"2025-01-17"},"payment":{"method":"Cash on delivery","status":"Pai';
wwv_flow_imp.g_varchar2_table(549) := 'd"},"delivery_address":{"street":"548 Main St","city":"Dallas","state_province":"Texas","country":"U';
wwv_flow_imp.g_varchar2_table(550) := 'SA","postal_code":"75201"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (or';
wwv_flow_imp.g_varchar2_table(551) := 'der_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1363,to_timestamp(''1';
wwv_flow_imp.g_varchar2_table(552) := '6-JAN-25 10.00.07.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),19,''Cancelle';
wwv_flow_imp.g_varchar2_table(553) := 'd'',1,json(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025-01-20"},"pa';
wwv_flow_imp.g_varchar2_table(554) := 'yment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"563 Main St","cit';
wwv_flow_imp.g_varchar2_table(555) := 'y":"Houston","state_province":"Texas","country":"USA","postal_code":"77001"},"notes":null}''));'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(556) := '   insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order';
wwv_flow_imp.g_varchar2_table(557) := '_metadata) values (1373,to_timestamp(''18-JAN-25 03.27.07.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''n';
wwv_flow_imp.g_varchar2_table(558) := 'ls_date_language=english''),16,''Cancelled'',16,json(''{"shipment":{"method":"Express","status":"Deliver';
wwv_flow_imp.g_varchar2_table(559) := 'ed","estimated_delivery":"2025-01-22"},"payment":{"method":"Paypal","status":"Paid"},"delivery_addre';
wwv_flow_imp.g_varchar2_table(560) := 'ss":{"street":"573 Main St","city":"Miami","state_province":"Florida","country":"USA","postal_code":';
wwv_flow_imp.g_varchar2_table(561) := '"33101"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_dat';
wwv_flow_imp.g_varchar2_table(562) := 'etime,customer_id,order_status,store_id,order_metadata) values (1390,to_timestamp(''21-JAN-25 04.51.3';
wwv_flow_imp.g_varchar2_table(563) := '7.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),1,''Complete'',1,json(''{"shipm';
wwv_flow_imp.g_varchar2_table(564) := 'ent":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-01-22"},"payment":{"method":';
wwv_flow_imp.g_varchar2_table(565) := '"Cash on delivery","status":"Paid"},"delivery_address":{"street":"590 Main St","city":"Seattle","sta';
wwv_flow_imp.g_varchar2_table(566) := 'te_province":"Washington","country":"USA","postal_code":"98101"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(567) := '      insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,or';
wwv_flow_imp.g_varchar2_table(568) := 'der_metadata) values (1400,to_timestamp(''22-JAN-25 06.52.24.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM''';
wwv_flow_imp.g_varchar2_table(569) := ',''nls_date_language=english''),15,''Complete'',15,json(''{"shipment":{"method":"Standard","status":"Deli';
wwv_flow_imp.g_varchar2_table(570) := 'vered","estimated_delivery":"2025-01-23"},"payment":{"method":"Paypal","status":"Paid"},"delivery_ad';
wwv_flow_imp.g_varchar2_table(571) := 'dress":{"street":"600 Main St","city":"New York","state_province":"New York","country":"USA","postal';
wwv_flow_imp.g_varchar2_table(572) := '_code":"10001"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,orde';
wwv_flow_imp.g_varchar2_table(573) := 'r_datetime,customer_id,order_status,store_id,order_metadata) values (1418,to_timestamp(''25-JAN-25 05';
wwv_flow_imp.g_varchar2_table(574) := '.30.59.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),13,''Cancelled'',13,json(';
wwv_flow_imp.g_varchar2_table(575) := '''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-01-29"},"payment":';
wwv_flow_imp.g_varchar2_table(576) := '{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"618 Main St","city":"Ottawa","stat';
wwv_flow_imp.g_varchar2_table(577) := 'e_province":"Ontario","country":"Canada","postal_code":"K1A 0B1"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(578) := '       insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,o';
wwv_flow_imp.g_varchar2_table(579) := 'rder_metadata) values (1437,to_timestamp(''28-JAN-25 09.08.42.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM';
wwv_flow_imp.g_varchar2_table(580) := ''',''nls_date_language=english''),16,''Cancelled'',16,json(''{"shipment":{"method":"Express","status":"Pro';
wwv_flow_imp.g_varchar2_table(581) := 'cessing","estimated_delivery":"2025-01-31"},"payment":{"method":"Card","status":"Paid"},"delivery_ad';
wwv_flow_imp.g_varchar2_table(582) := 'dress":{"street":"637 Main St","city":"Calgary","state_province":"Alberta","country":"Canada","posta';
wwv_flow_imp.g_varchar2_table(583) := 'l_code":"T2P 1J9"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id';
wwv_flow_imp.g_varchar2_table(584) := ',order_datetime,customer_id,order_status,store_id,order_metadata) values (1439,to_timestamp(''29-JAN-';
wwv_flow_imp.g_varchar2_table(585) := '25 04.52.36.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),16,''Paid'',1,json(''';
wwv_flow_imp.g_varchar2_table(586) := '{"shipment":{"method":"Express","status":"Delivered","estimated_delivery":"2025-02-03"},"payment":{"';
wwv_flow_imp.g_varchar2_table(587) := 'method":"Paypal","status":"Paid"},"delivery_address":{"street":"639 Main St","city":"Edmonton","stat';
wwv_flow_imp.g_varchar2_table(588) := 'e_province":"Alberta","country":"Canada","postal_code":"T5J 0N3"},"notes":null}''));'||wwv_flow.LF||
'        insert i';
wwv_flow_imp.g_varchar2_table(589) := 'nto eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) ';
wwv_flow_imp.g_varchar2_table(590) := 'values (1448,to_timestamp(''31-JAN-25 07.09.51.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_lan';
wwv_flow_imp.g_varchar2_table(591) := 'guage=english''),16,''Open'',1,json(''{"shipment":{"method":"Standard","status":"Delivered","estimated_d';
wwv_flow_imp.g_varchar2_table(592) := 'elivery":"2025-02-04"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"6';
wwv_flow_imp.g_varchar2_table(593) := '48 Main St","city":"Dallas","state_province":"Texas","country":"USA","postal_code":"75201"},"notes":';
wwv_flow_imp.g_varchar2_table(594) := '"leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,o';
wwv_flow_imp.g_varchar2_table(595) := 'rder_status,store_id,order_metadata) values (1450,to_timestamp(''31-JAN-25 07.56.41.000000000 AM'',''DD';
wwv_flow_imp.g_varchar2_table(596) := '-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),6,''Complete'',1,json(''{"shipment":{"method":"Sta';
wwv_flow_imp.g_varchar2_table(597) := 'ndard","status":"Shipped","estimated_delivery":"2025-02-01"},"payment":{"method":"Cash on delivery",';
wwv_flow_imp.g_varchar2_table(598) := '"status":"Paid"},"delivery_address":{"street":"650 Main St","city":"Seattle","state_province":"Washi';
wwv_flow_imp.g_varchar2_table(599) := 'ngton","country":"USA","postal_code":"98101"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
'        insert into e';
wwv_flow_imp.g_varchar2_table(600) := 'ba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) value';
wwv_flow_imp.g_varchar2_table(601) := 's (1451,to_timestamp(''31-JAN-25 08.10.59.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language';
wwv_flow_imp.g_varchar2_table(602) := '=english''),16,''Paid'',16,json(''{"shipment":{"method":"Express","status":"Delivered","estimated_delive';
wwv_flow_imp.g_varchar2_table(603) := 'ry":"2025-02-02"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"651 Ma';
wwv_flow_imp.g_varchar2_table(604) := 'in St","city":"Denver","state_province":"Colorado","country":"USA","postal_code":"80201"},"notes":nu';
wwv_flow_imp.g_varchar2_table(605) := 'll}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,s';
wwv_flow_imp.g_varchar2_table(606) := 'tore_id,order_metadata) values (1455,to_timestamp(''01-FEB-25 03.40.10.000000000 AM'',''DD-MON-RR HH.MI';
wwv_flow_imp.g_varchar2_table(607) := '.SS.FF AM'',''nls_date_language=english''),4,''Complete'',1,json(''{"shipment":{"method":"Express","status';
wwv_flow_imp.g_varchar2_table(608) := '":"Processing","estimated_delivery":"2025-02-02"},"payment":{"method":"Card","status":"Paid"},"deliv';
wwv_flow_imp.g_varchar2_table(609) := 'ery_address":{"street":"655 Main St","city":"Montreal","state_province":"Quebec","country":"Canada",';
wwv_flow_imp.g_varchar2_table(610) := '"postal_code":"H2X 1Y4"},"notes":null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_';
wwv_flow_imp.g_varchar2_table(611) := 'datetime,customer_id,order_status,store_id,order_metadata) values (1468,to_timestamp(''02-FEB-25 02.2';
wwv_flow_imp.g_varchar2_table(612) := '7.01.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),4,''Complete'',1,json(''{"sh';
wwv_flow_imp.g_varchar2_table(613) := 'ipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-02-06"},"payment":{"metho';
wwv_flow_imp.g_varchar2_table(614) := 'd":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"668 Main St","city":"Dallas","s';
wwv_flow_imp.g_varchar2_table(615) := 'tate_province":"Texas","country":"USA","postal_code":"75201"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(616) := 'nsert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_met';
wwv_flow_imp.g_varchar2_table(617) := 'adata) values (1471,to_timestamp(''02-FEB-25 07.29.40.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_d';
wwv_flow_imp.g_varchar2_table(618) := 'ate_language=english''),14,''Paid'',14,json(''{"shipment":{"method":"Express","status":"Shipped","estima';
wwv_flow_imp.g_varchar2_table(619) := 'ted_delivery":"2025-02-04"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_addres';
wwv_flow_imp.g_varchar2_table(620) := 's":{"street":"671 Main St","city":"Denver","state_province":"Colorado","country":"USA","postal_code"';
wwv_flow_imp.g_varchar2_table(621) := ':"80201"},"notes":null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,custom';
wwv_flow_imp.g_varchar2_table(622) := 'er_id,order_status,store_id,order_metadata) values (1483,to_timestamp(''04-FEB-25 08.09.09.000000000 ';
wwv_flow_imp.g_varchar2_table(623) := 'AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),14,''Refunded'',14,json(''{"shipment":{"met';
wwv_flow_imp.g_varchar2_table(624) := 'hod":"Express","status":"Shipped","estimated_delivery":"2025-02-08"},"payment":{"method":"Cash on de';
wwv_flow_imp.g_varchar2_table(625) := 'livery","status":"Paid"},"delivery_address":{"street":"683 Main St","city":"Houston","state_province';
wwv_flow_imp.g_varchar2_table(626) := '":"Texas","country":"USA","postal_code":"77001"},"notes":null}''));'||wwv_flow.LF||
'        insert into eba_demo_json';
wwv_flow_imp.g_varchar2_table(627) := '_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1486,to_t';
wwv_flow_imp.g_varchar2_table(628) := 'imestamp(''05-FEB-25 04.35.40.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),1';
wwv_flow_imp.g_varchar2_table(629) := '5,''Complete'',15,json(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025';
wwv_flow_imp.g_varchar2_table(630) := '-02-07"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"686 M';
wwv_flow_imp.g_varchar2_table(631) := 'ain St","city":"San Antonio","state_province":"Texas","country":"USA","postal_code":"78201"},"notes"';
wwv_flow_imp.g_varchar2_table(632) := ':"hand to recipient"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer';
wwv_flow_imp.g_varchar2_table(633) := '_id,order_status,store_id,order_metadata) values (1491,to_timestamp(''05-FEB-25 09.16.42.000000000 PM';
wwv_flow_imp.g_varchar2_table(634) := ''',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),1,''Open'',1,json(''{"shipment":{"method":"Ex';
wwv_flow_imp.g_varchar2_table(635) := 'press","status":"Processing","estimated_delivery":"2025-02-07"},"payment":{"method":"Card","status":';
wwv_flow_imp.g_varchar2_table(636) := '"Paid"},"delivery_address":{"street":"691 Main St","city":"Denver","state_province":"Colorado","coun';
wwv_flow_imp.g_varchar2_table(637) := 'try":"USA","postal_code":"80201"},"notes":null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_';
wwv_flow_imp.g_varchar2_table(638) := 'id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1498,to_timestamp(''06-FE';
wwv_flow_imp.g_varchar2_table(639) := 'B-25 06.40.27.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),13,''Complete'',13';
wwv_flow_imp.g_varchar2_table(640) := ',json(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2025-02-10"},"payme';
wwv_flow_imp.g_varchar2_table(641) := 'nt":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"698 Main St","city":';
wwv_flow_imp.g_varchar2_table(642) := '"Ottawa","state_province":"Ontario","country":"Canada","postal_code":"K1A 0B1"},"notes":"hand to rec';
wwv_flow_imp.g_varchar2_table(643) := 'ipient"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_sta';
wwv_flow_imp.g_varchar2_table(644) := 'tus,store_id,order_metadata) values (1513,to_timestamp(''09-FEB-25 05.17.37.000000000 PM'',''DD-MON-RR ';
wwv_flow_imp.g_varchar2_table(645) := 'HH.MI.SS.FF AM'',''nls_date_language=english''),20,''Cancelled'',1,json(''{"shipment":{"method":"Express",';
wwv_flow_imp.g_varchar2_table(646) := '"status":"Shipped","estimated_delivery":"2025-02-13"},"payment":{"method":"Cash on delivery","status';
wwv_flow_imp.g_varchar2_table(647) := '":"Paid"},"delivery_address":{"street":"713 Main St","city":"Miami","state_province":"Florida","coun';
wwv_flow_imp.g_varchar2_table(648) := 'try":"USA","postal_code":"33101"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_o';
wwv_flow_imp.g_varchar2_table(649) := 'rders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1520,to_tim';
wwv_flow_imp.g_varchar2_table(650) := 'estamp(''10-FEB-25 12.46.23.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),3,''';
wwv_flow_imp.g_varchar2_table(651) := 'Cancelled'',1,json(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-';
wwv_flow_imp.g_varchar2_table(652) := '02-11"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"720 Main St","ci';
wwv_flow_imp.g_varchar2_table(653) := 'ty":"New York","state_province":"New York","country":"USA","postal_code":"10001"},"notes":"leave at ';
wwv_flow_imp.g_varchar2_table(654) := 'door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_statu';
wwv_flow_imp.g_varchar2_table(655) := 's,store_id,order_metadata) values (1525,to_timestamp(''11-FEB-25 02.22.05.000000000 AM'',''DD-MON-RR HH';
wwv_flow_imp.g_varchar2_table(656) := '.MI.SS.FF AM'',''nls_date_language=english''),10,''Complete'',1,json(''{"shipment":{"method":"Express","st';
wwv_flow_imp.g_varchar2_table(657) := 'atus":"Shipped","estimated_delivery":"2025-02-12"},"payment":{"method":"Cash on delivery","status":"';
wwv_flow_imp.g_varchar2_table(658) := 'Paid"},"delivery_address":{"street":"725 Main St","city":"Philadelphia","state_province":"Pennsylvan';
wwv_flow_imp.g_varchar2_table(659) := 'ia","country":"USA","postal_code":"19101"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_de';
wwv_flow_imp.g_varchar2_table(660) := 'mo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (15';
wwv_flow_imp.g_varchar2_table(661) := '43,to_timestamp(''13-FEB-25 12.54.09.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=engl';
wwv_flow_imp.g_varchar2_table(662) := 'ish''),8,''Open'',1,json(''{"shipment":{"method":"Express","status":"Shipped","estimated_delivery":"2025';
wwv_flow_imp.g_varchar2_table(663) := '-02-17"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"743 M';
wwv_flow_imp.g_varchar2_table(664) := 'ain St","city":"Houston","state_province":"Texas","country":"USA","postal_code":"77001"},"notes":nul';
wwv_flow_imp.g_varchar2_table(665) := 'l}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,st';
wwv_flow_imp.g_varchar2_table(666) := 'ore_id,order_metadata) values (1549,to_timestamp(''13-FEB-25 05.28.26.000000000 PM'',''DD-MON-RR HH.MI.';
wwv_flow_imp.g_varchar2_table(667) := 'SS.FF AM'',''nls_date_language=english''),19,''Refunded'',1,json(''{"shipment":{"method":"Express","status';
wwv_flow_imp.g_varchar2_table(668) := '":"Shipped","estimated_delivery":"2025-02-18"},"payment":{"method":"Cash on delivery","status":"Paid';
wwv_flow_imp.g_varchar2_table(669) := '"},"delivery_address":{"street":"749 Main St","city":"San Francisco","state_province":"California","';
wwv_flow_imp.g_varchar2_table(670) := 'country":"USA","postal_code":"94102"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_js';
wwv_flow_imp.g_varchar2_table(671) := 'on_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1552,to';
wwv_flow_imp.g_varchar2_table(672) := '_timestamp(''14-FEB-25 01.13.25.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english'')';
wwv_flow_imp.g_varchar2_table(673) := ',17,''Cancelled'',17,json(''{"shipment":{"method":"Standard","status":"Shipped","estimated_delivery":"2';
wwv_flow_imp.g_varchar2_table(674) := '025-02-17"},"payment":{"method":"Cash on delivery","status":"Paid"},"delivery_address":{"street":"75';
wwv_flow_imp.g_varchar2_table(675) := '2 Main St","city":"Boston","state_province":"Massachusetts","country":"USA","postal_code":"02108"},"';
wwv_flow_imp.g_varchar2_table(676) := 'notes":"leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,custom';
wwv_flow_imp.g_varchar2_table(677) := 'er_id,order_status,store_id,order_metadata) values (1555,to_timestamp(''14-FEB-25 04.22.00.000000000 ';
wwv_flow_imp.g_varchar2_table(678) := 'AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),7,''Cancelled'',7,json(''{"shipment":{"meth';
wwv_flow_imp.g_varchar2_table(679) := 'od":"Express","status":"Shipped","estimated_delivery":"2025-02-15"},"payment":{"method":"Cash on del';
wwv_flow_imp.g_varchar2_table(680) := 'ivery","status":"Paid"},"delivery_address":{"street":"755 Main St","city":"Montreal","state_province';
wwv_flow_imp.g_varchar2_table(681) := '":"Quebec","country":"Canada","postal_code":"H2X 1Y4"},"notes":null}''));'||wwv_flow.LF||
'        insert into eba_dem';
wwv_flow_imp.g_varchar2_table(682) := 'o_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (156';
wwv_flow_imp.g_varchar2_table(683) := '0,to_timestamp(''14-FEB-25 06.38.06.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=engli';
wwv_flow_imp.g_varchar2_table(684) := 'sh''),14,''Complete'',1,json(''{"shipment":{"method":"Standard","status":"Processing","estimated_deliver';
wwv_flow_imp.g_varchar2_table(685) := 'y":"2025-02-15"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"760 Main ';
wwv_flow_imp.g_varchar2_table(686) := 'St","city":"New York","state_province":"New York","country":"USA","postal_code":"10001"},"notes":"le';
wwv_flow_imp.g_varchar2_table(687) := 'ave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,orde';
wwv_flow_imp.g_varchar2_table(688) := 'r_status,store_id,order_metadata) values (1561,to_timestamp(''14-FEB-25 09.01.04.000000000 PM'',''DD-MO';
wwv_flow_imp.g_varchar2_table(689) := 'N-RR HH.MI.SS.FF AM'',''nls_date_language=english''),8,''Complete'',8,json(''{"shipment":{"method":"Expres';
wwv_flow_imp.g_varchar2_table(690) := 's","status":"Shipped","estimated_delivery":"2025-02-16"},"payment":{"method":"Cash on delivery","sta';
wwv_flow_imp.g_varchar2_table(691) := 'tus":"Paid"},"delivery_address":{"street":"761 Main St","city":"Los Angeles","state_province":"Calif';
wwv_flow_imp.g_varchar2_table(692) := 'ornia","country":"USA","postal_code":"90001"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba';
wwv_flow_imp.g_varchar2_table(693) := '_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values ';
wwv_flow_imp.g_varchar2_table(694) := '(1635,to_timestamp(''26-FEB-25 02.22.36.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=e';
wwv_flow_imp.g_varchar2_table(695) := 'nglish''),11,''Cancelled'',11,json(''{"shipment":{"method":"Express","status":"Processing","estimated_de';
wwv_flow_imp.g_varchar2_table(696) := 'livery":"2025-02-27"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"835 ';
wwv_flow_imp.g_varchar2_table(697) := 'Main St","city":"Montreal","state_province":"Quebec","country":"Canada","postal_code":"H2X 1Y4"},"no';
wwv_flow_imp.g_varchar2_table(698) := 'tes":null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_s';
wwv_flow_imp.g_varchar2_table(699) := 'tatus,store_id,order_metadata) values (1637,to_timestamp(''26-FEB-25 03.21.00.000000000 PM'',''DD-MON-R';
wwv_flow_imp.g_varchar2_table(700) := 'R HH.MI.SS.FF AM'',''nls_date_language=english''),12,''Complete'',1,json(''{"shipment":{"method":"Express"';
wwv_flow_imp.g_varchar2_table(701) := ',"status":"Delivered","estimated_delivery":"2025-03-01"},"payment":{"method":"Paypal","status":"Paid';
wwv_flow_imp.g_varchar2_table(702) := '"},"delivery_address":{"street":"837 Main St","city":"Calgary","state_province":"Alberta","country":';
wwv_flow_imp.g_varchar2_table(703) := '"Canada","postal_code":"T2P 1J9"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_o';
wwv_flow_imp.g_varchar2_table(704) := 'rders (order_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1659,to_tim';
wwv_flow_imp.g_varchar2_table(705) := 'estamp(''02-MAR-25 02.20.04.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),18,';
wwv_flow_imp.g_varchar2_table(706) := '''Cancelled'',18,json(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"202';
wwv_flow_imp.g_varchar2_table(707) := '5-03-07"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"859 Main St","ci';
wwv_flow_imp.g_varchar2_table(708) := 'ty":"Edmonton","state_province":"Alberta","country":"Canada","postal_code":"T5J 0N3"},"notes":null}''';
wwv_flow_imp.g_varchar2_table(709) := '));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store';
wwv_flow_imp.g_varchar2_table(710) := '_id,order_metadata) values (1730,to_timestamp(''15-MAR-25 03.38.39.000000000 PM'',''DD-MON-RR HH.MI.SS.';
wwv_flow_imp.g_varchar2_table(711) := 'FF AM'',''nls_date_language=english''),10,''Refunded'',10,json(''{"shipment":{"method":"Standard","status"';
wwv_flow_imp.g_varchar2_table(712) := ':"Delivered","estimated_delivery":"2025-03-16"},"payment":{"method":"Paypal","status":"Paid"},"deliv';
wwv_flow_imp.g_varchar2_table(713) := 'ery_address":{"street":"930 Main St","city":"Seattle","state_province":"Washington","country":"USA",';
wwv_flow_imp.g_varchar2_table(714) := '"postal_code":"98101"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (or';
wwv_flow_imp.g_varchar2_table(715) := 'der_id,order_datetime,customer_id,order_status,store_id,order_metadata) values (1731,to_timestamp(''1';
wwv_flow_imp.g_varchar2_table(716) := '6-MAR-25 09.57.43.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),19,''Cancelle';
wwv_flow_imp.g_varchar2_table(717) := 'd'',19,json(''{"shipment":{"method":"Express","status":"Processing","estimated_delivery":"2025-03-18"}';
wwv_flow_imp.g_varchar2_table(718) := ',"payment":{"method":"Card","status":"Paid"},"delivery_address":{"street":"931 Main St","city":"Denv';
wwv_flow_imp.g_varchar2_table(719) := 'er","state_province":"Colorado","country":"USA","postal_code":"80201"},"notes":null}''));'||wwv_flow.LF||
'        ins';
wwv_flow_imp.g_varchar2_table(720) := 'ert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_metad';
wwv_flow_imp.g_varchar2_table(721) := 'ata) values (1776,to_timestamp(''24-MAR-25 12.05.43.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_dat';
wwv_flow_imp.g_varchar2_table(722) := 'e_language=english''),20,''Complete'',20,json(''{"shipment":{"method":"Standard","status":"Processing","';
wwv_flow_imp.g_varchar2_table(723) := 'estimated_delivery":"2025-03-26"},"payment":{"method":"Card","status":"Paid"},"delivery_address":{"s';
wwv_flow_imp.g_varchar2_table(724) := 'treet":"976 Main St","city":"Vancouver","state_province":"British Columbia","country":"Canada","post';
wwv_flow_imp.g_varchar2_table(725) := 'al_code":"V5K 0A1"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,';
wwv_flow_imp.g_varchar2_table(726) := 'order_datetime,customer_id,order_status,store_id,order_metadata) values (1808,to_timestamp(''29-MAR-2';
wwv_flow_imp.g_varchar2_table(727) := '5 11.37.35.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),20,''Refunded'',20,js';
wwv_flow_imp.g_varchar2_table(728) := 'on(''{"shipment":{"method":"Standard","status":"Delivered","estimated_delivery":"2025-04-02"},"paymen';
wwv_flow_imp.g_varchar2_table(729) := 't":{"method":"Paypal","status":"Paid"},"delivery_address":{"street":"108 Main St","city":"Dallas","s';
wwv_flow_imp.g_varchar2_table(730) := 'tate_province":"Texas","country":"USA","postal_code":"75201"},"notes":"leave at door"}''));'||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(731) := 'nsert into eba_demo_json_orders (order_id,order_datetime,customer_id,order_status,store_id,order_met';
wwv_flow_imp.g_varchar2_table(732) := 'adata) values (1817,to_timestamp(''31-MAR-25 10.58.36.000000000 AM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_d';
wwv_flow_imp.g_varchar2_table(733) := 'ate_language=english''),8,''Cancelled'',8,json(''{"shipment":{"method":"Express","status":"Delivered","e';
wwv_flow_imp.g_varchar2_table(734) := 'stimated_delivery":"2025-04-03"},"payment":{"method":"Paypal","status":"Paid"},"delivery_address":{"';
wwv_flow_imp.g_varchar2_table(735) := 'street":"117 Main St","city":"Calgary","state_province":"Alberta","country":"Canada","postal_code":"';
wwv_flow_imp.g_varchar2_table(736) := 'T2P 1J9"},"notes":"call on arrival"}''));'||wwv_flow.LF||
'        insert into eba_demo_json_orders (order_id,order_da';
wwv_flow_imp.g_varchar2_table(737) := 'tetime,customer_id,order_status,store_id,order_metadata) values (1890,to_timestamp(''15-APR-25 12.36.';
wwv_flow_imp.g_varchar2_table(738) := '09.000000000 PM'',''DD-MON-RR HH.MI.SS.FF AM'',''nls_date_language=english''),7,''Refunded'',7,json(''{"ship';
wwv_flow_imp.g_varchar2_table(739) := 'ment":{"method":"Standard","status":"Processing","estimated_delivery":"2025-04-16"},"payment":{"meth';
wwv_flow_imp.g_varchar2_table(740) := 'od":"Card","status":"Paid"},"delivery_address":{"street":"190 Main St","city":"Seattle","state_provi';
wwv_flow_imp.g_varchar2_table(741) := 'nce":"Washington","country":"USA","postal_code":"98101"},"notes":"hand to recipient"}''));'||wwv_flow.LF||
'       --P';
wwv_flow_imp.g_varchar2_table(742) := 'roducts data'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_';
wwv_flow_imp.g_varchar2_table(743) := 'details) values (16,''Women''''s Socks (Grey)'',39.89,null);'||wwv_flow.LF||
'        insert into eba_demo_json_products ';
wwv_flow_imp.g_varchar2_table(744) := '(product_id,product_name,unit_price,product_details) values (17,''Women''''s Sweater (Brown)'',24.46,jso';
wwv_flow_imp.g_varchar2_table(745) := 'n(''{"colour":"brown","gender":"Women''''s","brand":"KLUGGER","description":"Dolore adipisicing commodo';
wwv_flow_imp.g_varchar2_table(746) := ' consequat Lorem ut incididunt. Ullamco nulla qui qui pariatur qui officia adipisicing magna aliqua ';
wwv_flow_imp.g_varchar2_table(747) := 'ex qui incididunt.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":7,"review":"Fugiat ci';
wwv_flow_imp.g_varchar2_table(748) := 'llum anim in qui laborum velit eu consectetur ad fugiat."},{"rating":6,"review":"Elit duis nostrud a';
wwv_flow_imp.g_varchar2_table(749) := 'd non enim elit mollit deserunt."},{"rating":2,"review":"Amet anim mollit laboris deserunt deserunt ';
wwv_flow_imp.g_varchar2_table(750) := 'laboris anim ad commodo dolor."},{"rating":7,"review":"Labore nulla ullamco aute labore esse do proi';
wwv_flow_imp.g_varchar2_table(751) := 'dent sit."},{"rating":5,"review":"Non amet cillum eu cillum cupidatat occaecat excepteur ad voluptat';
wwv_flow_imp.g_varchar2_table(752) := 'e culpa id."},{"rating":4,"review":"Non aliqua nisi anim qui consectetur id dolore duis sint aliqua ';
wwv_flow_imp.g_varchar2_table(753) := 'ea tempor laborum."},{"rating":5,"review":"Elit ea Lorem duis amet."},{"rating":10,"review":"Aliqua ';
wwv_flow_imp.g_varchar2_table(754) := 'velit nulla exercitation dolor minim ipsum culpa nostrud occaecat proident voluptate."},{"rating":3,';
wwv_flow_imp.g_varchar2_table(755) := '"review":"Exercitation anim eu et veniam tempor ea."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_produc';
wwv_flow_imp.g_varchar2_table(756) := 'ts (product_id,product_name,unit_price,product_details) values (18,''Women''''s Jacket (Black)'',14.34,n';
wwv_flow_imp.g_varchar2_table(757) := 'ull);'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_details';
wwv_flow_imp.g_varchar2_table(758) := ') values (19,''Men''''s Coat (Red)'',28.21,json(''{"colour":"red","gender":"Men''''s","brand":"VELOS","desc';
wwv_flow_imp.g_varchar2_table(759) := 'ription":"Sint quis dolor in dolore sint elit ullamco ex magna laborum id eu. Magna fugiat qui paria';
wwv_flow_imp.g_varchar2_table(760) := 'tur dolore ex est esse minim elit velit.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating"';
wwv_flow_imp.g_varchar2_table(761) := ':7,"review":"Esse velit est cupidatat ea labore cupidatat ipsum ullamco cupidatat Lorem."}]}''));'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(762) := '     insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values ';
wwv_flow_imp.g_varchar2_table(763) := '(20,''Girl''''s Shorts (Green)'',38.34,json(''{"colour":"green","gender":"Girl''''s","brand":"TRASOLA","des';
wwv_flow_imp.g_varchar2_table(764) := 'cription":"These shorts are perfect for a day out at sea. Made with quick-drying and breathable mate';
wwv_flow_imp.g_varchar2_table(765) := 'rials, they are comfortable to wear even in hot and humid conditions.","sizes":["1 Yr","2 Yr","3-4 Y';
wwv_flow_imp.g_varchar2_table(766) := 'r","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Veniam consectetur ea nisi irure au';
wwv_flow_imp.g_varchar2_table(767) := 'te cillum."},{"rating":8,"review":"Consequat ex incididunt pariatur mollit magna incididunt veniam p';
wwv_flow_imp.g_varchar2_table(768) := 'ariatur aliqua ex exercitation aute mollit ullamco."},{"rating":4,"review":"Proident tempor cupidata';
wwv_flow_imp.g_varchar2_table(769) := 't ut cillum nisi sunt consectetur veniam dolore est ut."},{"rating":8,"review":"Deserunt amet quis d';
wwv_flow_imp.g_varchar2_table(770) := 'o duis nulla officia anim sint do eiusmod exercitation."},{"rating":5,"review":"Anim magna incididun';
wwv_flow_imp.g_varchar2_table(771) := 't mollit deserunt proident veniam occaecat ex ut ex incididunt."},{"rating":4,"review":"Consectetur ';
wwv_flow_imp.g_varchar2_table(772) := 'cillum minim dolore cupidatat esse."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,p';
wwv_flow_imp.g_varchar2_table(773) := 'roduct_name,unit_price,product_details) values (21,''Girl''''s Pyjamas (White)'',39.78,json(''{"colour":"';
wwv_flow_imp.g_varchar2_table(774) := 'black","gender":"Girl''''s","brand":"UTARIAN","description":"Fugiat adipisicing sunt ullamco est ea. D';
wwv_flow_imp.g_varchar2_table(775) := 'olor excepteur sit ad eu.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{';
wwv_flow_imp.g_varchar2_table(776) := '"rating":7,"review":"Proident consequat consequat eu enim Lorem incididunt ad amet excepteur tempor ';
wwv_flow_imp.g_varchar2_table(777) := 'aliquip ad aliquip ea."},{"rating":7,"review":"Nulla sint anim aliqua laboris sint eu adipisicing in';
wwv_flow_imp.g_varchar2_table(778) := 'cididunt."},{"rating":10,"review":"Aliqua aliquip non commodo duis consequat ad nisi et magna."},{"r';
wwv_flow_imp.g_varchar2_table(779) := 'ating":9,"review":"Tempor consequat Lorem ipsum proident do nisi est dolore."},{"rating":7,"review":';
wwv_flow_imp.g_varchar2_table(780) := '"Pariatur amet laborum dolor dolore incididunt sint labore."},{"rating":10,"review":"Eu exercitation';
wwv_flow_imp.g_varchar2_table(781) := ' incididunt et est."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit';
wwv_flow_imp.g_varchar2_table(782) := '_price,product_details) values (22,''Men''''s Shorts (Black)'',10.33,json(''{"colour":"black","gender":"M';
wwv_flow_imp.g_varchar2_table(783) := 'en''''s","brand":"TERSANKI","description":"Occaecat veniam do aliqua irure consectetur ea fugiat aliqu';
wwv_flow_imp.g_varchar2_table(784) := 'a qui ea veniam officia. Culpa officia Lorem dolor ullamco culpa adipisicing qui exercitation labore';
wwv_flow_imp.g_varchar2_table(785) := ' minim exercitation sunt.","sizes":["XS","S","M","L","XL","XXL"],"reviews":[{"rating":3,"review":"Co';
wwv_flow_imp.g_varchar2_table(786) := 'nsequat anim reprehenderit commodo non aliqua laborum aute."},{"rating":6,"review":"Labore cillum do';
wwv_flow_imp.g_varchar2_table(787) := ' qui magna culpa ea excepteur quis."},{"rating":1,"review":"Dolor amet quis ea magna."},{"rating":7,';
wwv_flow_imp.g_varchar2_table(788) := '"review":"Minim sit nostrud anim nostrud excepteur nostrud ea ex veniam consectetur elit."}]}''));'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(789) := '      insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values';
wwv_flow_imp.g_varchar2_table(790) := ' (23,''Men''''s Pyjamas (Blue)'',48.39,json(''{"colour":"blue","gender":"Men''''s","brand":"ADORNICA","desc';
wwv_flow_imp.g_varchar2_table(791) := 'ription":"Irure amet Lorem consequat aliquip officia dolore amet officia. Do elit laboris non dolore';
wwv_flow_imp.g_varchar2_table(792) := ' nostrud dolore cupidatat ea quis aliquip ex aliquip non ex.","sizes":["XS","S","M","L","XL","XXL"],';
wwv_flow_imp.g_varchar2_table(793) := '"reviews":[{"rating":3,"review":"Laboris elit pariatur labore duis fugiat ad in nulla tempor."},{"ra';
wwv_flow_imp.g_varchar2_table(794) := 'ting":5,"review":"Voluptate minim officia id excepteur."},{"rating":8,"review":"Eiusmod cupidatat et';
wwv_flow_imp.g_varchar2_table(795) := ' nisi ipsum non aliqua."},{"rating":1,"review":"Aute veniam irure dolor laborum esse ut ex tempor no';
wwv_flow_imp.g_varchar2_table(796) := 'n velit."},{"rating":2,"review":"Nostrud nostrud mollit incididunt et tempor excepteur sit ut id exe';
wwv_flow_imp.g_varchar2_table(797) := 'rcitation."},{"rating":6,"review":"Labore tempor cillum laborum commodo et sit est qui aute enim id ';
wwv_flow_imp.g_varchar2_table(798) := 'aute."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product';
wwv_flow_imp.g_varchar2_table(799) := '_details) values (24,''Boy''''s Sweater (Red)'',9.8,json(''{"colour":"red","gender":"Boy''''s","brand":"PHA';
wwv_flow_imp.g_varchar2_table(800) := 'RMEX","description":"Ex occaecat nulla esse duis nulla laboris aute. Commodo magna Lorem exercitatio';
wwv_flow_imp.g_varchar2_table(801) := 'n occaecat do anim minim non ad non ex do nulla ad.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Y';
wwv_flow_imp.g_varchar2_table(802) := 'r","9-10 Yr"],"reviews":[{"rating":7,"review":"Ea reprehenderit occaecat commodo exercitation ut adi';
wwv_flow_imp.g_varchar2_table(803) := 'pisicing laboris adipisicing ex aute reprehenderit nisi sint qui."},{"rating":8,"review":"Qui anim s';
wwv_flow_imp.g_varchar2_table(804) := 'int dolore id dolor proident occaecat."},{"rating":5,"review":"Dolore fugiat mollit Lorem aliqua id ';
wwv_flow_imp.g_varchar2_table(805) := 'consequat irure veniam."},{"rating":2,"review":"Esse dolore occaecat consectetur sit sit labore exer';
wwv_flow_imp.g_varchar2_table(806) := 'citation sint occaecat quis enim occaecat."},{"rating":4,"review":"Do commodo do laboris qui minim f';
wwv_flow_imp.g_varchar2_table(807) := 'ugiat nisi nostrud elit."},{"rating":7,"review":"Pariatur eu non eiusmod ex dolor veniam."},{"rating';
wwv_flow_imp.g_varchar2_table(808) := '":3,"review":"Magna aliqua dolor sint anim aliquip officia officia esse labore do."}]}''));'||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(809) := 'nsert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (25,''G';
wwv_flow_imp.g_varchar2_table(810) := 'irl''''s Jeans (Grey)'',48.75,json(''{"colour":"grey","gender":"Girl''''s","brand":"KINETICUT","descriptio';
wwv_flow_imp.g_varchar2_table(811) := 'n":"Ut aliqua nostrud exercitation cupidatat cupidatat in. Sit tempor eu cillum quis incididunt cons';
wwv_flow_imp.g_varchar2_table(812) := 'ectetur quis amet.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating';
wwv_flow_imp.g_varchar2_table(813) := '":2,"review":"Id consectetur minim anim nisi occaecat elit labore duis."},{"rating":5,"review":"Ut f';
wwv_flow_imp.g_varchar2_table(814) := 'ugiat qui velit fugiat nostrud ea dolor amet magna id pariatur."},{"rating":3,"review":"Labore labor';
wwv_flow_imp.g_varchar2_table(815) := 'um eiusmod qui minim exercitation."},{"rating":4,"review":"Excepteur ea mollit ad pariatur mollit ve';
wwv_flow_imp.g_varchar2_table(816) := 'niam."},{"rating":9,"review":"Consectetur aliquip deserunt fugiat excepteur elit occaecat culpa fugi';
wwv_flow_imp.g_varchar2_table(817) := 'at dolor in."},{"rating":1,"review":"Adipisicing adipisicing mollit reprehenderit ex nulla in ea ad ';
wwv_flow_imp.g_varchar2_table(818) := 'exercitation irure ullamco."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_n';
wwv_flow_imp.g_varchar2_table(819) := 'ame,unit_price,product_details) values (26,''Girl''''s Hoodie (White)'',39.91,json(''{"colour":"white","g';
wwv_flow_imp.g_varchar2_table(820) := 'ender":"Girl''''s","brand":"PROXSOFT","description":"Aliquip culpa eu deserunt ex culpa in laborum adi';
wwv_flow_imp.g_varchar2_table(821) := 'pisicing. Amet et id minim esse ea non qui veniam.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr';
wwv_flow_imp.g_varchar2_table(822) := '","9-10 Yr"],"reviews":[{"rating":6,"review":"Commodo ut fugiat voluptate adipisicing deserunt."},{"';
wwv_flow_imp.g_varchar2_table(823) := 'rating":4,"review":"Fugiat cupidatat amet fugiat cupidatat ea ea."},{"rating":7,"review":"Incididunt';
wwv_flow_imp.g_varchar2_table(824) := ' ex enim commodo sit consequat enim."},{"rating":3,"review":"Ullamco in et aute laboris cillum."},{"';
wwv_flow_imp.g_varchar2_table(825) := 'rating":3,"review":"Reprehenderit Lorem proident sit deserunt do tempor commodo velit velit nulla ip';
wwv_flow_imp.g_varchar2_table(826) := 'sum."},{"rating":10,"review":"Dolore pariatur velit enim est culpa eiusmod cupidatat deserunt esse e';
wwv_flow_imp.g_varchar2_table(827) := 'lit exercitation sunt proident exercitation."},{"rating":2,"review":"Minim fugiat elit aliquip nostr';
wwv_flow_imp.g_varchar2_table(828) := 'ud velit reprehenderit cillum."},{"rating":4,"review":"Sint Lorem est laborum consectetur pariatur m';
wwv_flow_imp.g_varchar2_table(829) := 'inim tempor ullamco Lorem est."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,produc';
wwv_flow_imp.g_varchar2_table(830) := 't_name,unit_price,product_details) values (27,''Boy''''s Coat (Blue)'',10.24,json(''{"colour":"brown","ge';
wwv_flow_imp.g_varchar2_table(831) := 'nder":"Boy''''s","brand":"GRONK","description":"Quis aliquip fugiat sunt qui eu velit aliqua sint eius';
wwv_flow_imp.g_varchar2_table(832) := 'mod mollit id ad. Anim anim ipsum in reprehenderit amet amet consectetur incididunt qui cillum Lorem';
wwv_flow_imp.g_varchar2_table(833) := '.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":8,"review":"Sit';
wwv_flow_imp.g_varchar2_table(834) := ' id elit cupidatat aute consectetur esse proident aliqua ad voluptate cillum Lorem."},{"rating":6,"r';
wwv_flow_imp.g_varchar2_table(835) := 'eview":"Enim enim fugiat consectetur ut sunt veniam ad sit minim amet Lorem veniam mollit."},{"ratin';
wwv_flow_imp.g_varchar2_table(836) := 'g":5,"review":"Dolor ipsum consectetur nostrud ex Lorem pariatur voluptate."},{"rating":8,"review":"';
wwv_flow_imp.g_varchar2_table(837) := 'Commodo magna sint sint dolore aute anim laborum."},{"rating":4,"review":"Laboris amet proident occa';
wwv_flow_imp.g_varchar2_table(838) := 'ecat dolore labore exercitation dolore sunt Lorem sunt anim."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_js';
wwv_flow_imp.g_varchar2_table(839) := 'on_products (product_id,product_name,unit_price,product_details) values (28,''Men''''s Hoodie (Red)'',24';
wwv_flow_imp.g_varchar2_table(840) := '.71,json(''{"colour":"red","gender":"Men''''s","brand":"FANGOLD","description":"Dolor irure dolore est ';
wwv_flow_imp.g_varchar2_table(841) := 'ipsum nisi incididunt laboris culpa. Ullamco ad cupidatat sint culpa adipisicing pariatur.","sizes":';
wwv_flow_imp.g_varchar2_table(842) := '["XS","S","M","L","XL","XXL"],"reviews":[{"rating":3,"review":"Proident aliqua aliquip aute quis cil';
wwv_flow_imp.g_varchar2_table(843) := 'lum."},{"rating":5,"review":"Pariatur enim ipsum aliqua Lorem eiusmod consequat cupidatat irure null';
wwv_flow_imp.g_varchar2_table(844) := 'a sint fugiat veniam amet ipsum."},{"rating":10,"review":"Sint duis ipsum reprehenderit Lorem aute p';
wwv_flow_imp.g_varchar2_table(845) := 'ariatur elit."},{"rating":4,"review":"Enim qui qui consequat culpa ex velit sint excepteur ipsum in ';
wwv_flow_imp.g_varchar2_table(846) := 'amet mollit mollit."},{"rating":10,"review":"Qui velit reprehenderit fugiat adipisicing anim incidid';
wwv_flow_imp.g_varchar2_table(847) := 'unt anim commodo occaecat consectetur in aute."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (p';
wwv_flow_imp.g_varchar2_table(848) := 'roduct_id,product_name,unit_price,product_details) values (29,''Boy''''s Shirt (Black)'',37.34,json(''{"c';
wwv_flow_imp.g_varchar2_table(849) := 'olour":"black","gender":"Boy''''s","brand":"SQUISH","description":"Pariatur nulla elit pariatur except';
wwv_flow_imp.g_varchar2_table(850) := 'eur ullamco officia incididunt. Aliquip quis aliquip cupidatat magna fugiat eiusmod pariatur excepte';
wwv_flow_imp.g_varchar2_table(851) := 'ur tempor officia voluptate fugiat.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"r';
wwv_flow_imp.g_varchar2_table(852) := 'eviews":[{"rating":5,"review":"Non esse labore ullamco laboris irure cupidatat ex proident eiusmod."';
wwv_flow_imp.g_varchar2_table(853) := '},{"rating":10,"review":"Ea velit et mollit labore consequat."},{"rating":6,"review":"Labore sit par';
wwv_flow_imp.g_varchar2_table(854) := 'iatur Lorem ad sint consectetur incididunt deserunt eiusmod sit nostrud dolore eiusmod sint."},{"rat';
wwv_flow_imp.g_varchar2_table(855) := 'ing":1,"review":"Id voluptate sunt amet laboris laborum ad dolor aliqua ipsum sint qui aute eu esse.';
wwv_flow_imp.g_varchar2_table(856) := '"},{"rating":5,"review":"Sint Lorem dolore do ea."},{"rating":9,"review":"Quis pariatur consequat ni';
wwv_flow_imp.g_varchar2_table(857) := 'si labore Lorem elit in qui Lorem."},{"rating":2,"review":"Consectetur voluptate tempor ullamco volu';
wwv_flow_imp.g_varchar2_table(858) := 'ptate labore sint."},{"rating":9,"review":"Qui laboris tempor ullamco ullamco commodo sint occaecat ';
wwv_flow_imp.g_varchar2_table(859) := 'Lorem."},{"rating":1,"review":"Laborum eu sit duis et culpa eu duis irure incididunt amet."}]}''));'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(860) := '       insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) value';
wwv_flow_imp.g_varchar2_table(861) := 's (30,''Women''''s Pyjamas (Grey)'',28.59,json(''{"colour":"grey","gender":"Women''''s","brand":"THREDZ","d';
wwv_flow_imp.g_varchar2_table(862) := 'escription":"Quis aliqua eiusmod incididunt quis ut ea aliqua sunt veniam ut et cupidatat eiusmod. S';
wwv_flow_imp.g_varchar2_table(863) := 'unt sunt duis excepteur excepteur do exercitation.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":';
wwv_flow_imp.g_varchar2_table(864) := '[{"rating":1,"review":"Et anim culpa voluptate pariatur ullamco dolore ad aliquip."},{"rating":4,"re';
wwv_flow_imp.g_varchar2_table(865) := 'view":"Nulla non ea nisi nulla elit veniam duis."},{"rating":4,"review":"Lorem adipisicing deserunt ';
wwv_flow_imp.g_varchar2_table(866) := 'duis id sint aliquip minim deserunt magna sunt magna laborum dolore."},{"rating":3,"review":"Officia';
wwv_flow_imp.g_varchar2_table(867) := ' amet magna eu nulla dolore magna pariatur deserunt amet reprehenderit."},{"rating":3,"review":"Ad a';
wwv_flow_imp.g_varchar2_table(868) := 'liqua ex eu cillum labore elit mollit reprehenderit anim."},{"rating":1,"review":"Duis excepteur mag';
wwv_flow_imp.g_varchar2_table(869) := 'na aliqua qui officia ipsum sunt."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,pro';
wwv_flow_imp.g_varchar2_table(870) := 'duct_name,unit_price,product_details) values (31,''Women''''s Skirt (Green)'',5.65,json(''{"colour":"gree';
wwv_flow_imp.g_varchar2_table(871) := 'n","gender":"Women''''s","brand":"ZIDANT","description":"Et est officia est amet est nisi sit veniam p';
wwv_flow_imp.g_varchar2_table(872) := 'roident. Ullamco proident culpa velit proident quis dolore occaecat proident Lorem tempor.","sizes":';
wwv_flow_imp.g_varchar2_table(873) := '[0,2,4,6,8,10,12,14,16,18,20],"reviews":[]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_';
wwv_flow_imp.g_varchar2_table(874) := 'id,product_name,unit_price,product_details) values (32,''Women''''s Jacket (Blue)'',37,json(''{"colour":"';
wwv_flow_imp.g_varchar2_table(875) := 'blue","gender":"Women''''s","brand":"ZOGAK","description":"Tempor ipsum duis aliqua veniam qui laboris';
wwv_flow_imp.g_varchar2_table(876) := ' et ut officia. Fugiat fugiat nisi labore excepteur ullamco excepteur veniam in in et adipisicing si';
wwv_flow_imp.g_varchar2_table(877) := 'nt.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":9,"review":"Sit amet id ut laborum i';
wwv_flow_imp.g_varchar2_table(878) := 'n exercitation laborum Lorem fugiat ex."},{"rating":7,"review":"Nisi non mollit dolore id aute velit';
wwv_flow_imp.g_varchar2_table(879) := ' laboris consequat voluptate id."},{"rating":1,"review":"Nisi nisi fugiat non nisi amet esse."},{"ra';
wwv_flow_imp.g_varchar2_table(880) := 'ting":1,"review":"Laborum eiusmod id ipsum aliqua adipisicing cillum enim."},{"rating":8,"review":"D';
wwv_flow_imp.g_varchar2_table(881) := 'uis aliqua ut nulla proident voluptate incididunt elit est exercitation id aute."},{"rating":4,"revi';
wwv_flow_imp.g_varchar2_table(882) := 'ew":"Veniam labore exercitation eiusmod nisi mollit anim eu."},{"rating":6,"review":"Exercitation eu';
wwv_flow_imp.g_varchar2_table(883) := ' est irure velit pariatur."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_na';
wwv_flow_imp.g_varchar2_table(884) := 'me,unit_price,product_details) values (33,''Boy''''s Pyjamas (Grey)'',23.32,json(''{"colour":"grey","gend';
wwv_flow_imp.g_varchar2_table(885) := 'er":"Boy''''s","brand":"RETRACK","description":"Sit consectetur Lorem culpa ipsum ad ullamco ea aute q';
wwv_flow_imp.g_varchar2_table(886) := 'ui ea. Laboris ipsum enim enim veniam.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"]';
wwv_flow_imp.g_varchar2_table(887) := ',"reviews":[{"rating":7,"review":"Ut incididunt veniam ullamco voluptate occaecat velit."},{"rating"';
wwv_flow_imp.g_varchar2_table(888) := ':5,"review":"Consectetur cupidatat voluptate dolore velit culpa est id enim aute."}]}''));'||wwv_flow.LF||
'        in';
wwv_flow_imp.g_varchar2_table(889) := 'sert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (34,''Wo';
wwv_flow_imp.g_varchar2_table(890) := 'men''''s Jeans (Red)'',7.18,json(''{"colour":"red","gender":"Women''''s","brand":"PANZENT","description":"';
wwv_flow_imp.g_varchar2_table(891) := 'Eiusmod culpa dolore occaecat excepteur esse magna fugiat dolore cupidatat laboris mollit culpa. Con';
wwv_flow_imp.g_varchar2_table(892) := 'sequat dolor qui tempor sit minim sit excepteur enim excepteur aute minim.","sizes":[0,2,4,6,8,10,12';
wwv_flow_imp.g_varchar2_table(893) := ',14,16,18,20],"reviews":[{"rating":10,"review":"Nulla enim cillum pariatur do consectetur et Lorem."';
wwv_flow_imp.g_varchar2_table(894) := '},{"rating":1,"review":"Cupidatat fugiat incididunt fugiat eu."},{"rating":1,"review":"Ullamco eiusm';
wwv_flow_imp.g_varchar2_table(895) := 'od adipisicing fugiat reprehenderit mollit aliquip."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_produc';
wwv_flow_imp.g_varchar2_table(896) := 'ts (product_id,product_name,unit_price,product_details) values (35,''Girl''''s Dress (Red)'',49.12,json(';
wwv_flow_imp.g_varchar2_table(897) := '''{"colour":"red","gender":"Girl''''s","brand":"NIXELT","description":"Ipsum pariatur laborum nulla par';
wwv_flow_imp.g_varchar2_table(898) := 'iatur consequat consequat amet nisi. Ut in quis officia excepteur.","sizes":["1 Yr","2 Yr","3-4 Yr",';
wwv_flow_imp.g_varchar2_table(899) := '"5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":10,"review":"Ut est anim sit nulla commodo velit o';
wwv_flow_imp.g_varchar2_table(900) := 'ccaecat amet mollit fugiat id."},{"rating":2,"review":"Eu quis ea anim incididunt nisi nisi velit ve';
wwv_flow_imp.g_varchar2_table(901) := 'lit labore do."},{"rating":9,"review":"Eu laborum laborum reprehenderit minim officia anim."},{"rati';
wwv_flow_imp.g_varchar2_table(902) := 'ng":8,"review":"Et consectetur labore ullamco occaecat cupidatat magna pariatur esse qui ut mollit e';
wwv_flow_imp.g_varchar2_table(903) := 'a cillum."},{"rating":4,"review":"Dolore culpa magna commodo aute do culpa non commodo qui id commod';
wwv_flow_imp.g_varchar2_table(904) := 'o consectetur exercitation."},{"rating":6,"review":"Adipisicing laborum tempor sunt laboris et sint ';
wwv_flow_imp.g_varchar2_table(905) := 'aute pariatur."},{"rating":9,"review":"Excepteur voluptate qui magna in cillum aliqua."}]}''));'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(906) := '   insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (3';
wwv_flow_imp.g_varchar2_table(907) := '6,''Women''''s Trousers (Blue)'',29.51,json(''{"colour":"blue","gender":"Women''''s","brand":"TROLLERY","de';
wwv_flow_imp.g_varchar2_table(908) := 'scription":"Proident sunt ipsum pariatur duis dolor eu dolore culpa ad aliquip elit. Mollit Lorem et';
wwv_flow_imp.g_varchar2_table(909) := ' aliquip commodo est anim amet eiusmod amet dolore laborum tempor officia.","sizes":[0,2,4,6,8,10,12';
wwv_flow_imp.g_varchar2_table(910) := ',14,16,18,20],"reviews":[{"rating":10,"review":"Consequat ut commodo irure sit elit anim amet eu est';
wwv_flow_imp.g_varchar2_table(911) := ' sunt tempor non."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit_p';
wwv_flow_imp.g_varchar2_table(912) := 'rice,product_details) values (37,''Boy''''s Jeans (Blue)'',22.98,json(''{"colour":"blue","gender":"Boy''''s';
wwv_flow_imp.g_varchar2_table(913) := '","brand":"AVIT","description":"Velit velit esse nulla minim minim laborum esse. Sint minim id aliqu';
wwv_flow_imp.g_varchar2_table(914) := 'ip amet fugiat dolor aliqua.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews"';
wwv_flow_imp.g_varchar2_table(915) := ':[]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_deta';
wwv_flow_imp.g_varchar2_table(916) := 'ils) values (38,''Girl''''s Pyjamas (Red)'',11,json(''{"colour":"red","gender":"Girl''''s","brand":"EMTRAK"';
wwv_flow_imp.g_varchar2_table(917) := ',"description":"Magna est occaecat consectetur ullamco mollit dolore aute irure consectetur nulla ip';
wwv_flow_imp.g_varchar2_table(918) := 'sum id elit occaecat. Amet Lorem sint nulla eiusmod commodo aliqua cillum anim tempor tempor pariatu';
wwv_flow_imp.g_varchar2_table(919) := 'r do nostrud minim.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"ratin';
wwv_flow_imp.g_varchar2_table(920) := 'g":4,"review":"Consectetur velit adipisicing excepteur in excepteur sit excepteur irure veniam velit';
wwv_flow_imp.g_varchar2_table(921) := '."},{"rating":4,"review":"Consectetur exercitation exercitation irure commodo officia do adipisicing';
wwv_flow_imp.g_varchar2_table(922) := ' ullamco sit anim consequat."},{"rating":9,"review":"Minim occaecat sunt laborum voluptate culpa eni';
wwv_flow_imp.g_varchar2_table(923) := 'm elit."},{"rating":2,"review":"Reprehenderit labore incididunt ex ullamco nostrud cillum irure moll';
wwv_flow_imp.g_varchar2_table(924) := 'it dolore aliqua enim tempor aliquip laborum."},{"rating":2,"review":"Enim commodo adipisicing conse';
wwv_flow_imp.g_varchar2_table(925) := 'quat commodo."},{"rating":8,"review":"Sint ut cillum Lorem ut ad aliquip elit sunt labore laboris co';
wwv_flow_imp.g_varchar2_table(926) := 'nsequat Lorem aliqua occaecat."},{"rating":2,"review":"Et consectetur in officia ullamco labore ea d';
wwv_flow_imp.g_varchar2_table(927) := 'uis amet."},{"rating":8,"review":"Reprehenderit enim tempor proident commodo ex eu fugiat cupidatat ';
wwv_flow_imp.g_varchar2_table(928) := 'exercitation culpa id adipisicing deserunt officia."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_produc';
wwv_flow_imp.g_varchar2_table(929) := 'ts (product_id,product_name,unit_price,product_details) values (39,''Boy''''s Trousers (Blue)'',34.06,js';
wwv_flow_imp.g_varchar2_table(930) := 'on(''{"colour":"blue","gender":"Boy''''s","brand":"DIGINETIC","description":"Dolor aliqua minim nostrud';
wwv_flow_imp.g_varchar2_table(931) := ' non labore in ullamco mollit mollit sit non. Duis nulla exercitation et adipisicing nostrud volupta';
wwv_flow_imp.g_varchar2_table(932) := 'te cupidatat eu reprehenderit.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"review';
wwv_flow_imp.g_varchar2_table(933) := 's":[{"rating":6,"review":"Culpa id consequat cillum dolor."},{"rating":8,"review":"Qui do quis magna';
wwv_flow_imp.g_varchar2_table(934) := ' nostrud exercitation enim aute dolore proident ipsum sint nostrud deserunt."},{"rating":9,"review":';
wwv_flow_imp.g_varchar2_table(935) := '"Excepteur fugiat adipisicing laboris ea culpa cupidatat laborum occaecat nostrud."}]}''));'||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(936) := 'nsert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (40,''G';
wwv_flow_imp.g_varchar2_table(937) := 'irl''''s Pyjamas (Black)'',8.66,json(''{"colour":"black","gender":"Girl''''s","brand":"ISOLOGICS","descrip';
wwv_flow_imp.g_varchar2_table(938) := 'tion":"Ex exercitation aliquip cillum adipisicing cupidatat. Culpa labore eiusmod do ut ipsum incidi';
wwv_flow_imp.g_varchar2_table(939) := 'dunt ipsum labore.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating';
wwv_flow_imp.g_varchar2_table(940) := '":6,"review":"Duis minim duis dolor laboris eiusmod consequat fugiat adipisicing ex non culpa Lorem ';
wwv_flow_imp.g_varchar2_table(941) := 'proident qui."},{"rating":4,"review":"Veniam tempor commodo aliqua sit ex mollit cillum aute officia';
wwv_flow_imp.g_varchar2_table(942) := ' fugiat tempor sunt nulla elit."},{"rating":10,"review":"Dolore officia aute magna eiusmod exercitat';
wwv_flow_imp.g_varchar2_table(943) := 'ion esse amet tempor."},{"rating":7,"review":"Proident nisi voluptate ea esse exercitation ullamco c';
wwv_flow_imp.g_varchar2_table(944) := 'onsequat consectetur in enim amet adipisicing commodo nulla."},{"rating":4,"review":"Irure ullamco i';
wwv_flow_imp.g_varchar2_table(945) := 'd adipisicing fugiat Lorem do non officia nisi sunt esse mollit consectetur."},{"rating":9,"review":';
wwv_flow_imp.g_varchar2_table(946) := '"Laboris do elit dolor officia irure esse incididunt pariatur elit."},{"rating":1,"review":"Aliqua L';
wwv_flow_imp.g_varchar2_table(947) := 'orem nostrud et reprehenderit exercitation exercitation nostrud consectetur dolor."}]}''));'||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(948) := 'nsert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (41,''W';
wwv_flow_imp.g_varchar2_table(949) := 'omen''''s Dress (Black)'',10.11,json(''{"colour":"black","gender":"Women''''s","brand":"NEOCENT","descript';
wwv_flow_imp.g_varchar2_table(950) := 'ion":"Eu enim aliquip deserunt est duis do sunt consequat sit sit labore nisi. Culpa mollit cupidata';
wwv_flow_imp.g_varchar2_table(951) := 't Lorem et minim sit.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":4,"review":"Ex cul';
wwv_flow_imp.g_varchar2_table(952) := 'pa sint ad eu quis."},{"rating":4,"review":"Irure labore adipisicing velit sint sint."},{"rating":4,';
wwv_flow_imp.g_varchar2_table(953) := '"review":"Ullamco dolore ad qui consequat labore do cillum velit."},{"rating":5,"review":"Velit offi';
wwv_flow_imp.g_varchar2_table(954) := 'cia eiusmod proident dolore occaecat eu eiusmod."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products ';
wwv_flow_imp.g_varchar2_table(955) := '(product_id,product_name,unit_price,product_details) values (1,''Boy''''s Shirt (White)'',29.55,json(''{"';
wwv_flow_imp.g_varchar2_table(956) := 'colour":"white","gender":"Boy''''s","brand":"COMTOURS","description":"Labore commodo velit cupidatat u';
wwv_flow_imp.g_varchar2_table(957) := 'llamco ea proident velit sunt adipisicing. Esse tempor exercitation reprehenderit ullamco esse incid';
wwv_flow_imp.g_varchar2_table(958) := 'idunt dolore laboris Lorem ipsum fugiat ea.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10';
wwv_flow_imp.g_varchar2_table(959) := ' Yr"],"reviews":[]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit_pri';
wwv_flow_imp.g_varchar2_table(960) := 'ce,product_details) values (2,''Women''''s Shirt (Green)'',16.67,json(''{"colour":"green","gender":"Women';
wwv_flow_imp.g_varchar2_table(961) := '''''s","brand":"NIKE","description":"Excepteur anim adipisicing aliqua ad. Ex aliquip ad tempor cupida';
wwv_flow_imp.g_varchar2_table(962) := 'tat dolore ipsum ex anim Lorem aute amet.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating';
wwv_flow_imp.g_varchar2_table(963) := '":8,"review":"Laborum ipsum adipisicing magna nulla tempor incididunt."},{"rating":10,"review":"Cupi';
wwv_flow_imp.g_varchar2_table(964) := 'datat dolore nulla pariatur quis quis."},{"rating":9,"review":"Pariatur mollit dolor in deserunt cil';
wwv_flow_imp.g_varchar2_table(965) := 'lum consectetur."},{"rating":3,"review":"Dolore occaecat mollit id ad aliqua irure reprehenderit ame';
wwv_flow_imp.g_varchar2_table(966) := 't eiusmod pariatur."},{"rating":10,"review":"Est pariatur et qui minim velit non consectetur sint fu';
wwv_flow_imp.g_varchar2_table(967) := 'giat ad."},{"rating":6,"review":"Et pariatur ipsum eu qui."},{"rating":6,"review":"Voluptate labore ';
wwv_flow_imp.g_varchar2_table(968) := 'irure cupidatat mollit irure quis fugiat enim laborum consectetur officia sunt."},{"rating":8,"revie';
wwv_flow_imp.g_varchar2_table(969) := 'w":"Irure elit do et elit aute veniam proident sunt."},{"rating":8,"review":"Aute mollit proident id';
wwv_flow_imp.g_varchar2_table(970) := ' veniam occaecat dolore mollit dolore nostrud."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (p';
wwv_flow_imp.g_varchar2_table(971) := 'roduct_id,product_name,unit_price,product_details) values (3,''Boy''''s Sweater (Green)'',44.17,json(''{"';
wwv_flow_imp.g_varchar2_table(972) := 'colour":"green","gender":"Boy''''s","brand":"KINETICA","description":"Occaecat dolore in ut et ad pari';
wwv_flow_imp.g_varchar2_table(973) := 'atur laborum mollit nulla exercitation. Laboris esse tempor quis velit nostrud exercitation veniam r';
wwv_flow_imp.g_varchar2_table(974) := 'eprehenderit minim minim exercitation.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"]';
wwv_flow_imp.g_varchar2_table(975) := ',"reviews":[{"rating":5,"review":"Sunt ad proident excepteur laboris officia eu reprehenderit dolor ';
wwv_flow_imp.g_varchar2_table(976) := 'nostrud elit nulla pariatur incididunt Lorem."},{"rating":2,"review":"Ullamco ad amet fugiat adipisi';
wwv_flow_imp.g_varchar2_table(977) := 'cing."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product';
wwv_flow_imp.g_varchar2_table(978) := '_details) values (4,''Boy''''s Trousers (White)'',43.71,json(''{"colour":"white","gender":"Boy''''s","brand';
wwv_flow_imp.g_varchar2_table(979) := '":"INTERLOO","description":"Nostrud esse velit incididunt occaecat ullamco dolor quis reprehenderit ';
wwv_flow_imp.g_varchar2_table(980) := 'proident dolore deserunt tempor qui proident. Magna deserunt sit minim eu commodo minim labore occae';
wwv_flow_imp.g_varchar2_table(981) := 'cat ea id sint laborum.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"r';
wwv_flow_imp.g_varchar2_table(982) := 'ating":7,"review":"Anim culpa qui est adipisicing qui dolore enim. Sint duis aute laborum nisi ut el';
wwv_flow_imp.g_varchar2_table(983) := 'it Lorem nisi proident consectetur."},{"rating":6,"review":"Reprehenderit ad ipsum sint mollit aliqu';
wwv_flow_imp.g_varchar2_table(984) := 'a."},{"rating":4,"review":"Enim culpa reprehenderit non ullamco non ex veniam. Sit do incididunt ull';
wwv_flow_imp.g_varchar2_table(985) := 'amco ad et et aliquip deserunt dolor officia nostrud ipsum officia nostrud. Lorem esse tempor aliqua';
wwv_flow_imp.g_varchar2_table(986) := ' ut quis occaecat."},{"rating":9,"review":"Pariatur sit dolor dolor tempor commodo aute culpa sit."}';
wwv_flow_imp.g_varchar2_table(987) := ',{"rating":2,"review":"Sunt enim sunt occaecat exercitation deserunt nisi anim mollit deserunt non l';
wwv_flow_imp.g_varchar2_table(988) := 'aboris cillum."},{"rating":8,"review":"Exercitation et duis quis minim id duis veniam occaecat amet ';
wwv_flow_imp.g_varchar2_table(989) := 'cillum velit pariatur tempor. Culpa aliquip adipisicing aliquip non minim occaecat eu nisi esse veni';
wwv_flow_imp.g_varchar2_table(990) := 'am eu aliqua."},{"rating":5,"review":"Culpa elit nulla dolore mollit tempor mollit in. Voluptate des';
wwv_flow_imp.g_varchar2_table(991) := 'erunt eiusmod sint id excepteur eiusmod excepteur qui enim cupidatat. Nostrud enim anim commodo adip';
wwv_flow_imp.g_varchar2_table(992) := 'isicing nisi dolore commodo elit commodo aliqua aliquip laborum."},{"rating":4,"review":"Exercitatio';
wwv_flow_imp.g_varchar2_table(993) := 'n sunt consequat anim nisi sunt cillum esse amet ut reprehenderit ea. Laborum labore ipsum consectet';
wwv_flow_imp.g_varchar2_table(994) := 'ur ad excepteur proident fugiat consectetur eiusmod incididunt officia enim ullamco."}]}''));'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(995) := ' insert into eba_demo_json_products (product_id,product_name,unit_price,product_details) values (5,''';
wwv_flow_imp.g_varchar2_table(996) := 'Girl''''s Shorts (Red)'',38.28,json(''{"colour":"red","gender":"Girl''''s","brand":"OZEAN","description":"';
wwv_flow_imp.g_varchar2_table(997) := 'These sea shorts are designed with quick-drying and breathable materials, making them the perfect ch';
wwv_flow_imp.g_varchar2_table(998) := 'oice for a day out on the water.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"revi';
wwv_flow_imp.g_varchar2_table(999) := 'ews":[]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_';
wwv_flow_imp.g_varchar2_table(1000) := 'details) values (6,''Boy''''s Socks (Grey)'',19.16,json(''{"colour":"grey","gender":"Boy''''s","brand":"GRO';
wwv_flow_imp.g_varchar2_table(1001) := 'K","description":"Pariatur elit adipisicing aute dolor sunt laborum ullamco aliqua exercitation cons';
wwv_flow_imp.g_varchar2_table(1002) := 'ectetur. Lorem qui sint ullamco sint commodo anim.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr';
wwv_flow_imp.g_varchar2_table(1003) := '","9-10 Yr"],"reviews":[{"rating":5,"review":"Ea eu sit est consectetur quis in dolor ut."},{"rating';
wwv_flow_imp.g_varchar2_table(1004) := '":6,"review":"In do cillum occaecat minim."},{"rating":6,"review":"Laborum laborum excepteur ipsum a';
wwv_flow_imp.g_varchar2_table(1005) := 'liquip reprehenderit cillum irure proident voluptate eiusmod in culpa."},{"rating":9,"review":"Exerc';
wwv_flow_imp.g_varchar2_table(1006) := 'itation magna proident non deserunt consectetur consectetur do ex sint id irure ipsum voluptate."},{';
wwv_flow_imp.g_varchar2_table(1007) := '"rating":7,"review":"Aliquip irure minim quis quis voluptate reprehenderit mollit dolore."},{"rating';
wwv_flow_imp.g_varchar2_table(1008) := '":1,"review":"Duis mollit aute cillum aute culpa magna."},{"rating":9,"review":"Magna exercitation e';
wwv_flow_imp.g_varchar2_table(1009) := 'xercitation sit commodo proident fugiat occaecat ullamco voluptate do consectetur officia velit."},{';
wwv_flow_imp.g_varchar2_table(1010) := '"rating":7,"review":"Laboris nostrud et nulla tempor commodo non aute ipsum excepteur qui dolore eni';
wwv_flow_imp.g_varchar2_table(1011) := 'm."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_de';
wwv_flow_imp.g_varchar2_table(1012) := 'tails) values (7,''Boy''''s Socks (Black)'',19.58,json(''{"colour":"black","gender":"Boy''''s","brand":"ENE';
wwv_flow_imp.g_varchar2_table(1013) := 'RVATE","description":"Sit minim sunt nulla proident velit Lorem dolor. Aute reprehenderit laborum la';
wwv_flow_imp.g_varchar2_table(1014) := 'bore proident non esse nisi ex magna consectetur minim ex est.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6';
wwv_flow_imp.g_varchar2_table(1015) := ' Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":8,"review":"Laborum laboris eu occaecat amet adipisici';
wwv_flow_imp.g_varchar2_table(1016) := 'ng consequat veniam velit."},{"rating":2,"review":"Mollit fugiat commodo minim sint do irure duis qu';
wwv_flow_imp.g_varchar2_table(1017) := 'is ex minim ad."},{"rating":2,"review":"Sit duis aliquip proident et nostrud enim anim amet dolor co';
wwv_flow_imp.g_varchar2_table(1018) := 'nsequat tempor culpa."},{"rating":3,"review":"Proident aute voluptate aute irure."},{"rating":2,"rev';
wwv_flow_imp.g_varchar2_table(1019) := 'iew":"Ex excepteur duis irure veniam elit occaecat sit Lorem labore id minim tempor dolore officia."';
wwv_flow_imp.g_varchar2_table(1020) := '},{"rating":2,"review":"Amet fugiat commodo qui eiusmod dolore sint fugiat commodo elit qui esse in ';
wwv_flow_imp.g_varchar2_table(1021) := 'officia."},{"rating":2,"review":"Dolor proident proident ad officia cillum dolor aute officia enim e';
wwv_flow_imp.g_varchar2_table(1022) := 'xercitation."},{"rating":4,"review":"Dolor esse cupidatat eiusmod non veniam elit nostrud aliquip eu';
wwv_flow_imp.g_varchar2_table(1023) := ' elit."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit_price,produc';
wwv_flow_imp.g_varchar2_table(1024) := 't_details) values (8,''Boy''''s Coat (Brown)'',21.16,json(''{"colour":"brown","gender":"Boy''''s","brand":"';
wwv_flow_imp.g_varchar2_table(1025) := 'KOFFEE","description":"Voluptate quis excepteur mollit id dolore. Sunt aliquip in magna ut irure nos';
wwv_flow_imp.g_varchar2_table(1026) := 'trud duis officia fugiat aute.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"review';
wwv_flow_imp.g_varchar2_table(1027) := 's":[]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit_price,product_de';
wwv_flow_imp.g_varchar2_table(1028) := 'tails) values (9,''Women''''s Jeans (Brown)'',29.49,json(''{"colour":"brown","gender":"Women''''s","brand":';
wwv_flow_imp.g_varchar2_table(1029) := '"PROTODYNE","description":"Est dolor tempor sint commodo irure sint ut dolor proident enim Lorem. Pa';
wwv_flow_imp.g_varchar2_table(1030) := 'riatur deserunt nostrud quis minim non.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"reviews":[{"rating":';
wwv_flow_imp.g_varchar2_table(1031) := '2,"review":"Occaecat cupidatat in id elit magna Lorem esse ad magna labore non qui magna."},{"rating';
wwv_flow_imp.g_varchar2_table(1032) := '":8,"review":"Cupidatat cupidatat laboris consectetur labore veniam aliqua et incididunt duis sunt p';
wwv_flow_imp.g_varchar2_table(1033) := 'roident."},{"rating":2,"review":"Esse ipsum veniam ullamco irure ad minim mollit consequat non dolor';
wwv_flow_imp.g_varchar2_table(1034) := ' labore."},{"rating":1,"review":"Cillum ea minim voluptate id ut consectetur commodo nostrud cillum ';
wwv_flow_imp.g_varchar2_table(1035) := 'eiusmod eiusmod dolore cillum veniam."},{"rating":5,"review":"Excepteur adipisicing culpa dolor id e';
wwv_flow_imp.g_varchar2_table(1036) := 't irure sint ex non nostrud velit pariatur esse quis."},{"rating":9,"review":"Do fugiat aliqua sunt ';
wwv_flow_imp.g_varchar2_table(1037) := 'quis proident fugiat."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,un';
wwv_flow_imp.g_varchar2_table(1038) := 'it_price,product_details) values (10,''Women''''s Skirt (Red)'',30.69,json(''{"colour":"green","gender":"';
wwv_flow_imp.g_varchar2_table(1039) := 'Women''''s","brand":"FLYBOYZ","description":"Qui aliquip dolor aute labore amet nostrud deserunt nulla';
wwv_flow_imp.g_varchar2_table(1040) := ' ut veniam id. Ut aute velit tempor anim ex sit nisi.","sizes":[0,2,4,6,8,10,12,14,16,18,20],"review';
wwv_flow_imp.g_varchar2_table(1041) := 's":[{"rating":7,"review":"Mollit consequat minim sit consequat deserunt duis."},{"rating":8,"review"';
wwv_flow_imp.g_varchar2_table(1042) := ':"Quis eu esse proident elit eu aliqua magna voluptate labore adipisicing voluptate ex do."},{"ratin';
wwv_flow_imp.g_varchar2_table(1043) := 'g":6,"review":"Laborum nulla aliquip nulla adipisicing aliquip qui cupidatat aliquip in."},{"rating"';
wwv_flow_imp.g_varchar2_table(1044) := ':3,"review":"Exercitation aute voluptate voluptate tempor sit enim ut veniam do."},{"rating":8,"revi';
wwv_flow_imp.g_varchar2_table(1045) := 'ew":"Cillum cillum anim aliqua eu deserunt amet eu ut veniam in qui."},{"rating":7,"review":"Nostrud';
wwv_flow_imp.g_varchar2_table(1046) := ' aliqua ullamco irure consectetur elit nisi eu elit reprehenderit ut."},{"rating":5,"review":"Irure ';
wwv_flow_imp.g_varchar2_table(1047) := 'nisi dolore dolore ut non ad minim pariatur."},{"rating":2,"review":"Laboris aliqua sint est incidid';
wwv_flow_imp.g_varchar2_table(1048) := 'unt sunt non tempor irure reprehenderit labore."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (';
wwv_flow_imp.g_varchar2_table(1049) := 'product_id,product_name,unit_price,product_details) values (11,''Boy''''s Shorts (Blue)'',10.48,json(''{"';
wwv_flow_imp.g_varchar2_table(1050) := 'colour":"blue","gender":"Boy''''s","brand":"WRAPTURE","description":"Id sit adipisicing ea dolore fugi';
wwv_flow_imp.g_varchar2_table(1051) := 'at laborum ut dolore. Reprehenderit aliqua non adipisicing aliqua adipisicing aute ullamco consectet';
wwv_flow_imp.g_varchar2_table(1052) := 'ur est aliqua.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,';
wwv_flow_imp.g_varchar2_table(1053) := '"review":"Laborum labore exercitation culpa sint cillum aute duis labore do excepteur."},{"rating":1';
wwv_flow_imp.g_varchar2_table(1054) := '0,"review":"Do velit laborum adipisicing velit."},{"rating":6,"review":"Culpa dolor aute adipisicing';
wwv_flow_imp.g_varchar2_table(1055) := ' ad."},{"rating":6,"review":"Sit sunt elit proident fugiat consectetur id incididunt nulla nulla mag';
wwv_flow_imp.g_varchar2_table(1056) := 'na consectetur."},{"rating":6,"review":"Adipisicing ipsum eiusmod sint ullamco dolor irure qui offic';
wwv_flow_imp.g_varchar2_table(1057) := 'ia."},{"rating":4,"review":"Ipsum commodo amet non ut labore."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_j';
wwv_flow_imp.g_varchar2_table(1058) := 'son_products (product_id,product_name,unit_price,product_details) values (12,''Boy''''s Socks (White)'',';
wwv_flow_imp.g_varchar2_table(1059) := '12.64,json(''{"colour":"grey","gender":"Boy''''s","brand":"HANDSHAKE","description":"Tempor laborum vol';
wwv_flow_imp.g_varchar2_table(1060) := 'uptate mollit aliquip et tempor nostrud Lorem. Nostrud anim exercitation est fugiat elit est deserun';
wwv_flow_imp.g_varchar2_table(1061) := 't mollit exercitation.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"ra';
wwv_flow_imp.g_varchar2_table(1062) := 'ting":8,"review":"Quis culpa laborum ex magna."},{"rating":3,"review":"Culpa ullamco deserunt ex ea.';
wwv_flow_imp.g_varchar2_table(1063) := '"},{"rating":3,"review":"Fugiat ullamco reprehenderit tempor nulla ad fugiat qui excepteur sunt offi';
wwv_flow_imp.g_varchar2_table(1064) := 'cia deserunt nulla."},{"rating":2,"review":"Mollit dolore magna magna veniam culpa ullamco tempor es';
wwv_flow_imp.g_varchar2_table(1065) := 'se id in occaecat excepteur ullamco ea."},{"rating":10,"review":"Culpa dolore enim consequat aliquip';
wwv_flow_imp.g_varchar2_table(1066) := ' nulla ipsum."},{"rating":2,"review":"Excepteur aliqua sunt exercitation mollit pariatur anim tempor';
wwv_flow_imp.g_varchar2_table(1067) := '."},{"rating":8,"review":"Proident culpa tempor dolore deserunt anim ea deserunt quis duis."},{"rati';
wwv_flow_imp.g_varchar2_table(1068) := 'ng":8,"review":"Reprehenderit est do quis quis reprehenderit adipisicing qui Lorem mollit sit labore';
wwv_flow_imp.g_varchar2_table(1069) := ' veniam."},{"rating":1,"review":"Mollit dolore ad laboris ut cillum velit in sint labore nulla Lorem';
wwv_flow_imp.g_varchar2_table(1070) := ' minim."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit_price,produ';
wwv_flow_imp.g_varchar2_table(1071) := 'ct_details) values (13,''Boy''''s Hoodie (Grey)'',26.14,json(''{"colour":"grey","gender":"Boy''''s","brand"';
wwv_flow_imp.g_varchar2_table(1072) := ':"SUNCLIPSE","description":"Voluptate irure voluptate labore sint amet occaecat elit ea incididunt a';
wwv_flow_imp.g_varchar2_table(1073) := 'liquip. Tempor laboris tempor tempor magna officia in aliqua consequat elit occaecat.","sizes":["1 Y';
wwv_flow_imp.g_varchar2_table(1074) := 'r","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":7,"review":"Fugiat officia nost';
wwv_flow_imp.g_varchar2_table(1075) := 'rud cillum duis consequat sunt culpa duis laborum reprehenderit laborum."},{"rating":10,"review":"Et';
wwv_flow_imp.g_varchar2_table(1076) := ' do reprehenderit do irure tempor id aliquip voluptate anim consequat amet sunt."},{"rating":3,"revi';
wwv_flow_imp.g_varchar2_table(1077) := 'ew":"Minim adipisicing dolore eiusmod laborum aliqua non Lorem laboris minim est cillum qui qui Lore';
wwv_flow_imp.g_varchar2_table(1078) := 'm."},{"rating":4,"review":"Esse Lorem aute deserunt quis."},{"rating":1,"review":"Ex deserunt aliqua';
wwv_flow_imp.g_varchar2_table(1079) := ' consectetur elit cillum cillum ex et mollit sint."},{"rating":4,"review":"Magna esse ipsum ipsum ir';
wwv_flow_imp.g_varchar2_table(1080) := 'ure officia nostrud ad velit sit."},{"rating":8,"review":"Mollit et tempor esse fugiat fugiat ad vol';
wwv_flow_imp.g_varchar2_table(1081) := 'uptate irure est sunt proident magna anim ex."},{"rating":4,"review":"Nulla nisi esse ut exercitatio';
wwv_flow_imp.g_varchar2_table(1082) := 'n commodo irure non amet labore mollit et elit."},{"rating":1,"review":"Enim officia anim proident c';
wwv_flow_imp.g_varchar2_table(1083) := 'onsequat."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit_price,pro';
wwv_flow_imp.g_varchar2_table(1084) := 'duct_details) values (14,''Women''''s Skirt (Brown)'',13.97,json(''{"colour":"brown","gender":"Women''''s",';
wwv_flow_imp.g_varchar2_table(1085) := '"brand":"ISOTRONIC","description":"Magna Lorem do ad incididunt qui magna irure commodo nisi. Dolore';
wwv_flow_imp.g_varchar2_table(1086) := ' ipsum adipisicing magna ea ullamco Lorem officia culpa do laborum voluptate.","sizes":[0,2,4,6,8,10';
wwv_flow_imp.g_varchar2_table(1087) := ',12,14,16,18,20],"reviews":[{"rating":1,"review":"Officia occaecat laboris magna sint tempor officia';
wwv_flow_imp.g_varchar2_table(1088) := ' deserunt proident eu excepteur."},{"rating":2,"review":"Aliqua nisi sint enim ad mollit qui."},{"ra';
wwv_flow_imp.g_varchar2_table(1089) := 'ting":3,"review":"Fugiat excepteur eiusmod incididunt Lorem nostrud nostrud labore aute esse aliquip';
wwv_flow_imp.g_varchar2_table(1090) := '."},{"rating":8,"review":"Voluptate ad enim anim culpa veniam amet."},{"rating":3,"review":"Do cillu';
wwv_flow_imp.g_varchar2_table(1091) := 'm quis cillum Lorem tempor labore laboris."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (produ';
wwv_flow_imp.g_varchar2_table(1092) := 'ct_id,product_name,unit_price,product_details) values (15,''Girl''''s Coat (Blue)'',13.09,json(''{"colour';
wwv_flow_imp.g_varchar2_table(1093) := '":"blue","gender":"Girl''''s","brand":"DECRATEX","description":"Proident ut officia non duis est eu al';
wwv_flow_imp.g_varchar2_table(1094) := 'iquip culpa cupidatat est incididunt amet ipsum veniam. Aliqua ea cupidatat incididunt ad excepteur ';
wwv_flow_imp.g_varchar2_table(1095) := 'irure ad pariatur occaecat duis incididunt excepteur amet.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr"';
wwv_flow_imp.g_varchar2_table(1096) := ',"7-8 Yr","9-10 Yr"],"reviews":[{"rating":8,"review":"Officia irure deserunt mollit Lorem dolor dolo';
wwv_flow_imp.g_varchar2_table(1097) := 'r minim deserunt."},{"rating":10,"review":"Aliqua nostrud dolore enim dolore reprehenderit officia q';
wwv_flow_imp.g_varchar2_table(1098) := 'uis aliquip irure occaecat et."},{"rating":2,"review":"Consectetur consequat ut cupidatat et elit et';
wwv_flow_imp.g_varchar2_table(1099) := ' cillum veniam exercitation Lorem culpa ipsum."},{"rating":9,"review":"Nisi tempor incididunt Lorem ';
wwv_flow_imp.g_varchar2_table(1100) := 'sit sit do mollit qui aliquip qui eu quis Lorem."},{"rating":9,"review":"Sunt nulla ad dolore fugiat';
wwv_flow_imp.g_varchar2_table(1101) := ' cillum et."},{"rating":8,"review":"Incididunt nostrud officia sunt cupidatat culpa ex id ut."},{"ra';
wwv_flow_imp.g_varchar2_table(1102) := 'ting":1,"review":"Deserunt sit officia enim adipisicing exercitation velit ipsum dolore laboris offi';
wwv_flow_imp.g_varchar2_table(1103) := 'cia mollit ex esse et."},{"rating":3,"review":"Aliqua nulla laborum id mollit irure incididunt aliqu';
wwv_flow_imp.g_varchar2_table(1104) := 'a mollit qui nostrud consectetur sint aliqua quis."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_product';
wwv_flow_imp.g_varchar2_table(1105) := 's (product_id,product_name,unit_price,product_details) values (42,''Boy''''s Jeans (Black)'',16.64,json(';
wwv_flow_imp.g_varchar2_table(1106) := '''{"colour":"black","gender":"Boy''''s","brand":"EARTHMARK","description":"Duis dolor est eu elit anim ';
wwv_flow_imp.g_varchar2_table(1107) := 'proident aliqua eu tempor. Est fugiat non ullamco et pariatur nulla exercitation eiusmod id officia ';
wwv_flow_imp.g_varchar2_table(1108) := 'minim.","sizes":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":10,"review';
wwv_flow_imp.g_varchar2_table(1109) := '":"Anim aliquip id reprehenderit laboris."},{"rating":7,"review":"Nostrud non cupidatat id eiusmod a';
wwv_flow_imp.g_varchar2_table(1110) := 'liquip anim ullamco aliquip cupidatat excepteur dolor reprehenderit."},{"rating":6,"review":"Veniam ';
wwv_flow_imp.g_varchar2_table(1111) := 'consequat deserunt nostrud sunt est commodo sint eu fugiat ipsum deserunt aute elit est."},{"rating"';
wwv_flow_imp.g_varchar2_table(1112) := ':9,"review":"Eiusmod excepteur ut ullamco eiusmod labore deserunt."},{"rating":5,"review":"Aute dese';
wwv_flow_imp.g_varchar2_table(1113) := 'runt eu voluptate id irure aliquip duis sint proident dolore dolor."},{"rating":5,"review":"Dolore m';
wwv_flow_imp.g_varchar2_table(1114) := 'ollit quis elit qui voluptate ad culpa voluptate elit consectetur."}]}''));'||wwv_flow.LF||
'        insert into eba_d';
wwv_flow_imp.g_varchar2_table(1115) := 'emo_json_products (product_id,product_name,unit_price,product_details) values (43,''Boy''''s Trousers (';
wwv_flow_imp.g_varchar2_table(1116) := 'Black)'',39.32,json(''{"colour":"blue","gender":"Boy''''s","brand":"PHOLIO","description":"Voluptate ex ';
wwv_flow_imp.g_varchar2_table(1117) := 'mollit enim minim nulla proident dolor eu nostrud velit. Ex ullamco aute dolor duis elit elit.","siz';
wwv_flow_imp.g_varchar2_table(1118) := 'es":["1 Yr","2 Yr","3-4 Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":3,"review":"Labore non';
wwv_flow_imp.g_varchar2_table(1119) := ' exercitation anim id deserunt excepteur dolore sunt deserunt dolor."},{"rating":5,"review":"Laborum';
wwv_flow_imp.g_varchar2_table(1120) := ' eiusmod mollit amet nulla ex esse culpa ut elit reprehenderit labore ex Lorem cupidatat."},{"rating';
wwv_flow_imp.g_varchar2_table(1121) := '":7,"review":"Reprehenderit dolore aute consectetur voluptate excepteur veniam nulla ad."},{"rating"';
wwv_flow_imp.g_varchar2_table(1122) := ':5,"review":"Reprehenderit proident in elit pariatur."},{"rating":8,"review":"Magna laborum ad deser';
wwv_flow_imp.g_varchar2_table(1123) := 'unt voluptate enim excepteur enim dolore veniam consequat officia anim dolore mollit."},{"rating":3,';
wwv_flow_imp.g_varchar2_table(1124) := '"review":"Elit et reprehenderit amet aute amet laboris minim irure sint."}]}''));'||wwv_flow.LF||
'        insert into';
wwv_flow_imp.g_varchar2_table(1125) := ' eba_demo_json_products (product_id,product_name,unit_price,product_details) values (44,''Women''''s Co';
wwv_flow_imp.g_varchar2_table(1126) := 'at (Black)'',31.68,json(''{"colour":"black","gender":"Women''''s","brand":"COMVEYOR","description":"Exer';
wwv_flow_imp.g_varchar2_table(1127) := 'citation ut ad reprehenderit sunt eiusmod sit. Qui nisi ut esse mollit nisi.","sizes":[0,2,4,6,8,10,';
wwv_flow_imp.g_varchar2_table(1128) := '12,14,16,18,20],"reviews":[{"rating":7,"review":"Ad consequat nisi est tempor nisi nulla veniam cons';
wwv_flow_imp.g_varchar2_table(1129) := 'ectetur ad ut laborum magna."},{"rating":8,"review":"Incididunt magna ipsum cupidatat elit eiusmod e';
wwv_flow_imp.g_varchar2_table(1130) := 'nim mollit eiusmod id esse sit elit irure Lorem."},{"rating":7,"review":"Aute aliquip et esse conseq';
wwv_flow_imp.g_varchar2_table(1131) := 'uat reprehenderit ipsum ut."},{"rating":8,"review":"Consectetur commodo cupidatat nostrud qui labore';
wwv_flow_imp.g_varchar2_table(1132) := ' magna duis sit."},{"rating":8,"review":"Qui occaecat elit exercitation do est officia fugiat adipis';
wwv_flow_imp.g_varchar2_table(1133) := 'icing velit occaecat deserunt Lorem ex adipisicing."},{"rating":6,"review":"Velit est commodo esse s';
wwv_flow_imp.g_varchar2_table(1134) := 'int id ullamco aute ut ut officia laboris irure in."},{"rating":10,"review":"Ad nulla labore cupidat';
wwv_flow_imp.g_varchar2_table(1135) := 'at do laboris do elit cupidatat excepteur occaecat cupidatat."},{"rating":5,"review":"Do esse magna ';
wwv_flow_imp.g_varchar2_table(1136) := 'occaecat non."},{"rating":10,"review":"Et sint qui tempor nostrud sunt sit duis dolor excepteur volu';
wwv_flow_imp.g_varchar2_table(1137) := 'ptate."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id,product_name,unit_price,produc';
wwv_flow_imp.g_varchar2_table(1138) := 't_details) values (45,''Men''''s Jeans (Grey)'',27.64,json(''{"colour":"grey","gender":"Men''''s","brand":"';
wwv_flow_imp.g_varchar2_table(1139) := 'QNEKT","description":"Dolore duis minim dolor est fugiat sit dolor nisi anim Lorem culpa id. Consequ';
wwv_flow_imp.g_varchar2_table(1140) := 'at labore et reprehenderit pariatur culpa minim laboris pariatur esse aliquip.","sizes":["XS","S","M';
wwv_flow_imp.g_varchar2_table(1141) := '","L","XL","XXL"],"reviews":[{"rating":7,"review":"Veniam qui ipsum consequat laboris ad aliquip est';
wwv_flow_imp.g_varchar2_table(1142) := ' reprehenderit esse sint cupidatat tempor."},{"rating":8,"review":"Ut anim anim ipsum ipsum irure."}';
wwv_flow_imp.g_varchar2_table(1143) := ',{"rating":9,"review":"Non qui sunt ullamco deserunt sint."},{"rating":10,"review":"Nostrud fugiat v';
wwv_flow_imp.g_varchar2_table(1144) := 'elit aliqua eu culpa do excepteur do."}]}''));'||wwv_flow.LF||
'        insert into eba_demo_json_products (product_id';
wwv_flow_imp.g_varchar2_table(1145) := ',product_name,unit_price,product_details) values (46,''Girl''''s Trousers (Red)'',39.16,json(''{"colour":';
wwv_flow_imp.g_varchar2_table(1146) := '"red","gender":"Girl''''s","brand":"OTHERSIDE","description":"Lorem officia laborum deserunt veniam ci';
wwv_flow_imp.g_varchar2_table(1147) := 'llum anim adipisicing minim aute ad esse sint sit tempor. Magna enim proident eiusmod incididunt adi';
wwv_flow_imp.g_varchar2_table(1148) := 'pisicing duis deserunt pariatur sint officia occaecat est minim ipsum.","sizes":["1 Yr","2 Yr","3-4 ';
wwv_flow_imp.g_varchar2_table(1149) := 'Yr","5-6 Yr","7-8 Yr","9-10 Yr"],"reviews":[{"rating":9,"review":"Magna magna ullamco ipsum pariatur';
wwv_flow_imp.g_varchar2_table(1150) := ' occaecat eiusmod amet ea sunt reprehenderit dolore aute voluptate."},{"rating":7,"review":"Eiusmod ';
wwv_flow_imp.g_varchar2_table(1151) := 'cupidatat cillum qui dolor consequat."},{"rating":4,"review":"Do proident cillum cupidatat laboris i';
wwv_flow_imp.g_varchar2_table(1152) := 'n cillum."},{"rating":5,"review":"Sunt eiusmod ea labore est sint adipisicing velit duis."},{"rating';
wwv_flow_imp.g_varchar2_table(1153) := '":6,"review":"Ut consectetur ad magna officia ut aliqua deserunt magna."}]}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Order it';
wwv_flow_imp.g_varchar2_table(1154) := 'ems data'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,';
wwv_flow_imp.g_varchar2_table(1155) := 'quantity) values (349,1,11,30.69,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_it';
wwv_flow_imp.g_varchar2_table(1156) := 'em_id,product_id,unit_price,quantity) values (349,2,12,10.48,4);'||wwv_flow.LF||
'        insert into eba_demo_json_o';
wwv_flow_imp.g_varchar2_table(1157) := 'rder_items (order_id,line_item_id,product_id,unit_price,quantity) values (401,1,28,10.24,3);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(1158) := ' insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values';
wwv_flow_imp.g_varchar2_table(1159) := ' (401,2,12,10.48,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id';
wwv_flow_imp.g_varchar2_table(1160) := ',unit_price,quantity) values (430,1,18,24.46,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (orde';
wwv_flow_imp.g_varchar2_table(1161) := 'r_id,line_item_id,product_id,unit_price,quantity) values (430,2,15,13.97,5);'||wwv_flow.LF||
'        insert into eba';
wwv_flow_imp.g_varchar2_table(1162) := '_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (437,1,37,29.51';
wwv_flow_imp.g_varchar2_table(1163) := ',3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quan';
wwv_flow_imp.g_varchar2_table(1164) := 'tity) values (437,2,20,28.21,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_i';
wwv_flow_imp.g_varchar2_table(1165) := 'd,product_id,unit_price,quantity) values (453,1,43,16.64,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order';
wwv_flow_imp.g_varchar2_table(1166) := '_items (order_id,line_item_id,product_id,unit_price,quantity) values (453,2,2,29.55,2);'||wwv_flow.LF||
'        inse';
wwv_flow_imp.g_varchar2_table(1167) := 'rt into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (506';
wwv_flow_imp.g_varchar2_table(1168) := ',1,18,24.46,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit';
wwv_flow_imp.g_varchar2_table(1169) := '_price,quantity) values (506,2,21,38.34,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,';
wwv_flow_imp.g_varchar2_table(1170) := 'line_item_id,product_id,unit_price,quantity) values (513,1,11,30.69,3);'||wwv_flow.LF||
'        insert into eba_demo';
wwv_flow_imp.g_varchar2_table(1171) := '_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (513,2,4,44.17,2);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1172) := '       insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) ';
wwv_flow_imp.g_varchar2_table(1173) := 'values (513,3,19,14.34,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,prod';
wwv_flow_imp.g_varchar2_table(1174) := 'uct_id,unit_price,quantity) values (544,1,37,29.51,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items';
wwv_flow_imp.g_varchar2_table(1175) := ' (order_id,line_item_id,product_id,unit_price,quantity) values (544,2,6,38.28,2);'||wwv_flow.LF||
'        insert int';
wwv_flow_imp.g_varchar2_table(1176) := 'o eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (544,3,27,';
wwv_flow_imp.g_varchar2_table(1177) := '39.91,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price';
wwv_flow_imp.g_varchar2_table(1178) := ',quantity) values (585,1,29,24.71,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_i';
wwv_flow_imp.g_varchar2_table(1179) := 'tem_id,product_id,unit_price,quantity) values (585,2,31,28.59,2);'||wwv_flow.LF||
'        insert into eba_demo_json_';
wwv_flow_imp.g_varchar2_table(1180) := 'order_items (order_id,line_item_id,product_id,unit_price,quantity) values (585,3,37,29.51,4);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(1181) := '  insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) value';
wwv_flow_imp.g_varchar2_table(1182) := 's (608,1,15,13.97,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_i';
wwv_flow_imp.g_varchar2_table(1183) := 'd,unit_price,quantity) values (608,2,23,10.33,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (ord';
wwv_flow_imp.g_varchar2_table(1184) := 'er_id,line_item_id,product_id,unit_price,quantity) values (608,3,35,7.18,3);'||wwv_flow.LF||
'        insert into eba';
wwv_flow_imp.g_varchar2_table(1185) := '_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (672,1,46,39.16';
wwv_flow_imp.g_varchar2_table(1186) := ',4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quan';
wwv_flow_imp.g_varchar2_table(1187) := 'tity) values (687,1,42,10.11,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_i';
wwv_flow_imp.g_varchar2_table(1188) := 'd,product_id,unit_price,quantity) values (687,2,13,12.64,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order';
wwv_flow_imp.g_varchar2_table(1189) := '_items (order_id,line_item_id,product_id,unit_price,quantity) values (707,1,18,24.46,3);'||wwv_flow.LF||
'        ins';
wwv_flow_imp.g_varchar2_table(1190) := 'ert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (76';
wwv_flow_imp.g_varchar2_table(1191) := '0,1,46,39.16,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,uni';
wwv_flow_imp.g_varchar2_table(1192) := 't_price,quantity) values (760,2,20,28.21,1);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id';
wwv_flow_imp.g_varchar2_table(1193) := ',line_item_id,product_id,unit_price,quantity) values (761,1,33,37,3);'||wwv_flow.LF||
'        insert into eba_demo_j';
wwv_flow_imp.g_varchar2_table(1194) := 'son_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (761,2,2,29.55,2);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(1195) := '     insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) va';
wwv_flow_imp.g_varchar2_table(1196) := 'lues (765,1,34,23.32,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,produc';
wwv_flow_imp.g_varchar2_table(1197) := 't_id,unit_price,quantity) values (765,2,13,12.64,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (';
wwv_flow_imp.g_varchar2_table(1198) := 'order_id,line_item_id,product_id,unit_price,quantity) values (766,1,12,10.48,3);'||wwv_flow.LF||
'        insert into';
wwv_flow_imp.g_varchar2_table(1199) := ' eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (769,1,42,1';
wwv_flow_imp.g_varchar2_table(1200) := '0.11,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,';
wwv_flow_imp.g_varchar2_table(1201) := 'quantity) values (808,1,39,11,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_';
wwv_flow_imp.g_varchar2_table(1202) := 'id,product_id,unit_price,quantity) values (808,2,13,12.64,3);'||wwv_flow.LF||
'        insert into eba_demo_json_orde';
wwv_flow_imp.g_varchar2_table(1203) := 'r_items (order_id,line_item_id,product_id,unit_price,quantity) values (1,1,33,37,4);'||wwv_flow.LF||
'        insert ';
wwv_flow_imp.g_varchar2_table(1204) := 'into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1,2,11';
wwv_flow_imp.g_varchar2_table(1205) := ',30.69,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_pric';
wwv_flow_imp.g_varchar2_table(1206) := 'e,quantity) values (3,1,41,8.66,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_ite';
wwv_flow_imp.g_varchar2_table(1207) := 'm_id,product_id,unit_price,quantity) values (5,1,40,34.06,4);'||wwv_flow.LF||
'        insert into eba_demo_json_orde';
wwv_flow_imp.g_varchar2_table(1208) := 'r_items (order_id,line_item_id,product_id,unit_price,quantity) values (5,2,32,5.65,3);'||wwv_flow.LF||
'        inser';
wwv_flow_imp.g_varchar2_table(1209) := 't into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (7,1,';
wwv_flow_imp.g_varchar2_table(1210) := '36,49.12,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_pr';
wwv_flow_imp.g_varchar2_table(1211) := 'ice,quantity) values (7,2,29,24.71,1);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_';
wwv_flow_imp.g_varchar2_table(1212) := 'item_id,product_id,unit_price,quantity) values (17,1,46,39.16,4);'||wwv_flow.LF||
'        insert into eba_demo_json_';
wwv_flow_imp.g_varchar2_table(1213) := 'order_items (order_id,line_item_id,product_id,unit_price,quantity) values (17,2,26,48.75,4);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(1214) := ' insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values';
wwv_flow_imp.g_varchar2_table(1215) := ' (20,1,27,39.91,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,';
wwv_flow_imp.g_varchar2_table(1216) := 'unit_price,quantity) values (20,2,9,21.16,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_i';
wwv_flow_imp.g_varchar2_table(1217) := 'd,line_item_id,product_id,unit_price,quantity) values (20,3,32,5.65,2);'||wwv_flow.LF||
'        insert into eba_demo';
wwv_flow_imp.g_varchar2_table(1218) := '_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (63,1,7,19.16,3);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(1219) := '      insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) v';
wwv_flow_imp.g_varchar2_table(1220) := 'alues (63,2,24,48.39,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,produc';
wwv_flow_imp.g_varchar2_table(1221) := 't_id,unit_price,quantity) values (78,1,3,16.67,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (or';
wwv_flow_imp.g_varchar2_table(1222) := 'der_id,line_item_id,product_id,unit_price,quantity) values (78,2,35,7.18,1);'||wwv_flow.LF||
'        insert into eba';
wwv_flow_imp.g_varchar2_table(1223) := '_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (78,3,9,21.16,5';
wwv_flow_imp.g_varchar2_table(1224) := ');'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quanti';
wwv_flow_imp.g_varchar2_table(1225) := 'ty) values (79,1,34,23.32,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,p';
wwv_flow_imp.g_varchar2_table(1226) := 'roduct_id,unit_price,quantity) values (79,2,8,19.58,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_item';
wwv_flow_imp.g_varchar2_table(1227) := 's (order_id,line_item_id,product_id,unit_price,quantity) values (79,3,4,44.17,3);'||wwv_flow.LF||
'        insert int';
wwv_flow_imp.g_varchar2_table(1228) := 'o eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (82,1,21,3';
wwv_flow_imp.g_varchar2_table(1229) := '8.34,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,';
wwv_flow_imp.g_varchar2_table(1230) := 'quantity) values (82,2,10,29.49,1);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_ite';
wwv_flow_imp.g_varchar2_table(1231) := 'm_id,product_id,unit_price,quantity) values (92,1,15,13.97,1);'||wwv_flow.LF||
'        insert into eba_demo_json_ord';
wwv_flow_imp.g_varchar2_table(1232) := 'er_items (order_id,line_item_id,product_id,unit_price,quantity) values (125,1,22,39.78,2);'||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(1233) := 'nsert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (';
wwv_flow_imp.g_varchar2_table(1234) := '125,2,39,11,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit';
wwv_flow_imp.g_varchar2_table(1235) := '_price,quantity) values (132,1,11,30.69,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,';
wwv_flow_imp.g_varchar2_table(1236) := 'line_item_id,product_id,unit_price,quantity) values (132,2,31,28.59,2);'||wwv_flow.LF||
'        insert into eba_demo';
wwv_flow_imp.g_varchar2_table(1237) := '_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (132,3,10,29.49,4);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1238) := '        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity)';
wwv_flow_imp.g_varchar2_table(1239) := ' values (159,1,8,19.58,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,prod';
wwv_flow_imp.g_varchar2_table(1240) := 'uct_id,unit_price,quantity) values (182,1,23,10.33,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items';
wwv_flow_imp.g_varchar2_table(1241) := ' (order_id,line_item_id,product_id,unit_price,quantity) values (182,2,20,28.21,2);'||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(1242) := 'to eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (196,1,3,';
wwv_flow_imp.g_varchar2_table(1243) := '16.67,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price';
wwv_flow_imp.g_varchar2_table(1244) := ',quantity) values (196,2,23,10.33,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_i';
wwv_flow_imp.g_varchar2_table(1245) := 'tem_id,product_id,unit_price,quantity) values (201,1,19,14.34,4);'||wwv_flow.LF||
'        insert into eba_demo_json_';
wwv_flow_imp.g_varchar2_table(1246) := 'order_items (order_id,line_item_id,product_id,unit_price,quantity) values (201,2,36,49.12,2);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(1247) := '  insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) value';
wwv_flow_imp.g_varchar2_table(1248) := 's (204,1,33,37,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,u';
wwv_flow_imp.g_varchar2_table(1249) := 'nit_price,quantity) values (204,2,12,10.48,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_';
wwv_flow_imp.g_varchar2_table(1250) := 'id,line_item_id,product_id,unit_price,quantity) values (240,1,12,10.48,2);'||wwv_flow.LF||
'        insert into eba_d';
wwv_flow_imp.g_varchar2_table(1251) := 'emo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (240,2,17,39.89,4';
wwv_flow_imp.g_varchar2_table(1252) := ');'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quanti';
wwv_flow_imp.g_varchar2_table(1253) := 'ty) values (290,1,11,30.69,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,';
wwv_flow_imp.g_varchar2_table(1254) := 'product_id,unit_price,quantity) values (290,2,27,39.91,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_i';
wwv_flow_imp.g_varchar2_table(1255) := 'tems (order_id,line_item_id,product_id,unit_price,quantity) values (290,3,38,22.98,2);'||wwv_flow.LF||
'        inser';
wwv_flow_imp.g_varchar2_table(1256) := 't into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (298,';
wwv_flow_imp.g_varchar2_table(1257) := '1,9,21.16,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_p';
wwv_flow_imp.g_varchar2_table(1258) := 'rice,quantity) values (298,2,43,16.64,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,li';
wwv_flow_imp.g_varchar2_table(1259) := 'ne_item_id,product_id,unit_price,quantity) values (306,1,28,10.24,3);'||wwv_flow.LF||
'        insert into eba_demo_j';
wwv_flow_imp.g_varchar2_table(1260) := 'son_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (307,1,38,22.98,4);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(1261) := '      insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) v';
wwv_flow_imp.g_varchar2_table(1262) := 'alues (307,2,19,14.34,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,produ';
wwv_flow_imp.g_varchar2_table(1263) := 'ct_id,unit_price,quantity) values (331,1,34,23.32,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items ';
wwv_flow_imp.g_varchar2_table(1264) := '(order_id,line_item_id,product_id,unit_price,quantity) values (1483,1,46,39.16,5);'||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(1265) := 'to eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1483,2,2';
wwv_flow_imp.g_varchar2_table(1266) := '3,10.33,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_pri';
wwv_flow_imp.g_varchar2_table(1267) := 'ce,quantity) values (1483,3,14,26.14,1);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,lin';
wwv_flow_imp.g_varchar2_table(1268) := 'e_item_id,product_id,unit_price,quantity) values (1486,1,44,39.32,3);'||wwv_flow.LF||
'        insert into eba_demo_j';
wwv_flow_imp.g_varchar2_table(1269) := 'son_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1486,2,36,49.12,2);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1270) := '       insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) ';
wwv_flow_imp.g_varchar2_table(1271) := 'values (1486,3,14,26.14,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,pro';
wwv_flow_imp.g_varchar2_table(1272) := 'duct_id,unit_price,quantity) values (1491,1,12,10.48,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_ite';
wwv_flow_imp.g_varchar2_table(1273) := 'ms (order_id,line_item_id,product_id,unit_price,quantity) values (1498,1,16,13.09,2);'||wwv_flow.LF||
'        insert';
wwv_flow_imp.g_varchar2_table(1274) := ' into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1498,';
wwv_flow_imp.g_varchar2_table(1275) := '2,5,43.71,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_p';
wwv_flow_imp.g_varchar2_table(1276) := 'rice,quantity) values (1513,1,36,49.12,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,l';
wwv_flow_imp.g_varchar2_table(1277) := 'ine_item_id,product_id,unit_price,quantity) values (1513,2,5,43.71,1);'||wwv_flow.LF||
'        insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(1278) := 'json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1513,3,44,39.32,4);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1279) := '        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity)';
wwv_flow_imp.g_varchar2_table(1280) := ' values (1520,1,13,12.64,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,pr';
wwv_flow_imp.g_varchar2_table(1281) := 'oduct_id,unit_price,quantity) values (1520,2,46,27.64,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_it';
wwv_flow_imp.g_varchar2_table(1282) := 'ems (order_id,line_item_id,product_id,unit_price,quantity) values (1520,3,33,37,1);'||wwv_flow.LF||
'        insert i';
wwv_flow_imp.g_varchar2_table(1283) := 'nto eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1525,1,';
wwv_flow_imp.g_varchar2_table(1284) := '40,34.06,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_pr';
wwv_flow_imp.g_varchar2_table(1285) := 'ice,quantity) values (1525,2,17,39.89,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,li';
wwv_flow_imp.g_varchar2_table(1286) := 'ne_item_id,product_id,unit_price,quantity) values (1543,1,21,38.34,1);'||wwv_flow.LF||
'        insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(1287) := 'json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1543,2,26,48.75,3);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1288) := '        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity)';
wwv_flow_imp.g_varchar2_table(1289) := ' values (1543,3,11,30.69,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,pr';
wwv_flow_imp.g_varchar2_table(1290) := 'oduct_id,unit_price,quantity) values (1549,1,14,26.14,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_it';
wwv_flow_imp.g_varchar2_table(1291) := 'ems (order_id,line_item_id,product_id,unit_price,quantity) values (1549,2,43,16.64,4);'||wwv_flow.LF||
'        inser';
wwv_flow_imp.g_varchar2_table(1292) := 't into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1552';
wwv_flow_imp.g_varchar2_table(1293) := ',1,34,23.32,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit';
wwv_flow_imp.g_varchar2_table(1294) := '_price,quantity) values (1555,1,17,39.89,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id';
wwv_flow_imp.g_varchar2_table(1295) := ',line_item_id,product_id,unit_price,quantity) values (1555,2,34,23.32,2);'||wwv_flow.LF||
'        insert into eba_de';
wwv_flow_imp.g_varchar2_table(1296) := 'mo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1560,1,8,19.58,5)';
wwv_flow_imp.g_varchar2_table(1297) := ';'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantit';
wwv_flow_imp.g_varchar2_table(1298) := 'y) values (1560,2,21,38.34,1);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,';
wwv_flow_imp.g_varchar2_table(1299) := 'product_id,unit_price,quantity) values (1561,1,43,16.64,1);'||wwv_flow.LF||
'        insert into eba_demo_json_order_';
wwv_flow_imp.g_varchar2_table(1300) := 'items (order_id,line_item_id,product_id,unit_price,quantity) values (1561,2,7,19.16,3);'||wwv_flow.LF||
'        inse';
wwv_flow_imp.g_varchar2_table(1301) := 'rt into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (163';
wwv_flow_imp.g_varchar2_table(1302) := '5,1,15,13.97,1);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,uni';
wwv_flow_imp.g_varchar2_table(1303) := 't_price,quantity) values (1635,2,4,44.17,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id';
wwv_flow_imp.g_varchar2_table(1304) := ',line_item_id,product_id,unit_price,quantity) values (1635,3,36,49.12,2);'||wwv_flow.LF||
'        insert into eba_de';
wwv_flow_imp.g_varchar2_table(1305) := 'mo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1637,1,25,9.8,2);';
wwv_flow_imp.g_varchar2_table(1306) := ''||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity';
wwv_flow_imp.g_varchar2_table(1307) := ') values (1659,1,14,26.14,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,p';
wwv_flow_imp.g_varchar2_table(1308) := 'roduct_id,unit_price,quantity) values (1730,1,20,28.21,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_i';
wwv_flow_imp.g_varchar2_table(1309) := 'tems (order_id,line_item_id,product_id,unit_price,quantity) values (1730,2,11,30.69,3);'||wwv_flow.LF||
'        inse';
wwv_flow_imp.g_varchar2_table(1310) := 'rt into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (173';
wwv_flow_imp.g_varchar2_table(1311) := '1,1,39,11,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_p';
wwv_flow_imp.g_varchar2_table(1312) := 'rice,quantity) values (1731,2,21,38.34,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,l';
wwv_flow_imp.g_varchar2_table(1313) := 'ine_item_id,product_id,unit_price,quantity) values (1776,1,34,23.32,1);'||wwv_flow.LF||
'        insert into eba_demo';
wwv_flow_imp.g_varchar2_table(1314) := '_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1776,2,25,9.8,2);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1315) := '       insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) ';
wwv_flow_imp.g_varchar2_table(1316) := 'values (1776,3,20,28.21,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,pro';
wwv_flow_imp.g_varchar2_table(1317) := 'duct_id,unit_price,quantity) values (1808,1,14,26.14,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_ite';
wwv_flow_imp.g_varchar2_table(1318) := 'ms (order_id,line_item_id,product_id,unit_price,quantity) values (1817,1,34,23.32,3);'||wwv_flow.LF||
'        insert';
wwv_flow_imp.g_varchar2_table(1319) := ' into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1817,';
wwv_flow_imp.g_varchar2_table(1320) := '2,42,10.11,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_';
wwv_flow_imp.g_varchar2_table(1321) := 'price,quantity) values (1817,3,22,39.78,1);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,';
wwv_flow_imp.g_varchar2_table(1322) := 'line_item_id,product_id,unit_price,quantity) values (1890,1,2,29.55,3);'||wwv_flow.LF||
'        insert into eba_demo';
wwv_flow_imp.g_varchar2_table(1323) := '_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1890,2,46,39.16,3);';
wwv_flow_imp.g_varchar2_table(1324) := ''||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity';
wwv_flow_imp.g_varchar2_table(1325) := ') values (832,1,10,29.49,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,pr';
wwv_flow_imp.g_varchar2_table(1326) := 'oduct_id,unit_price,quantity) values (832,2,9,21.16,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_item';
wwv_flow_imp.g_varchar2_table(1327) := 's (order_id,line_item_id,product_id,unit_price,quantity) values (839,1,38,22.98,3);'||wwv_flow.LF||
'        insert i';
wwv_flow_imp.g_varchar2_table(1328) := 'nto eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (839,2,7';
wwv_flow_imp.g_varchar2_table(1329) := ',19.16,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_pric';
wwv_flow_imp.g_varchar2_table(1330) := 'e,quantity) values (862,1,23,10.33,1);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_';
wwv_flow_imp.g_varchar2_table(1331) := 'item_id,product_id,unit_price,quantity) values (862,2,33,37,4);'||wwv_flow.LF||
'        insert into eba_demo_json_or';
wwv_flow_imp.g_varchar2_table(1332) := 'der_items (order_id,line_item_id,product_id,unit_price,quantity) values (899,1,31,28.59,2);'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(1333) := 'insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values ';
wwv_flow_imp.g_varchar2_table(1334) := '(920,1,41,8.66,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,u';
wwv_flow_imp.g_varchar2_table(1335) := 'nit_price,quantity) values (920,2,4,44.17,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_i';
wwv_flow_imp.g_varchar2_table(1336) := 'd,line_item_id,product_id,unit_price,quantity) values (928,1,3,16.67,2);'||wwv_flow.LF||
'        insert into eba_dem';
wwv_flow_imp.g_varchar2_table(1337) := 'o_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (928,2,12,10.48,4);';
wwv_flow_imp.g_varchar2_table(1338) := ''||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity';
wwv_flow_imp.g_varchar2_table(1339) := ') values (928,3,35,7.18,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,pro';
wwv_flow_imp.g_varchar2_table(1340) := 'duct_id,unit_price,quantity) values (943,1,6,38.28,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items';
wwv_flow_imp.g_varchar2_table(1341) := ' (order_id,line_item_id,product_id,unit_price,quantity) values (950,1,22,39.78,3);'||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(1342) := 'to eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (950,2,23';
wwv_flow_imp.g_varchar2_table(1343) := ',10.33,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_pric';
wwv_flow_imp.g_varchar2_table(1344) := 'e,quantity) values (960,1,26,48.75,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_';
wwv_flow_imp.g_varchar2_table(1345) := 'item_id,product_id,unit_price,quantity) values (960,2,43,16.64,3);'||wwv_flow.LF||
'        insert into eba_demo_json';
wwv_flow_imp.g_varchar2_table(1346) := '_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (960,3,24,48.39,1);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(1347) := '   insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) valu';
wwv_flow_imp.g_varchar2_table(1348) := 'es (968,1,30,37.34,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_';
wwv_flow_imp.g_varchar2_table(1349) := 'id,unit_price,quantity) values (968,2,13,12.64,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (or';
wwv_flow_imp.g_varchar2_table(1350) := 'der_id,line_item_id,product_id,unit_price,quantity) values (968,3,35,7.18,3);'||wwv_flow.LF||
'        insert into eb';
wwv_flow_imp.g_varchar2_table(1351) := 'a_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (972,1,27,39.9';
wwv_flow_imp.g_varchar2_table(1352) := '1,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,qua';
wwv_flow_imp.g_varchar2_table(1353) := 'ntity) values (972,2,23,10.33,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_';
wwv_flow_imp.g_varchar2_table(1354) := 'id,product_id,unit_price,quantity) values (986,1,12,10.48,3);'||wwv_flow.LF||
'        insert into eba_demo_json_orde';
wwv_flow_imp.g_varchar2_table(1355) := 'r_items (order_id,line_item_id,product_id,unit_price,quantity) values (986,2,14,26.14,5);'||wwv_flow.LF||
'        in';
wwv_flow_imp.g_varchar2_table(1356) := 'sert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (9';
wwv_flow_imp.g_varchar2_table(1357) := '93,1,35,7.18,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,uni';
wwv_flow_imp.g_varchar2_table(1358) := 't_price,quantity) values (993,2,14,26.14,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id';
wwv_flow_imp.g_varchar2_table(1359) := ',line_item_id,product_id,unit_price,quantity) values (993,3,19,14.34,4);'||wwv_flow.LF||
'        insert into eba_dem';
wwv_flow_imp.g_varchar2_table(1360) := 'o_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1052,1,36,49.12,4)';
wwv_flow_imp.g_varchar2_table(1361) := ';'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantit';
wwv_flow_imp.g_varchar2_table(1362) := 'y) values (1052,2,33,37,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,pro';
wwv_flow_imp.g_varchar2_table(1363) := 'duct_id,unit_price,quantity) values (1052,3,44,39.32,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_ite';
wwv_flow_imp.g_varchar2_table(1364) := 'ms (order_id,line_item_id,product_id,unit_price,quantity) values (1058,1,16,13.09,5);'||wwv_flow.LF||
'        insert';
wwv_flow_imp.g_varchar2_table(1365) := ' into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1058,';
wwv_flow_imp.g_varchar2_table(1366) := '2,34,23.32,1);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_';
wwv_flow_imp.g_varchar2_table(1367) := 'price,quantity) values (1058,3,2,29.55,1);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,l';
wwv_flow_imp.g_varchar2_table(1368) := 'ine_item_id,product_id,unit_price,quantity) values (1082,1,22,39.78,3);'||wwv_flow.LF||
'        insert into eba_demo';
wwv_flow_imp.g_varchar2_table(1369) := '_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1082,2,20,28.21,2);';
wwv_flow_imp.g_varchar2_table(1370) := ''||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity';
wwv_flow_imp.g_varchar2_table(1371) := ') values (1102,1,10,29.49,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,p';
wwv_flow_imp.g_varchar2_table(1372) := 'roduct_id,unit_price,quantity) values (1102,2,39,11,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_item';
wwv_flow_imp.g_varchar2_table(1373) := 's (order_id,line_item_id,product_id,unit_price,quantity) values (1102,3,14,26.14,2);'||wwv_flow.LF||
'        insert ';
wwv_flow_imp.g_varchar2_table(1374) := 'into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1111,1';
wwv_flow_imp.g_varchar2_table(1375) := ',41,8.66,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_pr';
wwv_flow_imp.g_varchar2_table(1376) := 'ice,quantity) values (1111,2,13,12.64,1);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,li';
wwv_flow_imp.g_varchar2_table(1377) := 'ne_item_id,product_id,unit_price,quantity) values (1119,1,25,9.8,3);'||wwv_flow.LF||
'        insert into eba_demo_js';
wwv_flow_imp.g_varchar2_table(1378) := 'on_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1119,2,9,21.16,4);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(1379) := '     insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) va';
wwv_flow_imp.g_varchar2_table(1380) := 'lues (1119,3,45,31.68,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,produ';
wwv_flow_imp.g_varchar2_table(1381) := 'ct_id,unit_price,quantity) values (1121,1,27,39.91,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items';
wwv_flow_imp.g_varchar2_table(1382) := ' (order_id,line_item_id,product_id,unit_price,quantity) values (1169,1,9,21.16,2);'||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(1383) := 'to eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1169,2,2';
wwv_flow_imp.g_varchar2_table(1384) := '2,39.78,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_pri';
wwv_flow_imp.g_varchar2_table(1385) := 'ce,quantity) values (1191,1,33,37,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_i';
wwv_flow_imp.g_varchar2_table(1386) := 'tem_id,product_id,unit_price,quantity) values (1191,2,40,34.06,3);'||wwv_flow.LF||
'        insert into eba_demo_json';
wwv_flow_imp.g_varchar2_table(1387) := '_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1191,3,14,26.14,3);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(1388) := '    insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) val';
wwv_flow_imp.g_varchar2_table(1389) := 'ues (1195,1,13,12.64,1);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,produc';
wwv_flow_imp.g_varchar2_table(1390) := 't_id,unit_price,quantity) values (1200,1,19,14.34,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items ';
wwv_flow_imp.g_varchar2_table(1391) := '(order_id,line_item_id,product_id,unit_price,quantity) values (1200,2,27,39.91,3);'||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(1392) := 'to eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1200,3,7';
wwv_flow_imp.g_varchar2_table(1393) := ',19.16,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_pric';
wwv_flow_imp.g_varchar2_table(1394) := 'e,quantity) values (1260,1,30,37.34,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line';
wwv_flow_imp.g_varchar2_table(1395) := '_item_id,product_id,unit_price,quantity) values (1260,2,5,43.71,4);'||wwv_flow.LF||
'        insert into eba_demo_jso';
wwv_flow_imp.g_varchar2_table(1396) := 'n_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1321,1,43,16.64,2);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(1397) := '     insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) va';
wwv_flow_imp.g_varchar2_table(1398) := 'lues (1321,2,37,29.51,1);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,produ';
wwv_flow_imp.g_varchar2_table(1399) := 'ct_id,unit_price,quantity) values (1321,3,46,39.16,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items';
wwv_flow_imp.g_varchar2_table(1400) := ' (order_id,line_item_id,product_id,unit_price,quantity) values (1348,1,31,28.59,2);'||wwv_flow.LF||
'        insert i';
wwv_flow_imp.g_varchar2_table(1401) := 'nto eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1348,2,';
wwv_flow_imp.g_varchar2_table(1402) := '23,10.33,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_pr';
wwv_flow_imp.g_varchar2_table(1403) := 'ice,quantity) values (1348,3,3,16.67,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,lin';
wwv_flow_imp.g_varchar2_table(1404) := 'e_item_id,product_id,unit_price,quantity) values (1363,1,11,30.69,4);'||wwv_flow.LF||
'        insert into eba_demo_j';
wwv_flow_imp.g_varchar2_table(1405) := 'son_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1363,2,14,26.14,2);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1406) := '       insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) ';
wwv_flow_imp.g_varchar2_table(1407) := 'values (1373,1,17,39.89,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,pro';
wwv_flow_imp.g_varchar2_table(1408) := 'duct_id,unit_price,quantity) values (1373,2,29,24.71,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_ite';
wwv_flow_imp.g_varchar2_table(1409) := 'ms (order_id,line_item_id,product_id,unit_price,quantity) values (1390,1,12,10.48,2);'||wwv_flow.LF||
'        insert';
wwv_flow_imp.g_varchar2_table(1410) := ' into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1390,';
wwv_flow_imp.g_varchar2_table(1411) := '2,28,10.24,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_';
wwv_flow_imp.g_varchar2_table(1412) := 'price,quantity) values (1390,3,9,21.16,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,l';
wwv_flow_imp.g_varchar2_table(1413) := 'ine_item_id,product_id,unit_price,quantity) values (1400,1,11,30.69,5);'||wwv_flow.LF||
'        insert into eba_demo';
wwv_flow_imp.g_varchar2_table(1414) := '_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1400,2,6,38.28,5);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1415) := '        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity)';
wwv_flow_imp.g_varchar2_table(1416) := ' values (1418,1,31,28.59,2);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,pr';
wwv_flow_imp.g_varchar2_table(1417) := 'oduct_id,unit_price,quantity) values (1418,2,45,31.68,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_it';
wwv_flow_imp.g_varchar2_table(1418) := 'ems (order_id,line_item_id,product_id,unit_price,quantity) values (1437,1,3,16.67,3);'||wwv_flow.LF||
'        insert';
wwv_flow_imp.g_varchar2_table(1419) := ' into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1439,';
wwv_flow_imp.g_varchar2_table(1420) := '1,46,27.64,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_';
wwv_flow_imp.g_varchar2_table(1421) := 'price,quantity) values (1439,2,9,21.16,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,l';
wwv_flow_imp.g_varchar2_table(1422) := 'ine_item_id,product_id,unit_price,quantity) values (1448,1,2,29.55,2);'||wwv_flow.LF||
'        insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(1423) := 'json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1450,1,4,44.17,3);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(1424) := '       insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) ';
wwv_flow_imp.g_varchar2_table(1425) := 'values (1451,1,10,29.49,5);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,pro';
wwv_flow_imp.g_varchar2_table(1426) := 'duct_id,unit_price,quantity) values (1451,2,35,7.18,4);'||wwv_flow.LF||
'        insert into eba_demo_json_order_item';
wwv_flow_imp.g_varchar2_table(1427) := 's (order_id,line_item_id,product_id,unit_price,quantity) values (1455,1,45,31.68,3);'||wwv_flow.LF||
'        insert ';
wwv_flow_imp.g_varchar2_table(1428) := 'into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1455,2';
wwv_flow_imp.g_varchar2_table(1429) := ',23,10.33,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_p';
wwv_flow_imp.g_varchar2_table(1430) := 'rice,quantity) values (1468,1,2,29.55,3);'||wwv_flow.LF||
'        insert into eba_demo_json_order_items (order_id,li';
wwv_flow_imp.g_varchar2_table(1431) := 'ne_item_id,product_id,unit_price,quantity) values (1468,2,45,31.68,4);'||wwv_flow.LF||
'        insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(1432) := 'json_order_items (order_id,line_item_id,product_id,unit_price,quantity) values (1471,1,14,26.14,2);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1433) := '        insert into eba_demo_json_order_items (order_id,line_item_id,product_id,unit_price,quantity)';
wwv_flow_imp.g_varchar2_table(1434) := ' values (1471,2,6,38.28,3);'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Support Ticket data'||wwv_flow.LF||
'        insert into eba_demo_json_suppor';
wwv_flow_imp.g_varchar2_table(1435) := 't_ticket (data) values (json(''{"ticket_id": 1,"title": "Wrong item delivered","description": "I orde';
wwv_flow_imp.g_varchar2_table(1436) := 'red a Boy''''s Trousers but received jeans instead.","status": "Open","priority": "High","created_at":';
wwv_flow_imp.g_varchar2_table(1437) := ' "2025-01-10","updated_at": "2025-01-11","customer_id": 4,"concern": {"order_id": 453,"product_id": ';
wwv_flow_imp.g_varchar2_table(1438) := '43,"store_id": 4},"comments": [{"comment_id": 1,"author": "agent","message": "We are looking into th';
wwv_flow_imp.g_varchar2_table(1439) := 'is issue.","created_at": "2025-01-10"},{"comment_id": 2,"author": "Victor Morris","message": "Please';
wwv_flow_imp.g_varchar2_table(1440) := ' hurry, I need it urgently.","created_at": "2025-01-11"}],"resolution": null}''));'||wwv_flow.LF||
'        insert int';
wwv_flow_imp.g_varchar2_table(1441) := 'o eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 2,"title": "Product damaged on arr';
wwv_flow_imp.g_varchar2_table(1442) := 'ival","description": "The pyjamas has a hole in it.","status": "Resolved","priority": "Medium","crea';
wwv_flow_imp.g_varchar2_table(1443) := 'ted_at": "2025-02-14","updated_at": "2025-02-16","customer_id": 4,"concern": {"order_id": 506,"produ';
wwv_flow_imp.g_varchar2_table(1444) := 'ct_id": 21,"store_id": 1},"comments": [{"comment_id": 3,"author": "agent","message": "Replacement ha';
wwv_flow_imp.g_varchar2_table(1445) := 's been shipped.","created_at": "2025-02-15"}],"resolution": "Replacement product sent to customer on';
wwv_flow_imp.g_varchar2_table(1446) := ' 2025-02-15."}''));'||wwv_flow.LF||
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id';
wwv_flow_imp.g_varchar2_table(1447) := '": 3,"title": "Store location incorrect on website","description": "The address listed for the store';
wwv_flow_imp.g_varchar2_table(1448) := ' is wrong.","status": "Pending","priority": "Low","created_at": "2025-03-01","updated_at": "2025-03-';
wwv_flow_imp.g_varchar2_table(1449) := '01","customer_id": 3,"concern": {"order_id": 544,"product_id": 37,"store_id": 1},"comments": [],"res';
wwv_flow_imp.g_varchar2_table(1450) := 'olution": null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_i';
wwv_flow_imp.g_varchar2_table(1451) := 'd": 4,"title": "Order never arrived","description": "My order was marked as delivered but I never re';
wwv_flow_imp.g_varchar2_table(1452) := 'ceived it.","status": "Open","priority": "High","created_at": "2025-03-05","updated_at": "2025-03-06';
wwv_flow_imp.g_varchar2_table(1453) := '","customer_id": 15,"concern": {"order_id": 513,"product_id": 4,"store_id": 1},"comments": [{"commen';
wwv_flow_imp.g_varchar2_table(1454) := 't_id": 4,"author": "agent","message": "We have contacted the delivery team.","created_at": "2025-03-';
wwv_flow_imp.g_varchar2_table(1455) := '06"}],"resolution": null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_support_ticket (data) values (json(''';
wwv_flow_imp.g_varchar2_table(1456) := '{"ticket_id": 5,"title": "Refund not processed","description": "I returned the item 2 weeks ago but ';
wwv_flow_imp.g_varchar2_table(1457) := 'still no refund.","status": "Pending","priority": "High","created_at": "2025-03-08","updated_at": "2';
wwv_flow_imp.g_varchar2_table(1458) := '025-03-09","customer_id": 4,"concern": {"order_id": 672,"product_id": 46,"store_id": 4},"comments": ';
wwv_flow_imp.g_varchar2_table(1459) := '[{"comment_id": 5,"author": "agent","message": "Refund request has been escalated to finance team.",';
wwv_flow_imp.g_varchar2_table(1460) := '"created_at": "2025-03-08"},{"comment_id": 6,"author": "Victor Morris","message": "This is taking to';
wwv_flow_imp.g_varchar2_table(1461) := 'o long, very disappointed.","created_at": "2025-03-09"}],"resolution": null}''));'||wwv_flow.LF||
'        insert into';
wwv_flow_imp.g_varchar2_table(1462) := ' eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 6,"title": "Incorrect charge on my ';
wwv_flow_imp.g_varchar2_table(1463) := 'account","description": "I was charged twice for the same order.","status": "Open","priority": "High';
wwv_flow_imp.g_varchar2_table(1464) := '","created_at": "2025-01-15","updated_at": "2025-01-16","customer_id": 15,"concern": {"order_id": 14';
wwv_flow_imp.g_varchar2_table(1465) := '00,"product_id": 11,"store_id": 15},"comments": [{"comment_id": 7,"author": "agent","message": "We a';
wwv_flow_imp.g_varchar2_table(1466) := 're verifying the payment records.","created_at": "2025-01-15"},{"comment_id": 8,"author": "Walter Ro';
wwv_flow_imp.g_varchar2_table(1467) := 'gers","message": "Please resolve this ASAP.","created_at": "2025-01-16"}],"resolution": null}''));'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(1468) := '      insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 7,"title": "Produc';
wwv_flow_imp.g_varchar2_table(1469) := 't not as described","description": "The socks I received is much different than shown on the website';
wwv_flow_imp.g_varchar2_table(1470) := '.","status": "Resolved","priority": "Medium","created_at": "2025-01-20","updated_at": "2025-01-25","';
wwv_flow_imp.g_varchar2_table(1471) := 'customer_id": 8,"concern": {"order_id": 1561,"product_id": 7,"store_id": 8},"comments": [{"comment_i';
wwv_flow_imp.g_varchar2_table(1472) := 'd": 9,"author": "agent","message": "We apologize for the inconvenience, a return label has been sent';
wwv_flow_imp.g_varchar2_table(1473) := '.","created_at": "2025-01-21"},{"comment_id": 10,"author": "Douglas Flores","message": "Thank you, I';
wwv_flow_imp.g_varchar2_table(1474) := ' have shipped it back.","created_at": "2025-01-23"},{"comment_id": 11,"author": "agent","message": "';
wwv_flow_imp.g_varchar2_table(1475) := 'Return received, full refund processed.","created_at": "2025-01-25"}],"resolution": "Full refund iss';
wwv_flow_imp.g_varchar2_table(1476) := 'ued on 2025-01-25."}''));'||wwv_flow.LF||
'        insert into eba_demo_json_support_ticket (data) values (json(''{"tic';
wwv_flow_imp.g_varchar2_table(1477) := 'ket_id": 8,"title": "App crashes when viewing order history","description": "Every time I open my or';
wwv_flow_imp.g_varchar2_table(1478) := 'der history the app freezes and crashes.","status": "Pending","priority": "Medium","created_at": "20';
wwv_flow_imp.g_varchar2_table(1479) := '25-01-28","updated_at": "2025-01-29","customer_id": 9,"concern": {"order_id": 1102,"product_id": nul';
wwv_flow_imp.g_varchar2_table(1480) := 'l,"store_id": null},"comments": [{"comment_id": 12,"author": "agent","message": "Our technical team ';
wwv_flow_imp.g_varchar2_table(1481) := 'is investigating the issue.","created_at": "2025-01-29"}],"resolution": null}''));'||wwv_flow.LF||
'        insert int';
wwv_flow_imp.g_varchar2_table(1482) := 'o eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 9,"title": "Missing items in order';
wwv_flow_imp.g_varchar2_table(1483) := '","description": "My order contained 3 items but only 2 were delivered.","status": "Open","priority"';
wwv_flow_imp.g_varchar2_table(1484) := ': "High","created_at": "2025-02-02","updated_at": "2025-02-03","customer_id": 5,"concern": {"order_i';
wwv_flow_imp.g_varchar2_table(1485) := 'd": 306,"product_id": 28,"store_id": 5},"comments": [{"comment_id": 13,"author": "agent","message": ';
wwv_flow_imp.g_varchar2_table(1486) := '"We are checking with the warehouse team.","created_at": "2025-02-02"},{"comment_id": 14,"author": "';
wwv_flow_imp.g_varchar2_table(1487) := 'Beverly Hughes","message": "Still waiting for an update.","created_at": "2025-02-03"}],"resolution":';
wwv_flow_imp.g_varchar2_table(1488) := ' null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_support_ticket (data) values (json(''{"ticket_id": 10,"t';
wwv_flow_imp.g_varchar2_table(1489) := 'itle": "Delivery address was wrong","description": "My package was delivered to the wrong address.",';
wwv_flow_imp.g_varchar2_table(1490) := '"status": "Resolved","priority": "High","created_at": "2025-02-05","updated_at": "2025-02-08","custo';
wwv_flow_imp.g_varchar2_table(1491) := 'mer_id": 13,"concern": {"order_id": 1052,"product_id": 21,"store_id": 13},"comments": [{"comment_id"';
wwv_flow_imp.g_varchar2_table(1492) := ': 15,"author": "agent_jones","message": "We have contacted the courier to retrieve the package.","cr';
wwv_flow_imp.g_varchar2_table(1493) := 'eated_at": "2025-02-06"},{"comment_id": 16,"author": "agent_jones","message": "Package has been retr';
wwv_flow_imp.g_varchar2_table(1494) := 'ieved and will be redelivered.","created_at": "2025-02-07"},{"comment_id": 17,"author": "Michelle Ra';
wwv_flow_imp.g_varchar2_table(1495) := 'mirez","message": "Package received, thank you!","created_at": "2025-02-08"}],"resolution": "Package';
wwv_flow_imp.g_varchar2_table(1496) := ' successfully redelivered on 2025-02-08."}''));'||wwv_flow.LF||
'        insert into eba_demo_json_support_ticket (dat';
wwv_flow_imp.g_varchar2_table(1497) := 'a) values (json(''{"ticket_id": 11,"title": "Cannot apply discount code","description": "The promo co';
wwv_flow_imp.g_varchar2_table(1498) := 'de SAVE20 is not working at checkout.","status": "Pending","priority": "Low","created_at": "2025-02-';
wwv_flow_imp.g_varchar2_table(1499) := '10","updated_at": "2025-02-10","customer_id": 17,"concern": {"order_id": 92,"product_id": 15,"store_';
wwv_flow_imp.g_varchar2_table(1500) := 'id": 1},"comments": [{"comment_id": 18,"author": "agent","message": "We are verifying the promo code';
null;
end;
/
begin
wwv_flow_imp.g_varchar2_table(1501) := ' validity.","created_at": "2025-02-10"}],"resolution": null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_s';
wwv_flow_imp.g_varchar2_table(1502) := 'upport_ticket (data) values (json(''{"ticket_id": 12,"title": "Item out of stock after purchase","des';
wwv_flow_imp.g_varchar2_table(1503) := 'cription": "I paid for an item that was then cancelled due to being out of stock.","status": "Resolv';
wwv_flow_imp.g_varchar2_table(1504) := 'ed","priority": "Medium","created_at": "2025-02-18","updated_at": "2025-02-20","customer_id": 20,"co';
wwv_flow_imp.g_varchar2_table(1505) := 'ncern": {"order_id": 1776,"product_id": 34,"store_id": 20},"comments": [{"comment_id": 19,"author": ';
wwv_flow_imp.g_varchar2_table(1506) := '"agent","message": "We sincerely apologize, a full refund has been initiated.","created_at": "2025-0';
wwv_flow_imp.g_varchar2_table(1507) := '2-19"},{"comment_id": 20,"author": "Dennis Lopez","message": "Refund received, thank you.","created_';
wwv_flow_imp.g_varchar2_table(1508) := 'at": "2025-02-20"}],"resolution": "Full refund processed on 2025-02-19."}''));'||wwv_flow.LF||
'        insert into eb';
wwv_flow_imp.g_varchar2_table(1509) := 'a_demo_json_support_ticket (data) values (json(''{"ticket_id": 13,"title": "Store staff was rude","de';
wwv_flow_imp.g_varchar2_table(1510) := 'scription": "The staff at Beijing store were very unhelpful and dismissive.","status": "Pending","pr';
wwv_flow_imp.g_varchar2_table(1511) := 'iority": "Low","created_at": "2025-02-22","updated_at": "2025-02-22","customer_id": 13,"concern": {"';
wwv_flow_imp.g_varchar2_table(1512) := 'order_id": null,"product_id": null,"store_id": 21},"comments": [{"comment_id": 21,"author": "agent",';
wwv_flow_imp.g_varchar2_table(1513) := '"message": "We apologize for the experience, this has been escalated to the store manager.","created';
wwv_flow_imp.g_varchar2_table(1514) := '_at": "2025-02-22"}],"resolution": null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_support_ticket (data)';
wwv_flow_imp.g_varchar2_table(1515) := ' values (json(''{"ticket_id": 14,"title": "Warranty claim rejected unfairly","description": "My produ';
wwv_flow_imp.g_varchar2_table(1516) := 'ct broke within the warranty period but the claim was rejected.","status": "Open","priority": "High"';
wwv_flow_imp.g_varchar2_table(1517) := ',"created_at": "2025-03-02","updated_at": "2025-03-03","customer_id": 4,"concern": {"order_id": 920,';
wwv_flow_imp.g_varchar2_table(1518) := '"product_id": 41,"store_id": 4},"comments": [{"comment_id": 22,"author": "agent","message": "We are ';
wwv_flow_imp.g_varchar2_table(1519) := 'reviewing the warranty claim details.","created_at": "2025-03-02"},{"comment_id": 23,"author": "Vict';
wwv_flow_imp.g_varchar2_table(1520) := 'or Morris","message": "I have photos of the defect, where can I send them?","created_at": "2025-03-0';
wwv_flow_imp.g_varchar2_table(1521) := '3"},{"comment_id": 24,"author": "agent","message": "Please send them to support@store.com.","created';
wwv_flow_imp.g_varchar2_table(1522) := '_at": "2025-03-03"}],"resolution": null}''));'||wwv_flow.LF||
'        insert into eba_demo_json_support_ticket (data)';
wwv_flow_imp.g_varchar2_table(1523) := ' values (json(''{"ticket_id": 15,"title": "Subscription not cancelled","description": "I requested ca';
wwv_flow_imp.g_varchar2_table(1524) := 'ncellation of my subscription last month but was still charged.","status": "Open","priority": "High"';
wwv_flow_imp.g_varchar2_table(1525) := ',"created_at": "2025-03-10","updated_at": "2025-03-11","customer_id": 15,"concern": {"order_id": 513';
wwv_flow_imp.g_varchar2_table(1526) := ',"product_id": null,"store_id": 1},"comments": [{"comment_id": 25,"author": "agent","message": "We a';
wwv_flow_imp.g_varchar2_table(1527) := 're checking your cancellation request status.","created_at": "2025-03-10"},{"comment_id": 26,"author';
wwv_flow_imp.g_varchar2_table(1528) := '": "Walter Rogers","message": "I have the cancellation email as proof.","created_at": "2025-03-11"}]';
wwv_flow_imp.g_varchar2_table(1529) := ',"resolution": null}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'    end load_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure load_product_images(p_ap';
wwv_flow_imp.g_varchar2_table(1530) := 'p_id in number, p_file_name in varchar2) is'||wwv_flow.LF||
'        l_zip_file      blob;'||wwv_flow.LF||
'        l_files         ap';
wwv_flow_imp.g_varchar2_table(1531) := 'ex_zip.t_files;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        select file_content'||wwv_flow.LF||
'        into l_zip_file'||wwv_flow.LF||
'        from APEX_APPL';
wwv_flow_imp.g_varchar2_table(1532) := 'ICATION_STATIC_FILES'||wwv_flow.LF||
'        where application_id = p_app_id and file_name = p_file_name;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(1533) := '   l_files := APEX_ZIP.get_files ('||wwv_flow.LF||
'                p_zipped_blob => l_zip_file );'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        for i';
wwv_flow_imp.g_varchar2_table(1534) := ' in 1 .. l_files.count loop'||wwv_flow.LF||
'            update eba_demo_json_products'||wwv_flow.LF||
'            set product_image ';
wwv_flow_imp.g_varchar2_table(1535) := '= APEX_ZIP.get_file_content ('||wwv_flow.LF||
'                p_zipped_blob => l_zip_file,'||wwv_flow.LF||
'                p_file_na';
wwv_flow_imp.g_varchar2_table(1536) := 'me   => l_files(i) )'||wwv_flow.LF||
'            where product_id = substr(l_files(i),0,instr(l_files(i),''.''));'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(1537) := '    end loop;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'    end load_product_images;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure reset_data is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(1538) := '      clear_data;'||wwv_flow.LF||
'        load_data;'||wwv_flow.LF||
'    end reset_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_demo_json_data_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(1539) := 'ba_demo_json_data_pkg.reset_data;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(296292070758789073769)
,p_install_id=>wwv_flow_imp.id(296295828950238257576)
,p_name=>' Load Data'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
