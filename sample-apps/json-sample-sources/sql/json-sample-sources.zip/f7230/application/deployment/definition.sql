prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7230
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7230
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- ==========================================================================='||wwv_flow.LF||
'-- Remove PL/SQL pack';
wwv_flow_imp.g_varchar2_table(2) := 'age'||wwv_flow.LF||
'-- ==========================================================================='||wwv_flow.LF||
'drop package eba_';
wwv_flow_imp.g_varchar2_table(3) := 'demo_json_data_pkg;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- ==========================================================================='||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(4) := '-- Remove tables'||wwv_flow.LF||
'-- ==========================================================================='||wwv_flow.LF||
'drop';
wwv_flow_imp.g_varchar2_table(5) := ' table eba_demo_json_stores          cascade constraints purge;'||wwv_flow.LF||
'drop table eba_demo_json_products   ';
wwv_flow_imp.g_varchar2_table(6) := '     cascade constraints purge;'||wwv_flow.LF||
'drop table eba_demo_json_customers       cascade constraints purge;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := 'drop table eba_demo_json_orders          cascade constraints purge;'||wwv_flow.LF||
'drop table eba_demo_json_order_i';
wwv_flow_imp.g_varchar2_table(8) := 'tems     cascade constraints purge;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Remove json collection'||wwv_flow.LF||
'drop table eba_demo_json_support_tick';
wwv_flow_imp.g_varchar2_table(9) := 'et  cascade constraints purge;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Remove duality views'||wwv_flow.LF||
'drop json relational duality view eba_demo_j';
wwv_flow_imp.g_varchar2_table(10) := 'son_stores_dv;'||wwv_flow.LF||
'drop json relational duality view eba_demo_json_customer_orders_dv;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- ============';
wwv_flow_imp.g_varchar2_table(11) := '==============================================================='||wwv_flow.LF||
'-- Remove sequences'||wwv_flow.LF||
'-- =============';
wwv_flow_imp.g_varchar2_table(12) := '=============================================================='||wwv_flow.LF||
''||wwv_flow.LF||
'drop sequence eba_demo_json_customer';
wwv_flow_imp.g_varchar2_table(13) := 's_seq ;'||wwv_flow.LF||
'drop sequence eba_demo_json_orders_seq ;'||wwv_flow.LF||
'drop sequence eba_demo_json_stores_seq ;'||wwv_flow.LF||
'drop seque';
wwv_flow_imp.g_varchar2_table(14) := 'nce eba_demo_json_products_seq ;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(296295828950238257576)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
);
wwv_flow_imp.component_end;
end;
/
