prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>606665064748577329
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Push Notifications'
,p_alias=>'PUSH-NOTIFICATIONS'
,p_step_title=>'Push Notifications'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'11'
,p_last_updated_by=>'VMORNEAU'
,p_last_upd_yyyymmddhh24miss=>'20230531164941'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(725192921410652977)
,p_plug_name=>'Existing Application'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="col-8">',
'    To enable push notifications in your existing APEX app, turn on',
'    the <strong>Enable Push Notifications</strong> switch in the',
'    Progressive Web App page and configure the required attributes.',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813754483113512242)
,p_plug_name=>'Enable push notifications on an existing APEX app'
,p_parent_plug_id=>wwv_flow_imp.id(725192921410652977)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813754690153512244)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(813754483113512242)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/edit-app-push.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813754585687512243)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(725192921410652977)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>In <strong>App Builder</strong> go to <strong>Shared Components</strong></li>',
'    <li>Go to <strong>Progressive Web App</strong></li>',
'    <li>Turn on <strong>Enable Progressive Web App</strong></li>',
'    <li>Turn on <strong>Enable Push Notifications</strong> </li>',
'    <li>Configure <strong>Credentials</strong>. Choose an existing key pair credential to authenticate against or click <strong>Generate Credentials</strong> to automatically generate a new key pair credentials for your application. This ensures that'
||' users can subscribe to push notifications securely. </li>',
'    <li>Configure <strong>Settings Page</strong>. Create a feature page where users can subscribe to push notifications for your application. This page will allow users to manage their push notification preferences. </li>',
'    <li>Configure <strong>Contact Email: </strong> Enter an email address where the push notification service provider (such as Google, Mozilla, or Apple) can contact the application owner if needed.</li>',
'    <li>Users can proceed with subscribing to push notifications</li>',
'    <li>APEX can proceed to send push notification to subscribers</li>',
'</ol>'))
,p_landmark_label=>'PWA Push Notifications Instructions'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(800887459266807979)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16021161199374556464)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16021046070145556359)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16021223304839556532)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813754212227512239)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16021082788416556399)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_landmark_type=>'navigation'
,p_landmark_label=>'Region Display Selector'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'USER'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813754307400512240)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    APEX push notifications bring real-time communication between APEX applications',
'    and users on all desktop or mobile devices. These notifications enhance your end',
'    user''s experience by providing instant updates and alerts, even when they are not',
'    actively engaged with the application. Notification target links redirect users',
'    back to your APEX application with a tap.',
'',
'</p>',
'',
'<p>',
'',
'    APEX provides hassle-free push notifications setup and offers declarative, no-code',
'    notification sending with a native page process. Developers who want more control',
'    can use the <code>apex_pwa</code> API to seamlessly integrate sending notifications',
'    into their existing workflow. There has never been an easier way to stay connected',
'    with users who''ve opted-in to receive notifications using the built-in settings page.',
'',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1064411986107904231)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(813754307400512240)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>7
,p_plug_grid_column_css_classes=>'flex-center'
,p_region_image=>'#APP_FILES#img/push-received-macos.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1064412094671904232)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(813754307400512240)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>2
,p_plug_grid_column_css_classes=>'flex-center'
,p_region_image=>'#APP_FILES#img/push-received-ios.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1064412263325904233)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(813754307400512240)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>2
,p_plug_grid_column_css_classes=>'flex-center'
,p_region_image=>'#APP_FILES#img/push-received-watch.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813754379285512241)
,p_plug_name=>'New Application'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    The fastest way to get started with APEX push notifications is enabling the push',
'    notification feature checkbox in the Create Application wizard.',
'',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(725192425066652972)
,p_plug_name=>'Enable push notifications for a new APEX application'
,p_parent_plug_id=>wwv_flow_imp.id(813754379285512241)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(725192680132652975)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(725192425066652972)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/create-app-push.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(725192861142652976)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(813754379285512241)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>In <strong>App Builder</strong>, click <strong>Create Application</strong></li>',
'    <li>Select <strong>New Application</strong></li>',
'    <li>Fill the required fields for creating a new application</li>',
'    <li>Under <strong>Features</strong>, select <strong>Push Notifications</strong> checkbox</li>',
'    <li>Click <strong>Create Application</strong></li>',
'    <li>Users can proceed with subscribing to push notifications</li>',
'    <li>APEX can proceed to send push notification to subscribers</li>',
'</ol>'))
,p_landmark_label=>'PWA Push Notifications Instructions'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813755735330512254)
,p_plug_name=>'Receiving Notifications'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Receiving push notifications from an APEX app feels special. Examples below',
'    illustrate how different devices receive notifications. Only devices that',
'    have opted in for push notifications can receive these updates. Those push',
'    notifications function even when the device is idle, or when users are not',
'    actively interacting with the app. This ensures that important information',
'    is delivered promptly, keeping users informed at all times.',
'',
'</p>',
'',
'<p>',
'',
'    When a user taps on a push notification, they can be redirected back into the',
'    APEX app. This simplifies navigation and fosters greater engagement and interaction',
'    with the app, as it helps maintain an ongoing connection with users, encourages user',
'    retention, and ultimately drives the overall success of the app. By default',
'    clicking the notification will redirect you to the home page.',
'',
'</p>'))
,p_landmark_label=>'PWA Receiving Push Notifications'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813755863789512255)
,p_plug_name=>'Receiving an APEX notification on macOS'
,p_parent_plug_id=>wwv_flow_imp.id(813755735330512254)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813755926083512256)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(813755863789512255)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/push-received-macos.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813756145024512258)
,p_plug_name=>'Receiving an APEX notification on iOS'
,p_parent_plug_id=>wwv_flow_imp.id(813755735330512254)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>30
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813756240421512259)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(813756145024512258)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>6
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/push-received-ios.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813756335767512260)
,p_plug_name=>'Receiving an APEX notification on a wearable'
,p_parent_plug_id=>wwv_flow_imp.id(813755735330512254)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813756461689512261)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(813756335767512260)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>6
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/push-received-watch.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813756482874512262)
,p_plug_name=>'Subscribing Devices'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="col-8">',
'',
'    APEX prioritizes security above all else, ensuring that users only receive push',
'    notifications that they have consented to. Web standards require an app to request',
'    permission before sending notifications to prevent unwanted messages.',
'',
'</p>',
'',
'<p class="col-8">',
'',
'    For each APEX application and on each device, end users opt-in to receive push',
'    notifications using the new, user-friendly Settings menu under the username in',
'    the navigation bar. Be sure to consult the compatibility matrix provided above',
'    to confirm that your device can fully utilize this feature.',
'',
'</p>',
'',
''))
,p_landmark_label=>'PWA Push Notifications Examples'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813756679203512264)
,p_plug_name=>'Example of an iOS device subscribing to APEX push notifications'
,p_parent_plug_id=>wwv_flow_imp.id(813756482874512262)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(667702620591275169)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(813756679203512264)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'padding-none'
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/push-subscribe-ios3.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_region_image_alt_text=>'Enable the checkbox'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(667702729394275170)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(813756679203512264)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'padding-none'
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/push-subscribe-ios4.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_region_image_alt_text=>'Authorize notifications for the operating system'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813756582637512263)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(813756679203512264)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'padding-none'
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/push-subscribe-ios2.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_region_image_alt_text=>'Open User Settings Page'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813756975498512267)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(813756679203512264)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>10
,p_plug_grid_column_css_classes=>'padding-none'
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/push-subscribe-ios1.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_region_image_alt_text=>'Locate User Settings Menu'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813756811084512265)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(813756482874512262)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>Run your application</li>',
'    <li>In the top navigation bar, tap your username and select <strong>Settings</strong></li>',
'    <li>A user settings drawer appears</li>',
'    <li>Select <strong>Push Notifications</strong> option from the list of settings</li>',
'    <li>Check the <strong>Enable push notifications on this device</strong> checkbox</li>',
'    <li>Tap <strong>Allow</strong> to authorize this APEX app to send notifications to iOS device</li>',
'    <li>Going back to the user settings list, <strong>Push Notifications</strong> should be set to <strong>On</strong></li>',
'</ol>'))
,p_landmark_label=>'PWA Push Notifications Instructions'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813757432864512271)
,p_plug_name=>'Sending Notifications'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="col-8">',
'',
'    APEX offers two methods for sending push notifications from an app. Each',
'    offers its own benefits and levels of control. Understanding these methods',
'    can help you choose the best approach for your specific needs.',
'',
'</p>'))
,p_landmark_label=>'API'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(725192562021652973)
,p_plug_name=>'Send using API'
,p_parent_plug_id=>wwv_flow_imp.id(813757432864512271)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>60
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'For users seeking more control over the appearance and content of their push notifications, the <code>apex_pwa</code> API offers more flexibility. By using this API, you can manage additional parameters such as the icon and a different destination ap'
||'plication. This approach is useful for looping through multiple users and sending multiple notifications at once.',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1064413199557904243)
,p_plug_name=>'Code'
,p_parent_plug_id=>wwv_flow_imp.id(725192562021652973)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--shadowBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<code>begin',
'    apex_pwa.send_push_notification (',
'        p_application_id => 100,',
'        p_user_name      => ''SMITH'',',
'        p_title          => ''Notification Title'',',
'        p_body           => ''Notification Body'' );',
'end;</code>',
'',
'<br /><br />',
'',
'<code>begin',
'    for l_subscription in ( ',
'        select distinct user_name',
'          from apex_appl_push_subscriptions',
'         where application_id = :APP_ID )',
'    loop',
'        apex_pwa.send_push_notification (',
'            p_application_id => :APP_ID,',
'            p_user_name      => l_subscription.user_name,',
'            p_title          => ''APEX 23.1 is here!'',',
'            p_body           => ''Try out the new features.'' );',
'    end loop;',
'end;</code>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(813757521743512272)
,p_plug_name=>'Send using Page Process'
,p_parent_plug_id=>wwv_flow_imp.id(813757432864512271)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>40
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    The built-in ''Send Push Notification'' page process lets you send a notification',
'    declaratively. This option is ideal for users who prefer a straightforward',
'    process without the need for extensive customization. This process sends a',
'    notification to a single user, although this user might have multiple devices',
'    expecting the same notification. To use this process, simply fill in the required',
'    fields, including the username, title, and description of the push notification.',
'    The process ensures your message is delivered to the intended recipient on any of',
'    their devices on which they''ve opted-in to receive notifications.',
'',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1064413294419904244)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(813757521743512272)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/process-send-push-notification.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(987827910339449444)
,p_plug_name=>'APEX Views'
,p_parent_plug_id=>wwv_flow_imp.id(813757432864512271)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>70
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Regardless of the method you choose to send a push notification, it''s',
'    important (for the APEX engine) to be able to identify the users who',
'    have subscribed to the feature in order to use the page process or the',
'    API meaningfully. APEX offers two views to help analyze this records of',
'    who is subscribed to the push notifications of your application and the',
'    notifications in the queue.',
'',
'</p>'))
,p_landmark_label=>'API'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1064413591954904247)
,p_plug_name=>'apex_appl_push_subscriptions'
,p_parent_plug_id=>wwv_flow_imp.id(987827910339449444)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16021148714879556451)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    The <code>apex_appl_push_subscriptions</code> view lists all users who have',
'    opted in to receive your notifications, making it easy to target your messages',
'    to all your subscribers and Send a notification using the API. You could find',
'    an example in <code>Send using API</code> section above.',
'',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(987828356466449448)
,p_plug_name=>'Code'
,p_parent_plug_id=>wwv_flow_imp.id(1064413591954904247)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--shadowBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<code>select * from apex_appl_push_subscriptions</code>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1064413719485904248)
,p_plug_name=>'apex_push_notifications_queue'
,p_parent_plug_id=>wwv_flow_imp.id(987827910339449444)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16021148714879556451)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<p>The <code>apex_push_notifications_queue</code> view, provides the notification records that are pending or have encountered errors during the sending process. This information useful for troubleshooting issues and ensuring the successful delivery '
||'of your push notifications.</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(987828540743449450)
,p_plug_name=>'Code'
,p_parent_plug_id=>wwv_flow_imp.id(1064413719485904248)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--shadowBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<code>select * from apex_push_notifications_queue</code>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(987828108767449446)
,p_plug_name=>'Push Queue'
,p_parent_plug_id=>wwv_flow_imp.id(813757432864512271)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>80
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    <code>apex_pwa.push_queue</code> is an API designed to trigger sending pending',
'    push notifications in the queue. When sending a push notification, it is in fact',
'    simply added to a queue, with the push queue mechanism responsible for dispatching',
'    these notifications. In case of a failure, the queue entry is updated with an error',
'    message and can be located in the apex_push_notifications_queue view. Upon successful',
'    delivery, the entry is removed from the queue. Although a background job is set to',
'    process the queue every 2 minutes by default, developers can expedite the delivery using',
'    the apex_pwa.push_queue API.',
'',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1064413513439904246)
,p_plug_name=>'Code'
,p_parent_plug_id=>wwv_flow_imp.id(987828108767449446)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--shadowBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<code>begin',
'    apex_pwa.push_queue;',
'end;</code>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(987828735088449452)
,p_plug_name=>'Common Issues'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(780683591650649464)
,p_plug_name=>'ORA-29106: Cannot import PKCS #12 wallet'
,p_parent_plug_id=>wwv_flow_imp.id(987828735088449452)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16021101672194556415)
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'   Some APEX community user who have used the <a target="_blank" href="https://github.com/Dani3lSun/oracle-ca-wallet-creator">open',
'   source certificate authority wallet generator script</a> from the machine where',
'   their Oracle Database is installed have encountered this error when trying to',
'   use the wallet that it creates using the <tt>orapki</tt> utility. The solution they''ve',
'   found was to remove <tt>$ORACLE_HOME/bin</tt> from the system path in the',
'   shell window where they run the script. Doing this causes the script to use',
'   <tt>openssl</tt> to generate the certificate authority wallet instead and the wallet',
'   produced using this alternative worked correctly. The issue does not reproduce on all',
'   versions of the Oracle Database <tt>orapki</tt>, and is not an issue with the script',
'   itself. ',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>606665064748577329
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1064414389296904255)
,p_plug_name=>'ORA-24247: network access denied by access control list (ACL)'
,p_parent_plug_id=>wwv_flow_imp.id(987828735088449452)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16021101672194556415)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    This error should not occur when using APEX Service or APEX on Autonomous Database. However, in other environments where',
'    you need to manually configure whih outbound network requests are allowed, you can run the following script',
'    as <tt>SYS</tt> or another user with DBA privileges to grant the appropriate privileges for the APEX engine to',
'    use the REST APIs involved in securely delivering notifications to subscribed users.',
'</p>',
'',
'<pre><code>',
'-- Run as SYS or DBA user',
'declare',
'    l_principal varchar2(20) := apex_application.g_flow_schema_owner;',
'    l_proxy varchar2(100)    := null; -- e.g. ''proxy.example.org''',
'    l_proxy_port number      := 80;',
'    l_hosts apex_t_varchar2  := apex_t_varchar2(',
'                                ''*.push.apple.com'',',
'                                ''*.notify.windows.com'',',
'                                ''updates.push.services.mozilla.com'',',
'                                ''android.googleapis.com'',',
'                                ''fcm.googleapis.com'');',
'    procedure add_priv(p_priv varchar2, p_host varchar2, p_port number) is',
'    begin',
'        dbms_network_acl_admin.append_host_ace (',
'            host       => p_host, ',
'            lower_port => p_port,',
'            upper_port => p_port,',
'            ace        => ',
'                xs$ace_type(privilege_list => xs$name_list(p_priv),',
'                            principal_name => l_principal,',
'                            principal_type => xs_acl.ptype_db));',
'    end;',
'begin',
'    if l_proxy is not null then',
'        add_priv(''connect'',l_proxy,l_proxy_port);',
'    end if;',
'    for j in (select column_value as hostname from table(l_hosts)) loop',
'        add_priv(''connect'',j.hostname,443);',
'    end loop;',
'    commit;',
'end;',
'</code></pre>',
'',
'<p>',
'    For more information, read this <a href="https://docs.oracle.com/en/database/oracle/apex/22.1/htmig/enabling-network-services-in-Oracle-db11g-or-later.html">documentation chapter.</a>',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1064414673289904258)
,p_plug_name=>'Changing the application alias blocks future delivery of push notifications'
,p_parent_plug_id=>wwv_flow_imp.id(987828735088449452)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16021101672194556415)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    Updating an application alias changes the structure of the URL and causes the service worker to invalidate.',
'</p>',
'<p>',
'    We recommend not updating an application alias for production systems, or users will have to subscribe to push notifications again.',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1064414795041904259)
,p_plug_name=>'ORA-29260: network error: TNS:operation timed out'
,p_parent_plug_id=>wwv_flow_imp.id(987828735088449452)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16021101672194556415)
,p_plug_display_sequence=>80
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    Your environment requires that you specify a proxy server for the notifications to be delivered successfully. ',
'</p>',
'<p>',
'    For example if you use a firewall and the target of the push notification endpoint is outside the firewall relative to APEX, you may need to specify a proxy server.',
'</p>',
'<p>',
'    The proxy can be set at the instance level if you are an administrator, or at the application level under Shared Components, Application Definition, Proxy Server.',
'</p>',
'<p>',
'    Here is an example of a proxy server value: www-proxy.company.com',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1064415141386904262)
,p_plug_name=>'ORA-29024: Certificate validation failure'
,p_parent_plug_id=>wwv_flow_imp.id(987828735088449452)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16021101672194556415)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'   APEX delivers push notifications using the secure HTTPS protocol that ',
'   requires your APEX instance to trust the certificate of the ',
'   Apple, Microsoft, Mozilla, and Google sites hostings their respective',
'   push notification delivery REST APIs. If you don''t currently have',
'   a wallet configured, many APEX community user''s have reported a successful',
'   experience using this <a target="_blank" href="https://github.com/Dani3lSun/oracle-ca-wallet-creator">open',
'   source certificate authority wallet generator script</a>,',
'   whose README file explains how to use it and update APEX to ',
'   point to the newly generated wallet. ',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1074147937091969633)
,p_plug_name=>'This device failed to enable push notifications'
,p_parent_plug_id=>wwv_flow_imp.id(987828735088449452)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16021101672194556415)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    To ensure that your Progressive Web App is properly configured for push',
'    notifications, start by checking your credentials in the settings of your',
'    Progressive Web App.',
'',
'</p>',
'',
'<p>',
'',
'    After installing or importing an Application into your workspace, you will',
'    need to generate the credentials for your application. If you failed to',
'    perform this step, click (Regenerate Credentials) button in the Push Notifications',
'    tab. However, be aware that regenerating already-valid credentials invalidates',
'    all existing subscriptions that used the previous key pair credentials that',
'    were in effect.',
'',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1438297351815218043)
,p_plug_name=>'On iOS, the user settings page shows "Not Supported"'
,p_parent_plug_id=>wwv_flow_imp.id(987828735088449452)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16021101672194556415)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    First, check to make sure that your device is running iOS 16.4 or later.',
'    If not, you''ll need to update your phone''s operating system by going to',
'    your phone settings and selecting "Software Update.".',
'</p>',
'',
'<p>',
'    If your device is running iOS 16.4 or later, note that push notifications',
'    are only available on Safari browsers for installed PWAs only. Try installing',
'    the PWA and then check back on the user settings page.',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1438297820027218047)
,p_plug_name=>'Notifications are not being delivered to my device'
,p_parent_plug_id=>wwv_flow_imp.id(987828735088449452)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(16021101672194556415)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    Ensure that the username has been correctly entered in the native page process',
'    or in the APEX_PWA API. The username is case sensitive.',
'</p>',
'',
'<p>',
'    First, check to see if notifications are enabled in your browser settings.',
'    You can usually access these settings by clicking on the three-dot menu in',
'    the top-right corner of your browser window and selecting "Settings" or',
'    "Preferences." From there, look for a section called "Notifications" or',
'    "Site Settings" and make sure that notifications are turned on for the',
'    relevant website.',
'</p>',
'',
'<p>',
'    If notifications are enabled but you''re still not receiving them, try',
'    clearing your browser''s cache and cookies.',
'</p>',
'',
'<p>',
'    Verify if your browser engine, the browser through which the PWA is installed',
'    allows sending notifications in your operating system settings.',
'</p>',
'',
'<p>',
'    Finally, make sure that you''re connected to the internet and that your',
'    device is not in "Do Not Disturb" mode. These settings can sometimes',
'    prevent notifications from coming through.',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1064415011200904261)
,p_plug_name=>'Deploying Application'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    For security purposes, APEX applications using push notifications require a key-pair credentials. ',
'    Since credentials are not exported with an application during deployment, ',
'    it''s necessary to regenerate the key-pair credentials on the destination environment for push notifications to work. ',
'',
'</p>',
'',
'<p>',
'',
'    It''s only necessary to regenerate the credentials the first time your application is being deployed. ',
'    Any subsequent deployments don''t need to regenerate their key-pair credentials.',
'',
'</p>',
'',
'<p>',
'',
'    To regenerate the credentials for an application push notifications, you can either:',
'',
'    <ol>',
'        <li>Go to Shared Components > Progressive Web App > Push Notifications > Regenerate Credentials</li>',
'        <li>Use the API to regenerate push credentials for the newly deployed application:</li>',
'    </ol>',
'',
'    <pre><code>',
'    begin',
'        apex_pwa.generate_push_credentials (',
'            p_application_id => :APP_ID );',
'    end;',
'    </code></pre>',
'',
'</p>',
'',
''))
,p_landmark_label=>'PWA Receiving Push Notifications'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16361618945751594665)
,p_plug_name=>'Compatibility'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    This table shows the supported combinations of operating',
'    systems and browsers for the push notification feature.',
'</p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc dm-Report--grid">',
'    <thead>',
'        <tr>',
'            <td class="display-hidden"></td>',
'            <th class="u-tL">Chrome</th>',
'            <th class="u-tL">Edge</th>',
'            <th class="u-tL">Firefox</th>',
'            <th class="u-tL">Safari</th>',
'        </tr>',
'    </thead>',
'    <tbody>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Android</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>iOS</span></th>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'            <td class="display-visible">Yes*</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>macOS</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Windows</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'    </tbody>',
'</table>',
'',
'<br />',
'<p>* iOS 16.4 and later only on installed PWAs.</p>',
'',
'<p class="margin-top-md"><em>Last updated: April 2023</em></p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
