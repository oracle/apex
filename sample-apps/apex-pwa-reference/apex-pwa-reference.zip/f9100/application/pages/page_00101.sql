prompt --application/pages/page_00101
begin
--   Manifest
--     PAGE: 00101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>1580934860364765
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>101
,p_name=>'Roadmap'
,p_alias=>'ROADMAP'
,p_step_title=>'Roadmap'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3399916521725184)
,p_name=>'APEX 23.2'
,p_template=>2322115667525957943
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG'
,p_component_template_options=>'#DEFAULT#:t-MediaList--stack:t-Report--hideNoPagination'
,p_grid_column_span=>8
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  11 id,',
'  ''QR Code Generator'' list_title,',
'  ''Let users easily share data using a QR code based on an APEX page URL or content'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-qrcode'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  13 id,',
'  ''Image Upload'' list_title,',
'  ''Modern image upload experience so users can edit images before saving'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-image'' icon_class',
'from sys.dual',
'',
'order by id'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2093604263195414824
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3400007032725185)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3400109513725186)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'List Title'
,p_use_as_row_header=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3400172190725187)
,p_query_column_id=>3
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'List Text'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3400321238725188)
,p_query_column_id=>4
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'List Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3400337804725189)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3400515958725190)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>60
,p_column_heading=>'Link Attr'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3400536178725191)
,p_query_column_id=>7
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>70
,p_column_heading=>'Icon Color Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3400650939725192)
,p_query_column_id=>8
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>80
,p_column_heading=>'Icon Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(815334210035876995)
,p_name=>'APEX 23.1'
,p_template=>2322115667525957943
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG'
,p_component_template_options=>'#DEFAULT#:t-MediaList--stack:t-Report--hideNoPagination'
,p_grid_column_span=>8
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  1 id,',
'  ''Push Notifications'' list_title,',
'  ''Deliver push notifications to users from an APEX application'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-bell-o'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  8 id,',
'  ''Improve application icon fidelity'' list_title,',
'  ''Generate great looking icons for all operating systems out of the box'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-design'' icon_class',
'from sys.dual',
'',
'order by id'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2093604263195414824
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(815334353415876996)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(815334431674876997)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'List Title'
,p_use_as_row_header=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(815334500336876998)
,p_query_column_id=>3
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'List Text'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(815334624623876999)
,p_query_column_id=>4
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'List Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(815334786033877000)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(815334829791877001)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>60
,p_column_heading=>'Link Attr'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(815334903191877002)
,p_query_column_id=>7
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>70
,p_column_heading=>'Icon Color Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(815335029306877003)
,p_query_column_id=>8
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>80
,p_column_heading=>'Icon Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1363441291859830523)
,p_name=>'APEX 21.2'
,p_template=>2322115667525957943
,p_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG'
,p_component_template_options=>'#DEFAULT#:t-MediaList--stack:t-Report--hideNoPagination'
,p_grid_column_span=>8
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  1 id,',
'  ''Declarative PWA'' list_title,',
'  ''Create an installable PWA in a single click'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-mobile'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  2 id,',
'  ''Improved App Performance'' list_title,',
'  ''Cache resources automatically for snappier page loading in installed apps'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-mobile'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  3 id,',
'  ''Make your APEX application installable'' list_title,',
'  ''Let users install your APEX app on their device''''s home screen and launch it like a native app'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-download'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  4 id,',
'  ''Custom Offline Page'' list_title,',
'  ''Customize the page your users see when their installed app has no internet connection'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-file-x'' icon_class',
'from sys.dual',
'',
'order by id'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2093604263195414824
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363441696110830527)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363441735875830528)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'List Title'
,p_use_as_row_header=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363441879890830529)
,p_query_column_id=>3
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'List Text'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363441962019830530)
,p_query_column_id=>4
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'List Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363442098987830531)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363442102068830532)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>60
,p_column_heading=>'Link Attr'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363442294248830533)
,p_query_column_id=>7
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>70
,p_column_heading=>'Icon Color Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363442386113830534)
,p_query_column_id=>8
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>80
,p_column_heading=>'Icon Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1363441568577830526)
,p_name=>'Roadmap'
,p_template=>2322115667525957943
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG'
,p_component_template_options=>'#DEFAULT#:t-MediaList--stack:t-Report--hideNoPagination'
,p_grid_column_span=>8
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  4 id,',
'  ''Declarative Badging'' list_title,',
'  ''Control badges for installed PWAs to notify users that there is new activity that require their attention'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-badge'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  4 id,',
'  ''Multi apps PWA'' list_title,',
'  ''Build a PWA that includes pages from multiple APEX applications'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-shapes'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  5 id,',
'  ''PWA-enable APEX App Builder'' list_title,',
'  ''Deliver your APEX applications with a builder launched like a native app'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-apex'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  6 id,',
'  ''Deploy APEX apps to app stores'' list_title,',
'  ''Automate deploying APEX apps to popular application stores from APEX Builder'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-object-group'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  9 id,',
'  ''PWA-only APEX applications'' list_title,',
'  ''Optionally compel end users to install your application as a PWA when that delivers the best user experience'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-mobile'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  10 id,',
'  ''Basic offline capabilities'' list_title,',
'  ''Offer initial declarative support for targeted offline use cases'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-signal'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  13 id,',
'  ''PWA Analytics'' list_title,',
'  ''Useful analytics on the installation, push notifications and general usage of your APEX PWA'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-analytics'' icon_class',
'from sys.dual',
'',
'order by id'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2093604263195414824
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370896482271870803)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370896534645870804)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'List Title'
,p_use_as_row_header=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370896604118870805)
,p_query_column_id=>3
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'List Text'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370896749913870806)
,p_query_column_id=>4
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'List Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370896856188870807)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370896913331870808)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>60
,p_column_heading=>'Link Attr'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370897015804870809)
,p_query_column_id=>7
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>70
,p_column_heading=>'Icon Color Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370897138240870810)
,p_query_column_id=>8
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>80
,p_column_heading=>'Icon Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1363442486423830535)
,p_name=>'APEX 22.1'
,p_template=>2322115667525957943
,p_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG'
,p_component_template_options=>'#DEFAULT#:t-MediaList--stack:t-Report--hideNoPagination'
,p_grid_column_span=>8
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  1 id,',
'  ''Application Icon'' list_title,',
'  ''Brand your app with a custom icon that automatically appears everywhere its needed'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-apex'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  2 id,',
'  ''Persistent Authentication'' list_title,',
'  ''Improve usability of your app by letting users stay logged in to focus immediately on getting their job done'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-lock'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  3 id,',
'  ''PWA in Shared Components'' list_title,',
'  ''Configure all PWA attributes in a dedicated Shared Components page'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-list-alt'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  4 id,',
'  ''Pick a Service Worker Strategy'' list_title,',
'  ''Extend the default APEX service worker to implement push notifications, web app payments, push app updates in the background and more'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-puzzle-piece'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  5 id,',
'  ''Share Your Custom Service Worker'' list_title,',
'  ''Reuse your service worker code easily across multiple applications'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-share-alt'' icon_class',
'from sys.dual',
'',
'order by id'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2093604263195414824
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363442556295830536)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363442672222830537)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'List Title'
,p_use_as_row_header=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363442774974830538)
,p_query_column_id=>3
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'List Text'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363442892799830539)
,p_query_column_id=>4
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'List Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363442919846830540)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363443011472830541)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>60
,p_column_heading=>'Link Attr'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363443173609830542)
,p_query_column_id=>7
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>70
,p_column_heading=>'Icon Color Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1363443227729830543)
,p_query_column_id=>8
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>80
,p_column_heading=>'Icon Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1363443345088830544)
,p_name=>'APEX 22.2'
,p_template=>2322115667525957943
,p_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG'
,p_component_template_options=>'#DEFAULT#:t-MediaList--stack:t-Report--hideNoPagination'
,p_grid_column_span=>8
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  1 id,',
'  ''Feature Detection'' list_title,',
'  ''Show Install App button only when current combination of device and browser supports it'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-lightbulb-o'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  2 id,',
'  ''App Screenshots'' list_title,',
'  ''Provide users a visual preview of your app at installation time'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-image'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  3 id,',
'  ''App Shortcuts'' list_title,',
'  ''Provide frequently-used actions as quick picks for users to access from your installed app icon'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-box-arrow-out-ne'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  4 id,',
'  ''Device Geolocation'' list_title,',
'  ''Retrieve the device''''s current location, speed, and altitude using a dynamic action'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-location-arrow-o'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  5 id,',
'  ''Web Share'' list_title,',
'  ''Share data declaratively with other apps on the user''''s device using the native share sheet'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-share'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  6 id,',
'  ''Declarative Meta Tags'' list_title,',
'  ''Improve how shared public app pages render on social media and appear in search engine results'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-tags'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  7 id,',
'  ''Improved PWA Install Dialog'' list_title,',
'  ''Incentivize users to install your app by fully leveraging the redesigned install experience'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-download'' icon_class',
'from sys.dual',
'',
'order by id'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2093604263195414824
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370895691291870795)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370895730157870796)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'List Title'
,p_use_as_row_header=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370895879189870797)
,p_query_column_id=>3
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'List Text'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370895979385870798)
,p_query_column_id=>4
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'List Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370896034656870799)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370896171149870800)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>60
,p_column_heading=>'Link Attr'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370896242532870801)
,p_query_column_id=>7
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>70
,p_column_heading=>'Icon Color Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1370896324746870802)
,p_query_column_id=>8
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>80
,p_column_heading=>'Icon Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1370690175731234913)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16022627005005921124)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1370897324083870812)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_landmark_type=>'navigation'
,p_landmark_label=>'Region Display Selector'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp.component_end;
end;
/
