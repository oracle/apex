prompt --application/pages/page_00101
begin
--   Manifest
--     PAGE: 00101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>606665064748577329
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>101
,p_name=>'Roadmap'
,p_alias=>'ROADMAP'
,p_step_title=>'Roadmap'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'03'
,p_last_updated_by=>'VMORNEAU'
,p_last_upd_yyyymmddhh24miss=>'20231101181337'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(220667361653624530)
,p_name=>'APEX 23.1'
,p_template=>wwv_flow_imp.id(16021111158546556422)
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG'
,p_component_template_options=>'#DEFAULT#:t-MediaList--stack:t-Report--hideNoPagination'
,p_grid_column_span=>8
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  1 id,',
'  ''Push Notifications'' list_title,',
'  ''Deliver push notifications to users from an APEX application'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-bell-o'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  8 id,',
'  ''Improve application icon fidelity'' list_title,',
'  ''Generate great looking icons for all operating systems out of the box'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-design'' icon_class',
'from sys.dual',
'',
'order by id'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(16021183464521556487)
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(220667432544624531)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(220667560524624532)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'List Title'
,p_use_as_row_header=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(220667665336624533)
,p_query_column_id=>3
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'List Text'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(220667793650624534)
,p_query_column_id=>4
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'List Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(220667838855624535)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(220667923891624536)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>60
,p_column_heading=>'Link Attr'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(220668060421624537)
,p_query_column_id=>7
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>70
,p_column_heading=>'Icon Color Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(220668114824624538)
,p_query_column_id=>8
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>80
,p_column_heading=>'Icon Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(813753275175512230)
,p_name=>'APEX 23.2'
,p_template=>wwv_flow_imp.id(16021111158546556422)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG'
,p_component_template_options=>'#DEFAULT#:t-MediaList--stack:t-Report--hideNoPagination'
,p_grid_column_span=>8
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  11 id,',
'  ''QR Code Generator'' list_title,',
'  ''Let users easily share data using a QR code based on an APEX page URL or content'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-qrcode'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  13 id,',
'  ''Image Upload'' list_title,',
'  ''Modern image upload experience so users can edit images before saving'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-image'' icon_class',
'from sys.dual',
'',
'order by id'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(16021183464521556487)
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(813753418555512231)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(813753496814512232)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'List Title'
,p_use_as_row_header=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(813753565476512233)
,p_query_column_id=>3
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'List Text'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(813753689763512234)
,p_query_column_id=>4
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'List Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(813753851173512235)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(813753894931512236)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>60
,p_column_heading=>'Link Attr'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(813753968331512237)
,p_query_column_id=>7
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>70
,p_column_heading=>'Icon Color Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(813754094446512238)
,p_query_column_id=>8
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>80
,p_column_heading=>'Icon Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1361860356999465758)
,p_name=>'APEX 21.2'
,p_template=>wwv_flow_imp.id(16021111158546556422)
,p_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG'
,p_component_template_options=>'#DEFAULT#:t-MediaList--stack:t-Report--hideNoPagination'
,p_grid_column_span=>8
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  1 id,',
'  ''Declarative PWA'' list_title,',
'  ''Create an installable PWA in a single click'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-mobile'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  2 id,',
'  ''Improved App Performance'' list_title,',
'  ''Cache resources automatically for snappier page loading in installed apps'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-mobile'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  3 id,',
'  ''Make your APEX application installable'' list_title,',
'  ''Let users install your APEX app on their device''''s home screen and launch it like a native app'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-download'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  4 id,',
'  ''Custom Offline Page'' list_title,',
'  ''Customize the page your users see when their installed app has no internet connection'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-file-x'' icon_class',
'from sys.dual',
'',
'order by id'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(16021183464521556487)
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361860761250465762)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361860801015465763)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'List Title'
,p_use_as_row_header=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361860945030465764)
,p_query_column_id=>3
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'List Text'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361861027159465765)
,p_query_column_id=>4
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'List Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361861164127465766)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361861167208465767)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>60
,p_column_heading=>'Link Attr'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361861359388465768)
,p_query_column_id=>7
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>70
,p_column_heading=>'Icon Color Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361861451253465769)
,p_query_column_id=>8
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>80
,p_column_heading=>'Icon Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1361860633717465761)
,p_name=>'Roadmap'
,p_template=>wwv_flow_imp.id(16021111158546556422)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG'
,p_component_template_options=>'#DEFAULT#:t-MediaList--stack:t-Report--hideNoPagination'
,p_grid_column_span=>8
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  4 id,',
'  ''Declarative Badging'' list_title,',
'  ''Control badges for installed PWAs to notify users that there is new activity that require their attention'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-badge'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  4 id,',
'  ''Multi apps PWA'' list_title,',
'  ''Build a PWA that includes pages from multiple APEX applications'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-shapes'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  5 id,',
'  ''PWA-enable APEX App Builder'' list_title,',
'  ''Deliver your APEX applications with a builder launched like a native app'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-apex'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  6 id,',
'  ''Deploy APEX apps to app stores'' list_title,',
'  ''Automate deploying APEX apps to popular application stores from APEX Builder'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-object-group'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  9 id,',
'  ''PWA-only APEX applications'' list_title,',
'  ''Optionally compel end users to install your application as a PWA when that delivers the best user experience'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-mobile'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  10 id,',
'  ''Basic offline capabilities'' list_title,',
'  ''Offer initial declarative support for targeted offline use cases'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-signal'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  13 id,',
'  ''PWA Analytics'' list_title,',
'  ''Useful analytics on the installation, push notifications and general usage of your APEX PWA'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-analytics'' icon_class',
'from sys.dual',
'',
'order by id'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(16021183464521556487)
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369315547411506038)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369315599785506039)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'List Title'
,p_use_as_row_header=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369315669258506040)
,p_query_column_id=>3
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'List Text'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369315815053506041)
,p_query_column_id=>4
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'List Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369315921328506042)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369315978471506043)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>60
,p_column_heading=>'Link Attr'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369316080944506044)
,p_query_column_id=>7
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>70
,p_column_heading=>'Icon Color Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369316203380506045)
,p_query_column_id=>8
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>80
,p_column_heading=>'Icon Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1361861551563465770)
,p_name=>'APEX 22.1'
,p_template=>wwv_flow_imp.id(16021111158546556422)
,p_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG'
,p_component_template_options=>'#DEFAULT#:t-MediaList--stack:t-Report--hideNoPagination'
,p_grid_column_span=>8
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  1 id,',
'  ''Application Icon'' list_title,',
'  ''Brand your app with a custom icon that automatically appears everywhere its needed'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-apex'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  2 id,',
'  ''Persistent Authentication'' list_title,',
'  ''Improve usability of your app by letting users stay logged in to focus immediately on getting their job done'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-lock'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  3 id,',
'  ''PWA in Shared Components'' list_title,',
'  ''Configure all PWA attributes in a dedicated Shared Components page'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-list-alt'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  4 id,',
'  ''Pick a Service Worker Strategy'' list_title,',
'  ''Extend the default APEX service worker to implement push notifications, web app payments, push app updates in the background and more'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-puzzle-piece'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  5 id,',
'  ''Share Your Custom Service Worker'' list_title,',
'  ''Reuse your service worker code easily across multiple applications'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-share-alt'' icon_class',
'from sys.dual',
'',
'order by id'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(16021183464521556487)
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361861621435465771)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361861737362465772)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'List Title'
,p_use_as_row_header=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361861840114465773)
,p_query_column_id=>3
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'List Text'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361861957939465774)
,p_query_column_id=>4
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'List Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361861984986465775)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361862076612465776)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>60
,p_column_heading=>'Link Attr'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361862238749465777)
,p_query_column_id=>7
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>70
,p_column_heading=>'Icon Color Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1361862292869465778)
,p_query_column_id=>8
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>80
,p_column_heading=>'Icon Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1361862410228465779)
,p_name=>'APEX 22.2'
,p_template=>wwv_flow_imp.id(16021111158546556422)
,p_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG'
,p_component_template_options=>'#DEFAULT#:t-MediaList--stack:t-Report--hideNoPagination'
,p_grid_column_span=>8
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  1 id,',
'  ''Feature Detection'' list_title,',
'  ''Show Install App button only when current combination of device and browser supports it'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-lightbulb-o'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  2 id,',
'  ''App Screenshots'' list_title,',
'  ''Provide users a visual preview of your app at installation time'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-image'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  3 id,',
'  ''App Shortcuts'' list_title,',
'  ''Provide frequently-used actions as quick picks for users to access from your installed app icon'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-box-arrow-out-ne'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  4 id,',
'  ''Device Geolocation'' list_title,',
'  ''Retrieve the device''''s current location, speed, and altitude using a dynamic action'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-location-arrow-o'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  5 id,',
'  ''Web Share'' list_title,',
'  ''Share data declaratively with other apps on the user''''s device using the native share sheet'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-share'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  6 id,',
'  ''Declarative Meta Tags'' list_title,',
'  ''Improve how shared public app pages render on social media and appear in search engine results'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-tags'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  7 id,',
'  ''Improved PWA Install Dialog'' list_title,',
'  ''Incentivize users to install your app by fully leveraging the redesigned install experience'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-download'' icon_class',
'from sys.dual',
'',
'order by id'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(16021183464521556487)
,p_query_num_rows=>9999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369314756431506030)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369314795297506031)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'List Title'
,p_use_as_row_header=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369314944329506032)
,p_query_column_id=>3
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'List Text'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369315044525506033)
,p_query_column_id=>4
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'List Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369315099796506034)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369315236289506035)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>60
,p_column_heading=>'Link Attr'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369315307672506036)
,p_query_column_id=>7
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>70
,p_column_heading=>'Icon Color Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1369315389886506037)
,p_query_column_id=>8
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>80
,p_column_heading=>'Icon Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1369109240870870148)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16021161199374556464)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16021046070145556359)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16021223304839556532)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1369316389223506047)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16021082788416556399)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_landmark_type=>'navigation'
,p_landmark_label=>'Region Display Selector'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'NO'
,p_attribute_04=>'N'
);
wwv_flow_imp.component_end;
end;
/
