prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>606665064748577329
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'Web Share'
,p_alias=>'WEB-SHARE'
,p_step_title=>'Web Share - &APP_NAME.'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Comments-instructions {',
'    margin: 24px 0px 0px 0px;',
'    text-align: center;',
'    font-weight: bold;',
'}',
'',
'.image-wrap {',
'    display: flex;',
'    flex-flow: column;',
'}',
'',
'.img-installer {',
'    width: 100%;',
'    border-radius: 5px;',
'}',
'',
'.img-installer-mobile {',
'    width: 100%;',
'    border-radius: 5px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'11'
,p_last_updated_by=>'VMORNEAU'
,p_last_upd_yyyymmddhh24miss=>'20230503171411'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568565626515562292)
,p_plug_name=>'Demo'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16037485109673581660)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16021082788416556399)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_landmark_type=>'navigation'
,p_landmark_label=>'Region Display Selector'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'NO'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16037485687834581666)
,p_plug_name=>'Meta tags'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p class="col-8">Meta tags are pieces of information about a web page that allows other systems to read a summary of the page content. Sharing APEX pages is more convenient when the content of that page can be previewed on other social media platform'
||'s. APEX allows to define meta tags for public-facing APEX pages directly from Page Designer.</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568564463339562281)
,p_plug_name=>'Edit Meta Tag'
,p_parent_plug_id=>wwv_flow_imp.id(16037485687834581666)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>8
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568564674858562283)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(15568564463339562281)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_region_image=>'#APP_FILES#img/edit-meta-tag.jpeg'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568564595415562282)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(16037485687834581666)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>In <strong>Page Designer</strong> check that your page is public (no authentication)</li>',
'    <li>In the page attributes, under <strong>Advanced</strong> turn on <strong>Enable Meta Tags</strong></li>',
'    <li>A new section will appear in the <strong>Page Designer Rendering Tree</strong></li>',
'    <li>Add your <strong>Meta Tag</strong> name and value pairs</li>',
'</ol>'))
,p_landmark_label=>'Instructions Meta tags'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16065234723690443983)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16021161199374556464)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16021046070145556359)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16021223304839556532)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16740022094229593948)
,p_plug_name=>'Sharing APEX Content'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="col-8">',
'    The <strong>Share</strong> dynamic action lets you easily share data from',
'    your APEX app to other apps on the current device. When a user triggers',
'    the Share action, their device''s native share sheet appears to let them',
'    pick contacts or other apps as the share destination.',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568564238933562278)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(16740022094229593948)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>In <strong>Page Designer</strong> create a new button</li>',
'    <li>Create a new <strong>Dynamic Action</strong> on the button''s click event</li>',
'    <li>Change the <strong>Action</strong> to <strong>Share</strong></li>',
'    <li>Use the property editor to configure whether to share the current page, URL or File(s)</li>',
'</ol>',
'<ul>',
'    <li style="list-style-type: none;">The shared content can be static or reside in session state items</li>',
'</ul>'))
,p_landmark_label=>'Instructions Sharing APEX Content'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568564260626562279)
,p_plug_name=>'Edit Dynamic Action'
,p_parent_plug_id=>wwv_flow_imp.id(16740022094229593948)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568564134934562277)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(15568564260626562279)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_region_image=>'#APP_FILES#img/da-share.jpeg'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568565003498562286)
,p_plug_name=>'Compatibility'
,p_parent_plug_id=>wwv_flow_imp.id(16740022094229593948)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>1
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This table shows the supported combinations of operating systems and browsers for the Web Share feature.</p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc dm-Report--grid">',
'    <thead>',
'        <tr>',
'            <td class="display-hidden"></td>',
'            <th class="u-tL">Chrome</th>',
'            <th class="u-tL">Edge</th>',
'            <th class="u-tL">Firefox</th>',
'            <th class="u-tL">Safari</th>',
'        </tr>',
'    </thead>',
'    <tbody>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Android</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>iOS</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>macOS</span></th>',
'            <td class="display-not">No</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-visible">Yes</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Windows</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'    </tbody>',
'</table>',
'',
'<p class="margin-top-md"><em>Last updated: April 2023</em></p>',
'',
'<p>Note: Using the Web Share dynamic action on a browser that does not support Web Share API will result in the associated button being hidden on the page. APEX does this to avoid having a button that can''t be actioned.</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16740023200047596508)
,p_plug_name=>'Examples'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_landmark_label=>'Meta tags Examples'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1358877931632862338)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(16740023200047596508)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>Run application and tap on the <strong>button</strong> or the <strong>element</strong> that triggers the dynamic action</li>',
'    <li>A share sheet should appear</li>',
'    <li>Click on the application or contact you want to share the content with</li>',
'</ol>'))
,p_landmark_label=>'Instructions Sharing APEX Content'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1358878039273862339)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(16740023200047596508)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>On iOS, tap on the <strong>button</strong> or the <strong>element</strong> that triggers the dynamic action</li>',
'    <li>An iOS share sheet should appear</li>',
'    <li>Tap on the application or contact you want to share the content with</li>',
'</ol>'))
,p_landmark_label=>'Instructions Sharing APEX Content'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568565732389562293)
,p_plug_name=>'Sharing an APEX page on Safari Desktop'
,p_parent_plug_id=>wwv_flow_imp.id(16740023200047596508)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568565366087562290)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(15568565732389562293)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/da-share-macos.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568565822274562294)
,p_plug_name=>'Sharing an APEX page on iOS'
,p_parent_plug_id=>wwv_flow_imp.id(16740023200047596508)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>40
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568565486440562291)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(15568565822274562294)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/da-share-ios.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16085439628482178778)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(15568565626515562292)
,p_button_name=>'SHARE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(16021221684256556531)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Share'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16037487313459581683)
,p_name=>'onClick SHARE'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(16085439628482178778)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16037487463883581684)
,p_event_id=>wwv_flow_imp.id(16037487313459581683)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHARE'
,p_attribute_01=>'Sharing a page title'
,p_attribute_02=>'Sharing an APEX page to the world!'
,p_attribute_03=>'current_page'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15568565093106562287)
,p_name=>'onPageLoad'
,p_event_sequence=>20
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'!navigator.canShare'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15568565233144562288)
,p_event_id=>wwv_flow_imp.id(15568565093106562287)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Hide Region Demo'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(15568565626515562292)
);
wwv_flow_imp_page.create_page_meta_tag(
 p_id=>wwv_flow_imp.id(15568562568281562262)
,p_meta_tag_name=>'og:image'
,p_meta_tag_value=>'#APP_FILES#img/da-share.png'
);
wwv_flow_imp_page.create_page_meta_tag(
 p_id=>wwv_flow_imp.id(15568564439413562280)
,p_meta_tag_name=>'twitter:image'
,p_meta_tag_value=>'#APP_FILES#img/da-share.png'
);
wwv_flow_imp_page.create_page_meta_tag(
 p_id=>wwv_flow_imp.id(16086294225182181654)
,p_meta_tag_name=>'description'
,p_meta_tag_value=>'Sharing an APEX page to the world'
);
wwv_flow_imp.component_end;
end;
/
