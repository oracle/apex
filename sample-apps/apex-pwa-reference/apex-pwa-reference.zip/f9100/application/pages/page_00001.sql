prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>14776237248443586610
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Home - &APP_NAME.'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'13'
,p_last_updated_by=>'VMORNEAU'
,p_last_upd_yyyymmddhh24miss=>'20221221185128'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(639571140021457342)
,p_name=>'Features'
,p_template=>wwv_flow_imp.id(15414446093797979093)
,p_display_sequence=>20
,p_region_css_classes=>'col-lg-10 col-xl-8 col-xxl-8'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:t-ContentBlock--lightBG:t-ContentBlock--hideHeader'
,p_component_template_options=>'t-MediaList--showIcons:t-MediaList--showDesc:t-MediaList--cols t-MediaList--2cols:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  1 id,',
'  ''Faster Performance'' list_title,',
'  ''Take advantage of advanced caching for even faster page rendering performance.'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-bolt'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  2 id,',
'  ''Install on Mobile or Desktop'' list_title,',
'  ''Your app can be installed on any desktop or mobile devices without downloading from an app store.'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-cloud-arrow-down'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  3 id,',
'  ''Feels Native'' list_title,',
'  ''Your app runs fullscreen, can be added to the home screen, provide shortcuts actions, and is searchable.'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-mobile'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  4 id,',
'  ''Lightweight'' list_title,',
'  ''APEX PWAs have a tiny footprint on devices and take virtually no space compared to native apps.'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-compress'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  5 id,',
'  ''Device Integration'' list_title,',
'  ''Fetch geolocation, display native share sheets, access the camera, and more.'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-shapes'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  6 id,',
'  ''Fully Branded'' list_title,',
'  ''Customize your app''''s appearance, including home screen icons, color scheme, logo and more.'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-design'' icon_class',
'from sys.dual'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(15414518399772979158)
,p_query_num_rows=>999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(752212084830285001)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(752212122721285002)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'List Title'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(752212207610285003)
,p_query_column_id=>3
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'List Text'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(752212352670285004)
,p_query_column_id=>4
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'List Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(752212413477285005)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(752212566970285006)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>60
,p_column_heading=>'Link Attr'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(752212635131285007)
,p_query_column_id=>7
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>70
,p_column_heading=>'Icon Color Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(752212767127285008)
,p_query_column_id=>8
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>80
,p_column_heading=>'Icon Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(669555952217976945)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>10
,p_plug_grid_column_css_classes=>'col-lg-10 col-xl-8 col-xxl-8'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Oracle APEX enables developers to build Progressive Web Apps (PWAs) that can be installed on any desktop or mobile device ',
'    to deliver a more native app experience. This application serves as a reference for key PWA features in APEX and how you can use them in your own apps.',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(752214297657285023)
,p_plug_name=>'Progressive Web Apps in APEX'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15414450674197979096)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    Users install an Oracle APEX Progressive Web App on any desktop or mobile device for a rich experience that rivals native apps and uses advanced caching for improved performance.',
'</p>'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15277975551456717049)
,p_plug_name=>'Explore'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_component_template_options=>'#DEFAULT#:t-Cards--featured force-fa-lg:t-Cards--displayIcons:t-Cards--3cols:t-Cards--hideBody:t-Cards--iconsRounded:t-Cards--animColorFill'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>30
,p_plug_grid_column_css_classes=>'col-lg-10 col-xl-8 col-xxl-8'
,p_list_id=>wwv_flow_imp.id(15414381537983979031)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(15414532362893979174)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp.component_end;
end;
/
