prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>1580934860364765
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Home - &APP_NAME.'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1247817139630399436)
,p_name=>'Features'
,p_template=>2322115667525957943
,p_display_sequence=>20
,p_region_css_classes=>'col-lg-10 col-xl-8 col-xxl-8'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:t-ContentBlock--lightBG:t-ContentBlock--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'t-MediaList--showIcons:t-MediaList--showDesc:t-MediaList--cols t-MediaList--2cols:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  1 id,',
'  ''Faster Performance'' list_title,',
'  ''Take advantage of advanced caching for even faster page rendering performance.'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-bolt'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  2 id,',
'  ''Install Anywhere'' list_title,',
'  ''Your app can be installed on any desktop or mobile devices without downloading from an app store.'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-cloud-arrow-down'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  3 id,',
'  ''Feels Native'' list_title,',
'  ''Your app runs fullscreen, can be added to the home screen, provide shortcuts actions, and is searchable.'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-mobile'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  4 id,',
'  ''Lightweight'' list_title,',
'  ''APEX PWAs have a tiny footprint on devices and take virtually no space compared to native apps.'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-compress'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  5 id,',
'  ''Device Integration'' list_title,',
'  ''Send notifications, fetch geolocation, share APEX data to other apps, access the camera, and more.'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-shapes'' icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'  6 id,',
'  ''Fully Branded'' list_title,',
'  ''Customize your app''''s appearance, including home screen icons, color scheme, logo and more.'' list_text,',
'  null list_class,',
'  null link, ',
'  null link_attr,',
'  null icon_color_class,',
'  ''fa fa-design'' icon_class',
'from sys.dual',
'',
'order by id'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2093604263195414824
,p_query_num_rows=>999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1360458084439227095)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1360458122330227096)
,p_query_column_id=>2
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'List Title'
,p_use_as_row_header=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1360458207219227097)
,p_query_column_id=>3
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>30
,p_column_heading=>'List Text'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1360458352279227098)
,p_query_column_id=>4
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'List Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1360458413086227099)
,p_query_column_id=>5
,p_column_alias=>'LINK'
,p_column_display_sequence=>50
,p_column_heading=>'Link'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1360458566579227100)
,p_query_column_id=>6
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>60
,p_column_heading=>'Link Attr'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1360458634740227101)
,p_query_column_id=>7
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>70
,p_column_heading=>'Icon Color Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1360458766736227102)
,p_query_column_id=>8
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>80
,p_column_heading=>'Icon Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1277801951826919039)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2:margin-bottom-sm'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_grid_column_css_classes=>'col-lg-10 col-xl-8 col-xxl-8'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Oracle APEX provides developers with the ability to create Progressive Web',
'    Apps (PWAs) that can be easily installed on any desktop or mobile device,',
'    offering users a more native app experience. This application serves as a',
'    useful reference for developers looking to incorporate key PWA features',
'    into their own applications, helping them to create more engaging and',
'    user-friendly apps.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1360460297266227117)
,p_plug_name=>'Progressive Web Apps in APEX'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    Users install an Oracle APEX Progressive Web App on any desktop or mobile device for a rich experience that rivals native apps and uses advanced caching for improved performance.',
'</p>'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15886221551065659143)
,p_plug_name=>'Explore'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_component_template_options=>'#DEFAULT#:t-Cards--featured force-fa-lg:t-Cards--displayIcons:t-Cards--3cols:t-Cards--hideBody:t-Cards--iconsRounded:t-Cards--animColorFill'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_plug_grid_column_css_classes=>'col-lg-10 col-xl-8 col-xxl-8'
,p_list_id=>wwv_flow_imp.id(16022627537592921125)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2886769488667748277
);
wwv_flow_imp.component_end;
end;
/
