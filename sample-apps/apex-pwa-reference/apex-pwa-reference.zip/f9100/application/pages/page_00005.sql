prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>14776237248443586610
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Service Worker'
,p_alias=>'SERVICE-WORKER'
,p_step_title=>'Service Worker - &APP_NAME.'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'11'
,p_last_updated_by=>'LEORODRI'
,p_last_upd_yyyymmddhh24miss=>'20221123152136'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15277976556071717059)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15414417723667979070)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_landmark_type=>'navigation'
,p_landmark_label=>'Region Display Selector'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15414606398769110990)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15414496134625979135)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(15414381005396979030)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(15414558240090979203)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15414617010276454530)
,p_plug_name=>'Default'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>When PWA is enabled for an APEX application, the a default service worker is generated with the following strategy:</p>',
'<ul>',
'    <li>Install and activate the service worker</li>',
'    <li>Serve resources from cache if cache exists</li>',
'    <li>Otherwise serve from network, then put resource in cache</li>',
'    <li>Serve an offline page if network fails</li>',
'</ul>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15414617084862454531)
,p_plug_name=>'Hooks'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The service worker can be modified through hooks or by replacing events completely. By tapping into service worker hooks, developers are able to extend their APEX application to support advanced PWA features such as offline or push notifications, '
||'that are not yet offered declaratively in APEX.</p>',
'',
'<p>Developers can hook into service worker events to add their own JavaScript code.</p>',
'',
'<ul>',
'    <li>Function and Variable Declaration</li>',
'    <li>Event: install</li>',
'    <li>Event: activate</li>',
'    <li>Event: fetch</li>',
'    <li>Event: sync</li>',
'    <li>Event: push</li>',
'    <li>Event: notificationclick</li>',
'    <li>Event: notificationclose</li>',
'    <li>Event: canmakepayment</li>',
'    <li>Event: paymentrequest</li>',
'</ul>',
'',
'<p>Go to the PWA attributes page in the APEX Builder to read more about how to leverage service worker hooks.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15414617218438454532)
,p_plug_name=>'File URL'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>'<p>Alternatively, service worker hooks can be shared across multiple applications by providing a URL reference to a file that contains the service worker hooks interface. If using the file reference, make sure to follow the interface architecture app'
||'ropriately or else the service worker will fail at runtime.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31412430931387928710)
,p_plug_name=>'Service Worker Interface'
,p_parent_plug_id=>wwv_flow_imp.id(15414617218438454532)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414483650130979122)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<code>const swHooks = {',
'  FUNCTION_VARIABLE_DECLARATION: ({ apex })                         => { console.log(1, { apex }); },',
'  EVENT_INSTALL:                 ({ apex, event })                  => { console.log(2, { apex, event }); },',
'  EVENT_INSTALL_BEFORE:          ({ apex, event })                  => { console.log(3, { apex, event }); },',
'  EVENT_INSTALL_AFTER:           ({ apex, event })                  => { console.log(4, { apex, event }); },',
'  EVENT_ACTIVATE:                ({ apex, event })                  => { console.log(5, { apex, event }); },',
'  EVENT_ACTIVATE_BEFORE:         ({ apex, event })                  => { console.log(6, { apex, event }); },',
'  EVENT_ACTIVATE_AFTER:          ({ apex, event })                  => { console.log(7, { apex, event }); },',
'  EVENT_FETCH:                   ({ apex, event })                  => { console.log(8, { apex, event }); },',
'  EVENT_FETCH_BEFORE:            ({ apex, event })                  => { console.log(9, { apex, event }); },',
'  EVENT_FETCH_CACHE_DEFINITION:  ({ apex, event, cacheName })       => { console.log(10, { apex, event, cacheName }); },',
'  EVENT_FETCH_CACHE_RESPONSE:    ({ apex, event, cache, response }) => { console.log(11, { apex, event, cache, response }); },',
'  EVENT_FETCH_NETWORK_RESP_SUC:  ({ apex, event, response })        => { console.log(12, { apex, event, response }); },',
'  EVENT_FETCH_NETWORK_RESP_ERR:  ({ apex, event, error })           => { console.log(13, { apex, event, error }); },',
'  EVENT_FETCH_OFFLINE_PAGE:      ({ apex, event, offlinePage })     => { console.log(14, { apex, event, offlinePage }); },',
'  EVENT_FETCH_NETWORK_FALLBACK:  ({ apex, event })                  => { console.log(15, { apex, event }); },',
'  EVENT_SYNC:                    ({ apex, event })                  => { console.log(16, { apex, event }); },',
'  EVENT_PUSH:                    ({ apex, event })                  => { console.log(17, { apex, event }); },',
'  EVENT_NOTIFICATIONCLICK:       ({ apex, event })                  => { console.log(18, { apex, event }); },',
'  EVENT_NOTIFICATIONCLOSE:       ({ apex, event })                  => { console.log(19, { apex, event }); },',
'  EVENT_CANMAKEPAYMENT:          ({ apex, event })                  => { console.log(20, { apex, event }); },',
'  EVENT_PAYMENTREQUEST:          ({ apex, event })                  => { console.log(21, { apex, event }); },',
'};</code>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15414618538366454545)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_source=>'<p>Service workers is a foundational technology for PWAs. Service workers react to incoming requests from web apps, allowing a web app to be designed for offline, receiving push notification and much more. Service workers can execute JavaScript code '
||'even when the app is not in use.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
