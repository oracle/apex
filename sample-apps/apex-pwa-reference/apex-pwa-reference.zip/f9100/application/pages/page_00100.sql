prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>14776237248443586610
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>100
,p_name=>'FAQ'
,p_alias=>'FAQ'
,p_step_title=>'FAQ'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'11'
,p_last_updated_by=>'LEORODRI'
,p_last_upd_yyyymmddhh24miss=>'20221218222305'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(752216682419285047)
,p_plug_name=>'PWAs'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>240
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Questions about PWA as a standalone technology</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(750392638139773434)
,p_plug_name=>'What is a PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(752216682419285047)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    ',
'    A Progressive Web App (PWA) is a type of web application that uses',
'    modern web capabilities to give users a native app-like',
'    experience. PWAs work on any platform with a standards-compliant',
'    browser, including desktop, mobile, and tablet devices.',
'',
'</p>',
'<p>',
'  ',
'    When a user visits a PWA in their browser, they can choose to',
'    install it on their device. They can then launch it from the',
'    device''s home screen like a native app. It runs in its own window,',
'    separate from the browser.',
'',
'</p>',
'<p>',
'',
'    PWAs can work offline, with features the user can use even when',
'    the device is not connected to the internet. Background scripts',
'    called <i>service workers</i> enable this capability, caching resources',
'    for later use.',
'',
'</p>',
'<p>',
'',
'    PWAs offer many benefits over traditional native apps.  They work',
'    on any device with a standards-compliant browser, are faster to',
'    deploy and install, and are less expensive to develop and',
'    maintain. They are more discoverable, since they can be found',
'    through search engines. They are more intuitive for users who',
'    always use the app''s latest features automatically without having',
'    to find, download, or update the app from an app store.',
'',
'</p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(750393124086773439)
,p_plug_name=>'What devices and browsers are compatible with PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(752216682419285047)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Users can install PWAs on a wide range of devices, including',
'    smartphones, tablets, and desktop computers, and access them',
'    through compatible web browsers.',
'',
'</p>',
'<p>',
'',
unistr('    All four modern web browsers that APEX supports \2013 Google Chrome,'),
unistr('    Mozilla Firefox, Microsoft Edge, and Apple Safari \2013 offer a rich'),
'    set of PWA features, but the exact set of PWA capabilities that',
'    each one offers depends on the browser.',
'',
'</p>',
'<p>',
'',
'    For each APEX PWA feature, this reference app carefully documents',
'    which combination of device and browser supports it. Explore the',
'    different pages of this application using the navigation menu to',
'    learn more.',
'',
'</p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(750393235752773440)
,p_plug_name=>'Is PWA a native mobile app?'
,p_parent_plug_id=>wwv_flow_imp.id(752216682419285047)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>30
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    No, but they behave like a native application in virtually all the',
'    ways end users care about. They are web-based apps that any user',
'    can install on their device and access like a native app, but they',
'    are not built using the native programming languages of the',
'    device''s operating system (such as Swift for iOS or Java for',
'    Android). PWAs can leverage native device resources like',
'    front-facing and selfie camera, native keyboards for entering',
'    decimals and numbers, sensors like GPS, accelerometer, and',
'    altimeter, and the native share sheet to exchange information or',
'    files to other apps or contacts. Using the PWA service worker',
'    hooks APEX offers to developers familiar with JavaScript, apps can',
'    further take advantage of push notifications, offline data',
'    handling, payment methods, and more.',
'',
'</p>',
'<p>',
'',
'    Since it is always automatically up to date with the latest',
'    version of your application onthe server, end users never need to',
'    manually update their installed app and you never have to bother',
'    users with pleas to install the latest version.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(755193167736888408)
,p_plug_name=>'Is it possible to generate an APK of my PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(752216682419285047)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>170
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Yes, it is possible to generate an Android Package Kit (APK) file',
'    for a PWA. An APK is a package file format used to distribute and',
'    install mobile apps on the Android operating system.',
'',
'</p>',
'',
'<p>',
'',
'    There are several tools and services that you can use to generate',
'    an APK file for your PWA:',
'',
'</p>',
'',
'<ol>',
'  <li>',
'',
'    PWA to APK: This is a online service that allows you to generate',
'    an APK file that can be installed on Android devices.',
'',
'  </li>',
'  <li>',
'',
'    PWA Wrapper: This is a command-line tool that allows you to',
'    generate an APK file for your PWA by providing the URL of your PWA',
'    and specifying some configuration options.',
'',
'  </li>',
'  <li>',
'',
'    PWA Builder: This is a web tool that allows you to generate an APK',
'    file for your PWA by providing the URL of your PWA and specifying',
'    some configuration options.',
'',
'  </li>',
'</ol>',
'',
'<p>',
'',
'    Once you have generated an APK file for your PWA, you can',
'    distribute it to users through the Google Play Store or other app',
'    stores, or by sharing the APK file directly with users. Users can',
'    install the APK file on their Android devices by opening the file',
'    on their device.',
'',
'</p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(752216725970285048)
,p_plug_name=>'APEX PWAs'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>250
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Questions about Oracle APEX''s support for PWA</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(672950921041005721)
,p_plug_name=>'What is an APEX PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(752216725970285048)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>40
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    An APEX PWA is a Progressive Web Application developed using',
'    Oracle APEX.',
'',
'</p>',
'<p>',
'',
'    Users access APEX PWA apps through a web browser on a wide range',
'    of devices, including smartphones, tablets, and desktop',
'    computers. They can install the app on their device and access it',
'    like a native app. Oracle APEX makes developing PWAs apps easy. ',
'',
'</p>',
'<p>',
'',
'    APEX PWA applications offer many benefits unique to the Oracle',
'    APEX platform, such as the ability to easily connect to Oracle',
'    databases and integrate with all other APEX features.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(750393365285773441)
,p_plug_name=>'How long does it take to develop an APEX PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(752216725970285048)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>50
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    The time it takes to develop an APEX PWA will depend on a number',
'    of factors, but it should require minimal additional effort by',
'    Oracle APEX developers. Two declarative, app-level settings',
'    control whether your application will be installable by users as a',
'    PWA. When creating a new application, the wizard reduces the',
'    effort to a single click.',
'',
'</p>',
'<p>',
'',
'    Your project''s specific requirements influence the time required',
'    to develop an APEX PWA. A simple app with few pages and basic',
'    functionality could potentially be developed in a few days or',
'    weeks. In contrast, a more complex APEX PWA with advanced features',
'    and integrations could take longer to develop.',
'',
'</p>',
'<p>',
'',
'    For advanced scenarios, developers can fully customize the APEX',
'    PWA''s Web App Manifest and Service Worker. When a project''s',
'    requirements require this level of customization, it''s hard to',
'    estimate the time and effort required.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(750393486601773442)
,p_plug_name=>'Can my existing APEX app become a PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(752216725970285048)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>70
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Yes, easily. First, make sure the <strong>Friendly URLs</strong> app',
'    setting is enabled.  Then ensure your application is served using',
'    HTTPS. Finally, switch on the two additional app-level',
'    settings <strong>Enable Progressive Web App</strong>',
'    and <strong>Installable</strong>.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(755192660132888403)
,p_plug_name=>'How do APEX PWAs use caching on a device?'
,p_parent_plug_id=>wwv_flow_imp.id(752216725970285048)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>230
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    In an APEX PWA, certain resources are cached by default to improve',
'    the performance of the app.',
'',
'</p>',
'<p>',
'',
'    By default, APEX PWAs use a service worker to cache static',
'    resources, such as JavaScript and CSS files, as well as image and',
'    font files. These resources are stored in the browser''s cache and',
'    are available offline, which can help to improve the app''s',
'    performance and make it more resilient to network disruptions.',
'',
'</p>',
'<p>',
'',
'    However, not all resources are cached in an APEX PWA. Dynamic',
'    content, such as data retrieved from the database, is not cached',
'    by default. This means that if an app needs to access this type of',
'    content while offline, its developer needs to be familiar with',
'    JavaScript and implement their own mechanism using supported',
'    Service Worker hooks for storing and retrieving the data.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(755192881056888405)
,p_plug_name=>'Do users need to sign in every time they open my APEX PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(752216725970285048)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>80
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    By default, users need to sign in every time they access an APEX',
'    application, and they stay authenticated for the duration of their',
'    app session. However, APEX provides several options for',
'    maintaining user sessions and allowing users to stay signed in,',
'    including the use of cookies, session state, and authentication',
'    schemes.',
'',
'</p>',
'<p>',
'',
'    After an instance administrator enables APEX''s persistent',
'    authentication feature, you can offer users the same native',
'    application launch experience they are familiar with from native',
'    desktop and mobile applications. Your APEX PWA users can tick',
'    a <strong>Remember me</strong> checkbox on their first login and',
'    stay logged in for a fixed period of time. By default a user''s',
'    authentication is remembered for 30 days, but you can configure',
'    that at the instance level.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(755193494272888411)
,p_plug_name=>'Can APEX PWAs use operating system resources?'
,p_parent_plug_id=>wwv_flow_imp.id(752216725970285048)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>90
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Yes, in most of the ways that matter most to end users, but not',
'    all operating system resources are available. Since Oracle APEX',
'    PWAs are web-based applications, they are not built using the',
'    native programming languages of the device''s operating system. As',
'    a result, they do not have the same level of access to the',
'    device''s hardware and software as native apps.',
'',
'</p>',
'<p>',
'',
'    An APEX PWA can access the device''s camera, location, share sheet',
'    and storage using both declarative and programmatic APIs, as well',
'    as cache network requests. The specific resources and features',
'    available to an APEX PWA will depend on the capabilities of the',
'    device and the web browser being used to access the application.',
'',
'</p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(762651570934928720)
,p_plug_name=>'Is it possible to have APEX Builder become a PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(752216725970285048)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>240
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'  ',
'    Making the APEX Builder a seamless PWA desktop experience is on our',
'    roadmap. It implies creating a group of applications that will',
'    function as a single PWA.',
'',
'</p>',
'',
'<p>',
'  ',
'    APEX Builder consists of numerous apps and it makes sense to have them',
'    as a single PWA. Customers will also be able to define a multi app PWA',
'    ecosystem.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(753238418754296160)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15414496134625979135)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(15414381005396979030)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(15414558240090979203)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(761920658123430842)
,p_plug_name=>'Development Tips'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>260
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Development tips for APEX developers building PWAs</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(750392891621773436)
,p_plug_name=>'How do I develop an APEX PWA icon?'
,p_parent_plug_id=>wwv_flow_imp.id(761920658123430842)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>110
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    You can choose one of the built-in icon and color combinations, or',
'    upload your own custom icon in PNG or JPG formats.',
'',
'</p>',
'<p>',
'',
'    You can also develop the icon using your favorite graphics program',
'    and should target 512x512 size for best results.  Once uploaded,',
'    APEX lets you optionally scale and crop the icon before it',
'    proceeds to save your app icon as shared application files. APEX',
'    will downsize and resize the icon to all appriopriate icon sizes',
'    it requires.',
'',
'</p>',
'<p>',
'',
'    APEX will generate the appropriate icon files and reference them',
'    automatically from all revelant places in your APEX app where the',
'    app icon needs to be displayed, such as the favicon, the PWA',
'    install icon, the login screen icon, etc.',
'',
'</p>',
'<p>',
'',
'    As of APEX 22.2, APEX will generate 3 files out of the original',
'    icon: 512x512, 192x192 and 32x32.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(750392905933773437)
,p_plug_name=>'How can I customize the UI of my APEX PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(761920658123430842)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>130
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'  ',
'    You can customize the appearance of your APEX PWA by configuring',
'    the display mode, orientation, theme color, background color,',
'    status bar style (for iOS), as well as use application shortcuts,',
'    and custom manifest properties.',
'',
'</p>',
'',
'<p>',
'',
'    It''s a good idea to validate the responsive design behaviour of',
'    your APEX PWA application through adequate testing on different',
'    devices or simulators.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(755193590626888412)
,p_plug_name=>'Can my APEX PWA use geolocation?'
,p_parent_plug_id=>wwv_flow_imp.id(761920658123430842)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>100
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Yes, it is possible for an APEX PWA to access and use geolocation',
'    information. Geolocation refers to the location of a device or',
'    user, typically determined using GPS or other location-based',
'    technologies.',
'',
'</p>',
'<p>',
'',
'    In an APEX PWA, you can declaratively acquire location, speed,',
'    direction, and altitude using the <strong>Get Current',
'    Position</strong> dynamic action (subject to the user''s granting',
'    permission). Your app can also declaratively geolocate any other',
'    address on the planet using built-in features. Your APEX PWA can',
'    take full advantage of APEX''s data-savvy map region to visualize',
'    location-based data on mobile devices, too.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(755193754484888414)
,p_plug_name=>'Can my APEX PWA detect the device I''m on?'
,p_parent_plug_id=>wwv_flow_imp.id(761920658123430842)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>210
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    APEX provides various JavaScript APIs to identify the current mode',
'    in which the PWA is accessed. For example this function is used to',
'    determine if the application is currently accessed through the PWA',
'    application (eg. in fullscreen) or through the browser',
'    normally. Possible values',
'    are: <strong>fullscreen</strong>, <strong>standalone</strong>, <strong>minimal-ui</strong>,',
'    and <strong>browser</strong>.',
'',
'</p>',
'',
'<pre><code>const displayMode = apex.pwa.getDisplayMode();</code></pre>',
'',
'<p>',
'',
'    Otherwise, it can be done using JavaScript and',
'    the <code>navigator.userAgent</code> property, which returns a',
'    string containing information about the device''s user agent,',
'    however this is not recommended as user agents can change without',
'    prior notice.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(761920589644430841)
,p_plug_name=>'How do I fix my macOS APEX PWA icon?'
,p_parent_plug_id=>wwv_flow_imp.id(761920658123430842)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>120
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    It has been reported that macOS doesn''t render the APEX PWA icon',
'    properly on the dock which leads to obvious UI disparities. To',
'    resolve this issue, design two special icons for macOS (144x144',
'    and 256x256) and inject them through the APEX PWA custom',
'    manifest. Follow <a href="https://developer.apple.com/design/resources/#macos-apps">Apple',
'    Design Guidelines</a>, upload the icon to your application static',
'    application files, and use the following custom manifest:',
'',
'</p>',
'<pre><code>{',
'    "icons": [',
'        { "src": "#APP_FILES#icons/app-icon-144-macos.png", "type": "image/png", "sizes": "144x144" },',
'        { "src": "#APP_FILES#icons/app-icon-192.png", "type": "image/png", "sizes": "192x192" },',
'        { "src": "#APP_FILES#icons/app-icon-256-macos.png", "type": "image/png", "sizes": "256x256" },',
'        { "src": "#APP_FILES#icons/app-icon-512.png", "type": "image/png", "sizes": "512x512" }',
'    ]',
'}</code></pre>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(762651436521928719)
,p_plug_name=>'Is there any way to avoid the splash screen when opening the app after some idle time?'
,p_parent_plug_id=>wwv_flow_imp.id(761920658123430842)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>220
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Like most PWA features, each browser can behave differently. As for',
'    iOS on APEX 22.2, there is currently no declarative way of defining',
'    a splash screen while the app loads. However, it can be done by',
'    adding a new link tag on the page manually ',
'    ',
'</p>',
'',
unistr('<pre><code>&lt;link rel=\201Capple-touch-startup-image\201D href=\201C#APP_FILES#ios-startup.png\201D&gt;</code></pre>'),
'',
'<p>',
'',
'    We should look into making this declarative in future APEX releases.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(761920729974430843)
,p_plug_name=>'Business'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>270
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Questions that could influence a business decision to use PWA or not</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(750392729700773435)
,p_plug_name=>'What apps are best for PWA and which ones are not recommended?'
,p_parent_plug_id=>wwv_flow_imp.id(761920729974430843)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    PWAs are well-suited for a wide range of applications, letting',
'    users quickly launch and use nearly any kind of data-centric',
'    application on smartphones, tablets, and desktop or laptop',
'    computers. This includes the vast majority of typical Oracle APEX',
'    applications, including:',
'',
'</p>',
'',
'<ul>',
'  <li>',
'',
'    Tracking, planning, productivity, and process automation apps with',
'    compelling data-driven visualizations, reporting, and data entry,',
'',
'  </li>',
'  <li>',
'',
'    E-commerce apps with a seamless shopping experience for quickly',
'    finding and buying goods and services,',
'',
'  </li>',
'  <li>',
'',
'    Social networking apps to interact with peers to ask questions,',
'    get answers, or exchange thoughts using text and media,',
'',
'  </li>',
'  <li>',
'',
'    News and media apps to abreast of a fast-changing world',
'',
'  </li>',
'</ul>',
'',
'<p>',
'',
'    While additional PWA features like offline support and push',
'    notifications require JavaScript skills to achieve with Oracle',
'    APEX today, they are possible to accomplish using supported APEX',
'    Service Worker hooks. This means that any of the APEX PWA',
'    applications above can be made to support these features to keep',
'    users working when connectivity is not reliable and keep them',
'    engaged through targeted app-specific alerts on their device.',
'  ',
'</p>',
'',
'<p>',
'',
'    However, not all apps are well-suited for PWA development. For',
'    example, apps that require complex graphics rendering or real-time',
'    data processing may not be suitable. ',
'',
'</p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(755192796704888404)
,p_plug_name=>'Can my PWA be installed from Google Play or App Store?'
,p_parent_plug_id=>wwv_flow_imp.id(761920729974430843)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>30
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    PWAs can be published to the Google Play Store and Apple App',
'    Store, but the process for doing so is different from the process',
'    for publishing a traditional native app.',
'',
'</p>',
'<p>',
'',
'    To publish a PWA to the Google Play Store, you will need to follow',
'    the steps outlined in the Google Play Console documentation. This',
'    process involves creating a new listing for your PWA in the Google',
'    Play Store, uploading your PWA''s web manifest and other required',
'    assets, and setting up a distribution channel for your PWA. Once',
'    the steps are completed, it will be made available in the Google',
'    Play Store for users to download and install on their devices.',
'',
'</p>',
'<p>',
'',
'    To publish a PWA to the Apple App Store, you will need to follow',
'    the steps outlined in the App Store Connect documentation. This',
'    process involves creating a new listing for your PWA in the App',
'    Store, wrapping your PWA in Swift as a Webview. Once your PWA has',
'    been reviewed and approved by Apple, it will be made available in',
'    the App Store for users to download and install on their devices.',
'',
'</p>',
'<p>',
'',
'    There are publishing costs to both stores.',
'',
'</p>',
'<p>',
'',
'    We plan to make this integration process easier in the future,',
'    hopefully with some steps automated within the APEX Builder.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(755192915745888406)
,p_plug_name=>'How can I implement push notifications in my PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(761920729974430843)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>70
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Push notifications in APEX is the top priority for the PWA',
'    roadmap.',
'',
'</p>',
'<p>',
'',
'    If you can''t afford to wait until APEX has declarative push',
'    notification support, you can use the custom service worker hooks',
'    to inject your own push notification server and transport',
'    layer. To do this, you will need to use the Web Push API. This API',
'    allows web apps to receive push notifications from a server, even',
'    when the app is not currently active in the browser.',
'',
'</p>',
'',
'<p>',
'',
'    Here is a high-level overview of the steps involved in',
'    implementing push notifications in a PWA:',
'',
'</p>',
'',
'<ol>',
'  <li>',
'',
'    Enable PWA in your APEX application.',
'',
'  </li>',
'  <li>',
'',
'    Request permission from the user to send push notifications. This',
'    can be done using the Notification.requestPermission() method.',
'',
'  </li>',
'  <li>',
'',
'    If the user grants permission, the browser will send a push',
'    subscription object, which contains a unique identifier for the',
'    user''s device and a public key that can be used to send push',
'    notifications to the device.',
'',
'  </li>',
'  <li>',
'',
'    Send the push subscription object to your server. This allows your',
'    server to send push notifications to the user''s device through the',
'    browser''s push service.',
'',
'  </li>',
'  <li>',
'',
'    When your server wants to send a push notification, it can use the',
'    push subscription object to send a message to the browser''s push',
'    service, which will then deliver the notification to the user''s',
'    device.',
'',
'  </li>',
'</ol>',
'',
'<p>',
'',
'    For more detailed information and code examples, you may find it',
'    helpful to consult the documentation for the Web Push API and',
'    service workers. You can also find many resources online that',
'    provide tutorials and guidance on implementing push notifications',
'    in PWAs.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>14776237248443586610
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(755193038250888407)
,p_plug_name=>'Can my APEX PWA support payment methods?'
,p_parent_plug_id=>wwv_flow_imp.id(761920729974430843)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>40
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    It is possible for APEX PWAs to support payment, but it requires',
'    some manual coding. A JavaScript developer on your team would use',
'    the APEX custom service worker to call the Web Payment API, a',
'    browser-based standard for handling payments on the web. It allows',
'    users to make payments using a variety of payment methods,',
'    including credit cards, debit cards, and digital wallets. The Web',
'    Payment API can be used to implement payment support in a PWA.',
'',
'</p>',
'',
'<p>',
'',
'    The <strong>canmakepayment</strong> event of the service worker',
'    interface is fired when the client requests the authorization',
'    status of the Payment Handler API. It can be used to check if the',
'    browser supports at least one payment method. More info:',
'',
'</p>',
'',
'<ul>',
'    <li><a rel="noreferrer" href="https://developer.mozilla.org/en-US/docs/Web/API/Payment_Request_API/Using_the_Payment_Request_API">https://developer.mozilla.org/en-US/docs/Web/API/Payment_Request_API/Using_the_Payment_Request_API</a></li>',
'    <li><a rel="noreferrer" href="https://web.dev/web-payments-updates">https://web.dev/web-payments-updates</a>/</li>',
'    <li><a rel="noreferrer" href="https://www.w3.org/TR/payment-handler/#handling-a-canmakepaymentevent">https://www.w3.org/TR/payment-handler/#handling-a-canmakepaymentevent</a></li>',
'</ul>',
'',
'<p>',
'',
'    The <strong>paymentrequest</strong> event of the service worker',
'    interface is fired when client chooses to pay with a web-based',
'    payment app. It can be used to initiate a payment on a web app,',
'    using payment methods such as Google Pay. More info:',
'',
'</p>',
'',
'<ul>',
'    <li><a rel="noreferrer" href="https://web.dev/how-payment-request-api-works/">https://web.dev/how-payment-request-api-works/</a></li>',
'    <li><a rel="noreferrer" href="https://web.dev/orchestrating-payment-transactions/">https://web.dev/orchestrating-payment-transactions/</a></li>',
'</ul>',
'',
'<p>',
'',
'    Implementing payment support in a PWA requires careful consideration',
'    of security and compliance issues. You should follow best',
'    practices to ensure that sensitive payment information is handled',
'    securely, and comply with relevant regulations and standards.',
'',
'</p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(755193365472888410)
,p_plug_name=>'Is it possible to use my APEX PWA offline?'
,p_parent_plug_id=>wwv_flow_imp.id(761920729974430843)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>50
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    The short answer is: not easily. APEX does provide a user friendly',
'    offline fallback page when there is no connection to the internet,',
'    however. You can easily customize this fallback page in a',
'    declarative way.',
'',
'</p>',
'<p>',
'',
'    For advanced users, it is technically possible to enable offline',
'    support for an APEX PWA. This entails using the custom Service',
'    Worker feature, which allows APEX applications to intercept',
'    network requests and serve cached responses when the device is',
'    offline.',
'',
'</p>',
'<p>',
'',
'    Within the service worker hooks, the <strong>fetch</strong> event',
'    is reponsible for intercepting network requests. It can be',
'    extended to cache complete pages, specific resources and',
'    requests. When offline, the service worker would be responsible',
'    for fetching the cached resources instead of going to the network.',
'',
'</p>',
'<p>',
'',
'    It is not trivial to make an APEX PWA app work offline in a',
'    generic way that would allow arbitrary searching, creation, and',
'    modification of the rich application data model that exists behind',
'    the typical APEX application.  We hope APEX can provide easier',
'    mechanisms to enable basic offline features in future releases of',
'    APEX.',
'</p>',
'<p>',
'',
'    Until then, developers can venture into the custom service worker',
'    hooks to enable specific application use cases. In doing so, these',
'    more advanced APEX developers can help the Oracle APEX community',
'    and development team better understand the most common offline',
'    data access patterns that surface in your applications. This',
'    information will help us narrow the focus on delivering',
'    incremental offline data capabilities into future Oracle APEX',
'    versions. You can do this by logging new ideas for targeted',
'    offline capabilities based on your experiences',
'    at <a target="_blank"',
'    href="https://apex.oracle.com/ideas">apex.oracle.com/ideas</a>.',
'',
'</p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(755193611663888413)
,p_plug_name=>'Can I track how many times my PWA was installed?'
,p_parent_plug_id=>wwv_flow_imp.id(761920729974430843)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15414436607445979086)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    As of APEX 22.2 this is not possible, but it is on our Roadmap. We',
'    are always careful when it comes to telemetry of direct user',
'    interaction, therefore APEX should provide a solution that is',
'    non-intrusive to users.',
'',
'</p>',
'',
'<p>',
'',
'    As an alternative today, workspace admins can track how many apps',
'    were developed as a PWA along with the different PWA attributes.',
'',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
