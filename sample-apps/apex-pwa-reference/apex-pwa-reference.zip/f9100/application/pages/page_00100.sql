prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>1580934860364765
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>100
,p_name=>'FAQ'
,p_alias=>'FAQ'
,p_step_title=>'FAQ'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1360462682028227141)
,p_plug_name=>'General'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>240
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Questions about PWA as a standalone technology</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1065994991370269016)
,p_plug_name=>'How do I uninstall a PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(1360462682028227141)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>180
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'Uninstalling a PWA varies slightly depending on the device and platform you are using. Here''s how to uninstall a PWA on Android, iOS, and desktop platforms:',
'</p>',
'',
'<p style="white-space: break-spaces;">',
'1. Android:',
'   a. Locate the PWA icon you want to uninstall.',
'   b. Press and hold the app icon until a menu appears.',
'   c. Select ''Uninstall''',
'   d. Confirm the action when prompted.',
'</p>',
'',
'<p style="white-space: break-spaces;">',
'2. iOS:',
'   a. Find the PWA on your home screen.',
'   b. Press and hold the app icon until it starts to wiggle, and an ''X'' appears on the top-left corner of the icon.',
'   c. Tap the ''X'' to uninstall the PWA.',
'   d. Confirm the action when prompted, and then press the home button or swipe up from the bottom of the screen to exit the edit mode.',
'</p>',
'',
'<p style="white-space: break-spaces;">',
'3. Desktop (Windows, macOS) using Chrome and Edge:',
'   a. Launch the PWA from its desktop icon or the applications folder.',
'   b. Click the ''Settings'' (three-dot) menu in the top-right corner of the app window.',
'   c. Select ''Uninstall [App Name]'' from the dropdown menu.',
'   d. Confirm the action when prompted.',
'</p>',
'',
'<p style="white-space: break-spaces;">',
'4. Windows:',
'   a. Click the ''Start'' button and open the list of all installed apps.',
'   b. Locate the PWA you want to uninstall.',
'   c. Right-click on the app and select ''Uninstall'' from the context menu.',
'   d. Follow any additional prompts to complete the uninstallation process.',
'</p>',
'',
'<p>',
'After completing these steps, the PWA will be uninstalled from your device. Keep in mind that these instructions may vary slightly depending on your device model and operating system version.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1358638637748715528)
,p_plug_name=>'What is a PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(1360462682028227141)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    ',
'    A Progressive Web App (PWA) is a type of web application that uses',
'    modern web capabilities to give users a native app-like',
'    experience. PWAs work on any platform with a standards-compliant',
'    browser, including desktop, mobile, and tablet devices.',
'',
'</p>',
'<p>',
'  ',
'    When a user visits a PWA in their browser, they can choose to',
'    install it on their device. They can then launch it from the',
'    device''s home screen like a native app. It runs in its own window,',
'    separate from the browser.',
'',
'</p>',
'<p>',
'',
'    PWAs can work offline, with features the user can use even when',
'    the device is not connected to the internet. Background scripts',
'    called <i>service workers</i> enable this capability, caching resources',
'    for later use.',
'',
'</p>',
'<p>',
'',
'    PWAs offer many benefits over traditional native apps.  They work',
'    on any device with a standards-compliant browser, are faster to',
'    deploy and install, and are less expensive to develop and',
'    maintain. They are more discoverable, since they can be found',
'    through search engines. They are more intuitive for users who',
'    always use the app''s latest features automatically without having',
'    to find, download, or update the app from an app store.',
'',
'</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1358639123695715533)
,p_plug_name=>'What devices and browsers are compatible with PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(1360462682028227141)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Users can install PWAs on a wide range of devices, including',
'    smartphones, tablets, and desktop computers, and access them',
'    through compatible web browsers.',
'',
'</p>',
'<p>',
'',
'    All four modern web browsers that APEX supports - Google Chrome,',
'    Mozilla Firefox, Microsoft Edge, and Apple Safari - offer a rich',
'    set of PWA features, but the exact set of PWA capabilities that',
'    each one offers depends on the browser.',
'',
'</p>',
'<p>',
'',
'    For each APEX PWA feature, this reference app carefully documents',
'    which combination of device and browser supports it. Explore the',
'    different pages of this application using the navigation menu to',
'    learn more.',
'',
'</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1358639235361715534)
,p_plug_name=>'Is PWA a native mobile app?'
,p_parent_plug_id=>wwv_flow_imp.id(1360462682028227141)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>30
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    No, but they behave like a native application in virtually all the',
'    ways end users care about. They are web-based apps that any user',
'    can install on their device and access like a native app, but they',
'    are not built using the native programming languages of the',
'    device''s operating system (such as Swift for iOS or Java for',
'    Android). PWAs can leverage native device resources like',
'    front-facing and selfie camera, native keyboards for entering',
'    decimals and numbers, sensors like GPS, accelerometer, and',
'    altimeter, and the native share sheet to exchange information or',
'    files to other apps or contacts. Using the PWA service worker',
'    hooks APEX offers to developers familiar with JavaScript, apps can',
'    further take advantage of push notifications, offline data',
'    handling, payment methods, and more.',
'',
'</p>',
'<p>',
'',
'    Since it is always automatically up to date with the latest',
'    version of your application onthe server, end users never need to',
'    manually update their installed app and you never have to bother',
'    users with pleas to install the latest version.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1363439167345830502)
,p_plug_name=>'Is it possible to generate an APK of my PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(1360462682028227141)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>170
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Yes, it is possible to generate an Android Package Kit (APK) file',
'    for a PWA. An APK is a package file format used to distribute and',
'    install mobile apps on the Android operating system.',
'',
'</p>',
'',
'<p>',
'',
'    There are several tools and services that you can use to generate',
'    an APK file for your PWA:',
'',
'</p>',
'',
'<ol>',
'  <li>',
'',
'    PWA to APK: This is a online service that allows you to generate',
'    an APK file that can be installed on Android devices.',
'',
'  </li>',
'  <li>',
'',
'    PWA Wrapper: This is a command-line tool that allows you to',
'    generate an APK file for your PWA by providing the URL of your PWA',
'    and specifying some configuration options.',
'',
'  </li>',
'  <li>',
'',
'    PWA Builder: This is a web tool that allows you to generate an APK',
'    file for your PWA by providing the URL of your PWA and specifying',
'    some configuration options.',
'',
'  </li>',
'</ol>',
'',
'<p>',
'',
'    Once you have generated an APK file for your PWA, you can',
'    distribute it to users through the Google Play Store or other app',
'    stores, or by sharing the APK file directly with users. Users can',
'    install the APK file on their Android devices by opening the file',
'    on their device.',
'',
'</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1360462725579227142)
,p_plug_name=>'APEX PWAs'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>250
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Questions about Oracle APEX''s support for PWA</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1281196920649947815)
,p_plug_name=>'What is an APEX PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(1360462725579227142)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>40
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    An APEX PWA is a Progressive Web Application developed using',
'    Oracle APEX.',
'',
'</p>',
'<p>',
'',
'    Users access APEX PWA apps through a web browser on a wide range',
'    of devices, including smartphones, tablets, and desktop',
'    computers. They can install the app on their device and access it',
'    like a native app. Oracle APEX makes developing PWAs apps easy. ',
'',
'</p>',
'<p>',
'',
'    APEX PWA applications offer many benefits unique to the Oracle',
'    APEX platform, such as the ability to easily connect to Oracle',
'    databases and integrate with all other APEX features.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1358639364894715535)
,p_plug_name=>'How long does it take to develop an APEX PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(1360462725579227142)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>50
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    The time it takes to develop an APEX PWA will depend on a number',
'    of factors, but it should require minimal additional effort by',
'    Oracle APEX developers. Two declarative, app-level settings',
'    control whether your application will be installable by users as a',
'    PWA. When creating a new application, the wizard reduces the',
'    effort to a single click.',
'',
'</p>',
'<p>',
'',
'    Your project''s specific requirements influence the time required',
'    to develop an APEX PWA. A simple app with few pages and basic',
'    functionality could potentially be developed in a few days or',
'    weeks. In contrast, a more complex APEX PWA with advanced features',
'    and integrations could take longer to develop.',
'',
'</p>',
'<p>',
'',
'    For advanced scenarios, developers can fully customize the APEX',
'    PWA''s Web App Manifest and Service Worker. When a project''s',
'    requirements require this level of customization, it''s hard to',
'    estimate the time and effort required.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1358639486210715536)
,p_plug_name=>'Can my existing APEX app become a PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(1360462725579227142)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>70
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Yes, easily. First, make sure the <strong>Friendly URLs</strong> app',
'    setting is enabled.  Then ensure your application is served using',
'    HTTPS. Finally, switch on the two additional app-level',
'    settings <strong>Enable Progressive Web App</strong>',
'    and <strong>Installable</strong>.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1363438659741830497)
,p_plug_name=>'How do APEX PWAs use caching on a device?'
,p_parent_plug_id=>wwv_flow_imp.id(1360462725579227142)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>230
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    In an APEX PWA, certain resources are cached by default to improve',
'    the performance of the app.',
'',
'</p>',
'<p>',
'',
'    By default, APEX PWAs use a service worker to cache static',
'    resources, such as JavaScript and CSS files, as well as image and',
'    font files. These resources are stored in the browser''s cache and',
'    are available offline, which can help to improve the app''s',
'    performance and make it more resilient to network disruptions.',
'',
'</p>',
'<p>',
'',
'    However, not all resources are cached in an APEX PWA. Dynamic',
'    content, such as data retrieved from the database, is not cached',
'    by default. This means that if an app needs to access this type of',
'    content while offline, its developer needs to be familiar with',
'    JavaScript and implement their own mechanism using supported',
'    Service Worker hooks for storing and retrieving the data.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1363438880665830499)
,p_plug_name=>'Do users need to sign in every time they open my APEX PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(1360462725579227142)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>80
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    By default, users need to sign in every time they access an APEX',
'    application, and they stay authenticated for the duration of their',
'    app session. However, APEX provides several options for',
'    maintaining user sessions and allowing users to stay signed in,',
'    including the use of cookies, session state, and authentication',
'    schemes.',
'',
'</p>',
'<p>',
'',
'    After an instance administrator enables APEX''s persistent',
'    authentication feature, you can offer users the same native',
'    application launch experience they are familiar with from native',
'    desktop and mobile applications. Your APEX PWA users can tick',
'    a <strong>Remember me</strong> checkbox on their first login and',
'    stay logged in for a fixed period of time. By default a user''s',
'    authentication is remembered for 30 days, but you can configure',
'    that at the instance level.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1363439493881830505)
,p_plug_name=>'Can APEX PWAs use operating system resources?'
,p_parent_plug_id=>wwv_flow_imp.id(1360462725579227142)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>90
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Yes, in most of the ways that matter most to end users, but not',
'    all operating system resources are available. Since Oracle APEX',
'    PWAs are web-based applications, they are not built using the',
'    native programming languages of the device''s operating system. As',
'    a result, they do not have the same level of access to the',
'    device''s hardware and software as native apps.',
'',
'</p>',
'<p>',
'',
'    An APEX PWA can access the device''s camera, location, share sheet',
'    and storage using both declarative and programmatic APIs, as well',
'    as cache network requests. The specific resources and features',
'    available to an APEX PWA will depend on the capabilities of the',
'    device and the web browser being used to access the application.',
'',
'</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1370897570543870814)
,p_plug_name=>'Is it possible to have APEX Builder become a PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(1360462725579227142)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>240
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'  ',
'    Making the APEX Builder a seamless PWA desktop experience is on our',
'    roadmap. It implies creating a group of applications that will',
'    function as a single PWA.',
'',
'</p>',
'',
'<p>',
'  ',
'    APEX Builder consists of numerous apps and it makes sense to have them',
'    as a single PWA. Customers will also be able to define a multi app PWA',
'    ecosystem.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1361484418363238254)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16022627005005921124)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1370166657732372936)
,p_plug_name=>'Development Tips'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>260
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Development tips for APEX developers building PWAs</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1358638891230715530)
,p_plug_name=>'How do I develop an APEX PWA icon?'
,p_parent_plug_id=>wwv_flow_imp.id(1370166657732372936)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>110
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    You can choose one of the built-in icon and color combinations, or',
'    upload your own custom icon in PNG or JPG formats.',
'',
'</p>',
'<p>',
'',
'    You can also develop the icon using your favorite graphics program',
'    and should target 512x512 size for best results.  Once uploaded,',
'    APEX lets you optionally scale and crop the icon before it',
'    proceeds to save your app icon as shared application files. APEX',
'    will downsize and resize the icon to all appriopriate icon sizes',
'    it requires.',
'',
'</p>',
'<p>',
'',
'    APEX will generate the appropriate icon files and reference them',
'    automatically from all revelant places in your APEX app where the',
'    app icon needs to be displayed, such as the favicon, the PWA',
'    install icon, the login screen icon, etc.',
'',
'</p>',
'<p>',
'',
'    As of APEX 23.1, APEX will generate 5 files out of the original',
'    icon: 512x512, 256x256, 192x192, 144x144 and 32x32. Each of them',
'    are designed to fit a specific use case such that it looks',
'    great on all platforms.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1358638905542715531)
,p_plug_name=>'How can I customize the UI of my APEX PWA?'
,p_parent_plug_id=>wwv_flow_imp.id(1370166657732372936)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>130
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'  ',
'    You can customize the appearance of your APEX PWA by configuring',
'    the display mode, orientation, theme color, background color,',
'    status bar style (for iOS), as well as use application shortcuts,',
'    and custom manifest properties.',
'',
'</p>',
'',
'<p>',
'',
'    It''s a good idea to validate the responsive design behaviour of',
'    your APEX PWA application through adequate testing on different',
'    devices or simulators.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1363439590235830506)
,p_plug_name=>'Can my APEX PWA use geolocation?'
,p_parent_plug_id=>wwv_flow_imp.id(1370166657732372936)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>100
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Yes, it is possible for an APEX PWA to access and use geolocation',
'    information. Geolocation refers to the location of a device or',
'    user, typically determined using GPS or other location-based',
'    technologies.',
'',
'</p>',
'<p>',
'',
'    In an APEX PWA, you can declaratively acquire location, speed,',
'    direction, and altitude using the <strong>Get Current',
'    Position</strong> dynamic action (subject to the user''s granting',
'    permission). Your app can also declaratively geolocate any other',
'    address on the planet using built-in features. Your APEX PWA can',
'    take full advantage of APEX''s data-savvy map region to visualize',
'    location-based data on mobile devices, too.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1363439754093830508)
,p_plug_name=>'Can my APEX PWA detect the device I''m on?'
,p_parent_plug_id=>wwv_flow_imp.id(1370166657732372936)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>210
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    APEX provides various JavaScript APIs to identify the current mode',
'    in which the PWA is accessed. For example this function is used to',
'    determine if the application is currently accessed through the PWA',
'    application (eg. in fullscreen) or through the browser',
'    normally. Possible values',
'    are: <strong>fullscreen</strong>, <strong>standalone</strong>, <strong>minimal-ui</strong>,',
'    and <strong>browser</strong>.',
'',
'</p>',
'',
'<pre><code>const displayMode = apex.pwa.getDisplayMode();</code></pre>',
'',
'<p>',
'',
'    Otherwise, it can be done using JavaScript and',
'    the <code>navigator.userAgent</code> property, which returns a',
'    string containing information about the device''s user agent,',
'    however this is not recommended as user agents can change without',
'    prior notice.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1370897436130870813)
,p_plug_name=>'Is there any way to avoid the splash screen when opening the app after some idle time?'
,p_parent_plug_id=>wwv_flow_imp.id(1370166657732372936)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>220
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Like most PWA features, each browser can behave differently. As for',
'    iOS on APEX 23.1, there is currently no declarative way of defining',
'    a splash screen while the app loads. However, it can be done by',
'    adding a new link tag on the page manually ',
'    ',
'</p>',
'',
'<pre><code>&lt;link rel="apple-touch-startup-image" href="#APP_FILES#ios-startup.png"&gt;</code></pre>',
'',
'<p>',
'',
'    We should look into making this declarative in future APEX releases.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1370166729583372937)
,p_plug_name=>'Business'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>270
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Questions that could influence a business decision to use PWA or not</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1358638729309715529)
,p_plug_name=>'What apps are best for PWA and which ones are not recommended?'
,p_parent_plug_id=>wwv_flow_imp.id(1370166729583372937)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    PWAs are well-suited for a wide range of applications, letting',
'    users quickly launch and use nearly any kind of data-centric',
'    application on smartphones, tablets, and desktop or laptop',
'    computers. This includes the vast majority of typical Oracle APEX',
'    applications, including:',
'',
'</p>',
'',
'<ul>',
'  <li>',
'',
'    Tracking, planning, productivity, and process automation apps with',
'    compelling data-driven visualizations, reporting, and data entry,',
'',
'  </li>',
'  <li>',
'',
'    E-commerce apps with a seamless shopping experience for quickly',
'    finding and buying goods and services,',
'',
'  </li>',
'  <li>',
'',
'    Social networking apps to interact with peers to ask questions,',
'    get answers, or exchange thoughts using text and media,',
'',
'  </li>',
'  <li>',
'',
'    News and media apps to abreast of a fast-changing world',
'',
'  </li>',
'</ul>',
'',
'<p>',
'',
'    While additional PWA features like offline support and push',
'    notifications require JavaScript skills to achieve with Oracle',
'    APEX today, they are possible to accomplish using supported APEX',
'    Service Worker hooks. This means that any of the APEX PWA',
'    applications above can be made to support these features to keep',
'    users working when connectivity is not reliable and keep them',
'    engaged through targeted app-specific alerts on their device.',
'  ',
'</p>',
'',
'<p>',
'',
'    However, not all apps are well-suited for PWA development. For',
'    example, apps that require complex graphics rendering or real-time',
'    data processing may not be suitable. ',
'',
'</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1363438796313830498)
,p_plug_name=>'Can my PWA be installed from Google Play or App Store?'
,p_parent_plug_id=>wwv_flow_imp.id(1370166729583372937)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>30
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    PWAs can be published to the Google Play Store and Apple App',
'    Store, but the process for doing so is different from the process',
'    for publishing a traditional native app.',
'',
'</p>',
'<p>',
'',
'    To publish a PWA to the Google Play Store, you will need to follow',
'    the steps outlined in the Google Play Console documentation. This',
'    process involves creating a new listing for your PWA in the Google',
'    Play Store, uploading your PWA''s web manifest and other required',
'    assets, and setting up a distribution channel for your PWA. Once',
'    the steps are completed, it will be made available in the Google',
'    Play Store for users to download and install on their devices.',
'',
'</p>',
'<p>',
'',
'    To publish a PWA to the Apple App Store, you will need to follow',
'    the steps outlined in the App Store Connect documentation. This',
'    process involves creating a new listing for your PWA in the App',
'    Store, wrapping your PWA in Swift as a Webview. Once your PWA has',
'    been reviewed and approved by Apple, it will be made available in',
'    the App Store for users to download and install on their devices.',
'',
'</p>',
'<p>',
'',
'    There are publishing costs to both stores.',
'',
'</p>',
'<p>',
'',
'    We plan to make this integration process easier in the future,',
'    hopefully with some steps automated within the APEX Builder.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1363439037859830501)
,p_plug_name=>'Can my APEX PWA support payment methods?'
,p_parent_plug_id=>wwv_flow_imp.id(1370166729583372937)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>40
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    It is possible for APEX PWAs to support payment, but it requires',
'    some manual coding. A JavaScript developer on your team would use',
'    the APEX custom service worker to call the Web Payment API, a',
'    browser-based standard for handling payments on the web. It allows',
'    users to make payments using a variety of payment methods,',
'    including credit cards, debit cards, and digital wallets. The Web',
'    Payment API can be used to implement payment support in a PWA.',
'',
'</p>',
'',
'<p>',
'',
'    The <strong>canmakepayment</strong> event of the service worker',
'    interface is fired when the client requests the authorization',
'    status of the Payment Handler API. It can be used to check if the',
'    browser supports at least one payment method. More info:',
'',
'</p>',
'',
'<ul>',
'    <li><a rel="noopener noreferrer" href="https://developer.mozilla.org/en-US/docs/Web/API/Payment_Request_API/Using_the_Payment_Request_API">https://developer.mozilla.org/en-US/docs/Web/API/Payment_Request_API/Using_the_Payment_Request_API</a></li>',
'    <li><a rel="noopener noreferrer" href="https://web.dev/web-payments-updates">https://web.dev/web-payments-updates</a>/</li>',
'    <li><a rel="noopener noreferrer" href="https://www.w3.org/TR/payment-handler/#handling-a-canmakepaymentevent">https://www.w3.org/TR/payment-handler/#handling-a-canmakepaymentevent</a></li>',
'</ul>',
'',
'<p>',
'',
'    The <strong>paymentrequest</strong> event of the service worker',
'    interface is fired when client chooses to pay with a web-based',
'    payment app. It can be used to initiate a payment on a web app,',
'    using payment methods such as Google Pay. More info:',
'',
'</p>',
'',
'<ul>',
'    <li><a rel="noopener noreferrer" href="https://web.dev/how-payment-request-api-works/">https://web.dev/how-payment-request-api-works/</a></li>',
'    <li><a rel="noopener noreferrer" href="https://web.dev/orchestrating-payment-transactions/">https://web.dev/orchestrating-payment-transactions/</a></li>',
'</ul>',
'',
'<p>',
'',
'    Implementing payment support in a PWA requires careful consideration',
'    of security and compliance issues. You should follow best',
'    practices to ensure that sensitive payment information is handled',
'    securely, and comply with relevant regulations and standards.',
'',
'</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1363439365081830504)
,p_plug_name=>'Is it possible to use my APEX PWA offline?'
,p_parent_plug_id=>wwv_flow_imp.id(1370166729583372937)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>50
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    The short answer is: not easily. APEX does provide a user friendly',
'    offline fallback page when there is no connection to the internet,',
'    however. You can easily customize this fallback page in a',
'    declarative way.',
'',
'</p>',
'<p>',
'',
'    For advanced users, it is technically possible to enable offline',
'    support for an APEX PWA. This entails using the custom Service',
'    Worker feature, which allows APEX applications to intercept',
'    network requests and serve cached responses when the device is',
'    offline.',
'',
'</p>',
'<p>',
'',
'    Within the service worker hooks, the <strong>fetch</strong> event',
'    is reponsible for intercepting network requests. It can be',
'    extended to cache complete pages, specific resources and',
'    requests. When offline, the service worker would be responsible',
'    for fetching the cached resources instead of going to the network.',
'',
'</p>',
'<p>',
'',
'    It is not trivial to make an APEX PWA app work offline in a',
'    generic way that would allow arbitrary searching, creation, and',
'    modification of the rich application data model that exists behind',
'    the typical APEX application.  We hope APEX can provide easier',
'    mechanisms to enable basic offline features in future releases of',
'    APEX.',
'</p>',
'<p>',
'',
'    Until then, developers can venture into the custom service worker',
'    hooks to enable specific application use cases. In doing so, these',
'    more advanced APEX developers can help the Oracle APEX community',
'    and development team better understand the most common offline',
'    data access patterns that surface in your applications. This',
'    information will help us narrow the focus on delivering',
'    incremental offline data capabilities into future Oracle APEX',
'    versions. You can do this by logging new ideas for targeted',
'    offline capabilities based on your experiences',
'    at <a target="_blank"',
'    href="https://apex.oracle.com/ideas">apex.oracle.com/ideas</a>.',
'',
'</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1363439611272830507)
,p_plug_name=>'Can I track how many times my PWA was installed?'
,p_parent_plug_id=>wwv_flow_imp.id(1370166729583372937)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    As of APEX 23.1 this is not possible, but it is on our Roadmap. We',
'    are always careful when it comes to telemetry of direct user',
'    interaction, therefore APEX should provide a solution that is',
'    non-intrusive to users.',
'',
'</p>',
'',
'<p>',
'',
'    As an alternative today, workspace admins can track how many apps',
'    were developed as a PWA along with the different PWA attributes.',
'',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
