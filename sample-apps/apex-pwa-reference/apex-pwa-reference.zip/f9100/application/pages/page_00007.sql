prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>14776237248443586610
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Installation'
,p_alias=>'INSTALLATION'
,p_step_title=>'Installation - &APP_NAME.'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'11'
,p_last_upd_yyyymmddhh24miss=>'20221220175426'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(639570154227457332)
,p_plug_name=>'Advanced'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>1050
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    Add screenshots and an app description to enhance the user installation experience of your APEX PWA.',
'</p>',
'',
'<p>',
'    Manage them from the APEX Builder Progressive Web App attributes page.',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_landmark_label=>'Advanced'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3018617095682313839)
,p_plug_name=>'PWA Description container'
,p_parent_plug_id=>wwv_flow_imp.id(639570154227457332)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15414417723667979070)
,p_plug_display_sequence=>1030
,p_plug_item_display_point=>'BELOW'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15713961540781266692)
,p_plug_name=>'Edit Description'
,p_parent_plug_id=>wwv_flow_imp.id(3018617095682313839)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15713961609966266693)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(15713961540781266692)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(15414453872237979099)
,p_plug_display_sequence=>10
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_FILES#img/manage-pwa-description.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15713961733432266694)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(3018617095682313839)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>',
'        In <strong>App Builder</strong> go to <strong>Shared Components</strong>',
'    </li>',
'    <li>',
'        Go to <strong>Progressive Web App</strong>',
'    </li>',
'    <li>',
'        Turn on <strong>Enable Progressive Web App</strong> and <strong>Installable</strong>',
'    </li>',
'    <li>',
'        In app description, enter a description of the PWA',
'    </li>',
'    <li>',
'        Save PWA attributes',
'    </li>',
'    <li>',
'        Your PWA description will be displayed to users when they install your app',
'    </li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_landmark_label=>'Instructions PWA Description'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17447755001080639982)
,p_plug_name=>'PWA Screenshots container'
,p_parent_plug_id=>wwv_flow_imp.id(639570154227457332)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15414417723667979070)
,p_plug_display_sequence=>1020
,p_plug_item_display_point=>'BELOW'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3018615719168313209)
,p_plug_name=>'Managing Screenshots'
,p_parent_plug_id=>wwv_flow_imp.id(17447755001080639982)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15713960184248266062)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(3018615719168313209)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(15414453872237979099)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_FILES#img/manage-pwa-screenshots.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3018615918148313211)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(17447755001080639982)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>',
'        In the <strong>App Builder</strong> go to <strong>Shared Components</strong>',
'    </li>',
'    <li>',
'        Go to <strong>Progressive Web App</strong>',
'    </li>',
'    <li>',
'        Turn on <strong>Enable Progressive Web App</strong> and <strong>Installable</strong>',
'    </li>',
'    <li>',
'        Click <strong>Add Screenshot</strong> button',
'    </li>',
'    <li>',
'        Type a description for the screenshot',
'    </li>',
'    <li>',
'        Upload your <strong>Screenshot</strong> file',
'    </li>',
'    <li>',
'        Click <strong>Create</strong>',
'    </li>',
'    <li>',
'        The screenshot will be shown to users when installing the PWA',
'    </li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_landmark_label=>'Instructions PWA Screenshots'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15713960293810265227)
,p_plug_name=>'Compatibility'
,p_parent_plug_id=>wwv_flow_imp.id(17447755001080639982)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'&OS_BROWSER_SUPPORT_TABLE_LABEL_PLURAL.',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc dm-Report--grid">',
'    <thead>',
'        <tr>',
'            <td class="display-hidden"></td>',
'            <th class="u-tL">Chrome</th>',
'            <th class="u-tL">Edge</th>',
'            <th class="u-tL">Firefox</th>',
'            <th class="u-tL">Safari</th>',
'        </tr>',
'    </thead>',
'    <tbody>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Android</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>iOS</span></th>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'            <td class="display-visible">Yes</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>macOS</span></th>',
'            <td class="display-not">No</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Windows</span></th>',
'            <td class="display-not">No</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'    </tbody>',
'</table>',
'',
'<p class="margin-top-md"><em>Last updated: November 2022</em></p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1391636139439739821)
,p_plug_name=>'Examples'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>1040
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_landmark_label=>'PWA Screenshots Example'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15415806899086043937)
,p_plug_name=>'Android container'
,p_parent_plug_id=>wwv_flow_imp.id(1391636139439739821)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15414417723667979070)
,p_plug_display_sequence=>80
,p_plug_grid_column_span=>12
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2266551751898032066)
,p_plug_name=>'Android'
,p_parent_plug_id=>wwv_flow_imp.id(15415806899086043937)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_landmark_label=>'Example Android Installation'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2266551969080032068)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(2266551751898032066)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(15414453872237979099)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>3
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_FILES#img/promotion-android.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14961901380108984971)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(2266551751898032066)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(15414453872237979099)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_FILES#img/installed-android.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2266551863702032067)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(15415806899086043937)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>',
'        Run your application',
'    </li>',
'    <li>',
'        In the top navigation bar, tap the <strong>Install App</strong> entry',
'        <ul>',
'            <li style="list-style-type: none;">',
'                If this does not appear, either PWA requirements are not met',
'                or the current device and browser does not support installing a PWA',
'            </li>',
'        </ul>',
'    <li>',
'        Tap <strong>Install</strong> on the confirmation box',
'    </li>',
'    <li>',
'        Your APEX app is now installed on your Android device and appears on a page of the home screen',
'    </li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_landmark_label=>'Instructions Android Installation'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16086768406699576208)
,p_plug_name=>'Desktop container'
,p_parent_plug_id=>wwv_flow_imp.id(1391636139439739821)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15414417723667979070)
,p_plug_display_sequence=>60
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="col-8">',
'    Both Windows and macOS offer a similar, automatic PWA installation experience.',
'</p>',
'',
'<p class="col-8">',
'    Supported browsers display an install icon in the URL bar to indicate the APEX app is installable.',
'    APEX also offers an in-app navigation bar entry to start the installation process.',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15415807132359043939)
,p_plug_name=>'Desktop'
,p_parent_plug_id=>wwv_flow_imp.id(16086768406699576208)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_landmark_label=>'Example Desktop Installation'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15415807006552043938)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(15415807132359043939)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(15414453872237979099)
,p_plug_display_sequence=>20
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_FILES#img/desktop-install1.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16086768000249576204)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(16086768406699576208)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>',
'        Run your application',
'    </li>',
'    <li>',
'        In the top navigation bar, click the <strong>Install App</strong> entry',
'        <ul>',
'            <li style="list-style-type: none;">',
'                If it does not appear, either PWA requirements are not met',
'                or the current device and browser does not support installing a PWA',
'            </li>',
'        </ul>',
'    <li>',
'        Click <strong>Install</strong> on the confirmation box',
'    </li>',
'    <li>',
'        Your APEX app is now installed on your desktop, appears in the app launcher, and can be pinned to the dock',
'    </li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_landmark_label=>'Instructions Desktop Installation'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16086768636111576210)
,p_plug_name=>'iOS container'
,p_parent_plug_id=>wwv_flow_imp.id(1391636139439739821)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15414417723667979070)
,p_plug_display_sequence=>70
,p_plug_grid_column_span=>12
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2266551459367032063)
,p_plug_name=>'iOS (or iPad OS)'
,p_parent_plug_id=>wwv_flow_imp.id(16086768636111576210)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_landmark_label=>'Example iOS Installation'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2266551537992032064)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(2266551459367032063)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(15414453872237979099)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>3
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_FILES#img/promotion-ios.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14961901205441984970)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(2266551459367032063)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(15414453872237979099)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_FILES#img/installed-ios.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2266551613491032065)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(16086768636111576210)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>',
'        Run your application',
'    </li>',
'    <li>',
'        In the top navigation bar, tap the <strong>Install App</strong> entry',
'        <ul>',
'            <li style="list-style-type: none;">',
'                If this does not appear, either PWA requirements are not met',
'                or the current device and browser does not support installing a PWA',
'            </li>',
'        </ul>',
'    <li>',
'        Tap <strong>Next</strong>',
'    </li>',
'    <li>',
'        Follow the simple iOS instructions',
'    </li>',
'    <li>',
'        Your APEX app is now installed on your iOS device and appears on a page of the home screen',
'    </li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_landmark_label=>'Instructions iOS Installation'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15415806776487043936)
,p_plug_name=>'Compatibility'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    PWA support differs by device and browser as shown in this table',
'    of combinations that APEX officially supports.',
'</p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc dm-Report--grid">',
'    <thead>',
'        <tr>',
'            <td class="display-hidden"></td>',
'            <th class="u-tL">Chrome</th>',
'            <th class="u-tL">Edge</th>',
'            <th class="u-tL">Firefox</th>',
'            <th class="u-tL">Safari</th>',
'        </tr>',
'    </thead>',
'    <tbody>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Android</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>iOS</span></th>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'            <td class="display-visible">Yes</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>macOS</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Windows</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'    </tbody>',
'</table>',
'',
'<p class="margin-top-md"><em>Last updated: November 2022</em></p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15430818999167004321)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15414417723667979070)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_landmark_type=>'navigation'
,p_landmark_label=>'Region Display Selector'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15445815920550612162)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15414496134625979135)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(15414381005396979030)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(15414558240090979203)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16085179884654797904)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    Installed APEX apps are deeply integrated with the operating system and easily accessible.',
'</p>',
'',
'<p>',
'    When users install your APEX PWA, they can open your app using an icon on their home screen,',
'    browse your app in full screen as a standalone window separate from the browser,',
'    and search for your app on their device.',
'</p>',
'',
'<p>',
'    To promote your PWA to the broadest audience possible, APEX provides a simple, user-friendly',
'    PWA install experience so users are encouraged to proceed with the installation of your app.',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
