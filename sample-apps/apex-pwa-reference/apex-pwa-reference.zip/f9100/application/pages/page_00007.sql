prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>1580934860364765
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Installation'
,p_alias=>'INSTALLATION'
,p_step_title=>'Installation - &APP_NAME.'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1247816153836399426)
,p_plug_name=>'Advanced'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>1050
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="col-8">',
'    The PWA installation experience can be enhanced with additional meaningful content ',
'    such as app screenshots and app description. ',
'    They add to the installation prompt visuals, reminding users of typical application stores UI.',
'    App screenshots should serve as a preview of the content of the application, to incentivize users',
'    to install the app and experience it for themselves.',
'    Manage screenshots and description from the APEX Builder Progressive Web App attributes page.',
'</p>'))
,p_landmark_label=>'Advanced'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3626863095291255933)
,p_plug_name=>'PWA Description container'
,p_parent_plug_id=>wwv_flow_imp.id(1247816153836399426)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>1030
,p_plug_item_display_point=>'BELOW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16322207540390208786)
,p_plug_name=>'Edit Description'
,p_parent_plug_id=>wwv_flow_imp.id(3626863095291255933)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16322207609575208787)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(16322207540390208786)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>10
,p_plug_grid_column_css_classes=>'padding-none'
,p_region_image=>'#APP_FILES#img/edit-description.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16322207733041208788)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(3626863095291255933)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>',
'        In <strong>App Builder</strong> go to <strong>Shared Components</strong>',
'    </li>',
'    <li>',
'        Go to <strong>Progressive Web App</strong>',
'    </li>',
'    <li>',
'        Turn on <strong>Enable Progressive Web App</strong> and <strong>Installable</strong>',
'    </li>',
'    <li>',
'        In <strong>App Description</strong>, enter a short description for the application',
'    </li>',
'    <li>',
'        Click <strong>Apply Changes</strong>',
'    </li>',
'    <li>',
'        The app description will be displayed to users when they install your PWA',
'    </li>',
'</ol>'))
,p_landmark_label=>'Instructions PWA Description'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18056001000689582076)
,p_plug_name=>'PWA Screenshots container'
,p_parent_plug_id=>wwv_flow_imp.id(1247816153836399426)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>1020
,p_plug_item_display_point=>'BELOW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3626861718777255303)
,p_plug_name=>'Managing Screenshots'
,p_parent_plug_id=>wwv_flow_imp.id(18056001000689582076)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16322206183857208156)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(3626861718777255303)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>10
,p_plug_grid_column_css_classes=>'padding-none'
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/edit-screenshots.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3626861917757255305)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(18056001000689582076)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>',
'        In the <strong>App Builder</strong> go to <strong>Shared Components</strong>',
'    </li>',
'    <li>',
'        Go to <strong>Progressive Web App</strong>',
'    </li>',
'    <li>',
'        Turn on <strong>Enable Progressive Web App</strong> and <strong>Installable</strong>',
'    </li>',
'    <li>',
'        Click <strong>Add Screenshot</strong> button',
'    </li>',
'    <li>',
'        Type a description for the screenshot',
'    </li>',
'    <li>',
'        Upload your <strong>Screenshot</strong> file',
'    </li>',
'    <li>',
'        Click <strong>Create</strong>',
'    </li>',
'    <li>',
'        The screenshot will be displayed to users when installing the PWA',
'    </li>',
'</ol>'))
,p_landmark_label=>'Instructions PWA Screenshots'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16322206293419207321)
,p_plug_name=>'Compatibility'
,p_parent_plug_id=>wwv_flow_imp.id(18056001000689582076)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This table shows the supported combinations of operating systems and browsers for the PWA Screenshots feature.</p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc dm-Report--grid">',
'    <thead>',
'        <tr>',
'            <td class="display-hidden"></td>',
'            <th class="u-tL">Chrome</th>',
'            <th class="u-tL">Edge</th>',
'            <th class="u-tL">Firefox</th>',
'            <th class="u-tL">Safari</th>',
'        </tr>',
'    </thead>',
'    <tbody>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Android</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>iOS</span></th>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'            <td class="display-visible">Yes</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>macOS</span></th>',
'            <td class="display-not">No</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Windows</span></th>',
'            <td class="display-not">No</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'    </tbody>',
'</table>',
'',
'<p class="margin-top-md"><em>Last updated: April 2023</em></p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1999882139048681915)
,p_plug_name=>'Examples'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>1040
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="col-8">',
'    All devices, from desktop to mobile, offer a tailored web app installation experience. ',
'    See examples below for a preview of the feature.',
'</p>',
'',
'<p class="col-8">',
'    Desktop users can find the <strong><span class="t-Icon fa fa-cloud-download" aria-hidden="true"></span> Install App</strong> button in the navigation bar to trigger the installation process. ',
'    Mobile users can find the same button, except it will display as only an icon.',
'</p>'))
,p_landmark_label=>'PWA Screenshots Example'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16024052898694986031)
,p_plug_name=>'Android container'
,p_parent_plug_id=>wwv_flow_imp.id(1999882139048681915)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>80
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2874797751506974160)
,p_plug_name=>'Installing an APEX PWA on Android'
,p_parent_plug_id=>wwv_flow_imp.id(16024052898694986031)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_landmark_label=>'Example Android Installation'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(669284579549639944)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(2874797751506974160)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'padding-none'
,p_region_image=>'#APP_FILES#img/installing-android3.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1065992888749268995)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(2874797751506974160)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'padding-none'
,p_region_image=>'#APP_FILES#img/installing-android4.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2874797968688974162)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(2874797751506974160)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>10
,p_plug_grid_column_css_classes=>'padding-none'
,p_region_image=>'#APP_FILES#img/installing-android1.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15570147379717927065)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(2874797751506974160)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'padding-none'
,p_region_image=>'#APP_FILES#img/installing-android2.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2874797863310974161)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(16024052898694986031)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>',
'        Run your application',
'    </li>',
'    <li>',
'        In the top navigation bar, tap the <span class="t-Icon fa fa-cloud-download"></span> icon',
'    <li>',
'        Tap <strong>Install</strong> on the confirmation box',
'    </li>',
'    <li>',
'        Your APEX app is now installed on your Android device and appears on the home screen',
'    </li>',
'</ol>'))
,p_landmark_label=>'Instructions Android Installation'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16695014406308518302)
,p_plug_name=>'Desktop container'
,p_parent_plug_id=>wwv_flow_imp.id(1999882139048681915)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>60
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16024053131967986033)
,p_plug_name=>'Installing an APEX PWA on Desktop'
,p_parent_plug_id=>wwv_flow_imp.id(16695014406308518302)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_landmark_label=>'Example Desktop Installation'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(669284473019639943)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(16024053131967986033)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_region_image=>'#APP_FILES#img/install-macos2.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16024053006160986032)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(16024053131967986033)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>20
,p_region_image=>'#APP_FILES#img/install-macos1.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16695013999858518298)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(16695014406308518302)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>',
'        Run your application',
'    </li>',
'    <li>',
'        In the top navigation bar, click the <strong>Install App</strong> entry',
'    <li>',
'        Click <strong>Install</strong> on the confirmation box',
'    </li>',
'    <li>',
'        Your APEX app is now installed on your desktop, appears in the app launcher, and can be pinned to the dock',
'    </li>',
'</ol>'))
,p_landmark_label=>'Instructions Desktop Installation'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16695014635720518304)
,p_plug_name=>'iOS container'
,p_parent_plug_id=>wwv_flow_imp.id(1999882139048681915)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>70
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2874797458975974157)
,p_plug_name=>'Installing an APEX PWA on iOS'
,p_parent_plug_id=>wwv_flow_imp.id(16695014635720518304)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_landmark_label=>'Example iOS Installation'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(669284122179639940)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(2874797458975974157)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'padding-none'
,p_region_image=>'#APP_FILES#img/installing-ios3.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(669284263519639941)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(2874797458975974157)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'padding-none'
,p_region_image=>'#APP_FILES#img/installing-ios4.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2874797537600974158)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(2874797458975974157)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>10
,p_plug_grid_column_css_classes=>'padding-none'
,p_region_image=>'#APP_FILES#img/installing-ios1.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15570147205050927064)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(2874797458975974157)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'padding-none'
,p_region_image=>'#APP_FILES#img/installing-ios2.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2874797613099974159)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(16695014635720518304)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>',
'        Run your application',
'    </li>',
'    <li>',
'        In the top navigation bar, tap the <span class="t-Icon fa fa-cloud-download"></span> icon',
'    <li>',
'        Tap <strong>Next</strong>',
'    </li>',
'    <li>',
'        Follow the simple instructions',
'    </li>',
'    <li>',
'        Your APEX app is now installed on your iOS device and appears on the home screen',
'    </li>',
'</ol>'))
,p_landmark_label=>'Instructions iOS Installation'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16024052776095986030)
,p_plug_name=>'Compatibility'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    This table shows the supported combinations of operating systems and',
'    browsers for the PWA installation feature.',
'',
'</p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc dm-Report--grid">',
'    <thead>',
'        <tr>',
'            <td class="display-hidden"></td>',
'            <th class="u-tL">Chrome</th>',
'            <th class="u-tL">Edge</th>',
'            <th class="u-tL">Firefox</th>',
'            <th class="u-tL">Safari</th>',
'        </tr>',
'    </thead>',
'    <tbody>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Android</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>iOS</span></th>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'            <td class="display-visible">Yes</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>macOS</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Windows</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'    </tbody>',
'</table>',
'',
'<p class="margin-top-md"><em>Last updated: April 2023</em></p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16039064998775946415)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_landmark_type=>'navigation'
,p_landmark_label=>'Region Display Selector'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16054061920159554256)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16022627005005921124)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16693425884263739998)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    APEX PWAs allow any APEX application to be installed on any device, ',
'    creating a deep integration with the operating system and providing remarkable accessibility.',
'</p>',
'',
'<p>',
'    An APEX PWA is the most convenient gateway to your app: users can launch it using a home screen icon, ',
'    enjoy a full-screen experience in a dedicated window, and effortlessly locate it on their device. ',
'    To attract the widest audience, APEX delivers a smooth, user-friendly installation process, ',
'    encouraging users to intuitively adopt your app.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
