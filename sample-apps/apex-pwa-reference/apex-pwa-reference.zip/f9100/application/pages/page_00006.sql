prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>606665064748577329
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Getting Started'
,p_alias=>'GETTING-STARTED'
,p_step_title=>'Getting Started - &APP_NAME.'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'11'
,p_last_updated_by=>'LEORODRI'
,p_last_upd_yyyymmddhh24miss=>'20230425161352'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16021282835000031867)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16021082788416556399)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_landmark_type=>'navigation'
,p_landmark_label=>'Region Display Selector'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'NO'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16021283493309031873)
,p_plug_name=>'Requirements'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="col-8">For your APEX PWA application to be installable, it must:</p>',
'<ul>',
'    <li>Enable <strong>Friendly URLs</strong></li>    ',
'    <li>Use <strong>HTTPS</strong></li>',
'</ul>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16022230635785019870)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16021161199374556464)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16021046070145556359)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16021223304839556532)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16022871363615810171)
,p_plug_name=>'Existing Application'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="col-8">',
'',
'    To activate PWA functionality for your existing APEX application, you can',
'    enable two options located in the "General" section of the Progressive Web',
'    App settings page. By switching on these options, you can make your app',
'    installable on user''s devices, and provide them with a more native app-like',
'    experience',
'',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16022471475409621261)
,p_plug_name=>'Example'
,p_parent_plug_id=>wwv_flow_imp.id(16022871363615810171)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>90
,p_plug_grid_column_span=>8
,p_landmark_label=>'Example Edit a PWA'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16022471658705621263)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(16022471475409621261)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>20
,p_region_image=>'#APP_FILES#img/edit-pwa.jpeg'
,p_region_image_alt_text=>'Editing an APEX PWA'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16022471551097621262)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(16022871363615810171)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>100
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>Edit your application</li>',
'    <li>Go to <strong>Shared Components</strong></li>',
'    <li>Go to <strong>Progressive Web App</strong></li>',
'    <li>Under General, enable <strong>Progressive Web App</strong> switch',
'        <ul>',
'            <li style="list-style-type: none;">',
'               This adds a default service worker to your application',
'            </li>',
'        </ul>',
'    </li>',
'    <li>Under General, enable <strong>Installable</strong> switch',
'        <ul>',
'            <li style="list-style-type: none;">',
'              This adds a default web app manifest to your application,',
'              and a new <strong>Install App</strong> navigation bar entry',
'              users can click to install the app',
'            </li>',
'        </ul> ',
'    </li>',
'    <li>(Optional) Configure PWA attributes</li>',
'</ol>'))
,p_landmark_label=>'Instructions Edit a PWA'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16660617636060955953)
,p_plug_name=>'New Application'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="col-8">',
'',
'    To take advantage of PWA capabilities when developing your APEX application,',
'    simply select the <strong>Install Progressive Web App</strong> feature when',
'    creating a new application.',
'',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16022871228265810170)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(16660617636060955953)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>In <strong>App Builder</strong>, click <strong>Create</strong></li>',
'    <li>Select <strong>New Application</strong></li>',
'    <li>Fill the required fields for creating a new application</li>',
'    <li>Under Features, select <strong>Install Progressive Web App</strong> checkbox</li>',
'    <li>Click <strong>Create Application</strong></li>',
'</ol>'))
,p_landmark_label=>'Instructions Create a PWA'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16105631895048576042)
,p_plug_name=>'Example'
,p_parent_plug_id=>wwv_flow_imp.id(16660617636060955953)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_landmark_label=>'Example Create a PWA'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16105631651551576040)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(16105631895048576042)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>10
,p_region_image=>'#APP_FILES#img/create-pwa.jpeg'
,p_region_image_alt_text=>'Creating a new APEX PWA'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
