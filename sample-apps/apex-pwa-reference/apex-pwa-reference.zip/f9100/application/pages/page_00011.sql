prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>14776237248443586610
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Offline Fallback'
,p_alias=>'OFFLINE-FALLBACK'
,p_step_title=>'Offline Fallback - &APP_NAME.'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.image-wrap {',
'    display: flex;',
'    flex-flow: column;',
'}',
'',
'.img-installer-mobile {',
'    width: 100%;',
'    border-radius: 5px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'11'
,p_last_upd_yyyymmddhh24miss=>'20221220175426'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15430820244828004333)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15414417723667979070)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_landmark_type=>'navigation'
,p_landmark_label=>'Region Display Selector'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15430820306933004334)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="col-8">The Offline Fallback page is displayed when the user performs an action that requires a connection but the device is offline.</p>',
'',
'<p class="col-8">You can add an offline fallback page to your PWA and customize it to suit your needs.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15430820840017004339)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(15430820306933004334)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>In the <strong>App Builder</strong> go to <strong>Share Components</strong></li>',
'    <li>Under <strong>Globalization</strong> click <strong>Text Messages</strong></li>',
'    <li>Click button <strong>Create Text message</strong></li>',
'    <li>Create messages <strong>APEX.PWA.OFFLINE.TITLE</strong> and <strong>APEX.PWA.OFFLINE.BODY</strong></li>',
'    <li>Add some the content to be rendered on the offline fallback page</li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_landmark_label=>'Offline Fallback Instructions'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16121534910439096579)
,p_plug_name=>'Offline Preview'
,p_parent_plug_id=>wwv_flow_imp.id(15430820306933004334)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(15414446093797979093)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16807583316741699136)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(16121534910439096579)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(15414453872237979099)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_FILES#img/offline.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15458775875784924243)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15414496134625979135)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(15414381005396979030)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(15414558240090979203)
);
wwv_flow_imp.component_end;
end;
/
