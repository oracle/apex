prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>606665064748577329
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'App Icon'
,p_alias=>'APP-ICON'
,p_step_title=>'App Icon - &APP_NAME.'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Comments-instructions {',
'    margin: 24px 0px 0px 0px;',
'    text-align: center;',
'    font-weight: bold;',
'}',
'',
'.image-wrap {',
'    display: flex;',
'    flex-flow: column;',
'}',
'',
'.img-installer {',
'    width: 100%;',
'    border-radius: 5px;',
'}',
'',
'.img-installer-mobile {',
'    width: 100%;',
'    border-radius: 5px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'11'
,p_last_updated_by=>'VMORNEAU'
,p_last_upd_yyyymmddhh24miss=>'20230426134815'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1246235104935034660)
,p_plug_name=>'Examples'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_landmark_label=>'PWA Shorcuts Examples'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1246235786915034667)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(1246235104935034660)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>Install APEX PWA on a Desktop device</li>',
'    <li>Locate app icon in task bar</li>',
'    <li>Right click app icon</li>',
'    <li>See PWA shortcuts</li>',
'</ol>'))
,p_landmark_label=>'PWA Shortcuts Instructions'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1246235884627034668)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(1246235104935034660)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>Install APEX PWA on an Android device</li>',
'    <li>Locate app icon in the home screen</li>',
'    <li>Long-press on app icon</li>',
'    <li>See PWA shortcuts</li>',
'</ol>'))
,p_landmark_label=>'PWA Shortcuts Instructions'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16037483749265581647)
,p_plug_name=>'PWA Shortcuts on macOS'
,p_parent_plug_id=>wwv_flow_imp.id(1246235104935034660)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>40
,p_plug_grid_column_span=>8
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568562070592562257)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(16037483749265581647)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/shortcuts-macos.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16037483832897581648)
,p_plug_name=>'PWA Shortcuts on Android'
,p_parent_plug_id=>wwv_flow_imp.id(1246235104935034660)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>60
,p_plug_grid_column_span=>8
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568562160180562258)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(16037483832897581648)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/shortcuts-android.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1246235330505034662)
,p_plug_name=>'App Icon'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="col-8">',
'',
'    Every APEX application comes with an icon that you can customize to',
'    give your app a unique look and feel. You can either choose an icon',
'    from a list of options provided or upload your own icon for a more',
'    personalized experience. The app icon serves as the PWA icon, appears',
'    on the application login page, favicon, and builder app icon.',
'',
'</p>',
'',
'<p class="col-8">',
'',
'    To ensure that your PWA icon looks great on all devices, APEX generates',
'    five different icon formats when you upload a file: 32x32, 144x144,',
'    192x192, 256x256, and 512x512. Each icon format has a specific use case,',
'    and by providing these different sizes, APEX ensures that your app looks',
'    visually appealing on all platforms.',
'',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1246235441570034663)
,p_plug_name=>'Managing App Icon'
,p_parent_plug_id=>wwv_flow_imp.id(1246235330505034662)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>8
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1246235598791034665)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(1246235441570034663)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/edit-app-icon.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1246235467456034664)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(1246235330505034662)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>In the <strong>App Builder</strong> click <strong>Shared Components</strong></li>',
'    <li>Click <strong>User Interface Attributes</strong></li>',
'    <li>Click <strong>Change Icon</strong> button</li>',
'    <li>Choose a predefined icon and color or upload, resize, and crop a custom icon</li>',
'    <li>Click <strong>Save Icon</strong></li>',
'    <li>Your app icon gets saved in three formats (32x32, 144x144 rounded, 192x192, 256x256 rounded and 512x512)</li>',
'</ol>'))
,p_landmark_label=>'PWA Shortcuts Instructions'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15884641409319294385)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16021082788416556399)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_landmark_type=>'navigation'
,p_landmark_label=>'Region Display Selector'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'NO'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15884641460919294386)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    An app icon is a visual representation that identifies an APEX PWA',
'    application on a device''s home screen or taskbar. A well-designed app',
'    icon can help to establish brand identity and improve the user experience',
'    by providing easy recognition and quick access to the app when this is',
'    installed. An effective icon should be simple, recognizable, and visually',
'    appealing, with a clear representation of the app''s purpose or function.',
'',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16021270081546679149)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16021161199374556464)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16021046070145556359)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16021223304839556532)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17944317472776266630)
,p_plug_name=>'PWA Shortcuts'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'   Oracle APEX Progressive Web App shortcuts provide a convenient way',
'   for users to access specific pages within the application.',
'',
'</p>',
'',
'<p>',
'',
'    On touch-enabled devices, users can simply long-press on the home',
'    screen app icon to access the shortcuts.',
'',
'</p>',
'',
'<p>',
'',
'    For non-touch devices, such as computers, users can right-click on',
'    the taskbar app icon to access the same feature. ',
'',
'</p>',
'',
'<p>',
'',
'    By providing these shortcuts, Oracle APEX enhances the user experience',
'    and makes it easier for users to quickly access the pages they need',
'    within the PWA.',
'',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568562336684562259)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(17944317472776266630)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>In the <strong>App Builder</strong> click <strong>Shared Components</strong></li>',
'    <li>Click <strong>Progressive Web App</strong></li>',
'    <li>Turn on <strong>Enable Progressive Web App</strong> and <strong>Installable</strong></li>',
'    <li>Choose if shortcuts are enabled for Public Sessions or All Sessions</li>',
'    <li>Click <strong>Add Shortcut</strong> button</li>',
'    <li>Type a name and select the page target</li>',
'    <li>Upload your <strong>shortcut icon</strong> file or or leave the default</li>',
'    <li>Click <strong>Create</strong></li>',
'</ol>'))
,p_landmark_label=>'PWA Shortcuts Instructions'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568562412218562260)
,p_plug_name=>'Managing Shortcuts'
,p_parent_plug_id=>wwv_flow_imp.id(17944317472776266630)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568562466154562261)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(15568562412218562260)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/edit-shortcuts.jpeg'
,p_region_image_attr=>'loading="lazy"'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29809986575346542744)
,p_plug_name=>'Compatibility'
,p_parent_plug_id=>wwv_flow_imp.id(17944317472776266630)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This table shows the supported combinations of operating systems and browsers for the PWA Shortcuts feature.</p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc dm-Report--grid">',
'    <thead>',
'        <tr>',
'            <td class="display-hidden"></td>',
'            <th class="u-tL">Chrome</th>',
'            <th class="u-tL">Edge</th>',
'            <th class="u-tL">Firefox</th>',
'            <th class="u-tL">Safari</th>',
'        </tr>',
'    </thead>',
'    <tbody>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Android</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>iOS</span></th>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>macOS</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-not">No</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Windows</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-not">No</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'    </tbody>',
'</table>',
'',
'<p class="margin-top-md"><em>Last updated: April 2023</em></p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
