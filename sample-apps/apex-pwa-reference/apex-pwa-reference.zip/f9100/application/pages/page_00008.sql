prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>606665064748577329
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'Geolocation'
,p_alias=>'GEOLOCATION'
,p_step_title=>'Geolocation - &APP_NAME.'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'let lSpinner$;'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16037484935927581659)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16021082788416556399)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_landmark_type=>'navigation'
,p_landmark_label=>'Region Display Selector'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16037486155260581671)
,p_plug_name=>'Demo'
,p_region_name=>'demo1'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>41
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Tap the <strong>Geolocate</strong> button to find your current position. Your browser may ask your permission to provide this information to the page. This app doesn''t save that information anywhere.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568565924530562295)
,p_plug_name=>'Item Container'
,p_parent_plug_id=>wwv_flow_imp.id(16037486155260581671)
,p_region_template_options=>'#DEFAULT#:t-ItemContainer--stackMobile:t-ItemContainer--alignStretch'
,p_plug_template=>wwv_flow_imp.id(16021141111086556444)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16037486901364581678)
,p_plug_name=>'Data Type'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>21
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    The <strong>Get Current Position</strong> dynamic action can be used to return the data in three different ways.',
'    Choose between returning the GeoJSON to a page item, Latitude and Longitude to a page item, or full object to a JavaScript function.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16037486998843581679)
,p_plug_name=>'GeoJSON'
,p_parent_plug_id=>wwv_flow_imp.id(16037486901364581678)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Returns a JSON with all the location content:</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568565951996562296)
,p_plug_name=>'GeoJSON Code'
,p_parent_plug_id=>wwv_flow_imp.id(16037486998843581679)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--shadowBG:t-ContentBlock--hideHeader'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<code>{',
'    "latitude":20.7195718,',
'    "longitude":-103.4363326,',
'    "altitude":null,',
'    "accuracy":16.452,',
'    "altitudeAccuracy":null,',
'    "heading":null,',
'    "speed":null',
'}</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16037487051342581680)
,p_plug_name=>'Latitude and Longitude'
,p_parent_plug_id=>wwv_flow_imp.id(16037486901364581678)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Returns Latitude and Longitude in separated values:</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568566244764562298)
,p_plug_name=>'Latitude and Longitude Code'
,p_parent_plug_id=>wwv_flow_imp.id(16037487051342581680)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--shadowBG:t-ContentBlock--hideHeader'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<code>P1_LATITUDE: 20.7195613',
'P1_LONGITUDE: -103.4363368',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16037487189122581681)
,p_plug_name=>'JavaScript Function'
,p_parent_plug_id=>wwv_flow_imp.id(16037486901364581678)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Returns full Geolocation object to a custom JavaScript function:</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15568566092627562297)
,p_plug_name=>'JavaScript Function Code'
,p_parent_plug_id=>wwv_flow_imp.id(16037487189122581681)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--shadowBG:t-ContentBlock--hideHeader'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<code>function( position, event ) {',
'    apex.debug.log( position, event );',
'}</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16065233235712439658)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16021161199374556464)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16021046070145556359)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16021223304839556532)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16586774515880832328)
,p_plug_name=>'Examples'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>31
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16739616657887119588)
,p_plug_name=>'iOS requesting permission'
,p_parent_plug_id=>wwv_flow_imp.id(16586774515880832328)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17414246997930276451)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(16739616657887119588)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_region_image=>'#APP_FILES#img/geolocation-request-ios.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17414247618959276457)
,p_plug_name=>'iOS returning geolocation'
,p_parent_plug_id=>wwv_flow_imp.id(16586774515880832328)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17414247131461276452)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(17414247618959276457)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_region_image=>'#APP_FILES#img/geolocation-done-ios.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32769853219773928999)
,p_plug_name=>'Get Current Position'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>1
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="col-8">',
'    Use the <strong>Get Current Position</strong> dynamic action to fetch',
'    the device''s current location.',
'</p>',
'',
'<p class="col-8">',
'    It can return latitude and longitude, or a GeoJSON object, into page items',
'    or a custom JavaScript function can receive a Geolocation object as a parameter.',
'    The accuracy of the geolocation depends on the user''s device.',
'</p>',
'',
'<p class="col-8">',
'    For privacy reasons, each user is asked for permission upon the first use of',
'    this dynamic action. If the user denies permission, the Geolocation returned',
'    is null so your application should handle that possibility gracefully.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31598395364477897329)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(32769853219773928999)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>In <strong>Page Designer</strong> add two items: <strong>P1_LATITUDE</strong> and <strong>P1_LONGITUDE</strong></li>',
'    <li>Create a <strong>Button</strong></li>',
'    <li>Add a <strong>Dynamic Action</strong> to the button click event</li>',
'    <li>Change the <strong>Action</strong> to <strong>Get Current Position</strong></li>',
'    <li>Set the Return Type to <strong>Latitude and Longitude</strong></li>',
'    <li>Set the Latitude Item to <strong>P1_LATITUDE</strong> to return latitude into it</li>',
'    <li>Set the Longitude Item to <strong>P1_LONGITUDE</strong> to return longitude into it</li>',
'</ol>'))
,p_landmark_label=>'Get Current Position Instructions'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31598395386170897330)
,p_plug_name=>'Edit Dynamic Action'
,p_parent_plug_id=>wwv_flow_imp.id(32769853219773928999)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31598395260478897328)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(31598395386170897330)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(16021118936986556428)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_region_image=>'#APP_FILES#img/da-get-current-position.jpeg'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31598396129042897337)
,p_plug_name=>'Compatibility'
,p_parent_plug_id=>wwv_flow_imp.id(32769853219773928999)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(16021111158546556422)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This table shows the supported combinations of operating systems and browsers for the Geolocation feature.</p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc dm-Report--grid">',
'    <thead>',
'        <tr>',
'            <td class="display-hidden"></td>',
'            <th class="u-tL">Chrome</th>',
'            <th class="u-tL">Edge</th>',
'            <th class="u-tL">Firefox</th>',
'            <th class="u-tL">Safari</th>',
'        </tr>',
'    </thead>',
'    <tbody>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Android</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>iOS</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>macOS</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Windows</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'    </tbody>',
'</table>',
'',
'<p class="margin-top-md"><em>Last updated: April 2023</em></p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16037486220564581672)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(15568565924530562295)
,p_button_name=>'GET_CURRENT_POSITION'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(16021221684256556531)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Geolocate'
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16037486366546581673)
,p_name=>'P1_LATITUDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(16037486155260581671)
,p_prompt=>'Latitude'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16021219146504556528)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16037486479912581674)
,p_name=>'P1_LONGITUDE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(15568565924530562295)
,p_prompt=>'Longitude'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16021219146504556528)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16037486603911581675)
,p_name=>'onClick GET_CURRENT_POSITION'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(16037486220564581672)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1361860073926465756)
,p_event_id=>wwv_flow_imp.id(16037486603911581675)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'lSpinner$ = apex.util.showSpinner( $( "#demo1" ) );'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16037486650400581676)
,p_event_id=>wwv_flow_imp.id(16037486603911581675)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_GET_CURRENT_POSITION'
,p_attribute_01=>'lat_long'
,p_attribute_03=>'P1_LATITUDE'
,p_attribute_04=>'P1_LONGITUDE'
,p_attribute_06=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1361860247169465757)
,p_event_id=>wwv_flow_imp.id(16037486603911581675)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'lSpinner$.remove();'
);
wwv_flow_imp.component_end;
end;
/
