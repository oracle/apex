prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>1580934860364765
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'Geolocation'
,p_alias=>'GEOLOCATION'
,p_step_title=>'Geolocation - &APP_NAME.'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'let lSpinner$;'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16039065870787946424)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_landmark_type=>'navigation'
,p_landmark_label=>'Region Display Selector'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16039067090120946436)
,p_plug_name=>'Demo'
,p_region_name=>'demo1'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>41
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Tap the <strong>Geolocate</strong> button to find your current position. Your browser may ask your permission to provide this information to the page. This app doesn''t save that information anywhere.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15570146859390927060)
,p_plug_name=>'Item Container'
,p_parent_plug_id=>wwv_flow_imp.id(16039067090120946436)
,p_region_template_options=>'#DEFAULT#:t-ItemContainer--stackMobile:t-ItemContainer--alignStretch'
,p_plug_template=>1569994581593435632
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16039067836224946443)
,p_plug_name=>'Data Type'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>21
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    The <strong>Get Current Position</strong> dynamic action can be used to return the data in three different ways.',
'    Choose between returning the GeoJSON to a page item, Latitude and Longitude to a page item, or full object to a JavaScript function.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16039067933703946444)
,p_plug_name=>'GeoJSON'
,p_parent_plug_id=>wwv_flow_imp.id(16039067836224946443)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Returns a JSON with all the location content:</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15570146886856927061)
,p_plug_name=>'GeoJSON Code'
,p_parent_plug_id=>wwv_flow_imp.id(16039067933703946444)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--shadowBG:t-ContentBlock--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<code>{',
'    "latitude":20.7195718,',
'    "longitude":-103.4363326,',
'    "altitude":null,',
'    "accuracy":16.452,',
'    "altitudeAccuracy":null,',
'    "heading":null,',
'    "speed":null',
'}</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16039067986202946445)
,p_plug_name=>'Latitude and Longitude'
,p_parent_plug_id=>wwv_flow_imp.id(16039067836224946443)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Returns Latitude and Longitude in separated values:</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15570147179624927063)
,p_plug_name=>'Latitude and Longitude Code'
,p_parent_plug_id=>wwv_flow_imp.id(16039067986202946445)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--shadowBG:t-ContentBlock--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<code>P1_LATITUDE: 20.7195613',
'P1_LONGITUDE: -103.4363368',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16039068123982946446)
,p_plug_name=>'JavaScript Function'
,p_parent_plug_id=>wwv_flow_imp.id(16039067836224946443)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Returns full Geolocation object to a custom JavaScript function:</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15570147027487927062)
,p_plug_name=>'JavaScript Function Code'
,p_parent_plug_id=>wwv_flow_imp.id(16039068123982946446)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--shadowBG:t-ContentBlock--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<code>function( position, event ) {',
'    apex.debug.log( position, event );',
'}</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16066814170572804423)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16022627005005921124)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16588355450741197093)
,p_plug_name=>'Examples'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>31
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16741197592747484353)
,p_plug_name=>'iOS requesting permission'
,p_parent_plug_id=>wwv_flow_imp.id(16588355450741197093)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17415827932790641216)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(16741197592747484353)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_region_image=>'#APP_FILES#img/geolocation-request-ios.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17415828553819641222)
,p_plug_name=>'iOS returning geolocation'
,p_parent_plug_id=>wwv_flow_imp.id(16588355450741197093)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17415828066321641217)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(17415828553819641222)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_region_image=>'#APP_FILES#img/geolocation-done-ios.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32771434154634293764)
,p_plug_name=>'Get Current Position'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>1
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="col-8">',
'    Use the <strong>Get Current Position</strong> dynamic action to fetch',
'    the device''s current location.',
'</p>',
'',
'<p class="col-8">',
'    It can return latitude and longitude, or a GeoJSON object, into page items',
'    or a custom JavaScript function can receive a Geolocation object as a parameter.',
'    The accuracy of the geolocation depends on the user''s device.',
'</p>',
'',
'<p class="col-8">',
'    For privacy reasons, each user is asked for permission upon the first use of',
'    this dynamic action. If the user denies permission, the Geolocation returned',
'    is null so your application should handle that possibility gracefully.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31599976299338262094)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(32771434154634293764)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>In <strong>Page Designer</strong> add two items: <strong>P1_LATITUDE</strong> and <strong>P1_LONGITUDE</strong></li>',
'    <li>Create a <strong>Button</strong></li>',
'    <li>Add a <strong>Dynamic Action</strong> to the button click event</li>',
'    <li>Change the <strong>Action</strong> to <strong>Get Current Position</strong></li>',
'    <li>Set the Return Type to <strong>Latitude and Longitude</strong></li>',
'    <li>Set the Latitude Item to <strong>P1_LATITUDE</strong> to return latitude into it</li>',
'    <li>Set the Longitude Item to <strong>P1_LONGITUDE</strong> to return longitude into it</li>',
'</ol>'))
,p_landmark_label=>'Get Current Position Instructions'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31599976321031262095)
,p_plug_name=>'Edit Dynamic Action'
,p_parent_plug_id=>wwv_flow_imp.id(32771434154634293764)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31599976195339262093)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(31599976321031262095)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_region_image=>'#APP_FILES#img/da-get-current-position.jpeg'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31599977063903262102)
,p_plug_name=>'Compatibility'
,p_parent_plug_id=>wwv_flow_imp.id(32771434154634293764)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This table shows the supported combinations of operating systems and browsers for the Geolocation feature.</p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc dm-Report--grid">',
'    <thead>',
'        <tr>',
'            <td class="display-hidden"></td>',
'            <th class="u-tL">Chrome</th>',
'            <th class="u-tL">Edge</th>',
'            <th class="u-tL">Firefox</th>',
'            <th class="u-tL">Safari</th>',
'        </tr>',
'    </thead>',
'    <tbody>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Android</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>iOS</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>macOS</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'        </tr>',
'        <tr>',
'            <th class="u-tL" scope="row"><span>Windows</span></th>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-visible">Yes</td>',
'            <td class="display-hidden">N/A</td>',
'        </tr>',
'    </tbody>',
'</table>',
'',
'<p class="margin-top-md"><em>Last updated: April 2023</em></p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16039067155424946437)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(15570146859390927060)
,p_button_name=>'GET_CURRENT_POSITION'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Geolocate'
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16039067301406946438)
,p_name=>'P1_LATITUDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(16039067090120946436)
,p_prompt=>'Latitude'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'Y',
  'send_on_page_submit', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16039067414772946439)
,p_name=>'P1_LONGITUDE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(15570146859390927060)
,p_prompt=>'Longitude'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'Y',
  'send_on_page_submit', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16039067538771946440)
,p_name=>'onClick GET_CURRENT_POSITION'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(16039067155424946437)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1363441008786830521)
,p_event_id=>wwv_flow_imp.id(16039067538771946440)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'lSpinner$ = apex.util.showSpinner( $( "#demo1" ) );'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16039067585260946441)
,p_event_id=>wwv_flow_imp.id(16039067538771946440)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_GET_CURRENT_POSITION'
,p_attribute_01=>'lat_long'
,p_attribute_03=>'P1_LATITUDE'
,p_attribute_04=>'P1_LONGITUDE'
,p_attribute_06=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1363441182029830522)
,p_event_id=>wwv_flow_imp.id(16039067538771946440)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'lSpinner$.remove();'
);
wwv_flow_imp.component_end;
end;
/
