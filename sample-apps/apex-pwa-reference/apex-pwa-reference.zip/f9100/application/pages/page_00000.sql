prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>14776237248443586610
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page'
,p_alias=>'PAGE-ZERO'
,p_autocomplete_on_off=>'OFF'
,p_protection_level=>'D'
,p_page_component_map=>'14'
,p_last_updated_by=>'VINCENT.MORNEAU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20221111230440'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14961896911880984927)
,p_plug_name=>'CSS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15414417723667979070)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_07'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.display-hidden {',
'    background-color: var(--ut-report-header-background-color, var(--a-gv-header-background-color)) !important;',
'    color: var(--ut-report-header-text-color, var(--a-gv-header-text-color)) !important;',
'}',
'',
'.display-visible {',
'    background-color: var(--a-palette-success-shade)!important;',
'}',
'',
'.display-not {',
'    background-color: var(--a-palette-danger-shade)!important;',
'}',
'',
'.display-partial {',
'    background-color: var(--a-palette-warning-shade)!important;',
'}'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>'<style>'
,p_plug_footer=>'</style>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
