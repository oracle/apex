prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>1580934860364765
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page'
,p_alias=>'PAGE-ZERO'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15570142911489927021)
,p_plug_name=>'CSS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_07'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.display-hidden {',
'    background-color: var(--ut-report-header-background-color, var(--a-gv-header-background-color)) !important;',
'    color: var(--ut-report-header-text-color, var(--a-gv-header-text-color)) !important;',
'}',
'',
'.display-visible {',
'    background-color: var(--a-palette-success-shade)!important;',
'}',
'',
'.display-not {',
'    background-color: var(--a-palette-danger-shade)!important;',
'}',
'',
'.display-partial {',
'    background-color: var(--a-palette-warning-shade)!important;',
'}'))
,p_plug_header=>'<style>'
,p_plug_footer=>'</style>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
