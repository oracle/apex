prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>1580934860364765
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'Always Signed In'
,p_alias=>'ALWAYS-SIGNED-IN'
,p_step_title=>'Always Signed In - &APP_NAME.'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Comments-instructions {',
'    text-align: center;',
'    font-weight: bold;',
'}',
'',
'.image-wrap {',
'    display: flex;',
'    flex-flow: column;',
'}',
'',
'.img-installer-mobile {',
'    width: 100%;',
'    border-radius: 5px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16039066096536946426)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_landmark_type=>'navigation'
,p_landmark_label=>'Region Display Selector'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16039068761872946453)
,p_plug_name=>'Example'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Without <strong>persistent authentication</strong>, APEX login screens typically contain a <strong>Remember Username</strong> checkbox. With <strong>persistent authentication</strong>, users see a <strong>Remember me</strong> checkbox instead.</p>'
,p_landmark_label=>'Persistent Authentication Example'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16087873823171546405)
,p_plug_name=>'Login page (Default)'
,p_parent_plug_id=>wwv_flow_imp.id(16039068761872946453)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_plug_grid_column_css_classes=>'padding-none'
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17415829210604641229)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(16087873823171546405)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>30
,p_plug_grid_column_css_classes=>'padding-none'
,p_region_image=>'#APP_FILES#img/login-normal.jpeg'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16087873901578546406)
,p_plug_name=>'Login page with PWA'
,p_parent_plug_id=>wwv_flow_imp.id(16039068761872946453)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_grid_column_css_classes=>'padding-none'
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17415829106271641228)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(16087873901578546406)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>20
,p_plug_grid_column_css_classes=>'padding-none'
,p_region_image=>'#APP_FILES#img/login-pwa.jpeg'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16066816972834816632)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(16022627005005921124)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16721609946747378046)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    Your customers launch your PWA app and start working immediately with the <strong>persistent authentication</strong> setting.',
'    Users sign in once and stay signed in for a fixed period of time.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1360459048073227105)
,p_plug_name=>'Increased engagement'
,p_parent_plug_id=>wwv_flow_imp.id(16721609946747378046)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>Let your users to choose to stay signed in and get them back into your app faster. When their session expires, a new one is automatically created.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1360459120914227106)
,p_plug_name=>'Secured by default'
,p_parent_plug_id=>wwv_flow_imp.id(16721609946747378046)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>The persistent authentication settings are configurable through the APEX admin instance and it can be disabled at any moment, giving you control over your system.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1360459271771227107)
,p_plug_name=>'Using the API'
,p_parent_plug_id=>wwv_flow_imp.id(16721609946747378046)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    The persistent authentication is enabled for new PWAs. Change your existing',
'    applications to use persistent authentication through the extended',
'    apex_authentication.login API.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1358637494212715516)
,p_plug_name=>'apex_authentication.login'
,p_parent_plug_id=>wwv_flow_imp.id(1360459271771227107)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--shadowBG:t-ContentBlock--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<code>APEX_AUTHENTICATION.LOGIN ( ',
'    p_username              IN VARCHAR2, ',
'    p_password              IN VARCHAR2,',
'    <strong>p_set_persistent_auth   IN BOOLEAN  DEFAULT FALSE</strong> ); ',
'</code>'))
,p_landmark_label=>'Code for apex_authentication.login'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18007279124119101115)
,p_plug_name=>'Manage Instance'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p><strong>Persistent authentication</strong> has to be enabled at the instance level.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17415828710263641224)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(18007279124119101115)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'    <li>Sign in to your APEX instance as admin</li>',
'    <li>Go to <strong>Manage Instance</strong></li>',
'    <li>Go to <strong>Security</strong></li>',
'    <li>Set <strong>Allow Persistent Auth</strong> to <strong>Yes</strong></li>',
'    <li>Set the <strong>lifetime</strong> duration for the automatic session renewal, in days</li>',
'</ol>',
'<ul>',
'    <li style="list-style-type: none;"><em class="u-flex">Note: apex.oracle.com has this enabled for demo purposes</em></li>',
'</ul>',
''))
,p_landmark_label=>'Persistent authentication Instructions'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17415828841545641225)
,p_plug_name=>'APEX Admin Instance'
,p_parent_plug_id=>wwv_flow_imp.id(18007279124119101115)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17415828908073641226)
,p_plug_name=>'Image'
,p_parent_plug_id=>wwv_flow_imp.id(17415828841545641225)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--rounded:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_region_image=>'#APP_FILES#img/persistent-auth-admin.jpeg'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
