prompt --application/shared_components/navigation/lists/advanced
begin
--   Manifest
--     LIST: Advanced
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>606665064748577329
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1370841295627793353)
,p_name=>'Advanced'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089100346
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1370843082707793358)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Service Worker'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-server'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1370844676976793359)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Offline Fallback'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-power-off'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
