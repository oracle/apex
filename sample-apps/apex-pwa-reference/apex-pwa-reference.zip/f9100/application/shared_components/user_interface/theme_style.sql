prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 9100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>606665064748577329
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(701335806730397145)
,p_theme_id=>42
,p_name=>'Redwood Light'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Redwood-Theme#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>2596426436825065489
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(701336195851397146)
,p_theme_id=>42
,p_name=>'Vita'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>2719875314571594493
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(701336560090397146)
,p_theme_id=>42
,p_name=>'Vita - Dark'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Dark.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Dark#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3543348412015319650
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(701336951960397146)
,p_theme_id=>42
,p_name=>'Vita - Red'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Red.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Red#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>1938457712423918173
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(701337340025397147)
,p_theme_id=>42
,p_name=>'Vita - Slate'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Slate.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Slate#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3291983347983194966
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(1359378345456490874)
,p_theme_id=>42
,p_name=>'APEX PWA'
,p_is_current=>true
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Accent-BG":"#7c5095","@g_Accent-OG":"#ffffff","@g_Color-Palette-1":"#4a2337","@g_Color-Palette-1-FG":"#ffffff","@g_Color-Palette-2":"#663c6e","@g_Color-Palette-2-FG":"#ffffff","@g_Color-Palette-3":"#7b638a","@g_Color-Palette'
||'-3-FG":"#ffffff","@g_Color-Palette-4":"#656e9d","@g_Color-Palette-4-FG":"#ffffff","@g_Color-Palette-5":"#3f79a8","@g_Color-Palette-5-FG":"#ffffff","@g_Color-Palette-6":"#0084a8","@g_Color-Palette-6-FG":"#ffffff","@g_Color-Palette-7":"#008d9c","@g_Col'
||'or-Palette-7-FG":"#ffffff","@g_Color-Palette-8":"#009485","@g_Color-Palette-8-FG":"#ffffff","@g_Color-Palette-9":"#549400","@g_Color-Palette-9-FG":"#ffffff","@g_Color-Palette-10":"#929400","@g_Color-Palette-10-FG":"#ffffff","@g_Color-Palette-11":"#94'
||'6500","@g_Color-Palette-11-FG":"#ffffff","@g_Color-Palette-12":"#944300","@g_Color-Palette-12-FG":"#f6f0f8","@g_Color-Palette-13":"#942000","@g_Color-Palette-13-FG":"#ffffff","@g_Color-Palette-14":"#3d0d00","@g_Color-Palette-14-FG":"#ffffff","@g_Colo'
||'r-Palette-15":"#000000","@g_Color-Palette-15-FG":"#ffffff","@g_Form-Item-BG":"#e9e7e7","@g_Form-Item-FG":"#202020","@g_Nav-BG":"#333333","@g_Nav-FG":"#ffffff","@g_Nav-Active-BG":"#111111","@g_Nav-Active-FG":"#ffffff","@g_Info-BG":"#f2eef4","@g_Info-F'
||'G":"#7c5095"},"customCSS":".t-ContentBlock--h3 {\n    --ut-content-block-header-font-size: 1.125rem;\n    --a-base-font-weight-semibold: 500;\n}\n.t-MediaList-icon.u-color {\n    background: var(--ut-palette-primary-shade);\n    color: var(--ut-palet'
||'te-primary);\n}\n.flex-center {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n} ","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#1359378345456490874.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
