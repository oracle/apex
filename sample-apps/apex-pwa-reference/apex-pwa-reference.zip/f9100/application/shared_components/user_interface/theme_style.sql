prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 9100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>1580934860364765
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(1360959280316855639)
,p_theme_id=>42
,p_name=>'APEX PWA'
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Accent-BG":"#7c5095","@g_Accent-OG":"#ffffff","@g_Color-Palette-1":"#4a2337","@g_Color-Palette-1-FG":"#ffffff","@g_Color-Palette-2":"#663c6e","@g_Color-Palette-2-FG":"#ffffff","@g_Color-Palette-3":"#7b638a","@g_Color-Palette'
||'-3-FG":"#ffffff","@g_Color-Palette-4":"#656e9d","@g_Color-Palette-4-FG":"#ffffff","@g_Color-Palette-5":"#3f79a8","@g_Color-Palette-5-FG":"#ffffff","@g_Color-Palette-6":"#0084a8","@g_Color-Palette-6-FG":"#ffffff","@g_Color-Palette-7":"#008d9c","@g_Col'
||'or-Palette-7-FG":"#ffffff","@g_Color-Palette-8":"#009485","@g_Color-Palette-8-FG":"#ffffff","@g_Color-Palette-9":"#549400","@g_Color-Palette-9-FG":"#ffffff","@g_Color-Palette-10":"#929400","@g_Color-Palette-10-FG":"#ffffff","@g_Color-Palette-11":"#94'
||'6500","@g_Color-Palette-11-FG":"#ffffff","@g_Color-Palette-12":"#944300","@g_Color-Palette-12-FG":"#f6f0f8","@g_Color-Palette-13":"#942000","@g_Color-Palette-13-FG":"#ffffff","@g_Color-Palette-14":"#3d0d00","@g_Color-Palette-14-FG":"#ffffff","@g_Colo'
||'r-Palette-15":"#000000","@g_Color-Palette-15-FG":"#ffffff","@g_Form-Item-BG":"#e9e7e7","@g_Form-Item-FG":"#202020","@g_Nav-BG":"#333333","@g_Nav-FG":"#ffffff","@g_Nav-Active-BG":"#111111","@g_Nav-Active-FG":"#ffffff","@g_Info-BG":"#f2eef4","@g_Info-F'
||'G":"#7c5095"},"customCSS":".t-ContentBlock--h3 {\n    --ut-content-block-header-font-size: 1.125rem;\n    --a-base-font-weight-semibold: 500;\n}\n.t-MediaList-icon.u-color {\n    background: var(--ut-palette-primary-shade);\n    color: var(--ut-palet'
||'te-primary);\n}\n.flex-center {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n} ","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#1360959280316855639.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
