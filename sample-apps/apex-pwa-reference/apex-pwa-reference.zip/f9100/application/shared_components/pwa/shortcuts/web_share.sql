prompt --application/shared_components/pwa/shortcuts/web_share
begin
--   Manifest
--     PWA SHORTCUT: Web Share
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>14776237248443586610
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_shortcut(
 p_id=>wwv_flow_imp.id(764225571234231818)
,p_name=>'Web Share'
,p_display_sequence=>70
,p_target_url=>'f?p=&APP_ID.:9:&SESSION.'
,p_icon_url=>'pwa/shortcut-icon-70.png'
);
wwv_flow_imp.component_end;
end;
/
