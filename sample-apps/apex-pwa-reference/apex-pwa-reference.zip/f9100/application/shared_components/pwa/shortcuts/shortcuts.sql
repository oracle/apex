prompt --application/shared_components/pwa/shortcuts/shortcuts
begin
--   Manifest
--     PWA SHORTCUT: Shortcuts
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>14776237248443586610
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_shortcut(
 p_id=>wwv_flow_imp.id(15414707665337754168)
,p_name=>'Shortcuts'
,p_display_sequence=>40
,p_target_url=>'f?p=&APP_ID.:4:&SESSION.'
,p_icon_url=>'pwa/shortcut-icon-40.png'
);
wwv_flow_imp.component_end;
end;
/
