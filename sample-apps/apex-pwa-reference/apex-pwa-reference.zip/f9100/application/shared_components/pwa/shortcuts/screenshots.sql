prompt --application/shared_components/pwa/shortcuts/screenshots
begin
--   Manifest
--     PWA SHORTCUT: Screenshots
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>14776237248443586610
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_shortcut(
 p_id=>wwv_flow_imp.id(15414707503432752736)
,p_name=>'Screenshots'
,p_display_sequence=>50
,p_target_url=>'f?p=&APP_ID.:3:&SESSION.'
,p_icon_url=>'pwa/shortcut-icon-50.png'
);
wwv_flow_imp.component_end;
end;
/
