prompt --application/shared_components/pwa/shortcuts/always_signed_in
begin
--   Manifest
--     PWA SHORTCUT: Always Signed In
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>1580934860364765
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_shortcut(
 p_id=>wwv_flow_imp.id(1372472197152175572)
,p_name=>'Always Signed In'
,p_display_sequence=>80
,p_target_url=>'f?p=&APP_ID.:10:&SESSION.'
,p_icon_url=>'pwa/shortcut-icon-80.png'
);
wwv_flow_imp.component_end;
end;
/
