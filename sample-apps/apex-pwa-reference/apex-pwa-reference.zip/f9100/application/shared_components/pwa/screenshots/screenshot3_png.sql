prompt --application/shared_components/pwa/screenshots/screenshot3_png
begin
--   Manifest
--     PWA SCREENSHOT: screenshot3.png
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>606665064748577329
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_screenshot(
 p_id=>wwv_flow_imp.id(1370896783127912417)
,p_label=>'screenshot3.png'
,p_display_sequence=>30
,p_screenshot_url=>'pwa/screenshot3.png'
);
wwv_flow_imp.component_end;
end;
/
