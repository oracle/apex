prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>1580934860364765
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>20
,p_name=>'Advanced'
,p_alias=>'ADVANCED'
,p_step_title=>'Advanced'
,p_autocomplete_on_off=>'ON'
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'06'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1371408188388807297)
,p_plug_name=>'Advanced'
,p_static_id=>'advanced'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:t-ContentBlock--lightBG:t-ContentBlock--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'t-MediaList--showIcons'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>40
,p_plug_grid_column_css_classes=>'col-lg-10 col-xl-8 col-xxl-8'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(1372422230488158118)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2071422514019082236
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16787048845188318656)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(16022627005005921124)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp.component_end;
end;
/
