prompt --application/shared_components/pwa/shortcuts/geolocation
begin
--   Manifest
--     PWA SHORTCUT: Geolocation
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>1580934860364765
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_shortcut(
 p_id=>wwv_flow_imp.id(1372470983503172295)
,p_name=>'Geolocation'
,p_static_id=>'geolocation'
,p_display_sequence=>60
,p_target_url=>'f?p=&APP_ID.:8:&SESSION.'
,p_icon_url=>'pwa/shortcut-icon-60.png'
);
wwv_flow_imp.component_end;
end;
/
