prompt --application/shared_components/pwa/shortcuts/appearance
begin
--   Manifest
--     PWA SHORTCUT: Appearance
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>1580934860364765
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_shortcut(
 p_id=>wwv_flow_imp.id(1372469536814167046)
,p_name=>'Appearance'
,p_static_id=>'appearance'
,p_display_sequence=>40
,p_target_url=>'f?p=&APP_ID.:2:&SESSION.'
,p_icon_url=>'pwa/shortcut-icon-40.png'
);
wwv_flow_imp.component_end;
end;
/
