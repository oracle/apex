prompt --application/shared_components/pwa/screenshots/screenshot2_png
begin
--   Manifest
--     PWA SCREENSHOT: screenshot2.png
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>1580934860364765
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_screenshot(
 p_id=>wwv_flow_imp.id(1372477146116276689)
,p_label=>'screenshot2.png'
,p_static_id=>'screenshot2-png'
,p_display_sequence=>20
,p_screenshot_url=>'pwa/screenshot2.png'
);
wwv_flow_imp.component_end;
end;
/
