prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 9100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9100
,p_default_id_offset=>1580934860364765
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
