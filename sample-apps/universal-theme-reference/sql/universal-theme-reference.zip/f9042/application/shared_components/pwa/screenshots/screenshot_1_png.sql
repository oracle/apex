prompt --application/shared_components/pwa/screenshots/screenshot_1_png
begin
--   Manifest
--     PWA SCREENSHOT: Screenshot-1.png
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_screenshot(
 p_id=>wwv_flow_imp.id(1997257554854488157)
,p_label=>'Screenshot-1.png'
,p_static_id=>'screenshot-1-png'
,p_display_sequence=>10
,p_screenshot_url=>'pwa/Screenshot-1.png'
);
wwv_flow_imp.component_end;
end;
/
