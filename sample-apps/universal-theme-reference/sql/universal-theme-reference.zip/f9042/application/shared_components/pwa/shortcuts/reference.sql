prompt --application/shared_components/pwa/shortcuts/reference
begin
--   Manifest
--     PWA SHORTCUT: Reference
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_shortcut(
 p_id=>wwv_flow_imp.id(1982258619144767204)
,p_name=>'Reference'
,p_static_id=>'reference'
,p_display_sequence=>50
,p_description=>'Reference Section'
,p_target_url=>'f?p=&APP_ID.:6000:&SESSION.'
,p_pwa_shortcut_comment=>'-'
);
wwv_flow_imp.component_end;
end;
/
