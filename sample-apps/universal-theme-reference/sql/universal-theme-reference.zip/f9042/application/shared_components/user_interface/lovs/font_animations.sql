prompt --application/shared_components/user_interface/lovs/font_animations
begin
--   Manifest
--     FONT_ANIMATIONS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2579369218704910721)
,p_lov_name=>'FONT_ANIMATIONS'
,p_static_id=>'font-animations'
,p_lov_query=>'.'||wwv_flow_imp.id(2579369218704910721)||'.'
,p_location=>'STATIC'
,p_version_scn=>'112802986'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(2579369867142910726)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Flash'
,p_lov_return_value=>'fa-anim-flash'
,p_static_id=>'flash'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(2579383048924983751)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Horizontal Shake'
,p_lov_return_value=>'fa-anim-horizontal-shake'
,p_static_id=>'horizontal-shake'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(2579370209609910727)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Spin'
,p_lov_return_value=>'fa-anim-spin'
,p_static_id=>'spin'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(2579369485483910724)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Spin in Steps'
,p_lov_return_value=>'fa-anim-spin-step'
,p_static_id=>'spin-in-steps'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(2579383459517983751)
,p_lov_disp_sequence=>50
,p_lov_disp_value=>'Vertical Shake'
,p_lov_return_value=>'fa-anim-vertical-shake'
,p_static_id=>'vertical-shake'
);
wwv_flow_imp.component_end;
end;
/
