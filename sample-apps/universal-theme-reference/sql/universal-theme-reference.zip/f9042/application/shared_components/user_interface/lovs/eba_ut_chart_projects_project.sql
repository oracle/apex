prompt --application/shared_components/user_interface/lovs/eba_ut_chart_projects_project
begin
--   Manifest
--     EBA_UT_CHART_PROJECTS.PROJECT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2020859052206630343)
,p_lov_name=>'EBA_UT_CHART_PROJECTS.PROJECT'
,p_static_id=>'eba-ut-chart-projects-project'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'EBA_UT_CHART_PROJECTS'
,p_return_column_name=>'ID'
,p_display_column_name=>'PROJECT'
,p_default_sort_column_name=>'PROJECT'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'112802986'
);
wwv_flow_imp.component_end;
end;
/
