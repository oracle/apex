prompt --application/shared_components/navigation/lists/badge_list_sample
begin
--   Manifest
--     LIST: Badge List Sample
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2654239782849710414)
,p_name=>'Badge List Sample'
,p_static_id=>'badge-list-sample'
,p_version_scn=>'112802243'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3922546448034724984)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Action Items'
,p_static_id=>'action-items'
,p_list_item_link_target=>'#'
,p_list_text_01=>'15'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2654239942224710415)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Active Bugs'
,p_static_id=>'active-bugs'
,p_list_item_link_target=>'#'
,p_list_text_01=>'12'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2654240268125710415)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Closed Bugs'
,p_static_id=>'closed-bugs'
,p_list_item_link_target=>'#'
,p_list_text_01=>'31'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2654243168068719229)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Milestones'
,p_static_id=>'milestones'
,p_list_item_link_target=>'#'
,p_list_text_01=>'3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2654241150345710420)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Projects'
,p_static_id=>'projects'
,p_list_item_link_target=>'#'
,p_list_text_01=>'34'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2654240792546710420)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Users'
,p_static_id=>'users'
,p_list_item_link_target=>'#'
,p_list_text_01=>'188'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
