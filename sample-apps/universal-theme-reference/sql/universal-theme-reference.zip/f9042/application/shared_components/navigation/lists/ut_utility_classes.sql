prompt --application/shared_components/navigation/lists/ut_utility_classes
begin
--   Manifest
--     LIST: UT - Utility Classes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2730035390736774836)
,p_name=>'UT - Utility Classes'
,p_static_id=>'ut-utility-classes'
,p_version_scn=>'112802243'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2730036117140774840)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Color and Status Modifiers'
,p_static_id=>'color-and-status-modifiers'
,p_list_item_link_target=>'f?p=&APP_ID.:6302:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-eyedropper'
,p_list_text_01=>'These color and status modifier classes enable you to add color to custom components.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2730036892742774841)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Content Modifiers'
,p_static_id=>'content-modifiers'
,p_list_item_link_target=>'f?p=&APP_ID.:6304:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-text-height'
,p_list_text_01=>'These content modifiers enable you to control the appearance of text, headings, and paragraphs.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(916625694254796705)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'CSS Variables'
,p_static_id=>'css-variables'
,p_list_item_link_target=>'f?p=&APP_ID.:6307:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-variable'
,p_list_text_01=>'Style references for your components.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2730036569852774840)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Layout Modifiers'
,p_static_id=>'layout-modifiers'
,p_list_item_link_target=>'f?p=&APP_ID.:6303:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-fit-to-size'
,p_list_text_01=>'These CSS classes enable you to modify layout blocks by setting margins, paddings, and more.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(916635021859930136)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Responsive Classes'
,p_static_id=>'responsive-classes'
,p_list_item_link_target=>'f?p=&APP_ID.:300:&SESSION.:responsive_design:&DEBUG.::::'
,p_list_item_icon=>'fa-expand'
,p_list_text_01=>'Classes with responsive behaviors for different screen sizes.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
