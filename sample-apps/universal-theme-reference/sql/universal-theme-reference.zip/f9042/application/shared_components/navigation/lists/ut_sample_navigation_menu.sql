prompt --application/shared_components/navigation/lists/ut_sample_navigation_menu
begin
--   Manifest
--     LIST: UT - Sample Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3901813781022261431)
,p_name=>'UT - Sample Navigation Menu'
,p_static_id=>'ut-sample-navigation-menu'
,p_version_scn=>'112802244'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901813971762261432)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Menu Item 1'
,p_static_id=>'menu-item'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901814360479261433)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Menu Item 2'
,p_static_id=>'menu-item-2'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-user'
,p_list_item_current_type=>'ALWAYS'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901814741336261433)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Menu Item 3'
,p_static_id=>'menu-item-3'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-play-circle-o'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901815091587261433)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Menu Item 4'
,p_static_id=>'menu-item-4'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-gear'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901815522606261433)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Menu Item 5'
,p_static_id=>'menu-item-5'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-alert'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901816380127271521)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Sub Menu Item 2.1'
,p_static_id=>'sub-menu-item'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(3901814360479261433)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901819224682281750)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Sub Menu Item 4.2'
,p_static_id=>'sub-menu-item-10'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(3901815091587261433)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901819492433282902)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Sub Menu Item 5.1'
,p_static_id=>'sub-menu-item-11'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(3901815522606261433)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901819843015283538)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Sub Menu Item 5.2'
,p_static_id=>'sub-menu-item-12'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(3901815522606261433)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901816672735272469)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Sub Menu Item 2.2'
,p_static_id=>'sub-menu-item-2'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(3901814360479261433)
,p_list_item_current_type=>'ALWAYS'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901816960631273329)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Sub Menu Item 2.3'
,p_static_id=>'sub-menu-item-3'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(3901814360479261433)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901817247665275433)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Sub Menu Item 3.1'
,p_static_id=>'sub-menu-item-4'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(3901814741336261433)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901817528019276334)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Sub Menu Item 3.2'
,p_static_id=>'sub-menu-item-5'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(3901814741336261433)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901817881435277421)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Sub Menu Item 3.2.1'
,p_static_id=>'sub-menu-item-6'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(3901817528019276334)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901818169138278464)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Sub Menu Item 3.2.2'
,p_static_id=>'sub-menu-item-7'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(3901817528019276334)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901818680699279374)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Sub Menu Item 3.2.3'
,p_static_id=>'sub-menu-item-8'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(3901817528019276334)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3901818966315281011)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Sub Menu Item 4.1'
,p_static_id=>'sub-menu-item-9'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(3901815091587261433)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
