prompt --application/shared_components/navigation/lists/ut_sample_menu_popup
begin
--   Manifest
--     LIST: UT - Sample Menu Popup
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4168482818825779033)
,p_name=>'UT - Sample Menu Popup'
,p_static_id=>'ut-sample-menu-popup'
,p_version_scn=>'112802249'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4168483036081779034)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Action A'
,p_static_id=>'action-a'
,p_list_item_link_target=>'#'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4168483456814779036)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Action B'
,p_static_id=>'action-b'
,p_list_item_link_target=>'#'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4168483802369779037)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Action C'
,p_static_id=>'action-c'
,p_list_item_link_target=>'#'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4168484263265779037)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Action D'
,p_static_id=>'action-d'
,p_list_item_link_target=>'#'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4168484658925779037)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Sub Item A'
,p_static_id=>'sub-item-a'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(4168483456814779036)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4168599501521782459)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Sub Item B'
,p_static_id=>'sub-item-b'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(4168483456814779036)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
