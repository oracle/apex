prompt --application/shared_components/navigation/lists/templates_components
begin
--   Manifest
--     LIST: Templates - Components
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4072543478264979648)
,p_name=>'Templates - Components'
,p_static_id=>'templates-components'
,p_version_scn=>'SH256:rJoga1NJTC6AmXZ8Ka4BN64hJPGRGR91NIUaAqosp1U'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2823818370968103596)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Alert'
,p_static_id=>'alert'
,p_list_item_link_target=>'f?p=&APP_ID.:1202:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-exclamation-triangle'
,p_list_text_01=>'Display alerts, confirmations, and other action-oriented messages.'
,p_list_text_02=>'Region'
,p_list_text_03=>'LS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1861871251497286870)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Avatar'
,p_static_id=>'avatar'
,p_list_item_link_target=>'f?p=&APP_ID.:3001:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-circle'
,p_list_text_01=>'Display an icon, image, or initials.'
,p_list_text_02=>'Partial'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1862801648392495112)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Badge'
,p_static_id=>'badge'
,p_list_item_link_target=>'f?p=&APP_ID.:3002:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-badges'
,p_list_text_01=>'Display content within a badge.'
,p_list_text_02=>'Partial'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4632899989492177122)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Badges List'
,p_static_id=>'badges-list'
,p_list_item_link_target=>'f?p=&APP_ID.:1304:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-badge-list'
,p_list_text_01=>'Display badges or counters.'
,p_list_text_02=>'List'
,p_list_text_03=>'BL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4072543641366979651)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_list_item_link_target=>'f?p=&APP_ID.:3810:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-breadcrumb'
,p_list_text_01=>'Indicate where the user is within the application with a hierarchical list of links.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2186528513296266548)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Button'
,p_static_id=>'button'
,p_list_item_link_target=>'f?p=&APP_ID.:1500:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-button'
,p_list_text_01=>'Display text, icon or both within a button.'
,p_list_text_02=>'Button'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2823819157224103597)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Button Container'
,p_static_id=>'button-container'
,p_list_item_link_target=>'f?p=&APP_ID.:1250:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-button-container'
,p_list_text_01=>'Organize buttons, toolbars, and simple horizontal forms.'
,p_list_text_02=>'Region'
,p_list_text_03=>'BC'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1864401681564361183)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Button Group'
,p_static_id=>'button-group'
,p_list_item_link_target=>'f?p=&APP_ID.:1204:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-button-group'
,p_list_text_01=>'Group buttons to appear together to make a single control.'
,p_list_text_02=>'Button'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4072544077587979652)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Calendar'
,p_static_id=>'calendar'
,p_list_item_link_target=>'f?p=&APP_ID.:1800:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'Display a calendar based on the Full Calendar library that supports drag and drop, multiple views, and more.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1864417712118742680)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Card Regions'
,p_static_id=>'card-regions'
,p_list_item_link_target=>'f?p=&APP_ID.:3110:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-address-card-o'
,p_list_text_01=>'Present a variety of information in small blocks and can be heavily customized.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4632900433793181645)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Card Templates'
,p_static_id=>'card-templates'
,p_list_item_link_target=>'f?p=&APP_ID.:3100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cards'
,p_list_text_01=>'Style regions like Classic Reports or Lists to look like a Cards region.'
,p_list_text_02=>'Report, List'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2823819505267103598)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Carousel'
,p_static_id=>'carousel'
,p_list_item_link_target=>'f?p=&APP_ID.:1205:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-carousel'
,p_list_text_01=>'Show off one sub region at a time. For example, display a report and a chart, a slideshow, or different views of the same data.'
,p_list_text_02=>'Region'
,p_list_text_03=>'CS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4072592642700162574)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Charts'
,p_static_id=>'charts'
,p_list_item_link_target=>'f?p=&APP_ID.:1902:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bar-chart'
,p_list_text_01=>'Visualize data in a variety of different ways based on Oracle JavaScript Extension Toolkit (JET) Data Visualizations.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4072648900561680293)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Classic Report'
,p_static_id=>'classic-report'
,p_list_item_link_target=>'f?p=&APP_ID.:1401:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>'Display tabular data in a default report template.'
,p_list_text_02=>'Report'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2823819904997103598)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Collapsible'
,p_static_id=>'collapsible'
,p_list_item_link_target=>'f?p=&APP_ID.:1206:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-collapsible'
,p_list_text_01=>'Toggle the visibility of a region''s content on the page.'
,p_list_text_02=>'Region'
,p_list_text_03=>'DL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2358979123099285495)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Column Toggle Report'
,p_static_id=>'column-toggle-report'
,p_list_item_link_target=>'f?p=&APP_ID.:1720:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-toggle-on'
,p_list_text_01=>'Quickly choose columns to display when screen size is limited.'
,p_list_text_02=>'Report'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2823974967616584421)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Comments'
,p_static_id=>'comments'
,p_list_item_link_target=>'f?p=&APP_ID.:3003:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-comments-o'
,p_list_text_01=>'Display user comments and status updates.'
,p_list_text_02=>'Region'
,p_list_text_03=>'CM'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4632919192750286042)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Content Block'
,p_static_id=>'content-block'
,p_list_item_link_target=>'f?p=&APP_ID.:1209:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-align-justify'
,p_list_text_01=>'Display region content in a simple block.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1864400863392342039)
,p_list_item_display_sequence=>165
,p_list_item_link_text=>'Content Row'
,p_static_id=>'content-row'
,p_list_item_link_target=>'f?p=&APP_ID.:3004:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-list-left'
,p_list_text_01=>'Display content using a column for selection, such as a checkbox or radio button, an icon, and actions.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3122614098116792682)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Contextual Info'
,p_static_id=>'contextual-info'
,p_list_item_link_target=>'f?p=&APP_ID.:1307:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-list-right'
,p_list_text_01=>'Display key-value pairs in a report.'
,p_list_text_02=>'Report'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3949390517208404)
,p_list_item_display_sequence=>172
,p_list_item_link_text=>'Flexbox Container'
,p_static_id=>'flexbox-container'
,p_list_item_link_target=>'f?p=&APP_ID.:3008:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-nav-left'
,p_list_text_01=>'Suitable for arranging components in a flexible layout.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2186524762183282939)
,p_list_item_display_sequence=>175
,p_list_item_link_text=>'Form Field'
,p_static_id=>'form-field'
,p_list_item_link_target=>'f?p=&APP_ID.:1600:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-forms'
,p_list_text_01=>'Position form field such as inputs, select lists and more on a page..'
,p_list_text_02=>'Form'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4072594590599182042)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Help Text'
,p_static_id=>'help-text'
,p_list_item_link_target=>'f?p=&APP_ID.:1903:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-info-circle'
,p_list_text_01=>'Provide page-level help to users.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2823818758053103597)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>'Hero'
,p_static_id=>'hero'
,p_list_item_link_target=>'f?p=&APP_ID.:1203:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bullhorn'
,p_list_text_01=>'Capture attention and display an icon, heading, sub-headings, and buttons on a homepage, dashboard, and other introductory-style pages.'
,p_list_text_02=>'Region'
,p_list_text_03=>'HR'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2050558333225534248)
,p_list_item_display_sequence=>195
,p_list_item_link_text=>'Image'
,p_static_id=>'image'
,p_list_item_link_target=>'f?p=&APP_ID.:1210:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-image'
,p_list_text_01=>'Display a single image without text in a region.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4632919488662286043)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'Inline Dialog'
,p_static_id=>'inline-dialog'
,p_list_item_link_target=>'f?p=&APP_ID.:1911:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-header'
,p_list_text_01=>'Display a region on the current page within a modal dialog.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4072649345138680293)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>'Interactive Grid'
,p_static_id=>'interactive-grid'
,p_list_item_link_target=>'f?p=&APP_ID.:1410:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-grid-2x'
,p_list_text_01=>'Customize reports using powerful features in this native APEX component.'
,p_list_text_02=>'Report'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4072649726696680293)
,p_list_item_display_sequence=>230
,p_list_item_link_text=>'Interactive Report'
,p_static_id=>'interactive-report'
,p_list_item_link_target=>'f?p=&APP_ID.:1402:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-sort-amount-desc'
,p_list_text_01=>'Create powerful reports using fixed headers, frozen columns, scroll pagination, multiple filters, sorting, aggregates, computations, and more.'
,p_list_text_02=>'Report'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2823965010144541851)
,p_list_item_display_sequence=>240
,p_list_item_link_text=>'Links List'
,p_static_id=>'links-list'
,p_list_item_link_target=>'f?p=&APP_ID.:1303:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list'
,p_list_text_01=>'Use a list of links for navigation and other action-oriented tasks, with the option to show badges, icons, sub-list items, and more.'
,p_list_text_02=>'List'
,p_list_text_03=>'LS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1867774918386927659)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>'List View'
,p_static_id=>'list-view'
,p_list_item_link_target=>'f?p=&APP_ID.:1700:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list-alt'
,p_list_text_01=>'Display a simple list-based user interface that has a wide range of features such as built in search, list dividers, nested lists, and more.'
,p_list_text_02=>'List'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2823964271563541848)
,p_list_item_display_sequence=>270
,p_list_item_link_text=>'Media List'
,p_static_id=>'media-list'
,p_list_item_link_target=>'f?p=&APP_ID.:3005:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-media-list'
,p_list_text_01=>'Design lists that involve an icon, heading, description, and a badge.'
,p_list_text_02=>'Region'
,p_list_text_03=>'ML'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4632900783431181645)
,p_list_item_display_sequence=>280
,p_list_item_link_text=>'Menu Bar'
,p_static_id=>'menu-bar'
,p_list_item_link_target=>'f?p=&APP_ID.:1305:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tabs'
,p_list_text_01=>'Display a menu bar control.'
,p_list_text_02=>'List'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4632901189498181646)
,p_list_item_display_sequence=>290
,p_list_item_link_text=>'Menu Popup'
,p_static_id=>'menu-popup'
,p_list_item_link_target=>'f?p=&APP_ID.:1306:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list-alt'
,p_list_text_01=>'Display a menu that pops up on a page by using Lists and associating a button with the menu.'
,p_list_text_02=>'List'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3948326137187420)
,p_list_item_display_sequence=>295
,p_list_item_link_text=>'Metric Card'
,p_static_id=>'metric-card'
,p_list_item_link_target=>'f?p=&APP_ID.:3007:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-credit-card-front'
,p_list_text_01=>'Used to display a single key value alongside a label and supporting details.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4632901573645181646)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>'Navigation Bar'
,p_static_id=>'navigation-bar'
,p_list_item_link_target=>'f?p=&APP_ID.:407:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header'
,p_list_text_01=>'Determine how users navigate within an application.'
,p_list_text_02=>'List'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4072595864965196479)
,p_list_item_display_sequence=>310
,p_list_item_link_text=>'PL/SQL Dynamic Content'
,p_static_id=>'pl-sql-dynamic-content'
,p_list_item_link_target=>'f?p=&APP_ID.:1908:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dynamic-content'
,p_list_text_01=>'Render HTML or text using the PL/SQL Web Toolkit.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2358781501308282571)
,p_list_item_display_sequence=>320
,p_list_item_link_text=>'Reflow Report'
,p_static_id=>'reflow-report'
,p_list_item_link_target=>'f?p=&APP_ID.:1710:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tablet'
,p_list_text_01=>'Display data vertically to save space when screen size becomes small.'
,p_list_text_02=>'Report'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4072596340147200843)
,p_list_item_display_sequence=>330
,p_list_item_link_text=>'Region Display Selector'
,p_static_id=>'region-display-selector'
,p_list_item_link_target=>'f?p=&APP_ID.:1923:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tabs'
,p_list_text_01=>'Show and hide controls for regions.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2823817925130103594)
,p_list_item_display_sequence=>350
,p_list_item_link_text=>'Standard'
,p_static_id=>'standard'
,p_list_item_link_target=>'f?p=&APP_ID.:1201:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header'
,p_list_text_01=>'Display widgets in a generic region template that can be heavily customized.'
,p_list_text_02=>'Region'
,p_list_text_03=>'SD'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4072596729004205628)
,p_list_item_display_sequence=>370
,p_list_item_link_text=>'Static Content'
,p_static_id=>'static-content'
,p_list_item_link_target=>'f?p=&APP_ID.:1905:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_list_text_01=>'Use HTML markup directly on the page.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4632901963353181646)
,p_list_item_display_sequence=>390
,p_list_item_link_text=>'Tabs Container'
,p_static_id=>'tabs-container'
,p_list_item_link_target=>'f?p=&APP_ID.:1907:&SESSION.:tab_list:&DEBUG.::::'
,p_list_item_icon=>'fa-tabs'
,p_list_text_01=>'Improve navigation, flow, and usability of pages in an application.'
,p_list_text_02=>'Region, List'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2823976987307609788)
,p_list_item_display_sequence=>400
,p_list_item_link_text=>'Timeline'
,p_static_id=>'timeline'
,p_list_item_link_target=>'f?p=&APP_ID.:3006:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clock-o'
,p_list_text_01=>'Display recent updates and interactions within an application.'
,p_list_text_02=>'Region'
,p_list_text_03=>'TL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2823820332741103598)
,p_list_item_display_sequence=>410
,p_list_item_link_text=>'Title Bar'
,p_static_id=>'title-bar'
,p_list_item_link_target=>'f?p=&APP_ID.:1207:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-breadcrumb'
,p_list_text_01=>'Group breadcrumbs, page title, and primary page actions at the top of the page.'
,p_list_text_02=>'Region'
,p_list_text_03=>'TB'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4072597240895210484)
,p_list_item_display_sequence=>420
,p_list_item_link_text=>'Tree'
,p_static_id=>'tree'
,p_list_item_link_target=>'f?p=&APP_ID.:1901:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tree-org'
,p_list_text_01=>'Perform hierarchical navigation control based on a SQL query.'
,p_list_text_02=>'Region'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2823974226991584420)
,p_list_item_display_sequence=>430
,p_list_item_link_text=>'Value Attribute Pairs'
,p_static_id=>'value-attribute-pairs'
,p_list_item_link_target=>'f?p=&APP_ID.:1403:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pause'
,p_list_text_01=>'Display attribute value / key value pairs with Row or Column based queries.'
,p_list_text_02=>'Report'
,p_list_text_03=>'VA'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2823826765346457687)
,p_list_item_display_sequence=>440
,p_list_item_link_text=>'Wizard'
,p_static_id=>'wizard'
,p_list_item_link_target=>'f?p=&APP_ID.:1208:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-magic'
,p_list_text_01=>'Contain the Wizard Progress List and forms using this region template.'
,p_list_text_02=>'Region, List, Page'
,p_list_text_03=>'WZ'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
