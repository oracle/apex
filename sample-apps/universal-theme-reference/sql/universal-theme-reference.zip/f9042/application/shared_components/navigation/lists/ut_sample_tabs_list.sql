prompt --application/shared_components/navigation/lists/ut_sample_tabs_list
begin
--   Manifest
--     LIST: UT - Sample Tabs List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4302175406745339863)
,p_name=>'UT - Sample Tabs List'
,p_static_id=>'ut-sample-tabs-list'
,p_version_scn=>'112802256'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4302175605497339864)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Tab 1'
,p_static_id=>'tab'
,p_list_item_link_target=>'javascript:void(0);'
,p_list_item_icon=>'fa-user'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'1907'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4302176079735339864)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Tab 2'
,p_static_id=>'tab-2'
,p_list_item_link_target=>'javascript:void(0);'
,p_list_item_icon=>'fa-heart-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4302176429774339864)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Tab 3'
,p_static_id=>'tab-3'
,p_list_item_link_target=>'javascript:void(0);'
,p_list_item_icon=>'fa-cloud'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
