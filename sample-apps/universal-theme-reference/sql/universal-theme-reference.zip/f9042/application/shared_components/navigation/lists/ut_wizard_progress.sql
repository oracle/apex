prompt --application/shared_components/navigation/lists/ut_wizard_progress
begin
--   Manifest
--     LIST: UT - Wizard Progress
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2577754628344096380)
,p_name=>'UT - Wizard Progress'
,p_static_id=>'ut-wizard-progress'
,p_version_scn=>'112802242'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2577754789897096380)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Step 1'
,p_static_id=>'step'
,p_list_item_icon=>'fa-check-circle'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2577756581318099929)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Step 2'
,p_static_id=>'step-2'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-cloud'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2577755152136096380)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Step 3'
,p_static_id=>'step-3'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-comment'
,p_list_item_current_type=>'ALWAYS'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2577756843343099929)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Step 4'
,p_static_id=>'step-4'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-dashboard'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp.component_end;
end;
/
