prompt --application/shared_components/navigation/lists/ut_sample_links_list
begin
--   Manifest
--     LIST: UT - Sample Links List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3922228009153550400)
,p_name=>'UT - Sample Links List'
,p_static_id=>'ut-sample-links-list'
,p_version_scn=>'112802244'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3922228224546550400)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Amet Incorporated'
,p_static_id=>'amet-incorporated'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-cloud'
,p_list_text_01=>'4'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3922229479811550401)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Cras Interdum Consulting'
,p_static_id=>'cras-interdum-consulting'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-envelope'
,p_list_text_01=>'431'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3922230272676550404)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Eros Nec Corporation'
,p_static_id=>'eros-nec-corporation'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-user'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3922229833125550402)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Felis Associates'
,p_static_id=>'felis-associates'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-dashboard'
,p_list_text_01=>'Pending'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3922228657824550401)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Ridiculus LLP'
,p_static_id=>'ridiculus-llp'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-comments'
,p_list_text_01=>'12'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3922229053078550401)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Tristique LLC'
,p_static_id=>'tristique-llc'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'4'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
