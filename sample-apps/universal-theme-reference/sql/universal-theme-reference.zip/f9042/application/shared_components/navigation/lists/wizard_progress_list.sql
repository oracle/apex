prompt --application/shared_components/navigation/lists/wizard_progress_list
begin
--   Manifest
--     LIST: Wizard Progress List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4302082424519661002)
,p_name=>'Wizard Progress List'
,p_static_id=>'wizard-progress-list'
,p_version_scn=>'112802256'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4302083493592661006)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Step 1'
,p_static_id=>'step'
,p_list_item_link_target=>'f?p=&APP_ID.:1920:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4302088366975661024)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Step 2'
,p_static_id=>'step-2'
,p_list_item_link_target=>'f?p=&APP_ID.:1921:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4302093850917661029)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Step 3'
,p_static_id=>'step-3'
,p_list_item_link_target=>'f?p=&APP_ID.:1922:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
