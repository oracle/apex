prompt --application/deployment/install/upgrade_add_map_airports
begin
--   Manifest
--     INSTALL: UPGRADE-Add Map Airports
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'alter session set nls_numeric_characters=''.,'';'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- create table'||wwv_flow.LF||
'--'||wwv_flow.LF||
'create table eba_ut_map_airpor';
wwv_flow_imp.g_varchar2_table(2) := 'ts ('||wwv_flow.LF||
'    id                     number not null primary key,'||wwv_flow.LF||
'    iata_code              varchar2(10)';
wwv_flow_imp.g_varchar2_table(3) := ','||wwv_flow.LF||
'    airport_type           varchar2(255),'||wwv_flow.LF||
'    airport_name           varchar2(255),'||wwv_flow.LF||
'    city      ';
wwv_flow_imp.g_varchar2_table(4) := '             varchar2(255),'||wwv_flow.LF||
'    state_name             varchar2(255),'||wwv_flow.LF||
'    activation_date        var';
wwv_flow_imp.g_varchar2_table(5) := 'char2(50),'||wwv_flow.LF||
'    activation_date_dt     date,'||wwv_flow.LF||
'    elevation              number,'||wwv_flow.LF||
'    dist_city_to_airp';
wwv_flow_imp.g_varchar2_table(6) := 'ort   number,'||wwv_flow.LF||
'    land_area_covered      number,'||wwv_flow.LF||
'    commercial_ops         number,'||wwv_flow.LF||
'    air_taxi_ops';
wwv_flow_imp.g_varchar2_table(7) := '           number,'||wwv_flow.LF||
'    geometry               mdsys.sdo_geometry )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'insert into eba_ut_map_airports';
wwv_flow_imp.g_varchar2_table(8) := ' (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevatio';
wwv_flow_imp.g_varchar2_table(9) := 'n,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (1568,''PHX'',''A';
wwv_flow_imp.g_varchar2_table(10) := 'IRPORT'',''PHOENIX SKY HARBOR INTL'',''PHOENIX'',''ARIZONA'',''APR-40'',to_date(''04/01/1940''),1135,3,3400,384';
wwv_flow_imp.g_varchar2_table(11) := '714,384714, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-112.01158, 33.43428, NULL), NULL, ';
wwv_flow_imp.g_varchar2_table(12) := 'NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,act';
wwv_flow_imp.g_varchar2_table(13) := 'ivation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_';
wwv_flow_imp.g_varchar2_table(14) := 'taxi_ops,geometry) values (2139,''LAX'',''AIRPORT'',''LOS ANGELES INTL'',''LOS ANGELES'',''CALIFORNIA'',''APR-4';
wwv_flow_imp.g_varchar2_table(15) := '0'',to_date(''04/01/1940''),128,9,3500,634515,634515, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TY';
wwv_flow_imp.g_varchar2_table(16) := 'PE (-118.40805, 33.9425, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport';
wwv_flow_imp.g_varchar2_table(17) := '_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport';
wwv_flow_imp.g_varchar2_table(18) := ',land_area_covered,commercial_ops,air_taxi_ops,geometry) values (2384,''SJC'',''AIRPORT'',''NORMAN Y MINE';
wwv_flow_imp.g_varchar2_table(19) := 'TA SAN JOSE INTL'',''SAN JOSE'',''CALIFORNIA'',''FEB-46'',to_date(''02/01/1946''),62,2,1050,138613,138613, MD';
wwv_flow_imp.g_varchar2_table(20) := 'SYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-121.92862, 37.36299, NULL), NULL, NULL ));'||wwv_flow.LF||
'inser';
wwv_flow_imp.g_varchar2_table(21) := 't into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,a';
wwv_flow_imp.g_varchar2_table(22) := 'ctivation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geome';
wwv_flow_imp.g_varchar2_table(23) := 'try) values (2376,''SFO'',''AIRPORT'',''SAN FRANCISCO INTL'',''SAN FRANCISCO'',''CALIFORNIA'',''APR-40'',to_date';
wwv_flow_imp.g_varchar2_table(24) := '(''04/01/1940''),13,8,5207,407153,407153, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-122.37';
wwv_flow_imp.g_varchar2_table(25) := '542, 37.61881, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airp';
wwv_flow_imp.g_varchar2_table(26) := 'ort_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area';
wwv_flow_imp.g_varchar2_table(27) := '_covered,commercial_ops,air_taxi_ops,geometry) values (2364,''SAN'',''AIRPORT'',''SAN DIEGO INTL'',''SAN DI';
wwv_flow_imp.g_varchar2_table(28) := 'EGO'',''CALIFORNIA'',''APR-40'',to_date(''04/01/1940''),17,2,663,203913,203913, MDSYS.SDO_GEOMETRY(2001, 43';
wwv_flow_imp.g_varchar2_table(29) := '26, MDSYS.SDO_POINT_TYPE (-117.18967, 32.73356, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airport';
wwv_flow_imp.g_varchar2_table(30) := 's (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevati';
wwv_flow_imp.g_varchar2_table(31) := 'on,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (2215,''OAK'',''';
wwv_flow_imp.g_varchar2_table(32) := 'AIRPORT'',''METROPOLITAN OAKLAND INTL'',''OAKLAND'',''CALIFORNIA'',''APR-40'',to_date(''04/01/1940''),9,4,2600,';
wwv_flow_imp.g_varchar2_table(33) := '132865,132865, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-122.22114, 37.72125, NULL), NUL';
wwv_flow_imp.g_varchar2_table(34) := 'L, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,';
wwv_flow_imp.g_varchar2_table(35) := 'activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,a';
wwv_flow_imp.g_varchar2_table(36) := 'ir_taxi_ops,geometry) values (2696,''DEN'',''AIRPORT'',''DENVER INTL'',''DENVER'',''COLORADO'',''AUG-93'',to_dat';
wwv_flow_imp.g_varchar2_table(37) := 'e(''08/01/1993''),5434,16,33531,462276,462276, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-1';
wwv_flow_imp.g_varchar2_table(38) := '04.67317, 39.86167, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type';
wwv_flow_imp.g_varchar2_table(39) := ',airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land';
wwv_flow_imp.g_varchar2_table(40) := '_area_covered,commercial_ops,air_taxi_ops,geometry) values (3150,''DCA'',''AIRPORT'',''RONALD REAGAN WASH';
wwv_flow_imp.g_varchar2_table(41) := 'INGTON NATIONAL'',''WASHINGTON'',''DIST. OF COLUMBIA'',''MAR-41'',to_date(''03/01/1941''),14,3,861,239759,239';
wwv_flow_imp.g_varchar2_table(42) := '759, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-77.03772, 38.85144, NULL), NULL, NULL ));';
wwv_flow_imp.g_varchar2_table(43) := ''||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_';
wwv_flow_imp.g_varchar2_table(44) := 'date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops';
wwv_flow_imp.g_varchar2_table(45) := ',geometry) values (3157,''IAD'',''AIRPORT'',''WASHINGTON DULLES INTL'',''WASHINGTON'',''DIST. OF COLUMBIA'',''N';
wwv_flow_imp.g_varchar2_table(46) := 'OV-62'',to_date(''11/01/1962''),313,20,13000,183677,183677, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_PO';
wwv_flow_imp.g_varchar2_table(47) := 'INT_TYPE (-77.45994, 38.94744, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,a';
wwv_flow_imp.g_varchar2_table(48) := 'irport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_a';
wwv_flow_imp.g_varchar2_table(49) := 'irport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (3719,''MIA'',''AIRPORT'',''MIAMI I';
wwv_flow_imp.g_varchar2_table(50) := 'NTL'',''MIAMI'',''FLORIDA'',''APR-40'',to_date(''04/01/1940''),9,8,3300,356198,356198, MDSYS.SDO_GEOMETRY(200';
wwv_flow_imp.g_varchar2_table(51) := '1, 4326, MDSYS.SDO_POINT_TYPE (-80.29012, 25.79536, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_air';
wwv_flow_imp.g_varchar2_table(52) := 'ports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,ele';
wwv_flow_imp.g_varchar2_table(53) := 'vation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (3836,''MC';
wwv_flow_imp.g_varchar2_table(54) := 'O'',''AIRPORT'',''ORLANDO INTL'',''ORLANDO'',''FLORIDA'',''JUN-41'',to_date(''06/01/1941''),96,6,12600,337510,337';
wwv_flow_imp.g_varchar2_table(55) := '510, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-81.309, 28.42939, NULL), NULL, NULL ));'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(56) := 'nsert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_da';
wwv_flow_imp.g_varchar2_table(57) := 'te,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,g';
wwv_flow_imp.g_varchar2_table(58) := 'eometry) values (3410,''FLL'',''AIRPORT'',''FORT LAUDERDALE/HOLLYWOOD INTL'',''FORT LAUDERDALE'',''FLORIDA'',''';
wwv_flow_imp.g_varchar2_table(59) := 'APR-40'',to_date(''04/01/1940''),65,3,1380,288866,288866, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POIN';
wwv_flow_imp.g_varchar2_table(60) := 'T_TYPE (-80.14969, 26.07167, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,air';
wwv_flow_imp.g_varchar2_table(61) := 'port_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_air';
wwv_flow_imp.g_varchar2_table(62) := 'port,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (3993,''TPA'',''AIRPORT'',''TAMPA INT';
wwv_flow_imp.g_varchar2_table(63) := 'L'',''TAMPA'',''FLORIDA'',''APR-40'',to_date(''04/01/1940''),26,6,3300,170756,170756, MDSYS.SDO_GEOMETRY(2001';
wwv_flow_imp.g_varchar2_table(64) := ', 4326, MDSYS.SDO_POINT_TYPE (-82.53325, 27.97547, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airp';
wwv_flow_imp.g_varchar2_table(65) := 'orts (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elev';
wwv_flow_imp.g_varchar2_table(66) := 'ation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (4118,''ATL';
wwv_flow_imp.g_varchar2_table(67) := ''',''AIRPORT'',''HARTSFIELD - JACKSON ATLANTA INTL'',''ATLANTA'',''GEORGIA'',''SEP-42'',to_date(''09/01/1942''),1';
wwv_flow_imp.g_varchar2_table(68) := '026,7,4700,723956,723956, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-84.42786, 33.6367, N';
wwv_flow_imp.g_varchar2_table(69) := 'ULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,st';
wwv_flow_imp.g_varchar2_table(70) := 'ate_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commerc';
wwv_flow_imp.g_varchar2_table(71) := 'ial_ops,air_taxi_ops,geometry) values (4562,''HNL'',''AIRPORT'',''DANIEL K INOUYE INTL'',''HONOLULU'',''HAWAI';
wwv_flow_imp.g_varchar2_table(72) := 'I'',''FEB-38'',to_date(''02/01/1938''),13,3,4220,159726,159726, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(73) := 'POINT_TYPE (-157.92026, 21.31783, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_cod';
wwv_flow_imp.g_varchar2_table(74) := 'e,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_t';
wwv_flow_imp.g_varchar2_table(75) := 'o_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (5291,''MDW'',''AIRPORT'',''CHIC';
wwv_flow_imp.g_varchar2_table(76) := 'AGO MIDWAY INTL'',''CHICAGO'',''ILLINOIS'',''APR-40'',to_date(''04/01/1940''),620,9,650,181702,181702, MDSYS.';
wwv_flow_imp.g_varchar2_table(77) := 'SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-87.75242, 41.78597, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert int';
wwv_flow_imp.g_varchar2_table(78) := 'o eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activa';
wwv_flow_imp.g_varchar2_table(79) := 'tion_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) ';
wwv_flow_imp.g_varchar2_table(80) := 'values (5292,''ORD'',''AIRPORT'',''CHICAGO O''''HARE INTL'',''CHICAGO'',''ILLINOIS'',''FEB-44'',to_date(''02/01/194';
wwv_flow_imp.g_varchar2_table(81) := '4''),680,14,7627,652622,652622, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-87.9066, 41.974';
wwv_flow_imp.g_varchar2_table(82) := '52, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,ci';
wwv_flow_imp.g_varchar2_table(83) := 'ty,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,co';
wwv_flow_imp.g_varchar2_table(84) := 'mmercial_ops,air_taxi_ops,geometry) values (6120,''IND'',''AIRPORT'',''INDIANAPOLIS INTL'',''INDIANAPOLIS'',';
wwv_flow_imp.g_varchar2_table(85) := '''INDIANA'',''APR-40'',to_date(''04/01/1940''),796,7,7700,127309,127309, MDSYS.SDO_GEOMETRY(2001, 4326, MD';
wwv_flow_imp.g_varchar2_table(86) := 'SYS.SDO_POINT_TYPE (-86.29464, 39.71731, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,i';
wwv_flow_imp.g_varchar2_table(87) := 'ata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist';
wwv_flow_imp.g_varchar2_table(88) := '_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (6814,''CVG'',''AIRPORT';
wwv_flow_imp.g_varchar2_table(89) := ''',''CINCINNATI/NORTHERN KENTUCKY INTL'',''COVINGTON'',''KENTUCKY'',''DEC-44'',to_date(''12/01/1944''),896,8,70';
wwv_flow_imp.g_varchar2_table(90) := '00,130690,130690, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-84.66782, 39.04884, NULL), N';
wwv_flow_imp.g_varchar2_table(91) := 'ULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_nam';
wwv_flow_imp.g_varchar2_table(92) := 'e,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops';
wwv_flow_imp.g_varchar2_table(93) := ',air_taxi_ops,geometry) values (6911,''SDF'',''AIRPORT'',''LOUISVILLE MUHAMMAD ALI INTL'',''LOUISVILLE'',''KE';
wwv_flow_imp.g_varchar2_table(94) := 'NTUCKY'',''NOV-42'',to_date(''11/01/1942''),501,4,1200,132315,132315, MDSYS.SDO_GEOMETRY(2001, 4326, MDSY';
wwv_flow_imp.g_varchar2_table(95) := 'S.SDO_POINT_TYPE (-85.7365, 38.17409, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata';
wwv_flow_imp.g_varchar2_table(96) := '_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_ci';
wwv_flow_imp.g_varchar2_table(97) := 'ty_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (7384,''MSY'',''AIRPORT'',''';
wwv_flow_imp.g_varchar2_table(98) := 'LOUIS ARMSTRONG NEW ORLEANS INTL'',''NEW ORLEANS'',''LOUISIANA'',''OCT-44'',to_date(''10/01/1944''),4,10,1500';
wwv_flow_imp.g_varchar2_table(99) := ',117292,117292, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-90.25903, 29.99328, NULL), NUL';
wwv_flow_imp.g_varchar2_table(100) := 'L, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,';
wwv_flow_imp.g_varchar2_table(101) := 'activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,a';
wwv_flow_imp.g_varchar2_table(102) := 'ir_taxi_ops,geometry) values (7775,''BWI'',''AIRPORT'',''BALTIMORE/WASHINGTON INTL THURGOOD MARSHALL'',''BA';
wwv_flow_imp.g_varchar2_table(103) := 'LTIMORE'',''MARYLAND'',''JAN-50'',to_date(''01/01/1950''),143,9,3160,221775,221775, MDSYS.SDO_GEOMETRY(2001';
wwv_flow_imp.g_varchar2_table(104) := ', 4326, MDSYS.SDO_POINT_TYPE (-76.66899, 39.17573, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airp';
wwv_flow_imp.g_varchar2_table(105) := 'orts (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elev';
wwv_flow_imp.g_varchar2_table(106) := 'ation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (7551,''BOS';
wwv_flow_imp.g_varchar2_table(107) := ''',''AIRPORT'',''GENERAL EDWARD LAWRENCE LOGAN INTL'',''BOSTON'',''MASSACHUSETTS'',''APR-40'',to_date(''04/01/19';
wwv_flow_imp.g_varchar2_table(108) := '40''),19,1,2384,317685,317685, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-71.00639, 42.362';
wwv_flow_imp.g_varchar2_table(109) := '94, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,ci';
wwv_flow_imp.g_varchar2_table(110) := 'ty,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,co';
wwv_flow_imp.g_varchar2_table(111) := 'mmercial_ops,air_taxi_ops,geometry) values (8303,''DTW'',''AIRPORT'',''DETROIT METROPOLITAN WAYNE COUNTY''';
wwv_flow_imp.g_varchar2_table(112) := ',''DETROIT'',''MICHIGAN'',''APR-40'',to_date(''04/01/1940''),645,15,4850,315995,315995, MDSYS.SDO_GEOMETRY(2';
wwv_flow_imp.g_varchar2_table(113) := '001, 4326, MDSYS.SDO_POINT_TYPE (-83.35339, 42.21244, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_a';
wwv_flow_imp.g_varchar2_table(114) := 'irports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,e';
wwv_flow_imp.g_varchar2_table(115) := 'levation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (8953,''';
wwv_flow_imp.g_varchar2_table(116) := 'MSP'',''AIRPORT'',''MINNEAPOLIS-ST PAUL INTL/WOLD-CHAMBERLAIN'',''MINNEAPOLIS'',''MINNESOTA'',''APR-40'',to_dat';
wwv_flow_imp.g_varchar2_table(117) := 'e(''04/01/1940''),842,6,2930,372138,372138, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-93.2';
wwv_flow_imp.g_varchar2_table(118) := '2178, 44.88197, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,air';
wwv_flow_imp.g_varchar2_table(119) := 'port_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_are';
wwv_flow_imp.g_varchar2_table(120) := 'a_covered,commercial_ops,air_taxi_ops,geometry) values (9372,''MCI'',''AIRPORT'',''KANSAS CITY INTL'',''KAN';
wwv_flow_imp.g_varchar2_table(121) := 'SAS CITY'',''MISSOURI'',''MAY-56'',to_date(''05/01/1956''),1027,15,10680,107375,107375, MDSYS.SDO_GEOMETRY(';
wwv_flow_imp.g_varchar2_table(122) := '2001, 4326, MDSYS.SDO_POINT_TYPE (-94.71389, 39.29761, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_';
wwv_flow_imp.g_varchar2_table(123) := 'airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,';
wwv_flow_imp.g_varchar2_table(124) := 'elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (9546,';
wwv_flow_imp.g_varchar2_table(125) := '''STL'',''AIRPORT'',''ST LOUIS LAMBERT INTL'',''ST LOUIS'',''MISSOURI'',''APR-40'',to_date(''04/01/1940''),618,10,';
wwv_flow_imp.g_varchar2_table(126) := '2800,139321,139321, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-90.37003, 38.7487, NULL), ';
wwv_flow_imp.g_varchar2_table(127) := 'NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_na';
wwv_flow_imp.g_varchar2_table(128) := 'me,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_op';
wwv_flow_imp.g_varchar2_table(129) := 's,air_taxi_ops,geometry) values (11943,''LAS'',''AIRPORT'',''MC CARRAN INTL'',''LAS VEGAS'',''NEVADA'',''JAN-47';
wwv_flow_imp.g_varchar2_table(130) := ''',to_date(''01/01/1947''),2181,5,2800,366704,366704, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TY';
wwv_flow_imp.g_varchar2_table(131) := 'PE (-115.15223, 36.08004, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airpor';
wwv_flow_imp.g_varchar2_table(132) := 't_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airpor';
wwv_flow_imp.g_varchar2_table(133) := 't,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (11574,''EWR'',''AIRPORT'',''NEWARK LIBE';
wwv_flow_imp.g_varchar2_table(134) := 'RTY INTL'',''NEWARK'',''NEW JERSEY'',''NOV-39'',to_date(''11/01/1939''),17,3,2027,351188,351188, MDSYS.SDO_GE';
wwv_flow_imp.g_varchar2_table(135) := 'OMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-74.16869, 40.69248, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_';
wwv_flow_imp.g_varchar2_table(136) := 'ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_d';
wwv_flow_imp.g_varchar2_table(137) := 'ate_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values';
wwv_flow_imp.g_varchar2_table(138) := ' (12354,''JFK'',''AIRPORT'',''JOHN F KENNEDY INTL'',''NEW YORK'',''NEW YORK'',''JAN-39'',to_date(''01/01/1939''),1';
wwv_flow_imp.g_varchar2_table(139) := '3,13,5200,423230,423230, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-73.77869, 40.63993, N';
wwv_flow_imp.g_varchar2_table(140) := 'ULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,st';
wwv_flow_imp.g_varchar2_table(141) := 'ate_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commerc';
wwv_flow_imp.g_varchar2_table(142) := 'ial_ops,air_taxi_ops,geometry) values (12355,''LGA'',''AIRPORT'',''LAGUARDIA'',''NEW YORK'',''NEW YORK'','''',to';
wwv_flow_imp.g_varchar2_table(143) := '_date(''''),21,4,680,317955,317955, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-73.87261, 40';
wwv_flow_imp.g_varchar2_table(144) := '.77725, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_nam';
wwv_flow_imp.g_varchar2_table(145) := 'e,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covere';
wwv_flow_imp.g_varchar2_table(146) := 'd,commercial_ops,air_taxi_ops,geometry) values (10274,''CLT'',''AIRPORT'',''CHARLOTTE/DOUGLAS INTL'',''CHAR';
wwv_flow_imp.g_varchar2_table(147) := 'LOTTE'',''NORTH CAROLINA'',''SEP-37'',to_date(''09/01/1937''),748,5,5558,454153,454153, MDSYS.SDO_GEOMETRY(';
wwv_flow_imp.g_varchar2_table(148) := '2001, 4326, MDSYS.SDO_POINT_TYPE (-80.94906, 35.21375, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_';
wwv_flow_imp.g_varchar2_table(149) := 'airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,';
wwv_flow_imp.g_varchar2_table(150) := 'elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (10554';
wwv_flow_imp.g_varchar2_table(151) := ',''RDU'',''AIRPORT'',''RALEIGH-DURHAM INTL'',''RALEIGH/DURHAM'',''NORTH CAROLINA'',''APR-43'',to_date(''04/01/194';
wwv_flow_imp.g_varchar2_table(152) := '3''),435,9,5000,106157,106157, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-78.78747, 35.877';
wwv_flow_imp.g_varchar2_table(153) := '64, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,ci';
wwv_flow_imp.g_varchar2_table(154) := 'ty,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,co';
wwv_flow_imp.g_varchar2_table(155) := 'mmercial_ops,air_taxi_ops,geometry) values (13985,''PDX'',''AIRPORT'',''PORTLAND INTL'',''PORTLAND'',''OREGON';
wwv_flow_imp.g_varchar2_table(156) := ''',''MAR-40'',to_date(''03/01/1940''),31,4,3000,195797,195797, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_P';
wwv_flow_imp.g_varchar2_table(157) := 'OINT_TYPE (-122.59687, 45.58871, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code';
wwv_flow_imp.g_varchar2_table(158) := ',airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to';
wwv_flow_imp.g_varchar2_table(159) := '_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (14632,''PHL'',''AIRPORT'',''PHIL';
wwv_flow_imp.g_varchar2_table(160) := 'ADELPHIA INTL'',''PHILADELPHIA'',''PENNSYLVANIA'',''OCT-40'',to_date(''10/01/1940''),36,5,2302,259799,259799,';
wwv_flow_imp.g_varchar2_table(161) := ' MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-75.24066, 39.87208, NULL), NULL, NULL ));'||wwv_flow.LF||
'ins';
wwv_flow_imp.g_varchar2_table(162) := 'ert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date';
wwv_flow_imp.g_varchar2_table(163) := ',activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geo';
wwv_flow_imp.g_varchar2_table(164) := 'metry) values (14658,''PIT'',''AIRPORT'',''PITTSBURGH INTL'',''PITTSBURGH'',''PENNSYLVANIA'',''MAR-44'',to_date(';
wwv_flow_imp.g_varchar2_table(165) := '''03/01/1944''),1203,12,10000,100765,100765, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-80.';
wwv_flow_imp.g_varchar2_table(166) := '23269, 40.49142, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,ai';
wwv_flow_imp.g_varchar2_table(167) := 'rport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_ar';
wwv_flow_imp.g_varchar2_table(168) := 'ea_covered,commercial_ops,air_taxi_ops,geometry) values (15520,''MEM'',''AIRPORT'',''MEMPHIS INTL'',''MEMPH';
wwv_flow_imp.g_varchar2_table(169) := 'IS'',''TENNESSEE'',''AUG-37'',to_date(''08/01/1937''),341,3,3900,204061,204061, MDSYS.SDO_GEOMETRY(2001, 43';
wwv_flow_imp.g_varchar2_table(170) := '26, MDSYS.SDO_POINT_TYPE (-89.97668, 35.04241, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports';
wwv_flow_imp.g_varchar2_table(171) := ' (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevatio';
wwv_flow_imp.g_varchar2_table(172) := 'n,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (15542,''BNA'',''';
wwv_flow_imp.g_varchar2_table(173) := 'AIRPORT'',''NASHVILLE INTL'',''NASHVILLE'',''TENNESSEE'',''DEC-37'',to_date(''12/01/1937''),599,5,3900,147743,1';
wwv_flow_imp.g_varchar2_table(174) := '47743, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-86.67818, 36.12447, NULL), NULL, NULL )';
wwv_flow_imp.g_varchar2_table(175) := ');'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activatio';
wwv_flow_imp.g_varchar2_table(176) := 'n_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_o';
wwv_flow_imp.g_varchar2_table(177) := 'ps,geometry) values (16147,''DFW'',''AIRPORT'',''DALLAS-FORT WORTH INTL'',''DALLAS-FORT WORTH'',''TEXAS'',''JAN';
wwv_flow_imp.g_varchar2_table(178) := '-74'',to_date(''01/01/1974''),607,12,17207,615799,615799, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POIN';
wwv_flow_imp.g_varchar2_table(179) := 'T_TYPE (-97.03769, 32.89723, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,air';
wwv_flow_imp.g_varchar2_table(180) := 'port_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_air';
wwv_flow_imp.g_varchar2_table(181) := 'port,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (16620,''IAH'',''AIRPORT'',''GEORGE B';
wwv_flow_imp.g_varchar2_table(182) := 'USH INTERCONTINENTAL/HOUSTON'',''HOUSTON'',''TEXAS'',''JAN-63'',to_date(''01/01/1963''),96,15,10000,362947,36';
wwv_flow_imp.g_varchar2_table(183) := '2947, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-95.34144, 29.98444, NULL), NULL, NULL ))';
wwv_flow_imp.g_varchar2_table(184) := ';'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation';
wwv_flow_imp.g_varchar2_table(185) := '_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_op';
wwv_flow_imp.g_varchar2_table(186) := 's,geometry) values (16619,''HOU'',''AIRPORT'',''WILLIAM P HOBBY'',''HOUSTON'',''TEXAS'',''JAN-39'',to_date(''01/0';
wwv_flow_imp.g_varchar2_table(187) := '1/1939''),46,8,1304,123823,123823, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-95.27889, 29';
wwv_flow_imp.g_varchar2_table(188) := '.64542, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_nam';
wwv_flow_imp.g_varchar2_table(189) := 'e,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covere';
wwv_flow_imp.g_varchar2_table(190) := 'd,commercial_ops,air_taxi_ops,geometry) values (16148,''DAL'',''AIRPORT'',''DALLAS LOVE FIELD'',''DALLAS'',''';
wwv_flow_imp.g_varchar2_table(191) := 'TEXAS'',''OCT-37'',to_date(''10/01/1937''),487,5,1300,144308,144308, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS';
wwv_flow_imp.g_varchar2_table(192) := '.SDO_POINT_TYPE (-96.85088, 32.84594, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata';
wwv_flow_imp.g_varchar2_table(193) := '_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_ci';
wwv_flow_imp.g_varchar2_table(194) := 'ty_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (15748,''AUS'',''AIRPORT'',';
wwv_flow_imp.g_varchar2_table(195) := '''AUSTIN-BERGSTROM INTL'',''AUSTIN'',''TEXAS'',''JUL-43'',to_date(''07/01/1943''),542,5,4242,140426,140426, MD';
wwv_flow_imp.g_varchar2_table(196) := 'SYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-97.66988, 30.19453, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(197) := ' into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,ac';
wwv_flow_imp.g_varchar2_table(198) := 'tivation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geomet';
wwv_flow_imp.g_varchar2_table(199) := 'ry) values (17818,''SLC'',''AIRPORT'',''SALT LAKE CITY INTL'',''SALT LAKE CITY'',''UTAH'',''NOV-38'',to_date(''11';
wwv_flow_imp.g_varchar2_table(200) := '/01/1938''),4231,3,7700,231232,231232, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-111.9777';
wwv_flow_imp.g_varchar2_table(201) := '7, 40.78839, NULL), NULL, NULL ));'||wwv_flow.LF||
'insert into eba_ut_map_airports (id,iata_code,airport_type,airpor';
wwv_flow_imp.g_varchar2_table(202) := 't_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_c';
wwv_flow_imp.g_varchar2_table(203) := 'overed,commercial_ops,air_taxi_ops,geometry) values (18776,''SEA'',''AIRPORT'',''SEATTLE-TACOMA INTL'',''SE';
wwv_flow_imp.g_varchar2_table(204) := 'ATTLE'',''WASHINGTON'',''JAN-44'',to_date(''01/01/1944''),432,10,2500,427170,427170, MDSYS.SDO_GEOMETRY(200';
wwv_flow_imp.g_varchar2_table(205) := '1, 4326, MDSYS.SDO_POINT_TYPE (-122.31178, 47.44989, NULL), NULL, NULL ));';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(814273116687709321)
,p_install_id=>wwv_flow_imp.id(4040874964717609762)
,p_name=>'Add Map Airports'
,p_sequence=>20
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>'select null from user_tables where table_name = ''EBA_UT_MAP_AIRPORTS'''
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
