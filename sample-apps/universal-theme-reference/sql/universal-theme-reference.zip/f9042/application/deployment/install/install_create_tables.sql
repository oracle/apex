prompt --application/deployment/install/install_create_tables
begin
--   Manifest
--     INSTALL: INSTALL-Create Tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'ALTER SESSION SET PLSCOPE_SETTINGS = ''IDENTIFIERS:NONE'';'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table  EBA_UT_chart_projects ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2) := ' id                   number         not null'||wwv_flow.LF||
'                                        constraint EBA';
wwv_flow_imp.g_varchar2_table(3) := '_UT_charts_proj_pk'||wwv_flow.LF||
'                                        primary key,'||wwv_flow.LF||
'    project              var';
wwv_flow_imp.g_varchar2_table(4) := 'char2(30)   not null,'||wwv_flow.LF||
'    row_version_number   number,'||wwv_flow.LF||
'    created              timestamp,'||wwv_flow.LF||
'    creat';
wwv_flow_imp.g_varchar2_table(5) := 'ed_by           varchar2(255),'||wwv_flow.LF||
'    updated              timestamp,'||wwv_flow.LF||
'    updated_by           varchar2';
wwv_flow_imp.g_varchar2_table(6) := '(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'REM EBA_UT_chart_tasks    '||wwv_flow.LF||
'create table  EBA_UT_chart_tasks ('||wwv_flow.LF||
'    id                  ';
wwv_flow_imp.g_varchar2_table(7) := '     number         not null'||wwv_flow.LF||
'                                            constraint EBA_UT_chart_tas';
wwv_flow_imp.g_varchar2_table(8) := 'ks_pk'||wwv_flow.LF||
'                                            primary key,'||wwv_flow.LF||
'    project                  number  ';
wwv_flow_imp.g_varchar2_table(9) := '       constraint EBA_UT_chart_tasks_fk'||wwv_flow.LF||
'                                            references EBA_U';
wwv_flow_imp.g_varchar2_table(10) := 'T_chart_projects on delete cascade,'||wwv_flow.LF||
'    parent_task              number,'||wwv_flow.LF||
'    task_name              ';
wwv_flow_imp.g_varchar2_table(11) := '  varchar2(255),'||wwv_flow.LF||
'    row_version_number       number,'||wwv_flow.LF||
'    start_date               date,'||wwv_flow.LF||
'    end_dat';
wwv_flow_imp.g_varchar2_table(12) := 'e                 date,'||wwv_flow.LF||
'    status                   varchar2(30),'||wwv_flow.LF||
'    assigned_to              varc';
wwv_flow_imp.g_varchar2_table(13) := 'har2(30),'||wwv_flow.LF||
'    cost                     number,'||wwv_flow.LF||
'    budget                   number,'||wwv_flow.LF||
'    created     ';
wwv_flow_imp.g_varchar2_table(14) := '             timestamp,'||wwv_flow.LF||
'    created_by               varchar2(255),'||wwv_flow.LF||
'    updated                  tim';
wwv_flow_imp.g_varchar2_table(15) := 'estamp,'||wwv_flow.LF||
'    updated_by               varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index EBA_UT_chart_tasks_idx1 on E';
wwv_flow_imp.g_varchar2_table(16) := 'BA_UT_chart_tasks (project);'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_EBA_UT_chart_proj '||wwv_flow.LF||
'   before insert o';
wwv_flow_imp.g_varchar2_table(17) := 'r update on EBA_UT_chart_projects'||wwv_flow.LF||
'   for each row '||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select ';
wwv_flow_imp.g_varchar2_table(18) := 'to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if in';
wwv_flow_imp.g_varchar2_table(19) := 'serting then'||wwv_flow.LF||
'       :new.created := localtimestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,us';
wwv_flow_imp.g_varchar2_table(20) := 'er);'||wwv_flow.LF||
'       :new.updated := localtimestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(21) := 'end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := localtimestamp;'||wwv_flow.LF||
'       :new.updated_';
wwv_flow_imp.g_varchar2_table(22) := 'by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.row_version_number := 1';
wwv_flow_imp.g_varchar2_table(23) := ';'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   en';
wwv_flow_imp.g_varchar2_table(24) := 'd if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigger biu_EBA_UT_chart_proj enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'create or replace trigger biu_EB';
wwv_flow_imp.g_varchar2_table(25) := 'A_UT_chart_tasks'||wwv_flow.LF||
'   before insert or update on EBA_UT_chart_tasks'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'   if :new';
wwv_flow_imp.g_varchar2_table(26) := '."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id';
wwv_flow_imp.g_varchar2_table(27) := ' from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := localtimestamp;'||wwv_flow.LF||
'       :new.creat';
wwv_flow_imp.g_varchar2_table(28) := 'ed_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := localtimestamp;'||wwv_flow.LF||
'       :new.updated_by :=';
wwv_flow_imp.g_varchar2_table(29) := ' nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := local';
wwv_flow_imp.g_varchar2_table(30) := 'timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(31) := '   :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.r';
wwv_flow_imp.g_varchar2_table(32) := 'ow_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigger biu_EBA_UT_chart_tasks enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'crea';
wwv_flow_imp.g_varchar2_table(33) := 'te table eba_ut_demo_cards ('||wwv_flow.LF||
'    id                             number               not null'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(34) := '                                                  constraint eba_ut_demo_cards_id_pk'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(35) := '                                         primary key,'||wwv_flow.LF||
'    category                       varchar2(25';
wwv_flow_imp.g_varchar2_table(36) := '5 char)   not null,'||wwv_flow.LF||
'    title                          varchar2(255 char)   not null,'||wwv_flow.LF||
'    subtitle  ';
wwv_flow_imp.g_varchar2_table(37) := '                     varchar2(255 char)   not null,'||wwv_flow.LF||
'    body                           varchar2(4000';
wwv_flow_imp.g_varchar2_table(38) := ' char)  not null,'||wwv_flow.LF||
'    secondary_body                 varchar2(4000 char),'||wwv_flow.LF||
'    icon_class            ';
wwv_flow_imp.g_varchar2_table(39) := '         varchar2(255 char),'||wwv_flow.LF||
'    badge                          varchar2(255 char),'||wwv_flow.LF||
'    image_url   ';
wwv_flow_imp.g_varchar2_table(40) := '                   varchar2(255 char)   not null,'||wwv_flow.LF||
'    start_date                     timestamp with ';
wwv_flow_imp.g_varchar2_table(41) := 'time zone,'||wwv_flow.LF||
'    end_date                       timestamp with time zone'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigge';
wwv_flow_imp.g_varchar2_table(42) := 'r biu_eba_ut_demo_cards'||wwv_flow.LF||
'   before insert or update on eba_ut_demo_cards'||wwv_flow.LF||
'   for each row '||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(43) := 'if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into ';
wwv_flow_imp.g_varchar2_table(44) := ':new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger biu_eba_ut_demo_cards enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_';
wwv_flow_imp.g_varchar2_table(45) := 'UT_chart_projects (ID,PROJECT) values (1,''Maintain Support Systems'');'||wwv_flow.LF||
'insert into EBA_UT_chart_proje';
wwv_flow_imp.g_varchar2_table(46) := 'cts (ID,PROJECT) values (2,''Load Software'');'||wwv_flow.LF||
'insert into EBA_UT_chart_projects (ID,PROJECT) values (';
wwv_flow_imp.g_varchar2_table(47) := '3,''Email Integration'');'||wwv_flow.LF||
'insert into EBA_UT_chart_projects (ID,PROJECT) values (4,''Documentation'');'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(48) := 'nsert into EBA_UT_chart_projects (ID,PROJECT) values (5,''Training'');'||wwv_flow.LF||
'insert into EBA_UT_chart_projec';
wwv_flow_imp.g_varchar2_table(49) := 'ts (ID,PROJECT) values (6,''Bug Tracker'');'||wwv_flow.LF||
'insert into EBA_UT_chart_projects (ID,PROJECT) values (7,''';
wwv_flow_imp.g_varchar2_table(50) := 'Migrate Old Systems'');'||wwv_flow.LF||
'insert into EBA_UT_chart_projects (ID,PROJECT) values (8,''Software Projects T';
wwv_flow_imp.g_varchar2_table(51) := 'racking'');'||wwv_flow.LF||
'insert into EBA_UT_chart_projects (ID,PROJECT) values (9,''Public Website'');'||wwv_flow.LF||
'insert into E';
wwv_flow_imp.g_varchar2_table(52) := 'BA_UT_chart_projects (ID,PROJECT) values (10,''Early Adopter Release'');'||wwv_flow.LF||
'insert into EBA_UT_chart_proj';
wwv_flow_imp.g_varchar2_table(53) := 'ects (ID,PROJECT) values (11,''Environment Configuration'');'||wwv_flow.LF||
'insert into EBA_UT_chart_projects (ID,PRO';
wwv_flow_imp.g_varchar2_table(54) := 'JECT) values (12,''Customer Satisfaction Survey'');'||wwv_flow.LF||
'insert into EBA_UT_chart_projects (ID,PROJECT) val';
wwv_flow_imp.g_varchar2_table(55) := 'ues (13,''Convert Excel Spreadsheet'');'||wwv_flow.LF||
'insert into EBA_UT_chart_projects (ID,PROJECT) values (14,''Upg';
wwv_flow_imp.g_varchar2_table(56) := 'rade Equipment'');'||wwv_flow.LF||
'    '||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE';
wwv_flow_imp.g_varchar2_table(57) := ',STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (74,14,''Decommission servers'',to_date(''01-02-12''';
wwv_flow_imp.g_varchar2_table(58) := ',''DD-MM-RR''),to_date(''30-04-12'',''DD-MM-RR''),''Pending'',''Al Bines'',0,500,null);'||wwv_flow.LF||
'    insert into EBA_UT';
wwv_flow_imp.g_varchar2_table(59) := '_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) v';
wwv_flow_imp.g_varchar2_table(60) := 'alues (75,6,''Measure effectiveness of improved QA'',to_date(''01-02-12'',''DD-MM-RR''),to_date(''02-03-12''';
wwv_flow_imp.g_varchar2_table(61) := ',''DD-MM-RR''),''Pending'',''Myra Sutcliff'',0,1500,18);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TA';
wwv_flow_imp.g_varchar2_table(62) := 'SK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (76,10,''Response to C';
wwv_flow_imp.g_varchar2_table(63) := 'ustomer Feedback'',to_date(''01-02-12'',''DD-MM-RR''),to_date(''25-05-12'',''DD-MM-RR''),''Pending'',''Russ Saun';
wwv_flow_imp.g_varchar2_table(64) := 'ders'',0,6000,33);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATU';
wwv_flow_imp.g_varchar2_table(65) := 'S,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (77,10,''User acceptance testing'',to_date(''16-02-12'',''D';
wwv_flow_imp.g_varchar2_table(66) := 'D-MM-RR''),to_date(''20-05-12'',''DD-MM-RR''),''Pending'',''Russ Saunders'',0,2500,33);'||wwv_flow.LF||
'    insert into EBA_U';
wwv_flow_imp.g_varchar2_table(67) := 'T_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) ';
wwv_flow_imp.g_varchar2_table(68) := 'values (78,10,''End-user Training'',to_date(''20-03-12'',''DD-MM-RR''),to_date(''01-06-12'',''DD-MM-RR''),''Pen';
wwv_flow_imp.g_varchar2_table(69) := 'ding'',''Myra Sutcliff'',0,2500,79);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DAT';
wwv_flow_imp.g_varchar2_table(70) := 'E,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (79,10,''Rollout sample applications'',t';
wwv_flow_imp.g_varchar2_table(71) := 'o_date(''23-05-12'',''DD-MM-RR''),to_date(''03-06-12'',''DD-MM-RR''),''Pending'',''Pam King'',0,500,32);'||wwv_flow.LF||
'    ins';
wwv_flow_imp.g_varchar2_table(72) := 'ert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET';
wwv_flow_imp.g_varchar2_table(73) := ',PARENT_TASK) values (72,14,''Installation'',to_date(''03-02-12'',''DD-MM-RR''),to_date(''04-03-12'',''DD-MM-';
wwv_flow_imp.g_varchar2_table(74) := 'RR''),''Pending'',''Mark Nile'',0,1500,67);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,STAR';
wwv_flow_imp.g_varchar2_table(75) := 'T_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (73,14,''Notify users'',to_date(''06';
wwv_flow_imp.g_varchar2_table(76) := '-03-12'',''DD-MM-RR''),to_date(''09-03-12'',''DD-MM-RR''),''Pending'',''Mark Nile'',0,200,67);'||wwv_flow.LF||
'    insert into ';
wwv_flow_imp.g_varchar2_table(77) := 'EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_T';
wwv_flow_imp.g_varchar2_table(78) := 'ASK) values (34,10,''Plan production release schedule'',to_date(''22-12-11'',''DD-MM-RR''),to_date(''22-12-';
wwv_flow_imp.g_varchar2_table(79) := '11'',''DD-MM-RR''),''Closed'',''Pam King'',100,100,32);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK';
wwv_flow_imp.g_varchar2_table(80) := '_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (37,12,''Complete questi';
wwv_flow_imp.g_varchar2_table(81) := 'onnaire'',to_date(''18-12-11'',''DD-MM-RR''),to_date(''01-01-11'',''DD-MM-RR''),''On-Hold'',''Irene Jones'',1200,';
wwv_flow_imp.g_varchar2_table(82) := '800,38);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNE';
wwv_flow_imp.g_varchar2_table(83) := 'D_TO,COST,BUDGET,PARENT_TASK) values (59,11,''Select servers for Development, Test, Production'',to_da';
wwv_flow_imp.g_varchar2_table(84) := 'te(''03-11-11'',''DD-MM-RR''),to_date(''08-11-11'',''DD-MM-RR''),''Closed'',''James Cassidy'',200,600,61);'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(85) := 'nsert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDG';
wwv_flow_imp.g_varchar2_table(86) := 'ET,PARENT_TASK) values (3,1,''HR Support Systems'',to_date(''01-11-11'',''DD-MM-RR''),to_date(''12-03-12'',''';
wwv_flow_imp.g_varchar2_table(87) := 'DD-MM-RR''),''Closed'',''Al Bines'',300,500,null);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NA';
wwv_flow_imp.g_varchar2_table(88) := 'ME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (1,1,''HR software upgrades';
wwv_flow_imp.g_varchar2_table(89) := ''',to_date(''01-11-11'',''DD-MM-RR''),to_date(''27-02-12'',''DD-MM-RR''),''On-Hold'',''Pam King'',8000,7000,3);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(90) := '   insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,';
wwv_flow_imp.g_varchar2_table(91) := 'BUDGET,PARENT_TASK) values (2,1,''Arrange for vacation coverage'',to_date(''01-11-11'',''DD-MM-RR''),to_da';
wwv_flow_imp.g_varchar2_table(92) := 'te(''31-12-11'',''DD-MM-RR''),''On-Hold'',''Russ Sanders'',9500,7000,3);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks ';
wwv_flow_imp.g_varchar2_table(93) := '(ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (4,3,''C';
wwv_flow_imp.g_varchar2_table(94) := 'omplete plan'',to_date(''08-11-11'',''DD-MM-RR''),to_date(''14-12-11'',''DD-MM-RR''),''Closed'',''Mark Nile'',300';
wwv_flow_imp.g_varchar2_table(95) := '0,1500,44);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSI';
wwv_flow_imp.g_varchar2_table(96) := 'GNED_TO,COST,BUDGET,PARENT_TASK) values (5,3,''Check software licenses'',to_date(''12-12-11'',''DD-MM-RR''';
wwv_flow_imp.g_varchar2_table(97) := '),to_date(''13-12-11'',''DD-MM-RR''),''Closed'',''Mark Nile'',200,200,44);'||wwv_flow.LF||
'    insert into EBA_UT_chart_task';
wwv_flow_imp.g_varchar2_table(98) := 's (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (6,5,';
wwv_flow_imp.g_varchar2_table(99) := '''Create training workspace'',to_date(''01-12-11'',''DD-MM-RR''),to_date(''08-12-11'',''DD-MM-RR''),''Closed'',''';
wwv_flow_imp.g_varchar2_table(100) := 'James Cassidy'',500,700,36);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_';
wwv_flow_imp.g_varchar2_table(101) := 'DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (7,5,''Publish links to self-study courses'',t';
wwv_flow_imp.g_varchar2_table(102) := 'o_date(''01-12-11'',''DD-MM-RR''),to_date(''01-12-11'',''DD-MM-RR''),''Closed'',''John Watson'',100,100,36);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(103) := ' insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BU';
wwv_flow_imp.g_varchar2_table(104) := 'DGET,PARENT_TASK) values (8,2,''Identify point solutions required'',to_date(''03-12-11'',''DD-MM-RR''),to_';
wwv_flow_imp.g_varchar2_table(105) := 'date(''05-12-11'',''DD-MM-RR''),''Closed'',''John Watson'',200,300,49);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (';
wwv_flow_imp.g_varchar2_table(106) := 'ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (9,2,''In';
wwv_flow_imp.g_varchar2_table(107) := 'stall in development'',to_date(''07-12-11'',''DD-MM-RR''),to_date(''07-12-11'',''DD-MM-RR''),''Closed'',''John W';
wwv_flow_imp.g_varchar2_table(108) := 'atson'',100,100,49);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STA';
wwv_flow_imp.g_varchar2_table(109) := 'TUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (15,4,''Identify owners'',to_date(''19-11-11'',''DD-MM-RR';
wwv_flow_imp.g_varchar2_table(110) := '''),to_date(''22-11-11'',''DD-MM-RR''),''Closed'',''Hank Davis'',250,300,17);'||wwv_flow.LF||
'    insert into EBA_UT_chart_ta';
wwv_flow_imp.g_varchar2_table(111) := 'sks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (16';
wwv_flow_imp.g_varchar2_table(112) := ',4,''Initial Draft Review'',to_date(''23-11-11'',''DD-MM-RR''),to_date(''23-11-11'',''DD-MM-RR''),''Closed'',''Ha';
wwv_flow_imp.g_varchar2_table(113) := 'nk Davis'',100,100,17);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,';
wwv_flow_imp.g_varchar2_table(114) := 'STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (17,4,''Monitor Review Comments'',to_date(''23-11-11';
wwv_flow_imp.g_varchar2_table(115) := ''',''DD-MM-RR''),to_date(''31-12-11'',''DD-MM-RR''),''Closed'',''Hank Davis'',450,500,null);'||wwv_flow.LF||
'    insert into EB';
wwv_flow_imp.g_varchar2_table(116) := 'A_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TAS';
wwv_flow_imp.g_varchar2_table(117) := 'K) values (18,6,''Implement bug tracking software'',to_date(''15-11-11'',''DD-MM-RR''),to_date(''15-11-11'',';
wwv_flow_imp.g_varchar2_table(118) := '''DD-MM-RR''),''Closed'',''Myra Sutcliff'',100,100,null);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,T';
wwv_flow_imp.g_varchar2_table(119) := 'ASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (19,6,''Review automa';
wwv_flow_imp.g_varchar2_table(120) := 'ted testing tools'',to_date(''16-11-11'',''DD-MM-RR''),to_date(''15-12-11'',''DD-MM-RR''),''Closed'',''Myra Sutc';
wwv_flow_imp.g_varchar2_table(121) := 'liff'',2750,1500,18);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,ST';
wwv_flow_imp.g_varchar2_table(122) := 'ATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (20,7,''Identify pilot applications'',to_date(''10-11-';
wwv_flow_imp.g_varchar2_table(123) := '11'',''DD-MM-RR''),to_date(''15-11-11'',''DD-MM-RR''),''Closed'',''Mark Nile'',300,500,53);'||wwv_flow.LF||
'    insert into EBA';
wwv_flow_imp.g_varchar2_table(124) := '_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK';
wwv_flow_imp.g_varchar2_table(125) := ') values (21,7,''Migrate pilot applications to '',to_date(''20-11-11'',''DD-MM-RR''),to_date(''25-11-11'',''D';
wwv_flow_imp.g_varchar2_table(126) := 'D-MM-RR''),''Closed'',''Mark Nile'',500,500,53);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME';
wwv_flow_imp.g_varchar2_table(127) := ',START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (22,8,''Customize Software Pr';
wwv_flow_imp.g_varchar2_table(128) := 'ojects software'',to_date(''15-12-12'',''DD-MM-RR''),to_date(''20-01-12'',''DD-MM-RR''),''Open'',''Tom Suess'',60';
wwv_flow_imp.g_varchar2_table(129) := '0,1000,28);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSI';
wwv_flow_imp.g_varchar2_table(130) := 'GNED_TO,COST,BUDGET,PARENT_TASK) values (23,7,''Post-migration review'',to_date(''01-12-11'',''DD-MM-RR'')';
wwv_flow_imp.g_varchar2_table(131) := ',to_date(''01-12-11'',''DD-MM-RR''),''Closed'',''Mark Nile'',100,100,53);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks';
wwv_flow_imp.g_varchar2_table(132) := ' (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (24,7,';
wwv_flow_imp.g_varchar2_table(133) := '''User acceptance testing'',to_date(''03-12-11'',''DD-MM-RR''),to_date(''04-12-11'',''DD-MM-RR''),''Closed'',''Ma';
wwv_flow_imp.g_varchar2_table(134) := 'rk Nile'',600,200,23);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,S';
wwv_flow_imp.g_varchar2_table(135) := 'TATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (25,8,''Enter base data (Projects, Milestones, etc.';
wwv_flow_imp.g_varchar2_table(136) := ')'',to_date(''10-12-11'',''DD-MM-RR''),to_date(''11-12-11'',''DD-MM-RR''),''Closed'',''Tom Suess'',200,200,28);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(137) := '   insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,';
wwv_flow_imp.g_varchar2_table(138) := 'BUDGET,PARENT_TASK) values (26,8,''Load current tasks and enhancements'',to_date(''12-12-11'',''DD-MM-RR''';
wwv_flow_imp.g_varchar2_table(139) := '),to_date(''16-12-11'',''DD-MM-RR''),''Closed'',''Tom Suess'',400,500,28);'||wwv_flow.LF||
'    insert into EBA_UT_chart_task';
wwv_flow_imp.g_varchar2_table(140) := 's (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (27,6';
wwv_flow_imp.g_varchar2_table(141) := ',''Document quality assurance procedures'',to_date(''16-12-11'',''DD-MM-RR''),to_date(''19-01-12'',''DD-MM-RR';
wwv_flow_imp.g_varchar2_table(142) := '''),''On-Hold'',''Myra Sutcliff'',3500,4000,18);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME';
wwv_flow_imp.g_varchar2_table(143) := ',START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (28,8,''Conduct project kicko';
wwv_flow_imp.g_varchar2_table(144) := 'ff meeting'',to_date(''05-12-11'',''DD-MM-RR''),to_date(''05-12-11'',''DD-MM-RR''),''Closed'',''Pam King'',100,10';
wwv_flow_imp.g_varchar2_table(145) := '0,null);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNE';
wwv_flow_imp.g_varchar2_table(146) := 'D_TO,COST,BUDGET,PARENT_TASK) values (29,9,''Determine host server'',to_date(''06-12-11'',''DD-MM-RR''),to';
wwv_flow_imp.g_varchar2_table(147) := '_date(''07-12-11'',''DD-MM-RR''),''Closed'',''Tiger Scott'',200,200,40);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks ';
wwv_flow_imp.g_varchar2_table(148) := '(ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (30,9,''';
wwv_flow_imp.g_varchar2_table(149) := 'Check software licenses'',to_date(''07-12-11'',''DD-MM-RR''),to_date(''07-12-11'',''DD-MM-RR''),''Closed'',''Tom';
wwv_flow_imp.g_varchar2_table(150) := ' Suess'',100,100,40);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,ST';
wwv_flow_imp.g_varchar2_table(151) := 'ATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (31,10,''Identify pilot users'',to_date(''05-12-11'',''D';
wwv_flow_imp.g_varchar2_table(152) := 'D-MM-RR''),to_date(''06-12-11'',''DD-MM-RR''),''Closed'',''Scott Spencer'',200,200,33);'||wwv_flow.LF||
'    insert into EBA_U';
wwv_flow_imp.g_varchar2_table(153) := 'T_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) ';
wwv_flow_imp.g_varchar2_table(154) := 'values (32,10,''Software Deliverable'',to_date(''07-12-11'',''DD-MM-RR''),to_date(''20-12-11'',''DD-MM-RR''),''';
wwv_flow_imp.g_varchar2_table(155) := 'Closed'',''Scott Spencer'',400,500,33);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_';
wwv_flow_imp.g_varchar2_table(156) := 'DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (33,10,''Early Adopter Release'',to_d';
wwv_flow_imp.g_varchar2_table(157) := 'ate(''21-12-11'',''DD-MM-RR''),to_date(''21-12-11'',''DD-MM-RR''),''Closed'',''Pam King'',100,100,null);'||wwv_flow.LF||
'    ins';
wwv_flow_imp.g_varchar2_table(158) := 'ert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET';
wwv_flow_imp.g_varchar2_table(159) := ',PARENT_TASK) values (35,11,''Determine midtier configuration(s)'',to_date(''02-11-11'',''DD-MM-RR''),to_d';
wwv_flow_imp.g_varchar2_table(160) := 'ate(''02-11-11'',''DD-MM-RR''),''Closed'',''James Cassidy'',100,100,61);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks ';
wwv_flow_imp.g_varchar2_table(161) := '(ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (36,5,''';
wwv_flow_imp.g_varchar2_table(162) := 'Manage Training Activities'',to_date(''28-11-11'',''DD-MM-RR''),to_date(''03-02-12'',''DD-MM-RR''),''On-Hold'',';
wwv_flow_imp.g_varchar2_table(163) := '''John Watson'',1000,2000,null);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,E';
wwv_flow_imp.g_varchar2_table(164) := 'ND_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (38,12,''Review feedback'',to_date(''09-01-1';
wwv_flow_imp.g_varchar2_table(165) := '2'',''DD-MM-RR''),to_date(''15-01-12'',''DD-MM-RR''),''On-Hold'',''Irene Jones'',200,400,null);'||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(166) := ' EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_';
wwv_flow_imp.g_varchar2_table(167) := 'TASK) values (39,12,''Plan rollout schedule'',to_date(''16-01-12'',''DD-MM-RR''),to_date(''24-01-12'',''DD-MM';
wwv_flow_imp.g_varchar2_table(168) := '-RR''),''On-Hold'',''Irene Jones'',0,750,38);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,ST';
wwv_flow_imp.g_varchar2_table(169) := 'ART_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (40,9,''Plan rollout schedule'',t';
wwv_flow_imp.g_varchar2_table(170) := 'o_date(''10-12-11'',''DD-MM-RR''),to_date(''02-01-12'',''DD-MM-RR''),''On-Hold'',''Al Bines'',300,1000,null);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(171) := '  insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,B';
wwv_flow_imp.g_varchar2_table(172) := 'UDGET,PARENT_TASK) values (41,9,''Develop web pages'',to_date(''10-01-12'',''DD-MM-RR''),to_date(''15-02-12';
wwv_flow_imp.g_varchar2_table(173) := ''',''DD-MM-RR''),''On-Hold'',''Tiger Scott'',800,2000,40);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,T';
wwv_flow_imp.g_varchar2_table(174) := 'ASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (42,9,''Purchase addi';
wwv_flow_imp.g_varchar2_table(175) := 'tional software licenses, if needed'',to_date(''17-02-12'',''DD-MM-RR''),to_date(''17-02-12'',''DD-MM-RR''),''';
wwv_flow_imp.g_varchar2_table(176) := 'On-Hold'',''Tom Suess'',0,100,40);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,';
wwv_flow_imp.g_varchar2_table(177) := 'END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (43,1,''Investigate new Virus Protection ';
wwv_flow_imp.g_varchar2_table(178) := 'software'',to_date(''29-12-11'',''DD-MM-RR''),to_date(''13-01-12'',''DD-MM-RR''),''Open'',''Pam King'',1700,1500,';
wwv_flow_imp.g_varchar2_table(179) := '3);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,';
wwv_flow_imp.g_varchar2_table(180) := 'COST,BUDGET,PARENT_TASK) values (44,3,''Get RFPs for new server'',to_date(''13-12-11'',''DD-MM-RR''),to_da';
wwv_flow_imp.g_varchar2_table(181) := 'te(''03-01-12'',''DD-MM-RR''),''Open'',''Mark Nile'',2000,1000,null);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID';
wwv_flow_imp.g_varchar2_table(182) := ',PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (45,13,''Co';
wwv_flow_imp.g_varchar2_table(183) := 'llect mission-critical spreadsheets'',to_date(''15-12-11'',''DD-MM-RR''),to_date(''15-02-12'',''DD-MM-RR''),''';
wwv_flow_imp.g_varchar2_table(184) := 'Open'',''Pam King'',2500,4000,46);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,';
wwv_flow_imp.g_varchar2_table(185) := 'END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (46,13,''Create  applications from spread';
wwv_flow_imp.g_varchar2_table(186) := 'sheets'',to_date(''15-12-11'',''DD-MM-RR''),to_date(''30-05-12'',''DD-MM-RR''),''Open'',''Pam King'',6000,10000,n';
wwv_flow_imp.g_varchar2_table(187) := 'ull);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_T';
wwv_flow_imp.g_varchar2_table(188) := 'O,COST,BUDGET,PARENT_TASK) values (47,13,''Lock spreadsheets'',to_date(''15-12-11'',''DD-MM-RR''),to_date(';
wwv_flow_imp.g_varchar2_table(189) := '''30-05-12'',''DD-MM-RR''),''Open'',''Pam King'',1000,800,46);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJEC';
wwv_flow_imp.g_varchar2_table(190) := 'T,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (48,13,''Send link';
wwv_flow_imp.g_varchar2_table(191) := 's to previous spreadsheet owners'',to_date(''16-12-11'',''DD-MM-RR''),to_date(''01-06-12'',''DD-MM-RR''),''Ope';
wwv_flow_imp.g_varchar2_table(192) := 'n'',''Pam King'',1000,1500,46);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END';
wwv_flow_imp.g_varchar2_table(193) := '_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (49,2,''Customize solutions'',to_date(''08-12-';
wwv_flow_imp.g_varchar2_table(194) := '11'',''DD-MM-RR''),to_date(''01-03-12'',''DD-MM-RR''),''Open'',''John Watson'',1500,4000,null);'||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(195) := ' EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_';
wwv_flow_imp.g_varchar2_table(196) := 'TASK) values (50,2,''Train developers / users'',to_date(''10-01-12'',''DD-MM-RR''),to_date(''25-03-12'',''DD-';
wwv_flow_imp.g_varchar2_table(197) := 'MM-RR''),''Pending'',''John Watson'',0,8000,49);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME';
wwv_flow_imp.g_varchar2_table(198) := ',START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (51,2,''Implement in Producti';
wwv_flow_imp.g_varchar2_table(199) := 'on'',to_date(''27-12-11'',''DD-MM-RR''),to_date(''03-05-12'',''DD-MM-RR''),''Open'',''John Watson'',200,1500,49);';
wwv_flow_imp.g_varchar2_table(200) := ''||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COS';
wwv_flow_imp.g_varchar2_table(201) := 'T,BUDGET,PARENT_TASK) values (52,7,''Migrate applications'',to_date(''15-12-11'',''DD-MM-RR''),to_date(''20';
wwv_flow_imp.g_varchar2_table(202) := '-02-12'',''DD-MM-RR''),''Open'',''Mark Nile'',1000,8000,53);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT';
wwv_flow_imp.g_varchar2_table(203) := ',TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (53,7,''Plan migrat';
wwv_flow_imp.g_varchar2_table(204) := 'ion schedule'',to_date(''22-12-11'',''DD-MM-RR''),to_date(''03-03-12'',''DD-MM-RR''),''Open'',''Mark Nile'',1500,';
wwv_flow_imp.g_varchar2_table(205) := '6000,null);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSI';
wwv_flow_imp.g_varchar2_table(206) := 'GNED_TO,COST,BUDGET,PARENT_TASK) values (54,10,''Publish Feedback application'',to_date(''26-12-11'',''DD';
wwv_flow_imp.g_varchar2_table(207) := '-MM-RR''),to_date(''04-05-12'',''DD-MM-RR''),''Open'',''Pam King'',300,12000,33);'||wwv_flow.LF||
'    insert into EBA_UT_char';
wwv_flow_imp.g_varchar2_table(208) := 't_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values';
wwv_flow_imp.g_varchar2_table(209) := ' (55,6,''Train developers on tracking bugs'',to_date(''20-01-12'',''DD-MM-RR''),to_date(''10-03-12'',''DD-MM-';
wwv_flow_imp.g_varchar2_table(210) := 'RR''),''On-Hold'',''Myra Sutcliff'',0,2000,18);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,';
wwv_flow_imp.g_varchar2_table(211) := 'START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (56,7,''End-user Training'',to_';
wwv_flow_imp.g_varchar2_table(212) := 'date(''28-12-11'',''DD-MM-RR''),to_date(''22-02-12'',''DD-MM-RR''),''Open'',''John Watson'',0,2000,53);'||wwv_flow.LF||
'    inse';
wwv_flow_imp.g_varchar2_table(213) := 'rt into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,';
wwv_flow_imp.g_varchar2_table(214) := 'PARENT_TASK) values (57,11,''Identify server requirements'',to_date(''01-11-11'',''DD-MM-RR''),to_date(''02';
wwv_flow_imp.g_varchar2_table(215) := '-11-11'',''DD-MM-RR''),''Closed'',''John Watson'',100,200,61);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJE';
wwv_flow_imp.g_varchar2_table(216) := 'CT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (58,11,''Specify ';
wwv_flow_imp.g_varchar2_table(217) := 'security authentication scheme(s)'',to_date(''03-11-11'',''DD-MM-RR''),to_date(''05-11-11'',''DD-MM-RR''),''Cl';
wwv_flow_imp.g_varchar2_table(218) := 'osed'',''John Watson'',200,300,61);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE';
wwv_flow_imp.g_varchar2_table(219) := ',END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (60,11,''Create pilot workspace'',to_date';
wwv_flow_imp.g_varchar2_table(220) := '(''10-11-11'',''DD-MM-RR''),to_date(''10-11-11'',''DD-MM-RR''),''Closed'',''John Watson'',100,100,61);'||wwv_flow.LF||
'    inser';
wwv_flow_imp.g_varchar2_table(221) := 't into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,P';
wwv_flow_imp.g_varchar2_table(222) := 'ARENT_TASK) values (61,11,''Configure Workspace provisioning'',to_date(''10-11-11'',''DD-MM-RR''),to_date(';
wwv_flow_imp.g_varchar2_table(223) := '''10-11-11'',''DD-MM-RR''),''Closed'',''John Watson'',200,100,null);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,';
wwv_flow_imp.g_varchar2_table(224) := 'PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (62,11,''Run';
wwv_flow_imp.g_varchar2_table(225) := ' installation'',to_date(''11-11-11'',''DD-MM-RR''),to_date(''11-11-11'',''DD-MM-RR''),''Closed'',''James Cassidy';
wwv_flow_imp.g_varchar2_table(226) := ''',100,100,57);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,A';
wwv_flow_imp.g_varchar2_table(227) := 'SSIGNED_TO,COST,BUDGET,PARENT_TASK) values (64,14,''Obtain equipment specifications'',to_date(''03-01-1';
wwv_flow_imp.g_varchar2_table(228) := '2'',''DD-MM-RR''),to_date(''06-01-12'',''DD-MM-RR''),''Pending'',''James Cassidy'',0,500,67);'||wwv_flow.LF||
'    insert into E';
wwv_flow_imp.g_varchar2_table(229) := 'BA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TA';
wwv_flow_imp.g_varchar2_table(230) := 'SK) values (65,3,''Purchase backup server'',to_date(''12-01-12'',''DD-MM-RR''),to_date(''07-02-12'',''DD-MM-R';
wwv_flow_imp.g_varchar2_table(231) := 'R''),''Pending'',''Mark Nile'',0,3000,44);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START';
wwv_flow_imp.g_varchar2_table(232) := '_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (66,14,''Identify integration point';
wwv_flow_imp.g_varchar2_table(233) := 's'',to_date(''08-01-12'',''DD-MM-RR''),to_date(''28-01-12'',''DD-MM-RR''),''Pending'',''Mark Nile'',0,2000,67);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(234) := '   insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,';
wwv_flow_imp.g_varchar2_table(235) := 'BUDGET,PARENT_TASK) values (67,14,''Decommission machines'',to_date(''08-01-12'',''DD-MM-RR''),to_date(''08';
wwv_flow_imp.g_varchar2_table(236) := '-01-12'',''DD-MM-RR''),''Pending'',''Scott Spencer'',0,100,null);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PR';
wwv_flow_imp.g_varchar2_table(237) := 'OJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (68,14,''Map d';
wwv_flow_imp.g_varchar2_table(238) := 'ata usage'',to_date(''20-01-12'',''DD-MM-RR''),to_date(''03-03-12'',''DD-MM-RR''),''Pending'',''Mark Nile'',0,800';
wwv_flow_imp.g_varchar2_table(239) := '0,67);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_';
wwv_flow_imp.g_varchar2_table(240) := 'TO,COST,BUDGET,PARENT_TASK) values (69,14,''Purchase new machines'',to_date(''24-02-12'',''DD-MM-RR''),to_';
wwv_flow_imp.g_varchar2_table(241) := 'date(''20-03-12'',''DD-MM-RR''),''Pending'',''John Watson'',0,2500,67);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (';
wwv_flow_imp.g_varchar2_table(242) := 'ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (70,14,''';
wwv_flow_imp.g_varchar2_table(243) := 'Import data'',to_date(''25-02-12'',''DD-MM-RR''),to_date(''23-03-12'',''DD-MM-RR''),''Pending'',''John Watson'',0';
wwv_flow_imp.g_varchar2_table(244) := ',1000,67);'||wwv_flow.LF||
'    insert into EBA_UT_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIG';
wwv_flow_imp.g_varchar2_table(245) := 'NED_TO,COST,BUDGET,PARENT_TASK) values (71,14,''Convert processes'',to_date(''02-02-12'',''DD-MM-RR''),to_';
wwv_flow_imp.g_varchar2_table(246) := 'date(''01-04-12'',''DD-MM-RR''),''Pending'',''Pam King'',0,3000,67);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, cat';
wwv_flow_imp.g_varchar2_table(247) := 'egory, title, subtitle, body, secondary_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'va';
wwv_flow_imp.g_varchar2_table(248) := 'lues'||wwv_flow.LF||
'(1, ''conference'', ''Accessibility'', ''Creating Accessible Apps'', ''This conference breaks down all';
wwv_flow_imp.g_varchar2_table(249) := ' aspects of creating accessible web applications. We focus on the latest World Wide Web Consortium (';
wwv_flow_imp.g_varchar2_table(250) := 'W3C) standards in sessions discussing tables, labels, forms, images, color contrast, links, page str';
wwv_flow_imp.g_varchar2_table(251) := 'ucture, screen reader testing, and Voluntary Product Accessibility Templates (VPATs). The conference';
wwv_flow_imp.g_varchar2_table(252) := ' starts at 8am  and ends at 4pm. Lunch will be served, with vegan options for those interested.'', ''<';
wwv_flow_imp.g_varchar2_table(253) := 'ul>'||wwv_flow.LF||
'<li>8am-9am: Tables</li>'||wwv_flow.LF||
'<li>9am-10am: Labels and Forms</li>'||wwv_flow.LF||
'<li>10am-11am: Images and Color Con';
wwv_flow_imp.g_varchar2_table(254) := 'trast</li>'||wwv_flow.LF||
'<li>11am-Noon: Links and Page Structure</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Screen';
wwv_flow_imp.g_varchar2_table(255) := ' Reader Analyzation</li>'||wwv_flow.LF||
'<li>2pm-3pm: Voluntary Product Accessibility Templates (VPATs)</li>'||wwv_flow.LF||
'<li>3pm';
wwv_flow_imp.g_varchar2_table(256) := '-4pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-universal-access'', ''200.00'', ''img/adaptable.jpg'','||wwv_flow.LF||
'cast(trunc(s';
wwv_flow_imp.g_varchar2_table(257) := 'ysdate + 10) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 10) as timestamp';
wwv_flow_imp.g_varchar2_table(258) := ' with time zone) + interval ''16'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, subtit';
wwv_flow_imp.g_varchar2_table(259) := 'le, body, secondary_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(2, ''conference';
wwv_flow_imp.g_varchar2_table(260) := ''', ''Security'', ''Creating Secure Apps'', ''This conference discusses all aspects of securing/hardening ';
wwv_flow_imp.g_varchar2_table(261) := 'a web application. You''''ll learn how to protect against Cross Side Scripting vulnerabilities and SQL';
wwv_flow_imp.g_varchar2_table(262) := ' Injection attacks. Other topics discussed are virus protection, VPNs and port sniffing, phishing an';
wwv_flow_imp.g_varchar2_table(263) := 'd malware, and handling data breaches. The conference starts at 8am and ends at 4pm. Lunch will be s';
wwv_flow_imp.g_varchar2_table(264) := 'erved, with vegan options for those interested.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Cross Side Scripting</li>'||wwv_flow.LF||
'<li>9';
wwv_flow_imp.g_varchar2_table(265) := 'am-10am: SQL Injection</li>'||wwv_flow.LF||
'<li>10am-11am: Virus Protection</li>'||wwv_flow.LF||
'<li>11am-Noon: VPNs and Port Sniffi';
wwv_flow_imp.g_varchar2_table(266) := 'ng</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Phishing and Malware</li>'||wwv_flow.LF||
'<li>2pm-3pm: Handling Data B';
wwv_flow_imp.g_varchar2_table(267) := 'reaches</li>'||wwv_flow.LF||
'<li>3pm-4pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-lock'', ''200.00'', ''img/discovery.jpg'','||wwv_flow.LF||
'cast';
wwv_flow_imp.g_varchar2_table(268) := '(trunc(sysdate + 20) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 20) as t';
wwv_flow_imp.g_varchar2_table(269) := 'imestamp with time zone) + interval ''16'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title';
wwv_flow_imp.g_varchar2_table(270) := ', subtitle, body, secondary_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(3, ''co';
wwv_flow_imp.g_varchar2_table(271) := 'nference'', ''Responsive Design'', ''Creating Responsive Apps'', ''This conference discusses all aspects o';
wwv_flow_imp.g_varchar2_table(272) := 'f making a web application responsive. We will discuss topics like responsive design, minimalism, pa';
wwv_flow_imp.g_varchar2_table(273) := 'rallax vs. infinite scrolling, cross-browser compatibility, typography, and CSS animations. The conf';
wwv_flow_imp.g_varchar2_table(274) := 'erence starts at 8am and ends at 4pm. Lunch will be served, with vegan options for those interested.';
wwv_flow_imp.g_varchar2_table(275) := ''', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Responsive Design</li>'||wwv_flow.LF||
'<li>9am-10am: Minimalism</li>'||wwv_flow.LF||
'<li>10am-11am: Parallax v';
wwv_flow_imp.g_varchar2_table(276) := 's. Infinite Scrolling</li>'||wwv_flow.LF||
'<li>11am-Noon: Cross-Browser Compatibility</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(277) := '<li>1pm-2pm: Typography</li>'||wwv_flow.LF||
'<li>2pm-3pm: CSS Animations</li>'||wwv_flow.LF||
'<li>3pm-4pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>';
wwv_flow_imp.g_varchar2_table(278) := ''', ''fa-arrows-h'', ''200.00'', ''img/construction-and-engineering.jpg'','||wwv_flow.LF||
'cast(trunc(sysdate + 30) as time';
wwv_flow_imp.g_varchar2_table(279) := 'stamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 30) as timestamp with time zone) + i';
wwv_flow_imp.g_varchar2_table(280) := 'nterval ''16'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, subtitle, body, secondary_';
wwv_flow_imp.g_varchar2_table(281) := 'body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(4, ''conference'', ''Slack Integratio';
wwv_flow_imp.g_varchar2_table(282) := 'n'', ''Integrate Slack Into Your Apps'', ''This conference shows how to integrate Slack into your web ap';
wwv_flow_imp.g_varchar2_table(283) := 'plication. We will discuss topics like the Slack API, channels, channel topics vs. descriptions, mar';
wwv_flow_imp.g_varchar2_table(284) := 'kdown, and third party vendor integration. The conference starts at 8am and ends at 3pm. Lunch will ';
wwv_flow_imp.g_varchar2_table(285) := 'be served, with vegan options for those interested.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Slack API</li>'||wwv_flow.LF||
'<li>9am-10am';
wwv_flow_imp.g_varchar2_table(286) := ': Channels</li>'||wwv_flow.LF||
'<li>10am-11am: Channel Topics vs. Descriptions</li>'||wwv_flow.LF||
'<li>11am-Noon: Markdown</li>'||wwv_flow.LF||
'<li';
wwv_flow_imp.g_varchar2_table(287) := '>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: 3rd Party Vendor Integration</li>'||wwv_flow.LF||
'<li>2pm-3pm: Review and Q&A</li';
wwv_flow_imp.g_varchar2_table(288) := '>'||wwv_flow.LF||
'</ul>'', ''fa-comment-o'', ''200.00'', ''img/diversity.jpg'','||wwv_flow.LF||
'cast(trunc(sysdate + 40) as timestamp with ';
wwv_flow_imp.g_varchar2_table(289) := 'time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 40) as timestamp with time zone) + interval ''15';
wwv_flow_imp.g_varchar2_table(290) := ''' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, subtitle, body, secondary_body, icon_';
wwv_flow_imp.g_varchar2_table(291) := 'class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(5, ''conference'', ''Blockchain'', ''Understanding';
wwv_flow_imp.g_varchar2_table(292) := ' Blockchain'', ''This conference will cover high value payments, enhancements in transactions includin';
wwv_flow_imp.g_varchar2_table(293) := 'g IoT and Supply Chain Automation. Bring your own Laptop. The conference starts at 8am and ends at 5';
wwv_flow_imp.g_varchar2_table(294) := 'pm. Lunch will be provided. If you have special dietary requirements, please send an email to the or';
wwv_flow_imp.g_varchar2_table(295) := 'ganizers.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Introduction to Blockchain</li>'||wwv_flow.LF||
'<li>9am-10am: High Value Payments</li';
wwv_flow_imp.g_varchar2_table(296) := '>'||wwv_flow.LF||
'<li>10am-11am: Enhancements in Transactions</li>'||wwv_flow.LF||
'<li>11am-Noon: Data and Finances</li>'||wwv_flow.LF||
'<li>Noon-1p';
wwv_flow_imp.g_varchar2_table(297) := 'm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Mobility and IoT</li>'||wwv_flow.LF||
'<li>2pm-3pm: Standards for Blockchain Adoption</li>';
wwv_flow_imp.g_varchar2_table(298) := ''||wwv_flow.LF||
'<li>3pm-4pm: Supply Chain Automation with Blockchain</li>'||wwv_flow.LF||
'<li>4pm-5pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ';
wwv_flow_imp.g_varchar2_table(299) := '''fa-cubes'', ''300.00'', ''img/blockchain.jpg'','||wwv_flow.LF||
'cast(trunc(sysdate + 50) as timestamp with time zone) + ';
wwv_flow_imp.g_varchar2_table(300) := 'interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 50) as timestamp with time zone) + interval ''17'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(301) := 'sert into eba_ut_demo_cards (id, category, title, subtitle, body, secondary_body, icon_class, badge,';
wwv_flow_imp.g_varchar2_table(302) := ' image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(6, ''conference'', ''Localizations'', ''Preparing your app for ';
wwv_flow_imp.g_varchar2_table(303) := 'a global audience'', ''This conference focuses on important considerations needed to ensure an applica';
wwv_flow_imp.g_varchar2_table(304) := 'tion can reach a global audience, it covers the difference between automated and manual translations';
wwv_flow_imp.g_varchar2_table(305) := ', User eXperience analysis, handling of sensitive data during translations, and some standards and d';
wwv_flow_imp.g_varchar2_table(306) := 'efinitions important for the target markets. Lunch will be at noon. It starts at 8 am and ends at 3 ';
wwv_flow_imp.g_varchar2_table(307) := 'pm.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Global Audience Analysis</li>'||wwv_flow.LF||
'<li>9am-10am: Automated vs Manual Translation';
wwv_flow_imp.g_varchar2_table(308) := 's</li>'||wwv_flow.LF||
'<li>10am-11am: UX Considerations</li>'||wwv_flow.LF||
'<li>11am-Noon: Sensitive Data Translations</li>'||wwv_flow.LF||
'<li>Noo';
wwv_flow_imp.g_varchar2_table(309) := 'n-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Localization Standards and Definitions</li>'||wwv_flow.LF||
'<li>2pm-3pm: Review and Q';
wwv_flow_imp.g_varchar2_table(310) := '&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-language'', ''140.00'', ''img/best-in-class.jpg'','||wwv_flow.LF||
'cast(trunc(sysdate + 60) as timest';
wwv_flow_imp.g_varchar2_table(311) := 'amp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 60) as timestamp with time zone) + int';
wwv_flow_imp.g_varchar2_table(312) := 'erval ''15'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, subtitle, body, secondary_bo';
wwv_flow_imp.g_varchar2_table(313) := 'dy, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(7, ''workshop'', ''Big Data'', ''Performa';
wwv_flow_imp.g_varchar2_table(314) := 'nt Searching Against Data Warehouses'', ''This small workshop covers data volume management, its analy';
wwv_flow_imp.g_varchar2_table(315) := 'sis, integration and visualization. It also encompases cost-effective solutions for our potential cu';
wwv_flow_imp.g_varchar2_table(316) := 'stomers. It starts at 8 am and ends at 2 pm. Lunch is included just before the Q&A.'', ''<ul>'||wwv_flow.LF||
'<li>8am-';
wwv_flow_imp.g_varchar2_table(317) := '9am: Data Volume Management</li>'||wwv_flow.LF||
'<li>9am-10am: Analysis of Unstructured Data</li>'||wwv_flow.LF||
'<li>10am-11am: Dat';
wwv_flow_imp.g_varchar2_table(318) := 'a Integration and Visualization</li>'||wwv_flow.LF||
'<li>11am-Noon: Cost-Effective Solutions</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunc';
wwv_flow_imp.g_varchar2_table(319) := 'h</li>'||wwv_flow.LF||
'<li>1pm-2pm: Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-database-wrench'', ''100.00'', ''img/analyze.jpg'', '||wwv_flow.LF||
'cast(trunc(';
wwv_flow_imp.g_varchar2_table(320) := 'sysdate + 15) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 15) as timestam';
wwv_flow_imp.g_varchar2_table(321) := 'p with time zone) + interval ''14'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, subti';
wwv_flow_imp.g_varchar2_table(322) := 'tle, body, secondary_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(8, ''workshop''';
wwv_flow_imp.g_varchar2_table(323) := ', ''Cloud Services'', ''Which Cloud Service Fits Your Needs'', ''In this workshop we will cover protectio';
wwv_flow_imp.g_varchar2_table(324) := 'n of your data, containerized apps, shared block storage and cloud tiering when using Oracle Cloud S';
wwv_flow_imp.g_varchar2_table(325) := 'ervices. There is focus on optimizing work loads and usage analysis. It starts at 8 am and ends at 4';
wwv_flow_imp.g_varchar2_table(326) := ' pm. Lunch is served at noon with vegan and meat options.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Data Protection</li>'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(327) := '<li>9am-10am: Legacy to Containerized Apps</li>'||wwv_flow.LF||
'<li>10am-11am: Shared Block Storage</li>'||wwv_flow.LF||
'<li>11am-No';
wwv_flow_imp.g_varchar2_table(328) := 'on: Cloud Tiering</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Optimizing Work Loads</li>'||wwv_flow.LF||
'<li>2pm-3pm:';
wwv_flow_imp.g_varchar2_table(329) := ' Cloud Usage Analysis</li>'||wwv_flow.LF||
'<li>3pm-4pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-cloud-new'', ''240.00'', ''img/e';
wwv_flow_imp.g_varchar2_table(330) := 'merging-tech.jpg'','||wwv_flow.LF||
'cast(trunc(sysdate + 25) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(t';
wwv_flow_imp.g_varchar2_table(331) := 'runc(sysdate + 25) as timestamp with time zone) + interval ''16'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_car';
wwv_flow_imp.g_varchar2_table(332) := 'ds (id, category, title, subtitle, body, secondary_body, icon_class, badge, image_url, start_date, e';
wwv_flow_imp.g_varchar2_table(333) := 'nd_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(9, ''workshop'', ''Quantum Computing'', ''Storing Data in Qubits'', ''In this workshop, th';
wwv_flow_imp.g_varchar2_table(334) := 'e topic of Quantum Computing as a strategy for the future development of applications and services i';
wwv_flow_imp.g_varchar2_table(335) := 's covered. It will include neural networks, advanced machine learning, natural language processing, ';
wwv_flow_imp.g_varchar2_table(336) := 'quantum simulations and modern applications. It starts at 8 am and ends at 4 pm. Lunch will be serve';
wwv_flow_imp.g_varchar2_table(337) := 'd.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Introduction to Quantum Computing</li>'||wwv_flow.LF||
'<li>9am-10am: Neural Networks</li>'||wwv_flow.LF||
'<l';
wwv_flow_imp.g_varchar2_table(338) := 'i>10am-11am: Advanced Machine Learning</li>'||wwv_flow.LF||
'<li>11am-Noon: Natural Language Processing</li>'||wwv_flow.LF||
'<li>Noon';
wwv_flow_imp.g_varchar2_table(339) := '-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Quantum Simulations</li>'||wwv_flow.LF||
'<li>2pm-3pm: Modern Applications</li>'||wwv_flow.LF||
'<li>3pm';
wwv_flow_imp.g_varchar2_table(340) := '-4pm: Review and Q&A & Anthony Rayner</li>'||wwv_flow.LF||
'</ul>'', ''fa-function'', ''350.00'', ''img/ai.jpg'','||wwv_flow.LF||
'cast(trunc';
wwv_flow_imp.g_varchar2_table(341) := '(sysdate + 35) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 35) as timesta';
wwv_flow_imp.g_varchar2_table(342) := 'mp with time zone) + interval ''16'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, subt';
wwv_flow_imp.g_varchar2_table(343) := 'itle, body, secondary_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(10, ''worksho';
wwv_flow_imp.g_varchar2_table(344) := 'p'', ''HIPAA Compliance'', ''Ensuring Your App Meets HIPAA Compliancies'', ''HIPPA compliance is required ';
wwv_flow_imp.g_varchar2_table(345) := 'for any application that deals with sensitive data such as medical history of patients. In this work';
wwv_flow_imp.g_varchar2_table(346) := 'shop you will understand the requirements that must be met before release, with special focus on per';
wwv_flow_imp.g_varchar2_table(347) := 'sonal sensitive data. It starts at 9 am and ends at 3 pm with lunch served at noon.'', ''<ul>'||wwv_flow.LF||
'<li>9am-';
wwv_flow_imp.g_varchar2_table(348) := '10am: Introduction to HIPAA</li>'||wwv_flow.LF||
'<li>10am-11am: HIPAA Compliance Checklist</li>'||wwv_flow.LF||
'<li>11am-Noon: Restr';
wwv_flow_imp.g_varchar2_table(349) := 'icted Personal Data</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: App-Focused Risk Assessment</li>'||wwv_flow.LF||
'<li>';
wwv_flow_imp.g_varchar2_table(350) := '2pm-3pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-medkit'', ''140.00'', ''img/hr.jpg'','||wwv_flow.LF||
'cast(trunc(sysdate + 45) a';
wwv_flow_imp.g_varchar2_table(351) := 's timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 45) as timestamp with time zon';
wwv_flow_imp.g_varchar2_table(352) := 'e) + interval ''15'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, subtitle, body, seco';
wwv_flow_imp.g_varchar2_table(353) := 'ndary_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(11, ''workshop'', ''Automated T';
wwv_flow_imp.g_varchar2_table(354) := 'esting'', ''Validate App Functionality Before Release'', ''This workshop covers automated build tools fr';
wwv_flow_imp.g_varchar2_table(355) := 'om you can setup unit, acceptance and UI testing. We will cover continuous integration and version c';
wwv_flow_imp.g_varchar2_table(356) := 'ontrol systems related to automated testing. A manager will provide insight on how to prepare your s';
wwv_flow_imp.g_varchar2_table(357) := 'oftware quality assurance team to cover all bases before, during and after tests, thus ensuring a re';
wwv_flow_imp.g_varchar2_table(358) := 'lease without bugs.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Automated Build Tools</li>'||wwv_flow.LF||
'<li>9am-10am: Unit, Acceptance a';
wwv_flow_imp.g_varchar2_table(359) := 'nd UI Testing</li>'||wwv_flow.LF||
'<li>10am-11am: Continuous Integration (CI)</li>'||wwv_flow.LF||
'<li>11am-Noon: Version Control Sy';
wwv_flow_imp.g_varchar2_table(360) := 'stems</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Coding Standards</li>'||wwv_flow.LF||
'<li>2pm-3pm: Managing Integra';
wwv_flow_imp.g_varchar2_table(361) := 'ted Testing Projects</li>'||wwv_flow.LF||
'<li>3pm-4pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-check-square-o'', ''300.00'', ''i';
wwv_flow_imp.g_varchar2_table(362) := 'mg/chatbots.jpg'','||wwv_flow.LF||
'cast(trunc(sysdate + 55) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(tr';
wwv_flow_imp.g_varchar2_table(363) := 'unc(sysdate + 55) as timestamp with time zone) + interval ''16'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_card';
wwv_flow_imp.g_varchar2_table(364) := 's (id, category, title, subtitle, body, secondary_body, icon_class, badge, image_url, start_date, en';
wwv_flow_imp.g_varchar2_table(365) := 'd_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(12, ''workshop'', ''Database Modeling'', ''Design Data Models With Referential Integrity''';
wwv_flow_imp.g_varchar2_table(366) := ', ''This workshop covers several design patterns for data modeling, including graphs and classic mode';
wwv_flow_imp.g_varchar2_table(367) := 'ls. There will be software tools available for the hands-on lab, so bring your laptop. It will start';
wwv_flow_imp.g_varchar2_table(368) := ' at 8 am and ends at 4 pm. Lunch will be served, with vegan options for those interested.'', ''<ul>'||wwv_flow.LF||
'<l';
wwv_flow_imp.g_varchar2_table(369) := 'i>8am-9am: Data Models Overview</li>'||wwv_flow.LF||
'<li>9am-10am: Graph Data Models</li>'||wwv_flow.LF||
'<li>10am-11am: Classic Dat';
wwv_flow_imp.g_varchar2_table(370) := 'a Modeling</li>'||wwv_flow.LF||
'<li>11am-Noon: Performance-Driven Analysis</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm';
wwv_flow_imp.g_varchar2_table(371) := ': Software Tools for Data Modeling</li>'||wwv_flow.LF||
'<li>2pm-3pm: Data Models Hands-on Lab</li>'||wwv_flow.LF||
'<li>3pm-4pm: Revi';
wwv_flow_imp.g_varchar2_table(372) := 'ew and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-database'', ''220.00'', ''img/collaboration.jpg'','||wwv_flow.LF||
'cast(trunc(sysdate + 65) a';
wwv_flow_imp.g_varchar2_table(373) := 's timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 65) as timestamp with time zon';
wwv_flow_imp.g_varchar2_table(374) := 'e) + interval ''16'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, subtitle, body, seco';
wwv_flow_imp.g_varchar2_table(375) := 'ndary_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(13, ''badge'', ''Fernanda Mende';
wwv_flow_imp.g_varchar2_table(376) := 'z'', ''Product Manager'', ''fernanda.mendez@yourcompany.com'', null, null, null, ''img/persona-female01-ap';
wwv_flow_imp.g_varchar2_table(377) := 'ex.png'', null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, subtitle, body, secondary';
wwv_flow_imp.g_varchar2_table(378) := '_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(14, ''badge'', ''Krist Grohl'', ''Qual';
wwv_flow_imp.g_varchar2_table(379) := 'ity Manager'', ''k.grohl@yourcompany.com'', null, null, null, ''img/persona-male03.png'', null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(380) := 'nsert into eba_ut_demo_cards (id, category, title, subtitle, body, secondary_body, icon_class, badge';
wwv_flow_imp.g_varchar2_table(381) := ', image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(15, ''badge'', ''Charles Statman'', ''QA Specialist'', ''charlie';
wwv_flow_imp.g_varchar2_table(382) := '.s@yourcompany.com'', null, null, null, ''img/persona-male01-apex.png'', null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_';
wwv_flow_imp.g_varchar2_table(383) := 'ut_demo_cards (id, category, title, subtitle, body, secondary_body, icon_class, badge, image_url, st';
wwv_flow_imp.g_varchar2_table(384) := 'art_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(16, ''badge'', ''Susan Parrish'', ''Software Developer'', ''susan.parrish@yourc';
wwv_flow_imp.g_varchar2_table(385) := 'ompany.com'', null, null, null, ''img/persona-female04-oracle.png'', null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_d';
wwv_flow_imp.g_varchar2_table(386) := 'emo_cards (id, category, title, subtitle, body, secondary_body, icon_class, badge, image_url, start_';
wwv_flow_imp.g_varchar2_table(387) := 'date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(17, ''badge'', ''Johnnathan Brie'', ''Team Lead'', ''johnathan.b@yourcompany.com'', ';
wwv_flow_imp.g_varchar2_table(388) := 'null, null, null, ''img/persona-male04-apex.png'', null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, ca';
wwv_flow_imp.g_varchar2_table(389) := 'tegory, title, subtitle, body, secondary_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'v';
wwv_flow_imp.g_varchar2_table(390) := 'alues'||wwv_flow.LF||
'(18, ''badge'', ''Diana Flores'', ''CFO'', ''diana.flores@yourcompany.com'', null, null, null, ''img/pe';
wwv_flow_imp.g_varchar2_table(391) := 'rsona-female03.png'', null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'update EBA_UT_chart_tasks'||wwv_flow.LF||
'   set start_date = start_date + (SYSDA';
wwv_flow_imp.g_varchar2_table(392) := 'TE - TO_DATE(''01012012'',''MMDDYYYY'')),'||wwv_flow.LF||
'       end_date = end_date + (SYSDATE - TO_DATE(''01012012'',''MM';
wwv_flow_imp.g_varchar2_table(393) := 'DDYYYY''))'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(4040875921716617969)
,p_install_id=>wwv_flow_imp.id(4040874964717609762)
,p_name=>'Create Tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
