prompt --application/deployment/install/upgrade_add_cards_demo_table_and_data
begin
--   Manifest
--     INSTALL: UPGRADE-Add Cards Demo Table and Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_ut_demo_cards ('||wwv_flow.LF||
'    id                             number               not null'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(2) := '                                                      constraint eba_ut_demo_cards_id_pk'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(3) := '                                             primary key,'||wwv_flow.LF||
'    category                       varchar';
wwv_flow_imp.g_varchar2_table(4) := '2(255 char)   not null,'||wwv_flow.LF||
'    title                          varchar2(255 char)   not null,'||wwv_flow.LF||
'    subtit';
wwv_flow_imp.g_varchar2_table(5) := 'le                       varchar2(255 char)   not null,'||wwv_flow.LF||
'    body                           varchar2(';
wwv_flow_imp.g_varchar2_table(6) := '4000 char)  not null,'||wwv_flow.LF||
'    secondary_body                 varchar2(4000 char),'||wwv_flow.LF||
'    icon_class        ';
wwv_flow_imp.g_varchar2_table(7) := '             varchar2(255 char),'||wwv_flow.LF||
'    badge                          varchar2(255 char),'||wwv_flow.LF||
'    image_ur';
wwv_flow_imp.g_varchar2_table(8) := 'l                      varchar2(255 char)   not null,'||wwv_flow.LF||
'    start_date                     timestamp w';
wwv_flow_imp.g_varchar2_table(9) := 'ith time zone,'||wwv_flow.LF||
'    end_date                       timestamp with time zone'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace tr';
wwv_flow_imp.g_varchar2_table(10) := 'igger biu_eba_ut_demo_cards'||wwv_flow.LF||
'   before insert or update on eba_ut_demo_cards'||wwv_flow.LF||
'   for each row '||wwv_flow.LF||
'begin  ';
wwv_flow_imp.g_varchar2_table(11) := ''||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') i';
wwv_flow_imp.g_varchar2_table(12) := 'nto :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger biu_eba_ut_demo_cards enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into ';
wwv_flow_imp.g_varchar2_table(13) := 'eba_ut_demo_cards (id, category, title, subtitle, body, secondary_body, icon_class, badge, image_url';
wwv_flow_imp.g_varchar2_table(14) := ', start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(1, ''conference'', ''Accessibility'', ''Creating Accessible Apps'', ''This ';
wwv_flow_imp.g_varchar2_table(15) := 'conference breaks down all aspects of creating accessible web applications. We focus on the latest W';
wwv_flow_imp.g_varchar2_table(16) := 'orld Wide Web Consortium (W3C) standards in sessions discussing tables, labels, forms, images, color';
wwv_flow_imp.g_varchar2_table(17) := ' contrast, links, page structure, screen reader testing, and Voluntary Product Accessibility Templat';
wwv_flow_imp.g_varchar2_table(18) := 'es (VPATs). The conference starts at 8am  and ends at 4pm. Lunch will be served, with vegan options ';
wwv_flow_imp.g_varchar2_table(19) := 'for those interested.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Tables</li>'||wwv_flow.LF||
'<li>9am-10am: Labels and Forms</li>'||wwv_flow.LF||
'<li>10am-';
wwv_flow_imp.g_varchar2_table(20) := '11am: Images and Color Contrast</li>'||wwv_flow.LF||
'<li>11am-Noon: Links and Page Structure</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunc';
wwv_flow_imp.g_varchar2_table(21) := 'h</li>'||wwv_flow.LF||
'<li>1pm-2pm: Screen Reader Analyzation</li>'||wwv_flow.LF||
'<li>2pm-3pm: Voluntary Product Accessibility Temp';
wwv_flow_imp.g_varchar2_table(22) := 'lates (VPATs)</li>'||wwv_flow.LF||
'<li>3pm-4pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-universal-access'', ''200.00'', ''img/ad';
wwv_flow_imp.g_varchar2_table(23) := 'aptable.jpg'','||wwv_flow.LF||
'cast(trunc(sysdate + 10) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(';
wwv_flow_imp.g_varchar2_table(24) := 'sysdate + 10) as timestamp with time zone) + interval ''16'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (i';
wwv_flow_imp.g_varchar2_table(25) := 'd, category, title, subtitle, body, secondary_body, icon_class, badge, image_url, start_date, end_da';
wwv_flow_imp.g_varchar2_table(26) := 'te)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(2, ''conference'', ''Security'', ''Creating Secure Apps'', ''This conference discusses all aspe';
wwv_flow_imp.g_varchar2_table(27) := 'cts of securing/hardening a web application. You''''ll learn how to protect against Cross Side Scripti';
wwv_flow_imp.g_varchar2_table(28) := 'ng vulnerabilities and SQL Injection attacks. Other topics discussed are virus protection, VPNs and ';
wwv_flow_imp.g_varchar2_table(29) := 'port sniffing, phishing and malware, and handling data breaches. The conference starts at 8am and en';
wwv_flow_imp.g_varchar2_table(30) := 'ds at 4pm. Lunch will be served, with vegan options for those interested.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Cross';
wwv_flow_imp.g_varchar2_table(31) := ' Side Scripting</li>'||wwv_flow.LF||
'<li>9am-10am: SQL Injection</li>'||wwv_flow.LF||
'<li>10am-11am: Virus Protection</li>'||wwv_flow.LF||
'<li>11am-';
wwv_flow_imp.g_varchar2_table(32) := 'Noon: VPNs and Port Sniffing</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Phishing and Malware</li>'||wwv_flow.LF||
'<l';
wwv_flow_imp.g_varchar2_table(33) := 'i>2pm-3pm: Handling Data Breaches</li>'||wwv_flow.LF||
'<li>3pm-4pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-lock'', ''200.00'',';
wwv_flow_imp.g_varchar2_table(34) := ' ''img/discovery.jpg'','||wwv_flow.LF||
'cast(trunc(sysdate + 20) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cas';
wwv_flow_imp.g_varchar2_table(35) := 't(trunc(sysdate + 20) as timestamp with time zone) + interval ''16'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_';
wwv_flow_imp.g_varchar2_table(36) := 'cards (id, category, title, subtitle, body, secondary_body, icon_class, badge, image_url, start_date';
wwv_flow_imp.g_varchar2_table(37) := ', end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(3, ''conference'', ''Responsive Design'', ''Creating Responsive Apps'', ''This conferen';
wwv_flow_imp.g_varchar2_table(38) := 'ce discusses all aspects of making a web application responsive. We will discuss topics like respons';
wwv_flow_imp.g_varchar2_table(39) := 'ive design, minimalism, parallax vs. infinite scrolling, cross-browser compatibility, typography, an';
wwv_flow_imp.g_varchar2_table(40) := 'd CSS animations. The conference starts at 8am and ends at 4pm. Lunch will be served, with vegan opt';
wwv_flow_imp.g_varchar2_table(41) := 'ions for those interested.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Responsive Design</li>'||wwv_flow.LF||
'<li>9am-10am: Minimalism</li>';
wwv_flow_imp.g_varchar2_table(42) := ''||wwv_flow.LF||
'<li>10am-11am: Parallax vs. Infinite Scrolling</li>'||wwv_flow.LF||
'<li>11am-Noon: Cross-Browser Compatibility</li>';
wwv_flow_imp.g_varchar2_table(43) := ''||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Typography</li>'||wwv_flow.LF||
'<li>2pm-3pm: CSS Animations</li>'||wwv_flow.LF||
'<li>3pm-4pm:';
wwv_flow_imp.g_varchar2_table(44) := ' Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-arrows-h'', ''200.00'', ''img/construction-and-engineering.jpg'','||wwv_flow.LF||
'cast(t';
wwv_flow_imp.g_varchar2_table(45) := 'runc(sysdate + 30) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 30) as tim';
wwv_flow_imp.g_varchar2_table(46) := 'estamp with time zone) + interval ''16'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, ';
wwv_flow_imp.g_varchar2_table(47) := 'subtitle, body, secondary_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(4, ''conf';
wwv_flow_imp.g_varchar2_table(48) := 'erence'', ''Slack Integration'', ''Integrate Slack Into Your Apps'', ''This conference shows how to integr';
wwv_flow_imp.g_varchar2_table(49) := 'ate Slack into your web application. We will discuss topics like the Slack API, channels, channel to';
wwv_flow_imp.g_varchar2_table(50) := 'pics vs. descriptions, markdown, and third party vendor integration. The conference starts at 8am an';
wwv_flow_imp.g_varchar2_table(51) := 'd ends at 3pm. Lunch will be served, with vegan options for those interested.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: S';
wwv_flow_imp.g_varchar2_table(52) := 'lack API</li>'||wwv_flow.LF||
'<li>9am-10am: Channels</li>'||wwv_flow.LF||
'<li>10am-11am: Channel Topics vs. Descriptions</li>'||wwv_flow.LF||
'<li>11';
wwv_flow_imp.g_varchar2_table(53) := 'am-Noon: Markdown</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: 3rd Party Vendor Integration</li>'||wwv_flow.LF||
'<li>2';
wwv_flow_imp.g_varchar2_table(54) := 'pm-3pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-comment-o'', ''200.00'', ''img/diversity.jpg'','||wwv_flow.LF||
'cast(trunc(sysdat';
wwv_flow_imp.g_varchar2_table(55) := 'e + 40) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 40) as timestamp with';
wwv_flow_imp.g_varchar2_table(56) := ' time zone) + interval ''15'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, subtitle, b';
wwv_flow_imp.g_varchar2_table(57) := 'ody, secondary_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(5, ''conference'', ''B';
wwv_flow_imp.g_varchar2_table(58) := 'lockchain'', ''Understanding Blockchain'', ''This conference will cover high value payments, enhancement';
wwv_flow_imp.g_varchar2_table(59) := 's in transactions including IoT and Supply Chain Automation. Bring your own Laptop. The conference s';
wwv_flow_imp.g_varchar2_table(60) := 'tarts at 8am and ends at 5pm. Lunch will be provided. If you have special dietary requirements, plea';
wwv_flow_imp.g_varchar2_table(61) := 'se send an email to the organizers.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Introduction to Blockchain</li>'||wwv_flow.LF||
'<li>9am-10a';
wwv_flow_imp.g_varchar2_table(62) := 'm: High Value Payments</li>'||wwv_flow.LF||
'<li>10am-11am: Enhancements in Transactions</li>'||wwv_flow.LF||
'<li>11am-Noon: Data and';
wwv_flow_imp.g_varchar2_table(63) := ' Finances</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Mobility and IoT</li>'||wwv_flow.LF||
'<li>2pm-3pm: Standards fo';
wwv_flow_imp.g_varchar2_table(64) := 'r Blockchain Adoption</li>'||wwv_flow.LF||
'<li>3pm-4pm: Supply Chain Automation with Blockchain</li>'||wwv_flow.LF||
'<li>4pm-5pm: Re';
wwv_flow_imp.g_varchar2_table(65) := 'view and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-cubes'', ''300.00'', ''img/blockchain.jpg'','||wwv_flow.LF||
'cast(trunc(sysdate + 50) as ti';
wwv_flow_imp.g_varchar2_table(66) := 'mestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 50) as timestamp with time zone) +';
wwv_flow_imp.g_varchar2_table(67) := ' interval ''17'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, subtitle, body, secondar';
wwv_flow_imp.g_varchar2_table(68) := 'y_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(6, ''conference'', ''Localizations''';
wwv_flow_imp.g_varchar2_table(69) := ', ''Preparing your app for a global audience'', ''This conference focuses on important considerations n';
wwv_flow_imp.g_varchar2_table(70) := 'eeded to ensure an application can reach a global audience, it covers the difference between automat';
wwv_flow_imp.g_varchar2_table(71) := 'ed and manual translations, User eXperience analysis, handling of sensitive data during translations';
wwv_flow_imp.g_varchar2_table(72) := ', and some standards and definitions important for the target markets. Lunch will be at noon. It sta';
wwv_flow_imp.g_varchar2_table(73) := 'rts at 8 am and ends at 3 pm.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Global Audience Analysis</li>'||wwv_flow.LF||
'<li>9am-10am: Autom';
wwv_flow_imp.g_varchar2_table(74) := 'ated vs Manual Translations</li>'||wwv_flow.LF||
'<li>10am-11am: UX Considerations</li>'||wwv_flow.LF||
'<li>11am-Noon: Sensitive Data';
wwv_flow_imp.g_varchar2_table(75) := ' Translations</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Localization Standards and Definitions</li>';
wwv_flow_imp.g_varchar2_table(76) := ''||wwv_flow.LF||
'<li>2pm-3pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-language'', ''140.00'', ''img/best-in-class.jpg'','||wwv_flow.LF||
'cast(tru';
wwv_flow_imp.g_varchar2_table(77) := 'nc(sysdate + 60) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 60) as times';
wwv_flow_imp.g_varchar2_table(78) := 'tamp with time zone) + interval ''15'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, su';
wwv_flow_imp.g_varchar2_table(79) := 'btitle, body, secondary_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(7, ''worksh';
wwv_flow_imp.g_varchar2_table(80) := 'op'', ''Big Data'', ''Performant Searching Against Data Warehouses'', ''This small workshop covers data vo';
wwv_flow_imp.g_varchar2_table(81) := 'lume management, its analysis, integration and visualization. It also encompases cost-effective solu';
wwv_flow_imp.g_varchar2_table(82) := 'tions for our potential customers. It starts at 8 am and ends at 2 pm. Lunch is included just before';
wwv_flow_imp.g_varchar2_table(83) := ' the Q&A.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Data Volume Management</li>'||wwv_flow.LF||
'<li>9am-10am: Analysis of Unstructured Da';
wwv_flow_imp.g_varchar2_table(84) := 'ta</li>'||wwv_flow.LF||
'<li>10am-11am: Data Integration and Visualization</li>'||wwv_flow.LF||
'<li>11am-Noon: Cost-Effective Solutio';
wwv_flow_imp.g_varchar2_table(85) := 'ns</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-database-wrench'', ''100.00'', ''img/';
wwv_flow_imp.g_varchar2_table(86) := 'analyze.jpg'', '||wwv_flow.LF||
'cast(trunc(sysdate + 15) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc';
wwv_flow_imp.g_varchar2_table(87) := '(sysdate + 15) as timestamp with time zone) + interval ''14'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (';
wwv_flow_imp.g_varchar2_table(88) := 'id, category, title, subtitle, body, secondary_body, icon_class, badge, image_url, start_date, end_d';
wwv_flow_imp.g_varchar2_table(89) := 'ate)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(8, ''workshop'', ''Cloud Services'', ''Which Cloud Service Fits Your Needs'', ''In this worksh';
wwv_flow_imp.g_varchar2_table(90) := 'op we will cover protection of your data, containerized apps, shared block storage and cloud tiering';
wwv_flow_imp.g_varchar2_table(91) := ' when using Oracle Cloud Services. There is focus on optimizing work loads and usage analysis. It st';
wwv_flow_imp.g_varchar2_table(92) := 'arts at 8 am and ends at 4 pm. Lunch is served at noon with vegan and meat options.'', ''<ul>'||wwv_flow.LF||
'<li>8am-';
wwv_flow_imp.g_varchar2_table(93) := '9am: Data Protection</li>'||wwv_flow.LF||
'<li>9am-10am: Legacy to Containerized Apps</li>'||wwv_flow.LF||
'<li>10am-11am: Shared Bloc';
wwv_flow_imp.g_varchar2_table(94) := 'k Storage</li>'||wwv_flow.LF||
'<li>11am-Noon: Cloud Tiering</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Optimizing Wo';
wwv_flow_imp.g_varchar2_table(95) := 'rk Loads</li>'||wwv_flow.LF||
'<li>2pm-3pm: Cloud Usage Analysis</li>'||wwv_flow.LF||
'<li>3pm-4pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-cl';
wwv_flow_imp.g_varchar2_table(96) := 'oud-new'', ''240.00'', ''img/emerging-tech.jpg'','||wwv_flow.LF||
'cast(trunc(sysdate + 25) as timestamp with time zone) +';
wwv_flow_imp.g_varchar2_table(97) := ' interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 25) as timestamp with time zone) + interval ''16'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(98) := 'nsert into eba_ut_demo_cards (id, category, title, subtitle, body, secondary_body, icon_class, badge';
wwv_flow_imp.g_varchar2_table(99) := ', image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(9, ''workshop'', ''Quantum Computing'', ''Storing Data in Qubi';
wwv_flow_imp.g_varchar2_table(100) := 'ts'', ''In this workshop, the topic of Quantum Computing as a strategy for the future development of a';
wwv_flow_imp.g_varchar2_table(101) := 'pplications and services is covered. It will include neural networks, advanced machine learning, nat';
wwv_flow_imp.g_varchar2_table(102) := 'ural language processing, quantum simulations and modern applications. It starts at 8 am and ends at';
wwv_flow_imp.g_varchar2_table(103) := ' 4 pm. Lunch will be served.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Introduction to Quantum Computing</li>'||wwv_flow.LF||
'<li>9am-10a';
wwv_flow_imp.g_varchar2_table(104) := 'm: Neural Networks</li>'||wwv_flow.LF||
'<li>10am-11am: Advanced Machine Learning</li>'||wwv_flow.LF||
'<li>11am-Noon: Natural Languag';
wwv_flow_imp.g_varchar2_table(105) := 'e Processing</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Quantum Simulations</li>'||wwv_flow.LF||
'<li>2pm-3pm: Modern';
wwv_flow_imp.g_varchar2_table(106) := ' Applications</li>'||wwv_flow.LF||
'<li>3pm-4pm: Review and Q&A & Anthony Rayner</li>'||wwv_flow.LF||
'</ul>'', ''fa-function'', ''350.00''';
wwv_flow_imp.g_varchar2_table(107) := ', ''img/ai.jpg'','||wwv_flow.LF||
'cast(trunc(sysdate + 35) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trun';
wwv_flow_imp.g_varchar2_table(108) := 'c(sysdate + 35) as timestamp with time zone) + interval ''16'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards ';
wwv_flow_imp.g_varchar2_table(109) := '(id, category, title, subtitle, body, secondary_body, icon_class, badge, image_url, start_date, end_';
wwv_flow_imp.g_varchar2_table(110) := 'date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(10, ''workshop'', ''HIPAA Compliance'', ''Ensuring Your App Meets HIPAA Compliancies'', ''HIP';
wwv_flow_imp.g_varchar2_table(111) := 'PA compliance is required for any application that deals with sensitive data such as medical history';
wwv_flow_imp.g_varchar2_table(112) := ' of patients. In this workshop you will understand the requirements that must be met before release,';
wwv_flow_imp.g_varchar2_table(113) := ' with special focus on personal sensitive data. It starts at 9 am and ends at 3 pm with lunch served';
wwv_flow_imp.g_varchar2_table(114) := ' at noon.'', ''<ul>'||wwv_flow.LF||
'<li>9am-10am: Introduction to HIPAA</li>'||wwv_flow.LF||
'<li>10am-11am: HIPAA Compliance Checklist';
wwv_flow_imp.g_varchar2_table(115) := '</li>'||wwv_flow.LF||
'<li>11am-Noon: Restricted Personal Data</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: App-Focused';
wwv_flow_imp.g_varchar2_table(116) := ' Risk Assessment</li>'||wwv_flow.LF||
'<li>2pm-3pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-medkit'', ''140.00'', ''img/hr.jpg'','||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(117) := 'cast(trunc(sysdate + 45) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 45) ';
wwv_flow_imp.g_varchar2_table(118) := 'as timestamp with time zone) + interval ''15'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, t';
wwv_flow_imp.g_varchar2_table(119) := 'itle, subtitle, body, secondary_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(11';
wwv_flow_imp.g_varchar2_table(120) := ', ''workshop'', ''Automated Testing'', ''Validate App Functionality Before Release'', ''This workshop cover';
wwv_flow_imp.g_varchar2_table(121) := 's automated build tools from you can setup unit, acceptance and UI testing. We will cover continuous';
wwv_flow_imp.g_varchar2_table(122) := ' integration and version control systems related to automated testing. A manager will provide insigh';
wwv_flow_imp.g_varchar2_table(123) := 't on how to prepare your software quality assurance team to cover all bases before, during and after';
wwv_flow_imp.g_varchar2_table(124) := ' tests, thus ensuring a release without bugs.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Automated Build Tools</li>'||wwv_flow.LF||
'<li>9a';
wwv_flow_imp.g_varchar2_table(125) := 'm-10am: Unit, Acceptance and UI Testing</li>'||wwv_flow.LF||
'<li>10am-11am: Continuous Integration (CI)</li>'||wwv_flow.LF||
'<li>11a';
wwv_flow_imp.g_varchar2_table(126) := 'm-Noon: Version Control Systems</li>'||wwv_flow.LF||
'<li>Noon-1pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Coding Standards</li>'||wwv_flow.LF||
'<li';
wwv_flow_imp.g_varchar2_table(127) := '>2pm-3pm: Managing Integrated Testing Projects</li>'||wwv_flow.LF||
'<li>3pm-4pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-che';
wwv_flow_imp.g_varchar2_table(128) := 'ck-square-o'', ''300.00'', ''img/chatbots.jpg'','||wwv_flow.LF||
'cast(trunc(sysdate + 55) as timestamp with time zone) + ';
wwv_flow_imp.g_varchar2_table(129) := 'interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 55) as timestamp with time zone) + interval ''16'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(130) := 'sert into eba_ut_demo_cards (id, category, title, subtitle, body, secondary_body, icon_class, badge,';
wwv_flow_imp.g_varchar2_table(131) := ' image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(12, ''workshop'', ''Database Modeling'', ''Design Data Models W';
wwv_flow_imp.g_varchar2_table(132) := 'ith Referential Integrity'', ''This workshop covers several design patterns for data modeling, includi';
wwv_flow_imp.g_varchar2_table(133) := 'ng graphs and classic models. There will be software tools available for the hands-on lab, so bring ';
wwv_flow_imp.g_varchar2_table(134) := 'your laptop. It will start at 8 am and ends at 4 pm. Lunch will be served, with vegan options for th';
wwv_flow_imp.g_varchar2_table(135) := 'ose interested.'', ''<ul>'||wwv_flow.LF||
'<li>8am-9am: Data Models Overview</li>'||wwv_flow.LF||
'<li>9am-10am: Graph Data Models</li>'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(136) := '<li>10am-11am: Classic Data Modeling</li>'||wwv_flow.LF||
'<li>11am-Noon: Performance-Driven Analysis</li>'||wwv_flow.LF||
'<li>Noon-1';
wwv_flow_imp.g_varchar2_table(137) := 'pm: Lunch</li>'||wwv_flow.LF||
'<li>1pm-2pm: Software Tools for Data Modeling</li>'||wwv_flow.LF||
'<li>2pm-3pm: Data Models Hands-on ';
wwv_flow_imp.g_varchar2_table(138) := 'Lab</li>'||wwv_flow.LF||
'<li>3pm-4pm: Review and Q&A</li>'||wwv_flow.LF||
'</ul>'', ''fa-database'', ''220.00'', ''img/collaboration.jpg'','||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(139) := 'cast(trunc(sysdate + 65) as timestamp with time zone) + interval ''8'' hour,'||wwv_flow.LF||
'cast(trunc(sysdate + 65) ';
wwv_flow_imp.g_varchar2_table(140) := 'as timestamp with time zone) + interval ''16'' hour'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, t';
wwv_flow_imp.g_varchar2_table(141) := 'itle, subtitle, body, secondary_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(13';
wwv_flow_imp.g_varchar2_table(142) := ', ''badge'', ''Fernanda Mendez'', ''Product Manager'', ''fernanda.mendez@yourcompany.com'', null, null, null';
wwv_flow_imp.g_varchar2_table(143) := ', ''img/persona-female01-apex.png'', null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title,';
wwv_flow_imp.g_varchar2_table(144) := ' subtitle, body, secondary_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(14, ''ba';
wwv_flow_imp.g_varchar2_table(145) := 'dge'', ''Krist Grohl'', ''Quality Manager'', ''k.grohl@yourcompany.com'', null, null, null, ''img/persona-ma';
wwv_flow_imp.g_varchar2_table(146) := 'le03.png'', null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, subtitle, body, seconda';
wwv_flow_imp.g_varchar2_table(147) := 'ry_body, icon_class, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(15, ''badge'', ''Charles Statman'',';
wwv_flow_imp.g_varchar2_table(148) := ' ''QA Specialist'', ''charlie.s@yourcompany.com'', null, null, null, ''img/persona-male01-apex.png'', null';
wwv_flow_imp.g_varchar2_table(149) := ', null);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, subtitle, body, secondary_body, icon_c';
wwv_flow_imp.g_varchar2_table(150) := 'lass, badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(16, ''badge'', ''Susan Parrish'', ''Software Develo';
wwv_flow_imp.g_varchar2_table(151) := 'per'', ''susan.parrish@yourcompany.com'', null, null, null, ''img/persona-female04-oracle.png'', null, nu';
wwv_flow_imp.g_varchar2_table(152) := 'll);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ut_demo_cards (id, category, title, subtitle, body, secondary_body, icon_class';
wwv_flow_imp.g_varchar2_table(153) := ', badge, image_url, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(17, ''badge'', ''Johnnathan Brie'', ''Team Lead'', ''john';
wwv_flow_imp.g_varchar2_table(154) := 'athan.b@yourcompany.com'', null, null, null, ''img/persona-male04-apex.png'', null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(155) := ' eba_ut_demo_cards (id, category, title, subtitle, body, secondary_body, icon_class, badge, image_ur';
wwv_flow_imp.g_varchar2_table(156) := 'l, start_date, end_date)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(18, ''badge'', ''Diana Flores'', ''CFO'', ''diana.flores@yourcompany.com'',';
wwv_flow_imp.g_varchar2_table(157) := ' null, null, null, ''img/persona-female03.png'', null, null);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2765583525875921787)
,p_install_id=>wwv_flow_imp.id(4040874964717609762)
,p_name=>'Add Cards Demo Table and Data'
,p_sequence=>10
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>'select null from user_tables where table_name = ''EBA_UT_DEMO_CARDS'''
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
