prompt --application/pages/page_00425
begin
--   Manifest
--     PAGE: 00425
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>425
,p_name=>'jQuery Mobile Components'
,p_alias=>'JQUERY-MOBILE-COMPONENTS'
,p_step_title=>'jQuery Mobile Components'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(2574898675351483580)
,p_step_template=>4075783602716660119
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'06'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7292417921389926816)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2806920191431269440)
,p_plug_name=>'Column Toggle Examples'
,p_static_id=>'column-toggle-examples'
,p_parent_plug_id=>wwv_flow_imp.id(2806920175357269439)
,p_icon_css_classes=>'fa-mouse-pointer'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark:margin-top-md'
,p_plug_template=>2044111091335791563
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<b>Column Toggle Examples</b>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2806920175357269439)
,p_plug_name=>'Column Toggle Report'
,p_static_id=>'column-toggle-report'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The column toggle table mode selectively hides columns at narrower widths as a sensible default but also offers a menu to let users manually control which columns they want to see.',
'',
'<p>The Column Toggle Report provides a responsive table-based report that can selectively hide columns based on the width of the screen. There is also a column selection control where you can manually set the columns to display. This component is ide'
||'ally suited for display tabular data in an easily consumable manner for small screen devices.</p>',
'',
'<p>Be sure to visit the <a href="f?p=&APP_ID.:1720">Components &rarr; Data Tables and Reports &rarr; Column Toggle Report</a> page for additional examples.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4010780530355111047)
,p_plug_name=>'jQuery Mobile is no longer supported'
,p_static_id=>'jquery-mobile-is-no-longer-supported'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:margin-bottom-lg'
,p_plug_template=>2044111091335791563
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Please note that jQuery Mobile applications are desupported.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4918627153952031286)
,p_plug_name=>'List View'
,p_static_id=>'list-view'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The List View component provides a simple list-based user interface that has a wide range of features. This component has built in search, list dividers, counters, nested lists, and more.</p>',
'',
'<p>Be sure to visit the <a href="f?p=&APP_ID.:1700">Components &rarr; List View</a> page for additional examples.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4320543399534920048)
,p_plug_name=>'List View Examples'
,p_static_id=>'list-view-examples'
,p_parent_plug_id=>wwv_flow_imp.id(4918627153952031286)
,p_icon_css_classes=>'fa-mouse-pointer'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark:margin-top-md'
,p_plug_template=>2044111091335791563
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<b>List View Examples</b>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2924174065628153686)
,p_plug_name=>'Mobile UI Patterns'
,p_static_id=>'mobile-ui-patterns'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Here are a number of Mobile UI Patterns you can follow as you build your next mobile app.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3107782396991750421)
,p_plug_name=>'Mobile UI Patterns'
,p_static_id=>'mobile-ui-patterns-2'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'t-MediaList--showIcons:u-colors'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(2624675180735897730)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2071422514019082236
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8712051984164905505)
,p_plug_name=>'Overview'
,p_static_id=>'overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>APEX 18.1 introduced three new Region Types that have been ported from the jQuery Mobile user interface. These components are light weight, mobile friendly, and can help to simplify your apps transition from jQuery Mobile to Universal Theme.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2807143632866099009)
,p_plug_name=>'Reflow Report'
,p_static_id=>'reflow-report'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The Reflow Report provides another responsive table-based report where on small screens, the table columns become stacked and each row becomes a block of data.',
'This is an alternative display to the Column Toggle Report and can be useful when you want to display all columns of a tabular report in a way that works well for small screens.</p>',
'',
'<p>Be sure to visit the <a href="f?p=&APP_ID.:1710">Components &rarr; Data Tables and Reports &rarr; Reflow Report</a> page for additional examples.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2807143747502099010)
,p_plug_name=>'Reflow Report Examples'
,p_static_id=>'reflow-report-examples'
,p_parent_plug_id=>wwv_flow_imp.id(2807143632866099009)
,p_icon_css_classes=>'fa-mouse-pointer'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark:margin-top-md'
,p_plug_template=>2044111091335791563
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<b>Reflow Report Examples</b>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4010780933294110436)
,p_plug_name=>'Responsive Design and Mobile UI Patterns'
,p_static_id=>'responsive-design-and-mobile-ui-patterns'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Universal Theme is designed to be responsive, so it will look and feel great on any screen size device. However, the patterns you use for your application may change depending on the your use cases. Here are some commonly asked questions that may '
||'provide some guidance as you build your next app.</p>',
'',
'<ul class="dm-UL">',
'  <li>',
'      <p><strong>How can I migrate my jQuery Mobile app to Universal Theme?</strong><br />',
'      For most apps, perhaps the simplest solution may be to start with a blank slate using Universal Theme.  Identify the key flows of your mobile app, and then reimagine them using all the features and functionality of Universal Theme.  This may be'
||' the perfect opportunity to experiment with the capabilities of Universal Theme and how you can use them to build an incredible small screen experience.</p>',
'  </li>',
'  <li>',
'      <p><strong>Should I build a separate app for mobile and desktop?</strong><br />',
'      This may be unnecessary for most cases. Unless your app will be primarily used on small screen devices, it may be better to optimize the UI of your app for the mobile use case rather than creating a separate app.  However, if you have a very sp'
||'ecific mobile use case, then by all means, build a separate app that is mobile-optimized and applies mobile UI patterns to provide a great small screen experience.</p>',
'  </li>',
'  <li>',
'      <p><strong>What are some things I should keep in mind as I develop my next mobile app?</strong><br />',
'      That''s a great question! First -- who are your users? What type of devices do they use? What is the primary usecase of your application? What is the setting in which your application is used? There are several things to consider before you writ'
||'e a single line of code. The more you understand your users and use cases, the more successful you will be with your APEX app.</p>',
'  </li>',
'</ul>',
'     '))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2806920371019269441)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2806920191431269440)
,p_button_name=>'COL_TOGGLE_1'
,p_static_id=>'col-toggle'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Example 1'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1721:&APP_SESSION.:sample1'',''Column Toggle Report'');'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2806920417789269442)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2806920191431269440)
,p_button_name=>'COL_TOGGLE_2'
,p_static_id=>'col-toggle-2'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Example 2'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1721:&APP_SESSION.:sample2'',''Column Toggle Report'');'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2807098094458914637)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4320543399534920048)
,p_button_name=>'LIST_1'
,p_static_id=>'list'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Example 1'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1701:&APP_SESSION.:sample1'',''List View'');'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2807098491632914637)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(4320543399534920048)
,p_button_name=>'LIST_2'
,p_static_id=>'list-2'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Example 2'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1701:&APP_SESSION.:sample2'',''List View'');'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2807143851439099011)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2807143747502099010)
,p_button_name=>'REFLOW_1'
,p_static_id=>'reflow'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Example 1'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1711:&APP_SESSION.:sample1'',''Reflow Report'');'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2807143954738099012)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2807143747502099010)
,p_button_name=>'REFLOW_2'
,p_static_id=>'reflow-2'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Example 2'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1711:&APP_SESSION.:sample2'',''Reflow Report'');'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp.component_end;
end;
/
