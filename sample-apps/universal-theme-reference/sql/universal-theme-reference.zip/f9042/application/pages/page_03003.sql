prompt --application/pages/page_03003
begin
--   Manifest
--     PAGE: 03003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3003
,p_name=>'Components - Comments'
,p_alias=>'COMMENTS-COMPONENT'
,p_step_title=>'Comments - &APP_TITLE.'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1861874853367418162)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920026291561065892)
,p_plug_name=>'Comments B'
,p_static_id=>'comments-b'
,p_region_name=>'ChatDemo'
,p_parent_plug_id=>wwv_flow_imp.id(1920026131770065891)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.ID,',
'       p.CREATED as COMMENT_DATE,',
'       lower(p.CREATED_BY) as USER_NAME,',
'       t.CREATED as TASK_CREATED,',
'       t.TASK_NAME || '' - '' || t.CREATED_BY as COMMENT_TEXT',
'  from EBA_UT_CHART_TASKS t,',
'       EBA_UT_CHART_PROJECTS p',
' where t.PROJECT = p.ID',
' order by t.CREATED'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$COMMENTS'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>true
,p_entity_title_singular=>'comment'
,p_entity_title_plural=>'comments'
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'ATTRIBUTES', '(&TASK_CREATED.)',
  'AVATAR_ICON', 'fa-user',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_TYPE', 'icon',
  'COMMENT_DATE', 'COMMENT_DATE',
  'COMMENT_TEXT', 'COMMENT_TEXT',
  'DISPLAY_AVATAR', 'Y',
  'STYLE', 't-Comments--chat',
  'USER_NAME', 'USER_NAME')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1920026539286065895)
,p_name=>'COMMENT_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENT_DATE'
,p_data_type=>'TIMESTAMP'
,p_display_sequence=>30
,p_format_mask=>'DD-MON-YYYY'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1920028067851065910)
,p_name=>'COMMENT_TEXT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENT_TEXT'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>120
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1920026297513065893)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1920027369302065903)
,p_name=>'TASK_CREATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TASK_CREATED'
,p_data_type=>'TIMESTAMP'
,p_display_sequence=>110
,p_format_mask=>'SINCE'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1920026596813065896)
,p_name=>'USER_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USER_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(1920028103051065911)
,p_region_id=>wwv_flow_imp.id(1920026291561065892)
,p_position_id=>357517927138372323
,p_display_sequence=>20
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(1920027804054065908)
,p_region_id=>wwv_flow_imp.id(1920026291561065892)
,p_position_id=>357310085755519673
,p_display_sequence=>10
,p_template_id=>357310677260527130
,p_label=>'Delete'
,p_static_id=>'delete'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3438296231241403)
,p_plug_name=>'Comments C'
,p_static_id=>'comments-c'
,p_parent_plug_id=>wwv_flow_imp.id(3438178431241402)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  select p.ID,',
'         p.CREATED as COMMENT_DATE,',
'         lower(p.CREATED_BY) as USER_NAME,',
'         t.CREATED as TASK_CREATED,',
'         t.TASK_NAME || '' - '' || t.CREATED_BY as COMMENT_TEXT,',
'         ''inbound'' as ALIGNMENT',
'    from EBA_UT_CHART_TASKS t,',
'         EBA_UT_CHART_PROJECTS p',
'   where t.PROJECT = p.ID',
'     and rownum = 1',
'',
'  union all',
'',
'  select p.ID,',
'         p.CREATED as COMMENT_DATE,',
'         lower(p.CREATED_BY) as USER_NAME,',
'         t.CREATED as TASK_CREATED,',
'         t.TASK_NAME || '' - '' || t.CREATED_BY as COMMENT_TEXT,',
'         ''outbound'' as ALIGNMENT',
'    from EBA_UT_CHART_TASKS t,',
'         EBA_UT_CHART_PROJECTS p',
'   where t.PROJECT = p.ID',
'     and rownum = 1'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$COMMENTS'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>true
,p_entity_title_singular=>'comment'
,p_entity_title_plural=>'comments'
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'ALIGNMENT', '&ALIGNMENT.',
  'APPLY_THEME_COLORS', 'Y',
  'ATTRIBUTES', '(&TASK_CREATED.)',
  'AVATAR_ICON', 'fa-user',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_TYPE', 'icon',
  'COMMENT_DATE', 'COMMENT_DATE',
  'COMMENT_TEXT', 'COMMENT_TEXT',
  'DISPLAY_AVATAR', 'Y',
  'STYLE', 't-Comments--chat',
  'USER_NAME', 'USER_NAME')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3439126595241412)
,p_name=>'ALIGNMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ALIGNMENT'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3438479437241405)
,p_name=>'COMMENT_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENT_DATE'
,p_data_type=>'TIMESTAMP'
,p_display_sequence=>20
,p_format_mask=>'DD-MON-YYYY'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3438742558241408)
,p_name=>'COMMENT_TEXT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENT_TEXT'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3438369839241404)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3438672488241407)
,p_name=>'TASK_CREATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TASK_CREATED'
,p_data_type=>'TIMESTAMP'
,p_display_sequence=>40
,p_format_mask=>'SINCE'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3438529055241406)
,p_name=>'USER_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USER_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1861875417611418164)
,p_plug_name=>'Components - Comments'
,p_static_id=>'components-comments'
,p_region_name=>'CommentsDemo'
,p_parent_plug_id=>wwv_flow_imp.id(1753723263347771595)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>35
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 as ID,',
'       ''JK'' as AVATAR_INITIALS,',
'       ''15 minutes ago'' as COMMENT_DATE,',
'       ''Praesent vel felis rutrum erat elementum viverra sit amet non odio. Cras vel auctor eros, ',
'        in malesuada dolor. Nulla tellus magna, ornare consectetur purus id, volutpat egestas felis. ',
'        Proin lobortis risus massa, nec faucibus arcu malesuada a. Nunc sed gravida urna. Fusce at ',
'        ligula sed erat consequat pharetra.'' as COMMENT_TEXT,',
'       ''Joel'' as USER_NAME',
'  from sys.dual',
'union all',
'select 2 as ID,',
'       ''JK'' as AVATAR_INITIALS,',
'       ''10 minutes ago'' as COMMENT_DATE,',
'       ''Praesent vel felis rutrum erat elementum viverra sit amet non odio. Cras vel auctor eros, ',
'        in malesuada dolor. Nulla tellus magna, ornare consectetur purus id, volutpat egestas felis. ',
'        Proin lobortis risus massa, nec faucibus arcu malesuada a. Nunc sed gravida urna. Fusce at ',
'        ligula sed erat consequat pharetra.'' as COMMENT_TEXT,',
'       ''Joel'' as USER_NAME',
'  from sys.dual',
'union all',
'select 3 as ID,',
'       ''JK'' as AVATAR_INITIALS,',
'       ''5 minutes ago'' as COMMENT_DATE,',
'       ''Praesent vel felis rutrum erat elementum viverra sit amet non odio. Cras vel auctor eros, ',
'        in malesuada dolor. Nulla tellus magna, ornare consectetur purus id, volutpat egestas felis. ',
'        Proin lobortis risus massa, nec faucibus arcu malesuada a. Nunc sed gravida urna. Fusce at ',
'        ligula sed erat consequat pharetra.'' as COMMENT_TEXT,',
'       ''Joel'' as USER_NAME',
'  from sys.dual'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$COMMENTS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_INITIALS', 'AVATAR_INITIALS',
  'AVATAR_SHAPE', 't-Avatar--circle',
  'AVATAR_TYPE', 'initials',
  'COMMENT_DATE', 'COMMENT_DATE',
  'COMMENT_TEXT', 'COMMENT_TEXT',
  'DISPLAY_AVATAR', 'Y',
  'STYLE', 't-Comments--basic',
  'USER_NAME', 'USER_NAME')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1861876460066418167)
,p_name=>'AVATAR_INITIALS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AVATAR_INITIALS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1861876993290418168)
,p_name=>'COMMENT_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENT_DATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1861877493781418168)
,p_name=>'COMMENT_TEXT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENT_TEXT'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1861875957562418167)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1861877945553418169)
,p_name=>'USER_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USER_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1905135309250067794)
,p_plug_name=>'Configuration: Basic'
,p_static_id=>'configuration-basic'
,p_parent_plug_id=>wwv_flow_imp.id(1753723263347771595)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2667762537863948531
,p_plug_display_sequence=>45
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Region</h4>',
'<strong>Type:</strong> Comments<br>',
'<strong>Template:</strong> Blank with Attributes (No Grid)<br>',
'',
'<h4>Attributes</h4>',
'Each row has <em>Comment Text</em>, a <em>User Name,</em> and a <em>Date</em>. <em>Avatar</em> is displayed, <em>Apply Theme Colors</em> is set to No, and <em>Style</em> is set to Basic.',
'',
'<h4>Avatar</h4>',
'<strong>Type:</strong> Initials<br>',
'<strong>Initials:</strong> <em>the AVATAR_INITIALS column</em><br>',
'<strong>Shape:</strong> Circular<br>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920028260605065912)
,p_plug_name=>'Configuration: Chat'
,p_static_id=>'configuration-chat'
,p_parent_plug_id=>wwv_flow_imp.id(1920026131770065891)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2667762537863948531
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Region</h4>',
'<strong>Type:</strong> Comments<br>',
'<strong>Template:</strong> Blank with Attributes (No Grid)<br>',
'',
'<h4>Attributes</h4>',
'Each row has <em>Comment Text</em>, a <em>User Name,</em> a <em>Date</em>, and <em>Attributes</em>. <em>Avatar</em> is displayed, <em>Apply Theme Colors</em> is set to Yes, and <em>Style</em> is set to Chat (Speech Bubbles).',
'',
'<h4>Avatar</h4>',
'<strong>Type:</strong> Icon<br>',
'<strong>Initials:</strong> fa-user<br>',
'<strong>Shape:</strong> Rounded<br>',
'',
'<h4>Actions</h4>',
'Each row has a <em>User Name Link</em> and a <em>Delete</em> button configured.'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3439231726241413)
,p_plug_name=>'Configuration: Thread'
,p_static_id=>'configuration-chat_1'
,p_parent_plug_id=>wwv_flow_imp.id(3438178431241402)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2667762537863948531
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Region</h4>',
'<strong>Type:</strong> Comments<br>',
'<strong>Template:</strong> Blank with Attributes (No Grid)<br>',
'',
'<h4>Attributes</h4>',
'Each row has <em>Comment Text</em>, a <em>User Name,</em> a <em>Date</em>, and <em>Attributes</em>. <em>Avatar</em> is displayed, <em>Apply Theme Colors</em> is set to Yes, and <em>Style</em> is set to Chat (Speech Bubbles). <em>Alignment</em> is set'
||' to either "inbound" or "outbound" to achieve the message thread style.',
'',
'<h4>Avatar</h4>',
'<strong>Type:</strong> Icon<br>',
'<strong>Initials:</strong> fa-user<br>',
'<strong>Shape:</strong> Rounded<br>',
'',
'<h4>Actions</h4>',
'Each row has a <em>User Name Link</em> and a <em>Delete</em> button configured.'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1753723263347771595)
,p_plug_name=>'Demo: Basic'
,p_static_id=>'demo-basic'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>25
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920026131770065891)
,p_plug_name=>'Demo: Chat'
,p_static_id=>'demo-chat'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>35
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3438178431241402)
,p_plug_name=>'Demo: Thread'
,p_static_id=>'demo-thread'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>45
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1753723133725771594)
,p_plug_name=>'Instructions'
,p_static_id=>'instructions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>15
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'REGION',
  'attribute_02', 'CommentsDemo')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1753723075259771593)
,p_plug_name=>'Overview'
,p_static_id=>'overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    The <strong>Comments</strong> component is used to display user comments and status updates.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1753723345168771596)
,p_plug_name=>'Region Display Selector'
,p_static_id=>'region-display-selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1905135463533067795)
,p_plug_name=>'Sample SQL Query'
,p_static_id=>'sample-sql-query'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>55
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.REGION_SOURCE_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'ChatDemo')).to_clob
);
wwv_flow_imp.component_end;
end;
/
