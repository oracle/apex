prompt --application/pages/page_03001
begin
--   Manifest
--     PAGE: 03001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3001
,p_name=>'Components - Avatar'
,p_alias=>'AVATAR-COMPONENT'
,p_step_title=>'Avatar - &APP_TITLE.'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16609229501828096)
,p_plug_name=>'Avatar'
,p_static_id=>'avatar'
,p_region_name=>'multipleDemo'
,p_parent_plug_id=>wwv_flow_imp.id(16609020534828094)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TITLE, ',
'       ''#APP_FILES#'' || IMAGE_URL as avatar',
'from EBA_UT_DEMO_CARDS',
'where category = ''badge'''))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$AVATAR'
,p_plug_query_num_rows=>20
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'CSS_CLASSES', 'u-color-29',
  'IMAGE', '{"source":"URL_COLUMN","urlColumn":"AVATAR"}',
  'SIZE', 't-Avatar--lg',
  'TYPE', 'IMAGE')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16609464931828098)
,p_name=>'AVATAR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AVATAR'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16609330016828097)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1861866939650271554)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1905136833653067809)
,p_name=>'Classic Report'
,p_static_id=>'classic-report'
,p_region_name=>'CRDemo'
,p_parent_plug_id=>wwv_flow_imp.id(1753721934289771582)
,p_template=>2103954283454391425
,p_display_sequence=>45
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff'
,p_grid_column_span=>8
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       TITLE as name, ',
'       SUBTITLE as job,',
'       BODY as email,',
'       ''#APP_FILES#'' || IMAGE_URL as avatar',
'  from EBA_UT_DEMO_CARDS',
' where category = ''badge'''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2542081983073888486
,p_query_num_rows=>5
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1892667594001316478)
,p_query_column_id=>5
,p_column_alias=>'AVATAR'
,p_column_display_sequence=>60
,p_column_heading=>'Avatar'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{with/}',
'        TYPE:=IMAGE',
'        IMAGE:=#AVATAR#',
'        IMAGE_ALT:=Employee Profile Image',
'        SIZE:=t-Avatar--lg',
'        SHAPE:=t-Avatar--circle',
'        CSS_CLASSES:=u-color-29',
'    {apply THEME$AVATAR/}'))
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1892667760432316480)
,p_query_column_id=>4
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>80
,p_column_heading=>'Email'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1956804758101303781)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1892667885771316481)
,p_query_column_id=>3
,p_column_alias=>'JOB'
,p_column_display_sequence=>90
,p_column_heading=>'Job'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1892667626628316479)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>70
,p_column_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1916069037094558474)
,p_plug_name=>'Configuration: Classic Report'
,p_static_id=>'configuration-classic-report'
,p_parent_plug_id=>wwv_flow_imp.id(1753721934289771582)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2667762537863948531
,p_plug_display_sequence=>55
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Region</h4>',
'<strong>Type:</strong> Classic Report<br>',
'',
'<h4>Avatar Column</h4>',
'<p>The <strong>Avatar</strong> column uses the with-apply syntax in the HTML Expression attribute under Column Formatting to access the <em>Avatar</em> partial and display an avatar in each row.</p>',
'<strong>Type:</strong> Plain Text<br>',
'<strong>HTML Expression:</strong>',
'<code>',
'    {with/}',
'        TYPE:=IMAGE',
'        IMAGE:=#AVATAR#',
'        IMAGE_ALT:=Employee Profile Image',
'        SIZE:=t-Avatar--lg',
'        SHAPE:=t-Avatar--circle',
'        CSS_CLASSES:=u-color-29',
'    {apply THEME$AVATAR/}',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1905136699902067808)
,p_plug_name=>'Configuration: Interactive Report'
,p_static_id=>'configuration-interactive-report'
,p_parent_plug_id=>wwv_flow_imp.id(1916069191113558475)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2667762537863948531
,p_plug_display_sequence=>45
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Region</h4>',
'<strong>Type:</strong> Interactive Report<br>',
'',
'<h4>Avatar Column</h4>',
'<p>In Interactive Reports, the <em>Avatar</em> partial is available for use as a column Type. The Avatar column in this demo uses the Avatar column Type and associated Partial settings to display an avatar in each row.</p>',
'',
'<h4>Avatar</h4>',
'<strong>Type:</strong> Initials<br>',
'<strong>Initials:</strong> Initials source column<br>',
'<strong>Shape:</strong> Default<br>',
'<strong>Size:</strong> Default<br>',
'<strong>CSS Classes:</strong> u-color-13'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16609565353828099)
,p_plug_name=>'Configuration: Multiple (Report)'
,p_static_id=>'configuration-multiple-report'
,p_parent_plug_id=>wwv_flow_imp.id(16609020534828094)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2667762537863948531
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Region</h4>',
'<strong>Type:</strong> Avatar<br>',
'<strong>Display:</strong> Multiple (Report)<br>',
'',
'<h4>Attributes</h4>',
'<strong>Type:</strong> Image<br>',
'<strong>Image:</strong> AVATAR<br>',
'<strong>Shape:</strong> Default<br>',
'<strong>Size:</strong> Large<br>',
'<strong>CSS Classes:</strong> u-color-29'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1753721934289771582)
,p_plug_name=>'Demo: Classic Report'
,p_static_id=>'demo-classic-report'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1916069191113558475)
,p_plug_name=>'Demo: Interactive Report'
,p_static_id=>'demo-interactive-report'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16609020534828094)
,p_plug_name=>'Demo: Multiple (Report)'
,p_static_id=>'demo-multiple-report'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1905135558770067796)
,p_plug_name=>'Interactive Report'
,p_static_id=>'interactive-report'
,p_region_name=>'IRDemo'
,p_parent_plug_id=>wwv_flow_imp.id(1916069191113558475)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2103954283454391425
,p_plug_display_sequence=>35
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       TITLE as name, ',
'       SUBTITLE as job,',
'       BODY as email,',
'       substr(TITLE, 0, 2) as AVATAR',
'  from EBA_UT_DEMO_CARDS',
' where category = ''badge'''))
,p_plug_source_type=>'NATIVE_IR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1905135690572067797)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_show_search_bar=>'N'
,p_show_search_textbox=>'N'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'NONE'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_select_columns=>'N'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_download=>'N'
,p_show_help=>'N'
,p_enable_mail_download=>'N'
,p_internal_uid=>386405396485599035
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1892667940930316482)
,p_db_column_name=>'AVATAR'
,p_display_order=>60
,p_column_identifier=>'Q'
,p_column_label=>'Avatar'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'TMPL_THEME_42$AVATAR'
,p_column_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'CSS_CLASSES', 'u-color-13',
  'INITIALS', 'AVATAR',
  'TYPE', 'INITIALS')).to_clob
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1892667358096316476)
,p_db_column_name=>'EMAIL'
,p_display_order=>40
,p_column_identifier=>'O'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1956804227096303776)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'J'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1892667433390316477)
,p_db_column_name=>'JOB'
,p_display_order=>50
,p_column_identifier=>'P'
,p_column_label=>'Job'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1892667228185316475)
,p_db_column_name=>'NAME'
,p_display_order=>30
,p_column_identifier=>'N'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1916027733321461513)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3972975'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5
,p_report_columns=>'NAME:EMAIL:JOB:AVATAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1753722088631771583)
,p_plug_name=>'Overview'
,p_static_id=>'overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    <strong>Avatars</strong> are useful for displaying an icon, image, or initials within a region. An Avatar can be used to display a single (partial) avatar, as multiple (report) avatars, or can be applied as a column type or in report templates to'
||' display an avatar for each report row. The multiple (report) display type is useful for being able to display multiple avatars as one region on a page outside of a report.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1753721883260771581)
,p_plug_name=>'Region Display Selector'
,p_static_id=>'region-display-selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1892667113262316474)
,p_plug_name=>'Sample SQL Query: Classic Report'
,p_static_id=>'sample-sql-query-classic-report'
,p_parent_plug_id=>wwv_flow_imp.id(1753721934289771582)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2667762537863948531
,p_plug_display_sequence=>65
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.REGION_SOURCE_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'CRDemo')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1905134603857067787)
,p_plug_name=>'Sample SQL Query: Interactive Report'
,p_static_id=>'sample-sql-query-interactive-report'
,p_parent_plug_id=>wwv_flow_imp.id(1916069191113558475)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2667762537863948531
,p_plug_display_sequence=>65
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.REGION_SOURCE_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'IRDemo')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16609595923828100)
,p_plug_name=>'Sample SQL Query: Multiple (Report)'
,p_static_id=>'sample-sql-query-multiple-report'
,p_parent_plug_id=>wwv_flow_imp.id(16609020534828094)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2667762537863948531
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.REGION_SOURCE_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'multipleDemo')).to_clob
);
wwv_flow_imp.component_end;
end;
/
