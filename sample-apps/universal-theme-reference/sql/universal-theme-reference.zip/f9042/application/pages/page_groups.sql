prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 9042
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2421696170353883330)
,p_group_name=>'Components'
,p_static_id=>'components'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2574898675351483580)
,p_group_name=>'Design'
,p_static_id=>'design'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2447663907894708185)
,p_group_name=>'Migration Guide'
,p_static_id=>'migration-guide'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2730271612854070151)
,p_group_name=>'Tools and Utilities'
,p_static_id=>'tools-and-utilities'
);
wwv_flow_imp.component_end;
end;
/
