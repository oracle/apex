prompt --application/pages/page_00424
begin
--   Manifest
--     PAGE: 00424
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>424
,p_name=>'Touch Gestures'
,p_alias=>'TOUCH-GESTURES'
,p_step_title=>'Touch Gestures'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(2574898675351483580)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.touch-region {',
'  -webkit-user-select: none;',
'     -moz-user-select: none;',
'      -ms-user-select: none;',
'          user-select: none; }',
'',
'.touch-region .anim-icon {',
'  height: 8rem;',
'  border-radius: var(--ut-comonent-border-radius, 0.125rem);',
'  background-color: rgba(255, 239, 94, 0.25);',
'  box-shadow: 0 0 0 1px var(--ut-comonent-border-color, rgba(0, 0, 0, 0.05)) inset;',
'  width: 100%;',
'  display: flex;',
'  align-items: center;',
'  justify-content: center;',
'  flex-direction: column;',
'  position: relative;',
'  overflow: hidden; }',
'',
'.js-event-icon {',
'  width: 3rem;',
'  height: 3rem;',
'  line-height: 3rem;',
'  text-align: center;',
'  border-radius: 100%;',
'  background-color: var(--ut-palette-primary, #3170C8);',
'  color: var(--ut-palette-primary-contrast, #FFF);',
'  transition: .2s transform ease; }',
'',
'.js-event-text {',
'  font-family: monospace; }',
'',
'.touch-region.is-active .anim-icon .fa {',
'  -webkit-animation: touch-active .5s forwards ease;',
'          animation: touch-active .5s forwards ease; }',
'',
'@-webkit-keyframes touch-active {',
'  0% {',
'    transform: scale(1) rotate(0deg); }',
'  10% {',
'    transform: scale(0.85) rotate(50deg); }',
'  50% {',
'    transform: scale(1.5) rotate(90deg); }',
'  100% {',
'    transform: scale(1) rotate(0deg); } }',
'',
'@keyframes touch-active {',
'  0% {',
'    transform: scale(1) rotate(0deg); }',
'  10% {',
'    transform: scale(0.85) rotate(50deg); }',
'  50% {',
'    transform: scale(1.5) rotate(90deg); }',
'  100% {',
'    transform: scale(1) rotate(0deg); } }'))
,p_step_template=>4075783602716660119
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4884990528861253735)
,p_plug_name=>'Available Gestures'
,p_static_id=>'available-gestures'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>APEX 18.1 provides declarative support for the following touch gestures via Dynamic Actions:</p>',
'',
'<ul>',
'  <li>tap and double tap</li>',
'  <li>press</li>',
'  <li>swipe</li>',
'  <li>pan</li>',
'</ul>',
'',
'<p>Note: While APEX wraps these touch events to make them accessible via Dynamic Actions, the underlying touch support is powered using the <a href="http://hammerjs.github.io/" target="_blank" rel="noopener noreferrer">hammer.js</a> library.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7258781296299149265)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2806918760546269425)
,p_plug_name=>'Details'
,p_static_id=>'details'
,p_parent_plug_id=>wwv_flow_imp.id(2806918493499269423)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><b>Notable <code>press</code> event data</b></p>',
'<ul>',
'  <li><code>this.data.pointerType</code> type of pointer (mouse or touch)</li>',
'</ul>',
'<p>Note: <code>press</code> events can also be triggered by clicking and holding</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2806919011258269428)
,p_plug_name=>'Details'
,p_static_id=>'details-2'
,p_parent_plug_id=>wwv_flow_imp.id(2806918873436269426)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><b>Notable <code>swipe</code> event data</b></p>',
'<ul>',
'  <li><code>this.data.offsetDirection</code> swipe direction (2 left, 4 right)</li>',
'  <li><code>this.data.distance</code> distance of the swipe gesture</li>',
'  <li><code>this.data.pointerType</code> type of pointer (mouse or touch)</li>',
'</ul>',
'<p>Note: <code>swipe</code> events can also be triggered by clicking and quickly moving the cursor to the right or left</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2806919317120269431)
,p_plug_name=>'Details'
,p_static_id=>'details-3'
,p_parent_plug_id=>wwv_flow_imp.id(2806919186616269429)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><b>Notable <code>pan</code> event data</b></p>',
'<ul>',
'  <li><code>this.data.offsetDirection</code> swipe direction (2 left, 4 right, 8 up, 16 down)</li>',
'  <li><code>this.data.isFinal</code> returns <code>true</code> if it is the last input</li>',
'  <li><code>this.data.pointerType</code> type of pointer (mouse or touch)</li>',
'</ul>',
'<p>Note: <code>pan</code> events can also be triggered by clicking and dragging</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2784974222798256825)
,p_plug_name=>'Details'
,p_static_id=>'details-4'
,p_parent_plug_id=>wwv_flow_imp.id(3530156698138458993)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><b>Notable <code>tap</code> event data</b></p>',
'<ul>',
'  <li><code>this.data.tapCount</code> number of times the screen was tapped</li>',
'  <li><code>this.data.pointerType</code> type of pointer (mouse or touch)</li>',
'</ul>',
'<p>Note: <code>tap</code> events can also be triggered by clicking</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8678415359074127954)
,p_plug_name=>'Overview'
,p_static_id=>'overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Adding touch support to your APEX apps help provide an improved and more natural mobile experience. This is especially important if your apps are more likely to be used on touch devices, such as smartphones or tablest. This page walks you through '
||'how you can use declarative touch events, introduced in APEX 18.1, to build touch friendly UIs.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2806919186616269429)
,p_plug_name=>'Pan'
,p_static_id=>'pan'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2806918493499269423)
,p_plug_name=>'Press'
,p_static_id=>'press'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2806918873436269426)
,p_plug_name=>'Swipe'
,p_static_id=>'swipe'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3530156698138458993)
,p_plug_name=>'Tap'
,p_static_id=>'tap'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2806918667105269424)
,p_plug_name=>'Touch Region'
,p_static_id=>'touch-region'
,p_region_name=>'press_region'
,p_parent_plug_id=>wwv_flow_imp.id(2806918493499269423)
,p_region_css_classes=>'touch-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="anim-icon">',
'<span class="fa fa-hand-pointer-o fa-lg js-event-icon" aria-hidden="true"></span> <span class="js-event-text">Press me!</span>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2806918894330269427)
,p_plug_name=>'Touch Region'
,p_static_id=>'touch-region-2'
,p_region_name=>'swipe_region'
,p_parent_plug_id=>wwv_flow_imp.id(2806918873436269426)
,p_region_css_classes=>'touch-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="anim-icon">',
'<span class="fa fa-hand-pointer-o fa-lg js-event-icon" aria-hidden="true"></span> <span class="js-event-text">Swipe me!</span>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2806919212191269430)
,p_plug_name=>'Touch Region'
,p_static_id=>'touch-region-3'
,p_region_name=>'pan_region'
,p_parent_plug_id=>wwv_flow_imp.id(2806919186616269429)
,p_region_css_classes=>'touch-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="anim-icon">',
'<span class="fa fa-hand-pointer-o fa-lg js-event-icon" aria-hidden="true"></span> <span class="js-event-text">Pan me!</span>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2784974150612256824)
,p_plug_name=>'Touch Region'
,p_static_id=>'touch-region-4'
,p_region_name=>'tap_region'
,p_parent_plug_id=>wwv_flow_imp.id(3530156698138458993)
,p_region_css_classes=>'touch-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="anim-icon">',
'<span class="fa fa-hand-pointer-o fa-lg js-event-icon" aria-hidden="true"></span> <span class="js-event-text">Tap me!</span>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2784973113331256814)
,p_name=>'Pan'
,p_static_id=>'pan'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2806919212191269430)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexpan'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2784973263380256815)
,p_event_id=>wwv_flow_imp.id(2784973113331256814)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'var touchRegion$ = $(this.triggeringElement);',
    'var text$ = touchRegion$.find(".js-event-text");',
    'var icon$ = touchRegion$.find(".js-event-icon");',
    'var swipeDir = this.data.offsetDirection;',
    '',
    'var offsetX = (touchRegion$.outerWidth() / 2) - 24;',
    '',
    'var message, icon;',
    '',
    'if (swipeDir === 2) {',
    '    message = ''Panning Left!''',
    '    icon = ''fa-hand-o-left''',
    '} else if (swipeDir === 4) {',
    '    message = ''Panning Right!''',
    '    icon = ''fa-hand-o-right''',
    '}',
    '',
    'if (this.data.isFinal ) {',
    '    icon$.css("position","static");',
    '} else {',
    '    icon$.css({',
    '        position: "absolute",',
    '        left: this.data.deltaX + offsetX',
    '    })',
    '}',
    '',
    '// reset icon after 1000 ms',
    'setTimeout(function(){',
    '    icon$.css("position","static");',
    '}, 1000);',
    '',
    'text$.text(message);',
    'icon$.removeClass("fa-hand-pointer-o fa-hand-o-right fa-hand-o-left fa-hand-o-up fa-hand-o-down").addClass(icon);')))).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2773330032670185051)
,p_name=>'Press'
,p_static_id=>'press'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2806918667105269424)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexpress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2773330149627185052)
,p_event_id=>wwv_flow_imp.id(2773330032670185051)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'var touchRegion$ = $(this.triggeringElement);',
    'touchRegion$.find(".js-event-text").text("Pressed!");',
    '',
    'var animationEvent = ''webkitAnimationEnd oanimationend msAnimationEnd animationend'';',
    '',
    'touchRegion$.addClass(''is-active'');',
    'touchRegion$.find(".js-event-icon").removeClass("fa-hand-pointer-o").addClass("fa-hand-grab-o");',
    'touchRegion$.one(animationEvent, function(event) {',
    '    touchRegion$.removeClass(''is-active'').find(".js-event-icon").addClass("fa-hand-pointer-o").removeClass("fa-hand-grab-o");',
    '});')))).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2784972941743256812)
,p_name=>'Swipe'
,p_static_id=>'swipe'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2806918894330269427)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexswipe'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2784973011390256813)
,p_event_id=>wwv_flow_imp.id(2784972941743256812)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'var touchRegion$ = $(this.triggeringElement);',
    'var text$ = touchRegion$.find(".js-event-text");',
    'var icon$ = touchRegion$.find(".js-event-icon");',
    'var swipeDir = this.data.offsetDirection;',
    '',
    'var message, icon;',
    '',
    'if (swipeDir === 2) {',
    '    message = ''Swiped Left!''',
    '    icon = ''fa-hand-o-left''',
    '} else if (swipeDir === 4) {',
    '    message = ''Swiped Right!''',
    '    icon = ''fa-hand-o-right''',
    '}',
    '',
    'text$.text(message);',
    '',
    'icon$.removeClass("fa-hand-pointer-o fa-hand-o-right fa-hand-o-left").addClass(icon);',
    'var animationEvent = ''webkitAnimationEnd oanimationend msAnimationEnd animationend'';',
    'touchRegion$.addClass(''is-active'');',
    'touchRegion$.one(animationEvent, function(event) {',
    '    touchRegion$.removeClass(''is-active'');',
    '});')))).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2773329611854185047)
,p_name=>'Tap'
,p_static_id=>'tap'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2784974150612256824)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apextap'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2773329786779185048)
,p_event_id=>wwv_flow_imp.id(2773329611854185047)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'var tapCount = this.data.tapCount;',
    'var touchRegion$ = $(this.triggeringElement);',
    'touchRegion$.find(".js-event-text").text("Tapped " + tapCount + " times!");',
    '',
    'var animationEvent = ''webkitAnimationEnd oanimationend msAnimationEnd animationend'';',
    'touchRegion$.addClass(''is-active'');',
    'touchRegion$.one(animationEvent, function(event) {',
    '    touchRegion$.removeClass(''is-active'');',
    '});')))).to_clob
);
wwv_flow_imp.component_end;
end;
/
