prompt --application/pages/page_03007
begin
--   Manifest
--     PAGE: 03007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3007
,p_name=>'Components: Metric Card'
,p_alias=>'METRIC-CARD'
,p_step_title=>'Metric Card'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(2421696170353883330)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.class, .class-value, .class-desc {',
'  display: inline-block;',
'  font-size: 12px;',
'  font-family: ''Menlo'', ''Consolas'', monospace;',
'}',
'.class {',
'  color: #9C27B0;',
'}'))
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3492062104169224)
,p_plug_name=>'Instructions'
,p_static_id=>'MetricCardDemo'
,p_region_name=>'METRIC_CARD'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:t-ContentBlock--shadowBG'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'REGION',
  'attribute_02', 'MetricCardDemo')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3529979975573958)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3493742561169241)
,p_plug_name=>'Configuration'
,p_static_id=>'configuration'
,p_parent_plug_id=>wwv_flow_imp.id(3494699696169250)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody:margin-bottom-lg'
,p_plug_template=>2667762537863948531
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Region</h4>',
'<b>Type</b>: Metric Card<br>',
'<br>',
'<h4>Settings</h4>',
'Utilizes Title, Metric and Meta with the 3 Column Layout. Metric CSS Classes set with <span class="class">u-bold</span> utility class.<br>',
'<br>',
'<h4>Avatar</h4>',
'<b>Type</b>: Icon<br>',
'<b>Position</b>: Inline<br>',
'<br>',
'<h4>Badge</h4>',
'Utilizes State and Icon with the Subtle Style set.<br>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3494507456169249)
,p_plug_name=>'Configuration'
,p_static_id=>'configuration_1'
,p_parent_plug_id=>wwv_flow_imp.id(3893069325948901)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2667762537863948531
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Region</h4>',
'<b>Type</b>: Metric Card<br>',
'<br>',
'<h4>Settings</h4>',
'Utilizes Title, Metric and Meta with the Default Layout.<br>',
'<br>',
'<h4>Avatar</h4>',
'<b>Type</b>: Icon<br>',
'<b>Position</b>: Top<br>',
'<b>Shape</b>: Circular<br>',
'<br>',
'<h4>Badge</h4>',
'Utilizes State and Icon with the Outline Style set.<br>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3893918874948910)
,p_plug_name=>'Configuration'
,p_static_id=>'configuration_2'
,p_parent_plug_id=>wwv_flow_imp.id(3893124902948902)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody:margin-bottom-lg'
,p_plug_template=>2667762537863948531
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_display_column=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Region</h4>',
'<b>Type</b>: Metric Card<br>',
'<br>',
'<h4>Settings</h4>',
'Utilizes Title, Metric and Meta with the Stacked Layout. Metric CSS Classes set with <span class="class">u-text-title-5</span> utility class<br>',
'<br>',
'<h4>Avatar</h4>',
'<b>Type</b>: Icon<br>',
'<b>Position</b>: Top<br>',
'<b>Alignment</b>: Center<br>',
'<br>',
'<h4>Badge</h4>',
'Utilizes State and Icon with the Default Style set.<br>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3893069325948901)
,p_plug_name=>'Default Layout with Avatar and Badge'
,p_static_id=>'default-layout'
,p_parent_plug_id=>wwv_flow_imp.id(3493452398169238)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3493452398169238)
,p_plug_name=>'Demo'
,p_static_id=>'demo'
,p_title=>'Demo'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3494699696169250)
,p_plug_name=>'Inline Avatar and 3 Column Layout'
,p_static_id=>'inline-avatar-and-3-column-layout'
,p_parent_plug_id=>wwv_flow_imp.id(3493452398169238)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3490183871169205)
,p_plug_name=>'Metric Card'
,p_static_id=>'new'
,p_title=>'Demo'
,p_region_name=>'MetricCardDemo'
,p_parent_plug_id=>wwv_flow_imp.id(3893124902948902)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT                                                         ',
'      company_name,                                                         ',
'      ticker,',
'      ''$'' || TO_CHAR(current_price, ''FM999,990.00'')       AS     ',
'  stock_price,          ',
'      TO_CHAR(ABS(pct_change), ''FM990.00'') || ''%''         AS',
'  stock_change,',
'      CASE',
'          WHEN pct_change > 0  THEN ''success''',
'          WHEN pct_change < 0  THEN ''danger''',
'      END                                                  AS',
'  state,',
'      CASE',
'          WHEN pct_change > 0  THEN ''fa-arrow-up''',
'          WHEN pct_change < 0  THEN ''fa-arrow-down''',
'      END                                                  AS',
'  icon_class',
'  FROM (',
'      SELECT ''Apple''     AS company_name, ''AAPL''  AS ticker,',
'  189.45 AS current_price,  2.34 AS pct_change FROM dual UNION',
'  ALL',
'      SELECT ''Microsoft'' AS company_name, ''MSFT''  AS ticker,',
'  415.80 AS current_price, -0.87 AS pct_change FROM dual UNION',
'  ALL',
'      SELECT ''Google''    AS company_name, ''GOOGL'' AS ticker,',
'  175.20 AS current_price,  1.12 AS pct_change FROM dual UNION',
'  ALL',
'      SELECT ''Amazon''    AS company_name, ''AMZN''  AS ticker,',
'  198.60 AS current_price, -3.45 AS pct_change FROM dual UNION',
'  ALL',
'      SELECT ''Tesla''     AS company_name, ''TSLA''  AS ticker,',
'  245.10 AS current_price,  1.00 AS pct_change FROM dual',
'  )'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$METRIC_CARD'
,p_plug_query_num_rows=>50
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AVATAR_ALIGNMENT', 't-MetricCard-body--avatarAlignmentCenter',
  'AVATAR_ICON', 'fa-line-chart',
  'AVATAR_POSITION', 't-MetricCard-body--avatarPositionInline',
  'AVATAR_SHAPE', 't-Avatar--square',
  'AVATAR_STYLE', 't-MetricCard-avatar--subtle',
  'AVATAR_TYPE', 'icon',
  'BADGE_ICON', '&ICON_CLASS.',
  'BADGE_LABEL', '&VALUE_DESCRIPTION.',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_SIZE', 't-Badge--lg',
  'BADGE_STATE', 'STATE',
  'BADGE_VALUE', 'STOCK_CHANGE',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'LAYOUT', 'stacked',
  'META', '&COMPANY_NAME.',
  'METRIC', '&STOCK_PRICE.',
  'METRIC_CSS_CLASSES', 'u-text-title-5',
  'TITLE', '&TICKER.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3493045804169234)
,p_name=>'COMPANY_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMPANY_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3493379657169237)
,p_name=>'ICON_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3491818524169222)
,p_name=>'STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3493247922169236)
,p_name=>'STOCK_CHANGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STOCK_CHANGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3493141479169235)
,p_name=>'STOCK_PRICE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STOCK_PRICE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3491947304169223)
,p_name=>'TICKER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TICKER'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3493851368169242)
,p_plug_name=>'Metric Card'
,p_static_id=>'new_1'
,p_title=>'Demo'
,p_parent_plug_id=>wwv_flow_imp.id(3893069325948901)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>40
,p_plug_grid_column_span=>9
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT                                                         ',
'      company_name,                                                         ',
'      ticker,',
'      ''$'' || TO_CHAR(current_price, ''FM999,990.00'')       AS     ',
'  stock_price,          ',
'      TO_CHAR(ABS(pct_change), ''FM990.00'') || ''%''         AS',
'  stock_change,',
'      CASE',
'          WHEN pct_change > 0  THEN ''success''',
'          WHEN pct_change < 0  THEN ''danger''',
'      END                                                  AS',
'  state,',
'      CASE',
'          WHEN pct_change > 0  THEN ''fa-arrow-up''',
'          WHEN pct_change < 0  THEN ''fa-arrow-down''',
'      END                                                  AS',
'  icon_class',
'  FROM (',
'      SELECT ''Apple''     AS company_name, ''AAPL''  AS ticker,',
'  189.45 AS current_price,  2.34 AS pct_change FROM dual UNION',
'  ALL',
'      SELECT ''Microsoft'' AS company_name, ''MSFT''  AS ticker,',
'  415.80 AS current_price, -0.87 AS pct_change FROM dual UNION',
'  ALL',
'      SELECT ''Google''    AS company_name, ''GOOGL'' AS ticker,',
'  175.20 AS current_price,  1.12 AS pct_change FROM dual UNION',
'  ALL',
'      SELECT ''Amazon''    AS company_name, ''AMZN''  AS ticker,',
'  198.60 AS current_price, -3.45 AS pct_change FROM dual UNION',
'  ALL',
'      SELECT ''Tesla''     AS company_name, ''TSLA''  AS ticker,',
'  245.10 AS current_price,  1.00 AS pct_change FROM dual',
'  )'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$METRIC_CARD'
,p_plug_query_num_rows=>50
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AVATAR_ICON', 'fa-line-chart',
  'AVATAR_POSITION', 't-MetricCard-body--avatarPositionTop',
  'AVATAR_SHAPE', 't-Avatar--circle',
  'AVATAR_TYPE', 'icon',
  'BADGE_ICON', '&ICON_CLASS.',
  'BADGE_LABEL', '&VALUE_DESCRIPTION.',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_SHAPE', 't-Badge--square',
  'BADGE_STATE', 'STATE',
  'BADGE_STYLE', 't-Badge--outline',
  'BADGE_VALUE', 'STOCK_CHANGE',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'META', '&COMPANY_NAME.',
  'METRIC', '&STOCK_PRICE.',
  'TITLE', '&TICKER.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3494157117169245)
,p_name=>'COMPANY_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMPANY_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3494431023169248)
,p_name=>'ICON_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3493972187169243)
,p_name=>'STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3494388280169247)
,p_name=>'STOCK_CHANGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STOCK_CHANGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3494286576169246)
,p_name=>'STOCK_PRICE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STOCK_PRICE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3494044730169244)
,p_name=>'TICKER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TICKER'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3893205451948903)
,p_plug_name=>'Metric Card'
,p_static_id=>'new_2'
,p_title=>'Demo'
,p_parent_plug_id=>wwv_flow_imp.id(3494699696169250)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>9
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT                                                         ',
'      company_name,                                                         ',
'      ticker,',
'      ''$'' || TO_CHAR(current_price, ''FM999,990.00'')       AS     ',
'  stock_price,          ',
'      TO_CHAR(ABS(pct_change), ''FM990.00'') || ''%''         AS',
'  stock_change,',
'      CASE',
'          WHEN pct_change > 0  THEN ''success''',
'          WHEN pct_change < 0  THEN ''danger''',
'      END                                                  AS',
'  state,',
'      CASE',
'          WHEN pct_change > 0  THEN ''fa-arrow-up''',
'          WHEN pct_change < 0  THEN ''fa-arrow-down''',
'      END                                                  AS',
'  icon_class',
'  FROM (',
'      SELECT ''Apple''     AS company_name, ''AAPL''  AS ticker,',
'  189.45 AS current_price,  2.34 AS pct_change FROM dual UNION',
'  ALL',
'      SELECT ''Microsoft'' AS company_name, ''MSFT''  AS ticker,',
'  415.80 AS current_price, -0.87 AS pct_change FROM dual UNION',
'  ALL',
'      SELECT ''Google''    AS company_name, ''GOOGL'' AS ticker,',
'  175.20 AS current_price,  1.12 AS pct_change FROM dual UNION',
'  ALL',
'      SELECT ''Amazon''    AS company_name, ''AMZN''  AS ticker,',
'  198.60 AS current_price, -3.45 AS pct_change FROM dual UNION',
'  ALL',
'      SELECT ''Tesla''     AS company_name, ''TSLA''  AS ticker,',
'  245.10 AS current_price,  1.00 AS pct_change FROM dual',
'  )'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$METRIC_CARD'
,p_plug_query_num_rows=>50
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AVATAR_ALIGNMENT', 't-MetricCard-body--avatarAlignmentStart',
  'AVATAR_ICON', 'fa-line-chart',
  'AVATAR_POSITION', 't-MetricCard-body--avatarPositionInline',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_TYPE', 'icon',
  'BADGE_ICON', '&ICON_CLASS.',
  'BADGE_LABEL', '&VALUE_DESCRIPTION.',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_STATE', 'STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'STOCK_CHANGE',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'LAYOUT', '3cols',
  'META', '&COMPANY_NAME.',
  'METRIC', '&STOCK_PRICE.',
  'METRIC_CSS_CLASSES', 'u-text-bold',
  'TITLE', '&TICKER.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3893504558948906)
,p_name=>'COMPANY_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMPANY_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3893824595948909)
,p_name=>'ICON_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3893320509948904)
,p_name=>'STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3893762799948908)
,p_name=>'STOCK_CHANGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STOCK_CHANGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3893657388948907)
,p_name=>'STOCK_PRICE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STOCK_PRICE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3893453837948905)
,p_name=>'TICKER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TICKER'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1760869891843880438)
,p_plug_name=>'Overview'
,p_static_id=>'overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p><strong>Metric Card</strong> is a compact card used to display a single key value alongside a label and supporting details, ideal for presenting KPIs, stats, or at-a-glance data points in a dashboard. </p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3492918774169233)
,p_plug_name=>'Region Display Selector'
,p_static_id=>'region-display-selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3893124902948902)
,p_plug_name=>'Stacked Layout'
,p_static_id=>'stacked-layout'
,p_parent_plug_id=>wwv_flow_imp.id(3493452398169238)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>80
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
