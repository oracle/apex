prompt --application/pages/page_01601
begin
--   Manifest
--     PAGE: 01601
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1601
,p_name=>'Form Item Types'
,p_alias=>'FORM-ITEM-TYPES'
,p_step_title=>'Form Item Types'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.ts-Placeholder {',
'height: 240px;',
'line-height: 240px;',
'text-align: center;',
'background-color: #D0D0D0;',
'color: #404040;',
'border-radius: 2px;',
'margin-bottom: 48px;',
'}',
'.ts-Container {',
'max-width: 1024px;',
'min-height: 50vh;',
'}'))
,p_step_template=>4075783602716660119
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3936651047889972247)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--showBreadcrumb:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>790
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1826123116176656918)
,p_plug_name=>'Demo'
,p_static_id=>'demo'
,p_region_name=>'Demo1'
,p_parent_plug_id=>wwv_flow_imp.id(1826122684452656914)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3936651390864972248)
,p_plug_name=>'Overview'
,p_static_id=>'overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Universal Theme enables easy form design by allowing developers to declaratively control form layout, field templates, and label column widths. This page introduces you to forms, field templates, and template options.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1826125160309656938)
,p_plug_name=>'Region Display Selector'
,p_static_id=>'region-display-selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>800
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1826122684452656914)
,p_plug_name=>'Region with Items'
,p_static_id=>'region-with-items'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>45
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1826122805656656915)
,p_plug_name=>'Template Options'
,p_static_id=>'template-options'
,p_parent_plug_id=>wwv_flow_imp.id(1826122684452656914)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'
,p_landmark_label=>'Region Items Template Options'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'REGION',
  'attribute_02', 'Demo1')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16610916950828113)
,p_name=>'P1601_CHECKBOX'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Single Checkbox'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_colspan=>4
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1826129417911656952)
,p_name=>'P1601_CHECKBOX_GROUP'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Checkbox Group'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1826129536650656953)
,p_name=>'P1601_COLOR_PICKER'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Color Picker'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_COLOR_PICKER'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16611854647828122)
,p_name=>'P1601_COMBOBOX'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Combobox'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_COMBOBOX'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'infinite_scroll', 'N',
  'manual_entries_item', 'P1601_COMBO_BOX_MANUAL_ENTRIES',
  'match_type', 'CONTAINS',
  'min_chars', '0',
  'multi_selection', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16611883112828123)
,p_name=>'P1601_COMBO_BOX_MANUAL_ENTRIES'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1826129611833656954)
,p_name=>'P1601_DATE_PICKER'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Date Picker'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16612276261828126)
,p_name=>'P1601_DATE_PICKER_INLINE'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Inline Date Picker'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'INLINE',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16612088041828125)
,p_name=>'P1601_DATE_PICKER_NATIVE'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Native HTML Date Picker'
,p_format_mask=>'YYYY-MM-DD'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'NATIVE',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'show_time', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16611993538828124)
,p_name=>'P1601_DISPLAY_MAP'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Display Map'
,p_source=>'{"coordinates": [-122.26226,37.53087], "type": "point"}'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_MAP'
,p_colspan=>12
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'background', 'default',
  'interactive_map', 'Y',
  'show_map_controls', 'Y',
  'show_marker', 'Y',
  'zoom_level', '14')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16610817392828112)
,p_name=>'P1601_DISPLAY_ONLY'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Display Only'
,p_source=>'Display Only Item'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1826129721897656955)
,p_name=>'P1601_FILE_BROWSE'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'File Browse'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_copy_paste', 'N',
  'allow_multiple_files', 'N',
  'display_as', 'INLINE',
  'purge_file_at', 'SESSION',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16611192465828116)
,p_name=>'P1601_IMAGE_UPLOAD'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Image Upload'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_copy_paste', 'N',
  'allow_cropping', 'N',
  'allow_multiple_files', 'N',
  'display_as', 'DROPZONE_ICON',
  'preview_size', 'AUTO',
  'purge_files_at', 'SESSION',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16611428524828118)
,p_name=>'P1601_LIST_MANAGER'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'List Manager'
,p_source=>'List Manager Item'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_LIST_MANAGER'
,p_lov=>'STATIC2:Display1;Return1,Display2;Return2,Display3;Return3,Display4;Return4'
,p_colspan=>12
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fetch', 'FIRST_ROWSET',
  'preserve_case', 'Y')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1826129764849656956)
,p_name=>'P1601_MARKDOWN_EDITOR'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Markdown Editor'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_MARKDOWN_EDITOR'
,p_colspan=>12
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'syntax_highlighting', 'Y',
  'toolbar', 'SIMPLE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1826129873976656957)
,p_name=>'P1601_NUMBER_FIELD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Number Field'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1826129976319656958)
,p_name=>'P1601_PASSWORD'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Password'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1826130133899656959)
,p_name=>'P1601_PERCENT_GRAPH'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_item_default=>'33'
,p_prompt=>'Percent Graph'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_PCT_GRAPH'
,p_colspan=>6
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_value', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16611570448828119)
,p_name=>'P1601_POPUP_LOV'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Popup Lov'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16612341763828127)
,p_name=>'P1601_QR_CODE'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'QR Code'
,p_source=>'https://oracleapex.com/en/'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_QRCODE'
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'data_type', 'URL',
  'size', 'a-QRCode--sm',
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1826130161847656960)
,p_name=>'P1601_RADIO_GROUP'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Radio Group'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_colspan=>4
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16611003059828114)
,p_name=>'P1601_RADIO_GROUP_AS_BUTTONS'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Radio Group As Buttons'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1826130292136656961)
,p_name=>'P1601_SELECT_LIST'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Select List'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16611731350828121)
,p_name=>'P1601_SELECT_MANY'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Select One'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_MANY'
,p_lov=>'STATIC2:Apple;APPLE,Orange;ORANGE,Pear;PEAR,Banana;BANANA,Watermelon;WATERMELON'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'infinite_scroll', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0',
  'use_defaults', 'Y')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16611667643828120)
,p_name=>'P1601_SELECT_ONE'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Select One'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_ONE'
,p_lov=>'STATIC2:Apple;APPLE,Orange;ORANGE,Pear;PEAR,Banana;BANANA,Watermelon;WATERMELON'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'infinite_scroll', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16611293195828117)
,p_name=>'P1601_SHUTTLE'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Shuttle'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>'STATIC2:Display1;Return1,Display2;Return2,Display3;Return3,Display4;Return4'
,p_cHeight=>5
,p_colspan=>12
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16611169149828115)
,p_name=>'P1601_STAR_RATING'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Star Rating'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_STAR_RATING'
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_stars', '5',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1826130435176656962)
,p_name=>'P1601_SWITCH'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Switch'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1826130480094656963)
,p_name=>'P1601_TEXTAREA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Textarea'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_colspan=>4
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1826128774831656946)
,p_name=>'P1601_TEXT_FIELD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Text Field'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>4
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1661840967182825946)
,p_name=>'P1601_TEXT_FIELD_WITH_AUTOCOMPLETE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1826123116176656918)
,p_prompt=>'Text Field With Autocomplete'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_named_lov=>'FONT_ANIMATIONS'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fetch_on_type', 'Y',
  'infinite_scroll', 'N',
  'match_type', 'CONTAINS_IGNORE',
  'max_values_in_list', '7',
  'min_chars', '1',
  'use_cache', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
