prompt --application/pages/page_01909
begin
--   Manifest
--     PAGE: 01909
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1909
,p_name=>'Redirect'
,p_alias=>'REDIRECT1'
,p_step_title=>'Redirect'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1626018403696809677)
,p_branch_name=>'Go To Page 2000'
,p_branch_action=>'f?p=&APP_ID.:2000:&SESSION.::&DEBUG.:::'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_comment=>'This is an legacy page that was referenced in the docs. We keep it so that older doc versions can still work.'
);
wwv_flow_imp.component_end;
end;
/
