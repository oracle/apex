prompt --application/pages/page_01923
begin
--   Manifest
--     PAGE: 01923
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1923
,p_name=>'Region Display Selector'
,p_alias=>'REGION-DISPLAY-SELECTOR'
,p_step_title=>'Region Display Selector'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(2574898675351483580)
,p_javascript_code_onload=>'apex.theme42demo.jump(''&REQUEST.'');'
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1817964901952424492)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1817964864351424491)
,p_plug_name=>'Instructions'
,p_static_id=>'instructions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--shadowBG:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'REGION',
  'attribute_02', 'Demo1',
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<p>Then in <strong>Page Designer</strong>, select the regions that should appear on the <strong>Region Display Selector</strong> and set the <em>Region Display Selector</em> property to <strong>Yes</strong>.</p>',
    '',
    '<p>It is recommended to place a <strong>Region Display Selector</strong> region in the <strong>Breadcrumb</strong> position on your page.</p>')))).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4602506778718930963)
,p_plug_name=>'Overview'
,p_static_id=>'overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The <strong>Region Display Selector</strong> is a Region component that provides a page level navigation control for other regions on the page with the <em>Region Display Selector</em> property set to <strong>Yes</strong>.  It can be configured to'
||' work in two modes:</p>',
'<ul>',
'  <li><strong>View Single Region</strong> Show regions as tabs. Selecting a tab will make the corresponding region visible and hide the other selections.</li>',
'  <li><strong>Scroll Window</strong> Always display all the regions on the page. Selecting a tab will scroll your window to the corresponding region.</li>',
'</ul>',
'<p>',
'   The <em>Remember Selection</em> attribute of a Region Display Selector can be set to control which tab is selected on page load:',
'</p>',
'<ul>',
'    <li><strong>By User</strong> Tab selection will always be remembered across all sessions unless intentionally reset.</li>',
'    <li><strong>By Session</strong> Tab selection will be remembered for the duration of a single session. Once a session ends, tab selection will be reset.</li>',
'    <li><strong>No</strong> Tab selection will be set to the first tab in the Region Display Selector every time the page loads.</li>',
'</ul>',
'<p>',
'    Region Display Selector also supports displaying icons in each tab with the <strong>Display Icon</strong> attribute. Any region that is included in the Region Display Selector and has the <em>Icon</em> property set will have that icon displayed.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1817964350768424486)
,p_plug_name=>'Region 1'
,p_static_id=>'region'
,p_icon_css_classes=>'fa-apex'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--noBorder:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Region 1 content'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1817964489464424487)
,p_plug_name=>'Region 2'
,p_static_id=>'region-2'
,p_icon_css_classes=>'fa-apex'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--noBorder:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Region 2 content'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1817964503487424488)
,p_plug_name=>'Region 3'
,p_static_id=>'region-3'
,p_icon_css_classes=>'fa-apex'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--noBorder:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Region 3 content'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1817964596698424489)
,p_plug_name=>'Region 4'
,p_static_id=>'region-4'
,p_icon_css_classes=>'fa-apex'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--noBorder:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Region 4 content'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1817964758627424490)
,p_plug_name=>'Region 5'
,p_static_id=>'region-5'
,p_icon_css_classes=>'fa-apex'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--noBorder:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Region 5 content'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6776580641639957163)
,p_plug_name=>'Region Display Selector'
,p_static_id=>'region-display-selector'
,p_region_name=>'Demo1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'Y',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp.component_end;
end;
/
