prompt --application/pages/page_00421
begin
--   Manifest
--     PAGE: 00421
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>421
,p_name=>'Navigation'
,p_alias=>'NAVIGATION2'
,p_step_title=>'Navigation'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(2574898675351483580)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.dm-Icon {',
'  display: inline-block; }',
'',
'.dm-Icon--page {',
'  width: 16rem;',
'  height: 10.25rem;',
'  display: block;',
'  margin: 1.5rem auto; }',
'  .dm-Icon--page + .t-Button {',
'    display: block;',
'    margin: 0 auto; }',
'  .apex-theme-vita-dark .dm-Icon--page {',
'    filter: invert(0.75); }',
'  .u-RTL .dm-Icon--page {',
'    transform: scaleX(-1); }',
'',
'.side-nav-one-column {',
'  background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20256%20164%22%3E%3Cpath%20fill%3D%22%23C2C2C2%22%20d%3D%22M0%202C0%20.9.9%200%202%200h252c1.1%200%202%20.9%'
||'202%202v160c0%201.105-.895%202-2%202H2c-1.1%200-2-.9-2-2V2z%22%2F%3E%3Cg%20fill%3D%22%23EBEBEB%22%3E%3Cpath%20d%3D%22M13%201H2c-.552%200-1%20.448-1%201v11h12V1zM254%201H14v12h241V2c0-.552-.448-1-1-1z%22%2F%3E%3C%2Fg%3E%3Cpath%20fill%3D%22%23EBEBEB%22'
||'%20d%3D%22M1%2074h38v89H2c-.552%200-1-.448-1-1V74z%22%2F%3E%3Cpath%20fill%3D%22%23FFF%22%20d%3D%22M40%2014h215v26H40z%22%2F%3E%3Cpath%20fill%3D%22%23C2C2C2%22%20d%3D%22M5%205h4v1H5zM5%208h4v1H5z%22%2F%3E%3Cpath%20fill%3D%22%23EBEBEB%22%20d%3D%22M1%20'
||'14h38v11H1zM1%2026h38v11H1zM1%2038h38v11H1zM1%2050h38v11H1zM1%2062h38v11H1z%22%2F%3E%3Cpath%20fill%3D%22%23FAFAFA%22%20d%3D%22M40%2041h215v121c0%20.552-.448%201-1%201H40V41z%22%2F%3E%3C%2Fsvg%3E");',
'  background-repeat: no-repeat; }',
'',
'.top-nav-one-column {',
'  background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20256%20164%22%3E%3Cpath%20fill%3D%22%23C2C2C2%22%20d%3D%22M0%202C0%20.9.9%200%202%200h252c1.1%200%202%20.9%'
||'202%202v160c0%201.105-.895%202-2%202H2c-1.1%200-2-.9-2-2V2z%22%2F%3E%3Cpath%20fill%3D%22%23EBEBEB%22%20d%3D%22M254%201H2c-.552%200-1%20.448-1%201v11h254V2c0-.552-.448-1-1-1z%22%2F%3E%3Cpath%20fill%3D%22%23FFF%22%20d%3D%22M1%2027h254v26H1z%22%2F%3E%3C'
||'path%20fill%3D%22%23EBEBEB%22%20d%3D%22M1%2014h50v12H1zM52%2014h50v12H52zM103%2014h50v12h-50zM154%2014h50v12h-50zM205%2014h50v12h-50z%22%2F%3E%3Cpath%20fill%3D%22%23FAFAFA%22%20d%3D%22M1%2054h254v108c0%20.552-.448%201-1%201H2c-.552%200-1-.448-1-1V54z'
||'%22%2F%3E%3C%2Fsvg%3E");',
'  background-repeat: no-repeat; }'))
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4997327065668397274)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2623536414536501745)
,p_plug_name=>'Instructions'
,p_static_id=>'instructions'
,p_parent_plug_id=>wwv_flow_imp.id(2623536298230501744)
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--noIcon:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>2044111091335791563
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><strong>Steps</strong></p>',
'',
'<ul>',
'  <li>Go to Shared Components &rarr; User Interface Attributes &rarr; Edit Desktop</li>',
'  <li>Scroll to Navigation Menu and set <b>Position</b> to Side</li>',
'  <li>Set the <b>List Template</b> to Side Navigation Menu</li>',
'</ul>'))
,p_landmark_label=>'Side Menu Instructions'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2623536549787501746)
,p_plug_name=>'Instructions'
,p_static_id=>'instructions-2'
,p_parent_plug_id=>wwv_flow_imp.id(3944975082597506551)
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--noIcon:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>2044111091335791563
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><strong>Steps</strong></p>',
'',
'<ul>',
'  <li>Go to Shared Components &rarr; User Interface Attributes &rarr; Edit Desktop</li>',
'  <li>Scroll to Navigation Menu and set <b>Position</b> to Top</li>',
'  <li>Set the <b>List Template</b> to Top Navigation Tabs</li>',
'</ul>'))
,p_landmark_label=>'Tab Menu Instructions'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6416961128443375963)
,p_plug_name=>'Overview'
,p_static_id=>'overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Navigation within your application is critical to its success. When building applications for mobile, it is important to keep in mind the complexity of the application you are developing and which navigation pattern makes most sense for your speci'
||'fic use case. Here are two of the mobile-friendly navigation patterns available in Universal Theme and when to pick one over the other.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2623536298230501744)
,p_plug_name=>'Side Menu'
,p_static_id=>'side-menu'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>This common navigation pattern is typically referred to as a <b>hamburger menu</b>, drawer menu, or tree navigation and is well suited for applications that have many navigation items, or require nested navigation. On small screens, you simply tap'
||' on the hamburger icon near the top left (or top right when using right-to-left languages) corner of your screen and the menu will slide out. You can make a selection and immediately navigate to the selected item.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3944975613044506563)
,p_plug_name=>'Side Menu Sample'
,p_static_id=>'side-menu-sample'
,p_parent_plug_id=>wwv_flow_imp.id(2623536298230501744)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="dm-Icon dm-Icon--page side-nav-one-column"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1101:&APP_SESSION.'',''Page with Side Menu'')" type="button">View Sample</span>',
'</button>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3944975082597506551)
,p_plug_name=>'Tab Menu'
,p_static_id=>'tab-menu'
,p_region_name=>'standard'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Tabs are another very common navigation pattern for small screen devices.  These tabs will automatically position themselves near the top or bottom of the screen depending on the device screensize.  On small screens, the tabs menu will be displaye'
||'d at the bottom of the screen allowing for comfortable use with one hand. On larger screens, the tabs will be near the top of the screen.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3944976070155506563)
,p_plug_name=>'Tab Menu Sample'
,p_static_id=>'tab-menu-sample'
,p_parent_plug_id=>wwv_flow_imp.id(3944975082597506551)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="dm-Icon dm-Icon--page top-nav-one-column"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1115:&APP_SESSION.'',''Page with Tabs Menu'')" type="button">View Sample</span>',
'</button>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
