prompt --application/pages/page_03008
begin
--   Manifest
--     PAGE: 03008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3008
,p_name=>'Components - Flexbox Container'
,p_alias=>'FLEXBOX-CONTAINER-COMPONENT'
,p_step_title=>'Components - Flexbox Container'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1865456164683361692)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3442802333241449)
,p_plug_name=>'Flexbox Container - Column'
,p_static_id=>'column'
,p_parent_plug_id=>wwv_flow_imp.id(3442789480241448)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_template_component_type=>'REGION_ONLY'
,p_plug_source_type=>'TMPL_THEME_42$FLEXBOX_CONTAINER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'DIRECTION', 'u-flex-direction-column',
  'GAP', 'u-gap-4')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1757263752775570578)
,p_plug_name=>'Demo'
,p_static_id=>'demo'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>This demonstrates how regions can be laid out in a row and stretch to be equal in height.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3441964536241440)
,p_plug_name=>'Alignment'
,p_static_id=>'demo-alignment'
,p_parent_plug_id=>wwv_flow_imp.id(1757263752775570578)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>This demonstrates how flexbox items can be aligned declaratively. Here we have two regions that are center aligned vertically.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3442789480241448)
,p_plug_name=>'Direction'
,p_static_id=>'demo-direction'
,p_parent_plug_id=>wwv_flow_imp.id(1757263752775570578)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>This demonstrates how flexbox items can be laid out vertically in a column, or horizontally in a row.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3867425698540607)
,p_plug_name=>'Wrapping'
,p_static_id=>'demo-wrapping'
,p_parent_plug_id=>wwv_flow_imp.id(1757263752775570578)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>60
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>This demonstrates how flexbox items can wrap onto multiple lines when needed.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3442145806241442)
,p_plug_name=>'Flexbox Container - Alignment'
,p_static_id=>'flexbox-container-alignment'
,p_parent_plug_id=>wwv_flow_imp.id(3441964536241440)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_template_component_type=>'REGION_ONLY'
,p_plug_source_type=>'TMPL_THEME_42$FLEXBOX_CONTAINER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'ALIGNITEMS', 'u-align-items-center',
  'FLEX_BEHAVIOR', 'a-FlexContainer--grow',
  'GAP', 'u-gap-4')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3867547130540608)
,p_plug_name=>'Flexbox Container - Wrapping'
,p_static_id=>'flexbox-container-wrapping'
,p_parent_plug_id=>wwv_flow_imp.id(3867425698540607)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_template_component_type=>'REGION_ONLY'
,p_plug_source_type=>'TMPL_THEME_42$FLEXBOX_CONTAINER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'GAP', 'u-gap-4',
  'WRAP', 'u-flex-wrap')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3439394398241414)
,p_plug_name=>'Flexbox Container - Stretching'
,p_static_id=>'flexbox-demo'
,p_region_name=>'FlexboxDemo'
,p_parent_plug_id=>wwv_flow_imp.id(3868195068540614)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_template_component_type=>'REGION_ONLY'
,p_plug_source_type=>'TMPL_THEME_42$FLEXBOX_CONTAINER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'ALIGNCONTENT', 'u-align-content-center',
  'FLEX_BEHAVIOR', 'a-FlexContainer--grow',
  'GAP', 'u-gap-4',
  'JUSTIFYCONTENT', 'u-justify-content-flex-start',
  'WRAP', 'u-flex-wrap')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1757263629388570577)
,p_plug_name=>'Instructions'
,p_static_id=>'instructions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--shadowBG:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'REGION',
  'attribute_02', 'FlexboxDemo')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3440900628241430)
,p_plug_name=>'Left Column'
,p_static_id=>'left-column'
,p_parent_plug_id=>wwv_flow_imp.id(3439394398241414)
,p_region_css_classes=>'h400'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>10
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3442504445241446)
,p_plug_name=>'Left Column'
,p_static_id=>'new_1'
,p_parent_plug_id=>wwv_flow_imp.id(3442145806241442)
,p_region_css_classes=>'h400'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>10
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3442618517241447)
,p_plug_name=>'Right Column'
,p_static_id=>'new_1_1'
,p_parent_plug_id=>wwv_flow_imp.id(3442145806241442)
,p_region_css_classes=>'h200'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>20
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3867605040540609)
,p_plug_name=>'Region 1'
,p_static_id=>'new_2'
,p_parent_plug_id=>wwv_flow_imp.id(3867547130540608)
,p_region_css_classes=>'w400'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>10
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3867776820540610)
,p_plug_name=>'Region 3'
,p_static_id=>'new_2_1'
,p_parent_plug_id=>wwv_flow_imp.id(3867547130540608)
,p_region_css_classes=>'w400'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>30
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3867824160540611)
,p_plug_name=>'Region 5'
,p_static_id=>'new_2_1_1'
,p_parent_plug_id=>wwv_flow_imp.id(3867547130540608)
,p_region_css_classes=>'w400'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>50
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3867921947540612)
,p_plug_name=>'Region 4'
,p_static_id=>'new_2_1_2'
,p_parent_plug_id=>wwv_flow_imp.id(3867547130540608)
,p_region_css_classes=>'w400'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>40
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3868067589540613)
,p_plug_name=>'Region 2'
,p_static_id=>'new_2_2'
,p_parent_plug_id=>wwv_flow_imp.id(3867547130540608)
,p_region_css_classes=>'w400'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>20
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1757263551978570576)
,p_plug_name=>'Overview'
,p_static_id=>'overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p><strong>Flexbox Container</strong> is a theme component that is suitable for arranging components in a flexible layout. This component supports horizontal or vertical direction, wrapping, spacing, alignment, justification, overflow, and flex item '
||'sizing.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3442967038241450)
,p_plug_name=>'Region 1'
,p_static_id=>'region-1'
,p_parent_plug_id=>wwv_flow_imp.id(3442802333241449)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>10
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3867161223540604)
,p_plug_name=>'Region 1'
,p_static_id=>'region-1_1'
,p_parent_plug_id=>wwv_flow_imp.id(3867054376540603)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>10
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3866844882540601)
,p_plug_name=>'Region 2'
,p_static_id=>'region-2'
,p_parent_plug_id=>wwv_flow_imp.id(3442802333241449)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>20
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3867251391540605)
,p_plug_name=>'Region 2'
,p_static_id=>'region-2_1'
,p_parent_plug_id=>wwv_flow_imp.id(3867054376540603)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>20
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3866942569540602)
,p_plug_name=>'Region 3'
,p_static_id=>'region-3'
,p_parent_plug_id=>wwv_flow_imp.id(3442802333241449)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>30
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3867316313540606)
,p_plug_name=>'Region 3'
,p_static_id=>'region-3_1'
,p_parent_plug_id=>wwv_flow_imp.id(3867054376540603)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>30
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1757263401165570575)
,p_plug_name=>'Region Display Selector'
,p_static_id=>'region-display-selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3441104786241432)
,p_plug_name=>'Right Column'
,p_static_id=>'right-column'
,p_parent_plug_id=>wwv_flow_imp.id(3439394398241414)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>20
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3867054376540603)
,p_plug_name=>'Flexbox Container - Row'
,p_static_id=>'row'
,p_parent_plug_id=>wwv_flow_imp.id(3442789480241448)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_template_component_type=>'REGION_ONLY'
,p_plug_source_type=>'TMPL_THEME_42$FLEXBOX_CONTAINER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'FLEX_BEHAVIOR', 'a-FlexContainer--grow',
  'GAP', 'u-gap-4')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3868195068540614)
,p_plug_name=>'Stretching'
,p_static_id=>'stretching'
,p_parent_plug_id=>wwv_flow_imp.id(1757263752775570578)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
