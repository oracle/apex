prompt --application/pages/page_00300
begin
--   Manifest
--     PAGE: 00300
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>300
,p_name=>'Grid Layout'
,p_alias=>'GRID-LAYOUT'
,p_step_title=>'Grid Layout - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.display-hidden {',
'    color: var(--ut-component-text-muted-color)!important;',
'}',
'',
'.display-visible {',
'    color: var(--ut-component-text-subtitle-color) !important;',
'    background-color: rgba(59, 170, 44, .1) !important;',
'}',
'',
'.region-grid {',
'    text-align: center;',
'    padding: 16px 8px;',
'    border-radius: 4px;',
'    box-shadow: var(--ut-alert-box-shadow);',
'    font-size: 10px;',
'    overflow: hidden;',
'    text-overflow: ellipsis;',
'    background-color: var(--ut-component-badge-background-color);',
'    color: var(--ut-component-badge-text-color);',
'    font-weight: 500;',
'    margin: 8px 0;',
'    line-height: 1.25;',
'}'))
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381449176772970882)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3817017092092871492)
,p_plug_name=>'Demo'
,p_static_id=>'demo'
,p_parent_plug_id=>wwv_flow_imp.id(1803662347756768779)
,p_region_css_classes=>'u-textCenter	'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="u-textLeft">Every region below uses the following responsive CSS Classes: <code>col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1</code></p>',
'<p class="u-textLeft">Resize this window to experience the responsiveness of this page.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3532052504014680107)
,p_plug_name=>'Demo'
,p_static_id=>'demo-2'
,p_region_css_classes=>'u-textCenter	'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3408490239846583893)
,p_plug_name=>'Overview'
,p_static_id=>'overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Universal Theme uses a 12 columns grid layout system for arranging components on a page.</p>',
'<p>Understanding this grid system will allow you to create thoughful designs and personalize the responsive experience of your applications.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381445522059970846)
,p_plug_name=>'Region 2'
,p_static_id=>'region'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381446462030970855)
,p_plug_name=>'Region 9'
,p_static_id=>'region-10'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>150
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381446581280970856)
,p_plug_name=>'Region 11'
,p_static_id=>'region-11'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>170
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381446641350970857)
,p_plug_name=>'Region 12'
,p_static_id=>'region-12'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>180
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381446783677970858)
,p_plug_name=>'Region 1'
,p_static_id=>'region-13'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>190
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'2 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381446828699970859)
,p_plug_name=>'Region 2'
,p_static_id=>'region-14'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>200
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'2 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381446909390970860)
,p_plug_name=>'Region 3'
,p_static_id=>'region-15'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>210
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'2 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381447064052970861)
,p_plug_name=>'Region 4'
,p_static_id=>'region-16'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>220
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'2 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381447147898970862)
,p_plug_name=>'Region 5'
,p_static_id=>'region-17'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>230
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'2 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381447244303970863)
,p_plug_name=>'Region 6'
,p_static_id=>'region-18'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>240
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'2 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381447305429970864)
,p_plug_name=>'Region 1'
,p_static_id=>'region-19'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>250
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'3 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381445697427970847)
,p_plug_name=>'Region 4'
,p_static_id=>'region-2'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>100
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381447456956970865)
,p_plug_name=>'Region 2'
,p_static_id=>'region-20'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>260
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'3 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381447525012970866)
,p_plug_name=>'Region 3'
,p_static_id=>'region-21'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>270
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'3 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381447671771970867)
,p_plug_name=>'Region 4'
,p_static_id=>'region-22'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>280
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'3 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381447978896970870)
,p_plug_name=>'Region 1'
,p_static_id=>'region-23'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>290
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'4 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381448063860970871)
,p_plug_name=>'Region 2'
,p_static_id=>'region-24'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>300
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'4 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381448179095970872)
,p_plug_name=>'Region 3'
,p_static_id=>'region-25'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>310
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'4 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381448275518970873)
,p_plug_name=>'Region 1'
,p_static_id=>'region-26'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>320
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'6 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381448346140970874)
,p_plug_name=>'Region 2'
,p_static_id=>'region-27'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>330
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'6 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381445735395970848)
,p_plug_name=>'Region 6'
,p_static_id=>'region-3'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>120
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381445811595970849)
,p_plug_name=>'Region 8'
,p_static_id=>'region-4'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>140
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381445988353970850)
,p_plug_name=>'Region 10'
,p_static_id=>'region-5'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>160
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381446103435970851)
,p_plug_name=>'Region 1'
,p_static_id=>'region-6'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381446121346970852)
,p_plug_name=>'Region 3'
,p_static_id=>'region-7'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381446232182970853)
,p_plug_name=>'Region 5'
,p_static_id=>'region-8'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>110
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381446348336970854)
,p_plug_name=>'Region 7'
,p_static_id=>'region-9'
,p_parent_plug_id=>wwv_flow_imp.id(3532052504014680107)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>130
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1803662136473768777)
,p_plug_name=>'Region Display Selector'
,p_static_id=>'region-display-selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3408490083877583891)
,p_name=>'Responsive Classes'
,p_static_id=>'responsive-classes'
,p_parent_plug_id=>wwv_flow_imp.id(1803662347756768779)
,p_template=>2325543309974442989
,p_display_sequence=>10
,p_region_css_classes=>'margin-top-xl'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--horizontalBorders:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Range'' grid_property,',
'       ''All'' grid_all,',
'       ''479px and below'' grid_extra_extra_small,',
'       ''480px to 639px'' grid_extra_small,',
'       ''640px to 767px'' grid_small,',
'       ''768px to 991px'' grid_medium,',
'       ''992px to 1199px'' grid_large,',
'       ''1200px to 1399px'' grid_extra_large,',
'       ''1400px and above'' grid_extra_extra_large',
'  from dual union all',
'',
'select ''CSS Class Prefix'' grid_property,',
'       ''.col-'' grid_all,',
'       ''.col-xxs-'' grid_extra_extra_small,',
'       ''.col-xs-'' grid_extra_small,',
'       ''.col-sm-'' grid_small,',
'       ''.col-md-'' grid_medium,',
'       ''.col-lg-'' grid_large,',
'       ''.col-xl-'' grid_extra_large,',
'       ''.col-xxl-'' grid_extra_extra_large',
'  from dual union all',
'',
'select ''Number of Columns'' grid_property,',
'       ''12'' grid_all,',
'       '''' grid_extra_extra_small,',
'       '''' grid_extra_small,',
'       '''' grid_small,',
'       '''' grid_medium,',
'       '''' grid_large,',
'       '''' grid_extra_large,',
'       '''' grid_extra_extra_large',
'  from dual union all',
'',
'select ''Gutter'' grid_property,',
'       ''1rem (0.5rem each side)'' grid_all,',
'       '''' grid_extra_extra_small,',
'       '''' grid_extra_small,',
'       '''' grid_small,',
'       '''' grid_medium,',
'       '''' grid_large,',
'       '''' grid_extra_large,',
'       '''' grid_extra_extra_large',
'  from dual'))
,p_header=>'<p>You can fine tune the responsive behavior of the components on your page by modifying the <strong>Column CSS Classes</strong> property of your components.</p>'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2542081983073888486
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1530517221508782772)
,p_query_column_id=>2
,p_column_alias=>'GRID_ALL'
,p_column_display_sequence=>20
,p_column_heading=>'All'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1530517903985782779)
,p_query_column_id=>9
,p_column_alias=>'GRID_EXTRA_EXTRA_LARGE'
,p_column_display_sequence=>90
,p_column_heading=>'XX Large'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1530517361504782773)
,p_query_column_id=>3
,p_column_alias=>'GRID_EXTRA_EXTRA_SMALL'
,p_column_display_sequence=>30
,p_column_heading=>'XX Small'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1530517833267782778)
,p_query_column_id=>8
,p_column_alias=>'GRID_EXTRA_LARGE'
,p_column_display_sequence=>80
,p_column_heading=>'X Large'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1530517473216782774)
,p_query_column_id=>4
,p_column_alias=>'GRID_EXTRA_SMALL'
,p_column_display_sequence=>40
,p_column_heading=>'X Small'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1530517783355782777)
,p_query_column_id=>7
,p_column_alias=>'GRID_LARGE'
,p_column_display_sequence=>70
,p_column_heading=>'Large'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1530517610538782776)
,p_query_column_id=>6
,p_column_alias=>'GRID_MEDIUM'
,p_column_display_sequence=>60
,p_column_heading=>'Medium'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1530517100830782771)
,p_query_column_id=>1
,p_column_alias=>'GRID_PROPERTY'
,p_column_display_sequence=>10
,p_column_html_expression=>'<strong>#GRID_PROPERTY#</strong>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1530517584655782775)
,p_query_column_id=>5
,p_column_alias=>'GRID_SMALL'
,p_column_display_sequence=>50
,p_column_heading=>'Small'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1803662347756768779)
,p_plug_name=>'Responsive Design'
,p_static_id=>'responsive-design'
,p_region_name=>'responsive_design'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Universal Theme is responsive out of the box. For more control on your application responsive behavior, read on the additional Universal Theme responsive options.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3666410110138162231)
,p_plug_name=>'Responsive Region 2'
,p_static_id=>'responsive-region'
,p_parent_plug_id=>wwv_flow_imp.id(3817017092092871492)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3666411050109162240)
,p_plug_name=>'Responsive Region 9'
,p_static_id=>'responsive-region-10'
,p_parent_plug_id=>wwv_flow_imp.id(3817017092092871492)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>150
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3666411169359162241)
,p_plug_name=>'Responsive Region 11'
,p_static_id=>'responsive-region-11'
,p_parent_plug_id=>wwv_flow_imp.id(3817017092092871492)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>170
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3666411229429162242)
,p_plug_name=>'Responsive Region 12'
,p_static_id=>'responsive-region-12'
,p_parent_plug_id=>wwv_flow_imp.id(3817017092092871492)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>180
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3666410285506162232)
,p_plug_name=>'Responsive Region 4'
,p_static_id=>'responsive-region-2'
,p_parent_plug_id=>wwv_flow_imp.id(3817017092092871492)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>100
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3666410323474162233)
,p_plug_name=>'Responsive Region 6'
,p_static_id=>'responsive-region-3'
,p_parent_plug_id=>wwv_flow_imp.id(3817017092092871492)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>120
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3666410399674162234)
,p_plug_name=>'Responsive Region 8'
,p_static_id=>'responsive-region-4'
,p_parent_plug_id=>wwv_flow_imp.id(3817017092092871492)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>140
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3666410576432162235)
,p_plug_name=>'Responsive Region 10'
,p_static_id=>'responsive-region-5'
,p_parent_plug_id=>wwv_flow_imp.id(3817017092092871492)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>160
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3666410691514162236)
,p_plug_name=>'Responsive Region 1'
,p_static_id=>'responsive-region-6'
,p_parent_plug_id=>wwv_flow_imp.id(3817017092092871492)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>70
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3666410709425162237)
,p_plug_name=>'Responsive Region 3'
,p_static_id=>'responsive-region-7'
,p_parent_plug_id=>wwv_flow_imp.id(3817017092092871492)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3666410820261162238)
,p_plug_name=>'Responsive Region 5'
,p_static_id=>'responsive-region-8'
,p_parent_plug_id=>wwv_flow_imp.id(3817017092092871492)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>110
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3666410936415162239)
,p_plug_name=>'Responsive Region 7'
,p_static_id=>'responsive-region-9'
,p_parent_plug_id=>wwv_flow_imp.id(3817017092092871492)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>130
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3381448504304970875)
,p_plug_name=>'Toggle Layout Columns'
,p_static_id=>'toggle-layout-columns'
,p_parent_plug_id=>wwv_flow_imp.id(3408490239846583893)
,p_region_css_classes=>'margin-bottom-xl'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>2044111091335791563
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Click the <b>Toggle Layout Columns</b> button to overlay the grid behind this page.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3498163710055301797)
,p_plug_name=>'Visibility Classes'
,p_static_id=>'visibility-classes'
,p_parent_plug_id=>wwv_flow_imp.id(1803662347756768779)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use the following classes to hide a given component when the viewport size is at the specified breakpoint.</p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc  dm-Report--grid">',
'  <thead>',
'    <tr>',
'      <th></th>',
'      <th>XXS <small>479px and below</small></th>',
'      <th>XS <small>480px to 639px</small></th>',
'      <th>Small <small>640px to 767px</small></th>',
'      <th>Medium <small>768px to 991px</small></th>',
'      <th>Large <small>992px and above</small></th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">xxs</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">xs</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">sm</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">md</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-visible">Visible</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">lg</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">xxs</span>-up</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">xs</span>-up</span></th>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">sm</span>-up</span></th>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">md</span>-up</span></th>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">lg</span>-up</span></th>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'  </tbody>',
'</table>',
'',
'<p><small>Note: These helper utilities are available in Oracle APEX 18.2 and later.</small></p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2730013940562748877)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3381448504304970875)
,p_button_name=>'TOGGLE_GRID_LAYOUT'
,p_static_id=>'toggle-grid-layout'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Toggle Layout Columns'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2730017681857748883)
,p_name=>'Toggle Grid Layout'
,p_static_id=>'toggle-grid-layout'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2730013940562748877)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'apex.jQuery(''body'').hasClass(''grid-debug-on'')'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2730018607476748885)
,p_event_id=>wwv_flow_imp.id(2730017681857748883)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-add-class'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(2730013940562748877)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'css_class', 'is-active')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2730019166148748885)
,p_event_id=>wwv_flow_imp.id(2730017681857748883)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-add-class-2'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'body'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'css_class', 'grid-debug-on')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2730018116076748884)
,p_event_id=>wwv_flow_imp.id(2730017681857748883)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-remove-class'
,p_action=>'NATIVE_REMOVE_CLASS'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'body'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'css_class', 'grid-debug-on')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2730019617460748886)
,p_event_id=>wwv_flow_imp.id(2730017681857748883)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-remove-class-2'
,p_action=>'NATIVE_REMOVE_CLASS'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(2730013940562748877)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'css_class', 'is-active')).to_clob
);
wwv_flow_imp.component_end;
end;
/
