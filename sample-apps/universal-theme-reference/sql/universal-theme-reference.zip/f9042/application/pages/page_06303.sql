prompt --application/pages/page_06303
begin
--   Manifest
--     PAGE: 06303
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6303
,p_name=>'Layout Modifiers'
,p_alias=>'LAYOUT-MODIFIERS'
,p_step_title=>'Layout Modifiers - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.class,',
'.class-value,',
'.class-desc {',
'    display: inline-block;',
'    font-size: 12px;',
'    font-family: ''Menlo'',''Consolas'',monospace;',
'}',
'.class {',
'    color: #9C27B0;',
'}',
'.class.tag {',
'    padding: 4px 8px;',
'    background-color: #FFF;',
'    border-radius: 2px;',
'    box-shadow: inset rgba(225, 190, 231, .25) 0 0 0 1px;',
'}',
'.class-value {',
'    color: #008676;',
'    min-width: 40px;',
'}',
'.class-var {',
'    font-weight: bold;',
'    color: #008676;',
'}',
'.dm-Report--doc {',
'    background: #FFF;',
'    border: 1px solid rgba(0,0,0,.05);',
'}',
'.dm-Report--doc th, ',
'.dm-Report--doc td {',
'    padding: 8px;',
'    min-height: 32px;',
'    background-color: transparent;',
'    border-width: 0 0 1px 0;',
'    border-style: solid;',
'    border-color: rgba(0,0,0,.05);',
'}',
'.dm-Report--doc td {',
'    vertical-align: top;',
'}',
'.dm-Report--doc tr:last-child td {',
'    border-bottom-width: 0;',
'}',
'.dm-Report--doc .class {',
'    min-width: 40px;',
'}',
'.dm-Report--doc .class-desc {',
'    width: 48px;',
'    text-align: right;',
'    color: rgba(0,0,0,.55);',
'    border-radius: 2px;',
'}',
'.dm-Code {',
'    border-radius: var(--ut-component-border-radius);',
'    border: var(--ut-component-border-width) solid var(--ut-component-border-color);',
'}'))
,p_step_template=>4075783602716660119
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5929825219234415225)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2084252041955326066)
,p_plug_name=>'Classes'
,p_static_id=>'classes'
,p_parent_plug_id=>wwv_flow_imp.id(2084251912727326065)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'    <thead>',
'    <tr>',
'      <th style="width: 20%" class="u-textStart">Class</th>',
'      <th style="width: 20%" class="u-textStart">Values</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'    <tbody>',
'        <!-- U-FLEX -->',
'        <tr>',
'            <td><span class="class">u-flex</span></td>',
'            <td></td>',
'            <td>Treat the element as a flex container and its children as flex items.</td>',
'        </tr>',
'        <!-- FLEX -->',
'        <tr>',
'            <td rowspan="7"><span class="class">u-flex-</span></td>',
'            <td><span class="class-value">item</span></td>',
'            <td>Size item according to its width and height properties, but grow to absorb any extra free space in the flex container and shrink to its minimum size to fit the container.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">direction-column</span></td>',
'            <td>Direction in which lines of text are stacked. Aligns items in columns as opposed to rows.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">direction-column-reverse</span></td>',
'            <td>Stacks items in a column, reversing the default column order.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">direction-row</span></td>',
'            <td>Direction in which lines of text are placed. Aligns items in rows as opposed to columns.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">direction-row-reverse</span></td>',
'            <td>Aligns items in rows, reversing the default row order.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">wrap</span></td>',
'            <td>Break flex items into multiple lines.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">wrap-nowrap</span></td>',
'            <td>Lay flex items out in a single line which may cause the flex container to overflow.</td>',
'        </tr>',
'        <!-- FLEX-BASIS -->',
'        <tr>',
'            <td rowspan="3"><span class="class">u-flex-basis-</span></td>',
'            <td><span class="class-value">auto</span></td>',
'            <td>Set the size of the element relative to the width and height of the content of the element.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">100</span></td>',
'            <td>Set the size of the element(s) to 100% of the available space in the parent container.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">0</span></td>',
'            <td>Prevent the element(s) from taking up the available space in the parent container.</td>',
'        </tr>',
'        <!-- FLEX-GROW -->',
'        <tr>',
'            <td rowspan="2"><span class="class">u-flex-grow-</span></td>',
'            <td><span class="class-value">1</span></td>',
'            <td>Allow the item to grow to fit available space.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">0</span></td>',
'            <td>Do not allow the item to grow to fit available space.</td>',
'        </tr>',
'        <!-- FLEX-SHRINK -->',
'        <tr>',
'            <td rowspan="2"><span class="class">u-flex-shrink-</span></td>',
'            <td><span class="class-value">1</span></td>',
'            <td>Allow the item to shrink to fit available space.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">0</span></td>',
'            <td>Prevent the item from shrinking to fit available space.</td>',
'        </tr>',
'        <!-- ORDER -->',
'        <tr>',
'            <td><span class="class">u-order-</span></td>',
'            <td></td>',
'            <td>Refer to the Order utilities on this page.</td>',
'        </tr>',
'        <!-- JUSTIFY-CONTENT -->',
'        <tr>',
'            <td rowspan="6"><span class="class">u-justify-content-</span></td>',
'            <td><span class="class-value">flex-start</span></td>',
'            <td>Horizontally align (justify) content to the start of the div.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">flex-end</span></td>',
'            <td>Horizontally align (justify) content to the end of the div.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">center</span></td>',
'            <td>Horizontally align (justify) content to the center of the div.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">space-between</span></td>',
'            <td>Distribute content evenly with the first item flush with the start and the last item flush with the end.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">space-around</span></td>',
'            <td>Distribute content evenly with a half-size space on either end of items.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">stretch</span></td>',
'            <td>Distribute content evenly by stretching ''auto''-sized items to fit the container.</td>',
'        </tr>',
'        <!-- ALIGN-ITEMS -->',
'        <tr>',
'            <td rowspan="5"><span class="class">u-align-items-</span></td>',
'            <td><span class="class-value">flex-start</span></td>',
'            <td>Vertical alignment. The cross-start margin edges of the flex items are flushed with the cross-start edge of the line.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">flex-end</span></td>',
'            <td>Vertical alignment. The cross-end margin edges of the flex items are flushed with the cross-end edge of the line.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">start</span></td>',
'            <td>Vertical alignment. Pack items flush to each other toward the start edge of the alignment container in the appropriate axis.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">center</span></td>',
'            <td>Vertically align all items to the center of the div.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">end</span></td>',
'            <td>Vertical alignment. Pack items flush to each other toward the end edge of the alignment container in the appropriate axis.</td>',
'        </tr>',
'        <!-- ALIGN CONTENT -->',
'        <tr>',
'            <td rowspan="6"><span class="class">u-align-content-</span></td>',
'            <td><span class="class-value">start</span></td>',
'            <td>Groups lines together at the top of the container.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">end</span></td>',
'            <td>Groups lines together at the bottom of the container.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">center</span></td>',
'            <td>Groups lines together in the vertical center of the container.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">between</span></td>',
'            <td>Spreads lines evenly with no space at the edges.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">around</span></td>',
'            <td>Spreads lines evenly with half-size space at the edges.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">evenly</span></td>',
'            <td>Spreads lines evenly with equal space at the edges.</td>',
'        </tr>',
'        <!-- ALIGN-SELF -->',
'        <tr>',
'            <td rowspan="6"><span class="class">u-align-self-</span></td>',
'            <td><span class="class-value">flex-start</span></td>',
'            <td>Vertical alignment of individual flex item. Flush the cross-start margin edges of the flex item with the cross-start edge of the line.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">flex-end</span></td>',
'            <td>Vertical alignment of individual flex item. Flush the cross-end margin edges of the flex item with the cross-end edge of the line.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">start</span></td>',
'            <td>Vertical alignment of individual flex item. Pack the item flush to the edge of the alignment container of the start side of the item, in the appropriate axis.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">center</span></td>',
'            <td>Vertically align individual flex item to the center of the div.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">end</span></td>',
'            <td>Vertical alignment of individual flex item. Pack the item flush to the edge of the alignment container of the end side of the item, in the appropriate axis.</td>',
'        </tr>',
'        <tr>',
'            <td><span class="class-value">stretch</span></td>',
'            <td>Vertical alignment of individual flex item. Stretch flex item such that the cross-size of the item margin box is the same as the line while respecting widget and height constraints.</td>',
'        </tr>',
'        <!-- GAP -->',
'        <tr>',
'            <td><span class="class">u-gap-</span></td>',
'            <td></td>',
'            <td>Refer to the Gap utilities on this page.</td>',
'        </tr>',
'    </tbody>',
'</table>'))
,p_landmark_label=>'Flex Classes'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3099796470862540970)
,p_plug_name=>'Classes'
,p_static_id=>'classes-2'
,p_parent_plug_id=>wwv_flow_imp.id(2602209235267515863)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-pull<span class="class-value">Left</span></span></td><td>Float to left</td></tr>',
'    <tr><td><span class="class">u-pull<span class="class-value">Right</span></span></td><td>Float to right</td></tr>',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Float Classes'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3099797014695540975)
,p_plug_name=>'Classes'
,p_static_id=>'classes-3'
,p_parent_plug_id=>wwv_flow_imp.id(2602210129925515872)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-align<span class="class-value">Top</span></span></td><td>Vertically align to the top</td></tr>',
'    <tr><td><span class="class">u-align<span class="class-value">Middle</span></span></td><td>Vertically align to the middle</td></tr>',
'    <tr><td><span class="class">u-align<span class="class-value">Baseline</span></span></td><td>Vertically align to the text baseline</td></tr>',
'    <tr><td><span class="class">u-align<span class="class-value">Bottom</span></span></td><td>Vertically align to the bottom</td></tr>',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Vertical Alignment Classes'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16850594680448081)
,p_plug_name=>'Example Markup'
,p_static_id=>'example-markup'
,p_parent_plug_id=>wwv_flow_imp.id(16850292935448078)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-html"><code>',
'&lt;div class="u-flex"&gt;',
'    &lt;div class="u-order-3"&gt;This column will appear as the 3rd column&lt;/div&gt;',
'    &lt;div class="u-order-1"&gt;This column will be first&lt;/div&gt;',
'    &lt;div class="u-order-2 u-order-xxs-1"&gt;<br />',
'    &nbsp;&nbsp;This column will appear first when the viewport is below 479px wide.<br />',
'    &nbsp;&nbsp;And will appear as the second column when the viewport is 480px and wider.<br />',
'    &lt;/div&gt;',
'&lt;/div&gt;',
'</code>',
'</pre>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2084252148021326067)
,p_plug_name=>'Example Markup'
,p_static_id=>'example-markup-2'
,p_parent_plug_id=>wwv_flow_imp.id(2084251912727326065)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-html"><code>',
'&lt;div class="u-flex u-align-items-center"&gt;',
'    &lt;div class="u-order-3"&gt;This column will appear as the 3rd column and centered&lt;/div&gt;',
'    &lt;div class="u-order-1 u-align-self-center"&gt;This column will be first and aligned at the start of the row&lt;/div&gt;',
'    &lt;div class="u-order-2"&gt;This column will appear as the 2nd column&lt;/div&gt;',
'&lt;/div&gt;',
'</code>',
'</pre>'))
,p_landmark_label=>'Demo Flex'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3099796568149540971)
,p_plug_name=>'Example Markup'
,p_static_id=>'example-markup-3'
,p_parent_plug_id=>wwv_flow_imp.id(2602209235267515863)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-html"><code>&lt;button class="u-pullLeft"&gt;Foo&lt;/button&gt; &lt;!-- Float button to the left --&gt;',
'&lt;div class="u-pullRight"&gt;Hello World&lt;/div&gt; &lt;!-- Float div to the right --&gt;</code></pre>',
''))
,p_landmark_label=>'Demo Float'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3099797320849540978)
,p_plug_name=>'Example Markup'
,p_static_id=>'example-markup-4'
,p_parent_plug_id=>wwv_flow_imp.id(2602209370563515864)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-html"><code>&lt;h1 class="u-margin-auto"&gt;Centered Heading Text&lt;/h1&gt;',
'&lt;p class="u-margin-top-lg"&gt;Content with a large margin on top.&lt;/p&gt;</code></pre>',
''))
,p_landmark_label=>'Demo Margin'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602210766634515878)
,p_plug_name=>'Example Markup'
,p_static_id=>'example-markup-5'
,p_parent_plug_id=>wwv_flow_imp.id(2602209554646515866)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<pre class="dm-Code lang-html"><code>&lt;div class="w95p mxw800"&gt;This region will be 95% wide with a max-widht of 800px.&lt;/div&gt;</code></pre>'
,p_landmark_label=>'Demo Width'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602210956197515880)
,p_plug_name=>'Example Markup'
,p_static_id=>'example-markup-6'
,p_parent_plug_id=>wwv_flow_imp.id(2602209658761515867)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<pre class="dm-Code lang-html"><code>&lt;div class="h400"&gt;This region would be 400px tall.&lt;/div&gt;</code></pre>'
,p_landmark_label=>'Demo Height'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3099797045181540976)
,p_plug_name=>'Example Markup'
,p_static_id=>'example-markup-7'
,p_parent_plug_id=>wwv_flow_imp.id(2602210129925515872)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-html"><code>&lt;table&gt;',
'  &lt;tbody&gt;',
'    &lt;tr&gt;',
'      &lt;td class="u-alignTop"&gt;Hello World!&lt;/td&gt;',
'      &lt;td class="u-alignMiddle"&gt;I''m in the middle!&lt;/td&gt;',
'    &lt;/tr&gt;',
'  &lt;/tbody&gt;',
'&lt;/table&gt;</code></pre>'))
,p_landmark_label=>'Demo Vertical Alignment'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602210540721515876)
,p_plug_name=>'Example Markup'
,p_static_id=>'example-markup-8'
,p_parent_plug_id=>wwv_flow_imp.id(2602210317719515873)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-html"><code>&lt;button class="u-padding-lg"&gt;Large button&lt;/button&gt;',
'&lt;div class="u-padding-left-md"&gt;Little bit of padding on the side.&lt;/div&gt;</code></pre>',
''))
,p_landmark_label=>'Demo Padding'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3493579766169239)
,p_plug_name=>'Example Markup'
,p_static_id=>'example-markup_1'
,p_parent_plug_id=>wwv_flow_imp.id(3489797692169201)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-html"><code>',
'&lt;div class="u-flex u-gap-4"&gt;',
'    &lt;div class="row"&gt;Row 1&lt;/div&gt;',
'    &lt;div class="row"&gt;Row 2&lt;/div&gt;',
'    &lt;div class="row"&gt;Row 3&lt;/div&gt;',
'&lt;/div&gt;',
'</code>',
'</pre>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3493622114169240)
,p_plug_name=>'Example Markup'
,p_static_id=>'example-markup_1_1'
,p_parent_plug_id=>wwv_flow_imp.id(3489957913169203)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-html u-overflow-hidden"><code>',
'&lt;div class="h50 u-overflow-y-scroll"&gt;',
'    &lt;div class="row"&gt;In vestibulum mattis ornare. Ut nec turpis eget tortor volutpat ultricies. Mauris tempor ex ac mauris elementum scelerisque. Pellentesque a magna vitae ex pretium efficitur ac at neque. Vivamus auctor vel tellus vitae viver'
||'ra. Aliquam quis quam velit. Vivamus sit amet semper est, quis eleifend diam. Pellentesque venenatis euismod dui sed dignissim. Nulla facilisi. Vestibulum in sollicitudin dolor. Vestibulum sollicitudin sollicitudin nibh, a ultricies est ornare id. Ut'
||' lorem quam, iaculis porta leo non, ultrices dapibus arcu. Sed venenatis ex vel viverra varius.&lt;/div&gt;',
'&lt;/div&gt;',
'</code>',
'</pre>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2084251912727326065)
,p_plug_name=>'Flex'
,p_static_id=>'flex'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>These utility classes can be added to help arrange items in rows, columns or more "flexible" layouts. They can ',
'    also help with item alignment, content justification, content ordering, and content spacing.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602209235267515863)
,p_plug_name=>'Floats'
,p_static_id=>'floats'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>To float an element, you can use the <span class="class tag">u-pull<span class="class-var">Direction</span></span> utility classes.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3489797692169201)
,p_plug_name=>'Gap'
,p_static_id=>'gap'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Gap classes help to set the spacing between flex or grid items, controlling both row and column gaps in a single property. To use these utility classes make sure the parent element has the display property set to flex, inline-flex, or grid.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602209658761515867)
,p_plug_name=>'Height'
,p_static_id=>'height'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>95
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Text</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3084491314124867124)
,p_plug_name=>'Introduction'
,p_static_id=>'introduction'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>You can use the following utility classes anywhere in your app to fine-tune the layout of your page and components. For most Oracle APEX components, you can simply populate the <b>CSS Classes</b> property to apply these modifiers to your page comp'
||'onents.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602209370563515864)
,p_plug_name=>'Margin'
,p_static_id=>'margin'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>65
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Margin classes can be added to help add spacing around your elements. As of Universal Theme 24.2 we added the "u-" prefix to margin utility classes.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16850450637448079)
,p_plug_name=>'Options'
,p_static_id=>'options'
,p_parent_plug_id=>wwv_flow_imp.id(16850292935448078)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Set the order to lay out an item in a flex container. Items in a container are sorted by ascending order value and then by their source code order.</p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Values</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'        <td><span class="class">u-order-</span></td>',
'        <td>',
'            <span class="class-value">0</span> <br />',
'            <span class="class-value">1</span> <br />',
'            <span class="class-value">2</span> <br />',
'            <span class="class-value">3</span> <br />',
'            <span class="class-value">4</span> <br />',
'            <span class="class-value">5</span>',
'        </td>',
'    </tr>',
'',
'  </tbody>',
'</table>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3099797167521540977)
,p_plug_name=>'Options'
,p_static_id=>'options-2'
,p_parent_plug_id=>wwv_flow_imp.id(2602209370563515864)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use the following class name structure with the options listed below to add spacing around your element.</p>',
'<p><span class="class tag">u-margin-<span class="class-var">direction</span>-<span class="class-var">spacing</span></span></p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Variable</th>',
'      <th class="u-textStart">Values</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'        <td>Direction</td>',
'        <td>',
'            <span class="class-value">top</span> <br />',
'            <span class="class-value">right</span> <br />',
'            <span class="class-value">bottom</span> <br />',
'            <span class="class-value">left</span> <br />',
'            <span class="class-value">block</span> <br />',
'            <span class="class-value">inline</span>',
'        </td>',
'        <td>Where the margin should be positioned</td>',
'    </tr>',
'    <tr>',
'        <td>Spacing</td>',
'        <td>',
'            <span class="class-value">none</span> <span class="class-desc">0 px</span><br />',
'            <span class="class-value">xs</span>   <span class="class-desc">4 px</span><br />',
'            <span class="class-value">sm</span>   <span class="class-desc">8 px</span><br />',
'            <span class="class-value">md</span>   <span class="class-desc">16 px</span><br />',
'            <span class="class-value">lg</span>   <span class="class-desc">32 px</span><br />',
'            <span class="class-value">xl</span>   <span class="class-desc">48 px</span>',
'        </td>',
'        <td>',
'            The amount of spacing in pixels. ',
'        </td>',
'    </tr>',
'',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Margin Options'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3489852869169202)
,p_plug_name=>'Options'
,p_static_id=>'options-2_1'
,p_parent_plug_id=>wwv_flow_imp.id(3489797692169201)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Values</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'        <td><span class="class">u-gap-</span></td>',
'        <td>',
'            <span class="class-value">0</span> <span class="class-desc">0 px</span> <br />',
'            <span class="class-value">px</span> <span class="class-desc">1 px</span> <br />',
'            <span class="class-value">0_5</span> <span class="class-desc">2 px</span> <br />',
'            <span class="class-value">1</span> <span class="class-desc">4 px</span> <br />',
'            <span class="class-value">1_5</span> <span class="class-desc">6 px</span> <br />',
'            <span class="class-value">2</span> <span class="class-desc">8 px</span> <br />',
'            <span class="class-value">2_5</span> <span class="class-desc">10 px</span> <br />',
'            <span class="class-value">3</span> <span class="class-desc">12 px</span> <br />',
'            <span class="class-value">3_5</span> <span class="class-desc">14 px</span> <br />',
'            <span class="class-value">4</span> <span class="class-desc">16 px</span> <br />',
'            <span class="class-value">5</span> <span class="class-desc">20 px</span> <br />',
'            <span class="class-value">6</span> <span class="class-desc">24 px</span> <br />',
'            <span class="class-value">7</span> <span class="class-desc">28 px</span> <br />',
'            <span class="class-value">8</span> <span class="class-desc">32 px</span> <br />',
'            <span class="class-value">9</span> <span class="class-desc">36 px</span> <br />',
'            <span class="class-value">10</span> <span class="class-desc">40 px</span>',
'        </td>',
'    </tr>',
'',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Margin Options'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3490043003169204)
,p_plug_name=>'Options'
,p_static_id=>'options-2_1_1'
,p_parent_plug_id=>wwv_flow_imp.id(3489957913169203)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-overflow-<span class="class-value">auto</span></span></td><td>Adds scrollbars only when content exceeds the container size.</td></tr>',
'    <tr><td><span class="class">u-overflow-<span class="class-value">hidden</span></span></td><td>Content that exceeds the container is clipped and hidden.  </td></tr>',
'    <tr><td><span class="class">u-overflow-<span class="class-value">scroll</span></span></td><td>Adds scrollbars to the container so all content can be reached. </td></tr>',
'    <tr><td><span class="class">u-overflow-<span class="class-value">x-scroll</span></span></td><td>Adds horizontal scrollbars.</td></tr>',
'    <tr><td><span class="class">u-overflow-<span class="class-value">y-scroll</span></span></td><td>Adds vertical scrollbars.</td></tr>',
'    <tr><td><span class="class">u-overflow-<span class="class-value">visible</span></span></td><td>Content spills outside the container and remains fully visible.</td></tr>',
'    <tr><td><span class="class">u-overflow-<span class="class-value">clip</span></span></td><td>Clips content like hidden, but also prevents any scrolling. </td></tr>',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Margin Options'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2336112478672202)
,p_plug_name=>'Options'
,p_static_id=>'options-2_1_1_1'
,p_parent_plug_id=>wwv_flow_imp.id(2336056696672201)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-displayNone</span></td><td>Hides an element, but another CSS rule may override it.</td></tr>',
'    <tr><td><span class="class">u-hidden</span></td><td>Hides an element, and gives the rule priority over competing declarations.</td></tr>',
'    </tbody>',
'</table>'))
,p_landmark_label=>'Margin Options'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602210706466515877)
,p_plug_name=>'Options'
,p_static_id=>'options-3'
,p_parent_plug_id=>wwv_flow_imp.id(2602209554646515866)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Classes</th>',
'      <th class="u-textStart">Values</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'        <td><span class="class tag">w<span class="class-value">amount</span></span></td>',
'        <td>',
'            <span class="class">10-800</span> <span class="class-desc">px</span>',
'        </td>',
'        <td>Sets the element''s width to specified value. Sizes in 10px increments.</td>',
'    </tr>',
'    <tr>',
'        <td><span class="class tag">w<span class="class-value">percentage</span>p</span></td>',
'        <td>',
'            <span class="class">5-100</span> <span class="class-desc">%</span>',
'        </td>',
'        <td>Sets the element''s width to specified percentage. Percentages in 5% increments</td>',
'    </tr>',
'    <tr>',
'        <td><span class="class tag">mnw<span class="class-value">amount</span></span></td>',
'        <td>',
'            <span class="class">10-800</span> <span class="class-desc">px</span>',
'        </td>',
'        <td>Sets the element''s min-width to specified value. Sizes in 10px increments</td>',
'    </tr>',
'    <tr>',
'        <td><span class="class tag">mxw<span class="class-value">amount</span></span></td>',
'        <td>',
'            <span class="class">10-800</span> <span class="class-desc">px</span>',
'        </td>',
'        <td>Sets the element''s max-width to specified value. Sizes in 10px increments</td>',
'    </tr>',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Width Options'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602210867894515879)
,p_plug_name=>'Options'
,p_static_id=>'options-4'
,p_parent_plug_id=>wwv_flow_imp.id(2602209658761515867)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Classes</th>',
'      <th class="u-textStart">Values</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'        <td><span class="class">h<span class="class-value">amount</span></span></td>',
'        <td>',
'            <span class="class-value">10-800</span> <span class="class-desc">px</span>',
'        </td>',
'        <td>Sets the element''s height to specified value. Sizes in 10px increments</td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">mxh<span class="class-value">amount</span></span></td>',
'        <td>',
'            <span class="class-value">10-800</span> <span class="class-desc">px</span>',
'        </td>',
'        <td>Sets the element''s max-height to specified value. Sizes in 10px increments</td>',
'    </tr>',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Height Options'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602210330826515874)
,p_plug_name=>'Options'
,p_static_id=>'options-5'
,p_parent_plug_id=>wwv_flow_imp.id(2602210317719515873)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use the following class name structure with the options listed below to add spacing around your element.</p>',
'<p><span class="class tag">u-padding-<span class="class-var">direction</span>-<span class="class-var">spacing</span></span></p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Variable</th>',
'      <th class="u-textStart">Values</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'        <td>Direction</td>',
'        <td>',
'            <span class="class-value">top</span> <br />',
'            <span class="class-value">right</span> <br />',
'            <span class="class-value">bottom</span> <br />',
'            <span class="class-value">left</span> <br />',
'            <span class="class-value">block</span> <br />',
'            <span class="class-value">inline</span>',
'        </td>',
'        <td>Where the padding should be positioned</td>',
'    </tr>',
'    <tr>',
'        <td>Spacing</td>',
'        <td>',
'            <span class="class-value">none</span> <span class="class-desc">0 px</span><br />',
'            <span class="class-value">xs</span>   <span class="class-desc">4 px</span><br />',
'            <span class="class-value">sm</span>   <span class="class-desc">8 px</span><br />',
'            <span class="class-value">md</span>   <span class="class-desc">16 px</span><br />',
'            <span class="class-value">lg</span>   <span class="class-desc">32 px</span><br />',
'            <span class="class-value">xl</span>   <span class="class-desc">48 px</span>',
'        </td>',
'        <td>',
'            The amount of spacing in pixels. ',
'        </td>',
'    </tr>',
'',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Padding Options'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16850292935448078)
,p_plug_name=>'Order'
,p_static_id=>'order'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>35
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Order classes can help you place elements in a different order. Order is a flex based property. To use these utility classes make sure the parent element has the display property set to flex, inline-flex, or grid.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16850500368448080)
,p_plug_name=>'Other Classes'
,p_static_id=>'other-classes'
,p_parent_plug_id=>wwv_flow_imp.id(16850292935448078)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use these classes to adjust the order of your elements when the viewport size is at the specified breakpoint.</p>',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-order-<span class="class-value">xxs-number</span></span></td><td>479px and below</td></tr>',
'    <tr><td><span class="class">u-order-<span class="class-value">xs-number</span></span></td><td>480px to 639px</td></tr>',
'    <tr><td><span class="class">u-order-<span class="class-value">sm-number</span></span></td><td>640px to 767px</td></tr>',
'    <tr><td><span class="class">u-order-<span class="class-value">md-number</span></span></td><td>768px to 991px</td></tr>',
'    <tr><td><span class="class">u-order-<span class="class-value">lg-number</span></span></td><td>992px to 1199px</td></tr>',
'    <tr><td><span class="class">u-order-<span class="class-value">xl-number</span></span></td><td>1200px to 1399px</td></tr>',
'    <tr><td><span class="class">u-order-<span class="class-value">xxl-number</span></span></td><td>1400px and above</td></tr>',
'  </tbody>',
'</table>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3099797381978540979)
,p_plug_name=>'Other Classes'
,p_static_id=>'other-classes-2'
,p_parent_plug_id=>wwv_flow_imp.id(2602209370563515864)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use these classes to adjust spacing around all sides of your element.</p>',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-margin-<span class="class-value">none</span></span></td><td>No margin</td></tr>',
'    <tr><td><span class="class">u-margin-<span class="class-value">xs</span></span></td><td>4 px margin</td></tr>',
'    <tr><td><span class="class">u-margin-<span class="class-value">sm</span></span></td><td>8 px margin</td></tr>',
'    <tr><td><span class="class">u-margin-<span class="class-value">md</span></span></td><td>16 px margin</td></tr>',
'    <tr><td><span class="class">u-margin-<span class="class-value">lg</span></span></td><td>32 px margin</td></tr>',
'    <tr><td><span class="class">u-margin-<span class="class-value">xl</span></span></td><td>48 px margin</td></tr>',
'    <tr><td><span class="class">u-margin-<span class="class-value">inline-auto</span></span></td><td>aligns content into the center</td></tr>',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Margin Classes'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602210492219515875)
,p_plug_name=>'Other Classes'
,p_static_id=>'other-classes-3'
,p_parent_plug_id=>wwv_flow_imp.id(2602210317719515873)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use these classes to adjust spacing within all sides of your element.</p>',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-padding-<span class="class-value">none</span></span></td><td>No padding</td></tr>',
'    <tr><td><span class="class">u-padding-<span class="class-value">xs</span></span></td><td>4 px padding</td></tr>',
'    <tr><td><span class="class">u-padding-<span class="class-value">sm</span></span></td><td>8 px padding</td></tr>',
'    <tr><td><span class="class">u-padding-<span class="class-value">md</span></span></td><td>16 px padding</td></tr>',
'    <tr><td><span class="class">u-padding-<span class="class-value">lg</span></span></td><td>32 px padding</td></tr>',
'    <tr><td><span class="class">u-padding-<span class="class-value">xl</span></span></td><td>48 px padding</td></tr>',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Padding Classes'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3489957913169203)
,p_plug_name=>'Overflow'
,p_static_id=>'overflow'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Controls what happens to content that is too large to fit inside its container. </p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2336056696672201)
,p_plug_name=>'Display'
,p_static_id=>'overflow_1'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>120
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Controls whether an element is displayed and whether its hidden state can be overridden by other CSS rules.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602210317719515873)
,p_plug_name=>'Padding'
,p_static_id=>'padding'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>75
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Padding classes can be added to help add spacing within your elements. As of Universal Theme 24.2 we added the "u-" prefix to padding utility classes.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3099796820874540973)
,p_plug_name=>'RDS'
,p_static_id=>'rds'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602210129925515872)
,p_plug_name=>'Vertical Alignment'
,p_static_id=>'vertical-alignment'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>To vertically-align the contents of an element you can use the <span class="class tag">u-align<span class="class-var">Direction</span></span> utility class.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602209554646515866)
,p_plug_name=>'Width'
,p_static_id=>'width'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>85
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Text</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
