prompt --application/pages/page_01919
begin
--   Manifest
--     PAGE: 01919
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1919
,p_name=>'Drawer Demo - Fixed Size'
,p_alias=>'DRAWER-DEMO-FIXED-SIZE'
,p_page_mode=>'MODAL'
,p_step_title=>'Drawer Demo - Fixed Size'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(2421696170353883330)
,p_step_template=>1664614232864994871
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4461879083100170108)
,p_plug_name=>'Overview'
,p_static_id=>'overview'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This drawer has a fixed width of 400px and will not automatically resize to fit its contents.  This type of drawer is useful for wizards where the navigation buttons should remain in a constant position.</p>',
'<p>To set a width for a drawer page, simply set the "Width" property for the page in the Property Editor.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
