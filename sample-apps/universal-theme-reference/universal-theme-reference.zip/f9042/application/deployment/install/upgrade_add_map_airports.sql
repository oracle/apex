prompt --application/deployment/install/upgrade_add_map_airports
begin
--   Manifest
--     INSTALL: UPGRADE-Add Map Airports
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>776266751179078842
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(794413995122986456)
,p_install_id=>wwv_flow_imp.id(4021015843152886897)
,p_name=>'Add Map Airports'
,p_sequence=>20
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>'select null from user_tables where table_name = ''EBA_UT_MAP_AIRPORTS'''
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'alter session set nls_numeric_characters=''.,'';',
'',
'--',
'-- create table',
'--',
'create table eba_ut_map_airports (',
'    id                     number not null primary key,',
'    iata_code              varchar2(10),',
'    airport_type           varchar2(255),',
'    airport_name           varchar2(255),',
'    city                   varchar2(255),',
'    state_name             varchar2(255),',
'    activation_date        varchar2(50),',
'    activation_date_dt     date,',
'    elevation              number,',
'    dist_city_to_airport   number,',
'    land_area_covered      number,',
'    commercial_ops         number,',
'    air_taxi_ops           number,',
'    geometry               mdsys.sdo_geometry )',
'/',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (1568,''PHX'',''AIRPORT'',''PHOENIX SK'
||'Y HARBOR INTL'',''PHOENIX'',''ARIZONA'',''APR-40'',to_date(''04/01/1940''),1135,3,3400,384714,384714, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-112.01158, 33.43428, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (2139,''LAX'',''AIRPORT'',''LOS ANGELE'
||'S INTL'',''LOS ANGELES'',''CALIFORNIA'',''APR-40'',to_date(''04/01/1940''),128,9,3500,634515,634515, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-118.40805, 33.9425, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (2384,''SJC'',''AIRPORT'',''NORMAN Y M'
||'INETA SAN JOSE INTL'',''SAN JOSE'',''CALIFORNIA'',''FEB-46'',to_date(''02/01/1946''),62,2,1050,138613,138613, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-121.92862, 37.36299, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (2376,''SFO'',''AIRPORT'',''SAN FRANCI'
||'SCO INTL'',''SAN FRANCISCO'',''CALIFORNIA'',''APR-40'',to_date(''04/01/1940''),13,8,5207,407153,407153, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-122.37542, 37.61881, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (2364,''SAN'',''AIRPORT'',''SAN DIEGO '
||'INTL'',''SAN DIEGO'',''CALIFORNIA'',''APR-40'',to_date(''04/01/1940''),17,2,663,203913,203913, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-117.18967, 32.73356, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (2215,''OAK'',''AIRPORT'',''METROPOLIT'
||'AN OAKLAND INTL'',''OAKLAND'',''CALIFORNIA'',''APR-40'',to_date(''04/01/1940''),9,4,2600,132865,132865, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-122.22114, 37.72125, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (2696,''DEN'',''AIRPORT'',''DENVER INT'
||'L'',''DENVER'',''COLORADO'',''AUG-93'',to_date(''08/01/1993''),5434,16,33531,462276,462276, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-104.67317, 39.86167, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (3150,''DCA'',''AIRPORT'',''RONALD REA'
||'GAN WASHINGTON NATIONAL'',''WASHINGTON'',''DIST. OF COLUMBIA'',''MAR-41'',to_date(''03/01/1941''),14,3,861,239759,239759, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-77.03772, 38.85144, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (3157,''IAD'',''AIRPORT'',''WASHINGTON'
||' DULLES INTL'',''WASHINGTON'',''DIST. OF COLUMBIA'',''NOV-62'',to_date(''11/01/1962''),313,20,13000,183677,183677, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-77.45994, 38.94744, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (3719,''MIA'',''AIRPORT'',''MIAMI INTL'
||''',''MIAMI'',''FLORIDA'',''APR-40'',to_date(''04/01/1940''),9,8,3300,356198,356198, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-80.29012, 25.79536, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (3836,''MCO'',''AIRPORT'',''ORLANDO IN'
||'TL'',''ORLANDO'',''FLORIDA'',''JUN-41'',to_date(''06/01/1941''),96,6,12600,337510,337510, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-81.309, 28.42939, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (3410,''FLL'',''AIRPORT'',''FORT LAUDE'
||'RDALE/HOLLYWOOD INTL'',''FORT LAUDERDALE'',''FLORIDA'',''APR-40'',to_date(''04/01/1940''),65,3,1380,288866,288866, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-80.14969, 26.07167, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (3993,''TPA'',''AIRPORT'',''TAMPA INTL'
||''',''TAMPA'',''FLORIDA'',''APR-40'',to_date(''04/01/1940''),26,6,3300,170756,170756, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-82.53325, 27.97547, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (4118,''ATL'',''AIRPORT'',''HARTSFIELD'
||' - JACKSON ATLANTA INTL'',''ATLANTA'',''GEORGIA'',''SEP-42'',to_date(''09/01/1942''),1026,7,4700,723956,723956, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-84.42786, 33.6367, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (4562,''HNL'',''AIRPORT'',''DANIEL K I'
||'NOUYE INTL'',''HONOLULU'',''HAWAII'',''FEB-38'',to_date(''02/01/1938''),13,3,4220,159726,159726, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-157.92026, 21.31783, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (5291,''MDW'',''AIRPORT'',''CHICAGO MI'
||'DWAY INTL'',''CHICAGO'',''ILLINOIS'',''APR-40'',to_date(''04/01/1940''),620,9,650,181702,181702, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-87.75242, 41.78597, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (5292,''ORD'',''AIRPORT'',''CHICAGO O'''
||'''HARE INTL'',''CHICAGO'',''ILLINOIS'',''FEB-44'',to_date(''02/01/1944''),680,14,7627,652622,652622, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-87.9066, 41.97452, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (6120,''IND'',''AIRPORT'',''INDIANAPOL'
||'IS INTL'',''INDIANAPOLIS'',''INDIANA'',''APR-40'',to_date(''04/01/1940''),796,7,7700,127309,127309, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-86.29464, 39.71731, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (6814,''CVG'',''AIRPORT'',''CINCINNATI'
||'/NORTHERN KENTUCKY INTL'',''COVINGTON'',''KENTUCKY'',''DEC-44'',to_date(''12/01/1944''),896,8,7000,130690,130690, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-84.66782, 39.04884, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (6911,''SDF'',''AIRPORT'',''LOUISVILLE'
||' MUHAMMAD ALI INTL'',''LOUISVILLE'',''KENTUCKY'',''NOV-42'',to_date(''11/01/1942''),501,4,1200,132315,132315, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-85.7365, 38.17409, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (7384,''MSY'',''AIRPORT'',''LOUIS ARMS'
||'TRONG NEW ORLEANS INTL'',''NEW ORLEANS'',''LOUISIANA'',''OCT-44'',to_date(''10/01/1944''),4,10,1500,117292,117292, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-90.25903, 29.99328, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (7775,''BWI'',''AIRPORT'',''BALTIMORE/'
||'WASHINGTON INTL THURGOOD MARSHALL'',''BALTIMORE'',''MARYLAND'',''JAN-50'',to_date(''01/01/1950''),143,9,3160,221775,221775, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-76.66899, 39.17573, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (7551,''BOS'',''AIRPORT'',''GENERAL ED'
||'WARD LAWRENCE LOGAN INTL'',''BOSTON'',''MASSACHUSETTS'',''APR-40'',to_date(''04/01/1940''),19,1,2384,317685,317685, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-71.00639, 42.36294, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (8303,''DTW'',''AIRPORT'',''DETROIT ME'
||'TROPOLITAN WAYNE COUNTY'',''DETROIT'',''MICHIGAN'',''APR-40'',to_date(''04/01/1940''),645,15,4850,315995,315995, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-83.35339, 42.21244, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (8953,''MSP'',''AIRPORT'',''MINNEAPOLI'
||'S-ST PAUL INTL/WOLD-CHAMBERLAIN'',''MINNEAPOLIS'',''MINNESOTA'',''APR-40'',to_date(''04/01/1940''),842,6,2930,372138,372138, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-93.22178, 44.88197, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (9372,''MCI'',''AIRPORT'',''KANSAS CIT'
||'Y INTL'',''KANSAS CITY'',''MISSOURI'',''MAY-56'',to_date(''05/01/1956''),1027,15,10680,107375,107375, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-94.71389, 39.29761, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (9546,''STL'',''AIRPORT'',''ST LOUIS L'
||'AMBERT INTL'',''ST LOUIS'',''MISSOURI'',''APR-40'',to_date(''04/01/1940''),618,10,2800,139321,139321, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-90.37003, 38.7487, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (11943,''LAS'',''AIRPORT'',''MC CARRAN'
||' INTL'',''LAS VEGAS'',''NEVADA'',''JAN-47'',to_date(''01/01/1947''),2181,5,2800,366704,366704, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-115.15223, 36.08004, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (11574,''EWR'',''AIRPORT'',''NEWARK LI'
||'BERTY INTL'',''NEWARK'',''NEW JERSEY'',''NOV-39'',to_date(''11/01/1939''),17,3,2027,351188,351188, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-74.16869, 40.69248, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (12354,''JFK'',''AIRPORT'',''JOHN F KE'
||'NNEDY INTL'',''NEW YORK'',''NEW YORK'',''JAN-39'',to_date(''01/01/1939''),13,13,5200,423230,423230, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-73.77869, 40.63993, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (12355,''LGA'',''AIRPORT'',''LAGUARDIA'
||''',''NEW YORK'',''NEW YORK'','''',to_date(''''),21,4,680,317955,317955, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-73.87261, 40.77725, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (10274,''CLT'',''AIRPORT'',''CHARLOTTE'
||'/DOUGLAS INTL'',''CHARLOTTE'',''NORTH CAROLINA'',''SEP-37'',to_date(''09/01/1937''),748,5,5558,454153,454153, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-80.94906, 35.21375, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (10554,''RDU'',''AIRPORT'',''RALEIGH-D'
||'URHAM INTL'',''RALEIGH/DURHAM'',''NORTH CAROLINA'',''APR-43'',to_date(''04/01/1943''),435,9,5000,106157,106157, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-78.78747, 35.87764, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (13985,''PDX'',''AIRPORT'',''PORTLAND '
||'INTL'',''PORTLAND'',''OREGON'',''MAR-40'',to_date(''03/01/1940''),31,4,3000,195797,195797, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-122.59687, 45.58871, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (14632,''PHL'',''AIRPORT'',''PHILADELP'
||'HIA INTL'',''PHILADELPHIA'',''PENNSYLVANIA'',''OCT-40'',to_date(''10/01/1940''),36,5,2302,259799,259799, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-75.24066, 39.87208, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (14658,''PIT'',''AIRPORT'',''PITTSBURG'
||'H INTL'',''PITTSBURGH'',''PENNSYLVANIA'',''MAR-44'',to_date(''03/01/1944''),1203,12,10000,100765,100765, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-80.23269, 40.49142, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (15520,''MEM'',''AIRPORT'',''MEMPHIS I'
||'NTL'',''MEMPHIS'',''TENNESSEE'',''AUG-37'',to_date(''08/01/1937''),341,3,3900,204061,204061, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-89.97668, 35.04241, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (15542,''BNA'',''AIRPORT'',''NASHVILLE'
||' INTL'',''NASHVILLE'',''TENNESSEE'',''DEC-37'',to_date(''12/01/1937''),599,5,3900,147743,147743, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-86.67818, 36.12447, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (16147,''DFW'',''AIRPORT'',''DALLAS-FO'
||'RT WORTH INTL'',''DALLAS-FORT WORTH'',''TEXAS'',''JAN-74'',to_date(''01/01/1974''),607,12,17207,615799,615799, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-97.03769, 32.89723, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (16620,''IAH'',''AIRPORT'',''GEORGE BU'
||'SH INTERCONTINENTAL/HOUSTON'',''HOUSTON'',''TEXAS'',''JAN-63'',to_date(''01/01/1963''),96,15,10000,362947,362947, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-95.34144, 29.98444, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (16619,''HOU'',''AIRPORT'',''WILLIAM P'
||' HOBBY'',''HOUSTON'',''TEXAS'',''JAN-39'',to_date(''01/01/1939''),46,8,1304,123823,123823, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-95.27889, 29.64542, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (16148,''DAL'',''AIRPORT'',''DALLAS LO'
||'VE FIELD'',''DALLAS'',''TEXAS'',''OCT-37'',to_date(''10/01/1937''),487,5,1300,144308,144308, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-96.85088, 32.84594, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (15748,''AUS'',''AIRPORT'',''AUSTIN-BE'
||'RGSTROM INTL'',''AUSTIN'',''TEXAS'',''JUL-43'',to_date(''07/01/1943''),542,5,4242,140426,140426, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-97.66988, 30.19453, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (17818,''SLC'',''AIRPORT'',''SALT LAKE'
||' CITY INTL'',''SALT LAKE CITY'',''UTAH'',''NOV-38'',to_date(''11/01/1938''),4231,3,7700,231232,231232, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-111.97777, 40.78839, NULL), NULL, NULL ));',
'insert into eba_ut_map_airports (id,iata_code,airport_type,airport_name,city,state_name,activation_date,activation_date_dt,elevation,dist_city_to_airport,land_area_covered,commercial_ops,air_taxi_ops,geometry) values (18776,''SEA'',''AIRPORT'',''SEATTLE-T'
||'ACOMA INTL'',''SEATTLE'',''WASHINGTON'',''JAN-44'',to_date(''01/01/1944''),432,10,2500,427170,427170, MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE (-122.31178, 47.44989, NULL), NULL, NULL ));'))
);
wwv_flow_imp.component_end;
end;
/
