prompt --application/shared_components/pwa/screenshots/screenshot_2_png
begin
--   Manifest
--     PWA SCREENSHOT: Screenshot-2.png
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_screenshot(
 p_id=>wwv_flow_imp.id(478527837271020179)
,p_label=>'Screenshot-2.png'
,p_display_sequence=>20
,p_screenshot_url=>'pwa/Screenshot-2.png'
);
wwv_flow_imp.component_end;
end;
/
