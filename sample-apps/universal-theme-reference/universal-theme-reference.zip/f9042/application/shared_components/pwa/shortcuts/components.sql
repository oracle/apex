prompt --application/shared_components/pwa/shortcuts/components
begin
--   Manifest
--     PWA SHORTCUT: Components
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_shortcut(
 p_id=>wwv_flow_imp.id(1982258083316760893)
,p_name=>'Components'
,p_display_sequence=>30
,p_description=>'Components Section'
,p_target_url=>'f?p=&APP_ID.:3000:&SESSION.'
,p_pwa_shortcut_comment=>'-'
);
wwv_flow_imp.component_end;
end;
/
