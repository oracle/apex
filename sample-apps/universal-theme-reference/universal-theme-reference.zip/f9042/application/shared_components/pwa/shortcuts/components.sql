prompt --application/shared_components/pwa/shortcuts/components
begin
--   Manifest
--     PWA SHORTCUT: Components
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>2028731318158593
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_shortcut(
 p_id=>wwv_flow_imp.id(1966442717791349068)
,p_name=>'Components'
,p_display_sequence=>30
,p_description=>'Components Section'
,p_target_url=>'f?p=&APP_ID.:3000:&SESSION.'
,p_pwa_shortcut_comment=>'-'
);
wwv_flow_imp.component_end;
end;
/
