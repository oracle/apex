prompt --application/shared_components/pwa/shortcuts/design
begin
--   Manifest
--     PWA SHORTCUT: Design
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_shortcut(
 p_id=>wwv_flow_imp.id(463527557763288443)
,p_name=>'Design'
,p_display_sequence=>20
,p_description=>'Design Section'
,p_target_url=>'f?p=&APP_ID.:400:&SESSION.'
,p_pwa_shortcut_comment=>'-'
);
wwv_flow_imp.component_end;
end;
/
