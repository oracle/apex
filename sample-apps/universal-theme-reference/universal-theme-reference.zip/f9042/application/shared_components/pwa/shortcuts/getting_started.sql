prompt --application/shared_components/pwa/shortcuts/getting_started
begin
--   Manifest
--     PWA SHORTCUT: Getting Started
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_shortcut(
 p_id=>wwv_flow_imp.id(463527352180285048)
,p_name=>'Getting Started'
,p_display_sequence=>10
,p_description=>'Getting Started'
,p_target_url=>'f?p=&APP_ID.:500:&SESSION.'
,p_icon_url=>'pwa/shortcut-icon-10.png'
);
wwv_flow_imp.component_end;
end;
/
