prompt --application/shared_components/navigation/lists/ut_sample_navigation_mega_menu
begin
--   Manifest
--     LIST: UT - Sample Navigation Mega Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1339911593214237493)
,p_name=>'UT - Sample Navigation Mega Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339911778239237494)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Menu Item 1'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-home'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339917745192237497)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Sub Menu Item 1.1'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(1339911778239237494)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339918104306237498)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Sub Menu Item 1.2'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(1339911778239237494)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339912155368237495)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Menu Item 2'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-user'
,p_list_item_current_type=>'ALWAYS'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339913759369237495)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Sub Menu Item 2.1'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(1339912155368237495)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339914172795237496)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Sub Menu Item 2.2'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(1339912155368237495)
,p_list_item_current_type=>'ALWAYS'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339914575675237496)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Sub Menu Item 2.3'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(1339912155368237495)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339912557697237495)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Menu Item 3'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-play-circle-o'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339914919304237496)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Sub Menu Item 3.1'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(1339912557697237495)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339915338568237496)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Sub Menu Item 3.2'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(1339912557697237495)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339915784561237496)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Sub Menu Item 3.2.1'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(1339915338568237496)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339916116199237497)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Sub Menu Item 3.2.2'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(1339915338568237496)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339916541932237497)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Sub Menu Item 3.2.3'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(1339915338568237496)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339912909738237495)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Menu Item 4'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-gear'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339916990868237497)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Sub Menu Item 4.1'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(1339912909738237495)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1339917297049237497)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Sub Menu Item 4.2'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(1339912909738237495)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
