prompt --application/shared_components/navigation/lists/ut_javascript_utilities
begin
--   Manifest
--     LIST: UT - JavaScript Utilities
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1211308721919306085)
,p_name=>'UT - JavaScript Utilities'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1211361998915820142)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'JavaScript Events'
,p_list_item_link_target=>'f?p=&APP_ID.:6200:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_list_text_01=>'Listen and respond to these documented events in Universal Theme'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1211309074699306085)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Javascript APIs'
,p_list_item_link_target=>'f?p=&APP_ID.:6201:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_list_text_01=>'Extend Universal Theme with the following widget APIs'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
