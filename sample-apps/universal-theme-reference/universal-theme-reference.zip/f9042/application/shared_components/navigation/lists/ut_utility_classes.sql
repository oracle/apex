prompt --application/shared_components/navigation/lists/ut_utility_classes
begin
--   Manifest
--     LIST: UT - Utility Classes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1211305096650306074)
,p_name=>'UT - Utility Classes'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1211305823054306078)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Color and Status Modifiers'
,p_list_item_link_target=>'f?p=&APP_ID.:6302:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-eyedropper'
,p_list_text_01=>'These color and status modifier classes enable you to add color to custom components.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1211306275766306078)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Layout Modifiers'
,p_list_item_link_target=>'f?p=&APP_ID.:6303:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-th'
,p_list_text_01=>'These CSS classes enable you to modify layout blocks by setting margins, paddings, and more.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1211306598656306079)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Content Modifiers'
,p_list_item_link_target=>'f?p=&APP_ID.:6304:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-keyboard-o'
,p_list_text_01=>'These content modifiers enable you to control the appearance of text, headings, and paragraphs.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
