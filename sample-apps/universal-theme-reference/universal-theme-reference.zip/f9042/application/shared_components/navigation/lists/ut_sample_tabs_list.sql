prompt --application/shared_components/navigation/lists/ut_sample_tabs_list
begin
--   Manifest
--     LIST: UT - Sample Tabs List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2783445112658871101)
,p_name=>'UT - Sample Tabs List'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2783445311410871102)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Tab 1'
,p_list_item_link_target=>'javascript:void(0);'
,p_list_item_icon=>'fa-user'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'1907'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2783445785648871102)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Tab 2'
,p_list_item_link_target=>'javascript:void(0);'
,p_list_item_icon=>'fa-heart-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2783446135687871102)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Tab 3'
,p_list_item_link_target=>'javascript:void(0);'
,p_list_item_icon=>'fa-cloud'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
