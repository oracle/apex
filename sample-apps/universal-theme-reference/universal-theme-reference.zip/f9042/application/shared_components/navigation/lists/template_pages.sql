prompt --application/shared_components/navigation/lists/template_pages
begin
--   Manifest
--     LIST: Template - Pages
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2415657869255697284)
,p_name=>'Template - Pages'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2415756159154480742)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Both Side Columns'
,p_list_item_link_target=>'#both_sides'
,p_list_item_icon=>'fa fa-columns'
,p_list_text_01=>'Organize complex pages with both the left side column and the collapsible right side column.'
,p_list_text_03=>'BS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2415658464343697288)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Left Side Column'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:left_side:&DEBUG.::::'
,p_list_item_icon=>'fa-layout-2col'
,p_list_text_01=>'Display search filters, charts, and other interactive widgets in a left-side display position.'
,p_list_text_03=>'LC'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2415660678372704139)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Login Page'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:other:&DEBUG.::::'
,p_list_item_icon=>'fa-user'
,p_list_text_01=>'Provide an elegant user interface for an application log in page.'
,p_list_text_03=>'LP'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2415659211416697288)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Master Detail'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:master_detail:&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header-sidebar-right'
,p_list_text_01=>'Provide a collapsible right side column and a title bar area which contains primary information.'
,p_list_text_03=>'MD'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2783398832568623906)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Minimal (No Navigation)'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:other:&DEBUG.::::'
,p_list_item_icon=>'fa-layout-blank'
,p_list_text_01=>'Hide the navigation display on single-page applications or pages where navigation is not necessary.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2415659613810697289)
,p_list_item_display_sequence=>65
,p_list_item_link_text=>'Modal Dialog Page'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:dialog:&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header'
,p_list_text_01=>'Display commonly used forms, reports, and other components by loading this template as either modal or non-modal (pop-up) dialogs.'
,p_list_text_03=>'DP'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2783402983756669218)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Modal Dialog Examples'
,p_list_item_link_target=>'f?p=&APP_ID.:1910:&SESSION.:other:&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-header'
,p_list_text_01=>'Get user input, display information, and speed up user interactions without changing context or leaving the current page.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2415658823874697288)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Right Side Column'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:right_side:&DEBUG.::::'
,p_list_item_icon=>'fa-layout-2col'
,p_list_text_01=>'Display action-oriented controls such as buttons or lists in a collapsible right side display position.'
,p_list_text_03=>'RS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2415658032186697285)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Standard'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:standard:&DEBUG.::::'
,p_list_item_icon=>'fa-layout-nav-left-header-header'
,p_list_text_01=>'The default page template.'
,p_list_text_03=>'ST'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2783404878213688159)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Wizard Modal Dialog'
,p_list_item_link_target=>'f?p=&APP_ID.:1208:&SESSION.:other:&DEBUG.::::'
,p_list_item_icon=>'fa-wizard'
,p_list_text_01=>'Simplify complex flows into smaller, more manageable steps.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
