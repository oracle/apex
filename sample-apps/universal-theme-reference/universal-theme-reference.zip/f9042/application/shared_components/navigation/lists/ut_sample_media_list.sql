prompt --application/shared_components/navigation/lists/ut_sample_media_list
begin
--   Manifest
--     LIST: UT - Sample Media List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>8200683834871648
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2629503254703250740)
,p_name=>'UT - Sample Media List'
,p_list_status=>'PUBLIC'
,p_version_scn=>112802242
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2629503439151250741)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Amet Incorporated'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-cloud'
,p_list_text_01=>'Mauris nulla. Integer urna. Vivamus molestie dapibus ligula. Aliquam erat volutpat. Nulla dignissim. Maecenas ornare egestas ligula. Nullam feugiat placerat'
,p_list_text_02=>'4'
,p_list_text_03=>'ML'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2629503746677250742)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Ridiculus LLP'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-comments-o'
,p_list_text_01=>'Phasellus nulla. Integer vulputate, risus a ultricies adipiscing, enim mi tempor lorem, eget mollis lectus pede et risus. Quisque libero.'
,p_list_text_02=>'12'
,p_list_text_03=>'AR'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2629504011002250742)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Tristique LLC'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'Aliquam nisl. Nulla eu neque pellentesque massa lobortis ultrices. Vivamus rhoncus. Donec est. Nunc ullamcorper, velit in aliquet lobortis, nisi.'
,p_list_text_02=>'4'
,p_list_text_03=>'SR'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2629504312294250742)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Cras Interdum Consulting'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-envelope-o'
,p_list_text_01=>'Integer tincidunt aliquam arcu. Aliquam ultrices iaculis odio. Nam interdum enim non nisi. Aenean eget metus. In nec orci.'
,p_list_text_02=>'431'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2629504690643250742)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Felis Associates'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-dashboard'
,p_list_text_01=>'Aenean gravida nunc sed pede. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Proin vel arcu.'
,p_list_text_02=>'Pending'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2629507925169281401)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Eros Nec Corporation'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-credit-card-terminal'
,p_list_text_01=>'Purus gravida sagittis. Duis gravida. Praesent eu nulla at sem molestie sodales. Mauris blandit enim consequat purus. Maecenas libero est.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
