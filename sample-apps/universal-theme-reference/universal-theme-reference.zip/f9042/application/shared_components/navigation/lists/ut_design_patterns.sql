prompt --application/shared_components/navigation/lists/ut_design_patterns
begin
--   Manifest
--     LIST: UT - Design Patterns
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1211321025744361569)
,p_name=>'UT - Design Patterns'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp.component_end;
end;
/
