prompt --application/shared_components/navigation/lists/ut_tools
begin
--   Manifest
--     LIST: UT - Tools
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>8200683834871648
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2722422907133234669)
,p_name=>'UT - Tools'
,p_list_status=>'PUBLIC'
,p_version_scn=>112802243
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(909010299677229249)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Migration Guides'
,p_list_item_link_target=>'f?p=&APP_ID.:2000:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tasks'
,p_list_text_01=>'Use the latest version of Universal Theme and keep current with the latest features, enhancements, and bug fixes.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2722423268002234669)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Button Builder'
,p_list_item_link_target=>'f?p=&APP_ID.:6100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-button'
,p_list_text_01=>'Get the HTML markup or link attributes you need to add buttons to report columns, static content regions, and more.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(909013503657272325)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Template Directives'
,p_list_item_link_target=>'f?p=&APP_ID.:6400:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-brackets'
,p_list_text_01=>'Take control of how substitution strings and content are processed.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(909013988275279089)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Change Log'
,p_list_item_link_target=>'f?p=&APP_ID.:6305:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-history'
,p_list_text_01=>'Look at the changes between Universal Theme versions, improvements, new features, and bug fixes.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
