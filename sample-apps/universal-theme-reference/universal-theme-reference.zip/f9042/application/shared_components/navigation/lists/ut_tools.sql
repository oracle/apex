prompt --application/shared_components/navigation/lists/ut_tools
begin
--   Manifest
--     LIST: UT - Tools
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1211307294737306084)
,p_name=>'UT - Tools'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1211307655606306084)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Button Builder'
,p_list_item_link_target=>'f?p=&APP_ID.:6100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tools'
,p_list_text_01=>'Get the HTML markup or link attributes you need to add buttons to report columns, static content regions, and more.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1211308013115306084)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Icon Builder'
,p_list_item_link_target=>'f?p=&APP_ID.:4000:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tools'
,p_list_text_01=>'Get the HTML markup or icon classes you need to add icons within your UI components.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
