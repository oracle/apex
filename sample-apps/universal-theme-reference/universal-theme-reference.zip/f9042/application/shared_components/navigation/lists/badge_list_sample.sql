prompt --application/shared_components/navigation/lists/badge_list_sample
begin
--   Manifest
--     LIST: Badge List Sample
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1135509488763241652)
,p_name=>'Badge List Sample'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1135509648138241653)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Active Bugs'
,p_list_item_link_target=>'#'
,p_list_text_01=>'12'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1135509974039241653)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Closed Bugs'
,p_list_item_link_target=>'#'
,p_list_text_01=>'31'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1135510498460241658)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Users'
,p_list_item_link_target=>'#'
,p_list_text_01=>'188'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1135510856259241658)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Projects'
,p_list_item_link_target=>'#'
,p_list_text_01=>'34'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1135512873982250467)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Milestones'
,p_list_item_link_target=>'#'
,p_list_text_01=>'3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2403816153948256222)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Action Items'
,p_list_item_link_target=>'#'
,p_list_text_01=>'15'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
