prompt --application/shared_components/navigation/lists/ut_mobile_patterns
begin
--   Manifest
--     LIST: UT - Mobile Patterns
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>776266751179078842
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2604816059171174865)
,p_name=>'UT - Mobile Patterns'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2604816173473174870)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Navigation'
,p_list_item_link_target=>'f?p=&APP_ID.:421:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-breadcrumb'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2604816635397174871)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Headers and Footers'
,p_list_item_link_target=>'f?p=&APP_ID.:422:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header-footer'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2604822161088222070)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Data Entry'
,p_list_item_link_target=>'f?p=&APP_ID.:423:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-forms'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2604817005062174872)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Touch Gestures'
,p_list_item_link_target=>'f?p=&APP_ID.:424:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-hand-o-right'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2604817395351174872)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Mobile Components'
,p_list_item_link_target=>'f?p=&APP_ID.:425:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cubes'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
