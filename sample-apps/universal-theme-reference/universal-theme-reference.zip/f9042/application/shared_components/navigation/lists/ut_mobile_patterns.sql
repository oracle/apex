prompt --application/shared_components/navigation/lists/ut_mobile_patterns
begin
--   Manifest
--     LIST: UT - Mobile Patterns
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2624675180735897730)
,p_name=>'UT - Mobile Patterns'
,p_list_status=>'PUBLIC'
,p_version_scn=>112802242
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2624675295037897735)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Navigation'
,p_list_item_link_target=>'f?p=&APP_ID.:421:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-breadcrumb'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2624675756961897736)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Headers and Footers'
,p_list_item_link_target=>'f?p=&APP_ID.:422:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header-footer'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2624681282652944935)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Data Entry'
,p_list_item_link_target=>'f?p=&APP_ID.:423:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-forms'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2624676126626897737)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Touch Gestures'
,p_list_item_link_target=>'f?p=&APP_ID.:424:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-hand-o-right'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2624676516915897737)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Mobile Components'
,p_list_item_link_target=>'f?p=&APP_ID.:425:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cubes'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
