prompt --application/shared_components/navigation/lists/ut_sample_menu_bar_list
begin
--   Manifest
--     LIST: UT - Sample Menu Bar List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2403853446567343223)
,p_name=>'UT - Sample Menu Bar List'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2403854002212343224)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Menu Item 1'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-cloud'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2403855609846343224)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Sub Menu Item 1.1'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-area-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(2403854002212343224)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2403856069186343225)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Sub Menu Item 1.2'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-bar-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(2403854002212343224)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2403856474755343225)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Sub Menu Item 1.3'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-bar-chart-o'
,p_parent_list_item_id=>wwv_flow_imp.id(2403854002212343224)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2403854467017343224)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Menu Item 2'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-anchor'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2403856877273343225)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Sub Menu Item 2.1'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-bars'
,p_parent_list_item_id=>wwv_flow_imp.id(2403854467017343224)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2403857288509343225)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Sub Menu Item 2.2'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-beer'
,p_parent_list_item_id=>wwv_flow_imp.id(2403854467017343224)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2403857675442343225)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Sub Menu Item 2.2.1'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-binoculars'
,p_parent_list_item_id=>wwv_flow_imp.id(2403857288509343225)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2403858066383343225)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Sub Menu Item 2.2.2'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-bomb'
,p_parent_list_item_id=>wwv_flow_imp.id(2403857288509343225)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2403858413402343226)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Sub Menu Item 2.2.3'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-bug'
,p_parent_list_item_id=>wwv_flow_imp.id(2403857288509343225)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2403854881399343224)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Menu Item 3'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-archive'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2403858805677343227)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Sub Menu Item 3.1'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-briefcase'
,p_parent_list_item_id=>wwv_flow_imp.id(2403854881399343224)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2403859277793343227)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Sub Menu Item 3.2'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-camera'
,p_parent_list_item_id=>wwv_flow_imp.id(2403854881399343224)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2947356266126540337)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Menu Item 4'
,p_list_item_link_target=>'#'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
