prompt --application/shared_components/navigation/lists/ut_sample_menu_bar_list
begin
--   Manifest
--     LIST: UT - Sample Menu Bar List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>776266751179078842
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3902724619089089120)
,p_name=>'UT - Sample Menu Bar List'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3902725174734089121)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Menu Item 1'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-cloud'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3902726782368089121)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Sub Menu Item 1.1'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-area-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(3902725174734089121)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3902727241708089122)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Sub Menu Item 1.2'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-bar-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(3902725174734089121)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3902727647277089122)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Sub Menu Item 1.3'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-bar-chart-o'
,p_parent_list_item_id=>wwv_flow_imp.id(3902725174734089121)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3902725639539089121)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Menu Item 2'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-anchor'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3902728049795089122)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Sub Menu Item 2.1'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-bars'
,p_parent_list_item_id=>wwv_flow_imp.id(3902725639539089121)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3902728461031089122)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Sub Menu Item 2.2'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-beer'
,p_parent_list_item_id=>wwv_flow_imp.id(3902725639539089121)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3902728847964089122)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Sub Menu Item 2.2.1'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-binoculars'
,p_parent_list_item_id=>wwv_flow_imp.id(3902728461031089122)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3902729238905089122)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Sub Menu Item 2.2.2'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-bomb'
,p_parent_list_item_id=>wwv_flow_imp.id(3902728461031089122)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3902729585924089123)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Sub Menu Item 2.2.3'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-bug'
,p_parent_list_item_id=>wwv_flow_imp.id(3902728461031089122)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3902726053921089121)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Menu Item 3'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-archive'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3902729978199089124)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Sub Menu Item 3.1'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-briefcase'
,p_parent_list_item_id=>wwv_flow_imp.id(3902726053921089121)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3902730450315089124)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Sub Menu Item 3.2'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-camera'
,p_parent_list_item_id=>wwv_flow_imp.id(3902726053921089121)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4446227438648286234)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Menu Item 4'
,p_list_item_link_target=>'#'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
