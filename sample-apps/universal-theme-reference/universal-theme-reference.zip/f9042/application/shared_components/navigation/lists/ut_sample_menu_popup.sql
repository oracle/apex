prompt --application/shared_components/navigation/lists/ut_sample_menu_popup
begin
--   Manifest
--     LIST: UT - Sample Menu Popup
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>2028731318158593
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4152667453300367208)
,p_name=>'UT - Sample Menu Popup'
,p_list_status=>'PUBLIC'
,p_version_scn=>112802249
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4152667670556367209)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Action A'
,p_list_item_link_target=>'#'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4152668091289367211)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Action B'
,p_list_item_link_target=>'#'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4152669293400367212)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Sub Item A'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(4152668091289367211)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4152784135996370634)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Sub Item B'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(4152668091289367211)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4152668436844367212)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Action C'
,p_list_item_link_target=>'#'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4152668897740367212)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Action D'
,p_list_item_link_target=>'#'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp.component_end;
end;
/
