prompt --application/shared_components/navigation/lists/ut_sample_menu_popup
begin
--   Manifest
--     LIST: UT - Sample Menu Popup
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>776266751179078842
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4148623697261056168)
,p_name=>'UT - Sample Menu Popup'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4148623914517056169)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Action A'
,p_list_item_link_target=>'#'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4148624335250056171)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Action B'
,p_list_item_link_target=>'#'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4148625537361056172)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Sub Item A'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(4148624335250056171)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4148740379957059594)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Sub Item B'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(4148624335250056171)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4148624680805056172)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Action C'
,p_list_item_link_target=>'#'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4148625141701056172)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Action D'
,p_list_item_link_target=>'#'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp.component_end;
end;
/
