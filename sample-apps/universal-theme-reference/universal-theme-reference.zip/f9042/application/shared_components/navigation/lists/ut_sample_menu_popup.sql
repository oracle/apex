prompt --application/shared_components/navigation/lists/ut_sample_menu_popup
begin
--   Manifest
--     LIST: UT - Sample Menu Popup
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>8200683834871648
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4160868137135238856)
,p_name=>'UT - Sample Menu Popup'
,p_list_status=>'PUBLIC'
,p_version_scn=>112802249
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4160868354391238857)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Action A'
,p_list_item_link_target=>'#'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4160868775124238859)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Action B'
,p_list_item_link_target=>'#'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4160869977235238860)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Sub Item A'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(4160868775124238859)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4160984819831242282)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Sub Item B'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_imp.id(4160868775124238859)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4160869120679238860)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Action C'
,p_list_item_link_target=>'#'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4160869581575238860)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Action D'
,p_list_item_link_target=>'#'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_imp.component_end;
end;
/
