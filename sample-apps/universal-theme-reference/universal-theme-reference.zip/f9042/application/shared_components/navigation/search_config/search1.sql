prompt --application/shared_components/navigation/search_config/search1
begin
--   Manifest
--     SEARCH CONFIG: Search1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(503527609819379179)
,p_label=>'Search1'
,p_static_id=>'search1'
,p_search_type=>'SIMPLE'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_UT_DEMO_CARDS'
,p_searchable_columns=>'CATEGORY:TITLE:SUBTITLE:BODY:SECONDARY_BODY:ICON_CLASS:BADGE:IMAGE_URL'
,p_pk_column_name=>'ID'
,p_title_column_name=>'TITLE'
,p_description_column_name=>'BODY'
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'ICON_CLASS'
);
wwv_flow_imp.component_end;
end;
/
