prompt --application/shared_components/navigation/search_config/search1
begin
--   Manifest
--     SEARCH CONFIG: Search1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>2028731318158593
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(2006242274376425304)
,p_label=>'Search1'
,p_static_id=>'search1'
,p_search_type=>'SIMPLE'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_UT_CHART_PROJECTS'
,p_searchable_columns=>'CREATED_BY:UPDATED_BY:PROJECT'
,p_pk_column_name=>'ID'
,p_title_column_name=>'PROJECT'
,p_icon_source_type=>'INITIALS'
,p_version_scn=>112803033
);
wwv_flow_imp.component_end;
end;
/
