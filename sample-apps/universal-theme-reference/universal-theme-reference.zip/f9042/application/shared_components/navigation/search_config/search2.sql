prompt --application/shared_components/navigation/search_config/search2
begin
--   Manifest
--     SEARCH CONFIG: Search2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(643332474521920620)
,p_label=>'Search2'
,p_static_id=>'search2'
,p_search_type=>'SIMPLE'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_UT_CHART_TASKS'
,p_searchable_columns=>'ID:PROJECT:PARENT_TASK:TASK_NAME:ROW_VERSION_NUMBER:START_DATE:END_DATE:STATUS:ASSIGNED_TO:COST:BUDGET'
,p_pk_column_name=>'ID'
,p_title_column_name=>'ASSIGNED_TO'
,p_description_column_name=>'TASK_NAME'
,p_badge_column_name=>'STATUS'
,p_icon_source_type=>'INITIALS'
);
wwv_flow_imp.component_end;
end;
/
