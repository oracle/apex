prompt --application/shared_components/navigation/search_config/search2
begin
--   Manifest
--     SEARCH CONFIG: Search2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(643332474521920620)
,p_label=>'Search2'
,p_static_id=>'search2'
,p_search_type=>'SIMPLE'
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_query_source=>'select e.*, first_name||'' ''||last_name full_name from AED_EMPLOYEE e'
,p_searchable_columns=>'LOCATION:USER_NAME:CREATED_BY:UPDATED_BY:FIRST_NAME:LAST_NAME:JOB_TITLE:DEPARTMENT'
,p_pk_column_name=>'ID'
,p_title_column_name=>'FULL_NAME'
,p_description_column_name=>'JOB_TITLE'
,p_custom_03_column_name=>'USER_NAME'
,p_icon_source_type=>'INITIALS'
);
wwv_flow_imp.component_end;
end;
/
