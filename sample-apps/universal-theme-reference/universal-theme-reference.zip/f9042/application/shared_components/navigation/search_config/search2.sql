prompt --application/shared_components/navigation/search_config/search2
begin
--   Manifest
--     SEARCH CONFIG: Search2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>2028731318158593
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(2006442538380436116)
,p_label=>'Search2'
,p_static_id=>'search2'
,p_search_type=>'SIMPLE'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_UT_DEMO_CARDS'
,p_searchable_columns=>'CATEGORY:TITLE:SUBTITLE:BODY:SECONDARY_BODY:ICON_CLASS:BADGE:IMAGE_URL'
,p_pk_column_name=>'ID'
,p_title_column_name=>'TITLE'
,p_description_column_name=>'BODY'
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'ICON_CLASS'
,p_version_scn=>112803033
);
wwv_flow_imp.component_end;
end;
/
