prompt --application/shared_components/navigation/breadcrumbs/universal_theme_breadcrumb
begin
--   Manifest
--     MENU: Universal Theme Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>776266751179078842
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(3722706651486710750)
,p_name=>'Universal Theme Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1549851014579591926)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Map'
,p_link=>'f?p=&APP_ID.:1906:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1906
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1749541964585443558)
,p_parent_id=>wwv_flow_imp.id(2875572653090135229)
,p_short_name=>'Theme Styles'
,p_link=>'f?p=&APP_ID.:405:&SESSION.::&DEBUG.:::'
,p_page_id=>405
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1799386694067209603)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Region Display Selector'
,p_link=>'f?p=&APP_ID.:1923:&SESSION.::&DEBUG.:::'
,p_page_id=>1923
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1802740381309578083)
,p_parent_id=>wwv_flow_imp.id(2710213677750467857)
,p_short_name=>'CSS Variables'
,p_link=>'f?p=&APP_ID.:6307:&SESSION.::&DEBUG.:::'
,p_page_id=>6307
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1829700506462585621)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Classic Report'
,p_link=>'f?p=&APP_ID.:1401:&SESSION.::&DEBUG.:::'
,p_page_id=>1401
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1829700969977588152)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Interactive Report'
,p_link=>'f?p=&APP_ID.:1402:&SESSION.::&DEBUG.:::'
,p_page_id=>1402
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1829701113789590209)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Interactive Grid'
,p_link=>'f?p=&APP_ID.:1410:&SESSION.::&DEBUG.:::'
,p_page_id=>1410
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1842008241783548690)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Avatar'
,p_link=>'f?p=&APP_ID.:3001:&SESSION.::&DEBUG.:::'
,p_page_id=>3001
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1842014691172690120)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Badge'
,p_link=>'f?p=&APP_ID.:3002:&SESSION.::&DEBUG.:::'
,p_page_id=>3002
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1842016169662695298)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Comments'
,p_link=>'f?p=&APP_ID.:3003:&SESSION.::&DEBUG.:::'
,p_page_id=>3003
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1842020676167700155)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Content Row'
,p_link=>'f?p=&APP_ID.:3004:&SESSION.::&DEBUG.:::'
,p_page_id=>3004
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1842027528864707194)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Media List'
,p_link=>'f?p=&APP_ID.:3005:&SESSION.::&DEBUG.:::'
,p_page_id=>3005
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1842031157436711891)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Timeline'
,p_link=>'f?p=&APP_ID.:3006:&SESSION.::&DEBUG.:::'
,p_page_id=>3006
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1844550644060688857)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Content Block'
,p_link=>'f?p=&APP_ID.:1209:&SESSION.::&DEBUG.:::'
,p_page_id=>1209
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1847911751474159559)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'List View'
,p_link=>'f?p=&APP_ID.:1700:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1700
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1895743828645237956)
,p_parent_id=>wwv_flow_imp.id(2710213677750467857)
,p_short_name=>'Template Directives'
,p_link=>'f?p=&APP_ID.:6400:&SESSION.::&DEBUG.:::'
,p_page_id=>6400
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1902840402401437176)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Smart Filters'
,p_link=>'f?p=&APP_ID.:1412:&SESSION.::&DEBUG.:::'
,p_page_id=>1412
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1902848208663447707)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Search Region'
,p_link=>'f?p=&APP_ID.:1413:&SESSION.::&DEBUG.:::'
,p_page_id=>1413
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1905008145236091763)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Faceted Search'
,p_link=>'f?p=&APP_ID.:1411:&SESSION.::&DEBUG.:::'
,p_page_id=>1411
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2004445927376986246)
,p_parent_id=>wwv_flow_imp.id(2710213677750467857)
,p_short_name=>'Layout Modifiers'
,p_link=>'f?p=&APP_ID.:6303:&SESSION.'
,p_page_id=>6303
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2004457955273006560)
,p_parent_id=>wwv_flow_imp.id(2710213677750467857)
,p_short_name=>'Content Modifiers'
,p_link=>'f?p=&APP_ID.:6304:&SESSION.'
,p_page_id=>6304
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2030697750307790048)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Region Image'
,p_link=>'f?p=&APP_ID.:1210:&SESSION.::&DEBUG.:::'
,p_page_id=>1210
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2206941443954698385)
,p_short_name=>'Inline Popup'
,p_link=>'f?p=&APP_ID.:1915:&SESSION.'
,p_page_id=>1915
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2208734356315306261)
,p_short_name=>'Inline Drawer'
,p_link=>'f?p=&APP_ID.:1916:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1916
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2211592412595533178)
,p_short_name=>'Page Drawer'
,p_link=>'f?p=&APP_ID.:1917:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1917
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2313248498278463786)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Reflow Report'
,p_link=>'f?p=&APP_ID.:1710:&SESSION.::&DEBUG.:::'
,p_page_id=>1710
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2313249055635470260)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Column Toggle Report'
,p_link=>'f?p=&APP_ID.:1720:&SESSION.::&DEBUG.:::'
,p_page_id=>1720
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2347055907786884689)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Content Row'
,p_link=>'f?p=&APP_ID.:1407:&SESSION.'
,p_page_id=>1407
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2401788908899986755)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Standard Region'
,p_link=>'f?p=&APP_ID.:1201:&SESSION.::&DEBUG.:::'
,p_page_id=>1201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2401813051224005917)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Alert'
,p_link=>'f?p=&APP_ID.:1202:&SESSION.::&DEBUG.:::'
,p_page_id=>1202
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2401835211382143958)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Hero'
,p_link=>'f?p=&APP_ID.:1203:&SESSION.::&DEBUG.:::'
,p_page_id=>1203
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2401880994602827044)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Button Group'
,p_link=>'f?p=&APP_ID.:1204:&SESSION.::&DEBUG.:::'
,p_page_id=>1204
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2401963969475296815)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Carousel'
,p_link=>'f?p=&APP_ID.:1205:&SESSION.::&DEBUG.:::'
,p_page_id=>1205
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2402004482853468568)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Collapsible'
,p_link=>'f?p=&APP_ID.:1206:&SESSION.::&DEBUG.:::'
,p_page_id=>1206
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2402032199577547332)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Title Bar Region'
,p_link=>'f?p=&APP_ID.:1207:&SESSION.::&DEBUG.:::'
,p_page_id=>1207
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2402087982397898048)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Wizards'
,p_link=>'f?p=&APP_ID.:1208:&SESSION.::&DEBUG.:::'
,p_page_id=>1208
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2402549207964035265)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Media List'
,p_link=>'f?p=&APP_ID.:1301:&SESSION.::&DEBUG.:::'
,p_page_id=>1301
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2412502097893615930)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Links List'
,p_link=>'f?p=&APP_ID.:1303:&SESSION.::&DEBUG.:::'
,p_page_id=>1303
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2412525021363672367)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Badge List'
,p_link=>'f?p=&APP_ID.:1304:&SESSION.::&DEBUG.:::'
,p_page_id=>1304
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2412545296183841594)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Menu Bar'
,p_link=>'f?p=&APP_ID.:1305:&SESSION.::&DEBUG.:::'
,p_page_id=>1305
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2412901939672711561)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>' Value Attribute Pairs'
,p_link=>'f?p=&APP_ID.:1403:&SESSION.::&DEBUG.:::'
,p_page_id=>1403
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2412990592745880737)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Comments'
,p_link=>'f?p=&APP_ID.:1405:&SESSION.::&DEBUG.:::'
,p_page_id=>1405
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2413076048991960288)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Timeline'
,p_link=>'f?p=&APP_ID.:1406:&SESSION.::&DEBUG.:::'
,p_page_id=>1406
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2413143017728039251)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Forms'
,p_link=>'f?p=&APP_ID.:1600:&SESSION.::&DEBUG.:::'
,p_page_id=>1600
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2427676878804307212)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Calendar'
,p_link=>'f?p=&APP_ID.:1800:&SESSION.::&DEBUG.:::'
,p_page_id=>1800
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2427804269861964282)
,p_parent_id=>wwv_flow_imp.id(2710213677750467857)
,p_short_name=>'Migration Guides'
,p_link=>'f?p=&APP_ID.:2000:&SESSION.::&DEBUG.:::'
,p_page_id=>2000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2670419214810660403)
,p_parent_id=>wwv_flow_imp.id(2875572653090135229)
,p_short_name=>'Navigation'
,p_link=>'f?p=&APP_ID.:421:&SESSION.::&DEBUG.:::'
,p_page_id=>421
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2710213042982453280)
,p_parent_id=>wwv_flow_imp.id(2710213677750467857)
,p_short_name=>'JavaScript Events'
,p_link=>'f?p=&APP_ID.:6200:&SESSION.::&DEBUG.:::'
,p_page_id=>6200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2710412325504334514)
,p_parent_id=>wwv_flow_imp.id(2710213677750467857)
,p_short_name=>'Button Builder'
,p_link=>'f?p=&APP_ID.:6100:&SESSION.'
,p_page_id=>6100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2729727056756854476)
,p_parent_id=>wwv_flow_imp.id(3755208163316576096)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1115:&SESSION.'
,p_page_id=>1115
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2744649391862934748)
,p_parent_id=>wwv_flow_imp.id(2875572653090135229)
,p_short_name=>'Headers and Footers'
,p_link=>'f?p=&APP_ID.:422:&SESSION.::&DEBUG.:::'
,p_page_id=>422
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2749325066648473548)
,p_parent_id=>wwv_flow_imp.id(2710213677750467857)
,p_short_name=>'Color and Status Modifiers'
,p_link=>'f?p=&APP_ID.:6302:&SESSION.'
,p_page_id=>6302
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2753450815965337800)
,p_short_name=>'Page Footer'
,p_link=>'f?p=&APP_ID.:1117:&SESSION.'
,p_page_id=>1117
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2753528462779823791)
,p_parent_id=>wwv_flow_imp.id(2875572653090135229)
,p_short_name=>'Data Entry'
,p_link=>'f?p=&APP_ID.:423:&SESSION.::&DEBUG.:::'
,p_page_id=>423
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2753604223339414226)
,p_parent_id=>wwv_flow_imp.id(2875572653090135229)
,p_short_name=>'Touch Gestures'
,p_link=>'f?p=&APP_ID.:424:&SESSION.::&DEBUG.:::'
,p_page_id=>424
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2757860789064724940)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Card Regions'
,p_link=>'f?p=&APP_ID.:3110:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>3110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2771979521158009693)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Contextual Info'
,p_link=>'f?p=&APP_ID.:1307:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1307
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2787240841848191777)
,p_parent_id=>wwv_flow_imp.id(2875572653090135229)
,p_short_name=>'jQuery Mobile Components'
,p_link=>'f?p=&APP_ID.:425:&SESSION.::&DEBUG.:::'
,p_page_id=>425
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2837599242950887408)
,p_parent_id=>wwv_flow_imp.id(2875583274418207212)
,p_short_name=>'Menu Bar'
,p_link=>'f?p=&APP_ID.:1120:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1120
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2838066865036923594)
,p_parent_id=>wwv_flow_imp.id(2875583274418207212)
,p_short_name=>'Tabs'
,p_link=>'f?p=&APP_ID.:1121:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1121
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2838773096834942106)
,p_parent_id=>wwv_flow_imp.id(2875583274418207212)
,p_short_name=>'Mega Menu'
,p_link=>'f?p=&APP_ID.:1122:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1122
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2838775362651951074)
,p_parent_id=>wwv_flow_imp.id(2875583274418207212)
,p_short_name=>'Side Tree Navigation'
,p_link=>'f?p=&APP_ID.:1123:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1123
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2838780155674970090)
,p_parent_id=>wwv_flow_imp.id(2875583274418207212)
,p_short_name=>'Mega Menu Variation 2'
,p_link=>'f?p=&APP_ID.:1124:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1124
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2875572653090135229)
,p_short_name=>'Design'
,p_link=>'f?p=&APP_ID.:401:&SESSION.::&DEBUG.:::'
,p_page_id=>401
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2875575677058180904)
,p_parent_id=>wwv_flow_imp.id(2875572653090135229)
,p_short_name=>'Colors'
,p_link=>'f?p=&APP_ID.:402:&SESSION.'
,p_page_id=>402
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2875583274418207212)
,p_parent_id=>wwv_flow_imp.id(2875572653090135229)
,p_short_name=>'Navigation'
,p_link=>'f?p=&APP_ID.:407:&SESSION.'
,p_page_id=>407
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2875599735756528419)
,p_parent_id=>wwv_flow_imp.id(2875572653090135229)
,p_short_name=>'Layout'
,p_link=>'f?p=&APP_ID.:700:&SESSION.::&DEBUG.:::'
,p_page_id=>700
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2875607641979728192)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Breadcrumb'
,p_link=>'f?p=&APP_ID.:3810:&SESSION.'
,p_page_id=>3810
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2876513479262936226)
,p_parent_id=>wwv_flow_imp.id(2875599735756528419)
,p_short_name=>'Grid Layout'
,p_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:::'
,p_page_id=>300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2877839414850422767)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Tree'
,p_link=>'f?p=&APP_ID.:1901:&SESSION.'
,p_page_id=>1901
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2877883606514742213)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Charts'
,p_link=>'f?p=&APP_ID.:1902:&SESSION.'
,p_page_id=>1902
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2877888892876864068)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Help Text'
,p_link=>'f?p=&APP_ID.:1903:&SESSION.'
,p_page_id=>1903
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2877894367053880836)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Static Content'
,p_link=>'f?p=&APP_ID.:1905:&SESSION.::&DEBUG.:::'
,p_page_id=>1905
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2877936462116912991)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Tabs'
,p_link=>'f?p=&APP_ID.:1907:&SESSION.::&DEBUG.:::'
,p_page_id=>1907
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2877939933018342855)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Dynamic Content Region'
,p_link=>'f?p=&APP_ID.:1908:&SESSION.::&DEBUG.:::'
,p_page_id=>1908
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2877942664541362458)
,p_short_name=>'Page Dialog'
,p_link=>'f?p=&APP_ID.:1910:&SESSION.::&DEBUG.:::'
,p_page_id=>1910
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2877944880913379095)
,p_short_name=>'Inline Dialog'
,p_link=>'f?p=&APP_ID.:1911:&SESSION.::&DEBUG.:::'
,p_page_id=>1911
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2878147042977121907)
,p_parent_id=>wwv_flow_imp.id(2710213677750467857)
,p_short_name=>'Change Log'
,p_link=>'f?p=&APP_ID.:6305:&SESSION.'
,p_page_id=>6305
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3755208163316576096)
,p_parent_id=>wwv_flow_imp.id(2875599735756528419)
,p_short_name=>'Page Templates'
,p_link=>'f?p=&APP_ID.:1100:&SESSION.::&DEBUG.:::'
,p_page_id=>1100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3770749437913120763)
,p_parent_id=>wwv_flow_imp.id(3755208163316576096)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1101:&SESSION.'
,p_page_id=>1101
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3882018328459692042)
,p_parent_id=>wwv_flow_imp.id(3755208163316576096)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1102:&SESSION.'
,p_page_id=>1102
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3882032029524765912)
,p_parent_id=>wwv_flow_imp.id(3755208163316576096)
,p_short_name=>'Left Column Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1103:&SESSION.'
,p_page_id=>1103
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3882040241656867441)
,p_parent_id=>wwv_flow_imp.id(3755208163316576096)
,p_short_name=>'Left Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1104:&SESSION.'
,p_page_id=>1104
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3887633001159301216)
,p_parent_id=>wwv_flow_imp.id(3755208163316576096)
,p_short_name=>'Right Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1105:&SESSION.'
,p_page_id=>1105
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3887637039833312825)
,p_parent_id=>wwv_flow_imp.id(3755208163316576096)
,p_short_name=>'Right Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1106:&SESSION.'
,p_page_id=>1106
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3887641481849351613)
,p_parent_id=>wwv_flow_imp.id(3755208163316576096)
,p_short_name=>'Marquee Detail Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1107:&SESSION.::&DEBUG.:::'
,p_page_id=>1107
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3888012285215536999)
,p_parent_id=>wwv_flow_imp.id(3755208163316576096)
,p_short_name=>'Marquee Detail Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1108:&SESSION.::&DEBUG.:::'
,p_page_id=>1108
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3894493365489139721)
,p_parent_id=>wwv_flow_imp.id(3755208163316576096)
,p_short_name=>'Side Columns Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1109:&SESSION.'
,p_page_id=>1109
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3894506653817161312)
,p_parent_id=>wwv_flow_imp.id(3755208163316576096)
,p_short_name=>'Side Columns Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1110:&SESSION.'
,p_page_id=>1110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3895251442306736164)
,p_parent_id=>wwv_flow_imp.id(3755208163316576096)
,p_short_name=>'Standard Dialog Page'
,p_link=>'f?p=&APP_ID.:1111:&SESSION.'
,p_page_id=>1111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3896011151043260971)
,p_parent_id=>wwv_flow_imp.id(3755208163316576096)
,p_short_name=>'Minimal Page Template'
,p_link=>'f?p=&APP_ID.:1113:&SESSION.'
,p_page_id=>1113
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3907803231872534812)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Buttons'
,p_link=>'f?p=&APP_ID.:1500:&SESSION.::&DEBUG.:::'
,p_page_id=>1500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4052728750031363137)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Menu Popup'
,p_link=>'f?p=&APP_ID.:1306:&SESSION.'
,p_page_id=>1306
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4086549873150427040)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Card Templates'
,p_link=>'f?p=&APP_ID.:3100:&SESSION.::&DEBUG.:::'
,p_page_id=>3100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4173228345300497163)
,p_parent_id=>wwv_flow_imp.id(2710213677750467857)
,p_short_name=>'JavaScript APIs'
,p_link=>'f?p=&APP_ID.:6201:&SESSION.'
,p_page_id=>6201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4179237804343104746)
,p_parent_id=>wwv_flow_imp.id(2555040385393764077)
,p_short_name=>'Button Container'
,p_link=>'f?p=&APP_ID.:1250:&SESSION.::&DEBUG.:::'
,p_page_id=>1250
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2555040385393764077)
,p_option_sequence=>30
,p_short_name=>'Components'
,p_link=>'f?p=&APP_ID.:3000:&SESSION.::&DEBUG.:::'
,p_page_id=>3000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2710213677750467857)
,p_option_sequence=>50
,p_short_name=>'Reference'
,p_link=>'f?p=&APP_ID.:6000:&SESSION.::&DEBUG.:::'
,p_page_id=>6000
);
wwv_flow_imp.component_end;
end;
/
