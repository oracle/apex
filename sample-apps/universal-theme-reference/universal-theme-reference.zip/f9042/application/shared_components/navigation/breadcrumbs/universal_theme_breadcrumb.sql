prompt --application/shared_components/navigation/breadcrumbs/universal_theme_breadcrumb
begin
--   Manifest
--     MENU: Universal Theme Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(3742565773051433615)
,p_name=>'Universal Theme Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16839626647433865)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Form Item Types'
,p_link=>'f?p=&APP_ID.:1601:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1601
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1569710136144314791)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Map'
,p_link=>'f?p=&APP_ID.:1906:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1906
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1769401086150166423)
,p_parent_id=>wwv_flow_imp.id(2895431774654858094)
,p_short_name=>'Theme Styles'
,p_link=>'f?p=&APP_ID.:405:&SESSION.::&DEBUG.:::'
,p_page_id=>405
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1819245815631932468)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Region Display Selector'
,p_link=>'f?p=&APP_ID.:1923:&SESSION.::&DEBUG.:::'
,p_page_id=>1923
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1822599502874300948)
,p_parent_id=>wwv_flow_imp.id(2730072799315190722)
,p_short_name=>'CSS Variables'
,p_link=>'f?p=&APP_ID.:6307:&SESSION.::&DEBUG.:::'
,p_page_id=>6307
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1849559628027308486)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Classic Report'
,p_link=>'f?p=&APP_ID.:1401:&SESSION.::&DEBUG.:::'
,p_page_id=>1401
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1849560091542311017)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Interactive Report'
,p_link=>'f?p=&APP_ID.:1402:&SESSION.::&DEBUG.:::'
,p_page_id=>1402
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1849560235354313074)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Interactive Grid'
,p_link=>'f?p=&APP_ID.:1410:&SESSION.::&DEBUG.:::'
,p_page_id=>1410
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1861867363348271555)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Avatar'
,p_link=>'f?p=&APP_ID.:3001:&SESSION.::&DEBUG.:::'
,p_page_id=>3001
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1861873812737412985)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Badge'
,p_link=>'f?p=&APP_ID.:3002:&SESSION.::&DEBUG.:::'
,p_page_id=>3002
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1861875291227418163)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Comments Component'
,p_link=>'f?p=&APP_ID.:3003:&SESSION.::&DEBUG.:::'
,p_page_id=>3003
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1861879797732423020)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Content Row Component'
,p_link=>'f?p=&APP_ID.:3004:&SESSION.::&DEBUG.:::'
,p_page_id=>3004
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1861886650429430059)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Media List Component'
,p_link=>'f?p=&APP_ID.:3005:&SESSION.::&DEBUG.:::'
,p_page_id=>3005
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1861890279001434756)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Timeline Component'
,p_link=>'f?p=&APP_ID.:3006:&SESSION.::&DEBUG.:::'
,p_page_id=>3006
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1864409765625411722)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Content Block'
,p_link=>'f?p=&APP_ID.:1209:&SESSION.::&DEBUG.:::'
,p_page_id=>1209
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1867770873038882424)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'List View'
,p_link=>'f?p=&APP_ID.:1700:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1700
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1915602950209960821)
,p_parent_id=>wwv_flow_imp.id(2730072799315190722)
,p_short_name=>'Template Directives'
,p_link=>'f?p=&APP_ID.:6400:&SESSION.::&DEBUG.:::'
,p_page_id=>6400
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1922699523966160041)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Smart Filters'
,p_link=>'f?p=&APP_ID.:1412:&SESSION.::&DEBUG.:::'
,p_page_id=>1412
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1922707330228170572)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Search Region'
,p_link=>'f?p=&APP_ID.:1413:&SESSION.::&DEBUG.:::'
,p_page_id=>1413
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1924867266800814628)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Faceted Search'
,p_link=>'f?p=&APP_ID.:1411:&SESSION.::&DEBUG.:::'
,p_page_id=>1411
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2024305048941709111)
,p_parent_id=>wwv_flow_imp.id(2730072799315190722)
,p_short_name=>'Layout Modifiers'
,p_link=>'f?p=&APP_ID.:6303:&SESSION.'
,p_page_id=>6303
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2024317076837729425)
,p_parent_id=>wwv_flow_imp.id(2730072799315190722)
,p_short_name=>'Content Modifiers'
,p_link=>'f?p=&APP_ID.:6304:&SESSION.'
,p_page_id=>6304
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2050556871872512913)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Region Image'
,p_link=>'f?p=&APP_ID.:1210:&SESSION.::&DEBUG.:::'
,p_page_id=>1210
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2226800565519421250)
,p_short_name=>'Inline Popup'
,p_link=>'f?p=&APP_ID.:1915:&SESSION.'
,p_page_id=>1915
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2228593477880029126)
,p_short_name=>'Inline Drawer'
,p_link=>'f?p=&APP_ID.:1916:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1916
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2231451534160256043)
,p_short_name=>'Page Drawer'
,p_link=>'f?p=&APP_ID.:1917:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1917
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2333107619843186651)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Reflow Report'
,p_link=>'f?p=&APP_ID.:1710:&SESSION.::&DEBUG.:::'
,p_page_id=>1710
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2333108177200193125)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Column Toggle Report'
,p_link=>'f?p=&APP_ID.:1720:&SESSION.::&DEBUG.:::'
,p_page_id=>1720
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2366915029351607554)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Content Row Report'
,p_link=>'f?p=&APP_ID.:1407:&SESSION.::&DEBUG.:::'
,p_page_id=>1407
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2421648030464709620)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Standard Region'
,p_link=>'f?p=&APP_ID.:1201:&SESSION.::&DEBUG.:::'
,p_page_id=>1201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2421672172788728782)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Alert'
,p_link=>'f?p=&APP_ID.:1202:&SESSION.::&DEBUG.:::'
,p_page_id=>1202
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2421694332946866823)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Hero'
,p_link=>'f?p=&APP_ID.:1203:&SESSION.::&DEBUG.:::'
,p_page_id=>1203
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2421740116167549909)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Button Group'
,p_link=>'f?p=&APP_ID.:1204:&SESSION.::&DEBUG.:::'
,p_page_id=>1204
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2421823091040019680)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Carousel'
,p_link=>'f?p=&APP_ID.:1205:&SESSION.::&DEBUG.:::'
,p_page_id=>1205
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2421863604418191433)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Collapsible'
,p_link=>'f?p=&APP_ID.:1206:&SESSION.::&DEBUG.:::'
,p_page_id=>1206
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2421891321142270197)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Title Bar Region'
,p_link=>'f?p=&APP_ID.:1207:&SESSION.::&DEBUG.:::'
,p_page_id=>1207
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2421947103962620913)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Wizards'
,p_link=>'f?p=&APP_ID.:1208:&SESSION.::&DEBUG.:::'
,p_page_id=>1208
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2422408329528758130)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Media List Report'
,p_link=>'f?p=&APP_ID.:1301:&SESSION.::&DEBUG.:::'
,p_page_id=>1301
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2432361219458338795)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Links List'
,p_link=>'f?p=&APP_ID.:1303:&SESSION.::&DEBUG.:::'
,p_page_id=>1303
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2432384142928395232)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Badge List'
,p_link=>'f?p=&APP_ID.:1304:&SESSION.::&DEBUG.:::'
,p_page_id=>1304
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2432404417748564459)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Menu Bar'
,p_link=>'f?p=&APP_ID.:1305:&SESSION.::&DEBUG.:::'
,p_page_id=>1305
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2432761061237434426)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>' Value Attribute Pairs'
,p_link=>'f?p=&APP_ID.:1403:&SESSION.::&DEBUG.:::'
,p_page_id=>1403
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2432849714310603602)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Comments Report'
,p_link=>'f?p=&APP_ID.:1405:&SESSION.::&DEBUG.:::'
,p_page_id=>1405
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2432935170556683153)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Timeline Report'
,p_link=>'f?p=&APP_ID.:1406:&SESSION.::&DEBUG.:::'
,p_page_id=>1406
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2433002139292762116)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Form Labels'
,p_link=>'f?p=&APP_ID.:1600:&SESSION.::&DEBUG.:::'
,p_page_id=>1600
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2447536000369030077)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Calendar'
,p_link=>'f?p=&APP_ID.:1800:&SESSION.::&DEBUG.:::'
,p_page_id=>1800
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2447663391426687147)
,p_parent_id=>wwv_flow_imp.id(2730072799315190722)
,p_short_name=>'Migration Guides'
,p_link=>'f?p=&APP_ID.:2000:&SESSION.::&DEBUG.:::'
,p_page_id=>2000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2690278336375383268)
,p_parent_id=>wwv_flow_imp.id(2895431774654858094)
,p_short_name=>'Navigation'
,p_link=>'f?p=&APP_ID.:421:&SESSION.::&DEBUG.:::'
,p_page_id=>421
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2730072164547176145)
,p_parent_id=>wwv_flow_imp.id(2730072799315190722)
,p_short_name=>'JavaScript Events'
,p_link=>'f?p=&APP_ID.:6200:&SESSION.::&DEBUG.:::'
,p_page_id=>6200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2730271447069057379)
,p_parent_id=>wwv_flow_imp.id(2730072799315190722)
,p_short_name=>'Button Builder'
,p_link=>'f?p=&APP_ID.:6100:&SESSION.'
,p_page_id=>6100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2749586178321577341)
,p_parent_id=>wwv_flow_imp.id(3775067284881298961)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1115:&SESSION.'
,p_page_id=>1115
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2764508513427657613)
,p_parent_id=>wwv_flow_imp.id(2895431774654858094)
,p_short_name=>'Headers and Footers'
,p_link=>'f?p=&APP_ID.:422:&SESSION.::&DEBUG.:::'
,p_page_id=>422
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2769184188213196413)
,p_parent_id=>wwv_flow_imp.id(2730072799315190722)
,p_short_name=>'Color, Status, and Style Modifiers'
,p_link=>'f?p=&APP_ID.:6302:&SESSION.::&DEBUG.:::'
,p_page_id=>6302
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2773309937530060665)
,p_short_name=>'Page Footer'
,p_link=>'f?p=&APP_ID.:1117:&SESSION.'
,p_page_id=>1117
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2773387584344546656)
,p_parent_id=>wwv_flow_imp.id(2895431774654858094)
,p_short_name=>'Data Entry'
,p_link=>'f?p=&APP_ID.:423:&SESSION.::&DEBUG.:::'
,p_page_id=>423
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2773463344904137091)
,p_parent_id=>wwv_flow_imp.id(2895431774654858094)
,p_short_name=>'Touch Gestures'
,p_link=>'f?p=&APP_ID.:424:&SESSION.::&DEBUG.:::'
,p_page_id=>424
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2777719910629447805)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Card Regions'
,p_link=>'f?p=&APP_ID.:3110:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>3110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2791838642722732558)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Contextual Info'
,p_link=>'f?p=&APP_ID.:1307:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1307
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2807099963412914642)
,p_parent_id=>wwv_flow_imp.id(2895431774654858094)
,p_short_name=>'jQuery Mobile Components'
,p_link=>'f?p=&APP_ID.:425:&SESSION.::&DEBUG.:::'
,p_page_id=>425
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2857458364515610273)
,p_parent_id=>wwv_flow_imp.id(2895442395982930077)
,p_short_name=>'Menu Bar'
,p_link=>'f?p=&APP_ID.:1120:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1120
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2857925986601646459)
,p_parent_id=>wwv_flow_imp.id(2895442395982930077)
,p_short_name=>'Tabs'
,p_link=>'f?p=&APP_ID.:1121:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1121
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2858632218399664971)
,p_parent_id=>wwv_flow_imp.id(2895442395982930077)
,p_short_name=>'Mega Menu'
,p_link=>'f?p=&APP_ID.:1122:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1122
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2858634484216673939)
,p_parent_id=>wwv_flow_imp.id(2895442395982930077)
,p_short_name=>'Side Tree Navigation'
,p_link=>'f?p=&APP_ID.:1123:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1123
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2858639277239692955)
,p_parent_id=>wwv_flow_imp.id(2895442395982930077)
,p_short_name=>'Mega Menu Variation 2'
,p_link=>'f?p=&APP_ID.:1124:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1124
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2895431774654858094)
,p_short_name=>'Design'
,p_link=>'f?p=&APP_ID.:401:&SESSION.::&DEBUG.:::'
,p_page_id=>401
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2895434798622903769)
,p_parent_id=>wwv_flow_imp.id(2895431774654858094)
,p_short_name=>'Colors'
,p_link=>'f?p=&APP_ID.:402:&SESSION.'
,p_page_id=>402
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2895442395982930077)
,p_parent_id=>wwv_flow_imp.id(2895431774654858094)
,p_short_name=>'Navigation'
,p_link=>'f?p=&APP_ID.:407:&SESSION.'
,p_page_id=>407
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2895458857321251284)
,p_parent_id=>wwv_flow_imp.id(2895431774654858094)
,p_short_name=>'Layout'
,p_link=>'f?p=&APP_ID.:700:&SESSION.::&DEBUG.:::'
,p_page_id=>700
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2895466763544451057)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Breadcrumb'
,p_link=>'f?p=&APP_ID.:3810:&SESSION.'
,p_page_id=>3810
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2896372600827659091)
,p_parent_id=>wwv_flow_imp.id(2895458857321251284)
,p_short_name=>'Grid Layout'
,p_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:::'
,p_page_id=>300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2897698536415145632)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Tree'
,p_link=>'f?p=&APP_ID.:1901:&SESSION.'
,p_page_id=>1901
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2897742728079465078)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Charts'
,p_link=>'f?p=&APP_ID.:1902:&SESSION.'
,p_page_id=>1902
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2897748014441586933)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Help Text'
,p_link=>'f?p=&APP_ID.:1903:&SESSION.'
,p_page_id=>1903
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2897753488618603701)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Static Content'
,p_link=>'f?p=&APP_ID.:1905:&SESSION.::&DEBUG.:::'
,p_page_id=>1905
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2897795583681635856)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Tabs'
,p_link=>'f?p=&APP_ID.:1907:&SESSION.::&DEBUG.:::'
,p_page_id=>1907
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2897799054583065720)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Dynamic Content Region'
,p_link=>'f?p=&APP_ID.:1908:&SESSION.::&DEBUG.:::'
,p_page_id=>1908
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2897801786106085323)
,p_short_name=>'Page Dialog'
,p_link=>'f?p=&APP_ID.:1910:&SESSION.::&DEBUG.:::'
,p_page_id=>1910
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2897804002478101960)
,p_short_name=>'Inline Dialog'
,p_link=>'f?p=&APP_ID.:1911:&SESSION.::&DEBUG.:::'
,p_page_id=>1911
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2898006164541844772)
,p_parent_id=>wwv_flow_imp.id(2730072799315190722)
,p_short_name=>'Change Log'
,p_link=>'f?p=&APP_ID.:6305:&SESSION.'
,p_page_id=>6305
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3775067284881298961)
,p_parent_id=>wwv_flow_imp.id(2895458857321251284)
,p_short_name=>'Page Templates'
,p_link=>'f?p=&APP_ID.:1100:&SESSION.::&DEBUG.:::'
,p_page_id=>1100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3790608559477843628)
,p_parent_id=>wwv_flow_imp.id(3775067284881298961)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1101:&SESSION.'
,p_page_id=>1101
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3901877450024414907)
,p_parent_id=>wwv_flow_imp.id(3775067284881298961)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1102:&SESSION.'
,p_page_id=>1102
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3901891151089488777)
,p_parent_id=>wwv_flow_imp.id(3775067284881298961)
,p_short_name=>'Left Column Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1103:&SESSION.'
,p_page_id=>1103
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3901899363221590306)
,p_parent_id=>wwv_flow_imp.id(3775067284881298961)
,p_short_name=>'Left Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1104:&SESSION.'
,p_page_id=>1104
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3907492122724024081)
,p_parent_id=>wwv_flow_imp.id(3775067284881298961)
,p_short_name=>'Right Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1105:&SESSION.'
,p_page_id=>1105
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3907496161398035690)
,p_parent_id=>wwv_flow_imp.id(3775067284881298961)
,p_short_name=>'Right Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1106:&SESSION.'
,p_page_id=>1106
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3907500603414074478)
,p_parent_id=>wwv_flow_imp.id(3775067284881298961)
,p_short_name=>'Marquee Detail Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1107:&SESSION.::&DEBUG.:::'
,p_page_id=>1107
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3907871406780259864)
,p_parent_id=>wwv_flow_imp.id(3775067284881298961)
,p_short_name=>'Marquee Detail Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1108:&SESSION.::&DEBUG.:::'
,p_page_id=>1108
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3914352487053862586)
,p_parent_id=>wwv_flow_imp.id(3775067284881298961)
,p_short_name=>'Side Columns Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1109:&SESSION.'
,p_page_id=>1109
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3914365775381884177)
,p_parent_id=>wwv_flow_imp.id(3775067284881298961)
,p_short_name=>'Side Columns Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1110:&SESSION.'
,p_page_id=>1110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3915110563871459029)
,p_parent_id=>wwv_flow_imp.id(3775067284881298961)
,p_short_name=>'Standard Dialog Page'
,p_link=>'f?p=&APP_ID.:1111:&SESSION.'
,p_page_id=>1111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3915870272607983836)
,p_parent_id=>wwv_flow_imp.id(3775067284881298961)
,p_short_name=>'Minimal Page Template'
,p_link=>'f?p=&APP_ID.:1113:&SESSION.'
,p_page_id=>1113
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3927662353437257677)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Buttons'
,p_link=>'f?p=&APP_ID.:1500:&SESSION.::&DEBUG.:::'
,p_page_id=>1500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4072587871596086002)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Menu Popup'
,p_link=>'f?p=&APP_ID.:1306:&SESSION.'
,p_page_id=>1306
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4106408994715149905)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Card Templates'
,p_link=>'f?p=&APP_ID.:3100:&SESSION.::&DEBUG.:::'
,p_page_id=>3100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4193087466865220028)
,p_parent_id=>wwv_flow_imp.id(2730072799315190722)
,p_short_name=>'JavaScript APIs'
,p_link=>'f?p=&APP_ID.:6201:&SESSION.'
,p_page_id=>6201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4199096925907827611)
,p_parent_id=>wwv_flow_imp.id(2574899506958486942)
,p_short_name=>'Button Container'
,p_link=>'f?p=&APP_ID.:1250:&SESSION.::&DEBUG.:::'
,p_page_id=>1250
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2574899506958486942)
,p_option_sequence=>30
,p_short_name=>'Components'
,p_link=>'f?p=&APP_ID.:3000:&SESSION.::&DEBUG.:::'
,p_page_id=>3000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2730072799315190722)
,p_option_sequence=>50
,p_short_name=>'Reference'
,p_link=>'f?p=&APP_ID.:6000:&SESSION.::&DEBUG.:::'
,p_page_id=>6000
);
wwv_flow_imp.component_end;
end;
/
