prompt --application/shared_components/navigation/breadcrumbs/universal_theme_breadcrumb
begin
--   Manifest
--     MENU: Universal Theme Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-16'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(2223835478964964853)
,p_name=>'Universal Theme Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(250670792063697661)
,p_parent_id=>wwv_flow_imp.id(1376701480568389332)
,p_short_name=>'Theme Styles'
,p_link=>'f?p=&APP_ID.:405:&SESSION.::&DEBUG.:::'
,p_page_id=>405
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(300515521545463706)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Region Display Selector'
,p_link=>'f?p=&APP_ID.:1923:&SESSION.::&DEBUG.:::'
,p_page_id=>1923
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(303869208787832186)
,p_parent_id=>wwv_flow_imp.id(1211342505228721960)
,p_short_name=>'CSS Variables'
,p_link=>'f?p=&APP_ID.:6307:&SESSION.::&DEBUG.:::'
,p_page_id=>6307
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(330829333940839724)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Classic Report'
,p_link=>'f?p=&APP_ID.:1401:&SESSION.::&DEBUG.:::'
,p_page_id=>1401
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(330829797455842255)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Interactive Report'
,p_link=>'f?p=&APP_ID.:1402:&SESSION.::&DEBUG.:::'
,p_page_id=>1402
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(330829941267844312)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Interactive Grid'
,p_link=>'f?p=&APP_ID.:1410:&SESSION.::&DEBUG.:::'
,p_page_id=>1410
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(345679471538942960)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Content Block'
,p_link=>'f?p=&APP_ID.:1209:&SESSION.::&DEBUG.:::'
,p_page_id=>1209
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(349040578952413662)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'List View'
,p_link=>'f?p=&APP_ID.:1700:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1700
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(505574754855240349)
,p_parent_id=>wwv_flow_imp.id(1211342505228721960)
,p_short_name=>'Layout Modifiers'
,p_link=>'f?p=&APP_ID.:6303:&SESSION.'
,p_page_id=>6303
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(505586782751260663)
,p_parent_id=>wwv_flow_imp.id(1211342505228721960)
,p_short_name=>'Content Modifiers'
,p_link=>'f?p=&APP_ID.:6304:&SESSION.'
,p_page_id=>6304
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(531826577786044151)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Region Image'
,p_link=>'f?p=&APP_ID.:1210:&SESSION.::&DEBUG.:::'
,p_page_id=>1210
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(708070271432952488)
,p_short_name=>'Inline Popup'
,p_link=>'f?p=&APP_ID.:1915:&SESSION.'
,p_page_id=>1915
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(709863183793560364)
,p_short_name=>'Inline Drawer'
,p_link=>'f?p=&APP_ID.:1916:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1916
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(712721240073787281)
,p_short_name=>'Page Drawer'
,p_link=>'f?p=&APP_ID.:1917:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1917
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(814377325756717889)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Reflow Report'
,p_link=>'f?p=&APP_ID.:1710:&SESSION.::&DEBUG.:::'
,p_page_id=>1710
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(814377883113724363)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Column Toggle Report'
,p_link=>'f?p=&APP_ID.:1720:&SESSION.::&DEBUG.:::'
,p_page_id=>1720
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(848184735265138792)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Content Row'
,p_link=>'f?p=&APP_ID.:1407:&SESSION.'
,p_page_id=>1407
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(902917736378240858)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Standard Region'
,p_link=>'f?p=&APP_ID.:1201:&SESSION.::&DEBUG.:::'
,p_page_id=>1201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(902941878702260020)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Alert'
,p_link=>'f?p=&APP_ID.:1202:&SESSION.::&DEBUG.:::'
,p_page_id=>1202
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(902964038860398061)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Hero'
,p_link=>'f?p=&APP_ID.:1203:&SESSION.::&DEBUG.:::'
,p_page_id=>1203
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(903009822081081147)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Button Group'
,p_link=>'f?p=&APP_ID.:1204:&SESSION.::&DEBUG.:::'
,p_page_id=>1204
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(903092796953550918)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Carousel'
,p_link=>'f?p=&APP_ID.:1205:&SESSION.::&DEBUG.:::'
,p_page_id=>1205
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(903133310331722671)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Collapsible'
,p_link=>'f?p=&APP_ID.:1206:&SESSION.::&DEBUG.:::'
,p_page_id=>1206
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(903161027055801435)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Title Bar Region'
,p_link=>'f?p=&APP_ID.:1207:&SESSION.::&DEBUG.:::'
,p_page_id=>1207
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(903216809876152151)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Wizards'
,p_link=>'f?p=&APP_ID.:1208:&SESSION.::&DEBUG.:::'
,p_page_id=>1208
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(903678035442289368)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Media List'
,p_link=>'f?p=&APP_ID.:1301:&SESSION.::&DEBUG.:::'
,p_page_id=>1301
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(913630925371870033)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Links List'
,p_link=>'f?p=&APP_ID.:1303:&SESSION.::&DEBUG.:::'
,p_page_id=>1303
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(913653848841926470)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Badge List'
,p_link=>'f?p=&APP_ID.:1304:&SESSION.::&DEBUG.:::'
,p_page_id=>1304
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(913674123662095697)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Menu Bar'
,p_link=>'f?p=&APP_ID.:1305:&SESSION.::&DEBUG.:::'
,p_page_id=>1305
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(914030767150965664)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>' Value Attribute Pairs'
,p_link=>'f?p=&APP_ID.:1403:&SESSION.::&DEBUG.:::'
,p_page_id=>1403
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(914119420224134840)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Comments'
,p_link=>'f?p=&APP_ID.:1405:&SESSION.::&DEBUG.:::'
,p_page_id=>1405
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(914204876470214391)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Timeline'
,p_link=>'f?p=&APP_ID.:1406:&SESSION.::&DEBUG.:::'
,p_page_id=>1406
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(914271845206293354)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Forms'
,p_link=>'f?p=&APP_ID.:1600:&SESSION.::&DEBUG.:::'
,p_page_id=>1600
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(928805706282561315)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Calendar'
,p_link=>'f?p=&APP_ID.:1800:&SESSION.::&DEBUG.:::'
,p_page_id=>1800
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(928933097340218385)
,p_parent_id=>wwv_flow_imp.id(1211342505228721960)
,p_short_name=>'Migration Guides'
,p_link=>'f?p=&APP_ID.:2000:&SESSION.::&DEBUG.:::'
,p_page_id=>2000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1171548042288914506)
,p_parent_id=>wwv_flow_imp.id(1376701480568389332)
,p_short_name=>'Navigation'
,p_link=>'f?p=&APP_ID.:421:&SESSION.::&DEBUG.:::'
,p_page_id=>421
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1211341870460707383)
,p_parent_id=>wwv_flow_imp.id(1211342505228721960)
,p_short_name=>'JavaScript Events'
,p_link=>'f?p=&APP_ID.:6200:&SESSION.::&DEBUG.:::'
,p_page_id=>6200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1211541152982588617)
,p_parent_id=>wwv_flow_imp.id(1211342505228721960)
,p_short_name=>'Button Builder'
,p_link=>'f?p=&APP_ID.:6100:&SESSION.'
,p_page_id=>6100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1230855884235108579)
,p_parent_id=>wwv_flow_imp.id(2256336990794830199)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1115:&SESSION.'
,p_page_id=>1115
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1245778219341188851)
,p_parent_id=>wwv_flow_imp.id(1376701480568389332)
,p_short_name=>'Headers and Footers'
,p_link=>'f?p=&APP_ID.:422:&SESSION.::&DEBUG.:::'
,p_page_id=>422
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1250453894126727651)
,p_parent_id=>wwv_flow_imp.id(1211342505228721960)
,p_short_name=>'Color and Status Modifiers'
,p_link=>'f?p=&APP_ID.:6302:&SESSION.'
,p_page_id=>6302
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1254579643443591903)
,p_short_name=>'Page Footer'
,p_link=>'f?p=&APP_ID.:1117:&SESSION.'
,p_page_id=>1117
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1254657290258077894)
,p_parent_id=>wwv_flow_imp.id(1376701480568389332)
,p_short_name=>'Data Entry'
,p_link=>'f?p=&APP_ID.:423:&SESSION.::&DEBUG.:::'
,p_page_id=>423
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1254733050817668329)
,p_parent_id=>wwv_flow_imp.id(1376701480568389332)
,p_short_name=>'Touch Gestures'
,p_link=>'f?p=&APP_ID.:424:&SESSION.::&DEBUG.:::'
,p_page_id=>424
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1258989616542979043)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Card Regions'
,p_link=>'f?p=&APP_ID.:3110:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>3110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1273108348636263796)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Contextual Info'
,p_link=>'f?p=&APP_ID.:1307:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1307
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1288369669326445880)
,p_parent_id=>wwv_flow_imp.id(1376701480568389332)
,p_short_name=>'jQuery Mobile Components'
,p_link=>'f?p=&APP_ID.:425:&SESSION.::&DEBUG.:::'
,p_page_id=>425
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1338728070429141511)
,p_parent_id=>wwv_flow_imp.id(1376712101896461315)
,p_short_name=>'Menu Bar'
,p_link=>'f?p=&APP_ID.:1120:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1120
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1339195692515177697)
,p_parent_id=>wwv_flow_imp.id(1376712101896461315)
,p_short_name=>'Tabs'
,p_link=>'f?p=&APP_ID.:1121:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1121
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1339901924313196209)
,p_parent_id=>wwv_flow_imp.id(1376712101896461315)
,p_short_name=>'Mega Menu'
,p_link=>'f?p=&APP_ID.:1122:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1122
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1339904190130205177)
,p_parent_id=>wwv_flow_imp.id(1376712101896461315)
,p_short_name=>'Side Tree Navigation'
,p_link=>'f?p=&APP_ID.:1123:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1123
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1339908983153224193)
,p_parent_id=>wwv_flow_imp.id(1376712101896461315)
,p_short_name=>'Mega Menu Variation 2'
,p_link=>'f?p=&APP_ID.:1124:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1124
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1376701480568389332)
,p_parent_id=>0
,p_short_name=>'Design'
,p_link=>'f?p=&APP_ID.:401:&SESSION.::&DEBUG.:::'
,p_page_id=>401
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1376704504536435007)
,p_parent_id=>wwv_flow_imp.id(1376701480568389332)
,p_short_name=>'Colors'
,p_link=>'f?p=&APP_ID.:402:&SESSION.'
,p_page_id=>402
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1376712101896461315)
,p_parent_id=>wwv_flow_imp.id(1376701480568389332)
,p_short_name=>'Navigation'
,p_link=>'f?p=&APP_ID.:407:&SESSION.'
,p_page_id=>407
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1376728563234782522)
,p_parent_id=>wwv_flow_imp.id(1376701480568389332)
,p_short_name=>'Layout'
,p_link=>'f?p=&APP_ID.:700:&SESSION.::&DEBUG.:::'
,p_page_id=>700
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1376736469457982295)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Breadcrumb'
,p_link=>'f?p=&APP_ID.:3810:&SESSION.'
,p_page_id=>3810
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1377642306741190329)
,p_parent_id=>wwv_flow_imp.id(1376728563234782522)
,p_short_name=>'Grid Layout'
,p_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:::'
,p_page_id=>300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1378968242328676870)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Tree'
,p_link=>'f?p=&APP_ID.:1901:&SESSION.'
,p_page_id=>1901
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1379012433992996316)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Charts'
,p_link=>'f?p=&APP_ID.:1902:&SESSION.'
,p_page_id=>1902
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1379017720355118171)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Help Text'
,p_link=>'f?p=&APP_ID.:1903:&SESSION.'
,p_page_id=>1903
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1379023194532134939)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Static Content'
,p_link=>'f?p=&APP_ID.:1905:&SESSION.::&DEBUG.:::'
,p_page_id=>1905
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1379065289595167094)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Tabs'
,p_link=>'f?p=&APP_ID.:1907:&SESSION.::&DEBUG.:::'
,p_page_id=>1907
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1379068760496596958)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'PL/SQL Dynamic Content'
,p_link=>'f?p=&APP_ID.:1908:&SESSION.'
,p_page_id=>1908
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1379071492019616561)
,p_short_name=>'Page Dialog'
,p_link=>'f?p=&APP_ID.:1910:&SESSION.::&DEBUG.:::'
,p_page_id=>1910
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1379073708391633198)
,p_short_name=>'Inline Dialog'
,p_link=>'f?p=&APP_ID.:1911:&SESSION.::&DEBUG.:::'
,p_page_id=>1911
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1379275870455376010)
,p_parent_id=>wwv_flow_imp.id(1211342505228721960)
,p_short_name=>'Change Log'
,p_link=>'f?p=&APP_ID.:6305:&SESSION.'
,p_page_id=>6305
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2256336990794830199)
,p_parent_id=>wwv_flow_imp.id(1376728563234782522)
,p_short_name=>'Page Templates'
,p_link=>'f?p=&APP_ID.:1100:&SESSION.::&DEBUG.:::'
,p_page_id=>1100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2271878265391374866)
,p_parent_id=>wwv_flow_imp.id(2256336990794830199)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1101:&SESSION.'
,p_page_id=>1101
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2383147155937946145)
,p_parent_id=>wwv_flow_imp.id(2256336990794830199)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1102:&SESSION.'
,p_page_id=>1102
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2383160857003020015)
,p_parent_id=>wwv_flow_imp.id(2256336990794830199)
,p_short_name=>'Left Column Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1103:&SESSION.'
,p_page_id=>1103
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2383169069135121544)
,p_parent_id=>wwv_flow_imp.id(2256336990794830199)
,p_short_name=>'Left Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1104:&SESSION.'
,p_page_id=>1104
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2388761828637555319)
,p_parent_id=>wwv_flow_imp.id(2256336990794830199)
,p_short_name=>'Right Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1105:&SESSION.'
,p_page_id=>1105
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2388765867311566928)
,p_parent_id=>wwv_flow_imp.id(2256336990794830199)
,p_short_name=>'Right Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1106:&SESSION.'
,p_page_id=>1106
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2388770309327605716)
,p_parent_id=>wwv_flow_imp.id(2256336990794830199)
,p_short_name=>'Marquee Detail Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1107:&SESSION.::&DEBUG.:::'
,p_page_id=>1107
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2389141112693791102)
,p_parent_id=>wwv_flow_imp.id(2256336990794830199)
,p_short_name=>'Marquee Detail Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1108:&SESSION.::&DEBUG.:::'
,p_page_id=>1108
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2395622192967393824)
,p_parent_id=>wwv_flow_imp.id(2256336990794830199)
,p_short_name=>'Side Columns Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1109:&SESSION.'
,p_page_id=>1109
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2395635481295415415)
,p_parent_id=>wwv_flow_imp.id(2256336990794830199)
,p_short_name=>'Side Columns Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1110:&SESSION.'
,p_page_id=>1110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2396380269784990267)
,p_parent_id=>wwv_flow_imp.id(2256336990794830199)
,p_short_name=>'Standard Dialog Page'
,p_link=>'f?p=&APP_ID.:1111:&SESSION.'
,p_page_id=>1111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2397139978521515074)
,p_parent_id=>wwv_flow_imp.id(2256336990794830199)
,p_short_name=>'Minimal Page Template'
,p_link=>'f?p=&APP_ID.:1113:&SESSION.'
,p_page_id=>1113
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2408932059350788915)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Buttons'
,p_link=>'f?p=&APP_ID.:1500:&SESSION.::&DEBUG.:::'
,p_page_id=>1500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2553857577509617240)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Menu Popup'
,p_link=>'f?p=&APP_ID.:1306:&SESSION.'
,p_page_id=>1306
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2587678700628681143)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Card Templates'
,p_link=>'f?p=&APP_ID.:3100:&SESSION.::&DEBUG.:::'
,p_page_id=>3100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2674357172778751266)
,p_parent_id=>wwv_flow_imp.id(1211342505228721960)
,p_short_name=>'JavaScript APIs'
,p_link=>'f?p=&APP_ID.:6201:&SESSION.'
,p_page_id=>6201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2680366631821358849)
,p_parent_id=>wwv_flow_imp.id(1056169212872018180)
,p_short_name=>'Button Container'
,p_link=>'f?p=&APP_ID.:1250:&SESSION.::&DEBUG.:::'
,p_page_id=>1250
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1056169212872018180)
,p_option_sequence=>30
,p_short_name=>'Components'
,p_link=>'f?p=&APP_ID.:3000:&SESSION.::&DEBUG.:::'
,p_page_id=>3000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1211342505228721960)
,p_parent_id=>0
,p_option_sequence=>50
,p_short_name=>'Reference'
,p_link=>'f?p=&APP_ID.:6000:&SESSION.::&DEBUG.:::'
,p_page_id=>6000
);
wwv_flow_imp.component_end;
end;
/
