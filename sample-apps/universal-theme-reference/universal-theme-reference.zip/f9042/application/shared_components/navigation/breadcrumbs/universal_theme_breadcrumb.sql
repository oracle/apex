prompt --application/shared_components/navigation/breadcrumbs/universal_theme_breadcrumb
begin
--   Manifest
--     MENU: Universal Theme Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>8200683834871648
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(3734951091360893438)
,p_name=>'Universal Theme Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(9224944956893688)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Form Item Types'
,p_link=>'f?p=&APP_ID.:1601:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1601
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1562095454453774614)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Map'
,p_link=>'f?p=&APP_ID.:1906:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1906
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1761786404459626246)
,p_parent_id=>wwv_flow_imp.id(2887817092964317917)
,p_short_name=>'Theme Styles'
,p_link=>'f?p=&APP_ID.:405:&SESSION.::&DEBUG.:::'
,p_page_id=>405
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1811631133941392291)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Region Display Selector'
,p_link=>'f?p=&APP_ID.:1923:&SESSION.::&DEBUG.:::'
,p_page_id=>1923
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1814984821183760771)
,p_parent_id=>wwv_flow_imp.id(2722458117624650545)
,p_short_name=>'CSS Variables'
,p_link=>'f?p=&APP_ID.:6307:&SESSION.::&DEBUG.:::'
,p_page_id=>6307
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1841944946336768309)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Classic Report'
,p_link=>'f?p=&APP_ID.:1401:&SESSION.::&DEBUG.:::'
,p_page_id=>1401
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1841945409851770840)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Interactive Report'
,p_link=>'f?p=&APP_ID.:1402:&SESSION.::&DEBUG.:::'
,p_page_id=>1402
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1841945553663772897)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Interactive Grid'
,p_link=>'f?p=&APP_ID.:1410:&SESSION.::&DEBUG.:::'
,p_page_id=>1410
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1854252681657731378)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Avatar'
,p_link=>'f?p=&APP_ID.:3001:&SESSION.::&DEBUG.:::'
,p_page_id=>3001
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1854259131046872808)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Badge'
,p_link=>'f?p=&APP_ID.:3002:&SESSION.::&DEBUG.:::'
,p_page_id=>3002
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1854260609536877986)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Comments Component'
,p_link=>'f?p=&APP_ID.:3003:&SESSION.::&DEBUG.:::'
,p_page_id=>3003
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1854265116041882843)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Content Row Component'
,p_link=>'f?p=&APP_ID.:3004:&SESSION.::&DEBUG.:::'
,p_page_id=>3004
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1854271968738889882)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Media List Component'
,p_link=>'f?p=&APP_ID.:3005:&SESSION.::&DEBUG.:::'
,p_page_id=>3005
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1854275597310894579)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Timeline Component'
,p_link=>'f?p=&APP_ID.:3006:&SESSION.::&DEBUG.:::'
,p_page_id=>3006
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1856795083934871545)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Content Block'
,p_link=>'f?p=&APP_ID.:1209:&SESSION.::&DEBUG.:::'
,p_page_id=>1209
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1860156191348342247)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'List View'
,p_link=>'f?p=&APP_ID.:1700:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1700
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1907988268519420644)
,p_parent_id=>wwv_flow_imp.id(2722458117624650545)
,p_short_name=>'Template Directives'
,p_link=>'f?p=&APP_ID.:6400:&SESSION.::&DEBUG.:::'
,p_page_id=>6400
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1915084842275619864)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Smart Filters'
,p_link=>'f?p=&APP_ID.:1412:&SESSION.::&DEBUG.:::'
,p_page_id=>1412
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1915092648537630395)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Search Region'
,p_link=>'f?p=&APP_ID.:1413:&SESSION.::&DEBUG.:::'
,p_page_id=>1413
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1917252585110274451)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Faceted Search'
,p_link=>'f?p=&APP_ID.:1411:&SESSION.::&DEBUG.:::'
,p_page_id=>1411
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2016690367251168934)
,p_parent_id=>wwv_flow_imp.id(2722458117624650545)
,p_short_name=>'Layout Modifiers'
,p_link=>'f?p=&APP_ID.:6303:&SESSION.'
,p_page_id=>6303
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2016702395147189248)
,p_parent_id=>wwv_flow_imp.id(2722458117624650545)
,p_short_name=>'Content Modifiers'
,p_link=>'f?p=&APP_ID.:6304:&SESSION.'
,p_page_id=>6304
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2042942190181972736)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Region Image'
,p_link=>'f?p=&APP_ID.:1210:&SESSION.::&DEBUG.:::'
,p_page_id=>1210
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2219185883828881073)
,p_short_name=>'Inline Popup'
,p_link=>'f?p=&APP_ID.:1915:&SESSION.'
,p_page_id=>1915
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2220978796189488949)
,p_short_name=>'Inline Drawer'
,p_link=>'f?p=&APP_ID.:1916:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1916
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2223836852469715866)
,p_short_name=>'Page Drawer'
,p_link=>'f?p=&APP_ID.:1917:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1917
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2325492938152646474)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Reflow Report'
,p_link=>'f?p=&APP_ID.:1710:&SESSION.::&DEBUG.:::'
,p_page_id=>1710
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2325493495509652948)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Column Toggle Report'
,p_link=>'f?p=&APP_ID.:1720:&SESSION.::&DEBUG.:::'
,p_page_id=>1720
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2359300347661067377)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Content Row Report'
,p_link=>'f?p=&APP_ID.:1407:&SESSION.::&DEBUG.:::'
,p_page_id=>1407
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2414033348774169443)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Standard Region'
,p_link=>'f?p=&APP_ID.:1201:&SESSION.::&DEBUG.:::'
,p_page_id=>1201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2414057491098188605)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Alert'
,p_link=>'f?p=&APP_ID.:1202:&SESSION.::&DEBUG.:::'
,p_page_id=>1202
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2414079651256326646)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Hero'
,p_link=>'f?p=&APP_ID.:1203:&SESSION.::&DEBUG.:::'
,p_page_id=>1203
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2414125434477009732)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Button Group'
,p_link=>'f?p=&APP_ID.:1204:&SESSION.::&DEBUG.:::'
,p_page_id=>1204
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2414208409349479503)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Carousel'
,p_link=>'f?p=&APP_ID.:1205:&SESSION.::&DEBUG.:::'
,p_page_id=>1205
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2414248922727651256)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Collapsible'
,p_link=>'f?p=&APP_ID.:1206:&SESSION.::&DEBUG.:::'
,p_page_id=>1206
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2414276639451730020)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Title Bar Region'
,p_link=>'f?p=&APP_ID.:1207:&SESSION.::&DEBUG.:::'
,p_page_id=>1207
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2414332422272080736)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Wizards'
,p_link=>'f?p=&APP_ID.:1208:&SESSION.::&DEBUG.:::'
,p_page_id=>1208
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2414793647838217953)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Media List Report'
,p_link=>'f?p=&APP_ID.:1301:&SESSION.::&DEBUG.:::'
,p_page_id=>1301
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2424746537767798618)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Links List'
,p_link=>'f?p=&APP_ID.:1303:&SESSION.::&DEBUG.:::'
,p_page_id=>1303
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2424769461237855055)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Badge List'
,p_link=>'f?p=&APP_ID.:1304:&SESSION.::&DEBUG.:::'
,p_page_id=>1304
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2424789736058024282)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Menu Bar'
,p_link=>'f?p=&APP_ID.:1305:&SESSION.::&DEBUG.:::'
,p_page_id=>1305
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2425146379546894249)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>' Value Attribute Pairs'
,p_link=>'f?p=&APP_ID.:1403:&SESSION.::&DEBUG.:::'
,p_page_id=>1403
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2425235032620063425)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Comments Report'
,p_link=>'f?p=&APP_ID.:1405:&SESSION.::&DEBUG.:::'
,p_page_id=>1405
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2425320488866142976)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Timeline Report'
,p_link=>'f?p=&APP_ID.:1406:&SESSION.::&DEBUG.:::'
,p_page_id=>1406
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2425387457602221939)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Form Labels'
,p_link=>'f?p=&APP_ID.:1600:&SESSION.::&DEBUG.:::'
,p_page_id=>1600
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2439921318678489900)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Calendar'
,p_link=>'f?p=&APP_ID.:1800:&SESSION.::&DEBUG.:::'
,p_page_id=>1800
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2440048709736146970)
,p_parent_id=>wwv_flow_imp.id(2722458117624650545)
,p_short_name=>'Migration Guides'
,p_link=>'f?p=&APP_ID.:2000:&SESSION.::&DEBUG.:::'
,p_page_id=>2000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2682663654684843091)
,p_parent_id=>wwv_flow_imp.id(2887817092964317917)
,p_short_name=>'Navigation'
,p_link=>'f?p=&APP_ID.:421:&SESSION.::&DEBUG.:::'
,p_page_id=>421
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2722457482856635968)
,p_parent_id=>wwv_flow_imp.id(2722458117624650545)
,p_short_name=>'JavaScript Events'
,p_link=>'f?p=&APP_ID.:6200:&SESSION.::&DEBUG.:::'
,p_page_id=>6200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2722656765378517202)
,p_parent_id=>wwv_flow_imp.id(2722458117624650545)
,p_short_name=>'Button Builder'
,p_link=>'f?p=&APP_ID.:6100:&SESSION.'
,p_page_id=>6100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2741971496631037164)
,p_parent_id=>wwv_flow_imp.id(3767452603190758784)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1115:&SESSION.'
,p_page_id=>1115
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2756893831737117436)
,p_parent_id=>wwv_flow_imp.id(2887817092964317917)
,p_short_name=>'Headers and Footers'
,p_link=>'f?p=&APP_ID.:422:&SESSION.::&DEBUG.:::'
,p_page_id=>422
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2761569506522656236)
,p_parent_id=>wwv_flow_imp.id(2722458117624650545)
,p_short_name=>'Color, Status, and Style Modifiers'
,p_link=>'f?p=&APP_ID.:6302:&SESSION.::&DEBUG.:::'
,p_page_id=>6302
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2765695255839520488)
,p_short_name=>'Page Footer'
,p_link=>'f?p=&APP_ID.:1117:&SESSION.'
,p_page_id=>1117
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2765772902654006479)
,p_parent_id=>wwv_flow_imp.id(2887817092964317917)
,p_short_name=>'Data Entry'
,p_link=>'f?p=&APP_ID.:423:&SESSION.::&DEBUG.:::'
,p_page_id=>423
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2765848663213596914)
,p_parent_id=>wwv_flow_imp.id(2887817092964317917)
,p_short_name=>'Touch Gestures'
,p_link=>'f?p=&APP_ID.:424:&SESSION.::&DEBUG.:::'
,p_page_id=>424
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2770105228938907628)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Card Regions'
,p_link=>'f?p=&APP_ID.:3110:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>3110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2784223961032192381)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Contextual Info'
,p_link=>'f?p=&APP_ID.:1307:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1307
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2799485281722374465)
,p_parent_id=>wwv_flow_imp.id(2887817092964317917)
,p_short_name=>'jQuery Mobile Components'
,p_link=>'f?p=&APP_ID.:425:&SESSION.::&DEBUG.:::'
,p_page_id=>425
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2849843682825070096)
,p_parent_id=>wwv_flow_imp.id(2887827714292389900)
,p_short_name=>'Menu Bar'
,p_link=>'f?p=&APP_ID.:1120:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1120
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2850311304911106282)
,p_parent_id=>wwv_flow_imp.id(2887827714292389900)
,p_short_name=>'Tabs'
,p_link=>'f?p=&APP_ID.:1121:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1121
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2851017536709124794)
,p_parent_id=>wwv_flow_imp.id(2887827714292389900)
,p_short_name=>'Mega Menu'
,p_link=>'f?p=&APP_ID.:1122:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1122
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2851019802526133762)
,p_parent_id=>wwv_flow_imp.id(2887827714292389900)
,p_short_name=>'Side Tree Navigation'
,p_link=>'f?p=&APP_ID.:1123:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1123
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2851024595549152778)
,p_parent_id=>wwv_flow_imp.id(2887827714292389900)
,p_short_name=>'Mega Menu Variation 2'
,p_link=>'f?p=&APP_ID.:1124:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1124
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2887817092964317917)
,p_short_name=>'Design'
,p_link=>'f?p=&APP_ID.:401:&SESSION.::&DEBUG.:::'
,p_page_id=>401
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2887820116932363592)
,p_parent_id=>wwv_flow_imp.id(2887817092964317917)
,p_short_name=>'Colors'
,p_link=>'f?p=&APP_ID.:402:&SESSION.'
,p_page_id=>402
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2887827714292389900)
,p_parent_id=>wwv_flow_imp.id(2887817092964317917)
,p_short_name=>'Navigation'
,p_link=>'f?p=&APP_ID.:407:&SESSION.'
,p_page_id=>407
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2887844175630711107)
,p_parent_id=>wwv_flow_imp.id(2887817092964317917)
,p_short_name=>'Layout'
,p_link=>'f?p=&APP_ID.:700:&SESSION.::&DEBUG.:::'
,p_page_id=>700
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2887852081853910880)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Breadcrumb'
,p_link=>'f?p=&APP_ID.:3810:&SESSION.'
,p_page_id=>3810
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2888757919137118914)
,p_parent_id=>wwv_flow_imp.id(2887844175630711107)
,p_short_name=>'Grid Layout'
,p_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:::'
,p_page_id=>300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2890083854724605455)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Tree'
,p_link=>'f?p=&APP_ID.:1901:&SESSION.'
,p_page_id=>1901
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2890128046388924901)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Charts'
,p_link=>'f?p=&APP_ID.:1902:&SESSION.'
,p_page_id=>1902
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2890133332751046756)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Help Text'
,p_link=>'f?p=&APP_ID.:1903:&SESSION.'
,p_page_id=>1903
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2890138806928063524)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Static Content'
,p_link=>'f?p=&APP_ID.:1905:&SESSION.::&DEBUG.:::'
,p_page_id=>1905
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2890180901991095679)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Tabs'
,p_link=>'f?p=&APP_ID.:1907:&SESSION.::&DEBUG.:::'
,p_page_id=>1907
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2890184372892525543)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Dynamic Content Region'
,p_link=>'f?p=&APP_ID.:1908:&SESSION.::&DEBUG.:::'
,p_page_id=>1908
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2890187104415545146)
,p_short_name=>'Page Dialog'
,p_link=>'f?p=&APP_ID.:1910:&SESSION.::&DEBUG.:::'
,p_page_id=>1910
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2890189320787561783)
,p_short_name=>'Inline Dialog'
,p_link=>'f?p=&APP_ID.:1911:&SESSION.::&DEBUG.:::'
,p_page_id=>1911
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2890391482851304595)
,p_parent_id=>wwv_flow_imp.id(2722458117624650545)
,p_short_name=>'Change Log'
,p_link=>'f?p=&APP_ID.:6305:&SESSION.'
,p_page_id=>6305
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3767452603190758784)
,p_parent_id=>wwv_flow_imp.id(2887844175630711107)
,p_short_name=>'Page Templates'
,p_link=>'f?p=&APP_ID.:1100:&SESSION.::&DEBUG.:::'
,p_page_id=>1100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3782993877787303451)
,p_parent_id=>wwv_flow_imp.id(3767452603190758784)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1101:&SESSION.'
,p_page_id=>1101
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3894262768333874730)
,p_parent_id=>wwv_flow_imp.id(3767452603190758784)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1102:&SESSION.'
,p_page_id=>1102
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3894276469398948600)
,p_parent_id=>wwv_flow_imp.id(3767452603190758784)
,p_short_name=>'Left Column Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1103:&SESSION.'
,p_page_id=>1103
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3894284681531050129)
,p_parent_id=>wwv_flow_imp.id(3767452603190758784)
,p_short_name=>'Left Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1104:&SESSION.'
,p_page_id=>1104
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3899877441033483904)
,p_parent_id=>wwv_flow_imp.id(3767452603190758784)
,p_short_name=>'Right Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1105:&SESSION.'
,p_page_id=>1105
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3899881479707495513)
,p_parent_id=>wwv_flow_imp.id(3767452603190758784)
,p_short_name=>'Right Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1106:&SESSION.'
,p_page_id=>1106
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3899885921723534301)
,p_parent_id=>wwv_flow_imp.id(3767452603190758784)
,p_short_name=>'Marquee Detail Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1107:&SESSION.::&DEBUG.:::'
,p_page_id=>1107
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3900256725089719687)
,p_parent_id=>wwv_flow_imp.id(3767452603190758784)
,p_short_name=>'Marquee Detail Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1108:&SESSION.::&DEBUG.:::'
,p_page_id=>1108
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3906737805363322409)
,p_parent_id=>wwv_flow_imp.id(3767452603190758784)
,p_short_name=>'Side Columns Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1109:&SESSION.'
,p_page_id=>1109
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3906751093691344000)
,p_parent_id=>wwv_flow_imp.id(3767452603190758784)
,p_short_name=>'Side Columns Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1110:&SESSION.'
,p_page_id=>1110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3907495882180918852)
,p_parent_id=>wwv_flow_imp.id(3767452603190758784)
,p_short_name=>'Standard Dialog Page'
,p_link=>'f?p=&APP_ID.:1111:&SESSION.'
,p_page_id=>1111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3908255590917443659)
,p_parent_id=>wwv_flow_imp.id(3767452603190758784)
,p_short_name=>'Minimal Page Template'
,p_link=>'f?p=&APP_ID.:1113:&SESSION.'
,p_page_id=>1113
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3920047671746717500)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Buttons'
,p_link=>'f?p=&APP_ID.:1500:&SESSION.::&DEBUG.:::'
,p_page_id=>1500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4064973189905545825)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Menu Popup'
,p_link=>'f?p=&APP_ID.:1306:&SESSION.'
,p_page_id=>1306
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4098794313024609728)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Card Templates'
,p_link=>'f?p=&APP_ID.:3100:&SESSION.::&DEBUG.:::'
,p_page_id=>3100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4185472785174679851)
,p_parent_id=>wwv_flow_imp.id(2722458117624650545)
,p_short_name=>'JavaScript APIs'
,p_link=>'f?p=&APP_ID.:6201:&SESSION.'
,p_page_id=>6201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4191482244217287434)
,p_parent_id=>wwv_flow_imp.id(2567284825267946765)
,p_short_name=>'Button Container'
,p_link=>'f?p=&APP_ID.:1250:&SESSION.::&DEBUG.:::'
,p_page_id=>1250
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2567284825267946765)
,p_option_sequence=>30
,p_short_name=>'Components'
,p_link=>'f?p=&APP_ID.:3000:&SESSION.::&DEBUG.:::'
,p_page_id=>3000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2722458117624650545)
,p_option_sequence=>50
,p_short_name=>'Reference'
,p_link=>'f?p=&APP_ID.:6000:&SESSION.::&DEBUG.:::'
,p_page_id=>6000
);
wwv_flow_imp.component_end;
end;
/
