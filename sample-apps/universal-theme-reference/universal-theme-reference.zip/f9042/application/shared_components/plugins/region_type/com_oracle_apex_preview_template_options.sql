prompt --application/shared_components/plugins/region_type/com_oracle_apex_preview_template_options
begin
--   Manifest
--     PLUGIN: COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(1274778399807540897)
,p_plugin_type=>'REGION TYPE'
,p_name=>'COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'
,p_display_name=>'Preview Template Options'
,p_supported_ui_types=>'DESKTOP:JQM_SMARTPHONE'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('REGION TYPE','COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'),'')
,p_javascript_file_urls=>'#PLUGIN_FILES#js/script#MIN#.js'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'c_workspace constant varchar2(100) := apex_util.find_workspace(:workspace_id);',
'',
'subtype t_region_type is varchar2(40);',
'c_region_type_list_region       constant t_region_type := ''NATIVE_LIST'';',
'c_region_type_breadcrumb_region constant t_region_type := ''NATIVE_BREADCRUMB'';',
'c_region_type_sql_report        constant t_region_type := ''NATIVE_SQL_REPORT'';',
'c_region_type_tabform           constant t_region_type := ''NATIVE_TABFORM'';',
'',
'procedure emit_template_templ_options ( ',
'    p_template_id    number,',
'    p_template_type  varchar2,',
'    p_current_values varchar2 )',
'as',
'    l_default varchar2(4000);',
'    l_preset varchar2(4000);',
'begin',
'    apex_json.open_object;',
'',
'    apex_json.open_array( ''groups'' );',
'    for i in ( select distinct',
'                        g.template_opt_group_id as group_id,',
'                        g.display_name          as group_display_name,',
'                        g.display_sequence      as group_display_sequence,',
'                        g.is_advanced           as group_is_advanced,',
'                        g.help_text             as group_help_text,',
'                        g.null_text             as group_null_text',
'                from apex_appl_template_options o,',
'                        apex_appl_template_opt_groups g',
'                where o.application_id    = :app_id',
'                    and o.theme_number      = wwv_flow.g_flow_theme_id',
'                    and o.workspace         = c_workspace',
'                    and (  ',
'                        ( o.virtual_template_id is null and instr( o.virtual_template_type, p_template_type ) > 0 )',
'                        or',
'                        ( o.virtual_template_id = p_template_id and o.virtual_template_type = p_template_type )',
'                        )',
'                    and g.template_opt_group_id = o.group_id',
'                order by g.display_sequence, g.template_opt_group_id )',
'    loop',
'',
'        apex_json.open_object;',
'        apex_json.write(''groupId'',    i.group_id );',
'        apex_json.write(''title'',      i.group_display_name );',
'        apex_json.write(''seq'',        i.group_display_sequence );',
'        apex_json.write(''isAdvanced'', i.group_is_advanced = ''Y'' );',
'        apex_json.write(''helpText'',   i.group_help_text );',
'        apex_json.write(''nullText'',   i.group_null_text );',
'',
'        apex_json.open_array( ''options'' );',
'        for j in ( select o.display_name,',
'                          o.display_sequence,',
'                          o.is_advanced,',
'                          o.help_text,',
'                          o.css_classes',
'                     from apex_appl_template_options o',
'                    where o.application_id    = :app_id',
'                      and o.theme_number      = wwv_flow.g_flow_theme_id',
'                      and o.workspace         = c_workspace',
'                      and (  ',
'                        ( o.virtual_template_id is null and instr( o.virtual_template_type, p_template_type ) > 0 )',
'                        or',
'                        ( o.virtual_template_id = p_template_id and o.virtual_template_type = p_template_type )',
'                        )',
'                      and o.group_id = i.group_id',
'                order by o.display_sequence, o.template_option_id )',
'        loop',
'',
'            apex_json.open_object;',
'            apex_json.write(''d'',          j.display_name );',
'            apex_json.write(''r'',          j.css_classes );',
'            apex_json.write(''seq'',        j.display_sequence );',
'            apex_json.write(''isAdvanced'', j.is_advanced = ''Y'' );',
'            apex_json.write(''helpText'',   j.help_text );',
'            apex_json.write(''groupId'',    i.group_id );',
'            apex_json.close_object;',
'',
'        end loop;',
'        apex_json.close_array;',
'',
'        apex_json.close_object;',
'',
'    end loop;',
'    apex_json.close_array; -- groups',
'',
'    apex_json.open_array( ''options'' );',
'    for i in ( select o.display_name,',
'                             o.display_sequence,',
'                             o.is_advanced,',
'                             o.help_text,',
'                             o.css_classes',
'                        from apex_appl_template_options o',
'                       where o.application_id    = :app_id',
'                         and o.theme_number      = wwv_flow.g_flow_theme_id',
'                         and o.workspace         = c_workspace',
'                         and (  ',
'                            ( o.virtual_template_id is null and instr( o.virtual_template_type, p_template_type ) > 0 )',
'                            or',
'                            ( o.virtual_template_id = p_template_id and o.virtual_template_type = p_template_type )',
'                            )',
'                         and o.group_id is null',
'                       order by o.display_sequence, o.template_option_id )',
'    loop',
'',
'        apex_json.open_object;',
'        apex_json.write(''d'',          i.display_name );',
'        apex_json.write(''r'',          i.css_classes );',
'        apex_json.write(''seq'',        i.display_sequence );',
'        apex_json.write(''isAdvanced'', i.is_advanced = ''Y'' );',
'        apex_json.write(''helpText'',   i.help_text );',
'        apex_json.close_object;',
'',
'    end loop;',
'    apex_json.close_array; -- options',
'',
'    execute immediate ''select default_template_options, preset_template_options from '' ||',
'                        case p_template_type',
'                        when ''REGION''     then ''apex_application_temp_region''',
'                        when ''BUTTON''     then ''apex_application_temp_button''',
'                        when ''FIELD''      then ''apex_application_temp_label''',
'                        when ''REPORT''     then ''apex_application_temp_report''',
'                        when ''LIST''       then ''apex_application_temp_list''',
'                        when ''BREADCRUMB'' then ''apex_application_temp_bc''',
'                        end ||',
'                    '' where '' ||',
'                        case p_template_type',
'                        when ''REGION''     then ''region_template_id''',
'                        when ''BUTTON''     then ''button_template_id''',
'                        when ''FIELD''      then ''label_template_id''',
'                        when ''REPORT''     then ''template_id''',
'                        when ''LIST''       then ''list_template_id''',
'                        when ''BREADCRUMB'' then ''breadcrumb_template_id''',
'                        end ||',
'                    '' = :p_template_id and workspace = :p_security_group_id''',
'                 into l_default,',
'                      l_preset',
'                using p_template_id,',
'                      c_workspace;',
'',
'    apex_json.write(',
'        p_name       => ''currentValues'',',
'        p_value      => p_current_values,',
'        p_write_null => true );',
'',
'    apex_json.write(',
'        p_name       => ''defaultValues'',',
'        p_values     => apex_string.split(',
'                            p_str => l_default,',
'                            p_sep => '':'' ),',
'        p_write_null => true );',
'',
'    apex_json.write(',
'        p_name       => ''presetValues'',',
'        p_values     => apex_string.split(',
'                            p_str => l_preset,',
'                            p_sep => '':'' ),',
'        p_write_null => true );',
'',
'    apex_json.close_object;',
'',
'end;',
'',
'procedure emit_component_templ_options( ',
'    p_component_type      varchar2,',
'    p_component_static_id varchar2 )',
'as',
'    l_component_id               number;',
'    l_primary_template_id        number;',
'    l_primary_template_type      varchar2(10);',
'    l_primary_template_options   apex_application_page_regions.region_template_options%type;',
'    l_secondary_template_id      number;',
'    l_secondary_template_type    varchar2(10);',
'    l_secondary_template_options apex_application_page_regions.component_template_options%type;',
'begin',
'    ',
'    if p_component_type = ''REGION'' then',
'',
'        l_primary_template_type := ''REGION'';',
'        select region_id,',
'               template_id,',
'               region_template_options,',
'               case',
'                 when source_type_plugin_name = c_region_type_list_region                          then list_template_override_id',
'                 when source_type_plugin_name = c_region_type_breadcrumb_region                    then breadcrumb_template_id',
'                 when source_type_plugin_name in (c_region_type_sql_report, c_region_type_tabform) then report_template_id',
'               end,',
'               case',
'                 when source_type_plugin_name = c_region_type_list_region                          then ''LIST''',
'                 when source_type_plugin_name = c_region_type_breadcrumb_region                    then ''BREADCRUMB''',
'                 when source_type_plugin_name in (c_region_type_sql_report, c_region_type_tabform) then ''REPORT''',
'               end,',
'               component_template_options',
'          into l_component_id,',
'               l_primary_template_id,',
'               l_primary_template_options,',
'               l_secondary_template_id,',
'               l_secondary_template_type,',
'               l_secondary_template_options',
'          from apex_application_page_regions',
'         where static_id         = p_component_static_id',
'           and application_id    = :app_id',
'           and page_id           = :app_page_id',
'           and workspace         = c_workspace;',
'        ',
'    elsif p_component_type = ''ITEM'' then',
'',
'        l_primary_template_type := ''FIELD'';',
'        select item_id,',
'               item_label_template_id,',
'               item_template_options',
'          into l_component_id,',
'               l_primary_template_id,',
'               l_primary_template_options',
'          from apex_application_page_items',
'         where item_name        = p_component_static_id',
'           and application_id   = :app_id',
'           and page_id          = :app_page_id',
'           and workspace        = c_workspace;',
'',
'    elsif p_component_type = ''BUTTON'' then',
'',
'        l_primary_template_type := ''BUTTON'';',
'        select button_id,',
'               button_template_id,',
'               button_template_options',
'          into l_component_id,',
'               l_primary_template_id,',
'               l_primary_template_options',
'          from apex_application_page_buttons',
'         where button_static_id = p_component_static_id',
'           and application_id   = :app_id',
'           and page_id          = :app_page_id',
'           and workspace        = c_workspace;',
'               ',
'    end if;',
'    ',
'    -- if there is a secondary template, get that one',
'    if l_secondary_template_id is not null then',
'        emit_template_templ_options (',
'            p_template_id    => l_secondary_template_id,',
'            p_template_type  => l_secondary_template_type,',
'            p_current_values => l_secondary_template_options );',
'    else',
'    -- if not, get the main template',
'        emit_template_templ_options (',
'            p_template_id    => l_primary_template_id,',
'            p_template_type  => l_primary_template_type,',
'            p_current_values => l_primary_template_options );',
'    end if;',
'end;',
'',
'function render (',
'    p_region              apex_plugin.t_region,',
'    p_plugin              apex_plugin.t_plugin,',
'    p_is_printer_friendly boolean )',
'return apex_plugin.t_region_render_result',
'as',
'',
'    c_component_type        constant varchar2(1000) := p_region.attribute_01;',
'    c_component_static_id   constant varchar2(1000) := p_region.attribute_02;',
'',
'    c_region_id             constant varchar2(1000) := p_region.static_id;',
'    c_preview_id            constant varchar2(1000) := c_region_id || ''_preview'';',
'',
'begin',
'',
'    if apex_application.g_debug then',
'        apex_plugin_util.debug_region ( ',
'            p_plugin => p_plugin,',
'            p_region => p_region );',
'    end if;',
'',
'    htp.p(''<div id="'' || apex_escape.html_attribute(c_preview_id) || ''" class="ut-TemplateOptions--preview"></div>'');',
'',
'    apex_json.initialize_clob_output;',
'',
'    emit_component_templ_options( ',
'        p_component_type      => c_component_type,',
'        p_component_static_id => c_component_static_id );',
'',
'    apex_javascript.add_onload_code ( ''apex.theme42demo.initPreviewTemplateOptions('' ||',
'        ''{'' ||',
'        apex_javascript.add_attribute(''previewId'',          sys.htf.escape_sc(c_preview_id)) ||',
'        apex_javascript.add_attribute(''componentType'',      sys.htf.escape_sc(c_component_type)) ||',
'        apex_javascript.add_attribute(''componentStaticId'',  sys.htf.escape_sc(c_component_static_id)) ||',
'        apex_javascript.add_attribute(''templateOptions'',    apex_json.get_clob_output(p_free => true)) ||',
'        ''});'' );',
'',
'    return null;',
'end;'))
,p_api_version=>1
,p_render_function=>'render'
,p_substitute_attributes=>true
,p_subscribe_plugin_settings=>false
,p_version_identifier=>'1.0'
,p_files_version=>358
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1274778626354540900)
,p_plugin_id=>wwv_flow_imp.id(1274778399807540897)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_prompt=>'Component Type'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'REGION'
,p_supported_ui_types=>'DESKTOP:JQM_SMARTPHONE'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1274779009738540902)
,p_plugin_attribute_id=>wwv_flow_imp.id(1274778626354540900)
,p_display_sequence=>10
,p_display_value=>'Region'
,p_return_value=>'REGION'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1274779521922540906)
,p_plugin_attribute_id=>wwv_flow_imp.id(1274778626354540900)
,p_display_sequence=>20
,p_display_value=>'Item'
,p_return_value=>'ITEM'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1274780015326540906)
,p_plugin_attribute_id=>wwv_flow_imp.id(1274778626354540900)
,p_display_sequence=>30
,p_display_value=>'Button'
,p_return_value=>'BUTTON'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1274780593036540907)
,p_plugin_id=>wwv_flow_imp.id(1274778399807540897)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_prompt=>'Static ID'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_is_translatable=>false
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>For regions and buttons, provide their Static ID.</p>',
'<p>For items, provide their regular names.</p>'))
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '77696E646F772E617065782E7468656D65343264656D6F3D617065782E7468656D65343264656D6F7C7C7B7D2C617065782E7468656D65343264656D6F2E696E69745072657669657754656D706C6174654F7074696F6E733D287B707265766965774964';
wwv_flow_imp.g_varchar2_table(2) := '3A652C636F6D706F6E656E74547970653A6E2C636F6D706F6E656E7453746174696349643A6F2C74656D706C6174654F7074696F6E733A697D293D3E7B693D4A534F4E2E70617273652869293B6C657420743D24286023247B6F7D60293B224954454D22';
wwv_flow_imp.g_varchar2_table(3) := '3D3D3D6E262628743D24286023247B6F7D5F434F4E5441494E45526029292C742E66696E6428222E646D2D54656D706C6174654F7074696F6E2D7072657669657754617267657422292E6C656E6774683E30262628743D24286023247B6F7D202E646D2D';
wwv_flow_imp.g_varchar2_table(4) := '54656D706C6174654F7074696F6E2D707265766965775461726765746029293B636F6E737420613D287B6973416476616E6365643A6E7D293D3E7B6966286E2626303D3D3D692E67726F7570732E66696C7465722828653D3E652E6973416476616E6365';
wwv_flow_imp.g_varchar2_table(5) := '643D3D3D6E29292E6C656E6774682972657475726E3B636F6E737420613D6E3F22416476616E636564223A22436F6D6D6F6E223B24286023247B657D60292E617070656E6428603C64697620726F6C653D22726567696F6E2220617269612D6C6162656C';
wwv_flow_imp.g_varchar2_table(6) := '3D22247B617D2220636C6173733D22742D526567696F6E20742D466F726D2D2D6E6F50616464696E6720742D526567696F6E2D2D6869646553686F7720742D526567696F6E2D2D7363726F6C6C426F647920742D526567696F6E2D2D6E6F50616464696E';
wwv_flow_imp.g_varchar2_table(7) := '6720742D526567696F6E2D2D6E6F554920247B6E3F2269732D636F6C6C6170736564223A2269732D657870616E646564227D222069643D22247B657D5F247B617D223E5C6E2020202020202020202020203C64697620636C6173733D22742D526567696F';
wwv_flow_imp.g_varchar2_table(8) := '6E2D686561646572223E5C6E202020202020202020202020202020203C64697620636C6173733D22742D526567696F6E2D6865616465724974656D7320742D526567696F6E2D6865616465724974656D732D2D636F6E74726F6C73223E5C6E2020202020';
wwv_flow_imp.g_varchar2_table(9) := '2020202020202020202020202020203C7370616E20636C6173733D22742D427574746F6E20742D427574746F6E2D2D69636F6E20742D427574746F6E2D2D6869646553686F77223E3C7370616E20636C6173733D22612D49636F6E205F612D436F6C6C61';
wwv_flow_imp.g_varchar2_table(10) := '707369626C652D69636F6E2220617269612D68696464656E3D2274727565223E3C2F7370616E3E3C2F7370616E3E5C6E202020202020202020202020202020203C2F6469763E5C6E202020202020202020202020202020203C64697620636C6173733D22';
wwv_flow_imp.g_varchar2_table(11) := '742D526567696F6E2D6865616465724974656D7320742D526567696F6E2D6865616465724974656D732D2D7469746C65223E5C6E20202020202020202020202020202020202020203C683220636C6173733D22742D526567696F6E2D7469746C65222064';
wwv_flow_imp.g_varchar2_table(12) := '6174612D617065782D68656164696E673E3C627574746F6E20636C6173733D22742D526567696F6E2D7469746C65427574746F6E2220747970653D22627574746F6E223E247B617D3C2F627574746F6E3E3C2F68323E5C6E202020202020202020202020';
wwv_flow_imp.g_varchar2_table(13) := '202020203C2F6469763E5C6E2020202020202020202020203C2F6469763E5C6E2020202020202020202020203C64697620636C6173733D22742D526567696F6E2D626F647957726170223E5C6E202020202020202020202020202020203C64697620636C';
wwv_flow_imp.g_varchar2_table(14) := '6173733D22742D526567696F6E2D626F647920752D666C6578206D617267696E2D6C6566742D6D64206D617267696E2D72696768742D6D6422207374796C653D22666C65782D777261703A20777261703B223E3C2F6469763E5C6E202020202020202020';
wwv_flow_imp.g_varchar2_table(15) := '2020203C2F6469763E5C6E20202020202020203C2F6469763E60292C28287B636F6C6C61707369626C655461726765743A6E2C6973416476616E6365643A617D293D3E7B617C7C692E6F7074696F6E732E666F72456163682828693D3E7B6C657420613D';
wwv_flow_imp.g_varchar2_table(16) := '605C6E20202020202020202020202020202020202020203C64697620636C6173733D22636F6C2D3132223E5C6E2020202020202020202020202020202020202020202020203C64697620636C6173733D22742D466F726D2D6669656C64436F6E7461696E';
wwv_flow_imp.g_varchar2_table(17) := '657220742D466F726D2D6669656C64436F6E7461696E65722D2D666C6F6174696E674C6162656C20617065782D6974656D2D7772617070657220617065782D6974656D2D777261707065722D2D73696E676C652D636865636B626F78222069643D22247B';
wwv_flow_imp.g_varchar2_table(18) := '657D5F6F7074696F6E5F247B692E727D5F434F4E5441494E4552223E5C6E202020202020202020202020202020202020202020202020202020203C64697620636C6173733D22742D466F726D2D6C6162656C436F6E7461696E6572223E3C2F6469763E5C';
wwv_flow_imp.g_varchar2_table(19) := '6E202020202020202020202020202020202020202020202020202020203C64697620636C6173733D22742D466F726D2D696E707574436F6E7461696E6572223E5C6E20202020202020202020202020202020202020202020202020202020202020203C64';
wwv_flow_imp.g_varchar2_table(20) := '697620636C6173733D22742D466F726D2D6974656D57726170706572223E5C6E2020202020202020202020202020202020202020202020202020202020202020202020203C64697620636C6173733D22617065782D6974656D2D73696E676C652D636865';
wwv_flow_imp.g_varchar2_table(21) := '636B626F78223E5C6E202020202020202020202020202020202020202020202020202020202020202020202020202020203C696E70757420747970653D22636865636B626F78222069643D22247B657D5F6F7074696F6E5F247B692E727D222076616C75';
wwv_flow_imp.g_varchar2_table(22) := '653D22247B692E727D2220247B742E686173436C61737328692E72293F22636865636B6564223A22227D3E5C6E202020202020202020202020202020202020202020202020202020202020202020202020202020203C6C6162656C20666F723D22247B65';
wwv_flow_imp.g_varchar2_table(23) := '7D5F6F7074696F6E5F247B692E727D222069643D22247B657D5F6F7074696F6E5F247B692E727D5F4C4142454C2220636C6173733D22752D636865636B626F78223E247B692E647D3C2F6C6162656C3E5C6E202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(24) := '2020202020202020202020202020202020203C2F6469763E5C6E20202020202020202020202020202020202020202020202020202020202020203C2F6469763E5C6E202020202020202020202020202020202020202020202020202020203C2F6469763E';
wwv_flow_imp.g_varchar2_table(25) := '5C6E2020202020202020202020202020202020202020202020203C2F6469763E5C6E20202020202020202020202020202020202020203C2F6469763E603B24286023247B657D5F247B6E7D202E742D526567696F6E2D626F647960292E617070656E6428';
wwv_flow_imp.g_varchar2_table(26) := '61292C24286023247B657D5F6F7074696F6E5F247B692E727D60292E6368616E6765282866756E6374696F6E28297B646F63756D656E742E717565727953656C6563746F72286023247B657D5F6F7074696F6E5F247B692E727D60292E636865636B6564';
wwv_flow_imp.g_varchar2_table(27) := '3F742E616464436C61737328692E72293A742E72656D6F7665436C61737328692E72292C617065782E6576656E742E7472696767657228646F63756D656E742C2274656D706C6174654F7074696F6E4368616E676564222C7B636F6D706F6E656E745374';
wwv_flow_imp.g_varchar2_table(28) := '6174696349643A6F7D297D29297D29292C692E67726F7570732E66696C7465722828653D3E652E6973416476616E6365643D3D3D6129292E666F72456163682828613D3E7B6C657420643D21612E6F7074696F6E732E6D61702828653D3E652E7229292E';
wwv_flow_imp.g_varchar2_table(29) := '736F6D652828653D3E692E70726573657456616C7565732E696E636C7564657328652929292C6C3D605C6E2020202020202020202020203C64697620636C6173733D22636F6C2D3420636F6C2D6D642D36223E5C6E202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(30) := '203C64697620636C6173733D22742D466F726D2D6669656C64436F6E7461696E657220742D466F726D2D6669656C64436F6E7461696E65722D2D666C6F6174696E674C6162656C20617065782D6974656D2D7772617070657220617065782D6974656D2D';
wwv_flow_imp.g_varchar2_table(31) := '777261707065722D2D726164696F67726F7570223E5C6E20202020202020202020202020202020202020203C64697620636C6173733D22742D466F726D2D6C6162656C436F6E7461696E6572223E5C6E2020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(32) := '202020203C6C6162656C20666F723D22247B657D5F67726F75705F247B612E67726F757049647D222069643D22247B657D5F67726F75705F247B612E67726F757049647D5F4C4142454C2220636C6173733D22742D466F726D2D6C6162656C20752D626F';
wwv_flow_imp.g_varchar2_table(33) := '6C64223E247B612E7469746C657D3C2F6C6162656C3E5C6E20202020202020202020202020202020202020203C2F6469763E5C6E20202020202020202020202020202020202020203C64697620636C6173733D22742D466F726D2D696E707574436F6E74';
wwv_flow_imp.g_varchar2_table(34) := '61696E6572223E5C6E2020202020202020202020202020202020202020202020203C64697620636C6173733D22742D466F726D2D6974656D57726170706572223E5C6E202020202020202020202020202020202020202020202020202020203C64697620';
wwv_flow_imp.g_varchar2_table(35) := '746162696E6465783D222D31222069643D22247B657D5F67726F75705F247B612E67726F757049647D2220617269612D6C6162656C6C656462793D22247B657D5F67726F75705F247B612E67726F757049647D5F4C4142454C2220636C6173733D226170';
wwv_flow_imp.g_varchar2_table(36) := '65782D6974656D2D67726F757020617065782D6974656D2D67726F75702D2D726320617065782D6974656D2D726164696F2220726F6C653D2267726F7570223E5C6E2020202020202020202020202020202020202020202020202020202020202020247B';
wwv_flow_imp.g_varchar2_table(37) := '612E6E756C6C546578742626643F603C64697620636C6173733D22617065782D6974656D2D6F7074696F6E20746F2D707265766965772D6F7074696F6E223E5C6E2020202020202020202020202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(38) := '20202020202020202020202020202020203C696E70757420747970653D22726164696F222069643D22247B657D5F67726F75705F247B612E67726F757049647D5F6E756C6C22206E616D653D22247B657D5F67726F75705F247B612E67726F757049647D';
wwv_flow_imp.g_varchar2_table(39) := '2220646174612D646973706C61793D22247B612E6E756C6C546578747D222076616C75653D222220247B742E697328612E6F7074696F6E732E6D61702828653D3E222E222B652E7229292E6A6F696E28222C2229293F22223A22636865636B6564227D20';
wwv_flow_imp.g_varchar2_table(40) := '3E5C6E202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020203C6C6162656C20636C6173733D22752D726164696F2220666F723D22247B657D5F67726F75705F247B612E6772';
wwv_flow_imp.g_varchar2_table(41) := '6F757049647D5F6E756C6C223E247B612E6E756C6C546578747D3C2F6C6162656C3E5C6E202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020203C2F6469763E603A22227D5C';
wwv_flow_imp.g_varchar2_table(42) := '6E202020202020202020202020202020202020202020202020202020203C2F6469763E5C6E2020202020202020202020202020202020202020202020203C2F6469763E5C6E20202020202020202020202020202020202020203C2F6469763E5C6E202020';
wwv_flow_imp.g_varchar2_table(43) := '202020202020202020202020203C2F6469763E5C6E2020202020202020202020203C2F6469763E603B24286023247B657D5F247B6E7D202E742D526567696F6E2D626F647960292E617070656E64286C292C612E6F7074696F6E732E666F724561636828';
wwv_flow_imp.g_varchar2_table(44) := '286E3D3E7B6C6574206F3D605C6E20202020202020202020202020202020202020203C64697620636C6173733D22617065782D6974656D2D6F7074696F6E20746F2D707265766965772D6F7074696F6E223E5C6E20202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(45) := '202020203C696E70757420747970653D22726164696F222069643D22247B657D5F67726F75705F247B612E67726F757049647D5F247B6E2E727D22206E616D653D22247B657D5F67726F75705F247B612E67726F757049647D2220646174612D64697370';
wwv_flow_imp.g_varchar2_table(46) := '6C61793D22247B6E2E647D222076616C75653D22247B6E2E727D2220247B742E686173436C617373286E2E72293F22636865636B6564223A22227D203E5C6E20202020202020202020202020202020202020203C6C6162656C20636C6173733D22752D72';
wwv_flow_imp.g_varchar2_table(47) := '6164696F2220666F723D22247B657D5F67726F75705F247B612E67726F757049647D5F247B6E2E727D223E247B6E2E647D3C2F6C6162656C3E5C6E20202020202020202020202020202020202020203C2F6469763E603B24286023247B657D5F67726F75';
wwv_flow_imp.g_varchar2_table(48) := '705F247B612E67726F757049647D60292E617070656E64286F297D29292C242860696E7075745B747970653D726164696F5D5B6E616D653D22247B657D5F67726F75705F247B612E67726F757049647D225D60292E6368616E6765282866756E6374696F';
wwv_flow_imp.g_varchar2_table(49) := '6E28297B742E72656D6F7665436C61737328612E6F7074696F6E732E6D61702828653D3E652E7229292E6A6F696E2822202229292C742E616464436C61737328646F63756D656E742E717565727953656C6563746F722860696E7075745B747970653D72';
wwv_flow_imp.g_varchar2_table(50) := '6164696F5D5B6E616D653D22247B657D5F67726F75705F247B612E67726F757049647D225D3A636865636B656460292E76616C7565292C617065782E6576656E742E7472696767657228646F63756D656E742C2274656D706C6174654F7074696F6E4368';
wwv_flow_imp.g_varchar2_table(51) := '616E676564222C7B636F6D706F6E656E7453746174696349643A6F7D297D29297D29297D29287B636F6C6C61707369626C655461726765743A612C6973416476616E6365643A6E7D297D3B61287B6973416476616E6365643A21317D292C61287B697341';
wwv_flow_imp.g_varchar2_table(52) := '6476616E6365643A21307D292C24286023247B657D202E742D526567696F6E2D2D6869646553686F7760292E65616368282866756E6374696F6E28297B76617220653D242874686973293B652E636F6C6C61707369626C65287B636F6E74656E743A2428';
wwv_flow_imp.g_varchar2_table(53) := '74686973292E66696E6428222E742D526567696F6E2D626F647922292E666972737428292C636F6C6C61707365643A652E686173436C617373282269732D636F6C6C617073656422292C72656E64657249636F6E3A21317D292C652E66696E6428222E74';
wwv_flow_imp.g_varchar2_table(54) := '2D427574746F6E2D2D6869646553686F77202E612D49636F6E22292E616464436C6173732822612D436F6C6C61707369626C652D69636F6E22292E636C69636B282866756E6374696F6E28297B242874686973292E636C6F7365737428222E742D526567';
wwv_flow_imp.g_varchar2_table(55) := '696F6E2D68656164657222292E66696E6428222E742D526567696F6E2D7469746C65427574746F6E22292E636C69636B28297D29297D29297D3B';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(332733852265290257)
,p_plugin_id=>wwv_flow_imp.id(1274778399807540897)
,p_file_name=>'js/script.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '77696E646F772E617065782E7468656D65343264656D6F203D20617065782E7468656D65343264656D6F207C7C207B7D3B0A0A617065782E7468656D65343264656D6F2E696E69745072657669657754656D706C6174654F7074696F6E73203D20287B0A';
wwv_flow_imp.g_varchar2_table(2) := '202020207072657669657749642C0A20202020636F6D706F6E656E74547970652C0A20202020636F6D706F6E656E7453746174696349642C0A2020202074656D706C6174654F7074696F6E730A7D29203D3E207B0A0A2020202074656D706C6174654F70';
wwv_flow_imp.g_varchar2_table(3) := '74696F6E73203D204A534F4E2E70617273652874656D706C6174654F7074696F6E73293B0A0A202020206C657420656C656D656E7424203D2024286023247B636F6D706F6E656E7453746174696349647D60293B0A0A202020206966202820636F6D706F';
wwv_flow_imp.g_varchar2_table(4) := '6E656E7454797065203D3D3D20274954454D272029207B0A2020202020202020656C656D656E7424203D2024286023247B636F6D706F6E656E7453746174696349647D5F434F4E5441494E455260293B0A202020207D0A0A202020206966202820656C65';
wwv_flow_imp.g_varchar2_table(5) := '6D656E74242E66696E6428222E646D2D54656D706C6174654F7074696F6E2D7072657669657754617267657422292E6C656E677468203E20302029207B0A2020202020202020656C656D656E7424203D2024286023247B636F6D706F6E656E7453746174';
wwv_flow_imp.g_varchar2_table(6) := '696349647D202E646D2D54656D706C6174654F7074696F6E2D7072657669657754617267657460293B0A202020207D0A0A202020202F2F20636F6E736F6C652E6C6F67287B0A202020202F2F20202020207072657669657749642C0A202020202F2F2020';
wwv_flow_imp.g_varchar2_table(7) := '202020636F6D706F6E656E74547970652C0A202020202F2F2020202020636F6D706F6E656E7453746174696349642C0A202020202F2F202020202074656D706C6174654F7074696F6E732C0A202020202F2F2020202020656C656D656E74240A20202020';
wwv_flow_imp.g_varchar2_table(8) := '2F2F207D293B0A0A20202020636F6E73742067657454656D706C6174654F7074696F6E73203D20287B0A2020202020202020636F6C6C61707369626C655461726765742C0A20202020202020206973416476616E6365640A202020207D29203D3E207B0A';
wwv_flow_imp.g_varchar2_table(9) := '20202020202020202F2F2053696E676C6520636865636B626F7865730A20202020202020206966202820216973416476616E6365642029207B0A20202020202020202020202074656D706C6174654F7074696F6E732E6F7074696F6E732E666F72456163';
wwv_flow_imp.g_varchar2_table(10) := '6828286F7074696F6E29203D3E207B0A202020202020202020202020202020206C6574206F7074696F6E48746D6C203D20600A20202020202020202020202020202020202020203C64697620636C6173733D22636F6C2D3132223E0A2020202020202020';
wwv_flow_imp.g_varchar2_table(11) := '202020202020202020202020202020203C64697620636C6173733D22742D466F726D2D6669656C64436F6E7461696E657220742D466F726D2D6669656C64436F6E7461696E65722D2D666C6F6174696E674C6162656C20617065782D6974656D2D777261';
wwv_flow_imp.g_varchar2_table(12) := '7070657220617065782D6974656D2D777261707065722D2D73696E676C652D636865636B626F78222069643D22247B7072657669657749647D5F6F7074696F6E5F247B6F7074696F6E2E727D5F434F4E5441494E4552223E0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(13) := '20202020202020202020202020202020203C64697620636C6173733D22742D466F726D2D6C6162656C436F6E7461696E6572223E3C2F6469763E0A202020202020202020202020202020202020202020202020202020203C64697620636C6173733D2274';
wwv_flow_imp.g_varchar2_table(14) := '2D466F726D2D696E707574436F6E7461696E6572223E0A20202020202020202020202020202020202020202020202020202020202020203C64697620636C6173733D22742D466F726D2D6974656D57726170706572223E0A202020202020202020202020';
wwv_flow_imp.g_varchar2_table(15) := '2020202020202020202020202020202020202020202020203C64697620636C6173733D22617065782D6974656D2D73696E676C652D636865636B626F78223E0A202020202020202020202020202020202020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(16) := '202020203C696E70757420747970653D22636865636B626F78222069643D22247B7072657669657749647D5F6F7074696F6E5F247B6F7074696F6E2E727D222076616C75653D22247B6F7074696F6E2E727D2220247B656C656D656E74242E686173436C';
wwv_flow_imp.g_varchar2_table(17) := '617373286F7074696F6E2E7229203F2027636865636B656427203A202727207D3E0A202020202020202020202020202020202020202020202020202020202020202020202020202020203C6C6162656C20666F723D22247B7072657669657749647D5F6F';
wwv_flow_imp.g_varchar2_table(18) := '7074696F6E5F247B6F7074696F6E2E727D222069643D22247B7072657669657749647D5F6F7074696F6E5F247B6F7074696F6E2E727D5F4C4142454C2220636C6173733D22752D636865636B626F78223E247B6F7074696F6E2E647D3C2F6C6162656C3E';
wwv_flow_imp.g_varchar2_table(19) := '0A2020202020202020202020202020202020202020202020202020202020202020202020203C2F6469763E0A20202020202020202020202020202020202020202020202020202020202020203C2F6469763E0A2020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(20) := '20202020202020202020203C2F6469763E0A2020202020202020202020202020202020202020202020203C2F6469763E0A20202020202020202020202020202020202020203C2F6469763E603B0A0A202020202020202020202020202020202428602324';
wwv_flow_imp.g_varchar2_table(21) := '7B7072657669657749647D5F247B636F6C6C61707369626C655461726765747D202E742D526567696F6E2D626F647960292E617070656E64286F7074696F6E48746D6C293B0A0A2020202020202020202020202020202024286023247B70726576696577';
wwv_flow_imp.g_varchar2_table(22) := '49647D5F6F7074696F6E5F247B6F7074696F6E2E727D6020292E6368616E67652866756E6374696F6E2829207B0A20202020202020202020202020202020202020206966202820646F63756D656E742E717565727953656C6563746F72286023247B7072';
wwv_flow_imp.g_varchar2_table(23) := '657669657749647D5F6F7074696F6E5F247B6F7074696F6E2E727D60292E636865636B65642029207B0A202020202020202020202020202020202020202020202020656C656D656E74242E616464436C617373286F7074696F6E2E72293B0A2020202020';
wwv_flow_imp.g_varchar2_table(24) := '2020202020202020202020202020207D20656C7365207B0A202020202020202020202020202020202020202020202020656C656D656E74242E72656D6F7665436C617373286F7074696F6E2E72293B0A2020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(25) := '7D0A2020202020202020202020202020202020202020617065782E6576656E742E7472696767657228646F63756D656E742C202774656D706C6174654F7074696F6E4368616E676564272C207B20636F6D706F6E656E745374617469634964207D293B0A';
wwv_flow_imp.g_varchar2_table(26) := '202020202020202020202020202020207D293B0A2020202020202020202020207D293B0A20202020202020207D0A0A20202020202020202F2F2047726F7570732028726164696F290A202020202020202074656D706C6174654F7074696F6E732E67726F';
wwv_flow_imp.g_varchar2_table(27) := '7570732E66696C7465722820282067726F75702029203D3E2067726F75702E6973416476616E636564203D3D3D206973416476616E636564292E666F7245616368282867726F757029203D3E207B0A2020202020202020202020206C6574206861734465';
wwv_flow_imp.g_varchar2_table(28) := '6661756C74203D202167726F75702E6F7074696F6E732E6D61702820656C203D3E20656C2E72292E736F6D6528723D3E2074656D706C6174654F7074696F6E732E70726573657456616C7565732E696E636C75646573287229293B0A2020202020202020';
wwv_flow_imp.g_varchar2_table(29) := '202020206C65742067726F757048746D6C203D20600A2020202020202020202020203C64697620636C6173733D22636F6C2D3420636F6C2D6D642D36223E0A202020202020202020202020202020203C64697620636C6173733D22742D466F726D2D6669';
wwv_flow_imp.g_varchar2_table(30) := '656C64436F6E7461696E657220742D466F726D2D6669656C64436F6E7461696E65722D2D666C6F6174696E674C6162656C20617065782D6974656D2D7772617070657220617065782D6974656D2D777261707065722D2D726164696F67726F7570223E0A';
wwv_flow_imp.g_varchar2_table(31) := '20202020202020202020202020202020202020203C64697620636C6173733D22742D466F726D2D6C6162656C436F6E7461696E6572223E0A2020202020202020202020202020202020202020202020203C6C6162656C20666F723D22247B707265766965';
wwv_flow_imp.g_varchar2_table(32) := '7749647D5F67726F75705F247B67726F75702E67726F757049647D222069643D22247B7072657669657749647D5F67726F75705F247B67726F75702E67726F757049647D5F4C4142454C2220636C6173733D22742D466F726D2D6C6162656C20752D626F';
wwv_flow_imp.g_varchar2_table(33) := '6C64223E247B67726F75702E7469746C657D3C2F6C6162656C3E0A20202020202020202020202020202020202020203C2F6469763E0A20202020202020202020202020202020202020203C64697620636C6173733D22742D466F726D2D696E707574436F';
wwv_flow_imp.g_varchar2_table(34) := '6E7461696E6572223E0A2020202020202020202020202020202020202020202020203C64697620636C6173733D22742D466F726D2D6974656D57726170706572223E0A202020202020202020202020202020202020202020202020202020203C64697620';
wwv_flow_imp.g_varchar2_table(35) := '746162696E6465783D222D31222069643D22247B7072657669657749647D5F67726F75705F247B67726F75702E67726F757049647D2220617269612D6C6162656C6C656462793D22247B7072657669657749647D5F67726F75705F247B67726F75702E67';
wwv_flow_imp.g_varchar2_table(36) := '726F757049647D5F4C4142454C2220636C6173733D22617065782D6974656D2D67726F757020617065782D6974656D2D67726F75702D2D726320617065782D6974656D2D726164696F2220726F6C653D2267726F7570223E0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(37) := '202020202020202020202020202020202020202020247B67726F75702E6E756C6C546578742026262068617344656661756C74203F20603C64697620636C6173733D22617065782D6974656D2D6F7074696F6E20746F2D707265766965772D6F7074696F';
wwv_flow_imp.g_varchar2_table(38) := '6E223E0A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020203C696E70757420747970653D22726164696F222069643D22247B7072657669657749647D5F67726F75705F24';
wwv_flow_imp.g_varchar2_table(39) := '7B67726F75702E67726F757049647D5F6E756C6C22206E616D653D22247B7072657669657749647D5F67726F75705F247B67726F75702E67726F757049647D2220646174612D646973706C61793D22247B67726F75702E6E756C6C546578747D22207661';
wwv_flow_imp.g_varchar2_table(40) := '6C75653D222220247B656C656D656E74242E69732867726F75702E6F7074696F6E732E6D61702828656C29203D3E20222E222B656C2E72292E6A6F696E28222C222929203F202727203A2027636865636B656427207D203E0A2020202020202020202020';
wwv_flow_imp.g_varchar2_table(41) := '20202020202020202020202020202020202020202020202020202020202020202020202020202020203C6C6162656C20636C6173733D22752D726164696F2220666F723D22247B7072657669657749647D5F67726F75705F247B67726F75702E67726F75';
wwv_flow_imp.g_varchar2_table(42) := '7049647D5F6E756C6C223E247B67726F75702E6E756C6C546578747D3C2F6C6162656C3E0A202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020203C2F6469763E60203A2027';
wwv_flow_imp.g_varchar2_table(43) := '277D0A202020202020202020202020202020202020202020202020202020203C2F6469763E0A2020202020202020202020202020202020202020202020203C2F6469763E0A20202020202020202020202020202020202020203C2F6469763E0A20202020';
wwv_flow_imp.g_varchar2_table(44) := '2020202020202020202020203C2F6469763E0A2020202020202020202020203C2F6469763E603B0A0A20202020202020202020202024286023247B7072657669657749647D5F247B636F6C6C61707369626C655461726765747D202E742D526567696F6E';
wwv_flow_imp.g_varchar2_table(45) := '2D626F647960292E617070656E642867726F757048746D6C293B0A0A20202020202020202020202067726F75702E6F7074696F6E732E666F724561636828286F7074696F6E29203D3E207B0A202020202020202020202020202020206C6574206F707469';
wwv_flow_imp.g_varchar2_table(46) := '6F6E48746D6C203D20600A20202020202020202020202020202020202020203C64697620636C6173733D22617065782D6974656D2D6F7074696F6E20746F2D707265766965772D6F7074696F6E223E0A2020202020202020202020202020202020202020';
wwv_flow_imp.g_varchar2_table(47) := '3C696E70757420747970653D22726164696F222069643D22247B7072657669657749647D5F67726F75705F247B67726F75702E67726F757049647D5F247B6F7074696F6E2E727D22206E616D653D22247B7072657669657749647D5F67726F75705F247B';
wwv_flow_imp.g_varchar2_table(48) := '67726F75702E67726F757049647D2220646174612D646973706C61793D22247B6F7074696F6E2E647D222076616C75653D22247B6F7074696F6E2E727D2220247B656C656D656E74242E686173436C617373286F7074696F6E2E7229203F202763686563';
wwv_flow_imp.g_varchar2_table(49) := '6B656427203A202727207D203E0A20202020202020202020202020202020202020203C6C6162656C20636C6173733D22752D726164696F2220666F723D22247B7072657669657749647D5F67726F75705F247B67726F75702E67726F757049647D5F247B';
wwv_flow_imp.g_varchar2_table(50) := '6F7074696F6E2E727D223E247B6F7074696F6E2E647D3C2F6C6162656C3E0A20202020202020202020202020202020202020203C2F6469763E603B0A0A2020202020202020202020202020202024286023247B7072657669657749647D5F67726F75705F';
wwv_flow_imp.g_varchar2_table(51) := '247B67726F75702E67726F757049647D60292E617070656E64286F7074696F6E48746D6C293B0A2020202020202020202020207D293B0A0A202020202020202020202020242860696E7075745B747970653D726164696F5D5B6E616D653D22247B707265';
wwv_flow_imp.g_varchar2_table(52) := '7669657749647D5F67726F75705F247B67726F75702E67726F757049647D225D6020292E6368616E67652866756E6374696F6E2829207B0A20202020202020202020202020202020656C656D656E74242E72656D6F7665436C6173732867726F75702E6F';
wwv_flow_imp.g_varchar2_table(53) := '7074696F6E732E6D61702828656C29203D3E20656C2E72292E6A6F696E2822202229293B0A20202020202020202020202020202020656C656D656E74242E616464436C61737328646F63756D656E742E717565727953656C6563746F722860696E707574';
wwv_flow_imp.g_varchar2_table(54) := '5B747970653D726164696F5D5B6E616D653D22247B7072657669657749647D5F67726F75705F247B67726F75702E67726F757049647D225D3A636865636B65646020292E76616C756520293B0A20202020202020202020202020202020617065782E6576';
wwv_flow_imp.g_varchar2_table(55) := '656E742E7472696767657228646F63756D656E742C202774656D706C6174654F7074696F6E4368616E676564272C207B20636F6D706F6E656E745374617469634964207D293B0A2020202020202020202020207D293B0A20202020202020207D293B0A20';
wwv_flow_imp.g_varchar2_table(56) := '2020207D3B0A0A20202020636F6E737420656D6974436F6C6C61707369626C65203D20287B0A20202020202020206973416476616E6365640A202020207D29203D3E207B0A202020202020202069662028206973416476616E6365642026262074656D70';
wwv_flow_imp.g_varchar2_table(57) := '6C6174654F7074696F6E732E67726F7570732E66696C7465722820282067726F75702029203D3E2067726F75702E6973416476616E636564203D3D3D206973416476616E63656420292E6C656E677468203D3D3D20302029207B0A202020202020202020';
wwv_flow_imp.g_varchar2_table(58) := '20202072657475726E3B0A20202020202020207D0A0A2020202020202020636F6E7374207469746C65203D206973416476616E636564203F2022416476616E63656422203A2022436F6D6D6F6E223B0A0A202020202020202024286023247B7072657669';
wwv_flow_imp.g_varchar2_table(59) := '657749647D60292E617070656E642820603C64697620726F6C653D22726567696F6E2220617269612D6C6162656C3D22247B7469746C657D2220636C6173733D22742D526567696F6E20742D466F726D2D2D6E6F50616464696E6720742D526567696F6E';
wwv_flow_imp.g_varchar2_table(60) := '2D2D6869646553686F7720742D526567696F6E2D2D7363726F6C6C426F647920742D526567696F6E2D2D6E6F50616464696E6720742D526567696F6E2D2D6E6F554920247B206973416476616E636564203F202769732D636F6C6C617073656427203A20';
wwv_flow_imp.g_varchar2_table(61) := '2769732D657870616E64656427207D222069643D22247B7072657669657749647D5F247B7469746C657D223E0A2020202020202020202020203C64697620636C6173733D22742D526567696F6E2D686561646572223E0A20202020202020202020202020';
wwv_flow_imp.g_varchar2_table(62) := '2020203C64697620636C6173733D22742D526567696F6E2D6865616465724974656D7320742D526567696F6E2D6865616465724974656D732D2D636F6E74726F6C73223E0A20202020202020202020202020202020202020203C7370616E20636C617373';
wwv_flow_imp.g_varchar2_table(63) := '3D22742D427574746F6E20742D427574746F6E2D2D69636F6E20742D427574746F6E2D2D6869646553686F77223E3C7370616E20636C6173733D22612D49636F6E205F612D436F6C6C61707369626C652D69636F6E2220617269612D68696464656E3D22';
wwv_flow_imp.g_varchar2_table(64) := '74727565223E3C2F7370616E3E3C2F7370616E3E0A202020202020202020202020202020203C2F6469763E0A202020202020202020202020202020203C64697620636C6173733D22742D526567696F6E2D6865616465724974656D7320742D526567696F';
wwv_flow_imp.g_varchar2_table(65) := '6E2D6865616465724974656D732D2D7469746C65223E0A20202020202020202020202020202020202020203C683220636C6173733D22742D526567696F6E2D7469746C652220646174612D617065782D68656164696E673E3C627574746F6E20636C6173';
wwv_flow_imp.g_varchar2_table(66) := '733D22742D526567696F6E2D7469746C65427574746F6E2220747970653D22627574746F6E223E247B7469746C657D3C2F627574746F6E3E3C2F68323E0A202020202020202020202020202020203C2F6469763E0A2020202020202020202020203C2F64';
wwv_flow_imp.g_varchar2_table(67) := '69763E0A2020202020202020202020203C64697620636C6173733D22742D526567696F6E2D626F647957726170223E0A202020202020202020202020202020203C64697620636C6173733D22742D526567696F6E2D626F647920752D666C6578206D6172';
wwv_flow_imp.g_varchar2_table(68) := '67696E2D6C6566742D6D64206D617267696E2D72696768742D6D6422207374796C653D22666C65782D777261703A20777261703B223E3C2F6469763E0A2020202020202020202020203C2F6469763E0A20202020202020203C2F6469763E6020293B0A0A';
wwv_flow_imp.g_varchar2_table(69) := '202020202020202067657454656D706C6174654F7074696F6E73287B0A202020202020202020202020636F6C6C61707369626C655461726765743A207469746C652C0A2020202020202020202020206973416476616E6365640A20202020202020207D29';
wwv_flow_imp.g_varchar2_table(70) := '3B0A202020207D3B0A0A20202020656D6974436F6C6C61707369626C65287B206973416476616E6365643A2066616C7365207D293B0A20202020656D6974436F6C6C61707369626C65287B206973416476616E6365643A2074727565207D293B0A0A2020';
wwv_flow_imp.g_varchar2_table(71) := '20202F2F20496E697420636F6C6C61707369626C65730A2020202024286023247B7072657669657749647D202E742D526567696F6E2D2D6869646553686F7760292E656163682866756E6374696F6E202829207B0A202020202020202076617220636F6C';
wwv_flow_imp.g_varchar2_table(72) := '6C61707369626C6524203D20242874686973293B0A0A2020202020202020636F6C6C61707369626C65242E636F6C6C61707369626C65287B0A202020202020202020202020636F6E74656E743A20242874686973292E66696E6428222E742D526567696F';
wwv_flow_imp.g_varchar2_table(73) := '6E2D626F647922292E666972737428292C0A202020202020202020202020636F6C6C61707365643A20636F6C6C61707369626C65242E686173436C617373282269732D636F6C6C617073656422292C0A20202020202020202020202072656E6465724963';
wwv_flow_imp.g_varchar2_table(74) := '6F6E3A2066616C73650A20202020202020207D293B0A0A20202020202020202F2F20496E6A6563742069636F6E20636C61737320696E746F206661757820746F67676C6520627574746F6E0A2020202020202020766172206869646553686F77546F6767';
wwv_flow_imp.g_varchar2_table(75) := '6C6524203D20636F6C6C61707369626C65242E66696E6428222E742D427574746F6E2D2D6869646553686F77202E612D49636F6E22292E616464436C6173732822612D436F6C6C61707369626C652D69636F6E22293B0A0A20202020202020202F2F2054';
wwv_flow_imp.g_varchar2_table(76) := '726967676572696E672061636365737369626C6520636F6C6C61707369626C6520627574746F6E2077697468206661757820627574746F6E0A20202020202020206869646553686F77546F67676C65242E636C69636B2866756E6374696F6E202829207B';
wwv_flow_imp.g_varchar2_table(77) := '0A202020202020202020202020242874686973292E636C6F7365737428272E742D526567696F6E2D68656164657227292E66696E6428272E742D526567696F6E2D7469746C65427574746F6E27292E636C69636B28293B0A20202020202020207D293B0A';
wwv_flow_imp.g_varchar2_table(78) := '202020207D293B0A0A7D3B0A';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(1274784900861540915)
,p_plugin_id=>wwv_flow_imp.id(1274778399807540897)
,p_file_name=>'js/script.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '7B2276657273696F6E223A332C22736F7572636573223A5B227363726970742E6A73225D2C226E616D6573223A5B2277696E646F77222C2261706578222C227468656D65343264656D6F222C22696E69745072657669657754656D706C6174654F707469';
wwv_flow_imp.g_varchar2_table(2) := '6F6E73222C2273656C6563746F72222C2264617461222C22656C656D656E7424222C227472793124222C2224222C22636F6D706F6E656E744964222C227472793024222C226C656E677468222C2274656D706C6174654F7074696F6E7348656C70657222';
wwv_flow_imp.g_varchar2_table(3) := '2C2261646447656E6572616C50726F706572747954797065222C2270726F70657274696573222C2267657450726F70657274696573222C2263757272656E7456616C756573222C2273706C6974222C2270726F7065727479456469746F72222C2270726F';
wwv_flow_imp.g_varchar2_table(4) := '7065727479536574222C22646973706C617947726F75704964222C22646973706C617947726F75705469746C65222C22636F6D6D6F6E222C22616476616E636564222C226368616E6765222C22704576656E74222C227044617461222C2270726F706572';
wwv_flow_imp.g_varchar2_table(5) := '747924222C22676574436C6173736573222C2276616C7565222C2268617344656661756C74222C22636C6173736573222C2266696C746572222C22636C6173734E616D65222C226A6F696E222C2264656661756C7456616C756573222C226E6577436C61';
wwv_flow_imp.g_varchar2_table(6) := '73736573222C2270726F7065727479222C226F6C64436C6173736573222C2270726576696F757356616C7565222C226F726967696E616C56616C7565222C2272656D6F7665436C617373222C22616464436C617373222C2272657175697265735F72656C';
wwv_flow_imp.g_varchar2_table(7) := '6F6164225D2C226D617070696E6773223A2241414141412C4F41414F432C4B41414B432C59414163442C4B41414B432C614141652C4741453943442C4B41414B432C59414159432C3242414136422C53414153432C45414155432C47414537442C494141';
wwv_flow_imp.g_varchar2_table(8) := '49432C45414341432C45414151432C454141452C4F41414F482C4541414B492C694241437442432C45414151462C454141452C4F41414F482C4541414B492C694241457442482C45414444432C4541414D492C4F41434D4A2C45414541472C4541476654';
wwv_flow_imp.g_varchar2_table(9) := '2C4B41414B572C734241417342432C7942414533422C4D41414D432C45414161622C4B41414B572C734241417342472C6341433143562C47414343412C4541414B572C65414169422C49414149432C4D41414D2C4D41477243542C454141454A2C474141';
wwv_flow_imp.g_varchar2_table(10) := '55632C654141652C4341437642622C4B41414D2C43414346632C594141612C434141432C43414356432C65414167422C5341436842432C6B4241416D422C5341436E42502C57414159412C45414157512C51414378422C43414343462C65414167422C57';
wwv_flow_imp.g_varchar2_table(11) := '41436842432C6B4241416D422C5741436E42502C57414159412C45414157532C5941472F42432C4F4141512C53414155432C45414151432C47414374422C4941653043432C4541667443432C454141612C53414155432C47414376422C49414149432C47';
wwv_flow_imp.g_varchar2_table(12) := '4141612C45414362432C47414157462C474141532C494141495A2C4D41414D2C4B41414B652C5141414F2C53414155432C47414370442C4D41416B422C63414164412C49414341482C474141612C4741434E2C4D41475A492C4B41414B2C4B4149522C4F';
wwv_flow_imp.g_varchar2_table(13) := '4148494A2C49414341432C474141572C4941414D31422C4541414B38422C63414163442C4B41414B2C4D41457443482C474165504B2C45414161522C45414157462C4541414D572C53414153522C4F41437643532C45414161562C45414157462C454141';
wwv_flow_imp.g_varchar2_table(14) := '4D612C654162515A2C4541556842442C4541414D432C5541547042442C4541414D572C53414153522C51414155482C4541414D572C53414153472C6341437843622C45414155632C594141592C63414163412C594141592C674241456844642C45414155';
wwv_flow_imp.g_varchar2_table(15) := '652C534141532C6341436668422C4541414D572C534141534D2C694241436668422C45414155652C534141532C674241536E4370432C454141536D432C59414159482C474143724268432C454141536F432C534141534E222C2266696C65223A22736372';
wwv_flow_imp.g_varchar2_table(16) := '6970742E6A73227D';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(1274785294972540915)
,p_plugin_id=>wwv_flow_imp.id(1274778399807540897)
,p_file_name=>'js/script.js.map'
,p_mime_type=>'application/json'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
