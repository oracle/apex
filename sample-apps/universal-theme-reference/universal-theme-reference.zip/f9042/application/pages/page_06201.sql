prompt --application/pages/page_06201
begin
--   Manifest
--     PAGE: 06201
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>776266751179078842
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6201
,p_name=>'JavaScript APIs'
,p_alias=>'JAVASCRIPT-APIS'
,p_step_title=>'JavaScript APIs - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(2710412491289347286)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'code.event-name {',
'    background: rgba(147, 180, 197, 0.25);',
'    padding: 6px 8px;',
'    border-radius: 3px;',
'    text-shadow: 1px 1px #fff;',
'}',
'',
'code.event-name:hover {',
'    color: #000;',
'    background:#eee',
'}',
'',
'.dm-Code {',
'    border-radius: var(--ut-component-border-radius);',
'    border: var(--ut-component-border-width) solid var(--ut-component-border-color);',
'}'))
,p_page_css_classes=>'dm-Page'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
,p_last_upd_yyyymmddhh24miss=>'20230110134708'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4869425670876354954)
,p_plug_name=>'API List'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol class="event-list">',
'    <li class="margin-bottom-md">',
'        <p><code class="event-name">apex.theme42.util.configAPEXMsgs( pOptions )</code></p><p>Configure the display behavior of success messages. You can use this API to programmatically determine how long the success message is displayed before auto'
||'matically dismissing itself.</p>',
'<pre class="dm-Code lang-js"><code>apex.jQuery(function() {',
'  apex.theme42.util.configAPEXMsgs({',
'    autoDismiss: true,',
'    duration: 5000  // duration is optional (Default is 3000 milliseconds)',
'  });',
'});</code></pre>',
'<p><small>Note: The previous name for this API, <code>apex.theme42.configureSuccessMessages</code>, is deprecated and will be removed in a future release.  Please update your application to use the new name.</small></p>',
'    </li>',
'    ',
'    <li class="margin-bottom-md">',
'        <p><code class="event-name">apex.theme42.util.scrollTo( pId )</code></p>',
'        <p>Enables smooth scrolling to the specified anchor, taking into account the sticky top height so the content is not partially blocked.</p>',
'<pre class="dm-Code lang-js"><code>// Example 1: Simply call it to scroll to an region',
'apex.theme42.util.scrollTo( ''my_region'' );',
'',
'// Example 2: Use smooth scroll for all anchor links such as href="#my_content".',
'apex.jQuery(function() {',
'  $( "a[href^=''#'']" ).click(function( e ) {',
'    e.preventDefault();',
'    apex.theme42.util.scrollTo( apex.jQuery( this ).attr( ''href'' ) );',
'  });',
'});</code></pre>',
'    </li>',
'</ol>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4869425777880354955)
,p_plug_name=>'Introduction'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Universal Theme provides the following JavaScript APIs that you may find useful in your applications.</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4886666742369810180)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3079207278690065424)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3722706651486710750)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(4620107297425992659)
);
wwv_flow_imp.component_end;
end;
/
