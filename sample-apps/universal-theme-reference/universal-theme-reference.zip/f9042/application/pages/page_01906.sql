prompt --application/pages/page_01906
begin
--   Manifest
--     PAGE: 01906
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>8200683834871648
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1906
,p_name=>'Map'
,p_alias=>'MAP'
,p_step_title=>'Map'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'19'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(498648482301517004)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(498648666403517006)
,p_plug_name=>'Demo'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(498648568904517005)
,p_plug_name=>'Configuration'
,p_parent_plug_id=>wwv_flow_imp.id(498648666403517006)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Region</h4>',
'<strong>Type:</strong> Map<br/>',
'<strong>Template:</strong> Blank with Attributes (No Grid)<br/>',
'',
'<h4>Attributes</h4>',
'<strong>Map Background:</strong> Built-In<br/>',
'<strong>Map Standard:</strong> Oracle World Map<br/>',
'<strong>Advanced:</strong> <em>Custom SVG Style for Airport</em><br/>',
'',
'<h4>Layer: Major US Airports</h4>',
'<strong>Type:</strong> Points<br/>',
'<strong>Geometry Column Data Type:</strong> SDO_GEOMETRY<br/>',
'<strong>Geometry Column:</strong> <em>The SDO_GEOMETRY column returning geometry objects to display on the map</em><br/>',
'<strong>Point Objects Style:</strong> SVG<br/>',
'<strong>Point Objects Shape:</strong> <em>Airport SVG Style</em><br/>',
'<strong>Point Objects Shape Scale:</strong> 2<br/>',
'<strong>Tooltip:</strong> <em>HTML Expression</em><br/>',
'<strong>Info Window:</strong> <em>Custom HTML Expression</em><br/>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1562095619983774615)
,p_plug_name=>'Map'
,p_region_name=>'map_demo'
,p_parent_plug_id=>wwv_flow_imp.id(498648666403517006)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_plug_grid_column_span=>8
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       IATA_CODE,',
'       CITY,',
'       STATE_NAME,',
'       to_char(ACTIVATION_DATE_DT,''fmDDfm-MON-YYYY'') as ACTIVATION_DATE,',
'       COMMERCIAL_OPS,',
'       to_char(COMMERCIAL_OPS,''999G999G999G999'') as com_ops_fmtd,',
'       AIR_TAXI_OPS,',
'       to_char(AIR_TAXI_OPS,''999G999G999G999'') as air_ops_fmtd,',
'       GEOMETRY',
'  from EBA_UT_MAP_AIRPORTS'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(1562096082389774615)
,p_region_id=>wwv_flow_imp.id(1562095619983774615)
,p_height=>640
,p_tilelayer_type=>'CUSTOM'
,p_tilelayer_name_default=>'world-map'
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
,p_custom_styles=>wwv_flow_string.join(wwv_flow_t_varchar2(
'[',
'    {',
'        "name": "Airport",',
'        "width": 20,',
'        "height": 20,',
'        "paint-order": "stroke",',
'        "viewBox": "0 0 20 20",',
'        "elements": [',
'            {',
'                "type": "path",',
'                "d": "M10,2A6.006,6.006,0,0,0,4,8c0,3.652,5.4,9.587,5.631,9.838a.5.5,0,0,0,.738,0C10.6,17.587,16,11.652,16,8A6.006,6.006,0,0,0,10,2Z"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M12.942,5.942,11.783,7.1l.655,2.836a.5.5,0,0,1-.317.583.509.509,0,0,1-.171.03.5.5,0,0,1-.445-.273l-.978-1.92-.986.986.123,1.1a.5.5,0,0,1-.972.213L8.354,9.646,7.342,9.308a.5.5,0,0,1-.33-.582.509.509,0,0,1,.543-.39l1.1.123.986-.98'
||'6L7.723,6.5a.5.5,0,0,1,.34-.933l2.836.655,1.159-1.159a.625.625,0,0,1,.884.884Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            }',
'        ]',
'    },',
'    {',
'        "name": "Heliport",',
'        "width": 20,',
'        "height": 20,',
'        "paint-order": "stroke",',
'        "viewBox": "0 0 20 20",',
'        "elements": [',
'            {',
'                "type": "path",',
'                "d": "M10,19a1.5,1.5,0,0,1-1.106-.487C8.291,17.855,3,11.967,3,8A7,7,0,0,1,17,8c0,3.967-5.291,9.855-5.894,10.514A1.506,1.506,0,0,1,10,19Z",',
'                "fill":"#ffffff"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M10,2A6.006,6.006,0,0,0,4,8c0,3.652,5.4,9.587,5.631,9.838a.5.5,0,0,0,.738,0C10.6,17.587,16,11.652,16,8A6.006,6.006,0,0,0,10,2Z"',
'            },',
'            {',
'                "type": "path",',
'                "d": "M10.454,9.7h1.224a1.008,1.008,0,0,0,.713-1.722A2.663,2.663,0,0,0,10.5,7.2h-.421v-.94h2.194a.314.314,0,0,0,0-.627H10.075V5.523a.314.314,0,0,0-.627,0v.105H7.254a.314.314,0,1,0,0,.627H9.448V7.2H6.418a.418.418,0,0,0,0,.836H7.5a1,1,0'
||',0,1,.707.293l.767.766A2.091,2.091,0,0,0,10.454,9.7Z",',
'                "fill":"#ffffff"',
'            },',
'            {',
'                "type": "path",',
'                "d": "M12.625,11.378a.375.375,0,0,0,0-.75H8.375a.375.375,0,0,0,0,.75Z",',
'                "fill":"#ffffff"',
'            }',
'        ]',
'    },',
'    {',
'        "name": "Small Airport",',
'        "width": 20,',
'        "height": 20,',
'        "paint-order": "stroke",',
'        "viewBox": "0 0 20 20",',
'        "elements": [',
'            {',
'                "type": "path",',
'                "d": "M10,19a1.5,1.5,0,0,1-1.106-.487C8.291,17.855,3,11.967,3,8A7,7,0,0,1,17,8c0,3.967-5.291,9.855-5.894,10.514A1.506,1.506,0,0,1,10,19Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M10,2A6.006,6.006,0,0,0,4,8c0,3.652,5.4,9.587,5.631,9.838a.5.5,0,0,0,.738,0C10.6,17.587,16,11.652,16,8A6.006,6.006,0,0,0,10,2Z"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M11.94,7.375h-.963L9.435,4.906a.5.5,0,0,0-.9.42L9.2,7.375H8.307l-.693-.866a.508.508,0,0,0-.66-.109.5.5,0,0,0-.177.645L7.29,8.072a1,1,0,0,0,.894.553H9.2l-.666,2.049a.5.5,0,0,0,.122.508.5.5,0,0,0,.778-.088l1.542-2.469h.963a.625.62'
||'5,0,0,0,0-1.25Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M13.076,9a.2.2,0,0,1-.2-.2V7.2a.2.2,0,1,1,.4,0V8.8A.2.2,0,0,1,13.076,9Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            }',
'        ]',
'    }',
']'))
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1562096524186774616)
,p_map_region_id=>wwv_flow_imp.id(1562096082389774615)
,p_name=>'Major US Airports'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Airport'
,p_point_svg_shape_scale=>'2'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'&CITY. (&IATA_CODE.)'
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>&CITY. (&IATA_CODE.)</h3>',
'<p>',
'<strong>&STATE_NAME.</strong><br>',
'{if ACTIVATION_DATE/}',
'Activation Date: &ACTIVATION_DATE.<br>',
'{endif/}',
'{if COMMERCIAL_OPS/}',
'Commercial Operations: &COM_OPS_FMTD.<br>',
'{endif/}',
'{if AIR_TAXI_OPS/}',
'Taxi Operations: &AIR_OPS_FMTD.<br>',
'{endif/}'))
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(498649378619517013)
,p_plug_name=>'Dataset Attribution'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_05'
,p_plug_source=>'<p><small>US Airports data from bts.gov "Airports", Bureau of Transportation Statistics / Federal Government.</small></p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(498649486809517014)
,p_plug_name=>'Sample SQL Query'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.REGION_SOURCE_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'map_demo')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1274915043500595844)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    The Map region is useful for displaying coordinate data and is highly customizable. Supports points, lines and polygon data, as well as a variety of map backgrounds from OpenStreetMap and Oracle World Map to custom backgrounds.',
'</p>',
'<p>',
'    Maps can be connected with additional APEX components such as Faceted Search and Reports, to make filtering and viewing data even easier. ',
'    To see additional Map examples, visit the <a href="https://apex.oracle.com/go/sample_maps" target="_blank" rel="noopener noreferrer">Sample Maps App</a>.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1274915177215595845)
,p_plug_name=>'Instructions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'REGION',
  'attribute_02', 'map_demo')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1562094943838774612)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3734951091360893438)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp.component_end;
end;
/
