prompt --application/pages/page_01918
begin
--   Manifest
--     PAGE: 01918
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1918
,p_name=>'Drawer Demo'
,p_alias=>'DRAWER-DEMO'
,p_page_mode=>'MODAL'
,p_step_title=>'Drawer Demo'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(2421696170353883330)
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutStart:js-dialog-class-t-Drawer--sm'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4247055868118822978)
,p_plug_name=>'Collapsible Region'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-collapsed:t-Region--scrollBody:margin-top-md'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ul>',
'  <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veniam dolorum velit eos illum, voluptatem repellat animi dolores! Tempora fugit natus, odio vitae fuga amet commodi, architecto eaque aperiam hic! Illo!</li>',
'  <li>Quidem dolorem totam consectetur, quis esse sequi non in praesentium illum fugit, provident voluptate perspiciatis voluptas a natus magnam sed accusamus omnis? Reiciendis dignissimos doloremque rem blanditiis. Reprehenderit, facere, velit!</li>',
'  <li>Harum, modi eum suscipit numquam, molestiae laudantium. Ratione enim maiores placeat consequatur sed quam repellat, corporis ducimus magnam, aspernatur quas iusto reprehenderit assumenda ut architecto vel nostrum consequuntur velit sit.</li>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4247056598663822985)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<p>This drawer will automatically expand to fit its contents.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
