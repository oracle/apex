prompt --application/pages/page_00300
begin
--   Manifest
--     PAGE: 00300
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>8200683834871648
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>300
,p_name=>'Grid Layout'
,p_alias=>'GRID-LAYOUT'
,p_step_title=>'Grid Layout - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.display-hidden {',
'    color: var(--ut-component-text-muted-color)!important;',
'}',
'',
'.display-visible {',
'    color: var(--ut-component-text-subtitle-color) !important;',
'    background-color: rgba(59, 170, 44, .1) !important;',
'}',
'',
'.region-grid {',
'    text-align: center;',
'    padding: 16px 8px;',
'    border-radius: 4px;',
'    box-shadow: var(--ut-alert-box-shadow);',
'    font-size: 10px;',
'    overflow: hidden;',
'    text-overflow: ellipsis;',
'    background-color: var(--ut-component-badge-background-color);',
'    color: var(--ut-component-badge-text-color);',
'    font-weight: 500;',
'    margin: 8px 0;',
'    line-height: 1.25;',
'}'))
,p_step_template=>4072355960268175073
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1796047454783228600)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1796047666066228602)
,p_plug_name=>'Responsive Design'
,p_region_name=>'responsive_design'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Universal Theme is responsive out of the box. For more control on your application responsive behavior, read on the additional Universal Theme responsive options.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3400875402187043714)
,p_name=>'Responsive Classes'
,p_parent_plug_id=>wwv_flow_imp.id(1796047666066228602)
,p_template=>2322115667525957943
,p_display_sequence=>10
,p_region_css_classes=>'margin-top-xl'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--horizontalBorders:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Range'' grid_property,',
'       ''All'' grid_all,',
'       ''479px and below'' grid_extra_extra_small,',
'       ''480px to 639px'' grid_extra_small,',
'       ''640px to 767px'' grid_small,',
'       ''768px to 991px'' grid_medium,',
'       ''992px to 1199px'' grid_large,',
'       ''1200px to 1399px'' grid_extra_large,',
'       ''1400px and above'' grid_extra_extra_large',
'  from dual union all',
'',
'select ''CSS Class Prefix'' grid_property,',
'       ''.col-'' grid_all,',
'       ''.col-xxs-'' grid_extra_extra_small,',
'       ''.col-xs-'' grid_extra_small,',
'       ''.col-sm-'' grid_small,',
'       ''.col-md-'' grid_medium,',
'       ''.col-lg-'' grid_large,',
'       ''.col-xl-'' grid_extra_large,',
'       ''.col-xxl-'' grid_extra_extra_large',
'  from dual union all',
'',
'select ''Number of Columns'' grid_property,',
'       ''12'' grid_all,',
'       '''' grid_extra_extra_small,',
'       '''' grid_extra_small,',
'       '''' grid_small,',
'       '''' grid_medium,',
'       '''' grid_large,',
'       '''' grid_extra_large,',
'       '''' grid_extra_extra_large',
'  from dual union all',
'',
'select ''Gutter'' grid_property,',
'       ''1rem (0.5rem each side)'' grid_all,',
'       '''' grid_extra_extra_small,',
'       '''' grid_extra_small,',
'       '''' grid_small,',
'       '''' grid_medium,',
'       '''' grid_large,',
'       '''' grid_extra_large,',
'       '''' grid_extra_extra_large',
'  from dual'))
,p_header=>'<p>You can fine tune the responsive behavior of the components on your page by modifying the <strong>Column CSS Classes</strong> property of your components.</p>'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1522902419140242594)
,p_query_column_id=>1
,p_column_alias=>'GRID_PROPERTY'
,p_column_display_sequence=>10
,p_column_html_expression=>'<strong>#GRID_PROPERTY#</strong>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1522902539818242595)
,p_query_column_id=>2
,p_column_alias=>'GRID_ALL'
,p_column_display_sequence=>20
,p_column_heading=>'All'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1522902679814242596)
,p_query_column_id=>3
,p_column_alias=>'GRID_EXTRA_EXTRA_SMALL'
,p_column_display_sequence=>30
,p_column_heading=>'XX Small'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1522902791526242597)
,p_query_column_id=>4
,p_column_alias=>'GRID_EXTRA_SMALL'
,p_column_display_sequence=>40
,p_column_heading=>'X Small'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1522902902965242598)
,p_query_column_id=>5
,p_column_alias=>'GRID_SMALL'
,p_column_display_sequence=>50
,p_column_heading=>'Small'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1522902928848242599)
,p_query_column_id=>6
,p_column_alias=>'GRID_MEDIUM'
,p_column_display_sequence=>60
,p_column_heading=>'Medium'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1522903101665242600)
,p_query_column_id=>7
,p_column_alias=>'GRID_LARGE'
,p_column_display_sequence=>70
,p_column_heading=>'Large'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1522903151577242601)
,p_query_column_id=>8
,p_column_alias=>'GRID_EXTRA_LARGE'
,p_column_display_sequence=>80
,p_column_heading=>'X Large'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1522903222295242602)
,p_query_column_id=>9
,p_column_alias=>'GRID_EXTRA_EXTRA_LARGE'
,p_column_display_sequence=>90
,p_column_heading=>'XX Large'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3490549028364761620)
,p_plug_name=>'Visibility Classes'
,p_parent_plug_id=>wwv_flow_imp.id(1796047666066228602)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use the following classes to hide a given component when the viewport size is at the specified breakpoint.</p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc  dm-Report--grid">',
'  <thead>',
'    <tr>',
'      <th></th>',
'      <th>XXS <small>479px and below</small></th>',
'      <th>XS <small>480px to 639px</small></th>',
'      <th>Small <small>640px to 767px</small></th>',
'      <th>Medium <small>768px to 991px</small></th>',
'      <th>Large <small>992px and above</small></th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">xxs</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">xs</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">sm</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">md</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-visible">Visible</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">lg</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">xxs</span>-up</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">xs</span>-up</span></th>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">sm</span>-up</span></th>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">md</span>-up</span></th>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">lg</span>-up</span></th>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'  </tbody>',
'</table>',
'',
'<p><small>Note: These helper utilities are available in Oracle APEX 18.2 and later.</small></p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3809402410402331315)
,p_plug_name=>'Demo'
,p_parent_plug_id=>wwv_flow_imp.id(1796047666066228602)
,p_region_css_classes=>'u-textCenter	'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="u-textLeft">Every region below uses the following responsive CSS Classes: <code>col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1</code></p>',
'<p class="u-textLeft">Resize this window to experience the responsiveness of this page.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3658795428447622054)
,p_plug_name=>'Responsive Region 2'
,p_parent_plug_id=>wwv_flow_imp.id(3809402410402331315)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3658795603815622055)
,p_plug_name=>'Responsive Region 4'
,p_parent_plug_id=>wwv_flow_imp.id(3809402410402331315)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>100
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3658795641783622056)
,p_plug_name=>'Responsive Region 6'
,p_parent_plug_id=>wwv_flow_imp.id(3809402410402331315)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>120
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3658795717983622057)
,p_plug_name=>'Responsive Region 8'
,p_parent_plug_id=>wwv_flow_imp.id(3809402410402331315)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>140
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3658795894741622058)
,p_plug_name=>'Responsive Region 10'
,p_parent_plug_id=>wwv_flow_imp.id(3809402410402331315)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>160
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3658796009823622059)
,p_plug_name=>'Responsive Region 1'
,p_parent_plug_id=>wwv_flow_imp.id(3809402410402331315)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>70
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3658796027734622060)
,p_plug_name=>'Responsive Region 3'
,p_parent_plug_id=>wwv_flow_imp.id(3809402410402331315)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3658796138570622061)
,p_plug_name=>'Responsive Region 5'
,p_parent_plug_id=>wwv_flow_imp.id(3809402410402331315)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>110
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3658796254724622062)
,p_plug_name=>'Responsive Region 7'
,p_parent_plug_id=>wwv_flow_imp.id(3809402410402331315)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>130
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3658796368418622063)
,p_plug_name=>'Responsive Region 9'
,p_parent_plug_id=>wwv_flow_imp.id(3809402410402331315)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>150
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3658796487668622064)
,p_plug_name=>'Responsive Region 11'
,p_parent_plug_id=>wwv_flow_imp.id(3809402410402331315)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>170
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3658796547738622065)
,p_plug_name=>'Responsive Region 12'
,p_parent_plug_id=>wwv_flow_imp.id(3809402410402331315)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>180
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xxs-12 col-xs-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-xxl-1'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373834495082430705)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3734951091360893438)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3400875558156043716)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Universal Theme uses a 12 columns grid layout system for arranging components on a page.</p>',
'<p>Understanding this grid system will allow you to create thoughful designs and personalize the responsive experience of your applications.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373833822614430698)
,p_plug_name=>'Toggle Layout Columns'
,p_parent_plug_id=>wwv_flow_imp.id(3400875558156043716)
,p_region_css_classes=>'margin-bottom-xl'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<p>Click the <b>Toggle Layout Columns</b> button to overlay the grid behind this page.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3524437822324139930)
,p_plug_name=>'Demo'
,p_region_css_classes=>'u-textCenter	'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373830840369430669)
,p_plug_name=>'Region 2'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373831015737430670)
,p_plug_name=>'Region 4'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>100
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373831053705430671)
,p_plug_name=>'Region 6'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>120
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373831129905430672)
,p_plug_name=>'Region 8'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>140
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373831306663430673)
,p_plug_name=>'Region 10'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>160
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373831421745430674)
,p_plug_name=>'Region 1'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373831439656430675)
,p_plug_name=>'Region 3'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373831550492430676)
,p_plug_name=>'Region 5'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>110
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373831666646430677)
,p_plug_name=>'Region 7'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>130
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373831780340430678)
,p_plug_name=>'Region 9'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>150
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373831899590430679)
,p_plug_name=>'Region 11'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>170
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373831959660430680)
,p_plug_name=>'Region 12'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>180
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'1 Column'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373832101987430681)
,p_plug_name=>'Region 1'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>190
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'2 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373832147009430682)
,p_plug_name=>'Region 2'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>200
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'2 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373832227700430683)
,p_plug_name=>'Region 3'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>210
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'2 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373832382362430684)
,p_plug_name=>'Region 4'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>220
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'2 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373832466208430685)
,p_plug_name=>'Region 5'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>230
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'2 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373832562613430686)
,p_plug_name=>'Region 6'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>240
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'2 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373832623739430687)
,p_plug_name=>'Region 1'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>250
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'3 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373832775266430688)
,p_plug_name=>'Region 2'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>260
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'3 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373832843322430689)
,p_plug_name=>'Region 3'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>270
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'3 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373832990081430690)
,p_plug_name=>'Region 4'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>280
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'3 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373833297206430693)
,p_plug_name=>'Region 1'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>290
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'4 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373833382170430694)
,p_plug_name=>'Region 2'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>300
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'4 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373833497405430695)
,p_plug_name=>'Region 3'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>310
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'4 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373833593828430696)
,p_plug_name=>'Region 1'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>320
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'6 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3373833664450430697)
,p_plug_name=>'Region 2'
,p_parent_plug_id=>wwv_flow_imp.id(3524437822324139930)
,p_region_css_classes=>'region-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>330
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'6 Columns'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2722399258872208700)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3373833822614430698)
,p_button_name=>'TOGGLE_GRID_LAYOUT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Toggle Layout Columns'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2722403000167208706)
,p_name=>'Toggle Grid Layout'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2722399258872208700)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'apex.jQuery(''body'').hasClass(''grid-debug-on'')'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2722403434386208707)
,p_event_id=>wwv_flow_imp.id(2722403000167208706)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REMOVE_CLASS'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'body'
,p_attribute_01=>'grid-debug-on'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2722403925786208708)
,p_event_id=>wwv_flow_imp.id(2722403000167208706)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(2722399258872208700)
,p_attribute_01=>'is-active'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2722404484458208708)
,p_event_id=>wwv_flow_imp.id(2722403000167208706)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'body'
,p_attribute_01=>'grid-debug-on'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2722404935770208709)
,p_event_id=>wwv_flow_imp.id(2722403000167208706)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REMOVE_CLASS'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(2722399258872208700)
,p_attribute_01=>'is-active'
);
wwv_flow_imp.component_end;
end;
/
