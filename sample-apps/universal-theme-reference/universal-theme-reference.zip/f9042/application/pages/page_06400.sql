prompt --application/pages/page_06400
begin
--   Manifest
--     PAGE: 06400
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6400
,p_name=>'Template Directives'
,p_alias=>'TEMPLATE-DIRECTIVES'
,p_step_title=>'Template Directives'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.item {',
'    color: #9C27B0;',
'}',
'.directive {',
'    color: #008676;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1915602526366960820)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920024297525065873)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920024449475065874)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Templating is an extremely powerful tool in APEX. ',
'    Template Directives provide control over how substitution strings and content is processed.</p>',
'<p>Template Directives can also be used to build dynamic, reusable templates, which can then be applied ',
'    in HTML Expressions anywhere in APEX.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920024628859065876)
,p_plug_name=>'If Directives'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<p>The <span class="directive"><strong>if</strong></span> directive can be used to conditionally show content based on the evaluation of an item or column value.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920024962491065879)
,p_plug_name=>'Syntax'
,p_parent_plug_id=>wwv_flow_imp.id(1920024628859065876)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'    <span class="directive">{if <span class="item"><em>ITEM</em></span>/}</span>',
'        ...',
'    <span class="directive">{elseif <span class="item"><em>!ITEM</em></span>/}</span>',
'        ...',
'    <span class="directive">{else/}</span>',
'        ...',
'    <span class="directive">{endif/}</span>',
'</pre>',
''))
,p_landmark_label=>'If Syntax'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920025049151065880)
,p_plug_name=>'Example'
,p_parent_plug_id=>wwv_flow_imp.id(1920024628859065876)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'    &lt;div&gt;',
'        <span class="directive">{if <span class="item">P1_DISPLAY_IMAGE</span>/}</span>',
'            &amp;P1_IMAGE.',
'        <span class="directive">{else/}</span>',
'            No image.',
'        <span class="directive">{endif/}</span>',
'    &lt;/div&gt;',
'</pre>',
''))
,p_landmark_label=>'If Example'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1956802987119303763)
,p_plug_name=>'Token Modifiers'
,p_parent_plug_id=>wwv_flow_imp.id(1920024628859065876)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>70
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th>Condition</th>',
'      <th>Directive</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td>if_exists_and_true</td><td><code><span class="directive">{if <span class="item">ITEM</span>/}</span></code></td></tr>',
'    <tr><td>if_exists</td><td><code><span class="directive">{if ?<span class="item">ITEM</span>/}</span></code></td></tr>',
'    <tr><td>if_not_exists_or_false</td><td><code><span class="directive">{if !<span class="item">ITEM</span>/}</span></code></td></tr>',
'    <tr><td>if_not_exists</td><td><code><span class="directive">{if !?<span class="item">ITEM</span>/}</span></code></td></tr>',
'    <tr><td>if_not_false</td><td><code><span class="directive">{if =<span class="item">ITEM</span>/}</span></code></td></tr>',
'    <tr><td>if_exists_and_false</td><td><code><span class="directive">{if !=<span class="item">ITEM</span>/}</span></code></td></tr>',
'  </tbody>',
'</table>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1956803081680303764)
,p_plug_name=>'Evaluation'
,p_parent_plug_id=>wwv_flow_imp.id(1920024628859065876)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th>Truthy</th>',
'      <th>Falsey</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td>Not Null</td><td>Null</td></tr>',
'    <tr><td>T</td><td>F</td></tr>',
'    <tr><td>Y</td><td>N</td></tr>',
'    <tr><td>1</td><td>0</td></tr>',
'  </tbody>',
'</table>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920024789329065877)
,p_plug_name=>'Case Directives'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<p>The <span class="directive"><strong>case</strong></span> directive can be used to show content based on the value of an item or column.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920025588363065885)
,p_plug_name=>'Syntax'
,p_parent_plug_id=>wwv_flow_imp.id(1920024789329065877)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'    <span class="directive">{case <span class="item"><em>ITEM</em></span>/}',
'        {when <span class="item"><em>VALUE</em></span>/}</span>',
'            ...',
'        <span class="directive">{when <span class="item"><em>VALUE</em></span>/}</span>',
'            ...',
'        <span class="directive">{otherwise/}</span>',
'            ...',
'    <span class="directive">{endcase/}</span>',
'</pre>',
''))
,p_landmark_label=>'Case Syntax'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920025659791065886)
,p_plug_name=>'Example'
,p_parent_plug_id=>wwv_flow_imp.id(1920024789329065877)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'    &lt;div class=" ',
'        <span class="directive">{case <span class="item">BADGE_SHAPE</span>/}',
'            {when <span class="item">SQUARE</span>/}</span>',
'                t-Badge--square',
'            <span class="directive">{when <span class="item">CIRCULAR</span>/}</span>',
'                t-Badge--circle',
'            <span class="directive">{otherwise/}</span>',
'                t-Badge--rounded',
'        <span class="directive">{endcase/}</span> "&gt;',
'</pre>',
''))
,p_landmark_label=>'Case Example'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920024803198065878)
,p_plug_name=>'Loop Directives'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<p>The <span class="directive"><strong>loop</strong></span> directive can be used to repeat content once for each item in a multi-value (character delimited) item or column.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920025725618065887)
,p_plug_name=>'Syntax'
,p_parent_plug_id=>wwv_flow_imp.id(1920024803198065878)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'    <span class="directive">{loop "<span class="item"><em>SEPARATOR</em></span>" <span class="item"><em>ITEM</em></span>/}</span>',
'        ...',
'    <span class="directive">{endloop/}</span>',
'</pre>',
''))
,p_landmark_label=>'Loop Syntax'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920025891081065888)
,p_plug_name=>'Example'
,p_parent_plug_id=>wwv_flow_imp.id(1920024803198065878)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'    &lt;ul&gt;',
'        <span class="directive">{loop "<span class="item">,</span>" <span class="item">TAGS</span>/}</span>',
'            &lt;li&gt;Tag: &amp;APEX$ITEM.&lt;/li&gt;',
'        <span class="directive">{endloop/}</span>',
'    &lt;/ul&gt;',
'</pre>',
''))
,p_landmark_label=>'Loop Example'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920025172152065881)
,p_plug_name=>'With & Apply Directives'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<p>The <span class="directive"><strong>with</strong></span> and <span class="directive"><strong>apply</strong></span> directives allow predefined dynamic templates to be used in HTML expressions.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920025918797065889)
,p_plug_name=>'Syntax'
,p_parent_plug_id=>wwv_flow_imp.id(1920025172152065881)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'    <span class="directive">{with/}</span>',
'        ...',
'    <span class="directive">{apply <span class="item"><em>TEMPLATE</em></span>/}</span>',
'</pre>',
''))
,p_landmark_label=>'With Apply Syntax'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1920026035713065890)
,p_plug_name=>'Example'
,p_parent_plug_id=>wwv_flow_imp.id(1920025172152065881)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:js-headingLevel-3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'    <span class="directive">{with/}</span>',
'        TYPE:=IMAGE',
'        IMAGE:=#PROFILE_IMAGE#',
'        IMAGE_ALT:=Profile Image',
'        SIZE:=t-Avatar--lg',
'        SHAPE:=t-Avatar--circle',
'        CSS_CLASSES:=u-color-29',
'    <span class="directive">{apply <span class="item">THEME$AVATAR</span>/}</span>',
'</pre>'))
,p_landmark_label=>'With Apply Example'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
