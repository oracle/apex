prompt --application/pages/page_01907
begin
--   Manifest
--     PAGE: 01907
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1907
,p_user_interface_id=>wwv_flow_imp.id(1319173717720724629)
,p_name=>'Tabs'
,p_alias=>'TABS'
,p_step_title=>'Tabs - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(1056168381265014818)
,p_javascript_code_onload=>'apex.theme42demo.jump(''&REQUEST.'');'
,p_step_template=>wwv_flow_imp.id(3121228739815246741)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'06'
,p_last_upd_yyyymmddhh24miss=>'20220225144709'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2783323263058914565)
,p_plug_name=>'Tabs as Regions'
,p_region_name=>'tab_container'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The <strong>Tabs Container</strong> Region Template can be used to create a set tabs within your page.  Simply place sub regions within the Tabs Container and they will appear as a tab.</p>',
'<p>This control is useful when you want to display different regions or information, but utilise the same space on a page.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(299234712227955731)
,p_plug_name=>'Demo'
,p_parent_plug_id=>wwv_flow_imp.id(2783323263058914565)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>21
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2523647804400931050)
,p_plug_name=>'Tabs Container'
,p_region_name=>'Demo1'
,p_parent_plug_id=>wwv_flow_imp.id(299234712227955731)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--pill'
,p_plug_template=>wwv_flow_imp.id(2272044597952680196)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2523647944784931051)
,p_plug_name=>'Tab 1'
,p_parent_plug_id=>wwv_flow_imp.id(2523647804400931050)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3121231715860246749)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Content 1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2523648037775931052)
,p_plug_name=>'Tab 2'
,p_parent_plug_id=>wwv_flow_imp.id(2523647804400931050)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3121231715860246749)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Content 2'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2523648136927931053)
,p_plug_name=>'Tab 3'
,p_parent_plug_id=>wwv_flow_imp.id(2523647804400931050)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3121231715860246749)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Content 3'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(299234845759955732)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(2783323263058914565)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>1
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Demo1'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Then create or move sub regions into the Tabs Container, one for each tab you want to have.</p>',
'<p><strong>Tip:</strong> You can easily nest tabs by creating another Tabs Container region within a sub region of an existing Tabs Container region.</p>'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2783324141713914574)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_imp.id(2783323263058914565)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>31
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Demo1'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2783323366413914566)
,p_plug_name=>'Tabs as a List'
,p_region_name=>'tab_list'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<p>The <strong>Tabs</strong> List Template can be used to create a set tabs where each tab links to another page.  This is especially useful for applications that require nested or complex navigation hierarchies.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(299234923241955733)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(2783323366413914566)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Demo2'
,p_attribute_03=>'<p><strong>Tip:</strong> You can add icons to these tabs simply by modifying the icon attribute of the list entry.</p>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2783324879053914581)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_imp.id(2783323366413914566)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Demo2'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2783325068832914583)
,p_plug_name=>'Demo'
,p_parent_plug_id=>wwv_flow_imp.id(2783323366413914566)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2420110581345097560)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2523647515659931047)
,p_plug_name=>'Tabs List'
,p_region_name=>'Demo2'
,p_parent_plug_id=>wwv_flow_imp.id(2783325068832914583)
,p_region_sub_css_classes=>'dm-TemplateOption-previewTarget'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_component_template_options=>'#DEFAULT#:t-Tabs--simple'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(2783445112658871101)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(2338526269025997434)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4957396650188942581)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>You can use Tabs and the Region Display Selector within your application pages to improve navigation, flow and usability of your pages.  These components are grouped together as they provide similar functionality, but have different implementation'
||'s and use cases.  This page will outline the three distinct methods you can use to apply these components to your page.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4957396957301940764)
,p_plug_name=>'Region Display Selector'
,p_region_name=>'dialog_fixed'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3550313444782567988)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9189455402498392101)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3121236124904246762)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(299235067770955734)
,p_name=>'customEvent templateOptionChanged'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'templateOptionChanged'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(299235147157955735)
,p_event_id=>wwv_flow_imp.id(299235067770955734)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let tabsRegion$ = $(`#${this.data.componentStaticId}.t-TabsRegion`);',
'',
'if ($.apex.aTabs && tabsRegion$.length > 0) {',
'    $(`#${this.data.componentStaticId} .apex-rds-slider, #${this.data.componentStaticId} .t-Tabs` ).remove();',
'    tabsRegion$.utTabs();',
'}'))
);
wwv_flow_imp.component_end;
end;
/
