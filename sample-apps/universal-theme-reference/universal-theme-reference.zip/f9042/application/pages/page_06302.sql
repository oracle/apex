prompt --application/pages/page_06302
begin
--   Manifest
--     PAGE: 06302
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>8200683834871648
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6302
,p_name=>'Color and Status Modifiers'
,p_alias=>'COLOR-AND-STATUS-MODIFIERS'
,p_step_title=>'Color and Status Modifiers - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(2722656931163529974)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.color-cell-block {',
'  display: block;',
'  padding: .5rem;',
'  text-align: center;',
'  border-radius: .125rem;',
'}',
'',
'.color-border {',
'  border-width: 1px;',
'  border-style: solid;',
'  padding: .5rem;',
'}'))
,p_page_css_classes=>'dm-Page'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8995038448287924)
,p_plug_name=>'Shadow Utility Class'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_location=>null
,p_plug_source=>'The shadow class allows for control over the drop shadow of elements.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(8995123412287925)
,p_name=>'Shadow Class'
,p_parent_plug_id=>wwv_flow_imp.id(8995038448287924)
,p_template=>4072358936313175081
,p_display_sequence=>10
,p_region_sub_css_classes=>'colors-table'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--horizontalBorders'
,p_grid_column_css_classes=>'col-sm-12'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 seq, ''None'' shadow_label, ''none'' shadow_size from dual',
'union all',
'select 2 seq, ''Small'' shadow_label, ''sm'' shadow_size from dual',
'union all',
'select 3 seq, ''Medium'' shadow_label, ''md'' shadow_size from dual',
'union all',
'select 4 seq, ''Large'' shadow_label, ''lg'' shadow_size from dual',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>45
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8995691804287930)
,p_query_column_id=>1
,p_column_alias=>'SEQ'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8995703421287931)
,p_query_column_id=>2
,p_column_alias=>'SHADOW_LABEL'
,p_column_display_sequence=>60
,p_column_heading=>'Shadow'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8995835930287932)
,p_query_column_id=>3
,p_column_alias=>'SHADOW_SIZE'
,p_column_display_sequence=>70
,p_column_heading=>'Block'
,p_column_html_expression=>'<span class="color-border u-color-29-border u-flex u-margin-block-#SHADOW_SIZE# u-justify-content-center u-padding-lg u-shadow-#SHADOW_SIZE#">u-shadow-#SHADOW_SIZE#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17275260103641849)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'SESSION')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17275377059641850)
,p_plug_name=>'Opacity Utility Class'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_location=>null
,p_plug_source=>'The opacity class allows for control over the opacity of elements. Combine u-opacity with any percentage amount to set the opacity of an element.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(17276876599641865)
,p_name=>'Opacity Class'
,p_parent_plug_id=>wwv_flow_imp.id(17275377059641850)
,p_template=>4072358936313175081
,p_display_sequence=>70
,p_region_sub_css_classes=>'colors-table'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--horizontalBorders'
,p_grid_column_css_classes=>'col-sm-12'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 seq, ''Opacity 10%'' opacity_label, ''u-opacity-10'' opacity, ''u-info'' status, null u_color from dual',
'union all',
'select 2 seq, ''Opacity 20%'' opacity_label, ''u-opacity-20'' opacity, ''u-info'' status, null u_color from dual',
'union all',
'select 3 seq, ''Opacity 30%'' opacity_label, ''u-opacity-30'' opacity, ''u-info'' status, null u_color from dual',
'union all',
'select 4 seq, ''Opacity 40%'' opacity_label, ''u-opacity-40'' opacity, ''u-info'' status, null u_color from dual',
'union all',
'select 5 seq, ''Opacity 50%'' opacity_label, ''u-opacity-50'' opacity, ''u-info'' status, null u_color from dual',
'union all',
'select 6 seq, ''Opacity 60%'' opacity_label, ''u-opacity-60'' opacity, ''u-info'' status, null u_color from dual',
'union all',
'select 7 seq, ''Opacity 70%'' opacity_label, ''u-opacity-70'' opacity, ''u-info'' status, null u_color from dual',
'union all',
'select 8 seq, ''Opacity 80%'' opacity_label, ''u-opacity-80'' opacity, ''u-info'' status, null u_color from dual',
'union all',
'select 9 seq, ''Opacity 90%'' opacity_label, ''u-opacity-90'' opacity, ''u-info'' status, null u_color from dual',
'union all',
'select 10 seq, ''Opacity 100%'' opacity_label, ''u-opacity-100'' opacity, ''u-info'' status, null u_color from dual',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>45
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17277520390641872)
,p_query_column_id=>1
,p_column_alias=>'SEQ'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17277833188641875)
,p_query_column_id=>2
,p_column_alias=>'OPACITY_LABEL'
,p_column_display_sequence=>10
,p_column_heading=>'Opacity Level'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17277934762641876)
,p_query_column_id=>3
,p_column_alias=>'OPACITY'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17277409178641871)
,p_query_column_id=>4
,p_column_alias=>'STATUS'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(17277026639641867)
,p_query_column_id=>5
,p_column_alias=>'U_COLOR'
,p_column_display_sequence=>30
,p_column_heading=>'Block'
,p_column_html_expression=>'<span class="color-cell-block #STATUS# #OPACITY#">#OPACITY#</span>'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3524439103597139942)
,p_plug_name=>'Stateful Color Utilities'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Universal Theme provides 6 stateful colors: normal, hot, informational, danger, warning, and success. Here are the CSS modifier classes you can use to apply these states to your own UI controls.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3524439125790139943)
,p_name=>'Stateful Utility Classes'
,p_parent_plug_id=>wwv_flow_imp.id(3524439103597139942)
,p_template=>4072358936313175081
,p_display_sequence=>60
,p_region_sub_css_classes=>'colors-table'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--horizontalBorders'
,p_grid_column_css_classes=>'col-sm-12'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 seq, ''Normal'' status_label, ''u-normal'' status, null u_color, null u_color_text, null u_color_bg, null u_color_bd from dual',
'union all',
'select 2 seq, ''Hot'' status_label, ''u-hot'' status, null u_color, null u_color_text, null u_color_bg, null u_color_bd from dual',
'union all',
'select 3 seq, ''Warning'' status_label, ''u-warning'' status, null u_color, null u_color_text, null u_color_bg, null u_color_bd from dual',
'union all',
'select 4 seq, ''Danger'' status_label, ''u-danger'' status, null u_color, null u_color_text, null u_color_bg, null u_color_bd from dual',
'union all',
'select 5 seq, ''Info'' status_label, ''u-info'' status, null u_color, null u_color_text, null u_color_bg, null u_color_bd from dual',
'union all',
'select 6 seq, ''Success'' status_label, ''u-success'' status, null u_color, null u_color_text, null u_color_bg, null u_color_bd from dual',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>45
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3524439967926139951)
,p_query_column_id=>1
,p_column_alias=>'SEQ'
,p_column_display_sequence=>61
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3524439806728139950)
,p_query_column_id=>2
,p_column_alias=>'STATUS_LABEL'
,p_column_display_sequence=>1
,p_column_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3524439745038139949)
,p_query_column_id=>3
,p_column_alias=>'STATUS'
,p_column_display_sequence=>51
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1989910493774952018)
,p_query_column_id=>4
,p_column_alias=>'U_COLOR'
,p_column_display_sequence=>11
,p_column_heading=>'Block'
,p_column_html_expression=>'<span class="color-cell-block #STATUS#">#STATUS#</span>'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1989910592958952019)
,p_query_column_id=>5
,p_column_alias=>'U_COLOR_TEXT'
,p_column_display_sequence=>21
,p_column_heading=>'Text'
,p_column_html_expression=>'<span class="color-cell-block color-text #STATUS#-text">#STATUS#-text</span>'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1989910700179952020)
,p_query_column_id=>6
,p_column_alias=>'U_COLOR_BG'
,p_column_display_sequence=>31
,p_column_heading=>'Background'
,p_column_html_expression=>'<span class="color-cell-block color-background #STATUS#-bg">#STATUS#-bg</span>'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1989910803822952021)
,p_query_column_id=>7
,p_column_alias=>'U_COLOR_BD'
,p_column_display_sequence=>41
,p_column_heading=>'Border'
,p_column_html_expression=>'<span class="color-cell-block color-border #STATUS#-border">#STATUS#-border</span>'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4194678318280642717)
,p_plug_name=>'General Color Utilities'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>While many components within Universal Theme automatically make use of these colors, you can use them in several custom components as well.  Universal Theme provides a number of CSS utility classes that can be used to apply this color palette to a'
||'ny HTML markup.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(2788683235822210336)
,p_name=>'General Utility Classes'
,p_parent_plug_id=>wwv_flow_imp.id(4194678318280642717)
,p_template=>4072358936313175081
,p_display_sequence=>40
,p_region_sub_css_classes=>'colors-table'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--horizontalBorders'
,p_grid_column_css_classes=>'col-sm-12'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT LEVEL num, null color, null color_text, null color_bg, null color_bd',
'  FROM DUAL',
'CONNECT BY LEVEL <= 45',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>45
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2788683902094210342)
,p_query_column_id=>1
,p_column_alias=>'NUM'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2788684006190210343)
,p_query_column_id=>2
,p_column_alias=>'COLOR'
,p_column_display_sequence=>2
,p_column_heading=>'Block'
,p_column_html_expression=>'<span class="color-cell-block u-color-#NUM#">u-color-#NUM#</span>'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2788683517807210339)
,p_query_column_id=>3
,p_column_alias=>'COLOR_TEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Text'
,p_column_html_expression=>'<span class="color-cell-block color-text u-color-#NUM#-text">u-color-#NUM#-text</span>'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2788683672215210340)
,p_query_column_id=>4
,p_column_alias=>'COLOR_BG'
,p_column_display_sequence=>4
,p_column_heading=>'Background'
,p_column_html_expression=>'<span class="color-cell-block color-background u-color-#NUM#-bg">u-color-#NUM#-bg</span>'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2788683769201210341)
,p_query_column_id=>5
,p_column_alias=>'COLOR_BD'
,p_column_display_sequence=>5
,p_column_heading=>'Border'
,p_column_html_expression=>'<span class="color-cell-block color-border u-color-#NUM#-border">u-color-#NUM#-border</span>'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4211919389774097943)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3734951091360893438)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp.component_end;
end;
/
