prompt --application/pages/page_01913
begin
--   Manifest
--     PAGE: 01913
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>776266751179078842
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1913
,p_name=>'Modal Dialog Demo - Fixed Size'
,p_alias=>'MODAL-DIALOG-DEMO-FIXED-SIZE'
,p_page_mode=>'MODAL'
,p_step_title=>'Fixed Height Modal Dialog'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(2401837048789160465)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'400'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'11'
,p_last_upd_yyyymmddhh24miss=>'20230110134708'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6031888325566845819)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3212078847484281050)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This modal dialog has a fixed height of 400px and will not automatically resize to fit its contents.  This type of dialog is useful for wizards where the navigation buttons should remain in a constant position.</p>',
'<p>To set a height for a modal dialog page, simply set the "Height" property for the page in the Property Editor.</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
