prompt --application/pages/page_01915
begin
--   Manifest
--     PAGE: 01915
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1915
,p_name=>'Inline Popup'
,p_alias=>'INLINE-POPUP'
,p_step_title=>'Inline Popup'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(2421696170353883330)
,p_step_template=>4072355960268175073
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2408037459361851204)
,p_plug_name=>'Popup with Callout'
,p_region_name=>'popup_callout'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-callout:js-dialog-size600x400'
,p_region_attributes=>'data-parent-element="#btn_popup_callout"'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>80
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>'This popup has a callout arrow that points to the button or element that this popup was opened from.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6273039269537339652)
,p_plug_name=>'Demo'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6273041818275351753)
,p_plug_name=>'Auto Height Popup'
,p_region_name=>'dialog_auto'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-size480x320'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_04'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6273041848239351754)
,p_plug_name=>'Collapsible Content'
,p_parent_plug_id=>wwv_flow_imp.id(6273041818275351753)
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel ullamcorper metus. Duis interdum est eu accumsan lobortis. Quisque eu urna a odio feugiat ultrices ac id eros. Donec tristique nulla vitae tortor convallis, in commodo dui fermentu'
||'m. Donec aliquet odio non lacus hendrerit, id elementum augue vehicula. Quisque tincidunt ex mauris. Duis scelerisque congue libero, quis eleifend est vulputate nec. Suspendisse molestie tortor eget malesuada maximus. Aliquam pharetra sem vitae conse'
||'ctetur rhoncus. Ut pharetra, neque ut elementum sagittis, ex ipsum tempus urna, pharetra ultricies justo nunc vel diam. Ut tristique placerat justo, a ornare diam. Fusce at metus id turpis bibendum ornare. Maecenas gravida nibh eu nibh eleifend, ac s'
||'ollicitudin ante lobortis. Donec non erat feugiat, auctor nunc sed, laoreet orci.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6273043139264352909)
,p_plug_name=>'Fixed Height Popup'
,p_region_name=>'dialog_fixed'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>70
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>'In its Template Options, uncheck "Auto Height" and pick a dialog size from the select list.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10714877619144422753)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10714877885951425745)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>An <strong>inline popup</strong> displays a region on the current page within a small popup component. It is similar to a dialog, however does not have a header bar, title, or close button. </p>',
'<p class="dm-Hero-steps">Create a region, set its "Position" attribute to Inline Dialogs, and use <strong>Inline Popup</strong> as its Region template.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13564367930437758659)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2226796235237421233)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6273039269537339652)
,p_button_name=>'OPEN_AUTO_SIZE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Inline Popup with Auto Size'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2226796670834421236)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6273039269537339652)
,p_button_name=>'OPEN_FIXED'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Inline Popup with Fixed Size'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2408037747997851207)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(6273039269537339652)
,p_button_name=>'OPEN_CALLOUT'
,p_button_static_id=>'btn_popup_callout'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Inline Popup with Fixed Size'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2226797367277421239)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6273041818275351753)
,p_button_name=>'CANCEL_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'js-close-button'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2226798790383421243)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6273043139264352909)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'js-close-button'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2226797796740421240)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6273041818275351753)
,p_button_name=>'OK_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'OK'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'js-close-button'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2226799129301421244)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6273043139264352909)
,p_button_name=>'OK'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'OK'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'js-close-button'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2408037651152851206)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2408037459361851204)
,p_button_name=>'OK_2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'OK'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'js-close-button'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2199653131501932903)
,p_name=>'Open Auto Size Popup'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2226796235237421233)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2199653291934932904)
,p_event_id=>wwv_flow_imp.id(2199653131501932903)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6273041818275351753)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2199653386897932905)
,p_name=>'Open Fixed Popup'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2226796670834421236)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2199653500523932906)
,p_event_id=>wwv_flow_imp.id(2199653386897932905)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6273043139264352909)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2199653527727932907)
,p_name=>'Close Auto Height Popup on Cancel'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2226797367277421239)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2199653632397932908)
,p_event_id=>wwv_flow_imp.id(2199653527727932907)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6273041818275351753)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1866753877309743086)
,p_name=>'Close Auto Height Popup on Ok'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2226797796740421240)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1866753926378743087)
,p_event_id=>wwv_flow_imp.id(1866753877309743086)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6273041818275351753)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2199653748122932909)
,p_name=>'Close Fixed Popup on Cancel'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2226798790383421243)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2199653819448932910)
,p_event_id=>wwv_flow_imp.id(2199653748122932909)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6273043139264352909)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1866753653356743084)
,p_name=>'Close Fixed Popup on Ok'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2226799129301421244)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1866753700235743085)
,p_event_id=>wwv_flow_imp.id(1866753653356743084)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6273043139264352909)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2408037874339851208)
,p_name=>'Open Inline Popup with Callout'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2408037747997851207)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2408037901733851209)
,p_event_id=>wwv_flow_imp.id(2408037874339851208)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2408037459361851204)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2408038266119851212)
,p_name=>'Close Callout Popup'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2408037651152851206)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2408038378621851213)
,p_event_id=>wwv_flow_imp.id(2408038266119851212)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2408037459361851204)
);
wwv_flow_imp.component_end;
end;
/
