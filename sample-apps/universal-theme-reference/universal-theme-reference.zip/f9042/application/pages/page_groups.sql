prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 9042
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>776266751179078842
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2401837048789160465)
,p_group_name=>'Components'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2555039553786760715)
,p_group_name=>'Design'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2427804786329985320)
,p_group_name=>'Migration Guide'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2710412491289347286)
,p_group_name=>'Tools and Utilities'
);
wwv_flow_imp.component_end;
end;
/
