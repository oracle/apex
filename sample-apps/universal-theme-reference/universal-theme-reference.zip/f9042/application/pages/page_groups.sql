prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 9042
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>2028731318158593
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2405880804828471505)
,p_group_name=>'Components'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2559083309826071755)
,p_group_name=>'Design'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2431848542369296360)
,p_group_name=>'Migration Guide'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2714456247328658326)
,p_group_name=>'Tools and Utilities'
);
wwv_flow_imp.component_end;
end;
/
