prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 9042
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>8200683834871648
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2414081488663343153)
,p_group_name=>'Components'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2567283993660943403)
,p_group_name=>'Design'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2440049226204168008)
,p_group_name=>'Migration Guide'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2722656931163529974)
,p_group_name=>'Tools and Utilities'
);
wwv_flow_imp.component_end;
end;
/
