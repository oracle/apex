prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 9042
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2421696170353883330)
,p_group_name=>'Components'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2574898675351483580)
,p_group_name=>'Design'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2447663907894708185)
,p_group_name=>'Migration Guide'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(2730271612854070151)
,p_group_name=>'Tools and Utilities'
);
wwv_flow_imp.component_end;
end;
/
