prompt --application/pages/page_03004
begin
--   Manifest
--     PAGE: 03004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>776266751179078842
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3004
,p_name=>'Components - Content Row'
,p_alias=>'CONTENT-ROW-COMPONENT'
,p_step_title=>'Content Row - &APP_TITLE.'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'27'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20231003212222'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1733864311776048732)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(5049184617304313885)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'NO'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1733864462589048733)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    <strong>Content Row</strong> is a theme component that is suitable for displaying most types of content. This component features a column for an icon, title and description, miscellaneous attributes, and actions.',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1733864539999048734)
,p_plug_name=>'Instructions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'ContentRowDemo'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1733864663386048735)
,p_plug_name=>'Demo'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1842020967757700156)
,p_plug_name=>'Components - Content Row'
,p_region_name=>'ContentRowDemo'
,p_parent_plug_id=>wwv_flow_imp.id(1733864663386048735)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3918981753866843457)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.ID,',
'       t.PROJECT,',
'       t.PARENT_TASK,',
'       t.TASK_NAME,',
'       t.START_DATE,',
'       t.END_DATE,',
'       t.STATUS,',
'       t.ASSIGNED_TO,',
'       p.project as proj_name,',
'       case t.status',
'         when ''Open''    then ''fa-exclamation-circle-o''',
'         when ''Closed''  then ''fa-check-circle u-success-text''',
'         when ''On-Hold'' then ''fa-minus-circle u-danger-text''',
'         when ''Pending'' then ''fa-exclamation-triangle u-warning-text''',
'       end icon_class',
'  from EBA_UT_CHART_TASKS t,',
'       EBA_UT_CHART_PROJECTS p',
'  where t.project = p.id',
'  order by p.created'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_string.join_clob(wwv_flow_t_varchar2('{',
  '"APPLY_THEME_COLORS": "N",',
  '"AVATAR_ICON": "\u0026ICON_CLASS.",',
  '"AVATAR_SHAPE": "t-Avatar--noShape",',
  '"AVATAR_SIZE": "t-Avatar--sm",',
  '"AVATAR_TYPE": "icon",',
  '"BADGE_COL_WIDTH": "t-ContentRow-badge--md",',
  '"BADGE_LABEL_DISPLAY": "N",',
  '"DESCRIPTION": "Project: \u0026PROJ_NAME.",',
  '"DISPLAY_AVATAR": "Y",',
  '"DISPLAY_BADGE": "N",',
  '"HIDE_BORDERS": "N",',
  '"MISC": "\u0026STATUS.",',
  '"OVERLINE": "Task",',
  '"REMOVE_PADDING": "N",',
  '"TITLE": "\u0026TASK_NAME."',
'}'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1842021427352700160)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_required=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1875924821599204824)
,p_name=>'PROJECT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROJECT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1875925440358204830)
,p_name=>'PARENT_TASK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PARENT_TASK'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1875925557463204831)
,p_name=>'TASK_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TASK_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1875925629288204832)
,p_name=>'START_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'START_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1875925689831204833)
,p_name=>'END_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'END_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>110
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1875925782110204834)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>120
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1875925952932204835)
,p_name=>'ASSIGNED_TO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASSIGNED_TO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>130
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1875926291168204839)
,p_name=>'PROJ_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROJ_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>160
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1875926472011204840)
,p_name=>'ICON_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON_CLASS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>170
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1875924085106204817)
,p_plug_name=>'Configuration'
,p_parent_plug_id=>wwv_flow_imp.id(1733864663386048735)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3212078847484281050)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Region</h4>',
'<strong>Type:</strong> Content Row<br/>',
'<strong>Template</strong> Blank with Attributes (No Grid)<br/>',
'',
'<h4>Attributes</h4>',
'Each row has a <em>Title, Description, Miscellaneous,</em> and <em>Actions</em><br/>',
'',
'<h4>Avatar</h4>',
'<strong>Type:</strong> Icon<br/>',
'<strong>Icon:</strong> <em>the ICON_CLASS column</em><br/>',
'<strong>Shape:</strong> No Shape<br/>',
'<strong>Size:</strong> Small<br/>',
'',
'<h4>Primary Actions</h4>',
'Two actions are in the <strong>Primary Actions</strong> position for each content row item.<br/>',
'The first action uses the <strong>Button</strong> template, with <em>Display Type</em> set to Icon and the <em>Icon</em> and <em>Hot</em> properties set.<br/>',
'The second action uses the <strong>Menu</strong> template, and has three sub actions: Create, Duplicate, amd Delete.'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1842020322879700154)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3079207278690065424)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3722706651486710750)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(4620107297425992659)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1875926665838204842)
,p_plug_name=>'Sample SQL Query'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--lightBG:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.REGION_SOURCE_CODE'
,p_attribute_01=>'ContentRowDemo'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(1875924232534204818)
,p_region_id=>wwv_flow_imp.id(1842020967757700156)
,p_position_id=>wwv_flow_imp.id(3648540058849718187)
,p_display_sequence=>10
,p_template_id=>wwv_flow_imp.id(3648540660526749316)
,p_label=>'Edit'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-edit'
,p_is_hot=>true
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(1875924329284204819)
,p_region_id=>wwv_flow_imp.id(1842020967757700156)
,p_position_id=>wwv_flow_imp.id(3648540058849718187)
,p_display_sequence=>20
,p_template_id=>wwv_flow_imp.id(3648541920046753464)
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(1875924461786204820)
,p_component_action_id=>wwv_flow_imp.id(1875924329284204819)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Create'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(1875924552682204821)
,p_component_action_id=>wwv_flow_imp.id(1875924329284204819)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Duplicate'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_icon_css_classes=>'fa-clone'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(1875924640410204822)
,p_component_action_id=>wwv_flow_imp.id(1875924329284204819)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Delete'
,p_display_sequence=>40
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_icon_css_classes=>'fa-trash-o'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(1875924758506204823)
,p_component_action_id=>wwv_flow_imp.id(1875924329284204819)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>30
);
wwv_flow_imp.component_end;
end;
/
