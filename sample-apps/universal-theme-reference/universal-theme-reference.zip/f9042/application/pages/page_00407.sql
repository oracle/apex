prompt --application/pages/page_00407
begin
--   Manifest
--     PAGE: 00407
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-16'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>407
,p_user_interface_id=>wwv_flow_imp.id(1319173717720724629)
,p_name=>'Navigation'
,p_alias=>'NAVIGATION'
,p_step_title=>'Navigation - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(1056168381265014818)
,p_step_template=>wwv_flow_imp.id(3121228739815246741)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
,p_last_upd_yyyymmddhh24miss=>'20220225144709'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1323176065228163057)
,p_plug_name=>'Menu Bar'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>The <b>Top Navigation Menu</b> template renders your application navigation as a menu bar, similar to what you find on most desktop applications. This is commonly used for more complex applications with several layers of hierarchy within the navig'
||'ation.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1323176138711163058)
,p_plug_name=>'Tabs'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The <b>Top Navigation Tabs</b> template renders your application navigation as tabs and is ideally suited for simple applications where you have approximately 6 or fewer tabs.</p>',
'',
'<p>This navigation template will automatically be positioned to the bottom of the screen for small screen or mobile devices so it is more comfortable to access.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1323176284345163059)
,p_plug_name=>'Mega Menu'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The <b>Top Navigation Mega Menu</b> template renders your application navigation in a popup panel that can be opened or closed from the header menu button.</p>',
'<p>Mega menus are especially useful when you want to display all navigation items at once to your user, and is a very common pattern you will see across the web.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1323176373431163060)
,p_plug_name=>'Side Tree Navigation'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>The <b>Side Navigation Menu</b> template renders your application navigation in a collapsible side panel. The navigation items are rendered as tree nodes that can be expanded.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2013322539426211348)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Navigation is an important part of your application and can determine the how your users navigate within your application.  There are two navigation concepts that are key for Universal Theme: Navigation Menus and Navigation Bar.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2013322629665211349)
,p_plug_name=>'Navigation Menus'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The primary navigation structure for your application is defined as a <b>Navigation Menu</b> and is based on the <b>List</b> component in APEX. Navigation Menus are hierarchical and can be any level deep.  This navigation control and can be both d'
||'ynamic (based on a query), or static (based on static list entries).  In addition, you can choose to position your navigation to the top or side of your screen.</p>',
'',
'<p>To change your application''s Navigation Menu settings, navigate to Shared Components &rarr; User Interface Defaults and then click on the edit icon next to the Desktop User Interface. From here, you can navigate to the Navigation Menu region and c'
||'hange the options listed.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2013322789484211350)
,p_plug_name=>'Navigation Bar'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The Navigation Bar is positioned near the end of the application''s header, and typically contains links for user authentication, help, feedback, and other global items.</p>',
'',
'<p>Navigation Bars are also based on the <b>List</b> component in APEX. However, as of APEX 5.1, you may only have a two-level deep menu.</p>',
'',
'<p>To change your application''s Navigation Bar settings, navigate to Shared Components &rarr; User Interface Defaults and then click on the edit icon next to the Desktop User Interface. From here, you can navigate to the Navigation Bar region and cha'
||'nge the options listed.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5658090578676154659)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3121236124904246762)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1323176434821163061)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1323176065228163057)
,p_button_name=>'OPEN_PREVIEW_MENU_BAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(1131702324492887059)
,p_button_image_alt=>'View'
,p_button_position=>'CHANGE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1323176750650163064)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1323176138711163058)
,p_button_name=>'OPEN_PREVIEW_TABS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(1131702324492887059)
,p_button_image_alt=>'View'
,p_button_position=>'CHANGE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1323177029077163067)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1323176284345163059)
,p_button_name=>'OPEN_PREVIEW_MEGA_MENU'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(1131702324492887059)
,p_button_image_alt=>'View'
,p_button_position=>'CHANGE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1323177347438163070)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1323176373431163060)
,p_button_name=>'OPEN_PREVIEW_SIDE_TREE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(1131702324492887059)
,p_button_image_alt=>'View'
,p_button_position=>'CHANGE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1323176521577163062)
,p_name=>'Menu Bar Preview'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1323176434821163061)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1323176648481163063)
,p_event_id=>wwv_flow_imp.id(1323176521577163062)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1120:&APP_SESSION.'',''Menu Bar Preview'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1323176883876163065)
,p_name=>'Tabs Preview'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1323176750650163064)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1323176945874163066)
,p_event_id=>wwv_flow_imp.id(1323176883876163065)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1121:&APP_SESSION.'',''Tabs Preview'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1323177124665163068)
,p_name=>'Mega Menu Preview'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1323177029077163067)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1323177285046163069)
,p_event_id=>wwv_flow_imp.id(1323177124665163068)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1122:&APP_SESSION.'',''Mega Menu Preview'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1323177450544163071)
,p_name=>'Side Nav Preview'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1323177347438163070)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1323177522336163072)
,p_event_id=>wwv_flow_imp.id(1323177450544163071)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1123:&APP_SESSION.'',''Side Navigation Menu Preview'');'
);
wwv_flow_imp.component_end;
end;
/
