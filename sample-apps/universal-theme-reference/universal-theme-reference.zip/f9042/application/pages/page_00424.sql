prompt --application/pages/page_00424
begin
--   Manifest
--     PAGE: 00424
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>424
,p_user_interface_id=>wwv_flow_imp.id(1319173717720724629)
,p_name=>'Touch Gestures'
,p_alias=>'TOUCH-GESTURES'
,p_step_title=>'Touch Gestures'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(1056168381265014818)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.touch-region {',
'  -webkit-user-select: none;',
'     -moz-user-select: none;',
'      -ms-user-select: none;',
'          user-select: none; }',
'',
'.touch-region .anim-icon {',
'  height: 8rem;',
'  border-radius: var(--ut-comonent-border-radius, 0.125rem);',
'  background-color: rgba(255, 239, 94, 0.25);',
'  box-shadow: 0 0 0 1px var(--ut-comonent-border-color, rgba(0, 0, 0, 0.05)) inset;',
'  width: 100%;',
'  display: flex;',
'  align-items: center;',
'  justify-content: center;',
'  flex-direction: column;',
'  position: relative;',
'  overflow: hidden; }',
'',
'.js-event-icon {',
'  width: 3rem;',
'  height: 3rem;',
'  line-height: 3rem;',
'  text-align: center;',
'  border-radius: 100%;',
'  background-color: var(--ut-palette-primary, #3170C8);',
'  color: var(--ut-palette-primary-contrast, #FFF);',
'  transition: .2s transform ease; }',
'',
'.js-event-text {',
'  font-family: monospace; }',
'',
'.touch-region.is-active .anim-icon .fa {',
'  -webkit-animation: touch-active .5s forwards ease;',
'          animation: touch-active .5s forwards ease; }',
'',
'@-webkit-keyframes touch-active {',
'  0% {',
'    transform: scale(1) rotate(0deg); }',
'  10% {',
'    transform: scale(0.85) rotate(50deg); }',
'  50% {',
'    transform: scale(1.5) rotate(90deg); }',
'  100% {',
'    transform: scale(1) rotate(0deg); } }',
'',
'@keyframes touch-active {',
'  0% {',
'    transform: scale(1) rotate(0deg); }',
'  10% {',
'    transform: scale(0.85) rotate(50deg); }',
'  50% {',
'    transform: scale(1.5) rotate(90deg); }',
'  100% {',
'    transform: scale(1) rotate(0deg); } }'))
,p_step_template=>wwv_flow_imp.id(3121228739815246741)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
,p_last_upd_yyyymmddhh24miss=>'20220225144709'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1288188199412800661)
,p_plug_name=>'Press'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1288188373018800662)
,p_plug_name=>'Touch Region'
,p_region_name=>'press_region'
,p_parent_plug_id=>wwv_flow_imp.id(1288188199412800661)
,p_region_css_classes=>'touch-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2420110581345097560)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="anim-icon">',
'<span class="fa fa-hand-pointer-o fa-lg js-event-icon" aria-hidden="true"></span> <span class="js-event-text">Press me!</span>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1288188466459800663)
,p_plug_name=>'Details'
,p_parent_plug_id=>wwv_flow_imp.id(1288188199412800661)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2420110581345097560)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><b>Notable <code>press</code> event data</b></p>',
'<ul>',
'  <li><code>this.data.pointerType</code> type of pointer (mouse or touch)</li>',
'</ul>',
'<p>Note: <code>press</code> events can also be triggered by clicking and holding</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1288188579349800664)
,p_plug_name=>'Swipe'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1288188600243800665)
,p_plug_name=>'Touch Region'
,p_region_name=>'swipe_region'
,p_parent_plug_id=>wwv_flow_imp.id(1288188579349800664)
,p_region_css_classes=>'touch-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2420110581345097560)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="anim-icon">',
'<span class="fa fa-hand-pointer-o fa-lg js-event-icon" aria-hidden="true"></span> <span class="js-event-text">Swipe me!</span>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1288188717171800666)
,p_plug_name=>'Details'
,p_parent_plug_id=>wwv_flow_imp.id(1288188579349800664)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2420110581345097560)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><b>Notable <code>swipe</code> event data</b></p>',
'<ul>',
'  <li><code>this.data.offsetDirection</code> swipe direction (2 left, 4 right)</li>',
'  <li><code>this.data.distance</code> distance of the swipe gesture</li>',
'  <li><code>this.data.pointerType</code> type of pointer (mouse or touch)</li>',
'</ul>',
'<p>Note: <code>swipe</code> events can also be triggered by clicking and quickly moving the cursor to the right or left</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1288188892529800667)
,p_plug_name=>'Pan'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1288188918104800668)
,p_plug_name=>'Touch Region'
,p_region_name=>'pan_region'
,p_parent_plug_id=>wwv_flow_imp.id(1288188892529800667)
,p_region_css_classes=>'touch-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2420110581345097560)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="anim-icon">',
'<span class="fa fa-hand-pointer-o fa-lg js-event-icon" aria-hidden="true"></span> <span class="js-event-text">Pan me!</span>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1288189023033800669)
,p_plug_name=>'Details'
,p_parent_plug_id=>wwv_flow_imp.id(1288188892529800667)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2420110581345097560)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><b>Notable <code>pan</code> event data</b></p>',
'<ul>',
'  <li><code>this.data.offsetDirection</code> swipe direction (2 left, 4 right, 8 up, 16 down)</li>',
'  <li><code>this.data.isFinal</code> returns <code>true</code> if it is the last input</li>',
'  <li><code>this.data.pointerType</code> type of pointer (mouse or touch)</li>',
'</ul>',
'<p>Note: <code>pan</code> events can also be triggered by clicking and dragging</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2011426404051990231)
,p_plug_name=>'Tap'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1266243856525788062)
,p_plug_name=>'Touch Region'
,p_region_name=>'tap_region'
,p_parent_plug_id=>wwv_flow_imp.id(2011426404051990231)
,p_region_css_classes=>'touch-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2420110581345097560)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="anim-icon">',
'<span class="fa fa-hand-pointer-o fa-lg js-event-icon" aria-hidden="true"></span> <span class="js-event-text">Tap me!</span>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1266243928711788063)
,p_plug_name=>'Details'
,p_parent_plug_id=>wwv_flow_imp.id(2011426404051990231)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2420110581345097560)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><b>Notable <code>tap</code> event data</b></p>',
'<ul>',
'  <li><code>this.data.tapCount</code> number of times the screen was tapped</li>',
'  <li><code>this.data.pointerType</code> type of pointer (mouse or touch)</li>',
'</ul>',
'<p>Note: <code>tap</code> events can also be triggered by clicking</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3366260234774784973)
,p_plug_name=>'Available Gestures'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>APEX 18.1 provides declarative support for the following touch gestures via Dynamic Actions:</p>',
'',
'<ul>',
'  <li>tap and double tap</li>',
'  <li>press</li>',
'  <li>swipe</li>',
'  <li>pan</li>',
'</ul>',
'',
'<p>Note: While APEX wraps these touch events to make them accessible via Dynamic Actions, the underlying touch support is powered using the <a href="http://hammerjs.github.io/" target="_blank">hammer.js</a> library.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5740051002212680503)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3121236124904246762)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7159685064987659192)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Adding touch support to your APEX apps help provide an improved and more natural mobile experience. This is especially important if your apps are more likely to be used on touch devices, such as smartphones or tablest. This page walks you through '
||'how you can use declarative touch events, introduced in APEX 18.1, to build touch friendly UIs.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1254599317767716285)
,p_name=>'Tap'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1266243856525788062)
,p_bind_type=>'bind'
,p_bind_event_type=>'apextap'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1254599492692716286)
,p_event_id=>wwv_flow_imp.id(1254599317767716285)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var tapCount = this.data.tapCount;',
'var touchRegion$ = $(this.triggeringElement);',
'touchRegion$.find(".js-event-text").text("Tapped " + tapCount + " times!");',
'',
'var animationEvent = ''webkitAnimationEnd oanimationend msAnimationEnd animationend'';',
'touchRegion$.addClass(''is-active'');',
'touchRegion$.one(animationEvent, function(event) {',
'    touchRegion$.removeClass(''is-active'');',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1254599738583716289)
,p_name=>'Press'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1288188373018800662)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexpress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1254599855540716290)
,p_event_id=>wwv_flow_imp.id(1254599738583716289)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var touchRegion$ = $(this.triggeringElement);',
'touchRegion$.find(".js-event-text").text("Pressed!");',
'',
'var animationEvent = ''webkitAnimationEnd oanimationend msAnimationEnd animationend'';',
'',
'touchRegion$.addClass(''is-active'');',
'touchRegion$.find(".js-event-icon").removeClass("fa-hand-pointer-o").addClass("fa-hand-grab-o");',
'touchRegion$.one(animationEvent, function(event) {',
'    touchRegion$.removeClass(''is-active'').find(".js-event-icon").addClass("fa-hand-pointer-o").removeClass("fa-hand-grab-o");',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1266242647656788050)
,p_name=>'Swipe'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1288188600243800665)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexswipe'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1266242717303788051)
,p_event_id=>wwv_flow_imp.id(1266242647656788050)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var touchRegion$ = $(this.triggeringElement);',
'var text$ = touchRegion$.find(".js-event-text");',
'var icon$ = touchRegion$.find(".js-event-icon");',
'var swipeDir = this.data.offsetDirection;',
'',
'var message, icon;',
'',
'if (swipeDir === 2) {',
'    message = ''Swiped Left!''',
'    icon = ''fa-hand-o-left''',
'} else if (swipeDir === 4) {',
'    message = ''Swiped Right!''',
'    icon = ''fa-hand-o-right''',
'}',
'',
'text$.text(message);',
'',
'icon$.removeClass("fa-hand-pointer-o fa-hand-o-right fa-hand-o-left").addClass(icon);',
'var animationEvent = ''webkitAnimationEnd oanimationend msAnimationEnd animationend'';',
'touchRegion$.addClass(''is-active'');',
'touchRegion$.one(animationEvent, function(event) {',
'    touchRegion$.removeClass(''is-active'');',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1266242819244788052)
,p_name=>'Pan'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1288188918104800668)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexpan'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1266242969293788053)
,p_event_id=>wwv_flow_imp.id(1266242819244788052)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var touchRegion$ = $(this.triggeringElement);',
'var text$ = touchRegion$.find(".js-event-text");',
'var icon$ = touchRegion$.find(".js-event-icon");',
'var swipeDir = this.data.offsetDirection;',
'',
'var offsetX = (touchRegion$.outerWidth() / 2) - 24;',
'',
'var message, icon;',
'',
'if (swipeDir === 2) {',
'    message = ''Panning Left!''',
'    icon = ''fa-hand-o-left''',
'} else if (swipeDir === 4) {',
'    message = ''Panning Right!''',
'    icon = ''fa-hand-o-right''',
'}',
'',
'if (this.data.isFinal ) {',
'    icon$.css("position","static");',
'} else {',
'    icon$.css({',
'        position: "absolute",',
'        left: this.data.deltaX + offsetX',
'    })',
'}',
'',
'// reset icon after 1000 ms',
'setTimeout(function(){',
'    icon$.css("position","static");',
'}, 1000);',
'',
'text$.text(message);',
'icon$.removeClass("fa-hand-pointer-o fa-hand-o-right fa-hand-o-left fa-hand-o-up fa-hand-o-down").addClass(icon);'))
);
wwv_flow_imp.component_end;
end;
/
