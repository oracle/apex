prompt --application/pages/page_00405
begin
--   Manifest
--     PAGE: 00405
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>405
,p_user_interface_id=>wwv_flow_imp.id(1319173717720724629)
,p_name=>'Theme Styles'
,p_alias=>'THEME-STYLES'
,p_step_title=>'Theme Styles'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'[aria-describedby="TSInstructions"] {',
'    max-width:90%!important;',
'    width: 1400px!important;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'VMORNEAU'
,p_last_upd_yyyymmddhh24miss=>'20220504052403'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(250050360406404011)
,p_plug_name=>'Official Theme Styles'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Here are the official <strong>Theme Styles</strong> for Oracle APEX.</p>',
'<p>These <strong>Theme Styles</strong> are part of the official Oracle APEX release and are maintained and supported by our team.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(497924671605826475)
,p_plug_name=>'Official Theme Styles Cards'
,p_parent_plug_id=>wwv_flow_imp.id(250050360406404011)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1121597295029327180)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select s.name,',
'       case ',
'        when :P0_THEME_STYLE_ID is not null and s.theme_style_id = :P0_THEME_STYLE_ID then ''Current'' ',
'        when :P0_THEME_STYLE_ID is null and s.is_current = ''Yes'' then ''Current'' ',
'       end as badge,',
'       s.theme_style_id,',
'       ''#APP_FILES#theme_styles/''||replace(lower(s.name), '' '', ''-'')||''.png'' image,',
'       ''javascript:apex.page.submit( { request: ''''APPLY_THEME_STYLE'''', set: { ''''P0_THEME_STYLE_ID'''': '''''' || s.theme_style_id || '''''' }, showWait: true } );'' javascript',
'  from apex_application_theme_styles s, ',
'       apex_application_themes t',
' where s.application_id = t.application_id',
'   and s.theme_number   = t.theme_number',
'   and s.application_id = :app_id',
'   and t.ui_type_name   = ''DESKTOP''',
'   and t.is_current     = ''Yes''',
'   and s.theme_roller_output_file_url like ''%THEME_FILES%'' -- custom theme style',
' order by case when s.name like ''%Redwood%'' then 2 else 1 end, s.name'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(497925116386826468)
,p_region_id=>wwv_flow_imp.id(497924671605826475)
,p_layout_type=>'GRID'
,p_grid_column_count=>3
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'BADGE'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'IMAGE'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(497929031824665906)
,p_card_id=>wwv_flow_imp.id(497925116386826468)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Live Preview'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'&JAVASCRIPT.'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(250050591628404013)
,p_plug_name=>'Sample Theme Styles'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Here are a few of sample <strong>Theme Styles</strong> to showcase what can be done with <strong>Theme Roller</strong></p>',
'<p>These <strong>Theme Styles</strong> are here for demo purposes and are subject to change with new Oracle APEX releases.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(497929335191665909)
,p_plug_name=>'Sample Theme Styles Cards'
,p_parent_plug_id=>wwv_flow_imp.id(250050591628404013)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1121597295029327180)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select s.name,',
'       case ',
'        when :P0_THEME_STYLE_ID is not null and s.theme_style_id = :P0_THEME_STYLE_ID then ''Current'' ',
'        when :P0_THEME_STYLE_ID is null and s.is_current = ''Yes'' then ''Current'' ',
'       end as badge,',
'       s.theme_style_id,',
'       ''#APP_FILES#theme_styles/''||replace(lower( regexp_replace(decompose( s.name ), unistr(''[\0300-\036F]''), null) ), '' '', ''-'')||''.png'' image,',
'       ''javascript:apex.page.submit( { request: ''''APPLY_THEME_STYLE'''', set: { ''''P0_THEME_STYLE_ID'''': '''''' || s.theme_style_id || '''''' }, showWait: true } );'' javascript',
'  from apex_application_theme_styles s, ',
'       apex_application_themes t',
' where s.application_id = t.application_id',
'   and s.theme_number   = t.theme_number',
'   and s.application_id = :app_id',
'   and t.ui_type_name   = ''DESKTOP''',
'   and t.is_current     = ''Yes''',
'   and s.theme_roller_output_file_url like ''%THEME_DB_FILES%'' -- custom theme style',
' order by s.name'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(497929533073665911)
,p_region_id=>wwv_flow_imp.id(497929335191665909)
,p_layout_type=>'GRID'
,p_grid_column_count=>3
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'BADGE'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'IMAGE'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(497929649875665912)
,p_card_id=>wwv_flow_imp.id(497929533073665911)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Live Preview'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'&JAVASCRIPT.'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(299232922415955713)
,p_card_id=>wwv_flow_imp.id(497929533073665911)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'Instructions'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'javascript:apex.event.trigger(document, ''openInstructions'', { themeStyleId: ''&THEME_STYLE_ID.'' })'
,p_button_display_type=>'TEXT'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(250669840807690977)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1580336106168319527)
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3121236124904246762)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(299233090843955714)
,p_name=>'Using this theme style'
,p_region_name=>'TSInstructions'
,p_template=>wwv_flow_imp.id(1721546526220724199)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:t-DialogRegion--noPadding:js-dialog-size720x480'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--inline:t-Report--hideNoPagination'
,p_display_point=>'REGION_POSITION_04'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''<strong>1.</strong> Log in to your APEX workspace to activate a developer session'' d from dual union all',
'select ''<strong>2.</strong> Run your application on any page'' d from dual union all',
'select ''<strong>3.</strong> Open Theme Roller using the APEX Developer Toolbar'' d from dual union all',
'select ''<strong>4.</strong> Open your browser developer console'' d from dual union all',
'select ''<strong>5.</strong> Run the following code <button type="button" title="Copy Theme Style Code" class="t-Button t-Button--icon t-Button--tiny t-Button--link t-Button--iconLeft" data-clipboard-source="#utrcode"><span aria-hidden="true" class="t'
||'-Icon t-Icon--left fa fa-synonym"></span>Copy</button> <pre style="white-space: normal; font-size: .65rem;"><code id="utrcode" style="white-space: normal; font-size: .65rem;">apex.utr.config(''||(select to_char(theme_roller_config) from apex_applicati'
||'on_theme_styles where theme_style_id = :p405_theme_style_id)||'');</code></pre>'' d from dual union all',
'select ''<strong>6.</strong> The Theme Style will be applied to the current page'' d from dual union all',
'select ''<strong>7.</strong> Use Save As and give a name to this new theme style'' d from dual'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P405_THEME_STYLE_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(1587527120172475108)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(299233504021955719)
,p_query_column_id=>1
,p_column_alias=>'D'
,p_column_display_sequence=>10
,p_column_heading=>'D'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(300686546012392105)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3550313444782567988)
,p_plug_display_sequence=>11
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3810080523223105699)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Using <strong>Theme Roller</strong> you can create <strong>Theme Styles</strong> to customize the UI of your application in more than a few creative ways.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(299233766893955721)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(299233090843955714)
,p_button_name=>'CLOSE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3121235740369246759)
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(299233315639955717)
,p_name=>'P405_THEME_STYLE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(299233090843955714)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(299233189136955715)
,p_name=>'customEvent openInstructions'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'openInstructions'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(299233433152955718)
,p_event_id=>wwv_flow_imp.id(299233189136955715)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P405_THEME_STYLE_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.themeStyleId'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(299233697723955720)
,p_event_id=>wwv_flow_imp.id(299233189136955715)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(299233090843955714)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(299233268232955716)
,p_event_id=>wwv_flow_imp.id(299233189136955715)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(299233090843955714)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(299233848589955722)
,p_name=>'onClick CLOSE'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(299233766893955721)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(299233951213955723)
,p_event_id=>wwv_flow_imp.id(299233848589955722)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(299233090843955714)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11786461669314005)
,p_name=>'afterRefresh Using this theme style'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(299233090843955714)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11786532709314006)
,p_event_id=>wwv_flow_imp.id(11786461669314005)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$( "[data-clipboard-source]", apex.gPageContext$ ).each( function() {',
'    const trigger$ = $( this );',
'    const source = trigger$.attr( "data-clipboard-source" );',
'    apex.clipboard.addElement( $(source)[0], trigger$[0] );',
'} );'))
);
wwv_flow_imp.component_end;
end;
/
