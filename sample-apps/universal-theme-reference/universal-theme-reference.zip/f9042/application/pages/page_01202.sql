prompt --application/pages/page_01202
begin
--   Manifest
--     PAGE: 01202
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>776266751179078842
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1202
,p_name=>'Region - Alert'
,p_alias=>'ALERT-REGION'
,p_step_title=>'Alert - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(2401837048789160465)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
,p_last_updated_by=>'PAIGE'
,p_last_upd_yyyymmddhh24miss=>'20230505215023'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1746459646770858536)
,p_plug_name=>'Instructions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--shadowBG:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'AlertDemo1'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2401802593013005905)
,p_plug_name=>'Button Positions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2401803101630005907)
,p_plug_name=>'Alert Region with Buttons'
,p_parent_plug_id=>wwv_flow_imp.id(2401802593013005905)
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--success'
,p_plug_template=>wwv_flow_imp.id(2588427400956124082)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<p>Your request has been submitted successfully. Please check again later in 30 minutes.</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2401805193470005909)
,p_plug_name=>'Use Cases'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2427673455043296057)
,p_plug_name=>'Order Created Successfully'
,p_parent_plug_id=>wwv_flow_imp.id(2401805193470005909)
,p_icon_css_classes=>'fa-check-circle'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--wizard:t-Alert--customIcons:t-Alert--success'
,p_plug_template=>wwv_flow_imp.id(2588427400956124082)
,p_plug_display_sequence=>180
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<p>A confirmation email has been sent to you. This order will be delivered in one week.</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2427673750032296060)
,p_plug_name=>'Access Denied'
,p_parent_plug_id=>wwv_flow_imp.id(2401805193470005909)
,p_icon_css_classes=>'fa-warning'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--wizard:t-Alert--customIcons:t-Alert--danger'
,p_plug_template=>wwv_flow_imp.id(2588427400956124082)
,p_plug_display_sequence=>190
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<p>You have insufficient privilege. Please contact your Administrator for more information.</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2401806243565005910)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Use the Alert region template to display alerts, confirmations, and other action-oriented messages within the context of a page.</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2401806765451005910)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3079207278690065424)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3722706651486710750)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(4620107297425992659)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2401807217695005911)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(5049184617304313885)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'NO'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2401807753337005911)
,p_plug_name=>'Demo'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1764540134839002620)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_imp.id(2401807753337005911)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'
,p_landmark_label=>'Default Template Options'
,p_attribute_01=>'REGION'
,p_attribute_02=>'AlertDemo1'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1764540219162002621)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_imp.id(2401807753337005911)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'
,p_landmark_label=>'Custom Icon Template Options'
,p_attribute_01=>'REGION'
,p_attribute_02=>'AlertDemo2'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2401808244332005911)
,p_plug_name=>'Default'
,p_parent_plug_id=>wwv_flow_imp.id(2401807753337005911)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2401808758593005912)
,p_plug_name=>'Alert Region'
,p_region_name=>'AlertDemo1'
,p_parent_plug_id=>wwv_flow_imp.id(2401808244332005911)
,p_region_template_options=>'#DEFAULT#:t-Alert--defaultIcons:t-Alert--warning:t-Alert--horizontal'
,p_plug_template=>wwv_flow_imp.id(2588427400956124082)
,p_plug_display_sequence=>140
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Region Body'
,p_landmark_label=>'Default Example'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2401811240482005915)
,p_plug_name=>'Custom Icon'
,p_parent_plug_id=>wwv_flow_imp.id(2401807753337005911)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>50
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2401812265429005916)
,p_plug_name=>'Alert Region'
,p_region_name=>'AlertDemo2'
,p_parent_plug_id=>wwv_flow_imp.id(2401811240482005915)
,p_icon_css_classes=>'fa-cog'
,p_region_template_options=>'#DEFAULT#:t-Alert--customIcons:t-Alert--info:t-Alert--wizard'
,p_plug_template=>wwv_flow_imp.id(2588427400956124082)
,p_plug_display_sequence=>200
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Region Body'
,p_landmark_label=>'Custom Icon Example'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2401803537843005907)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(2401803101630005907)
,p_button_name=>'Close'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(4620106912890992656)
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2401803901268005907)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2401803101630005907)
,p_button_name=>'Create'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(4620106912890992656)
,p_button_image_alt=>'Create'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2427673580642296059)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2427673455043296057)
,p_button_name=>'Continue'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(4620106912890992656)
,p_button_image_alt=>'Continue Shopping'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2427673786154296061)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2427673750032296060)
,p_button_name=>'Contact'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(2630573497014632956)
,p_button_image_alt=>'Contact Administrator'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2427673500651296058)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2427673455043296057)
,p_button_name=>'View'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(2630573497014632956)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'View Order'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2401804270964005908)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(2401803101630005907)
,p_button_name=>'Next'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(4620106912890992656)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2401804704620005908)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(2401803101630005907)
,p_button_name=>'Previous'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(4620106912890992656)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp.component_end;
end;
/
