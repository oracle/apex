prompt --application/pages/page_06305
begin
--   Manifest
--     PAGE: 06305
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6305
,p_user_interface_id=>wwv_flow_imp.id(1319173717720724629)
,p_name=>'Change Log'
,p_alias=>'CHANGE-LOG'
,p_step_title=>'Change Log - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(1211541318767601389)
,p_step_template=>wwv_flow_imp.id(3121228739815246741)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
,p_last_updated_by=>'SHAKEEB'
,p_last_upd_yyyymmddhh24miss=>'20220407063116'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11787942636314020)
,p_plug_name=>'21.2'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>Template Changes</h3>',
'',
'<ul>',
'<li><strong>New Inline Drawer region template</strong></li>',
'<li><strong>New Drawer page template</strong></li>',
'<li>Misc Accessibility changes</li>',
'<li>Added aria-current to list templates where needed</li>',
'<li>Collapsible region now uses a button wrapping the region title, faux button to keep current behavior/styles</li>',
'<li>Title Bar region updated to use &lt;nav&gt;</li>',
'<li>Button container removed region title from &lt;h1&gt; this is now used with aria-label</li>',
'<li>Button template options that hide label more accessible to screen readers</li>',
'<li>Main navigation now correctly sets the side navigation to hidden when collapsed</li>',
'<li>Added aria-hidden="true" to icons in regions</li>',
'<li>Hamburger menu label changed from "Expand / Collapse Navigation" to "Main Navigation"</li>',
'</ul>',
'',
'<h3>Template Options</h3>',
'',
'<ul>',
'<li>Button modifier for hide icon on desktop added</li>',
'<li>Button icon position now defaults to left instead of right</li>',
'<li>Added Dialog Size: None to Inline Dialog (now consistent with Modal Dialog)</li>',
'<li>Added inline scripts to help prevent layout shift on page load</li>',
'<li>Added Smart Filter custom position to Title Bar</li>',
'<li>Added Smart Filter custom position to Hero</li>',
'</ul>',
'',
'<h3>Page Template Changes</h3>',
'',
'<ul>',
'<li><strong>New Position for After Logo</strong></li>',
'<li><strong>New Position for Before Navigation Bar</strong></li>',
'<li><strong>New Position for After Navigation Bar</strong></li>',
'<li>Renamed Content Body to Body</li>',
'<li>Renamed Page Header to Banner</li>',
'<li>Renamed Page Navigation to Top Navigation</li>',
'<li>Renamed Before Content Body to Full Width Content</li>',
'<li>Renamed Inline Dialogs to Dialogs, Drawers and Popups</li>',
'<li>Enabled Items and Buttons in Footer</li>',
'</ul>',
'',
'<h3>CSS Changes</h3>',
'',
'<ul>',
'<li>Header Accent Changed to Primary Accent </li>',
'<li>Header Bottom Border (better support for white header)</li>',
'<li>Header Small Shadow</li>',
'<li>Header buttons removed border and active inner shadow</li>',
'<li>Button Border color changed from rgba(0,0,0,.15) to rgba(0,0,0,.075);</li>',
'<li>Button Box shadow added for normal state</li>',
'<li>Button icon spacing changed from 4px to 6px</li>',
'<li>Region Border radius changed from 2px to 4px</li>',
'<li>Region header buttons right padding changed from 8px to 12px (now consistent with other sides)</li>',
'<li>Region header buttons now have padding on top and bottom so they do not touch large button variations</li>',
'<li>Region Shadow added</li>',
'<li>Alert Shadow added</li>',
'<li>Alert font weight changed from normal to semibold</li>',
'<li>Tabs & RDS active tab font weight changed from normal to semibold</li>',
'<li>Content Block (Light/Shaded) Shadow added</li>',
'<li>Primary color changed to #056AC8</li>',
'<li>Warning color changed to #FFC628</li>',
'<li>Success color changed to #278701</li>',
'<li>Danger color changed to #CB1100</li>',
'<li>Info changed to new primary color</li>',
'<li>Title Bar/Hero font weight changed from normal to semibold</li>',
'<li>Removed DevToolbar button color overrides</li>',
'<li>Added support for reduced motion on dialogs/login split</li>',
'<li>Added spacing between radio/checkbox items</li>',
'<li>Increased spacing between radio/checkbox and label</li>',
'<li>Added custom scrollbar back to Side Navigation</li>',
'<li>Updated focus shadow on TreeNav to be inset</li>',
'<li>Added the ability to enlarge the input-font-size on mobile.</li>',
'<li>Added new variables for breadcrumb links controlled by theme roller</li>',
'<li>Added placeholder styles for Top Navigation Menu (faster loading)</li>',
'</ul>',
'',
'<h3>Bug Fixes</h3>',
'',
'<ul>',
'<li><strong>Hammer.js scoped so native touch gestures will now work across the app. Enabling gestures such as zooming in and out.</strong></li>',
'<li>Hero Body now has grid support</li>',
'<li>Carousel swipe gesture reversed</li>',
'<li>Sidebar Navigation overflow/scroll/focus fixed (Moved overflow back to t-Body-nav from t-TreeNav)</li>',
'<li>Fixed incorrect icon color on fields</li>',
'<li>Fixed breadcrumb region title not displaying inline when shrunk</li>',
'</ul>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(246582062558933126)
,p_plug_name=>'22.1'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>Template Changes</h3>',
'',
'<ul>',
'<li><strong>New Image region template</strong></li>',
'<li>Added support for Region Images in Login Region and Hero Region</li>',
'<li>Added support for custom Background Image using Image Region on Login Page</li>',
'</ul>',
'',
'<h3>Template Options</h3>',
'',
'<ul>',
'<li>Added new modifiers for Image regions</li>',
'<li>Added Legacy "Deferred Rendering" to Pages</li>',
'</ul>',
'',
'<h3>CSS Changes</h3>',
'',
'<ul>',
'<li>Updated Menu Bars render during page load to reduce page flickering</li>',
'<li>Updated Side Navigation to render during page load to reduce page flickering</li>',
'<li>Updated Semi-bold weight to 600 from 500, allowing for thicker type in certain areas</li>',
'<li>Cleaned up Faceted Search spacing and support for new actions menu</li>',
'<li>Minor Redwood Light enhancements</li>',
'</ul>',
'',
'<h3>Bug Fixes</h3>',
'',
'<ul>',
'<li>Fixed checkboxes that would render with different color</li>',
'<li>Fixed layout issue with Cards set to render as Row</li>',
'<li>Fixed where Tabs would display all content during page load</li>',
'<li>Fixed FontAPEX scale modifier classes to work with CSS variables</li>',
'<li>Fixed Standard Region title to wrap text when too long</li>',
'<li>Fixed button colors in Interactive Report and Interactive Grid</li>',
'</ul>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5665774305249891233)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3121236124904246762)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp.component_end;
end;
/
