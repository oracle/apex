prompt --application/pages/page_01413
begin
--   Manifest
--     PAGE: 01413
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1413
,p_name=>'Reports - Search Region'
,p_alias=>'REPORTS-SEARCH-REGION'
,p_step_title=>'Search Region - &APP_TITLE.'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'26'
,p_last_updated_by=>'LEORODRI'
,p_last_upd_yyyymmddhh24miss=>'20221206211821'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133893626339463512)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>A search region allows you to combine data from different search sources. This region allows you to find unrelated information in one place.</p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133893720756463513)
,p_plug_name=>'Demo'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(403977275141701810)
,p_plug_name=>'Search Region'
,p_region_name=>'Demo1'
,p_parent_plug_id=>wwv_flow_imp.id(133893720756463513)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(120112912900666637)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_02=>'N'
,p_attribute_04=>'Y'
,p_attribute_05=>'P1413_SEARCH_FIELD'
,p_attribute_06=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'0'
,p_attribute_13=>'Start typing some text to test the search region.'
,p_attribute_14=>'15'
,p_attribute_15=>'Y'
,p_attribute_16=>'No data found.'
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(639969357735646235)
,p_region_id=>wwv_flow_imp.id(403977275141701810)
,p_search_config_id=>wwv_flow_imp.id(643332474521920620)
,p_use_as_initial_result=>false
,p_display_sequence=>10
,p_name=>'Search2'
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(501735848828130414)
,p_region_id=>wwv_flow_imp.id(403977275141701810)
,p_search_config_id=>wwv_flow_imp.id(503527609819379179)
,p_use_as_initial_result=>false
,p_display_sequence=>20
,p_name=>'Search1'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(654582221865417716)
,p_plug_name=>'Info text'
,p_parent_plug_id=>wwv_flow_imp.id(403977275141701810)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3121231715860246749)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SEARCH_FIELD'
,p_plug_source=>unistr('Try typing \201CData\201D or "Tom Suess"')
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133893822581463514)
,p_plug_name=>'Instructions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--shadowBG:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Demo1'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133893975046463515)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3550313444782567988)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(403976640657701809)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3121236124904246762)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(501736052008130416)
,p_plug_name=>'Template Options'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Demo1'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(501735935727130415)
,p_name=>'P1413_SEARCH_FIELD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(403977275141701810)
,p_item_display_point=>'SEARCH_FIELD'
,p_item_default=>'Work'
,p_prompt=>'Search'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(657994747061339302)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(654582399006417717)
,p_name=>'Refresh Region'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1413_SEARCH_FIELD'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(654582538156417719)
,p_event_id=>wwv_flow_imp.id(654582399006417717)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(403977275141701810)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var input = document.getElementById( "P1413_SEARCH_FIELD" );',
'',
'input.addEventListener("keyup", function(event) {',
'    if (event.keyCode === 13) {',
'        event.preventDefault();',
'        var region = apex.region( "Demo1" );',
'        region.refresh();',
'    }',
'})'))
);
wwv_flow_imp.component_end;
end;
/
