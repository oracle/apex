prompt --application/pages/page_01600
begin
--   Manifest
--     PAGE: 01600
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>776266751179078842
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1600
,p_name=>'Forms'
,p_alias=>'FORMS'
,p_step_title=>'Forms - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.ts-Placeholder {',
'height: 240px;',
'line-height: 240px;',
'text-align: center;',
'background-color: #D0D0D0;',
'color: #404040;',
'border-radius: 2px;',
'margin-bottom: 48px;',
'}',
'.ts-Container {',
'max-width: 1024px;',
'min-height: 50vh;',
'}'))
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'17'
,p_last_updated_by=>'DANIEL'
,p_last_upd_yyyymmddhh24miss=>'20230510171247'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1797051575791040399)
,p_plug_name=>'Region with Items'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>45
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1797051696995040400)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_imp.id(1797051575791040399)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'
,p_landmark_label=>'Region Items Template Options'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Demo1'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1797052007515040403)
,p_plug_name=>'Demo'
,p_region_name=>'Demo1'
,p_parent_plug_id=>wwv_flow_imp.id(1797051575791040399)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_landmark_label=>'Demo Region Items'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1797054051648040423)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(5049184617304313885)
,p_plug_display_sequence=>800
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'NO'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2096133511635821880)
,p_plug_name=>'Floating Labels'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>15
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2096133943359821884)
,p_plug_name=>'Demo'
,p_parent_plug_id=>wwv_flow_imp.id(2096133511635821880)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_landmark_label=>'Demo Floating Labels'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2096135651718821901)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_imp.id(2096133511635821880)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'
,p_landmark_label=>'Template Options Floating Labels'
,p_attribute_01=>'ITEM'
,p_attribute_02=>'P1600_FLOATING'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2772366218495591359)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(2096133511635821880)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_landmark_label=>'Instructions Floating Labels'
,p_attribute_01=>'ITEM'
,p_attribute_02=>'P1600_FLOATING'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2395223817238532111)
,p_plug_name=>'Label Above'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>25
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2395224248962532115)
,p_plug_name=>'Demo'
,p_parent_plug_id=>wwv_flow_imp.id(2395223817238532111)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_landmark_label=>'Demo Label Above'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2395225957321532132)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_imp.id(2395223817238532111)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'
,p_landmark_label=>'Template Options Label Above'
,p_attribute_01=>'ITEM'
,p_attribute_02=>'P1600_ABOVE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3071456524098301590)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(2395223817238532111)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_landmark_label=>'Instructions Label Above'
,p_attribute_01=>'ITEM'
,p_attribute_02=>'P1600_ABOVE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2694319699570215643)
,p_plug_name=>'Label Horizontal'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>35
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2694320131294215647)
,p_plug_name=>'Demo'
,p_parent_plug_id=>wwv_flow_imp.id(2694319699570215643)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_landmark_label=>'Demo Label Horizontal'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2694321839653215664)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_imp.id(2694319699570215643)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'
,p_landmark_label=>'Template Options Label Horizontal'
,p_attribute_01=>'ITEM'
,p_attribute_02=>'P1600_HORIZONTAL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3370552406429985122)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_imp.id(2694319699570215643)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_landmark_label=>'Instructions Label Horizontal'
,p_attribute_01=>'ITEM'
,p_attribute_02=>'P1600_HORIZONTAL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3907579939228355732)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--showBreadcrumb:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_imp.id(3079207278690065424)
,p_plug_display_sequence=>790
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3722706651486710750)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(4620107297425992659)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3907580282203355733)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Universal Theme enables easy form design by allowing developers to declaratively control form layout, field templates, and label column widths. This page introduces you to forms, field templates, and template options.</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1632763979206209401)
,p_name=>'P1600_TEXT_FIELD_WITH_AUTOCOMPLETE'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(1797052007515040403)
,p_prompt=>'Text Field With Autocomplete'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_named_lov=>'FONT_ANIMATIONS'
,p_lov=>'.'||wwv_flow_imp.id(2559510097140187856)||'.'
,p_cSize=>30
,p_colspan=>12
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'7'
,p_attribute_09=>'1'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797051786855040401)
,p_name=>'P1600_TEXT_FIELD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1797052007515040403)
,p_prompt=>'Text Field'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797052429935040407)
,p_name=>'P1600_CHECKBOX_GROUP'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(1797052007515040403)
,p_prompt=>'Checkbox Group'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797052548674040408)
,p_name=>'P1600_COLOR_PICKER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(1797052007515040403)
,p_prompt=>'Color Picker'
,p_display_as=>'NATIVE_COLOR_PICKER'
,p_cSize=>30
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797052623857040409)
,p_name=>'P1600_DATE_PICKER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1797052007515040403)
,p_prompt=>'Date Picker'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797052733921040410)
,p_name=>'P1600_FILE_BROWSE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(1797052007515040403)
,p_prompt=>'File Browse'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797052776873040411)
,p_name=>'P1600_MARKDOWN_EDITOR'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(1797052007515040403)
,p_prompt=>'Markdown Editor'
,p_display_as=>'NATIVE_MARKDOWN_EDITOR'
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'SIMPLE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797052886000040412)
,p_name=>'P1600_NUMBER_FIELD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1797052007515040403)
,p_prompt=>'Number Field'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797052988343040413)
,p_name=>'P1600_PASSWORD'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(1797052007515040403)
,p_prompt=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797053145923040414)
,p_name=>'P1600_PERCENT_GRAPH'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(1797052007515040403)
,p_item_default=>'33'
,p_prompt=>'Percent Graph'
,p_display_as=>'NATIVE_PCT_GRAPH'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797053173871040415)
,p_name=>'P1600_RADIO_GROUP'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(1797052007515040403)
,p_prompt=>'Radio Group'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797053304160040416)
,p_name=>'P1600_SELECT_LIST'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(1797052007515040403)
,p_prompt=>'Select List'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797053447200040417)
,p_name=>'P1600_SWITCH'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(1797052007515040403)
,p_prompt=>'Switch'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797053492118040418)
,p_name=>'P1600_TEXTAREA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1797052007515040403)
,p_prompt=>'Textarea'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797053800807040421)
,p_name=>'P1600_FLOATING'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2096133943359821884)
,p_prompt=>'Text Field'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2156865919583085199)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797053956453040422)
,p_name=>'P1600_ABOVE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2395224248962532115)
,p_prompt=>'Text Field'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(3579305618860901738)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1797054176058040425)
,p_name=>'P1600_HORIZONTAL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2694320131294215647)
,p_prompt=>'Text Field'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(2866344966928739864)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp.component_end;
end;
/
