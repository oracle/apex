prompt --application/pages/page_06303
begin
--   Manifest
--     PAGE: 06303
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-16'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6303
,p_user_interface_id=>wwv_flow_imp.id(1319173717720724629)
,p_name=>'Layout Modifiers'
,p_alias=>'LAYOUT-MODIFIERS'
,p_step_title=>'Layout Modifiers - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.class,',
'.class-value,',
'.class-desc {',
'    display: inline-block;',
'    font-size: 12px;',
'    font-family: ''Menlo'',''Consolas'',monospace;',
'}',
'.class {',
'    color: #9C27B0;',
'}',
'.class.tag {',
'    padding: 4px 8px;',
'    background-color: #FFF;',
'    border-radius: 2px;',
'    box-shadow: inset rgba(225, 190, 231, .25) 0 0 0 1px;',
'}',
'.class-value {',
'    color: #008676;',
'    min-width: 40px;',
'}',
'.class-var {',
'    font-weight: bold;',
'    color: #008676;',
'}',
'.dm-Report--doc {',
'    background: #FFF;',
'    border: 1px solid rgba(0,0,0,.05);',
'}',
'.dm-Report--doc th, ',
'.dm-Report--doc td {',
'    padding: 8px;',
'    min-height: 32px;',
'    background-color: transparent;',
'    border-width: 0 0 1px 0;',
'    border-style: solid;',
'    border-color: rgba(0,0,0,.05);',
'}',
'.dm-Report--doc td {',
'    vertical-align: top;',
'}',
'.dm-Report--doc tr:last-child td {',
'    border-bottom-width: 0;',
'}',
'.dm-Report--doc .class {',
'    min-width: 40px;',
'}',
'.dm-Report--doc .class-desc {',
'    width: 48px;',
'    text-align: right;',
'    color: rgba(0,0,0,.55);',
'    border-radius: 2px;',
'}',
'.dm-Code {',
'    border-radius: var(--ut-component-border-radius);',
'    border: var(--ut-component-border-width) solid var(--ut-component-border-color);',
'}'))
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
,p_last_updated_by=>'PAIGE'
,p_last_upd_yyyymmddhh24miss=>'20220412143650'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083478941181047101)
,p_plug_name=>'Floats'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>To float an element, you can use the <span class="class tag">u-pull<span class="class-var">Direction</span></span> utility classes.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1581066176776072208)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_imp.id(1083478941181047101)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-pull<span class="class-value">Left</span></span></td><td>Float to left</td></tr>',
'    <tr><td><span class="class">u-pull<span class="class-value">Right</span></span></td><td>Float to right</td></tr>',
'  </tbody>',
'</table>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1581066274063072209)
,p_plug_name=>'Demo'
,p_parent_plug_id=>wwv_flow_imp.id(1083478941181047101)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-html"><code>&lt;button class="u-pullLeft"&gt;Foo&lt;/button&gt; &lt;!-- Float button to the left --&gt;',
'&lt;div class="u-pullRight"&gt;Hello World&lt;/div&gt; &lt;!-- Float div to the right --&gt;</code></pre>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083479076477047102)
,p_plug_name=>'Margin'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Margin classes can be added to help add spacing around your elements.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1581066873435072215)
,p_plug_name=>'Options'
,p_parent_plug_id=>wwv_flow_imp.id(1083479076477047102)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use the following class name structure with the options listed below to add spacing around your element.</p>',
'<p><span class="class tag">margin-<span class="class-var">direction</span>-<span class="class-var">spacing</span></span></p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Variable</th>',
'      <th class="u-textStart">Values</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'        <td>Direction</td>',
'        <td>',
'            <span class="class-value">top</span> <br />',
'            <span class="class-value">right</span> <br />',
'            <span class="class-value">bottom</span> <br />',
'            <span class="class-value">left</span>',
'        </td>',
'        <td>Where the margin should be positioned</td>',
'    </tr>',
'    <tr>',
'        <td>Spacing</td>',
'        <td>',
'            <span class="class-value">none</span> <span class="class-desc">0 px</span><br />',
'            <span class="class-value">sm</span>   <span class="class-desc">8 px</span><br />',
'            <span class="class-value">md</span>   <span class="class-desc">16 px</span><br />',
'            <span class="class-value">lg</span>   <span class="class-desc">32 px</span>',
'        </td>',
'        <td>',
'            The amount of spacing in pixels. ',
'        </td>',
'    </tr>',
'',
'  </tbody>',
'</table>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1581067026763072216)
,p_plug_name=>'Demo'
,p_parent_plug_id=>wwv_flow_imp.id(1083479076477047102)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-html"><code>&lt;h1 class="margin-auto"&gt;Centered Heading Text&lt;/h1&gt;',
'&lt;p class="margin-top-lg"&gt;Content with a large margin on top.&lt;/p&gt;</code></pre>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1581067087892072217)
,p_plug_name=>'Other Classes'
,p_parent_plug_id=>wwv_flow_imp.id(1083479076477047102)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use these classes to adjust spacing around all sides of your element.</p>',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">margin-<span class="class-value">none</span></span></td><td>No margin</td></tr>',
'    <tr><td><span class="class">margin-<span class="class-value">sm</span></span></td><td>8 px margin</td></tr>',
'    <tr><td><span class="class">margin-<span class="class-value">md</span></span></td><td>16 px margin</td></tr>',
'    <tr><td><span class="class">margin-<span class="class-value">lg</span></span></td><td>32 px margin</td></tr>',
'    <tr><td><span class="class">margin-<span class="class-value">auto</span></span></td><td>aligns content into the center</td></tr>',
'  </tbody>',
'</table>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083479260560047104)
,p_plug_name=>'Width'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Text</p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083480412380047115)
,p_plug_name=>'Options'
,p_parent_plug_id=>wwv_flow_imp.id(1083479260560047104)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Classes</th>',
'      <th class="u-textStart">Values</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'        <td><span class="class tag">w<span class="class-value">amount</span></span></td>',
'        <td>',
'            <span class="class">10-800</span> <span class="class-desc">px</span>',
'        </td>',
'        <td>Sets the element''s width to specified value. Sizes in 10px increments.</td>',
'    </tr>',
'    <tr>',
'        <td><span class="class tag">w<span class="class-value">percentage</span>p</span></td>',
'        <td>',
'            <span class="class">5-100</span> <span class="class-desc">%</span>',
'        </td>',
'        <td>Sets the element''s width to specified percentage. Percentages in 5% increments</td>',
'    </tr>',
'    <tr>',
'        <td><span class="class tag">mnw<span class="class-value">amount</span></span></td>',
'        <td>',
'            <span class="class">10-800</span> <span class="class-desc">px</span>',
'        </td>',
'        <td>Sets the element''s min-width to specified value. Sizes in 10px increments</td>',
'    </tr>',
'    <tr>',
'        <td><span class="class tag">mxw<span class="class-value">amount</span></span></td>',
'        <td>',
'            <span class="class">10-800</span> <span class="class-desc">px</span>',
'        </td>',
'        <td>Sets the element''s max-width to specified value. Sizes in 10px increments</td>',
'    </tr>',
'  </tbody>',
'</table>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083480472548047116)
,p_plug_name=>'Demo'
,p_parent_plug_id=>wwv_flow_imp.id(1083479260560047104)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<pre class="dm-Code lang-html"><code>&lt;div class="w95p mxw800"&gt;This region will be 95% wide with a max-widht of 800px.&lt;/div&gt;</code></pre>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083479364675047105)
,p_plug_name=>'Height'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Text</p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083480573808047117)
,p_plug_name=>'Options'
,p_parent_plug_id=>wwv_flow_imp.id(1083479364675047105)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Classes</th>',
'      <th class="u-textStart">Values</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'        <td><span class="class">h<span class="class-value">amount</span></span></td>',
'        <td>',
'            <span class="class-value">10-800</span> <span class="class-desc">px</span>',
'        </td>',
'        <td>Sets the element''s height to specified value. Sizes in 10px increments</td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">mxh<span class="class-value">amount</span></span></td>',
'        <td>',
'            <span class="class-value">10-800</span> <span class="class-desc">px</span>',
'        </td>',
'        <td>Sets the element''s max-height to specified value. Sizes in 10px increments</td>',
'    </tr>',
'  </tbody>',
'</table>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083480662111047118)
,p_plug_name=>'Demo'
,p_parent_plug_id=>wwv_flow_imp.id(1083479364675047105)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<pre class="dm-Code lang-html"><code>&lt;div class="h400"&gt;This region would be 400px tall.&lt;/div&gt;</code></pre>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083479835839047110)
,p_plug_name=>'Vertical Alignment'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>To vertically-align the contents of an element you can use the <span class="class tag">u-align<span class="class-var">Direction</span></span> utility class.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1581066720609072213)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_imp.id(1083479835839047110)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-align<span class="class-value">Top</span></span></td><td>Vertically align to the top</td></tr>',
'    <tr><td><span class="class">u-align<span class="class-value">Middle</span></span></td><td>Vertically align to the middle</td></tr>',
'    <tr><td><span class="class">u-align<span class="class-value">Baseline</span></span></td><td>Vertically align to the text baseline</td></tr>',
'    <tr><td><span class="class">u-align<span class="class-value">Bottom</span></span></td><td>Vertically align to the bottom</td></tr>',
'  </tbody>',
'</table>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1581066751095072214)
,p_plug_name=>'Demo'
,p_parent_plug_id=>wwv_flow_imp.id(1083479835839047110)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-html"><code>&lt;table&gt;',
'  &lt;tbody&gt;',
'    &lt;tr&gt;',
'      &lt;td class="u-alignTop"&gt;Hello World!&lt;/td&gt;',
'      &lt;td class="u-alignMiddle"&gt;I''m in the middle!&lt;/td&gt;',
'    &lt;/tr&gt;',
'  &lt;/tbody&gt;',
'&lt;/table&gt;</code></pre>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083480023633047111)
,p_plug_name=>'Padding'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Padding classes can be added to help add spacing within your elements.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083480036740047112)
,p_plug_name=>'Options'
,p_parent_plug_id=>wwv_flow_imp.id(1083480023633047111)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use the following class name structure with the options listed below to add spacing around your element.</p>',
'<p><span class="class tag">padding-<span class="class-var">direction</span>-<span class="class-var">spacing</span></span></p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Variable</th>',
'      <th class="u-textStart">Values</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'        <td>Direction</td>',
'        <td>',
'            <span class="class-value">top</span> <br />',
'            <span class="class-value">right</span> <br />',
'            <span class="class-value">bottom</span> <br />',
'            <span class="class-value">left</span>',
'        </td>',
'        <td>Where the padding should be positioned</td>',
'    </tr>',
'    <tr>',
'        <td>Spacing</td>',
'        <td>',
'            <span class="class-value">none</span> <span class="class-desc">0 px</span><br />',
'            <span class="class-value">sm</span>   <span class="class-desc">8 px</span><br />',
'            <span class="class-value">md</span>   <span class="class-desc">16 px</span><br />',
'            <span class="class-value">lg</span>   <span class="class-desc">32 px</span>',
'        </td>',
'        <td>',
'            The amount of spacing in pixels. ',
'        </td>',
'    </tr>',
'',
'  </tbody>',
'</table>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083480198133047113)
,p_plug_name=>'Other Classes'
,p_parent_plug_id=>wwv_flow_imp.id(1083480023633047111)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use these classes to adjust spacing within all sides of your element.</p>',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">padding-<span class="class-value">none</span></span></td><td>No padding</td></tr>',
'    <tr><td><span class="class">padding-<span class="class-value">sm</span></span></td><td>8 px padding</td></tr>',
'    <tr><td><span class="class">padding-<span class="class-value">md</span></span></td><td>16 px padding</td></tr>',
'    <tr><td><span class="class">padding-<span class="class-value">lg</span></span></td><td>32 px padding</td></tr>',
'  </tbody>',
'</table>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1083480246635047114)
,p_plug_name=>'Demo'
,p_parent_plug_id=>wwv_flow_imp.id(1083480023633047111)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-html"><code>&lt;button class="padding-lg"&gt;Large button&lt;/button&gt;',
'&lt;div class="padding-left-md"&gt;Little bit of padding on the side.&lt;/div&gt;</code></pre>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1565761020038398362)
,p_plug_name=>'Introduction'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>You can use the following utility classes anywhere in your app to fine-tune the layout of your page and components. For most Oracle APEX components, you can simply populate the <b>CSS Classes</b> property to apply these modifiers to your page comp'
||'onents.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1581066526788072211)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2420110581345097560)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4411094925147946463)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3121236124904246762)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp.component_end;
end;
/
