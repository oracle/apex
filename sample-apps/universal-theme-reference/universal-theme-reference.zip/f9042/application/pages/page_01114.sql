prompt --application/pages/page_01114
begin
--   Manifest
--     PAGE: 01114
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-16'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1114
,p_user_interface_id=>wwv_flow_imp.id(1319173717720724629)
,p_name=>'Login Page Template'
,p_alias=>'LOGIN-PAGE-TEMPLATE'
,p_step_title=>'Login Page Template - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_step_template=>wwv_flow_imp.id(1150030732397538053)
,p_page_template_options=>'#DEFAULT#:t-LoginPage--bg3'
,p_overwrite_navigation_list=>'Y'
,p_navigation_list_position=>'TOP'
,p_navigation_list_id=>wwv_flow_imp.id(2383083486935792669)
,p_navigation_list_template_id=>wwv_flow_imp.id(1575627483634426509)
,p_nav_list_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'17'
,p_last_upd_yyyymmddhh24miss=>'20220225144709'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2397142084134519743)
,p_plug_name=>'Login Region'
,p_icon_css_classes=>'app-sample-universal-theme'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1723030776885263813)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2395692178317480363)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2397142084134519743)
,p_button_name=>'P1114_LOGIN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(3121235740369246759)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Log In'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2395691951618480361)
,p_name=>'P1114_USER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2397142084134519743)
,p_prompt=>'User Name'
,p_placeholder=>'username'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(1089658686482546942)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2395692089174480362)
,p_name=>'P1114_PASSWORD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2397142084134519743)
,p_prompt=>'Password'
,p_placeholder=>'password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_tag_css_classes=>'icon-login-password'
,p_field_template=>wwv_flow_imp.id(1089658686482546942)
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
