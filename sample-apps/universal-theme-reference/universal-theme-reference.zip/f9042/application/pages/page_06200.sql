prompt --application/pages/page_06200
begin
--   Manifest
--     PAGE: 06200
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6200
,p_user_interface_id=>wwv_flow_imp.id(1319173717720724629)
,p_name=>'JavaScript Events'
,p_alias=>'JAVASCRIPT-EVENTS'
,p_step_title=>'JavaScript Events - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(1211541318767601389)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'code.event-name {',
'    background: rgba(147, 180, 197, 0.25);',
'    padding: 6px 8px;',
'    border-radius: 3px;',
'    text-shadow: 1px 1px #fff;',
'}',
'',
'code.event-name:hover {',
'    color: #000;',
'    background:#eee',
'}',
'',
'.dm-Code {',
'    border-radius: var(--ut-component-border-radius);',
'    border: var(--ut-component-border-width) solid var(--ut-component-border-color);',
'}'))
,p_page_css_classes=>'dm-Page'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
,p_last_upd_yyyymmddhh24miss=>'20220225144709'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1194100416267252156)
,p_plug_name=>'API List'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol class="event-list">',
'    <li>',
'        <p><code class="event-name">theme42ready</code> is triggered after the initialization of Universal Theme:</p>',
'<pre class="dm-Code lang-js"><code>apex.jQuery(window).on(''<strong>theme42ready</strong>'', function() {',
'    console.log(''Do something after UI elements are rendered on the page.'');',
'});</code></pre>',
'        ',
'    </li>',
'    <li>',
'        <p>',
'<code class="event-name">theme42layoutchanged</code> is triggered when left navigation menu is expanded or collapsed.</p>',
'<pre class="dm-Code lang-js"><code>apex.jQuery("#t_TreeNav").on(''<strong>theme42layoutchanged</strong>'', function(event, obj) {',
'    console.log(''Left menu action: '' + obj.action);   // obj.action will return expand or collapse',
'});</code></pre>',
'    </li>',
'    <li>',
'        <p><code class="event-name">apexwindowresized</code> is triggered by the browser window resize or the maximize/restore action of a region.</p>',
'<pre class="dm-Code lang-js"><code>apex.jQuery(window).on(''<strong>apexwindowresized</strong>'', function() {',
'    console.log(''Window resized.'');',
'});</code></pre>',
'    </li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1194100523271252157)
,p_plug_name=>'Introduction'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    You can extending Universal Theme by attaching handlers to its events.',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1211341487760707382)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3121236124904246762)
);
wwv_flow_imp.component_end;
end;
/
