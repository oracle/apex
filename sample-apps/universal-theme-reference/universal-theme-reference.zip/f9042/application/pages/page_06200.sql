prompt --application/pages/page_06200
begin
--   Manifest
--     PAGE: 06200
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6200
,p_name=>'JavaScript Events'
,p_alias=>'JAVASCRIPT-EVENTS'
,p_step_title=>'JavaScript Events - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(2730271612854070151)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'code.event-name {',
'    background: rgba(147, 180, 197, 0.25);',
'    padding: 6px 8px;',
'    border-radius: 3px;',
'    text-shadow: 1px 1px #fff;',
'}',
'',
'code.event-name:hover {',
'    color: #000;',
'    background:#eee',
'}',
'',
'.dm-Code {',
'    border-radius: var(--ut-component-border-radius);',
'    border: var(--ut-component-border-width) solid var(--ut-component-border-color);',
'}'))
,p_page_css_classes=>'dm-Page'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2712830710353720918)
,p_plug_name=>'API List'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol class="event-list">',
'    <li>',
'        <p><code class="event-name">theme42ready</code> is triggered after the initialization of Universal Theme:</p>',
'<pre class="dm-Code lang-js"><code>apex.jQuery(window).on(''<strong>theme42ready</strong>'', function() {',
'    console.log(''Do something after UI elements are rendered on the page.'');',
'});</code></pre>',
'        ',
'    </li>',
'    <li>',
'        <p>',
'<code class="event-name">theme42layoutchanged</code> is triggered when left navigation menu is expanded or collapsed.</p>',
'<pre class="dm-Code lang-js"><code>apex.jQuery("#t_TreeNav").on(''<strong>theme42layoutchanged</strong>'', function(event, obj) {',
'    console.log(''Left menu action: '' + obj.action);   // obj.action will return expand or collapse',
'});</code></pre>',
'    </li>',
'    <li>',
'        <p><code class="event-name">apexwindowresized</code> is triggered by the browser window resize or the maximize/restore action of a region.</p>',
'<pre class="dm-Code lang-js"><code>apex.jQuery(window).on(''<strong>apexwindowresized</strong>'', function() {',
'    console.log(''Window resized.'');',
'});</code></pre>',
'    </li>',
'</ol>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2712830817357720919)
,p_plug_name=>'Introduction'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    You can extending Universal Theme by attaching handlers to its events.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2730071781847176144)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp.component_end;
end;
/
