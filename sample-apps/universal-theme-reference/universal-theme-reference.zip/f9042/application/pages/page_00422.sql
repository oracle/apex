prompt --application/pages/page_00422
begin
--   Manifest
--     PAGE: 00422
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>422
,p_name=>'Headers and Footers'
,p_alias=>'HEADERS-AND-FOOTERS'
,p_step_title=>'Headers and Footers'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(1056168381265014818)
,p_step_template=>wwv_flow_imp.id(3121228739815246741)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
,p_last_updated_by=>'VMORNEAU'
,p_last_upd_yyyymmddhh24miss=>'20220909124800'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1104806627318032988)
,p_plug_name=>'Mobile Page Footer'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>You can configure a <b>Buttons Container</b> region so that it sticks to the bottom of the page for small screen devices.  This could be useful for when you want to have one set of buttons for a given page and position them to the bottom when a sm'
||'all screen device is used.</p>',
'',
'<p><b>Steps</b></p>',
'<ol>',
'  <li>Create a Region with the region template set to <b>Buttons Container</b></li>',
'  <li>Modify the Template Options for this region and check the <b>Stick to Bottom on Mobile</b> option</li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1254595948844716251)
,p_plug_name=>'Page Footer Examples'
,p_parent_plug_id=>wwv_flow_imp.id(1104806627318032988)
,p_icon_css_classes=>'fa-mouse-pointer'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(1089556228434378185)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<b>Page Footer Examples</b>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1852679388167827486)
,p_plug_name=>'Mobile Page Header'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The <strong>Breadcrumb Bar</strong> region position on any given Page Template within Universal Theme is designed to persist on large screens as the user scrolls.  This is the position where the Breadcrumbs component, or Hero region, is typically '
||'placed.</p>',
'',
'<p>By default, the contents of this region are not stuck to the top of the screen on small screen devices as it can take away valuable screen realestate. However, if you wish to persist this header to always be visible on a given page, you can add th'
||'e following template option to make this happen.</p>',
'',
'<p><strong>Steps</strong></p>',
'<ol>',
'  <li>Select the Page in Page Designer</li>',
'  <li>Modify the Template Options for the page and check the <strong>Sticky Header on Mobile</strong> option</li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1254595633750716248)
,p_plug_name=>'Page Header Examples'
,p_parent_plug_id=>wwv_flow_imp.id(1852679388167827486)
,p_icon_css_classes=>'fa-mouse-pointer'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(1089556228434378185)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<b>Page Header Examples</b>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4226470155605723016)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3121236124904246762)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5646104218380701705)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Many mobile apps share a common pattern for placement of buttons and other content. This content is typically positioned on the header or footer of the page which is easily accessible and on screen for quick actions. This page explains how you can'
||' apply this pattern for your own apps.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1254595705691716249)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1254595633750716248)
,p_button_name=>'HEADER_1'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(1131702324492887059)
,p_button_image_alt=>'Header Example 1'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1116:&APP_SESSION.:sample1'',''Sticky Page Header'');'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1254596236377716254)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1254595948844716251)
,p_button_name=>'FOOTER_1'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(1131702324492887059)
,p_button_image_alt=>'Footer Example 1'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1117:&APP_SESSION.:sample1'',''Sticky Page Header'');'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1254595849717716250)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1254595633750716248)
,p_button_name=>'HEADER_2'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(1131702324492887059)
,p_button_image_alt=>'Header Example 2'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1116:&APP_SESSION.:sample2'',''Sticky Page Header'');'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1254596379912716255)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1254595948844716251)
,p_button_name=>'FOOTER_2'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(1131702324492887059)
,p_button_image_alt=>'Footer Example 2'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1117:&APP_SESSION.:sample2'',''Sticky Page Header'');'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp.component_end;
end;
/
