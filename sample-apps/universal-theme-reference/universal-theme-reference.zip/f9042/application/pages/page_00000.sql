prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_user_interface_id=>wwv_flow_imp.id(1319173717720724629)
,p_name=>'Page Zero'
,p_alias=>'PAGE-ZERO'
,p_step_title=>'Page Zero'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_step_template=>wwv_flow_imp.id(3121228739815246741)
,p_page_template_options=>'#DEFAULT#'
,p_nav_list_template_options=>'#DEFAULT#'
,p_page_component_map=>'14'
,p_last_updated_by=>'SHAKEEB'
,p_last_upd_yyyymmddhh24miss=>'20220330125242'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(231753414141461232)
,p_plug_name=>'Script'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3550313444782567988)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_07'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script>',
'const toggleRtl = ( ) => {',
'    if ( $(''html'').hasClass(''u-RTL'') ) {',
'        sessionStorage.removeItem(''dir'');',
'        $(''html'').removeClass(''u-RTL'').attr(''dir'', ''ltr'');',
'    } else {',
'        sessionStorage.setItem(''dir'', ''rtl'');',
'        $(''html'').addClass(''u-RTL'').attr(''dir'', ''rtl'');',
'    }',
'};',
'',
'window.addEventListener(''load'', () => {',
'    if ( sessionStorage.getItem(''dir'') ) {',
'        toggleRtl();',
'    }',
'});',
'</script>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(247585693772112611)
,p_plug_name=>'Items'
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_06'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3580113220358300572)
,p_plug_name=>'Woops.'
,p_icon_css_classes=>'fa-emoji-grin-sweat'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(1089556228434378185)
,p_plug_display_sequence=>10
,p_plug_source=>'You''ve stumbled on a page that doesn''t exist.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'CURRENT_PAGE_IN_CONDITION'
,p_plug_display_when_condition=>'400,403,404,406,5001,5002,5003,5004,5005,6306,700,701'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(247585733421112612)
,p_name=>'P0_THEME_STYLE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(247585693772112611)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
