prompt --application/pages/page_03810
begin
--   Manifest
--     PAGE: 03810
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>776266751179078842
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3810
,p_name=>'Breadcrumb'
,p_alias=>'BREADCRUMB'
,p_step_title=>'Breadcrumb - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(2401837048789160465)
,p_step_template=>wwv_flow_imp.id(4620099912336992638)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
,p_last_upd_yyyymmddhh24miss=>'20230131092402'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1764540467756002623)
,p_plug_name=>'Instructions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--shadowBG:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'BreadcrumbDemo'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3719588806509513288)
,p_plug_name=>'Demo'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4012375243529747342)
,p_plug_name=>'Within the Blank with Attributes Template'
,p_parent_plug_id=>wwv_flow_imp.id(3719588806509513288)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--lightBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4012375039531747340)
,p_plug_name=>'Blank Region'
,p_region_name=>'BreadcrumbDemo'
,p_parent_plug_id=>wwv_flow_imp.id(4012375243529747342)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3918981753866843457)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_menu_id=>wwv_flow_imp.id(3722706651486710750)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(4620107297425992659)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4012375315968747343)
,p_plug_name=>'Within the Title Bar Template'
,p_parent_plug_id=>wwv_flow_imp.id(3719588806509513288)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4012374910855747339)
,p_plug_name=>'Title Bar'
,p_parent_plug_id=>wwv_flow_imp.id(4012375315968747343)
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3079207278690065424)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_menu_id=>wwv_flow_imp.id(3722706651486710750)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(4620107297425992659)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5399402776971833117)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3079207278690065424)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3722706651486710750)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(4620107297425992659)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6443721416779213179)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2869859619594775508)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>A <strong>Breadcrumb</strong> is a hierarchical list of links that indicates where the user is within the application from a hierarchical perspective.  It is useful for providing navigational context to end users, and an easy way to navigate back '
||'to the home.  Within Universal Theme, the application breadcrumb has a special location for placement and should be used with the <a href="f?p=&APP_ID.:1207:&APP_SESSION.">Title Bar</a> region template in most cases.</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6443721733501211528)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(5049184617304313885)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'NO'
,p_attribute_04=>'N'
);
wwv_flow_imp.component_end;
end;
/
