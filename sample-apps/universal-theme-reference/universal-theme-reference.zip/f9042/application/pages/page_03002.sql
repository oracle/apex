prompt --application/pages/page_03002
begin
--   Manifest
--     PAGE: 03002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>2028731318158593
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3002
,p_name=>'Components - Badge'
,p_alias=>'BADGE-COMPONENT'
,p_step_title=>'Badge - Universal Theme'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1737907133320359763)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2873903375634086548)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    The <strong>Badge</strong> partial is useful for displaying badges or counters. ',
'    This partial can be used to display a single badge, or can be applied in report templates to display a badge for each report row.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1737907571514359767)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(5053228373343624925)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'rds_mode', 'JUMP',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1846058094384001159)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3083251034729376464)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3726750407526021790)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(4624151053465303699)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1900255340050146666)
,p_plug_name=>'Demo: Interactive Report'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2873903375634086548)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1900255484984146667)
,p_plug_name=>'IR'
,p_region_name=>'IRDemo'
,p_parent_plug_id=>wwv_flow_imp.id(1900255340050146666)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(2652314349114034984)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       TASK_NAME,',
'       START_DATE,',
'       END_DATE,',
'       STATUS,',
'       ASSIGNED_TO,',
'       COST,',
'       BUDGET,',
'       case STATUS',
'         when ''Closed''  then ''success''',
'         when ''Open''    then ''danger''',
'         when ''Pending'' then ''warning''',
'         else ''info''',
'       end as BADGE_STATE,',
'       case STATUS',
'         when ''Closed''  then ''fa-check''',
'         when ''Open''    then ''fa-exclamation''',
'         when ''Pending'' then ''fa-question''',
'         else ''fa-info''',
'       end as BADGE_ICON',
'  from EBA_UT_CHART_TASKS'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'IR'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1900255570923146668)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'PAIGE'
,p_internal_uid=>397340642362089731
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1900255652893146669)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1900255932252146672)
,p_db_column_name=>'TASK_NAME'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Task Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1900256128468146673)
,p_db_column_name=>'START_DATE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Start Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1900256159709146674)
,p_db_column_name=>'END_DATE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'End Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1900256408089146676)
,p_db_column_name=>'ASSIGNED_TO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Assigned To'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1900256500364146677)
,p_db_column_name=>'COST'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Cost'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1900256621207146678)
,p_db_column_name=>'BUDGET'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Budget'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1900256320817146675)
,p_db_column_name=>'STATUS'
,p_display_order=>110
,p_column_identifier=>'G'
,p_column_label=>'Status'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'TMPL_THEME_42$BADGE'
,p_column_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'LABEL', 'Status',
  'LABEL_DISPLAY', 'N',
  'STATE', 'BADGE_STATE',
  'VALUE', 'STATUS')).to_clob
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1900256677730146679)
,p_db_column_name=>'BADGE_STATE'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Badge State'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1900256761124146680)
,p_db_column_name=>'BADGE_ICON'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Badge Icon'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1903787812825601734)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4008729'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:TASK_NAME:START_DATE:END_DATE:STATUS:ASSIGNED_TO:COST:BUDGET:BADGE_STATE:BADGE_ICON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1900256966346146682)
,p_plug_name=>'Configuration: Interactive Report'
,p_parent_plug_id=>wwv_flow_imp.id(1900255340050146666)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3216122603523592090)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Region</h4>',
'<strong>Type:</strong> Interactive Report',
'',
'<h4>Status Column</h4>',
'<p>In Interactive Reports, the <em>Badge</em> partial is available for use as a column Type. The <strong>Status</strong> column in this demo uses the Badge column type and associated Partial settings to display a badge in each row.</p>',
'',
'<h4>Badge</h4>',
'<strong>Label:</strong> Status<br>',
'<strong>Value:</strong> #STATUS#<br>',
'<strong>Icon:</strong> <em>None</em><br>',
'<strong>Display Label:</strong> No<br>',
'<strong>Style:</strong> Default<br>',
'<strong>Shape:</strong> Default<br>',
'<strong>Size:</strong> Default'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1904208842567654047)
,p_plug_name=>'Sample SQL Query: Interactive Report'
,p_parent_plug_id=>wwv_flow_imp.id(1900255340050146666)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3216122603523592090)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.REGION_SOURCE_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'IRDemo')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1900256832656146681)
,p_plug_name=>'Demo: Classic Report'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_imp.id(2873903375634086548)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1876852668402904658)
,p_plug_name=>'Sample SQL Query: Classic Report'
,p_parent_plug_id=>wwv_flow_imp.id(1900256832656146681)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3216122603523592090)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.REGION_SOURCE_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'CRDemo')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1900257084596146683)
,p_name=>'CR'
,p_region_name=>'CRDemo'
,p_parent_plug_id=>wwv_flow_imp.id(1900256832656146681)
,p_template=>wwv_flow_imp.id(2652314349114034984)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff'
,p_grid_column_span=>8
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       TASK_NAME,',
'       START_DATE,',
'       END_DATE,',
'       STATUS,',
'       ASSIGNED_TO,',
'       COST,',
'       BUDGET,',
'       case STATUS',
'         when ''Closed''  then ''success''',
'         when ''Open''    then ''danger''',
'         when ''Pending'' then ''warning''',
'         else ''info''',
'       end as BADGE_STATE,',
'       case STATUS',
'         when ''Closed''  then ''fa-check''',
'         when ''Open''    then ''fa-exclamation''',
'         when ''Pending'' then ''fa-question''',
'         else ''fa-info''',
'       end as BADGE_ICON',
'  from EBA_UT_CHART_TASKS'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3090442048733532045)
,p_query_num_rows=>10
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1900257135403146684)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1900257466231146687)
,p_query_column_id=>2
,p_column_alias=>'TASK_NAME'
,p_column_display_sequence=>40
,p_column_heading=>'Task Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1904208025783654038)
,p_query_column_id=>3
,p_column_alias=>'START_DATE'
,p_column_display_sequence=>50
,p_column_heading=>'Start Date'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1904208101517654039)
,p_query_column_id=>4
,p_column_alias=>'END_DATE'
,p_column_display_sequence=>60
,p_column_heading=>'End Date'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1904208667039654045)
,p_query_column_id=>5
,p_column_alias=>'STATUS'
,p_column_display_sequence=>120
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{with/}',
'LABEL:=STATUS',
'VALUE:=#STATUS#',
'STATE:=#BADGE_STATE#',
'ICON:=#BADGE_ICON#',
'LABEL_DISPLAY:=N',
'STYLE:=t-Badge--subtle',
'SHAPE:=t-Badge--circle',
'{apply THEME$BADGE/}'))
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1904208201593654040)
,p_query_column_id=>6
,p_column_alias=>'ASSIGNED_TO'
,p_column_display_sequence=>70
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1904208279124654041)
,p_query_column_id=>7
,p_column_alias=>'COST'
,p_column_display_sequence=>80
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1904208357420654042)
,p_query_column_id=>8
,p_column_alias=>'BUDGET'
,p_column_display_sequence=>90
,p_column_heading=>'Budget'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1904208480210654043)
,p_query_column_id=>9
,p_column_alias=>'BADGE_STATE'
,p_column_display_sequence=>100
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1904208601855654044)
,p_query_column_id=>10
,p_column_alias=>'BADGE_ICON'
,p_column_display_sequence=>110
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1904208783778654046)
,p_plug_name=>'Configuration: Classic Report'
,p_parent_plug_id=>wwv_flow_imp.id(1900256832656146681)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3216122603523592090)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Region</h4>',
'<strong>Type:</strong> Classic Report',
'',
'<h4>Status Column</h4>',
'<p>The <strong>Status</strong> column uses the with-apply syntax in the HTML Expression attribute under Column Formatting to access the <em>Badge</em> partial and display a badge in each row.</p>',
'',
'<strong>Type:</strong> Plain Text<br>',
'<strong>HTML Expression:</strong>',
'<code>',
'    {with/}',
'        LABEL:=STATUS',
'        VALUE:=#STATUS#',
'        STATE:=#BADGE_STATE#',
'        ICON:=#BADGE_ICON#',
'        LABEL_DISPLAY:=N',
'        STYLE:=t-Badge--subtle',
'        SHAPE:=t-Badge--circle',
'    {apply THEME$BADGE/}',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
