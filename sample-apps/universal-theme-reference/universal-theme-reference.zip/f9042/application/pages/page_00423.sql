prompt --application/pages/page_00423
begin
--   Manifest
--     PAGE: 00423
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>423
,p_user_interface_id=>wwv_flow_imp.id(1319173717720724629)
,p_name=>'Data Entry'
,p_alias=>'DATA-ENTRY2'
,p_step_title=>'Data Entry'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(1056168381265014818)
,p_step_template=>wwv_flow_imp.id(3121228739815246741)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
,p_last_upd_yyyymmddhh24miss=>'20220225144709'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1254597532641716267)
,p_plug_name=>'Good Design Practices'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Here are some good design practices to follow when designing pages and apps for small screen devices.</p>',
'',
'<ul class="dm-UL">',
'<li><strong>Limit the number of fields to fill out</strong><br />',
'      Fewer fields to complete means a higher successrate of users completing the form. Whenever possible, use smart defaults, and employ HTML5 apis such as <a href="https://developer.mozilla.org/en-US/docs/Web/API/Geolocation/Using_geolocation" targ'
||'et="_blank">geolocation</a> to capture location data rather than asking the user to enter it manually.</li>',
'<li><strong>Use radio buttons in place of select lists when possible</strong><br />',
'      You can improve the usability of your form by replacing select lists which have a few options to a radio button.  This will result in fewer taps to see the available options as they will already be displayed on screen.  You can go even further '
||'by setting the <a href="f?p=&APP_ID.:1204">Display as Pill Button</a> template option to provide a more user friendly control.</li>',
'<li><strong>Position submit buttons near the end of the form</strong><br />',
'      This simple trick will make it far more easier to reach and tap on the submit button.</li>',
'<li><strong>Avoid using heavy controls and widgets</strong><br />',
'      While it may be tempting to use Interactive Grid on a phone, there may be alternatives that provide better usability and mobile performance. When in doubt, try to avoid large controls like Interactive Grids on mobile screens and instead try to '
||'optimize for user experience.</li>',
'</ul>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2609431363364511009)
,p_plug_name=>'Form Design'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>When designing your data entry screens for mobile, consider using the <b>Floating Labels</b> field templates for your page items.  These templates are especially optimized for mobile use cases as they provide a much larger tap area to gain focus a'
||'nd provides larger text for improved readibility.  The field label will automatically shrink as a value is populated, but still remaining on screen so context is not lost.</p>',
'',
'<p>Be sure to visit the <a href="f?p=&APP_ID.:1600">Components &rarr; Forms &rarr; Floating Labels</a> page for additional examples.</p>',
'',
'<p><b>Steps</b></p>',
'<ol>',
'  <li>Select the page item in Page Designer</li>',
'  <li>Modify the Template property under Appearance</li>',
'  <li>Select either the <b>Optional - Floating</b> or <b>Required - Floating</b> template from the select list.</li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2011347608947399771)
,p_plug_name=>'Mobile Form Example'
,p_parent_plug_id=>wwv_flow_imp.id(2609431363364511009)
,p_icon_css_classes=>'fa-mouse-pointer'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(1089556228434378185)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<b>Mobile Form Examples</b>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4983222130802406539)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3121236124904246762)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6402856193577385228)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_imp.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Data entry is a key component of many APEX apps and should be very carefully considered when designing screens for mobile use cases.  This page outlines a few patterns that Universal Theme provides as well as some general guidelines when designing'
||' forms and data entry pages for small screens.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1254654299173077883)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2011347608947399771)
,p_button_name=>'FORM_1'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(1131702324492887059)
,p_button_image_alt=>'Form Sample 1'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1600:&APP_SESSION.:sample1'',''Sticky Page Header'');'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1254654754525077884)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2011347608947399771)
,p_button_name=>'FORM_2'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(1131702324492887059)
,p_button_image_alt=>'Form Sample 2'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1600:&APP_SESSION.:sample2'',''Sticky Page Header'');'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp.component_end;
end;
/
