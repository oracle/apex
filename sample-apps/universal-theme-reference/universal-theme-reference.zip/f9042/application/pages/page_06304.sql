prompt --application/pages/page_06304
begin
--   Manifest
--     PAGE: 06304
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>7614681690540177
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6304
,p_name=>'Content Modifiers'
,p_alias=>'CONTENT-MODIFIERS'
,p_step_title=>'Content Modifiers - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.class,',
'.class-value,',
'.class-desc {',
'    display: inline-block;',
'    font-size: 12px;',
'    font-family: ''Menlo'',''Consolas'',monospace;',
'}',
'.class {',
'    color: #9C27B0;',
'}',
'.class.tag {',
'    padding: 4px 8px;',
'    background-color: #FFF;',
'    border-radius: 2px;',
'    box-shadow: inset rgba(225, 190, 231, .25) 0 0 0 1px;',
'}',
'.class-value {',
'    color: #008676;',
'    min-width: 40px;',
'}',
'.class-var {',
'    font-weight: bold;',
'    color: #008676;',
'}',
'.dm-Report--doc {',
'    background: #FFF;',
'    border: 1px solid rgba(0,0,0,.05);',
'}',
'.dm-Report--doc th, ',
'.dm-Report--doc td {',
'    padding: 8px;',
'    min-height: 32px;',
'    background-color: transparent;',
'    border-width: 0 0 1px 0;',
'    border-style: solid;',
'    border-color: rgba(0,0,0,.05);',
'}',
'.dm-Report--doc td {',
'    --a-base-font-weight-semibold: 500 !important;',
'    vertical-align: top;',
'}',
'.dm-Report--alignMiddle td {',
'    vertical-align: middle;',
'}',
'.dm-Report--doc tr:last-child td {',
'    border-bottom-width: 0;',
'}',
'.dm-Report--doc .class {',
'    min-width: 40px;',
'}',
'.dm-Report--doc .class-desc {',
'    width: 48px;',
'    text-align: right;',
'    color: rgba(0,0,0,.55);',
'    border-radius: 2px;',
'}',
'.dm-Code {',
'    border-radius: var(--ut-component-border-radius);',
'    border: var(--ut-component-border-width) solid var(--ut-component-border-color);',
'}',
'',
'.u-truncate {',
'    max-inline-size: 15rem;',
'}',
'',
'@media (min-width: 640px) {',
'    .dm-Report--doc td:first-child {',
'        inline-size: 350px;',
'    }',
'}'))
,p_step_template=>4072355960268175073
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16850683746448082)
,p_plug_name=>'Headings'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_location=>null
,p_plug_source=>'<!-- <p>Use these classes to set the font size, font weight, and line height properties of your text elements.</p> -->'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16850795738448083)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_imp.id(16850683746448082)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!-- <p>Use the following class name structure with the options listed below to set the size of your headings.</p> -->',
'<!-- <p><span class="class tag">u-text-heading-<span class="class-var">size</span></span></p> -->',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc dm-Report--alignMiddle">',
'  <thead>',
'    <tr>',
'      <th class="u-textStart">Class</th>',
'      <th class="u-textStart">Example</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'        <td><span class="class">u-text-heading-2xl<br />u-text-title-1</span></td>',
'        <td><span class="u-text-heading-2xl">Heading 2XL</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-heading-xl<br />u-text-title-2</span></td>',
'        <td><span class="u-text-heading-xl">Heading XL</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-heading-lg<br />u-text-title-3</span></td>',
'        <td><span class="u-text-heading-lg">Heading LG</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-heading-md<br />u-text-title-4</span></td>',
'        <td><span class="u-text-heading-md">Heading MD</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-heading-sm<br />u-text-title-5</span></td>',
'        <td><span class="u-text-heading-sm">Heading SM</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-heading-xs<br />u-text-title-6</span></td>',
'        <td><span class="u-text-heading-xs">Heading XS</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-subheading-2xl<br />u-text-subtitle-1</span></td>',
'        <td><span class="u-text-subheading-2xl">Subheading 2XL</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-subheading-xl<br />u-text-subtitle-2</span></td>',
'        <td><span class="u-text-subheading-xl">Subheading XL</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-subheading-lg<br />u-text-subtitle-3</span></td>',
'        <td><span class="u-text-subheading-lg">Subheading LG</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-subheading-md<br />u-text-subtitle-4</span></td>',
'        <td><span class="u-text-subheading-md">Subheading MD</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-subheading-sm<br />u-text-subtitle-5</span></td>',
'        <td><span class="u-text-subheading-sm">Subheading SM</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-subheading-xs<br />u-text-subtitle-6</span></td>',
'        <td><span class="u-text-subheading-xs">Subheading XS</span></td>',
'    </tr>',
'  </tbody>',
'</table>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16850928113448084)
,p_plug_name=>'Content'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_location=>null
,p_plug_source=>'<!-- <p>Use these classes to set the font size, font weight, and line height properties of your text elements.</p> -->'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16851176705448086)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_imp.id(16850928113448084)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!-- <p>Use the following class name structure with the options listed below to set the size of your headings.</p> -->',
'<!-- <p><span class="class tag">u-text-body-<span class="class-var">size</span></span></p> -->',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc dm-Report--alignMiddle">',
'  <thead>',
'    <tr>',
'      <th class="u-textStart">Class</th>',
'      <th class="u-textStart">Example</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'        <td><span class="class">u-text-body-xl</span></td>',
'        <td><span class="u-text-body-xl">Body XL</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-body-lg<br />u-text-body-1</span></td>',
'        <td><span class="u-text-body-lg">Body LG</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-body-md<br />u-text-body-2</span></td>',
'        <td><span class="u-text-body-md">Body MD</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-body-sm<br />u-text-body-3</span></td>',
'        <td><span class="u-text-body-sm">Body SM</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-body-xs</span></td>',
'        <td><span class="u-text-body-xs">Body XS</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-body-2xs</span></td>',
'        <td><span class="u-text-body-2xs">Body 2XS</span></td>',
'    </tr>',
'  </tbody>',
'</table>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16851192440448087)
,p_plug_name=>'Line Clamp, Truncate & Hyphenate'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_location=>null
,p_plug_source=>'<!-- <p>Use these classes as simple modifiers to restrict a block of text control to a specified number of lines. If a block of text surpasses the specified number of lines then an ellipses (...) is added and the remaining text is hidden.</p> -->'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16851364492448088)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_imp.id(16851192440448087)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th class="u-textStart">Class</th>',
'      <th class="u-textStart">Example</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-lineclamp-1</span></td><td><p class="u-lineclamp-1">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Volutpat diam ut venenatis tellus in met'
||'us. Scelerisque fermentum dui faucibus in ornare quam viverra. Mattis ullamcorper velit sed ullamcorper. Rhoncus est pellentesque elit ullamcorper. Sapien nec sagittis aliquam malesuada bibendum. Interdum varius sit amet mattis vulputate enim nulla. '
||'Vehicula ipsum a arcu cursus vitae congue mauris. Quis imperdiet massa tincidunt nunc pulvinar sapien et. Congue nisi vitae suscipit tellus mauris.</p></td></tr>',
'    <tr><td><span class="class">u-lineclamp-2</span></td><td><p class="u-lineclamp-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Volutpat diam ut venenatis tellus in met'
||'us. Scelerisque fermentum dui faucibus in ornare quam viverra. Mattis ullamcorper velit sed ullamcorper. Rhoncus est pellentesque elit ullamcorper. Sapien nec sagittis aliquam malesuada bibendum. Interdum varius sit amet mattis vulputate enim nulla. '
||'Vehicula ipsum a arcu cursus vitae congue mauris. Quis imperdiet massa tincidunt nunc pulvinar sapien et. Congue nisi vitae suscipit tellus mauris.</p></td></tr>',
'    <tr><td><span class="class">u-lineclamp-3</span></td><td><p class="u-lineclamp-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Volutpat diam ut venenatis tellus in met'
||'us. Scelerisque fermentum dui faucibus in ornare quam viverra. Mattis ullamcorper velit sed ullamcorper. Rhoncus est pellentesque elit ullamcorper. Sapien nec sagittis aliquam malesuada bibendum. Interdum varius sit amet mattis vulputate enim nulla. '
||'Vehicula ipsum a arcu cursus vitae congue mauris. Quis imperdiet massa tincidunt nunc pulvinar sapien et. Congue nisi vitae suscipit tellus mauris.</p></td></tr>',
'    <tr><td><span class="class">u-lineclamp-4</span></td><td><p class="u-lineclamp-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Volutpat diam ut venenatis tellus in met'
||'us. Scelerisque fermentum dui faucibus in ornare quam viverra. Mattis ullamcorper velit sed ullamcorper. Rhoncus est pellentesque elit ullamcorper. Sapien nec sagittis aliquam malesuada bibendum. Interdum varius sit amet mattis vulputate enim nulla. '
||'Vehicula ipsum a arcu cursus vitae congue mauris. Quis imperdiet massa tincidunt nunc pulvinar sapien et. Congue nisi vitae suscipit tellus mauris.</p></td></tr>',
'    <tr><td><span class="class">u-lineclamp-5</span></td><td><p class="u-lineclamp-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Volutpat diam ut venenatis tellus in met'
||'us. Scelerisque fermentum dui faucibus in ornare quam viverra. Mattis ullamcorper velit sed ullamcorper. Rhoncus est pellentesque elit ullamcorper. Sapien nec sagittis aliquam malesuada bibendum. Interdum varius sit amet mattis vulputate enim nulla. '
||'Vehicula ipsum a arcu cursus vitae congue mauris. Quis imperdiet massa tincidunt nunc pulvinar sapien et. Congue nisi vitae suscipit tellus mauris.</p></td></tr>',
'    <tr><td><span class="class">u-hyphenate<br />u-hyphen</span></td><td><p class="u-hyphenate">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Volutpat diam ut venenatis tel'
||'lus in metus. Scelerisque fermentum dui faucibus in ornare quam viverra. Mattis ullamcorper velit sed ullamcorper. Rhoncus est pellentesque elit ullamcorper. Sapien nec sagittis aliquam malesuada bibendum. Interdum varius sit amet mattis vulputate en'
||'im nulla. Vehicula ipsum a arcu cursus vitae congue mauris. Quis imperdiet massa tincidunt nunc pulvinar sapien et. Congue nisi vitae suscipit tellus mauris.</p></td></tr>',
'    <tr><td><span class="class">u-truncate</span></td><td><p class="u-truncate">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Volutpat diam ut venenatis tellus in metus. Sc'
||'elerisque fermentum dui faucibus in ornare quam viverra. Mattis ullamcorper velit sed ullamcorper. Rhoncus est pellentesque elit ullamcorper. Sapien nec sagittis aliquam malesuada bibendum. Interdum varius sit amet mattis vulputate enim nulla. Vehicu'
||'la ipsum a arcu cursus vitae congue mauris. Quis imperdiet massa tincidunt nunc pulvinar sapien et. Congue nisi vitae suscipit tellus mauris.</p></td></tr>',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Style Classes'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1765312969546401894)
,p_plug_name=>'Colors'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_location=>null
,p_plug_source=>'<!-- <p>Use these classes as simple modifiers to restrict a block of text control to a specified number of lines. If a block of text surpasses the specified number of lines then an ellipses (...) is added and the remaining text is hidden.</p> -->'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1765313266221401897)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_imp.id(1765312969546401894)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!-- <p>Use the following class name structure with the options listed below to set the size of your headings.</p> -->',
'<!-- <p><span class="class tag">u-text-heading-<span class="class-var">size</span></span></p> -->',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc dm-Report--alignMiddle">',
'  <thead>',
'    <tr>',
'      <th class="u-textStart">Class</th>',
'      <th class="u-textStart">Example</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'        <td><span class="class">u-text-default-color</td>',
'        <td><span class="u-text-default-color">Default</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-title-color</span></td>',
'        <td><span class="u-text-title-color">Title & Headings</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-subtitle-color</span></td>',
'        <td><span class="u-text-subtitle-color">Sub Title & Sub Headings</span></td>',
'    </tr>',
'    <tr>',
'        <td><span class="class">u-text-muted-color</span></td>',
'        <td><span class="u-text-muted-color">Descriptions & Secondary Text</span></td>',
'    </tr>',
'  </tbody>',
'</table>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1892666752853316470)
,p_plug_name=>'Text Wrap'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_location=>null
,p_plug_source=>'<p>Use this class to force text not to wrap inside its container.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1892666864229316471)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_imp.id(1892666752853316470)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th class="u-textStart">Class</th>',
'      <th class="u-textStart">Example</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-nowrap</span></td><td class="u-nowrap">Text stays on one line and does not wrap</td></tr>',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Wrap Classes'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602225988467536207)
,p_plug_name=>'Accessibility'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_location=>null
,p_plug_source=>'<p>These classes can help you build more accessible apps and help you design a more usable experience for all users.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602227420294536221)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_imp.id(2602225988467536207)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-VisuallyHidden</span></td><td>This will make any text visually hidden, but still accessible for screen readers and other assistive technologies.</td></tr>',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Accessibility Classes'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602227007179536217)
,p_plug_name=>'Text Transform'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_location=>null
,p_plug_source=>'<p>These classes are useful when you want to control the text case for a given component. For example, an input field where you want characters to display in upper case. </p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602227029902536218)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_imp.id(2602227007179536217)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc dm-Report--alignMiddle">',
'  <thead>',
'    <tr>',
'      <th class="u-textStart">Class</th>',
'      <th class="u-textStart">Example</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-textUpper<br />u-text-uppercase</span></td><td class="u-textUpper">Sets the text to use all uppercase</td></tr>',
'    <tr><td><span class="class">u-textLower<br />u-text-lowercase</span></td><td class="u-textLower">Sets the text to use all lowercase</td></tr>',
'    <tr><td><span class="class">u-textInitCap</span></td><td class="u-textInitCap">Sets the first letter in each word to use uppercase</td></tr>',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Transform Classes'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602227179124536219)
,p_plug_name=>'Text Style'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_location=>null
,p_plug_source=>'<p>Use these classes as simple modifiers to control the text style of a given component. For example, you may want to use the <span class="class tag">u-bold</span> to make the text of a button have a stronger weight.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2602227300118536220)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_imp.id(2602227179124536219)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc dm-Report--alignMiddle">',
'  <thead>',
'    <tr>',
'      <th class="u-textStart">Class</th>',
'      <th class="u-textStart">Example</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-text-serif</span></td><td class="u-text-serif">Serif</td></tr>',
'    <tr><td><span class="class">u-text-sansserif<br />u-text-sans-serif</span></td><td class="u-text-sansserif">Sans-Serif</td></tr>',
'    <tr><td><span class="class">u-text-mono</span></td><td class="u-text-mono">Monospace</td></tr>',
'    <tr><td><span class="class">u-text-ultralight<br />u-text-lighter</span></td><td class="u-text-ultralight">Ultralight</td></tr>',
'    <tr><td><span class="class">u-text-light</span></td><td class="u-text-light">Light</td></tr>',
'    <tr><td><span class="class">u-text-normal</span></td><td class="u-text-normal">Normal</td></tr>',
'    <tr><td><span class="class">u-text-semibold<br />u-text-semi-bold</span></td><td class="u-text-semibold">Semi-Bold</td></tr>',
'    <tr><td><span class="class">u-bold<br />u-text-bold</span></td><td class="u-text-bold">Bold</td></tr>',
'    <tr><td><span class="class">u-text-heavy<br />u-text-bolder</span></td><td class="u-text-heavy">Heavy</td></tr>',
'    <tr><td><span class="class">u-italics</span></td><td class="u-italics">Italicize</td></tr>',
'    <tr><td><span class="class">u-underline</span></td><td class="u-underline">Underline</td></tr>',
'    <tr><td><span class="class">u-fixedFont</span></td><td class="u-fixedFont">Use a fixed-letter-space font</td></tr>',
'    <tr><td><span class="class">u-hidden</span></td><td>Hide text</td></tr>',
'    <tr><td><span class="class">u-visible</span></td><td>Show text</td></tr>',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Style Classes'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3084491393855867125)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3092182057030762624)
,p_plug_name=>'Introduction'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>You can use the following utility classes anywhere in your app to fine-tune the layout of your page and components. For most Oracle APEX components, you can simply populate the <b>CSS Classes</b> property to apply these modifiers to your page comp'
||'onents.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3690443665265012724)
,p_plug_name=>'Text Alignment'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_location=>null
,p_plug_source=>'<p>These classes are direction aware, meaning the text direction will be based on the direction of the language. For example, text using the <span class="class tag">u-text<span class="class-var">Start</span></span> class will align text to the left f'
||'or Left-to-Right languages, and will align text to the right for Right-to-Left languages.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4188030900860037831)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_imp.id(3690443665265012724)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th class="u-textStart">Class</th>',
'      <th class="u-textStart">Example</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-textStart</span></td><td class="u-textStart">Align text to the start of the container</td></tr>',
'    <tr><td><span class="class">u-textCenter</span></td><td class="u-textCenter">Align text to the center of the container</td></tr>',
'    <tr><td><span class="class">u-textEnd</span></td><td class="u-textEnd">Align text to the end of the container</td></tr>',
'  </tbody>',
'</table>'))
,p_landmark_label=>'Alignment Classes'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6811210364259410132)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(3742565773051433615)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp.component_end;
end;
/
