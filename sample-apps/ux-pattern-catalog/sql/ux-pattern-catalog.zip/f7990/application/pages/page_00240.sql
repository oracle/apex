prompt --application/pages/page_00240
begin
--   Manifest
--     PAGE: 00240
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>240
,p_name=>'Full Page Search'
,p_alias=>'FULL-PAGE-SEARCH'
,p_step_title=>'Search - Full Page'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-ContentRow-title {',
'    font-weight: 400;',
'}'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Provides a focused, full-page search experience that starts with a single search field and replaces the prompt with matching content rows after the user enters a term.',
'',
'## When to Use',
'',
'Use when search is the primary task and users benefit from a distraction-free entry state followed by a compact results list. This page is suited to keyword lookup across a modest record set.',
'',
'## Implementation Guidance',
'',
'Submit the search item with the results region, normalize the search term in SQL, and search only fields users expect. Keep the input debounce short enough to feel responsive, protect expensive queries with appropriate indexes or a minimum-term rule,'
||' and make result rows open the matching record when real data is used.'))
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49790625862217151575)
,p_plug_name=>'Search Results'
,p_static_id=>'pattern-search-results'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>60
,p_plug_grid_column_span=>8
,p_plug_display_column=>3
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with results as (',
'    select',
'        1 as id,',
'        ''Record 001'' as title,',
'        ''Summary information and current context for this record.'' as description,',
'        ''Standard Record'' as category,',
'        ''assigned, customer-facing, current'' as tags,',
'        sysdate - interval ''30'' minute as updated_on,',
'        ''fa-file-text-o'' as icon,',
'        ''Standard Record'' as overline',
'    from sys.dual',
'    union all',
'    select',
'        2,',
'        ''Record 002'',',
'        ''Supporting details are currently being prepared and reviewed.'',',
'        ''Review Record'',',
'        ''internal, draft, supporting-docs'',',
'        sysdate - interval ''3'' hour,',
'        ''fa-clipboard-check'',',
'        ''Review Record''',
'    from sys.dual',
'    union all',
'    select',
'        3,',
'        ''Record 003'',',
'        ''Recent changes require confirmation before work can continue.'',',
'        ''Tracked Record'',',
'        ''assigned, follow-up'',',
'        sysdate - interval ''1'' day,',
'        ''fa-list-alt'',',
'        ''Tracked Record''',
'    from sys.dual',
'    union all',
'    select',
'        4,',
'        ''Record 004'',',
'        ''Reference information and supporting material are available.'',',
'        ''Reference Record'',',
'        ''published, shared, documentation'',',
'        sysdate - interval ''4'' day,',
'        ''fa-book'',',
'        ''Reference Record''',
'    from sys.dual',
'    union all',
'    select',
'        5,',
'        ''Record 005'',',
'        ''All required work has been completed and validated.'',',
'        ''Standard Record'',',
'        ''validated, complete'',',
'        sysdate - interval ''7'' day,',
'        ''fa-check-square-o'',',
'        ''Standard Record''',
'    from sys.dual',
') ',
'select * ',
'  from results',
' where upper(title) like ''%'' || upper(trim(:P240_SEARCH_FIELD)) || ''%''',
'    or upper(description) like ''%'' || upper(trim(:P240_SEARCH_FIELD)) || ''%'''))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'updated_on desc'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P240_SEARCH_FIELD'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>'No Results. Try searching for "Record."'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON. fa-lg',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', wwv_flow_string.join(wwv_flow_t_varchar2(
    '&DESCRIPTION.',
    '<div>',
    '{loop "," TAGS/}',
    '    <span class="t-Badge t-Badge--subtle t-Badge--sm"><span class="t-Badge-value">&APEX$ITEM.</span></span>',
    '{endloop/}',
    '</div>')),
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'MISC', 'Updated &UPDATED_ON.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Displays the matching records for the Full Page Search after the user enters a term. The sample query matches title and description, and the region submits P240_SEARCH_FIELD during its AJAX refresh.',
'',
'## When to Use',
'',
'Use when users need to review and open records returned by a search, filter, or browse action. This pattern works well when titles alone are not enough to distinguish results and users benefit from supporting descriptions, categories, status, or rece'
||'ncy.',
'',
'## When to Avoid',
'',
'Avoid when users need to compare many attributes across records, edit values directly, or analyze large result sets. Use a report, interactive grid, cards, or faceted search pattern instead.',
'',
'## AI Guidance',
'',
'Lead with the record title and include only the supporting details needed to distinguish one result from another. Use the overline for a stable category or record type, the badge for a meaningful status, and the metadata area for concise secondary in'
||'formation such as the last update date.',
'',
'Keep the entire row selectable when it opens the record. Reserve the row menu for less common secondary actions. Apply semantic badge states consistently, avoid decorative status colors, and keep row structure and metadata placement consistent across'
||' all results.',
''))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49790670304821585191)
,p_name=>'CATEGORY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49790670264137585190)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49790670714681585195)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49790670084229585188)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49790671421640585202)
,p_name=>'OVERLINE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OVERLINE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>150
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(25432046360510023915)
,p_name=>'TAGS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TAGS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>160
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49790670167207585189)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49790670639379585194)
,p_name=>'UPDATED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPDATED_ON'
,p_data_type=>'DATE'
,p_display_sequence=>70
,p_format_mask=>'SINCE'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(49790671916136585207)
,p_region_id=>wwv_flow_imp.id(49790625862217151575)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(49790672052781585208)
,p_region_id=>wwv_flow_imp.id(49790625862217151575)
,p_position_id=>363792341120765662
,p_display_sequence=>20
,p_template_id=>363794202317800939
,p_label=>'Row Actions'
,p_static_id=>'row-actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(49790672113897585209)
,p_component_action_id=>wwv_flow_imp.id(49790672052781585208)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Row Action 1'
,p_static_id=>'row-action-1'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(49790672224250585210)
,p_component_action_id=>wwv_flow_imp.id(49790672052781585208)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Row Action 2'
,p_static_id=>'row-action-2'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(49790672364432585211)
,p_component_action_id=>wwv_flow_imp.id(49790672052781585208)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Row Action 3'
,p_static_id=>'row-action-3'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5887398301756534)
,p_plug_name=>'Search Actions'
,p_static_id=>'search-actions'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>8
,p_plug_display_column=>3
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    1 as id,',
'    ''Advanced search'' as title,',
'    ''fa fa-search'' as icon',
'from sys.dual',
'union all',
'select',
'    2 as id,',
'    ''Find a project'' as title,',
'    ''fa fa-apex'' as icon',
'from sys.dual',
'union all',
'select',
'    3 as id,',
'    ''Start a task'' as title,',
'    ''fa fa-tasks'' as icon',
'from sys.dual'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(6304870954348603)
,p_region_id=>wwv_flow_imp.id(5887398301756534)
,p_layout_type=>'GRID'
,p_grid_column_count=>3
,p_title_adv_formatting=>false
,p_title_column_name=>'TITLE'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'ICON'
,p_icon_position=>'TOP'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5884113621756502)
,p_plug_name=>'Search Item Container'
,p_static_id=>'search-container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1571470918551430249
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_display_column=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>'Intent: Positions the full-width search field between the landing prompt and the results. Pattern role: Search input container.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4627369511683249)
,p_plug_name=>'What do you want to search for?'
,p_static_id=>'start-search'
,p_icon_css_classes=>'fa-ai-prompt'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--featured t-HeroRegion--centered'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Creates the initial full-page search landing state and prompts the user to start a search.',
'Pattern role: Search hero.',
'AI guidance: Use a direct task-oriented prompt. Keep this region visible only while no term has been entered so it does not compete with results.'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5885526548756516)
,p_name=>'P240_SEARCH_FIELD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5884113621756502)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Search'
,p_placeholder=>'Enter search...'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>2042262243893469891
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'SEARCH',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Captures the keyword used to retrieve full-page search results.',
'Pattern role: Primary search input.',
'Implementation guidance: This value is trimmed in the results SQL and submitted during refresh. For production data, define the searchable fields, validate any minimum length needed for performance, and use a placeholder that reflects the searchable '
||'content.'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5885164119756512)
,p_name=>'Show Search Results'
,p_static_id=>'enable-button-show-search'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P240_SEARCH_FIELD'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'apex.item( "P240_SEARCH_FIELD" ).getValue().length > 0'
,p_bind_type=>'bind'
,p_execution_type=>'DEBOUNCE'
,p_execution_time=>200
,p_execution_immediate=>false
,p_bind_event_type=>'input'
,p_da_event_comment=>'Runs after a short debounce whenever the search field changes. A nonempty term reveals and refreshes results while hiding the landing prompt; an empty term restores the initial state.'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5888107448756542)
,p_event_id=>wwv_flow_imp.id(5885164119756512)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5887398301756534)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5888288800756543)
,p_event_id=>wwv_flow_imp.id(5885164119756512)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide_1'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(49790625862217151575)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5888905863756550)
,p_event_id=>wwv_flow_imp.id(5885164119756512)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(49790625862217151575)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5888041905756541)
,p_event_id=>wwv_flow_imp.id(5885164119756512)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(49790625862217151575)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5888387435756544)
,p_event_id=>wwv_flow_imp.id(5885164119756512)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show_1'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5887398301756534)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5887581343756536)
,p_name=>'Show/Hide Actions and Results'
,p_static_id=>'show-hide-actions-and-results'
,p_event_sequence=>40
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'apex.item( "P240_SEARCH_FIELD" ).getValue().length > 0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_da_event_comment=>'Sets the correct landing or results state when the page first loads, including when P240_SEARCH_FIELD is restored from session state or supplied by a link.'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5887700559756538)
,p_event_id=>wwv_flow_imp.id(5887581343756536)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5887398301756534)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5887887933756539)
,p_event_id=>wwv_flow_imp.id(5887581343756536)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_static_id=>'native-hide_1'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(49790625862217151575)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5887662578756537)
,p_event_id=>wwv_flow_imp.id(5887581343756536)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5887398301756534)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5887953450756540)
,p_event_id=>wwv_flow_imp.id(5887581343756536)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_static_id=>'native-show_1'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(49790625862217151575)
);
wwv_flow_imp.component_end;
end;
/
