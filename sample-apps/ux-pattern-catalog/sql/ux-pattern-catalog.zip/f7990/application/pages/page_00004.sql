prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Component Primitives'
,p_alias=>'COMPONENT-PRIMITIVES'
,p_step_title=>'Component Primitives'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'The Component Primitives index is a catalog context page that introduces reusable component-level patterns and helps users choose an appropriate building block. It is not itself a component pattern to copy.',
'',
'## When to Use',
'',
'Use component primitives when designing focused interface elements such as content rows, cards, lists, badges, actions, and other reusable presentation or interaction structures.',
'',
'## When to Avoid',
'',
'Avoid treating component primitives as complete page patterns. Use Page Patterns when the primary need is overall page structure, information hierarchy, navigation, or task flow.',
'',
'## AI Guidance',
'',
'Treat this page as catalog navigation, not as a component pattern example. Use the linked primitive pages as implementation references. Adapt each primitive to the surrounding page context while preserving its intended hierarchy, interaction role, an'
||'d semantic meaning.'))
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49781186186018264425)
,p_plug_name=>'Component Primitives Catalog'
,p_static_id=>'apex-ux-pattern-catalog'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:t-Region--removeHeader js-removeLandmark:margin-bottom-md'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Explore reusable Oracle APEX component primitives for presenting content, actions, status, navigation, and data input. Each example demonstrates recommended configuration, visual hierarchy, and interaction patterns that developers and AI coding as'
||'sistants can adapt across different application contexts.</p>',
'',
'<p>Choose the primitive that best supports the intended interaction, then combine and configure it to fit the needs of the page.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49796056383412166864)
,p_plug_name=>'Components'
,p_static_id=>'patterns'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:margin-top-md'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>60
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-media-list'' as icon_class,',
'    ''Content Rows'' as title,',
'    ''Present compact, scannable records with supporting metadata, status, icons, badges, and contextual actions.'' as description,',
'    ''content-rows'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-cards'' as icon_class,',
'    ''Cards'' as title,',
'    ''Group related content and actions into flexible visual containers for browsing, comparison, and summary views.'' as description,',
'    ''cards'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-tachometer'' as icon_class,',
'    ''Metrics'' as title,',
'    ''Highlight key values, trends, targets, and supporting context using clear and appropriately emphasized metric displays.'' as description,',
'    ''metrics'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-bar-chart'' as icon_class,',
'    ''Charts'' as title,',
'    ''Visualize comparisons, distributions, composition, and change over time using charts suited to the data and task.'' as description,',
'    ''charts'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-tag'' as icon_class,',
'    ''Status and Badges'' as title,',
'    ''Communicate state, category, priority, and other concise metadata with consistent labels and semantic styling.'' as description,',
'    null as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-hand-pointer-o'' as icon_class,',
'    ''Buttons and Menus'' as title,',
'    ''Present primary, secondary, and contextual actions with clear hierarchy, placement, labeling, and interaction behavior.'' as description,',
'    null as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-check-square-o'' as icon_class,',
'    ''Form Controls'' as title,',
'    ''Capture selections and input using controls that clearly communicate purpose, available choices, and expected interaction.'' as description,',
'    null as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-inbox'' as icon_class,',
'    ''Empty States'' as title,',
'    ''Explain why content is unavailable and provide an appropriate next step when a region, search, or collection has no results.'' as description,',
'    null as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-compass'' as icon_class,',
'    ''Navigation'' as title,',
'    ''Help users understand their location, move between related views, and access the next level of information efficiently.'' as description,',
'    null as page_alias',
'from sys.dual;'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON_CLASS. fa-2x u-opacity-50',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49796056607755166867)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49796056445403166865)
,p_name=>'ICON_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49796056726053166868)
,p_name=>'PAGE_ALIAS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PAGE_ALIAS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49796056574843166866)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(49796056821114166869)
,p_region_id=>wwv_flow_imp.id(49796056383412166864)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'f?p=&APP_ID.:&PAGE_ALIAS.:&SESSION.::&DEBUG.::::'
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'PAGE_ALIAS'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49781187822104264441)
,p_plug_name=>'Component Primitives'
,p_static_id=>'reusable-apex-ux-patterns'
,p_icon_css_classes=>'fa-shapes'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>90
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
