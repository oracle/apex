prompt --application/pages/page_01120
begin
--   Manifest
--     PAGE: 01120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1120
,p_name=>'Metrics'
,p_alias=>'METRICS'
,p_step_title=>'Metrics'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.ux-about-text {',
'    padding: 1rem;',
'    border-bottom: 1px solid var(--ut-component-border-color);',
'    background: var(--ut-component-toolbar-background-color);',
'}',
'',
'.app-PatternGuidance > p:first-child {',
'    font-weight: 600;',
'}',
'',
'.app-PatternGuidance h4 {',
'    text-transform: uppercase;',
'    font-size: 0.75rem;',
'    color: var(--ut-component-text-muted-color);',
'    margin-bottom: 0.25rem;',
'}',
'',
'/* Stretch the percent graph item to full width */',
'.apex-item-pct-graph {',
'    width: 100%;',
'}'))
,p_step_template=>2528119710305719084
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'The Metrics pattern page demonstrates reusable metric-style components for highlighting key values, targets, progress, capacity, utilization, and status. Examples show how metrics can support KPI scorecards, status metric cards, gauges, project progr'
||'ess, and record-detail summaries.',
'',
'## When to Use',
'',
'Use metric components when users need to understand a value quickly, interpret it against a target, maximum, or status, or see supporting context without opening a full report or dashboard.',
'',
'## When to Avoid',
'',
'Avoid metrics when users need to inspect many records, compare many attributes in detail, perform bulk actions, enter data, or understand trends over time. Use a report, interactive grid, chart, or dedicated detail page instead. Do not combine too ma'
||'ny metrics without clear grouping or context.',
'',
'## AI Guidance',
'',
'Use the examples on this page to choose a metric component based on the information and interpretation needed. Use Metric Cards for multiple headline values, badges when state adds meaning, Status Meter Gauges for a value relative to a maximum or tar'
||'get, Percent Graphs for progress across repeated records or a single page-level completion value, and Value Attribute Pairs for structured record detail. Keep labels explicit, values prominent, supporting context concise, and formatting consistent. A'
||'void presenting a metric without a unit, time frame, target, or status when that context is needed for interpretation.'))
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49797279473304980517)
,p_plug_name=>'About'
,p_static_id=>'about'
,p_region_css_classes=>'margin-md'
,p_icon_css_classes=>'fa-mouse-pointer'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Metrics highlight key values, trends, targets, and supporting context using clear and appropriately emphasized metric displays. They work well for quickly communicating performance, progress, capacity, utilization, and current status without requirin'
||'g a full report or dashboard. These patterns demonstrate common ways to use APEX metric components for KPI scorecards, status metric cards, status gauges, project progress, and project-detail summaries.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31507347260218950)
,p_plug_name=>'About'
,p_static_id=>'about-kpi-scorecards'
,p_parent_plug_id=>wwv_flow_imp.id(31507298676218949)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Presents a focused set of headline business measures with current values and concise context for quick comparison.</p>',
'',
'<h4>Best For</h4>',
'<p>Executive or operational users who need to understand current performance immediately without reviewing detail.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31508238544218959)
,p_plug_name=>'About'
,p_static_id=>'about-project-detail-summary'
,p_parent_plug_id=>wwv_flow_imp.id(31507844051218955)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Summarizes the key attributes and values associated with a single record in a compact, easy-to-scan layout.</p>',
'',
'<h4>Best For</h4>',
'<p>Detail pages, modal dialogs, side panels, or master-detail pages where users need context before reviewing or editing the main record.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25444617691583456155)
,p_plug_name=>'About'
,p_static_id=>'about-project-progress'
,p_parent_plug_id=>wwv_flow_imp.id(25444617045126456148)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Shows how far each project has progressed toward completion using a percent graph, with task counts and current progress context.</p>',
'',
'<h4>Best For</h4>',
'',
'<p>Comparing progress across several projects while retaining project-level context.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25444617912061456157)
,p_plug_name=>'About'
,p_static_id=>'about-status-meter-gauge'
,p_parent_plug_id=>wwv_flow_imp.id(25444617844927456156)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Illustrates how much of a defined resource capacity is being used and how the current value relates to the available limit.</p>',
'',
'<h4>Best For</h4>',
'<p>Situations where the user must interpret a value against a maximum or target - not just read an isolated number.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6263809982191228)
,p_plug_name=>'About'
,p_static_id=>'about-status-metric-cards'
,p_parent_plug_id=>wwv_flow_imp.id(6263065650191220)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Displays current operational metrics with badges that communicate whether each condition is healthy, at risk, or requires attention.</p>',
'',
'<h4>Best For</h4>',
'<p>Operational monitoring, service management, compliance, risk, approvals, and any situation where users need both a value and an interpretation of that value.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49797280191380980524)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(24910759108528178725)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31507298676218949)
,p_plug_name=>'KPI Scorecards'
,p_static_id=>'kpi-scorecards'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6307456640348629)
,p_plug_name=>'Pattern: Budget Capacity'
,p_static_id=>'pattern-budget-capacity'
,p_parent_plug_id=>wwv_flow_imp.id(25444617844927456156)
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'u-align-content-center'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''Q3 Marketing Budget'' as label,',
'    58450                 as value,',
'    100000                as max_value,',
'    ''$58,450 of $100,000 budget used'' as tooltip',
'from sys.dual;'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_landmark_type=>'region'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a circular Status Meter Gauge for showing a currency amount consumed against a fixed budget, with thresholds that communicate budget risk.',
'',
'## When to Use',
'',
'Use for spending, funding, or forecast measures where users need to interpret a current amount against a financial limit.',
'',
'## When to Avoid',
'',
'Avoid when users need to compare multiple budget categories, analyze spending over time, or review detailed financial transactions. Use a chart, report, or financial detail page instead.',
'',
'## AI Guidance',
'',
'Use raw numeric values in the source and apply currency formatting in the gauge configuration. Label the budget clearly, provide an exact tooltip such as $58,450 of $100,000 budget used, and set thresholds to reflect meaningful financial risk.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6307522437348630)
,p_region_id=>wwv_flow_imp.id(6307456640348629)
,p_chart_type=>'dial'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_text_type=>'number'
,p_value_format_type=>'currency'
,p_value_decimal_places=>0
,p_value_numeric_pattern=>'$XK'
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_gauge_orientation=>'circular'
,p_gauge_indicator_size=>1
,p_gauge_inner_radius=>.7
,p_gauge_plot_area=>'on'
,p_gauge_start_angle=>90
,p_gauge_angle_extent=>360
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6307674967348631)
,p_chart_id=>wwv_flow_imp.id(6307522437348630)
,p_static_id=>'utilization'
,p_seq=>10
,p_name=>'Utilization'
,p_location=>'REGION_SOURCE'
,p_series_type=>'dial'
,p_items_value_column_name=>'VALUE'
,p_items_max_value=>'MAX_VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_short_desc_column_name=>'TOOLTIP'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_values=>'60000,85000,100000'
,p_threshold_colors=>'green,yellow,red'
,p_threshold_display=>'currentOnly'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31506097578218937)
,p_plug_name=>'Pattern: KPI Scorecards'
,p_static_id=>'pattern-kpi-scorecards'
,p_parent_plug_id=>wwv_flow_imp.id(31507298676218949)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''Total Revenue'' as title,',
'    ''$2.4M''         as metric,',
'    ''This month''    as meta,',
'    ''fa fa-dollar''  as icon',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Open Orders'',',
'    ''1,248'',',
'    ''Currently open'',',
'    ''fa fa-shopping-cart''',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''On-Time Delivery'',',
'    ''94.6%'',',
'    ''This month'',',
'    ''fa fa-truck''',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Avg. Resolution'',',
'    ''3.2 days'',',
'    ''Last 30 days'',',
'    ''fa fa-clock-o''',
'from sys.dual;'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$METRIC_CARD'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AVATAR_ALIGNMENT', 't-MetricCard-body--avatarAlignmentStart',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_POSITION', 't-MetricCard-body--avatarPositionInline',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_TYPE', 'icon',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'META', '&META.',
  'METRIC', '&METRIC.',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates Metric Cards for presenting a focused set of headline business KPIs with prominent values, concise time or context metadata, and category icons.',
'',
'## When to Use',
'',
'Use for executive or operational overviews where users need to understand current performance quickly without reviewing detailed records.',
'',
'## When to Avoid',
'',
'Avoid when users need detailed comparisons, historical trends, record-level context, bulk actions, or data entry. Use a chart, report, interactive grid, or dedicated detail page instead.',
'',
'## AI Guidance',
'',
'Use the title for a specific KPI, the metric for the primary value with its unit or format, and the meta text for a time frame or concise qualifier. Use an icon to reinforce meaning without making it the only cue. Keep the cards structurally consiste'
||'nt and limit the collection to measures that users need to compare at a glance; add badges only when status is part of the KPI''s meaning, as demonstrated in Status Metric Cards.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6304910670348604)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6058468921169743)
,p_name=>'META'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'META'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6058378856169742)
,p_name=>'METRIC'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'METRIC'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6058236944169741)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49817780688320706010)
,p_plug_name=>'Pattern: Percent Capacity'
,p_static_id=>'pattern-percent-capacity'
,p_parent_plug_id=>wwv_flow_imp.id(25444617844927456156)
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>40
,p_plug_grid_column_css_classes=>'u-align-content-center'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''Support Team Utilization'' as label,',
'    round(41 / 50 * 100, 1)    as value,',
'    100                        as max_value,',
'    ''Percent capacity used''    as tooltip',
'from sys.dual;'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_landmark_type=>'region'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a circular Status Meter Gauge for showing percentage capacity used against a defined maximum, with thresholds that indicate when utilization requires attention.',
'',
'## When to Use',
'',
'Use for team utilization, service capacity, quota consumption, or other percentage-based measures where the current value needs to be interpreted against a limit or target.',
'',
'## When to Avoid',
'',
'Avoid when there is no meaningful maximum or target, when users need to understand change over time, or when several categories must be compared precisely. Use a chart, report, or table instead.',
'',
'## AI Guidance',
'',
'Use a clear label for the resource and provide a tooltip that states the current value and limit. Set the maximum to a meaningful capacity, use thresholds to communicate consistent attention levels, and keep the threshold colors semantically consiste'
||'nt with the rest of the application.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6306738215348622)
,p_region_id=>wwv_flow_imp.id(49817780688320706010)
,p_chart_type=>'dial'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_text_type=>'percent'
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_gauge_orientation=>'circular'
,p_gauge_indicator_size=>1
,p_gauge_inner_radius=>.7
,p_gauge_plot_area=>'on'
,p_gauge_start_angle=>90
,p_gauge_angle_extent=>360
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6306803148348623)
,p_chart_id=>wwv_flow_imp.id(6306738215348622)
,p_static_id=>'utilization'
,p_seq=>10
,p_name=>'Utilization'
,p_location=>'REGION_SOURCE'
,p_series_type=>'dial'
,p_items_value_column_name=>'VALUE'
,p_items_max_value=>'MAX_VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_short_desc_column_name=>'TOOLTIP'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_values=>'70,85,100'
,p_threshold_colors=>'#8be89a,#fee47f,#ff3b30'
,p_threshold_display=>'currentOnly'
,p_reference_line_values=>'85'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6959331568595806)
,p_plug_name=>'Pattern: Project Detail Summary'
,p_static_id=>'pattern-project-detail-summary'
,p_title=>'Customer Portal Refresh'
,p_parent_plug_id=>wwv_flow_imp.id(31507844051218955)
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_template_component_type=>'PARTIAL'
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AVATAR_ICON', 'fa-window-user',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_SIZE', 't-Avatar--xs',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', 'PRJ-1042',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'TITLE', 'Customer Portal Refresh')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a record-detail summary that combines a prominent record header, value-attribute pairs, and a percent graph to present a single project''s identity, supporting attributes, and completion status.',
'',
'## When to Use',
'',
'Use on detail pages, modal dialogs, side panels, and master-detail views where users need context about one record before reviewing or editing it.',
'',
'## When to Avoid',
'',
'Avoid when users need to browse or compare many records, inspect a large set of attributes, perform bulk actions, or enter extensive data. Use a report, interactive grid, or form instead.',
'',
'## AI Guidance',
'',
'Use a Content Row or equivalent record header for the primary identity and concise metadata. Use Value Attribute Pairs for a small, scannable set of supporting attributes, excluding values already represented in the header. Use a Percent Graph page i'
||'tem for a single completion value and keep its label visible. Keep the layout focused on one record rather than turning it into a dashboard.'))
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(49817637591151060941)
,p_name=>'Pattern: Project Progress'
,p_static_id=>'pattern-project-progress'
,p_parent_plug_id=>wwv_flow_imp.id(25444617045126456148)
,p_template=>3372714138756020509
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''ERP Upgrade'' as project_name,',
'    round(18 / 25 * 100, 1) as progress_pct,',
'    ''18 of 25 tasks'' as progress_detail,',
'    ''At Risk'' as status',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Mobile Redesign'',',
'    round(9 / 20 * 100, 1),',
'    ''9 of 20 tasks'',',
'    ''On Track''',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Data Migration'',',
'    round(41 / 45 * 100, 1),',
'    ''41 of 45 tasks'',',
'    ''Almost Complete''',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Customer Portal'',',
'    round(12 / 30 * 100, 1),',
'    ''12 of 30 tasks'',',
'    ''On Track''',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Security Review'',',
'    round(6 / 18 * 100, 1),',
'    ''6 of 18 tasks'',',
'    ''Blocked''',
'from sys.dual',
'',
'order by progress_pct desc;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a Classic Report with a Percent Graph column for comparing completion across multiple projects while retaining the project name and progress detail for each row.',
'',
'## When to Use',
'',
'Use for projects, initiatives, workstreams, or task groups where users need to scan progress across several records and retain concise row-level context.',
'',
'## When to Avoid',
'',
'Avoid for a single-record completion value, detailed project analysis, historical progress trends, or collections that require filtering, editing, or bulk actions. Use a Percent Graph page item, chart, interactive report, or interactive grid instead.',
'',
'## AI Guidance',
'',
'Use a numeric value from 0 to 100 for the Percent Graph column, keep the project name visible as the row identifier, and use an adjacent text column for exact progress context such as task counts. Do not rely on the graph alone to communicate importa'
||'nt status; include meaningful text when the state affects interpretation.'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6306561744348620)
,p_query_column_id=>3
,p_column_alias=>'PROGRESS_DETAIL'
,p_column_display_sequence=>30
,p_column_heading=>'Progress Detail'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6306428891348619)
,p_query_column_id=>2
,p_column_alias=>'PROGRESS_PCT'
,p_column_display_sequence=>20
,p_column_heading=>'Progress Percentage'
,p_column_format=>'PCT_GRAPH:::'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6306308775348618)
,p_query_column_id=>1
,p_column_alias=>'PROJECT_NAME'
,p_column_display_sequence=>10
,p_column_heading=>'Project Name'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6306634867348621)
,p_query_column_id=>4
,p_column_alias=>'STATUS'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6307146638348626)
,p_plug_name=>'Pattern: Seat Capacity'
,p_static_id=>'pattern-seat-capacity'
,p_parent_plug_id=>wwv_flow_imp.id(25444617844927456156)
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'u-align-content-center'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''Seats Assigned''          as label,',
'    41                        as value,',
'    50                        as max_value,',
'    ''41 of 50 seats assigned'' as tooltip',
'from sys.dual;'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_landmark_type=>'region'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a horizontal Status Meter Gauge for showing an absolute count against an available capacity, such as assigned seats out of total seats.',
'',
'## When to Use',
'',
'Use for seats, licenses, inventory, staffing, reservations, or other count-based resources where users need to see both the current amount and the remaining capacity.',
'',
'## When to Avoid',
'',
'Avoid when the limit is not meaningful, when the measure is primarily a percentage, or when users need a historical view or detailed breakdown. Use a chart, report, or table instead.',
'',
'## AI Guidance',
'',
'Use raw numeric values for the current amount and maximum capacity, and provide a tooltip that expresses the relationship in user terms, such as 41 of 50 seats assigned. Prefer a horizontal gauge when the count relationship is more important than a p'
||'ercentage view.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6307202803348627)
,p_region_id=>wwv_flow_imp.id(6307146638348626)
,p_chart_type=>'dial'
,p_width=>'250'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_text_type=>'number'
,p_value_position=>'auto'
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_gauge_orientation=>'horizontal'
,p_gauge_indicator_size=>1
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6307387284348628)
,p_chart_id=>wwv_flow_imp.id(6307202803348627)
,p_static_id=>'utilization'
,p_seq=>10
,p_name=>'Utilization'
,p_location=>'REGION_SOURCE'
,p_series_type=>'dial'
,p_items_value_column_name=>'VALUE'
,p_items_max_value=>'MAX_VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_short_desc_column_name=>'TOOLTIP'
,p_color=>'#4251bf'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'currentOnly'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6263112863191221)
,p_plug_name=>'Pattern: Status Metric Cards'
,p_static_id=>'pattern-status-metric-cards'
,p_parent_plug_id=>wwv_flow_imp.id(6263065650191220)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''Service Availability'' as title,',
'    ''99.95%''             as metric,',
'    ''Last 30 days''       as meta,',
'    ''fa-server''          as icon,',
'    ''Healthy''            as badge_label,',
'    ''success''            as badge_state',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Open Incidents''     as title,',
'    ''3''                  as metric,',
'    ''2 critical''         as meta,',
'    ''fa-exclamation-triangle'' as icon,',
'    ''Attention''          as badge_label,',
'    ''warning''            as badge_state',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Pending Reviews''    as title,',
'    ''12''                 as metric,',
'    ''Due this week''      as meta,',
'    ''fa-file-text-o''     as icon,',
'    ''Review''             as badge_label,',
'    ''info''               as badge_state',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Failed Jobs''        as title,',
'    ''1''                  as metric,',
'    ''Last run 15 minutes ago'' as meta,',
'    ''fa-cogs''            as icon,',
'    ''Error''              as badge_label,',
'    ''danger''             as badge_state',
'from sys.dual'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$METRIC_CARD'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AVATAR_ALIGNMENT', 't-MetricCard-body--avatarAlignmentCenter',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_POSITION', 't-MetricCard-body--avatarPositionInline',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_SIZE', 't-Avatar--sm',
  'AVATAR_STYLE', 't-MetricCard-avatar--subtle',
  'AVATAR_TYPE', 'icon',
  'BADGE_LABEL', '&BADGE_LABEL.',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'BADGE_LABEL',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'LAYOUT', '2cols',
  'META', '&META.',
  'METRIC', '&METRIC.',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates Metric Cards for presenting current operational values with a category icon, prominent metric, supporting context, and status badge.',
'',
'## When to Use',
'',
'Use for operational monitoring, service management, compliance, risk, approvals, and other situations where users need both a value and an interpretation of its current condition.',
'',
'## When to Avoid',
'',
'Avoid when users need detailed records, exact comparison across many attributes, historical trends, bulk actions, or data entry. Use a report, chart, interactive grid, or dedicated detail page instead.',
'',
'## AI Guidance',
'',
'Use the title for the metric name, the metric for the primary value, and the meta text for a unit, time frame, or concise qualifier. Use the icon to reinforce the metric category and use one badge to communicate its current state; the badge state sho'
||'uld add meaning rather than repeat the metric. Keep the hierarchy and formatting consistent across the cards, and do not rely on color alone to communicate status.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6959796064595810)
,p_name=>'BADGE_LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_LABEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6959823866595811)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6959633393595809)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6263596579191225)
,p_name=>'META'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'META'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6263429691191224)
,p_name=>'METRIC'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'METRIC'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6263363196191223)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31507844051218955)
,p_plug_name=>'Project Detail Summary'
,p_static_id=>'project-detail-summary'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(92555609556662871173)
,p_name=>'Project Details'
,p_static_id=>'project-details'
,p_parent_plug_id=>wwv_flow_imp.id(6959331568595806)
,p_template=>4502917002193490937
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--variableLabelLarge:t-AVPList--leftAligned'
,p_new_grid_row=>false
,p_new_grid_column=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''PRJ-1042''                as project_id,',
'    ''Customer Portal Refresh'' as project_name,',
'    ''Maya Chen''               as owner,',
'    ''In Progress''             as status,',
'    ''High''                    as priority,',
'    date ''2026-12-15''         as target_date,',
'    78450                     as budget,',
'    68                        as completion,',
'    date ''2026-09-15''         as last_updated',
'from sys.dual;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2101991776017792140
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6309385517348648)
,p_query_column_id=>7
,p_column_alias=>'BUDGET'
,p_column_display_sequence=>80
,p_column_heading=>'Budget'
,p_column_format=>'FML999G999G999G999G990D00'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6309496474348649)
,p_query_column_id=>8
,p_column_alias=>'COMPLETION'
,p_column_display_sequence=>110
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6309578546348650)
,p_query_column_id=>9
,p_column_alias=>'LAST_UPDATED'
,p_column_display_sequence=>100
,p_column_heading=>'Last Updated'
,p_column_format=>'Mon DD, YYYY'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6308975374348644)
,p_query_column_id=>3
,p_column_alias=>'OWNER'
,p_column_display_sequence=>40
,p_column_heading=>'Owner'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6309192919348646)
,p_query_column_id=>5
,p_column_alias=>'PRIORITY'
,p_column_display_sequence=>60
,p_column_heading=>'Priority'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6308783791348642)
,p_query_column_id=>1
,p_column_alias=>'PROJECT_ID'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6308842345348643)
,p_query_column_id=>2
,p_column_alias=>'PROJECT_NAME'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6309049122348645)
,p_query_column_id=>4
,p_column_alias=>'STATUS'
,p_column_display_sequence=>50
,p_column_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6309238870348647)
,p_query_column_id=>6
,p_column_alias=>'TARGET_DATE'
,p_column_display_sequence=>90
,p_column_heading=>'Target Date'
,p_column_format=>'Mon DD, YYYY'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25444617045126456148)
,p_plug_name=>'Project Progress'
,p_static_id=>'project-progress'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25444617844927456156)
,p_plug_name=>'Status Meter Gauge'
,p_static_id=>'status-meter-gauge'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6263065650191220)
,p_plug_name=>'Status Metric Cards'
,p_static_id=>'status-metric-cards'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92555608643967871164)
,p_plug_name=>'Region Display Selector'
,p_static_id=>'tabs'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6959419742595807)
,p_name=>'P1120_COMPLETION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6959331568595806)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Completion'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    68 as completion',
'from sys.dual;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_PCT_GRAPH'
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'foreground_color', '#4251bf',
  'show_value', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
