prompt --application/pages/page_00210
begin
--   Manifest
--     PAGE: 00210
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>210
,p_name=>unistr('Faceted Search \2013\00A0Cards')
,p_alias=>'FACETED-SEARCH-CARDS'
,p_step_title=>unistr('Faceted Search \2013\00A0Cards')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2528119710305719084
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrate this page pattern as a reusable, production-quality Oracle APEX experience.',
'',
'## When to Use',
'',
'Use when this page''s primary user task matches the pattern represented by its title and structure.',
'',
'## When to Avoid',
'',
'Avoid when another catalog pattern better supports the user''s task, information density, or workflow complexity.',
'',
'## AI Guidance',
'',
'Preserve the page''s pattern-first structure, generic terminology, accessible labels, semantic formatting, and clear action hierarchy. Keep documentation in metadata rather than visible instructional text.',
'            '))
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12444336935121566)
,p_plug_name=>'Active Facets Go Here'
,p_static_id=>'active-facets'
,p_region_name=>'active_facets'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Shows the filters currently applied so users can understand and adjust the result set.',
'Pattern role: Active-filter summary.',
'AI guidance: Keep this region visually associated with the results and ensure clearing individual or all filters is discoverable.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12342472238128076)
,p_plug_name=>'Faceted Search with Cards'
,p_static_id=>'button-bar'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<span class="u-text-body-sm u-text-muted-color"><span id="total_row_count">Loading</span> Rows</span>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides the page context and current result count for the faceted card search experience.',
'Pattern role: Search context and result summary.',
'AI guidance: Keep the result count concise and update it as filters change. Do not use this region for instructional text or competing page actions.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12340106550128071)
,p_plug_name=>'Search'
,p_static_id=>'search'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(12340027781128071)
,p_landmark_label=>'Filters'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'current_facets_selector', '#active_facets',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'E',
  'show_total_row_count', 'E',
  'total_row_count_selector', '#total_row_count')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides the primary filtering surface for narrowing a larger set of card results.',
'Pattern role: Faceted search controls.',
'AI guidance: Keep facets limited to meaningful filtering dimensions. Put the broadest or most frequently used filters first, preserve accessible labels, and avoid exposing filters that do not help users decide which cards to inspect.'))
);
wwv_flow_imp_page.create_page_item_group(
 p_id=>wwv_flow_imp.id(12367918395430741)
,p_page_plug_id=>wwv_flow_imp.id(12340106550128071)
,p_label=>'Feature Flags'
,p_static_id=>'feature-flags'
,p_display_sequence=>90
,p_icon_css_classes=>'fa-flag-checkered'
,p_fc_filter_combination=>'OR'
,p_fc_sort_by_top_counts=>true
,p_fc_show_more_count=>7
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_display_as=>'INLINE'
,p_group_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Groups related boolean filters under one conceptual facet category.',
'Pattern role: Grouped facet controls.',
'AI guidance: Group related filters only when they represent a coherent dimension. Avoid using a facet group to collect unrelated options.'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12390923951561692)
,p_item_group_id=>wwv_flow_imp.id(12367918395430741)
,p_name=>'P210_FLAG_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12340106550128071)
,p_prompt=>'Feature Flag 1'
,p_source=>'FLAG_1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'use_defaults', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12391061390561693)
,p_item_group_id=>wwv_flow_imp.id(12367918395430741)
,p_name=>'P210_FLAG_2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(12340106550128071)
,p_prompt=>'Feature Flag 2'
,p_source=>'FLAG_2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'use_defaults', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12391172789561694)
,p_item_group_id=>wwv_flow_imp.id(12367918395430741)
,p_name=>'P210_FLAG_3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(12340106550128071)
,p_prompt=>'Feature Flag 3'
,p_source=>'FLAG_3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'use_defaults', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12391216007561695)
,p_item_group_id=>wwv_flow_imp.id(12367918395430741)
,p_name=>'P210_FLAG_4'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(12340106550128071)
,p_prompt=>'Feature Flag 4'
,p_source=>'FLAG_4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'use_defaults', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12366599016430728)
,p_name=>'P210_CATEGORY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(12340106550128071)
,p_prompt=>'Category'
,p_source=>'CATEGORY'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_icon_css_classes=>'fa-shapes'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12367423155430736)
,p_name=>'P210_PRIORITY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(12340106550128071)
,p_prompt=>'Priority'
,p_source=>'PRIORITY'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov_sort_direction=>'ASC'
,p_item_icon_css_classes=>'fa-exclamation-square-o'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'hide_radio_buttons', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12349354944128103)
,p_name=>'P210_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12340106550128071)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12366840785430730)
,p_name=>'P210_UPDATED_ON'
,p_source_data_type=>'DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(12340106550128071)
,p_prompt=>'Last Updated'
,p_source=>'UPDATED_ON'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_item_icon_css_classes=>'fa-calendar-month'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'N',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12340027781128071)
,p_plug_name=>'Search Results'
,p_static_id=>'search-results'
,p_region_template_options=>'t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc:t-CardsRegion--styleC'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Sample data for browse-oriented UX patterns.',
'',
'The values in this query are intentionally generic and synthetic.',
'Replace the query with application-specific data while preserving',
'the same overall shape:',
'',
'- Primary label',
'- Secondary description',
'- Category facet',
'- Priority facet',
'- Date facet',
'- Boolean flag facets',
'- Icon',
'- Badge',
'',
'This allows the same content row, cards, and faceted search patterns',
'to be reused across different application domains.',
'*/',
'select * from (',
'    select',
'        level as id,',
'        ''Item '' || level as title,',
'        case mod(level - 1, 4)',
'            when 0 then ''Summary for item '' || level',
'            when 1 then ''Description for item '' || level',
'            when 2 then ''Supporting text for item '' || level',
'            else ''Additional note for item '' || level',
'        end as description,',
'        case mod(level - 1, 5)',
'            when 0 then ''Category A''',
'            when 1 then ''Category B''',
'            when 2 then ''Category C''',
'            when 3 then ''Category D''',
'            else ''Category E''',
'        end as category,',
'        trunc(sysdate) - mod(level, 30) as updated_on,',
'        case mod(level - 1, 6)',
'            when 0 then ''fa-columns''',
'            when 1 then ''fa-search''',
'            when 2 then ''fa-table''',
'            when 3 then ''fa-id-card-o''',
'            when 4 then ''fa-edit''',
'            else ''fa-clone''',
'        end as icon,',
'        case mod(level - 1, 3)',
'            when 0 then ''High''',
'            when 1 then ''Medium''',
'            else ''Low''',
'        end as priority,',
'        case mod(level - 1, 3)',
'            when 0 then ''danger''',
'            when 1 then ''warning''',
'            else ''success''',
'        end as badge_state,',
'        case when mod(level, 2) = 0 then ''Y'' else ''N'' end as flag_1,',
'        case when mod(level, 3) = 0 then ''Y'' else ''N'' end as flag_2,',
'        case when mod(level, 4) = 0 then ''Y'' else ''N'' end as flag_3,',
'        case when mod(level, 5) = 0 then ''Y'' else ''N'' end as flag_4,',
'        ''Category '' || chr(64 + mod(level - 1, 5) + 1) as overline,',
'        ''Updated '' || to_char(trunc(sysdate) - mod(level, 30), ''Mon DD'') as meta',
'    from dual',
'    connect by level <= 24',
'    order by level',
')'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Presents filtered records as visual cards for quick scanning and selection.',
'Pattern role: Faceted card results.',
'AI guidance: Keep card content consistent and scannable. Use the title, description, category, date, icon, and badge to support comparison without turning each card into a dense report. Preserve one clear path to item detail.'))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(7137504112059200)
,p_region_id=>wwv_flow_imp.id(12340027781128071)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITLE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'CATEGORY'
,p_body_adv_formatting=>false
,p_body_column_name=>'DESCRIPTION'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa &ICON.'
,p_icon_position=>'START'
,p_badge_column_name=>'PRIORITY'
,p_badge_label=>'Priority'
,p_badge_css_classes=>'u-&BADGE_STATE.'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(7138044442059201)
,p_card_id=>wwv_flow_imp.id(7137504112059200)
,p_action_type=>'TITLE'
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(7138653876059202)
,p_card_id=>wwv_flow_imp.id(7137504112059200)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'Edit'
,p_static_id=>'action_1'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-edit'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(7139166459059202)
,p_card_id=>wwv_flow_imp.id(7137504112059200)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'Primary Action'
,p_static_id=>'action_1_1'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-heart-o u-danger-text'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7131533169059194)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(12342472238128076)
,p_button_name=>'ACTIONS_MENU'
,p_static_id=>'actions-menu'
,p_show_as_disabled=>false
,p_button_type=>'MENU'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Actions Menu'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ellipsis-v'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(12389922190561736)
,p_button_id=>wwv_flow_imp.id(7131533169059194)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Menu Action 1'
,p_static_id=>'menu-action-1'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(12446971020121587)
,p_button_id=>wwv_flow_imp.id(7131533169059194)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Menu Action 2'
,p_static_id=>'menu-action-2'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(12447058254121588)
,p_button_id=>wwv_flow_imp.id(7131533169059194)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Menu Action 3'
,p_static_id=>'menu-action-3'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7133071965059195)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(12342472238128076)
,p_button_name=>'PRIMARY_ACTION'
,p_static_id=>'primary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Primary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7133491990059195)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(12342472238128076)
,p_button_name=>'SECONDARY_ACTION'
,p_static_id=>'secondary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Secondary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp.component_end;
end;
/
