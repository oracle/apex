prompt --application/pages/page_00330
begin
--   Manifest
--     PAGE: 00330
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>330
,p_name=>'Item Selection with Details'
,p_alias=>'ITEM-SELECTION-WITH-DETAILS'
,p_step_title=>'Item Selection with Details'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#js/split-view-selection#MIN#.js'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Keep contextual information compact and make its status badges easy to scan. */',
'.app-ContextualInfo {',
'  --ut-contextualinfo-item-label-stacked-margin-y: 0;',
'  --ut-badge-font-weight: 600;',
'}',
'',
'/* Establish visual hierarchy between featured, standard, and compact activity rows. */',
'.app-ActivityTimeline .is-standard {',
'  --ut-cr-title-font-weight: 600;',
'}',
'',
'.app-ActivityTimeline .is-compact {',
'  --ut-cr-title-font-size: 0.875rem;',
'  --ut-cr-title-font-weight: 400;',
'}',
'',
'/* Temporarily loading utility class for full height */',
'.u-block-size-full {',
'  block-size: 100%;',
'}'))
,p_step_template=>2528119710305719084
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a split-view item detail pattern with a searchable, selectable list on the left and contextual details for the selected item on the right.',
'',
'## When to Use',
'',
'Use when users need to inspect several items one at a time while keeping the surrounding list visible. This works well for inbox, review, triage, queue, and administrative experiences.',
'',
'## When to Avoid',
'',
'Avoid when users need bulk actions, detailed comparison, extensive editing, or a long multi-step workflow. Use a report, browse, sectioned, or tabbed pattern instead.',
'',
'## AI Guidance',
'',
'Preserve the split-view hierarchy: search and filtering, single-selection list, then selected-item identity, actions, summary, supporting details, related information, and activity.',
'',
'The page loads `split-view-selection.js` to restore or reconcile list selection, select the first available row when needed, handle empty results, toggle detail and empty-state regions, and keep the selected row visible.',
'',
'Initialize `appSplitViewSelection` on Page Ready and call `reconcile()` after `tablemodelviewpagechange`.',
'',
'Use `P330_SELECTED_ITEM_ID_UI` for the Content Row selection and `P330_SELECTED_ITEM_ID` as the canonical context used by detail-region queries.',
'',
'Mark data-dependent regions with `.js-item-refresh` and submit `P330_SELECTED_ITEM_ID` when they refresh. Mark selected-item content with `.js-selected-item-content` and the empty-state region with `.js-selected-item-empty`.',
'',
'Keep terminology generic, summaries concise, semantic states consistent, and the action hierarchy clear. Use component comments to explain intent, data mappings, refresh dependencies, and custom behavior.',
''))
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24902584620620802907)
,p_plug_name=>'Recent Activity'
,p_static_id=>'activity'
,p_region_css_classes=>'js-item-refresh js-selected-item-content'
,p_region_sub_css_classes=>'app-ActivityTimeline'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Activity timeline pattern sample',
'',
'Purpose:',
'',
'* Demonstrates how to build a representative activity timeline for an item detail pattern.',
'* Shows a balanced mix of event types, row densities, and content shapes so AI-generated pages can learn the intended UX structure.',
'',
'Implementation notes:',
'',
'* The timeline is intentionally data-driven but not business-dependent.',
'* The selected item ID is used as a seed so the example changes when the current record changes, while remaining stable for the same record.',
'* Hash-based variation is used to produce realistic-looking labels, titles, and metrics without hardcoding business data.',
'* Some rows are rich and descriptive; others are compact or title-only to show that not every activity needs equal detail.',
'* Attribute changes should communicate the new state directly in the title.',
'* Comment and file events should surface the meaningful payload as early as possible.',
'* Description text should add only supporting context such as prior value, author, or follow-up note.',
'',
'Pattern guidance:',
'',
'* Use this region as a reusable reference for AI-generated item detail pages.',
'* Keep labels generic and interaction-focused so the pattern can be adapted to any business domain.',
'* Prefer representative structure over realistic transactional completeness.',
'* Avoid encoding domain-specific meaning into the sample unless the pattern is explicitly tied to that domain.',
'  */',
'',
'',
'with seed as (',
'    select nvl(:P330_SELECTED_ITEM_ID, ''0'') as item_id',
'    from dual',
')',
'select ''Today'' as activity_group,',
'       10 as display_sequence,',
'       sysdate - interval ''1'' hour as activity_time,',
'       ''Maya Chen'' as actioned_by,',
'       ''Updated'' as action_type,',
'       null as badge_label,',
'       ''Status changed to '' ||',
'           case mod(ora_hash(seed.item_id || '':status''), 4)',
'               when 0 then ''On Track''',
'               when 1 then ''Needs Review''',
'               when 2 then ''At Risk''',
'               else ''Blocked''',
'           end as title,',
'       ''Previous status: '' ||',
'           case mod(ora_hash(seed.item_id || '':prev_status''), 4)',
'               when 0 then ''On Track''',
'               when 1 then ''Needs Review''',
'               when 2 then ''At Risk''',
'               else ''Blocked''',
'           end as description,',
'       ''fa-check-circle-o u-success-text'' as icon_class,',
'       ''is-featured'' as row_class,',
'       1 as id',
'  from seed',
'union all',
'select ''Today'',',
'       20,',
'       sysdate - interval ''4'' hour,',
'       ''Jordan Lee'',',
'       ''Reviewed'',',
'       null,',
'       ''Review completed for item '' || seed.item_id,',
'       ''Next step confirmed for the current owner'',',
'       ''fa-check-circle-o u-success-text'',',
'       ''is-standard'',',
'       2',
'  from seed',
'union all',
'select ''This Week'',',
'       30,',
'       trunc(sysdate) - 2 + (9/24),',
'       ''Maya Chen'',',
'       ''Commented'',',
'       null,',
'       ''We should confirm the owner before moving item '' || seed.item_id || '' forward.'',',
'       ''Comment added to the current record'',',
'       ''fa-comments-o u-info-text'',',
'       ''is-standard'',',
'       3',
'  from seed',
'union all',
'select ''This Week'',',
'       40,',
'       trunc(sysdate) - 3 + (14/24),',
'       ''Jordan Lee'',',
'       ''Adjusted'',',
'       null,',
'       ''Target Date set to October 1'',',
'       ''Previous target date: September 18'',',
'       ''fa-calendar-o u-info-text'',',
'       ''is-standard'',',
'       4',
'  from seed',
'union all',
'select ''Earlier'',',
'       50,',
'       trunc(sysdate) - 7 + (11/24),',
'       null,',
'       null,',
'       null,',
'       ''Ownership assigned to Avery Smith for ongoing follow-up'',',
'       null,',
'       ''fa-user u-info-text'',',
'       ''is-compact'',',
'       5',
'  from seed',
'union all',
'select ''Earlier'',',
'       60,',
'       trunc(sysdate) - 9 + (10/24),',
'       null,',
'       null,',
'       null,',
'       ''Standard Intake linked to support the current record'',',
'       null,',
'       ''fa-link u-info-text'',',
'       ''is-compact'',',
'       6',
'  from seed',
'union all',
'select ''Earlier'',',
'       70,',
'       trunc(sysdate) - 10 + (12/24),',
'       null,',
'       null,',
'       null,',
'       ''Reference removed after duplicate values were identified'',',
'       null,',
'       ''fa-minus-circle-o u-danger-text'',',
'       ''is-compact'',',
'       7',
'  from seed',
'union all',
'select ''Earlier'',',
'       80,',
'       trunc(sysdate) - 11 + (16/24),',
'       null,',
'       null,',
'       null,',
'       ''Initial record created and prepared for first review'',',
'       null,',
'       ''fa-plus-circle-o u-info-text'',',
'       ''is-compact'',',
'       8',
'  from seed;'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'display_sequence, activity_group'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P330_SELECTED_ITEM_ID'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON_CLASS.',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_SIZE', 't-Avatar--sm',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'GROUP_TITLE', '<div class="u-text-uppercase u-text-muted-color u-text-body-xs u-text-bold">&ACTIVITY_GROUP.</div>',
  'HIDE_BORDERS', 'N',
  'ITEM_CSS_CLASSES', '&ROW_CLASS.',
  'MISC', '&ACTIVITY_TIME.',
  'OVERLINE', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{if ACTIONED_BY/}',
    '    &ACTIONED_BY.{if ACTION_TYPE/} &middot; &ACTION_TYPE.{endif/}',
    '{elseif ACTION_TYPE/}',
    '    &ACTION_TYPE.',
    '{endif/}')),
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Shows meaningful changes, decisions, comments, and events associated with the current item.',
'',
'Pattern role: Activity timeline.',
'',
'AI guidance: Make the event title carry the meaningful payload at a glance. Attribute changes should describe the new value or state. File events should identify the file. Comment events should surface the comment text. Use the description only for u'
||'seful supporting context such as a previous value, author, or note. Keep some rows title-only and retain a mix of featured, standard, and compact rows to demonstrate different event shapes. Use featured rows for especially important events and compac'
||'t rows for lower-detail history.',
'',
'Implementation note: This region participates in selected-item refreshes through `.js-item-refresh` and submits `P330_SELECTED_ITEM_ID` when refreshed.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24902585054892802911)
,p_name=>'ACTIONED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIONED_BY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24902585149117802912)
,p_name=>'ACTION_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTION_TYPE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24902584755905802908)
,p_name=>'ACTIVITY_GROUP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIVITY_GROUP'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>true
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24902584949230802910)
,p_name=>'ACTIVITY_TIME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIVITY_TIME'
,p_data_type=>'DATE'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24902585234082802913)
,p_name=>'BADGE_LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_LABEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24902585442155802915)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24902584870968802909)
,p_name=>'DISPLAY_SEQUENCE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DISPLAY_SEQUENCE'
,p_data_type=>'NUMBER'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24902585594938802916)
,p_name=>'ICON_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24902585811856802918)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>110
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24902585630601802917)
,p_name=>'ROW_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROW_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24902585352406802914)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(24902441344769216906)
,p_name=>'Details 1'
,p_static_id=>'details'
,p_parent_plug_id=>wwv_flow_imp.id(24902504497986674697)
,p_template=>3372714138756020509
,p_display_sequence=>40
,p_region_css_classes=>'js-item-refresh'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Item Reference '' || nvl(:P330_SELECTED_ITEM_ID, 0) as reference,',
'       ''Standard Intake'' as source,',
'       ''Summary Record'' as type,',
'       ''Tracked, Reviewable'' as tags',
'  from dual;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P330_SELECTED_ITEM_ID'
,p_lazy_loading=>false
,p_query_row_template=>2101991776017792140
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Presents stable, descriptive attributes that characterize the selected item.',
'',
'Pattern role: Attribute-pair detail layout.',
'',
'AI guidance: Use this group for classification-style properties such as type, category, source, and tags. Keep labels concise and values consistently formatted for scanning. Do not mix in ownership, timing, progress, or operational status; place thos'
||'e in separate groups.',
'',
'Implementation note: This region participates in selected-item refreshes through `.js-item-refresh` and submits `P330_SELECTED_ITEM_ID` when refreshed.'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893981385231818352)
,p_query_column_id=>1
,p_column_alias=>'REFERENCE'
,p_column_display_sequence=>10
,p_column_heading=>'Reference'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893981801508818352)
,p_query_column_id=>2
,p_column_alias=>'SOURCE'
,p_column_display_sequence=>20
,p_column_heading=>'Source'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893982191536818352)
,p_query_column_id=>4
,p_column_alias=>'TAGS'
,p_column_display_sequence=>60
,p_column_heading=>'Tags'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893982562881818352)
,p_query_column_id=>3
,p_column_alias=>'TYPE'
,p_column_display_sequence=>30
,p_column_heading=>'Type'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(24902504559146674698)
,p_name=>'Details 2'
,p_static_id=>'details-2'
,p_parent_plug_id=>wwv_flow_imp.id(24902504497986674697)
,p_template=>3372714138756020509
,p_display_sequence=>50
,p_region_css_classes=>'js-item-refresh'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    to_char(mod(ora_hash(nvl(:P330_SELECTED_ITEM_ID, ''0'')), 101)) || ''%'' as progress,',
'    case mod(ora_hash(nvl(:P330_SELECTED_ITEM_ID, ''0'') || '':priority''), 4)',
'        when 0 then ''Low''',
'        when 1 then ''Medium''',
'        when 2 then ''High''',
'        else ''Critical''',
'    end as priority,',
'    case mod(ora_hash(nvl(:P330_SELECTED_ITEM_ID, ''0'') || '':owner''), 4)',
'        when 0 then ''Maya Chen''',
'        when 1 then ''Alex Rivera''',
'        when 2 then ''Jordan Patel''',
'        else ''Sam Taylor''',
'    end as owner,',
'    trunc(sysdate) + mod(ora_hash(nvl(:P330_SELECTED_ITEM_ID, ''0'') || '':due''), 21) as due',
'from dual;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P330_SELECTED_ITEM_ID'
,p_lazy_loading=>false
,p_query_row_template=>2101991776017792140
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Presents supporting item attributes in compact value-and-attribute groups.',
'',
'Pattern role: Attribute-pair detail layout.',
'',
'AI guidance: Use this group for additional descriptive properties that do not fit into the primary classification set. Maintain consistency in formatting and avoid introducing operational, ownership, or timing-related fields.',
'',
'Implementation note: This region participates in selected-item refreshes through .js-item-refresh and submits P330_SELECTED_ITEM_ID when refreshed.'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893983486884818353)
,p_query_column_id=>4
,p_column_alias=>'DUE'
,p_column_display_sequence=>40
,p_column_heading=>'Due'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893983913962818353)
,p_query_column_id=>3
,p_column_alias=>'OWNER'
,p_column_display_sequence=>30
,p_column_heading=>'Owner'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893984317917818353)
,p_query_column_id=>2
,p_column_alias=>'PRIORITY'
,p_column_display_sequence=>20
,p_column_heading=>'Priority'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893984709277818353)
,p_query_column_id=>1
,p_column_alias=>'PROGRESS'
,p_column_display_sequence=>10
,p_column_heading=>'Progress'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24898687589822147545)
,p_plug_name=>'Faceted Search'
,p_static_id=>'faceted-search'
,p_parent_plug_id=>wwv_flow_imp.id(24898687216421147541)
,p_region_css_classes=>'u-flex-shrink-0'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>10
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(24897972039297214584)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'Y',
  'show_total_row_count', 'N')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Helps users narrow the primary item list before selecting a record.',
'',
'Pattern role: List search and filtering controls.',
'',
'AI guidance: Expose facets only through the Add Filter dialog; do not display them inline. Use faceted search primarily to power search and provide advanced filtering via the popup dialog button. Include only facets that materially help users locate '
||'an item, keeping the set small and high-value so the selection list remains visually dominant.',
'',
'Implementation note: This region filters the List Selection region. After filtering, ensure the page still has a valid selected row or deliberately clear the detail context when no matching rows remain.'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24898694744941147556)
,p_name=>'P330_CATEGORY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(24898687589822147545)
,p_prompt=>'Category'
,p_source=>'CATEGORY'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_display_as=>'FILTER_DIALOG'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24898694297693147552)
,p_name=>'P330_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(24898687589822147545)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24898694449270147553)
,p_name=>'P330_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(24898687589822147545)
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'FILTER_DIALOG'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24898687216421147541)
,p_plug_name=>'Flex Container'
,p_static_id=>'flex-container'
,p_region_sub_css_classes=>'u-block-size-full'
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_location=>null
,p_template_component_type=>'REGION_ONLY'
,p_plug_source_type=>'TMPL_THEME_42$FLEXBOX_CONTAINER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'DIRECTION', 'u-flex-direction-column',
  'OVERFLOW', 'u-overflow-hidden')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Organizes the search controls and selectable item list as one continuous left-side selection panel.',
'',
'Pattern role: Structural container for the master-list area.',
'',
'AI guidance: Keep search and filtering above the results they control. Allow the list region to grow into the remaining available space. Do not place unrelated detail content inside this container.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24904699864209168380)
,p_plug_name=>'Item Details'
,p_static_id=>'item-header'
,p_region_css_classes=>'js-selected-item-content'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noBorder'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_08'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Establishes the identity and current state of the item before users inspect details or take action.',
'',
'Pattern role: Item detail header with contextual information.',
'',
'AI guidance: Keep the most important identity, ownership, status, impact, and timing information near the item title. Use contextual information for quick scanning rather than a full attribute report. Map status values to supported semantic states su'
||'ch as success, warning, danger, or info. Keep badge value, state, label, and styling semantically aligned. Use relative time only when it is useful for recency; use an explicit date when the exact date matters.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24902441233895216905)
,p_plug_name=>'Summary'
,p_static_id=>'item-summary-details'
,p_parent_plug_id=>wwv_flow_imp.id(24902504497986674697)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>4
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'This record represents a standard item that is being reviewed, tracked, or acted on. The summary explains the current state, expected outcome, and any context needed before taking action.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Gives users concise narrative context about what the item represents and why it matters.',
'',
'Pattern role: Item summary narrative.',
'',
'AI guidance: Keep the summary short, generic, and decision-relevant. Explain the item''s current purpose, state, or expected outcome without adding instructional or tutorial text. Move detailed attributes, history, and related records into their dedic'
||'ated regions.'))
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(24904699913819168381)
,p_name=>'Item Contextual Info'
,p_static_id=>'key-facts'
,p_parent_plug_id=>wwv_flow_imp.id(24904699864209168380)
,p_template=>3372714138756020509
,p_display_sequence=>10
,p_region_css_classes=>'app-ContextualInfo js-item-refresh'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo--hideNulls:t-ContextualInfo-label--stacked:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''Item '' || nvl(:P330_SELECTED_ITEM_ID, 0) as item_title,',
'    ''Record Owner'' as owner,',
'    ''Standard Category'' as category,',
'    case mod(nvl(:P330_SELECTED_ITEM_ID, 0), 4)',
'        when 1 then ''On Track''',
'        when 2 then ''Paused''',
'        when 3 then ''Blocked''',
'        else ''Pending Review''',
'    end as status,',
'    case mod(nvl(:P330_SELECTED_ITEM_ID, 0), 4)',
'        when 1 then ''success''',
'        when 2 then ''warning''',
'        when 3 then ''danger''',
'        else ''info''',
'    end as status_state,',
'    sysdate - 1 / 24 as last_updated,',
'    ''High'' as impact,',
'    ''danger'' as impact_state,',
'    sysdate + 14 as target_date',
'from dual;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P330_SELECTED_ITEM_ID'
,p_lazy_loading=>false
,p_query_row_template=>2117249020861433971
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Presents the highest-value item facts for quick assessment before users take action.',
'',
'Pattern role: Contextual information summary.',
'',
'AI guidance: Keep this region limited to ownership, classification, status, impact, recency, and timing information that users need for quick decisions. Keep visible values and their semantic state columns aligned. Use supported state values such as '
||unistr('success, warning, danger, or info. Expose target timing when it materially affects the user\2019s decision; otherwise remove the unused supporting column.'),
'',
'Implementation note: This region participates in selected-item refreshes through `.js-item-refresh` and submits `P330_SELECTED_ITEM_ID` when refreshed.'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893975442090818349)
,p_query_column_id=>3
,p_column_alias=>'CATEGORY'
,p_column_display_sequence=>40
,p_column_heading=>'Category'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893972649369818348)
,p_query_column_id=>7
,p_column_alias=>'IMPACT'
,p_column_display_sequence=>80
,p_column_heading=>'Impact'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{with/}',
'  LABEL:=Impact',
'  VALUE:=#IMPACT#',
'  STATE:=#IMPACT_STATE#',
'  LABEL_DISPLAY:=N',
'  STYLE:=t-Badge--subtle',
'  SIZE:=t-Badge--sm',
'{apply THEME$BADGE/}'))
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893973083098818348)
,p_query_column_id=>8
,p_column_alias=>'IMPACT_STATE'
,p_column_display_sequence=>90
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893972299986818348)
,p_query_column_id=>1
,p_column_alias=>'ITEM_TITLE'
,p_column_display_sequence=>10
,p_column_html_expression=>'<div class="u-text-subheading-sm">#ITEM_TITLE#</div>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893973506428818348)
,p_query_column_id=>6
,p_column_alias=>'LAST_UPDATED'
,p_column_display_sequence=>50
,p_column_heading=>'Last Updated'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893973828791818348)
,p_query_column_id=>2
,p_column_alias=>'OWNER'
,p_column_display_sequence=>30
,p_column_heading=>'Owner'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893974318802818348)
,p_query_column_id=>4
,p_column_alias=>'STATUS'
,p_column_display_sequence=>20
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{with/}',
'  LABEL:=Status',
'  VALUE:=#STATUS#',
'  STATE:=#STATUS_STATE#',
'  LABEL_DISPLAY:=Y',
'  STYLE:=t-Badge--subtle margin-top-xs',
'  SHAPE:=t-Badge--circle',
'  SIZE:=t-Badge--md',
'{apply THEME$BADGE/}'))
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893974640607818349)
,p_query_column_id=>5
,p_column_alias=>'STATUS_STATE'
,p_column_display_sequence=>70
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893975092198818349)
,p_query_column_id=>9
,p_column_alias=>'TARGET_DATE'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24897972039297214584)
,p_plug_name=>'List Selection'
,p_static_id=>'list-selection'
,p_region_name=>'primary_items_list'
,p_parent_plug_id=>wwv_flow_imp.id(24898687216421147541)
,p_region_css_classes=>'u-flex-grow-1 u-overflow-auto'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>40
,p_plug_display_point=>'PLUGIN_BODY'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    q.item_id,',
'    q.title,',
'    q.category,',
'    q.last_updated,',
'    q.badge as status,',
'    q.badge_state',
'from (',
'    /*',
'      Content Row Pattern Guidance',
'      ----------------------------',
'      Use this region to present a primary collection on the left and the',
'      detail view for the selected row on the right.',
'',
'      Design intent:',
'- Show one clear primary item per row.',
'- Keep titles simple and representative.',
'- Use category as a general-purpose facet.',
'- Use the badge to surface the item''s current status.',
'- Show a date-based field that makes the list feel more realistic and varied.',
'- Use single selection because the detail area represents one current item.',
'- Store the selected primary key in the configured Current Selection Page Item.',
'- Use multi-selection only when the adapted page supports bulk actions rather than a single contextual detail view.',
'- Change the hard-coded row_count value below to show 10 or 50 rows.',
'    */',
'    with params as (',
'        select 50 as row_count from dual   -- change 10 to 50 when needed',
'    )',
'    select',
'        level as item_id,',
'        ''Item '' || level as title,',
'        case mod(level - 1, 4)',
'            when 0 then ''Planning''',
'            when 1 then ''Operations''',
'            when 2 then ''Review''',
'            else ''Reporting''',
'        end as category,',
'        sysdate - mod(level - 1, 14) as last_updated,',
'        case mod(level, 4)',
'            when 1 then ''On Track''',
'            when 2 then ''Paused''',
'            when 3 then ''Blocked''',
'            else ''Pending Review''',
'        end as badge,',
'        case mod(level, 4)',
'            when 1 then ''success''',
'            when 2 then ''warning''',
'            when 3 then ''danger''',
'            else ''info''',
'        end as badge_state',
'    from dual',
'    connect by level <= (select row_count from params)',
') q'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>100
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'No items found',
''))
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_row_selection_type=>'SINGLE'
,p_current_selection_page_item=>'P330_SELECTED_ITEM_ID_UI'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignEnd',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', 'Status',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_POS', 't-ContentRow-badge--posEnd',
  'BADGE_SHAPE', 't-Badge--circle',
  'BADGE_SIZE', 't-Badge--sm',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'STATUS',
  'DESCRIPTION', '&LAST_UPDATED.',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'STYLE', 't-ContentRow--styleCompact',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides the searchable, single-selection collection that controls the item shown in the detail area.',
'',
'Pattern role: Master list and UI selection source.',
'',
'AI guidance: Keep each row concise and make its title, status, category, and recency easy to scan. Use a stable primary key for selection. Preserve single-selection behavior when the right side represents one current item. Do not enable multi-selecti'
||'on controls unless the adapted workflow supports bulk actions.',
'',
'Implementation note: The Content Row writes the selected primary key to P330_SELECTED_ITEM_ID_UI through Current Selection Page Item. The primary_items_list Static ID is used by the page-load JavaScript to restore an existing selection or select the '
||'first row.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24898686996444147539)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24898688064360147549)
,p_name=>'CATEGORY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897972149486214585)
,p_name=>'ITEM_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITEM_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24898686865313147537)
,p_name=>'LAST_UPDATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED'
,p_data_type=>'DATE'
,p_display_sequence=>30
,p_format_mask=>'SINCE'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24898687925504147548)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897972202376214586)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24927398352250017426)
,p_plug_name=>'Key Metrics'
,p_static_id=>'metric-cards'
,p_region_css_classes=>'app-MetricCards js-item-refresh js-selected-item-content'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-line-chart'' as icon,',
'    ''Primary KPI''   as label,',
'    50000 + mod(ora_hash(nvl(:P330_SELECTED_ITEM_ID, ''0'') || '':primary''), 50000) as metric_value',
'from dual',
'union all',
'select',
'    ''fa-bar-chart''  as icon,',
'    ''Secondary KPI'' as label,',
'    5000 + mod(ora_hash(nvl(:P330_SELECTED_ITEM_ID, ''0'') || '':secondary''), 20000) as metric_value',
'from dual',
'union all',
'select',
'    ''fa-area-chart'' as icon,',
'    ''Trend KPI''     as label,',
'    mod(ora_hash(nvl(:P330_SELECTED_ITEM_ID, ''0'') || '':trend''), 100) as metric_value',
'from dual',
'union all',
'select',
'    ''fa-dashboard''  as icon,',
'    ''Status KPI''    as label,',
'    100 + mod(ora_hash(nvl(:P330_SELECTED_ITEM_ID, ''0'') || '':status''), 900) as metric_value',
'from dual'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$METRIC_CARD'
,p_ajax_items_to_submit=>'P330_SELECTED_ITEM_ID'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AVATAR_ALIGNMENT', 't-MetricCard-body--avatarAlignmentStart',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_POSITION', 't-MetricCard-body--avatarPositionInline',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_STYLE', 't-MetricCard-avatar--subtle',
  'AVATAR_TYPE', 'icon',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'LAYOUT', '4cols',
  'META', '&LABEL.',
  'METRIC', '&METRIC_VALUE.',
  'METRIC_CSS_CLASSES', 'u-text-subheading-md')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Highlights a small number of measures that help users assess the current item quickly.',
'',
'Pattern role: Item-level KPI summary.',
'',
'AI guidance: Use only the most relevant measures for this item, generally two to four cards. Keep metrics comparable in importance and avoid turning the region into a dense report. Format large values with thousands separators and use consistent unit'
||'s. If badges or icons are added, keep their value, state, and icon semantically aligned.',
'',
'Implementation note: This region participates in selected-item refreshes through `.js-item-refresh` and submits `P330_SELECTED_ITEM_ID` when refreshed.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24927398420079017427)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24927398594411017429)
,p_name=>'LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LABEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24927398736304017430)
,p_name=>'METRIC_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'METRIC_VALUE'
,p_data_type=>'NUMBER'
,p_display_sequence=>40
,p_format_mask=>'999G999G999G999G999G999G990'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24893924486784100069)
,p_plug_name=>'No Item Selected'
,p_static_id=>'no-item-selected'
,p_region_css_classes=>'js-selected-item-empty u-hidden u-tC'
,p_icon_css_classes=>'fa-search'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>2042159785845301134
,p_plug_display_sequence=>70
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Select an item to view its details.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24927343658539176721)
,p_plug_name=>'Related Information'
,p_static_id=>'related-information'
,p_region_css_classes=>'js-item-refresh js-selected-item-content'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with seed as (',
'    select nvl(:P330_SELECTED_ITEM_ID, ''0'') as item_id',
'    from dual',
')',
'select ''fa-users'' as icon,',
'       ''People'' as title,',
'       ''Associated people and owners'' as description,',
'       1 + mod(ora_hash(seed.item_id || '':people''), 10) as item_count,',
'       ''PEOPLE'' as page_alias',
'  from seed',
'union all',
'select ''fa-file-o'' as icon,',
'       ''Files'' as title,',
'       ''Documents and attachments'' as description,',
'       1 + mod(ora_hash(seed.item_id || '':files''), 20) as item_count,',
'       ''FILES'' as page_alias',
'  from seed',
'union all',
'select ''fa-comments-o'' as icon,',
'       ''Comments'' as title,',
'       ''Discussion and feedback'' as description,',
'       1 + mod(ora_hash(seed.item_id || '':comments''), 30) as item_count,',
'       ''COMMENTS'' as page_alias',
'  from seed',
'union all',
'select ''fa-sitemap'' as icon,',
'       ''Child Records'' as title,',
'       ''Associated child records'' as description,',
'       1 + mod(ora_hash(seed.item_id || '':child_records''), 15) as item_count,',
'       ''CHILD_RECORDS'' as page_alias',
'  from seed',
'union all',
'select ''fa-link'' as icon,',
'       ''Related Records'' as title,',
'       ''Connected business entities'' as description,',
'       1 + mod(ora_hash(seed.item_id || '':related_records''), 8) as item_count,',
'       ''RELATED_RECORDS'' as page_alias',
'  from seed;'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P330_SELECTED_ITEM_ID'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON. fa-lg',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignCenter',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', 'Related Item Count',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_POS', 't-ContentRow-badge--posEnd',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'ITEM_COUNT',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides compact entry points to related information without overwhelming the item summary.',
'',
'Pattern role: Related-content navigation list.',
'',
'AI guidance: Keep rows concise and use the description to clarify what the related area contains. Use the badge to show the number of related items when that count is meaningful. Row titles should navigate to the corresponding related area or item-le'
||'vel detail. Keep this region focused on navigation and summary; use a full report or dedicated page for extensive related data.',
'',
'Implementation note: Each row represents a navigation entry to a related-information area. Replace the placeholder action target with the destination represented by PAGE_ALIAS, passing the current item context and selected related-information categor'
||'y.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24927344369403176728)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24927344478554176729)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24902505574215674708)
,p_name=>'ITEM_COUNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITEM_COUNT'
,p_data_type=>'NUMBER'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24902505474599674707)
,p_name=>'PAGE_ALIAS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PAGE_ALIAS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24927344219624176727)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(24909134033876453470)
,p_region_id=>wwv_flow_imp.id(24927343658539176721)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24902504497986674697)
,p_plug_name=>'Overview'
,p_static_id=>'summary-container'
,p_region_css_classes=>'js-selected-item-content'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides the primary scan-first container for the item detail summary.',
'',
'Pattern role: Item detail overview.',
'',
'AI guidance: Keep this region visually dominant and place the most decision-relevant summary content here. Use a concise narrative summary alongside logically grouped attribute pairs. Preserve the overview-first structure and avoid turning this regio'
||'n into a dense report or long-form documentation area.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24893969478575818346)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(24904699864209168380)
,p_button_name=>'ACTIONS_MENU'
,p_static_id=>'actions-menu'
,p_show_as_disabled=>false
,p_button_type=>'MENU'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Actions Menu'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ellipsis-v'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Groups optional or lower-frequency actions so they remain available without competing with the primary action hierarchy.',
'',
'Pattern role: Overflow actions.',
'',
'AI guidance: Place destructive, administrative, export, duplicate, or infrequently used actions here when they do not need persistent prominence. Do not hide the primary task in the overflow menu. Use clear action labels and preserve a logical menu o'
||'rder.'))
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24929689069830632365)
,p_button_id=>wwv_flow_imp.id(24893969478575818346)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 1'
,p_static_id=>'menu-action-a'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24929689145221632366)
,p_button_id=>wwv_flow_imp.id(24893969478575818346)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 2'
,p_static_id=>'menu-action-b'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24929689257392632367)
,p_button_id=>wwv_flow_imp.id(24893969478575818346)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 3'
,p_static_id=>'menu-action-c'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24893971116006818347)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24904699864209168380)
,p_button_name=>'PRIMARY_ACTION'
,p_static_id=>'primary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Primary Action'
,p_button_position=>'NEXT'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Represents the most important next step available from the item detail page.',
'',
'Pattern role: Primary page action.',
'',
'AI guidance: Keep this action prominent and use a clear, domain-specific verb when adapting the pattern. There should normally be one primary action. The action should be directly related to the item''s current state and intended workflow.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24893971498596818347)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(24904699864209168380)
,p_button_name=>'SECONDARY_ACTION'
,p_static_id=>'secondary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Secondary Action'
,p_button_position=>'NEXT'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides a useful follow-up action that is less important than the primary action.',
'',
'Pattern role: Secondary page action.',
'',
'AI guidance: Keep this action visually subordinate to the primary action. Use it for a common but non-primary path, and avoid presenting several actions with equal visual emphasis.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24893963498303818341)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24902584620620802907)
,p_button_name=>'VIEW_ALL_ACTIVITY'
,p_static_id=>'view-details-link-3'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight:t-Button--padTop'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'View All Activity'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-right'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides a contextual path from the activity summary to the complete activity history.',
'',
'Pattern role: Region-level detail action.',
'',
'AI guidance: Use this action when the summary is intentionally truncated or when users may need to inspect the full history. Keep it visually attached to the Recent Activity region and lower in emphasis than the page''s primary action. Omit it when th'
||'e region already contains the complete activity history.',
'',
'Implementation note: This action should navigate to the complete activity history for the current item. Replace the placeholder target URL when the activity-history destination is available.'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24898697503314147550)
,p_name=>'P330_SELECTED_ITEM_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(24897972039297214584)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>'Stores the canonical selected-item context used by the detail-region queries. Changes to this item refresh all dependent regions marked with .js-item-refresh.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24893923000298100054)
,p_name=>'P330_SELECTED_ITEM_ID_UI'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(24897972039297214584)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>'Stores the current primary-key selection maintained by the Content Row component. Changes to this item are synchronized into P330_SELECTED_ITEM_ID.'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(24893986131358818355)
,p_name=>'Initialize List Selection'
,p_static_id=>'focus-first-item-in-list'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_da_event_comment=>'Initializes the reusable split-view selection controller. The controller restores the canonical item when it remains in the list, selects the first available row when necessary, or shows the empty state when no rows are available.'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24893986565442818357)
,p_event_id=>wwv_flow_imp.id(24893986131358818355)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'appSplitViewSelection.initialize({',
    '    regionId: "primary_items_list",',
    '    uiItem: "P330_SELECTED_ITEM_ID_UI",',
    '    contextItem: "P330_SELECTED_ITEM_ID"',
    '});')))).to_clob
,p_da_action_comment=>'Configures split-view-selection.js with the List Selection region Static ID, the Content Row UI selection item, and the canonical selected-item context.'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(24893924297817100067)
,p_name=>'Reconcile Selection After List Refresh'
,p_static_id=>'reconcile-selection-after-list-refresh'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(24897972039297214584)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'tablemodelviewpagechange'
,p_da_event_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Runs after the Content Row model view changes because of search, filtering, pagination, or another list update. It reconciles the selected-item context after the refreshed rows are available.',
'',
'Implementation Note: This page uses the dynamically scoped tablemodelviewpagechange event because it reliably runs after the Content Row model view has updated for this workflow.'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24893924574384100070)
,p_event_id=>wwv_flow_imp.id(24893924297817100067)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Console Log'
,p_static_id=>'console-log'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'console.warn(',
    '    "List Selection after refresh fired",',
    '    new Date().toISOString(),',
    '    $("#primary_items_list .t-ContentRow-item").length',
    ');')))).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24893924372946100068)
,p_event_id=>wwv_flow_imp.id(24893924297817100067)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', 'appSplitViewSelection.reconcile();')).to_clob
,p_da_action_comment=>'Calls the reusable split-view controller to preserve the current selection when possible, select the first available row when necessary, or show the empty state when no rows remain.'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(24893987068353818358)
,p_name=>'Sync Selected Item Context'
,p_static_id=>'refresh-item-contextual-details'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P330_SELECTED_ITEM_ID_UI'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_da_event_comment=>'Runs when the Content Row updates its UI selection item. This separates the selection state maintained by the component from the canonical item context used by the detail regions.'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24893923261177100057)
,p_event_id=>wwv_flow_imp.id(24893987068353818358)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Set Item Context from UI Selection'
,p_static_id=>'set-p330-selected-item-id'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    '/*',
    ' * Copy the component-managed UI selection into the canonical item',
    ' * context only when the value has actually changed.',
    ' */',
    'var uiId =',
    '    apex.item("P330_SELECTED_ITEM_ID_UI").getValue();',
    '',
    'var contextId =',
    '    apex.item("P330_SELECTED_ITEM_ID").getValue();',
    '',
    '/*',
    ' * Do not suppress this change event. Updating the canonical item is',
    ' * what triggers the dependent detail-region refresh Dynamic Action.',
    ' */',
    'if (uiId && uiId !== contextId) {',
    '    apex.item("P330_SELECTED_ITEM_ID").setValue(uiId);',
    '}')))).to_clob
,p_da_action_comment=>'Copies the current UI selection into P330_SELECTED_ITEM_ID only when the value has changed. This item is the canonical context used by the detail-region queries.'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(24893923501545100059)
,p_name=>'Refresh Selected Item Details'
,p_static_id=>'selection-item-changes'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P330_SELECTED_ITEM_ID'
,p_condition_element=>'P330_SELECTED_ITEM_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_da_event_comment=>'Runs when the canonical selected-item context changes. It refreshes all dependent regions marked with .js-item-refresh so the detail area reflects the selected row.'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24893987517940818358)
,p_event_id=>wwv_flow_imp.id(24893923501545100059)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Item Detail Regions'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'.js-item-refresh'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
,p_da_action_comment=>'Refreshes every region marked with .js-item-refresh. Add this class only to regions whose content depends on P330_SELECTED_ITEM_ID, and include that item in Page Items to Submit for each dependent region.'
);
wwv_flow_imp.component_end;
end;
/
