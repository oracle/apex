prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Patterns'
,p_alias=>'PATTERNS'
,p_step_title=>'Patterns'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11343852270646311)
,p_plug_name=>'Pattern Catalog'
,p_static_id=>'apex-ux-pattern-catalog'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:t-Region--removeHeader js-removeLandmark:margin-bottom-md'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Browse reusable Oracle APEX UX patterns organized by common application tasks. Each pattern combines representative implementations with documented design intent to help developers and AI coding assistants produce more consistent, high-quality app'
||'lication experiences.</p>',
'',
'<p>Choose the pattern that best supports the user''s primary task, then adapt it to your application''s specific requirements.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26214049664548750)
,p_plug_name=>'Pattern Categories'
,p_static_id=>'patterns'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:margin-top-md'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>60
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-dashboard'' as icon_class,',
'    ''Dashboards'' as title,',
'    ''Summarize status, highlight exceptions, and guide users toward meaningful follow-up actions.'' as description,',
'    ''dashboards'' as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-mouse-pointer'' as icon_class,',
'    ''Browse and Search'' as title,',
'    ''Help users find, filter, compare, and open records using the right browsing experience for the task.'' as description,',
'    ''browse-search'' as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-id-card-o'' as icon_class,',
'    ''Item Details'' as title,',
'    ''Inspect one record with the right amount of context, supporting information, and follow-up action.'' as description,',
'    ''item-details'' as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-forms'' as icon_class,',
'    ''Data Entry'' as title,',
'    ''Create and update information with form patterns that match the complexity, context, and confidence required by the task.'' as description,',
'    ''data-entry'' as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-files-o'' as icon_class,',
'    ''Master Detail'' as title,',
'    ''Work across parent and child records with layouts that preserve context, support comparison, and keep related actions close to the data.'' as description,',
'    ''master-detail'' as page_alias',
'from sys.dual'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON_CLASS. fa-2x u-opacity-50',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(26214274007548753)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(26214111655548751)
,p_name=>'ICON_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(26214392305548754)
,p_name=>'PAGE_ALIAS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PAGE_ALIAS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(26214241095548752)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(26214487366548755)
,p_region_id=>wwv_flow_imp.id(26214049664548750)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'f?p=&APP_ID.:&PAGE_ALIAS.:&SESSION.::&DEBUG.::::'
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'PAGE_ALIAS'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11345488356646327)
,p_plug_name=>'Patterns'
,p_static_id=>'reusable-apex-ux-patterns'
,p_icon_css_classes=>'fa-cards'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>90
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
