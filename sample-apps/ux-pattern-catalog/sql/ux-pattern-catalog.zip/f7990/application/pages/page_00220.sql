prompt --application/pages/page_00220
begin
--   Manifest
--     PAGE: 00220
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>220
,p_name=>unistr('Faceted Search \2013\00A0Content Row')
,p_alias=>'FACETED-SEARCH-CONTENT-ROW'
,p_step_title=>unistr('Faceted Search \2013\00A0Content Row')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2528119710305719084
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrate this page pattern as a reusable, production-quality Oracle APEX experience.',
'',
'## When to Use',
'',
'Use when this page''s primary user task matches the pattern represented by its title and structure.',
'',
'## When to Avoid',
'',
'Avoid when another catalog pattern better supports the user''s task, information density, or workflow complexity.',
'',
'## AI Guidance',
'',
'Preserve the page''s pattern-first structure, generic terminology, accessible labels, semantic formatting, and clear action hierarchy. Keep documentation in metadata rather than visible instructional text.',
'            '))
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9353042260006226)
,p_plug_name=>'Active Facets'
,p_static_id=>'active-facets'
,p_region_name=>'active_facets'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Shows the filters currently applied so users can understand and adjust the result set.',
'Pattern role: Active-filter summary.',
'AI guidance: Keep this region visually associated with the results and ensure clearing individual or all filters is discoverable.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9251177563012736)
,p_plug_name=>'Faceted Search with Content Row'
,p_static_id=>'button-bar'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<span class="u-text-body-sm u-text-muted-color"><span id="total_row_count">Loading</span> Rows</span>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides the page context and current result count for the faceted content-row search experience.',
'Pattern role: Search context and result summary.',
'AI guidance: Keep the result count concise and update it as filters change. Do not use this region for instructional text or competing page actions.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9248811875012731)
,p_plug_name=>'Search'
,p_static_id=>'search'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(9248733106012731)
,p_landmark_label=>'Filters'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'current_facets_selector', '#active_facets',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'E',
  'show_total_row_count', 'E',
  'total_row_count_selector', '#total_row_count')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides the primary filtering surface for narrowing a larger set of content-row results.',
'Pattern role: Faceted search controls.',
'AI guidance: Keep facets limited to meaningful filtering dimensions. Put the broadest or most frequently used filters first, preserve accessible labels, and avoid exposing filters that do not help users decide which rows to inspect.'))
);
wwv_flow_imp_page.create_page_item_group(
 p_id=>wwv_flow_imp.id(9272096226315376)
,p_page_plug_id=>wwv_flow_imp.id(9248811875012731)
,p_label=>'Feature Flags'
,p_static_id=>'feature-flags'
,p_display_sequence=>90
,p_icon_css_classes=>'fa-flag-checkered'
,p_fc_filter_combination=>'OR'
,p_fc_sort_by_top_counts=>true
,p_fc_show_more_count=>7
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_display_as=>'INLINE'
,p_group_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Groups related boolean filters under one conceptual facet category.',
'Pattern role: Grouped facet controls.',
'AI guidance: Group related filters only when they represent a coherent dimension. Avoid using a facet group to collect unrelated options.'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9295101782446327)
,p_item_group_id=>wwv_flow_imp.id(9272096226315376)
,p_name=>'P220_FLAG_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9248811875012731)
,p_prompt=>'Feature Flag 1'
,p_source=>'FLAG_1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'use_defaults', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9295239221446328)
,p_item_group_id=>wwv_flow_imp.id(9272096226315376)
,p_name=>'P220_FLAG_2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9248811875012731)
,p_prompt=>'Feature Flag 2'
,p_source=>'FLAG_2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'use_defaults', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9295350620446329)
,p_item_group_id=>wwv_flow_imp.id(9272096226315376)
,p_name=>'P220_FLAG_3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(9248811875012731)
,p_prompt=>'Feature Flag 3'
,p_source=>'FLAG_3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'use_defaults', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9295393838446330)
,p_item_group_id=>wwv_flow_imp.id(9272096226315376)
,p_name=>'P220_FLAG_4'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(9248811875012731)
,p_prompt=>'Feature Flag 4'
,p_source=>'FLAG_4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'use_defaults', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9270776847315363)
,p_name=>'P220_CATEGORY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(9248811875012731)
,p_prompt=>'Category'
,p_source=>'CATEGORY'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_icon_css_classes=>'fa-shapes'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9271600986315371)
,p_name=>'P220_PRIORITY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(9248811875012731)
,p_prompt=>'Priority'
,p_source=>'PRIORITY'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov_sort_direction=>'ASC'
,p_item_icon_css_classes=>'fa-exclamation-square-o'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'hide_radio_buttons', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9253532775012738)
,p_name=>'P220_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9248811875012731)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9271018616315365)
,p_name=>'P220_UPDATED_ON'
,p_source_data_type=>'DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(9248811875012731)
,p_prompt=>'Last Updated'
,p_source=>'UPDATED_ON'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_item_icon_css_classes=>'fa-calendar-month'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'N',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9248733106012731)
,p_plug_name=>'Search Results'
,p_static_id=>'search-results'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Sample data for browse-oriented UX patterns.',
'',
'The values in this query are intentionally generic and synthetic.',
'Replace the query with application-specific data while preserving',
'the same overall shape:',
'',
'- Primary label',
'- Secondary description',
'- Category facet',
'- Priority facet',
'- Date facet',
'- Boolean flag facets',
'- Icon',
'- Badge',
'',
'This allows the same content row, cards, and faceted search patterns',
'to be reused across different application domains.',
'*/',
'select * from (',
'    select',
'        level as id,',
'        ''Item '' || level as title,',
'        case mod(level - 1, 4)',
'            when 0 then ''Summary for item '' || level',
'            when 1 then ''Description for item '' || level',
'            when 2 then ''Supporting text for item '' || level',
'            else ''Additional note for item '' || level',
'        end as description,',
'        case mod(level - 1, 5)',
'            when 0 then ''Category A''',
'            when 1 then ''Category B''',
'            when 2 then ''Category C''',
'            when 3 then ''Category D''',
'            else ''Category E''',
'        end as category,',
'        trunc(sysdate) - mod(level, 30) as updated_on,',
'        case mod(level - 1, 6)',
'            when 0 then ''fa-columns''',
'            when 1 then ''fa-search''',
'            when 2 then ''fa-table''',
'            when 3 then ''fa-id-card-o''',
'            when 4 then ''fa-edit''',
'            else ''fa-clone''',
'        end as icon,',
'        case mod(level - 1, 3)',
'            when 0 then ''High''',
'            when 1 then ''Medium''',
'            else ''Low''',
'        end as priority,',
'        case mod(level - 1, 3)',
'            when 0 then ''danger''',
'            when 1 then ''warning''',
'            else ''success''',
'        end as badge_state,',
'        case when mod(level, 2) = 0 then ''Y'' else ''N'' end as flag_1,',
'        case when mod(level, 3) = 0 then ''Y'' else ''N'' end as flag_2,',
'        case when mod(level, 4) = 0 then ''Y'' else ''N'' end as flag_3,',
'        case when mod(level, 5) = 0 then ''Y'' else ''N'' end as flag_4,',
'        ''Category '' || chr(64 + mod(level - 1, 5) + 1) as overline,',
'        ''Updated '' || to_char(trunc(sysdate) - mod(level, 30), ''Mon DD'') as meta',
'    from dual',
'    connect by level <= 24',
'    order by level',
')'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON. fa-lg',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--md',
  'BADGE_LABEL', 'Badge',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_SHAPE', 't-Badge--circle',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'PRIORITY',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'MISC', '&META.',
  'OVERLINE', '&CATEGORY.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Presents filtered records as concise content rows for efficient scanning.',
'Pattern role: Faceted content-row results.',
'AI guidance: Put the most decision-relevant information first. Use the overline, title, description, metadata, icon, and badge to support quick comparison. Keep rows compact, align badge value and state semantically, and preserve one clear path to it'
||'em detail.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9293797029446353)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9293175710446347)
,p_name=>'CATEGORY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9293135026446346)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9293894600446354)
,p_name=>'FLAG_1'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FLAG_1'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>110
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9293994292446355)
,p_name=>'FLAG_2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FLAG_2'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>120
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9294145002446356)
,p_name=>'FLAG_3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FLAG_3'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>130
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9294216707446357)
,p_name=>'FLAG_4'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FLAG_4'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>140
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9293585570446351)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9292955118446344)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9294417072446359)
,p_name=>'META'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'META'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>160
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9294292529446358)
,p_name=>'OVERLINE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OVERLINE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>150
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9293299450446348)
,p_name=>'PRIORITY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRIORITY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9293038096446345)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9293510268446350)
,p_name=>'UPDATED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPDATED_ON'
,p_data_type=>'DATE'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(9294787025446363)
,p_region_id=>wwv_flow_imp.id(9248733106012731)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(9294923670446364)
,p_region_id=>wwv_flow_imp.id(9248733106012731)
,p_position_id=>363792341120765662
,p_display_sequence=>20
,p_template_id=>363794202317800939
,p_label=>'Row Actions'
,p_static_id=>'row-actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(9294984786446365)
,p_component_action_id=>wwv_flow_imp.id(9294923670446364)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Row Action 1'
,p_static_id=>'row-action-1'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(9295095139446366)
,p_component_action_id=>wwv_flow_imp.id(9294923670446364)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Row Action 2'
,p_static_id=>'row-action-2'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(9295235321446367)
,p_component_action_id=>wwv_flow_imp.id(9294923670446364)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Row Action 3'
,p_static_id=>'row-action-3'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7142013969062625)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(9251177563012736)
,p_button_name=>'ACTIONS_MENU'
,p_static_id=>'actions-menu'
,p_show_as_disabled=>false
,p_button_type=>'MENU'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Actions Menu'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ellipsis-v'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(9296949179446374)
,p_button_id=>wwv_flow_imp.id(7142013969062625)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Menu Action 1'
,p_static_id=>'menu-action-1'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(9353998009006225)
,p_button_id=>wwv_flow_imp.id(7142013969062625)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Menu Action 2'
,p_static_id=>'menu-action-2'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(9354085243006226)
,p_button_id=>wwv_flow_imp.id(7142013969062625)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Menu Action 3'
,p_static_id=>'menu-action-3'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7143598639062625)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(9251177563012736)
,p_button_name=>'PRIMARY_ACTION'
,p_static_id=>'primary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Primary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7143963940062625)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9251177563012736)
,p_button_name=>'SECONDARY_ACTION'
,p_static_id=>'secondary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Secondary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp.component_end;
end;
/
