prompt --application/pages/page_00420
begin
--   Manifest
--     PAGE: 00420
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>420
,p_name=>unistr('Data Entry \2013\00A0Drawer Form')
,p_alias=>'DATA-ENTRY-DRAWER-FORM'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Data Entry \2013\00A0Drawer Form')
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.app-Form .t-ContentBlock--h3 {',
'    --ut-content-block-header-font-size: 1rem;',
'}'))
,p_step_template=>1662662927374504442
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_resizable=>'Y'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrate contextual data entry in a drawer while preserving the user''s originating page and surrounding context.',
'',
'## When to Use',
'',
'Use for short create or edit tasks that users may perform without losing their place in a browse or work surface.',
'',
'## When to Avoid',
'',
'Avoid for long forms, complex workflows, or tasks requiring sustained focus and substantial supporting context.',
'',
'## AI Guidance',
'',
'Keep the drawer focused and compact. Make save and cancel behavior explicit, preserve the underlying context, and avoid placing a full-page workflow inside a drawer.',
'            '))
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9454420610598492)
,p_plug_name=>'Supporting Details'
,p_static_id=>'assignment'
,p_parent_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_icon_css_classes=>'fa-globe fa-2x u-opacity-50'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<p>Captures supporting dates, classification, and administrative information.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Groups secondary record details that support the entry task.',
'Pattern role: Supporting drawer form section.',
'AI guidance: Include only fields relevant to the short edit task. Keep secondary sections compact so the drawer remains easy to scan.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9385304392012639)
,p_plug_name=>'Basic Information'
,p_static_id=>'basic-information'
,p_parent_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_icon_css_classes=>'fa-id-card-o fa-2x u-opacity-50'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<p>Core identifying information and contact details for this record.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Presents the core identifying information needed for the drawer form.',
'Pattern role: Primary drawer form section.',
'AI guidance: Put the most important fields first and keep this section concise enough to work within the drawer''s constrained context.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9384640643012632)
,p_plug_name=>'Buttons Container'
,p_static_id=>'buttons-container'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Holds the drawer''s completion and dismissal actions.',
'Pattern role: Drawer form action area.',
'AI guidance: Make Save and Cancel clear and consistently placed. Keep the primary completion action visually distinct and preserve an easy path to dismiss without submitting.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9383141925012617)
,p_plug_name=>'Edit Form'
,p_static_id=>'form'
,p_region_css_classes=>'app-Form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>'SAMPLE_DATA'
,p_query_table=>'EMPLOYEES'
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Collects a short edit task while keeping the originating page context available behind the drawer.',
'Pattern role: Drawer data-entry form.',
'AI guidance: Keep the form compact, group related fields, provide meaningful validation, and avoid turning the drawer into a full-page workflow.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9454316723598491)
,p_plug_name=>'Ownership and Classification'
,p_static_id=>'organization'
,p_parent_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_icon_css_classes=>'fa-briefcase fa-2x u-opacity-50'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<p>Defines the record''s role, ownership, and classification relationships.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7169233268068991)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9384640643012632)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_show_as_disabled=>false
,p_button_action=>'DEFINED_BY_DA_ACTION'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_component_da_action(
 p_id=>wwv_flow_imp.id(7169615757068992)
,p_button_id=>wwv_flow_imp.id(7169233268068991)
,p_action_sequence=>10
,p_action=>'NATIVE_DIALOG_CANCEL'
,p_static_id=>'native-dialog-cancel'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7170082922068993)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9384640643012632)
,p_button_name=>'SAVE'
,p_static_id=>'save'
,p_show_as_disabled=>false
,p_button_action=>'DEFINED_BY_DA_ACTION'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_component_da_action(
 p_id=>wwv_flow_imp.id(7170515476068993)
,p_button_id=>wwv_flow_imp.id(7170082922068993)
,p_action_sequence=>10
,p_name=>'Close Dialog'
,p_action=>'NATIVE_DIALOG_CLOSE'
,p_static_id=>'close-dialog'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9394158026012634)
,p_name=>'P420_DEPARTMENT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(9454316723598491)
,p_item_source_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_prompt=>'Department'
,p_source=>'DEPARTMENT'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Department A;A,Department B;B'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1610598304472262251
,p_item_icon_css_classes=>'fa-building'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9391004312012629)
,p_name=>'P420_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(9385304392012639)
,p_item_source_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_prompt=>'Email'
,p_source=>'EMAIL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>267
,p_begin_on_new_line=>'N'
,p_field_template=>1610598304472262251
,p_item_icon_css_classes=>'fa-envelope-o'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'EMAIL',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9388545020012632)
,p_name=>'P420_EMPLOYMENT_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9454420610598492)
,p_item_source_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_prompt=>'Employment Type'
,p_source=>'WORK_MODE'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Full Time;FTE,Part Time;PT,Contractor;C'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1610598304472262251
,p_item_icon_css_classes=>'fa-laptop'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9459340718598502)
,p_name=>'P420_END_DATE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(9454420610598492)
,p_item_source_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_prompt=>'End Date'
,p_source=>'WORK_MODE'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_cMaxlength=>25
,p_begin_on_new_line=>'N'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9386407253012622)
,p_name=>'P420_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_item_source_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_source=>'ID'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9393964185012632)
,p_name=>'P420_JOB'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(9454316723598491)
,p_item_source_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_prompt=>'Job Code'
,p_source=>'JOB'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Job A;A,Job B;B'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1610598304472262251
,p_item_icon_css_classes=>'fa-briefcase'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9465256710598507)
,p_name=>'P420_JOB_TITLE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(9454316723598491)
,p_item_source_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_prompt=>'Job Title'
,p_source=>'JOB'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Job A;A,Job B;B'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1610598304472262251
,p_item_icon_css_classes=>'fa-briefcase'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9462085511598502)
,p_name=>'P420_LOCATION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(9385304392012639)
,p_item_source_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_prompt=>'Location'
,p_source=>'TIME_ZONE'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>10
,p_begin_on_new_line=>'N'
,p_field_template=>1610598304472262251
,p_item_icon_css_classes=>'fa-location-circle-o'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEL',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9394526349012638)
,p_name=>'P420_MANAGER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(9454316723598491)
,p_item_source_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_prompt=>'Manager'
,p_source=>'MANAGERNO'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Manager A;A,Manager B;B'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1610598304472262251
,p_item_icon_css_classes=>'fa-user-secret'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9390913185012628)
,p_name=>'P420_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(9385304392012639)
,p_item_source_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_prompt=>'Name'
,p_source=>'NAME'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>1610598304472262251
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9391426651012633)
,p_name=>'P420_PHONE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(9385304392012639)
,p_item_source_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_prompt=>'Phone'
,p_source=>'TIME_ZONE'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>10
,p_field_template=>1610598304472262251
,p_item_icon_css_classes=>'fa-globe'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEL',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9388192990012629)
,p_name=>'P420_SALARY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(9454420610598492)
,p_item_source_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_prompt=>'Salary'
,p_post_element_text=>'USD'
,p_source=>'SALARY'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1610598304472262251
,p_item_icon_css_classes=>'fa-dollar'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--postTextBlock'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9459214121598501)
,p_name=>'P420_START_DATE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(9454420610598492)
,p_item_source_plug_id=>wwv_flow_imp.id(9383141925012617)
,p_prompt=>'Start Date'
,p_source=>'WORK_MODE'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_cMaxlength=>25
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7172169876068994)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(9383141925012617)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Drawer Form'
,p_static_id=>'initialize-form-drawer-form'
,p_internal_uid=>3423105975535939
);
wwv_flow_imp.component_end;
end;
/
