prompt --application/pages/page_00500
begin
--   Manifest
--     PAGE: 00500
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>500
,p_name=>'Master Detail'
,p_alias=>'MASTER-DETAIL'
,p_step_title=>'Master Detail'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Organize and explain master-detail patterns in the catalog. This is a category context page, not a pattern implementation.',
'',
'## When to Use',
'',
'Use when this page''s primary user task matches the pattern represented by its title and structure.',
'',
'## When to Avoid',
'',
'Avoid when another catalog pattern better supports the user''s task, information density, or workflow complexity.',
'',
'## AI Guidance',
'',
'Preserve the page''s pattern-first structure, generic terminology, accessible labels, semantic formatting, and clear action hierarchy. Keep documentation in metadata rather than visible instructional text.',
'            '))
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24907546438765397530)
,p_plug_name=>'About'
,p_static_id=>'about'
,p_icon_css_classes=>'fa-mouse-pointer'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Master-detail patterns help users work across related levels of information while preserving context. Use these patterns when users need to select a parent record, inspect dependent detail, compare related rows, or move between summary and detail wit'
||'hout losing their place.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24907549072928398653)
,p_plug_name=>'Master Detail'
,p_static_id=>'master-detail'
,p_icon_css_classes=>'fa-copy'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24907547499158399693)
,p_plug_name=>'Patterns'
,p_static_id=>'patterns'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-columns'' as icon_class,',
'    ''Master Detail - Split View'' as title,',
'    ''A two-pane layout where users select a master record on one side and review or act on its details on the other. Best for triage, queues, inbox-style workflows, and rapid review.'' as description,',
'    null as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-table'' as icon_class,',
'    ''Master Detail - Stacked Grids'' as title,',
'    ''A classic data maintenance pattern where parent records and child records are shown in stacked interactive grids for structured review, comparison, and inline updates.'' as description,',
'    null as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-level-down'' as icon_class,',
'    ''Master Detail - Drill Down'' as title,',
'    ''A progressive navigation pattern where users start from a master list and open a focused detail view for related information when the detail needs more space.'' as description,',
'    null as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-list-alt'' as icon_class,',
'    ''Master Detail - Related Records'' as title,',
'    ''A detail-centered pattern where one parent record stays in focus while related child records, activity, or dependencies are shown below.'' as description,',
'    null as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-sitemap'' as icon_class,',
'    ''Master Detail - Hierarchy'' as title,',
'    ''A hierarchical pattern where users navigate parent-child levels through a tree or grouped structure and inspect the selected node in context.'' as description,',
'    null as page_alias',
'from sys.dual'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON_CLASS. fa-2x u-opacity-50',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24907547723501399696)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24907547561149399694)
,p_name=>'ICON_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24907547841799399697)
,p_name=>'PAGE_ALIAS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PAGE_ALIAS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24907547690589399695)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(24907547936860399698)
,p_region_id=>wwv_flow_imp.id(24907547499158399693)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'f?p=&APP_ID.:&PAGE_ALIAS.:&SESSION.::&DEBUG.::::'
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'PAGE_ALIAS'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp.component_end;
end;
/
