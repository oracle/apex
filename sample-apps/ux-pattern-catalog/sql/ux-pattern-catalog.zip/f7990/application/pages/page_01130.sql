prompt --application/pages/page_01130
begin
--   Manifest
--     PAGE: 01130
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1130
,p_name=>'Charts'
,p_alias=>'CHARTS'
,p_step_title=>'Charts'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.ux-about-text {',
'    padding: 1rem;',
'    border-bottom: 1px solid var(--ut-component-border-color);',
'    background: var(--ut-component-toolbar-background-color);',
'}',
'',
'.app-PatternGuidance > p:first-child {',
'    font-weight: 600;',
'}',
'',
'.app-PatternGuidance h4 {',
'    text-transform: uppercase;',
'    font-size: 0.75rem;',
'    color: var(--ut-component-text-muted-color);',
'    margin-bottom: 0.25rem;',
'}'))
,p_step_template=>2528119710305719084
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'The Charts pattern page demonstrates use-case-driven Oracle APEX chart configurations for analyzing trends, comparing values, ranking items, tracking progress, and showing composition. Examples include line, line with area, grouped bar, stacked bar, '
||'combination, pie, and donut charts.',
'',
'## When to Use',
'',
'Use charts when users need to identify change over time, compare categories or series, understand relative position, monitor performance against a target, or see how a total is distributed across meaningful parts. Choose the chart structure based on '
||'the question users need to answer, not only on the type of data available.',
'',
'## When to Avoid',
'',
'Avoid charts when users need to read exact values across many rows, compare numerous attributes, enter or edit data, or inspect detailed records. Use a report, interactive grid, table, or dedicated detail page when precise lookup or dense comparison '
||'is more important than visual pattern recognition. Avoid adding series, categories, labels, or decorative effects that make the chart difficult to read.',
'',
'## AI Guidance',
'',
'Use the examples on this page as references for selecting and configuring charts around a specific analytical question. Identify the measure, category, time grain, comparison baseline, and intended decision before choosing a chart. Use line-based cha'
||'rts for trends, bars for category comparisons and rankings, combination charts for actual-versus-target views, and pie or donut charts for manageable part-to-whole relationships. Keep series counts low, use consistent units and scales, format labels '
||'and tooltips clearly, and use color to reinforce meaning rather than decoration.'))
,p_page_component_map=>'04'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49804153328094038483)
,p_plug_name=>'About'
,p_static_id=>'about'
,p_region_css_classes=>'margin-md'
,p_icon_css_classes=>'fa-mouse-pointer'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Charts visualize comparisons, distributions, composition, and change over time using charts suited to the data and task. They work well when users need to understand trends, compare values, rank items, track progress, or see how a total is distribute'
||'d across meaningful categories. These patterns demonstrate common ways to use the APEX Charts component for time series, comparing values, ranking items, tracking progress, and showing composition.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25451491766850514123)
,p_plug_name=>'About'
,p_static_id=>'about-composition'
,p_parent_plug_id=>wwv_flow_imp.id(25451491699716514122)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>Shows how a total is distributed across meaningful categories, using status slices and project-task groupings to communicate each category\2019s share of the whole.</p>'),
'',
'<h4>Best For</h4>',
'<p>Part-to-whole relationships where the total is important and the number of categories is manageable enough for users to distinguish the slices.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25451491546372514121)
,p_plug_name=>'About'
,p_static_id=>'about-item-ranking'
,p_parent_plug_id=>wwv_flow_imp.id(25451490899915514114)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Orders items by a measure so users can identify the strongest and weakest performers, including positive and negative variance from a baseline.</p>',
'',
'<h4>Best For</h4>',
'<p>Top and bottom performers, customer rankings, department variance, leaders and laggards, and other situations where relative position matters.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6960412808595817)
,p_plug_name=>'About'
,p_static_id=>'about-progress-tracking'
,p_parent_plug_id=>wwv_flow_imp.id(6960305256595816)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Compares actual performance with a target across periods, using grouped bars for discrete period snapshots and a combination chart for actual values with a target reference line.</p>',
'',
'<h4>Best For</h4>',
'<p>Monitoring progress against targets, budgets, milestones, or plans where the size and direction of the performance gap need to be visible.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38382093333276925)
,p_plug_name=>'About'
,p_static_id=>'about-time-series'
,p_parent_plug_id=>wwv_flow_imp.id(38381698840276921)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Shows how one or more measures change across ordered time periods, using line and line with area variations to reveal direction, volatility, and contribution over time.</p>',
'',
'<h4>Best For</h4>',
'<p>Trends, seasonality, volatility, and relationships between measures where timing and direction are more important than individual category comparison.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38381202049276916)
,p_plug_name=>'About'
,p_static_id=>'about-value-comparison'
,p_parent_plug_id=>wwv_flow_imp.id(38381153465276915)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Compares revenue across product lines, regions, or categories using grouped and stacked bars to show either direct magnitudes or contribution to a total.</p>',
'',
'<h4>Best For</h4>',
'<p>Comparing revenue, volume, counts, or contribution across a common set of products, regions, departments, or other discrete categories.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49804377438852846228)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>70
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(24910759108528178725)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7053753730468001)
,p_plug_name=>'Pattern: Combination Chart'
,p_static_id=>'combination-chart'
,p_parent_plug_id=>wwv_flow_imp.id(6960305256595816)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates monthly actual sales as bars and target sales as a line, combining magnitude and benchmark information in one chart.',
'',
'## When to Use',
'',
'Use when one measure should be emphasized as discrete values while another measure serves as a continuous reference, target, or threshold.',
'',
'## When to Avoid',
'',
'Avoid when both measures should be read as equal trend lines or when the measures use unrelated units without a clearly justified secondary axis.',
'',
'## AI Guidance',
'',
'Use the same month grain and unit for both series. Make actual values visually prominent, use a contrasting or dashed target line, and include the actual value, target value, gap, and performance status in the tooltip.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(7053804353468002)
,p_region_id=>wwv_flow_imp.id(7053753730468001)
,p_chart_type=>'combo'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_fill_multi_series_gaps=>false
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_overview_rendered=>'off'
,p_time_axis_type=>'enabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(7053973709468003)
,p_chart_id=>wwv_flow_imp.id(7053804353468002)
,p_static_id=>'sales-revenue'
,p_seq=>10
,p_name=>'Sales Revenue'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH revenue_data AS (',
'    SELECT DATE ''2026-01-01'' AS month_date, 68.2 AS sales_value FROM dual',
'    UNION ALL SELECT DATE ''2026-02-01'', 71.4 FROM dual',
'    UNION ALL SELECT DATE ''2026-03-01'', 74.8 FROM dual',
'    UNION ALL SELECT DATE ''2026-04-01'', 73.1 FROM dual',
'    UNION ALL SELECT DATE ''2026-05-01'', 76.9 FROM dual',
'    UNION ALL SELECT DATE ''2026-06-01'', 79.3 FROM dual',
'    UNION ALL SELECT DATE ''2026-07-01'', 81.6 FROM dual',
'    UNION ALL SELECT DATE ''2026-08-01'', 84.2 FROM dual',
')',
'SELECT',
'    month_date,',
'    TO_CHAR(',
'        month_date,',
'        ''FMMon'',',
'        ''NLS_DATE_LANGUAGE=English''',
'    ) AS month_label,',
'    sales_value AS value',
'FROM revenue_data',
'ORDER BY month_date;'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'MONTH_DATE'
,p_color=>'#3f8efc'
,p_line_style=>'solid'
,p_line_width=>2
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(7054090058468004)
,p_chart_id=>wwv_flow_imp.id(7053804353468002)
,p_static_id=>'target-revenue'
,p_seq=>20
,p_name=>'Target Revenue'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH revenue_data AS (',
'    SELECT DATE ''2026-01-01'' AS month_date, 70 AS target_value FROM dual',
'    UNION ALL SELECT DATE ''2026-02-01'', 72 FROM dual',
'    UNION ALL SELECT DATE ''2026-03-01'', 74 FROM dual',
'    UNION ALL SELECT DATE ''2026-04-01'', 76 FROM dual',
'    UNION ALL SELECT DATE ''2026-05-01'', 78 FROM dual',
'    UNION ALL SELECT DATE ''2026-06-01'', 80 FROM dual',
'    UNION ALL SELECT DATE ''2026-07-01'', 82 FROM dual',
'    UNION ALL SELECT DATE ''2026-08-01'', 84 FROM dual',
')',
'SELECT',
'    month_date,',
'    TO_CHAR(',
'        month_date,',
'        ''FMMon'',',
'        ''NLS_DATE_LANGUAGE=English''',
'    ) AS month_label,',
'    target_value AS value',
'FROM revenue_data',
'ORDER BY month_date;'))
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'MONTH_DATE'
,p_color=>'#8f99a8'
,p_line_style=>'dashed'
,p_line_width=>2
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(7054193310468005)
,p_chart_id=>wwv_flow_imp.id(7053804353468002)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'inside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(7054208946468006)
,p_chart_id=>wwv_flow_imp.id(7053804353468002)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>0
,p_numeric_pattern=>'$#M'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25451491699716514122)
,p_plug_name=>'Composition'
,p_static_id=>'composition'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6962357811595836)
,p_plug_name=>'Pattern: Donut Chart'
,p_static_id=>'donut-chart'
,p_parent_plug_id=>wwv_flow_imp.id(25451491699716514122)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a Donut chart that shows how 245 project tasks are distributed across ten projects. Each slice represents a project, and its size represents the number of tasks assigned to that project. The center of the donut remains intentionally unus'
||'ed.',
'',
'## When to Use',
'',
'Use when users need to understand part-to-whole composition across a manageable number of project categories, with exact task counts available through labels, the legend, or tooltips.',
'',
'## When to Avoid',
'',
'Avoid when there are many very small slices, when users need precise comparisons, or when the categories do not form a meaningful whole. Use a bar chart when ranking or comparing exact project totals is more important.',
'',
'## AI Guidance',
'',
'Use clear project labels, stable colors, and tooltips that include task counts and percentages. Keep the number of slices manageable and group minor projects into an Other category when necessary. Do not rely on the center of the donut to communicate'
||' a metric; place important totals in the region title, supporting text, or a separate KPI region.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6962423009595837)
,p_region_id=>wwv_flow_imp.id(6962357811595836)
,p_chart_type=>'donut'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_format_scaling=>'none'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6962595733595838)
,p_chart_id=>wwv_flow_imp.id(6962423009595837)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Project Tasks'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Customer Portal'' label, 58 value from sys.dual',
'union all',
'select ''Mobile App'' label, 44 value from sys.dual',
'union all',
'select ''Data Migration'' label, 37 value from sys.dual',
'union all',
'select ''Reporting & Analytics'' label, 29 value from sys.dual',
'union all',
'select ''Security Upgrade'' label, 25 value from sys.dual',
'union all',
'select ''API Integration'' label, 20 value from sys.dual',
'union all',
'select ''Workflow Automation'' label, 15 value from sys.dual',
'union all',
'select ''User Training'' label, 10 value from sys.dual',
'union all',
'select ''Documentation'' label, 5 value from sys.dual',
'union all',
'select ''Infrastructure Improvements'' label, 2 value from sys.dual',
'order by value desc'))
,p_max_row_count=>20
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'donut'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'COMBO'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24921009004548929470)
,p_plug_name=>'Pattern: Grouped Bar Chart'
,p_static_id=>'grouped-bar-chart'
,p_parent_plug_id=>wwv_flow_imp.id(38381153465276915)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with product_lines as (',
'    select ''Hardware'' as product_line, 1 as product_line_no from sys.dual',
'    union all',
'    select ''Software'', 2 from sys.dual',
'    union all',
'    select ''Services'', 3 from sys.dual',
'    union all',
'    select ''Support'', 4 from sys.dual',
'),',
'regions as (',
'    select ''North'' as region, 1 as region_no from sys.dual',
'    union all',
'    select ''South'', 2 from sys.dual',
'    union all',
'    select ''West'', 3 from sys.dual',
')',
'select p.product_line as label,',
'       r.region as series_name,',
'       round(',
'           case p.product_line_no',
'               when 1 then 120000',
'               when 2 then 95000',
'               when 3 then 75000',
'               when 4 then 55000',
'           end',
'           + (r.region_no * 12000)',
'       ) as value',
'from product_lines p',
'cross join regions r',
'order by p.product_line_no,',
'         r.region_no'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates revenue by product line and region, using separate bar series for North, South, and West across the same product categories.',
'',
'## When to Use',
'',
'Use grouped bars when users need to compare multiple series directly within each category and absolute magnitude is more important than total composition.',
'',
'## When to Avoid',
'',
'Avoid when the main question concerns contribution to a total, when there are too many series, or when a time trend is more important than category comparison.',
'',
'## AI Guidance',
'',
'Use the same category order for every series, keep the number of series manageable, use a common scale, and provide a clear legend. Use grouped rather than stacked bars when comparing the same region or product line across groups.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6917102678241268)
,p_region_id=>wwv_flow_imp.id(24921009004548929470)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6918802040241269)
,p_chart_id=>wwv_flow_imp.id(6917102678241268)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series 1'
,p_max_row_count=>20
,p_location=>'REGION_SOURCE'
,p_series_type=>'bar'
,p_series_name_column_name=>'SERIES_NAME'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#8a89d1'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6917656848241269)
,p_chart_id=>wwv_flow_imp.id(6917102678241268)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6918291597241269)
,p_chart_id=>wwv_flow_imp.id(6917102678241268)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12950035733301470)
,p_plug_name=>'Pattern: Grouped Bar Chart - Quarterly Actual vs Target'
,p_static_id=>'grouped-bar-chart-actual-target'
,p_parent_plug_id=>wwv_flow_imp.id(6960305256595816)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with quarterly_revenue as (',
'    select 1 as quarter_order,',
'           ''Q1 ''''26'' as quarter_label,',
'           214.0 as actual_revenue,',
'           215.0 as target_revenue',
'    from dual',
'',
'    union all',
'',
'    select 2,',
'           ''Q2 ''''26'',',
'           229.3,',
'           234.0',
'    from dual',
'',
'    union all',
'',
'    select 3,',
'           ''Q3 ''''26'',',
'           165.0,',
'           165.0',
'    from dual',
'',
'    union all',
'',
'    select 4,',
'           ''Q4 ''''26'',',
'           cast(null as number) as actual_revenue,',
'           171.0',
'    from dual',
'),',
'chart_data as (',
'    select',
'        quarter_order,',
'        quarter_label,',
'        ''Actual'' as series_name,',
'        actual_revenue as value,',
'        actual_revenue,',
'        target_revenue,',
'        case',
'            when actual_revenue is null then ''In progress''',
'            when actual_revenue >= target_revenue then ''Met target''',
'            else ''Below target''',
'        end as performance_status',
'    from quarterly_revenue',
'',
'    union all',
'',
'    select',
'        quarter_order,',
'        quarter_label,',
'        ''Target'' as series_name,',
'        target_revenue as value,',
'        actual_revenue,',
'        target_revenue,',
'        case',
'            when actual_revenue is null then ''In progress''',
'            when actual_revenue >= target_revenue then ''Met target''',
'            else ''Below target''',
'        end as performance_status',
'    from quarterly_revenue',
')',
'select',
'    quarter_order,',
'    quarter_label,',
'    series_name,',
'    value,',
'    actual_revenue,',
'    target_revenue,',
'    performance_status,',
'    quarter_label || chr(10) ||',
'    ''Target  $'' || to_char(target_revenue, ''FM999G990D0'') || ''M'' || chr(10) ||',
'    case',
'        when actual_revenue is null then ''Actual  In progress''',
'        else ''Actual  $'' || to_char(actual_revenue, ''FM999G990D0'') || ''M''',
'    end as tooltip_text',
'from chart_data',
'order by',
'    quarter_order,',
'    case series_name',
'        when ''Actual'' then 1',
'        when ''Target'' then 2',
'    end;'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'QUARTER_ORDER'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a quarterly grouped bar chart that places actual revenue beside target revenue so users can see performance for each quarter. A missing actual value represents a period that is still in progress rather than zero performance.',
'',
'## When to Use',
'',
'Use for discrete period snapshots where users need to compare actual and target values directly for each quarter or reporting period.',
'',
'## When to Avoid',
'',
'Avoid when month-by-month movement or a continuous target trend is the primary question. Use a combination chart or multi-series line chart instead.',
'',
'## AI Guidance',
'',
'Use the same currency, scale, and period definition for both series. Keep Actual and Target visually distinct, represent unavailable actuals as missing or in progress, and include actual, target, and performance status in the tooltip.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(7063803741544945)
,p_region_id=>wwv_flow_imp.id(12950035733301470)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'N'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_overview_rendered=>'off'
,p_time_axis_type=>'disabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(7066179830544946)
,p_chart_id=>wwv_flow_imp.id(7063803741544945)
,p_static_id=>'actual'
,p_seq=>20
,p_name=>'Actual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH quarterly_revenue AS (',
'    SELECT 1 AS quarter_order,',
'           ''Q1 ''''26'' AS quarter_label,',
'           214.0 AS actual_revenue,',
'           215.0 AS target_revenue',
'    FROM dual',
'',
'    UNION ALL',
'    SELECT 2, ''Q2 ''''26'', 229.3, 234.0 FROM dual',
'',
'    UNION ALL',
'    SELECT 3, ''Q3 ''''26'', 165.0, 165.0 FROM dual',
'',
'    UNION ALL',
'    SELECT 4, ''Q4 ''''26'', CAST(NULL AS NUMBER), 171.0 FROM dual',
')',
'SELECT',
'    quarter_order,',
'    quarter_label,',
'    actual_revenue AS value,',
'',
'    quarter_label || CHR(10) ||',
'    ''Revenue  $'' || TO_CHAR(target_revenue, ''FM999G990D0'') || ''M'' ||',
'    CHR(10) ||',
'    CASE',
'        WHEN actual_revenue IS NULL THEN ''Actual  In progress''',
'        ELSE ''Actual  $'' || TO_CHAR(actual_revenue, ''FM999G990D0'') || ''M''',
'    END AS tooltip_text',
'',
'FROM quarterly_revenue',
'WHERE actual_revenue IS NOT NULL',
'ORDER BY quarter_order;'))
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'QUARTER_LABEL'
,p_color=>'#3f8efc'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(7066710883544946)
,p_chart_id=>wwv_flow_imp.id(7063803741544945)
,p_static_id=>'target'
,p_seq=>10
,p_name=>'Target'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH quarterly_revenue AS (',
'    SELECT 1 AS quarter_order,',
'           ''Q1 ''''26'' AS quarter_label,',
'           214.0 AS actual_revenue,',
'           215.0 AS target_revenue',
'    FROM dual',
'',
'    UNION ALL',
'    SELECT 2, ''Q2 ''''26'', 229.3, 234.0 FROM dual',
'',
'    UNION ALL',
'    SELECT 3, ''Q3 ''''26'', 165.0, 165.0 FROM dual',
'',
'    UNION ALL',
'    SELECT 4, ''Q4 ''''26'', CAST(NULL AS NUMBER), 171.0 FROM dual',
')',
'SELECT',
'    quarter_order,',
'    quarter_label,',
'    target_revenue AS value,',
'',
'    quarter_label || CHR(10) ||',
'    ''Revenue  $'' || TO_CHAR(target_revenue, ''FM999G990D0'') || ''M'' ||',
'    CHR(10) ||',
'    CASE',
'        WHEN actual_revenue IS NULL THEN ''Actual  In progress''',
'        ELSE ''Actual  $'' || TO_CHAR(actual_revenue, ''FM999G990D0'') || ''M''',
'    END AS tooltip_text',
'',
'FROM quarterly_revenue',
'ORDER BY quarter_order;'))
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'QUARTER_LABEL'
,p_color=>'#8f99a8'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(7064365433544945)
,p_chart_id=>wwv_flow_imp.id(7063803741544945)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'inside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(7064906755544946)
,p_chart_id=>wwv_flow_imp.id(7063803741544945)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>0
,p_numeric_pattern=>'$#M'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6963137925595844)
,p_plug_name=>'Pattern: Horizontal Bar Chart'
,p_static_id=>'horizontal-bar-chart'
,p_parent_plug_id=>wwv_flow_imp.id(25451490899915514114)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Ranks customers by revenue using a horizontal bar chart so the highest and lowest values can be identified quickly.',
'',
'## When to Use',
'',
'Use horizontal bars when ranking items, especially when category labels are long or users need to scan an ordered list.',
'',
'## When to Avoid',
'',
'Avoid when users need to understand movement over time, compare several dimensions simultaneously, or inspect a large number of records.',
'',
'## AI Guidance',
'',
'Sort values in descending order, limit the display to a useful top-N set, keep labels readable, and show the value directly or through a concise tooltip. Use a single series when ranking one measure.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6963208184595845)
,p_region_id=>wwv_flow_imp.id(6963137925595844)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'value-desc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6963317181595846)
,p_chart_id=>wwv_flow_imp.id(6963208184595845)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Top Customers'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Customer A'' label, 12 value from sys.dual',
'union all',
'select ''Customer B'' label, 26 value from sys.dual',
'union all',
'select ''Customer C'' label, 18 value from sys.dual',
'union all',
'select ''Customer D'' label, 64 value from sys.dual',
'union all',
'select ''Customer E'' label, 29 value from sys.dual',
'union all',
'select ''Customer F'' label, 51 value from sys.dual',
'union all',
'select ''Customer G'' label, 46 value from sys.dual'))
,p_max_row_count=>20
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'VALUE DESC'
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#3f8efc'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6963440424595847)
,p_chart_id=>wwv_flow_imp.id(6963208184595845)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6963548690595848)
,p_chart_id=>wwv_flow_imp.id(6963208184595845)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>0
,p_numeric_pattern=>'$#M'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24929357292255176815)
,p_plug_name=>'Pattern: Horizontal Bar Chart - Variance'
,p_static_id=>'horizontal-bar-chart-variance'
,p_parent_plug_id=>wwv_flow_imp.id(25451490899915514114)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Shows positive and negative budget variance by department so users can identify favorable and unfavorable deviations from the budget baseline.',
'',
'## When to Use',
'',
'Use a diverging horizontal bar chart when the direction of a metric matters and values need to be compared against zero or another reference point.',
'',
'## When to Avoid',
'',
'Avoid when the values represent parts of a whole, when the primary question is a time trend, or when positive and negative values do not have a meaningful shared baseline.',
'',
'## AI Guidance',
'',
'Keep the zero baseline visible, format positive and negative values consistently, use semantic colors carefully, and order departments to make the largest favorable and unfavorable variances easy to find.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6919700951246483)
,p_region_id=>wwv_flow_imp.id(24929357292255176815)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_fill_multi_series_gaps=>false
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6921417169246484)
,p_chart_id=>wwv_flow_imp.id(6919700951246483)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Budget Variance by Department'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with budget_variance (sort_order, label, metric_value) as (',
'    select 1, ''Marketing'', 12 from sys.dual',
'    union all',
'    select 2, ''Sales'', 7 from sys.dual',
'    union all',
'    select 3, ''Operations'', -4 from sys.dual',
'    union all',
'    select 4, ''Support'', -11 from sys.dual',
')',
'select label,',
'       metric_value as value',
'  from budget_variance',
' order by metric_value'))
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6920275597246483)
,p_chart_id=>wwv_flow_imp.id(6919700951246483)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'inside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6920884604246483)
,p_chart_id=>wwv_flow_imp.id(6919700951246483)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>0
,p_numeric_pattern=>'$#M'
,p_format_scaling=>'million'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25451490899915514114)
,p_plug_name=>'Item Ranking'
,p_static_id=>'item-ranking'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24929451668820125307)
,p_plug_name=>'Pattern: Multi Series Line Chart'
,p_static_id=>'multi-series-line-chart'
,p_parent_plug_id=>wwv_flow_imp.id(38381698840276921)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Compares actual and target revenue as two continuous lines across monthly periods, emphasizing how the measures move and diverge over time.',
'',
'## When to Use',
'',
'Use a multi-series line chart when users need to compare the direction, timing, and gap between related measures across the same time axis.',
'',
'## When to Avoid',
'',
'Avoid when actual values need to stand out as discrete columns or when the target should function primarily as a reference line. Use the combination chart for that presentation.',
'',
'## AI Guidance',
'',
'Use the same date grain, unit, and scale for both series. Use a solid line for actual revenue and a contrasting dashed line for target revenue, and include the monthly gap in the tooltip.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(7014152689194975)
,p_region_id=>wwv_flow_imp.id(24929451668820125307)
,p_chart_type=>'line'
,p_height=>'180'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_fill_multi_series_gaps=>false
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_overview_rendered=>'off'
,p_time_axis_type=>'enabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(7015857635194976)
,p_chart_id=>wwv_flow_imp.id(7014152689194975)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Actual Revenue'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH revenue_data AS (',
'    SELECT DATE ''2026-01-01'' AS month_date, 68.2 AS actual_value FROM dual',
'    UNION ALL SELECT DATE ''2026-02-01'', 71.4 FROM dual',
'    UNION ALL SELECT DATE ''2026-03-01'', 74.8 FROM dual',
'    UNION ALL SELECT DATE ''2026-04-01'', 73.1 FROM dual',
'    UNION ALL SELECT DATE ''2026-05-01'', 76.9 FROM dual',
'    UNION ALL SELECT DATE ''2026-06-01'', 79.3 FROM dual',
'    UNION ALL SELECT DATE ''2026-07-01'', 81.6 FROM dual',
'    UNION ALL SELECT DATE ''2026-08-01'', 84.2 FROM dual',
')',
'SELECT',
'    month_date,',
'    TO_CHAR(',
'        month_date,',
'        ''FMMon'',',
'        ''NLS_DATE_LANGUAGE=English''',
'    ) AS month_label,',
'    actual_value AS value',
'FROM revenue_data',
'ORDER BY month_date;'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'MONTH_DATE'
,p_color=>'#3f8efc'
,p_line_style=>'solid'
,p_line_width=>2
,p_line_type=>'curved'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(7016483475194976)
,p_chart_id=>wwv_flow_imp.id(7014152689194975)
,p_static_id=>'series-2'
,p_seq=>20
,p_name=>'Target Revenue'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH revenue_data AS (',
'    SELECT DATE ''2026-01-01'' AS month_date, 70 AS target_value FROM dual',
'    UNION ALL SELECT DATE ''2026-02-01'', 72 FROM dual',
'    UNION ALL SELECT DATE ''2026-03-01'', 74 FROM dual',
'    UNION ALL SELECT DATE ''2026-04-01'', 76 FROM dual',
'    UNION ALL SELECT DATE ''2026-05-01'', 78 FROM dual',
'    UNION ALL SELECT DATE ''2026-06-01'', 80 FROM dual',
'    UNION ALL SELECT DATE ''2026-07-01'', 82 FROM dual',
'    UNION ALL SELECT DATE ''2026-08-01'', 84 FROM dual',
')',
'SELECT',
'    month_date,',
'    TO_CHAR(',
'        month_date,',
'        ''FMMon'',',
'        ''NLS_DATE_LANGUAGE=English''',
'    ) AS month_label,',
'    target_value AS value',
'FROM revenue_data',
'ORDER BY month_date;'))
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'MONTH_DATE'
,p_color=>'#8f99a8'
,p_line_style=>'dashed'
,p_line_width=>2
,p_line_type=>'curved'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(7014636722194975)
,p_chart_id=>wwv_flow_imp.id(7014152689194975)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'inside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(7015290744194975)
,p_chart_id=>wwv_flow_imp.id(7014152689194975)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_min=>65
,p_max=>85
,p_format_type=>'currency'
,p_decimal_places=>0
,p_numeric_pattern=>'$#M'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24920955931932658348)
,p_plug_name=>'Pattern: Pie Chart'
,p_static_id=>'pie-chart'
,p_parent_plug_id=>wwv_flow_imp.id(25451491699716514122)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Shows the distribution of work items across Open, In Progress, Completed, and On Hold statuses.',
'',
'## When to Use',
'',
'Use a pie chart when a small number of meaningful categories form a complete whole and approximate proportions are more important than precise comparison.',
'',
'## When to Avoid',
'',
'Avoid when there are many categories, similar-sized slices, negative values, or a need to compare exact values across categories. Use a bar chart instead.',
'',
'## AI Guidance',
'',
'Use semantic status colors consistently: blue for Open, amber for In Progress, green for Completed, and gray for On Hold. Keep labels and tooltips clear, and ensure the values represent the same population and time period.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6898370020082783)
,p_region_id=>wwv_flow_imp.id(24920955931932658348)
,p_chart_type=>'pie'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'top'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6898800463082783)
,p_chart_id=>wwv_flow_imp.id(6898370020082783)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Item Status'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with status_data (status_order, label, value, slice_color) as (',
'    select 1, ''Open'', 18, ''#2563EB'' from sys.dual',
'    union all',
'    select 2, ''In Progress'', 34, ''#F59E0B'' from sys.dual',
'    union all',
'    select 3, ''Completed'', 21, ''#16A34A'' from sys.dual',
'    union all',
'    select 4, ''On Hold'', 27, ''#64748B'' from sys.dual',
')',
'select label,',
'       value,',
'       slice_color',
'from status_data',
'order by status_order'))
,p_max_row_count=>20
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'pie'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'&SLICE_COLOR.'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6960305256595816)
,p_plug_name=>'Progress Tracking'
,p_static_id=>'progress-tracking'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24923427427841131138)
,p_plug_name=>'Pattern: Single Series Line Chart'
,p_static_id=>'single-series-line-chart'
,p_parent_plug_id=>wwv_flow_imp.id(38381698840276921)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Shows the month-by-month trend of a single revenue measure across an ordered time period.',
'',
'## When to Use',
'',
'Use a single-series line chart when the primary question is whether one measure is increasing, decreasing, stable, or volatile over time.',
'',
'## When to Avoid',
'',
'Avoid when users need to compare unrelated categories, rank items, or understand part-to-whole composition.',
'',
'## AI Guidance',
'',
'Use a true date column for the time axis, preserve chronological ordering, use a consistent unit and scale, and keep markers or tooltips available when users need to inspect individual periods.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6902332927219758)
,p_region_id=>wwv_flow_imp.id(24923427427841131138)
,p_chart_type=>'line'
,p_height=>'180'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_fill_multi_series_gaps=>false
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_time_axis_type=>'enabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6904070312219759)
,p_chart_id=>wwv_flow_imp.id(6902332927219758)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH revenue_data AS (',
'    SELECT DATE ''2026-01-01'' AS month_date, 63.2 AS actual_value FROM dual',
'    UNION ALL',
'    SELECT DATE ''2026-02-01'', 70.4 FROM dual',
'    UNION ALL',
'    SELECT DATE ''2026-03-01'', 68.8 FROM dual',
'    UNION ALL',
'    SELECT DATE ''2026-04-01'', 73.1 FROM dual',
'    UNION ALL',
'    SELECT DATE ''2026-05-01'', 76.9 FROM dual',
'    UNION ALL',
'    SELECT DATE ''2026-06-01'', 75.3 FROM dual',
'    UNION ALL',
'    SELECT DATE ''2026-07-01'', 81.6 FROM dual',
'    UNION ALL',
'    SELECT DATE ''2026-08-01'', 84.2 FROM dual',
')',
'SELECT',
'    month_date,',
'    TO_CHAR(',
'        month_date,',
'        ''FMMon'',',
'        ''NLS_DATE_LANGUAGE=English''',
'    ) AS month_label,',
'    actual_value AS value',
'FROM revenue_data',
'ORDER BY month_date;'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'MONTH_DATE'
,p_line_style=>'solid'
,p_line_width=>2
,p_line_type=>'curved'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6902819875219758)
,p_chart_id=>wwv_flow_imp.id(6902332927219758)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'inside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6903489110219759)
,p_chart_id=>wwv_flow_imp.id(6902332927219758)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>1
,p_numeric_pattern=>'$#M'
,p_format_scaling=>'million'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6962646784595839)
,p_plug_name=>'Pattern: Stacked Bar Chart'
,p_static_id=>'stacked-bar-chart'
,p_parent_plug_id=>wwv_flow_imp.id(38381153465276915)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
unistr('Shows revenue by product category with each bar divided into North, South, and West regional contributions. The total bar height represents overall revenue while each segment represents a region\2019s contribution.'),
'',
'## When to Use',
'',
'Use stacked bars when users need to compare category totals and understand how each total is composed.',
'',
'## When to Avoid',
'',
'Avoid when users need to compare one segment precisely across many categories, when there are too many series, or when the segments do not form a meaningful total.',
'',
'## AI Guidance',
'',
'Use the same category order in every series, keep the number of segments low, maintain consistent series colors, and use a common unit. Choose stacked bars when total size and composition are both important.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6962779543595840)
,p_region_id=>wwv_flow_imp.id(6962646784595839)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6962807792595841)
,p_chart_id=>wwv_flow_imp.id(6962779543595840)
,p_static_id=>'north'
,p_seq=>10
,p_name=>'North'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with north_revenue (label, category_order, value) as (',
'    select ''Hardware'', 1, 122000 from sys.dual',
'    union all',
'    select ''Software'', 2, 105000 from sys.dual',
'    union all',
'    select ''Services'', 3, 73000 from sys.dual',
'    union all',
'    select ''Support'', 4, 57000 from sys.dual',
')',
'select label,',
'       value',
'from north_revenue',
'order by category_order'))
,p_max_row_count=>20
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#5856d6'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6963604513595849)
,p_chart_id=>wwv_flow_imp.id(6962779543595840)
,p_static_id=>'south'
,p_seq=>20
,p_name=>'South'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with south_revenue (label, category_order, value) as (',
'    select ''Hardware'', 1, 142000 from sys.dual',
'    union all',
'    select ''Software'', 2, 105000 from sys.dual',
'    union all',
'    select ''Services'', 3, 89000 from sys.dual',
'    union all',
'    select ''Support'', 4, 77000 from sys.dual',
')',
'select label,',
'       value',
'from south_revenue',
'order by category_order'))
,p_max_row_count=>20
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#ff2d55'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6963790590595850)
,p_chart_id=>wwv_flow_imp.id(6962779543595840)
,p_static_id=>'west'
,p_seq=>30
,p_name=>'West'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with west_revenue (label, category_order, value) as (',
'    select ''Hardware'', 1, 142000 from sys.dual',
'    union all',
'    select ''Software'', 2, 121000 from sys.dual',
'    union all',
'    select ''Services'', 3, 109000 from sys.dual',
'    union all',
'    select ''Support'', 4, 77000 from sys.dual',
')',
'select label,',
'       value',
'from west_revenue',
'order by category_order'))
,p_max_row_count=>20
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#34aadc'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6962982906595842)
,p_chart_id=>wwv_flow_imp.id(6962779543595840)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6963004316595843)
,p_chart_id=>wwv_flow_imp.id(6962779543595840)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6961712297595830)
,p_plug_name=>'Pattern: Stacked Line with Area Chart'
,p_static_id=>'stacked-line-with-area-chart'
,p_parent_plug_id=>wwv_flow_imp.id(38381698840276921)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
unistr('Shows two related measures across a recent time period, using stacked areas to emphasize the combined total and each measure\2019s contribution to that total.'),
'',
'## When to Use',
'',
'Use stacked line with area charts when additive components change over time and users need to understand both the total trend and the relative contribution of each component.',
'',
'## When to Avoid',
'',
'Avoid when precise comparison between individual series is more important than total composition. Use separate lines instead when series frequently cross or have very different scales.',
'',
'## AI Guidance',
'',
'Use only additive measures, keep the number of series low, provide meaningful series names, preserve a consistent time grain, and use tooltips to expose exact values because area boundaries can be difficult to compare precisely.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6961890149595831)
,p_region_id=>wwv_flow_imp.id(6961712297595830)
,p_chart_type=>'lineWithArea'
,p_height=>'180'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_overview_rendered=>'off'
,p_time_axis_type=>'enabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6961963703595832)
,p_chart_id=>wwv_flow_imp.id(6961890149595831)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trunc(sysdate) - 23 + (level - 1) as label,',
'       round(',
'           65',
'           + (level * 0.7)',
'           + (sin(level / 0.9) * 22)',
'           + (cos(level / 1.7) * 15)',
'           + case',
'               when level between 3 and 4 then 28',
'               when level between 6 and 8 then -24',
'               when level between 10 and 11 then 34',
'               when level between 13 and 15 then -30',
'               when level between 17 and 19 then 26',
'               when level between 21 and 22 then -22',
'               when level = 24 then 18',
'               else 0',
'             end,',
'           1',
'       ) as value',
'from sys.dual',
'connect by level <= 48',
'order by label'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'lineWithArea'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#3f8efc'
,p_line_style=>'solid'
,p_line_width=>2
,p_line_type=>'curved'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6962061125595833)
,p_chart_id=>wwv_flow_imp.id(6961890149595831)
,p_static_id=>'series-2'
,p_seq=>20
,p_name=>'Series 2'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trunc(sysdate) - 23 + (level - 1) as label,',
'       round(',
'           65',
'           + (level * 0.7)',
'           + (sin(level / 0.9) * 22)',
'           + (cos(level / 1.7) * 15)',
'           + (sin(level * 2.8) * 7)    -- pseudo-random noise',
'           + (cos(level * 3.9) * 4)    -- more noise',
'           + case',
'               when level between 3 and 4 then 18',
'               when level between 6 and 8 then -14',
'               when level between 10 and 11 then 24',
'               when level between 13 and 15 then -18',
'               when level between 17 and 19 then 16',
'               when level between 21 and 22 then -12',
'               when level = 24 then 10',
'               else 0',
'             end,',
'           1',
'       ) as value',
'from sys.dual',
'connect by level <= 48',
'order by label;'))
,p_series_type=>'lineWithArea'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_line_style=>'dashed'
,p_line_width=>2
,p_line_type=>'curved'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6962108321595834)
,p_chart_id=>wwv_flow_imp.id(6961890149595831)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_type=>'date-short'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'inside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6962252742595835)
,p_chart_id=>wwv_flow_imp.id(6961890149595831)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92562482498756929130)
,p_plug_name=>'Region Display Selector'
,p_static_id=>'tabs'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38381698840276921)
,p_plug_name=>'Time Series'
,p_static_id=>'time-series'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38381153465276915)
,p_plug_name=>'Value Comparison'
,p_static_id=>'value-comparison'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
