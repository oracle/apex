prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Reference'
,p_alias=>'REFERENCE'
,p_step_title=>'Reference'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24904670521712307984)
,p_plug_name=>'Reference Intro'
,p_static_id=>'apex-ux-pattern-catalog'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:t-Region--removeHeader js-removeLandmark:margin-bottom-md'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Supporting documentation for the Oracle APEX UX Pattern Catalog. This section captures the design principles, conventions, and ongoing evolution of the catalog, providing guidance for developers and AI coding assistants adapting these patterns to '
||'new applications.</p>',
'<p>These principles guide every pattern in the catalog and help ensure consistent, reusable user experiences. A dedicated Design Principles page will provide expanded guidance in a future release.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24893204989247167069)
,p_plug_name=>'Catalog Updates'
,p_static_id=>'catalog-updates'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>60
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Track notable changes to the catalog, including new patterns, guidance updates, and structural refinements.</p>',
'',
'<h3 class="u-text-subheading-sm">Version 26.1.2</h3>',
'<p><strong>Component Pattern Updates</strong></p>',
'<ul>',
'  <li>Added the Component Primitives section, including example use case patterns for Content Row.</li>',
'  <li>Renamed Patterns to Page Patterns to better distinguish page-level patterns from reusable component patterns.</li>',
'  <li>Fixed issues in the Item Selection and Details pattern.</li>',
'</ul>',
'',
'<h3 class="u-text-subheading-sm">Version 26.1.1</h3>',
'<p><strong>Item Detail Pattern Updates</strong></p>',
'<ul>',
'  <li>Added the Item Selection and Details pattern, combining a selectable item list with an adjacent detail view.</li>',
'  <li>Consolidated the placeholder Master-Detail category into Item Details.</li>',
'</ul>',
'',
'<h3 class="u-text-subheading-sm">Version 26.1.0</h3>',
'<p><strong>Initial Release</strong></p>',
'<ul>',
'  <li>Introduced the Oracle APEX UX Pattern Catalog.</li>',
'  <li>Added core pattern categories for dashboards, browse and search, item details, data entry, and master-detail layouts.</li>',
'  <li>Established design principles and pattern documentation conventions.</li>',
'  <li>Optimized pattern pages for both developers and AI-assisted application generation.</li>',
'</ul>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24919548280753228713)
,p_plug_name=>'Design Principles'
,p_static_id=>'pattern-categories'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-target-arrow'' as icon_class,',
'    ''Design for User Tasks'' as title,',
'    ''Organize pages around what users need to accomplish rather than underlying data structures or database entities.'' as description',
'from sys.dual',
'union all',
'select',
'    ''fa-layers'' as icon_class,',
'    ''Establish Clear Hierarchy'' as title,',
'    ''Use layout, spacing, typography, and grouping to guide attention before relying on decorative elements.'' as description',
'from sys.dual',
'union all',
'select',
'    ''fa-mouse-pointer'' as icon_class,',
'    ''Choose the Right Pattern'' as title,',
'    ''Select the pattern that best supports the primary task, then adapt it to your application''''s specific requirements.'' as description',
'from sys.dual',
'union all',
'select',
'    ''fa-synonym'' as icon_class,',
'    ''Create Reusable Patterns'' as title,',
'    ''Build representative examples that can be adapted across applications instead of modeling a single business process.'' as description',
'from sys.dual',
'union all',
'select',
'    ''fa-commenting-o'' as icon_class,',
'    ''Document Design Intent'' as title,',
'    ''Use Page Help, Comments, and metadata to explain when a pattern should be used and the decisions behind it.'' as description',
'from sys.dual',
'union all',
'select',
'    ''fa-sparkles'' as icon_class,',
'    ''Design for Humans and AI'' as title,',
'    ''Create patterns that are easy to understand, inspect, and adapt by both developers and AI coding assistants.'' as description',
'from sys.dual;'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_ICON', '&ICON_CLASS. fa-2x u-opacity-75',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'Y',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24919548505096228716)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24919548342744228714)
,p_name=>'ICON_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24919548472184228715)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24904672157798308000)
,p_plug_name=>'Reference'
,p_static_id=>'reusable-apex-ux-patterns'
,p_icon_css_classes=>'fa-book'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>90
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
