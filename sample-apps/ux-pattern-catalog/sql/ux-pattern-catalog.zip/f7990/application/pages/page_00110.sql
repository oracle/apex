prompt --application/pages/page_00110
begin
--   Manifest
--     PAGE: 00110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>110
,p_name=>unistr('Dashboard \2013\00A0Simple')
,p_alias=>'DASHBOARD-SIMPLE'
,p_step_title=>unistr('Dashboard \2013\00A0Simple')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Scope metric-card layout adjustments to the Metric Cards region. */',
'.app-MetricCards .t-MetricCard { flex-wrap: wrap; }',
'.app-MetricCards .t-MetricCard-badge { margin-inline-start: auto; }'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a simple dashboard pattern for giving users a fast overview of current state and clear paths to inspect supporting information.',
'',
'## When to Use',
'',
'Use when users need a scan-first summary built from a small set of measures, lightweight visual summaries, and concise supporting records.',
'',
'## When to Avoid',
'',
'Avoid when users need deep analysis, complex filtering, dense report comparison, or multi-step workflows.',
'',
'## AI Guidance',
'',
'Preserve the overview-first structure. Keep terminology generic, production-like, and domain-neutral. Do not add visible instructional text to the page. Use component comments to explain the role of each region, action, and custom behavior.'))
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24914089515475688199)
,p_plug_name=>'Line with Area Chart'
,p_static_id=>'chart-1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Highlights directional movement across ordered categories or periods.',
'Pattern role: Lightweight trend visual.',
'AI guidance: Use when the shape of change is more important than individual values. Keep styling subtle and avoid adding multiple competing series.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(24896257874875813290)
,p_region_id=>wwv_flow_imp.id(24914089515475688199)
,p_chart_type=>'lineWithArea'
,p_height=>'220'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(24896259520156813292)
,p_chart_id=>wwv_flow_imp.id(24896257874875813290)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Series A'' label, 12 value from sys.dual',
'union all',
'select ''Series B'' label, 26 value from sys.dual',
'union all',
'select ''Series C'' label, 18 value from sys.dual',
'union all',
'select ''Series D'' label, 34 value from sys.dual',
'union all',
'select ''Series E'' label, 29 value from sys.dual',
'union all',
'select ''Series F'' label, 51 value from sys.dual',
'union all',
'select ''Series G'' label, 46 value from sys.dual',
'union all',
'select ''Series H'' label, 74 value from sys.dual',
'order by 1'))
,p_max_row_count=>20
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'lineWithArea'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#4251bf'
,p_line_style=>'solid'
,p_line_width=>2
,p_line_type=>'curved'
,p_marker_rendered=>'off'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896258362614813291)
,p_chart_id=>wwv_flow_imp.id(24896257874875813290)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896258921709813292)
,p_chart_id=>wwv_flow_imp.id(24896257874875813290)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24914092179561688203)
,p_plug_name=>'Bar Chart'
,p_static_id=>'chart-2'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Compares values across a small set of categories.',
'Pattern role: Category comparison.',
'AI guidance: Use when users need to compare magnitudes quickly. Keep category labels short and avoid too many bars.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(24896261008597813298)
,p_region_id=>wwv_flow_imp.id(24914092179561688203)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(24896262765048813299)
,p_chart_id=>wwv_flow_imp.id(24896261008597813298)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Series A'' label, 12 value from sys.dual',
'union all',
'select ''Series B'' label, 26 value from sys.dual',
'union all',
'select ''Series C'' label, 18 value from sys.dual',
'union all',
'select ''Series D'' label, 34 value from sys.dual',
'union all',
'select ''Series E'' label, 29 value from sys.dual',
'union all',
'select ''Series F'' label, 51 value from sys.dual',
'union all',
'select ''Series G'' label, 46 value from sys.dual',
'union all',
'select ''Series H'' label, 74 value from sys.dual',
'order by 1'))
,p_max_row_count=>20
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#8e6ac8'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896261553229813298)
,p_chart_id=>wwv_flow_imp.id(24896261008597813298)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896262107061813298)
,p_chart_id=>wwv_flow_imp.id(24896261008597813298)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24914057888696575568)
,p_plug_name=>'Pie Chart'
,p_static_id=>'chart-3'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Shows a simple proportional breakdown across a small number of categories.',
'Pattern role: Part-to-whole summary.',
'AI guidance: Use only when there are a few meaningful categories and approximate proportion is more important than precise comparison.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(24896264231973813299)
,p_region_id=>wwv_flow_imp.id(24914057888696575568)
,p_chart_type=>'pie'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(24896264760208813299)
,p_chart_id=>wwv_flow_imp.id(24896264231973813299)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Series A'' label, 18 value from sys.dual',
'union all',
'select ''Series B'' label, 34 value from sys.dual',
'union all',
'select ''Series C'' label, 21 value from sys.dual',
'union all',
'select ''Series D'' label, 27 value from sys.dual',
'order by 1'))
,p_max_row_count=>20
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'pie'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24914059318540575582)
,p_plug_name=>'Status List'
,p_static_id=>'content-row'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>80
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''Task''             overline,',
'    ''Dashboard Item 1'' title,',
'    ''Representative workflow item one'' description,',
'    ''fa-clipboard-list'' icon,',
'    ''Complete''         badge,',
'    ''success''          badge_state,',
'    null               badge_icon',
'from sys.dual',
'union all',
'select',
'    ''Document''         overline,',
'    ''Dashboard Item 2'' title,',
'    ''Representative workflow item two'' description,',
'    ''fa-file-text-o''   icon,',
'    ''In Progress''      badge,',
'    ''warning''          badge_state,',
'    null               badge_icon',
'from sys.dual',
'union all',
'select',
'    ''Approval''         overline,',
'    ''Dashboard Item 3'' title,',
'    ''Representative workflow item three'' description,',
'    ''fa-user-check''    icon,',
'    ''Needs Review''     badge,',
'    ''danger''           badge_state,',
'    null               badge_icon',
'from sys.dual',
'union all',
'select',
'    ''Dataset''          overline,',
'    ''Dashboard Item 4'' title,',
'    ''Representative workflow item four'' description,',
'    ''fa-database''      icon,',
'    ''Available''        badge,',
'    ''info''             badge_state,',
'    null               badge_icon',
'from sys.dual',
'union all',
'select',
'    ''Configuration''    overline,',
'    ''Dashboard Item 5'' title,',
'    ''Representative workflow item five'' description,',
'    ''fa-cogs''          icon,',
'    ''Updated''          badge,',
'    ''success''          badge_state,',
'    null               badge_icon',
'from sys.dual'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON. fa-lg',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignCenter',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', 'Badge',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_POS', 't-ContentRow-badge--posEnd',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'BADGE',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'OVERLINE', '&OVERLINE.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Shows a short set of high-level status items that support the dashboard summary.',
'Pattern role: Supporting status list.',
'AI guidance: Keep rows concise and scannable. Use badges only when status needs to be visible at a glance, and keep badge value, state, and icon semantically aligned. Row titles may link to related application areas or item-level details. Avoid turni'
||'ng this region into a full report.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914060215267575591)
,p_name=>'BADGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914060431420575593)
,p_name=>'BADGE_ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914060341978575592)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914060029404575589)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914060138555575590)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914059844086575587)
,p_name=>'OVERLINE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OVERLINE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914059879625575588)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(24895849693877852331)
,p_region_id=>wwv_flow_imp.id(24914059318540575582)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24914181022951219446)
,p_plug_name=>'Section Summary'
,p_static_id=>'content-row-2'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''Section 1''                                 title,',
'    ''Representative summary text for the first section''   description,',
'    ''fa-line-chart''                                       icon,',
'    ''12 metrics''                                          meta,',
'    null                                                  badge,',
'    null                                                  badge_state,',
'    null                                                  badge_icon',
'from sys.dual',
'union all',
'select',
'    ''Section 2''                                 title,',
'    ''Representative summary text for the second section''  description,',
'    ''fa-database''                                         icon,',
'    ''Updated 10m ago''                                     meta,',
'    null                                                  badge,',
'    null                                                  badge_state,',
'    null                                                  badge_icon',
'from sys.dual',
'union all',
'select',
'    ''Section 3''                                 title,',
'    ''Representative summary text for the third section''   description,',
'    ''fa-users''                                            icon,',
'    ''4 groups''                                            meta,',
'    null                                                  badge,',
'    null                                                  badge_state,',
'    null                                                  badge_icon',
'from sys.dual',
'union all',
'select',
'    ''Section 4''                                 title,',
'    ''Representative summary text for the fourth section''  description,',
'    ''fa-shield''                                           icon,',
'    ''2 reviews''                                           meta,',
'    null                                                  badge,',
'    null                                                  badge_state,',
'    null                                                  badge_icon',
'from sys.dual',
'union all',
'select',
'    ''Section 5''                                 title,',
'    ''Representative summary text for the fifth section''   description,',
'    ''fa-cogs''                                             icon,',
'    ''5 settings''                                          meta,',
'    null                                                  badge,',
'    null                                                  badge_state,',
'    null                                                  badge_icon',
'from sys.dual'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_SIZE', 't-Avatar--xs',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'MISC', '&META.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'STYLE', 't-ContentRow--styleCompact',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Shows a compact summary of related sections or areas represented by the dashboard.',
'Pattern role: Supporting section summary.',
'AI guidance: Use this variation when the dashboard needs lightweight navigation or orientation across related areas. Keep text brief and high-level. Row titles may link to the corresponding section or application area. Avoid duplicating the status li'
||'st or adding dense operational detail.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914181562840219451)
,p_name=>'BADGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914181687937219453)
,p_name=>'BADGE_ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914181577216219452)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914181352045219449)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914181418222219450)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914182080838219457)
,p_name=>'META'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'META'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914181249171219448)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(24896408561198562583)
,p_region_id=>wwv_flow_imp.id(24914181022951219446)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24914057005827575559)
,p_plug_name=>unistr('Dashboard \2013\00A0Simple')
,p_static_id=>'dashboard-title'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Track key measures and supporting activity from one overview.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Establishes the dashboard title, short context, and page-level actions.',
'Pattern role: Dashboard header.',
'AI guidance: Keep this region concise and action-oriented. Do not use it for instructional pattern documentation.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24914056154907575550)
,p_plug_name=>'Metric Cards'
,p_static_id=>'metric-cards'
,p_region_css_classes=>'app-MetricCards'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-line-chart''    icon,',
'    ''Primary KPI''      label,',
'    84200              metric_value,',
'    ''Trend''            badge,',
'    ''+12%''             badge_value,',
'    ''success''          badge_state,',
'    ''fa-trend-up''      badge_icon',
'from sys.dual',
'union all',
'select',
'    ''fa-bar-chart''     icon,',
'    ''Secondary KPI''    label,',
'    12800              metric_value,',
'    ''Trend''            badge,',
'    ''+320 units''       badge_value,',
'    ''success''          badge_state,',
'    ''fa-trend-up''      badge_icon',
'from sys.dual',
'union all',
'select',
'    ''fa-area-chart''    icon,',
'    ''Trend KPI''        label,',
'    64                 metric_value,',
'    ''Trend''            badge,',
'    ''20m faster''       badge_value,',
'    ''success''          badge_state,',
'    ''fa-trend-up''      badge_icon',
'from sys.dual',
'union all',
'select',
'    ''fa-dashboard''     icon,',
'    ''Status KPI''       label,',
'    348                metric_value,',
'    ''Trend''            badge,',
'    ''-14 items''        badge_value,',
'    ''danger''           badge_state,',
'    ''fa-trend-down''    badge_icon',
'from sys.dual'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'BADGE_VALUE'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$METRIC_CARD'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AVATAR_ALIGNMENT', 't-MetricCard-body--avatarAlignmentStart',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_POSITION', 't-MetricCard-body--avatarPositionInline',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_STYLE', 't-MetricCard-avatar--subtle',
  'AVATAR_TYPE', 'icon',
  'BADGE_ICON', '&BADGE_ICON.',
  'BADGE_LABEL', 'Trend',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_SIZE', 't-Badge--md',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'BADGE_VALUE',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'LAYOUT', '4cols',
  'META', '&LABEL.',
  'METRIC', '&METRIC_VALUE.',
  'METRIC_CSS_CLASSES', 'u-text-subheading-md')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Presents the highest-priority dashboard measures for immediate scanning.',
'Pattern role: KPI summary.',
'AI guidance: Use a small number of comparable metrics, usually two to four when the dashboard needs a KPI group. Badge value, badge state, and badge icon should be semantically aligned. Format the key metric value for quick scanning, typically with t'
||'housands separators for large numbers. Avoid turning this region into a dense report.',
'Implementation note: The app-MetricCards CSS class scopes page-level CSS to this region.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914056564919575555)
,p_name=>'BADGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914056869534575558)
,p_name=>'BADGE_ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914056766345575557)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914056692535575556)
,p_name=>'BADGE_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_VALUE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914056222736575551)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914056397068575553)
,p_name=>'LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LABEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24914056538961575554)
,p_name=>'METRIC_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'METRIC_VALUE'
,p_data_type=>'NUMBER'
,p_display_sequence=>40
,p_format_mask=>'999G999G999G999G999G999G990'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24914182208232219458)
,p_plug_name=>'Time Series'
,p_static_id=>'time-series'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Shows how a key measure changes over a recent period.',
'Pattern role: Trend summary.',
'AI guidance: Use for time-based movement where direction and change matter more than exact point comparison. Keep the series count low and labels readable.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(24896278909015813310)
,p_region_id=>wwv_flow_imp.id(24914182208232219458)
,p_chart_type=>'lineWithArea'
,p_height=>'220'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_time_axis_type=>'enabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(24896280645990813310)
,p_chart_id=>wwv_flow_imp.id(24896278909015813310)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trunc(sysdate) - 23 + (level - 1) as label,',
'       round(',
'           65',
'           + (level * 0.7)',
'           + (sin(level / 0.9) * 22)',
'           + (cos(level / 1.7) * 15)',
'           + case',
'               when level between 3 and 4 then 28',
'               when level between 6 and 8 then -24',
'               when level between 10 and 11 then 34',
'               when level between 13 and 15 then -30',
'               when level between 17 and 19 then 26',
'               when level between 21 and 22 then -22',
'               when level = 24 then 18',
'               else 0',
'             end,',
'           1',
'       ) as value',
'from sys.dual',
'connect by level <= 24',
'order by label'))
,p_max_row_count=>20
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'lineWithArea'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#1fb6a6'
,p_line_style=>'solid'
,p_line_width=>2
,p_line_type=>'curved'
,p_marker_rendered=>'off'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896279427932813310)
,p_chart_id=>wwv_flow_imp.id(24896278909015813310)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_type=>'date-short'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'inside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896280081345813310)
,p_chart_id=>wwv_flow_imp.id(24896278909015813310)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896272790460813306)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(24914057005827575559)
,p_button_name=>'ACTIONS_MENU'
,p_static_id=>'actions-menu'
,p_show_as_disabled=>false
,p_button_type=>'MENU'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Actions'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ellipsis-v'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Groups lower-frequency or optional page actions.',
'Pattern role: Overflow actions.',
'AI guidance: Use for actions that should remain available without competing with the primary action.'))
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24914072928506575589)
,p_button_id=>wwv_flow_imp.id(24896272790460813306)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 1'
,p_static_id=>'menu-action-a'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24914073003897575590)
,p_button_id=>wwv_flow_imp.id(24896272790460813306)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 2'
,p_static_id=>'menu-action-b'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24914073116068575591)
,p_button_id=>wwv_flow_imp.id(24896272790460813306)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 3'
,p_static_id=>'menu-action-c'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896274408164813308)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24914057005827575559)
,p_button_name=>'PRIMARY_ACTION'
,p_static_id=>'primary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Primary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Represents the main follow-up action from the dashboard overview.',
'Pattern role: Primary page action.',
'AI guidance: Keep prominent. Use a domain-specific label only when adapting this pattern to a real application.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896274853894813308)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(24914057005827575559)
,p_button_name=>'SECONDARY_ACTION'
,p_static_id=>'secondary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Secondary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Represents a useful but lower-priority follow-up action.',
'Pattern role: Secondary page action.',
'AI guidance: Keep visually subordinate to the primary action.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896260205240813293)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(24914089515475688199)
,p_button_name=>'VIEW_DETAILS_LINK'
,p_static_id=>'view-details'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'View Details Link'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-right'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896408597517562584)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24914059318540575582)
,p_button_name=>'VIEW_DETAILS_LINK_3'
,p_static_id=>'view-details-link-3'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'View Details Link'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-right'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896263402734813299)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(24914092179561688203)
,p_button_name=>'VIEW_DETAILS_POPUP'
,p_static_id=>'view-details-popup'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'View Details'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896408748255562585)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(24914181022951219446)
,p_button_name=>'VIEW_DETAILS_POPUP_3'
,p_static_id=>'view-details-popup-3'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'View Details'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896265458821813299)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24914057888696575568)
,p_button_name=>'VIEW_DETAILS_POPUP_2'
,p_static_id=>'view-details-popup_2'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'View Details'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896281326067813311)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(24914182208232219458)
,p_button_name=>'VIEW_DETAILS_LINK_2'
,p_static_id=>'view-details_2'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'View Details Link'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-right'
,p_grid_new_row=>'Y'
);
wwv_flow_imp.component_end;
end;
/
