prompt --application/pages/page_00320
begin
--   Manifest
--     PAGE: 00320
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>320
,p_name=>unistr('Item Detail \2013 Full')
,p_alias=>'ITEM-DETAIL-FULL'
,p_step_title=>unistr('Item Detail \2013 Full')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Keep contextual information compact and make its status badges easy to scan. */',
'.app-ContextualInfo {',
'  --ut-contextualinfo-item-label-stacked-margin-y: 0;',
'  --ut-badge-font-weight: 600;',
'}',
'',
'/* Establish visual hierarchy between featured, standard, and compact activity rows. */',
'.app-ActivityTimeline .is-standard {',
'  --ut-cr-title-font-weight: 600;',
'}',
'',
'.app-ActivityTimeline .is-compact {',
'  --ut-cr-title-font-size: 0.875rem;',
'  --ut-cr-title-font-weight: 400;',
'}',
'',
'.app-ItemDetailTabs .a-RDS-list {padding-block-start: 0;}'))
,p_step_template=>1999837786206682705
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates an item detail summary pattern for inspecting one record quickly before taking action. The page combines item context, a concise summary, key details, supporting metrics, related information, and recent activity.',
'',
'## When to Use',
'',
'Use when users need a scan-first view of one item and a small number of clear next actions. This pattern works well when users need current state, ownership, timing, supporting context, and links to related information in one place.',
'',
'## When to Avoid',
'',
'Avoid when users need to compare many records, perform complex filtering, edit large amounts of data, or complete a multi-step workflow. Use a sectioned, tabbed, or master-detail pattern when the item has substantially more information or deeper rela'
||'ted tasks.',
'',
'## AI Guidance',
'',
'Preserve the item-detail hierarchy: item identity and context first, primary and secondary actions next, followed by summary information, supporting details, related information, and activity. Keep the terminology generic and domain-neutral. Keep sum'
||'maries concise and decision-relevant. Use semantic state values consistently for badges and status indicators. Keep primary actions prominent, secondary actions subordinate, and lower-frequency actions in the overflow menu. Do not add visible instruc'
||'tional text to the page. Use component comments to explain region intent, action hierarchy, data mappings, and custom behavior.'))
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24897072591518550356)
,p_plug_name=>'Activity'
,p_static_id=>'activity-2'
,p_region_sub_css_classes=>'app-ActivityTimeline'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Activity timeline guidance for AI:',
'',
'1. The timeline should show the meaningful payload of the event at a glance.',
'2. Attribute changes should use the title to describe the new value or state.',
'3. File events should name the file in the title so the user can identify it immediately.',
'4. Comment events should surface the comment text itself; the title can be the comment body, or the description can carry it if the title is a short summary.',
'5. Use the description only when it adds useful context such as previous value, author, or a short supporting note.',
'6. Keep some rows title-only to demonstrate that not every activity needs a description.',
'7. Keep the mix of row shapes so the timeline can represent simple and rich events.',
'*/',
'',
'select ''Today'' as activity_group,',
'       10 as display_sequence,',
'       sysdate - interval ''1'' hour as activity_time,',
'       ''Maya Chen'' as actioned_by,',
'       ''Updated'' as action_type,',
'       null as badge_label,',
'       ''Status changed to On Track'' as title,',
'       ''Previous status: Needs Review'' as description,',
'       ''fa-check-circle-o u-success-text'' as icon_class,',
'       ''is-featured'' as row_class,',
'       1 as id',
'  from sys.dual',
'union all',
'select ''Today'',',
'       20,',
'       sysdate - interval ''4'' hour,',
'       ''Jordan Lee'',',
'       ''Reviewed'',',
'       null,',
'       ''Review completed'',',
'       ''Next step confirmed for the current owner'',',
'       ''fa-check-circle-o u-success-text'',',
'       ''is-standard'',',
'       2',
'  from sys.dual',
'union all',
'select ''This Week'',',
'       30,',
'       trunc(sysdate) - 2 + (9/24),',
'       ''Maya Chen'',',
'       ''Commented'',',
'       null,',
'       ''We should confirm the owner before moving this forward.'',',
'       ''Comment added to the current record'',',
'       ''fa-comments-o u-info-text'',',
'       ''is-standard'',',
'       3',
'  from sys.dual',
'union all',
'select ''This Week'',',
'       40,',
'       trunc(sysdate) - 3 + (14/24),',
'       ''Jordan Lee'',',
'       ''Adjusted'',',
'       null,',
'       ''Target Date set to October 1'',',
'       ''Previous target date: September 18'',',
'       ''fa-calendar-o u-info-text'',',
'       ''is-standard'',',
'       4',
'  from sys.dual',
'union all',
'select ''Earlier'',',
'       50,',
'       trunc(sysdate) - 7 + (11/24),',
'       null,',
'       null,',
'       null,',
'       ''Ownership assigned to Avery Smith for ongoing follow-up'',',
'       null,',
'       ''fa-user u-info-text'',',
'       ''is-compact'',',
'       5',
'  from sys.dual',
'union all',
'select ''Earlier'',',
'       60,',
'       trunc(sysdate) - 9 + (10/24),',
'       null,',
'       null,',
'       null,',
'       ''Standard Intake linked to support the current record'',',
'       null,',
'       ''fa-link u-info-text'',',
'       ''is-compact'',',
'       6',
'  from sys.dual',
'union all',
'select ''Earlier'',',
'       70,',
'       trunc(sysdate) - 10 + (12/24),',
'       null,',
'       null,',
'       null,',
'       ''Reference removed after duplicate values were identified'',',
'       null,',
'       ''fa-minus-circle-o u-danger-text'',',
'       ''is-compact'',',
'       7',
'  from sys.dual',
'union all',
'select ''Earlier'',',
'       80,',
'       trunc(sysdate) - 11 + (16/24),',
'       null,',
'       null,',
'       null,',
'       ''Initial record created and prepared for first review'',',
'       null,',
'       ''fa-plus-circle-o u-info-text'',',
'       ''is-compact'',',
'       8',
'  from sys.dual;'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'display_sequence, activity_group'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON_CLASS.',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_SIZE', 't-Avatar--sm',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'GROUP_TITLE', '<div class="u-text-uppercase u-text-muted-color u-text-body-xs u-text-bold">&ACTIVITY_GROUP.</div>',
  'HIDE_BORDERS', 'N',
  'ITEM_CSS_CLASSES', '&ROW_CLASS.',
  'MISC', '&ACTIVITY_TIME.',
  'OVERLINE', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{if ACTIONED_BY/}',
    '    &ACTIONED_BY.{if ACTION_TYPE/} &middot; &ACTION_TYPE.{endif/}',
    '{elseif ACTION_TYPE/}',
    '    &ACTION_TYPE.',
    '{endif/}')),
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Shows meaningful changes, decisions, comments, and events associated with the current item.',
'',
'Pattern role: Activity timeline.',
'',
'AI guidance: Make the event title carry the meaningful payload at a glance. Attribute changes should describe the new value or state. File events should identify the file. Comment events should surface the comment text. Use the description only for u'
||'seful supporting context such as a previous value, author, or note. Keep some rows title-only and retain a mix of featured, standard, and compact rows to demonstrate different event shapes. Use featured rows for especially important events and compac'
||'t rows for lower-detail history.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897073025790550360)
,p_name=>'ACTIONED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIONED_BY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897073120015550361)
,p_name=>'ACTION_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTION_TYPE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897072726803550357)
,p_name=>'ACTIVITY_GROUP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIVITY_GROUP'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>true
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897072920128550359)
,p_name=>'ACTIVITY_TIME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIVITY_TIME'
,p_data_type=>'DATE'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897073204980550362)
,p_name=>'BADGE_LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_LABEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897073413053550364)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897072841866550358)
,p_name=>'DISPLAY_SEQUENCE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DISPLAY_SEQUENCE'
,p_data_type=>'NUMBER'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897073565836550365)
,p_name=>'ICON_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897073782754550367)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>110
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897073601499550366)
,p_name=>'ROW_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROW_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897073323304550363)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(24893133491064541271)
,p_name=>'Related Records'
,p_static_id=>'child-records'
,p_template=>2323592004483952560
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Child record table guidance for AI:',
'',
'1. Use the child record name as the primary identifying value and make it linkable when detail navigation is available.',
'2. Use the type to distinguish common child-record roles such as tasks, reviews, approvals, and deliverables.',
'3. Use the owner to show accountability for each child record.',
'4. Use status as a badge and map each status label to one consistent semantic state.',
'5. Use DUE_DATE as a real date value and apply presentation formatting in the report column mapping.',
'6. Keep the column set compact so the table demonstrates text, classification, ownership, badge, and date components without becoming dense.',
'*/',
'',
'-- Tabular query for child records belonging to an item.',
'select ''Prepare requirements summary'' as child_record_name,',
'       ''Task''                      as child_record_type,',
'       ''Jordan Lee''                as owner_name,',
'       ''In Progress''               as child_record_status,',
'       ''warning''                   as child_record_status_state,',
'       sysdate + 3                 as due_date',
'  from sys.dual',
'union all',
'select ''Confirm review participants'' as child_record_name,',
'       ''Review''                     as child_record_type,',
'       ''Morgan Patel''               as owner_name,',
'       ''Not Started''                as child_record_status,',
'       ''info''                       as child_record_status_state,',
'       sysdate + 7                  as due_date',
'  from sys.dual',
'union all',
'select ''Approve delivery plan''      as child_record_name,',
'       ''Approval''                   as child_record_type,',
'       ''Casey Nguyen''               as owner_name,',
'       ''Blocked''                    as child_record_status,',
'       ''danger''                     as child_record_status_state,',
'       sysdate + 5                  as due_date',
'  from sys.dual',
'union all',
'select ''Publish final summary''      as child_record_name,',
'       ''Deliverable''                as child_record_type,',
'       ''Avery Ross''                 as owner_name,',
'       ''Complete''                   as child_record_status,',
'       ''success''                    as child_record_status_state,',
'       sysdate - 2                  as due_date',
'  from sys.dual',
'union all',
'select ''Schedule follow-up review''  as child_record_name,',
'       ''Follow-up''                  as child_record_type,',
'       ''Taylor Singh''               as owner_name,',
'       ''In Progress''                as child_record_status,',
'       ''warning''                    as child_record_status_state,',
'       sysdate + 14                 as due_date',
'  from sys.dual',
'order by 6'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893133547285541272)
,p_query_column_id=>1
,p_column_alias=>'CHILD_RECORD_NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Name'
,p_column_link=>'#'
,p_column_linktext=>'#CHILD_RECORD_NAME#'
,p_column_link_attr=>'class="u-text-bold"'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893133836050541275)
,p_query_column_id=>4
,p_column_alias=>'CHILD_RECORD_STATUS'
,p_column_display_sequence=>60
,p_column_heading=>'Status'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{with/}',
'  LABEL:=Status',
'  VALUE:=#CHILD_RECORD_STATUS#',
'  STATE:=#CHILD_RECORD_STATUS_STATE#',
'  LABEL_DISPLAY:=N',
'  STYLE:=t-Badge--subtle t-Badge--circle',
'  SIZE:=t-Badge--md',
'{apply THEME$BADGE/}'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893133997303541276)
,p_query_column_id=>5
,p_column_alias=>'CHILD_RECORD_STATUS_STATE'
,p_column_display_sequence=>70
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893133714958541273)
,p_query_column_id=>2
,p_column_alias=>'CHILD_RECORD_TYPE'
,p_column_display_sequence=>30
,p_column_heading=>'Type'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893134078041541277)
,p_query_column_id=>6
,p_column_alias=>'DUE_DATE'
,p_column_display_sequence=>80
,p_column_heading=>'Due'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893133808143541274)
,p_query_column_id=>3
,p_column_alias=>'OWNER_NAME'
,p_column_display_sequence=>50
,p_column_heading=>'Owner'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24893200919076167028)
,p_plug_name=>'Comments'
,p_static_id=>'comments'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Comments query guidance for AI:',
'',
'1. Keep COMMENT_TEXT realistic and concise; each sample comment should stay below 250 characters.',
'2. Keep the comment text separate from the author, date, and direction.',
'3. Derive USER_INITIALS from USERNAME with APEX_STRING.GET_INITIALS.',
'4. Derive AVATAR_COLOR_CLASS from USERNAME with ORA_HASH so repeated authors keep the same color.',
'5. Use COMMENT_DATE as a real date value and apply presentation formatting in the component mapping.',
'6. Use MESSAGE_DIRECTION to distinguish inbound and outbound communication; outbound messages represent the current user.',
'7. Keep the sample to four people and eight messages so repeated authors demonstrate consistent avatar colors.',
'*/',
'',
'-- Query for comments associated with an item.',
'with comments as (',
'    select ''I updated the summary with the latest ownership notes. Please confirm the final reviewer before I send it for approval.'' as comment_text,',
'           ''Shakira Raymond''                                                                                              as username,',
'           sysdate - 1 + (10 / 24)                                                                                        as comment_date,',
'           ''outbound''                                                                                                     as message_direction',
'      from sys.dual',
'    union all',
'    select ''We should confirm the owner before moving this forward.'' as comment_text,',
'           ''Maya Chen''                                           as username,',
'           trunc(sysdate) - 2 + (9 / 24)                          as comment_date,',
'           ''inbound''                                              as message_direction',
'      from sys.dual',
'    union all',
'    select ''The revised requirements are ready for review. I clarified the acceptance criteria and added the dependency notes from yesterday''''s discussion.'' as comment_text,',
'           ''Shakira Raymond''                                                                                                           as username,',
'           sysdate - 6                                                                                                                 as comment_date,',
'           ''outbound''                                                                                                                  as message_direction',
'      from sys.dual',
'    union all',
'    select ''Thanks. I reviewed the changes and added two questions about the handoff timing. The rest of the summary looks good to me.'' as comment_text,',
'           ''Morgan Patel''                                                                                                      as username,',
'           sysdate - 3                                                                                                           as comment_date,',
'           ''inbound''                                                                                                             as message_direction',
'      from sys.dual',
'    union all',
'    select ''The supporting file has been updated with the latest figures. Please use the new version for the review meeting.'' as comment_text,',
'           ''Casey Nguyen''                                                                                                 as username,',
'           sysdate - 4                                                                                                    as comment_date,',
'           ''inbound''                                                                                                      as message_direction',
'      from sys.dual',
'    union all',
'    select ''I can take the follow-up review. I will confirm the open items with the team and share an update before the end of the week.'' as comment_text,',
'           ''Maya Chen''                                                                                                             as username,',
'           sysdate - 7                                                                                                             as comment_date,',
'           ''inbound''                                                                                                               as message_direction',
'      from sys.dual',
'    union all',
'    select ''The final decision is recorded in the summary. No additional changes are needed unless the ownership or delivery date changes.'' as comment_text,',
'           ''Morgan Patel''                                                                                                                 as username,',
'           sysdate - 12                                                                                                                   as comment_date,',
'           ''inbound''                                                                                                                      as message_direction',
'      from sys.dual',
'    union all',
'    select ''I added the meeting notes and linked the supporting document. The remaining question is whether the current due date still holds.'' as comment_text,',
'           ''Casey Nguyen''                                                                                                                 as username,',
'           sysdate - 15                                                                                                                   as comment_date,',
'           ''inbound''                                                                                                                      as message_direction',
'      from sys.dual',
')',
'select comment_text,',
'       username,',
'       apex_string.get_initials(username) as user_initials,',
'       comment_date,',
'       message_direction,',
'       ''u-color-'' || to_char(ora_hash(username, 10)) as avatar_color_class',
'  from comments;',
''))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'4'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$COMMENTS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'ALIGNMENT', '&MESSAGE_DIRECTION.',
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_CSS_CLASSES', '&AVATAR_COLOR_CLASS.',
  'AVATAR_INITIALS', 'USER_INITIALS',
  'AVATAR_SHAPE', 't-Avatar--circle',
  'AVATAR_TYPE', 'initials',
  'COMMENT_DATE', 'COMMENT_DATE',
  'COMMENT_TEXT', 'COMMENT_TEXT',
  'DISPLAY_AVATAR', 'Y',
  'STYLE', 't-Comments--chat',
  'USER_NAME', 'USERNAME')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893202796075167047)
,p_name=>'AVATAR_COLOR_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AVATAR_COLOR_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893202463577167044)
,p_name=>'COMMENT_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENT_DATE'
,p_data_type=>'DATE'
,p_display_sequence=>40
,p_format_mask=>'SINCE'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893202216597167041)
,p_name=>'COMMENT_TEXT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENT_TEXT'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893202618777167045)
,p_name=>'MESSAGE_DIRECTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MESSAGE_DIRECTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893202253581167042)
,p_name=>'USERNAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USERNAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893202339969167043)
,p_name=>'USER_INITIALS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USER_INITIALS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(24896929315666964355)
,p_name=>'Item Properties 2'
,p_static_id=>'details'
,p_parent_plug_id=>wwv_flow_imp.id(24896992468884422146)
,p_template=>3372714138756020509
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_grid_row_css_classes=>'u-gap-0'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''REC-1001'' as reference,',
'       ''Standard Intake'' as source,',
'       ''Summary Record'' as type,',
'       ''Tracked, Reviewable'' as tags',
'  from dual;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2101991776017792140
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Presents supporting item attributes in compact value-and-attribute groups.',
'',
'Pattern role: Attribute-pair detail layout.',
'',
'AI guidance: Group related attributes together and order them according to the decisions users need to make. Keep labels concise and values consistently formatted. Format percentages, dates, durations, counts, and units for scanning. Use separate gro'
||'ups when the item has distinct categories of supporting information, such as classification versus ownership and timing.'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893167492168853270)
,p_query_column_id=>1
,p_column_alias=>'REFERENCE'
,p_column_display_sequence=>10
,p_column_heading=>'Reference'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893167922778853270)
,p_query_column_id=>2
,p_column_alias=>'SOURCE'
,p_column_display_sequence=>20
,p_column_heading=>'Source'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893168700949853270)
,p_query_column_id=>4
,p_column_alias=>'TAGS'
,p_column_display_sequence=>60
,p_column_heading=>'Tags'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893168245833853270)
,p_query_column_id=>3
,p_column_alias=>'TYPE'
,p_column_display_sequence=>30
,p_column_heading=>'Type'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(24896992530044422147)
,p_name=>'Item Properties 3'
,p_static_id=>'details-2'
,p_parent_plug_id=>wwv_flow_imp.id(24896992468884422146)
,p_template=>3372714138756020509
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''72%''        as progress,',
'       ''Medium''     as priority,',
'       ''Maya Chen''  as owner,',
'       sysdate + 14     as due',
'  from dual;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2101991776017792140
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Presents supporting item attributes in compact value-and-attribute groups.',
'',
'Pattern role: Attribute-pair detail layout.',
'',
'AI guidance: Group related attributes together and order them according to the decisions users need to make. Keep labels concise and values consistently formatted. Format percentages, dates, durations, counts, and units for scanning. Use separate gro'
||'ups when the item has distinct categories of supporting information, such as classification versus ownership and timing.'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893170758125853271)
,p_query_column_id=>4
,p_column_alias=>'DUE'
,p_column_display_sequence=>40
,p_column_heading=>'Due'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893170374089853271)
,p_query_column_id=>3
,p_column_alias=>'OWNER'
,p_column_display_sequence=>30
,p_column_heading=>'Owner'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893170002672853271)
,p_query_column_id=>2
,p_column_alias=>'PRIORITY'
,p_column_display_sequence=>20
,p_column_heading=>'Priority'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893169563166853271)
,p_query_column_id=>1
,p_column_alias=>'PROGRESS'
,p_column_display_sequence=>10
,p_column_heading=>'Progress'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24893131605547541252)
,p_plug_name=>'Files'
,p_static_id=>'files'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'File list guidance for AI:',
'',
'1. Use the file title as the human-readable label users scan first.',
'2. Preserve the real filename separately so users can identify the downloadable or stored asset.',
'3. Use a file-extension icon to reinforce the file format without requiring a separate file-type label.',
'4. Keep file size and last-updated date as separate values for quick scanning.',
'5. Use the badge for access level because it communicates what users can do with the file.',
'6. Map each access label to one consistent semantic state.',
'7. Preserve a mix of file formats, access levels, sizes, and update dates so the pattern demonstrates realistic variation.',
'*/',
'',
'-- Content row query for files associated with an item.',
'select ''fa-file-pdf-o''          as file_icon,',
'       ''Planning brief''         as file_title,',
'       ''planning-brief-v3.pdf''  as file_name,',
'       ''2.4 MB''                 as file_size,',
'       sysdate - 2              as last_updated,',
'       ''Shared''                 as file_access,',
'       ''info''                   as file_access_state',
'  from sys.dual',
'union all',
'select ''fa-file-archive-o''      as file_icon,',
'       ''Reference image set''    as file_title,',
'       ''reference-images.zip''   as file_name,',
'       ''18.7 MB''                as file_size,',
'       sysdate - 5              as last_updated,',
'       ''Restricted''             as file_access,',
'       ''warning''                as file_access_state',
'  from sys.dual',
'union all',
'select ''fa-file-excel-o''        as file_icon,',
'       ''Review notes''           as file_title,',
'       ''review-notes.xlsx''      as file_name,',
'       ''860 KB''                 as file_size,',
'       sysdate - 7              as last_updated,',
'       ''Shared''                 as file_access,',
'       ''info''                   as file_access_state',
'  from sys.dual',
'union all',
'select ''fa-file-word-o''         as file_icon,',
'       ''Requirements summary''   as file_title,',
'       ''requirements-summary.docx'' as file_name,',
'       ''1.1 MB''                 as file_size,',
'       sysdate - 9              as last_updated,',
'       ''Shared''                 as file_access,',
'       ''info''                   as file_access_state',
'  from sys.dual',
'union all',
'select ''fa-file-pdf-o''          as file_icon,',
'       ''Decision log''           as file_title,',
'       ''decision-log.pdf''       as file_name,',
'       ''640 KB''                 as file_size,',
'       sysdate - 14             as last_updated,',
'       ''Private''                as file_access,',
'       ''danger''                 as file_access_state',
'  from sys.dual',
'union all',
'select ''fa-file-text-o''         as file_icon,',
'       ''Source data extract''    as file_title,',
'       ''source-data-extract.csv'' as file_name,',
'       ''4.8 MB''                 as file_size,',
'       sysdate - 21             as last_updated,',
'       ''Restricted''             as file_access,',
'       ''warning''                as file_access_state',
'  from sys.dual',
'union all',
'select ''fa-file-powerpoint-o''   as file_icon,',
'       ''Previous plan''          as file_title,',
'       ''previous-plan.pptx''     as file_name,',
'       ''6.2 MB''                 as file_size,',
'       sysdate - 60             as last_updated,',
'       ''Private''                as file_access,',
'       ''danger''                 as file_access_state',
'  from sys.dual;',
''))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&FILE_ICON. fa-lg',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignCenter',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--md',
  'BADGE_LABEL', 'Status',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_STATE', 'FILE_ACCESS_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'FILE_ACCESS',
  'DESCRIPTION', '&FILE_NAME. (&FILE_SIZE.)',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'MISC', '&LAST_UPDATED.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'STYLE', 't-ContentRow--styleCompact',
  'TITLE', '&FILE_TITLE.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893132814868541264)
,p_name=>'FILE_ACCESS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FILE_ACCESS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893132877345541265)
,p_name=>'FILE_ACCESS_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FILE_ACCESS_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893132308755541259)
,p_name=>'FILE_ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FILE_ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893132475790541261)
,p_name=>'FILE_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FILE_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893132567640541262)
,p_name=>'FILE_SIZE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FILE_SIZE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893132426191541260)
,p_name=>'FILE_TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FILE_TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893132664895541263)
,p_name=>'LAST_UPDATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED'
,p_data_type=>'DATE'
,p_display_sequence=>50
,p_format_mask=>'SINCE'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(24893132983669541266)
,p_region_id=>wwv_flow_imp.id(24893131605547541252)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(24893133116300541267)
,p_region_id=>wwv_flow_imp.id(24893131605547541252)
,p_position_id=>363792341120765662
,p_display_sequence=>20
,p_template_id=>363792942797796791
,p_label=>'Edit File'
,p_static_id=>'edit-file'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-edit'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24893203053465167050)
,p_plug_name=>'Flex Container'
,p_static_id=>'flex-container'
,p_parent_plug_id=>wwv_flow_imp.id(24893200919076167028)
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_plug_template=>1571470918551430249
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24893130558868541242)
,p_plug_name=>'Item Detail Tabs'
,p_static_id=>'item-detail-tabs'
,p_region_css_classes=>'app-ItemDetailTabs'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24899187835106915829)
,p_plug_name=>unistr('Item Details \2013\00A0Full')
,p_static_id=>'item-header'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon:margin-right-lg'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Establishes the identity and current state of the item before users inspect details or take action.',
'',
'Pattern role: Item detail header with contextual information.',
'',
'AI guidance: Keep the most important identity, ownership, status, impact, and timing information near the item title. Use contextual information for quick scanning rather than a full attribute report. Map status values to supported semantic states su'
||'ch as success, warning, danger, or info. Keep badge value, state, label, and styling semantically aligned. Use relative time only when it is useful for recency; use an explicit date when the exact date matters.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24896929204792964354)
,p_plug_name=>'Summary'
,p_static_id=>'item-summary-details'
,p_region_css_classes=>'margin-md'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'This record represents a standard item that is being reviewed, tracked, or acted on. The summary explains the current state, expected outcome, and any context needed before taking action.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Gives users concise narrative context about what the item represents and why it matters.',
'',
'Pattern role: Item summary narrative.',
'',
'AI guidance: Keep the summary short, generic, and decision-relevant. Explain the item''s current purpose, state, or expected outcome without adding instructional or tutorial text. Move detailed attributes, history, and related records into their dedic'
||'ated regions.'))
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(24899187884716915830)
,p_name=>'Item Properties 1'
,p_static_id=>'key-facts'
,p_parent_plug_id=>wwv_flow_imp.id(24899187835106915829)
,p_template=>3372714138756020509
,p_display_sequence=>30
,p_region_css_classes=>'app-ContextualInfo'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo--hideNulls:t-ContextualInfo-label--stacked:t-Report--hideNoPagination'
,p_display_point=>'SMART_FILTERS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Record Owner'' as owner,',
'       ''Standard Category'' as category,',
'       ''On Track'' as status,',
'       ''success'' as status_state,',
'       sysdate - 1/24 as last_updated,',
'       ''High'' as impact,',
'       ''danger'' as impact_state,',
'       sysdate + 14 as target_date',
'  from dual;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2117249020861433971
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Presents the highest-value item facts for quick assessment before users take action.',
'',
'Pattern role: Contextual information summary.',
'',
'AI guidance: Keep this region limited to ownership, classification, status, impact, recency, and timing information that users need for quick decisions. Keep visible values and their semantic state columns aligned. Use supported state values such as '
||unistr('success, warning, danger, or info. Expose target timing when it materially affects the user\2019s decision; otherwise remove the unused supporting column.')))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893159900022853266)
,p_query_column_id=>2
,p_column_alias=>'CATEGORY'
,p_column_display_sequence=>30
,p_column_heading=>'Category'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893159043348853266)
,p_query_column_id=>6
,p_column_alias=>'IMPACT'
,p_column_display_sequence=>80
,p_column_heading=>'Impact'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{with/}',
'  LABEL:=Impact',
'  VALUE:=#IMPACT#',
'  STATE:=#IMPACT_STATE#',
'  LABEL_DISPLAY:=N',
'  STYLE:=t-Badge--subtle',
'  SIZE:=t-Badge--sm',
'{apply THEME$BADGE/}'))
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893159429147853266)
,p_query_column_id=>7
,p_column_alias=>'IMPACT_STATE'
,p_column_display_sequence=>90
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893160237934853266)
,p_query_column_id=>5
,p_column_alias=>'LAST_UPDATED'
,p_column_display_sequence=>50
,p_column_heading=>'Last Updated'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893160660934853266)
,p_query_column_id=>1
,p_column_alias=>'OWNER'
,p_column_display_sequence=>20
,p_column_heading=>'Owner'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893161045407853267)
,p_query_column_id=>3
,p_column_alias=>'STATUS'
,p_column_display_sequence=>10
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{with/}',
'  LABEL:=Status',
'  VALUE:=#STATUS#',
'  STATE:=#STATUS_STATE#',
'  LABEL_DISPLAY:=Y',
'  STYLE:=t-Badge--subtle margin-top-xs',
'  SHAPE:=t-Badge--circle',
'  SIZE:=t-Badge--md',
'{apply THEME$BADGE/}'))
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893158660253853265)
,p_query_column_id=>4
,p_column_alias=>'STATUS_STATE'
,p_column_display_sequence=>70
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(24893161506980853267)
,p_query_column_id=>8
,p_column_alias=>'TARGET_DATE'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24921886323147764875)
,p_plug_name=>'Key Metrics'
,p_static_id=>'metric-cards'
,p_region_css_classes=>'app-MetricCards'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-line-chart''    icon,',
'    ''Primary KPI''      label,',
'    84200              metric_value',
'from sys.dual',
'union all',
'select',
'    ''fa-bar-chart''     icon,',
'    ''Secondary KPI''    label,',
'    12800              metric_value',
'from sys.dual',
'union all',
'select',
'    ''fa-area-chart''    icon,',
'    ''Trend KPI''        label,',
'    64                 metric_value',
'from sys.dual',
'union all',
'select',
'    ''fa-dashboard''     icon,',
'    ''Status KPI''       label,',
'    348                metric_value',
'from sys.dual'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$METRIC_CARD'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AVATAR_ALIGNMENT', 't-MetricCard-body--avatarAlignmentStart',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_POSITION', 't-MetricCard-body--avatarPositionInline',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_STYLE', 't-MetricCard-avatar--subtle',
  'AVATAR_TYPE', 'icon',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'ITEM_CSS_CLASSES', 'margin-none',
  'LAYOUT', 'stacked',
  'META', '&LABEL.',
  'METRIC', '&METRIC_VALUE.',
  'METRIC_CSS_CLASSES', 'u-text-subheading-md')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Highlights a small number of measures that help users assess the current item quickly.',
'',
'Pattern role: Item-level KPI summary.',
'',
'AI guidance: Use only the most relevant measures for this item, generally two to four cards. Keep metrics comparable in importance and avoid turning the region into a dense report. Format large values with thousands separators and use consistent unit'
||'s. If badges or icons are added, keep their value, state, and icon semantically aligned.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24921886390976764876)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24921886565308764878)
,p_name=>'LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LABEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24921886707201764879)
,p_name=>'METRIC_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'METRIC_VALUE'
,p_data_type=>'NUMBER'
,p_display_sequence=>40
,p_format_mask=>'999G999G999G999G999G999G990'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24893130820567541244)
,p_plug_name=>'People'
,p_static_id=>'people'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'People list guidance for AI:',
'',
'1. Use the person''s name as the primary identifying value.',
'2. Derive initials from PERSON_NAME with APEX_STRING.GET_INITIALS when a photo is unavailable.',
'3. Derive AVATAR_COLOR_CLASS from PERSON_NAME with ORA_HASH so the same person keeps the same color.',
'4. Keep the person''s role and department as separate attributes; do not concatenate them.',
'5. Use availability as the badge meaning because it communicates whether the person can engage with the item.',
'6. Map each availability label to one consistent semantic state.',
'7. Use LAST_UPDATED as a real date value and apply presentation formatting in the component mapping.',
'*/',
'',
'-- Query for people associated with an item.',
'with people as (',
'    select ''Jordan Lee''          as person_name,',
'           ''Owner''               as person_role,',
'           ''Product Operations''  as person_department,',
'           ''Available''           as person_status,',
'           ''success''             as person_status_state,',
'           sysdate               as last_updated',
'      from sys.dual',
'    union all',
'    select ''Morgan Patel''        as person_name,',
'           ''Contributor''         as person_role,',
'           ''Engineering''         as person_department,',
'           ''Busy''                as person_status,',
'           ''warning''             as person_status_state,',
'           sysdate - 1           as last_updated',
'      from sys.dual',
'    union all',
'    select ''Casey Nguyen''        as person_name,',
'           ''Reviewer''            as person_role,',
'           ''Quality Assurance''   as person_department,',
'           ''Available''           as person_status,',
'           ''success''             as person_status_state,',
'           sysdate - 3           as last_updated',
'      from sys.dual',
'    union all',
'    select ''Avery Ross''          as person_name,',
'           ''Editor''              as person_role,',
'           ''Design''              as person_department,',
'           ''Busy''                as person_status,',
'           ''warning''             as person_status_state,',
'           sysdate - 5           as last_updated',
'      from sys.dual',
'    union all',
'    select ''Taylor Singh''        as person_name,',
'           ''Viewer''              as person_role,',
'           ''Planning''            as person_department,',
'           ''Away''                as person_status,',
'           ''info''                as person_status_state,',
'           sysdate - 7           as last_updated',
'      from sys.dual',
'    union all',
'    select ''Riley Brooks''        as person_name,',
'           ''Approver''            as person_role,',
'           ''Finance''             as person_department,',
'           ''Offline''             as person_status,',
'           ''danger''              as person_status_state,',
'           sysdate - 14          as last_updated',
'      from sys.dual',
'    union all',
'    select ''Kai Morgan''          as person_name,',
'           ''Coordinator''         as person_role,',
'           ''Operations''          as person_department,',
'           ''Available''           as person_status,',
'           ''success''             as person_status_state,',
'           sysdate - 21          as last_updated',
'      from sys.dual',
')',
'select apex_string.get_initials(person_name) as person_initials,',
'       person_name,',
'       person_role,',
'       person_department,',
'       person_status,',
'       person_status_state,',
'       last_updated,',
'       ''u-color-'' || to_char(ora_hash(person_name, 10)) as avatar_color_class',
'  from people;',
''))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_CSS_CLASSES', '&AVATAR_COLOR_CLASS.',
  'AVATAR_INITIALS', 'PERSON_INITIALS',
  'AVATAR_SHAPE', 't-Avatar--circle',
  'AVATAR_SIZE', 't-Avatar--xs',
  'AVATAR_TYPE', 'initials',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignCenter',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--md',
  'BADGE_LABEL', 'Status',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_STATE', 'PERSON_STATUS_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'PERSON_STATUS',
  'DESCRIPTION', '&PERSON_DEPARTMENT. &middot; &PERSON_ROLE.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'MISC', '&LAST_UPDATED.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'STYLE', 't-ContentRow--styleCompact',
  'TITLE', '&PERSON_NAME.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893202834150167048)
,p_name=>'AVATAR_COLOR_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AVATAR_COLOR_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893133375754541270)
,p_name=>'LAST_UPDATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED'
,p_data_type=>'DATE'
,p_display_sequence=>80
,p_format_mask=>'SINCE'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893131481529541251)
,p_name=>'PERSON_DEPARTMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PERSON_DEPARTMENT'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893130918565541245)
,p_name=>'PERSON_INITIALS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PERSON_INITIALS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893131006120541246)
,p_name=>'PERSON_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PERSON_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893131065435541247)
,p_name=>'PERSON_ROLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PERSON_ROLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893131314452541249)
,p_name=>'PERSON_STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PERSON_STATUS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24893131339947541250)
,p_name=>'PERSON_STATUS_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PERSON_STATUS_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(24893133180262541268)
,p_region_id=>wwv_flow_imp.id(24893130820567541244)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(24893133274842541269)
,p_region_id=>wwv_flow_imp.id(24893130820567541244)
,p_position_id=>363792341120765662
,p_display_sequence=>20
,p_template_id=>363792942797796791
,p_label=>'Edit Person'
,p_static_id=>'edit'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-edit'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24921948230852874467)
,p_plug_name=>'Related Information'
,p_static_id=>'related-information'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''fa-users''                     as icon,',
'       ''People''                      as title,',
'       ''Associated people and owners'' as description,',
'       4                             as item_count,',
'       ''PEOPLE''                      as page_alias',
'  from sys.dual',
'union all',
'select ''fa-file-o''                   as icon,',
'       ''Files''                       as title,',
'       ''Documents and attachments''   as description,',
'       12                            as item_count,',
'       ''FILES''                       as page_alias',
'  from sys.dual',
'union all',
'select ''fa-comments-o''               as icon,',
'       ''Comments''                    as title,',
'       ''Discussion and feedback''     as description,',
'       18                            as item_count,',
'       ''COMMENTS''                    as page_alias',
'  from sys.dual',
'union all',
'select ''fa-sitemap''                  as icon,',
'       ''Child Records''               as title,',
'       ''Associated child records''    as description,',
'       6                             as item_count,',
'       ''CHILD_RECORDS''               as page_alias',
'  from sys.dual',
'union all',
'select ''fa-link''                     as icon,',
'       ''Related Records''             as title,',
'       ''Connected business entities'' as description,',
'       3                             as item_count,',
'       ''RELATED_RECORDS''             as page_alias',
'  from sys.dual;'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignCenter',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', 'Related Item Count',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_POS', 't-ContentRow-badge--posEnd',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'ITEM_COUNT',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'Y',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'STYLE', 't-ContentRow--styleCompact',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides compact entry points to related information without overwhelming the item summary.',
'',
'Pattern role: Related-content navigation list.',
'',
'AI guidance: Keep rows concise and use the description to clarify what the related area contains. Use the badge to show the number of related items when that count is meaningful. Row titles should navigate to the corresponding related area or item-le'
||'vel detail. Keep this region focused on navigation and summary; use a full report or dedicated page for extensive related data.',
'',
'Implementation note: Each row represents a navigation entry to a related-information area. Replace the placeholder action target with the destination represented by PAGE_ALIAS, passing the current item context and selected related-information categor'
||'y.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24921948941716874474)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24921949050867874475)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897110146529372454)
,p_name=>'ITEM_COUNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITEM_COUNT'
,p_data_type=>'NUMBER'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24897110046913372453)
,p_name=>'PAGE_ALIAS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PAGE_ALIAS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24921948791937874473)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(24903738606190151216)
,p_region_id=>wwv_flow_imp.id(24921948230852874467)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24893203493351167054)
,p_plug_name=>'Actions'
,p_static_id=>'side-actions'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-LinksList--showArrow:t-LinksList--nowrap:t-LinksList--actions:t-LinksList--showTopIcons'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(24893270990150842205)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>4073837480889169704
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24896992468884422146)
,p_plug_name=>'Overview'
,p_static_id=>'summary-container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides the primary scan-first container for the item detail summary.',
'',
'Pattern role: Item detail overview.',
'',
'AI guidance: Keep this region visually dominant and place the most decision-relevant summary content here. Use a concise narrative summary alongside logically grouped attribute pairs. Preserve the overview-first structure and avoid turning this regio'
||'n into a dense report or long-form documentation area.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24893155516103853262)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(24899187835106915829)
,p_button_name=>'ACTIONS_MENU'
,p_static_id=>'actions-menu'
,p_show_as_disabled=>false
,p_button_type=>'MENU'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Actions Menu'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ellipsis-v'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Groups optional or lower-frequency actions so they remain available without competing with the primary action hierarchy.',
'',
'Pattern role: Overflow actions.',
'',
'AI guidance: Place destructive, administrative, export, duplicate, or infrequently used actions here when they do not need persistent prominence. Do not hide the primary task in the overflow menu. Use clear action labels and preserve a logical menu o'
||'rder.'))
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24924165745209379807)
,p_button_id=>wwv_flow_imp.id(24893155516103853262)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 1'
,p_static_id=>'menu-action-a'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24924165820600379808)
,p_button_id=>wwv_flow_imp.id(24893155516103853262)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 2'
,p_static_id=>'menu-action-b'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24924165932771379809)
,p_button_id=>wwv_flow_imp.id(24893155516103853262)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 3'
,p_static_id=>'menu-action-c'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24893203187154167051)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(24893203053465167050)
,p_button_name=>'ADD_COMMENT'
,p_static_id=>'add-comment'
,p_show_as_disabled=>false
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Add Comment'
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-up'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24893157031526853263)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(24899187835106915829)
,p_button_name=>'BACK'
,p_static_id=>'back'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Back'
,p_button_position=>'UP'
,p_icon_css_classes=>'fa-chevron-left'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Returns users to the previous browse, search, or parent context.',
'',
'Pattern role: Detail-page exit action.',
'',
unistr('AI guidance: Keep Back visually separate from the forward actions. Preserve the user\2019s prior context when returning to the originating page.')))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24893157493651853263)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24899187835106915829)
,p_button_name=>'PRIMARY_ACTION'
,p_static_id=>'primary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Primary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Represents the most important next step available from the item detail page.',
'',
'Pattern role: Primary page action.',
'',
'AI guidance: Keep this action prominent and use a clear, domain-specific verb when adapting the pattern. There should normally be one primary action. The action should be directly related to the item''s current state and intended workflow.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24893157857618853263)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(24899187835106915829)
,p_button_name=>'SECONDARY_ACTION'
,p_static_id=>'secondary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Secondary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides a useful follow-up action that is less important than the primary action.',
'',
'Pattern role: Secondary page action.',
'',
'AI guidance: Keep this action visually subordinate to the primary action. Use it for a common but non-primary path, and avoid presenting several actions with equal visual emphasis.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24893202647404167046)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(24893131605547541252)
,p_button_name=>'UPLOAD_FILE'
,p_static_id=>'upload-file'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Upload File'
,p_button_position=>'CHANGE'
,p_icon_css_classes=>'fa-upload'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24893154618603853257)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24897072591518550356)
,p_button_name=>'VIEW_ALL_ACTIVITY'
,p_static_id=>'view-details-link-3'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight:t-Button--padTop'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'View All Activity'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-right'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides a contextual path from the activity summary to the complete activity history.',
'',
'Pattern role: Region-level detail action.',
'',
'AI guidance: Use this action when the summary is intentionally truncated or when users may need to inspect the full history. Keep it visually attached to the Recent Activity region and lower in emphasis than the page''s primary action. Omit it when th'
||'e region already contains the complete activity history.',
'',
'Implementation note: This action should navigate to the complete activity history for the current item. Replace the placeholder target URL when the activity-history destination is available.'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24893203022742167049)
,p_name=>'P320_COMMENT_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(24893203053465167050)
,p_prompt=>'Comment Text'
,p_placeholder=>'Add a comment...'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>2
,p_field_template=>2042262243893469891
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'N',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp.component_end;
end;
/
