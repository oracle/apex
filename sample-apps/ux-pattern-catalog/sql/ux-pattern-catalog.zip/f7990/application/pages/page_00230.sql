prompt --application/pages/page_00230
begin
--   Manifest
--     PAGE: 00230
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>230
,p_name=>unistr('Browse \2013 Interactive Report')
,p_alias=>'BROWSE-INTERACTIVE-REPORT'
,p_step_title=>unistr('Browse \2013 Interactive Report')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrate this page pattern as a reusable, production-quality Oracle APEX experience.',
'',
'## When to Use',
'',
'Use when this page''s primary user task matches the pattern represented by its title and structure.',
'',
'## When to Avoid',
'',
'Avoid when another catalog pattern better supports the user''s task, information density, or workflow complexity.',
'',
'## AI Guidance',
'',
'Preserve the page''s pattern-first structure, generic terminology, accessible labels, semantic formatting, and clear action hierarchy. Keep documentation in metadata rather than visible instructional text.',
'            '))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9369043865010210)
,p_plug_name=>'Interactive Report'
,p_static_id=>'interactive-report'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Sample data for browse-oriented UX patterns.',
'',
'The values in this query are intentionally generic and synthetic.',
'Replace the query with application-specific data while preserving',
'the same overall shape:',
'',
'- Primary label',
'- Secondary description',
'- Category facet',
'- Priority facet',
'- Date facet',
'- Boolean flag facets',
'- Icon',
'- Badge',
'',
'This allows the same content row, cards, and faceted search patterns',
'to be reused across different application domains.',
'*/',
'select * from (',
'    select',
'        level as id,',
'        ''Item '' || level as title,',
'        case mod(level - 1, 4)',
'            when 0 then ''Summary for item '' || level',
'            when 1 then ''Description for item '' || level',
'            when 2 then ''Supporting text for item '' || level',
'            else ''Additional note for item '' || level',
'        end as description,',
'        case mod(level - 1, 5)',
'            when 0 then ''Category A''',
'            when 1 then ''Category B''',
'            when 2 then ''Category C''',
'            when 3 then ''Category D''',
'            else ''Category E''',
'        end as category,',
'        trunc(sysdate) - mod(level, 30) as updated_on,',
'        case mod(level - 1, 6)',
'            when 0 then ''fa-columns''',
'            when 1 then ''fa-search''',
'            when 2 then ''fa-table''',
'            when 3 then ''fa-id-card-o''',
'            when 4 then ''fa-edit''',
'            else ''fa-clone''',
'        end as icon,',
'        case mod(level - 1, 3)',
'            when 0 then ''High''',
'            when 1 then ''Medium''',
'            else ''Low''',
'        end as priority,',
'        case mod(level - 1, 3)',
'            when 0 then ''danger''',
'            when 1 then ''warning''',
'            else ''success''',
'        end as badge_state,',
'        case when mod(level, 2) = 0 then ''Y'' else ''N'' end as flag_1,',
'        case when mod(level, 3) = 0 then ''Y'' else ''N'' end as flag_2,',
'        case when mod(level, 4) = 0 then ''Y'' else ''N'' end as flag_3,',
'        case when mod(level, 5) = 0 then ''Y'' else ''N'' end as flag_4,',
'        ''Category '' || chr(64 + mod(level - 1, 5) + 1) as overline,',
'        ''Updated '' || to_char(trunc(sysdate) - mod(level, 30), ''Mon DD'') as meta',
'    from dual',
'    connect by level <= 48',
'    order by level',
')'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Presents a structured record set that users can filter, sort, group, and compare through Interactive Report controls.',
'Pattern role: Flexible tabular browse and analysis surface.',
'AI guidance: Keep columns purposeful and labels readable. Use interactive capabilities to support the task rather than expose every available field. Preserve a clear path to record detail and keep the default saved report focused on the most useful c'
||'omparison fields.'))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(9369223880010212)
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_internal_uid=>5620159979477157
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9370020648010220)
,p_db_column_name=>'BADGE_STATE'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Badge State'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9369655366010216)
,p_db_column_name=>'CATEGORY'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Category'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'TMPL_THEME_42$BADGE'
,p_heading_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'LABEL', 'Category',
  'LABEL_DISPLAY', 'N',
  'SHAPE', 't-Badge--rounded',
  'STYLE', 't-Badge--subtle',
  'VALUE', 'CATEGORY')).to_clob
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9369474082010215)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9370128289010221)
,p_db_column_name=>'FLAG_1'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Flag 1'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if FLAG_1/}',
'  <span aria-hidden="true" class="fa fa-check-circle u-success-text" title="Yes"></span>',
'{else /}',
'  <span aria-hidden="true" class="fa fa-circle-o u-opacity-50" title="No"></span>',
'{endif /}'))
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9370178873010222)
,p_db_column_name=>'FLAG_2'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Flag 2'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if FLAG_2/}',
'  <span aria-hidden="true" class="fa fa-check-circle u-success-text" title="Yes"></span>',
'{else /}',
'  <span aria-hidden="true" class="fa fa-circle-o u-opacity-50" title="No"></span>',
'{endif /}'))
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9370357452010223)
,p_db_column_name=>'FLAG_3'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Flag 3'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if FLAG_3/}',
'  <span aria-hidden="true" class="fa fa-check-circle u-success-text" title="Yes"></span>',
'{else /}',
'  <span aria-hidden="true" class="fa fa-circle-o u-opacity-50" title="No"></span>',
'{endif /}'))
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9370394459010224)
,p_db_column_name=>'FLAG_4'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Flag 4'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if FLAG_4/}',
'  <span aria-hidden="true" class="fa fa-check-circle u-success-text" title="Yes"></span>',
'{else /}',
'  <span aria-hidden="true" class="fa fa-circle-o u-opacity-50" title="No"></span>',
'{endif /}'))
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9369812778010218)
,p_db_column_name=>'ICON'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Icon'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'TMPL_THEME_42$AVATAR'
,p_column_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'ICON', '&ICON. fa-lg',
  'SHAPE', 't-Avatar--noShape',
  'TYPE', 'ICON')).to_clob
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9369284380010213)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Actions'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'TMPL_THEME_42$ACTIONS'
,p_column_alignment=>'CENTER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'ACTIONS_WRAP', 'N')).to_clob
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(9370669519010227)
,p_ir_column_id=>wwv_flow_imp.id(9369284380010213)
,p_position_id=>4847451154346391
,p_display_sequence=>10
,p_template_id=>4848158907352517
,p_label=>'Primary Row Action'
,p_static_id=>'primary-row-action_1'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-edit'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(9370892154010229)
,p_ir_column_id=>wwv_flow_imp.id(9369284380010213)
,p_position_id=>4847451154346391
,p_display_sequence=>20
,p_template_id=>4849195998354815
,p_label=>'Row Actions Menu'
,p_static_id=>'row-actions-menu'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v-o'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(9371001826010230)
,p_component_action_id=>wwv_flow_imp.id(9370892154010229)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Row Action 1'
,p_static_id=>'row-action-1'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(9371077780010231)
,p_component_action_id=>wwv_flow_imp.id(9370892154010229)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Row Action 2'
,p_static_id=>'row-action-2'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(9371242857010232)
,p_component_action_id=>wwv_flow_imp.id(9370892154010229)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Row Action 3'
,p_static_id=>'row-action-3'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9370602498010226)
,p_db_column_name=>'META'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Meta'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9370531494010225)
,p_db_column_name=>'OVERLINE'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Overline'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9369887205010219)
,p_db_column_name=>'PRIORITY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Priority'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'TMPL_THEME_42$BADGE'
,p_heading_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'LABEL', 'Priority',
  'LABEL_DISPLAY', 'N',
  'SHAPE', 't-Badge--circle',
  'SIZE', 't-Badge--md',
  'STATE', 'BADGE_STATE',
  'STYLE', 't-Badge--subtle',
  'VALUE', 'PRIORITY')).to_clob
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9369450828010214)
,p_db_column_name=>'TITLE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Title'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'TMPL_THEME_42$CONTENT_ROW'
,p_heading_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AVATAR_ICON', '#ICON# fa-lg',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '#DESCRIPTION#',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'ITEM_CSS_CLASSES', 'u-padding-none',
  'TITLE', '&TITLE.')).to_clob
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(9443346833596115)
,p_ir_column_id=>wwv_flow_imp.id(9369450828010214)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9369716848010217)
,p_db_column_name=>'UPDATED_ON'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Updated On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(9388163672131111)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'primary'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TITLE:CATEGORY:PRIORITY:FLAG_1:FLAG_2:FLAG_3:FLAG_4:UPDATED_ON:ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11546386724505092)
,p_plug_name=>'Interactive Report'
,p_static_id=>'interactive-report-2'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Interactive Report'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides context and an optional action area for the interactive report.',
'Pattern role: Report context and optional action container.',
'AI guidance: Keep the description concise and production-like. Use this area for secondary or infrequent report actions when needed; do not imply that a drawer, editor, or other specific interaction is required by the pattern.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7165558996066623)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(11546386724505092)
,p_button_name=>'ACTIONS_MENU'
,p_static_id=>'actions-menu'
,p_show_as_disabled=>false
,p_button_type=>'MENU'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Actions Menu'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ellipsis-v'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(11600034448938750)
,p_button_id=>wwv_flow_imp.id(7165558996066623)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Menu Action 1'
,p_static_id=>'menu-action-1'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(11657083278498601)
,p_button_id=>wwv_flow_imp.id(7165558996066623)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Menu Action 2'
,p_static_id=>'menu-action-2'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(11657170512498602)
,p_button_id=>wwv_flow_imp.id(7165558996066623)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Menu Action 3'
,p_static_id=>'menu-action-3'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7167064646066624)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(11546386724505092)
,p_button_name=>'PRIMARY_ACTION'
,p_static_id=>'primary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Primary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7167499478066624)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(11546386724505092)
,p_button_name=>'SECONDARY_ACTION'
,p_static_id=>'secondary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Secondary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp.component_end;
end;
/
