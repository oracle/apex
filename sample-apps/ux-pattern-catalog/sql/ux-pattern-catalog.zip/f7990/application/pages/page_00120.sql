prompt --application/pages/page_00120
begin
--   Manifest
--     PAGE: 00120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>120
,p_name=>unistr('Dashboard \2013\00A0Advanced')
,p_alias=>'DASHBOARD-ADVANCED'
,p_step_title=>unistr('Dashboard \2013\00A0Advanced')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Scope metric-card layout adjustments to Metric Card regions. */',
'.app-MetricCards .t-MetricCard { flex-wrap: wrap; }',
'.app-MetricCards .t-MetricCard-badge { margin-left: auto; }'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates an advanced dashboard pattern for comparing multiple measures, trends, categories, and supporting records from a single overview page.',
'',
'## When to Use',
'',
'Use when users need more than a quick status snapshot: multiple related metrics, deeper visual comparison, trend analysis, and clear drill-down paths into supporting information.',
'',
'## When to Avoid',
'',
'Avoid when users only need a compact operational summary, when a focused report would answer the task more directly, or when dense analysis would make the page harder to scan.',
'',
'## AI Guidance',
'',
'Preserve the dashboard''s comparison-first structure. Keep the page scannable, generic, and production-like. Use advanced visualizations only when they clarify a specific comparison task, and keep component comments focused on design intent rather tha'
||'n implementation trivia.'))
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24916432678416380123)
,p_plug_name=>'Line with Area Chart'
,p_static_id=>'chart-1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>100
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Highlights directional movement across ordered categories or periods.',
'Pattern role: Trend comparison visual.',
'AI guidance: Use when the shape of change supports a broader dashboard comparison. Keep the chart readable and avoid adding competing series without a clear reason.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(24896282884894825818)
,p_region_id=>wwv_flow_imp.id(24916432678416380123)
,p_chart_type=>'lineWithArea'
,p_height=>'220'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ) {',
'',
'    options.styleDefaults = $.extend( true, {}, options.styleDefaults, {',
'        areaOpacity: 0.15',
'    });',
'',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(24896284507396825818)
,p_chart_id=>wwv_flow_imp.id(24896282884894825818)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Series A'' label, 12 value from sys.dual',
'union all',
'select ''Series B'' label, 26 value from sys.dual',
'union all',
'select ''Series C'' label, 18 value from sys.dual',
'union all',
'select ''Series D'' label, 34 value from sys.dual',
'union all',
'select ''Series E'' label, 29 value from sys.dual',
'union all',
'select ''Series F'' label, 51 value from sys.dual',
'union all',
'select ''Series G'' label, 46 value from sys.dual',
'union all',
'select ''Series H'' label, 74 value from sys.dual',
'order by 1'))
,p_max_row_count=>20
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'lineWithArea'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_line_style=>'solid'
,p_line_width=>2
,p_line_type=>'curved'
,p_marker_rendered=>'off'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896283338816825818)
,p_chart_id=>wwv_flow_imp.id(24896282884894825818)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896283933347825818)
,p_chart_id=>wwv_flow_imp.id(24896282884894825818)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24916435342502380127)
,p_plug_name=>'Bar Chart'
,p_static_id=>'chart-2'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>130
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Compares category magnitudes in a format that is easy to scan.',
'Pattern role: Ranked category comparison.',
'AI guidance: Keep category labels short and the row count limited. Use this chart when relative size matters more than precise point-in-time trend.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(24896286056497825819)
,p_region_id=>wwv_flow_imp.id(24916435342502380127)
,p_chart_type=>'bar'
,p_height=>'220'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(24896287757776825820)
,p_chart_id=>wwv_flow_imp.id(24896286056497825819)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Series A'' label, 12 value from sys.dual',
'union all',
'select ''Series B'' label, 26 value from sys.dual',
'union all',
'select ''Series C'' label, 18 value from sys.dual',
'union all',
'select ''Series D'' label, 34 value from sys.dual',
'union all',
'select ''Series E'' label, 29 value from sys.dual',
'union all',
'select ''Series F'' label, 51 value from sys.dual',
'union all',
'select ''Series G'' label, 46 value from sys.dual',
'union all',
'select ''Series H'' label, 74 value from sys.dual',
'order by 1'))
,p_max_row_count=>20
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896286519885825820)
,p_chart_id=>wwv_flow_imp.id(24896286056497825819)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896287180287825820)
,p_chart_id=>wwv_flow_imp.id(24896286056497825819)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24916401051637267492)
,p_plug_name=>'Pyramid Chart'
,p_static_id=>'chart-3'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>120
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Shows a staged or proportional breakdown across a small set of categories.',
'Pattern role: Composition summary.',
'AI guidance: Use only when the categories form a meaningful hierarchy or funnel-like comparison. Avoid using this chart for unrelated categories.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(24896289227006825820)
,p_region_id=>wwv_flow_imp.id(24916401051637267492)
,p_chart_type=>'pyramid'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(24896289747613825821)
,p_chart_id=>wwv_flow_imp.id(24896289227006825820)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Series A'' label, 30 value from sys.dual',
'union all',
'select ''Series B'' label, 20 value from sys.dual',
'union all',
'select ''Series C'' label, 34 value from sys.dual',
'union all',
'select ''Series D'' label, 6  value from sys.dual',
'order by 1 desc'))
,p_max_row_count=>20
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'pyramid'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24916401547470267497)
,p_plug_name=>'Bubble Chart'
,p_static_id=>'chart-4'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with src as (',
'    select',
'        level rn,',
'        mod(ora_hash(''x_inc_'' || level), 15) - 7 as x_noise,',
'        mod(ora_hash(''y_inc_'' || level), 19) - 9 as y_noise,',
'        mod(ora_hash(''s_inc_'' || level), 11) - 5 as s_noise',
'    from dual',
'    connect by level <= 12',
'),',
'walk as (',
'    select',
'        rn,',
'        sum(4 + x_noise) over (order by rn) as x_walk,',
'        sum(case when mod(rn, 5) = 0 then 1 else 3 end + y_noise) over (order by rn) as y_walk,',
'        sum(25 + (s_noise * 3)) over (order by rn) as s_walk',
'    from src',
')',
'select',
'    case when mod(rn, 2) = 1 then ''Group A'' else ''Group B'' end as series,',
'    case when mod(rn, 2) = 1 then ''A'' else ''B'' end || ceil(rn / 2) as label,',
'    round(15 + x_walk + case when mod(rn, 4) = 0 then -4 when mod(rn, 4) = 3 then 3 else 0 end, 0) as x_value,',
'    round(20 + y_walk + round(8 * sin(rn / 2)) + case when mod(rn, 6) = 0 then -10 when mod(rn, 6) = 4 then 6 else 0 end, 0) as y_value,',
'    round(60 + s_walk + case when mod(rn, 3) = 0 then 20 else 0 end, 0) as size_value',
'from walk',
'order by rn;'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Compares items across two measures while using marker size for a third measure.',
'Pattern role: Multidimensional comparison.',
'AI guidance: Use when users need to spot clusters, outliers, or tradeoffs. Keep labels concise and explain size semantics through source data or surrounding metadata, not visible instructional text.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(24896291200693825821)
,p_region_id=>wwv_flow_imp.id(24916401547470267497)
,p_chart_type=>'bubble'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_overview_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(24896292950095825822)
,p_chart_id=>wwv_flow_imp.id(24896291200693825821)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series 1'
,p_location=>'REGION_SOURCE'
,p_series_type=>'bubble'
,p_series_name_column_name=>'SERIES'
,p_items_x_column_name=>'X_VALUE'
,p_items_y_column_name=>'Y_VALUE'
,p_items_z_column_name=>'SIZE_VALUE'
,p_items_label_column_name=>'LABEL'
,p_line_style=>'dotted'
,p_line_width=>2
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_items_label_rendered=>true
,p_items_label_position=>'aboveMarker'
,p_items_label_display_as=>'PERCENT'
,p_items_label_font_size=>'10'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896291731375825821)
,p_chart_id=>wwv_flow_imp.id(24896291200693825821)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'X Axis Label'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896292341018825822)
,p_chart_id=>wwv_flow_imp.id(24896291200693825821)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Y Axis Label'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24898569974562355337)
,p_plug_name=>'Radar Chart'
,p_static_id=>'chart-4_1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from (',
'    select 1 seq, ''Current'' series, ''Coverage''       label, 42 value from sys.dual',
'    union all',
'    select 2 seq, ''Current'' series, ''Usability''      label, 78 value from sys.dual',
'    union all',
'    select 3 seq, ''Current'' series, ''Performance''    label, 31 value from sys.dual',
'    union all',
'    select 4 seq, ''Current'' series, ''Reliability''    label, 84 value from sys.dual',
'    union all',
'    select 5 seq, ''Current'' series, ''Supportability'' label, 56 value from sys.dual',
'    union all',
'    select 6 seq, ''Current'' series, ''Security''       label, 68 value from sys.dual',
'',
'    union all',
'',
'    select 1 seq, ''Target'' series, ''Coverage''        label, 88 value from sys.dual',
'    union all',
'    select 2 seq, ''Target'' series, ''Usability''       label, 54 value from sys.dual',
'    union all',
'    select 3 seq, ''Target'' series, ''Performance''     label, 92 value from sys.dual',
'    union all',
'    select 4 seq, ''Target'' series, ''Reliability''     label, 61 value from sys.dual',
'    union all',
'    select 5 seq, ''Target'' series, ''Supportability''  label, 79 value from sys.dual',
'    union all',
'    select 6 seq, ''Target'' series, ''Security''        label, 47 value from sys.dual',
')',
'order by seq desc, series'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Compares current and target values across several dimensions.',
'Pattern role: Multi-attribute gap comparison.',
'AI guidance: Use for balanced scorecard-style comparisons where the shape of strengths and gaps matters. Keep the number of dimensions small enough to read.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(24896294428475825822)
,p_region_id=>wwv_flow_imp.id(24898569974562355337)
,p_chart_type=>'radar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_overview_rendered=>'off'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ) {',
'',
'    options.styleDefaults = $.extend( true, {}, options.styleDefaults, {',
'        colors: [',
'            ''rgba(66, 81, 191, 0.5)'',',
'            ''rgba(95, 185, 181, 0.5)''',
'        ]',
'    });',
'',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(24896296153952825823)
,p_chart_id=>wwv_flow_imp.id(24896294428475825822)
,p_static_id=>'series-1_1'
,p_seq=>10
,p_name=>'Series 1'
,p_location=>'REGION_SOURCE'
,p_series_type=>'area'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896294981164825823)
,p_chart_id=>wwv_flow_imp.id(24896294428475825822)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'X Axis Label'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896295518633825823)
,p_chart_id=>wwv_flow_imp.id(24896294428475825822)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Y Axis Label'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24916402481481267506)
,p_plug_name=>'Status List'
,p_static_id=>'content-row'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from (',
'    select',
'        level as seq,',
'        case mod(level - 1, 5)',
'            when 0 then ''Task''',
'            when 1 then ''Document''',
'            when 2 then ''Approval''',
'            when 3 then ''Dataset''',
'            else ''Configuration''',
'        end as overline,',
'        ''Dashboard Item '' || level as title,',
'        ''Representative workflow item '' || level as description,',
'        case mod(level - 1, 5)',
'            when 0 then ''fa-clipboard-list''',
'            when 1 then ''fa-file-text-o''',
'            when 2 then ''fa-user-check''',
'            when 3 then ''fa-database''',
'            else ''fa-cogs''',
'        end as icon,',
'        case mod(level - 1, 5)',
'            when 0 then ''Complete''',
'            when 1 then ''In Progress''',
'            when 2 then ''Needs Review''',
'            when 3 then ''Available''',
'            else ''Updated''',
'        end as badge,',
'        case mod(level - 1, 5)',
'            when 0 then ''success''',
'            when 1 then ''warning''',
'            when 2 then ''danger''',
'            when 3 then ''info''',
'            else ''success''',
'        end as badge_state,',
'        null as badge_icon',
'    from dual',
'    connect by level <= 7',
')'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON. fa-lg',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignCenter',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', 'Badge',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_POS', 't-ContentRow-badge--posEnd',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'BADGE',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'OVERLINE', '&OVERLINE.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Shows a prioritized set of operational or workflow items that support the dashboard summary.',
'Pattern role: Supporting status list.',
'AI guidance: Keep rows concise and scannable. Use badges only when status needs to be visible at a glance, and keep badge value, state, and icon semantically aligned.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916403378208267515)
,p_name=>'BADGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916403594361267517)
,p_name=>'BADGE_ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916403504919267516)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916403192345267513)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916403301496267514)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916403007027267511)
,p_name=>'OVERLINE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OVERLINE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24898568987954355327)
,p_name=>'SEQ'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEQ'
,p_data_type=>'NUMBER'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916403042566267512)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24916524185891911370)
,p_plug_name=>'Section Summary'
,p_static_id=>'content-row-2'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from (',
'    select',
'        level as seq,',
'        ''Section '' || level as title,',
'        case mod(level - 1, 5)',
'            when 0 then ''Trend overview''',
'            when 1 then ''Data snapshot''',
'            when 2 then ''Team summary''',
'            when 3 then ''Review status''',
'            else ''System settings''',
'        end as description,',
'        case mod(level - 1, 5)',
'            when 0 then ''fa-line-chart''',
'            when 1 then ''fa-database''',
'            when 2 then ''fa-users''',
'            when 3 then ''fa-shield''',
'            else ''fa-cogs''',
'        end as icon,',
'        case mod(level - 1, 5)',
'            when 0 then ''12 metrics''',
'            when 1 then ''Updated 10m ago''',
'            when 2 then ''4 groups''',
'            when 3 then ''2 reviews''',
'            else ''5 settings''',
'        end as meta,',
'        null as badge,',
'        null as badge_state,',
'        null as badge_icon',
'    from dual',
'    connect by level <= 4',
')'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_SIZE', 't-Avatar--xs',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'MISC', '&META.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'STYLE', 't-ContentRow--styleCompact',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Orients users to related sections represented by the advanced dashboard.',
'Pattern role: Supporting section summary.',
'AI guidance: Use this region for lightweight navigation or context across dashboard areas. Keep descriptions brief and avoid duplicating the status list.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916524725780911375)
,p_name=>'BADGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916524850877911377)
,p_name=>'BADGE_ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916524740156911376)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916524514985911373)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916524581162911374)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916525243778911381)
,p_name=>'META'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'META'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24898569080004355328)
,p_name=>'SEQ'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEQ'
,p_data_type=>'NUMBER'
,p_display_sequence=>90
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916524412111911372)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24916400168768267483)
,p_plug_name=>'Advanced Dashboard'
,p_static_id=>'dashboard-title'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'One line dashboard description.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Frames the advanced dashboard and provides the page-level action area.',
'Pattern role: Dashboard heading and action container.',
'AI guidance: Keep the description short and production-like. Do not use this region for visible pattern documentation.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24916399317848267474)
,p_plug_name=>'Metric Cards'
,p_static_id=>'metric-cards'
,p_region_css_classes=>'app-MetricCards'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-line-chart''    icon,',
'    ''Primary KPI''      label,',
'    84200              metric_value,',
'    ''Trend''            badge,',
'    ''+12%''             badge_value,',
'    ''success''          badge_state,',
'    ''fa-trend-up''      badge_icon',
'from sys.dual',
'union all',
'select',
'    ''fa-bar-chart''     icon,',
'    ''Secondary KPI''    label,',
'    12800              metric_value,',
'    ''Trend''            badge,',
'    ''+320 units''       badge_value,',
'    ''success''          badge_state,',
'    ''fa-trend-up''      badge_icon',
'from sys.dual',
'union all',
'select',
'    ''fa-area-chart''    icon,',
'    ''Trend KPI''        label,',
'    64                 metric_value,',
'    ''Trend''            badge,',
'    ''20m faster''       badge_value,',
'    ''success''          badge_state,',
'    ''fa-trend-up''      badge_icon',
'from sys.dual',
'union all',
'select',
'    ''fa-dashboard''     icon,',
'    ''Status KPI''       label,',
'    348                metric_value,',
'    ''Trend''            badge,',
'    ''-14 items''        badge_value,',
'    ''danger''           badge_state,',
'    ''fa-trend-down''    badge_icon',
'from sys.dual'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'BADGE_VALUE'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$METRIC_CARD'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AVATAR_ALIGNMENT', 't-MetricCard-body--avatarAlignmentStart',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_POSITION', 't-MetricCard-body--avatarPositionInline',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_STYLE', 't-MetricCard-avatar--subtle',
  'AVATAR_TYPE', 'icon',
  'BADGE_ICON', '&BADGE_ICON.',
  'BADGE_LABEL', 'Trend',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_SHAPE', 't-Badge--rounded',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'BADGE_VALUE',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'LAYOUT', '4cols',
  'META', '&LABEL.',
  'METRIC', '&METRIC_VALUE.',
  'METRIC_CSS_CLASSES', 'u-text-subheading-md')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Presents the highest-priority dashboard measures for immediate scanning before deeper analysis.',
'Pattern role: Primary KPI summary.',
'AI guidance: Keep metrics comparable in importance. Badge value, badge state, and badge icon should be semantically aligned. Format key values for quick scanning and avoid turning this region into a dense report.',
'Implementation note: The app-MetricCards CSS class scopes page-level CSS to this region.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916399727860267479)
,p_name=>'BADGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916400032475267482)
,p_name=>'BADGE_ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916399929286267481)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916399855476267480)
,p_name=>'BADGE_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_VALUE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916399385677267475)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916399560009267477)
,p_name=>'LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LABEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24916399701902267478)
,p_name=>'METRIC_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'METRIC_VALUE'
,p_data_type=>'NUMBER'
,p_display_sequence=>40
,p_format_mask=>'999G999G999G999G999G999G990'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24898569209605355329)
,p_plug_name=>'Metric Cards Stacked'
,p_static_id=>'metric-cards_1'
,p_region_css_classes=>'app-MetricCards'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>110
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-pyramid-chart''     icon,',
'    ''Adoption''         label,',
'    78                 metric_value,',
'    ''Growth''           badge,',
'    ''+8.4%''            badge_value,',
'    ''success''          badge_state,',
'    ''fa-arrow-up''      badge_icon',
'from sys.dual',
'union all',
'select',
'    ''fa-random''        icon,',
'    ''Throughput''       label,',
'    1.42               metric_value,',
'    ''Change''           badge,',
'    ''+96 items''        badge_value,',
'    ''success''          badge_state,',
'    ''fa-arrow-up''      badge_icon',
'from sys.dual',
'union all',
'select',
'    ''fa-traffic-light-stop'' icon,',
'    ''Latency''          label,',
'    32                 metric_value,',
'    ''Risk''             badge,',
'    ''14m slower''       badge_value,',
'    ''danger''           badge_state,',
'    ''fa-arrow-down''    badge_icon',
'from sys.dual',
'union all',
'select',
'    ''fa-tasks-alt''          icon,',
'    ''Open Issues''      label,',
'    6                  metric_value,',
'    ''Watch''            badge,',
'    ''2 delayed''    badge_value,',
'    ''danger''           badge_state,',
'    ''fa-exclamation-circle'' badge_icon',
'from sys.dual'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'BADGE_VALUE'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$METRIC_CARD'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AVATAR_ALIGNMENT', 't-MetricCard-body--avatarAlignmentStart',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_POSITION', 't-MetricCard-body--avatarPositionInline',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_STYLE', 't-MetricCard-avatar--subtle',
  'AVATAR_TYPE', 'icon',
  'BADGE_ICON', '&BADGE_ICON.',
  'BADGE_LABEL', 'Trend',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_SHAPE', 't-Badge--rounded',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'BADGE_VALUE',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'LAYOUT', 'stacked',
  'META', '&LABEL.',
  'METRIC', '&METRIC_VALUE.',
  'METRIC_CSS_CLASSES', 'u-text-subheading-md')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides a compact secondary KPI set alongside detailed dashboard visuals.',
'Pattern role: Secondary KPI summary.',
'AI guidance: Use stacked metric cards when space is constrained or when the metrics support a nearby visualization. Keep badge semantics aligned with the represented measure.',
'Implementation note: The app-MetricCards CSS class scopes page-level CSS to this region.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24898569665949355333)
,p_name=>'BADGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24898569946407355336)
,p_name=>'BADGE_ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24898569775675355335)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24898569729013355334)
,p_name=>'BADGE_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_VALUE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24898569357339355330)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24898569426705355331)
,p_name=>'LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LABEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24898569489867355332)
,p_name=>'METRIC_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'METRIC_VALUE'
,p_data_type=>'NUMBER'
,p_display_sequence=>30
,p_format_mask=>'999G999G999G999G999G999G990'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24898570523544355342)
,p_plug_name=>'Stock Chart'
,p_static_id=>'stock-chart'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from (',
'    select',
'        trunc(sysdate) - (24 - level) as trade_date,',
'        round(100 + (level * 0.8) + (sin(level / 2.3) * 6), 2) as open_value,',
'        round(103 + (level * 0.75) + (sin(level / 2.0) * 7), 2) as close_value,',
'        round(',
'            greatest(',
'                100 + (level * 0.8) + (sin(level / 2.3) * 6),',
'                103 + (level * 0.75) + (sin(level / 2.0) * 7)',
'            ) + 1 + mod(level, 4),',
'            2',
'        ) as high_value,',
'        round(',
'            least(',
'                100 + (level * 0.8) + (sin(level / 2.3) * 6),',
'                103 + (level * 0.75) + (sin(level / 2.0) * 7)',
'            ) - 1 - mod(level, 3),',
'            2',
'        ) as low_value,',
'        12000 + (level * 240) + round(abs(sin(level / 1.4)) * 3800) as volume_value',
'    from dual',
'    connect by level <= 24',
')',
'order by trade_date'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_required_patch=>wwv_flow_imp.id(24910758457553178721)
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Preserves a specialized financial-style comparison option for advanced dashboard variants.',
'Pattern role: Optional specialized chart.',
'AI guidance: Use only when open, high, low, close, and volume values are part of the user task. Treat this as an optional specialized dashboard variation, not a default chart for general-purpose dashboards.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(24896315334175825831)
,p_region_id=>wwv_flow_imp.id(24898570523544355342)
,p_chart_type=>'stock'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_stock_render_as=>'candlestick'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ) {',
'',
'    options.styleDefaults = $.extend( true, {}, options.styleDefaults, {',
'        colors: [',
'            ''rgba(66, 81, 191, 0.5)'',',
'            ''rgba(95, 185, 181, 0.5)''',
'        ]',
'    });',
'',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(24896316994160825832)
,p_chart_id=>wwv_flow_imp.id(24896315334175825831)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series 1'
,p_location=>'REGION_SOURCE'
,p_series_type=>'stock'
,p_items_low_column_name=>'LOW_VALUE'
,p_items_high_column_name=>'HIGH_VALUE'
,p_items_open_column_name=>'OPEN_VALUE'
,p_items_close_column_name=>'CLOSE_VALUE'
,p_items_volume_column_name=>'VOLUME_VALUE'
,p_items_label_column_name=>'TRADE_DATE'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896315841650825831)
,p_chart_id=>wwv_flow_imp.id(24896315334175825831)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'X Axis Label'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896316447182825832)
,p_chart_id=>wwv_flow_imp.id(24896315334175825831)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Y Axis Label'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24916525371172911382)
,p_plug_name=>'Time Series'
,p_static_id=>'time-series'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Shows how related measures change over a recent period.',
'Pattern role: Comparative time-series trend.',
'AI guidance: Use for time-based comparison where direction, volatility, and relative movement matter. Keep the series count low and labels readable.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(24896318146360825832)
,p_region_id=>wwv_flow_imp.id(24916525371172911382)
,p_chart_type=>'lineWithArea'
,p_height=>'180'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'live'
,p_initial_zooming=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_overview_rendered=>'off'
,p_time_axis_type=>'enabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(24896319832747825833)
,p_chart_id=>wwv_flow_imp.id(24896318146360825832)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trunc(sysdate) - 23 + (level - 1) as label,',
'       round(',
'           65',
'           + (level * 0.7)',
'           + (sin(level / 0.9) * 22)',
'           + (cos(level / 1.7) * 15)',
'           + case',
'               when level between 3 and 4 then 28',
'               when level between 6 and 8 then -24',
'               when level between 10 and 11 then 34',
'               when level between 13 and 15 then -30',
'               when level between 17 and 19 then 26',
'               when level between 21 and 22 then -22',
'               when level = 24 then 18',
'               else 0',
'             end,',
'           1',
'       ) as value',
'from sys.dual',
'connect by level <= 48',
'order by label'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'lineWithArea'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#3f8efc'
,p_line_style=>'solid'
,p_line_width=>2
,p_line_type=>'curved'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(24896320434489825833)
,p_chart_id=>wwv_flow_imp.id(24896318146360825832)
,p_static_id=>'series-2'
,p_seq=>20
,p_name=>'Series 2'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trunc(sysdate) - 23 + (level - 1) as label,',
'       round(',
'           65',
'           + (level * 0.7)',
'           + (sin(level / 0.9) * 22)',
'           + (cos(level / 1.7) * 15)',
'           + (sin(level * 2.8) * 7)    -- pseudo-random noise',
'           + (cos(level * 3.9) * 4)    -- more noise',
'           + case',
'               when level between 3 and 4 then 18',
'               when level between 6 and 8 then -14',
'               when level between 10 and 11 then 24',
'               when level between 13 and 15 then -18',
'               when level between 17 and 19 then 16',
'               when level between 21 and 22 then -12',
'               when level = 24 then 10',
'               else 0',
'             end,',
'           1',
'       ) as value',
'from sys.dual',
'connect by level <= 48',
'order by label;'))
,p_series_type=>'lineWithArea'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_line_style=>'dashed'
,p_line_width=>2
,p_line_type=>'curved'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896318634738825832)
,p_chart_id=>wwv_flow_imp.id(24896318146360825832)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_type=>'date-short'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'inside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(24896319195830825832)
,p_chart_id=>wwv_flow_imp.id(24896318146360825832)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896305979178825827)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(24916400168768267483)
,p_button_name=>'ACTIONS_MENU'
,p_static_id=>'actions-menu'
,p_show_as_disabled=>false
,p_button_type=>'MENU'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Actions Menu'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ellipsis-v'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Groups lower-frequency or optional page actions.',
'Pattern role: Overflow actions.',
'AI guidance: Use for actions that should remain available without competing with primary and secondary actions.'))
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24916443478981267517)
,p_button_id=>wwv_flow_imp.id(24896305979178825827)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 1'
,p_static_id=>'menu-action-a'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24916443554372267518)
,p_button_id=>wwv_flow_imp.id(24896305979178825827)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 2'
,p_static_id=>'menu-action-b'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24916443666543267519)
,p_button_id=>wwv_flow_imp.id(24896305979178825827)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 3'
,p_static_id=>'menu-action-c'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896307501577825828)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24916400168768267483)
,p_button_name=>'PRIMARY_ACTION'
,p_static_id=>'primary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Primary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Represents the main follow-up action from the advanced dashboard overview.',
'Pattern role: Primary page action.',
'AI guidance: Keep prominent. Use a domain-specific label only when adapting this pattern to a real application.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896307930556825828)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(24916400168768267483)
,p_button_name=>'SECONDARY_ACTION'
,p_static_id=>'secondary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Secondary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Represents a useful but lower-priority follow-up action.',
'Pattern role: Secondary page action.',
'AI guidance: Keep visually subordinate to the primary action.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896285282278825819)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(24916432678416380123)
,p_button_name=>'VIEW_DETAILS_LINK'
,p_static_id=>'view-details'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'View Details Link'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-right'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides a direct path from the summary chart to supporting detail.',
'Pattern role: Region-level detail action.',
'AI guidance: Keep detail actions attached to the region header so they support analysis without competing with page-level actions.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896296795349825823)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24898569974562355337)
,p_button_name=>'VIEW_DETAILS_LINK_3'
,p_static_id=>'view-details-link-3'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'View Details Link'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-right'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides a direct path from the comparison chart to supporting detail.',
'Pattern role: Region-level detail action.',
'AI guidance: Use text-link detail actions when the drill-down is a common analytical follow-up.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896288483565825820)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(24916435342502380127)
,p_button_name=>'VIEW_DETAILS_POPUP'
,p_static_id=>'view-details-popup'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'View Details'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides lower-emphasis access to supporting detail for this dashboard region.',
'Pattern role: Region-level detail action.',
'AI guidance: Use icon detail actions when drill-down should be available but visually subordinate to the region content.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896300934442825825)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(24916402481481267506)
,p_button_name=>'VIEW_DETAILS_POPUP_3'
,p_static_id=>'view-details-popup-3'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'View Details'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides lower-emphasis access to supporting status detail.',
'Pattern role: Region-level detail action.',
'AI guidance: Keep repeated detail actions consistent unless a region requires different behavior.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896305072799825827)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(24916524185891911370)
,p_button_name=>'VIEW_DETAILS_POPUP_4'
,p_static_id=>'view-details-popup-4'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'View Details'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides lower-emphasis access to supporting section detail.',
'Pattern role: Region-level detail action.',
'AI guidance: Keep repeated detail actions consistent unless a region requires different behavior.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896293657401825822)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24916401547470267497)
,p_button_name=>'VIEW_DETAILS_POPUP_1'
,p_static_id=>'view-details-popup_1'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'View Details'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides lower-emphasis access to supporting detail for this dashboard region.',
'Pattern role: Region-level detail action.',
'AI guidance: Use icon detail actions when drill-down should be available but visually subordinate to the region content.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896290406822825821)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24916401051637267492)
,p_button_name=>'VIEW_DETAILS_POPUP_2'
,p_static_id=>'view-details-popup_2'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'View Details'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides lower-emphasis access to supporting detail for this dashboard region.',
'Pattern role: Region-level detail action.',
'AI guidance: Use icon detail actions when drill-down should be available but visually subordinate to the region content.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24896321092192825833)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(24916525371172911382)
,p_button_name=>'VIEW_DETAILS_LINK_2'
,p_static_id=>'view-details_2'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'View Details Link'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-right'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides a direct path from the time-series chart to supporting detail.',
'Pattern role: Region-level detail action.',
'AI guidance: Use text-link detail actions when the drill-down is a common analytical follow-up.'))
);
wwv_flow_imp.component_end;
end;
/
