prompt --application/pages/page_00250
begin
--   Manifest
--     PAGE: 00250
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>250
,p_name=>'AI Chat'
,p_alias=>'AI-CHAT'
,p_step_title=>'AI Chat'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'body:has(#ai_assistant) {',
'    overflow: hidden;',
'}',
'',
'.t-Body-mainContent:has(#ai_assistant) {',
'    max-block-size: calc(100dvh - 135px);',
'}',
'',
'.t-Body-contentInner:has(#ai_assistant),',
'.t-Body-contentInner:has(#ai_assistant) > .container,',
'.t-Body-contentInner:has(#ai_assistant) > .container > .row,',
'#ai_assistant {',
'    block-size: 100%;',
'}',
'',
'.t-Body-contentInner:has(#ai_assistant) {',
'    padding: 0;',
'}',
'',
'.a-ChatTranscript {',
'    max-block-size: calc(100dvh - 192px);',
'}',
'',
'/* Styling for the AI chat intro section */',
'#ai_assistant .ai-chat-intro {',
'    inline-size: min(100%, 60rem);',
'    margin-inline: auto;',
'    padding: 1rem 1.5rem;',
'    text-align: center;',
'}'))
,p_step_template=>4073832297226169690
,p_page_css_classes=>'ai-chat-page'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Provides a dedicated inline AI chat page that opens the APEX AI Assistant in a full-height conversation area with a short introductory message.',
'',
'## When to Use',
'',
'Use when a conversational interface is the primary task and the assistant should answer questions without leaving the current application experience.',
'',
'## Implementation Guidance',
'',
'Configure the assistant system prompt, welcome message, authorization, and available AI providers for the application''s approved use case. Keep the prompt explicit about permitted data and actions, provide a useful empty-state introduction, and test '
||'the layout at desktop and mobile heights.'))
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6055439027169713)
,p_plug_name=>'AI Assistant'
,p_static_id=>'ai-assistant'
,p_region_name=>'ai_assistant'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_grid_column_css_classes=>'u-flex u-flex-direction-column'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Supplies the inline container into which the APEX AI Assistant renders its transcript and composer.',
'Pattern role: Full-page AI chat host.',
'Implementation guidance: Keep the static ID and region name synchronized with the Open AI Assistant action. The page CSS relies on this container to size the conversation area to the viewport.'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6055298848169711)
,p_name=>'Initialize AI Assistant'
,p_static_id=>'initialize-ai-assistant'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_da_event_comment=>'Initializes the inline AI Assistant after the page DOM is ready, ensuring that the designated chat container exists before the assistant is opened.'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6055399266169712)
,p_event_id=>wwv_flow_imp.id(6055298848169711)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_static_id=>'native-open-ai-assistant'
,p_action=>'NATIVE_OPEN_AI_ASSISTANT'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function ( options ) {',
'    options.useChatContext = function () {',
'        const root = document.querySelector( "#ai_assistant" );',
'',
'        if ( !root ) {',
'            return;',
'        }',
'',
'        const transcript = root.querySelector( ".a-ChatTranscript" );',
'',
'        if ( !transcript || transcript.querySelector( ".ai-chat-intro" ) ) {',
'            return;',
'        }',
'',
'        transcript.insertAdjacentHTML(',
'            "afterbegin",',
'            `',
'            <section class="ai-chat-intro" aria-label="About this assistant">',
'                <h2>AI Assistant</h2>',
'                <p>',
'                    Enter a question or request below to begin a conversation.',
'                </p>',
'            </section>',
'            `',
'        );',
'    };',
'',
'    return options;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'container_selector', '#ai_assistant',
  'display_as', 'INLINE')).to_clob
,p_ai_system_prompt=>unistr('You are a basic AI assistant. Answer the user\2019s questions using only the information available to you. Do not perform actions, modify data, run code, or make changes. If you do not know the answer, say so clearly. Keep your responses concise and fact')
||'ual.'
,p_ai_welcome_message=>'Welcome! How can I help you today?'
,p_da_action_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Opens the APEX AI Assistant inline in the AI Assistant region and adds a concise accessible introduction to the transcript.',
'Pattern role: AI chat initialization.',
'Implementation guidance: The system prompt constrains the assistant to factual answers and no actions. Adapt it to the approved data scope and safety requirements; preserve the selector checks so the introduction is inserted once only.'))
);
wwv_flow_imp.component_end;
end;
/
