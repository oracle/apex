prompt --application/pages/page_01110
begin
--   Manifest
--     PAGE: 01110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1110
,p_name=>'Cards'
,p_alias=>'CARDS'
,p_step_title=>'Cards'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.ux-about-text {',
'    padding: 1rem;',
'    border-bottom: 1px solid var(--ut-component-border-color);',
'    background: var(--ut-component-toolbar-background-color);',
'}',
'',
'.app-PatternGuidance > p:first-child {',
'    font-weight: 600;',
'}',
'',
'.app-PatternGuidance h4 {',
'    text-transform: uppercase;',
'    font-size: 0.75rem;',
'    color: var(--ut-component-text-muted-color);',
'    margin-bottom: 0.25rem;',
'}',
'',
'.a-CardView-items--row .has-media {',
'    grid-template-columns: minmax(32px,128px) minmax(0,var(--a-cv-icon-spacer,44px)) 1fr minmax(0,auto);',
'}',
'',
'/* Position the Media Cards favorite button over the image */',
'/* Make each card the positioning context */',
'.product-listings .a-CardView-item {',
'    position: relative;',
'}',
'',
'/* Remove the action row from normal document flow */',
'.product-listings .a-CardView-actions {',
'    display: contents !important;',
'    pointer-events: none;',
'}',
'',
'/* Position the button */',
'.product-listings .a-CardView-actions .product-favorite-button,',
'.product-listings .a-CardView-actions .a-CardView-button.product-favorite-button {',
'    position: absolute;',
'    top: 0.75rem;',
'    right: 0.75rem;',
'    z-index: 10;',
'',
'    display: inline-flex;',
'    align-items: center;',
'    justify-content: center;',
'',
'    width: 2.5rem;',
'    height: 2.5rem;',
'    min-width: 2.5rem;',
'    padding: 0;',
'',
'    border: 1px solid rgb(255 255 255 / 0.9);',
'    border-radius: 50%;',
'    background: rgb(255 255 255 / 0.95);',
'    color: #102a43;',
'    box-shadow: 0 0.2rem 0.5rem rgb(15 23 42 / 0.2);',
'',
'    font-size: 1.15rem;',
'    line-height: 1;',
'    pointer-events: auto;',
'',
'    transition:',
'        background-color 160ms ease,',
'        color 160ms ease,',
'        transform 160ms ease,',
'        box-shadow 160ms ease;',
'}'))
,p_step_template=>2528119710305719084
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'The Cards pattern page demonstrates reusable card-based patterns for presenting related information as distinct, visually grouped items. Examples show how cards can support navigation, people, item details, approvals and actions, product catalogs, me'
||'dia-rich content, and files or documents.',
'',
'## When to Use',
'',
'Use cards when users need to scan, compare, select, or act on a collection of items that benefit from a clear identity, supporting context, optional media, status, links, or actions.',
'',
'## When to Avoid',
'',
'Avoid cards when information is better represented as a compact list, comparison table, data-entry form, or unstructured text. Do not use cards merely to decorate simple navigation or dense result sets, and do not overload each card with excessive at'
||'tributes, badges, images, or competing actions.',
'',
'## AI Guidance',
'',
'Use the examples on this page as references for adapting Cards regions to different interaction roles. Choose the card layout, hierarchy, media, icon, badge, link target, and actions according to the use case. Preserve a clear emphasis on the item id'
||'entity and its primary purpose; include only the supporting information needed to scan, compare, navigate, or act confidently. Keep cards structurally consistent within a region, use one primary interaction per card, and ensure that buttons or links '
||'represent meaningful next steps.'))
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25438385002703580153)
,p_plug_name=>'About'
,p_static_id=>'about'
,p_parent_plug_id=>wwv_flow_imp.id(25438385634180580160)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Helps users move between related areas by presenting each destination with enough context to understand where it leads.</p>',
'',
'<h4>Best For</h4>',
'<p>Small sets of peer destinations where a label alone may not be enough, such as related record areas, settings categories, or application sections.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25438386520718580169)
,p_plug_name=>'About'
,p_static_id=>'about_1'
,p_parent_plug_id=>wwv_flow_imp.id(25438385874261580162)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Presents identifiable records with key context, helping users quickly scan, compare, and open the right item.</p>',
'',
'<h4>Best For</h4>',
'<p>Small to medium collections of business records, such as requests, plans, contracts, or related items, where a compact summary is more useful than a table row alone.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25438386741196580171)
,p_plug_name=>'About'
,p_static_id=>'about_1_1'
,p_parent_plug_id=>wwv_flow_imp.id(25438386674062580170)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Presents items that require a decision or next step with enough context to act confidently, using clear buttons or links for the available actions.</p>',
'',
'<h4>Best For</h4>',
'<p>Small to medium queues of approvals, requests, tasks, or other work items where users need to review information and take a direct action.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25276328665342965)
,p_plug_name=>'About'
,p_static_id=>'about_1_1_1'
,p_parent_plug_id=>wwv_flow_imp.id(25276396851342966)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>110
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Helps users browse visually identifiable items by combining imagery with concise descriptions, key attributes, status, and optional actions.</p>',
'',
'<h4>Best For</h4>',
'<p>Product catalogs and media-rich lists where images help users recognize content, view high-level details, and take actions on items.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25277067679342973)
,p_plug_name=>'About'
,p_static_id=>'about_1_1_1_1_1_1'
,p_parent_plug_id=>wwv_flow_imp.id(25276673186342969)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>240
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Makes files and documents easy to recognize, evaluate, and act on by combining a visual preview with file type, ownership, version, status, and update information.</p>',
'',
'<h4>Best For</h4>',
'<p>Document libraries, project workspaces, attachment areas, template galleries, and knowledge bases where users need more context than a filename alone provides and commonly perform actions such as viewing or downloading.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25276176395342964)
,p_plug_name=>'About'
,p_static_id=>'about_1_2'
,p_parent_plug_id=>wwv_flow_imp.id(25276127811342963)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Displays a list of people with an avatar or initials, lightweight role context, and current presence or account state.</p>',
'',
'<h4>Best For</h4>',
'<p>Small to medium user lists where names, roles, presence, and recent activity help users quickly understand who is involved or available.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92549378385797995187)
,p_plug_name=>'Pattern: Files and Documents'
,p_static_id=>'action-list'
,p_parent_plug_id=>wwv_flow_imp.id(25276673186342969)
,p_region_template_options=>'t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc:t-CardsRegion--styleA'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>220
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'File and Document Cards Pattern Guidance',
'----------------------------------------',
'Use this region to present documents, files, templates, or knowledge',
'resources with enough context for users to recognize and evaluate them.',
'',
'Design intent:',
'- Use the document name as the primary label.',
'- Use the subtitle for the file type or document category.',
'- Use the body for a concise description of the document''s purpose.',
'- Use the secondary body for owner, version, size, and recency.',
'- Use one badge for the document''s most important state.',
'- Use a file preview image as the card media.',
'- Use a file-type icon to reinforce the document format.',
'- Link the title to a document preview or document details page.',
'- Use Card Actions for common operations such as View and Download.',
'- Keep image URLs, action labels, and action targets in separate columns.',
'- Use Advanced Formatting to combine secondary attributes with',
'  separators such as &middot;.',
'*/',
'select',
'    201 as document_id,',
'    ''Project Charter'' as document_name,',
'    ''project-charter.pdf'' as document_filename,',
'    ''Defines the project purpose, scope, stakeholders, milestones, and success criteria.'' as document_summary,',
'    ''Project Management Office'' as document_owner,',
'    ''v1.0'' as document_version,',
'    ''2.4 MB'' as document_size,',
'    apex_util.get_since( sysdate - 8 ) as last_updated,',
'    ''#APP_FILES#documents/project-charter-preview.jpg'' as document_preview_url,',
'    ''Preview of the Project Charter document'' as document_preview_description,',
'    ''fa fa-file-pdf-o'' as document_icon_class,',
'    ''u-color-36'' document_icon_color,',
'    ''PDF document'' as document_icon_description,',
'    ''Approved'' as status_label,',
'    ''u-success'' as status_css_class',
'from sys.dual',
'',
'union all',
'',
'select',
'    202 as document_id,',
'    ''Research Findings'' as document_name,',
'    ''research_findings.ppt'' as document_filename,',
'    ''Summarizes user research findings, key observations, and recommended design opportunities.'' as document_summary,',
'    ''Maya Chen'' as document_owner,',
'    ''v0.9'' as document_version,',
'    ''8.7 MB'' as document_size,',
'    apex_util.get_since( sysdate - 5 ) as last_updated,',
'    ''#APP_FILES#documents/research-findings-preview.jpg'' as document_preview_url,',
'    ''Preview of the Research Findings presentation'' as document_preview_description,',
'    ''fa fa-file-powerpoint-o'' as document_icon_class,',
'    ''u-color-22'' document_icon_color,',
'    ''Presentation document'' as document_icon_description,',
'    ''Draft'' as status_label,',
'    ''u-warning'' as status_css_class',
'from sys.dual',
'',
'union all',
'',
'select',
'    203 as document_id,',
'    ''Launch Plan'' as document_name,',
'    ''launch_plan.doc'' as document_filename,',
'    ''Lists launch activities, owners, dependencies, dates, and readiness checkpoints.'' as document_summary,',
'    ''Jordan Lee'' as document_owner,',
'    ''v2.1'' as document_version,',
'    ''1.1 MB'' as document_size,',
'    apex_util.get_since( sysdate - 3 ) as last_updated,',
'    ''#APP_FILES#documents/launch-plan-preview.jpg'' as document_preview_url,',
'    ''Preview of the Project Launch Plan document'' as document_preview_description,',
'    ''fa fa-file-word-o'' as document_icon_class,',
'    ''u-color-41'' document_icon_color,',
'    ''Word document'' as document_icon_description,',
'    ''In Review'' as status_label,',
'    ''u-info'' as status_css_class',
'from sys.dual',
'',
'union all',
'',
'select',
'    204 as document_id,',
'    ''Budget Forecast'' as document_name,',
'    ''budget_forecast.xls'' as document_filename,',
'    ''Provides projected costs, approved funding, and the expected variance for the project.'' as document_summary,',
'    ''Priya Patel'' as document_owner,',
'    ''v3.0'' as document_version,',
'    ''640 KB'' as document_size,',
'    apex_util.get_since( sysdate - 1 ) as last_updated,',
'    ''#APP_FILES#documents/budget-forecast-preview.jpg'' as document_preview_url,',
'    ''Preview of the Budget Forecast spreadsheet'' as document_preview_description,',
'    ''fa fa-file-excel-o'' as document_icon_class,',
'    ''u-color-27'' document_icon_color,',
'    ''Spreadsheet document'' as document_icon_description,',
'    ''Approved'' as status_label,',
'    ''u-success'' as status_css_class',
'from sys.dual',
'',
'union all',
'',
'select',
'    205 as document_id,',
'    ''Release Readiness Checklist'' as document_name,',
'    ''release-checklist'' as document_filename,',
'    ''Tracks required validation, sign-offs, communications, and deployment preparation.'' as document_summary,',
'    ''Daniel Kim'' as document_owner,',
'    ''v1.3'' as document_version,',
'    ''320 KB'' as document_size,',
'    apex_util.get_since( sysdate - 12 ) as last_updated,',
'    ''#APP_FILES#documents/release-readiness-checklist-preview.jpg'' as document_preview_url,',
'    ''Preview of the Release Readiness Checklist'' as document_preview_description,',
'    ''fa fa-check-square-o'' as document_icon_class,',
'    ''u-color-39'' document_icon_color,',
'    ''Checklist document'' as document_icon_description,',
'    ''Needs Attention'' as status_label,',
'    ''u-danger'' as status_css_class',
'from sys.dual;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates Cards for presenting files, documents, templates, and knowledge resources with enough context for users to recognize, evaluate, and act on them. Each card combines a visual preview, file-type icon, ownership, version, status, and update '
||'information.',
'',
'## When to Use',
'',
'Use for document libraries, project workspaces, attachment areas, template galleries, and knowledge bases where users need more context than a filename alone provides and commonly perform actions such as viewing or downloading.',
'',
'## When to Avoid',
'',
'Avoid when the collection is very large, when users need to compare detailed document metadata, or when a simple filename list is sufficient. Use a report, interactive grid, search result list, or file-management view instead.',
'',
'## AI Guidance',
'',
'Use the document name as the title and link it to a document preview or detail page. Use the subtitle for file type, filename, or size; use the body for a concise summary; and use the secondary body for owner, version, and recency. Use a file preview'
||' as media when it aids recognition and a file-type icon to reinforce format. Use one badge for the document''s most important state. Add actions such as View and Download only when they are common, meaningful operations.'))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(4698032551126731)
,p_region_id=>wwv_flow_imp.id(92549378385797995187)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'DOCUMENT_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'&DOCUMENT_FILENAME. (&DOCUMENT_SIZE.)'
,p_body_adv_formatting=>false
,p_body_column_name=>'DOCUMENT_SUMMARY'
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'Updated &LAST_UPDATED. by &DOCUMENT_OWNER.'
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'DOCUMENT_ICON_CLASS'
,p_icon_css_classes=>'&DOCUMENT_ICON_COLOR.'
,p_icon_position=>'START'
,p_icon_description=>'&DOCUMENT_ICON_DESCRIPTION.'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'DOCUMENT_PREVIEW_URL'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'COVER'
,p_media_description=>'&DOCUMENT_PREVIEW_DESCRIPTION.'
,p_pk1_column_name=>'DOCUMENT_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4698154686126732)
,p_card_id=>wwv_flow_imp.id(4698032551126731)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'View'
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_button_display_type=>'TEXT'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4698247105126733)
,p_card_id=>wwv_flow_imp.id(4698032551126731)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'Download'
,p_static_id=>'action_1'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-download'
,p_is_hot=>true
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4698439270126735)
,p_card_id=>wwv_flow_imp.id(4698032551126731)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'Bookmark'
,p_static_id=>'action_2'
,p_link_target_type=>'DEFINED_BY_DA_ACTION'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-bookmark-o'
,p_is_hot=>false
);
wwv_flow_imp_page.create_component_da_action(
 p_id=>wwv_flow_imp.id(4626375321683239)
,p_card_action_id=>wwv_flow_imp.id(4698439270126735)
,p_action_sequence=>10
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_static_id=>'native-javascript-code'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    '// Ensure we always target the icon span when updating the icon class',
    '$icon = $(this.triggeringElement).closest(".a-CardView-button ").children(".a-CardView-buttonIcon");',
    '$icon.toggleClass("fa-bookmark fa-bookmark-o");')))).to_clob
,p_stop_execution_on_error=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49791048302440104531)
,p_plug_name=>'About'
,p_static_id=>'dashboards'
,p_region_css_classes=>'margin-md'
,p_icon_css_classes=>'fa-mouse-pointer'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Cards present related information as distinct, visually grouped items that are easy to scan, compare, and select. They work well for collections where each item benefits from a clear identity, supporting context, optional media, status, or actions. T'
||'hese patterns demonstrate common ways to use the APEX Cards component for navigation, summaries, entities, media-rich content, and other reusable card-based layouts.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49791049020516104538)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'dashboards_1'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(24910759108528178725)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25276673186342969)
,p_plug_name=>'File and Document Cards'
,p_static_id=>'decision-and-action-list'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25438385634180580160)
,p_plug_name=>'Navigation Cards'
,p_static_id=>'nav-list-container'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49791048471839104532)
,p_plug_name=>'Pattern: Navigation'
,p_static_id=>'patterns'
,p_parent_plug_id=>wwv_flow_imp.id(25438385634180580160)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-home'' as icon_class,',
'    ''Overview'' as title,',
'    ''Review the primary summary, current status, and key information for this area.'' as description,',
'    ''cards'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-info-circle-o'' as icon_class,',
'    ''Details'' as title,',
'    ''View supporting attributes, context, and additional information.'' as description,',
'    ''cards'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-link'' as icon_class,',
'    ''Related Information'' as title,',
'    ''Open associated records, resources, and other relevant content.'' as description,',
'    ''cards'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-history'' as icon_class,',
'    ''Activity'' as title,',
'    ''Review recent changes, updates, and other notable events.'' as description,',
'    ''cards'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-cog'' as icon_class,',
'    ''Settings'' as title,',
'    ''Manage configuration, preferences, and supporting options.'' as description,',
'    ''cards'' as page_alias',
'from sys.dual;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates Cards for moving between related destinations within the same application area. Each card gives a destination a clear label, supporting context, and recognizable icon so users understand where it leads before selecting it.',
'',
'## When to Use',
'',
'Use when users need to choose from a small set of peer destinations, such as an overview, details, related information, activity, or settings. This pattern works best when a label alone does not provide enough context.',
'',
'## When to Avoid',
'',
'Avoid when destinations represent a sequential process, a large navigation hierarchy, or frequently used global navigation. Use tabs, breadcrumbs, a navigation menu, or a step-based pattern instead.',
'',
'## AI Guidance',
'',
'Use a concise, task-oriented title and a brief description that explains what users will find after opening the destination. Use icons only when they reinforce meaning. Make the full card selectable and link it to a stable page alias or URL. Do not a'
||'dd buttons when opening the destination is the only meaningful action.'))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(12618460805375526)
,p_region_id=>wwv_flow_imp.id(49791048471839104532)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITLE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'DESCRIPTION'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'ICON_CLASS'
,p_icon_css_classes=>'fa'
,p_icon_position=>'TOP'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(12618513786375527)
,p_card_id=>wwv_flow_imp.id(12618460805375526)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'f?p=&APP_ID.:&PAGE_ALIAS.:&SESSION.::&DEBUG.::::'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49815673560020463281)
,p_plug_name=>'Pattern: Product Catalog'
,p_static_id=>'related-information'
,p_parent_plug_id=>wwv_flow_imp.id(25276396851342966)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>100
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr('Hotel Stays \2014 Product/Catalog Cards Pattern Guidance'),
'----------------------------------------------------',
'Use this region to present hotel and hostel listings that users can',
'browse, compare, save, and open for more information.',
'',
'Design intent:',
'- Use HOTEL_NAME as the card title.',
'- Use Subtitle Advanced Formatting to combine HIGHLIGHT, RATING,',
'  and REVIEWS_DISPLAY.',
'- Use the secondary body for HOTEL_GRADE and TAGS.',
'- Use Body Advanced Formatting to display DEAL_PRICE when present;',
'  otherwise display CURRENT_PRICE.',
'- Use the property photograph as the card media.',
'- Use one badge for the deal state.',
'- Use a dummy # target for Full Card and Button actions.',
'- Use Grid layout with the default Cards column behavior.',
'- Use REVIEWS for sorting and filtering.',
'- Use REVIEWS_DISPLAY for visible card text only.',
'- Store TAGS as comma-separated values and format them in the',
'  Secondary Body expression using Template Directives.',
'',
'Recommended Card column mappings:',
'- Primary Key Column 1: HOTEL_ID',
'- Title: HOTEL_NAME',
'- Subtitle: Advanced Formatting using HIGHLIGHT, RATING, REVIEWS_DISPLAY',
'- Body: Advanced Formatting using CURRENT_PRICE and DEAL_PRICE',
'- Secondary Body: Advanced Formatting using HOTEL_GRADE and TAGS',
'- Badge Column: DEAL_LABEL',
'- Badge CSS Classes: &DEAL_CSS_CLASS.',
'- Media URL: IMAGE_URL',
'- Image Description: IMAGE_DESCRIPTION',
'*/',
'',
'select',
'    301 as hotel_id,',
'    ''Luxury Hotel'' as hotel_name,',
'    ''Excellent location'' as highlight,',
'    ''$310'' as current_price,',
'    ''$265'' as deal_price,',
'    4.8 as rating,',
'    1257 as reviews,',
'    to_char(1257, ''FM999G999G999'') as reviews_display,',
'    ''5-Star Hotel'' as hotel_grade,',
'    ''Free WiFi,Pool,Parking,Food'' as tags,',
'    ''#APP_FILES#media-cards/luxury-hotel.png'' as image_url,',
'    ''Elegant luxury hotel exterior with landscaped entrance'' as image_description,',
'    ''Deal'' as deal_label,',
'    ''u-success'' as deal_css_class',
'from sys.dual',
'',
'union all',
'',
'select',
'    302 as hotel_id,',
'    ''Business Travel Hotel'' as hotel_name,',
'    ''Connected to downtown'' as highlight,',
'    ''$220'' as current_price,',
'    cast(null as varchar2(50)) as deal_price,',
'    4.6 as rating,',
'    842 as reviews,',
'    to_char(842, ''FM999G999G999'') as reviews_display,',
'    ''4-Star Hotel'' as hotel_grade,',
'    ''Free WiFi,Parking,Business Center,Bar'' as tags,',
'    ''#APP_FILES#media-cards/business-travel-hotel.png'' as image_url,',
'    ''Modern business hotel lobby with workspaces and natural light'' as image_description,',
'    cast(null as varchar2(50)) as deal_label,',
'    cast(null as varchar2(50)) as deal_css_class',
'from sys.dual',
'',
'union all',
'',
'select',
'    303 as hotel_id,',
'    ''Family Stay Hotel'' as hotel_name,',
'    ''Spacious rooms'' as highlight,',
'    ''$285'' as current_price,',
'    ''$249'' as deal_price,',
'    4.7 as rating,',
'    2103 as reviews,',
'    to_char(2103, ''FM999G999G999'') as reviews_display,',
'    ''4-Star Hotel'' as hotel_grade,',
'    ''Free WiFi,Pool,Breakfast,Parking'' as tags,',
'    ''#APP_FILES#media-cards/family-stay-hotel.png'' as image_url,',
'    ''Family-friendly hotel with a bright outdoor pool area'' as image_description,',
'    ''Deal'' as deal_label,',
'    ''u-success'' as deal_css_class',
'from sys.dual',
'',
'union all',
'',
'select',
'    304 as hotel_id,',
'    ''City Hostel'' as hotel_name,',
'    ''Best value'' as highlight,',
'    ''$72'' as current_price,',
'    ''$59'' as deal_price,',
'    4.4 as rating,',
'    693 as reviews,',
'    to_char(693, ''FM999G999G999'') as reviews_display,',
'    ''Hostel'' as hotel_grade,',
'    ''Free WiFi,Shared Kitchen,Lockers,Transit'' as tags,',
'    ''#APP_FILES#media-cards/city-hostel.png'' as image_url,',
'    ''Bright shared hostel lounge in a central city location'' as image_description,',
'    ''Deal'' as deal_label,',
'    ''u-success'' as deal_css_class',
'from sys.dual;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates Cards for browsing and comparing visually identifiable offerings. Each card combines imagery with concise descriptions, key attributes, availability or deal status, and optional actions that help users evaluate and select an item.',
'',
'## When to Use',
'',
'Use for product catalogs and media-rich lists where images help users recognize content, view high-level details, and take actions on items.',
'',
'## When to Avoid',
'',
'Avoid when items do not benefit from visual recognition, when users need to compare many structured attributes, or when the collection is too dense for image-led browsing. Use a report, comparison table, or compact list instead.',
'',
'## AI Guidance',
'',
'Use meaningful media with an accurate image description. Use the title for the offering name, the subtitle for concise comparison context, and the body and secondary body for the attributes that influence selection. Use one badge for the most importa'
||'nt availability, deal, or lifecycle state. Link the full card, title, or media to item details. Add a focused secondary action, such as Favorite or Save, only when it does not compete with the primary navigation action.'))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(4697079741126721)
,p_region_id=>wwv_flow_imp.id(49815673560020463281)
,p_layout_type=>'GRID'
,p_component_css_classes=>'product-listings'
,p_title_adv_formatting=>false
,p_title_column_name=>'HOTEL_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'<span class="u-color-17-text">&#9733;</span> &RATING. (&REVIEWS_DISPLAY. reviews) &middot; &HIGHLIGHT.'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if DEAL_PRICE/}',
'<span class="u-text-body-md">&DEAL_PRICE.</span>',
'<span class="u-text-body-sm">per night</span>  <span class="u-text-body-xs">was <del>&CURRENT_PRICE.</del></span>',
'{else/}',
'<span class="u-text-body-md">&CURRENT_PRICE.</span>',
'<span class="u-text-body-sm">per night</span>',
'{endif/}'))
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&HOTEL_GRADE.</strong>',
'{loop "," TAGS/}',
'&middot; &APEX$ITEM.',
'{endloop/}'))
,p_badge_column_name=>'DEAL_LABEL'
,p_badge_css_classes=>'&DEAL_CSS_CLASS.'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'IMAGE_URL'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'COVER'
,p_media_description=>'&IMAGE_DESCRIPTION.'
,p_pk1_column_name=>'HOTEL_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4697172831126722)
,p_card_id=>wwv_flow_imp.id(4697079741126721)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Favorite'
,p_static_id=>'action'
,p_link_target_type=>'DEFINED_BY_DA_ACTION'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-heart-o'
,p_action_css_classes=>'product-favorite-button'
,p_is_hot=>true
);
wwv_flow_imp_page.create_component_da_action(
 p_id=>wwv_flow_imp.id(4625804193683234)
,p_card_action_id=>wwv_flow_imp.id(4697172831126722)
,p_action_sequence=>10
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_static_id=>'native-remove-class'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    '// Ensure we always target the icon span when updating the icon class',
    '$icon = $(this.triggeringElement).closest(".product-favorite-button").children(".a-CardView-buttonIcon");',
    '$icon.toggleClass("fa-heart fa-heart-o");')))).to_clob
,p_stop_execution_on_error=>true
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4697286785126723)
,p_card_id=>wwv_flow_imp.id(4697079741126721)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>30
,p_static_id=>'action_1'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25276396851342966)
,p_plug_name=>'Media Cards'
,p_static_id=>'related-information_1'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25438386674062580170)
,p_plug_name=>'Action Cards'
,p_static_id=>'section-overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49811549517455830024)
,p_plug_name=>'Pattern: Approvals'
,p_static_id=>'section-summary'
,p_parent_plug_id=>wwv_flow_imp.id(25438386674062580170)
,p_region_template_options=>'t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc:t-CardsRegion--styleC'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Work Item Cards Pattern Guidance',
'--------------------------------',
'Use this region to present actionable work items with enough context',
'for users to prioritize, review, and act on them.',
'',
'Design intent:',
'- Use the expense description as the primary label.',
'- Use the subtitle for the work item or expense category.',
'- Use the body for a concise explanation of the request.',
'- Use separate columns for amount, requester, due date, priority, and',
'  submission age.',
'- Combine those values in the Subtitle or Secondary Body using Advanced',
'  Formatting.',
'- Use status_label for the visible workflow state.',
'- Use status_code for Server-Side Conditions on Card Actions.',
'- Use one badge for the current workflow state.',
'- Use an icon to distinguish work item types.',
'- Use a title link for review/details.',
'- Use buttons only when the current status permits an action.',
'- Do not make the full card a link when buttons are present.',
'',
'Recommended Cards attributes:',
'- Layout: Grid',
'- Title Column: work_item_name',
'- Subtitle Column: work_item_type',
'- Body Column: work_item_summary',
'- Secondary Body: Advanced Formatting',
'- Icon Source: Icon Class Column',
'- Icon Column: work_item_icon_class',
'- Icon Position: Start',
'- Badge Column: status_label',
'- Badge CSS Classes: &STATUS_CSS_CLASS.',
'- Primary Key Column 1: work_item_id',
'*/',
'',
'select',
'    201 as work_item_id,',
'    ''Client Workshop Travel'' as work_item_name,',
'    ''Travel Expense'' as work_item_type,',
'    ''Travel and lodging expenses for the Northstar client workshop in Chicago.'' as work_item_summary,',
'    to_char(1248.60, ''FM$999G999G990D00'',',
'        ''NLS_NUMERIC_CHARACTERS=''''.,'''''') as expense_amount,',
'    ''Maya Chen'' as requester_name,',
'    ''Due today'' as due_date_label,',
'    ''High'' as priority_label,',
'    apex_util.get_since( sysdate - 3 ) as submitted_since,',
'    ''fa fa-hourglass-half'' as work_item_icon_class,',
'    ''Pending Approval'' as status_label,',
'    ''PENDING_APPROVAL'' as status_code,',
'    ''u-warning'' as status_css_class',
'from sys.dual',
'',
'union all',
'',
'select',
'    202,',
'    ''Software Subscription Renewal'',',
'    ''Software Expense'',',
'    ''Annual renewal for the design collaboration and prototyping workspace.'',',
'    to_char(2400.00, ''FM$999G999G990D00'',',
'        ''NLS_NUMERIC_CHARACTERS=''''.,''''''),',
'    ''Priya Patel'',',
'    ''Due in 5 days'',',
'    ''High'',',
'    apex_util.get_since( sysdate - 5 ),',
'    ''fa fa-hourglass-half'',',
'    ''Pending Approval'',',
'    ''PENDING_APPROVAL'',',
'    ''u-warning''',
'from sys.dual',
'',
'union all',
'',
'select',
'    203,',
'    ''Accessibility Conference Registration'',',
'    ''Professional Development'',',
'    ''Additional supporting information is required before a decision can be made.'',',
'    to_char(895.00, ''FM$999G999G990D00'',',
'        ''NLS_NUMERIC_CHARACTERS=''''.,''''''),',
'    ''Jordan Lee'',',
'    ''Review requested'',',
'    ''Standard'',',
'    apex_util.get_since( sysdate - 2 ),',
'    ''fa fa-search'',',
'    ''Needs Review'',',
'    ''NEEDS_REVIEW'',',
'    ''u-info''',
'from sys.dual',
'',
'union all',
'',
'select',
'    204,',
'    ''Team Lunch Reimbursement'',',
'    ''Meals Expense'',',
'    ''The reimbursement request was reviewed and accepted.'',',
'    to_char(182.45, ''FM$999G999G990D00'',',
'        ''NLS_NUMERIC_CHARACTERS=''''.,''''''),',
'    ''Avery Smith'',',
'    ''Decision completed'',',
'    ''Standard'',',
'    apex_util.get_since( sysdate - 1 ),',
'    ''fa fa-check'',',
'    ''Approved'',',
'    ''APPROVED'',',
'    ''u-success''',
'from sys.dual',
'',
'union all',
'',
'select',
'    205,',
'    ''Home Office Equipment'',',
'    ''Equipment Expense'',',
'    ''Supporting information is available for context but requires no action.'',',
'    to_char(684.20, ''FM$999G999G990D00'',',
'        ''NLS_NUMERIC_CHARACTERS=''''.,''''''),',
'    ''Daniel Kim'',',
'    ''Reference only'',',
'    ''Standard'',',
'    apex_util.get_since( sysdate - 7 ),',
'    ''fa fa-info-circle'',',
'    ''No Action Required'',',
'    ''NO_ACTION_REQUIRED'',',
'    null',
'from sys.dual;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates Cards for presenting actionable work items that require a decision, review, or follow-up. Each card combines the work item identity, supporting context, workflow state, priority, timing, and actions that are appropriate for the item''s cu'
||'rrent state.',
'',
'## When to Use',
'',
'Use for small to medium queues of approvals, requests, tasks, issues, or cases where users need to review information and take a direct action.',
'',
'## When to Avoid',
'',
'Avoid when users need to process large volumes of work, compare many attributes, perform bulk actions, or complete a complex multi-step workflow. Use a report, interactive grid, dedicated task page, or workflow interface instead.',
'',
'## AI Guidance',
'',
'Use the title as a link to the review or detail page. Include only the information needed to understand and prioritize the decision, such as requester, amount, due date, priority, and submission age. Use one badge for the visible workflow state and u'
||'se status data separately to control when actions are available. Show buttons only when the current state permits an action. Do not make the full card a link when it contains decision buttons, as this creates competing interaction targets. Use confir'
||'mation for consequential or difficult-to-reverse actions.'))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(4697454856126725)
,p_region_id=>wwv_flow_imp.id(49811549517455830024)
,p_layout_type=>'GRID'
,p_grid_column_count=>2
,p_title_adv_formatting=>false
,p_title_column_name=>'WORK_ITEM_NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'&WORK_ITEM_TYPE. &middot; Submitted &SUBMITTED_SINCE.'
,p_body_adv_formatting=>false
,p_body_column_name=>'WORK_ITEM_SUMMARY'
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'&EXPENSE_AMOUNT. &middot; &REQUESTER_NAME. &middot; &DUE_DATE_LABEL. &middot; Priority: &PRIORITY_LABEL.'
,p_badge_column_name=>'STATUS_LABEL'
,p_badge_css_classes=>'&STATUS_CSS_CLASS.'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'WORK_ITEM_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4697614241126727)
,p_card_id=>wwv_flow_imp.id(4697454856126725)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Approve'
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>':STATUS_CODE = ''PENDING_APPROVAL'''
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4697745950126728)
,p_card_id=>wwv_flow_imp.id(4697454856126725)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'Reject'
,p_static_id=>'action_1'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_button_display_type=>'TEXT'
,p_is_hot=>false
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>':STATUS_CODE = ''PENDING_APPROVAL'''
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4697848691126729)
,p_card_id=>wwv_flow_imp.id(4697454856126725)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>30
,p_label=>'Review'
,p_static_id=>'action_2'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_button_display_type=>'TEXT'
,p_is_hot=>false
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>':STATUS_CODE = ''NEEDS_REVIEW'''
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4697985992126730)
,p_card_id=>wwv_flow_imp.id(4697454856126725)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>40
,p_static_id=>'action_3'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>':STATUS_CODE IN (''PENDING_APPROVAL'', ''NEEDS_REVIEW'')'
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25438385874261580162)
,p_plug_name=>'Item Detail Cards'
,p_static_id=>'status-list'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49811406420286184955)
,p_plug_name=>'Pattern: Item Details'
,p_static_id=>'status-list-2'
,p_parent_plug_id=>wwv_flow_imp.id(25438385874261580162)
,p_region_template_options=>'t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc:t-CardsRegion--styleA'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Item Details Cards Pattern Guidance',
'----------------------------------',
'Use this region to present identifiable business records with enough',
'supporting context for users to recognize, compare, and open an item.',
'',
'Design intent:',
'- Use the item name as the primary label.',
'- Use the subtitle to identify the item type or category.',
'- Use the body for a concise description of the item''s purpose or context.',
'- Use the secondary body for a small number of key attributes, such as',
'  owner, date, location, or related information.',
'- Use an icon to distinguish item types when imagery is unnecessary.',
'- Make the full card the primary action that links to the item''s detail page.',
'- Make the Edit button a secondary action that opens the edit page or dialog.',
'*/',
'select',
'    101 as item_id,',
'    ''Finance Reporting Access Review'' as item_name,',
'    ''Access Request'' as item_category,',
'    ''Request to confirm reporting access for the quarterly close process.'' as item_summary,',
'    ''Maya Chen'' as assigned_to,',
'    apex_util.get_since( sysdate - 2.5 ) as last_updated,',
'    ''fa fa-key'' as item_icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'    102 as item_id,',
'    ''Denver Office Hardware Refresh'' as item_name,',
'    ''Equipment Request'' as item_category,',
'    ''Replacement laptops and docking stations are being reviewed for approval.'' as item_summary,',
'    ''Jordan Lee'' as assigned_to,',
'    apex_util.get_since( sysdate - 1 ) as last_updated,',
'    ''fa fa-laptop'' as item_icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'    103 as item_id,',
'    ''Northstar Labs Client Onboarding'' as item_name,',
'    ''Onboarding Plan'' as item_category,',
'    ''Required setup activities and supporting materials are awaiting confirmation.'' as item_summary,',
'    ''Avery Smith'' as assigned_to,',
'    apex_util.get_since( sysdate - 1 ) as last_updated,',
'    ''fa fa-rocket'' as item_icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'    104 as item_id,',
'    ''Apex Supply Contract Renewal'' as item_name,',
'    ''Contract Record'' as item_category,',
'    ''Renewal terms and supporting documentation are ready for stakeholder review.'' as item_summary,',
'    ''Priya Patel'' as assigned_to,',
'    apex_util.get_since( sysdate - 1 ) as last_updated,',
'    ''fa fa-file-text-o'' as item_icon_class',
'from sys.dual',
'',
'union all',
'',
'select',
'    105 as item_id,',
'    ''Remote Work Policy Exception'' as item_name,',
'    ''Policy Request'' as item_category,',
'    ''The requested exception has been reviewed and recorded for reference.'' as item_summary,',
'    ''Daniel Kim'' as assigned_to,',
'    apex_util.get_since( sysdate - 1 ) as last_updated,',
'    ''fa fa-check-circle-o'' as item_icon_class',
'from sys.dual;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates Cards for presenting identifiable business records with enough supporting context for users to recognize, compare, and open an item. Each card emphasizes the item identity, key attributes, and its most important current state.',
'',
'## When to Use',
'',
'Use for small to medium collections of business records, such as requests, plans, contracts, assets, or related items, where a compact summary is more useful than a table row alone.',
'',
'## When to Avoid',
'',
'Avoid when users need to compare many attributes across a large result set, perform bulk actions, or edit records directly in the collection. Use a report, interactive grid, or dedicated form instead.',
'',
'## AI Guidance',
'',
'Use the title for the item name, the subtitle for its type or category, and the body for a concise description or context. Use the secondary body for a small number of useful attributes, such as owner, date, location, or related information. Use an i'
||'con when imagery is unnecessary. Make the full card a link to the item detail page and the Edit button open the edit page or dialog; the full card action is the primary action, and the Edit button is the secondary action.'))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(16191434632427702)
,p_region_id=>wwv_flow_imp.id(49811406420286184955)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'ITEM_NAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'ITEM_CATEGORY'
,p_body_adv_formatting=>false
,p_body_column_name=>'ITEM_SUMMARY'
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'&ASSIGNED_TO. &middot; Last updated &LAST_UPDATED.'
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'ITEM_ICON_CLASS'
,p_icon_css_classes=>'u-normal'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ITEM_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4622940842683205)
,p_card_id=>wwv_flow_imp.id(16191434632427702)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>'Edit'
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-pencil'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4626456232683240)
,p_card_id=>wwv_flow_imp.id(16191434632427702)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_static_id=>'action_1'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92549377473102995178)
,p_plug_name=>'Region Display Selector'
,p_static_id=>'tabs'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25274926713342951)
,p_plug_name=>'Pattern: Users'
,p_static_id=>'users-list'
,p_parent_plug_id=>wwv_flow_imp.id(25276127811342963)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc:t-CardsRegion--styleB'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Users List Pattern Guidance',
'---------------------------',
'Use this region to present people or application users with a clear',
'identity hierarchy and lightweight presence information.',
'',
'Design intent:',
'- Use the person''s name as the primary label.',
'- Use initials as the avatar when no profile image is available.',
'- Use the description for one concise attribute such as role or team.',
'- Use the badge for a meaningful presence or account state.',
'- Use last-active time as secondary metadata and apply the SINCE format in APEX.',
'- Do not add row actions unless the adapted experience requires them.',
'*/',
'select',
'    1 as user_id,',
'    ''Maya Chen'' as title,',
'    ''Product Manager'' as description,',
'    apex_string.get_initials(''Maya Chen'') as initials,',
'    ''#APP_FILES#avatars/persona-female03.png'' as avatar,',
'    ''Active'' as badge,',
'    ''u-success'' as badge_state,',
'    sysdate - interval ''12'' minute as last_active',
'from sys.dual',
'',
'union all',
'',
'select',
'    2,',
'    ''Jordan Lee'',',
'    ''Senior Developer'',',
'    apex_string.get_initials(''Jordan Lee''),',
'    ''#APP_FILES#avatars/persona-male01.png'',',
'    ''Active'',',
'    ''u-success'',',
'    sysdate - interval ''45'' minute',
'from sys.dual',
'',
'union all',
'',
'select',
'    3,',
'    ''Avery Smith'',',
'    ''UX Designer'',',
'    apex_string.get_initials(''Avery Smith''),',
'    ''#APP_FILES#avatars/persona-female01.png'',',
'    ''Away'',',
'    ''u-warning'',',
'    sysdate - interval ''4'' hour',
'from sys.dual',
'',
'union all',
'',
'select',
'    4,',
'    ''Priya Patel'',',
'    ''Business Analyst'',',
'    apex_string.get_initials(''Priya Patel''),',
'    ''#APP_FILES#avatars/persona-female02.png'',',
'    ''Busy'',',
'    ''u-danger'',',
'    sysdate - interval ''1'' day',
'from sys.dual',
'',
'union all',
'',
'select',
'    5,',
'    ''Daniel Kim'',',
'    ''Reviewer'',',
'    apex_string.get_initials(''Daniel Kim''),',
'    ''#APP_FILES#avatars/persona-male02.png'',',
'    ''Inactive'',',
'    ''u-info'',',
'    sysdate - interval ''7'' day',
'from sys.dual;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates Cards for presenting people or application users with a clear identity hierarchy, concise role or team context, and lightweight presence or account state.',
'',
'## When to Use',
'',
'Use for small to medium user lists where names, roles, presence, and recent activity help users quickly understand who is involved, responsible, or available.',
'',
'## When to Avoid',
'',
'Avoid when users need to compare many user attributes, manage accounts in bulk, or perform complex filtering and administration. Use a report, table, or dedicated user-management view instead.',
'',
'## AI Guidance',
'',
'Use the person''s name as the card title and show one useful supporting attribute, such as role or team. Use an avatar or initials to establish identity; initials are an appropriate fallback when a profile image is unavailable. Use a badge only for a '
||'meaningful presence or account state, and show recent activity as secondary metadata only when it helps users understand availability or engagement. Keep the full card or title link focused on the user profile or related details. Do not add actions b'
||'y default; add them only when the experience has a clear user-management or collaboration need.'))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(12618665040375528)
,p_region_id=>wwv_flow_imp.id(25274926713342951)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITLE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'DESCRIPTION'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'URL'
,p_icon_image_url=>'&AVATAR.'
,p_icon_position=>'START'
,p_badge_column_name=>'BADGE'
,p_badge_css_classes=>'&BADGE_STATE.'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'USER_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(12618740413375529)
,p_card_id=>wwv_flow_imp.id(12618665040375528)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25276127811342963)
,p_plug_name=>'User Cards'
,p_static_id=>'users-list_1'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
