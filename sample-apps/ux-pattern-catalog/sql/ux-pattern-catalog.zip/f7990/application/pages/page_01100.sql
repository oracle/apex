prompt --application/pages/page_01100
begin
--   Manifest
--     PAGE: 01100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1100
,p_name=>'Content Rows'
,p_alias=>'CONTENT-ROWS'
,p_step_title=>'Content Rows'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.ux-about-text {',
'    padding: 1rem;',
'    border-bottom: 1px solid var(--ut-component-border-color);',
'    background: var(--ut-component-toolbar-background-color);',
'}',
'',
'.app-PatternGuidance > p:first-child {',
'    font-weight: 600;',
'}',
'',
'.app-PatternGuidance h4 {',
'  text-transform: uppercase;',
'  font-size: 0.75rem;',
'  color: var(--ut-component-text-muted-color);',
'  margin-bottom: 0.25rem;',
'}'))
,p_step_template=>2528119710305719084
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'The Content Rows pattern page demonstrates reusable row-based patterns for presenting structured information in a compact, scannable format. Examples show how content rows can support different purposes such as navigation, status, search results, sel'
||'ection, activity, related information, and people.',
'',
'## When to Use',
'',
'Use content rows when users need to scan or interact with a collection of similarly structured items while retaining more context than a simple list provides.',
'',
'## When to Avoid',
'',
'Avoid content rows when information is better represented as a comparison table, highly visual card layout, form, or unstructured text. Do not overload rows with excessive attributes or actions.',
'',
'## AI Guidance',
'',
'Use the examples on this page as references for adapting Content Row to different interaction roles. Preserve a clear hierarchy between the primary label, supporting description, metadata, status, and actions. Include only the elements needed for the'
||' specific use case, and keep repeated rows structurally consistent and easy to scan.',
''))
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25425726041375612703)
,p_plug_name=>'About'
,p_static_id=>'about'
,p_parent_plug_id=>wwv_flow_imp.id(25425726672852612710)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Helps users move between related areas by presenting each destination with enough context to understand where it leads.</p>',
'',
'<h4>Best For</h4>',
'<p>Small sets of peer destinations where a label alone may not be enough, such as related record areas, settings categories, or application sections.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25425727559390612719)
,p_plug_name=>'About'
,p_static_id=>'about_1'
,p_parent_plug_id=>wwv_flow_imp.id(25425726912933612712)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Summarizes the current condition of related items so exceptions and required attention are easy to spot.</p>',
'',
'<h4>Best For</h4>',
'<p>Small sets of checks, requirements, stages, or system conditions where concise labels and semantic status indicators support rapid scanning.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25425727779868612721)
,p_plug_name=>'About'
,p_static_id=>'about_1_1'
,p_parent_plug_id=>wwv_flow_imp.id(25425727712734612720)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Provides a compact overview of the main information areas associated with one item, including what each section contains and any useful supporting context.</p>',
'',
'<h4>Best For</h4>',
'<p>Detail pages with several related sections where counts, recency, or short descriptions help users decide what to review next.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12617367337375515)
,p_plug_name=>'About'
,p_static_id=>'about_1_1_1'
,p_parent_plug_id=>wwv_flow_imp.id(12617435523375516)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>110
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Groups the supporting information associated with an item into clear categories, making related content easy to discover and open.</p>',
'',
'<h4>Best For</h4>',
'<p>Detail pages with several kinds of related content, such as people, files, comments, child records, or other connected records.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12617914611375521)
,p_plug_name=>'About'
,p_static_id=>'about_1_1_1_1'
,p_parent_plug_id=>wwv_flow_imp.id(12617544818375517)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>150
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Presents search matches with enough context to distinguish similar records and quickly identify the most relevant result.</p>',
'',
'<h4>Best For</h4>',
'<p>Search or filtered result sets where record type, descriptive context, tags, and recency help users evaluate results before opening them.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12618060212375522)
,p_plug_name=>'About'
,p_static_id=>'about_1_1_1_1_1'
,p_parent_plug_id=>wwv_flow_imp.id(12617694559375518)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>190
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Presents a selectable set of records where choosing an item updates or drives a related detail area.</p>',
'',
'<h4>Best For</h4>',
'<p>Master-detail or inspection layouts where users review one current item at a time and need concise status and supporting context before selecting it.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12618106351375523)
,p_plug_name=>'About'
,p_static_id=>'about_1_1_1_1_1_1'
,p_parent_plug_id=>wwv_flow_imp.id(12617711858375519)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>230
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Presents items that may require a decision or review, keeping the relevant context, current state, and available actions together.</p>',
'',
'<h4>Best For</h4>',
'<p>Approval, review, and triage scenarios where users need to quickly distinguish actionable items from completed or informational ones.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12618251910375524)
,p_plug_name=>'About'
,p_static_id=>'about_1_1_1_1_1_1_1'
,p_parent_plug_id=>wwv_flow_imp.id(12617885630375520)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>270
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Shows a chronological history of meaningful changes and events so users can quickly understand what happened, when, and by whom.</p>',
'',
'<h4>Best For</h4>',
'<p>Record histories, audit-style activity, comments, assignments, file changes, and status updates where recent events and their context matter.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12617215067375514)
,p_plug_name=>'About'
,p_static_id=>'about_1_2'
,p_parent_plug_id=>wwv_flow_imp.id(12617166483375513)
,p_region_css_classes=>'app-PatternGuidance'
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Displays a list of people with an avatar or initials, lightweight role context, and current presence or account state.</p>',
'',
'<h4>Best For</h4>',
'<p>Small to medium user lists where names, roles, presence, and recent activity help users quickly understand who is involved or available.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92536719424470027737)
,p_plug_name=>'Pattern: Decision and Action List'
,p_static_id=>'action-list'
,p_parent_plug_id=>wwv_flow_imp.id(12617711858375519)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>220
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Decision and Action List Pattern Guidance',
'-----------------------------------------',
'Use this region to present items that may require a decision, review,',
'or no further action.',
'',
'Design intent:',
'- Use the icon as a reinforcing status cue rather than decoration.',
'- Keep the status available as text so meaning does not depend on icon or color alone.',
'- Show Approve and Reject only for rows awaiting a decision.',
'- Show Review only when additional inspection is required.',
'- Do not show actions for completed or informational rows.',
'- Keep descriptions focused on the context needed to make the decision.',
'- Map META_DATE to a date-aware display attribute and apply the SINCE format in APEX.',
'*/',
'select',
'    1 as item_id,',
'    ''Review proposed changes'' as title,',
'    ''Confirm whether the proposed updates should be accepted.'' as description,',
'    ''fa-hourglass-2 u-warning'' as icon,',
'    ''Pending Approval'' as status,',
'    sysdate - interval ''2'' hour as meta_date,',
'    ''PENDING_APPROVAL'' as row_state',
'from sys.dual',
'',
'union all',
'',
'select',
'    2,',
'    ''Evaluate access request'',',
'    ''Review the requested access level and supporting justification.'',',
'    ''fa-hourglass-2 u-warning'',',
'    ''Pending Approval'',',
'    sysdate - interval ''1'' day,',
'    ''PENDING_APPROVAL''',
'from sys.dual',
'',
'union all',
'',
'select',
'    3,',
'    ''Review supporting details'',',
'    ''Additional context is available and should be reviewed before a decision.'',',
'    ''fa-search u-info'',',
'    ''Needs Review'',',
'    sysdate - interval ''3'' hour,',
'    ''NEEDS_REVIEW''',
'from sys.dual',
'',
'union all',
'',
'select',
'    4,',
'    ''Approved configuration update'',',
'    ''The proposed configuration was reviewed and accepted.'',',
'    ''fa-check u-success'',',
'    ''Approved'',',
'    trunc(sysdate) - 1,',
'    ''APPROVED''',
'from sys.dual',
'',
'union all',
'',
'select',
'    5,',
'    ''Reference information available'',',
'    ''Supporting information is available for context but requires no action.'',',
'    ''fa-info u-info'',',
'    ''No Action Required'',',
'    trunc(sysdate) - 3,',
'    ''INFORMATIONAL''',
'from sys.dual;'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_SHAPE', 't-Avatar--circle',
  'AVATAR_SIZE', 't-Avatar--xs',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'MISC', '&META_DATE.',
  'OVERLINE', '&STATUS.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates an action list for presenting items that may require a decision, review, or no further action. Each row combines a clear task or outcome, supporting context, status, recency, and conditional actions.',
'',
'## When to Use',
'',
'Use when users need to scan a small set of items and quickly identify which ones require attention. This pattern works well for approvals, reviews, exception handling, and other lightweight work queues.',
'',
'## When to Avoid',
'',
'Avoid when users need to process large volumes of work, compare many attributes, perform bulk actions, or follow a complex multi-step workflow. Use a report, interactive grid, dedicated task page, or workflow interface instead.',
'',
'## AI Guidance',
'',
'Write titles that clearly describe the decision, review, or outcome. Use the description only for context needed to understand or complete the task. Keep status and date values separate so they can be mapped independently and formatted appropriately '
||'in APEX.',
'',
'Use icons as reinforcing status cues rather than decoration. Do not rely on icon shape or color alone; expose the status as text for accessibility and clarity. Show Approve and Reject only for rows awaiting a decision, show Review only when inspectio'
||'n is required, and omit actions for completed or informational rows.',
'',
'Keep routine review actions neutral. Reserve success and danger treatments for actions that commit meaningful state changes, and use confirmation when rejection or another consequential action cannot be easily reversed.',
''))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(92536719682700027740)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(92536720014981027743)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24903446015080173611)
,p_name=>'ITEM_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITEM_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>120
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24903446450295173615)
,p_name=>'META_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'META_DATE'
,p_data_type=>'DATE'
,p_display_sequence=>150
,p_format_mask=>'SINCE'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24903446155143173612)
,p_name=>'ROW_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROW_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>130
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24903446274911173614)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>140
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(92536719638248027739)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(92536720594333027749)
,p_region_id=>wwv_flow_imp.id(92536719424470027737)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(24903446234705173613)
,p_region_id=>wwv_flow_imp.id(92536719424470027737)
,p_position_id=>363792341120765662
,p_display_sequence=>30
,p_template_id=>363792942797796791
,p_label=>'Reject'
,p_static_id=>'reject'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_button_display_type=>'TEXT'
,p_is_hot=>false
,p_show_as_disabled=>false
,p_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_condition_expr1=>'ROW_STATE'
,p_condition_expr2=>'PENDING_APPROVAL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(92536720698067027750)
,p_region_id=>wwv_flow_imp.id(92536719424470027737)
,p_position_id=>363792341120765662
,p_display_sequence=>20
,p_template_id=>363792942797796791
,p_label=>'Approve'
,p_static_id=>'review'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
,p_show_as_disabled=>false
,p_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_condition_expr1=>'ROW_STATE'
,p_condition_expr2=>'PENDING_APPROVAL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(24903445704135173608)
,p_region_id=>wwv_flow_imp.id(92536719424470027737)
,p_position_id=>363792341120765662
,p_display_sequence=>40
,p_template_id=>363792942797796791
,p_label=>'Review'
,p_static_id=>'review_2'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_button_display_type=>'TEXT'
,p_is_hot=>false
,p_show_as_disabled=>false
,p_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_condition_expr1=>'ROW_STATE'
,p_condition_expr2=>'NEEDS_REVIEW'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49778389341112137081)
,p_plug_name=>'About'
,p_static_id=>'dashboards'
,p_region_css_classes=>'margin-md'
,p_icon_css_classes=>'fa-mouse-pointer'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Content row patterns help users scan repeated information, recognize important details, and take action without opening each record. Use these examples when a page needs to present records, statuses, navigation choices, activity, or related informati'
||'on in a consistent row-based layout.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49778390059188137088)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'dashboards_1'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(24910759108528178725)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12617711858375519)
,p_plug_name=>'Decision and Action List'
,p_static_id=>'decision-and-action-list'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>210
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49783912253584175107)
,p_plug_name=>'Pattern: List Selection'
,p_static_id=>'list-selection'
,p_region_name=>'list_selection_region'
,p_parent_plug_id=>wwv_flow_imp.id(12617694559375518)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>180
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Content Row Selection Pattern Guidance',
'--------------------------------------',
'Use this region to present a selectable list alongside a contextual',
'detail area.',
'',
'Design intent:',
'- Show one clear primary item per row.',
'- Use single selection when the detail area represents one current item.',
'- Store the selected primary key in the configured Current Selection Page Item.',
'- Use the badge to communicate the item''s current status.',
'- Keep supporting metadata concise and consistent.',
'- Use multi-selection only when the adapted page supports bulk actions.',
'*/',
'select',
'    1 as item_id,',
'    ''Item Record A'' as title,',
'    ''Planning'' as category,',
'    trunc(sysdate) as last_updated,',
'    ''On Track'' as status,',
'    ''success'' as badge_state',
'from sys.dual',
'',
'union all',
'',
'select',
'    2,',
'    ''Item Record B'',',
'    ''Operations'',',
'    trunc(sysdate) - 1,',
'    ''Paused'',',
'    ''warning''',
'from sys.dual',
'',
'union all',
'',
'select',
'    3,',
'    ''Item Record C'',',
'    ''Review'',',
'    trunc(sysdate) - 3,',
'    ''Blocked'',',
'    ''danger''',
'from sys.dual',
'',
'union all',
'',
'select',
'    4,',
'    ''Item Record D'',',
'    ''Reporting'',',
'    trunc(sysdate) - 5,',
'    ''Pending Review'',',
'    ''info''',
'from sys.dual',
'',
'union all',
'',
'select',
'    5,',
'    ''Item Record E'',',
'    ''Planning'',',
'    trunc(sysdate) - 8,',
'    ''On Track'',',
'    ''success''',
'from sys.dual',
''))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'item_id'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'No items found',
''))
,p_show_total_row_count=>false
,p_row_selection_type=>'SINGLE'
,p_current_selection_page_item=>'P1100_SELECTED_ITEM_ID_UI'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignEnd',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', 'Status',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_POS', 't-ContentRow-badge--posEnd',
  'BADGE_SHAPE', 't-Badge--circle',
  'BADGE_SIZE', 't-Badge--sm',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'STATUS',
  'DESCRIPTION', '&LAST_UPDATED.',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'STYLE', 't-ContentRow--styleCompact',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a selectable content-row list used to control a contextual detail view. Each row represents one record and exposes the key information users need to identify, compare, and select the current item.',
'',
'## When to Use',
'',
'Use when users need to scan a small collection and inspect one item at a time without leaving the page. This pattern works well in list-detail, inbox-style, and master-detail layouts where the selected row determines the content shown in an adjacent '
||'region.',
'',
'## When to Avoid',
'',
'Avoid when users primarily need bulk actions, side-by-side comparison, or editing across many records. Use a report, interactive grid, or multi-select pattern instead.',
'',
'## AI Guidance',
'',
'Use single selection when one detail area represents the current record. Store the selected primary key in the configured Current Selection Page Item and refresh only the regions that depend on that value.',
'',
'Keep titles concise and use supporting fields such as category, date, and status only when they help distinguish records. Clearly indicate the selected row, preserve selection after refresh when possible, and establish a sensible initial selection wh'
||'en the page first loads.',
'',
'Use multi-selection only when the adapted experience supports bulk actions rather than a single contextual detail view.',
''))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49784627210731108062)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49784628278647108072)
,p_name=>'CATEGORY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49783912363773175108)
,p_name=>'ITEM_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITEM_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49784627079600108060)
,p_name=>'LAST_UPDATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED'
,p_data_type=>'DATE'
,p_display_sequence=>30
,p_format_mask=>'SINCE'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49784628139791108071)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49783912416663175109)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12617694559375518)
,p_plug_name=>'List Selection'
,p_static_id=>'list-selection_1'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>170
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25425726672852612710)
,p_plug_name=>'Navigation List'
,p_static_id=>'nav-list-container'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49778389510511137082)
,p_plug_name=>'Pattern: Navigation List'
,p_static_id=>'patterns'
,p_parent_plug_id=>wwv_flow_imp.id(25425726672852612710)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-home'' as icon_class,',
'    ''Overview'' as title,',
'    ''Review the primary summary, current status, and key information for this area.'' as description,',
'    ''content-rows'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-info-circle-o'' as icon_class,',
'    ''Details'' as title,',
'    ''View supporting attributes, context, and additional information.'' as description,',
'    ''content-rows'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-link'' as icon_class,',
'    ''Related Information'' as title,',
'    ''Open associated records, resources, and other relevant content.'' as description,',
'    ''content-rows'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-history'' as icon_class,',
'    ''Activity'' as title,',
'    ''Review recent changes, updates, and other notable events.'' as description,',
'    ''content-rows'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-cog'' as icon_class,',
'    ''Settings'' as title,',
'    ''Manage configuration, preferences, and supporting options.'' as description,',
'    ''content-rows'' as page_alias',
'from sys.dual;'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON_CLASS. fa-2x u-opacity-50',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a navigation list for moving between related destinations within the same application area. Each row combines a clear destination label, optional supporting description, and recognizable icon.',
'',
'## When to Use',
'',
'Use when users need to choose from a small set of peer destinations, such as overview, details, related information, activity, or settings. This pattern works best for approximately three to seven options that are distinct enough to require explanati'
||'on.',
'',
'## When to Avoid',
'',
'Avoid when the destinations represent a sequential process, a large navigation hierarchy, or frequently used global navigation. Use tabs, breadcrumbs, a navigation menu, or a step-based pattern instead.',
'',
'## AI Guidance',
'',
'Use task-oriented labels that describe the destination clearly. Keep descriptions brief and explain what users will find after selecting the row. Use icons only when they reinforce meaning; do not rely on icons alone. Keep all rows visually consisten'
||'t and make the entire row selectable.',
'',
unistr('Set the target from a stable page alias or URL. Preserve the user\2019s current context when appropriate, and indicate the current destination when the list remains visible after navigation.'),
''))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49778389734854137085)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49778389572502137083)
,p_name=>'ICON_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49778389853152137086)
,p_name=>'PAGE_ALIAS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PAGE_ALIAS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49778389701942137084)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(49778389948213137087)
,p_region_id=>wwv_flow_imp.id(49778389510511137082)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'f?p=&APP_ID.:&PAGE_ALIAS.:&SESSION.::&DEBUG.::::'
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'PAGE_ALIAS'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49779099891862431461)
,p_plug_name=>'Pattern: Recent Activity'
,p_static_id=>'recent-activity'
,p_parent_plug_id=>wwv_flow_imp.id(12617885630375520)
,p_region_sub_css_classes=>'app-ActivityTimeline'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>260
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Activity timeline guidance for AI:',
'',
'1. The timeline should show the meaningful payload of the event at a glance.',
'2. Attribute changes should use the title to describe the new value or state.',
'3. File events should name the file in the title so the user can identify it immediately.',
'4. Comment events should surface the comment text itself; the title can be the comment body, or the description can carry it if the title is a short summary.',
'5. Use the description only when it adds useful context such as previous value, author, or a short supporting note.',
'6. Keep some rows title-only to demonstrate that not every activity needs a description.',
'7. Keep the mix of row shapes so the timeline can represent simple and rich events.',
'*/',
'',
'select ''Today'' as activity_group,',
'       10 as display_sequence,',
'       sysdate - interval ''1'' hour as activity_time,',
'       ''Maya Chen'' as actioned_by,',
'       ''Updated'' as action_type,',
'       null as badge_label,',
'       ''Status changed to On Track'' as title,',
'       ''Previous status: Needs Review'' as description,',
'       ''fa-check-circle-o u-success-text'' as icon_class,',
'       ''is-featured'' as row_class,',
'       1 as id',
'  from sys.dual',
'union all',
'select ''Today'',',
'       20,',
'       sysdate - interval ''4'' hour,',
'       ''Jordan Lee'',',
'       ''Reviewed'',',
'       null,',
'       ''Review completed'',',
'       ''Next step confirmed for the current owner'',',
'       ''fa-check-circle-o u-success-text'',',
'       ''is-standard'',',
'       2',
'  from sys.dual',
'union all',
'select ''This Week'',',
'       30,',
'       trunc(sysdate) - 2 + (9/24),',
'       ''Maya Chen'',',
'       ''Commented'',',
'       null,',
'       ''We should confirm the owner before moving this forward.'',',
'       ''Comment added to the current record'',',
'       ''fa-comments-o u-info-text'',',
'       ''is-standard'',',
'       3',
'  from sys.dual',
'union all',
'select ''This Week'',',
'       40,',
'       trunc(sysdate) - 3 + (14/24),',
'       ''Jordan Lee'',',
'       ''Adjusted'',',
'       null,',
'       ''Target Date set to October 1'',',
'       ''Previous target date: September 18'',',
'       ''fa-calendar-o u-info-text'',',
'       ''is-standard'',',
'       4',
'  from sys.dual',
'union all',
'select ''Earlier'',',
'       50,',
'       trunc(sysdate) - 7 + (11/24),',
'       null,',
'       null,',
'       null,',
'       ''Ownership assigned to Avery Smith for ongoing follow-up'',',
'       null,',
'       ''fa-user u-info-text'',',
'       ''is-compact'',',
'       5',
'  from sys.dual',
'union all',
'select ''Earlier'',',
'       60,',
'       trunc(sysdate) - 9 + (10/24),',
'       null,',
'       null,',
'       null,',
'       ''Standard Intake linked to support the current record'',',
'       null,',
'       ''fa-link u-info-text'',',
'       ''is-compact'',',
'       6',
'  from sys.dual',
'union all',
'select ''Earlier'',',
'       70,',
'       trunc(sysdate) - 10 + (12/24),',
'       null,',
'       null,',
'       null,',
'       ''Reference removed after duplicate values were identified'',',
'       null,',
'       ''fa-minus-circle-o u-danger-text'',',
'       ''is-compact'',',
'       7',
'  from sys.dual',
'union all',
'select ''Earlier'',',
'       80,',
'       trunc(sysdate) - 11 + (16/24),',
'       null,',
'       null,',
'       null,',
'       ''Initial record created and prepared for first review'',',
'       null,',
'       ''fa-plus-circle-o u-info-text'',',
'       ''is-compact'',',
'       8',
'  from sys.dual;'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'display_sequence, activity_group'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON_CLASS.',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_SIZE', 't-Avatar--sm',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'GROUP_TITLE', '<div class="u-text-uppercase u-text-muted-color u-text-body-xs u-text-bold">&ACTIVITY_GROUP.</div>',
  'HIDE_BORDERS', 'N',
  'ITEM_CSS_CLASSES', '&ROW_CLASS.',
  'MISC', '&ACTIVITY_TIME.',
  'OVERLINE', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{if ACTIONED_BY/}',
    '    &ACTIONED_BY.{if ACTION_TYPE/} &middot; &ACTION_TYPE.{endif/}',
    '{elseif ACTION_TYPE/}',
    '    &ACTION_TYPE.',
    '{endif/}')),
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a recent activity list for showing meaningful changes, comments, decisions, and system events associated with one record. Activities are grouped by relative time period so users can scan recent events first while retaining older history.',
'',
'## When to Use',
'',
'Use when users need a concise chronological history of what changed, who acted, and when it occurred. This pattern works well on detail pages where activity provides supporting context without requiring a full audit report.',
'',
'## When to Avoid',
'',
'Avoid when users need a legally complete audit trail, detailed field-by-field comparison, or analysis across many records. Use a dedicated audit report, change-history view, or timeline when those requirements are primary.',
'',
'## AI Guidance',
'',
'Describe the meaningful result of each event, not only the action type. Attribute changes should state the new value in the title and use the description for the previous value or other supporting context. File events should name the file, and commen'
||'ts should expose the comment text directly.',
'',
'Group rows using clear, mutually exclusive time periods such as Today, This Week, and Earlier. Order groups from newest to oldest, and order events chronologically within each group. Keep the group labels stable and derive them from the event timesta'
||'mp rather than storing them as unrelated display text.',
'',
'Use actor and action metadata when it adds context, but allow compact title-only rows for simple system events. Apply icons and semantic color only when they reinforce event meaning. Do not rely on color alone, and reserve stronger emphasis for genui'
||'nely important or featured activity.',
''))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49779100326134431465)
,p_name=>'ACTIONED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIONED_BY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49779100420359431466)
,p_name=>'ACTION_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTION_TYPE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49779100027147431462)
,p_name=>'ACTIVITY_GROUP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIVITY_GROUP'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>true
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49779100220472431464)
,p_name=>'ACTIVITY_TIME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIVITY_TIME'
,p_data_type=>'DATE'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49779100505324431467)
,p_name=>'BADGE_LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_LABEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49779100713397431469)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49779100142210431463)
,p_name=>'DISPLAY_SEQUENCE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DISPLAY_SEQUENCE'
,p_data_type=>'NUMBER'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49779100866180431470)
,p_name=>'ICON_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49779101083098431472)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>110
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49779100901843431471)
,p_name=>'ROW_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROW_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49779100623648431468)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12617885630375520)
,p_plug_name=>'Recent Activity'
,p_static_id=>'recent-activity_1'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>250
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49803014598692495831)
,p_plug_name=>'Pattern: Related Information'
,p_static_id=>'related-information'
,p_parent_plug_id=>wwv_flow_imp.id(12617435523375516)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>100
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-users'' as icon,',
'    ''People'' as title,',
'    ''View owners, participants, and other people associated with this item.'' as description,',
'    4 as item_count,',
'    ''PEOPLE'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-file-o'' as icon,',
'    ''Files'' as title,',
'    ''Open documents, attachments, and other supporting files.'' as description,',
'    12 as item_count,',
'    ''FILES'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-comments-o'' as icon,',
'    ''Comments'' as title,',
'    ''Review discussion, feedback, and notes related to this item.'' as description,',
'    18 as item_count,',
'    ''COMMENTS'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-sitemap'' as icon,',
'    ''Child Records'' as title,',
'    ''View records that belong to or depend on the current item.'' as description,',
'    6 as item_count,',
'    ''CHILD_RECORDS'' as page_alias',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''fa-link'' as icon,',
'    ''Related Records'' as title,',
'    ''Open other records connected to the current item.'' as description,',
'    3 as item_count,',
'    ''RELATED_RECORDS'' as page_alias',
'from sys.dual;'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON. fa-lg',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignCenter',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', 'Related Item Count',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_POS', 't-ContentRow-badge--posEnd',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'ITEM_COUNT',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a related-information list for exposing the main collections and supporting content associated with one current record. Each row identifies a related content type, briefly explains what it contains, and shows the number of available item'
||'s.',
'',
'## When to Use',
'',
'Use on detail pages when a record has several related collections that users may need to inspect, such as people, files, comments, child records, or connected records. This pattern works well when the related content is important but does not need to'
||' be displayed directly on the current page.',
'',
'## When to Avoid',
'',
'Avoid when there is only one related collection, when the related content is already visible nearby, or when users need to compare individual related records immediately. Use an inline report, tabs, cards, or a dedicated related-records region instea'
||'d.',
'',
'## AI Guidance',
'',
'Keep all rows scoped to the current record. Use clear plural labels for related content types, concise descriptions that explain what users will find, and counts that reflect the actual number of available items.',
'',
'Make the entire row selectable and navigate to a focused view of that related collection. Keep icons meaningful and visually consistent. Do not show counts when they are unavailable, misleading, or expensive to calculate. Order rows by relevance or e'
||'xpected frequency of use rather than alphabetically by default.',
'',
'This differs from **Section Overview** in one important way: Section Overview summarizes areas of the current page or record, while Related Information points to distinct collections of associated content.',
''))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49803015309556495838)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49803015418707495839)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49778176514368993818)
,p_name=>'ITEM_COUNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITEM_COUNT'
,p_data_type=>'NUMBER'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49778176414752993817)
,p_name=>'PAGE_ALIAS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PAGE_ALIAS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49803015159777495837)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(49784804974029772580)
,p_region_id=>wwv_flow_imp.id(49803014598692495831)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12617435523375516)
,p_plug_name=>'Related Information'
,p_static_id=>'related-information_1'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49784309047752740398)
,p_plug_name=>'Pattern: Search Results'
,p_static_id=>'search-results'
,p_parent_plug_id=>wwv_flow_imp.id(12617544818375517)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>140
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Sample data for a search-results content row.',
'',
'Each result includes:',
'',
'- Stable record type',
'- Primary result label',
'- Distinguishing description',
'- Search-relevant tags',
'- Last-updated date',
'- Optional secondary actions',
'',
'Map UPDATED_ON to the metadata attribute and apply the SINCE format',
'in APEX. TAGS contains a comma-separated set of short values that can',
'be rendered with template directives.',
'',
'Use tags for meaningful attributes that help users identify or',
'differentiate results. Keep the number of visible tags small and',
'avoid repeating the title, record type, or status.',
'*/',
'select',
'    1 as id,',
'    ''Record 001'' as title,',
'    ''Summary information and current context for this record.'' as description,',
'    ''Standard Record'' as category,',
'    ''assigned, customer-facing, current'' as tags,',
'    sysdate - interval ''30'' minute as updated_on,',
'    ''fa-file-text-o'' as icon,',
'    ''Standard Record'' as overline',
'from sys.dual',
'',
'union all',
'',
'select',
'    2,',
'    ''Record 002'',',
'    ''Supporting details are currently being prepared and reviewed.'',',
'    ''Review Record'',',
'    ''internal, draft, supporting-docs'',',
'    sysdate - interval ''3'' hour,',
'    ''fa-clipboard-check'',',
'    ''Review Record''',
'from sys.dual',
'',
'union all',
'',
'select',
'    3,',
'    ''Record 003'',',
'    ''Recent changes require confirmation before work can continue.'',',
'    ''Tracked Record'',',
'    ''assigned, follow-up'',',
'    sysdate - interval ''1'' day,',
'    ''fa-list-alt'',',
'    ''Tracked Record''',
'from sys.dual',
'',
'union all',
'',
'select',
'    4,',
'    ''Record 004'',',
'    ''Reference information and supporting material are available.'',',
'    ''Reference Record'',',
'    ''published, shared, documentation'',',
'    sysdate - interval ''4'' day,',
'    ''fa-book'',',
'    ''Reference Record''',
'from sys.dual',
'',
'union all',
'',
'select',
'    5,',
'    ''Record 005'',',
'    ''All required work has been completed and validated.'',',
'    ''Standard Record'',',
'    ''validated, complete'',',
'    sysdate - interval ''7'' day,',
'    ''fa-check-square-o'',',
'    ''Standard Record''',
'from sys.dual;'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'updated_on desc'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON. fa-lg',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', wwv_flow_string.join(wwv_flow_t_varchar2(
    '&DESCRIPTION.',
    '<div>',
    '{loop "," TAGS/}',
    '    <span class="t-Badge t-Badge--subtle t-Badge--sm"><span class="t-Badge-value">&APEX$ITEM.</span></span>',
    '{endloop/}',
    '</div>')),
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'MISC', 'Updated &UPDATED_ON.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a search-results list for presenting a small set of matching records in a compact, scannable format. Each row combines record identity, distinguishing context, current status, update metadata, and optional secondary actions.',
'',
'## When to Use',
'',
'Use when users need to review and open records returned by a search, filter, or browse action. This pattern works well when titles alone are not enough to distinguish results and users benefit from supporting descriptions, categories, status, or rece'
||'ncy.',
'',
'## When to Avoid',
'',
'Avoid when users need to compare many attributes across records, edit values directly, or analyze large result sets. Use a report, interactive grid, cards, or faceted search pattern instead.',
'',
'## AI Guidance',
'',
'Lead with the record title and include only the supporting details needed to distinguish one result from another. Use the overline for a stable category or record type, the badge for a meaningful status, and the metadata area for concise secondary in'
||'formation such as the last update date.',
'',
'Keep the entire row selectable when it opens the record. Reserve the row menu for less common secondary actions. Apply semantic badge states consistently, avoid decorative status colors, and keep row structure and metadata placement consistent across'
||' all results.',
''))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49784353490357174014)
,p_name=>'CATEGORY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49784353449673174013)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49784353900217174018)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49784353269765174011)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49784354607176174025)
,p_name=>'OVERLINE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OVERLINE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>150
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(25425729546045612738)
,p_name=>'TAGS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TAGS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>160
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49784353352743174012)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49784353824915174017)
,p_name=>'UPDATED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPDATED_ON'
,p_data_type=>'DATE'
,p_display_sequence=>70
,p_format_mask=>'SINCE'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(49784355101672174030)
,p_region_id=>wwv_flow_imp.id(49784309047752740398)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(49784355238317174031)
,p_region_id=>wwv_flow_imp.id(49784309047752740398)
,p_position_id=>363792341120765662
,p_display_sequence=>20
,p_template_id=>363794202317800939
,p_label=>'Row Actions'
,p_static_id=>'row-actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(49784355299433174032)
,p_component_action_id=>wwv_flow_imp.id(49784355238317174031)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Row Action 1'
,p_static_id=>'row-action-1'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(49784355409786174033)
,p_component_action_id=>wwv_flow_imp.id(49784355238317174031)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Row Action 2'
,p_static_id=>'row-action-2'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(49784355549968174034)
,p_component_action_id=>wwv_flow_imp.id(49784355238317174031)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Row Action 3'
,p_static_id=>'row-action-3'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12617544818375517)
,p_plug_name=>'Search Results'
,p_static_id=>'search-results_1'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>130
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25425727712734612720)
,p_plug_name=>'Section Overview'
,p_static_id=>'section-overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49798890556127862574)
,p_plug_name=>'Pattern: Section Overview'
,p_static_id=>'section-summary'
,p_parent_plug_id=>wwv_flow_imp.id(25425727712734612720)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''Overview'' as title,',
'    ''Review the primary summary, current status, and key attributes for this item.'' as description,',
'    ''fa-id-card-o'' as icon,',
'    ''8 attributes'' as meta,',
'    null as badge,',
'    null as badge_state,',
'    null as badge_icon',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''People'' as title,',
'    ''View associated people, ownership, responsibilities, and other participants.'' as description,',
'    ''fa-users'' as icon,',
'    ''4 people'' as meta,',
'    null as badge,',
'    null as badge_state,',
'    null as badge_icon',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Files'' as title,',
'    ''Access supporting documents, attachments, and other reference material.'' as description,',
'    ''fa-file-text-o'' as icon,',
'    ''12 files'' as meta,',
'    null as badge,',
'    null as badge_state,',
'    null as badge_icon',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Comments'' as title,',
'    ''Review discussion, feedback, and notes associated with this item.'' as description,',
'    ''fa-comments-o'' as icon,',
'    ''18 comments'' as meta,',
'    null as badge,',
'    null as badge_state,',
'    null as badge_icon',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Activity'' as title,',
'    ''Review recent changes, decisions, and other notable events.'' as description,',
'    ''fa-history'' as icon,',
'    ''Updated 10m ago'' as meta,',
'    null as badge,',
'    null as badge_state,',
'    null as badge_icon',
'from sys.dual;'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_SIZE', 't-Avatar--xs',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'MISC', '&META.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'STYLE', 't-ContentRow--styleCompact',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a section overview for summarizing the major content areas associated with one item. Each row identifies a section, briefly explains its contents, and provides supporting metadata such as a count or recent update.',
'',
'## When to Use',
'',
'Use on detail pages with several distinct information areas when users benefit from understanding what each section contains before opening or navigating to it. This pattern works well for sections such as overview, people, files, comments, and activ'
||'ity.',
'',
'## When to Avoid',
'',
'Avoid when the page has only a few visible sections, when section labels are already clear, or when users need primary application navigation. Use headings, tabs, a navigation list, or a table of contents instead.',
'',
'## AI Guidance',
'',
'Keep all rows scoped to one record or page context. Use concise section names, descriptions that explain the content available, and metadata that adds useful context, such as item counts or recency. Do not use decorative metrics that do not help user'
||'s decide where to go.',
'',
'Make rows selectable when they navigate to the corresponding section. Keep icons consistent and meaningful, preserve a stable section order, and avoid using status colors unless the metadata represents an actual state.',
''))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49798891096016862579)
,p_name=>'BADGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49798891221113862581)
,p_name=>'BADGE_ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49798891110392862580)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49798890885221862577)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49798890951398862578)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49798891614014862585)
,p_name=>'META'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'META'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49798890782347862576)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(49781118094375205711)
,p_region_id=>wwv_flow_imp.id(49798890556127862574)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25425726912933612712)
,p_plug_name=>'Status List'
,p_static_id=>'status-list'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49798747458958217505)
,p_plug_name=>'Pattern: Status List'
,p_static_id=>'status-list-2'
,p_parent_plug_id=>wwv_flow_imp.id(25425726912933612712)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''Data''                         as overline,',
'    ''Required Information''        as title,',
'    ''All required fields have been completed.'' as description,',
'    ''fa-tasks-alt''              as icon,',
'    ''Complete''                     as badge,',
'    ''success''                      as badge_state,',
'    ''fa-check''                     as badge_icon',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Review''                       as overline,',
'    ''Content Review''              as title,',
'    ''Updates are in progress and have not yet been finalized.'' as description,',
'    ''fa-search''                    as icon,',
'    ''In Progress''                  as badge,',
'    ''warning''                      as badge_state,',
'    ''fa-clock-o''                   as badge_icon',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Approval''                     as overline,',
'    ''Required Approval''            as title,',
'    ''An outstanding decision is blocking further progress.'' as description,',
'    ''fa-user-check''                as icon,',
'    ''Action Required''              as badge,',
'    ''danger''                       as badge_state,',
'    ''fa-exclamation''               as badge_icon',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Files''                        as overline,',
'    ''Supporting Documents''        as title,',
'    ''Reference files are available for review.'' as description,',
'    ''fa-file-text-o''               as icon,',
'    ''Available''                    as badge,',
'    ''info''                         as badge_state,',
'    ''fa-info''                      as badge_icon',
'from sys.dual',
'',
'union all',
'',
'select',
'    ''Configuration''               as overline,',
'    ''Application Settings''        as title,',
'    ''The current configuration has been validated successfully.'' as description,',
'    ''fa-cogs''                      as icon,',
'    ''Validated''                    as badge,',
'    ''success''                      as badge_state,',
'    ''fa-check''                     as badge_icon',
'from sys.dual;'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON. fa-lg',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignCenter',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', 'Badge',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_POS', 't-ContentRow-badge--posEnd',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'BADGE',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'OVERLINE', '&OVERLINE.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a status list for summarizing the condition of several related parts of a record, process, or application area. Each row combines a clear label, brief explanation, supporting icon, and semantic status badge.',
'',
'## When to Use',
'',
'Use when users need to scan a small set of related checks, requirements, stages, or system conditions and quickly identify what is complete, in progress, available, or requires attention.',
'',
'## When to Avoid',
'',
'Avoid when users need to compare many records, analyze status trends, or act on a complex workflow. Use a report, chart, timeline, or task-oriented view instead.',
'',
'## AI Guidance',
'',
'Keep all rows within one coherent status context. Use concise titles for the item being evaluated and descriptions that explain the meaning or consequence of its current state. Apply semantic badge states consistently: success for positive completion'
||', warning for incomplete or pending work, danger for blockers or required action, and info for neutral availability or context.',
'',
'Use icons to reinforce the item or status, but do not rely on color or icons alone. Order rows by importance when exceptions require attention; otherwise, follow the natural sequence of the process or information.',
''))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49798748355685217514)
,p_name=>'BADGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49798748571838217516)
,p_name=>'BADGE_ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49798748482396217515)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49798748169822217512)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49798748278973217513)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49798747984504217510)
,p_name=>'OVERLINE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OVERLINE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49798748020043217511)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(49780537834295494254)
,p_region_id=>wwv_flow_imp.id(49798747458958217505)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92536718511775027728)
,p_plug_name=>'Region Display Selector'
,p_static_id=>'tabs'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12615965385375501)
,p_plug_name=>'Pattern: Users List'
,p_static_id=>'users-list'
,p_parent_plug_id=>wwv_flow_imp.id(12617166483375513)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'Users List Pattern Guidance',
'---------------------------',
'Use this region to present people or application users with a clear',
'identity hierarchy and lightweight presence information.',
'',
'Design intent:',
'- Use the person''s name as the primary label.',
'- Use initials as the avatar when no profile image is available.',
'- Use the description for one concise attribute such as role or team.',
'- Use the badge for a meaningful presence or account state.',
'- Use last-active time as secondary metadata and apply the SINCE format in APEX.',
'- Do not add row actions unless the adapted experience requires them.',
'*/',
'select',
'    1 as user_id,',
'    ''Maya Chen'' as title,',
'    ''Product Manager'' as description,',
'    apex_string.get_initials(''Maya Chen'') as initials,',
'    ''Active'' as badge,',
'    ''success'' as badge_state,',
'    sysdate - interval ''12'' minute as last_active',
'from sys.dual',
'',
'union all',
'',
'select',
'    2,',
'    ''Jordan Lee'',',
'    ''Senior Developer'',',
'    apex_string.get_initials(''Jordan Lee''),',
'    ''Active'',',
'    ''success'',',
'    sysdate - interval ''45'' minute',
'from sys.dual',
'',
'union all',
'',
'select',
'    3,',
'    ''Avery Smith'',',
'    ''UX Designer'',',
'    apex_string.get_initials(''Avery Smith''),',
'    ''Away'',',
'    ''warning'',',
'    sysdate - interval ''4'' hour',
'from sys.dual',
'',
'union all',
'',
'select',
'    4,',
'    ''Priya Patel'',',
'    ''Business Analyst'',',
'    apex_string.get_initials(''Priya Patel''),',
'    ''Busy'',',
'    ''danger'',',
'    sysdate - interval ''1'' day',
'from sys.dual',
'',
'union all',
'',
'select',
'    5,',
'    ''Daniel Kim'',',
'    ''Reviewer'',',
'    apex_string.get_initials(''Daniel Kim''),',
'    ''Inactive'',',
'    ''info'',',
'    sysdate - interval ''7'' day',
'from sys.dual;'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_INITIALS', 'INITIALS',
  'AVATAR_SHAPE', 't-Avatar--circle',
  'AVATAR_TYPE', 'initials',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignCenter',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', 'Status',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_POS', 't-ContentRow-badge--posEnd',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'BADGE',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'MISC', '&LAST_ACTIVE.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a users list for presenting people with a clear identity hierarchy, concise role or team context, and lightweight presence or account state.',
'',
'## When to Use',
'',
'Use when users need to scan a small or medium set of people associated with an application area, record, team, or task. This pattern works well when identity, role, availability, and recent activity are useful at a glance.',
'',
'## When to Avoid',
'',
'Avoid when users need to compare many user attributes, manage accounts in bulk, or perform complex filtering and administration. Use a report, table, or dedicated user-management view instead.',
'',
'## AI Guidance',
'',
'Use the person''s name as the primary label and keep supporting information concise. Show one useful secondary attribute, such as role or team, rather than turning each row into a profile summary.',
'',
'Use initials as a fallback avatar when no profile image is available. Use badges only for meaningful presence or account states, and keep state labels and semantic colors consistent. Show recent activity as secondary metadata when it helps users unde'
||'rstand availability or engagement.',
'',
'Do not add row actions by default. Add actions only when the adapted experience has a clear user-management or collaboration need.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12616884990375510)
,p_name=>'BADGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12616962183375511)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12616118697375503)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12616745308375509)
,p_name=>'INITIALS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INITIALS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12617035036375512)
,p_name=>'LAST_ACTIVE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_ACTIVE'
,p_data_type=>'DATE'
,p_display_sequence=>70
,p_format_mask=>'SINCE'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12616053094375502)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12616688378375508)
,p_name=>'USER_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USER_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(12616581549375507)
,p_region_id=>wwv_flow_imp.id(12615965385375501)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12617166483375513)
,p_plug_name=>'Users List'
,p_static_id=>'users-list_1'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49784640403565108079)
,p_name=>'P1100_SELECTED_ITEM_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(49783912253584175107)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>'Stores the canonical selected-item context used by the detail-region queries. Changes to this item refresh all dependent regions marked with .js-item-refresh.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49779865900549060583)
,p_name=>'P1100_SELECTED_ITEM_ID_UI'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(49783912253584175107)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>'Stores the current primary-key selection maintained by the Content Row component. Changes to this item are synchronized into P1100_SELECTED_ITEM_ID.'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(24903446543551173616)
,p_name=>'Initialize Selection'
,p_static_id=>'initialize-selection'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24903446569738173617)
,p_event_id=>wwv_flow_imp.id(24903446543551173616)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', 'apex.region("list_selection_region").setSelectedValues(["1"]);')).to_clob
);
wwv_flow_imp.component_end;
end;
/
