prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>100
,p_name=>'Dashboards'
,p_alias=>'DASHBOARDS'
,p_step_title=>'Dashboards'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'The Dashboards index is a catalog context page that introduces dashboard patterns and helps users choose an appropriate overview pattern. It is not itself a dashboard pattern to copy.',
'',
'## When to Use',
'',
'Use dashboard patterns when users need to understand status, monitor progress, identify exceptions, or decide where to focus next.',
'',
'## When to Avoid',
'',
'Avoid dashboard patterns when users primarily need to browse individual records, complete data entry, or inspect the full details of a single item.',
'',
'## AI Guidance',
'',
'Treat this page as catalog navigation, not as a dashboard pattern example. Use the linked dashboard pages as implementation references. Preserve the distinction between summary, exception, trend, and follow-up content when adapting dashboard patterns'
||'.'))
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24896409714005562595)
,p_plug_name=>'About'
,p_static_id=>'dashboards'
,p_icon_css_classes=>'fa-mouse-pointer'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Dashboard patterns help users understand status, spot exceptions, and decide where to focus next. Use these examples when a page needs to summarize information across records, categories, or time periods.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24896410432081562602)
,p_plug_name=>'Dashboards'
,p_static_id=>'dashboards_1'
,p_icon_css_classes=>'fa-dashboard'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24896409883404562596)
,p_plug_name=>'Patterns'
,p_static_id=>'patterns'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-dashboard'' as icon_class,',
'    ''Simple Dashboard'' as title,',
'    ''A focused overview with a small set of metrics, supporting summaries, and clear follow-up paths.'' as description,',
'    ''dashboard-simple'' as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-area-chart'' as icon_class,',
'    ''Advanced Dashboard'' as title,',
'    ''A richer dashboard layout for comparing multiple signals, reviewing trends, and balancing summary metrics with deeper supporting detail.'' as description,',
'    ''dashboard-advanced'' as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-line-chart'' as icon_class,',
'    ''Executive Dashboard'' as title,',
'    ''A high-level view for leadership audiences, emphasizing outcomes, trends, risks, and concise status indicators.'' as description,',
'    cast(null as varchar2(100)) as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-tasks'' as icon_class,',
'    ''Operational Dashboard'' as title,',
'    ''A work-focused view for monitoring activity, exceptions, queues, and time-sensitive follow-up.'' as description,',
'    cast(null as varchar2(100)) as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-bar-chart'' as icon_class,',
'    ''Analytical Dashboard'' as title,',
'    ''A data-rich view for exploring trends, comparisons, and performance drivers across dimensions.'' as description,',
'    cast(null as varchar2(100)) as page_alias',
'from sys.dual'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON_CLASS. fa-2x u-opacity-50',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24896410107747562599)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24896409945395562597)
,p_name=>'ICON_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24896410226045562600)
,p_name=>'PAGE_ALIAS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PAGE_ALIAS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24896410074835562598)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(24896410321106562601)
,p_region_id=>wwv_flow_imp.id(24896409883404562596)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'f?p=&APP_ID.:&PAGE_ALIAS.:&SESSION.::&DEBUG.::::'
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'PAGE_ALIAS'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp.component_end;
end;
/
