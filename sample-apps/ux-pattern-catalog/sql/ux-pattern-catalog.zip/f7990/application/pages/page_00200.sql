prompt --application/pages/page_00200
begin
--   Manifest
--     PAGE: 00200
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>200
,p_name=>'Browse and Search'
,p_alias=>'BROWSE-SEARCH'
,p_step_title=>'Browse and Search'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Organize and explain browse and search patterns in the catalog. This is a category context page, not a pattern implementation.',
'',
'## When to Use',
'',
'Use when this page''s primary user task matches the pattern represented by its title and structure.',
'',
'## When to Avoid',
'',
'Avoid when another catalog pattern better supports the user''s task, information density, or workflow complexity.',
'',
'## AI Guidance',
'',
'Preserve the page''s pattern-first structure, generic terminology, accessible labels, semantic formatting, and clear action hierarchy. Keep documentation in metadata rather than visible instructional text.',
'            '))
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24900111498620423514)
,p_plug_name=>'About'
,p_static_id=>'about'
,p_icon_css_classes=>'fa-mouse-pointer'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Browse and search patterns help users find the right record across a larger set of information. These pages demonstrate different ways to support scanning, filtering, comparison, and drill-down depending on how much structure users need and how they '
||'prefer to explore results.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24900114746136425860)
,p_plug_name=>'Browse and Search'
,p_static_id=>'dashboards'
,p_icon_css_classes=>'fa-mouse-pointer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24900111940469424476)
,p_plug_name=>'Patterns'
,p_static_id=>'patterns'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-cards'' as icon_class,',
'    ''Browse - Cards'' as title,',
'    ''A visual browsing pattern for scanning records as distinct items with prominent titles, supporting details, badges, and clear follow-up actions.'' as description,',
'    ''faceted-search-cards'' as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-list-alt'' as icon_class,',
'    ''Browse - Content Row'' as title,',
'    ''A compact list-style pattern for comparing records with consistent summaries, secondary attributes, status indicators, and row-level actions.'' as description,',
'    ''faceted-search-content-row'' as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-table'' as icon_class,',
'    ''Browse - Interactive Report'' as title,',
'    ''A data-dense browsing pattern for users who need sorting, filtering, saved views, column control, and precise comparison across many records.'' as description,',
'    ''browse-interactive-report'' as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-window-search'' as icon_class,',
'    ''Full Page Search'' as title,',
'    ''A focused search pattern that combines search, quick actions, and results in a dedicated full-page experience.'' as description,',
'    ''full-page-search'' as page_alias',
'from sys.dual',
'union all',
'select',
'    ''fa-ai-prompt'' as icon_class,',
'    ''AI Chat'' as title,',
'    ''A full-page conversational pattern for interacting with an AI assistant through messages, prompts, and contextual actions.'' as description,',
'    ''ai-chat'' as page_alias',
'from sys.dual'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON_CLASS. fa-2x u-opacity-50',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24900112164812424479)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24900112002460424477)
,p_name=>'ICON_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON_CLASS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24900112283110424480)
,p_name=>'PAGE_ALIAS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PAGE_ALIAS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24900112131900424478)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(24900112378171424481)
,p_region_id=>wwv_flow_imp.id(24900111940469424476)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'f?p=&APP_ID.:&PAGE_ALIAS.:&SESSION.::&DEBUG.::::'
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'PAGE_ALIAS'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp.component_end;
end;
/
