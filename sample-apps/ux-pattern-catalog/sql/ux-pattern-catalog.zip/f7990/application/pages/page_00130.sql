prompt --application/pages/page_00130
begin
--   Manifest
--     PAGE: 00130
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>130
,p_name=>unistr('Dashboard \2013\00A0Executive')
,p_alias=>'DASHBOARD-EXECUTIVE'
,p_step_title=>unistr('Dashboard \2013\00A0Executive')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Scope metric-card layout adjustments to Metric Card regions. */',
'.app-MetricCards .t-MetricCard { flex-wrap: wrap; }',
'.app-MetricCards .t-MetricCard-badge { margin-left: auto; }'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Provides an executive dashboard that brings the most important revenue, pipeline, regional, and operating-status measures into one decision-oriented view.',
'',
'## When to Use',
'',
'Use when leaders need a concise overview before drilling into operational detail. Combine a small set of comparable KPIs with charts that explain performance against targets, pipeline progression, and regional variation.',
'',
'## When to Avoid',
'',
'Avoid when users need to inspect transactions, edit records, or perform detailed analysis. Provide a report or task page for those workflows instead.',
'',
'## AI Guidance',
'',
'Replace the sample SQL with governed business measures, keep periods and units consistent across regions, and connect the time-range item and detail links to real filters and drill-down pages. Preserve the hierarchy: KPI cards first, then diagnostic '
||'charts and status context.'))
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5886527581756526)
,p_plug_name=>'Actual vs Target Series'
,p_static_id=>'actual-vs-target-series'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with quarterly_revenue as (',
'    select 1 as quarter_order,',
'           ''Q1 ''''26'' as quarter_label,',
'           214.0 as actual_revenue,',
'           215.0 as target_revenue',
'    from dual',
'',
'    union all',
'',
'    select 2,',
'           ''Q2 ''''26'',',
'           229.3,',
'           234.0',
'    from dual',
'',
'    union all',
'',
'    select 3,',
'           ''Q3 ''''26'',',
'           165.0,',
'           165.0',
'    from dual',
'',
'    union all',
'',
'    select 4,',
'           ''Q4 ''''26'',',
'           cast(null as number) as actual_revenue,',
'           171.0',
'    from dual',
'),',
'chart_data as (',
'    select',
'        quarter_order,',
'        quarter_label,',
'        ''Actual'' as series_name,',
'        actual_revenue as value,',
'        actual_revenue,',
'        target_revenue,',
'        case',
'            when actual_revenue is null then ''In progress''',
'            when actual_revenue >= target_revenue then ''Met target''',
'            else ''Below target''',
'        end as performance_status',
'    from quarterly_revenue',
'',
'    union all',
'',
'    select',
'        quarter_order,',
'        quarter_label,',
'        ''Target'' as series_name,',
'        target_revenue as value,',
'        actual_revenue,',
'        target_revenue,',
'        case',
'            when actual_revenue is null then ''In progress''',
'            when actual_revenue >= target_revenue then ''Met target''',
'            else ''Below target''',
'        end as performance_status',
'    from quarterly_revenue',
')',
'select',
'    quarter_order,',
'    quarter_label,',
'    series_name,',
'    value,',
'    actual_revenue,',
'    target_revenue,',
'    performance_status,',
'    quarter_label || chr(10) ||',
'    ''Target  $'' || to_char(target_revenue, ''FM999G990D0'') || ''M'' || chr(10) ||',
'    case',
'        when actual_revenue is null then ''Actual  In progress''',
'        else ''Actual  $'' || to_char(actual_revenue, ''FM999G990D0'') || ''M''',
'    end as tooltip_text',
'from chart_data',
'order by',
'    quarter_order,',
'    case series_name',
'        when ''Actual'' then 1',
'        when ''Target'' then 2',
'    end;'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'QUARTER_ORDER'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Compares actual and target revenue by quarter so executives can identify the size and direction of performance gaps.',
'Pattern role: Revenue performance comparison.',
'AI guidance: Use a common currency and period grain for both series. Keep the actual and target series visually distinct, and provide a drill-down when a gap requires investigation.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(5886637819756527)
,p_region_id=>wwv_flow_imp.id(5886527581756526)
,p_chart_type=>'bar'
,p_height=>'250'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'N'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_overview_rendered=>'off'
,p_time_axis_type=>'disabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6307984047348634)
,p_chart_id=>wwv_flow_imp.id(5886637819756527)
,p_static_id=>'revenue'
,p_seq=>40
,p_name=>'Revenue'
,p_location=>'REGION_SOURCE'
,p_series_type=>'bar'
,p_series_name_column_name=>'SERIES_NAME'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'QUARTER_LABEL'
,p_items_short_desc_column_name=>'TOOLTIP_TEXT'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_required_patch=>wwv_flow_imp.id(24910758457553178721)
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(5886798315756528)
,p_chart_id=>wwv_flow_imp.id(5886637819756527)
,p_static_id=>'series-1_1'
,p_seq=>20
,p_name=>'Actual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH quarterly_revenue AS (',
'    SELECT 1 AS quarter_order,',
'           ''Q1 ''''26'' AS quarter_label,',
'           214.0 AS actual_revenue,',
'           215.0 AS target_revenue',
'    FROM dual',
'',
'    UNION ALL',
'    SELECT 2, ''Q2 ''''26'', 229.3, 234.0 FROM dual',
'',
'    UNION ALL',
'    SELECT 3, ''Q3 ''''26'', 165.0, 165.0 FROM dual',
'',
'    UNION ALL',
'    SELECT 4, ''Q4 ''''26'', CAST(NULL AS NUMBER), 171.0 FROM dual',
')',
'SELECT',
'    quarter_order,',
'    quarter_label,',
'    actual_revenue AS value,',
'',
'    quarter_label || CHR(10) ||',
'    ''Revenue  $'' || TO_CHAR(target_revenue, ''FM999G990D0'') || ''M'' ||',
'    CHR(10) ||',
'    CASE',
'        WHEN actual_revenue IS NULL THEN ''Actual  In progress''',
'        ELSE ''Actual  $'' || TO_CHAR(actual_revenue, ''FM999G990D0'') || ''M''',
'    END AS tooltip_text',
'',
'FROM quarterly_revenue',
'WHERE actual_revenue IS NOT NULL',
'ORDER BY quarter_order;'))
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'QUARTER_LABEL'
,p_color=>'#3f8efc'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6307743042348632)
,p_chart_id=>wwv_flow_imp.id(5886637819756527)
,p_static_id=>'target'
,p_seq=>10
,p_name=>'Target'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH quarterly_revenue AS (',
'    SELECT 1 AS quarter_order,',
'           ''Q1 ''''26'' AS quarter_label,',
'           214.0 AS actual_revenue,',
'           215.0 AS target_revenue',
'    FROM dual',
'',
'    UNION ALL',
'    SELECT 2, ''Q2 ''''26'', 229.3, 234.0 FROM dual',
'',
'    UNION ALL',
'    SELECT 3, ''Q3 ''''26'', 165.0, 165.0 FROM dual',
'',
'    UNION ALL',
'    SELECT 4, ''Q4 ''''26'', CAST(NULL AS NUMBER), 171.0 FROM dual',
')',
'SELECT',
'    quarter_order,',
'    quarter_label,',
'    target_revenue AS value,',
'',
'    quarter_label || CHR(10) ||',
'    ''Revenue  $'' || TO_CHAR(target_revenue, ''FM999G990D0'') || ''M'' ||',
'    CHR(10) ||',
'    CASE',
'        WHEN actual_revenue IS NULL THEN ''Actual  In progress''',
'        ELSE ''Actual  $'' || TO_CHAR(actual_revenue, ''FM999G990D0'') || ''M''',
'    END AS tooltip_text',
'',
'FROM quarterly_revenue',
'ORDER BY quarter_order;'))
,p_series_type=>'bar'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'QUARTER_LABEL'
,p_color=>'#8f99a8'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(5886939212756530)
,p_chart_id=>wwv_flow_imp.id(5886637819756527)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'inside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(5887072016756531)
,p_chart_id=>wwv_flow_imp.id(5886637819756527)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>0
,p_numeric_pattern=>'$#M'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24904482465466374288)
,p_plug_name=>'Pipeline Funnel'
,p_static_id=>'chart-4_1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    1 seq,',
'    ''Awareness'' label,',
'    48200 as value',
'from sys.dual',
'union all',
'select 2, ''Leads'', 12400 from sys.dual',
'union all',
'select 3, ''Qualified'', 4800 from sys.dual',
'union all',
'select 4, ''Proposals'', 1920 from sys.dual',
'union all',
'select 5, ''Closed Won'', 480 from sys.dual'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Shows how opportunities narrow from awareness through closed-won so executives can see conversion and stage drop-off.',
'Pattern role: Sales pipeline funnel.',
'AI guidance: Order stages from broadest to narrowest, use mutually exclusive stage counts, and keep the funnel focused on a single pipeline definition. Pair it with a detail link when users need to investigate a stage.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(5925080047018970)
,p_region_id=>wwv_flow_imp.id(24904482465466374288)
,p_chart_type=>'funnel'
,p_title=>'Opportunities Conversion'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ) {',
'',
'    options.styleDefaults = $.extend( true, {}, options.styleDefaults, {',
'        colors: [',
'            ''rgba(66, 81, 191, 0.5)'',',
'            ''rgba(95, 185, 181, 0.5)''',
'        ]',
'    });',
'',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(5926733841018970)
,p_chart_id=>wwv_flow_imp.id(5925080047018970)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Opportunities Conversion'
,p_location=>'REGION_SOURCE'
,p_series_type=>'funnel'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24922312659672286434)
,p_plug_name=>'Executive Dashboard'
,p_static_id=>'dashboard-title'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'One line dashboard description.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Establishes the Executive Dashboard context and holds its time-range control and page-level actions.',
'Pattern role: Executive dashboard header and action container.',
'AI guidance: Keep the visible description concise and business-focused. Place only actions that apply to the dashboard as a whole here; keep implementation guidance in component comments rather than in the visible region.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24922311808752286425)
,p_plug_name=>'Metric Cards'
,p_static_id=>'metric-cards'
,p_region_css_classes=>'app-MetricCards'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''fa-line-chart''    icon,',
'    ''Primary KPI''      label,',
'    84200              metric_value,',
'    ''Trend''            badge,',
'    ''+12%''             badge_value,',
'    ''success''          badge_state,',
'    ''fa-trend-up''      badge_icon',
'from sys.dual',
'union all',
'select',
'    ''fa-bar-chart''     icon,',
'    ''Secondary KPI''    label,',
'    12800              metric_value,',
'    ''Trend''            badge,',
'    ''+320 units''       badge_value,',
'    ''success''          badge_state,',
'    ''fa-trend-up''      badge_icon',
'from sys.dual',
'union all',
'select',
'    ''fa-area-chart''    icon,',
'    ''Trend KPI''        label,',
'    64                 metric_value,',
'    ''Trend''            badge,',
'    ''20m faster''       badge_value,',
'    ''success''          badge_state,',
'    ''fa-trend-up''      badge_icon',
'from sys.dual',
'union all',
'select',
'    ''fa-dashboard''     icon,',
'    ''Status KPI''       label,',
'    348                metric_value,',
'    ''Trend''            badge,',
'    ''-14 items''        badge_value,',
'    ''danger''           badge_state,',
'    ''fa-trend-down''    badge_icon',
'from sys.dual'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'BADGE_VALUE'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$METRIC_CARD'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AVATAR_ALIGNMENT', 't-MetricCard-body--avatarAlignmentStart',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_POSITION', 't-MetricCard-body--avatarPositionInline',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_STYLE', 't-MetricCard-avatar--subtle',
  'AVATAR_TYPE', 'icon',
  'BADGE_ICON', '&BADGE_ICON.',
  'BADGE_LABEL', 'Trend',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_SHAPE', 't-Badge--rounded',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'BADGE_VALUE',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'LAYOUT', '4cols',
  'META', '&LABEL.',
  'METRIC', '&METRIC_VALUE.',
  'METRIC_CSS_CLASSES', 'u-text-subheading-md')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Presents the executive KPIs that should be scanned before reviewing the revenue, pipeline, and regional charts.',
'Pattern role: Primary KPI summary.',
'AI guidance: Keep metrics comparable in importance. Badge value, badge state, and badge icon should be semantically aligned. Format key values for quick scanning and avoid turning this region into a dense report.',
'Implementation note: The app-MetricCards CSS class scopes page-level CSS to this region.'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24922312218764286430)
,p_name=>'BADGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24922312523379286433)
,p_name=>'BADGE_ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24922312420190286432)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24922312346380286431)
,p_name=>'BADGE_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_VALUE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24922311876581286426)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24922312050913286428)
,p_name=>'LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LABEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24922312192806286429)
,p_name=>'METRIC_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'METRIC_VALUE'
,p_data_type=>'NUMBER'
,p_display_sequence=>40
,p_format_mask=>'999G999G999G999G999G999G990'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49804907395986646097)
,p_plug_name=>'Status List'
,p_static_id=>'pattern-status-list'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''Revenue Report''      as title,',
'    ''-4% vs target''       as description,',
'    ''fa-tasks-alt''        as icon,',
'    ''Off Track''           as badge,',
'    ''danger''              as badge_state',
'from sys.dual',
'union all',
'select',
'    ''Q4 Pipeline''         as title,',
'    ''Below 2x floor''      as description,',
'    ''fa-search''           as icon,',
'    ''Off Track''           as badge,',
'    ''danger''              as badge_state',
'from sys.dual',
'union all',
'select',
'    ''Pipeline Ratio''      as title,',
'    ''Needs acceleration''  as description,',
'    ''fa-cogs''             as icon,',
'    ''At Risk''             as badge,',
'    ''warning''             as badge_state',
'from sys.dual',
'union all',
'select',
'    ''Gross Margin''        as title,',
'    ''Improved 1.2 points'' as description,',
'    ''fa-file-text-o''      as icon,',
'    ''On Track''            as badge,',
'    ''success''             as badge_state',
'from sys.dual',
'union all',
'select',
'    ''Customers''           as title,',
'    ''Trending up''         as description,',
'    ''fa-user-check''       as icon,',
'    ''On track''            as badge,',
'    ''success''             as badge_state',
'from sys.dual;'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', '&ICON. fa-lg',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'BADGE_ALIGNMENT', 't-ContentRow-badge--alignCenter',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', 'Badge',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_POS', 't-ContentRow-badge--posEnd',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'BADGE',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&TITLE.')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrates a status list for summarizing the condition of several related parts of a record, process, or application area. Each row combines a clear label, brief explanation, supporting icon, and semantic status badge.',
'',
'## When to Use',
'',
'Use when users need to scan a small set of related checks, requirements, stages, or system conditions and quickly identify what is complete, in progress, available, or requires attention.',
'',
'## When to Avoid',
'',
'Avoid when users need to compare many records, analyze status trends, or act on a complex workflow. Use a report, chart, timeline, or task-oriented view instead.',
'',
'## AI Guidance',
'',
'Keep all rows within one coherent status context. Use concise titles for the item being evaluated and descriptions that explain the meaning or consequence of its current state. Apply semantic badge states consistently: success for positive completion'
||', warning for incomplete or pending work, danger for blockers or required action, and info for neutral availability or context.',
'',
'Use icons to reinforce the item or status, but do not rely on color or icons alone. Order rows by importance when exceptions require attention; otherwise, follow the natural sequence of the process or information.',
''))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49804908292713646106)
,p_name=>'BADGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49804908419424646107)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49804908106850646104)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49804908216001646105)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(49804907957071646103)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(49786697771323922846)
,p_region_id=>wwv_flow_imp.id(49804907395986646097)
,p_position_id=>350199314123390058
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24904483014448374293)
,p_plug_name=>'Regional Revenue Ranking'
,p_static_id=>'stock-chart'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>70
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 sort_order,',
'       ''North America'' label,',
'       38.4 actual_value,',
'       40.0 target_value',
'from sys.dual',
'union all',
'select 2, ''EMEA'', 22.1, 23.5',
'from sys.dual',
'union all',
'select 3, ''APAC'', 14.8, 16.0',
'from sys.dual',
'union all',
'select 4, ''Latin America'', 6.2, 5.5',
'from sys.dual',
'union all',
'select 5, ''MENA'', 2.7, 3.1',
'from sys.dual',
'order by sort_order'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Compares actual and target revenue by sales region to expose where geographic performance is above or below plan.',
'Pattern role: Regional revenue ranking and target comparison.',
'AI guidance: Rank regions consistently, use one currency and period, and retain both actual and target values so the comparison remains actionable. Do not use financial OHLC guidance for this combo chart.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(5945907702018981)
,p_region_id=>wwv_flow_imp.id(24904483014448374293)
,p_chart_type=>'combo'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_fill_multi_series_gaps=>false
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (options) {',
'    options.styleDefaults = $.extend(true, {}, options.styleDefaults, {',
'        colors: [',
'            ''rgba(66, 81, 191, 0.5)'' // Actual revenue color',
'        ],',
'        maxBarWidth: 15',
'    });',
'',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(5947669885018982)
,p_chart_id=>wwv_flow_imp.id(5945907702018981)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Actual Revenue'
,p_location=>'REGION_SOURCE'
,p_series_type=>'bar'
,p_items_value_column_name=>'ACTUAL_VALUE'
,p_items_label_column_name=>'LABEL'
,p_line_style=>'solid'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'insideBarEdge'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6055957791169718)
,p_chart_id=>wwv_flow_imp.id(5945907702018981)
,p_static_id=>'target-revenue-series'
,p_seq=>20
,p_name=>'Target Revenue'
,p_location=>'REGION_SOURCE'
,p_series_type=>'line'
,p_items_value_column_name=>'TARGET_VALUE'
,p_items_label_column_name=>'LABEL'
,p_color=>'#8f99a8'
,p_line_style=>'solid'
,p_line_type=>'none'
,p_marker_rendered=>'on'
,p_marker_shape=>'diamond'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(5946423876018981)
,p_chart_id=>wwv_flow_imp.id(5945907702018981)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(5947030766018982)
,p_chart_id=>wwv_flow_imp.id(5945907702018981)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'off'
,p_format_type=>'currency'
,p_decimal_places=>1
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24922437862076930333)
,p_plug_name=>'Revenue Trend Series'
,p_static_id=>'time-series'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>40
,p_plug_grid_column_span=>8
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Shows actual and target revenue over time as a second executive trend view.',
'Pattern role: Revenue trend comparison.',
'AI guidance: Use the same period definition and value formatting as the primary revenue chart. Include this region only when the additional trend perspective supports a distinct executive question.'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(5948761999018982)
,p_region_id=>wwv_flow_imp.id(24922437862076930333)
,p_chart_type=>'line'
,p_height=>'250'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_fill_multi_series_gaps=>false
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_time_axis_type=>'enabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(5950402647018983)
,p_chart_id=>wwv_flow_imp.id(5948761999018982)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Actual'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH revenue_data AS (',
'    SELECT DATE ''2026-01-01'' AS month_date, 68.2 AS actual_value FROM dual',
'    UNION ALL SELECT DATE ''2026-02-01'', 71.4 FROM dual',
'    UNION ALL SELECT DATE ''2026-03-01'', 74.8 FROM dual',
'    UNION ALL SELECT DATE ''2026-04-01'', 73.1 FROM dual',
'    UNION ALL SELECT DATE ''2026-05-01'', 76.9 FROM dual',
'    UNION ALL SELECT DATE ''2026-06-01'', 79.3 FROM dual',
'    UNION ALL SELECT DATE ''2026-07-01'', 81.6 FROM dual',
'    UNION ALL SELECT DATE ''2026-08-01'', 84.2 FROM dual',
')',
'SELECT',
'    month_date,',
'    TO_CHAR(',
'        month_date,',
'        ''FMMon'',',
'        ''NLS_DATE_LANGUAGE=English''',
'    ) AS month_label,',
'    actual_value AS value',
'FROM revenue_data',
'ORDER BY month_date;'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'MONTH_DATE'
,p_color=>'#3f8efc'
,p_line_style=>'solid'
,p_line_width=>2
,p_line_type=>'curved'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(5951077854018983)
,p_chart_id=>wwv_flow_imp.id(5948761999018982)
,p_static_id=>'series-2'
,p_seq=>20
,p_name=>'Target'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH revenue_data AS (',
'    SELECT DATE ''2026-01-01'' AS month_date, 70 AS target_value FROM dual',
'    UNION ALL SELECT DATE ''2026-02-01'', 72 FROM dual',
'    UNION ALL SELECT DATE ''2026-03-01'', 74 FROM dual',
'    UNION ALL SELECT DATE ''2026-04-01'', 76 FROM dual',
'    UNION ALL SELECT DATE ''2026-05-01'', 78 FROM dual',
'    UNION ALL SELECT DATE ''2026-06-01'', 80 FROM dual',
'    UNION ALL SELECT DATE ''2026-07-01'', 82 FROM dual',
'    UNION ALL SELECT DATE ''2026-08-01'', 84 FROM dual',
')',
'SELECT',
'    month_date,',
'    TO_CHAR(',
'        month_date,',
'        ''FMMon'',',
'        ''NLS_DATE_LANGUAGE=English''',
'    ) AS month_label,',
'    target_value AS value',
'FROM revenue_data',
'ORDER BY month_date;'))
,p_series_type=>'line'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'MONTH_DATE'
,p_color=>'#8f99a8'
,p_line_style=>'dashed'
,p_line_width=>2
,p_line_type=>'curved'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(5949254970018983)
,p_chart_id=>wwv_flow_imp.id(5948761999018982)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'inside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(5949824043018983)
,p_chart_id=>wwv_flow_imp.id(5948761999018982)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_min=>65
,p_max=>85
,p_format_type=>'currency'
,p_decimal_places=>0
,p_numeric_pattern=>'$#M'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5936517203018976)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(24922312659672286434)
,p_button_name=>'ACTIONS_MENU'
,p_static_id=>'actions-menu'
,p_show_as_disabled=>false
,p_button_type=>'MENU'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Actions Menu'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ellipsis-v'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Groups lower-frequency or optional page actions.',
'Pattern role: Overflow actions.',
'AI guidance: Use for actions that should remain available without competing with primary and secondary actions.'))
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24922379946730286493)
,p_button_id=>wwv_flow_imp.id(5936517203018976)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 1'
,p_static_id=>'menu-action-a'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24922380022121286494)
,p_button_id=>wwv_flow_imp.id(5936517203018976)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 2'
,p_static_id=>'menu-action-b'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(24922380134292286495)
,p_button_id=>wwv_flow_imp.id(5936517203018976)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Action 3'
,p_static_id=>'menu-action-c'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5938122117018977)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24922312659672286434)
,p_button_name=>'PRIMARY_ACTION'
,p_static_id=>'primary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Primary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Represents the main follow-up action from the Executive Dashboard overview.',
'Pattern role: Primary page action.',
'AI guidance: Keep prominent. Use a domain-specific label only when adapting this pattern to a real application.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5938532260018977)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(24922312659672286434)
,p_button_name=>'SECONDARY_ACTION'
,p_static_id=>'secondary-action'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Secondary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Represents a useful but lower-priority follow-up action.',
'Pattern role: Secondary page action.',
'AI guidance: Keep visually subordinate to the primary action.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5927461165018970)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24904482465466374288)
,p_button_name=>'VIEW_DETAILS_LINK'
,p_static_id=>'view-details-link-3'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'View Report'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'#'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-right'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides a direct path from the comparison chart to supporting detail.',
'Pattern role: Region-level detail action.',
'AI guidance: Use text-link detail actions when the drill-down is a common analytical follow-up.'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6055851833169717)
,p_name=>'P130_TIME_RANGE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(24922312659672286434)
,p_item_display_point=>'NEXT'
,p_prompt=>'Time Range'
,p_source=>'YEAR'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:MTD;MONTH,QTD;QUARTER,YTD;YEAR'
,p_field_template=>2042262243893469891
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Lets an executive choose the reporting period used by the dashboard.',
'Pattern role: Dashboard-wide time filter.',
'Implementation guidance: Bind this item to every affected region query and refresh those regions on change. The sample regions currently use static data, so changing this item does not alter them until the queries are made period-aware.'))
);
wwv_flow_imp.component_end;
end;
/
