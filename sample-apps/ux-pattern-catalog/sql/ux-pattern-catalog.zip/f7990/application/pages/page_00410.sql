prompt --application/pages/page_00410
begin
--   Manifest
--     PAGE: 00410
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>410
,p_name=>unistr('Data Entry \2013\00A0Simple Form')
,p_alias=>'DATA-ENTRY-SIMPLE-FORM'
,p_step_title=>unistr('Data Entry \2013\00A0Simple Form')
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.app-Form .t-ContentBlock--h3 {',
'    --ut-content-block-header-font-size: 1rem;',
'}'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Purpose',
'',
'Demonstrate a focused form for entering a small, straightforward set of related fields.',
'',
'## When to Use',
'',
'Use when users can complete the task in one pass and do not need a long workflow or extensive surrounding context.',
'',
'## When to Avoid',
'',
'Avoid when the form has many sections, complex dependencies, or requires a guided sequence.',
'',
'## AI Guidance',
'',
'Order fields by the user''s task, group related inputs, keep inline help brief, and provide one clear primary submit action. Preserve accessible validation and generic sample data.',
'            '))
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24893204511577167064)
,p_plug_name=>'Basic Fields'
,p_static_id=>'basic-fields-container'
,p_parent_plug_id=>wwv_flow_imp.id(24902288918258790677)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<p>Start with the fields users complete first.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Introduces the fields users complete first in the simple entry task.',
'Pattern role: Primary form section.',
'AI guidance: Keep this section focused on the minimum information needed to begin. Order fields by task sequence and avoid adding unrelated inputs.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24893203892250167058)
,p_plug_name=>'Buttons Container'
,p_static_id=>'buttons-container_1'
,p_parent_plug_id=>wwv_flow_imp.id(24902288918258790677)
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>60
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24893203824942167057)
,p_plug_name=>unistr('Data Entry \2013\00A0Simple Form')
,p_static_id=>'data-entry-simple-form'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Provides the context and title for the focused form experience.',
'Pattern role: Form context and heading.',
'AI guidance: Keep the heading concise and production-like. Do not use this region for visible pattern documentation.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24902288918258790677)
,p_plug_name=>'Edit Form'
,p_static_id=>'form'
,p_region_css_classes=>'app-Form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>'SAMPLE_DATA'
,p_query_table=>'EMPLOYEES'
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Collects a small, related set of values in one focused interaction.',
'Pattern role: Simple data-entry form.',
'AI guidance: Group related fields, keep the form compact, provide meaningful validation, and maintain one clear primary submit action.'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24902360093057376551)
,p_plug_name=>'Field Guidance'
,p_static_id=>'organization'
,p_parent_plug_id=>wwv_flow_imp.id(24902288918258790677)
,p_icon_css_classes=>'fa-briefcase fa-2x u-opacity-50'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<p>Keep inline help brief and reserve help dialogs for additional context.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Intent: Demonstrates how brief contextual guidance can support form completion.',
'Pattern role: Inline-help support section.',
'AI guidance: Keep inline help short and task-specific. Reserve longer explanations or reference material for a help dialog or external documentation.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24893203987573167059)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(24893203892250167058)
,p_button_name=>'PRIMARY_ACTION'
,p_static_id=>'apply'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Primary Action'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24893204033126167060)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(24893203824942167057)
,p_button_name=>'BACK'
,p_static_id=>'cancel'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Back'
,p_button_position=>'UP'
,p_icon_css_classes=>'fa-chevron-left'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24893204190523167061)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(24893203892250167058)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel_1'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--noUI:t-Button--gapRight'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24902304276624790708)
,p_name=>'P410_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(24893204511577167064)
,p_item_source_plug_id=>wwv_flow_imp.id(24902288918258790677)
,p_prompt=>'Email'
,p_source=>'EMAIL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>267
,p_field_template=>1610598304472262251
,p_item_icon_css_classes=>'fa-envelope-o'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'EMAIL',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24902310739119790718)
,p_name=>'P410_FIELD_HELP'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(24902360093057376551)
,p_item_source_plug_id=>wwv_flow_imp.id(24902288918258790677)
,p_prompt=>'Help Dialog'
,p_source=>'MANAGERNO'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Manager A;A,Manager B;B'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_help_text=>'Use contextual help for information that is useful but not required during every interaction. This may include field definitions, formatting rules, business guidance, examples, or links to related documentation. Keep dialog help concise and focused o'
||'n helping users complete the current task.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24902295280910790695)
,p_name=>'P410_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(24902288918258790677)
,p_item_source_plug_id=>wwv_flow_imp.id(24902288918258790677)
,p_source=>'ID'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24902381469481376587)
,p_name=>'P410_INLINE_HELP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(24902360093057376551)
,p_item_source_plug_id=>wwv_flow_imp.id(24902288918258790677)
,p_prompt=>'Inline Help'
,p_source=>'JOB'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Job A;A,Job B;B'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_inline_help_text=>'Brief guidance that remains visible while users complete this field.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24902310176955790712)
,p_name=>'P410_JOB'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(24893204511577167064)
,p_item_source_plug_id=>wwv_flow_imp.id(24902288918258790677)
,p_prompt=>'Job Code'
,p_source=>'JOB'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Job A;A,Job B;B'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_inline_help_text=>'Choose the standardized job code used by your organization.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24902304185497790707)
,p_name=>'P410_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(24893204511577167064)
,p_item_source_plug_id=>wwv_flow_imp.id(24902288918258790677)
,p_prompt=>'Name'
,p_source=>'NAME'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>1610598484065263269
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24893204271591167062)
,p_name=>'P410_NOTES'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(24893204511577167064)
,p_prompt=>'Notes'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24902298600146790705)
,p_name=>'P410_SALARY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(24893204511577167064)
,p_item_source_plug_id=>wwv_flow_imp.id(24902288918258790677)
,p_prompt=>'Salary'
,p_post_element_text=>'USD'
,p_source=>'SALARY'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--postTextBlock'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24902369621278376577)
,p_name=>'P410_START_DATE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(24893204511577167064)
,p_item_source_plug_id=>wwv_flow_imp.id(24902288918258790677)
,p_prompt=>'Start Date'
,p_source=>'WORK_MODE'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_cMaxlength=>25
,p_begin_on_new_line=>'N'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(24896658614680311130)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(24902288918258790677)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Drawer Form'
,p_static_id=>'initialize-form-drawer-form'
,p_internal_uid=>3717724488007248
);
wwv_flow_imp.component_end;
end;
/
