prompt --application/shared_components/navigation/lists/item_details_side_actions
begin
--   Manifest
--     LIST: Item Details - Side Actions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4079163859071378)
,p_name=>'Item Details - Side Actions'
,p_static_id=>'item-details-side-actions'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4094940030478135)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Delete'
,p_static_id=>'delete'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-trash-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4079714238071383)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Duplicate'
,p_static_id=>'duplicate'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-copy'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4079321758071380)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Edit'
,p_static_id=>'edit'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-edit'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4080524437071384)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Export'
,p_static_id=>'export'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-download'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4080100347071383)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Share'
,p_static_id=>'share'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-share-alt'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4080943971071384)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Watch Changes'
,p_static_id=>'watch-changes'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-eye'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
