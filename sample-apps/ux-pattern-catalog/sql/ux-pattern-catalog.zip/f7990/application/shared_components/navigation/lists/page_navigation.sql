prompt --application/shared_components/navigation/lists/page_navigation
begin
--   Manifest
--     LIST: Page Navigation
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(24910785523392178822)
,p_name=>'Page Navigation'
,p_static_id=>'page-navigation'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24896424178098817686)
,p_list_item_display_sequence=>2
,p_list_item_link_text=>'Browse and Seach'
,p_static_id=>'browse-and-seach'
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-mouse-pointer'
,p_list_text_01=>'Help users discover, filter, compare, and open records using cards, lists, reports, and search-oriented layouts.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24896423307130795934)
,p_list_item_display_sequence=>1
,p_list_item_link_text=>'Dashboards'
,p_static_id=>'dashboards'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-dashboard'
,p_list_text_01=>'Summarize key information, highlight status, and guide users toward high-value follow-up actions.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24896424860396817687)
,p_list_item_display_sequence=>4
,p_list_item_link_text=>'Data Entry'
,p_static_id=>'data-entry'
,p_list_item_link_target=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-forms'
,p_list_text_01=>'Guide users through creating or changing information with forms, dialogs, drawers, and wizards.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24896424452041817686)
,p_list_item_display_sequence=>3
,p_list_item_link_text=>'Item Details'
,p_static_id=>'item-details'
,p_list_item_link_target=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-id-card-o'
,p_list_text_01=>'Present a single record with the right balance of summary, supporting detail, and related information.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24896425280909822674)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'Master Detail'
,p_static_id=>'master-detail'
,p_list_item_link_target=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-files-o'
,p_list_text_01=>'Show parent-child relationships where users need context, comparison, and focused detail editing.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
