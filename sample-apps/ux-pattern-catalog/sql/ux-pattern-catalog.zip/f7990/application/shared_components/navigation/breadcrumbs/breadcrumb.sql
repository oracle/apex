prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(21567282236407898)
,p_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5856798503483162)
,p_short_name=>'Faceted Search'
,p_static_id=>'faceted-search'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(21567458836407899)
,p_short_name=>'Home'
,p_static_id=>'home'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5974701593593702)
,p_parent_id=>wwv_flow_imp.id(21593337378407986)
,p_short_name=>'Interactive Report'
,p_static_id=>'interactive-report'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(21593337378407986)
,p_short_name=>'Reports'
,p_static_id=>'reports'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(21591628688407985)
,p_short_name=>'Simple Dashboard'
,p_static_id=>'simple-dashboard'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.'
,p_page_id=>2
);
wwv_flow_imp.component_end;
end;
/
