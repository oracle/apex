prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(24910759108528178725)
,p_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12705820107967530)
,p_parent_id=>wwv_flow_imp.id(12647400082564890)
,p_short_name=>'Cards'
,p_static_id=>'cards'
,p_link=>'f?p=&APP_ID.:1110:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12647400082564890)
,p_short_name=>'Component Primitives'
,p_static_id=>'component-primitives'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12647615826566418)
,p_parent_id=>wwv_flow_imp.id(12647400082564890)
,p_short_name=>'Content Rows'
,p_static_id=>'content-rows'
,p_link=>'f?p=&APP_ID.:1100:&SESSION.::&DEBUG.:::'
,p_page_id=>1100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24895048624795253989)
,p_short_name=>'Faceted Search'
,p_static_id=>'faceted-search'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24910759285128178726)
,p_short_name=>'Home'
,p_static_id=>'home'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24895166527885364529)
,p_parent_id=>wwv_flow_imp.id(24910785163670178813)
,p_short_name=>'Interactive Report'
,p_static_id=>'interactive-report'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6254445849876009)
,p_parent_id=>wwv_flow_imp.id(12647400082564890)
,p_short_name=>'Metrics'
,p_static_id=>'metrics'
,p_link=>'f?p=&APP_ID.:1120:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1120
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24910785163670178813)
,p_short_name=>'Reports'
,p_static_id=>'reports'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24910783454980178812)
,p_short_name=>'Simple Dashboard'
,p_static_id=>'simple-dashboard'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.'
,p_page_id=>2
);
wwv_flow_imp.component_end;
end;
/
