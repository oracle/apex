prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(24910759632250178728)
,p_name=>'Navigation Menu'
,p_static_id=>'navigation-menu'
,p_version_scn=>'SH256:NGjPdCI_sz4uNUZn_Z53DhYCevKq2ANZmWShMzqghVA'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24893314526602533122)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Reference'
,p_static_id=>'about'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-book'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24896043088058422659)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Browse \2013\00A0Cards')
,p_static_id=>'browse-cards'
,p_list_item_link_target=>'f?p=&APP_ID.:210:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(24910783800398178812)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24895047684562253975)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('Browse \2013\00A0Content Row')
,p_static_id=>'browse-content-row'
,p_list_item_link_target=>'f?p=&APP_ID.:220:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(24910783800398178812)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4277019788119080)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'Tree Selection'
,p_static_id=>'browse-tree'
,p_list_item_link_target=>'f?p=&APP_ID.:240:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(24896254309195707236)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'240'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24893110015078206832)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>'Cards'
,p_static_id=>'cards'
,p_list_item_link_target=>'f?p=&APP_ID.:1110:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cards'
,p_parent_list_item_id=>wwv_flow_imp.id(24892181762206866583)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24895259358740983271)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Advanced'
,p_static_id=>'complex-dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(24910790791280181782)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24892181762206866583)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Component Primitives'
,p_static_id=>'component-primitives'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-shapes'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24892970063872200993)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Content Rows'
,p_static_id=>'content-rows'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-media-list'
,p_parent_list_item_id=>wwv_flow_imp.id(24892181762206866583)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24910790791280181782)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Dashboards'
,p_static_id=>'dashboards'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-dashboard'
,p_parent_list_item_id=>wwv_flow_imp.id(24893313173126473415)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24896254725756707237)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Data Entry'
,p_static_id=>'data-entry'
,p_list_item_link_target=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-forms'
,p_parent_list_item_id=>wwv_flow_imp.id(24893313173126473415)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24896401988733868678)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>unistr('Data Entry \2013\00A0Drawer Form')
,p_static_id=>'data-entry-drawer-form'
,p_list_item_link_target=>'f?p=&APP_ID.:420:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(24896254725756707237)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24893249327960458055)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>unistr('Data Entry \2013 Simple Form')
,p_static_id=>'data-entry-simple-form'
,p_list_item_link_target=>'f?p=&APP_ID.:410:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(24896254725756707237)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24910770977958178794)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Getting Started'
,p_static_id=>'home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-mouse-pointer'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24895165568028364524)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Browse - Interactive Report'
,p_static_id=>'interactive-report'
,p_list_item_link_target=>'f?p=&APP_ID.:230:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(24910783800398178812)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24893173165345352116)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>unistr('Item Detail \2013\00A0Full')
,p_static_id=>'item-detail-full'
,p_list_item_link_target=>'f?p=&APP_ID.:320:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(24896254309195707236)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24896678839683699262)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>unistr('Item Detail \2013\00A0Summary')
,p_static_id=>'item-detail-summary'
,p_list_item_link_target=>'f?p=&APP_ID.:310:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(24896254309195707236)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24896254309195707236)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Item Details'
,p_static_id=>'item-details'
,p_list_item_link_target=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-id-card-o'
,p_parent_list_item_id=>wwv_flow_imp.id(24893313173126473415)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24893957727360816058)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Item Selection'
,p_static_id=>'item-selection-and-details'
,p_list_item_link_target=>'f?p=&APP_ID.:330:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(24896254309195707236)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24896255163658707237)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Master Detail'
,p_static_id=>'master-detail'
,p_list_item_link_target=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-files-o'
,p_list_item_disp_cond_type=>'NEVER'
,p_parent_list_item_id=>wwv_flow_imp.id(24893313173126473415)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24893313173126473415)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Page Patterns'
,p_static_id=>'patterns'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cards'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24910783800398178812)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Browse and Search'
,p_static_id=>'reports'
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-mouse-pointer'
,p_parent_list_item_id=>wwv_flow_imp.id(24893313173126473415)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24910772555820178799)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Simple'
,p_static_id=>'simple-dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(24910790791280181782)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
