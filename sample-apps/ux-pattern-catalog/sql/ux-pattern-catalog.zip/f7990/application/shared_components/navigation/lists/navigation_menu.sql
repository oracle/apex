prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(21567805958407901)
,p_name=>'Navigation Menu'
,p_static_id=>'navigation-menu'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4122700310762295)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Reference'
,p_static_id=>'about'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-book'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6851261766651832)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Browse \2013\00A0Cards')
,p_static_id=>'browse-cards'
,p_list_item_link_target=>'f?p=&APP_ID.:210:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(21591974106407985)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5855858270483148)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('Browse \2013\00A0Content Row')
,p_static_id=>'browse-content-row'
,p_list_item_link_target=>'f?p=&APP_ID.:220:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(21591974106407985)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6067532449212444)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Advanced'
,p_static_id=>'complex-dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(21598964988410955)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(21598964988410955)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Dashboards'
,p_static_id=>'dashboards'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-dashboard'
,p_parent_list_item_id=>wwv_flow_imp.id(4121346834702588)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7062899464936410)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Data Entry'
,p_static_id=>'data-entry'
,p_list_item_link_target=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-forms'
,p_parent_list_item_id=>wwv_flow_imp.id(4121346834702588)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7210162442097851)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>unistr('Data Entry \2013\00A0Drawer Form')
,p_static_id=>'data-entry-drawer-form'
,p_list_item_link_target=>'f?p=&APP_ID.:420:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(7062899464936410)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4057501668687228)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>unistr('Data Entry \2013 Simple Form')
,p_static_id=>'data-entry-simple-form'
,p_list_item_link_target=>'f?p=&APP_ID.:410:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(7062899464936410)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(21579151666407967)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Getting Started'
,p_static_id=>'home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-mouse-pointer'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5973741736593697)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Interactive Report'
,p_static_id=>'interactive-report'
,p_list_item_link_target=>'f?p=&APP_ID.:230:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(21591974106407985)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3981339053581289)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>unistr('Item Detail \2013\00A0Full')
,p_static_id=>'item-detail-full'
,p_list_item_link_target=>'f?p=&APP_ID.:320:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(7062482903936409)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7487013391928435)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>unistr('Item Detail \2013\00A0Summary')
,p_static_id=>'item-detail-summary'
,p_list_item_link_target=>'f?p=&APP_ID.:310:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(7062482903936409)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7062482903936409)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Item Details'
,p_static_id=>'item-details'
,p_list_item_link_target=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-id-card-o'
,p_parent_list_item_id=>wwv_flow_imp.id(4121346834702588)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7063337366936410)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Master Detail'
,p_static_id=>'master-detail'
,p_list_item_link_target=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-files-o'
,p_parent_list_item_id=>wwv_flow_imp.id(4121346834702588)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4121346834702588)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Patterns'
,p_static_id=>'patterns'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-cards'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(21591974106407985)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Browse and Search'
,p_static_id=>'reports'
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-mouse-pointer'
,p_parent_list_item_id=>wwv_flow_imp.id(4121346834702588)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(21580729528407972)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Simple'
,p_static_id=>'simple-dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.'
,p_parent_list_item_id=>wwv_flow_imp.id(21598964988410955)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
