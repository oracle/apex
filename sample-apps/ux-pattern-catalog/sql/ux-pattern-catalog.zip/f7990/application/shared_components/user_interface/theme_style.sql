prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 42
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.2'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(24895213365247667045)
,p_theme_id=>42
,p_name=>'Iris - UX Pattern Catalog'
,p_static_id=>'iris-copy-1'
,p_css_file_urls=>'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#'
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Iris.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_FontFamily":"system","@g_Nav_Style":"light","@g_Header_Style":"pillar","@g_Accent-Pillar":"custom","@g_CustomAccent-BG":"#4251bf","@g_Color-Palette-1":"#5463d6","@g_Color-Palette-1-FG":"#ffffff","@g_Link-Base":"#2f3a8d","@Ac'
||'tions-Exp":"320px","@Side-Exp":"320px","@Nav-Exp":"280px"},"customCSS":":root {\n--u-color-1: #4251BF;\n--u-color-1-contrast: #FFF;\n\n--u-color-2: #3F8EFC;\n--u-color-2-contrast: #FFF;\n\n--u-color-3: #1FB6A6;\n--u-color-3-contrast: #FFF;\n\n--u-col'
||'or-4: #4CBF7A;\n--u-color-4-contrast: #FFF;\n\n--u-color-5: #E5B73B;\n--u-color-5-contrast: #FFF;\n\n--u-color-6: #F28C52;\n--u-color-6-contrast: #FFF;\n\n--u-color-7: #E76F6A;\n--u-color-7-contrast: #FFF;\n\n--u-color-8: #A86BD8;\n--u-color-8-contra'
||'st: #FFF;\n\n--u-color-9: #D65C97;\n--u-color-9-contrast: #FFF;\n\n--u-color-10: #6B7A90;\n--u-color-10-contrast: #FFF;\n\n--u-color-11: #5C6EE5;\n--u-color-11-contrast: #FFF;\n\n--u-color-12: #28C7D9;\n--u-color-12-contrast: #FFF;\n\n--u-color-13: #'
||'72C95F;\n--u-color-13-contrast: #FFF;\n\n--u-color-14: #C5A23A;\n--u-color-14-contrast: #FFF;\n\n--u-color-15: #8E6AC8;\n--u-color-15-contrast: #FFF;\n\n--ut-body-title-background-color: #FFF;\n--ut-body-sidebar-background-color: #FBFBFE;\n--ut-body-'
||'background-color: #FBFBFE;\n\n--ut-palette-danger: #B73122;\n--ut-palette-danger-contrast: #FFFFFF;\n--ut-palette-danger-shade: #FDECEA;\n--ut-palette-danger-text: #9F271B;\n\n--ut-palette-warning: #9A5B00;\n--ut-palette-warning-contrast: #FFFFFF;\n-'
||'-ut-palette-warning-shade: #FFF4DB;\n--ut-palette-warning-text: #7A4700;\n\n--ut-palette-success: #1D7A52;\n--ut-palette-success-contrast: #FFFFFF;\n--ut-palette-success-shade: #E7F6EE;\n--ut-palette-success-text: #166341;\n\n--ut-palette-info: #2B6C'
||'B0;\n--ut-palette-info-contrast: #FFFFFF;\n--ut-palette-info-shade: #EAF2FF;\n--ut-palette-info-text: #20548A;\n\n}   \n\n.t-ContentRow-item.is-selected {\n    --ut-cr-item-background-color: var(--a-palette-primary);\n    --ut-cr-item-text-color: var'
||'(--a-palette-primary-contrast);\n    --ut-component-text-title-color: var(--ut-cr-item-text-color);\n    --ut-component-text-muted-color: var(--ut-cr-item-text-color);\n}\n\n/* Hide the processing spinner when it is first added to the page. */\n.u-Pr'
||'ocessing {\n    opacity: 0;\n    animation: spinner-fade-in 0.5s ease 0.5s forwards;\n}\n\n/* Gradually transition the spinner from hidden to fully visible. */\n@keyframes spinner-fade-in {\n    from {\n        opacity: 0;\n    }\n\n    to {\n       '
||' opacity: 1;\n    }\n}\n\n/* Align Side RDS */\n.t-Body-side .a-RDS-link {\n    --ut-tabs-item-padding-x: 1rem;\n}\n","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#24895213365247667045.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
