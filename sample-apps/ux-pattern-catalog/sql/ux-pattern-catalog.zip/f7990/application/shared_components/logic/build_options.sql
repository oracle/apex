prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 7990
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7990
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(24910758457553178721)
,p_build_option_name=>'Commented Out'
,p_static_id=>'commented-out'
,p_build_option_status=>'EXCLUDE'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(24896373504618843770)
,p_build_option_name=>'Legacy'
,p_static_id=>'legacy'
,p_build_option_status=>'EXCLUDE'
);
wwv_flow_imp.component_end;
end;
/
