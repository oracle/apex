prompt --application/pages/page_00112
begin
--   Manifest
--     PAGE: 00112
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>112
,p_name=>'US States (flat)'
,p_alias=>'US-STATES-FLAT'
,p_step_title=>'&APP_NAME. - US States (flat)'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'19'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1555797769172485654)
,p_plug_name=>'About This Page'
,p_region_name=>'about_this_page'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-size480x320'
,p_region_attributes=>'data-parent-element="#help_button"'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'This map visualizes US states as polygons. The polygon color is determined by the <strong>WATER_AREA</strong> column, using the built-in <strong>Blue to Yellow</strong> color scheme. Click on a state to show a info popup with details.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1558128927410571237)
,p_plug_name=>'US States'
,p_region_name=>'airport-map-region'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(1556520208894934856)
,p_region_id=>wwv_flow_imp.id(1558128927410571237)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-90'
,p_init_position_lat_static=>'35'
,p_init_zoomlevel_static=>'3'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1556520569385934941)
,p_map_region_id=>wwv_flow_imp.id(1556520208894934856)
,p_name=>'US States'
,p_layer_type=>'POLYGON'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       NAME,',
'       STATE_CODE,',
'       to_char(LAND_AREA / 1000000,''9G999G999G990D000'')  land_area,',
'       to_char(WATER_AREA / 1000000,''9G999G999G990D000'')  water_area,',
'       case when water_area > 50000000000 then 50000000000 else water_area end as water_area_color,',
'       geometry',
'  from EBA_SAMPLE_MAP_SIMPLE_STATES'))
,p_no_data_found_message=>'No States found.'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#101010'
,p_fill_color_is_spectrum=>true
,p_fill_color_spectr_name=>'BluYl'
,p_fill_color_spectr_type=>'SEQUENTIAL'
,p_fill_value_column=>'WATER_AREA_COLOR'
,p_fill_opacity=>.7
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'NAME'
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&NAME. (&STATE_CODE.)</strong><br>',
'Land Area: &LAND_AREA. km&sup2;<br>',
'Water Area: &WATER_AREA. km&sup2;<br>'))
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(787158267571835020)
,p_name=>'On Click Point'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1558128927410571237)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapobjectclick'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(787158658469835021)
,p_event_id=>wwv_flow_imp.id(787158267571835020)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const { lng, lat } = this.data;',
'',
'apex.region("airport-map-region").call( "getMapObject" ).flyTo({ ',
'    center: [ lng, lat ],',
'    screenSpeed: 0.8',
'});'))
);
wwv_flow_imp.component_end;
end;
/
