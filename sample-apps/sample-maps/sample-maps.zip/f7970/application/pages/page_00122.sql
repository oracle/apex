prompt --application/pages/page_00122
begin
--   Manifest
--     PAGE: 00122
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>122
,p_name=>'Map Circle Search '
,p_alias=>'AIRPORTS-MAP-CIRCLE-SEARCH'
,p_step_title=>'&APP_NAME. - Map Circle Search '
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function showFeature( pId, pScale ) {',
'    var lMapRegion = apex.region("airport-map-region"), lLayerId, lFeature;',
'    // important: Use the layer name exactly as specified in the "name" attribute in Page Designer',
'    if (pScale === 2){',
'        lLayerId = lMapRegion.call("getLayerIdByName", "Large Airports");',
'    } else {',
'        lLayerId = lMapRegion.call("getLayerIdByName", "Small Airports");',
'    }',
'    lFeature = lMapRegion.call("getFeature", lLayerId, pId );',
'',
'    if ( lFeature.geometry ) {',
'        lMapRegion.call( "getMapObject" ).flyTo({ ',
'            center: lFeature.geometry.coordinates,',
'            screenSpeed: 0.8',
'        });',
'        lMapRegion.call( "closeAllInfoWindows" );',
'        lMapRegion.call( "displayPopup", "infoWindow", lLayerId, pId.toString(), false );',
'    }',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_upd_yyyymmddhh24miss=>'20230110134707'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(776850643960258325)
,p_name=>'Selected Airports'
,p_template=>wwv_flow_imp.id(1548376270170069419)
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-ContentRow--styleCompact:t-Report--hideNoPagination'
,p_new_grid_row=>false
,p_grid_column_span=>4
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'',
'       -- data columns',
'       IATA_CODE,',
'       initcap(AIRPORT_NAME) airport_name,',
'       initcap(CITY) city,',
'       initcap(STATE_NAME) state_name,',
'       nvl(commercial_ops,0) as commercial_ops,',
'       air_taxi_ops,',
'       activation_date,',
'       case when commercial_ops > 100000 then 2 else 1 end as scale,',
'',
'       -- display columns',
'       null item_classes,',
'       null selection,',
'       case when commercial_ops > 100000 then ''fa fa-lg fa-map-marker-s u-danger-text'' else ''fa fa-lg fa-flag-pennant'' end as icon_class,',
'       null icon_html,',
'       null title,',
'       null description,',
'       null misc,',
'       null actions',
'       ',
'  from EBA_SAMPLE_MAP_AIRPORTS',
' where :P122_CIRCLE_GEOJSON is not null',
'   and sdo_anyinteract( geometry, mdsys.sdo_util.from_geojson( :P122_CIRCLE_GEOJSON)) = ''TRUE''',
'   and commercial_ops > 0',
'   and (',
'        case when nvl(commercial_ops,0) > 100000                then ''Y'' end = :P122_LARGE_VISIBLE',
'        or ',
'        case when nvl(commercial_ops,0) between 1000 and 100000 then ''Y'' end = :P122_SMALL_VISIBLE',
'       )',
'order by nvl(commercial_ops,0) desc, airport_name'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P122_CIRCLE_GEOJSON,P122_LARGE_VISIBLE,P122_SMALL_VISIBLE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(1548398706896069458)
,p_query_num_rows=>8
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'This page visualizes large US airports as ',
' a <em>Point Layer</em>. Each airport is visualized with a <em>Map Marker</em>. Clicking the map marker reveals detailed information about the airport. Red markers are used for large airports.',
'<p>Use the <em>Circle</em> tool <span aria-hidden="true" class="a-Icon icon-draw-circle"></span> to additionally find and visualize small airports. Once the circle is drawn, the application will reveal the small airports within the circle''s circumfer'
||'ence and update the report results.',
'</p>'))
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776850760711258326)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776850895897258327)
,p_query_column_id=>2
,p_column_alias=>'IATA_CODE'
,p_column_display_sequence=>20
,p_column_heading=>'Iata Code'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776850983275258328)
,p_query_column_id=>3
,p_column_alias=>'AIRPORT_NAME'
,p_column_display_sequence=>30
,p_column_heading=>'Airport Name'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776851071138258329)
,p_query_column_id=>4
,p_column_alias=>'CITY'
,p_column_display_sequence=>40
,p_column_heading=>'City'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776851165565258330)
,p_query_column_id=>5
,p_column_alias=>'STATE_NAME'
,p_column_display_sequence=>50
,p_column_heading=>'State Name'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776851214372258331)
,p_query_column_id=>6
,p_column_alias=>'COMMERCIAL_OPS'
,p_column_display_sequence=>60
,p_column_heading=>'Commercial Ops'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776851394959258332)
,p_query_column_id=>7
,p_column_alias=>'AIR_TAXI_OPS'
,p_column_display_sequence=>70
,p_column_heading=>'Air Taxi Ops'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776851403938258333)
,p_query_column_id=>8
,p_column_alias=>'ACTIVATION_DATE'
,p_column_display_sequence=>80
,p_column_heading=>'Activation Date'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(779237384577141101)
,p_query_column_id=>9
,p_column_alias=>'SCALE'
,p_column_display_sequence=>170
,p_column_heading=>'Scale'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776851510638258334)
,p_query_column_id=>10
,p_column_alias=>'ITEM_CLASSES'
,p_column_display_sequence=>90
,p_column_heading=>'Item Classes'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776851666548258335)
,p_query_column_id=>11
,p_column_alias=>'SELECTION'
,p_column_display_sequence=>100
,p_column_heading=>'Selection'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776851785140258336)
,p_query_column_id=>12
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>110
,p_column_heading=>'Icon Class'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776851869434258337)
,p_query_column_id=>13
,p_column_alias=>'ICON_HTML'
,p_column_display_sequence=>120
,p_column_heading=>'Icon Html'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776851921745258338)
,p_query_column_id=>14
,p_column_alias=>'TITLE'
,p_column_display_sequence=>130
,p_column_heading=>'Title'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript: showFeature(''#ID#'', #SCALE#);'
,p_column_linktext=>'#AIRPORT_NAME# (#IATA_CODE#)'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776852006402258339)
,p_query_column_id=>15
,p_column_alias=>'DESCRIPTION'
,p_column_display_sequence=>140
,p_column_heading=>'Description'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'#COMMERCIAL_OPS# Operations'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776852149475258340)
,p_query_column_id=>16
,p_column_alias=>'MISC'
,p_column_display_sequence=>150
,p_column_heading=>'Misc'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(776852235968258341)
,p_query_column_id=>17
,p_column_alias=>'ACTIONS'
,p_column_display_sequence=>160
,p_column_heading=>'Actions'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1549137978572502589)
,p_plug_name=>'Selected Airports IRR'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1548374350541069417)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>4
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       IATA_CODE,',
'       initcap(AIRPORT_NAME) airport_name,',
'       initcap(CITY) city,',
'       initcap(STATE_NAME) state_name,',
'       commercial_ops,',
'       air_taxi_ops,',
'       activation_date',
'  from EBA_SAMPLE_MAP_AIRPORTS',
' where COMMERCIAL_OPS between 0 and 100000 ',
'   and :P122_CIRCLE_GEOJSON is not null',
'   and sdo_anyinteract( geometry, mdsys.sdo_util.from_geojson( :P122_CIRCLE_GEOJSON)) = ''TRUE'''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P122_CIRCLE_GEOJSON'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Selected Airports IRR'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1549138246244502591)
,p_no_data_found_message=>'No small airports found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_control_break=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'CCZARSKI'
,p_internal_uid=>2621768598440925
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1549138360875502592)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1549138458244502593)
,p_db_column_name=>'IATA_CODE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Airport'
,p_column_html_expression=>'#AIRPORT_NAME# (#IATA_CODE#)'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1549138568227502594)
,p_db_column_name=>'CITY'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'City'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1549138596312502595)
,p_db_column_name=>'STATE_NAME'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'State'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547996332322599359)
,p_db_column_name=>'COMMERCIAL_OPS'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Commercial Operations'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547996508541599360)
,p_db_column_name=>'AIR_TAXI_OPS'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Air Taxi Operations'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547996579047599361)
,p_db_column_name=>'ACTIVATION_DATE'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Opened'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1541528398011884271)
,p_db_column_name=>'AIRPORT_NAME'
,p_display_order=>90
,p_column_identifier=>'E'
,p_column_label=>'Airport Name'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1549212223522944067)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'26958'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IATA_CODE:STATE_NAME:ACTIVATION_DATE:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1549138832452502597)
,p_plug_name=>'About this Page'
,p_region_name=>'about_this_page'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-size480x320'
,p_region_attributes=>'data-parent-element="#help_button"'
,p_plug_template=>wwv_flow_imp.id(1548371059936069414)
,p_plug_display_sequence=>5
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'This page visualizes large US airports as ',
' a <em>Point Layer</em>. Each airport is visualized with a <em>Map Marker</em>. Clicking the map marker reveals detailed information about the airport. Red markers are used for large airports.',
'<p>Use the <em>Circle</em> tool <span aria-hidden="true" class="a-Icon icon-draw-circle"></span> to additionally find and visualize small airports. Once the circle is drawn, the application will reveal the small airports within the circle''s circumfer'
||'ence and update the report results.',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1551799469866208464)
,p_plug_name=>'US Airports'
,p_region_name=>'airport-map-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1548376270170069419)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(1549181011657767576)
,p_region_id=>wwv_flow_imp.id(1551799469866208464)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-90'
,p_init_position_lat_static=>'35'
,p_init_zoomlevel_static=>'3'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'RECTANGLE_ZOOM:SCALE_BAR:INFINITE_MAP:CIRCLE_TOOL:DISTANCE_TOOL'
,p_custom_styles=>wwv_flow_string.join(wwv_flow_t_varchar2(
'[',
'    {',
'        "name": "Airport",',
'        "width": 20,',
'        "height": 20,',
'        "paint-order": "stroke",',
'        "viewBox": "0 0 20 20",',
'        "elements": [',
'            {',
'                "type": "path",',
'                "d": "M10,2A6.006,6.006,0,0,0,4,8c0,3.652,5.4,9.587,5.631,9.838a.5.5,0,0,0,.738,0C10.6,17.587,16,11.652,16,8A6.006,6.006,0,0,0,10,2Z"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M12.942,5.942,11.783,7.1l.655,2.836a.5.5,0,0,1-.317.583.509.509,0,0,1-.171.03.5.5,0,0,1-.445-.273l-.978-1.92-.986.986.123,1.1a.5.5,0,0,1-.972.213L8.354,9.646,7.342,9.308a.5.5,0,0,1-.33-.582.509.509,0,0,1,.543-.39l1.1.123.986-.98'
||'6L7.723,6.5a.5.5,0,0,1,.34-.933l2.836.655,1.159-1.159a.625.625,0,0,1,.884.884Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            }',
'        ]',
'    },',
'    {',
'        "name": "Small Airport",',
'        "width": 20,',
'        "height": 20,',
'        "paint-order": "stroke",',
'        "viewBox": "0 0 20 20",',
'        "elements": [',
'            {',
'                "type": "path",',
'                "d": "M10,19a1.5,1.5,0,0,1-1.106-.487C8.291,17.855,3,11.967,3,8A7,7,0,0,1,17,8c0,3.967-5.291,9.855-5.894,10.514A1.506,1.506,0,0,1,10,19Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M10,2A6.006,6.006,0,0,0,4,8c0,3.652,5.4,9.587,5.631,9.838a.5.5,0,0,0,.738,0C10.6,17.587,16,11.652,16,8A6.006,6.006,0,0,0,10,2Z"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M11.94,7.375h-.963L9.435,4.906a.5.5,0,0,0-.9.42L9.2,7.375H8.307l-.693-.866a.508.508,0,0,0-.66-.109.5.5,0,0,0-.177.645L7.29,8.072a1,1,0,0,0,.894.553H9.2l-.666,2.049a.5.5,0,0,0,.122.508.5.5,0,0,0,.778-.088l1.542-2.469h.963a.625.62'
||'5,0,0,0,0-1.25Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M13.076,9a.2.2,0,0,1-.2-.2V7.2a.2.2,0,1,1,.4,0V8.8A.2.2,0,0,1,13.076,9Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            }',
'        ]',
'    }',
']',
''))
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1549182154369767577)
,p_map_region_id=>wwv_flow_imp.id(1549181011657767576)
,p_name=>'Large Airports'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       IATA_CODE,',
'       CITY,',
'       AIRPORT_NAME,',
'       AIRPORT_TYPE,',
'       STATE_NAME,',
'       ELEVATION,',
'       DIST_CITY_TO_AIRPORT,',
'       LAND_AREA_COVERED,',
'       to_char(ACTIVATION_DATE_DT,''fmDDfm-MON-YYYY'') as ACTIVATION_DATE,',
'       COMMERCIAL_OPS,',
'       to_char(COMMERCIAL_OPS,''999G999G999G999'') as com_ops_fmtd,',
'       AIR_TAXI_OPS,',
'       to_char(AIR_TAXI_OPS,''999G999G999G999'') as air_ops_fmtd,',
'       GEOMETRY,',
'       2 as scale',
'  from EBA_SAMPLE_MAP_AIRPORTS',
' where COMMERCIAL_OPS > 100000'))
,p_items_to_submit=>'P122_CIRCLE_GEOJSON'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#ffffff'
,p_fill_color=>'#ff0000'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Airport'
,p_point_svg_shape_scale=>'2'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'<strong>&AIRPORT_NAME. (&IATA_CODE.)</strong>'
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>&AIRPORT_NAME. (&IATA_CODE.)</h3>',
'<p>',
'&AIRPORT_TYPE.<br>',
'<strong>&CITY., &STATE_NAME.</strong><br>',
'{if ACTIVATION_DATE/}',
'Activation Date: &ACTIVATION_DATE.<br>',
'{endif/}',
'{if COMMERCIAL_OPS/}',
'Commercial Operations: &COM_OPS_FMTD.<br>',
'{endif/}',
'{if AIR_TAXI_OPS/}',
'Taxi Operations: &AIR_OPS_FMTD.<br>',
'{endif/}'))
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1547996162517599357)
,p_map_region_id=>wwv_flow_imp.id(1549181011657767576)
,p_name=>'Search Circle'
,p_layer_type=>'POLYGON'
,p_display_sequence=>20
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 0 as id,',
'       mdsys.sdo_util.from_geojson( to_clob( :P122_CIRCLE_GEOJSON )) as geometry',
'  from sys.dual',
' where :P122_CIRCLE_GEOJSON is not null'))
,p_items_to_submit=>'P122_CIRCLE_GEOJSON'
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#101010'
,p_fill_color=>'#d8aa12'
,p_fill_color_is_spectrum=>false
,p_fill_opacity=>.2
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1549181576209767577)
,p_map_region_id=>wwv_flow_imp.id(1549181011657767576)
,p_name=>'Small Airports'
,p_layer_type=>'POINT'
,p_display_sequence=>30
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       IATA_CODE,',
'       CITY,',
'       AIRPORT_NAME,',
'       AIRPORT_TYPE,',
'       STATE_NAME,',
'       ELEVATION,',
'       DIST_CITY_TO_AIRPORT,',
'       LAND_AREA_COVERED,',
'       ACTIVATION_DATE,',
'       COMMERCIAL_OPS,',
'       AIR_TAXI_OPS,',
'       GEOMETRY,',
'       1 as scale',
'  from EBA_SAMPLE_MAP_AIRPORTS',
' where COMMERCIAL_OPS between 0 and 100000 and :P122_CIRCLE_GEOJSON is not null',
'   and sdo_anyinteract( geometry, mdsys.sdo_util.from_geojson( :P122_CIRCLE_GEOJSON)) = ''TRUE'''))
,p_items_to_submit=>'P122_CIRCLE_GEOJSON'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#ffffff'
,p_fill_color=>'#392423'
,p_fill_opacity=>.8
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Small Airport'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'&AIRPORT_NAME. (&IATA_CODE.)'
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&AIRPORT_NAME. (&IATA_CODE.)</strong><br>',
'&CITY., &STATE_NAME.'))
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(779232285996792344)
,p_name=>'P122_LARGE_VISIBLE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1551799469866208464)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(779232561447794643)
,p_name=>'P122_SMALL_VISIBLE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1551799469866208464)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1549137860703502587)
,p_name=>'P122_CIRCLE_GEOJSON'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1551799469866208464)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1549137558069502584)
,p_name=>'Circle Finished'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1551799469866208464)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.changeType === "circle-drawn"'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapchanged'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1549137648432502585)
,p_event_id=>wwv_flow_imp.id(1549137558069502584)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P122_CIRCLE_GEOJSON'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'( this.data.circle ? JSON.stringify( this.data.circle.data.geometry ) : "" )'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1549138724250502596)
,p_event_id=>wwv_flow_imp.id(1549137558069502584)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(776850643960258325)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1549137904067502588)
,p_event_id=>wwv_flow_imp.id(1549137558069502584)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1551799469866208464)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1547996252074599358)
,p_event_id=>wwv_flow_imp.id(1549137558069502584)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.region( "airport-map-region" ).call ( "clearCircle" );',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(776852981127258348)
,p_name=>'Refresh Selected Airports Classic Report'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1551799469866208464)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.changeType === "toggle-layer"'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapchanged'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(776853008349258349)
,p_event_id=>wwv_flow_imp.id(776852981127258348)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// the "map-changed" event sends the type of change as the "changeType" attribute. "toggle-layer" indicates',
'// that the layer visibility has been toggled by clicking the layer entry in the legend.',
'// so "copy" the layer visibility information from the dynamic action "payload" object to the',
'// P122_LARGE_VISIBLE and P122_SMALL_VISIBLE page items, which are then picked up by the',
'// report query.',
'for ( l = 0; l < this.data.layers.length; l++) {',
'    if ( this.data.layers[ l ].name === "Small Airports" ) {',
'        apex.item( "P122_SMALL_VISIBLE" ).setValue( ( this.data.layers[ l ].visible ? ''Y'' : ''N'' ) );',
'    } else if ( this.data.layers[ l ].name === "Large Airports" ) {',
'        apex.item( "P122_LARGE_VISIBLE" ).setValue( ( this.data.layers[ l ].visible ? ''Y'' : ''N'' ) );',
'    }',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(776853128809258350)
,p_event_id=>wwv_flow_imp.id(776852981127258348)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(776850643960258325)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(779346064340669026)
,p_name=>'On Click Point'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1551799469866208464)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapobjectclick'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(779346445067669051)
,p_event_id=>wwv_flow_imp.id(779346064340669026)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const { lng, lat } = this.data;',
'',
'apex.region("airport-map-region").call( "getMapObject" ).flyTo({ ',
'    center: [ lng, lat ],',
'    screenSpeed: 0.8',
'});'))
);
wwv_flow_imp.component_end;
end;
/
