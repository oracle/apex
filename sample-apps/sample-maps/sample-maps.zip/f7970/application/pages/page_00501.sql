prompt --application/pages/page_00501
begin
--   Manifest
--     PAGE: 00501
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>501
,p_name=>'Load Full Dataset'
,p_alias=>'LOAD-FULL-DATASET'
,p_step_title=>'&APP_NAME. - Load Full Dataset'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20231002215321'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1551166680237006123)
,p_plug_name=>'Load Full Dataset'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(1548376270170069419)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(772845639641815544)
,p_plug_name=>'File Items'
,p_parent_plug_id=>wwv_flow_imp.id(1551166680237006123)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_imp.id(1548376270170069419)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<p>Download the <strong>states-full.json</strong> and <strong>airports-full.json</strong> files from <strong><a href="https://github.com/oracle/apex/tree/22.1/sample-apps/sample-maps/" target="_blank">https://github.com/oracle/apex/tree/22.1/sample-a'
||'pps/sample-maps/</a></strong> and upload here.</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(772845704042815545)
,p_plug_name=>'From GitHub'
,p_parent_plug_id=>wwv_flow_imp.id(1551166680237006123)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_imp.id(1548376270170069419)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1551168290611006139)
,p_plug_name=>'Status States'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1548347865227069394)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1551167094660006127)
,p_plug_name=>'States Data'
,p_parent_plug_id=>wwv_flow_imp.id(1551168290611006139)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--success'
,p_plug_template=>wwv_flow_imp.id(1548344173494069385)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'US States Data is fully loaded.'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from eba_sample_map_states'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1551167849570006135)
,p_plug_name=>'States Data'
,p_parent_plug_id=>wwv_flow_imp.id(1551168290611006139)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_imp.id(1548344173494069385)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Use this page to load US States boundaries to the Sample Application.'
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>'select 1 from eba_sample_map_states'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1551168339859006140)
,p_plug_name=>'Status Airports'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1548347865227069394)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1551167952802006136)
,p_plug_name=>'Airports Data'
,p_parent_plug_id=>wwv_flow_imp.id(1551168339859006140)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--success'
,p_plug_template=>wwv_flow_imp.id(1548344173494069385)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Airports Data is fully loaded.'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_sample_map_airports',
'having count(*)>1000'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1551168032981006137)
,p_plug_name=>'Airports Data'
,p_parent_plug_id=>wwv_flow_imp.id(1551168339859006140)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_imp.id(1548344173494069385)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'Use this page to load the full US Airports dataset to the Sample Application.'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_sample_map_airports',
'having count(*)<1000'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2332358275861827378)
,p_plug_name=>'About This Page'
,p_region_name=>'about_this_page'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-size480x320'
,p_region_attributes=>'data-parent-element="#help_button"'
,p_plug_template=>wwv_flow_imp.id(1548371059936069414)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'Use this page to load full airport and US state boundary data into this sample application. If your database can connect to the internet, the application can download directly from GitHub. Otherwise, download the JSON files from GitHub using your bro'
||'wser, and upload them here afterwards.',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1551167504853006132)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2327991724510922201)
,p_button_name=>'LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(1548440222930069520)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Load Dataset'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-download'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(784815179077645605)
,p_branch_name=>'Go To Page 1'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:501::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(1551167504853006132)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(772845867314815546)
,p_name=>'P501_PROXY_OVERRIDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(772845704042815545)
,p_prompt=>'Use Proxy Server'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(1548437654692069507)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1551166789746006124)
,p_name=>'P501_STATES_FILE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(772845639641815544)
,p_prompt=>'US States Data'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(1548437654692069507)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1551166865864006125)
,p_name=>'P501_AIRPORTS_FILE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(772845639641815544)
,p_prompt=>'Airports Data'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(1548437654692069507)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1551167181458006128)
,p_name=>'P501_SOURCE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1551166680237006123)
,p_item_default=>'FILE'
,p_prompt=>'Load Data From'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Upload Files;FILE,Directly from GitHub;GITHUB'
,p_field_template=>wwv_flow_imp.id(1548437532778069507)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1551167219001006129)
,p_name=>'Load From'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P501_SOURCE'
,p_condition_element=>'P501_SOURCE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'FILE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(772846060818815548)
,p_event_id=>wwv_flow_imp.id(1551167219001006129)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(772845704042815545)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1551167377986006130)
,p_event_id=>wwv_flow_imp.id(1551167219001006129)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(772845639641815544)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(772845900114815547)
,p_event_id=>wwv_flow_imp.id(1551167219001006129)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(772845704042815545)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1551167440669006131)
,p_event_id=>wwv_flow_imp.id(1551167219001006129)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(772845639641815544)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1551167601831006133)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Full Dataset'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    eba_sample_map_load_data(',
'        p_load_from          => :P501_SOURCE,',
'        p_states_file_name   => :P501_STATES_FILE,',
'        p_airports_file_name => :P501_AIRPORTS_FILE,',
'        p_proxy_override     => :P501_PROXY_OVERRIDE );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1551167504853006132)
,p_process_success_message=>'Data loaded.'
,p_internal_uid=>1551167601831006133
);
wwv_flow_imp.component_end;
end;
/
