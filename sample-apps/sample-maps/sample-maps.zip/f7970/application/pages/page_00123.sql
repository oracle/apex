prompt --application/pages/page_00123
begin
--   Manifest
--     PAGE: 00123
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>123
,p_name=>'Map and Report'
,p_alias=>'MAP-AND-REPORT'
,p_step_title=>'&APP_NAME. - Map and Report'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//',
'// globals to memorize the previously clicked airport; important to be able to reset the highlight',
'var gPrevFeature, gPrevLayerId;',
'',
'function showFeature( pId, pFromReport ) {',
'    var lMapRegion, lLayerLargeId, lLayerSmallId, lLayerId, lFeature;',
'',
'    //',
'    // if the same airport is clicked twice, exit early without doing anything',
'    if ( gPrevFeature && gPrevFeature.id === pId ) {',
'        return false;',
'    }',
'',
'    //',
'    // get Map Region and Layer Handles',
'    lMapRegion    = apex.region("airport-map-region");',
'    lLayerLargeId = lMapRegion.call("getLayerIdByName", "Large Airports");',
'    lLayerSmallId = lMapRegion.call("getLayerIdByName", "Small Airports");',
'',
'    //',
'    // Look up a large airport first; if not found, loop for a small airport.',
'    lFeature = lMapRegion.call("getFeature", lLayerLargeId, pId );',
'    if ( lFeature.id ) {',
'        lLayerId = lLayerLargeId;',
'    } else {',
'        lFeature = lMapRegion.call("getFeature", lLayerSmallId, pId ) ;',
'        lLayerId = lLayerSmallId;',
'    }',
'    ',
'    //',
'    // if there is no coordinate, don''t do anything ',
'    if ( lFeature && lFeature.geometry ) {',
'        //',
'        // reinstate previously selected feature on the map (remove highlight)',
'        if ( gPrevFeature ) {',
'            lMapRegion.call( "updateFeature", gPrevLayerId, gPrevFeature );',
'        }',
'        //',
'        // center the map to the clicked object',
'        lMapRegion.call( "getMapObject" ).flyTo({ ',
'            center: lFeature.geometry.coordinates,',
'            screenSpeed: 0.8',
'        });',
'        //',
'        // save the feature before changing to the "highlight" style; do a "deep copy".',
'        gPrevFeature = JSON.parse( JSON.stringify( lFeature ) );',
'        gPrevLayerId = lLayerId;',
'        // ',
'        // set highlight styles and update map',
'        lFeature.pointSvgShape     = ''Pin Circle'';',
'        lFeature.color             = ''darkorange'';',
'        lFeature.pointSvgShapeSize = 3.5;        ',
'        lMapRegion.call( "updateFeature", lLayerId, lFeature );    ',
'',
'        if ( pFromReport ) {',
'            lMapRegion.call( "closeAllInfoWindows" );',
'            lMapRegion.call( "displayPopup", "infoWindow", lLayerId, pId.toString(), false );',
'        }',
'    }',
'}'))
,p_inline_css=>'td[headers="LINK"] {text-align: center;}'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(736070018834862215)
,p_name=>'Results'
,p_template=>4072358936313175081
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-ContentRow--styleCompact:t-Report--hideNoPagination'
,p_new_grid_row=>false
,p_grid_column_span=>4
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       -- Data',
'       iata_code,',
'       initcap( city ) as city,',
'       initcap( airport_name ) as airport_name,',
'       initcap( airport_type ) as airport_type,',
'       initcap( state_name )   as state_name,',
'       elevation,',
'       dist_city_to_airport,',
'       land_area_covered,',
'       activation_date_dt as activation_date,',
'       commercial_ops,',
'       air_taxi_ops,',
'       geometry,',
'       case when nvl(commercial_ops,0) > 100000 then 2 else 1 end as scale,',
'',
'       -- display columns',
'       null item_classes,',
'       null selection,',
'       case when nvl(commercial_ops,0) > 100000 then ''fa fa-lg fa-map-marker-s u-danger-text'' else ''fa fa-lg fa-flag-pennant'' end as icon_class,',
'       null icon_html,',
'       null title,',
'       null description,',
'       null misc,',
'       null actions',
'  from eba_sample_map_airports',
' where sdo_anyinteract(',
'           geometry,',
'           mdsys.sdo_util.from_geojson( :P123_BBOX )',
'       ) = ''TRUE''',
'  and commercial_ops > 1000',
'  and :P123_BBOX is not null',
'  --',
'  -- select rows based on map layer visibility',
'  and (',
'           case when nvl(commercial_ops,0) > 100000                then ''Y'' end = :P123_LARGE_VISIBLE',
'        or case when nvl(commercial_ops,0) between 1000 and 100000 then ''Y'' end = :P123_SMALL_VISIBLE )',
'order by commercial_ops desc, airport_name'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P123_BBOX,P123_LARGE_VISIBLE,P123_SMALL_VISIBLE'
,p_lazy_loading=>false
,p_query_row_template=>1799290257735395920
,p_query_num_rows=>8
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No airports found.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736070050541862216)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736070183436862217)
,p_query_column_id=>2
,p_column_alias=>'IATA_CODE'
,p_column_display_sequence=>20
,p_column_heading=>'Iata Code'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736070315956862218)
,p_query_column_id=>3
,p_column_alias=>'CITY'
,p_column_display_sequence=>30
,p_column_heading=>'City'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736070438242862219)
,p_query_column_id=>4
,p_column_alias=>'AIRPORT_NAME'
,p_column_display_sequence=>40
,p_column_heading=>'Airport Name'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736070454518862220)
,p_query_column_id=>5
,p_column_alias=>'AIRPORT_TYPE'
,p_column_display_sequence=>50
,p_column_heading=>'Airport Type'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736070583721862221)
,p_query_column_id=>6
,p_column_alias=>'STATE_NAME'
,p_column_display_sequence=>60
,p_column_heading=>'State Name'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736070669398862222)
,p_query_column_id=>7
,p_column_alias=>'ELEVATION'
,p_column_display_sequence=>70
,p_column_heading=>'Elevation'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736070773137862223)
,p_query_column_id=>8
,p_column_alias=>'DIST_CITY_TO_AIRPORT'
,p_column_display_sequence=>80
,p_column_heading=>'Dist City To Airport'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736070885782862224)
,p_query_column_id=>9
,p_column_alias=>'LAND_AREA_COVERED'
,p_column_display_sequence=>90
,p_column_heading=>'Land Area Covered'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736070972325862225)
,p_query_column_id=>10
,p_column_alias=>'ACTIVATION_DATE'
,p_column_display_sequence=>100
,p_column_heading=>'Activation Date'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736071062760862226)
,p_query_column_id=>11
,p_column_alias=>'COMMERCIAL_OPS'
,p_column_display_sequence=>110
,p_column_heading=>'Commercial Ops'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736071169508862227)
,p_query_column_id=>12
,p_column_alias=>'AIR_TAXI_OPS'
,p_column_display_sequence=>120
,p_column_heading=>'Air Taxi Ops'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736071330532862228)
,p_query_column_id=>13
,p_column_alias=>'GEOMETRY'
,p_column_display_sequence=>130
,p_column_heading=>'Geometry'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(784653883958144638)
,p_query_column_id=>14
,p_column_alias=>'SCALE'
,p_column_display_sequence=>140
,p_column_heading=>'Scale'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736071415310862229)
,p_query_column_id=>15
,p_column_alias=>'ITEM_CLASSES'
,p_column_display_sequence=>150
,p_column_heading=>'Item Classes'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736071460317862230)
,p_query_column_id=>16
,p_column_alias=>'SELECTION'
,p_column_display_sequence=>160
,p_column_heading=>'Selection'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736071561322862231)
,p_query_column_id=>17
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>170
,p_column_heading=>'Icon Class'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736071687160862232)
,p_query_column_id=>18
,p_column_alias=>'ICON_HTML'
,p_column_display_sequence=>180
,p_column_heading=>'Icon Html'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736071819875862233)
,p_query_column_id=>19
,p_column_alias=>'TITLE'
,p_column_display_sequence=>190
,p_column_heading=>'Title'
,p_column_link=>'javascript:showFeature(''#ID#'', true);'
,p_column_linktext=>'#AIRPORT_NAME# (#IATA_CODE#)'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736071918959862234)
,p_query_column_id=>20
,p_column_alias=>'DESCRIPTION'
,p_column_display_sequence=>200
,p_column_heading=>'Description'
,p_column_html_expression=>'#CITY#, #STATE_NAME#'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736072010099862235)
,p_query_column_id=>21
,p_column_alias=>'MISC'
,p_column_display_sequence=>210
,p_column_heading=>'Misc'
,p_column_html_expression=>'#ACTIVATION_DATE#'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(736072086174862236)
,p_query_column_id=>22
,p_column_alias=>'ACTIONS'
,p_column_display_sequence=>220
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1552728732424058071)
,p_plug_name=>'No Report'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source=>'The map area is too large to show the details report. Please zoom in on the map.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1552729037184058074)
,p_plug_name=>'About this Page'
,p_region_name=>'about_this_page'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-size480x320'
,p_region_attributes=>'data-parent-element="#help_button"'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page illustrates how to combine a Map with a Interactive Report region. Whenever the map is panned or zoomed, the Interactive  Report refreshes to show the airports being currently visible on the map. The report can be used for keyboard navig'
||'ation. Clicking the <span class="fa fa-map-marker"></span> button opens the information popup for the selected airport on the map.</p>',
'<p>This feature is implemented using the <strong>Bounding Box Item</strong> Map region attribute. If enabled, the map will always set that item to the coordinates of the current map window in GeoJSON format. Then use Oracle Spatial SQL functions in t'
||'he Interactive Report query to restrict the filter results accordingly. Note that this feature requires a Spatial index to be created on the table.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1558324937332256259)
,p_plug_name=>'Airports'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="height: 640px"'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       iata_code,',
'       initcap( city ) as city,',
'       initcap( airport_name ) as airport_name,',
'       initcap( airport_type ) as airport_type,',
'       initcap( state_name )   as state_name,',
'       elevation,',
'       dist_city_to_airport,',
'       land_area_covered,',
'       activation_date_dt as activation_date,',
'       commercial_ops,',
'       air_taxi_ops,',
'       geometry,',
'       case when nvl(commercial_ops,0) > 100000 then 2 else 1 end as scale',
'  from eba_sample_map_airports',
' where sdo_anyinteract(',
'           geometry,',
'           sdo_util.from_geojson( :P123_BBOX )',
'       ) = ''TRUE''',
'  and commercial_ops > 1000',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P123_BBOX'
,p_plug_display_condition_type=>'NEVER'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'New'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1558325124338256261)
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_rows_per_page=>'N'
,p_show_control_break=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'javascript:showFeature(''#ID#'',#SCALE#);'
,p_detail_link_text=>'<span class="t-Icon fa fa-map-marker" aria-hidden="true"></span>'
,p_detail_link_attr=>'class="t-Button t-Button--icon t-Button--tiny t-Button--primary"'
,p_owner=>'CCZARSKI'
,p_internal_uid=>7907803330409905
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1552818643734518277)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1552819361209518297)
,p_db_column_name=>'CITY'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'City'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1549329417874770561)
,p_db_column_name=>'AIRPORT_NAME'
,p_display_order=>40
,p_column_identifier=>'N'
,p_column_label=>'Airport Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1552819731403518297)
,p_db_column_name=>'STATE_NAME'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'State'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1552822144805518298)
,p_db_column_name=>'ACTIVATION_DATE'
,p_display_order=>60
,p_column_identifier=>'J'
,p_column_label=>'Opened'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1552818922785518296)
,p_db_column_name=>'IATA_CODE'
,p_display_order=>70
,p_column_identifier=>'B'
,p_column_label=>'Code'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1552822565118518298)
,p_db_column_name=>'COMMERCIAL_OPS'
,p_display_order=>80
,p_column_identifier=>'K'
,p_column_label=>'Operations'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1552820957686518297)
,p_db_column_name=>'ELEVATION'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Elevation'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1552821413630518298)
,p_db_column_name=>'DIST_CITY_TO_AIRPORT'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Dist City To Airport'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1552821748193518298)
,p_db_column_name=>'LAND_AREA_COVERED'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Land Area Covered'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1552823000803518298)
,p_db_column_name=>'AIR_TAXI_OPS'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Air Taxi Ops'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1552823372153518298)
,p_db_column_name=>'GEOMETRY'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Geometry'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1549329485654770562)
,p_db_column_name=>'AIRPORT_TYPE'
,p_display_order=>140
,p_column_identifier=>'O'
,p_column_label=>'Airport Type'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(784653992832144639)
,p_db_column_name=>'SCALE'
,p_display_order=>150
,p_column_identifier=>'P'
,p_column_label=>'Scale'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1558831041290793405)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'24064'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>10
,p_report_columns=>'IATA_CODE:AIRPORT_NAME:STATE_NAME:ACTIVATION_DATE::SCALE'
,p_sort_column_1=>'CITY'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'COMMERCIAL_OPS'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'ACTIVATION_DATE'
,p_sort_direction_3=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1558326525809256275)
,p_plug_name=>'Map'
,p_region_name=>'airport-map-region'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       IATA_CODE,',
'       CITY,',
'       STATE_NAME,',
'       AIRPORT_NAME,',
'       AIRPORT_TYPE,',
'       ELEVATION,',
'       DIST_CITY_TO_AIRPORT,',
'       LAND_AREA_COVERED,',
'       to_char(ACTIVATION_DATE_DT,''fmDDfm-MON-YYYY'') as ACTIVATION_DATE,',
'       COMMERCIAL_OPS,',
'       to_char(COMMERCIAL_OPS,''999G999G999G999'') as com_ops_fmtd,',
'       AIR_TAXI_OPS,',
'       to_char(AIR_TAXI_OPS,''999G999G999G999'') as air_ops_fmtd,',
'       GEOMETRY,',
'       case when commercial_ops > 100000 then ''Airport'' else ''Flag Pennant'' end as shape,',
'       case when commercial_ops > 100000 then ''red'' else ''gray'' end as color,',
'       case when commercial_ops > 100000 then ''fa-map-marker-s'' else ''fa-flag-pennant'' end as icon,',
'       case when commercial_ops > 100000 then 2 else 1 end as scale',
'  from EBA_SAMPLE_MAP_AIRPORTS',
' where COMMERCIAL_OPS > 1000'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(1552826764272518317)
,p_region_id=>wwv_flow_imp.id(1558326525809256275)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-110'
,p_init_position_lat_static=>'35'
,p_init_zoomlevel_static=>'4'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_map_status_item=>'P123_BBOX'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(736072326851862238)
,p_map_region_id=>wwv_flow_imp.id(1552826764272518317)
,p_name=>'Small Airports'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_row_assignment_column=>'SCALE'
,p_row_assignment_value=>'1'
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#ffffff'
,p_fill_color=>'&COLOR.'
,p_fill_opacity=>.8
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'&SHAPE.'
,p_point_svg_shape_scale=>'&SCALE.'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'&AIRPORT_NAME. (&IATA_CODE.)'
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&AIRPORT_NAME. (&IATA_CODE.)</strong><br>',
'&CITY., &STATE_NAME.'))
,p_legend_icon_css_classes=>'fa-flag-pennant'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1552827310233518321)
,p_map_region_id=>wwv_flow_imp.id(1552826764272518317)
,p_name=>'Large Airports'
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_row_assignment_column=>'SCALE'
,p_row_assignment_value=>'2'
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#ffffff'
,p_fill_color=>'&COLOR.'
,p_fill_opacity=>.8
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'&SHAPE.'
,p_point_svg_shape_scale=>'&SCALE.'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'<strong>&AIRPORT_NAME. (&IATA_CODE.)</strong>'
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>&AIRPORT_NAME. (&IATA_CODE.)</h3>',
'<p>&AIRPORT_TYPE.<br>',
'<strong>&CITY., &STATE_NAME.</strong><br>',
'{if ACTIVATION_DATE/}',
'Activation Date: &ACTIVATION_DATE.<br>',
'{endif/}',
'{if COMMERCIAL_OPS/}',
'Commercial Operations: &COM_OPS_FMTD.<br>',
'{endif/}',
'{if AIR_TAXI_OPS/}',
'Taxi Operations: &AIR_OPS_FMTD.<br>',
'{endif/}'))
,p_legend_icon_css_classes=>'fa-map-marker-s'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(780646600808701834)
,p_name=>'P123_LARGE_VISIBLE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1558326525809256275)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(780646686291701835)
,p_name=>'P123_SMALL_VISIBLE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1558326525809256275)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1552728466386058068)
,p_name=>'P123_BBOX'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1558326525809256275)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1552829540099518378)
,p_name=>'Map Refresh'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#airport-map-region'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'refresh_and_center'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1552830551787518382)
,p_event_id=>wwv_flow_imp.id(1552829540099518378)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1558326525809256275)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1552830957436518382)
,p_name=>'Refresh Report'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1558326525809256275)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v("P123_BBOX") !== "" && apex.region("airport-map-region").call("getMapCenterAndZoomLevel").zoom >= 3'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapchanged'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(780646546475701833)
,p_event_id=>wwv_flow_imp.id(1552830957436518382)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// the "map-changed" event sends the type of change as the "changeType" attribute. "toggle-layer" indicates',
'// that the layer visibility has been toggled by clicking the layer entry in the legend.',
'if ( this.data.changeType === "toggle-layer") {',
'    //',
'    // "copy" the layer visibility information from the dynamic action "payload" object to the',
'    // P123_LARGE_VISIBLE and P123_SMALL_VISIBLE page items, which are then picked up by the',
'    // report query.',
'    for ( l = 0; l < this.data.layers.length; l++) {',
'        if ( this.data.layers[ l ].name === "Small Airports" ) {',
'            apex.item( "P123_SMALL_VISIBLE" ).setValue( ( this.data.layers[ l ].visible ? ''Y'' : ''N'' ) );',
'        } else if ( this.data.layers[ l ].name === "Large Airports" ) {',
'            apex.item( "P123_LARGE_VISIBLE" ).setValue( ( this.data.layers[ l ].visible ? ''Y'' : ''N'' ) );',
'        }',
'    }',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1552728939458058073)
,p_event_id=>wwv_flow_imp.id(1552830957436518382)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1552728732424058071)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(736072216441862237)
,p_event_id=>wwv_flow_imp.id(1552830957436518382)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(736070018834862215)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1552728718230058070)
,p_event_id=>wwv_flow_imp.id(1552830957436518382)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(736070018834862215)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1552728528606058069)
,p_event_id=>wwv_flow_imp.id(1552830957436518382)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(736070018834862215)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1552728878911058072)
,p_event_id=>wwv_flow_imp.id(1552830957436518382)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1552728732424058071)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(623070051810530832)
,p_name=>'On Click Point'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1558326525809256275)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapobjectclick'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(623070182480530833)
,p_event_id=>wwv_flow_imp.id(623070051810530832)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'showFeature( this.data.id, false );'
);
wwv_flow_imp.component_end;
end;
/
