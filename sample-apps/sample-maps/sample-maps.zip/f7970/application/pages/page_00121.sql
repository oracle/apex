prompt --application/pages/page_00121
begin
--   Manifest
--     PAGE: 00121
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>121
,p_name=>'Airports Search'
,p_alias=>'AIRPORTS-SEARCH'
,p_step_title=>'&APP_NAME. - Airports Search'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function showFeature( pId ) {',
'    apex.item( "P121_ID").setValue( pId );',
'    apex.event.trigger( $("#airport-map-region"), "refresh_and_center" );',
'}'))
,p_inline_css=>'td[headers="LINK"] {text-align: center;}'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_upd_yyyymmddhh24miss=>'20220823161416'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1547995850437599354)
,p_plug_name=>'About This Page'
,p_region_name=>'about_this_page'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-size480x320'
,p_region_attributes=>'data-parent-element="#help_button"'
,p_plug_template=>wwv_flow_imp.id(1548371059936069414)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>'<p>This page shows how to combine an Interactive Report with a Map Region. First look up an airport in the interactive report. Clicking the <strong><span class="fa fa-map-marker"></span></strong> button shows this airport within the map region on the'
||' right.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1548123423738698277)
,p_plug_name=>'Airports'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1548374350541069417)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>6
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       IATA_CODE,',
'       initcap(AIRPORT_NAME) airport_name,',
'       initcap(CITY) as city,',
'       STATE_NAME,',
'       ELEVATION,',
'       DIST_CITY_TO_AIRPORT,',
'       LAND_AREA_COVERED,',
'       ACTIVATION_DATE_dt as ACTIVATION_DATE,',
'       nvl(COMMERCIAL_OPS,0) COMMERCIAL_OPS,',
'       AIR_TAXI_OPS,',
'       GEOMETRY',
'  from EBA_SAMPLE_MAP_AIRPORTS',
' where airport_type = ''AIRPORT'''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'New'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1548123610744698279)
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'javascript:showFeature(''#ID#'')'
,p_detail_link_text=>'<span class="t-Icon fa fa-lg fa-map-marker-s u-danger-text" aria-hidden="true"></span>'
,p_detail_link_attr=>'style="text-align: center;"'
,p_owner=>'CCZARSKI'
,p_internal_uid=>1607133098636613
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1548123770298698280)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1548123856762698281)
,p_db_column_name=>'IATA_CODE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Code'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1548123916133698282)
,p_db_column_name=>'CITY'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'City'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1548123990732698283)
,p_db_column_name=>'STATE_NAME'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'State'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1548124612428698289)
,p_db_column_name=>'ACTIVATION_DATE'
,p_display_order=>50
,p_column_identifier=>'J'
,p_column_label=>'Opened'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1548124690710698290)
,p_db_column_name=>'COMMERCIAL_OPS'
,p_display_order=>60
,p_column_identifier=>'K'
,p_column_label=>'Operations'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1548124346493698286)
,p_db_column_name=>'ELEVATION'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Elevation'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1548124411492698287)
,p_db_column_name=>'DIST_CITY_TO_AIRPORT'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Dist City To Airport'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1548124508211698288)
,p_db_column_name=>'LAND_AREA_COVERED'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Land Area Covered'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1548124838913698291)
,p_db_column_name=>'AIR_TAXI_OPS'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Air Taxi Ops'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1548124964328698292)
,p_db_column_name=>'GEOMETRY'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Geometry'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1541528148183884268)
,p_db_column_name=>'AIRPORT_NAME'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Airport Name'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1548629527697235423)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'21131'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'AIRPORT_NAME:IATA_CODE:CITY:STATE_NAME:COMMERCIAL_OPS:'
,p_sort_column_1=>'COMMERCIAL_OPS'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'ACTIVATION_DATE'
,p_sort_direction_2=>'DESC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(1544327290781495745)
,p_report_id=>wwv_flow_imp.id(1548629527697235423)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'COMMERCIAL_OPS'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>'"COMMERCIAL_OPS" > to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1549164266299636263)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Commercial Airports'
,p_report_seq=>10
,p_report_alias=>'26478'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'IATA_CODE:AIRPORT_NAME:STATE_NAME:COMMERCIAL_OPS:'
,p_sort_column_1=>'COMMERCIAL_OPS'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'ACTIVATION_DATE'
,p_sort_direction_2=>'DESC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(1544328398339502864)
,p_report_id=>wwv_flow_imp.id(1549164266299636263)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'COMMERCIAL_OPS'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>'"COMMERCIAL_OPS" > to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1549165266374638760)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Large Airports'
,p_report_seq=>10
,p_report_alias=>'26488'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'IATA_CODE:AIRPORT_NAME:STATE_NAME:COMMERCIAL_OPS:'
,p_sort_column_1=>'COMMERCIAL_OPS'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'ACTIVATION_DATE'
,p_sort_direction_2=>'DESC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(1544329239519504501)
,p_report_id=>wwv_flow_imp.id(1549165266374638760)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'COMMERCIAL_OPS'
,p_operator=>'>'
,p_expr=>'100000'
,p_condition_sql=>'"COMMERCIAL_OPS" > to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1549166242042641295)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'All Airports'
,p_report_seq=>10
,p_report_alias=>'26498'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'AIRPORT_NAME:IATA_CODE:STATE_NAME:COMMERCIAL_OPS:'
,p_sort_column_1=>'COMMERCIAL_OPS'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'ACTIVATION_DATE'
,p_sort_direction_2=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1548125012215698293)
,p_plug_name=>'Map'
,p_region_name=>'airport-map-region'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1548347865227069394)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(1548125101263698294)
,p_region_id=>wwv_flow_imp.id(1548125012215698293)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1548125211660698295)
,p_map_region_id=>wwv_flow_imp.id(1548125101263698294)
,p_name=>'Airport'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ID,',
'    IATA_CODE,',
'    AIRPORT_TYPE,',
'    AIRPORT_NAME,',
'    CITY,',
'    STATE_NAME,',
'    to_char(ACTIVATION_DATE_DT,''fmDDfm-MON-YYYY'') as ACTIVATION_DATE,',
'    ELEVATION,',
'    DIST_CITY_TO_AIRPORT,',
'    LAND_AREA_COVERED,',
'    COMMERCIAL_OPS,',
'    to_char(COMMERCIAL_OPS,''999G999G999G999'') as com_ops_fmtd,',
'    AIR_TAXI_OPS,',
'    to_char(AIR_TAXI_OPS,''999G999G999G999'') as air_ops_fmtd,',
'    GEOMETRY',
'from ',
'    eba_sample_map_airports',
'where',
'    ID = :P121_ID'))
,p_items_to_submit=>'P121_ID'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#ffffff'
,p_fill_color=>'#ff0000'
,p_fill_opacity=>.8
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_point_svg_shape_scale=>'2'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>&AIRPORT_NAME. (&IATA_CODE.)</h3>',
'<p><strong>&CITY., &STATE_NAME.</strong><br>',
'{if ACTIVATION_DATE/}',
'Activation Date: &ACTIVATION_DATE.<br>',
'{endif/}',
'{if COMMERCIAL_OPS/}',
'Commercial Operations: &COM_OPS_FMTD.<br>',
'{endif/}',
'{if AIR_TAXI_OPS/}',
'Taxi Operations: &AIR_OPS_FMTD.<br>',
'{endif/}'))
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1548125314606698296)
,p_name=>'P121_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1548125012215698293)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1548125408589698297)
,p_name=>'Map Refresh'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#airport-map-region'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'refresh_and_center'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1548125482257698298)
,p_event_id=>wwv_flow_imp.id(1548125408589698297)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1548125012215698293)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1548125612751698299)
,p_name=>'Show Feature'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1548125012215698293)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1548125677747698300)
,p_event_id=>wwv_flow_imp.id(1548125612751698299)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lMapRegion   = apex.region("airport-map-region"),',
'    // important: Use the layer name exactly as specified in the "name" attribute in Page Designer',
'    lLayerId     = lMapRegion.call("getLayerIdByName", "Airport"),',
'    lCurrentZoom = lMapRegion.call("getMapCenterAndZoomLevel").zoom,',
'    lAirportId   = apex.item("P121_ID").getValue(),',
'    lFeature     = lMapRegion.call("getFeature", lLayerId, lAirportId ),',
'    lPosition;',
'',
'if ( lFeature.geometry ) {',
'    lPosition    = lFeature.geometry.coordinates;',
'        ',
'    // close all Info Windows, which might currently be open',
'    lMapRegion.call( "closeAllInfoWindows" );',
'',
'    // focus the map to the chosen feature',
'    lMapRegion.call( "setCenter", lPosition );',
'',
'    // if the current zoom level is below 8, zoom in. Otherwise do nothing.',
'    if ( lCurrentZoom < 12 ) {',
'        lMapRegion.call( "setZoomLevel", 12 );',
'    }',
'    setTimeout( function() {lMapRegion.call( "displayPopup", "infoWindow", lLayerId, lAirportId.toString(), false )}, 500 );',
'}'))
);
wwv_flow_imp.component_end;
end;
/
