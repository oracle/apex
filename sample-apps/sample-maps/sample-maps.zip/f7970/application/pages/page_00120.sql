prompt --application/pages/page_00120
begin
--   Manifest
--     PAGE: 00120
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>120
,p_user_interface_id=>wwv_flow_api.id(1548464614636069603)
,p_name=>'Airports Faceted Search'
,p_alias=>'AIRPORTS'
,p_step_title=>'&APP_NAME. - Airports Faceted Search'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_api.id(1548321470212069302)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210506080407'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1547995938323599355)
,p_plug_name=>'About This Page'
,p_region_name=>'about_this_page'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-size480x320'
,p_region_attributes=>'data-parent-element="#help_button"'
,p_plug_template=>wwv_flow_api.id(1548371059936069414)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>'<p>This page demonstrates the <strong>Faceted Search</strong> feature in combination with the <strong>Map Region</strong>. As long as the map is zoomed out, airports are displayed as a <em>Heat Map</em>. Zoom in on the map in order to see clickable <'
||'em>Map Markers</em>.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1548126093810698304)
,p_plug_name=>'Facets'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1548347865227069394)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<div id="current-facets"></div>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1549808844491663991)
,p_plug_name=>'Airports Map'
,p_region_name=>'airport-map-region'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1548347865227069394)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       IATA_CODE,',
'       CITY,',
'       airport_type,',
'       airport_name,',
'       STATE_NAME,',
'       ELEVATION,',
'       DIST_CITY_TO_AIRPORT,',
'       LAND_AREA_COVERED,',
'       ACTIVATION_DATE_dt ACTIVATION_DATE,',
'       nvl(COMMERCIAL_OPS,0) COMMERCIAL_OPS,',
'       to_char(COMMERCIAL_OPS,''999G999G999G999'') as com_ops_fmtd,',
'       AIR_TAXI_OPS,',
'       to_char(AIR_TAXI_OPS,''999G999G999G999'') as air_ops_fmtd,',
'       case when nvl(COMMERCIAL_OPS,0) < 10000 then ''Y'' else ''N'' end as tiny_airport,',
'       case when COMMERCIAL_OPS < 10000 then 1',
'            when COMMERCIAL_OPS between 10000 and 50000 then 1.5',
'            when COMMERCIAL_OPS between 50000 and 100000 then 2',
'            else 2.5',
'       end marker_size,',
'       GEOMETRY',
'  from EBA_SAMPLE_MAP_AIRPORTS',
'  where commercial_ops is not null',
' '))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_map_region(
 p_id=>wwv_flow_api.id(1549808948998663992)
,p_region_id=>wwv_flow_api.id(1549808844491663991)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-100'
,p_init_position_lat_static=>'35'
,p_init_zoomlevel_static=>'3'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
,p_custom_styles=>wwv_flow_string.join(wwv_flow_t_varchar2(
'[',
'    {',
'        "name": "Airport",',
'        "width": 20,',
'        "height": 20,',
'        "paint-order": "stroke",',
'        "viewBox": "0 0 20 20",',
'        "elements": [',
'            {',
'                "type": "path",',
'                "d": "M10,2A6.006,6.006,0,0,0,4,8c0,3.652,5.4,9.587,5.631,9.838a.5.5,0,0,0,.738,0C10.6,17.587,16,11.652,16,8A6.006,6.006,0,0,0,10,2Z"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M12.942,5.942,11.783,7.1l.655,2.836a.5.5,0,0,1-.317.583.509.509,0,0,1-.171.03.5.5,0,0,1-.445-.273l-.978-1.92-.986.986.123,1.1a.5.5,0,0,1-.972.213L8.354,9.646,7.342,9.308a.5.5,0,0,1-.33-.582.509.509,0,0,1,.543-.39l1.1.123.986-.98'
||'6L7.723,6.5a.5.5,0,0,1,.34-.933l2.836.655,1.159-1.159a.625.625,0,0,1,.884.884Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            }',
'        ]',
'    },',
'    {',
'        "name": "Heliport",',
'        "width": 20,',
'        "height": 20,',
'        "paint-order": "stroke",',
'        "viewBox": "0 0 20 20",',
'        "elements": [',
'            {',
'                "type": "path",',
'                "d": "M10,19a1.5,1.5,0,0,1-1.106-.487C8.291,17.855,3,11.967,3,8A7,7,0,0,1,17,8c0,3.967-5.291,9.855-5.894,10.514A1.506,1.506,0,0,1,10,19Z",',
'                "fill":"#ffffff"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M10,2A6.006,6.006,0,0,0,4,8c0,3.652,5.4,9.587,5.631,9.838a.5.5,0,0,0,.738,0C10.6,17.587,16,11.652,16,8A6.006,6.006,0,0,0,10,2Z"',
'            },',
'            {',
'                "type": "path",',
'                "d": "M10.454,9.7h1.224a1.008,1.008,0,0,0,.713-1.722A2.663,2.663,0,0,0,10.5,7.2h-.421v-.94h2.194a.314.314,0,0,0,0-.627H10.075V5.523a.314.314,0,0,0-.627,0v.105H7.254a.314.314,0,1,0,0,.627H9.448V7.2H6.418a.418.418,0,0,0,0,.836H7.5a1,1,0'
||',0,1,.707.293l.767.766A2.091,2.091,0,0,0,10.454,9.7Z",',
'                "fill":"#ffffff"',
'            },',
'            {',
'                "type": "path",',
'                "d": "M12.625,11.378a.375.375,0,0,0,0-.75H8.375a.375.375,0,0,0,0,.75Z",',
'                "fill":"#ffffff"',
'            }',
'        ]',
'    },',
'    {',
'        "name": "Small Airport",',
'        "width": 20,',
'        "height": 20,',
'        "paint-order": "stroke",',
'        "viewBox": "0 0 20 20",',
'        "elements": [',
'            {',
'                "type": "path",',
'                "d": "M10,19a1.5,1.5,0,0,1-1.106-.487C8.291,17.855,3,11.967,3,8A7,7,0,0,1,17,8c0,3.967-5.291,9.855-5.894,10.514A1.506,1.506,0,0,1,10,19Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M10,2A6.006,6.006,0,0,0,4,8c0,3.652,5.4,9.587,5.631,9.838a.5.5,0,0,0,.738,0C10.6,17.587,16,11.652,16,8A6.006,6.006,0,0,0,10,2Z"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M11.94,7.375h-.963L9.435,4.906a.5.5,0,0,0-.9.42L9.2,7.375H8.307l-.693-.866a.508.508,0,0,0-.66-.109.5.5,0,0,0-.177.645L7.29,8.072a1,1,0,0,0,.894.553H9.2l-.666,2.049a.5.5,0,0,0,.122.508.5.5,0,0,0,.778-.088l1.542-2.469h.963a.625.62'
||'5,0,0,0,0-1.25Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M13.076,9a.2.2,0,0,1-.2-.2V7.2a.2.2,0,1,1,.4,0V8.8A.2.2,0,0,1,13.076,9Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            }',
'        ]',
'    }',
']'))
);
wwv_flow_api.create_map_region_layer(
 p_id=>wwv_flow_api.id(1549809059881663993)
,p_map_region_id=>wwv_flow_api.id(1549808948998663992)
,p_name=>'All Airports'
,p_label=>'Airport Density'
,p_layer_type=>'HEATMAP'
,p_display_sequence=>10
,p_visible_max_zoom_level=>4
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_fill_color_spectr_name=>'Sunset'
,p_fill_color_spectr_type=>'SEQUENTIAL'
,p_allow_hide=>true
,p_condition_type=>'NEVER'
);
wwv_flow_api.create_map_region_layer(
 p_id=>wwv_flow_api.id(1548126076400698303)
,p_map_region_id=>wwv_flow_api.id(1549808948998663992)
,p_name=>'Smaller Airports'
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_row_assignment_column=>'TINY_AIRPORT'
,p_row_assignment_value=>'Y'
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#ffffff'
,p_fill_color=>'#392423'
,p_fill_opacity=>.8
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Flag Pennant'
,p_point_svg_shape_scale=>'0.9'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'&AIRPORT_NAME. (&IATA_CODE.)'
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>&AIRPORT_NAME. (&IATA_CODE.)</h3>',
'<p><strong>&CITY., &STATE_NAME.</strong><br>',
'{if ACTIVATION_DATE/}',
'Activation Date: &ACTIVATION_DATE.<br>',
'{endif/}',
'{if COMMERCIAL_OPS/}',
'Commercial Operations: &COM_OPS_FMTD.<br>',
'{endif/}',
'{if AIR_TAXI_OPS/}',
'Taxi Operations: &AIR_OPS_FMTD.<br>',
'{endif/}'))
,p_allow_hide=>true
);
wwv_flow_api.create_map_region_layer(
 p_id=>wwv_flow_api.id(1548125902056698302)
,p_map_region_id=>wwv_flow_api.id(1549808948998663992)
,p_name=>'Larger Airports'
,p_layer_type=>'POINT'
,p_display_sequence=>30
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_row_assignment_column=>'TINY_AIRPORT'
,p_row_assignment_value=>'N'
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#ffffff'
,p_fill_color=>'#ff0000'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Airport'
,p_point_svg_shape_scale=>'&MARKER_SIZE.'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'<strong>&AIRPORT_NAME. (&IATA_CODE.)</strong>'
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>&AIRPORT_NAME. (&IATA_CODE.)</h3>',
'<p><strong>&CITY., &STATE_NAME.</strong><br>',
'{if ACTIVATION_DATE/}',
'Activation Date: &ACTIVATION_DATE.<br>',
'{endif/}',
'{if COMMERCIAL_OPS/}',
'Commercial Operations: &COM_OPS_FMTD.<br>',
'{endif/}',
'{if AIR_TAXI_OPS/}',
'Taxi Operations: &AIR_OPS_FMTD.<br>',
'{endif/}'))
,p_allow_hide=>true
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1549809082237663994)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1548347865227069394)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_api.id(1549808844491663991)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#current-facets'
,p_attribute_09=>'Y'
,p_attribute_10=>'Airport Count:'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1541527997155884267)
,p_name=>'P120_AIRPORT_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(1549809082237663994)
,p_prompt=>'Airport Type'
,p_source=>'AIRPORT_TYPE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>true
,p_fc_initial_collapsed=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_toggleable=>false
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1549137063287502579)
,p_name=>'P120_STATE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(1549809082237663994)
,p_prompt=>'State'
,p_source=>'STATE_NAME'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>true
,p_fc_initial_collapsed=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>true
,p_fc_sort_by_top_counts=>false
,p_fc_show_selected_first=>true
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_toggleable=>false
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1549809218581663995)
,p_name=>'P120_ACTIVATION_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(1549809082237663994)
,p_prompt=>'Opened'
,p_source=>'ACTIVATION_DATE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC2:before 1950;|19500101000000,1950 - 1970;19500101000000|19700101000000,1970 - 1990;19700101000000|19900101000000,1990 - 2005;19900101000000|20050101000000,since 2005;20050101000000|'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>true
,p_fc_initial_collapsed=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_toggleable=>true
,p_fc_initial_toggled=>false
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(1549809419010663997)
,p_name=>'P120_COMMERCIAL_OPS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(1549809082237663994)
,p_prompt=>'Operations'
,p_source=>'COMMERCIAL_OPS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC2:none;|1,less than 1000;1|1000,1000 to 10K;1000|10000,10K to 100K;10000|100000,more than 100K;100000|'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>true
,p_fc_initial_collapsed=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_toggleable=>true
,p_fc_initial_toggled=>false
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(779348910890710151)
,p_name=>'On Click Point'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(1549808844491663991)
,p_bind_type=>'bind'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapobjectclick'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(779349327832710152)
,p_event_id=>wwv_flow_api.id(779348910890710151)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const { lng, lat } = this.data;',
'',
'apex.region("airport-map-region").call( "getMapObject" ).flyTo({ ',
'    center: [ lng, lat ],',
'    screenSpeed: 0.8',
'});'))
);
wwv_flow_api.component_end;
end;
/
