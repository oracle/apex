prompt --application/pages/page_00114
begin
--   Manifest
--     PAGE: 00114
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>114
,p_name=>'US States with Links'
,p_alias=>'US-STATES-WITH-LINKS'
,p_step_title=>'&APP_NAME. - US States with Links'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'19'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1555798001748485656)
,p_plug_name=>'About This Page'
,p_region_name=>'about_this_page'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-size480x320'
,p_region_attributes=>'data-parent-element="#help_button"'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'This map visualizes US states as <em>Extruded</em> polygons. Polygon color is derived from ',
'the "airport count" by state. The states and airports table are joined using the state name. ',
'Click on a state to be redirected to a <em>Faceted Search</em> page with more details.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1564467414307151027)
,p_plug_name=>'Airports by State'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(1552748817689181516)
,p_region_id=>wwv_flow_imp.id(1564467414307151027)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-90'
,p_init_position_lat_static=>'35'
,p_init_zoomlevel_static=>'3'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1552749227960181517)
,p_map_region_id=>wwv_flow_imp.id(1552748817689181516)
,p_name=>'Airports by State'
,p_layer_type=>'POLYGON'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with data as (',
'    select s.ID,',
'       s.NAME,',
'       s.STATE_CODE,',
'       ( select count( a.id ) ',
'           from eba_sample_map_airports a',
'          where commercial_ops > 0 and upper(s.name) = upper(a.state_name) ) airport_count,',
'       s.GEOMETRY',
'  from EBA_SAMPLE_MAP_SIMPLE_STATES s',
') ',
'select id,',
'       upper(name) as name,',
'       state_code,',
'       airport_count,',
'       airport_count * 10 as polygon_height,',
'       geometry',
'  from data'))
,p_no_data_found_message=>'No States found.'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#101010'
,p_fill_color_is_spectrum=>true
,p_fill_color_spectr_name=>'Temps'
,p_fill_color_spectr_type=>'DIVERGING'
,p_fill_value_column=>'AIRPORT_COUNT'
,p_fill_opacity=>.7
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'NAME'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:110:P110_STATE:&NAME.'
,p_allow_hide=>true
);
wwv_flow_imp.component_end;
end;
/
