prompt --application/pages/page_00124
begin
--   Manifest
--     PAGE: 00124
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>124
,p_name=>'Nearest Neighbor Search'
,p_alias=>'NEAREST-NEIGHBOR-SEARCH'
,p_step_title=>'&APP_NAME. - Nearest Neighbor Search'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function showFeature( pId ) {',
'    var lMapRegion   = apex.region("airport-map-region"),',
'        // important: Use the layer name exactly as specified in the "name" attribute in Page Designer',
'        lLayerId     = lMapRegion.call("getLayerIdByName", "Neighbors"),',
'        lFeature     = lMapRegion.call("getFeature", lLayerId, pId );',
'',
'    if ( lFeature.geometry ) {',
'        lMapRegion.call( "closeAllInfoWindows" );',
'        lMapRegion.call( "displayPopup", "infoWindow", lLayerId, pId.toString(), false );',
'    }',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.popup-left {',
'    transform: translate(0, -10%) !important;',
'}'))
,p_step_template=>wwv_flow_imp.id(1548321470212069302)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_upd_yyyymmddhh24miss=>'20230110134707'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1912218494142019775)
,p_plug_name=>'Filters'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(1548376270170069419)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_02'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2317729174303770139)
,p_plug_name=>'About This Page'
,p_region_name=>'about_this_page'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-size480x320'
,p_region_attributes=>'data-parent-element="#help_button"'
,p_plug_template=>wwv_flow_imp.id(1548371059936069414)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page demonstrates a <em>Nearest Neighbor Search</em>. After the user clicked a position on the map and adjusted the filter settings, the application looks up <em>nearest neighbors</em> to the clicked position and shows them on the map as well'
||' as in the interactive report below the map.</p>',
'<p>This functionality is built on top of the <strong>SDO_NN</strong> Spatial SQL function, which walks through the spatial index and returns nearest neighbors based on the given position. Additional relational filters are respected, so that the retur'
||'ned neighbors are typically farther away as the filter selectivity increases.</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2323325074451968324)
,p_plug_name=>'Airports'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="height: 640px"'
,p_plug_template=>wwv_flow_imp.id(1548348038485069395)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       iata_code,',
'       initcap( city ) as city,',
'       initcap( airport_name ) as airport_name,',
'       initcap( airport_type ) as airport_type,',
'       state_name,',
'       elevation,',
'       dist_city_to_airport,',
'       land_area_covered,',
'       activation_date_dt as activation_date,',
'       commercial_ops,',
'       air_taxi_ops,',
'       geometry,',
'       sdo_nn_distance( 1 ) as distance',
'  from eba_sample_map_airports',
' where sdo_nn( geometry, mdsys.sdo_util.from_geojson (:P124_CLICK_POSITION ), case when :P124_MAX_DISTANCE is not null then ''distance='' || :P124_MAX_DISTANCE || '' '' end || ''unit=km'',   1 ) = ''TRUE''',
'   and airport_type = :P124_AIRPORT_TYPE',
'   and nvl( commercial_ops, 0 ) >= nvl( :P124_COMMERCIAL_OPS_MIN, 0)',
'   and :P124_CLICK_POSITION is not null and :P124_AIRPORT_TYPE is not null',
'   and ''Y'' = nvl(:P124_NEIGHBORS,''Y'')',
'   and rownum <=   :P124_NEIGHBOR_COUNT'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P124_AIRPORT_TYPE,P124_CLICK_POSITION,P124_COMMERCIAL_OPS_MIN,P124_NEIGHBOR_COUNT,P124_MAX_DISTANCE'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'New'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2323325261457968326)
,p_no_data_found_message=>'No nearest neighbors found. Click a position on the map to begin.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_control_break=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'javascript:showFeature(''#ID#'')'
,p_detail_link_text=>'<center><span class="t-Icon fa fa-lg fa-map-marker-s u-danger-text" aria-hidden="true"></span></center>'
,p_owner=>'CCZARSKI'
,p_internal_uid=>1548171950621184485
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547957316786382717)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547958117478382718)
,p_db_column_name=>'CITY'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'City'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547956684801382621)
,p_db_column_name=>'AIRPORT_NAME'
,p_display_order=>40
,p_column_identifier=>'N'
,p_column_label=>'Airport Name'
,p_column_html_expression=>'#AIRPORT_NAME# (#IATA_CODE#)'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547958531755382718)
,p_db_column_name=>'STATE_NAME'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'State'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547960186923382720)
,p_db_column_name=>'ACTIVATION_DATE'
,p_display_order=>60
,p_column_identifier=>'J'
,p_column_label=>'Opened'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547957783450382717)
,p_db_column_name=>'IATA_CODE'
,p_display_order=>70
,p_column_identifier=>'B'
,p_column_label=>'Code'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547960582697382720)
,p_db_column_name=>'COMMERCIAL_OPS'
,p_display_order=>80
,p_column_identifier=>'K'
,p_column_label=>'Operations'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547958941855382718)
,p_db_column_name=>'ELEVATION'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Elevation'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547959354902382718)
,p_db_column_name=>'DIST_CITY_TO_AIRPORT'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Dist City To Airport'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547959735021382719)
,p_db_column_name=>'LAND_AREA_COVERED'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Land Area Covered'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547960995307382720)
,p_db_column_name=>'AIR_TAXI_OPS'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Air Taxi Ops'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547961347303382721)
,p_db_column_name=>'GEOMETRY'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Geometry'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1547956952052382717)
,p_db_column_name=>'AIRPORT_TYPE'
,p_display_order=>140
,p_column_identifier=>'O'
,p_column_label=>'Airport Type'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1912219489363019785)
,p_db_column_name=>'DISTANCE'
,p_display_order=>150
,p_column_identifier=>'P'
,p_column_label=>'Distance&nbsp;KM'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'9G999G999G999G990D0'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2323831178410505470)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'7728084'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>10
,p_report_columns=>'DISTANCE:STATE_NAME:AIRPORT_NAME:CITY:ACTIVATION_DATE:'
,p_sort_column_1=>'DISTANCE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'CITY'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'COMMERCIAL_OPS'
,p_sort_direction_3=>'DESC'
,p_sort_column_4=>'ACTIVATION_DATE'
,p_sort_direction_4=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2323326662928968340)
,p_plug_name=>'Map'
,p_region_name=>'airport-map-region'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1548347865227069394)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(1547962492912382734)
,p_region_id=>wwv_flow_imp.id(2323326662928968340)
,p_height=>420
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-110'
,p_init_position_lat_static=>'35'
,p_init_zoomlevel_static=>'4'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
,p_custom_styles=>wwv_flow_string.join(wwv_flow_t_varchar2(
'[',
'    {',
'        "name": "Airport",',
'        "width": 20,',
'        "height": 20,',
'        "paint-order": "stroke",',
'        "viewBox": "0 0 20 20",',
'        "elements": [',
'            {',
'                "type": "path",',
'                "d": "M10,2A6.006,6.006,0,0,0,4,8c0,3.652,5.4,9.587,5.631,9.838a.5.5,0,0,0,.738,0C10.6,17.587,16,11.652,16,8A6.006,6.006,0,0,0,10,2Z"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M12.942,5.942,11.783,7.1l.655,2.836a.5.5,0,0,1-.317.583.509.509,0,0,1-.171.03.5.5,0,0,1-.445-.273l-.978-1.92-.986.986.123,1.1a.5.5,0,0,1-.972.213L8.354,9.646,7.342,9.308a.5.5,0,0,1-.33-.582.509.509,0,0,1,.543-.39l1.1.123.986-.98'
||'6L7.723,6.5a.5.5,0,0,1,.34-.933l2.836.655,1.159-1.159a.625.625,0,0,1,.884.884Z",',
'                "fill":"#ffffff",',
'                "fill-opacity":"1",',
'                "stroke": "none"',
'            }',
'        ]',
'    },',
'    {',
'        "name": "Small Airport",',
'        "width": 20,',
'        "height": 20,',
'        "paint-order": "stroke",',
'        "viewBox": "0 0 20 20",',
'        "elements": [',
'            {',
'                "type": "path",',
'                "d": "M10,19a1.5,1.5,0,0,1-1.106-.487C8.291,17.855,3,11.967,3,8A7,7,0,0,1,17,8c0,3.967-5.291,9.855-5.894,10.514A1.506,1.506,0,0,1,10,19Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M10,2A6.006,6.006,0,0,0,4,8c0,3.652,5.4,9.587,5.631,9.838a.5.5,0,0,0,.738,0C10.6,17.587,16,11.652,16,8A6.006,6.006,0,0,0,10,2Z"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M11.94,7.375h-.963L9.435,4.906a.5.5,0,0,0-.9.42L9.2,7.375H8.307l-.693-.866a.508.508,0,0,0-.66-.109.5.5,0,0,0-.177.645L7.29,8.072a1,1,0,0,0,.894.553H9.2l-.666,2.049a.5.5,0,0,0,.122.508.5.5,0,0,0,.778-.088l1.542-2.469h.963a.625.62'
||'5,0,0,0,0-1.25Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M13.076,9a.2.2,0,0,1-.2-.2V7.2a.2.2,0,1,1,.4,0V8.8A.2.2,0,0,1,13.076,9Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            }',
'        ]',
'    }',
']',
''))
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1547962972570382758)
,p_map_region_id=>wwv_flow_imp.id(1547962492912382734)
,p_name=>'Large Airports'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       IATA_CODE,',
'       CITY,',
'       STATE_NAME,',
'       AIRPORT_NAME,',
'       AIRPORT_TYPE,',
'       ELEVATION,',
'       DIST_CITY_TO_AIRPORT,',
'       LAND_AREA_COVERED,',
'       ACTIVATION_DATE,',
'       COMMERCIAL_OPS,',
'       AIR_TAXI_OPS,',
'       GEOMETRY',
'  from EBA_SAMPLE_MAP_AIRPORTS',
' where COMMERCIAL_OPS > 100000'))
,p_items_to_submit=>'P121_ID'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#000000'
,p_stroke_width=>.4
,p_fill_color=>'#363434'
,p_fill_opacity=>.2
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Airport'
,p_point_svg_shape_scale=>'2'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><strong>&AIRPORT_NAME. (&IATA_CODE.)</strong><br>',
'&CITY., &STATE_NAME.</p>'))
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1547994900601599344)
,p_map_region_id=>wwv_flow_imp.id(1547962492912382734)
,p_name=>'Distance Circle'
,p_layer_type=>'POLYGON'
,p_display_sequence=>20
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 0 as id,',
'       mdsys.sdo_util.circle_polygon(',
'        point         => mdsys.sdo_util.from_geojson( :P124_CLICK_POSITION ),',
'        radius        => :P124_MAX_DISTANCE * 1000,',
'        arc_tolerance => 1 ) as geometry',
'  from sys.dual',
' where :P124_MAX_DISTANCE is not null and :P124_CLICK_POSITION is not null  '))
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#101010'
,p_fill_color=>'#d8aa12'
,p_fill_color_is_spectrum=>false
,p_fill_opacity=>.2
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1912219092308019781)
,p_map_region_id=>wwv_flow_imp.id(1547962492912382734)
,p_name=>'Neighbors'
,p_layer_type=>'POINT'
,p_display_sequence=>40
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       IATA_CODE,',
'       CITY,',
'       STATE_NAME,',
'       AIRPORT_NAME,',
'       AIRPORT_TYPE,',
'       ELEVATION,',
'       DIST_CITY_TO_AIRPORT,',
'       LAND_AREA_COVERED,',
'       ACTIVATION_DATE,',
'       COMMERCIAL_OPS,',
'       AIR_TAXI_OPS,',
'       GEOMETRY,',
'       case ',
'           when sdo_nn_distance(1) < 50                 then ''#e06060''',
'           when sdo_nn_distance(1) between 50  and 100  then ''#c05050''',
'           when sdo_nn_distance(1) between 100 and 200  then ''#a04040''',
'           when sdo_nn_distance(1) between 200 and 500  then ''#803030''',
'           when sdo_nn_distance(1) between 500 and 1000 then ''#601010''',
'           else                                              ''#200000''',
'       end as color',
'  from EBA_SAMPLE_MAP_AIRPORTS',
' where sdo_nn( geometry, mdsys.sdo_util.from_geojson (:P124_CLICK_POSITION ), case when :P124_MAX_DISTANCE is not null then ''distance='' || :P124_MAX_DISTANCE || '' '' end || ''unit=km'', 1 ) = ''TRUE''',
'   and airport_type = :P124_AIRPORT_TYPE',
'   and nvl(commercial_ops,0) >= nvl( :P124_COMMERCIAL_OPS_MIN, 0)',
'   and :P124_CLICK_POSITION is not null and :P124_AIRPORT_TYPE is not null ',
'   and rownum <=   :P124_NEIGHBOR_COUNT'))
,p_items_to_submit=>'P124_COMMERCIAL_OPS_MIN,P124_NEIGHBOR_COUNT,P124_CLICK_POSITION,P124_AIRPORT_TYPE,P124_MAX_DISTANCE'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#ffffff'
,p_stroke_width=>2
,p_fill_color=>'&COLOR.'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Circle'
,p_point_svg_shape_scale=>'1.5'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'&AIRPORT_NAME. (&IATA_CODE.)'
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>&AIRPORT_NAME. (&IATA_CODE.)</h3>',
'<p>&AIRPORT_TYPE.<br>',
'<strong>&CITY., &STATE_NAME.</strong><br>',
'{if ACTIVATION_DATE/}',
'Activation Date: &ACTIVATION_DATE.<br>',
'{endif/}',
'{if COMMERCIAL_OPS/}',
'Commercial Operations: &COMMERCIAL_OPS.<br>',
'{endif/}',
'{if AIR_TAXI_OPS/}',
'Taxi Operations: &AIR_TAXI_OPS.<br>',
'{endif/}'))
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1912219402267019784)
,p_map_region_id=>wwv_flow_imp.id(1547962492912382734)
,p_name=>'Clicked Position'
,p_label=>'my Position'
,p_layer_type=>'POINT'
,p_display_sequence=>50
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 0 as id, mdsys.sdo_util.from_geojson( :P124_CLICK_POSITION ) as geometry ',
'  from sys.dual',
' where :P124_CLICK_POSITION is not null'))
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#ffffff'
,p_stroke_width=>1
,p_fill_color=>'#007aff'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Pin Circle'
,p_point_svg_shape_scale=>'2'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'This is the position you have clicked on the map.'
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>'Your Position'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(779237450007141102)
,p_name=>'P124_NEIGHBORS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2323326662928968340)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1547994735788599343)
,p_name=>'P124_MAX_DISTANCE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1912218494142019775)
,p_prompt=>'Max Distance (km)'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(1548437532778069507)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Specify the maximum distance to return nearest neighbors in.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'0'
,p_attribute_02=>'10000'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1547994991088599345)
,p_name=>'P124_SEARCH_FROM'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1912218494142019775)
,p_prompt=>'Start Search at Airport'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_AIRPORTS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       airport_name,',
'       iata_code,',
'       initcap( airport_type ) airport_type,',
'       city,',
'       state_name,',
'       activation_date,',
'       apex_json.stringify( geometry ) as geojson',
'  from eba_sample_map_airports'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Pick an Airport or a Position on the Map -'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(1548437532778069507)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>'Pick an airport from the list to search nearest neighbors for. As an alternative, click any position on the map.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_attribute_08=>'800'
,p_attribute_10=>'GEOJSON:P124_CLICK_POSITION'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1912218351967019774)
,p_name=>'P124_CLICK_POSITION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2323326662928968340)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1912218526502019776)
,p_name=>'P124_AIRPORT_TYPE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1912218494142019775)
,p_item_default=>'AIRPORT'
,p_prompt=>'Airport Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Airport;AIRPORT,Heliport;HELIPORT,Seaplane Base;SEAPLANE BASE,Ultralight;ULTRALIGHT,Gliderport;GLIDERPORT,Balloonport;BALLOONPORT'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(1548437532778069507)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>'Nearest Neighbors will only return for the selected airport type.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1912218619797019777)
,p_name=>'P124_COMMERCIAL_OPS_MIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1912218494142019775)
,p_prompt=>'Minimum Operations'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(1548437532778069507)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Return only nearest neighbors with at least the specified amount of "commercial operations".'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1912218958166019780)
,p_name=>'P124_NEIGHBOR_COUNT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1912218494142019775)
,p_item_default=>'15'
,p_prompt=>'Nearest Neighbor Count'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(1548437532778069507)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Specify the maximum amount of nearest neighbors to return.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'1'
,p_attribute_02=>'20'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1912218788060019778)
,p_name=>'Click on Map'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2323326662928968340)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapclick'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1547995284630599348)
,p_event_id=>wwv_flow_imp.id(1912218788060019778)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_SEARCH_FROM'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1912218851199019779)
,p_event_id=>wwv_flow_imp.id(1912218788060019778)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_CLICK_POSITION'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'JSON.stringify({"type":"Point", "coordinates": [this.data.lng, this.data.lat]})'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1912219650436019787)
,p_name=>'Refresh after Change'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_AIRPORT_TYPE,P124_COMMERCIAL_OPS_MIN,P124_NEIGHBOR_COUNT,P124_MAX_DISTANCE,P124_CLICK_POSITION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1912219720122019788)
,p_event_id=>wwv_flow_imp.id(1912219650436019787)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2323326662928968340)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1912219910578019789)
,p_event_id=>wwv_flow_imp.id(1912219650436019787)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2323325074451968324)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(779237558943141103)
,p_name=>'Refresh Airports IRR if neighbors legend is toggled'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2323326662928968340)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.changeType === "toggle-layer"'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapchanged'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(779237694540141104)
,p_event_id=>wwv_flow_imp.id(779237558943141103)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// the "map-changed" event sends the type of change as the "changeType" attribute. "toggle-layer" indicates',
'// that the layer visibility has been toggled by clicking the layer entry in the legend.',
'// "copy" the layer visibility information from the dynamic action "payload" object to the',
'// P124_NEIGHBORS page item, which are then picked up by the',
'// report query.',
'for ( l = 0; l < this.data.layers.length; l++) {',
'    if ( this.data.layers[ l ].name === "Neighbors" ) {',
'        apex.item( "P124_NEIGHBORS" ).setValue( ( this.data.layers[ l ].visible ? ''Y'' : ''N'' ) );',
'    }',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(779237889391141106)
,p_event_id=>wwv_flow_imp.id(779237558943141103)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- This true action just ensures the hidden P124_NEIGHBORS value gets into session state',
'-- before refreshing the Airports IRR',
'null;'))
,p_attribute_02=>'P124_NEIGHBORS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(779237795519141105)
,p_event_id=>wwv_flow_imp.id(779237558943141103)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2323325074451968324)
);
wwv_flow_imp.component_end;
end;
/
