prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7970
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(1556268882524956022)
,p_group_name=>'Administration'
);
wwv_flow_imp.component_end;
end;
/
