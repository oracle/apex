prompt --application/pages/page_00115
begin
--   Manifest
--     PAGE: 00115
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>115
,p_user_interface_id=>wwv_flow_imp.id(1548464614636069603)
,p_name=>'US States and Large Airports'
,p_alias=>'US-STATES-AND-LARGE-AIRPORTS'
,p_step_title=>'&APP_NAME. - US States and Large Airports'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'19'
,p_last_upd_yyyymmddhh24miss=>'20210506080401'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1547996970590599365)
,p_plug_name=>'About This Page'
,p_region_name=>'about_this_page'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-size480x320'
,p_region_attributes=>'data-parent-element="#help_button"'
,p_plug_template=>wwv_flow_imp.id(1548371059936069414)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'This map visualizes US states as a <em>Polygon</em>) layer and the large airports (with more than 50,000 commercial operations) as a <em>Point</em> layer on top. ',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1561580525346228391)
,p_plug_name=>'States and Large Airports'
,p_region_name=>'airport-map-region'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1548348038485069395)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(1544131518179636282)
,p_region_id=>wwv_flow_imp.id(1561580525346228391)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-90'
,p_init_position_lat_static=>'35'
,p_init_zoomlevel_static=>'3'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
,p_custom_styles=>wwv_flow_string.join(wwv_flow_t_varchar2(
'[',
'    {',
'        "name": "Airport",',
'        "width": 20,',
'        "height": 20,',
'        "paint-order": "stroke",',
'        "viewBox": "0 0 20 20",',
'        "elements": [',
'            {',
'                "type": "path",',
'                "d": "M10,2A6.006,6.006,0,0,0,4,8c0,3.652,5.4,9.587,5.631,9.838a.5.5,0,0,0,.738,0C10.6,17.587,16,11.652,16,8A6.006,6.006,0,0,0,10,2Z"',
'            },',
'            {',
'                "type":"path",',
'                "d": "M12.942,5.942,11.783,7.1l.655,2.836a.5.5,0,0,1-.317.583.509.509,0,0,1-.171.03.5.5,0,0,1-.445-.273l-.978-1.92-.986.986.123,1.1a.5.5,0,0,1-.972.213L8.354,9.646,7.342,9.308a.5.5,0,0,1-.33-.582.509.509,0,0,1,.543-.39l1.1.123.986-.98'
||'6L7.723,6.5a.5.5,0,0,1,.34-.933l2.836.655,1.159-1.159a.625.625,0,0,1,.884.884Z",',
'                "fill":"#ffffff",',
'                "stroke": "none"',
'            }',
'        ]',
'    }',
']',
'',
''))
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1544132051631636285)
,p_map_region_id=>wwv_flow_imp.id(1544131518179636282)
,p_name=>'US States'
,p_layer_type=>'POLYGON'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_table_name=>'EBA_SAMPLE_MAP_SIMPLE_STATES'
,p_include_rowid_column=>false
,p_no_data_found_message=>'No States found.'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#ffffff'
,p_fill_color=>'#808080'
,p_fill_color_is_spectrum=>false
,p_fill_opacity=>.5
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'NAME'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1541527877555884265)
,p_map_region_id=>wwv_flow_imp.id(1544131518179636282)
,p_name=>'Large Airports'
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ID,',
'    IATA_CODE,',
'    AIRPORT_TYPE,',
'    AIRPORT_NAME,',
'    CITY,',
'    STATE_NAME,',
'    --ACTIVATION_DATE,',
'    to_char(ACTIVATION_DATE_DT,''fmDDfm-MON-YYYY'') as ACTIVATION_DATE,',
'    ELEVATION,',
'    DIST_CITY_TO_AIRPORT,',
'    LAND_AREA_COVERED,',
'    COMMERCIAL_OPS,',
'    to_char(COMMERCIAL_OPS,''999G999G999G999'') as com_ops_fmtd,',
'    AIR_TAXI_OPS,',
'    to_char(AIR_TAXI_OPS,''999G999G999G999'') as air_ops_fmtd,',
'    GEOMETRY',
'from ',
'    eba_sample_map_airports',
'where',
'    commercial_ops > 50000'))
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#ffffff'
,p_fill_color=>'#ff0000'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Airport'
,p_point_svg_shape_scale=>'1.5'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'&AIRPORT_NAME. (&IATA_CODE.)'
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>&AIRPORT_NAME. (&IATA_CODE.)</h3>',
'<p><strong>&CITY., &STATE_NAME.</strong><br>',
'{if ACTIVATION_DATE/}',
'Activation Date: &ACTIVATION_DATE.<br>',
'{endif/}',
'{if COMMERCIAL_OPS/}',
'Commercial Operations: &COM_OPS_FMTD.<br>',
'{endif/}',
'{if AIR_TAXI_OPS/}',
'Taxi Operations: &AIR_OPS_FMTD.<br>',
'{endif/}'))
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(779362086959980694)
,p_name=>'On Click Point'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1561580525346228391)
,p_bind_type=>'bind'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapobjectclick'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(779362462387980695)
,p_event_id=>wwv_flow_imp.id(779362086959980694)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const { lng, lat } = this.data;',
'',
'apex.region("airport-map-region").call( "getMapObject" ).flyTo({ ',
'    center: [ lng, lat ],',
'    screenSpeed: 0.8',
'});'))
);
wwv_flow_imp.component_end;
end;
/
