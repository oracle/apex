prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page - Desktop'
,p_step_title=>'Global Page - Desktop'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
,p_last_upd_yyyymmddhh24miss=>'20210609075831'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(728268434469975919)
,p_plug_name=>'Airport Data'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1548348038485069395)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_05'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>&AIRPORT_DATA.<br />',
'&US_STATES_DATA.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2327991724510922201)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1548385599038069436)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(1548320620918069282)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(1548441527127069524)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_plug_display_when_condition=>'1,2'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2342469797149020005)
,p_plug_name=>'Only minimal data is installed'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_imp.id(1548344173494069385)
,p_plug_display_sequence=>5
,p_plug_source=>'<p>Only the minimal dataset is currently installed in this application, so demo pages are limited. To install the full <strong>Airports</strong> and <strong>US States</strong> data, navigate to the <a href="f?p=&APP_ID.:501:&SESSION.::&DEBUG."><stron'
||'g><span class="fa fa-download"></span> Data Loading</strong></a> page.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_sample_map_states',
'union all',
'select 1 from sys.dual where :APP_PAGE_ID in ( 501,9999 )'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(778796344423099250)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2327991724510922201)
,p_button_name=>'HELP'
,p_button_static_id=>'help_button'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(1548440222930069520)
,p_button_image_alt=>'About This Page'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'2,9999'
,p_button_condition_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_icon_css_classes=>'fa-question-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(778795971130099247)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2327991724510922201)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(1548440222930069520)
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.::&DEBUG.:RR,&APP_PAGE_ID.::'
,p_button_condition=>'501,9999'
,p_button_condition_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(778798633711109373)
,p_name=>'Toggle Help'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(778796344423099250)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(778799029050109378)
,p_event_id=>wwv_flow_imp.id(778798633711109373)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.theme.openRegion("about_this_page");'
);
wwv_flow_imp.component_end;
end;
/
