prompt --application/pages/page_00201
begin
--   Manifest
--     PAGE: 00201
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>201
,p_name=>'Legacy Oracle Maps Plug-In'
,p_alias=>'LEGACY-ORACLE-MAPS-PLUG-IN'
,p_step_title=>'&APP_NAME. - Legacy Oracle Maps Plug-In'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1549329054472770558)
,p_plug_name=>'US States (Legacy Oracle Maps Plug-In)'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       name as infotip,',
'       geometry,',
'       ''blue'' as style,',
'       null as markersize',
'  from eba_sample_map_states',
'union all',
'select id,',
'       city || '' ('' || iata_code || '')'' as infotip,',
'       geometry,',
'       ''red'' as style,',
'       ''C'' || round(commercial_ops/10000) as markersize',
'  from eba_sample_map_airports',
' where commercial_ops > 50000',
''))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.ORAMAPS.HTML5'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'https://elocation.oracle.com/mapviewer',
  'attribute_03', '100,500',
  'attribute_06', '-115,35',
  'attribute_07', '4',
  'attribute_08', 'WEST',
  'attribute_09', '1',
  'attribute_13', 'MARQUEE:DISTANCE:SCALE',
  'attribute_14', '500',
  'attribute_15', '150',
  'attribute_16', '250',
  'attribute_17', 'Y',
  'attribute_18', 'Y',
  'attribute_19', 'N',
  'attribute_21', 'PERCENT',
  'attribute_22', 'METRIC',
  'attribute_24', 'OSM')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1555798233206485658)
,p_plug_name=>'About This Page'
,p_region_name=>'about_this_page'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-size480x320'
,p_region_attributes=>'data-parent-element="#help_button"'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'This map visualizes US states as a <em>Polygon</em>) layer and the large airports (with more than 50,000 commercial operations) as a <em>Point</em> layer on top.</p>',
'<p>The region uses the <strong>Oracle Maps Region Plug-In</strong> from the <strong>Sample Geolocation Showcase</strong> packaged application, which was shipped with APEX up to version 20.2.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
