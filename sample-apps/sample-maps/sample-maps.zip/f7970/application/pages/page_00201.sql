prompt --application/pages/page_00201
begin
--   Manifest
--     PAGE: 00201
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>201
,p_user_interface_id=>wwv_flow_imp.id(1548464614636069603)
,p_name=>'Legacy Oracle Maps Plug-In'
,p_alias=>'LEGACY-ORACLE-MAPS-PLUG-IN'
,p_step_title=>'&APP_NAME. - Legacy Oracle Maps Plug-In'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_upd_yyyymmddhh24miss=>'20210510110323'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1541527907248884266)
,p_plug_name=>'US States (Legacy Oracle Maps Plug-In)'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(1548376270170069419)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       name as infotip,',
'       geometry,',
'       ''blue'' as style,',
'       null as markersize',
'  from eba_sample_map_states',
'union all',
'select id,',
'       city || '' ('' || iata_code || '')'' as infotip,',
'       geometry,',
'       ''red'' as style,',
'       ''C'' || round(commercial_ops/10000) as markersize',
'  from eba_sample_map_airports',
' where commercial_ops > 50000',
''))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.ORAMAPS.HTML5'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'https://elocation.oracle.com/mapviewer'
,p_attribute_03=>'100,500'
,p_attribute_06=>'-115,35'
,p_attribute_07=>'4'
,p_attribute_08=>'WEST'
,p_attribute_09=>'1'
,p_attribute_13=>'MARQUEE:DISTANCE:SCALE'
,p_attribute_14=>'500'
,p_attribute_15=>'150'
,p_attribute_16=>'250'
,p_attribute_17=>'Y'
,p_attribute_18=>'Y'
,p_attribute_19=>'N'
,p_attribute_21=>'PERCENT'
,p_attribute_22=>'METRIC'
,p_attribute_24=>'OSM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1547997085982599366)
,p_plug_name=>'About This Page'
,p_region_name=>'about_this_page'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-size480x320'
,p_region_attributes=>'data-parent-element="#help_button"'
,p_plug_template=>wwv_flow_imp.id(1548371059936069414)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'This map visualizes US states as a <em>Polygon</em>) layer and the large airports (with more than 50,000 commercial operations) as a <em>Point</em> layer on top.</p>',
'<p>The region uses the <strong>Oracle Maps Region Plug-In</strong> from the <strong>Sample Geolocation Showcase</strong> packaged application, which was shipped with APEX up to version 20.2.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
