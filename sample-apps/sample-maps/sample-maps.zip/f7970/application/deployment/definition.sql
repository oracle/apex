prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7970
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(1556278723360956933)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table eba_sample_map_airports purge',
'/',
'',
'drop table eba_sample_map_states purge',
'/',
'',
'drop table eba_sample_map_simple_states purge',
'/',
'',
'',
'--',
'-- remove tables from Spatial Registry (USER_SDO_GEOM_METADATA)',
'--',
'begin',
'    apex_spatial.delete_geom_metadata(',
'        p_table_name  => ''EBA_SAMPLE_MAP_STATES'',',
'        p_column_name => ''GEOMETRY'' );',
'end;',
'/',
'',
'begin',
'    apex_spatial.delete_geom_metadata(',
'        p_table_name  => ''EBA_SAMPLE_MAP_SIMPLE_STATES'',',
'        p_column_name => ''GEOMETRY'' );',
'end;',
'/',
'',
'begin',
'    apex_spatial.delete_geom_metadata(',
'        p_table_name  => ''EBA_SAMPLE_MAP_AIRPORTS'',',
'        p_column_name => ''GEOMETRY'' );',
'end;',
'/',
'',
'drop procedure eba_sample_map_load_data',
'/'))
);
wwv_flow_imp.component_end;
end;
/
