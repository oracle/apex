prompt --application/deployment/install/install_create_spatial_indexes
begin
--   Manifest
--     INSTALL: INSTALL-Create Spatial Indexes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1550517362030861782)
,p_install_id=>wwv_flow_imp.id(1556278723360956933)
,p_name=>'Create Spatial Indexes'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_spatial.insert_geom_metadata_lonlat(',
'        p_table_name => ''EBA_SAMPLE_MAP_STATES'',',
'        p_column_name => ''GEOMETRY'',',
'        p_tolerance => 0.05 );',
'end;',
'/',
'',
'begin',
'    apex_spatial.insert_geom_metadata_lonlat(',
'        p_table_name => ''EBA_SAMPLE_MAP_SIMPLE_STATES'',',
'        p_column_name => ''GEOMETRY'',',
'        p_tolerance => 0.05 );',
'end;',
'/',
'',
'begin',
'    apex_spatial.insert_geom_metadata_lonlat(',
'        p_table_name => ''EBA_SAMPLE_MAP_AIRPORTS'',',
'        p_column_name => ''GEOMETRY'',',
'        p_tolerance => 0.05 );',
'end;',
'/',
'',
'create index eba_sample_map_airports_sx on eba_sample_map_airports(geometry)',
'indextype is mdsys.spatial_index_v2',
'parameters( ''layer_gtype=POINT'')',
'/',
'',
'create index eba_sample_map_simplestates_sx on eba_sample_map_simple_states(geometry)',
'indextype is mdsys.spatial_index_v2',
'/',
'',
'create index eba_sample_map_states_sx on eba_sample_map_states(geometry)',
'indextype is mdsys.spatial_index_v2',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
