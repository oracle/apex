prompt --application/deployment/install/install_create_spatial_indexes
begin
--   Manifest
--     INSTALL: INSTALL-Create Spatial Indexes
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(1542716214806975490)
,p_install_id=>wwv_flow_api.id(1548477576137070641)
,p_name=>'Create Spatial Indexes'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_spatial.insert_geom_metadata_lonlat(',
'        p_table_name => ''EBA_SAMPLE_MAP_STATES'',',
'        p_column_name => ''GEOMETRY'',',
'        p_tolerance => 0.05 );',
'end;',
'/',
'',
'begin',
'    apex_spatial.insert_geom_metadata_lonlat(',
'        p_table_name => ''EBA_SAMPLE_MAP_SIMPLE_STATES'',',
'        p_column_name => ''GEOMETRY'',',
'        p_tolerance => 0.05 );',
'end;',
'/',
'',
'begin',
'    apex_spatial.insert_geom_metadata_lonlat(',
'        p_table_name => ''EBA_SAMPLE_MAP_AIRPORTS'',',
'        p_column_name => ''GEOMETRY'',',
'        p_tolerance => 0.05 );',
'end;',
'/',
'',
'create index eba_sample_map_airports_sx on eba_sample_map_airports(geometry)',
'indextype is mdsys.spatial_index_v2',
'parameters( ''layer_gtype=POINT'')',
'/',
'',
'create index eba_sample_map_simplestates_sx on eba_sample_map_simple_states(geometry)',
'indextype is mdsys.spatial_index_v2',
'/',
'',
'create index eba_sample_map_states_sx on eba_sample_map_states(geometry)',
'indextype is mdsys.spatial_index_v2',
'/',
''))
);
wwv_flow_api.component_end;
end;
/
