prompt --application/deployment/install/install_table_eba_sample_map_states
begin
--   Manifest
--     INSTALL: INSTALL-Table EBA_SAMPLE_MAP_STATES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1556517841053911586)
,p_install_id=>wwv_flow_imp.id(1556278723360956933)
,p_name=>'Table EBA_SAMPLE_MAP_STATES'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--',
'-- create table',
'--',
'create table eba_sample_map_states (',
'   	id                     number not null primary key,',
'	name                   varchar2(255),',
'	state_code             varchar2(2),',
'    land_area              number,',
'    water_area             number,',
'    geometry               sdo_geometry )',
'/',
'',
'create table eba_sample_map_simple_states(',
'   	id                     number not null primary key,',
'	name                   varchar2(255),',
'	state_code             varchar2(2),',
'    land_area              number,',
'    water_area             number,',
'    geometry               sdo_geometry )',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
