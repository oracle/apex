prompt --application/deployment/checks
begin
--   Manifest
--     INSTALL CHECKS: 7970
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_check(
 p_id=>wwv_flow_imp.id(1546616746182111642)
,p_install_id=>wwv_flow_imp.id(1548477576137070641)
,p_name=>'Database Version is 12.2.0.1 or higher'
,p_sequence=>10
,p_check_type=>'EXPRESSION'
,p_check_condition=>'sys.dbms_db_version.version > 12 or ( sys.dbms_db_version.version = 12 and sys.dbms_db_version.release = 2 )'
,p_check_condition2=>'PLSQL'
,p_failure_message=>'This sample application requires Oracle Database 12.2 or higher.'
);
wwv_flow_imp_shared.create_install_check(
 p_id=>wwv_flow_imp.id(1543116143720007566)
,p_install_id=>wwv_flow_imp.id(1548477576137070641)
,p_name=>'SDO_GEOMETRY is available'
,p_sequence=>20
,p_check_type=>'EXISTS'
,p_check_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 ',
'  from sys.all_objects',
' where owner       = ''MDSYS''',
'   and object_name = ''SDO_GEOMETRY''',
'   and object_type = ''TYPE'''))
,p_failure_message=>'The SDO_GEOMETRY data type is not available in this database.'
);
wwv_flow_imp.component_end;
end;
/
