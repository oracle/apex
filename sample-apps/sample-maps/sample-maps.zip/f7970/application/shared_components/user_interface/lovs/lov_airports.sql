prompt --application/shared_components/user_interface/lovs/lov_airports
begin
--   Manifest
--     LOV_AIRPORTS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(1548021289554401858)
,p_lov_name=>'LOV_AIRPORTS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       airport_name,',
'       iata_code,',
'       initcap( airport_type ) airport_type,',
'       city,',
'       state_name,',
'       activation_date,',
'       apex_json.stringify( geometry ) as geojson',
'  from eba_sample_map_airports'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'EBA_SAMPLE_MAP_AIRPORTS'
,p_return_column_name=>'ID'
,p_display_column_name=>'AIRPORT_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(1548031297903443350)
,p_query_column_name=>'ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(1548031627319443350)
,p_query_column_name=>'AIRPORT_NAME'
,p_heading=>'Airport Name'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(1548032098243443350)
,p_query_column_name=>'IATA_CODE'
,p_heading=>'Code'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(1548032482883443351)
,p_query_column_name=>'AIRPORT_TYPE'
,p_heading=>'Airport Type'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(1548032883760443351)
,p_query_column_name=>'CITY'
,p_heading=>'City'
,p_display_sequence=>50
,p_data_type=>'VARCHAR2'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(1548033288714443351)
,p_query_column_name=>'STATE_NAME'
,p_heading=>'State'
,p_display_sequence=>60
,p_data_type=>'VARCHAR2'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(1548033699873443351)
,p_query_column_name=>'ACTIVATION_DATE'
,p_heading=>'Activation Date'
,p_display_sequence=>70
,p_format_mask=>'mon-yyyy'
,p_data_type=>'VARCHAR2'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(1548034047674443351)
,p_query_column_name=>'GEOJSON'
,p_heading=>'Geojson'
,p_display_sequence=>80
,p_data_type=>'CLOB'
,p_is_visible=>'N'
);
wwv_flow_api.component_end;
end;
/
