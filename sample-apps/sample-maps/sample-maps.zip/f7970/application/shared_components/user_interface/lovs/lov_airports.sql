prompt --application/shared_components/user_interface/lovs/lov_airports
begin
--   Manifest
--     LOV_AIRPORTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(1555822436778288150)
,p_lov_name=>'LOV_AIRPORTS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       airport_name,',
'       iata_code,',
'       initcap( airport_type ) airport_type,',
'       city,',
'       state_name,',
'       activation_date,',
'       apex_json.stringify( geometry ) as geojson',
'  from eba_sample_map_airports'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'EBA_SAMPLE_MAP_AIRPORTS'
,p_return_column_name=>'ID'
,p_display_column_name=>'AIRPORT_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1089080483
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(1555832445127329642)
,p_query_column_name=>'ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(1555832774543329642)
,p_query_column_name=>'AIRPORT_NAME'
,p_heading=>'Airport Name'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(1555833245467329642)
,p_query_column_name=>'IATA_CODE'
,p_heading=>'Code'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(1555833630107329643)
,p_query_column_name=>'AIRPORT_TYPE'
,p_heading=>'Airport Type'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(1555834030984329643)
,p_query_column_name=>'CITY'
,p_heading=>'City'
,p_display_sequence=>50
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(1555834435938329643)
,p_query_column_name=>'STATE_NAME'
,p_heading=>'State'
,p_display_sequence=>60
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(1555834847097329643)
,p_query_column_name=>'ACTIVATION_DATE'
,p_heading=>'Activation Date'
,p_display_sequence=>70
,p_format_mask=>'mon-yyyy'
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(1555835194898329643)
,p_query_column_name=>'GEOJSON'
,p_heading=>'Geojson'
,p_display_sequence=>80
,p_data_type=>'CLOB'
,p_is_visible=>'N'
);
wwv_flow_imp.component_end;
end;
/
