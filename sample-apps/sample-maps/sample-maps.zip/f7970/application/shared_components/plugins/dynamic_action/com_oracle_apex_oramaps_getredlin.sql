prompt --application/shared_components/plugins/dynamic_action/com_oracle_apex_oramaps_getredlin
begin
--   Manifest
--     PLUGIN: COM.ORACLE.APEX.ORAMAPS.GETREDLIN
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(1544236348997878111)
,p_plugin_type=>'DYNAMIC ACTION'
,p_name=>'COM.ORACLE.APEX.ORAMAPS.GETREDLIN'
,p_display_name=>'Legacy: Oracle Maps - Get Redline'
,p_category=>'MISC'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('DYNAMIC ACTION','COM.ORACLE.APEX.ORAMAPS.GETREDLIN'),'')
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function render_da_oramaps_getRedline(',
'    p_dynamic_action in apex_plugin.t_dynamic_action,',
'    p_plugin         in apex_plugin.t_plugin )',
'    return apex_plugin.t_dynamic_action_render_result',
'is',
'    l_type          varchar2(30)   := upper(p_dynamic_action.attribute_01);',
'    l_item_names    apex_application_page_da_acts.affected_elements%type;',
'    l_result        apex_plugin.t_dynamic_action_render_result;       ',
'begin',
'  begin',
'    select affected_elements into l_item_names',
'    from apex_application_page_da_acts',
'    where application_id = v(''APP_ID'') and page_id = v(''APP_PAGE_ID'')',
'    and action_id = p_dynamic_action.id;',
'  exception',
'    when NO_DATA_FOUND then ',
'      apex_debug.message(',
'        p_message => ''ORAMAPS_DA_GETREDLINE: FATAL ERROR: Dynamic Action ID "%s" not found in the APEX dictionary!'',',
'        p0      => p_dynamic_action.id,',
'        p_level   => apex_debug.c_log_level_error',
'      );',
'      raise_application_error(-20000, ''FATAL ERROR: ''||p_dynamic_action.id||'' not found in dictionary for APP:PAGE ''||v(''APP_ID'')||'':''||v(''APP_PAGE_ID''), true);',
'  end;',
'',
'  apex_debug.message(',
'    p_message => ''ORAMAPS_DA_GETREDLINE: found affected elements: %s'',',
'    p0        => l_item_names,',
'    p_level   => apex_debug.c_log_level_info',
'  );',
'  l_result.javascript_function := ''function () {',
'     $s(''||apex_javascript.add_value(l_item_names, false)||'', getOramaps_redlinegeom(this.triggeringElement.id, ''||apex_javascript.add_value(l_type, false)||''));',
'  }'';',
'  apex_debug.message(',
'       p_message => ''ORAMAPS_DA_GETREDLINE: JavaScript function is: %s'',',
'        p0      => l_result.javascript_function,',
'        p_level   => apex_debug.c_log_level_info',
'      );',
'  return l_result;',
'end render_da_oramaps_getRedline;',
''))
,p_api_version=>1
,p_render_function=>'render_da_oramaps_getRedline'
,p_standard_attributes=>'ITEM:REQUIRED'
,p_substitute_attributes=>true
,p_version_scn=>1089080485
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'20140707'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1544236639150878111)
,p_plugin_id=>wwv_flow_imp.id(1544236348997878111)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_prompt=>'Render Data as'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'XML'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1544237011750878111)
,p_plugin_attribute_id=>wwv_flow_imp.id(1544236639150878111)
,p_display_sequence=>10
,p_display_value=>'JSON'
,p_return_value=>'JSON'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1544237490900878111)
,p_plugin_attribute_id=>wwv_flow_imp.id(1544236639150878111)
,p_display_sequence=>20
,p_display_value=>'XML'
,p_return_value=>'XML'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1544238044570878111)
,p_plugin_attribute_id=>wwv_flow_imp.id(1544236639150878111)
,p_display_sequence=>30
,p_display_value=>'Well Known Text (WKT)'
,p_return_value=>'WKT'
);
end;
/
begin
wwv_flow_imp.component_end;
end;
/
