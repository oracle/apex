prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(1548320620918069282)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(784363335368245229)
,p_parent_id=>0
,p_short_name=>'Load Full Dataset'
,p_link=>'f?p=&APP_ID.:501:&SESSION.::&DEBUG.:::'
,p_page_id=>501
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1544132686291636289)
,p_parent_id=>0
,p_short_name=>'US States and Large Airports'
,p_link=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.:::'
,p_page_id=>115
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1544300988016881706)
,p_parent_id=>0
,p_short_name=>'Legacy Oracle Maps Plug-In'
,p_link=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:::'
,p_page_id=>201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1544990085319483196)
,p_parent_id=>0
,p_short_name=>'US States (flat)'
,p_link=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:::'
,p_page_id=>112
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1544991626761499058)
,p_parent_id=>0
,p_short_name=>'US States (extruded)'
,p_link=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:::'
,p_page_id=>113
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1544992504101506975)
,p_parent_id=>0
,p_short_name=>'US States with Links'
,p_link=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:::'
,p_page_id=>114
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1545038865814695620)
,p_parent_id=>0
,p_short_name=>'Map and Report'
,p_link=>'f?p=&APP_ID.:123:&SESSION.::&DEBUG.:::'
,p_page_id=>123
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1547963989282382807)
,p_parent_id=>0
,p_short_name=>'Nearest Neighbor Search'
,p_link=>'f?p=&APP_ID.:124:&SESSION.::&DEBUG.:::'
,p_page_id=>124
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1548320823079069284)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1549122503443411524)
,p_parent_id=>0
,p_short_name=>'Heat Map'
,p_link=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:::'
,p_page_id=>110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1549130409783454190)
,p_parent_id=>0
,p_short_name=>'Clickable Map'
,p_link=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:::'
,p_page_id=>111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1549167959692649958)
,p_parent_id=>0
,p_short_name=>'Search and Show'
,p_link=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.:::'
,p_page_id=>121
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1549169335820661388)
,p_parent_id=>0
,p_short_name=>'Faceted Search'
,p_link=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:::'
,p_page_id=>120
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1549196432424822956)
,p_parent_id=>0
,p_short_name=>'Circle Search '
,p_link=>'f?p=&APP_ID.:122:&SESSION.::&DEBUG.:::'
,p_page_id=>122
);
wwv_flow_imp.component_end;
end;
/
