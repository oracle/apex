prompt --application/shared_components/navigation/lists/main_menu
begin
--   Manifest
--     LIST: Main Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1552809097149445998)
,p_name=>'Main Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089080427
);
wwv_flow_imp.component_end;
end;
/
