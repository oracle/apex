prompt --application/shared_components/navigation/lists/all_maps
begin
--   Manifest
--     LIST: All Maps
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(778750595143826735)
,p_name=>'All Maps'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(778751191813826743)
,p_list_item_display_sequence=>1020
,p_list_item_link_text=>'Clickable Map'
,p_list_item_link_target=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:111:::'
,p_list_item_icon=>'fa-map-marker'
,p_list_text_01=>'Visualize airport data using <em>map markers</em>.'
,p_list_text_02=>'map-screenshots/clickable-map.jpg'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'111'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(778751583052826743)
,p_list_item_display_sequence=>1030
,p_list_item_link_text=>'Search and Show'
,p_list_item_link_target=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.:121:::'
,p_list_item_icon=>'fa-search'
,p_list_text_01=>'Search for an airport within an Interactive Report, and visualize it on a map.'
,p_list_text_02=>'map-screenshots/search-and-show.jpg'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'121'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(778751900897826744)
,p_list_item_display_sequence=>1040
,p_list_item_link_text=>'Faceted Search'
,p_list_item_link_target=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:120:::'
,p_list_item_icon=>'fa-filter'
,p_list_text_01=>'Provide powerful analysis on airport data using <em>Faceted Search</em>.'
,p_list_text_02=>'map-screenshots/faceted-search.jpg'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'120'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(778752383634826744)
,p_list_item_display_sequence=>1050
,p_list_item_link_text=>'Circle Search'
,p_list_item_link_target=>'f?p=&APP_ID.:122:&SESSION.::&DEBUG.:122:::'
,p_list_item_icon=>'fa-circle-o'
,p_list_text_01=>'Draw a circle onto a map and find all airports within that circle.'
,p_list_text_02=>'map-screenshots/circle-search.jpg'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'122'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(778752795319826756)
,p_list_item_display_sequence=>1060
,p_list_item_link_text=>'Map and Report'
,p_list_item_link_target=>'f?p=&APP_ID.:123:&SESSION.::&DEBUG.:123:::'
,p_list_item_icon=>'fa-arrows-h'
,p_list_text_01=>'Connect a map to a report (or other) component.'
,p_list_text_02=>'map-screenshots/map-and-report.jpg'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'123'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(778753104175826756)
,p_list_item_display_sequence=>1070
,p_list_item_link_text=>'Nearest Neighbor Search'
,p_list_item_link_target=>'f?p=&APP_ID.:124:&SESSION.::&DEBUG.:124,RR:::'
,p_list_item_icon=>'fa-line-map'
,p_list_text_01=>'Show nearest neighbors to a clicked position on the map.'
,p_list_text_02=>'map-screenshots/nearest-neighbor.jpg'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'124'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(778750772561826736)
,p_list_item_display_sequence=>1080
,p_list_item_link_text=>'Heat Map'
,p_list_item_link_target=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:110:::'
,p_list_item_icon=>'fa-heat-map'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_text_01=>'Visualize airport data as a <em>heat map</em>.'
,p_list_text_02=>'map-screenshots/heat-map.jpg'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'110'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2323751650754359922)
,p_list_item_display_sequence=>4060
,p_list_item_link_text=>'US States (flat)'
,p_list_item_link_target=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-2d-mode'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_text_01=>'Visualize US states as flat polygons.'
,p_list_text_02=>'map-screenshots/us-states-flat.jpg'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'112'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2323752136453359922)
,p_list_item_display_sequence=>4070
,p_list_item_link_text=>'US States (extruded)'
,p_list_item_link_target=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-3d-mode'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_text_01=>'Visualize US states as extruded 3D polygons, based on a value.'
,p_list_text_02=>'map-screenshots/us-states-extruded.jpg'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'113'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2323752460820359922)
,p_list_item_display_sequence=>4080
,p_list_item_link_text=>'US States with Links'
,p_list_item_link_target=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-link'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_text_01=>'Visualize US states as a clickable map.'
,p_list_text_02=>'map-screenshots/us-states-with-links.jpg'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'114'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2322892050347524130)
,p_list_item_display_sequence=>4090
,p_list_item_link_text=>'US States and Large Airports'
,p_list_item_link_target=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.:115:::'
,p_list_item_icon=>'fa-map-markers-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_text_01=>'Visualize US state boundaries and large airports on one map.'
,p_list_text_02=>'map-screenshots/us-states-and-large-airports.jpg'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'115'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2318125858651410777)
,p_list_item_display_sequence=>4100
,p_list_item_link_text=>'Legacy Oracle Maps Plug-In'
,p_list_item_link_target=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:201:::'
,p_list_item_icon=>'fa-plug'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_text_01=>'Visualize Spatial data using the Plug-In from the (legacy) Sample Geolocation Showcase.'
,p_list_text_02=>'map-screenshots/legacy.jpg'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'201'
);
wwv_flow_imp.component_end;
end;
/
