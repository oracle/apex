prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>1546516477646061666
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1548321172887069287)
,p_name=>'Desktop Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1548474447076069806)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1549127024251452405)
,p_list_item_display_sequence=>1020
,p_list_item_link_text=>'Clickable Map'
,p_list_item_link_target=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-marker'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'111'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1548618334320198023)
,p_list_item_display_sequence=>1030
,p_list_item_link_text=>'Search and Show'
,p_list_item_link_target=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'121'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1550316852137765691)
,p_list_item_display_sequence=>1040
,p_list_item_link_text=>'Faceted Search'
,p_list_item_link_target=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.::P120_AIRPORT_TYPE:AIRPORT:'
,p_list_item_icon=>'fa-filter'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'120'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1549180296502767570)
,p_list_item_display_sequence=>1050
,p_list_item_link_text=>'Circle Search'
,p_list_item_link_target=>'f?p=&APP_ID.:122:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'122'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1545016858388631845)
,p_list_item_display_sequence=>1060
,p_list_item_link_text=>'Map and Report'
,p_list_item_link_target=>'f?p=&APP_ID.:123:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-search'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'123'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1547954843596382472)
,p_list_item_display_sequence=>1070
,p_list_item_link_text=>'Nearest Neighbor Search'
,p_list_item_link_target=>'f?p=&APP_ID.:124:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-line-map'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'124'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1549117851020381422)
,p_list_item_display_sequence=>1080
,p_list_item_link_text=>'Heat Map'
,p_list_item_link_target=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-heat-map'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1548718278512048500)
,p_list_item_display_sequence=>2010
,p_list_item_link_text=>'US States (flat)'
,p_list_item_link_target=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-2d-mode'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'112'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1546624529650204750)
,p_list_item_display_sequence=>2020
,p_list_item_link_text=>'US States (extruded)'
,p_list_item_link_target=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-3d-mode'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'113'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1544946936808295218)
,p_list_item_display_sequence=>2030
,p_list_item_link_text=>'US States with Links'
,p_list_item_link_target=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-link'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'114'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1544130494030636261)
,p_list_item_display_sequence=>2040
,p_list_item_link_text=>'US States and Large Airports'
,p_list_item_link_target=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-markers-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'115'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1544300109361881702)
,p_list_item_display_sequence=>2060
,p_list_item_link_text=>'Legacy Oracle Maps Plug-In'
,p_list_item_link_target=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plug'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'201'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(784246724122483573)
,p_list_item_display_sequence=>2070
,p_list_item_link_text=>'Load Full Dataset'
,p_list_item_link_target=>'f?p=&APP_ID.:501:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-download'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'501'
);
wwv_flow_imp.component_end;
end;
/
