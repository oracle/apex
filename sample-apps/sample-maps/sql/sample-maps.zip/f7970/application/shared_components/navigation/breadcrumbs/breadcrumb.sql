prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(1556121768141955574)
,p_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1556997579648709248)
,p_short_name=>'Circle Search '
,p_static_id=>'circle-search'
,p_link=>'f?p=&APP_ID.:122:&SESSION.::&DEBUG.:::'
,p_page_id=>122
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1556931557007340482)
,p_short_name=>'Clickable Map'
,p_static_id=>'clickable-map'
,p_link=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:::'
,p_page_id=>111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1556970483044547680)
,p_short_name=>'Faceted Search'
,p_static_id=>'faceted-search'
,p_link=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:::'
,p_page_id=>120
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1556923650667297816)
,p_short_name=>'Heat Map'
,p_static_id=>'heat-map'
,p_link=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:::'
,p_page_id=>110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1556121970302955576)
,p_short_name=>'Home'
,p_static_id=>'home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1552102135240767998)
,p_short_name=>'Legacy Oracle Maps Plug-In'
,p_static_id=>'legacy-oracle-maps-plug-in'
,p_link=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:::'
,p_page_id=>201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792164482592131521)
,p_short_name=>'Load Full Dataset'
,p_static_id=>'load-full-dataset'
,p_link=>'f?p=&APP_ID.:501:&SESSION.::&DEBUG.:::'
,p_page_id=>501
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1552840013038581912)
,p_short_name=>'Map and Report'
,p_static_id=>'map-and-report'
,p_link=>'f?p=&APP_ID.:123:&SESSION.::&DEBUG.:::'
,p_page_id=>123
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1555765136506269099)
,p_short_name=>'Nearest Neighbor Search'
,p_static_id=>'nearest-neighbor-search'
,p_link=>'f?p=&APP_ID.:124:&SESSION.::&DEBUG.:::'
,p_page_id=>124
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1556969106916536250)
,p_short_name=>'Search and Show'
,p_static_id=>'search-and-show'
,p_link=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.:::'
,p_page_id=>121
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1551933833515522581)
,p_short_name=>'US States and Large Airports'
,p_static_id=>'us-states-and-large-airports'
,p_link=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.:::'
,p_page_id=>115
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1552792773985385350)
,p_short_name=>'US States (extruded)'
,p_static_id=>'us-states-extruded'
,p_link=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:::'
,p_page_id=>113
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1552791232543369488)
,p_short_name=>'US States (flat)'
,p_static_id=>'us-states-flat'
,p_link=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:::'
,p_page_id=>112
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1552793651325393267)
,p_short_name=>'US States with Links'
,p_static_id=>'us-states-with-links'
,p_link=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:::'
,p_page_id=>114
);
wwv_flow_imp.component_end;
end;
/
