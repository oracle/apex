prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1556122320110955579)
,p_name=>'Desktop Navigation Menu'
,p_static_id=>'desktop-navigation-menu'
,p_version_scn=>'1089080427'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1556981443726653862)
,p_list_item_display_sequence=>1050
,p_list_item_link_text=>'Circle Search'
,p_static_id=>'circle-search'
,p_list_item_link_target=>'f?p=&APP_ID.:122:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'122'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1556928171475338697)
,p_list_item_display_sequence=>1020
,p_list_item_link_text=>'Clickable Map'
,p_static_id=>'clickable-map'
,p_list_item_link_target=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-marker'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'111'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1558117999361651983)
,p_list_item_display_sequence=>1040
,p_list_item_link_text=>'Faceted Search'
,p_static_id=>'faceted-search'
,p_list_item_link_target=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.::P120_AIRPORT_TYPE:AIRPORT:'
,p_list_item_icon=>'fa-filter'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'120'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1556918998244267714)
,p_list_item_display_sequence=>1080
,p_list_item_link_text=>'Heat Map'
,p_static_id=>'heat-map'
,p_list_item_link_target=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-heat-map'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1556275594299956098)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_static_id=>'home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1552101256585767994)
,p_list_item_display_sequence=>2060
,p_list_item_link_text=>'Legacy Oracle Maps Plug-In'
,p_static_id=>'legacy-oracle-maps-plug-in'
,p_list_item_link_target=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plug'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'201'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(792047871346369865)
,p_list_item_display_sequence=>2070
,p_list_item_link_text=>'Load Full Dataset'
,p_static_id=>'load-full-dataset'
,p_list_item_link_target=>'f?p=&APP_ID.:501:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-download'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'501'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1552818005612518137)
,p_list_item_display_sequence=>1060
,p_list_item_link_text=>'Map and Report'
,p_static_id=>'map-and-report'
,p_list_item_link_target=>'f?p=&APP_ID.:123:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-search'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'123'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1555755990820268764)
,p_list_item_display_sequence=>1070
,p_list_item_link_text=>'Nearest Neighbor Search'
,p_static_id=>'nearest-neighbor-search'
,p_list_item_link_target=>'f?p=&APP_ID.:124:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-line-map'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'124'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1556419481544084315)
,p_list_item_display_sequence=>1030
,p_list_item_link_text=>'Search and Show'
,p_static_id=>'search-and-show'
,p_list_item_link_target=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'121'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1551931641254522553)
,p_list_item_display_sequence=>2040
,p_list_item_link_text=>'US States and Large Airports'
,p_static_id=>'us-states-and-large-airports'
,p_list_item_link_target=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-markers-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'115'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1554425676874091042)
,p_list_item_display_sequence=>2020
,p_list_item_link_text=>'US States (extruded)'
,p_static_id=>'us-states-extruded'
,p_list_item_link_target=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-3d-mode'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'113'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1556519425735934792)
,p_list_item_display_sequence=>2010
,p_list_item_link_text=>'US States (flat)'
,p_static_id=>'us-states-flat'
,p_list_item_link_target=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-2d-mode'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'112'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1552748084032181510)
,p_list_item_display_sequence=>2030
,p_list_item_link_text=>'US States with Links'
,p_static_id=>'us-states-with-links'
,p_list_item_link_target=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-link'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from eba_sample_map_states'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'114'
);
wwv_flow_imp.component_end;
end;
/
