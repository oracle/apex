prompt --application/shared_components/plugins/dynamic_action/com_oracle_apex_oramaps_clearrl
begin
--   Manifest
--     PLUGIN: COM.ORACLE.APEX.ORAMAPS.CLEARRL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(1552039687498764404)
,p_plugin_type=>'DYNAMIC ACTION'
,p_name=>'COM.ORACLE.APEX.ORAMAPS.CLEARRL'
,p_display_name=>'Legacy: Oracle Maps - Map Actions'
,p_apexlang_name=>'legacyOracleMapsMapActions'
,p_category=>'EXECUTE'
,p_image_prefix=>nvl(wwv_flow_application_install.get_static_plugin_file_prefix('DYNAMIC ACTION','COM.ORACLE.APEX.ORAMAPS.CLEARRL'),'')
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function render_da_oramaps_redline_acts(',
'    p_dynamic_action in apex_plugin.t_dynamic_action,',
'    p_plugin         in apex_plugin.t_plugin )',
'    return apex_plugin.t_dynamic_action_render_result',
'is',
'    l_region_id     apex_application_page_da_acts.affected_elements%type;',
'    l_action        p_dynamic_action.attribute_01%type := upper(p_dynamic_action.attribute_01);',
'  ',
'    l_result        apex_plugin.t_dynamic_action_render_result;       ',
'begin',
'  begin',
'    select nvl(r.static_id, ''R''||da.affected_region_id) into l_region_id',
'    from apex_application_page_da_acts da, apex_application_page_regions r',
'    where da.affected_region_id = r.region_id',
'    and da.application_id = v(''APP_ID'') and da.page_id = v(''APP_PAGE_ID'')',
'    and da.action_id = p_dynamic_action.id;',
'  exception',
'    when NO_DATA_FOUND then ',
'      apex_debug.message(',
'        p_message => ''ORAMAPS_DA_REDLINE_ACT: FATAL ERROR: Dynamic Action ID "%s" not found in the APEX dictionary!'',',
'        p0      => p_dynamic_action.id,',
'        p_level   => apex_debug.c_log_level_error',
'      );',
'      raise_application_error(-20000, ''FATAL ERROR: ''||p_dynamic_action.id||'' not found in dictionary for APP:PAGE ''||v(''APP_ID'')||'':''||v(''APP_PAGE_ID''), true);',
'  end;',
'',
'  apex_debug.message(',
'    p_message => ''ORAMAPS_DA_REDLINE_ACT: found affected region: %s'',',
'    p0        => l_region_id,',
'    p_level   => apex_debug.c_log_level_info',
'  );',
'  if l_action = ''RLCLEAR'' then',
'    l_result.javascript_function := ''function () {',
'       getOramaps_clearRedLine(''||apex_javascript.add_value(l_region_id, false)||'');',
'    }'';',
'  elsif l_action = ''CLEARCIRCLE'' then',
'    l_result.javascript_function := ''function () {',
'       getOramaps_clearCircle(''||apex_javascript.add_value(l_region_id, false)||'');',
'    }'';',
'  elsif l_action = ''ENDCIRCLE'' then',
'    l_result.javascript_function := ''function () {',
'       getOramaps_finishCircle(''||apex_javascript.add_value(l_region_id, false)||'');',
'    }'';',
'  elsif l_action = ''STARTCIRCLE'' then',
'    l_result.javascript_function := ''function () {',
'       getOramaps_startCircle(''||apex_javascript.add_value(l_region_id, false)||'');',
'    }'';',
'  elsif l_action = ''RLSTART'' then',
'    l_result.javascript_function := ''function () {',
'       getOramaps_startRedLine(''||apex_javascript.add_value(l_region_id, false)||'');',
'    }'';',
'  elsif l_action = ''REMOVEMARKER'' then',
'    l_result.javascript_function := ''function () {',
'       getOramaps_removeCustomMarker(''||apex_javascript.add_value(l_region_id, false)||'');',
'    }'';',
'  elsif l_action = ''REFRESHFOI'' then',
'    l_result.javascript_function := ''function () {',
'       getOramaps_refreshSqlFOI(''||apex_javascript.add_value(l_region_id, false)||'');',
'    }'';',
'  elsif l_action = ''RLFINISH'' then',
'    l_result.javascript_function := ''function () {',
'       getOramaps_finishRedLine(''||apex_javascript.add_value(l_region_id, false)||'');',
'    }'';',
'  elsif l_action = ''RECTZOOM'' then',
'    l_result.javascript_function := ''function () {',
'       getOramaps_startRectZoom(''||apex_javascript.add_value(l_region_id, false)||'');',
'    }'';',
'  elsif l_action = ''DISTANCE'' then',
'    l_result.javascript_function := ''function () {',
'       getOramaps_startDistanceTool(''||apex_javascript.add_value(l_region_id, false)||'');',
'    }'';',
'  end if;',
'  apex_debug.message(',
'       p_message => ''ORAMAPS_DA_REDLINE_ACT: JavaScript function is: %s'',',
'        p0      => l_result.javascript_function,',
'        p_level   => apex_debug.c_log_level_info',
'      );',
'  return l_result;',
'end render_da_oramaps_redline_acts; ',
'',
''))
,p_api_version=>1
,p_render_function=>'render_da_oramaps_redline_acts'
,p_standard_attributes=>'REGION:REQUIRED'
,p_substitute_attributes=>true
,p_version_scn=>'1089080485'
,p_version_identifier=>'20140707'
,p_files_version=>2461161212722
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552040023578764405)
,p_plugin_id=>wwv_flow_imp.id(1552039687498764404)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_static_id=>'attribute_01'
,p_prompt=>'Map Action'
,p_apexlang_name=>'mapAction'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'RECTZOOM'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552043845190764406)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552040023578764405)
,p_display_sequence=>80
,p_display_value=>'Clear Circle Tool'
,p_return_value=>'CLEARCIRCLE'
,p_apexlang_name=>'clearCircleTool'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552042412217764406)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552040023578764405)
,p_display_sequence=>50
,p_display_value=>'Clear Drawing'
,p_return_value=>'RLCLEAR'
,p_apexlang_name=>'clearDrawing'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552040887324764406)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552040023578764405)
,p_display_sequence=>20
,p_display_value=>'Distance Tool'
,p_return_value=>'DISTANCE'
,p_apexlang_name=>'distanceTool'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552044843863764407)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552040023578764405)
,p_display_sequence=>100
,p_display_value=>'Finish Circle Tool'
,p_return_value=>'ENDCIRCLE'
,p_apexlang_name=>'finishCircleTool'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552041851143764406)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552040023578764405)
,p_display_sequence=>40
,p_display_value=>'Finish Drawing'
,p_return_value=>'RLFINISH'
,p_apexlang_name=>'finishDrawing'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552040376119764405)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552040023578764405)
,p_display_sequence=>10
,p_display_value=>'Rectangle Zoom'
,p_return_value=>'RECTZOOM'
,p_apexlang_name=>'rectangleZoom'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552042845349764406)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552040023578764405)
,p_display_sequence=>60
,p_display_value=>'Refresh SQL Features'
,p_return_value=>'REFRESHFOI'
,p_apexlang_name=>'refreshSqlFeatures'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552043424312764406)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552040023578764405)
,p_display_sequence=>70
,p_display_value=>'Remove Markers'
,p_return_value=>'REMOVEMARKER'
,p_apexlang_name=>'removeMarkers'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552044406184764407)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552040023578764405)
,p_display_sequence=>90
,p_display_value=>'Start Circle Tool'
,p_return_value=>'STARTCIRCLE'
,p_apexlang_name=>'startCircleTool'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552041351632764406)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552040023578764405)
,p_display_sequence=>30
,p_display_value=>'Start Drawing'
,p_return_value=>'RLSTART'
,p_apexlang_name=>'startDrawing'
);
end;
/
begin
wwv_flow_imp.component_end;
end;
/
