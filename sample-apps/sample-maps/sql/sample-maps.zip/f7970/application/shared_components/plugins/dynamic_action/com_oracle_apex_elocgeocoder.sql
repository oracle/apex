prompt --application/shared_components/plugins/dynamic_action/com_oracle_apex_elocgeocoder
begin
--   Manifest
--     PLUGIN: COM.ORACLE.APEX.ELOCGEOCODER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(1552020635936764372)
,p_plugin_type=>'DYNAMIC ACTION'
,p_name=>'COM.ORACLE.APEX.ELOCGEOCODER'
,p_display_name=>'Oracle Elocation Geocoder'
,p_apexlang_name=>'oracleElocationGeocoder'
,p_category=>'MISC'
,p_image_prefix=>nvl(wwv_flow_application_install.get_static_plugin_file_prefix('DYNAMIC ACTION','COM.ORACLE.APEX.ELOCGEOCODER'),'')
,p_api_version=>1
,p_render_function=>'eba_spatial_gcdr_pkg.render_elocation_geocoder'
,p_ajax_function=>'eba_spatial_gcdr_pkg.ajax_elocation_geocoder'
,p_substitute_attributes=>true
,p_version_scn=>'1089080485'
,p_version_identifier=>'20140707'
,p_files_version=>2461161212721
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552020856050764376)
,p_plugin_id=>wwv_flow_imp.id(1552020635936764372)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_static_id=>'attribute_01'
,p_prompt=>'Collection Name'
,p_apexlang_name=>'collectionName'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_default_value=>'GEOCODER_RESULTS'
,p_display_length=>30
,p_max_length=>30
,p_is_translatable=>false
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'Enter the name of a collection to store the geocoding results here. The collection can be queried as follows:',
'</p>',
'<pre>',
'select ',
'     c001 as street,',
'     c002 as house_number,',
'     c003 as postal_code,',
'     c004 as settlement,',
'     c005 as builtup_area,',
'     c006 as municipality,',
'     c007 as order1_area,',
'     c008 as side,',
'     c009 as error_message,',
'     c010 as match_vector,',
'     c011 as country,',
'     n001 as sequence,',
'     n002 as longitude,',
'     n003 as latitude,',
'     n004 as edge_id',
'    from apex_collections where collection_name = ''<i>{Collection Name}</i>''',
'    order by seq_id',
'</pre>',
'<p>',
' To display geocoding results, create a Report based on that query and add another <i>true action</i> to this dynamic action, in order to refresh that report.',
'</p>',
''))
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552021271456764380)
,p_plugin_id=>wwv_flow_imp.id(1552020635936764372)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_static_id=>'attribute_02'
,p_prompt=>'Geocoder match mode'
,p_apexlang_name=>'geocoderMatchMode'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'DEFAULT'
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(1552024779537764381)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'NORMAL'
,p_lov_type=>'STATIC'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Match Modes for Geocoding Operations</p>',
'<table cellspacing="0" cellpadding="3" border="1" dir="ltr" >',
'<tr valign="top" align="left">',
'<th valign="bottom" align="left" >Match Mode</th>',
'<th valign="bottom" align="left" >Description</th>',
'</tr>',
'<tr valign="top" align="left">',
'<td align="left" headers="r1c1-t3" >',
'<p>EXACT</p>',
'</td>',
'<td align="left" headers="r2c1-t3 r1c2-t3">',
'<p>All attributes of the input address must match the data used for geocoding. However, if the house or building number, base name (street name), street type, street prefix, and street suffix do not all match the geocoding data, a location in the fir'
||'st match found in the following is returned: postal code, city or town (settlement) within the state, and state. For example, if the street name is incorrect but a valid postal code is specified, a location in the postal code is returned.</p>',
'</td>',
'</tr>',
'<tr valign="top" align="left">',
'<td align="left" headers="r1c1-t3" >',
'<p>RELAX_BASE_NAME</p>',
'</td>',
'<td align="left" headers="r6c1-t3 r1c2-t3">',
'<p>The base name of the street, the house or building number, and the street type can be different from the data used for geocoding. For example, if <i>Pleasant Valley</i> is the base name of a street in the data used for geocoding, <i>Pleasant Vale<'
||'/i> would also match as long as there were no ambiguities or other matches in the data.</p>',
'</td>',
'</tr>',
'<tr valign="top" align="left">',
'<td align="left" headers="r1c1-t3" >',
'<p>RELAX_POSTAL_CODE</p>',
'</td>',
'<td align="left" headers="r7c1-t3 r1c2-t3">',
'<p>The postal code (if provided), base name, house or building number, and street type can be different from the data used for geocoding.</p>',
'</td>',
'</tr>',
'<tr valign="top" align="left">',
'<td align="left" headers="r1c1-t3" >',
'<p>DEFAULT</p>',
'</td>',
'<td align="left" headers="r8c1-t3 r1c2-t3">',
'<p>The address can be outside the city specified as long as it is within the same county. Also includes the characteristics of RELAX_POSTAL_CODE.</p>',
'</td>',
'</tr>',
'</table>'))
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552021598932764380)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552021271456764380)
,p_display_sequence=>10
,p_display_value=>'Do only exact matches'
,p_return_value=>'EXACT'
,p_apexlang_name=>'doOnlyExactMatches'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552022549679764381)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552021271456764380)
,p_display_sequence=>30
,p_display_value=>'Relax Base Name'
,p_return_value=>'RELAX_BASE_NAME'
,p_apexlang_name=>'relaxBaseName'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552022096904764381)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552021271456764380)
,p_display_sequence=>20
,p_display_value=>'Relax Postal Code'
,p_return_value=>'RELAX_POSTAL_CODE'
,p_apexlang_name=>'relaxPostalCode'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552023035912764381)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552021271456764380)
,p_display_sequence=>40
,p_display_value=>'Use Server Default'
,p_return_value=>'DEFAULT'
,p_apexlang_name=>'useServerDefault'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552023611018764381)
,p_plugin_id=>wwv_flow_imp.id(1552020635936764372)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>30
,p_static_id=>'attribute_03'
,p_prompt=>'Item containing Country Code'
,p_apexlang_name=>'itemContainingCountryCode'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>true
,p_default_value=>'PX_GEOCODER_COUNTRY'
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(1552024779537764381)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'NORMAL'
,p_help_text=>'Enter the name of the item containing the country code for the Geocoder.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552024025819764381)
,p_plugin_id=>wwv_flow_imp.id(1552020635936764372)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>40
,p_static_id=>'attribute_04'
,p_prompt=>'Item containing address lines'
,p_apexlang_name=>'itemContainingAddressLines'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>true
,p_default_value=>'PX_GEOCODER_ADDRESS'
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(1552024779537764381)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'NORMAL'
,p_help_text=>'Enter the name of the item containing the address to geocode.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552024379904764381)
,p_plugin_id=>wwv_flow_imp.id(1552020635936764372)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>5
,p_display_sequence=>50
,p_static_id=>'attribute_05'
,p_prompt=>'Separator for address elements'
,p_apexlang_name=>'separatorForAddressElements'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_default_value=>','
,p_display_length=>2
,p_max_length=>2
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(1552024779537764381)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'NORMAL'
,p_help_text=>'Enter the character which separates the parts of an address.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552024779537764381)
,p_plugin_id=>wwv_flow_imp.id(1552020635936764372)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>8
,p_display_sequence=>5
,p_static_id=>'attribute_08'
,p_prompt=>'Geocoding type'
,p_apexlang_name=>'geocodingType'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'NORMAL'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_help_text=>'Specify the kind of geocoding here. <b>Geocoding</b> is converting a postal address to a coordinate - <b>Reverse Geocoding</b> is determining the postal address from the coordinate.'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552025188316764381)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552024779537764381)
,p_display_sequence=>10
,p_display_value=>'Geocoding'
,p_return_value=>'NORMAL'
,p_apexlang_name=>'geocoding'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552025656612764382)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552024779537764381)
,p_display_sequence=>20
,p_display_value=>'Reverse Geocoding'
,p_return_value=>'REVERSE'
,p_apexlang_name=>'reverseGeocoding'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552026214362764382)
,p_plugin_id=>wwv_flow_imp.id(1552020635936764372)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>9
,p_display_sequence=>90
,p_static_id=>'attribute_09'
,p_prompt=>'Item containing Longitude value'
,p_apexlang_name=>'itemContainingLongitudeValue'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(1552024779537764381)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'REVERSE'
,p_help_text=>'Specify the APEX item containing the longitude value here.'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552026617777764382)
,p_plugin_id=>wwv_flow_imp.id(1552020635936764372)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>10
,p_display_sequence=>100
,p_static_id=>'attribute_10'
,p_prompt=>'Item containing Latitude value'
,p_apexlang_name=>'itemContainingLatitudeValue'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
,p_depending_on_attribute_id=>wwv_flow_imp.id(1552024779537764381)
,p_depending_on_has_to_exist=>true
,p_depending_on_condition_type=>'EQUALS'
,p_depending_on_expression=>'REVERSE'
,p_help_text=>'Specify the item containing the Latitude value.'
);
wwv_flow_imp_shared.create_plugin_event(
 p_id=>wwv_flow_imp.id(1552028794387764392)
,p_plugin_id=>wwv_flow_imp.id(1552020635936764372)
,p_name=>'com_oracle_eloc_gcdr_done'
,p_display_name=>'elocation_geocoder_success'
);
wwv_flow_imp_shared.create_plugin_event(
 p_id=>wwv_flow_imp.id(1552029183492764392)
,p_plugin_id=>wwv_flow_imp.id(1552020635936764372)
,p_name=>'com_oracle_eloc_gcdr_error'
,p_display_name=>'elocation_geocoder_error'
);
end;
/
begin
wwv_flow_imp.component_end;
end;
/
