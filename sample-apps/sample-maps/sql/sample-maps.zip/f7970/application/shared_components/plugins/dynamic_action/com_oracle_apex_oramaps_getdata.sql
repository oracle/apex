prompt --application/shared_components/plugins/dynamic_action/com_oracle_apex_oramaps_getdata
begin
--   Manifest
--     PLUGIN: COM.ORACLE.APEX.ORAMAPS.GETDATA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(1552029565283764397)
,p_plugin_type=>'DYNAMIC ACTION'
,p_name=>'COM.ORACLE.APEX.ORAMAPS.GETDATA'
,p_display_name=>'Legacy: Oracle Maps - Get Data '
,p_apexlang_name=>'legacyOracleMapsGetData'
,p_category=>'MISC'
,p_image_prefix=>nvl(wwv_flow_application_install.get_static_plugin_file_prefix('DYNAMIC ACTION','COM.ORACLE.APEX.ORAMAPS.GETDATA'),'')
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function render_da_oramaps_getdata(',
'    p_dynamic_action in apex_plugin.t_dynamic_action,',
'    p_plugin         in apex_plugin.t_plugin )',
'    return apex_plugin.t_dynamic_action_render_result',
'is',
'    l_type           varchar2(30)   := upper(p_dynamic_action.attribute_01);',
'    l_srid           varchar2(30)   := upper(p_dynamic_action.attribute_02);',
'    l_region_id      apex_application_page_regions.static_id%type;',
'    l_it_map_bb_xmin p_dynamic_action.attribute_03%type := upper(p_dynamic_action.attribute_03);',
'    l_it_map_bb_ymin p_dynamic_action.attribute_04%type := upper(p_dynamic_action.attribute_04);',
'    l_it_map_bb_xmax p_dynamic_action.attribute_05%type := upper(p_dynamic_action.attribute_05);',
'    l_it_map_bb_ymax p_dynamic_action.attribute_06%type := upper(p_dynamic_action.attribute_06);',
'    l_it_map_ctr_x   p_dynamic_action.attribute_07%type := upper(p_dynamic_action.attribute_07);',
'    l_it_map_ctr_y   p_dynamic_action.attribute_08%type := upper(p_dynamic_action.attribute_08);',
'    l_it_map_mse_x   p_dynamic_action.attribute_09%type := upper(p_dynamic_action.attribute_09);',
'    l_it_map_mse_y   p_dynamic_action.attribute_10%type := upper(p_dynamic_action.attribute_10);',
'    l_it_map_zl_cur  p_dynamic_action.attribute_11%type := upper(p_dynamic_action.attribute_11);',
'    l_it_map_zl_max  p_dynamic_action.attribute_12%type := upper(p_dynamic_action.attribute_12);',
'    l_it_map_srid    p_dynamic_action.attribute_13%type := upper(p_dynamic_action.attribute_13);',
'    l_it_mapdata     p_dynamic_action.attribute_14%type := upper(p_dynamic_action.attribute_14);',
'    l_result         apex_plugin.t_dynamic_action_render_result;       ',
'',
'    l_js             varchar2(32767):='''';',
'    l_dec_char       varchar2(1);',
'begin',
'  l_dec_char := substr(to_char(1/2, ''FM0D0''),2,1);',
'  begin',
'    select nvl(r.static_id, ''R''||to_char(d.affected_region_id)) into l_region_id',
'    from apex_application_page_da_acts d, apex_application_page_regions r',
'    where d.affected_region_id = r.region_id and d.application_id = r.application_id and d.page_id = r.page_id',
'    and d.application_id = v(''APP_ID'') and d.page_id = v(''APP_PAGE_ID'')',
'    and d.action_id = p_dynamic_action.id;',
'',
'  exception',
'    when NO_DATA_FOUND then ',
'      apex_debug.message(',
'        p_message => ''ORAMAPS_DA_GETDATA: FATAL ERROR: Dynamic Action ID "%s" not found in the APEX dictionary!'',',
'        p0      => p_dynamic_action.id,',
'        p_level   => apex_debug.c_log_level_error',
'      );',
'      raise_application_error(-20000, ''FATAL ERROR: ''||p_dynamic_action.id||'' not found in dictionary for APP:PAGE ''||v(''APP_ID'')||'':''||v(''APP_PAGE_ID''), true);',
'  end;',
'',
'  apex_debug.message(',
'    p_message => ''ORAMAPS_DA_GETDATA: found affected region: %s'',',
'    p0        => l_region_id,',
'    p_level   => apex_debug.c_log_level_info',
'  );',
'  ',
'  l_js := ',
'    ''function () {''                                                          ||',
'       ''getOramaps_mapdata(''                                                 ||',
'          apex_javascript.add_value(l_region_id, true)                       ||',
'          ''"JSON", ''                                                         ||',
'          apex_javascript.add_value(l_srid, true)                            ||',
'          ''function( pData ) { ''                                             ||',
'          ''var lData = JSON.parse(pData);''                                   ;',
'',
'      if l_it_map_bb_xmin is not null then ',
'        l_js := l_js || ',
'         ''$s(''||apex_javascript.add_value(l_it_map_bb_xmin, false)||'', String(lData.mapdata.bbox.xmin).replace(".", "''||l_dec_char||''"));'';',
'      end if;',
'      if l_it_map_bb_ymin is not null then ',
'        l_js := l_js || ',
'         ''$s(''||apex_javascript.add_value(l_it_map_bb_ymin, false)||'', String(lData.mapdata.bbox.ymin).replace(".", "''||l_dec_char||''"));'';',
'      end if;',
'      if l_it_map_bb_xmax is not null then ',
'        l_js := l_js || ',
'         ''$s(''||apex_javascript.add_value(l_it_map_bb_xmax, false)||'', String(lData.mapdata.bbox.xmax).replace(".", "''||l_dec_char||''"));'';',
'      end if;',
'      if l_it_map_bb_ymax is not null then ',
'        l_js := l_js || ',
'         ''$s(''||apex_javascript.add_value(l_it_map_bb_ymax, false)||'', String(lData.mapdata.bbox.ymax).replace(".", "''||l_dec_char||''"));'';',
'      end if;',
'      if l_it_map_ctr_x is not null then ',
'        l_js := l_js || ',
'         ''$s(''||apex_javascript.add_value(l_it_map_ctr_x, false)||'', String(lData.mapdata.center.x).replace(".", "''||l_dec_char||''"));'';',
'      end if;',
'      if l_it_map_ctr_y is not null then ',
'        l_js := l_js || ',
'         ''$s(''||apex_javascript.add_value(l_it_map_ctr_y, false)||'', String(lData.mapdata.center.y).replace(".", "''||l_dec_char||''"));'';',
'      end if;',
'      if l_it_map_mse_x is not null then ',
'        l_js := l_js || ',
'         ''$s(''||apex_javascript.add_value(l_it_map_mse_x, false)||'', String(lData.mapdata.mouse_location.x).replace(".", "''||l_dec_char||''"));'';',
'      end if;',
'      if l_it_map_mse_y is not null then ',
'        l_js := l_js || ',
'         ''$s(''||apex_javascript.add_value(l_it_map_mse_y, false)||'', String(lData.mapdata.mouse_location.y).replace(".", "''||l_dec_char||''"));'';',
'      end if;',
'      if l_it_map_zl_cur is not null then ',
'        l_js := l_js || ',
'         ''$s(''||apex_javascript.add_value(l_it_map_zl_cur, false)||'', lData.mapdata.zoomlevel.current);'';',
'      end if;',
'      if l_it_map_zl_max is not null then ',
'        l_js := l_js || ',
'         ''$s(''||apex_javascript.add_value(l_it_map_zl_max, false)||'', lData.mapdata.zoomlevel.max);'';',
'      end if;',
'      if l_it_map_srid is not null then ',
'        l_js := l_js || ',
'         ''$s(''||apex_javascript.add_value(l_it_map_srid, false)||'', lData.mapdata.srid);'';',
'      end if;',
'',
'      if l_it_mapdata is not null then ',
'        l_js := l_js || ',
'         ''$s(''||apex_javascript.add_value(l_it_mapdata, false)||'', pData );'';',
'      end if;',
'',
'',
'  l_js := l_js || ''});}'';',
'   ',
'     ',
'  l_result.javascript_function := l_js;',
'  apex_debug.message(',
'       p_message => ''ORAMAPS_DA_GETDATA: JavaScript function is: %s'',',
'        p0      => l_result.javascript_function,',
'        p_level   => apex_debug.c_log_level_info',
'      );',
'  return l_result;',
'end render_da_oramaps_getdata;'))
,p_api_version=>1
,p_render_function=>'render_da_oramaps_getdata'
,p_standard_attributes=>'REGION'
,p_substitute_attributes=>true
,p_version_scn=>'1089080485'
,p_version_identifier=>'20140707'
,p_files_version=>2461161212722
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552029889533764399)
,p_plugin_id=>wwv_flow_imp.id(1552029565283764397)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_static_id=>'attribute_01'
,p_prompt=>'Render Data As ...'
,p_apexlang_name=>'renderDataAs'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'JSON'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552030245011764399)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552029889533764399)
,p_display_sequence=>10
,p_display_value=>'JSON'
,p_return_value=>'JSON'
,p_apexlang_name=>'json'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552030808497764399)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552029889533764399)
,p_display_sequence=>20
,p_display_value=>'XML'
,p_return_value=>'XML'
,p_apexlang_name=>'xml'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552031294500764399)
,p_plugin_id=>wwv_flow_imp.id(1552029565283764397)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_static_id=>'attribute_02'
,p_prompt=>'Coordinate System'
,p_apexlang_name=>'coordinateSystem'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'WGS84'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552032151254764400)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552031294500764399)
,p_display_sequence=>20
,p_display_value=>'Current map projection'
,p_return_value=>'MAP'
,p_apexlang_name=>'currentMapProjection'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(1552031682247764399)
,p_plugin_attribute_id=>wwv_flow_imp.id(1552031294500764399)
,p_display_sequence=>10
,p_display_value=>'Longitiude / Latitude (WGS84)'
,p_return_value=>'WGS84'
,p_apexlang_name=>'longitiudeLatitudeWgs84'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552032703615764400)
,p_plugin_id=>wwv_flow_imp.id(1552029565283764397)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>30
,p_static_id=>'attribute_03'
,p_prompt=>'Item for Map BBOX XMIN '
,p_apexlang_name=>'itemForMapBboxXmin'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552033127298764400)
,p_plugin_id=>wwv_flow_imp.id(1552029565283764397)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>40
,p_static_id=>'attribute_04'
,p_prompt=>'Item for Map BBOX YMIN'
,p_apexlang_name=>'itemForMapBboxYmin'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552033488318764400)
,p_plugin_id=>wwv_flow_imp.id(1552029565283764397)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>5
,p_display_sequence=>50
,p_static_id=>'attribute_05'
,p_prompt=>'Item for Map BBOX XMAX'
,p_apexlang_name=>'itemForMapBboxXmax'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552033893880764400)
,p_plugin_id=>wwv_flow_imp.id(1552029565283764397)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>6
,p_display_sequence=>60
,p_static_id=>'attribute_06'
,p_prompt=>'Item for Map BBOX YMAX'
,p_apexlang_name=>'itemForMapBboxYmax'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552034256848764400)
,p_plugin_id=>wwv_flow_imp.id(1552029565283764397)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>7
,p_display_sequence=>70
,p_static_id=>'attribute_07'
,p_prompt=>'Item for Map Center X'
,p_apexlang_name=>'itemForMapCenterX'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552034665839764400)
,p_plugin_id=>wwv_flow_imp.id(1552029565283764397)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>8
,p_display_sequence=>80
,p_static_id=>'attribute_08'
,p_prompt=>'Item for Map Center Y'
,p_apexlang_name=>'itemForMapCenterY'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552035128449764400)
,p_plugin_id=>wwv_flow_imp.id(1552029565283764397)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>9
,p_display_sequence=>90
,p_static_id=>'attribute_09'
,p_prompt=>'Item for Mouse Location X'
,p_apexlang_name=>'itemForMouseLocationX'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552035518955764401)
,p_plugin_id=>wwv_flow_imp.id(1552029565283764397)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>10
,p_display_sequence=>100
,p_static_id=>'attribute_10'
,p_prompt=>'Item for Mouse Location Y'
,p_apexlang_name=>'itemForMouseLocationY'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552035928451764401)
,p_plugin_id=>wwv_flow_imp.id(1552029565283764397)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>11
,p_display_sequence=>110
,p_static_id=>'attribute_11'
,p_prompt=>'Item for current Zoomlevel'
,p_apexlang_name=>'itemForCurrentZoomlevel'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552036267906764401)
,p_plugin_id=>wwv_flow_imp.id(1552029565283764397)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>12
,p_display_sequence=>120
,p_static_id=>'attribute_12'
,p_prompt=>'Item for max. Zoomlevel'
,p_apexlang_name=>'itemForMaxZoomlevel'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552036633918764401)
,p_plugin_id=>wwv_flow_imp.id(1552029565283764397)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>13
,p_display_sequence=>130
,p_static_id=>'attribute_13'
,p_prompt=>'Item for MAP SRID value'
,p_apexlang_name=>'itemForMapSridValue'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(1552037044506764402)
,p_plugin_id=>wwv_flow_imp.id(1552029565283764397)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>14
,p_display_sequence=>140
,p_static_id=>'attribute_14'
,p_prompt=>'Item for whole "Map Data" content (JSON / XML)'
,p_apexlang_name=>'itemForWholeMapDataContentJsonXml'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
end;
/
begin
wwv_flow_imp.component_end;
end;
/
