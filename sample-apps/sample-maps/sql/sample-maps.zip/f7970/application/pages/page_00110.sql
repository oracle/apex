prompt --application/pages/page_00110
begin
--   Manifest
--     PAGE: 00110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>110
,p_name=>'Airports Heat Map'
,p_alias=>'AIRPORTS-HEAT-MAP'
,p_step_title=>'&APP_NAME. - Airports Heat Map'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1555796862834485645)
,p_plug_name=>'About This Page'
,p_static_id=>'about-this-page'
,p_region_name=>'about_this_page'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-size480x320'
,p_region_attributes=>'data-parent-element="#help_button"'
,p_plug_template=>1486845678744495616
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'This page visualizes US <strong>Heliports</strong> as ',
' a <em>Heat Map</em>. Heat maps are used to visualize the density of spatial objects. Zoom in and out to see how the heat map visualizes point density.',
'</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1556938300820388872)
,p_plug_name=>'State'
,p_static_id=>'state'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1555927333594584597)
,p_plug_name=>'US Airports'
,p_static_id=>'us-airports'
,p_region_name=>'airport-map-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(1555927449751584598)
,p_region_id=>wwv_flow_imp.id(1555927333594584597)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-90'
,p_init_position_lat_static=>'35'
,p_init_zoomlevel_static=>'3'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1555927544946584599)
,p_map_region_id=>wwv_flow_imp.id(1555927449751584598)
,p_name=>'Airports Density'
,p_static_id=>'airports-density'
,p_layer_type=>'HEATMAP'
,p_display_sequence=>20
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_table_name=>'EBA_SAMPLE_MAP_AIRPORTS'
,p_where_clause=>wwv_flow_string.join(wwv_flow_t_varchar2(
'STATE_NAME = :P110_STATE or :P110_STATE IS NULL',
'and airport_type = ''HELIPORT'' '))
,p_include_rowid_column=>false
,p_items_to_submit=>'P110_STATE'
,p_use_vector_tiles=>true
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_fill_color_spectr_name=>'Sunset'
,p_fill_color_spectr_type=>'SEQUENTIAL'
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1552728373881058067)
,p_map_region_id=>wwv_flow_imp.id(1555927449751584598)
,p_name=>'US State'
,p_static_id=>'us-state'
,p_layer_type=>'POLYGON'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_table_name=>'EBA_SAMPLE_MAP_STATES'
,p_where_clause=>'upper(NAME) = :P110_STATE'
,p_include_rowid_column=>false
,p_items_to_submit=>'P110_STATE'
,p_use_vector_tiles=>true
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_stroke_color=>'#101010'
,p_fill_color=>'#808080'
,p_fill_color_is_spectrum=>false
,p_fill_opacity_subst=>'.3'
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'NAME'
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1556938341680388873)
,p_name=>'P110_STATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1556938300820388872)
,p_prompt=>'Filter for State'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct initcap( name ) d, upper(name) r',
'  from EBA_SAMPLE_MAP_STATES',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'All States'
,p_cHeight=>1
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1556938450579388874)
,p_name=>'Refresh Map'
,p_static_id=>'refresh-map'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P110_STATE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1556938531495388875)
,p_event_id=>wwv_flow_imp.id(1556938450579388874)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1555927333594584597)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
