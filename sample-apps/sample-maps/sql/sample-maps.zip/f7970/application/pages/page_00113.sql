prompt --application/pages/page_00113
begin
--   Manifest
--     PAGE: 00113
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>113
,p_name=>'US States (extruded)'
,p_alias=>'US-STATES-EXTRUDED'
,p_step_title=>'&APP_NAME. - US States (extruded)'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'19'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1555797884776485655)
,p_plug_name=>'About This Page'
,p_static_id=>'about-this-page'
,p_region_name=>'about_this_page'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-size480x320'
,p_region_attributes=>'data-parent-element="#help_button"'
,p_plug_template=>1486845678744495616
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'These map visualize US states as <em>Extruded</em> polygons.  Click on a state to show a info popup with details.',
'</p>',
'<p>For the map on the left, Polygon color and height are determined by the <strong>WATER_AREA</strong> column, using the built-in <strong>Blue to Yellow</strong> color scheme. For the map on the right, Polygon color and height are derived from the "a'
||'irport count" by state. The airports and states table are joined using the  ',
'<strong>SDO_ANYINTERACT</strong> spatial SQL function, based on airports and state coordinates.',
'</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2349287189190798707)
,p_plug_name=>'Airports by State'
,p_static_id=>'airports-by-state'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(792621155331533973)
,p_region_id=>wwv_flow_imp.id(2349287189190798707)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-90'
,p_init_position_lat_static=>'35'
,p_init_zoomlevel_static=>'3'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(792621652596533981)
,p_map_region_id=>wwv_flow_imp.id(792621155331533973)
,p_name=>'Airports by State'
,p_static_id=>'airports-by-state'
,p_layer_type=>'POLYGON_3D'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with data as (',
'    select s.ID,',
'       s.NAME,',
'       s.STATE_CODE,',
'       ( select count( a.id ) ',
'           from eba_sample_map_airports a',
'          where commercial_ops > 0 and upper(s.name) = upper(a.state_name) ) airport_count,',
'       s.GEOMETRY',
'  from EBA_SAMPLE_MAP_SIMPLE_STATES s',
') ',
'select id,',
'       upper(name) as name,',
'       state_code,',
'       airport_count,',
'       airport_count * 10 as polygon_height,',
'       geometry',
'  from data'))
,p_no_data_found_message=>'No States found.'
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_fill_color_is_spectrum=>true
,p_fill_color_spectr_name=>'Temps'
,p_fill_color_spectr_type=>'DIVERGING'
,p_fill_value_column=>'AIRPORT_COUNT'
,p_fill_opacity_subst=>'.7'
,p_extrude_value_column=>'POLYGON_HEIGHT'
,p_extrude_unit=>'KM'
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'NAME'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:110:P110_STATE:&NAME.'
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1555362639065565316)
,p_plug_name=>'Water Area by State'
,p_static_id=>'water-area-by-state'
,p_region_name=>'water-map-region'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(1552740052173124395)
,p_region_id=>wwv_flow_imp.id(1555362639065565316)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-90'
,p_init_position_lat_static=>'35'
,p_init_zoomlevel_static=>'3'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(1552740565621124396)
,p_map_region_id=>wwv_flow_imp.id(1552740052173124395)
,p_name=>'Water Area by State'
,p_static_id=>'water-area-by-state'
,p_layer_type=>'POLYGON_3D'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       NAME,',
'       STATE_CODE,',
'       to_char(LAND_AREA / 1000000,''9G999G999G990D000'')  land_area,',
'       to_char(WATER_AREA / 1000000,''9G999G999G990D000'')  water_area,',
'       case when water_area > 50000000000 then 2500000 else water_area / 20000 end as water_area_color,',
'       GEOMETRY',
'  from EBA_SAMPLE_MAP_SIMPLE_STATES'))
,p_no_data_found_message=>'No States found.'
,p_use_vector_tiles=>false
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY'
,p_fill_color_is_spectrum=>true
,p_fill_color_spectr_name=>'BluYl'
,p_fill_color_spectr_type=>'SEQUENTIAL'
,p_fill_value_column=>'WATER_AREA_COLOR'
,p_fill_opacity_subst=>'.7'
,p_extrude_value_column=>'WATER_AREA_COLOR'
,p_extrude_unit=>'M'
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'NAME'
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&NAME. (&STATE_CODE.)</strong><br>',
'Land Area: &LAND_AREA. km&sup2;<br>',
'Water Area: &WATER_AREA. km&sup2;<br>'))
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(787161537242850849)
,p_name=>'On Click Point'
,p_static_id=>'on-click-point'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1555362639065565316)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapobjectclick'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(787161924918850849)
,p_event_id=>wwv_flow_imp.id(787161537242850849)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'const { lng, lat } = this.data;',
    '',
    'apex.region("water-map-region").call( "getMapObject" ).flyTo({ ',
    '    center: [ lng, lat ],',
    '    screenSpeed: 0.8',
    '});')))).to_clob
);
wwv_flow_imp.component_end;
end;
/
