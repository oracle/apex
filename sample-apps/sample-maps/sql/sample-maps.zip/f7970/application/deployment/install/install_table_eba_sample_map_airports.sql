prompt --application/deployment/install/install_table_eba_sample_map_airports
begin
--   Manifest
--     INSTALL: INSTALL-Table EBA_SAMPLE_MAP_AIRPORTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'alter session set nls_numeric_characters=''.,'''||wwv_flow.LF||
'/'||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- create table'||wwv_flow.LF||
'--'||wwv_flow.LF||
'create table eba_sample_map_ai';
wwv_flow_imp.g_varchar2_table(2) := 'rports ('||wwv_flow.LF||
'    id                     number not null primary key,'||wwv_flow.LF||
'    iata_code              varchar2';
wwv_flow_imp.g_varchar2_table(3) := '(10),'||wwv_flow.LF||
'    airport_type           varchar2(255),'||wwv_flow.LF||
'    airport_name           varchar2(255),'||wwv_flow.LF||
'    city  ';
wwv_flow_imp.g_varchar2_table(4) := '                 varchar2(255),'||wwv_flow.LF||
'    state_name             varchar2(255),'||wwv_flow.LF||
'    activation_date       ';
wwv_flow_imp.g_varchar2_table(5) := ' varchar2(50),'||wwv_flow.LF||
'    activation_date_dt     date,'||wwv_flow.LF||
'    elevation              number,'||wwv_flow.LF||
'    dist_city_to_';
wwv_flow_imp.g_varchar2_table(6) := 'airport   number,'||wwv_flow.LF||
'    land_area_covered      number,'||wwv_flow.LF||
'    commercial_ops         number,'||wwv_flow.LF||
'    air_taxi';
wwv_flow_imp.g_varchar2_table(7) := '_ops           number,'||wwv_flow.LF||
'    geometry               mdsys.sdo_geometry )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP';
wwv_flow_imp.g_varchar2_table(8) := '_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT';
wwv_flow_imp.g_varchar2_table(9) := ',ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1,''A';
wwv_flow_imp.g_varchar2_table(10) := 'DK'',''AIRPORT'',''ADAK'',''ADAK ISLAND'',''ALASKA'',''Apr-49'',to_timestamp(''01.04.1949 00:00:00'',''DD.MM.RR HH';
wwv_flow_imp.g_varchar2_table(11) := '24:MI:SSXFF''),20,0,null,104,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-176.64248, 51.883';
wwv_flow_imp.g_varchar2_table(12) := '58, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME';
wwv_flow_imp.g_varchar2_table(13) := ',CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED';
wwv_flow_imp.g_varchar2_table(14) := ',COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6,''KQA'',''SEAPLANE BASE'',''AKUTAN'',''AKUTAN'',''ALASKA'',nu';
wwv_flow_imp.g_varchar2_table(15) := 'll,null,0,0,null,0,200,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-165.77838, 54.1339, NULL';
wwv_flow_imp.g_varchar2_table(16) := '), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,ST';
wwv_flow_imp.g_varchar2_table(17) := 'ATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERC';
wwv_flow_imp.g_varchar2_table(18) := 'IAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (30,''ANC'',''AIRPORT'',''TED STEVENS ANCHORAGE INTL'',''ANCHORAGE'',''';
wwv_flow_imp.g_varchar2_table(19) := 'ALASKA'',''Nov-51'',to_timestamp(''01.11.1951 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),151,4,4608,98395,76301';
wwv_flow_imp.g_varchar2_table(20) := ',MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-149.99814, 61.17408, NULL), NULL, NULL));'||wwv_flow.LF||
'Inse';
wwv_flow_imp.g_varchar2_table(21) := 'rt into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(22) := 'ATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,';
wwv_flow_imp.g_varchar2_table(23) := 'GEOMETRY) values (39,''LHD'',''AIRPORT'',''LAKE HOOD'',''ANCHORAGE'',''ALASKA'',''Jun-47'',to_timestamp(''01.06.1';
wwv_flow_imp.g_varchar2_table(24) := '947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),79,3,null,118,18417,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(25) := '_POINT_TYPE(-149.96539, 61.18664, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_';
wwv_flow_imp.g_varchar2_table(26) := 'CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CIT';
wwv_flow_imp.g_varchar2_table(27) := 'Y_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (51,''AKA'',''AIRPORT'',''ATK';
wwv_flow_imp.g_varchar2_table(28) := 'A'',''ATKA'',''ALASKA'',''Feb-83'',to_timestamp(''01.02.1983 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),55,2,340,31';
wwv_flow_imp.g_varchar2_table(29) := '2,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-174.20619, 52.22058, NULL), NULL, NULL));'||wwv_flow.LF||
'I';
wwv_flow_imp.g_varchar2_table(30) := 'nsert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(31) := 'N_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_O';
wwv_flow_imp.g_varchar2_table(32) := 'PS,GEOMETRY) values (56,''BRW'',''AIRPORT'',''WILEY POST-WILL ROGERS MEMORIAL'',''BARROW'',''ALASKA'',null,nul';
wwv_flow_imp.g_varchar2_table(33) := 'l,49,0,null,1460,6000,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-156.76858, 71.28486, NULL';
wwv_flow_imp.g_varchar2_table(34) := '), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,ST';
wwv_flow_imp.g_varchar2_table(35) := 'ATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERC';
wwv_flow_imp.g_varchar2_table(36) := 'IAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (68,''BET'',''AIRPORT'',''BETHEL'',''BETHEL'',''ALASKA'',''Nov-58'',to_tim';
wwv_flow_imp.g_varchar2_table(37) := 'estamp(''01.11.1958 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),129,3,1056,5195,65857,MDSYS.SDO_GEOMETRY(2001';
wwv_flow_imp.g_varchar2_table(38) := ', 4326, MDSYS.SDO_POINT_TYPE(-161.83717, 60.77856, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_A';
wwv_flow_imp.g_varchar2_table(39) := 'IRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,E';
wwv_flow_imp.g_varchar2_table(40) := 'LEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (139,''C';
wwv_flow_imp.g_varchar2_table(41) := 'DB'',''AIRPORT'',''COLD BAY'',''COLD BAY'',''ALASKA'',''Apr-49'',to_timestamp(''01.04.1949 00:00:00'',''DD.MM.RR H';
wwv_flow_imp.g_varchar2_table(42) := 'H24:MI:SSXFF''),100,0,2213,2690,5750,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-162.72625, ';
wwv_flow_imp.g_varchar2_table(43) := '55.20592, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPOR';
wwv_flow_imp.g_varchar2_table(44) := 'T_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_C';
wwv_flow_imp.g_varchar2_table(45) := 'OVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (146,''CDV'',''AIRPORT'',''MERLE K (MUDHOLE) SMITH'',''';
wwv_flow_imp.g_varchar2_table(46) := 'CORDOVA'',''ALASKA'',''Jan-49'',to_timestamp(''01.01.1949 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),54,11,2959,2';
wwv_flow_imp.g_varchar2_table(47) := '540,4100,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-145.47756, 60.49178, NULL), NULL, NULL';
wwv_flow_imp.g_varchar2_table(48) := '));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTI';
wwv_flow_imp.g_varchar2_table(49) := 'VATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_T';
wwv_flow_imp.g_varchar2_table(50) := 'AXI_OPS,GEOMETRY) values (157,''DCK'',''AIRPORT'',''DAHL CREEK'',''DAHL CREEK'',''ALASKA'',''Jul-51'',to_timesta';
wwv_flow_imp.g_varchar2_table(51) := 'mp(''01.07.1951 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),260,10,13,5,20,MDSYS.SDO_GEOMETRY(2001, 4326, MDS';
wwv_flow_imp.g_varchar2_table(52) := 'YS.SDO_POINT_TYPE(-156.89137, 66.94256, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID';
wwv_flow_imp.g_varchar2_table(53) := ',IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DI';
wwv_flow_imp.g_varchar2_table(54) := 'ST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (158,''SCC'',''AIRPOR';
wwv_flow_imp.g_varchar2_table(55) := 'T'',''DEADHORSE'',''DEADHORSE'',''ALASKA'',''Apr-70'',to_timestamp(''01.04.1970 00:00:00'',''DD.MM.RR HH24:MI:SS';
wwv_flow_imp.g_varchar2_table(56) := 'XFF''),67,0,6506,5616,3432,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-148.46516, 70.19475, ';
wwv_flow_imp.g_varchar2_table(57) := 'NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CIT';
wwv_flow_imp.g_varchar2_table(58) := 'Y,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COM';
wwv_flow_imp.g_varchar2_table(59) := 'MERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (159,''AK15'',''AIRPORT'',''ALPINE AIRSTRIP'',''NUIQSUT'',''ALASKA''';
wwv_flow_imp.g_varchar2_table(60) := ',''Feb-00'',to_timestamp(''01.02.2000 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),21,8,null,748,null,MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(61) := 'GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-150.94475, 70.34428, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA';
wwv_flow_imp.g_varchar2_table(62) := '_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVAT';
wwv_flow_imp.g_varchar2_table(63) := 'ION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) v';
wwv_flow_imp.g_varchar2_table(64) := 'alues (178,''DLG'',''AIRPORT'',''DILLINGHAM'',''DILLINGHAM'',''ALASKA'',''Nov-50'',to_timestamp(''01.11.1950 00:0';
wwv_flow_imp.g_varchar2_table(65) := '0:00'',''DD.MM.RR HH24:MI:SSXFF''),82,2,620,1323,36489,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_T';
wwv_flow_imp.g_varchar2_table(66) := 'YPE(-158.5055, 59.04467, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRP';
wwv_flow_imp.g_varchar2_table(67) := 'ORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRP';
wwv_flow_imp.g_varchar2_table(68) := 'ORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (214,''FAI'',''AIRPORT'',''FAIRBANKS I';
wwv_flow_imp.g_varchar2_table(69) := 'NTL'',''FAIRBANKS'',''ALASKA'',''Jun-51'',to_timestamp(''01.06.1951 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),439,';
wwv_flow_imp.g_varchar2_table(70) := '3,3470,10894,27611,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-147.85644, 64.81511, NULL), ';
wwv_flow_imp.g_varchar2_table(71) := 'NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE';
wwv_flow_imp.g_varchar2_table(72) := '_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL';
wwv_flow_imp.g_varchar2_table(73) := '_OPS,AIR_TAXI_OPS,GEOMETRY) values (226,''GBH'',''AIRPORT'',''GALBRAITH LAKE'',''GALBRAITH LAKE'',''ALASKA'',''';
wwv_flow_imp.g_varchar2_table(74) := 'Jan-71'',to_timestamp(''01.01.1971 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2663,2,null,26,175,MDSYS.SDO_GE';
wwv_flow_imp.g_varchar2_table(75) := 'OMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-149.48992, 68.47967, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_S';
wwv_flow_imp.g_varchar2_table(76) := 'AMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(77) := 'N_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) val';
wwv_flow_imp.g_varchar2_table(78) := 'ues (227,''GAL'',''AIRPORT'',''EDWARD G PITKA SR'',''GALENA'',''ALASKA'',''Sep-47'',to_timestamp(''01.09.1947 00:';
wwv_flow_imp.g_varchar2_table(79) := '00:00'',''DD.MM.RR HH24:MI:SSXFF''),154,0,1250,3000,1000,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT';
wwv_flow_imp.g_varchar2_table(80) := '_TYPE(-156.93496, 64.7362, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AI';
wwv_flow_imp.g_varchar2_table(81) := 'RPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AI';
wwv_flow_imp.g_varchar2_table(82) := 'RPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (228,''GAM'',''AIRPORT'',''GAMBELL'',';
wwv_flow_imp.g_varchar2_table(83) := '''GAMBELL'',''ALASKA'',''Mar-50'',to_timestamp(''01.03.1950 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),30,0,200,16';
wwv_flow_imp.g_varchar2_table(84) := '52,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-171.73278, 63.76662, NULL), NULL, NULL));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(85) := 'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATI';
wwv_flow_imp.g_varchar2_table(86) := 'ON_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_';
wwv_flow_imp.g_varchar2_table(87) := 'OPS,GEOMETRY) values (239,''GKN'',''AIRPORT'',''GULKANA'',''GULKANA'',''ALASKA'',''Jul-47'',to_timestamp(''01.07.';
wwv_flow_imp.g_varchar2_table(88) := '1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1586,4,1678,996,540,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SD';
wwv_flow_imp.g_varchar2_table(89) := 'O_POINT_TYPE(-145.45529, 62.15433, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA';
wwv_flow_imp.g_varchar2_table(90) := '_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CI';
wwv_flow_imp.g_varchar2_table(91) := 'TY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (241,''GST'',''AIRPORT'',''G';
wwv_flow_imp.g_varchar2_table(92) := 'USTAVUS'',''GUSTAVUS'',''ALASKA'',''Jan-49'',to_timestamp(''01.01.1949 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),3';
wwv_flow_imp.g_varchar2_table(93) := '6,0,1821,200,3300,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-135.70742, 58.42528, NULL), N';
wwv_flow_imp.g_varchar2_table(94) := 'ULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_';
wwv_flow_imp.g_varchar2_table(95) := 'NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_';
wwv_flow_imp.g_varchar2_table(96) := 'OPS,AIR_TAXI_OPS,GEOMETRY) values (257,''HOM'',''AIRPORT'',''HOMER'',''HOMER'',''ALASKA'',''May-47'',to_timestam';
wwv_flow_imp.g_varchar2_table(97) := 'p(''01.05.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),84,2,1040,33077,10900,MDSYS.SDO_GEOMETRY(2001, 432';
wwv_flow_imp.g_varchar2_table(98) := '6, MDSYS.SDO_POINT_TYPE(-151.48581, 59.64499, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPOR';
wwv_flow_imp.g_varchar2_table(99) := 'TS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVAT';
wwv_flow_imp.g_varchar2_table(100) := 'ION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (290,''JNU'',''';
wwv_flow_imp.g_varchar2_table(101) := 'AIRPORT'',''JUNEAU INTL'',''JUNEAU'',''ALASKA'',''Nov-41'',to_timestamp(''01.11.1941 00:00:00'',''DD.MM.RR HH24:';
wwv_flow_imp.g_varchar2_table(102) := 'MI:SSXFF''),25,7,662,9138,86135,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-134.57847, 58.35';
wwv_flow_imp.g_varchar2_table(103) := '471, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAM';
wwv_flow_imp.g_varchar2_table(104) := 'E,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERE';
wwv_flow_imp.g_varchar2_table(105) := 'D,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (313,''ENA'',''AIRPORT'',''KENAI MUNI'',''KENAI'',''ALASKA'',''M';
wwv_flow_imp.g_varchar2_table(106) := 'ay-47'',to_timestamp(''01.05.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),100,0,1200,1040,24529,MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(107) := 'GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-151.24483, 60.57328, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA';
wwv_flow_imp.g_varchar2_table(108) := '_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVAT';
wwv_flow_imp.g_varchar2_table(109) := 'ION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) v';
wwv_flow_imp.g_varchar2_table(110) := 'alues (328,''KTN'',''AIRPORT'',''KETCHIKAN INTL'',''KETCHIKAN'',''ALASKA'',''Apr-73'',to_timestamp(''01.04.1973 0';
wwv_flow_imp.g_varchar2_table(111) := '0:00:00'',''DD.MM.RR HH24:MI:SSXFF''),92,1,2600,5290,9789,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POIN';
wwv_flow_imp.g_varchar2_table(112) := 'T_TYPE(-131.71122, 55.35408, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,';
wwv_flow_imp.g_varchar2_table(113) := 'AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_';
wwv_flow_imp.g_varchar2_table(114) := 'AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (335,''AKN'',''AIRPORT'',''KING SA';
wwv_flow_imp.g_varchar2_table(115) := 'LMON'',''KING SALMON'',''ALASKA'',''Aug-54'',to_timestamp(''01.08.1954 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),7';
wwv_flow_imp.g_varchar2_table(116) := '3,0,5277,476,10708,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-156.64869, 58.67649, NULL), ';
wwv_flow_imp.g_varchar2_table(117) := 'NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE';
wwv_flow_imp.g_varchar2_table(118) := '_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL';
wwv_flow_imp.g_varchar2_table(119) := '_OPS,AIR_TAXI_OPS,GEOMETRY) values (346,''ADQ'',''AIRPORT'',''KODIAK'',''KODIAK'',''ALASKA'',''Apr-48'',to_times';
wwv_flow_imp.g_varchar2_table(120) := 'tamp(''01.04.1948 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),79,4,null,2300,20880,MDSYS.SDO_GEOMETRY(2001, 4';
wwv_flow_imp.g_varchar2_table(121) := '326, MDSYS.SDO_POINT_TYPE(-152.49394, 57.74979, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRP';
wwv_flow_imp.g_varchar2_table(122) := 'ORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEV';
wwv_flow_imp.g_varchar2_table(123) := 'ATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (350,''DUY''';
wwv_flow_imp.g_varchar2_table(124) := ',''AIRPORT'',''KONGIGANAK'',''KONGIGANAK'',''ALASKA'',''Sep-76'',to_timestamp(''01.09.1976 00:00:00'',''DD.MM.RR ';
wwv_flow_imp.g_varchar2_table(125) := 'HH24:MI:SSXFF''),33,1,134,2080,624,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-162.88059, 59';
wwv_flow_imp.g_varchar2_table(126) := '.96163, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(127) := 'NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COV';
wwv_flow_imp.g_varchar2_table(128) := 'ERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (352,''OTZ'',''AIRPORT'',''RALPH WIEN MEMORIAL'',''KOTZEB';
wwv_flow_imp.g_varchar2_table(129) := 'UE'',''ALASKA'',''Sep-47'',to_timestamp(''01.09.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),15,1,1480,2000,20';
wwv_flow_imp.g_varchar2_table(130) := '000,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-162.59814, 66.88481, NULL), NULL, NULL));'||wwv_flow.LF||
'I';
wwv_flow_imp.g_varchar2_table(131) := 'nsert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(132) := 'N_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_O';
wwv_flow_imp.g_varchar2_table(133) := 'PS,GEOMETRY) values (364,''2A3'',''AIRPORT'',''LARSEN BAY'',''LARSEN BAY'',''ALASKA'',null,null,87,0,null,0,19';
wwv_flow_imp.g_varchar2_table(134) := '50,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-153.97667, 57.53508, NULL), NULL, NULL));'||wwv_flow.LF||
'In';
wwv_flow_imp.g_varchar2_table(135) := 'sert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION';
wwv_flow_imp.g_varchar2_table(136) := '_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OP';
wwv_flow_imp.g_varchar2_table(137) := 'S,GEOMETRY) values (391,''MYU'',''AIRPORT'',''MEKORYUK'',''MEKORYUK'',''ALASKA'',''Oct-60'',to_timestamp(''01.10.';
wwv_flow_imp.g_varchar2_table(138) := '1960 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),53,3,575,1207,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(139) := '_POINT_TYPE(-166.27019, 60.37239, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_';
wwv_flow_imp.g_varchar2_table(140) := 'CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CIT';
wwv_flow_imp.g_varchar2_table(141) := 'Y_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (427,''OME'',''AIRPORT'',''NO';
wwv_flow_imp.g_varchar2_table(142) := 'ME'',''NOME'',''ALASKA'',null,null,41,2,null,1525,14950,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TY';
wwv_flow_imp.g_varchar2_table(143) := 'PE(-165.44439, 64.51256, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRP';
wwv_flow_imp.g_varchar2_table(144) := 'ORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRP';
wwv_flow_imp.g_varchar2_table(145) := 'ORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (487,''PSG'',''AIRPORT'',''PETERSBURG ';
wwv_flow_imp.g_varchar2_table(146) := 'JAMES A JOHNSON'',''PETERSBURG'',''ALASKA'',''Jan-64'',to_timestamp(''01.01.1964 00:00:00'',''DD.MM.RR HH24:MI';
wwv_flow_imp.g_varchar2_table(147) := ':SSXFF''),113,1,null,1392,10000,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-132.94622, 56.80';
wwv_flow_imp.g_varchar2_table(148) := '147, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAM';
wwv_flow_imp.g_varchar2_table(149) := 'E,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERE';
wwv_flow_imp.g_varchar2_table(150) := 'D,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (503,''05K'',''AIRPORT'',''WILDER/NATWICK LLC'',''PORT ALSWO';
wwv_flow_imp.g_varchar2_table(151) := 'RTH'',''ALASKA'',''Nov-02'',to_timestamp(''01.11.2002 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),288,0,20,1,null,';
wwv_flow_imp.g_varchar2_table(152) := 'MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-154.32305, 60.19848, NULL), NULL, NULL));'||wwv_flow.LF||
'Inser';
wwv_flow_imp.g_varchar2_table(153) := 't into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DA';
wwv_flow_imp.g_varchar2_table(154) := 'TE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,G';
wwv_flow_imp.g_varchar2_table(155) := 'EOMETRY) values (512,''PPC'',''AIRPORT'',''PROSPECT CREEK'',''PROSPECT CREEK'',''ALASKA'',''Jun-71'',to_timestam';
wwv_flow_imp.g_varchar2_table(156) := 'p(''01.06.1971 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1095,3,null,26,252,MDSYS.SDO_GEOMETRY(2001, 4326, ';
wwv_flow_imp.g_varchar2_table(157) := 'MDSYS.SDO_POINT_TYPE(-150.64361, 66.81406, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS ';
wwv_flow_imp.g_varchar2_table(158) := '(ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION';
wwv_flow_imp.g_varchar2_table(159) := ',DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (526,''PBV'',''AIR';
wwv_flow_imp.g_varchar2_table(160) := 'PORT'',''ST GEORGE'',''ST GEORGE'',''ALASKA'',''Jul-92'',to_timestamp(''01.07.1992 00:00:00'',''DD.MM.RR HH24:MI';
wwv_flow_imp.g_varchar2_table(161) := ':SSXFF''),128,4,278,156,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-169.66372, 56.57736, N';
wwv_flow_imp.g_varchar2_table(162) := 'ULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY';
wwv_flow_imp.g_varchar2_table(163) := ',STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMM';
wwv_flow_imp.g_varchar2_table(164) := 'ERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (527,''KSM'',''AIRPORT'',''ST MARY''''S'',''ST MARY''''S'',''ALASKA'',nul';
wwv_flow_imp.g_varchar2_table(165) := 'l,null,312,4,3600,250,250,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-163.30183, 62.06083, ';
wwv_flow_imp.g_varchar2_table(166) := 'NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CIT';
wwv_flow_imp.g_varchar2_table(167) := 'Y,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COM';
wwv_flow_imp.g_varchar2_table(168) := 'MERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (531,''SDP'',''AIRPORT'',''SAND POINT'',''SAND POINT'',''ALASKA'',''J';
wwv_flow_imp.g_varchar2_table(169) := 'un-58'',to_timestamp(''01.06.1958 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),24,2,null,0,0,MDSYS.SDO_GEOMETRY';
wwv_flow_imp.g_varchar2_table(170) := '(2001, 4326, MDSYS.SDO_POINT_TYPE(-160.52142, 55.3137, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_M';
wwv_flow_imp.g_varchar2_table(171) := 'AP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_';
wwv_flow_imp.g_varchar2_table(172) := 'DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (53';
wwv_flow_imp.g_varchar2_table(173) := '3,''SVA'',''AIRPORT'',''SAVOONGA'',''SAVOONGA'',''ALASKA'',''Aug-65'',to_timestamp(''01.08.1965 00:00:00'',''DD.MM.';
wwv_flow_imp.g_varchar2_table(174) := 'RR HH24:MI:SSXFF''),59,1,834,256,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-170.49317,';
wwv_flow_imp.g_varchar2_table(175) := ' 63.68628, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPO';
wwv_flow_imp.g_varchar2_table(176) := 'RT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_';
wwv_flow_imp.g_varchar2_table(177) := 'COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (549,''SIT'',''AIRPORT'',''SITKA ROCKY GUTIERREZ'',''S';
wwv_flow_imp.g_varchar2_table(178) := 'ITKA'',''ALASKA'',''Dec-69'',to_timestamp(''01.12.1969 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),27,0,null,1800,';
wwv_flow_imp.g_varchar2_table(179) := '9860,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-135.36107, 57.04683, NULL), NULL, NULL));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(180) := 'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATI';
wwv_flow_imp.g_varchar2_table(181) := 'ON_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_';
wwv_flow_imp.g_varchar2_table(182) := 'OPS,GEOMETRY) values (584,''UMM'',''AIRPORT'',''SUMMIT'',''SUMMIT'',''ALASKA'',''Aug-47'',to_timestamp(''01.08.19';
wwv_flow_imp.g_varchar2_table(183) := '47 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2409,0,null,0,400,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_PO';
wwv_flow_imp.g_varchar2_table(184) := 'INT_TYPE(-149.12884, 63.33104, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_COD';
wwv_flow_imp.g_varchar2_table(185) := 'E,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_T';
wwv_flow_imp.g_varchar2_table(186) := 'O_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (622,''KTB'',''SEAPLANE BASE'',';
wwv_flow_imp.g_varchar2_table(187) := '''THORNE BAY'',''THORNE BAY'',''ALASKA'',''Apr-70'',to_timestamp(''01.04.1970 00:00:00'',''DD.MM.RR HH24:MI:SSX';
wwv_flow_imp.g_varchar2_table(188) := 'FF''),0,0,null,0,900,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-132.53668, 55.68796, NULL),';
wwv_flow_imp.g_varchar2_table(189) := ' NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STAT';
wwv_flow_imp.g_varchar2_table(190) := 'E_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIA';
wwv_flow_imp.g_varchar2_table(191) := 'L_OPS,AIR_TAXI_OPS,GEOMETRY) values (652,''DUT'',''AIRPORT'',''UNALASKA'',''UNALASKA'',''ALASKA'',''Jan-50'',to_';
wwv_flow_imp.g_varchar2_table(192) := 'timestamp(''01.01.1950 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),23,1,null,2500,100,MDSYS.SDO_GEOMETRY(2001';
wwv_flow_imp.g_varchar2_table(193) := ', 4326, MDSYS.SDO_POINT_TYPE(-166.54503, 53.89894, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_A';
wwv_flow_imp.g_varchar2_table(194) := 'IRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,E';
wwv_flow_imp.g_varchar2_table(195) := 'LEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (751,''W';
wwv_flow_imp.g_varchar2_table(196) := 'RG'',''AIRPORT'',''WRANGELL'',''WRANGELL'',''ALASKA'',null,null,44,1,null,725,6200,MDSYS.SDO_GEOMETRY(2001, 4';
wwv_flow_imp.g_varchar2_table(197) := '326, MDSYS.SDO_POINT_TYPE(-132.36983, 56.48433, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRP';
wwv_flow_imp.g_varchar2_table(198) := 'ORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEV';
wwv_flow_imp.g_varchar2_table(199) := 'ATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (753,''3AK''';
wwv_flow_imp.g_varchar2_table(200) := ',''AIRPORT'',''DRY BAY'',''YAKUTAT'',''ALASKA'',''May-13'',to_timestamp(''01.05.2013 00:00:00'',''DD.MM.RR HH24:M';
wwv_flow_imp.g_varchar2_table(201) := 'I:SSXFF''),33,44,null,0,800,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-138.48881, 59.16433,';
wwv_flow_imp.g_varchar2_table(202) := ' NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CI';
wwv_flow_imp.g_varchar2_table(203) := 'TY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,CO';
wwv_flow_imp.g_varchar2_table(204) := 'MMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (754,''YAK'',''AIRPORT'',''YAKUTAT'',''YAKUTAT'',''ALASKA'',''Mar-49';
wwv_flow_imp.g_varchar2_table(205) := ''',to_timestamp(''01.03.1949 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),40,3,null,726,5000,MDSYS.SDO_GEOMETRY';
wwv_flow_imp.g_varchar2_table(206) := '(2001, 4326, MDSYS.SDO_POINT_TYPE(-139.66027, 59.50332, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_';
wwv_flow_imp.g_varchar2_table(207) := 'MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(208) := '_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7';
wwv_flow_imp.g_varchar2_table(209) := '58,''2Y3'',''SEAPLANE BASE'',''YAKUTAT'',''YAKUTAT'',''ALASKA'',null,null,0,1,null,200,null,MDSYS.SDO_GEOMETRY';
wwv_flow_imp.g_varchar2_table(210) := '(2001, 4326, MDSYS.SDO_POINT_TYPE(-139.74994, 59.57769, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_';
wwv_flow_imp.g_varchar2_table(211) := 'MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(212) := '_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7';
wwv_flow_imp.g_varchar2_table(213) := '73,''ANB'',''AIRPORT'',''ANNISTON RGNL'',''ANNISTON'',''ALABAMA'',''Mar-41'',to_timestamp(''01.03.1941 00:00:00'',';
wwv_flow_imp.g_varchar2_table(214) := '''DD.MM.RR HH24:MI:SSXFF''),612,5,596,6,4812,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-85.8';
wwv_flow_imp.g_varchar2_table(215) := '5811, 33.58817, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,';
wwv_flow_imp.g_varchar2_table(216) := 'AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_';
wwv_flow_imp.g_varchar2_table(217) := 'AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (789,''BHM'',''AIRPORT'',''BIRMINGHAM-SHUTTLESW';
wwv_flow_imp.g_varchar2_table(218) := 'ORTH INTL'',''BIRMINGHAM'',''ALABAMA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXF';
wwv_flow_imp.g_varchar2_table(219) := 'F''),650,4,2170,33994,20366,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-86.75231, 33.56389, ';
wwv_flow_imp.g_varchar2_table(220) := 'NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CIT';
wwv_flow_imp.g_varchar2_table(221) := 'Y,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COM';
wwv_flow_imp.g_varchar2_table(222) := 'MERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (846,''DHN'',''AIRPORT'',''DOTHAN RGNL'',''DOTHAN'',''ALABAMA'',''Jul';
wwv_flow_imp.g_varchar2_table(223) := '-42'',to_timestamp(''01.07.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),401,5,1150,2365,707,MDSYS.SDO_GEOM';
wwv_flow_imp.g_varchar2_table(224) := 'ETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-85.44947, 31.32103, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMP';
wwv_flow_imp.g_varchar2_table(225) := 'LE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(226) := 'ATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values';
wwv_flow_imp.g_varchar2_table(227) := ' (939,''HSV'',''AIRPORT'',''HUNTSVILLE INTL-CARL T JONES FIELD'',''HUNTSVILLE'',''ALABAMA'',''May-64'',to_timest';
wwv_flow_imp.g_varchar2_table(228) := 'amp(''01.05.1964 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),629,9,6000,15085,10872,MDSYS.SDO_GEOMETRY(2001, ';
wwv_flow_imp.g_varchar2_table(229) := '4326, MDSYS.SDO_POINT_TYPE(-86.77505, 34.6372, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPO';
wwv_flow_imp.g_varchar2_table(230) := 'RTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVA';
wwv_flow_imp.g_varchar2_table(231) := 'TION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (969,''BFM'',';
wwv_flow_imp.g_varchar2_table(232) := '''AIRPORT'',''MOBILE DOWNTOWN'',''MOBILE'',''ALABAMA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR';
wwv_flow_imp.g_varchar2_table(233) := ' HH24:MI:SSXFF''),26,3,1616,2065,160725,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-88.06808';
wwv_flow_imp.g_varchar2_table(234) := ', 30.62678, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRP';
wwv_flow_imp.g_varchar2_table(235) := 'ORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA';
wwv_flow_imp.g_varchar2_table(236) := '_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (974,''MOB'',''AIRPORT'',''MOBILE RGNL'',''MOBILE'',''A';
wwv_flow_imp.g_varchar2_table(237) := 'LABAMA'',''Apr-42'',to_timestamp(''01.04.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),219,11,1717,3739,7531,';
wwv_flow_imp.g_varchar2_table(238) := 'MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-88.24283, 30.69142, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert';
wwv_flow_imp.g_varchar2_table(239) := ' into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DAT';
wwv_flow_imp.g_varchar2_table(240) := 'E,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GE';
wwv_flow_imp.g_varchar2_table(241) := 'OMETRY) values (983,''MGM'',''AIRPORT'',''MONTGOMERY RGNL (DANNELLY FIELD)'',''MONTGOMERY'',''ALABAMA'',''Jun-8';
wwv_flow_imp.g_varchar2_table(242) := '7'',to_timestamp(''01.06.1987 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),221,6,1907,1048,8873,MDSYS.SDO_GEOME';
wwv_flow_imp.g_varchar2_table(243) := 'TRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-86.39397, 32.30064, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPL';
wwv_flow_imp.g_varchar2_table(244) := 'E_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DA';
wwv_flow_imp.g_varchar2_table(245) := 'TE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values ';
wwv_flow_imp.g_varchar2_table(246) := '(989,''MSL'',''AIRPORT'',''NORTHWEST ALABAMA RGNL'',''MUSCLE SHOALS'',''ALABAMA'',''Apr-40'',to_timestamp(''01.04';
wwv_flow_imp.g_varchar2_table(247) := '.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),551,1,640,2750,350,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SD';
wwv_flow_imp.g_varchar2_table(248) := 'O_POINT_TYPE(-87.61022, 34.74531, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_';
wwv_flow_imp.g_varchar2_table(249) := 'CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CIT';
wwv_flow_imp.g_varchar2_table(250) := 'Y_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1048,''ASN'',''AIRPORT'',''T';
wwv_flow_imp.g_varchar2_table(251) := 'ALLADEGA MUNI'',''TALLADEGA'',''ALABAMA'',''Oct-43'',to_timestamp(''01.10.1943 00:00:00'',''DD.MM.RR HH24:MI:S';
wwv_flow_imp.g_varchar2_table(252) := 'SXFF''),529,8,1029,0,630,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-86.0512, 33.5695, NULL)';
wwv_flow_imp.g_varchar2_table(253) := ', NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STA';
wwv_flow_imp.g_varchar2_table(254) := 'TE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCI';
wwv_flow_imp.g_varchar2_table(255) := 'AL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1056,''TCL'',''AIRPORT'',''TUSCALOOSA RGNL'',''TUSCALOOSA'',''ALABAMA'',';
wwv_flow_imp.g_varchar2_table(256) := '''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),170,3,724,378,2807,MDSYS.SDO_G';
wwv_flow_imp.g_varchar2_table(257) := 'EOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-87.6114, 33.22063, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SA';
wwv_flow_imp.g_varchar2_table(258) := 'MPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION';
wwv_flow_imp.g_varchar2_table(259) := '_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) valu';
wwv_flow_imp.g_varchar2_table(260) := 'es (1165,''ELD'',''AIRPORT'',''SOUTH ARKANSAS RGNL AT GOODWIN FIELD'',''EL DORADO'',''ARKANSAS'',''Dec-44'',to_t';
wwv_flow_imp.g_varchar2_table(261) := 'imestamp(''01.12.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),277,8,1540,2496,2920,MDSYS.SDO_GEOMETRY(200';
wwv_flow_imp.g_varchar2_table(262) := '1, 4326, MDSYS.SDO_POINT_TYPE(-92.81175, 33.22124, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_A';
wwv_flow_imp.g_varchar2_table(263) := 'IRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,E';
wwv_flow_imp.g_varchar2_table(264) := 'LEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1174,''';
wwv_flow_imp.g_varchar2_table(265) := 'FYV'',''AIRPORT'',''DRAKE FIELD'',''FAYETTEVILLE'',''ARKANSAS'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''';
wwv_flow_imp.g_varchar2_table(266) := 'DD.MM.RR HH24:MI:SSXFF''),1252,3,631,41,1076,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-94.';
wwv_flow_imp.g_varchar2_table(267) := '17006, 36.00508, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE';
wwv_flow_imp.g_varchar2_table(268) := ',AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND';
wwv_flow_imp.g_varchar2_table(269) := '_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1175,''XNA'',''AIRPORT'',''NORTHWEST ARKANSAS';
wwv_flow_imp.g_varchar2_table(270) := ' RGNL'',''FAYETTEVILLE/SPRINGDALE/ROGERS'',''ARKANSAS'',''Apr-97'',to_timestamp(''01.04.1997 00:00:00'',''DD.M';
wwv_flow_imp.g_varchar2_table(271) := 'M.RR HH24:MI:SSXFF''),1288,15,2184,17551,12095,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-9';
wwv_flow_imp.g_varchar2_table(272) := '4.30777, 36.28158, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TY';
wwv_flow_imp.g_varchar2_table(273) := 'PE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LA';
wwv_flow_imp.g_varchar2_table(274) := 'ND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1187,''FSM'',''AIRPORT'',''FORT SMITH RGNL''';
wwv_flow_imp.g_varchar2_table(275) := ',''FORT SMITH'',''ARKANSAS'',''Jul-41'',to_timestamp(''01.07.1941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),469,3';
wwv_flow_imp.g_varchar2_table(276) := ',1359,1499,3261,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-94.36744, 35.33658, NULL), NULL';
wwv_flow_imp.g_varchar2_table(277) := ', NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAM';
wwv_flow_imp.g_varchar2_table(278) := 'E,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS';
wwv_flow_imp.g_varchar2_table(279) := ',AIR_TAXI_OPS,GEOMETRY) values (1207,''HRO'',''AIRPORT'',''BOONE COUNTY'',''HARRISON'',''ARKANSAS'',''Dec-44'',t';
wwv_flow_imp.g_varchar2_table(280) := 'o_timestamp(''01.12.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1365,3,425,2100,1150,MDSYS.SDO_GEOMETRY(';
wwv_flow_imp.g_varchar2_table(281) := '2001, 4326, MDSYS.SDO_POINT_TYPE(-93.15473, 36.26152, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MA';
wwv_flow_imp.g_varchar2_table(282) := 'P_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_D';
wwv_flow_imp.g_varchar2_table(283) := 'T,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (124';
wwv_flow_imp.g_varchar2_table(284) := '5,''LIT'',''AIRPORT'',''BILL AND HILLARY CLINTON NATIONAL/ADAMS FIELD'',''LITTLE ROCK'',''ARKANSAS'',''Apr-40'',';
wwv_flow_imp.g_varchar2_table(285) := 'to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),266,2,2000,23716,13210,MDSYS.SDO_GEOMET';
wwv_flow_imp.g_varchar2_table(286) := 'RY(2001, 4326, MDSYS.SDO_POINT_TYPE(-92.22478, 34.72944, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE';
wwv_flow_imp.g_varchar2_table(287) := '_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DAT';
wwv_flow_imp.g_varchar2_table(288) := 'E_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (';
wwv_flow_imp.g_varchar2_table(289) := '1362,''TXK'',''AIRPORT'',''TEXARKANA RGNL-WEBB FIELD'',''TEXARKANA'',''ARKANSAS'',''Apr-40'',to_timestamp(''01.04';
wwv_flow_imp.g_varchar2_table(290) := '.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),390,3,964,33,4816,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(291) := '_POINT_TYPE(-93.99103, 33.45372, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_C';
wwv_flow_imp.g_varchar2_table(292) := 'ODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY';
wwv_flow_imp.g_varchar2_table(293) := '_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1386,''FAQ'',''AIRPORT'',''FI';
wwv_flow_imp.g_varchar2_table(294) := 'TIUTA'',''FITIUTA VILLAGE'',''AMERICAN SAMOA'',''Oct-90'',to_timestamp(''01.10.1990 00:00:00'',''DD.MM.RR HH24';
wwv_flow_imp.g_varchar2_table(295) := ':MI:SSXFF''),110,0,null,480,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-169.42355, -14.216';
wwv_flow_imp.g_varchar2_table(296) := '11, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME';
wwv_flow_imp.g_varchar2_table(297) := ',CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED';
wwv_flow_imp.g_varchar2_table(298) := ',COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1387,''Z08'',''AIRPORT'',''OFU'',''OFU VILLAGE'',''AMERICAN SA';
wwv_flow_imp.g_varchar2_table(299) := 'MOA'',''Jan-75'',to_timestamp(''01.01.1975 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),12,1,18,220,0,MDSYS.SDO_G';
wwv_flow_imp.g_varchar2_table(300) := 'EOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-169.6701, -14.18434, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_';
wwv_flow_imp.g_varchar2_table(301) := 'SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATI';
wwv_flow_imp.g_varchar2_table(302) := 'ON_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) va';
wwv_flow_imp.g_varchar2_table(303) := 'lues (1388,''PPG'',''AIRPORT'',''PAGO PAGO INTL'',''PAGO PAGO'',''AMERICAN SAMOA'',''Jan-56'',to_timestamp(''01.0';
wwv_flow_imp.g_varchar2_table(304) := '1.1956 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),31,3,700,8474,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.S';
wwv_flow_imp.g_varchar2_table(305) := 'DO_POINT_TYPE(-170.7115, -14.33166, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IAT';
wwv_flow_imp.g_varchar2_table(306) := 'A_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_C';
wwv_flow_imp.g_varchar2_table(307) := 'ITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1403,''IFP'',''AIRPORT'',';
wwv_flow_imp.g_varchar2_table(308) := '''LAUGHLIN/BULLHEAD INTL'',''BULLHEAD CITY'',''ARIZONA'',null,null,707,1,650,1620,1589,MDSYS.SDO_GEOMETRY(';
wwv_flow_imp.g_varchar2_table(309) := '2001, 4326, MDSYS.SDO_POINT_TYPE(-114.55933, 35.15461, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_M';
wwv_flow_imp.g_varchar2_table(310) := 'AP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_';
wwv_flow_imp.g_varchar2_table(311) := 'DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14';
wwv_flow_imp.g_varchar2_table(312) := '40,''FLG'',''AIRPORT'',''FLAGSTAFF PULLIAM'',''FLAGSTAFF'',''ARIZONA'',''Nov-48'',to_timestamp(''01.11.1948 00:00';
wwv_flow_imp.g_varchar2_table(313) := ':00'',''DD.MM.RR HH24:MI:SSXFF''),7015,4,763,1157,10778,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_';
wwv_flow_imp.g_varchar2_table(314) := 'TYPE(-111.66924, 35.14032, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AI';
wwv_flow_imp.g_varchar2_table(315) := 'RPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AI';
wwv_flow_imp.g_varchar2_table(316) := 'RPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1443,''FHU'',''AIRPORT'',''SIERRA V';
wwv_flow_imp.g_varchar2_table(317) := 'ISTA MUNI-LIBBY AAF'',''FORT HUACHUCA SIERRA VISTA'',''ARIZONA'',''Nov-72'',to_timestamp(''01.11.1972 00:00:';
wwv_flow_imp.g_varchar2_table(318) := '00'',''DD.MM.RR HH24:MI:SSXFF''),4719,3,null,5013,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_T';
wwv_flow_imp.g_varchar2_table(319) := 'YPE(-110.34439, 31.58847, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIR';
wwv_flow_imp.g_varchar2_table(320) := 'PORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIR';
wwv_flow_imp.g_varchar2_table(321) := 'PORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1461,''GYR'',''AIRPORT'',''PHOENIX G';
wwv_flow_imp.g_varchar2_table(322) := 'OODYEAR'',''GOODYEAR'',''ARIZONA'',null,null,969,1,789,228,5989,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(323) := 'POINT_TYPE(-112.37536, 33.42328, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_C';
wwv_flow_imp.g_varchar2_table(324) := 'ODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY';
wwv_flow_imp.g_varchar2_table(325) := '_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1462,''GCN'',''AIRPORT'',''GR';
wwv_flow_imp.g_varchar2_table(326) := 'AND CANYON NATIONAL PARK'',''GRAND CANYON'',''ARIZONA'',''May-62'',to_timestamp(''01.05.1962 00:00:00'',''DD.M';
wwv_flow_imp.g_varchar2_table(327) := 'M.RR HH24:MI:SSXFF''),6609,6,859,53,48661,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-112.14';
wwv_flow_imp.g_varchar2_table(328) := '697, 35.95236, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,A';
wwv_flow_imp.g_varchar2_table(329) := 'IRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_A';
wwv_flow_imp.g_varchar2_table(330) := 'REA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1475,''IGM'',''AIRPORT'',''KINGMAN'',''KINGMAN'',''';
wwv_flow_imp.g_varchar2_table(331) := 'ARIZONA'',''Sep-43'',to_timestamp(''01.09.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),3449,8,4200,1358,1100';
wwv_flow_imp.g_varchar2_table(332) := ',MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-113.93805, 35.25948, NULL), NULL, NULL));'||wwv_flow.LF||
'Inse';
wwv_flow_imp.g_varchar2_table(333) := 'rt into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(334) := 'ATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,';
wwv_flow_imp.g_varchar2_table(335) := 'GEOMETRY) values (1503,''FFZ'',''AIRPORT'',''FALCON FLD'',''MESA'',''ARIZONA'',''Dec-41'',to_timestamp(''01.12.19';
wwv_flow_imp.g_varchar2_table(336) := '41 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1394,5,784,9,67638,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_P';
wwv_flow_imp.g_varchar2_table(337) := 'OINT_TYPE(-111.72833, 33.46084, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CO';
wwv_flow_imp.g_varchar2_table(338) := 'DE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_';
wwv_flow_imp.g_varchar2_table(339) := 'TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1522,''PGA'',''AIRPORT'',''PAG';
wwv_flow_imp.g_varchar2_table(340) := 'E MUNI'',''PAGE'',''ARIZONA'',''Sep-57'',to_timestamp(''01.09.1957 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4317,';
wwv_flow_imp.g_varchar2_table(341) := '1,555,355,7586,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-111.44835, 36.92607, NULL), NULL';
wwv_flow_imp.g_varchar2_table(342) := ', NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAM';
wwv_flow_imp.g_varchar2_table(343) := 'E,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS';
wwv_flow_imp.g_varchar2_table(344) := ',AIR_TAXI_OPS,GEOMETRY) values (1552,''DVT'',''AIRPORT'',''PHOENIX DEER VALLEY'',''PHOENIX'',''ARIZONA'',''Sep-';
wwv_flow_imp.g_varchar2_table(345) := '59'',to_timestamp(''01.09.1959 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1478,15,914,12,4670,MDSYS.SDO_GEOME';
wwv_flow_imp.g_varchar2_table(346) := 'TRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-112.08256, 33.68831, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMP';
wwv_flow_imp.g_varchar2_table(347) := 'LE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(348) := 'ATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values';
wwv_flow_imp.g_varchar2_table(349) := ' (1567,''IWA'',''AIRPORT'',''PHOENIX-MESA GATEWAY'',''PHOENIX'',''ARIZONA'',''Dec-93'',to_timestamp(''01.12.1993 ';
wwv_flow_imp.g_varchar2_table(350) := '00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1384,20,3020,12197,45324,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SD';
wwv_flow_imp.g_varchar2_table(351) := 'O_POINT_TYPE(-111.65547, 33.30783, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA';
wwv_flow_imp.g_varchar2_table(352) := '_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CI';
wwv_flow_imp.g_varchar2_table(353) := 'TY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1568,''PHX'',''AIRPORT'',''';
wwv_flow_imp.g_varchar2_table(354) := 'PHOENIX SKY HARBOR INTL'',''PHOENIX'',''ARIZONA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR H';
wwv_flow_imp.g_varchar2_table(355) := 'H24:MI:SSXFF''),1135,3,3400,384714,27327,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-112.011';
wwv_flow_imp.g_varchar2_table(356) := '58, 33.43428, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AI';
wwv_flow_imp.g_varchar2_table(357) := 'RPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AR';
wwv_flow_imp.g_varchar2_table(358) := 'EA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1574,''PRC'',''AIRPORT'',''PRESCOTT RGNL - ERNES';
wwv_flow_imp.g_varchar2_table(359) := 'T A LOVE FLD'',''PRESCOTT'',''ARIZONA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSX';
wwv_flow_imp.g_varchar2_table(360) := 'FF''),5045,7,760,68,31424,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-112.41922, 34.65483, N';
wwv_flow_imp.g_varchar2_table(361) := 'ULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY';
wwv_flow_imp.g_varchar2_table(362) := ',STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMM';
wwv_flow_imp.g_varchar2_table(363) := 'ERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1611,''SOW'',''AIRPORT'',''SHOW LOW RGNL'',''SHOW LOW'',''ARIZONA'',';
wwv_flow_imp.g_varchar2_table(364) := '''Dec-46'',to_timestamp(''01.12.1946 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),6415,2,691,0,8948,MDSYS.SDO_GE';
wwv_flow_imp.g_varchar2_table(365) := 'OMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-110.00567, 34.26547, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_S';
wwv_flow_imp.g_varchar2_table(366) := 'AMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(367) := 'N_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) val';
wwv_flow_imp.g_varchar2_table(368) := 'ues (1656,''TUS'',''AIRPORT'',''TUCSON INTL'',''TUCSON'',''ARIZONA'',''Nov-41'',to_timestamp(''01.11.1941 00:00:0';
wwv_flow_imp.g_varchar2_table(369) := '0'',''DD.MM.RR HH24:MI:SSXFF''),2643,6,7938,37003,14024,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_';
wwv_flow_imp.g_varchar2_table(370) := 'TYPE(-110.94101, 32.11607, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AI';
wwv_flow_imp.g_varchar2_table(371) := 'RPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AI';
wwv_flow_imp.g_varchar2_table(372) := 'RPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1684,''NYL'',''AIRPORT'',''YUMA MCA';
wwv_flow_imp.g_varchar2_table(373) := 'S/YUMA INTL'',''YUMA'',''ARIZONA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),';
wwv_flow_imp.g_varchar2_table(374) := '213,3,3100,16299,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-114.60599, 32.65657, NULL';
wwv_flow_imp.g_varchar2_table(375) := '), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,ST';
wwv_flow_imp.g_varchar2_table(376) := 'ATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERC';
wwv_flow_imp.g_varchar2_table(377) := 'IAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1713,''ACV'',''AIRPORT'',''CALIFORNIA REDWOOD COAST-HUMBOLDT COUNT';
wwv_flow_imp.g_varchar2_table(378) := 'Y'',''ARCATA/EUREKA'',''CALIFORNIA'',''Mar-43'',to_timestamp(''01.03.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''';
wwv_flow_imp.g_varchar2_table(379) := '),222,7,745,5840,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-124.10847, 40.97783, NULL), ';
wwv_flow_imp.g_varchar2_table(380) := 'NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE';
wwv_flow_imp.g_varchar2_table(381) := '_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL';
wwv_flow_imp.g_varchar2_table(382) := '_OPS,AIR_TAXI_OPS,GEOMETRY) values (1728,''BFL'',''AIRPORT'',''MEADOWS FIELD'',''BAKERSFIELD'',''CALIFORNIA'',';
wwv_flow_imp.g_varchar2_table(383) := '''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),510,3,1357,2575,12387,MDSYS.SD';
wwv_flow_imp.g_varchar2_table(384) := 'O_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-119.05767, 35.43386, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into E';
wwv_flow_imp.g_varchar2_table(385) := 'BA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIV';
wwv_flow_imp.g_varchar2_table(386) := 'ATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY)';
wwv_flow_imp.g_varchar2_table(387) := ' values (1766,''BUR'',''AIRPORT'',''BOB HOPE'',''BURBANK'',''CALIFORNIA'',''Dec-42'',to_timestamp(''01.12.1942 00';
wwv_flow_imp.g_varchar2_table(388) := ':00:00'',''DD.MM.RR HH24:MI:SSXFF''),778,3,555,59691,24925,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POI';
wwv_flow_imp.g_varchar2_table(389) := 'NT_TYPE(-118.35867, 34.20069, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE';
wwv_flow_imp.g_varchar2_table(390) := ',AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO';
wwv_flow_imp.g_varchar2_table(391) := '_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1789,''CRQ'',''AIRPORT'',''MC CL';
wwv_flow_imp.g_varchar2_table(392) := 'ELLAN-PALOMAR'',''CARLSBAD'',''CALIFORNIA'',''May-59'',to_timestamp(''01.05.1959 00:00:00'',''DD.MM.RR HH24:MI';
wwv_flow_imp.g_varchar2_table(393) := ':SSXFF''),331,3,466,273,6308,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-117.28008, 33.12825';
wwv_flow_imp.g_varchar2_table(394) := ', NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,C';
wwv_flow_imp.g_varchar2_table(395) := 'ITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,C';
wwv_flow_imp.g_varchar2_table(396) := 'OMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1806,''CIC'',''AIRPORT'',''CHICO MUNI'',''CHICO'',''CALIFORNIA'',';
wwv_flow_imp.g_varchar2_table(397) := '''Apr-87'',to_timestamp(''01.04.1987 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),240,4,1475,21,6719,MDSYS.SDO_G';
wwv_flow_imp.g_varchar2_table(398) := 'EOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-121.85842, 39.79539, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_';
wwv_flow_imp.g_varchar2_table(399) := 'SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATI';
wwv_flow_imp.g_varchar2_table(400) := 'ON_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) va';
wwv_flow_imp.g_varchar2_table(401) := 'lues (1838,''CCR'',''AIRPORT'',''BUCHANAN FIELD'',''CONCORD'',''CALIFORNIA'',''Jul-44'',to_timestamp(''01.07.1944';
wwv_flow_imp.g_varchar2_table(402) := ' 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),26,1,495,4,4982,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_';
wwv_flow_imp.g_varchar2_table(403) := 'TYPE(-122.0569, 37.98966, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIR';
wwv_flow_imp.g_varchar2_table(404) := 'PORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIR';
wwv_flow_imp.g_varchar2_table(405) := 'PORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1853,''CEC'',''AIRPORT'',''JACK MC N';
wwv_flow_imp.g_varchar2_table(406) := 'AMARA FIELD'',''CRESCENT CITY'',''CALIFORNIA'',''Aug-43'',to_timestamp(''01.08.1943 00:00:00'',''DD.MM.RR HH24';
wwv_flow_imp.g_varchar2_table(407) := ':MI:SSXFF''),61,3,544,0,3390,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-124.23653, 41.78017';
wwv_flow_imp.g_varchar2_table(408) := ', NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,C';
wwv_flow_imp.g_varchar2_table(409) := 'ITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,C';
wwv_flow_imp.g_varchar2_table(410) := 'OMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1895,''EMT'',''AIRPORT'',''SAN GABRIEL VALLEY'',''EL MONTE'',''C';
wwv_flow_imp.g_varchar2_table(411) := 'ALIFORNIA'',''Apr-44'',to_timestamp(''01.04.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),296,1,103,0,734,MDS';
wwv_flow_imp.g_varchar2_table(412) := 'YS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-118.03485, 34.08601, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert i';
wwv_flow_imp.g_varchar2_table(413) := 'nto EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,';
wwv_flow_imp.g_varchar2_table(414) := 'ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOM';
wwv_flow_imp.g_varchar2_table(415) := 'ETRY) values (1942,''FAT'',''AIRPORT'',''FRESNO YOSEMITE INTL'',''FRESNO'',''CALIFORNIA'',''Jun-42'',to_timestam';
wwv_flow_imp.g_varchar2_table(416) := 'p(''01.06.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),336,5,1728,21183,11917,MDSYS.SDO_GEOMETRY(2001, 43';
wwv_flow_imp.g_varchar2_table(417) := '26, MDSYS.SDO_POINT_TYPE(-119.71883, 36.77656, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPO';
wwv_flow_imp.g_varchar2_table(418) := 'RTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVA';
wwv_flow_imp.g_varchar2_table(419) := 'TION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1945,''FUL''';
wwv_flow_imp.g_varchar2_table(420) := ',''AIRPORT'',''FULLERTON MUNI'',''FULLERTON'',''CALIFORNIA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD';
wwv_flow_imp.g_varchar2_table(421) := '.MM.RR HH24:MI:SSXFF''),96,3,86,3,112,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-117.97978,';
wwv_flow_imp.g_varchar2_table(422) := ' 33.87201, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPO';
wwv_flow_imp.g_varchar2_table(423) := 'RT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_';
wwv_flow_imp.g_varchar2_table(424) := 'COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1985,''HWD'',''AIRPORT'',''HAYWARD EXECUTIVE'',''HAYW';
wwv_flow_imp.g_varchar2_table(425) := 'ARD'',''CALIFORNIA'',''May-47'',to_timestamp(''01.05.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),52,2,543,7,1';
wwv_flow_imp.g_varchar2_table(426) := '363,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-122.12174, 37.65893, NULL), NULL, NULL));'||wwv_flow.LF||
'I';
wwv_flow_imp.g_varchar2_table(427) := 'nsert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(428) := 'N_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_O';
wwv_flow_imp.g_varchar2_table(429) := 'PS,GEOMETRY) values (2010,''IPL'',''AIRPORT'',''IMPERIAL COUNTY'',''IMPERIAL'',''CALIFORNIA'',''Apr-40'',to_time';
wwv_flow_imp.g_varchar2_table(430) := 'stamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),-54,1,370,1220,null,MDSYS.SDO_GEOMETRY(2001, 4';
wwv_flow_imp.g_varchar2_table(431) := '326, MDSYS.SDO_POINT_TYPE(-115.57875, 32.83422, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRP';
wwv_flow_imp.g_varchar2_table(432) := 'ORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEV';
wwv_flow_imp.g_varchar2_table(433) := 'ATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2014,''IYK';
wwv_flow_imp.g_varchar2_table(434) := ''',''AIRPORT'',''INYOKERN'',''INYOKERN'',''CALIFORNIA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR';
wwv_flow_imp.g_varchar2_table(435) := ' HH24:MI:SSXFF''),2457,1,1640,1374,1650,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-117.8295';
wwv_flow_imp.g_varchar2_table(436) := '3, 35.65874, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIR';
wwv_flow_imp.g_varchar2_table(437) := 'PORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_ARE';
wwv_flow_imp.g_varchar2_table(438) := 'A_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2085,''LGB'',''AIRPORT'',''LONG BEACH /DAUGHERTY ';
wwv_flow_imp.g_varchar2_table(439) := 'FIELD/'',''LONG BEACH'',''CALIFORNIA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXF';
wwv_flow_imp.g_varchar2_table(440) := 'F''),60,3,1166,32314,8249,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-118.15189, 33.81793, N';
wwv_flow_imp.g_varchar2_table(441) := 'ULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY';
wwv_flow_imp.g_varchar2_table(442) := ',STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMM';
wwv_flow_imp.g_varchar2_table(443) := 'ERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2139,''LAX'',''AIRPORT'',''LOS ANGELES INTL'',''LOS ANGELES'',''CAL';
wwv_flow_imp.g_varchar2_table(444) := 'IFORNIA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),128,9,3500,634515,385';
wwv_flow_imp.g_varchar2_table(445) := '05,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-118.40805, 33.9425, NULL), NULL, NULL));'||wwv_flow.LF||
'Ins';
wwv_flow_imp.g_varchar2_table(446) := 'ert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_';
wwv_flow_imp.g_varchar2_table(447) := 'DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS';
wwv_flow_imp.g_varchar2_table(448) := ',GEOMETRY) values (2162,''MMH'',''AIRPORT'',''MAMMOTH YOSEMITE'',''MAMMOTH LAKES'',''CALIFORNIA'',''Sep-47'',to_';
wwv_flow_imp.g_varchar2_table(449) := 'timestamp(''01.09.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),7135,6,230,1050,2134,MDSYS.SDO_GEOMETRY(20';
wwv_flow_imp.g_varchar2_table(450) := '01, 4326, MDSYS.SDO_POINT_TYPE(-118.83875, 37.62406, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP';
wwv_flow_imp.g_varchar2_table(451) := '_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT';
wwv_flow_imp.g_varchar2_table(452) := ',ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2178';
wwv_flow_imp.g_varchar2_table(453) := ',''MCE'',''AIRPORT'',''MERCED RGNL/MACREADY FIELD'',''MERCED'',''CALIFORNIA'',''Apr-28'',to_timestamp(''01.04.192';
wwv_flow_imp.g_varchar2_table(454) := '8 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),155,2,766,3500,300,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_PO';
wwv_flow_imp.g_varchar2_table(455) := 'INT_TYPE(-120.51392, 37.28475, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_COD';
wwv_flow_imp.g_varchar2_table(456) := 'E,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_T';
wwv_flow_imp.g_varchar2_table(457) := 'O_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2181,''MER'',''AIRPORT'',''CAST';
wwv_flow_imp.g_varchar2_table(458) := 'LE'',''ATWATER'',''CALIFORNIA'',''Jul-42'',to_timestamp(''01.07.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),190';
wwv_flow_imp.g_varchar2_table(459) := ',3,1360,0,51,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-120.56819, 37.38048, NULL), NULL, ';
wwv_flow_imp.g_varchar2_table(460) := 'NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,';
wwv_flow_imp.g_varchar2_table(461) := 'ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,A';
wwv_flow_imp.g_varchar2_table(462) := 'IR_TAXI_OPS,GEOMETRY) values (2188,''MHV'',''AIRPORT'',''MOJAVE AIR AND SPACE PORT'',''MOJAVE'',''CALIFORNIA''';
wwv_flow_imp.g_varchar2_table(463) := ',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2801,1,2998,33,6,MDSYS.SDO_GE';
wwv_flow_imp.g_varchar2_table(464) := 'OMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-118.15061, 35.05894, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_S';
wwv_flow_imp.g_varchar2_table(465) := 'AMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(466) := 'N_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) val';
wwv_flow_imp.g_varchar2_table(467) := 'ues (2193,''MRY'',''AIRPORT'',''MONTEREY RGNL'',''MONTEREY'',''CALIFORNIA'',''Apr-40'',to_timestamp(''01.04.1940 ';
wwv_flow_imp.g_varchar2_table(468) := '00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),257,3,496,4686,12903,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_PO';
wwv_flow_imp.g_varchar2_table(469) := 'INT_TYPE(-121.84278, 36.58695, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_COD';
wwv_flow_imp.g_varchar2_table(470) := 'E,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_T';
wwv_flow_imp.g_varchar2_table(471) := 'O_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2202,''APC'',''AIRPORT'',''NAPA';
wwv_flow_imp.g_varchar2_table(472) := ' COUNTY'',''NAPA'',''CALIFORNIA'',''Oct-44'',to_timestamp(''01.10.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),3';
wwv_flow_imp.g_varchar2_table(473) := '6,5,820,3,5503,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-122.28069, 38.21319, NULL), NULL';
wwv_flow_imp.g_varchar2_table(474) := ', NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAM';
wwv_flow_imp.g_varchar2_table(475) := 'E,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS';
wwv_flow_imp.g_varchar2_table(476) := ',AIR_TAXI_OPS,GEOMETRY) values (2215,''OAK'',''AIRPORT'',''METROPOLITAN OAKLAND INTL'',''OAKLAND'',''CALIFORN';
wwv_flow_imp.g_varchar2_table(477) := 'IA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),9,4,2600,132865,24112,MDSY';
wwv_flow_imp.g_varchar2_table(478) := 'S.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-122.22114, 37.72125, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert in';
wwv_flow_imp.g_varchar2_table(479) := 'to EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,A';
wwv_flow_imp.g_varchar2_table(480) := 'CTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOME';
wwv_flow_imp.g_varchar2_table(481) := 'TRY) values (2225,''ONT'',''AIRPORT'',''ONTARIO INTL'',''ONTARIO'',''CALIFORNIA'',''Apr-40'',to_timestamp(''01.04';
wwv_flow_imp.g_varchar2_table(482) := '.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),944,2,1741,70247,13396,MDSYS.SDO_GEOMETRY(2001, 4326, MDSY';
wwv_flow_imp.g_varchar2_table(483) := 'S.SDO_POINT_TYPE(-117.60119, 34.056, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IA';
wwv_flow_imp.g_varchar2_table(484) := 'TA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_';
wwv_flow_imp.g_varchar2_table(485) := 'CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2234,''OXR'',''AIRPORT''';
wwv_flow_imp.g_varchar2_table(486) := ',''OXNARD'',''OXNARD'',''CALIFORNIA'',''Apr-42'',to_timestamp(''01.04.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''';
wwv_flow_imp.g_varchar2_table(487) := '),45,1,230,0,4898,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-119.20723, 34.20081, NULL), N';
wwv_flow_imp.g_varchar2_table(488) := 'ULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_';
wwv_flow_imp.g_varchar2_table(489) := 'NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_';
wwv_flow_imp.g_varchar2_table(490) := 'OPS,AIR_TAXI_OPS,GEOMETRY) values (2240,''PMD'',''AIRPORT'',''PALMDALE USAF PLANT 42'',''PALMDALE'',''CALIFOR';
wwv_flow_imp.g_varchar2_table(491) := 'NIA'',null,null,2543,3,5832,1203,1320,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-118.08455,';
wwv_flow_imp.g_varchar2_table(492) := ' 34.62939, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPO';
wwv_flow_imp.g_varchar2_table(493) := 'RT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_';
wwv_flow_imp.g_varchar2_table(494) := 'COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2242,''PSP'',''AIRPORT'',''PALM SPRINGS INTL'',''PALM';
wwv_flow_imp.g_varchar2_table(495) := ' SPRINGS'',''CALIFORNIA'',''Jul-42'',to_timestamp(''01.07.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),476,2,9';
wwv_flow_imp.g_varchar2_table(496) := '40,21226,10872,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-116.50669, 33.82967, NULL), NULL';
wwv_flow_imp.g_varchar2_table(497) := ', NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAM';
wwv_flow_imp.g_varchar2_table(498) := 'E,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS';
wwv_flow_imp.g_varchar2_table(499) := ',AIR_TAXI_OPS,GEOMETRY) values (2285,''RNM'',''AIRPORT'',''RAMONA'',''RAMONA'',''CALIFORNIA'',''Jun-47'',to_time';
wwv_flow_imp.g_varchar2_table(500) := 'stamp(''01.06.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1395,2,342,0,128,MDSYS.SDO_GEOMETRY(2001, 4326';
wwv_flow_imp.g_varchar2_table(501) := ', MDSYS.SDO_POINT_TYPE(-116.91525, 33.03917, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORT';
wwv_flow_imp.g_varchar2_table(502) := 'S (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATI';
wwv_flow_imp.g_varchar2_table(503) := 'ON,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2300,''RDD'',''';
wwv_flow_imp.g_varchar2_table(504) := 'AIRPORT'',''REDDING MUNI'',''REDDING'',''CALIFORNIA'',''Jul-44'',to_timestamp(''01.07.1944 00:00:00'',''DD.MM.RR';
wwv_flow_imp.g_varchar2_table(505) := ' HH24:MI:SSXFF''),505,6,1584,2320,25652,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-122.2933';
wwv_flow_imp.g_varchar2_table(506) := '9, 40.50897, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIR';
wwv_flow_imp.g_varchar2_table(507) := 'PORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_ARE';
wwv_flow_imp.g_varchar2_table(508) := 'A_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2331,''SMF'',''AIRPORT'',''SACRAMENTO INTL'',''SACR';
wwv_flow_imp.g_varchar2_table(509) := 'AMENTO'',''CALIFORNIA'',''Jun-62'',to_timestamp(''01.06.1962 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),27,10,600';
wwv_flow_imp.g_varchar2_table(510) := '0,98811,10711,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-121.59078, 38.69544, NULL), NULL,';
wwv_flow_imp.g_varchar2_table(511) := ' NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME';
wwv_flow_imp.g_varchar2_table(512) := ',ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,';
wwv_flow_imp.g_varchar2_table(513) := 'AIR_TAXI_OPS,GEOMETRY) values (2334,''MHR'',''AIRPORT'',''SACRAMENTO MATHER'',''SACRAMENTO'',''CALIFORNIA'',''J';
wwv_flow_imp.g_varchar2_table(514) := 'ul-42'',to_timestamp(''01.07.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),98,10,2875,4781,12493,MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(515) := 'GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-121.29721, 38.55531, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA';
wwv_flow_imp.g_varchar2_table(516) := '_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVAT';
wwv_flow_imp.g_varchar2_table(517) := 'ION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) v';
wwv_flow_imp.g_varchar2_table(518) := 'alues (2335,''SAC'',''AIRPORT'',''SACRAMENTO EXECUTIVE'',''SACRAMENTO'',''CALIFORNIA'',''Apr-40'',to_timestamp(''';
wwv_flow_imp.g_varchar2_table(519) := '01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),24,3,540,0,2202,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.';
wwv_flow_imp.g_varchar2_table(520) := 'SDO_POINT_TYPE(-121.4933, 38.51286, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IAT';
wwv_flow_imp.g_varchar2_table(521) := 'A_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_C';
wwv_flow_imp.g_varchar2_table(522) := 'ITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2349,''SBD'',''AIRPORT'',';
wwv_flow_imp.g_varchar2_table(523) := '''SAN BERNARDINO INTL'',''SAN BERNARDINO'',''CALIFORNIA'',''Jul-40'',to_timestamp(''01.07.1940 00:00:00'',''DD.';
wwv_flow_imp.g_varchar2_table(524) := 'MM.RR HH24:MI:SSXFF''),1159,2,1329,2795,4624,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-117';
wwv_flow_imp.g_varchar2_table(525) := '.23489, 34.09536, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYP';
wwv_flow_imp.g_varchar2_table(526) := 'E,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAN';
wwv_flow_imp.g_varchar2_table(527) := 'D_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2354,''SEE'',''AIRPORT'',''GILLESPIE FIELD'',';
wwv_flow_imp.g_varchar2_table(528) := '''SAN DIEGO/EL CAJON'',''CALIFORNIA'',''Dec-42'',to_timestamp(''01.12.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXF';
wwv_flow_imp.g_varchar2_table(529) := 'F''),388,10,758,0,390,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-116.97244, 32.82622, NULL)';
wwv_flow_imp.g_varchar2_table(530) := ', NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STA';
wwv_flow_imp.g_varchar2_table(531) := 'TE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCI';
wwv_flow_imp.g_varchar2_table(532) := 'AL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2358,''MYF'',''AIRPORT'',''MONTGOMERY-GIBBS EXECUTIVE'',''SAN DIEGO'',';
wwv_flow_imp.g_varchar2_table(533) := '''CALIFORNIA'',''Jul-40'',to_timestamp(''01.07.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),427,6,549,15,3378';
wwv_flow_imp.g_varchar2_table(534) := ',MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-117.13956, 32.81572, NULL), NULL, NULL));'||wwv_flow.LF||
'Inse';
wwv_flow_imp.g_varchar2_table(535) := 'rt into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(536) := 'ATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,';
wwv_flow_imp.g_varchar2_table(537) := 'GEOMETRY) values (2364,''SAN'',''AIRPORT'',''SAN DIEGO INTL'',''SAN DIEGO'',''CALIFORNIA'',''Apr-40'',to_timesta';
wwv_flow_imp.g_varchar2_table(538) := 'mp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),17,2,663,203913,12720,MDSYS.SDO_GEOMETRY(2001, 43';
wwv_flow_imp.g_varchar2_table(539) := '26, MDSYS.SDO_POINT_TYPE(-117.18967, 32.73356, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPO';
wwv_flow_imp.g_varchar2_table(540) := 'RTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVA';
wwv_flow_imp.g_varchar2_table(541) := 'TION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2376,''SFO''';
wwv_flow_imp.g_varchar2_table(542) := ',''AIRPORT'',''SAN FRANCISCO INTL'',''SAN FRANCISCO'',''CALIFORNIA'',''Apr-40'',to_timestamp(''01.04.1940 00:00';
wwv_flow_imp.g_varchar2_table(543) := ':00'',''DD.MM.RR HH24:MI:SSXFF''),13,8,5207,407153,48646,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT';
wwv_flow_imp.g_varchar2_table(544) := '_TYPE(-122.37542, 37.61881, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,A';
wwv_flow_imp.g_varchar2_table(545) := 'IRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_A';
wwv_flow_imp.g_varchar2_table(546) := 'IRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2384,''SJC'',''AIRPORT'',''NORMAN ';
wwv_flow_imp.g_varchar2_table(547) := 'Y MINETA SAN JOSE INTL'',''SAN JOSE'',''CALIFORNIA'',''Feb-46'',to_timestamp(''01.02.1946 00:00:00'',''DD.MM.R';
wwv_flow_imp.g_varchar2_table(548) := 'R HH24:MI:SSXFF''),62,2,1050,138613,22668,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-121.92';
wwv_flow_imp.g_varchar2_table(549) := '862, 37.36299, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,A';
wwv_flow_imp.g_varchar2_table(550) := 'IRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_A';
wwv_flow_imp.g_varchar2_table(551) := 'REA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2385,''SBP'',''AIRPORT'',''SAN LUIS COUNTY RGNL';
wwv_flow_imp.g_varchar2_table(552) := ''',''SAN LUIS OBISPO'',''CALIFORNIA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF';
wwv_flow_imp.g_varchar2_table(553) := '''),212,3,340,5313,7907,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-120.64261, 35.23728, NUL';
wwv_flow_imp.g_varchar2_table(554) := 'L), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,S';
wwv_flow_imp.g_varchar2_table(555) := 'TATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMER';
wwv_flow_imp.g_varchar2_table(556) := 'CIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2398,''SNA'',''AIRPORT'',''JOHN WAYNE AIRPORT-ORANGE COUNTY'',''SAN';
wwv_flow_imp.g_varchar2_table(557) := 'TA ANA'',''CALIFORNIA'',''Nov-41'',to_timestamp(''01.11.1941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),56,4,504,';
wwv_flow_imp.g_varchar2_table(558) := '95434,21466,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-117.86822, 33.67567, NULL), NULL, N';
wwv_flow_imp.g_varchar2_table(559) := 'ULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,A';
wwv_flow_imp.g_varchar2_table(560) := 'CTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AI';
wwv_flow_imp.g_varchar2_table(561) := 'R_TAXI_OPS,GEOMETRY) values (2399,''SBA'',''AIRPORT'',''SANTA BARBARA MUNI'',''SANTA BARBARA'',''CALIFORNIA'',';
wwv_flow_imp.g_varchar2_table(562) := '''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),13,7,948,7243,17421,MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(563) := 'GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-119.84149, 34.42619, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA';
wwv_flow_imp.g_varchar2_table(564) := '_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVAT';
wwv_flow_imp.g_varchar2_table(565) := 'ION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) v';
wwv_flow_imp.g_varchar2_table(566) := 'alues (2410,''SMX'',''AIRPORT'',''SANTA MARIA PUB/CAPT G ALLAN HANCOCK FLD'',''SANTA MARIA'',''CALIFORNIA'',''J';
wwv_flow_imp.g_varchar2_table(567) := 'un-47'',to_timestamp(''01.06.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),261,3,2516,424,6132,MDSYS.SDO_GE';
wwv_flow_imp.g_varchar2_table(568) := 'OMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-120.45808, 34.89994, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_S';
wwv_flow_imp.g_varchar2_table(569) := 'AMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(570) := 'N_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) val';
wwv_flow_imp.g_varchar2_table(571) := 'ues (2415,''STS'',''AIRPORT'',''CHARLES M SCHULZ - SONOMA COUNTY'',''SANTA ROSA'',''CALIFORNIA'',null,null,129';
wwv_flow_imp.g_varchar2_table(572) := ',6,1125,7052,8456,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-122.81289, 38.50969, NULL), N';
wwv_flow_imp.g_varchar2_table(573) := 'ULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_';
wwv_flow_imp.g_varchar2_table(574) := 'NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_';
wwv_flow_imp.g_varchar2_table(575) := 'OPS,AIR_TAXI_OPS,GEOMETRY) values (2446,''TVL'',''AIRPORT'',''LAKE TAHOE'',''SOUTH LAKE TAHOE'',''CALIFORNIA''';
wwv_flow_imp.g_varchar2_table(576) := ',null,null,6268,3,348,0,1100,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-119.99533, 38.8938';
wwv_flow_imp.g_varchar2_table(577) := '9, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,';
wwv_flow_imp.g_varchar2_table(578) := 'CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,';
wwv_flow_imp.g_varchar2_table(579) := 'COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2449,''SCK'',''AIRPORT'',''STOCKTON METROPOLITAN'',''STOCKTON';
wwv_flow_imp.g_varchar2_table(580) := ''',''CALIFORNIA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),33,3,1552,2677,';
wwv_flow_imp.g_varchar2_table(581) := '1642,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-121.23874, 37.89441, NULL), NULL, NULL));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(582) := 'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATI';
wwv_flow_imp.g_varchar2_table(583) := 'ON_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_';
wwv_flow_imp.g_varchar2_table(584) := 'OPS,GEOMETRY) values (2482,''TOA'',''AIRPORT'',''ZAMPERINI FIELD'',''TORRANCE'',''CALIFORNIA'',null,null,103,3';
wwv_flow_imp.g_varchar2_table(585) := ',506,28,348,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-118.33961, 33.80338, NULL), NULL, N';
wwv_flow_imp.g_varchar2_table(586) := 'ULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,A';
wwv_flow_imp.g_varchar2_table(587) := 'CTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AI';
wwv_flow_imp.g_varchar2_table(588) := 'R_TAXI_OPS,GEOMETRY) values (2515,''VNY'',''AIRPORT'',''VAN NUYS'',''VAN NUYS'',''CALIFORNIA'',''Jul-42'',to_tim';
wwv_flow_imp.g_varchar2_table(589) := 'estamp(''01.07.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),802,3,725,96,27523,MDSYS.SDO_GEOMETRY(2001, 4';
wwv_flow_imp.g_varchar2_table(590) := '326, MDSYS.SDO_POINT_TYPE(-118.48997, 34.20981, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRP';
wwv_flow_imp.g_varchar2_table(591) := 'ORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEV';
wwv_flow_imp.g_varchar2_table(592) := 'ATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2519,''VCV';
wwv_flow_imp.g_varchar2_table(593) := ''',''AIRPORT'',''SOUTHERN CALIFORNIA LOGISTICS'',''VICTORVILLE'',''CALIFORNIA'',''Sep-43'',to_timestamp(''01.09.';
wwv_flow_imp.g_varchar2_table(594) := '1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2885,5,2300,307,1983,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.S';
wwv_flow_imp.g_varchar2_table(595) := 'DO_POINT_TYPE(-117.383, 34.59747, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_';
wwv_flow_imp.g_varchar2_table(596) := 'CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CIT';
wwv_flow_imp.g_varchar2_table(597) := 'Y_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2525,''VIS'',''AIRPORT'',''V';
wwv_flow_imp.g_varchar2_table(598) := 'ISALIA MUNI'',''VISALIA'',''CALIFORNIA'',null,null,295,4,821,2200,11000,MDSYS.SDO_GEOMETRY(2001, 4326, MD';
wwv_flow_imp.g_varchar2_table(599) := 'SYS.SDO_POINT_TYPE(-119.39286, 36.31864, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (I';
wwv_flow_imp.g_varchar2_table(600) := 'D,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,D';
wwv_flow_imp.g_varchar2_table(601) := 'IST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2569,''AKO'',''AIRP';
wwv_flow_imp.g_varchar2_table(602) := 'ORT'',''COLORADO PLAINS RGNL'',''AKRON'',''COLORADO'',''Oct-46'',to_timestamp(''01.10.1946 00:00:00'',''DD.MM.RR';
wwv_flow_imp.g_varchar2_table(603) := ' HH24:MI:SSXFF''),4716,1,639,0,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-103.22203, 40.1';
wwv_flow_imp.g_varchar2_table(604) := '7564, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NA';
wwv_flow_imp.g_varchar2_table(605) := 'ME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVER';
wwv_flow_imp.g_varchar2_table(606) := 'ED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2570,''ALS'',''AIRPORT'',''SAN LUIS VALLEY RGNL/BERGMAN ';
wwv_flow_imp.g_varchar2_table(607) := 'FIELD'',''ALAMOSA'',''COLORADO'',''Mar-41'',to_timestamp(''01.03.1941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),75';
wwv_flow_imp.g_varchar2_table(608) := '40,2,1700,0,2535,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-105.86788, 37.43512, NULL), NU';
wwv_flow_imp.g_varchar2_table(609) := 'LL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_N';
wwv_flow_imp.g_varchar2_table(610) := 'AME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_O';
wwv_flow_imp.g_varchar2_table(611) := 'PS,AIR_TAXI_OPS,GEOMETRY) values (2574,''ASE'',''AIRPORT'',''ASPEN-PITKIN CO/SARDY FIELD'',''ASPEN'',''COLORA';
wwv_flow_imp.g_varchar2_table(612) := 'DO'',''Mar-49'',to_timestamp(''01.03.1949 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),7838,3,573,11202,10615,MDS';
wwv_flow_imp.g_varchar2_table(613) := 'YS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-106.86822, 39.22189, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert i';
wwv_flow_imp.g_varchar2_table(614) := 'nto EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,';
wwv_flow_imp.g_varchar2_table(615) := 'ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOM';
wwv_flow_imp.g_varchar2_table(616) := 'ETRY) values (2653,''COS'',''AIRPORT'',''CITY OF COLORADO SPRINGS MUNI'',''COLORADO SPRINGS'',''COLORADO'',''Ap';
wwv_flow_imp.g_varchar2_table(617) := 'r-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),6187,6,7200,13740,15554,MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(618) := '_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-104.70077, 38.80581, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EB';
wwv_flow_imp.g_varchar2_table(619) := 'A_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVA';
wwv_flow_imp.g_varchar2_table(620) := 'TION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) ';
wwv_flow_imp.g_varchar2_table(621) := 'values (2657,''CEZ'',''AIRPORT'',''CORTEZ MUNI'',''CORTEZ'',''COLORADO'',''Jul-49'',to_timestamp(''01.07.1949 00:';
wwv_flow_imp.g_varchar2_table(622) := '00:00'',''DD.MM.RR HH24:MI:SSXFF''),5918,3,622,0,1304,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TY';
wwv_flow_imp.g_varchar2_table(623) := 'PE(-108.62806, 37.303, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPOR';
wwv_flow_imp.g_varchar2_table(624) := 'T_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPOR';
wwv_flow_imp.g_varchar2_table(625) := 'T,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2694,''BJC'',''AIRPORT'',''ROCKY MOUNTA';
wwv_flow_imp.g_varchar2_table(626) := 'IN METROPOLITAN'',''DENVER'',''COLORADO'',''Oct-60'',to_timestamp(''01.10.1960 00:00:00'',''DD.MM.RR HH24:MI:S';
wwv_flow_imp.g_varchar2_table(627) := 'SXFF''),5673,9,1700,96,6749,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-105.11719, 39.90881,';
wwv_flow_imp.g_varchar2_table(628) := ' NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CI';
wwv_flow_imp.g_varchar2_table(629) := 'TY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,CO';
wwv_flow_imp.g_varchar2_table(630) := 'MMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2695,''APA'',''AIRPORT'',''CENTENNIAL'',''DENVER'',''COLORADO'',''M';
wwv_flow_imp.g_varchar2_table(631) := 'ar-68'',to_timestamp(''01.03.1968 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),5885,15,1400,0,32130,MDSYS.SDO_G';
wwv_flow_imp.g_varchar2_table(632) := 'EOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-104.84929, 39.57012, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_';
wwv_flow_imp.g_varchar2_table(633) := 'SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATI';
wwv_flow_imp.g_varchar2_table(634) := 'ON_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) va';
wwv_flow_imp.g_varchar2_table(635) := 'lues (2696,''DEN'',''AIRPORT'',''DENVER INTL'',''DENVER'',''COLORADO'',''Aug-93'',to_timestamp(''01.08.1993 00:00';
wwv_flow_imp.g_varchar2_table(636) := ':00'',''DD.MM.RR HH24:MI:SSXFF''),5434,16,33531,462276,137027,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(637) := 'POINT_TYPE(-104.67317, 39.86167, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_C';
wwv_flow_imp.g_varchar2_table(638) := 'ODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY';
wwv_flow_imp.g_varchar2_table(639) := '_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2701,''DRO'',''AIRPORT'',''DU';
wwv_flow_imp.g_varchar2_table(640) := 'RANGO-LA PLATA COUNTY'',''DURANGO'',''COLORADO'',''Nov-46'',to_timestamp(''01.11.1946 00:00:00'',''DD.MM.RR HH';
wwv_flow_imp.g_varchar2_table(641) := '24:MI:SSXFF''),6689,10,1281,5768,5128,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-107.75378,';
wwv_flow_imp.g_varchar2_table(642) := ' 37.15153, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPO';
wwv_flow_imp.g_varchar2_table(643) := 'RT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_';
wwv_flow_imp.g_varchar2_table(644) := 'COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2708,''EGE'',''AIRPORT'',''EAGLE COUNTY RGNL'',''EAGL';
wwv_flow_imp.g_varchar2_table(645) := 'E'',''COLORADO'',''Jul-40'',to_timestamp(''01.07.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),6547,4,632,4379,';
wwv_flow_imp.g_varchar2_table(646) := '8143,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-106.91594, 39.64275, NULL), NULL, NULL));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(647) := 'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATI';
wwv_flow_imp.g_varchar2_table(648) := 'ON_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_';
wwv_flow_imp.g_varchar2_table(649) := 'OPS,GEOMETRY) values (2747,''FNL'',''AIRPORT'',''NORTHERN COLORADO RGNL'',''FORT COLLINS/LOVELAND'',''COLORAD';
wwv_flow_imp.g_varchar2_table(650) := 'O'',null,null,5016,9,1065,46,3500,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-105.01134, 40.';
wwv_flow_imp.g_varchar2_table(651) := '45183, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_N';
wwv_flow_imp.g_varchar2_table(652) := 'AME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVE';
wwv_flow_imp.g_varchar2_table(653) := 'RED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2773,''GJT'',''AIRPORT'',''GRAND JUNCTION REGIONAL'',''GR';
wwv_flow_imp.g_varchar2_table(654) := 'AND JUNCTION'',''COLORADO'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4861,';
wwv_flow_imp.g_varchar2_table(655) := '3,2357,4937,9329,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-108.52675, 39.12242, NULL), NU';
wwv_flow_imp.g_varchar2_table(656) := 'LL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_N';
wwv_flow_imp.g_varchar2_table(657) := 'AME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_O';
wwv_flow_imp.g_varchar2_table(658) := 'PS,AIR_TAXI_OPS,GEOMETRY) values (2786,''GUC'',''AIRPORT'',''GUNNISON-CRESTED BUTTE RGNL'',''GUNNISON'',''COL';
wwv_flow_imp.g_varchar2_table(659) := 'ORADO'',''Aug-47'',to_timestamp(''01.08.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),7680,1,1600,566,763,MDS';
wwv_flow_imp.g_varchar2_table(660) := 'YS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-106.93175, 38.53433, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert i';
wwv_flow_imp.g_varchar2_table(661) := 'nto EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,';
wwv_flow_imp.g_varchar2_table(662) := 'ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOM';
wwv_flow_imp.g_varchar2_table(663) := 'ETRY) values (2791,''HDN'',''AIRPORT'',''YAMPA VALLEY'',''HAYDEN'',''COLORADO'',null,null,6606,2,671,2100,3955';
wwv_flow_imp.g_varchar2_table(664) := ',MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-107.21767, 40.48119, NULL), NULL, NULL));'||wwv_flow.LF||
'Inse';
wwv_flow_imp.g_varchar2_table(665) := 'rt into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(666) := 'ATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,';
wwv_flow_imp.g_varchar2_table(667) := 'GEOMETRY) values (2871,''MTJ'',''AIRPORT'',''MONTROSE RGNL'',''MONTROSE'',''COLORADO'',''Sep-46'',to_timestamp(''';
wwv_flow_imp.g_varchar2_table(668) := '01.09.1946 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),5759,1,966,6850,200,MDSYS.SDO_GEOMETRY(2001, 4326, MD';
wwv_flow_imp.g_varchar2_table(669) := 'SYS.SDO_POINT_TYPE(-107.89425, 38.50981, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (I';
wwv_flow_imp.g_varchar2_table(670) := 'D,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,D';
wwv_flow_imp.g_varchar2_table(671) := 'IST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2923,''PUB'',''AIRP';
wwv_flow_imp.g_varchar2_table(672) := 'ORT'',''PUEBLO MEMORIAL'',''PUEBLO'',''COLORADO'',''Feb-44'',to_timestamp(''01.02.1944 00:00:00'',''DD.MM.RR HH2';
wwv_flow_imp.g_varchar2_table(673) := '4:MI:SSXFF''),4729,5,3872,170,4133,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-104.49803, 38';
wwv_flow_imp.g_varchar2_table(674) := '.28995, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(675) := 'NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COV';
wwv_flow_imp.g_varchar2_table(676) := 'ERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (2932,''RIL'',''AIRPORT'',''RIFLE GARFIELD COUNTY'',''RIF';
wwv_flow_imp.g_varchar2_table(677) := 'LE'',''COLORADO'',''Jul-40'',to_timestamp(''01.07.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),5537,3,517,0,23';
wwv_flow_imp.g_varchar2_table(678) := '00,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-107.728, 39.52661, NULL), NULL, NULL));'||wwv_flow.LF||
'Inse';
wwv_flow_imp.g_varchar2_table(679) := 'rt into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(680) := 'ATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,';
wwv_flow_imp.g_varchar2_table(681) := 'GEOMETRY) values (2972,''TEX'',''AIRPORT'',''TELLURIDE RGNL'',''TELLURIDE'',''COLORADO'',''Mar-86'',to_timestamp';
wwv_flow_imp.g_varchar2_table(682) := '(''01.03.1986 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),9070,5,542,32,null,MDSYS.SDO_GEOMETRY(2001, 4326, M';
wwv_flow_imp.g_varchar2_table(683) := 'DSYS.SDO_POINT_TYPE(-107.90875, 37.95381, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (';
wwv_flow_imp.g_varchar2_table(684) := 'ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,';
wwv_flow_imp.g_varchar2_table(685) := 'DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3019,''GSN'',''AIR';
wwv_flow_imp.g_varchar2_table(686) := 'PORT'',''FRANCISCO C ADA/SAIPAN INTL'',''SAIPAN ISLAND'',''N MARIANA ISLANDS'',null,null,215,4,734,5277,281';
wwv_flow_imp.g_varchar2_table(687) := '87,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(145.72998, 15.12026, NULL), NULL, NULL));'||wwv_flow.LF||
'Ins';
wwv_flow_imp.g_varchar2_table(688) := 'ert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_';
wwv_flow_imp.g_varchar2_table(689) := 'DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS';
wwv_flow_imp.g_varchar2_table(690) := ',GEOMETRY) values (3021,''GRO'',''AIRPORT'',''BENJAMIN TAISACAN MANGLONA INTL'',''ROTA ISLAND'',''N MARIANA I';
wwv_flow_imp.g_varchar2_table(691) := 'SLANDS'',''Jun-64'',to_timestamp(''01.06.1964 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),607,6,800,0,826,MDSYS.';
wwv_flow_imp.g_varchar2_table(692) := 'SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(145.24113, 14.17436, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into ';
wwv_flow_imp.g_varchar2_table(693) := 'EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTI';
wwv_flow_imp.g_varchar2_table(694) := 'VATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY';
wwv_flow_imp.g_varchar2_table(695) := ') values (3026,''TNI'',''AIRPORT'',''TINIAN INTL'',''TINIAN ISLAND'',''N MARIANA ISLANDS'',''May-73'',to_timesta';
wwv_flow_imp.g_varchar2_table(696) := 'mp(''01.05.1973 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),270,1,1416,0,21610,MDSYS.SDO_GEOMETRY(2001, 4326,';
wwv_flow_imp.g_varchar2_table(697) := ' MDSYS.SDO_POINT_TYPE(145.61935, 14.99923, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS ';
wwv_flow_imp.g_varchar2_table(698) := '(ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION';
wwv_flow_imp.g_varchar2_table(699) := ',DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3035,''BDR'',''AI';
wwv_flow_imp.g_varchar2_table(700) := 'RPORT'',''IGOR I SIKORSKY MEMORIAL'',''BRIDGEPORT'',''CONNECTICUT'',''Apr-40'',to_timestamp(''01.04.1940 00:00';
wwv_flow_imp.g_varchar2_table(701) := ':00'',''DD.MM.RR HH24:MI:SSXFF''),9,3,800,0,3094,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-7';
wwv_flow_imp.g_varchar2_table(702) := '3.12617, 41.16347, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TY';
wwv_flow_imp.g_varchar2_table(703) := 'PE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LA';
wwv_flow_imp.g_varchar2_table(704) := 'ND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3073,''GON'',''AIRPORT'',''GROTON-NEW LONDO';
wwv_flow_imp.g_varchar2_table(705) := 'N'',''GROTON (NEW LONDON)'',''CONNECTICUT'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI';
wwv_flow_imp.g_varchar2_table(706) := ':SSXFF''),9,3,489,1,1107,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-72.04514, 41.33006, NUL';
wwv_flow_imp.g_varchar2_table(707) := 'L), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,S';
wwv_flow_imp.g_varchar2_table(708) := 'TATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMER';
wwv_flow_imp.g_varchar2_table(709) := 'CIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3101,''HVN'',''AIRPORT'',''TWEED-NEW HAVEN'',''NEW HAVEN'',''CONNECTI';
wwv_flow_imp.g_varchar2_table(710) := 'CUT'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),13,3,394,1906,5907,MDSYS.';
wwv_flow_imp.g_varchar2_table(711) := 'SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-72.8868, 41.26375, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into E';
wwv_flow_imp.g_varchar2_table(712) := 'BA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIV';
wwv_flow_imp.g_varchar2_table(713) := 'ATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY)';
wwv_flow_imp.g_varchar2_table(714) := ' values (3146,''BDL'',''AIRPORT'',''BRADLEY INTL'',''WINDSOR LOCKS'',''CONNECTICUT'',''Jul-42'',to_timestamp(''01';
wwv_flow_imp.g_varchar2_table(715) := '.07.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),173,3,2432,57046,19269,MDSYS.SDO_GEOMETRY(2001, 4326, M';
wwv_flow_imp.g_varchar2_table(716) := 'DSYS.SDO_POINT_TYPE(-72.68336, 41.93914, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (I';
wwv_flow_imp.g_varchar2_table(717) := 'D,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,D';
wwv_flow_imp.g_varchar2_table(718) := 'IST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3150,''DCA'',''AIRP';
wwv_flow_imp.g_varchar2_table(719) := 'ORT'',''RONALD REAGAN WASHINGTON NATIONAL'',''WASHINGTON'',''DIST. OF COLUMBIA'',''Mar-41'',to_timestamp(''01.';
wwv_flow_imp.g_varchar2_table(720) := '03.1941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),14,3,861,239759,52704,MDSYS.SDO_GEOMETRY(2001, 4326, MDS';
wwv_flow_imp.g_varchar2_table(721) := 'YS.SDO_POINT_TYPE(-77.03772, 38.85144, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,';
wwv_flow_imp.g_varchar2_table(722) := 'IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIS';
wwv_flow_imp.g_varchar2_table(723) := 'T_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3157,''IAD'',''AIRPOR';
wwv_flow_imp.g_varchar2_table(724) := 'T'',''WASHINGTON DULLES INTL'',''WASHINGTON'',''DIST. OF COLUMBIA'',''Nov-62'',to_timestamp(''01.11.1962 00:00';
wwv_flow_imp.g_varchar2_table(725) := ':00'',''DD.MM.RR HH24:MI:SSXFF''),313,20,13000,183677,90741,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_PO';
wwv_flow_imp.g_varchar2_table(726) := 'INT_TYPE(-77.45994, 38.94744, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE';
wwv_flow_imp.g_varchar2_table(727) := ',AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO';
wwv_flow_imp.g_varchar2_table(728) := '_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3201,''ILG'',''AIRPORT'',''NEW C';
wwv_flow_imp.g_varchar2_table(729) := 'ASTLE'',''WILMINGTON'',''DELAWARE'',''May-43'',to_timestamp(''01.05.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF'')';
wwv_flow_imp.g_varchar2_table(730) := ',80,4,1250,14,3573,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-75.60664, 39.67872, NULL), N';
wwv_flow_imp.g_varchar2_table(731) := 'ULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_';
wwv_flow_imp.g_varchar2_table(732) := 'NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_';
wwv_flow_imp.g_varchar2_table(733) := 'OPS,AIR_TAXI_OPS,GEOMETRY) values (3365,''DAB'',''AIRPORT'',''DAYTONA BEACH INTL'',''DAYTONA BEACH'',''FLORID';
wwv_flow_imp.g_varchar2_table(734) := 'A'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),34,3,1800,7203,149696,MDSYS';
wwv_flow_imp.g_varchar2_table(735) := '.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.05806, 29.17992, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into';
wwv_flow_imp.g_varchar2_table(736) := ' EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACT';
wwv_flow_imp.g_varchar2_table(737) := 'IVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETR';
wwv_flow_imp.g_varchar2_table(738) := 'Y) values (3386,''DTS'',''AIRPORT'',''DESTIN EXECUTIVE'',''DESTIN'',''FLORIDA'',''Feb-65'',to_timestamp(''01.02.1';
wwv_flow_imp.g_varchar2_table(739) := '965 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),23,1,395,0,654,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POIN';
wwv_flow_imp.g_varchar2_table(740) := 'T_TYPE(-86.47147, 30.40005, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,A';
wwv_flow_imp.g_varchar2_table(741) := 'IRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_A';
wwv_flow_imp.g_varchar2_table(742) := 'IRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3410,''FLL'',''AIRPORT'',''FORT LA';
wwv_flow_imp.g_varchar2_table(743) := 'UDERDALE/HOLLYWOOD INTL'',''FORT LAUDERDALE'',''FLORIDA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD';
wwv_flow_imp.g_varchar2_table(744) := '.MM.RR HH24:MI:SSXFF''),65,3,1380,288866,39209,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-8';
wwv_flow_imp.g_varchar2_table(745) := '0.14969, 26.07167, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TY';
wwv_flow_imp.g_varchar2_table(746) := 'PE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LA';
wwv_flow_imp.g_varchar2_table(747) := 'ND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3428,''FMY'',''AIRPORT'',''PAGE FIELD'',''FOR';
wwv_flow_imp.g_varchar2_table(748) := 'T MYERS'',''FLORIDA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),17,3,588,9,';
wwv_flow_imp.g_varchar2_table(749) := '3545,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.86325, 26.58661, NULL), NULL, NULL));'||wwv_flow.LF||
'I';
wwv_flow_imp.g_varchar2_table(750) := 'nsert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(751) := 'N_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_O';
wwv_flow_imp.g_varchar2_table(752) := 'PS,GEOMETRY) values (3430,''RSW'',''AIRPORT'',''SOUTHWEST FLORIDA INTL'',''FORT MYERS'',''FLORIDA'',''Mar-83'',t';
wwv_flow_imp.g_varchar2_table(753) := 'o_timestamp(''01.03.1983 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),30,10,13555,69941,4674,MDSYS.SDO_GEOMETR';
wwv_flow_imp.g_varchar2_table(754) := 'Y(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.75517, 26.53617, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_';
wwv_flow_imp.g_varchar2_table(755) := 'MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(756) := '_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3';
wwv_flow_imp.g_varchar2_table(757) := '457,''GNV'',''AIRPORT'',''GAINESVILLE RGNL'',''GAINESVILLE'',''FLORIDA'',''Apr-40'',to_timestamp(''01.04.1940 00:';
wwv_flow_imp.g_varchar2_table(758) := '00:00'',''DD.MM.RR HH24:MI:SSXFF''),151,3,1650,3047,7814,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT';
wwv_flow_imp.g_varchar2_table(759) := '_TYPE(-82.27178, 29.69006, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AI';
wwv_flow_imp.g_varchar2_table(760) := 'RPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AI';
wwv_flow_imp.g_varchar2_table(761) := 'RPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3534,''JAX'',''AIRPORT'',''JACKSONV';
wwv_flow_imp.g_varchar2_table(762) := 'ILLE INTL'',''JACKSONVILLE'',''FLORIDA'',''Nov-68'',to_timestamp(''01.11.1968 00:00:00'',''DD.MM.RR HH24:MI:SS';
wwv_flow_imp.g_varchar2_table(763) := 'XFF''),30,9,7911,67684,16737,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.68785, 30.49405,';
wwv_flow_imp.g_varchar2_table(764) := ' NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CI';
wwv_flow_imp.g_varchar2_table(765) := 'TY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,CO';
wwv_flow_imp.g_varchar2_table(766) := 'MMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3538,''VQQ'',''AIRPORT'',''CECIL'',''JACKSONVILLE'',''FLORIDA'',nu';
wwv_flow_imp.g_varchar2_table(767) := 'll,null,80,0,6082,744,346,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.87717, 30.21878, N';
wwv_flow_imp.g_varchar2_table(768) := 'ULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY';
wwv_flow_imp.g_varchar2_table(769) := ',STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMM';
wwv_flow_imp.g_varchar2_table(770) := 'ERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3574,''EYW'',''AIRPORT'',''KEY WEST INTL'',''KEY WEST'',''FLORIDA'',';
wwv_flow_imp.g_varchar2_table(771) := '''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),3,2,334,15915,5043,MDSYS.SDO_G';
wwv_flow_imp.g_varchar2_table(772) := 'EOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.75996, 24.55612, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_S';
wwv_flow_imp.g_varchar2_table(773) := 'AMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(774) := 'N_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) val';
wwv_flow_imp.g_varchar2_table(775) := 'ues (3617,''LAL'',''AIRPORT'',''LAKELAND LINDER INTL'',''LAKELAND'',''FLORIDA'',''Jan-43'',to_timestamp(''01.01.1';
wwv_flow_imp.g_varchar2_table(776) := '943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),142,4,1710,10,1279,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(777) := 'POINT_TYPE(-82.01899, 27.98764, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CO';
wwv_flow_imp.g_varchar2_table(778) := 'DE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_';
wwv_flow_imp.g_varchar2_table(779) := 'TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3671,''MTH'',''AIRPORT'',''THE';
wwv_flow_imp.g_varchar2_table(780) := ' FLORIDA KEYS MARATHON INTL'',''MARATHON'',''FLORIDA'',''Mar-44'',to_timestamp(''01.03.1944 00:00:00'',''DD.MM';
wwv_flow_imp.g_varchar2_table(781) := '.RR HH24:MI:SSXFF''),5,3,197,0,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.05136, 24.72';
wwv_flow_imp.g_varchar2_table(782) := '619, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAM';
wwv_flow_imp.g_varchar2_table(783) := 'E,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERE';
wwv_flow_imp.g_varchar2_table(784) := 'D,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3687,''MLB'',''AIRPORT'',''MELBOURNE INTL'',''MELBOURNE'',''F';
wwv_flow_imp.g_varchar2_table(785) := 'LORIDA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),33,2,2800,5497,3017,MD';
wwv_flow_imp.g_varchar2_table(786) := 'SYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-80.64525, 28.10275, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert i';
wwv_flow_imp.g_varchar2_table(787) := 'nto EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,';
wwv_flow_imp.g_varchar2_table(788) := 'ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOM';
wwv_flow_imp.g_varchar2_table(789) := 'ETRY) values (3719,''MIA'',''AIRPORT'',''MIAMI INTL'',''MIAMI'',''FLORIDA'',''Apr-40'',to_timestamp(''01.04.1940 ';
wwv_flow_imp.g_varchar2_table(790) := '00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),9,8,3300,356198,44828,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_P';
wwv_flow_imp.g_varchar2_table(791) := 'OINT_TYPE(-80.29012, 25.79536, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_COD';
wwv_flow_imp.g_varchar2_table(792) := 'E,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_T';
wwv_flow_imp.g_varchar2_table(793) := 'O_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3720,''OPF'',''AIRPORT'',''MIAM';
wwv_flow_imp.g_varchar2_table(794) := 'I-OPA LOCKA EXECUTIVE'',''MIAMI'',''FLORIDA'',''May-41'',to_timestamp(''01.05.1941 00:00:00'',''DD.MM.RR HH24:';
wwv_flow_imp.g_varchar2_table(795) := 'MI:SSXFF''),8,10,1880,36,9494,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-80.27822, 25.90742';
wwv_flow_imp.g_varchar2_table(796) := ', NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,C';
wwv_flow_imp.g_varchar2_table(797) := 'ITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,C';
wwv_flow_imp.g_varchar2_table(798) := 'OMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3749,''APF'',''AIRPORT'',''NAPLES MUNI'',''NAPLES'',''FLORIDA'',''';
wwv_flow_imp.g_varchar2_table(799) := 'Jul-44'',to_timestamp(''01.07.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),8,2,732,1,14631,MDSYS.SDO_GEOME';
wwv_flow_imp.g_varchar2_table(800) := 'TRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.77564, 26.15244, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPL';
wwv_flow_imp.g_varchar2_table(801) := 'E_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DA';
wwv_flow_imp.g_varchar2_table(802) := 'TE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values ';
wwv_flow_imp.g_varchar2_table(803) := '(3762,''EVB'',''AIRPORT'',''NEW SMYRNA BEACH MUNI'',''NEW SMYRNA BEACH'',''FLORIDA'',''Apr-40'',to_timestamp(''01';
wwv_flow_imp.g_varchar2_table(804) := '.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),11,3,718,1,69,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(805) := 'POINT_TYPE(-80.94892, 29.05569, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CO';
wwv_flow_imp.g_varchar2_table(806) := 'DE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_';
wwv_flow_imp.g_varchar2_table(807) := 'TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3780,''OCF'',''AIRPORT'',''OCA';
wwv_flow_imp.g_varchar2_table(808) := 'LA INTL-JIM TAYLOR FIELD'',''OCALA'',''FLORIDA'',''Aug-61'',to_timestamp(''01.08.1961 00:00:00'',''DD.MM.RR HH';
wwv_flow_imp.g_varchar2_table(809) := '24:MI:SSXFF''),90,4,1532,34,1201,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-82.22411, 29.17';
wwv_flow_imp.g_varchar2_table(810) := '188, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAM';
wwv_flow_imp.g_varchar2_table(811) := 'E,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERE';
wwv_flow_imp.g_varchar2_table(812) := 'D,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3836,''MCO'',''AIRPORT'',''ORLANDO INTL'',''ORLANDO'',''FLORI';
wwv_flow_imp.g_varchar2_table(813) := 'DA'',''Jun-41'',to_timestamp(''01.06.1941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),96,6,12600,337510,13512,MD';
wwv_flow_imp.g_varchar2_table(814) := 'SYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.309, 28.42939, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert int';
wwv_flow_imp.g_varchar2_table(815) := 'o EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,AC';
wwv_flow_imp.g_varchar2_table(816) := 'TIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMET';
wwv_flow_imp.g_varchar2_table(817) := 'RY) values (3838,''SFB'',''AIRPORT'',''ORLANDO SANFORD INTL'',''ORLANDO'',''FLORIDA'',''Feb-43'',to_timestamp(''0';
wwv_flow_imp.g_varchar2_table(818) := '1.02.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),55,16,3000,23286,116266,MDSYS.SDO_GEOMETRY(2001, 4326,';
wwv_flow_imp.g_varchar2_table(819) := ' MDSYS.SDO_POINT_TYPE(-81.23491, 28.77718, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS ';
wwv_flow_imp.g_varchar2_table(820) := '(ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION';
wwv_flow_imp.g_varchar2_table(821) := ',DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3840,''ISM'',''AI';
wwv_flow_imp.g_varchar2_table(822) := 'RPORT'',''KISSIMMEE GATEWAY'',''ORLANDO'',''FLORIDA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR';
wwv_flow_imp.g_varchar2_table(823) := ' HH24:MI:SSXFF''),82,16,892,4,2326,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.43708, 28.';
wwv_flow_imp.g_varchar2_table(824) := '28981, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_N';
wwv_flow_imp.g_varchar2_table(825) := 'AME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVE';
wwv_flow_imp.g_varchar2_table(826) := 'RED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3880,''ECP'',''AIRPORT'',''NORTHWEST FLORIDA BEACHES IN';
wwv_flow_imp.g_varchar2_table(827) := 'TL'',''PANAMA CITY'',''FLORIDA'',''Feb-10'',to_timestamp(''01.02.2010 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),69';
wwv_flow_imp.g_varchar2_table(828) := ',16,4000,10654,5925,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-85.79561, 30.35825, NULL), ';
wwv_flow_imp.g_varchar2_table(829) := 'NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE';
wwv_flow_imp.g_varchar2_table(830) := '_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL';
wwv_flow_imp.g_varchar2_table(831) := '_OPS,AIR_TAXI_OPS,GEOMETRY) values (3889,''PNS'',''AIRPORT'',''PENSACOLA INTL'',''PENSACOLA'',''FLORIDA'',null';
wwv_flow_imp.g_varchar2_table(832) := ',null,121,3,1211,18332,11218,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-87.18661, 30.47342';
wwv_flow_imp.g_varchar2_table(833) := ', NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,C';
wwv_flow_imp.g_varchar2_table(834) := 'ITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,C';
wwv_flow_imp.g_varchar2_table(835) := 'OMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3918,''PGD'',''AIRPORT'',''PUNTA GORDA'',''PUNTA GORDA'',''FLORI';
wwv_flow_imp.g_varchar2_table(836) := 'DA'',''Feb-44'',to_timestamp(''01.02.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),26,3,1934,10960,1590,MDSYS';
wwv_flow_imp.g_varchar2_table(837) := '.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.99093, 26.91894, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into';
wwv_flow_imp.g_varchar2_table(838) := ' EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACT';
wwv_flow_imp.g_varchar2_table(839) := 'IVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETR';
wwv_flow_imp.g_varchar2_table(840) := 'Y) values (3935,''SGJ'',''AIRPORT'',''NORTHEAST FLORIDA RGNL'',''ST AUGUSTINE'',''FLORIDA'',''Apr-40'',to_timest';
wwv_flow_imp.g_varchar2_table(841) := 'amp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),10,4,668,3,6464,MDSYS.SDO_GEOMETRY(2001, 4326, M';
wwv_flow_imp.g_varchar2_table(842) := 'DSYS.SDO_POINT_TYPE(-81.33973, 29.95925, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (I';
wwv_flow_imp.g_varchar2_table(843) := 'D,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,D';
wwv_flow_imp.g_varchar2_table(844) := 'IST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3950,''PIE'',''AIRP';
wwv_flow_imp.g_varchar2_table(845) := 'ORT'',''ST PETE-CLEARWATER INTL'',''ST PETERSBURG-CLEARWATER'',''FLORIDA'',''Oct-42'',to_timestamp(''01.10.194';
wwv_flow_imp.g_varchar2_table(846) := '2 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),11,8,1900,15564,4592,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(847) := 'POINT_TYPE(-82.6865, 27.90869, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_COD';
wwv_flow_imp.g_varchar2_table(848) := 'E,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_T';
wwv_flow_imp.g_varchar2_table(849) := 'O_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3963,''SRQ'',''AIRPORT'',''SARA';
wwv_flow_imp.g_varchar2_table(850) := 'SOTA/BRADENTON INTL'',''SARASOTA/BRADENTON'',''FLORIDA'',''Apr-42'',to_timestamp(''01.04.1942 00:00:00'',''DD.';
wwv_flow_imp.g_varchar2_table(851) := 'MM.RR HH24:MI:SSXFF''),30,3,1102,16726,10475,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-82.';
wwv_flow_imp.g_varchar2_table(852) := '55439, 27.39544, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE';
wwv_flow_imp.g_varchar2_table(853) := ',AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND';
wwv_flow_imp.g_varchar2_table(854) := '_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (3985,''TLH'',''AIRPORT'',''TALLAHASSEE INTL'',';
wwv_flow_imp.g_varchar2_table(855) := '''TALLAHASSEE'',''FLORIDA'',''Sep-61'',to_timestamp(''01.09.1961 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),83,4,2';
wwv_flow_imp.g_varchar2_table(856) := '485,8738,9984,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-84.35087, 30.39675, NULL), NULL, ';
wwv_flow_imp.g_varchar2_table(857) := 'NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,';
wwv_flow_imp.g_varchar2_table(858) := 'ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,A';
wwv_flow_imp.g_varchar2_table(859) := 'IR_TAXI_OPS,GEOMETRY) values (3993,''TPA'',''AIRPORT'',''TAMPA INTL'',''TAMPA'',''FLORIDA'',''Apr-40'',to_timest';
wwv_flow_imp.g_varchar2_table(860) := 'amp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),26,6,3300,170756,17624,MDSYS.SDO_GEOMETRY(2001, ';
wwv_flow_imp.g_varchar2_table(861) := '4326, MDSYS.SDO_POINT_TYPE(-82.53325, 27.97547, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRP';
wwv_flow_imp.g_varchar2_table(862) := 'ORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEV';
wwv_flow_imp.g_varchar2_table(863) := 'ATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4018,''TIX';
wwv_flow_imp.g_varchar2_table(864) := ''',''AIRPORT'',''SPACE COAST RGNL'',''TITUSVILLE'',''FLORIDA'',''Oct-44'',to_timestamp(''01.10.1944 00:00:00'',''D';
wwv_flow_imp.g_varchar2_table(865) := 'D.MM.RR HH24:MI:SSXFF''),34,5,1650,0,249,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-80.7992';
wwv_flow_imp.g_varchar2_table(866) := '2, 28.51481, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIR';
wwv_flow_imp.g_varchar2_table(867) := 'PORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_ARE';
wwv_flow_imp.g_varchar2_table(868) := 'A_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4025,''VPS'',''AIRPORT'',''EGLIN AFB/DESTIN-FT WA';
wwv_flow_imp.g_varchar2_table(869) := 'LTON BEACH'',''VALPARAISO/DESTIN-FT WALTON BEACH'',''FLORIDA'',''Mar-41'',to_timestamp(''01.03.1941 00:00:00';
wwv_flow_imp.g_varchar2_table(870) := ''',''DD.MM.RR HH24:MI:SSXFF''),84,1,6500,17587,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-8';
wwv_flow_imp.g_varchar2_table(871) := '6.52604, 30.48322, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TY';
wwv_flow_imp.g_varchar2_table(872) := 'PE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LA';
wwv_flow_imp.g_varchar2_table(873) := 'ND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4035,''VRB'',''AIRPORT'',''VERO BEACH RGNL''';
wwv_flow_imp.g_varchar2_table(874) := ',''VERO BEACH'',''FLORIDA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),24,1,1';
wwv_flow_imp.g_varchar2_table(875) := '707,177,64572,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-80.41794, 27.65556, NULL), NULL, ';
wwv_flow_imp.g_varchar2_table(876) := 'NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,';
wwv_flow_imp.g_varchar2_table(877) := 'ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,A';
wwv_flow_imp.g_varchar2_table(878) := 'IR_TAXI_OPS,GEOMETRY) values (4051,''PBI'',''AIRPORT'',''PALM BEACH INTL'',''WEST PALM BEACH'',''FLORIDA'',''Ap';
wwv_flow_imp.g_varchar2_table(879) := 'r-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),20,3,2120,53389,28298,MDSYS.SDO_G';
wwv_flow_imp.g_varchar2_table(880) := 'EOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-80.09559, 26.68316, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_S';
wwv_flow_imp.g_varchar2_table(881) := 'AMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(882) := 'N_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) val';
wwv_flow_imp.g_varchar2_table(883) := 'ues (4092,''ABY'',''AIRPORT'',''SOUTHWEST GEORGIA RGNL'',''ALBANY'',''GEORGIA'',''Apr-40'',to_timestamp(''01.04.1';
wwv_flow_imp.g_varchar2_table(884) := '940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),196,3,980,55,2776,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_P';
wwv_flow_imp.g_varchar2_table(885) := 'OINT_TYPE(-84.19447, 31.53553, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_COD';
wwv_flow_imp.g_varchar2_table(886) := 'E,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_T';
wwv_flow_imp.g_varchar2_table(887) := 'O_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4106,''AHN'',''AIRPORT'',''ATHE';
wwv_flow_imp.g_varchar2_table(888) := 'NS/BEN EPPS'',''ATHENS'',''GEORGIA'',''Jul-40'',to_timestamp(''01.07.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''';
wwv_flow_imp.g_varchar2_table(889) := '),813,3,425,24,1078,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-83.32592, 33.94864, NULL), ';
wwv_flow_imp.g_varchar2_table(890) := 'NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE';
wwv_flow_imp.g_varchar2_table(891) := '_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL';
wwv_flow_imp.g_varchar2_table(892) := '_OPS,AIR_TAXI_OPS,GEOMETRY) values (4118,''ATL'',''AIRPORT'',''HARTSFIELD - JACKSON ATLANTA INTL'',''ATLANT';
wwv_flow_imp.g_varchar2_table(893) := 'A'',''GEORGIA'',''Sep-42'',to_timestamp(''01.09.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1026,7,4700,72395';
wwv_flow_imp.g_varchar2_table(894) := '6,85130,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-84.42786, 33.6367, NULL), NULL, NULL));';
wwv_flow_imp.g_varchar2_table(895) := ''||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVAT';
wwv_flow_imp.g_varchar2_table(896) := 'ION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI';
wwv_flow_imp.g_varchar2_table(897) := '_OPS,GEOMETRY) values (4138,''AGS'',''AIRPORT'',''AUGUSTA RGNL AT BUSH FIELD'',''AUGUSTA'',''GEORGIA'',''Oct-43';
wwv_flow_imp.g_varchar2_table(898) := ''',to_timestamp(''01.10.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),146,6,1411,5434,8589,MDSYS.SDO_GEOMET';
wwv_flow_imp.g_varchar2_table(899) := 'RY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.9645, 33.36994, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_';
wwv_flow_imp.g_varchar2_table(900) := 'MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(901) := '_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4';
wwv_flow_imp.g_varchar2_table(902) := '163,''BQK'',''AIRPORT'',''BRUNSWICK GOLDEN ISLES'',''BRUNSWICK'',''GEORGIA'',''Feb-44'',to_timestamp(''01.02.1944';
wwv_flow_imp.g_varchar2_table(903) := ' 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),26,5,2003,2190,1000,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_PO';
wwv_flow_imp.g_varchar2_table(904) := 'INT_TYPE(-81.46632, 31.25903, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE';
wwv_flow_imp.g_varchar2_table(905) := ',AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO';
wwv_flow_imp.g_varchar2_table(906) := '_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4205,''CSG'',''AIRPORT'',''COLUM';
wwv_flow_imp.g_varchar2_table(907) := 'BUS'',''COLUMBUS'',''GEORGIA'',''Nov-42'',to_timestamp(''01.11.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),397,';
wwv_flow_imp.g_varchar2_table(908) := '3,680,348,2846,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-84.93886, 32.51633, NULL), NULL,';
wwv_flow_imp.g_varchar2_table(909) := ' NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME';
wwv_flow_imp.g_varchar2_table(910) := ',ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,';
wwv_flow_imp.g_varchar2_table(911) := 'AIR_TAXI_OPS,GEOMETRY) values (4371,''MCN'',''AIRPORT'',''MIDDLE GEORGIA RGNL'',''MACON'',''GEORGIA'',''Mar-42''';
wwv_flow_imp.g_varchar2_table(912) := ',to_timestamp(''01.03.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),354,9,1149,47,1734,MDSYS.SDO_GEOMETRY(';
wwv_flow_imp.g_varchar2_table(913) := '2001, 4326, MDSYS.SDO_POINT_TYPE(-83.64922, 32.69283, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MA';
wwv_flow_imp.g_varchar2_table(914) := 'P_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_D';
wwv_flow_imp.g_varchar2_table(915) := 'T,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (443';
wwv_flow_imp.g_varchar2_table(916) := '6,''RMG'',''AIRPORT'',''RICHARD B RUSSELL REGIONAL - J H TOWERS FIELD'',''ROME'',''GEORGIA'',''Mar-44'',to_times';
wwv_flow_imp.g_varchar2_table(917) := 'tamp(''01.03.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),644,6,985,0,null,MDSYS.SDO_GEOMETRY(2001, 4326,';
wwv_flow_imp.g_varchar2_table(918) := ' MDSYS.SDO_POINT_TYPE(-85.15867, 34.35078, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS ';
wwv_flow_imp.g_varchar2_table(919) := '(ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION';
wwv_flow_imp.g_varchar2_table(920) := ',DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4445,''SAV'',''AI';
wwv_flow_imp.g_varchar2_table(921) := 'RPORT'',''SAVANNAH/HILTON HEAD INTL'',''SAVANNAH'',''GEORGIA'',''Sep-42'',to_timestamp(''01.09.1942 00:00:00'',';
wwv_flow_imp.g_varchar2_table(922) := '''DD.MM.RR HH24:MI:SSXFF''),50,7,3650,29856,19430,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(';
wwv_flow_imp.g_varchar2_table(923) := '-81.20214, 32.12758, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(924) := 'TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,';
wwv_flow_imp.g_varchar2_table(925) := 'LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4502,''VLD'',''AIRPORT'',''VALDOSTA RGNL''';
wwv_flow_imp.g_varchar2_table(926) := ',''VALDOSTA'',''GEORGIA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),203,3,76';
wwv_flow_imp.g_varchar2_table(927) := '0,13,3124,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-83.27622, 30.78137, NULL), NULL, NULL';
wwv_flow_imp.g_varchar2_table(928) := '));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTI';
wwv_flow_imp.g_varchar2_table(929) := 'VATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_T';
wwv_flow_imp.g_varchar2_table(930) := 'AXI_OPS,GEOMETRY) values (4549,''GUM'',''AIRPORT'',''GUAM INTL'',''GUAM'',''GUAM'',''Jun-53'',to_timestamp(''01.0';
wwv_flow_imp.g_varchar2_table(931) := '6.1953 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),305,3,1657,24347,262,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS';
wwv_flow_imp.g_varchar2_table(932) := '.SDO_POINT_TYPE(144.79713, 13.48395, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IA';
wwv_flow_imp.g_varchar2_table(933) := 'TA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_';
wwv_flow_imp.g_varchar2_table(934) := 'CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4554,''HNM'',''AIRPORT''';
wwv_flow_imp.g_varchar2_table(935) := ',''HANA'',''HANA'',''HAWAII'',''Oct-50'',to_timestamp(''01.10.1950 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),78,3,1';
wwv_flow_imp.g_varchar2_table(936) := '19,0,1944,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-156.01444, 20.79564, NULL), NULL, NUL';
wwv_flow_imp.g_varchar2_table(937) := 'L));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACT';
wwv_flow_imp.g_varchar2_table(938) := 'IVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_';
wwv_flow_imp.g_varchar2_table(939) := 'TAXI_OPS,GEOMETRY) values (4559,''ITO'',''AIRPORT'',''HILO INTL'',''HILO'',''HAWAII'',''Apr-38'',to_timestamp(''0';
wwv_flow_imp.g_varchar2_table(940) := '1.04.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),38,2,1007,15592,3147,MDSYS.SDO_GEOMETRY(2001, 4326, MD';
wwv_flow_imp.g_varchar2_table(941) := 'SYS.SDO_POINT_TYPE(-155.04847, 19.72026, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (I';
wwv_flow_imp.g_varchar2_table(942) := 'D,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,D';
wwv_flow_imp.g_varchar2_table(943) := 'IST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4562,''HNL'',''AIRP';
wwv_flow_imp.g_varchar2_table(944) := 'ORT'',''DANIEL K INOUYE INTL'',''HONOLULU'',''HAWAII'',''Feb-38'',to_timestamp(''01.02.1938 00:00:00'',''DD.MM.R';
wwv_flow_imp.g_varchar2_table(945) := 'R HH24:MI:SSXFF''),13,3,4220,159726,92317,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-157.92';
wwv_flow_imp.g_varchar2_table(946) := '026, 21.31783, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,A';
wwv_flow_imp.g_varchar2_table(947) := 'IRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_A';
wwv_flow_imp.g_varchar2_table(948) := 'REA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4569,''OGG'',''AIRPORT'',''KAHULUI'',''KAHULUI'',''';
wwv_flow_imp.g_varchar2_table(949) := 'HAWAII'',''Oct-46'',to_timestamp(''01.10.1946 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),53,3,1391,53348,75299,';
wwv_flow_imp.g_varchar2_table(950) := 'MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-156.43045, 20.89865, NULL), NULL, NULL));'||wwv_flow.LF||
'Inser';
wwv_flow_imp.g_varchar2_table(951) := 't into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DA';
wwv_flow_imp.g_varchar2_table(952) := 'TE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,G';
wwv_flow_imp.g_varchar2_table(953) := 'EOMETRY) values (4570,''KOA'',''AIRPORT'',''ELLISON ONIZUKA KONA INTL AT KEAHOLE'',''KAILUA/KONA'',''HAWAII'',';
wwv_flow_imp.g_varchar2_table(954) := '''Jan-71'',to_timestamp(''01.01.1971 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),47,6,2700,32090,22325,MDSYS.SD';
wwv_flow_imp.g_varchar2_table(955) := 'O_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-156.04563, 19.73877, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into E';
wwv_flow_imp.g_varchar2_table(956) := 'BA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIV';
wwv_flow_imp.g_varchar2_table(957) := 'ATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY)';
wwv_flow_imp.g_varchar2_table(958) := ' values (4571,''LUP'',''AIRPORT'',''KALAUPAPA'',''KALAUPAPA'',''HAWAII'',''Oct-41'',to_timestamp(''01.10.1941 00:';
wwv_flow_imp.g_varchar2_table(959) := '00:00'',''DD.MM.RR HH24:MI:SSXFF''),24,2,55,0,2394,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(';
wwv_flow_imp.g_varchar2_table(960) := '-156.9736, 21.21104, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(961) := 'TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,';
wwv_flow_imp.g_varchar2_table(962) := 'LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4572,''MUE'',''AIRPORT'',''WAIMEA-KOHALA''';
wwv_flow_imp.g_varchar2_table(963) := ',''KAMUELA'',''HAWAII'',''Apr-53'',to_timestamp(''01.04.1953 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2671,1,90,';
wwv_flow_imp.g_varchar2_table(964) := '0,2378,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-155.66811, 20.00133, NULL), NULL, NULL))';
wwv_flow_imp.g_varchar2_table(965) := ';'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVA';
wwv_flow_imp.g_varchar2_table(966) := 'TION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAX';
wwv_flow_imp.g_varchar2_table(967) := 'I_OPS,GEOMETRY) values (4575,''JRF'',''AIRPORT'',''KALAELOA (JOHN RODGERS FIELD)'',''KAPOLEI'',''HAWAII'',''Sep';
wwv_flow_imp.g_varchar2_table(968) := '-46'',to_timestamp(''01.09.1946 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),30,2,752,21,1455,MDSYS.SDO_GEOMETR';
wwv_flow_imp.g_varchar2_table(969) := 'Y(2001, 4326, MDSYS.SDO_POINT_TYPE(-158.0703, 21.30735, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_';
wwv_flow_imp.g_varchar2_table(970) := 'MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(971) := '_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4';
wwv_flow_imp.g_varchar2_table(972) := '576,''MKK'',''AIRPORT'',''MOLOKAI'',''KAUNAKAKAI'',''HAWAII'',''Jul-46'',to_timestamp(''01.07.1946 00:00:00'',''DD.';
wwv_flow_imp.g_varchar2_table(973) := 'MM.RR HH24:MI:SSXFF''),454,6,288,0,38808,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-157.096';
wwv_flow_imp.g_varchar2_table(974) := '26, 21.15289, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AI';
wwv_flow_imp.g_varchar2_table(975) := 'RPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AR';
wwv_flow_imp.g_varchar2_table(976) := 'EA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4581,''JHM'',''AIRPORT'',''KAPALUA'',''LAHAINA'',''H';
wwv_flow_imp.g_varchar2_table(977) := 'AWAII'',''Apr-87'',to_timestamp(''01.04.1987 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),256,5,50,0,12948,MDSYS.';
wwv_flow_imp.g_varchar2_table(978) := 'SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-156.67303, 20.96294, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into';
wwv_flow_imp.g_varchar2_table(979) := ' EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACT';
wwv_flow_imp.g_varchar2_table(980) := 'IVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETR';
wwv_flow_imp.g_varchar2_table(981) := 'Y) values (4583,''LNY'',''AIRPORT'',''LANAI'',''LANAI CITY'',''HAWAII'',''Sep-46'',to_timestamp(''01.09.1946 00:0';
wwv_flow_imp.g_varchar2_table(982) := '0:00'',''DD.MM.RR HH24:MI:SSXFF''),1308,3,505,1588,4118,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_';
wwv_flow_imp.g_varchar2_table(983) := 'TYPE(-156.95142, 20.78561, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AI';
wwv_flow_imp.g_varchar2_table(984) := 'RPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AI';
wwv_flow_imp.g_varchar2_table(985) := 'RPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4585,''LIH'',''AIRPORT'',''LIHUE'',''';
wwv_flow_imp.g_varchar2_table(986) := 'LIHUE'',''HAWAII'',''Mar-50'',to_timestamp(''01.03.1950 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),153,2,915,2944';
wwv_flow_imp.g_varchar2_table(987) := '1,82879,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-159.33896, 21.97598, NULL), NULL, NULL)';
wwv_flow_imp.g_varchar2_table(988) := ');'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIV';
wwv_flow_imp.g_varchar2_table(989) := 'ATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TA';
wwv_flow_imp.g_varchar2_table(990) := 'XI_OPS,GEOMETRY) values (4627,''BRL'',''AIRPORT'',''SOUTHEAST IOWA RGNL'',''BURLINGTON'',''IOWA'',''Apr-40'',to_';
wwv_flow_imp.g_varchar2_table(991) := 'timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),698,2,537,1872,3200,MDSYS.SDO_GEOMETRY(200';
wwv_flow_imp.g_varchar2_table(992) := '1, 4326, MDSYS.SDO_POINT_TYPE(-91.1255, 40.78322, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AI';
wwv_flow_imp.g_varchar2_table(993) := 'RPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,EL';
wwv_flow_imp.g_varchar2_table(994) := 'EVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4636,''C';
wwv_flow_imp.g_varchar2_table(995) := 'ID'',''AIRPORT'',''THE EASTERN IOWA'',''CEDAR RAPIDS'',''IOWA'',''Dec-44'',to_timestamp(''01.12.1944 00:00:00'',''';
wwv_flow_imp.g_varchar2_table(996) := 'DD.MM.RR HH24:MI:SSXFF''),869,6,3288,12795,10074,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(';
wwv_flow_imp.g_varchar2_table(997) := '-91.7108, 41.88469, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_T';
wwv_flow_imp.g_varchar2_table(998) := 'YPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,L';
wwv_flow_imp.g_varchar2_table(999) := 'AND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4674,''DSM'',''AIRPORT'',''DES MOINES INTL';
wwv_flow_imp.g_varchar2_table(1000) := ''',''DES MOINES'',''IOWA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),958,3,26';
wwv_flow_imp.g_varchar2_table(1001) := '25,31210,9249,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-93.66307, 41.53397, NULL), NULL, ';
wwv_flow_imp.g_varchar2_table(1002) := 'NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,';
wwv_flow_imp.g_varchar2_table(1003) := 'ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,A';
wwv_flow_imp.g_varchar2_table(1004) := 'IR_TAXI_OPS,GEOMETRY) values (4684,''DBQ'',''AIRPORT'',''DUBUQUE RGNL'',''DUBUQUE'',''IOWA'',''Mar-43'',to_times';
wwv_flow_imp.g_varchar2_table(1005) := 'tamp(''01.03.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1077,7,1240,23,2229,MDSYS.SDO_GEOMETRY(2001, 43';
wwv_flow_imp.g_varchar2_table(1006) := '26, MDSYS.SDO_POINT_TYPE(-90.70947, 42.402, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS';
wwv_flow_imp.g_varchar2_table(1007) := ' (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATIO';
wwv_flow_imp.g_varchar2_table(1008) := 'N,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4698,''FOD'',''A';
wwv_flow_imp.g_varchar2_table(1009) := 'IRPORT'',''FORT DODGE RGNL'',''FORT DODGE'',''IOWA'',''Oct-52'',to_timestamp(''01.10.1952 00:00:00'',''DD.MM.RR ';
wwv_flow_imp.g_varchar2_table(1010) := 'HH24:MI:SSXFF''),1156,3,967,3016,500,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-94.19183, 4';
wwv_flow_imp.g_varchar2_table(1011) := '2.55119, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT';
wwv_flow_imp.g_varchar2_table(1012) := '_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_CO';
wwv_flow_imp.g_varchar2_table(1013) := 'VERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4765,''MCW'',''AIRPORT'',''MASON CITY MUNI'',''MASON CI';
wwv_flow_imp.g_varchar2_table(1014) := 'TY'',''IOWA'',''Mar-43'',to_timestamp(''01.03.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1213,5,1103,4,3536,';
wwv_flow_imp.g_varchar2_table(1015) := 'MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-93.33125, 43.15781, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert';
wwv_flow_imp.g_varchar2_table(1016) := ' into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DAT';
wwv_flow_imp.g_varchar2_table(1017) := 'E,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GE';
wwv_flow_imp.g_varchar2_table(1018) := 'OMETRY) values (4841,''SUX'',''AIRPORT'',''SIOUX GATEWAY/BRIG GEN BUD DAY FIELD'',''SIOUX CITY'',''IOWA'',''Apr';
wwv_flow_imp.g_varchar2_table(1019) := '-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1098,6,2460,2269,3270,MDSYS.SDO_GE';
wwv_flow_imp.g_varchar2_table(1020) := 'OMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-96.38436, 42.40261, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SA';
wwv_flow_imp.g_varchar2_table(1021) := 'MPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION';
wwv_flow_imp.g_varchar2_table(1022) := '_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) valu';
wwv_flow_imp.g_varchar2_table(1023) := 'es (4860,''ALO'',''AIRPORT'',''WATERLOO RGNL'',''WATERLOO'',''IOWA'',''May-47'',to_timestamp(''01.05.1947 00:00:0';
wwv_flow_imp.g_varchar2_table(1024) := '0'',''DD.MM.RR HH24:MI:SSXFF''),873,4,2583,27,1325,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(';
wwv_flow_imp.g_varchar2_table(1025) := '-92.40033, 42.55708, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(1026) := 'TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,';
wwv_flow_imp.g_varchar2_table(1027) := 'LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4906,''BOI'',''AIRPORT'',''BOISE AIR TERM';
wwv_flow_imp.g_varchar2_table(1028) := 'INAL/GOWEN FLD'',''BOISE'',''IDAHO'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''';
wwv_flow_imp.g_varchar2_table(1029) := '),2872,3,5000,49867,10180,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-116.22286, 43.56436, ';
wwv_flow_imp.g_varchar2_table(1030) := 'NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CIT';
wwv_flow_imp.g_varchar2_table(1031) := 'Y,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COM';
wwv_flow_imp.g_varchar2_table(1032) := 'MERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (4930,''C53'',''AIRPORT'',''LOWER LOON CREEK'',''CHALLIS'',''IDAHO''';
wwv_flow_imp.g_varchar2_table(1033) := ',''Nov-92'',to_timestamp(''01.11.1992 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4200,30,5,0,250,MDSYS.SDO_GEO';
wwv_flow_imp.g_varchar2_table(1034) := 'METRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-114.80866, 44.80867, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SA';
wwv_flow_imp.g_varchar2_table(1035) := 'MPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION';
wwv_flow_imp.g_varchar2_table(1036) := '_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) valu';
wwv_flow_imp.g_varchar2_table(1037) := 'es (4954,''COE'',''AIRPORT'',''COEUR D''''ALENE - PAPPY BOYINGTON FIELD'',''COEUR D''''ALENE'',''IDAHO'',''Dec-42'',';
wwv_flow_imp.g_varchar2_table(1038) := 'to_timestamp(''01.12.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2320,9,1140,4,27200,MDSYS.SDO_GEOMETRY(';
wwv_flow_imp.g_varchar2_table(1039) := '2001, 4326, MDSYS.SDO_POINT_TYPE(-116.81958, 47.77431, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_M';
wwv_flow_imp.g_varchar2_table(1040) := 'AP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_';
wwv_flow_imp.g_varchar2_table(1041) := 'DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (49';
wwv_flow_imp.g_varchar2_table(1042) := '63,''C48'',''AIRPORT'',''WILSON BAR USFS'',''DIXIE'',''IDAHO'',''May-96'',to_timestamp(''01.05.1996 00:00:00'',''DD';
wwv_flow_imp.g_varchar2_table(1043) := '.MM.RR HH24:MI:SSXFF''),2275,8,5,0,40,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-115.48333,';
wwv_flow_imp.g_varchar2_table(1044) := ' 45.39667, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPO';
wwv_flow_imp.g_varchar2_table(1045) := 'RT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_';
wwv_flow_imp.g_varchar2_table(1046) := 'COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (5000,''SUN'',''AIRPORT'',''FRIEDMAN MEMORIAL'',''HAIL';
wwv_flow_imp.g_varchar2_table(1047) := 'EY'',''IDAHO'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),5320,1,211,3391,62';
wwv_flow_imp.g_varchar2_table(1048) := '71,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-114.29556, 43.50378, NULL), NULL, NULL));'||wwv_flow.LF||
'In';
wwv_flow_imp.g_varchar2_table(1049) := 'sert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION';
wwv_flow_imp.g_varchar2_table(1050) := '_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OP';
wwv_flow_imp.g_varchar2_table(1051) := 'S,GEOMETRY) values (5018,''IDA'',''AIRPORT'',''IDAHO FALLS RGNL'',''IDAHO FALLS'',''IDAHO'',''Apr-40'',to_timest';
wwv_flow_imp.g_varchar2_table(1052) := 'amp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4744,2,866,1152,10140,MDSYS.SDO_GEOMETRY(2001, 4';
wwv_flow_imp.g_varchar2_table(1053) := '326, MDSYS.SDO_POINT_TYPE(-112.07075, 43.51372, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRP';
wwv_flow_imp.g_varchar2_table(1054) := 'ORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEV';
wwv_flow_imp.g_varchar2_table(1055) := 'ATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (5041,''LWS';
wwv_flow_imp.g_varchar2_table(1056) := ''',''AIRPORT'',''LEWISTON-NEZ PERCE COUNTY'',''LEWISTON'',''IDAHO'',''Jul-44'',to_timestamp(''01.07.1944 00:00:0';
wwv_flow_imp.g_varchar2_table(1057) := '0'',''DD.MM.RR HH24:MI:SSXFF''),1442,2,865,1768,3496,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYP';
wwv_flow_imp.g_varchar2_table(1058) := 'E(-117.01539, 46.3745, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPOR';
wwv_flow_imp.g_varchar2_table(1059) := 'T_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPOR';
wwv_flow_imp.g_varchar2_table(1060) := 'T,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (5108,''PIH'',''AIRPORT'',''POCATELLO RG';
wwv_flow_imp.g_varchar2_table(1061) := 'NL'',''POCATELLO'',''IDAHO'',''Feb-44'',to_timestamp(''01.02.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4452,7';
wwv_flow_imp.g_varchar2_table(1062) := ',3374,1100,6751,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-112.59592, 42.90979, NULL), NUL';
wwv_flow_imp.g_varchar2_table(1063) := 'L, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NA';
wwv_flow_imp.g_varchar2_table(1064) := 'ME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OP';
wwv_flow_imp.g_varchar2_table(1065) := 'S,AIR_TAXI_OPS,GEOMETRY) values (5164,''TWF'',''AIRPORT'',''JOSLIN FIELD - MAGIC VALLEY RGNL'',''TWIN FALLS';
wwv_flow_imp.g_varchar2_table(1066) := ''',''IDAHO'',''Feb-48'',to_timestamp(''01.02.1948 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4154,4,1468,414,5000';
wwv_flow_imp.g_varchar2_table(1067) := ',MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-114.48775, 42.48181, NULL), NULL, NULL));'||wwv_flow.LF||
'Inse';
wwv_flow_imp.g_varchar2_table(1068) := 'rt into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(1069) := 'ATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,';
wwv_flow_imp.g_varchar2_table(1070) := 'GEOMETRY) values (5185,''ALN'',''AIRPORT'',''ST LOUIS RGNL'',''ALTON/ST LOUIS'',''ILLINOIS'',''Apr-40'',to_times';
wwv_flow_imp.g_varchar2_table(1071) := 'tamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),544,4,2250,16,3943,MDSYS.SDO_GEOMETRY(2001, 432';
wwv_flow_imp.g_varchar2_table(1072) := '6, MDSYS.SDO_POINT_TYPE(-90.046, 38.88992, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS ';
wwv_flow_imp.g_varchar2_table(1073) := '(ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION';
wwv_flow_imp.g_varchar2_table(1074) := ',DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (5209,''BLV'',''AI';
wwv_flow_imp.g_varchar2_table(1075) := 'RPORT'',''SCOTT AFB/MIDAMERICA'',''BELLEVILLE'',''ILLINOIS'',''Jul-42'',to_timestamp(''01.07.1942 00:00:00'',''D';
wwv_flow_imp.g_varchar2_table(1076) := 'D.MM.RR HH24:MI:SSXFF''),459,14,7003,2020,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.8';
wwv_flow_imp.g_varchar2_table(1077) := '3519, 38.54517, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,';
wwv_flow_imp.g_varchar2_table(1078) := 'AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_';
wwv_flow_imp.g_varchar2_table(1079) := 'AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (5221,''BMI'',''AIRPORT'',''CENTRAL IL RGNL ARP';
wwv_flow_imp.g_varchar2_table(1080) := 'T AT BLOOMINGTON-NORMAL'',''BLOOMINGTON/NORMAL'',''ILLINOIS'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00''';
wwv_flow_imp.g_varchar2_table(1081) := ',''DD.MM.RR HH24:MI:SSXFF''),871,3,1968,5664,2300,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(';
wwv_flow_imp.g_varchar2_table(1082) := '-88.91592, 40.47711, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(1083) := 'TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,';
wwv_flow_imp.g_varchar2_table(1084) := 'LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (5241,''CPS'',''AIRPORT'',''ST LOUIS DOWNT';
wwv_flow_imp.g_varchar2_table(1085) := 'OWN'',''CAHOKIA/ST LOUIS'',''ILLINOIS'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSX';
wwv_flow_imp.g_varchar2_table(1086) := 'FF''),413,1,1013,163,9846,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-90.15508, 38.57036, NU';
wwv_flow_imp.g_varchar2_table(1087) := 'LL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,';
wwv_flow_imp.g_varchar2_table(1088) := 'STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMME';
wwv_flow_imp.g_varchar2_table(1089) := 'RCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (5250,''MDH'',''AIRPORT'',''SOUTHERN ILLINOIS'',''CARBONDALE/MURPHY';
wwv_flow_imp.g_varchar2_table(1090) := 'SBORO'',''ILLINOIS'',''Sep-50'',to_timestamp(''01.09.1950 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),411,3,920,31';
wwv_flow_imp.g_varchar2_table(1091) := ',24734,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.25203, 37.77808, NULL), NULL, NULL));';
wwv_flow_imp.g_varchar2_table(1092) := ''||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVAT';
wwv_flow_imp.g_varchar2_table(1093) := 'ION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI';
wwv_flow_imp.g_varchar2_table(1094) := '_OPS,GEOMETRY) values (5269,''CMI'',''AIRPORT'',''UNIVERSITY OF ILLINOIS-WILLARD'',''CHAMPAIGN/URBANA'',''ILL';
wwv_flow_imp.g_varchar2_table(1095) := 'INOIS'',''May-45'',to_timestamp(''01.05.1945 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),755,5,1799,168,12487,MD';
wwv_flow_imp.g_varchar2_table(1096) := 'SYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-88.27781, 40.03883, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert i';
wwv_flow_imp.g_varchar2_table(1097) := 'nto EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,';
wwv_flow_imp.g_varchar2_table(1098) := 'ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOM';
wwv_flow_imp.g_varchar2_table(1099) := 'ETRY) values (5277,''UGN'',''AIRPORT'',''WAUKEGAN NATIONAL'',''CHICAGO/WAUKEGAN'',''ILLINOIS'',''Apr-47'',to_tim';
wwv_flow_imp.g_varchar2_table(1100) := 'estamp(''01.04.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),728,35,600,1,3792,MDSYS.SDO_GEOMETRY(2001, 43';
wwv_flow_imp.g_varchar2_table(1101) := '26, MDSYS.SDO_POINT_TYPE(-87.86792, 42.42215, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPOR';
wwv_flow_imp.g_varchar2_table(1102) := 'TS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVAT';
wwv_flow_imp.g_varchar2_table(1103) := 'ION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (5287,''ARR'',';
wwv_flow_imp.g_varchar2_table(1104) := '''AIRPORT'',''AURORA MUNI'',''CHICAGO/AURORA'',''ILLINOIS'',''Apr-66'',to_timestamp(''01.04.1966 00:00:00'',''DD.';
wwv_flow_imp.g_varchar2_table(1105) := 'MM.RR HH24:MI:SSXFF''),712,38,1100,28,947,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-88.475';
wwv_flow_imp.g_varchar2_table(1106) := '67, 41.77192, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AI';
wwv_flow_imp.g_varchar2_table(1107) := 'RPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AR';
wwv_flow_imp.g_varchar2_table(1108) := 'EA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (5291,''MDW'',''AIRPORT'',''CHICAGO MIDWAY INTL'',';
wwv_flow_imp.g_varchar2_table(1109) := '''CHICAGO'',''ILLINOIS'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),620,9,650';
wwv_flow_imp.g_varchar2_table(1110) := ',181702,27420,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-87.75242, 41.78597, NULL), NULL, ';
wwv_flow_imp.g_varchar2_table(1111) := 'NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,';
wwv_flow_imp.g_varchar2_table(1112) := 'ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,A';
wwv_flow_imp.g_varchar2_table(1113) := 'IR_TAXI_OPS,GEOMETRY) values (5292,''ORD'',''AIRPORT'',''CHICAGO O''''HARE INTL'',''CHICAGO'',''ILLINOIS'',''Feb-';
wwv_flow_imp.g_varchar2_table(1114) := '44'',to_timestamp(''01.02.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),680,14,7627,652622,245587,MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(1115) := '_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-87.9066, 41.97452, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_';
wwv_flow_imp.g_varchar2_table(1116) := 'SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATI';
wwv_flow_imp.g_varchar2_table(1117) := 'ON_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) va';
wwv_flow_imp.g_varchar2_table(1118) := 'lues (5293,''PWK'',''AIRPORT'',''CHICAGO EXECUTIVE'',''CHICAGO/PROSPECT HEIGHTS/WHEELING'',''ILLINOIS'',''Feb-4';
wwv_flow_imp.g_varchar2_table(1119) := '4'',to_timestamp(''01.02.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),647,18,411,48,13232,MDSYS.SDO_GEOMET';
wwv_flow_imp.g_varchar2_table(1120) := 'RY(2001, 4326, MDSYS.SDO_POINT_TYPE(-87.90153, 42.11428, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE';
wwv_flow_imp.g_varchar2_table(1121) := '_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DAT';
wwv_flow_imp.g_varchar2_table(1122) := 'E_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (';
wwv_flow_imp.g_varchar2_table(1123) := '5296,''DPA'',''AIRPORT'',''DUPAGE'',''CHICAGO/WEST CHICAGO'',''ILLINOIS'',''Mar-43'',to_timestamp(''01.03.1943 00';
wwv_flow_imp.g_varchar2_table(1124) := ':00:00'',''DD.MM.RR HH24:MI:SSXFF''),759,29,2800,19,5229,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT';
wwv_flow_imp.g_varchar2_table(1125) := '_TYPE(-88.24799, 41.90705, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AI';
wwv_flow_imp.g_varchar2_table(1126) := 'RPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AI';
wwv_flow_imp.g_varchar2_table(1127) := 'RPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (5329,''DEC'',''AIRPORT'',''DECATUR''';
wwv_flow_imp.g_varchar2_table(1128) := ',''DECATUR'',''ILLINOIS'',''Mar-45'',to_timestamp(''01.03.1945 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),682,4,21';
wwv_flow_imp.g_varchar2_table(1129) := '00,9,4349,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-88.86569, 39.83456, NULL), NULL, NULL';
wwv_flow_imp.g_varchar2_table(1130) := '));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTI';
wwv_flow_imp.g_varchar2_table(1131) := 'VATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_T';
wwv_flow_imp.g_varchar2_table(1132) := 'AXI_OPS,GEOMETRY) values (5563,''MWA'',''AIRPORT'',''VETERANS AIRPORT OF SOUTHERN ILLINOIS'',''MARION'',''ILL';
wwv_flow_imp.g_varchar2_table(1133) := 'INOIS'',''Oct-44'',to_timestamp(''01.10.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),472,4,1300,44,8727,MDSY';
wwv_flow_imp.g_varchar2_table(1134) := 'S.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.01108, 37.75497, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert int';
wwv_flow_imp.g_varchar2_table(1135) := 'o EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,AC';
wwv_flow_imp.g_varchar2_table(1136) := 'TIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMET';
wwv_flow_imp.g_varchar2_table(1137) := 'RY) values (5594,''MLI'',''AIRPORT'',''QUAD CITY INTL'',''MOLINE'',''ILLINOIS'',''Apr-40'',to_timestamp(''01.04.1';
wwv_flow_imp.g_varchar2_table(1138) := '940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),590,3,2021,5580,9052,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SD';
wwv_flow_imp.g_varchar2_table(1139) := 'O_POINT_TYPE(-90.50753, 41.44828, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_';
wwv_flow_imp.g_varchar2_table(1140) := 'CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CIT';
wwv_flow_imp.g_varchar2_table(1141) := 'Y_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (5687,''PIA'',''AIRPORT'',''G';
wwv_flow_imp.g_varchar2_table(1142) := 'ENERAL DOWNING - PEORIA INTL'',''PEORIA'',''ILLINOIS'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM';
wwv_flow_imp.g_varchar2_table(1143) := '.RR HH24:MI:SSXFF''),661,4,3800,3946,11659,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.69';
wwv_flow_imp.g_varchar2_table(1144) := '325, 40.66419, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,A';
wwv_flow_imp.g_varchar2_table(1145) := 'IRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_A';
wwv_flow_imp.g_varchar2_table(1146) := 'REA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (5743,''RFD'',''AIRPORT'',''CHICAGO/ROCKFORD INT';
wwv_flow_imp.g_varchar2_table(1147) := 'L'',''CHICAGO/ROCKFORD'',''ILLINOIS'',''Mar-50'',to_timestamp(''01.03.1950 00:00:00'',''DD.MM.RR HH24:MI:SSXFF';
wwv_flow_imp.g_varchar2_table(1148) := '''),742,68,2900,17810,1289,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.09722, 42.19536, N';
wwv_flow_imp.g_varchar2_table(1149) := 'ULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY';
wwv_flow_imp.g_varchar2_table(1150) := ',STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMM';
wwv_flow_imp.g_varchar2_table(1151) := 'ERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (5781,''2LL6'',''HELIPORT'',''GENESIS MEDICAL CENTER - ILLINI CA';
wwv_flow_imp.g_varchar2_table(1152) := 'MPUS'',''SILVIS'',''ILLINOIS'',''May-73'',to_timestamp(''01.05.1973 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),700,';
wwv_flow_imp.g_varchar2_table(1153) := '0,null,50,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-90.41814, 41.49521, NULL), NULL,';
wwv_flow_imp.g_varchar2_table(1154) := ' NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME';
wwv_flow_imp.g_varchar2_table(1155) := ',ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,';
wwv_flow_imp.g_varchar2_table(1156) := 'AIR_TAXI_OPS,GEOMETRY) values (5791,''SPI'',''AIRPORT'',''ABRAHAM LINCOLN CAPITAL'',''SPRINGFIELD'',''ILLINOI';
wwv_flow_imp.g_varchar2_table(1157) := 'S'',''Mar-47'',to_timestamp(''01.03.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),598,3,2300,309,4116,MDSYS.S';
wwv_flow_imp.g_varchar2_table(1158) := 'DO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.67808, 39.84422, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into E';
wwv_flow_imp.g_varchar2_table(1159) := 'BA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIV';
wwv_flow_imp.g_varchar2_table(1160) := 'ATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY)';
wwv_flow_imp.g_varchar2_table(1161) := ' values (5913,''BMG'',''AIRPORT'',''MONROE COUNTY'',''BLOOMINGTON'',''INDIANA'',''Mar-42'',to_timestamp(''01.03.1';
wwv_flow_imp.g_varchar2_table(1162) := '942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),846,4,1035,81,875,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_P';
wwv_flow_imp.g_varchar2_table(1163) := 'OINT_TYPE(-86.61668, 39.14602, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_COD';
wwv_flow_imp.g_varchar2_table(1164) := 'E,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_T';
wwv_flow_imp.g_varchar2_table(1165) := 'O_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6010,''EVV'',''AIRPORT'',''EVAN';
wwv_flow_imp.g_varchar2_table(1166) := 'SVILLE RGNL'',''EVANSVILLE'',''INDIANA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SS';
wwv_flow_imp.g_varchar2_table(1167) := 'XFF''),422,3,1250,2397,9927,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-87.5285, 38.04081, N';
wwv_flow_imp.g_varchar2_table(1168) := 'ULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY';
wwv_flow_imp.g_varchar2_table(1169) := ',STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMM';
wwv_flow_imp.g_varchar2_table(1170) := 'ERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6030,''FWA'',''AIRPORT'',''FORT WAYNE INTL'',''FORT WAYNE'',''INDIA';
wwv_flow_imp.g_varchar2_table(1171) := 'NA'',''Jan-43'',to_timestamp(''01.01.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),815,7,3351,7106,12132,MDSY';
wwv_flow_imp.g_varchar2_table(1172) := 'S.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-85.19517, 40.97847, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert int';
wwv_flow_imp.g_varchar2_table(1173) := 'o EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,AC';
wwv_flow_imp.g_varchar2_table(1174) := 'TIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMET';
wwv_flow_imp.g_varchar2_table(1175) := 'RY) values (6046,''GYY'',''AIRPORT'',''GARY/CHICAGO INTL'',''GARY'',''INDIANA'',null,null,597,3,763,409,1525,M';
wwv_flow_imp.g_varchar2_table(1176) := 'DSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-87.41453, 41.61725, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert ';
wwv_flow_imp.g_varchar2_table(1177) := 'into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(1178) := ',ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEO';
wwv_flow_imp.g_varchar2_table(1179) := 'METRY) values (6120,''IND'',''AIRPORT'',''INDIANAPOLIS INTL'',''INDIANAPOLIS'',''INDIANA'',''Apr-40'',to_timesta';
wwv_flow_imp.g_varchar2_table(1180) := 'mp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),796,7,7700,127309,24796,MDSYS.SDO_GEOMETRY(2001, ';
wwv_flow_imp.g_varchar2_table(1181) := '4326, MDSYS.SDO_POINT_TYPE(-86.29464, 39.71731, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRP';
wwv_flow_imp.g_varchar2_table(1182) := 'ORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEV';
wwv_flow_imp.g_varchar2_table(1183) := 'ATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6143,''LAF';
wwv_flow_imp.g_varchar2_table(1184) := ''',''AIRPORT'',''PURDUE UNIVERSITY'',''LAFAYETTE'',''INDIANA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''D';
wwv_flow_imp.g_varchar2_table(1185) := 'D.MM.RR HH24:MI:SSXFF''),606,2,527,96,925,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-86.936';
wwv_flow_imp.g_varchar2_table(1186) := '89, 40.41231, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AI';
wwv_flow_imp.g_varchar2_table(1187) := 'RPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AR';
wwv_flow_imp.g_varchar2_table(1188) := 'EA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6228,''MIE'',''AIRPORT'',''DELAWARE COUNTY RGNL''';
wwv_flow_imp.g_varchar2_table(1189) := ',''MUNCIE'',''INDIANA'',null,null,937,3,963,15,1017,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(';
wwv_flow_imp.g_varchar2_table(1190) := '-85.39575, 40.24247, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(1191) := 'TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,';
wwv_flow_imp.g_varchar2_table(1192) := 'LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6327,''SBN'',''AIRPORT'',''SOUTH BEND INT';
wwv_flow_imp.g_varchar2_table(1193) := 'L'',''SOUTH BEND'',''INDIANA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),798,';
wwv_flow_imp.g_varchar2_table(1194) := '3,2200,4698,15084,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-86.31733, 41.70822, NULL), NU';
wwv_flow_imp.g_varchar2_table(1195) := 'LL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_N';
wwv_flow_imp.g_varchar2_table(1196) := 'AME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_O';
wwv_flow_imp.g_varchar2_table(1197) := 'PS,AIR_TAXI_OPS,GEOMETRY) values (6343,''HUF'',''AIRPORT'',''TERRE HAUTE RGNL'',''TERRE HAUTE'',''INDIANA'',''D';
wwv_flow_imp.g_varchar2_table(1198) := 'ec-44'',to_timestamp(''01.12.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),589,5,1475,36,990,MDSYS.SDO_GEOM';
wwv_flow_imp.g_varchar2_table(1199) := 'ETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-87.30699, 39.45063, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMP';
wwv_flow_imp.g_varchar2_table(1200) := 'LE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(1201) := 'ATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values';
wwv_flow_imp.g_varchar2_table(1202) := ' (6471,''DDC'',''AIRPORT'',''DODGE CITY RGNL'',''DODGE CITY'',''KANSAS'',''Apr-40'',to_timestamp(''01.04.1940 00:';
wwv_flow_imp.g_varchar2_table(1203) := '00:00'',''DD.MM.RR HH24:MI:SSXFF''),2596,3,451,4500,1500,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT';
wwv_flow_imp.g_varchar2_table(1204) := '_TYPE(-99.96542, 37.76311, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AI';
wwv_flow_imp.g_varchar2_table(1205) := 'RPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AI';
wwv_flow_imp.g_varchar2_table(1206) := 'RPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6506,''GCK'',''AIRPORT'',''GARDEN C';
wwv_flow_imp.g_varchar2_table(1207) := 'ITY RGNL'',''GARDEN CITY'',''KANSAS'',''Feb-44'',to_timestamp(''01.02.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF';
wwv_flow_imp.g_varchar2_table(1208) := '''),2891,8,1848,14,2993,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-100.72442, 37.92753, NUL';
wwv_flow_imp.g_varchar2_table(1209) := 'L), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,S';
wwv_flow_imp.g_varchar2_table(1210) := 'TATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMER';
wwv_flow_imp.g_varchar2_table(1211) := 'CIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6522,''GBD'',''AIRPORT'',''GREAT BEND MUNI'',''GREAT BEND'',''KANSAS''';
wwv_flow_imp.g_varchar2_table(1212) := ',''Jun-43'',to_timestamp(''01.06.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1887,4,1887,0,1944,MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(1213) := 'GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-98.85919, 38.34425, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_';
wwv_flow_imp.g_varchar2_table(1214) := 'SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATI';
wwv_flow_imp.g_varchar2_table(1215) := 'ON_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) va';
wwv_flow_imp.g_varchar2_table(1216) := 'lues (6534,''HYS'',''AIRPORT'',''HAYS RGNL'',''HAYS'',''KANSAS'',''Apr-60'',to_timestamp(''01.04.1960 00:00:00'',''';
wwv_flow_imp.g_varchar2_table(1217) := 'DD.MM.RR HH24:MI:SSXFF''),1999,3,545,2419,8115,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-9';
wwv_flow_imp.g_varchar2_table(1218) := '9.27317, 38.84222, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TY';
wwv_flow_imp.g_varchar2_table(1219) := 'PE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LA';
wwv_flow_imp.g_varchar2_table(1220) := 'ND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6551,''HUT'',''AIRPORT'',''HUTCHINSON RGNL''';
wwv_flow_imp.g_varchar2_table(1221) := ',''HUTCHINSON'',''KANSAS'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1543,3,';
wwv_flow_imp.g_varchar2_table(1222) := '1597,0,1488,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.86049, 38.06615, NULL), NULL, NU';
wwv_flow_imp.g_varchar2_table(1223) := 'LL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,AC';
wwv_flow_imp.g_varchar2_table(1224) := 'TIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR';
wwv_flow_imp.g_varchar2_table(1225) := '_TAXI_OPS,GEOMETRY) values (6559,''K88'',''AIRPORT'',''ALLEN COUNTY'',''IOLA'',''KANSAS'',''Feb-44'',to_timestam';
wwv_flow_imp.g_varchar2_table(1226) := 'p(''01.02.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1016,3,340,12,260,MDSYS.SDO_GEOMETRY(2001, 4326, M';
wwv_flow_imp.g_varchar2_table(1227) := 'DSYS.SDO_POINT_TYPE(-95.38694, 37.86822, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (I';
wwv_flow_imp.g_varchar2_table(1228) := 'D,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,D';
wwv_flow_imp.g_varchar2_table(1229) := 'IST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6586,''LBL'',''AIRP';
wwv_flow_imp.g_varchar2_table(1230) := 'ORT'',''LIBERAL MID-AMERICA RGNL'',''LIBERAL'',''KANSAS'',''Feb-44'',to_timestamp(''01.02.1944 00:00:00'',''DD.M';
wwv_flow_imp.g_varchar2_table(1231) := 'M.RR HH24:MI:SSXFF''),2886,2,2005,1120,1220,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-100.';
wwv_flow_imp.g_varchar2_table(1232) := '95997, 37.04392, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE';
wwv_flow_imp.g_varchar2_table(1233) := ',AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND';
wwv_flow_imp.g_varchar2_table(1234) := '_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6603,''MHK'',''AIRPORT'',''MANHATTAN RGNL'',''M';
wwv_flow_imp.g_varchar2_table(1235) := 'ANHATTAN'',''KANSAS'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1066,4,680,';
wwv_flow_imp.g_varchar2_table(1236) := '632,2535,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-96.67181, 39.14122, NULL), NULL, NULL)';
wwv_flow_imp.g_varchar2_table(1237) := ');'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIV';
wwv_flow_imp.g_varchar2_table(1238) := 'ATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TA';
wwv_flow_imp.g_varchar2_table(1239) := 'XI_OPS,GEOMETRY) values (6611,''MYZ'',''AIRPORT'',''MARYSVILLE MUNI'',''MARYSVILLE'',''KANSAS'',''Dec-46'',to_ti';
wwv_flow_imp.g_varchar2_table(1240) := 'mestamp(''01.12.1946 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1283,1,338,4900,0,MDSYS.SDO_GEOMETRY(2001, 4';
wwv_flow_imp.g_varchar2_table(1241) := '326, MDSYS.SDO_POINT_TYPE(-96.63071, 39.85643, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPO';
wwv_flow_imp.g_varchar2_table(1242) := 'RTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVA';
wwv_flow_imp.g_varchar2_table(1243) := 'TION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6637,''IXD''';
wwv_flow_imp.g_varchar2_table(1244) := ',''AIRPORT'',''NEW CENTURY AIRCENTER'',''OLATHE'',''KANSAS'',null,null,1087,4,2600,1,2760,MDSYS.SDO_GEOMETRY';
wwv_flow_imp.g_varchar2_table(1245) := '(2001, 4326, MDSYS.SDO_POINT_TYPE(-94.89031, 38.83092, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_M';
wwv_flow_imp.g_varchar2_table(1246) := 'AP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_';
wwv_flow_imp.g_varchar2_table(1247) := 'DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (66';
wwv_flow_imp.g_varchar2_table(1248) := '81,''SLN'',''AIRPORT'',''SALINA RGNL'',''SALINA'',''KANSAS'',null,null,1288,3,2862,1345,20299,MDSYS.SDO_GEOMET';
wwv_flow_imp.g_varchar2_table(1249) := 'RY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.65222, 38.79061, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE';
wwv_flow_imp.g_varchar2_table(1250) := '_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DAT';
wwv_flow_imp.g_varchar2_table(1251) := 'E_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (';
wwv_flow_imp.g_varchar2_table(1252) := '6717,''TOP'',''AIRPORT'',''PHILIP BILLARD MUNI'',''TOPEKA'',''KANSAS'',''Apr-40'',to_timestamp(''01.04.1940 00:00';
wwv_flow_imp.g_varchar2_table(1253) := ':00'',''DD.MM.RR HH24:MI:SSXFF''),881,3,920,0,543,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-';
wwv_flow_imp.g_varchar2_table(1254) := '95.62238, 39.06882, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_T';
wwv_flow_imp.g_varchar2_table(1255) := 'YPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,L';
wwv_flow_imp.g_varchar2_table(1256) := 'AND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6720,''FOE'',''AIRPORT'',''TOPEKA RGNL'',''T';
wwv_flow_imp.g_varchar2_table(1257) := 'OPEKA'',''KANSAS'',''Feb-44'',to_timestamp(''01.02.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1078,6,2854,25';
wwv_flow_imp.g_varchar2_table(1258) := '7,363,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-95.66361, 38.95095, NULL), NULL, NULL));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1259) := 'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATI';
wwv_flow_imp.g_varchar2_table(1260) := 'ON_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_';
wwv_flow_imp.g_varchar2_table(1261) := 'OPS,GEOMETRY) values (6739,''EGT'',''AIRPORT'',''WELLINGTON MUNI'',''WELLINGTON'',''KANSAS'',''Nov-42'',to_times';
wwv_flow_imp.g_varchar2_table(1262) := 'tamp(''01.11.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1277,3,190,200,null,MDSYS.SDO_GEOMETRY(2001, 43';
wwv_flow_imp.g_varchar2_table(1263) := '26, MDSYS.SDO_POINT_TYPE(-97.38836, 37.325, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS';
wwv_flow_imp.g_varchar2_table(1264) := ' (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATIO';
wwv_flow_imp.g_varchar2_table(1265) := 'N,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6756,''ICT'',''A';
wwv_flow_imp.g_varchar2_table(1266) := 'IRPORT'',''WICHITA DWIGHT D EISENHOWER NATIONAL'',''WICHITA'',''KANSAS'',''Apr-53'',to_timestamp(''01.04.1953 ';
wwv_flow_imp.g_varchar2_table(1267) := '00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1333,5,3248,16157,22019,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(1268) := '_POINT_TYPE(-97.43306, 37.64994, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_C';
wwv_flow_imp.g_varchar2_table(1269) := 'ODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY';
wwv_flow_imp.g_varchar2_table(1270) := '_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6786,''BWG'',''AIRPORT'',''BO';
wwv_flow_imp.g_varchar2_table(1271) := 'WLING GREEN-WARREN COUNTY RGNL'',''BOWLING GREEN'',''KENTUCKY'',''Apr-40'',to_timestamp(''01.04.1940 00:00:0';
wwv_flow_imp.g_varchar2_table(1272) := '0'',''DD.MM.RR HH24:MI:SSXFF''),547,2,566,0,75,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-86.';
wwv_flow_imp.g_varchar2_table(1273) := '41967, 36.96453, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE';
wwv_flow_imp.g_varchar2_table(1274) := ',AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND';
wwv_flow_imp.g_varchar2_table(1275) := '_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6814,''CVG'',''AIRPORT'',''CINCINNATI/NORTHER';
wwv_flow_imp.g_varchar2_table(1276) := 'N KENTUCKY INTL'',''COVINGTON'',''KENTUCKY'',''Dec-44'',to_timestamp(''01.12.1944 00:00:00'',''DD.MM.RR HH24:M';
wwv_flow_imp.g_varchar2_table(1277) := 'I:SSXFF''),896,8,7000,130690,26602,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-84.66782, 39.';
wwv_flow_imp.g_varchar2_table(1278) := '04884, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_N';
wwv_flow_imp.g_varchar2_table(1279) := 'AME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVE';
wwv_flow_imp.g_varchar2_table(1280) := 'RED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6896,''LEX'',''AIRPORT'',''BLUE GRASS'',''LEXINGTON'',''KEN';
wwv_flow_imp.g_varchar2_table(1281) := 'TUCKY'',''Jul-44'',to_timestamp(''01.07.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),979,4,911,15921,16094,M';
wwv_flow_imp.g_varchar2_table(1282) := 'DSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-84.60864, 38.03675, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert ';
wwv_flow_imp.g_varchar2_table(1283) := 'into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(1284) := ',ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEO';
wwv_flow_imp.g_varchar2_table(1285) := 'METRY) values (6911,''SDF'',''AIRPORT'',''LOUISVILLE MUHAMMAD ALI INTL'',''LOUISVILLE'',''KENTUCKY'',''Nov-42'',';
wwv_flow_imp.g_varchar2_table(1286) := 'to_timestamp(''01.11.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),501,4,1200,132315,25066,MDSYS.SDO_GEOME';
wwv_flow_imp.g_varchar2_table(1287) := 'TRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-85.7365, 38.17409, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE';
wwv_flow_imp.g_varchar2_table(1288) := '_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DAT';
wwv_flow_imp.g_varchar2_table(1289) := 'E_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (';
wwv_flow_imp.g_varchar2_table(1290) := '6959,''OWB'',''AIRPORT'',''OWENSBORO-DAVIESS COUNTY RGNL'',''OWENSBORO'',''KENTUCKY'',''Dec-49'',to_timestamp(''0';
wwv_flow_imp.g_varchar2_table(1291) := '1.12.1949 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),407,3,880,232,2795,MDSYS.SDO_GEOMETRY(2001, 4326, MDSY';
wwv_flow_imp.g_varchar2_table(1292) := 'S.SDO_POINT_TYPE(-87.16683, 37.73883, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,I';
wwv_flow_imp.g_varchar2_table(1293) := 'ATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST';
wwv_flow_imp.g_varchar2_table(1294) := '_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (6963,''PAH'',''AIRPORT';
wwv_flow_imp.g_varchar2_table(1295) := ''',''BARKLEY RGNL'',''PADUCAH'',''KENTUCKY'',''Jan-43'',to_timestamp(''01.01.1943 00:00:00'',''DD.MM.RR HH24:MI:';
wwv_flow_imp.g_varchar2_table(1296) := 'SSXFF''),411,12,1018,1386,1854,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-88.77296, 37.0602';
wwv_flow_imp.g_varchar2_table(1297) := '9, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,';
wwv_flow_imp.g_varchar2_table(1298) := 'CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,';
wwv_flow_imp.g_varchar2_table(1299) := 'COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7039,''AEX'',''AIRPORT'',''ALEXANDRIA INTL'',''ALEXANDRIA'',''L';
wwv_flow_imp.g_varchar2_table(1300) := 'OUISIANA'',''Feb-44'',to_timestamp(''01.02.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),89,4,3212,2477,6777,';
wwv_flow_imp.g_varchar2_table(1301) := 'MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-92.54856, 31.32737, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert';
wwv_flow_imp.g_varchar2_table(1302) := ' into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DAT';
wwv_flow_imp.g_varchar2_table(1303) := 'E,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GE';
wwv_flow_imp.g_varchar2_table(1304) := 'OMETRY) values (7068,''21LA'',''AIRPORT'',''SOUTHERN HELICOPTERS'',''BATON ROUGE'',''LOUISIANA'',''Jun-97'',to_t';
wwv_flow_imp.g_varchar2_table(1305) := 'imestamp(''01.06.1997 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),28,15,null,1,null,MDSYS.SDO_GEOMETRY(2001, ';
wwv_flow_imp.g_varchar2_table(1306) := '4326, MDSYS.SDO_POINT_TYPE(-91.215, 30.29694, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPOR';
wwv_flow_imp.g_varchar2_table(1307) := 'TS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVAT';
wwv_flow_imp.g_varchar2_table(1308) := 'ION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7079,''BTR'',';
wwv_flow_imp.g_varchar2_table(1309) := '''AIRPORT'',''BATON ROUGE METROPOLITAN, RYAN FIELD'',''BATON ROUGE'',''LOUISIANA'',''Jun-42'',to_timestamp(''01';
wwv_flow_imp.g_varchar2_table(1310) := '.06.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),70,4,1250,11908,7288,MDSYS.SDO_GEOMETRY(2001, 4326, MDS';
wwv_flow_imp.g_varchar2_table(1311) := 'YS.SDO_POINT_TYPE(-91.14989, 30.53292, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,';
wwv_flow_imp.g_varchar2_table(1312) := 'IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIS';
wwv_flow_imp.g_varchar2_table(1313) := 'T_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7284,''LFT'',''AIRPOR';
wwv_flow_imp.g_varchar2_table(1314) := 'T'',''LAFAYETTE RGNL/PAUL FOURNET FIELD'',''LAFAYETTE'',''LOUISIANA'',''Apr-40'',to_timestamp(''01.04.1940 00:';
wwv_flow_imp.g_varchar2_table(1315) := '00:00'',''DD.MM.RR HH24:MI:SSXFF''),42,2,746,4237,13264,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_';
wwv_flow_imp.g_varchar2_table(1316) := 'TYPE(-91.98775, 30.20503, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIR';
wwv_flow_imp.g_varchar2_table(1317) := 'PORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIR';
wwv_flow_imp.g_varchar2_table(1318) := 'PORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7296,''LCH'',''AIRPORT'',''LAKE CHAR';
wwv_flow_imp.g_varchar2_table(1319) := 'LES RGNL'',''LAKE CHARLES'',''LOUISIANA'',''Nov-61'',to_timestamp(''01.11.1961 00:00:00'',''DD.MM.RR HH24:MI:S';
wwv_flow_imp.g_varchar2_table(1320) := 'SXFF''),15,5,1878,19,8393,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-93.22342, 30.12608, NU';
wwv_flow_imp.g_varchar2_table(1321) := 'LL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,';
wwv_flow_imp.g_varchar2_table(1322) := 'STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMME';
wwv_flow_imp.g_varchar2_table(1323) := 'RCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7307,''CWF'',''AIRPORT'',''CHENNAULT INTL'',''LAKE CHARLES'',''LOUIS';
wwv_flow_imp.g_varchar2_table(1324) := 'IANA'',''Jan-64'',to_timestamp(''01.01.1964 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),17,4,1310,150,1040,MDSYS';
wwv_flow_imp.g_varchar2_table(1325) := '.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-93.14319, 30.21058, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into';
wwv_flow_imp.g_varchar2_table(1326) := ' EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACT';
wwv_flow_imp.g_varchar2_table(1327) := 'IVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETR';
wwv_flow_imp.g_varchar2_table(1328) := 'Y) values (7350,''MLU'',''AIRPORT'',''MONROE RGNL'',''MONROE'',''LOUISIANA'',''Apr-40'',to_timestamp(''01.04.1940';
wwv_flow_imp.g_varchar2_table(1329) := ' 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),79,3,2660,1220,5488,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_PO';
wwv_flow_imp.g_varchar2_table(1330) := 'INT_TYPE(-92.03767, 32.51086, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE';
wwv_flow_imp.g_varchar2_table(1331) := ',AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO';
wwv_flow_imp.g_varchar2_table(1332) := '_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7374,''ARA'',''AIRPORT'',''ACADI';
wwv_flow_imp.g_varchar2_table(1333) := 'ANA RGNL'',''NEW IBERIA'',''LOUISIANA'',''Feb-44'',to_timestamp(''01.02.1944 00:00:00'',''DD.MM.RR HH24:MI:SSX';
wwv_flow_imp.g_varchar2_table(1334) := 'FF''),24,4,2328,120,20034,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-91.8839, 30.03776, NUL';
wwv_flow_imp.g_varchar2_table(1335) := 'L), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,S';
wwv_flow_imp.g_varchar2_table(1336) := 'TATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMER';
wwv_flow_imp.g_varchar2_table(1337) := 'CIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7384,''MSY'',''AIRPORT'',''LOUIS ARMSTRONG NEW ORLEANS INTL'',''NEW';
wwv_flow_imp.g_varchar2_table(1338) := ' ORLEANS'',''LOUISIANA'',''Oct-44'',to_timestamp(''01.10.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4,10,150';
wwv_flow_imp.g_varchar2_table(1339) := '0,117292,7493,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-90.25903, 29.99328, NULL), NULL, ';
wwv_flow_imp.g_varchar2_table(1340) := 'NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,';
wwv_flow_imp.g_varchar2_table(1341) := 'ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,A';
wwv_flow_imp.g_varchar2_table(1342) := 'IR_TAXI_OPS,GEOMETRY) values (7449,''SHV'',''AIRPORT'',''SHREVEPORT RGNL'',''SHREVEPORT'',''LOUISIANA'',''Aug-5';
wwv_flow_imp.g_varchar2_table(1343) := '2'',to_timestamp(''01.08.1952 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),258,4,1625,8777,11718,MDSYS.SDO_GEOM';
wwv_flow_imp.g_varchar2_table(1344) := 'ETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-93.82603, 32.44653, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMP';
wwv_flow_imp.g_varchar2_table(1345) := 'LE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(1346) := 'ATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values';
wwv_flow_imp.g_varchar2_table(1347) := ' (7543,''BED'',''AIRPORT'',''LAURENCE G HANSCOM FLD'',''BEDFORD'',''MASSACHUSETTS'',''Apr-43'',to_timestamp(''01.';
wwv_flow_imp.g_varchar2_table(1348) := '04.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),132,0,1125,295,22488,MDSYS.SDO_GEOMETRY(2001, 4326, MDSY';
wwv_flow_imp.g_varchar2_table(1349) := 'S.SDO_POINT_TYPE(-71.289, 42.46994, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IAT';
wwv_flow_imp.g_varchar2_table(1350) := 'A_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_C';
wwv_flow_imp.g_varchar2_table(1351) := 'ITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7548,''BVY'',''AIRPORT'',';
wwv_flow_imp.g_varchar2_table(1352) := '''BEVERLY RGNL'',''BEVERLY'',''MASSACHUSETTS'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:';
wwv_flow_imp.g_varchar2_table(1353) := 'MI:SSXFF''),107,3,470,0,1942,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-70.91614, 42.58414,';
wwv_flow_imp.g_varchar2_table(1354) := ' NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CI';
wwv_flow_imp.g_varchar2_table(1355) := 'TY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,CO';
wwv_flow_imp.g_varchar2_table(1356) := 'MMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7551,''BOS'',''AIRPORT'',''GENERAL EDWARD LAWRENCE LOGAN INTL';
wwv_flow_imp.g_varchar2_table(1357) := ''',''BOSTON'',''MASSACHUSETTS'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),19,';
wwv_flow_imp.g_varchar2_table(1358) := '1,2384,317685,77625,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-71.00639, 42.36294, NULL), ';
wwv_flow_imp.g_varchar2_table(1359) := 'NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE';
wwv_flow_imp.g_varchar2_table(1360) := '_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL';
wwv_flow_imp.g_varchar2_table(1361) := '_OPS,AIR_TAXI_OPS,GEOMETRY) values (7618,''HYA'',''AIRPORT'',''BARNSTABLE MUNI-BOARDMAN/POLANDO FIELD'',''H';
wwv_flow_imp.g_varchar2_table(1362) := 'YANNIS'',''MASSACHUSETTS'',''Feb-40'',to_timestamp(''01.02.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),54,1,6';
wwv_flow_imp.g_varchar2_table(1363) := '39,183,32956,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-70.28036, 41.66933, NULL), NULL, N';
wwv_flow_imp.g_varchar2_table(1364) := 'ULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,A';
wwv_flow_imp.g_varchar2_table(1365) := 'CTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AI';
wwv_flow_imp.g_varchar2_table(1366) := 'R_TAXI_OPS,GEOMETRY) values (7657,''ACK'',''AIRPORT'',''NANTUCKET MEMORIAL'',''NANTUCKET'',''MASSACHUSETTS'',''';
wwv_flow_imp.g_varchar2_table(1367) := 'Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),47,3,1200,1725,41357,MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(1368) := 'GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-70.05991, 41.25298, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_';
wwv_flow_imp.g_varchar2_table(1369) := 'SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATI';
wwv_flow_imp.g_varchar2_table(1370) := 'ON_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) va';
wwv_flow_imp.g_varchar2_table(1371) := 'lues (7663,''EWB'',''AIRPORT'',''NEW BEDFORD RGNL'',''NEW BEDFORD'',''MASSACHUSETTS'',''Apr-42'',to_timestamp(''0';
wwv_flow_imp.g_varchar2_table(1372) := '1.04.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),79,2,847,0,5047,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.S';
wwv_flow_imp.g_varchar2_table(1373) := 'DO_POINT_TYPE(-70.95784, 41.67657, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA';
wwv_flow_imp.g_varchar2_table(1374) := '_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CI';
wwv_flow_imp.g_varchar2_table(1375) := 'TY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7690,''PVC'',''AIRPORT'',''';
wwv_flow_imp.g_varchar2_table(1376) := 'PROVINCETOWN MUNI'',''PROVINCETOWN'',''MASSACHUSETTS'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM';
wwv_flow_imp.g_varchar2_table(1377) := '.RR HH24:MI:SSXFF''),8,2,310,4400,950,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-70.22072, ';
wwv_flow_imp.g_varchar2_table(1378) := '42.07228, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPOR';
wwv_flow_imp.g_varchar2_table(1379) := 'T_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_C';
wwv_flow_imp.g_varchar2_table(1380) := 'OVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7711,''CEF'',''AIRPORT'',''WESTOVER ARB/METROPOLITAN';
wwv_flow_imp.g_varchar2_table(1381) := ''',''SPRINGFIELD/CHICOPEE'',''MASSACHUSETTS'',''Jul-42'',to_timestamp(''01.07.1942 00:00:00'',''DD.MM.RR HH24:';
wwv_flow_imp.g_varchar2_table(1382) := 'MI:SSXFF''),241,3,2500,538,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-72.53478, 42.194';
wwv_flow_imp.g_varchar2_table(1383) := '01, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME';
wwv_flow_imp.g_varchar2_table(1384) := ',CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED';
wwv_flow_imp.g_varchar2_table(1385) := ',COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7726,''MVY'',''AIRPORT'',''MARTHA''''S VINEYARD'',''VINEYARD H';
wwv_flow_imp.g_varchar2_table(1386) := 'AVEN'',''MASSACHUSETTS'',''Jul-74'',to_timestamp(''01.07.1974 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),67,3,688';
wwv_flow_imp.g_varchar2_table(1387) := ',999,16340,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-70.61387, 41.39342, NULL), NULL, NUL';
wwv_flow_imp.g_varchar2_table(1388) := 'L));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACT';
wwv_flow_imp.g_varchar2_table(1389) := 'IVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_';
wwv_flow_imp.g_varchar2_table(1390) := 'TAXI_OPS,GEOMETRY) values (7738,''BAF'',''AIRPORT'',''WESTFIELD-BARNES RGNL'',''WESTFIELD/SPRINGFIELD'',''MAS';
wwv_flow_imp.g_varchar2_table(1391) := 'SACHUSETTS'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),270,3,1200,20,723,';
wwv_flow_imp.g_varchar2_table(1392) := 'MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-72.71586, 42.15794, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert';
wwv_flow_imp.g_varchar2_table(1393) := ' into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DAT';
wwv_flow_imp.g_varchar2_table(1394) := 'E,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GE';
wwv_flow_imp.g_varchar2_table(1395) := 'OMETRY) values (7752,''ORH'',''AIRPORT'',''WORCESTER RGNL'',''WORCESTER'',''MASSACHUSETTS'',''Feb-46'',to_timest';
wwv_flow_imp.g_varchar2_table(1396) := 'amp(''01.02.1946 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1009,3,1000,2467,2121,MDSYS.SDO_GEOMETRY(2001, 4';
wwv_flow_imp.g_varchar2_table(1397) := '326, MDSYS.SDO_POINT_TYPE(-71.87561, 42.26714, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPO';
wwv_flow_imp.g_varchar2_table(1398) := 'RTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVA';
wwv_flow_imp.g_varchar2_table(1399) := 'TION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7764,''MTN''';
wwv_flow_imp.g_varchar2_table(1400) := ',''AIRPORT'',''MARTIN STATE'',''BALTIMORE'',''MARYLAND'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.';
wwv_flow_imp.g_varchar2_table(1401) := 'RR HH24:MI:SSXFF''),22,9,747,6,2683,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-76.41378, 39';
wwv_flow_imp.g_varchar2_table(1402) := '.32567, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(1403) := 'NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COV';
wwv_flow_imp.g_varchar2_table(1404) := 'ERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7775,''BWI'',''AIRPORT'',''BALTIMORE/WASHINGTON INTL T';
wwv_flow_imp.g_varchar2_table(1405) := 'HURGOOD MARSHALL'',''BALTIMORE'',''MARYLAND'',''Jan-50'',to_timestamp(''01.01.1950 00:00:00'',''DD.MM.RR HH24:';
wwv_flow_imp.g_varchar2_table(1406) := 'MI:SSXFF''),143,9,3160,221775,31508,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-76.66899, 39';
wwv_flow_imp.g_varchar2_table(1407) := '.17573, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(1408) := 'NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COV';
wwv_flow_imp.g_varchar2_table(1409) := 'ERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7853,''FDK'',''AIRPORT'',''FREDERICK MUNI'',''FREDERICK''';
wwv_flow_imp.g_varchar2_table(1410) := ',''MARYLAND'',''Dec-03'',to_timestamp(''01.12.2003 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),306,0,616,2,2375,M';
wwv_flow_imp.g_varchar2_table(1411) := 'DSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-77.3743, 39.41757, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert i';
wwv_flow_imp.g_varchar2_table(1412) := 'nto EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,';
wwv_flow_imp.g_varchar2_table(1413) := 'ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOM';
wwv_flow_imp.g_varchar2_table(1414) := 'ETRY) values (7866,''HGR'',''AIRPORT'',''HAGERSTOWN RGNL-RICHARD A HENSON FLD'',''HAGERSTOWN'',''MARYLAND'',''A';
wwv_flow_imp.g_varchar2_table(1415) := 'pr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),703,4,693,277,4378,MDSYS.SDO_GEO';
wwv_flow_imp.g_varchar2_table(1416) := 'METRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-77.7265, 39.7085, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPL';
wwv_flow_imp.g_varchar2_table(1417) := 'E_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DA';
wwv_flow_imp.g_varchar2_table(1418) := 'TE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values ';
wwv_flow_imp.g_varchar2_table(1419) := '(7917,''2G4'',''AIRPORT'',''GARRETT COUNTY'',''OAKLAND'',''MARYLAND'',''May-62'',to_timestamp(''01.05.1962 00:00:';
wwv_flow_imp.g_varchar2_table(1420) := '00'',''DD.MM.RR HH24:MI:SSXFF''),2933,13,284,0,325,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(';
wwv_flow_imp.g_varchar2_table(1421) := '-79.33594, 39.58081, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(1422) := 'TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,';
wwv_flow_imp.g_varchar2_table(1423) := 'LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (7992,''BGR'',''AIRPORT'',''BANGOR INTL'',''';
wwv_flow_imp.g_varchar2_table(1424) := 'BANGOR'',''MAINE'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),192,3,2079,561';
wwv_flow_imp.g_varchar2_table(1425) := '0,11555,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-68.82814, 44.80744, NULL), NULL, NULL))';
wwv_flow_imp.g_varchar2_table(1426) := ';'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVA';
wwv_flow_imp.g_varchar2_table(1427) := 'TION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAX';
wwv_flow_imp.g_varchar2_table(1428) := 'I_OPS,GEOMETRY) values (7995,''BHB'',''AIRPORT'',''HANCOCK COUNTY-BAR HARBOR'',''BAR HARBOR'',''MAINE'',''Apr-4';
wwv_flow_imp.g_varchar2_table(1429) := '0'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),83,8,468,1600,1500,MDSYS.SDO_GEOMETR';
wwv_flow_imp.g_varchar2_table(1430) := 'Y(2001, 4326, MDSYS.SDO_POINT_TYPE(-68.36149, 44.44971, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_';
wwv_flow_imp.g_varchar2_table(1431) := 'MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(1432) := '_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8';
wwv_flow_imp.g_varchar2_table(1433) := '144,''PWM'',''AIRPORT'',''PORTLAND INTL JETPORT'',''PORTLAND'',''MAINE'',''Apr-40'',to_timestamp(''01.04.1940 00:';
wwv_flow_imp.g_varchar2_table(1434) := '00:00'',''DD.MM.RR HH24:MI:SSXFF''),76,2,726,19597,16508,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT';
wwv_flow_imp.g_varchar2_table(1435) := '_TYPE(-70.30862, 43.64564, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AI';
wwv_flow_imp.g_varchar2_table(1436) := 'RPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AI';
wwv_flow_imp.g_varchar2_table(1437) := 'RPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8146,''PQI'',''AIRPORT'',''PRESQUE ';
wwv_flow_imp.g_varchar2_table(1438) := 'ISLE INTL'',''PRESQUE ISLE'',''MAINE'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXF';
wwv_flow_imp.g_varchar2_table(1439) := 'F''),534,1,1489,1324,3976,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-68.04479, 46.68896, NU';
wwv_flow_imp.g_varchar2_table(1440) := 'LL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,';
wwv_flow_imp.g_varchar2_table(1441) := 'STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMME';
wwv_flow_imp.g_varchar2_table(1442) := 'RCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8153,''RKD'',''AIRPORT'',''KNOX COUNTY RGNL'',''ROCKLAND'',''MAINE'',';
wwv_flow_imp.g_varchar2_table(1443) := '''Feb-43'',to_timestamp(''01.02.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),55,3,538,2812,9903,MDSYS.SDO_G';
wwv_flow_imp.g_varchar2_table(1444) := 'EOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-69.09967, 44.06014, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_S';
wwv_flow_imp.g_varchar2_table(1445) := 'AMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(1446) := 'N_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) val';
wwv_flow_imp.g_varchar2_table(1447) := 'ues (8206,''APN'',''AIRPORT'',''ALPENA COUNTY RGNL'',''ALPENA'',''MICHIGAN'',''Apr-40'',to_timestamp(''01.04.1940';
wwv_flow_imp.g_varchar2_table(1448) := ' 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),690,6,3084,1540,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_P';
wwv_flow_imp.g_varchar2_table(1449) := 'OINT_TYPE(-83.56031, 45.07808, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_COD';
wwv_flow_imp.g_varchar2_table(1450) := 'E,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_T';
wwv_flow_imp.g_varchar2_table(1451) := 'O_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8222,''BTL'',''AIRPORT'',''BATT';
wwv_flow_imp.g_varchar2_table(1452) := 'LE CREEK EXECUTIVE AT KELLOGG FIELD'',''BATTLE CREEK'',''MICHIGAN'',''Apr-40'',to_timestamp(''01.04.1940 00:';
wwv_flow_imp.g_varchar2_table(1453) := '00:00'',''DD.MM.RR HH24:MI:SSXFF''),952,3,1500,38,1208,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_T';
wwv_flow_imp.g_varchar2_table(1454) := 'YPE(-85.25009, 42.30647, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRP';
wwv_flow_imp.g_varchar2_table(1455) := 'ORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRP';
wwv_flow_imp.g_varchar2_table(1456) := 'ORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8262,''CVX'',''AIRPORT'',''CHARLEVOIX';
wwv_flow_imp.g_varchar2_table(1457) := ' MUNI'',''CHARLEVOIX'',''MICHIGAN'',''Mar-45'',to_timestamp(''01.03.1945 00:00:00'',''DD.MM.RR HH24:MI:SSXFF'')';
wwv_flow_imp.g_varchar2_table(1458) := ',669,1,185,0,12000,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-85.27531, 45.30486, NULL), N';
wwv_flow_imp.g_varchar2_table(1459) := 'ULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_';
wwv_flow_imp.g_varchar2_table(1460) := 'NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_';
wwv_flow_imp.g_varchar2_table(1461) := 'OPS,AIR_TAXI_OPS,GEOMETRY) values (8296,''DET'',''AIRPORT'',''COLEMAN A YOUNG MUNI'',''DETROIT'',''MICHIGAN'',';
wwv_flow_imp.g_varchar2_table(1462) := '''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),626,5,264,4,2114,MDSYS.SDO_GEO';
wwv_flow_imp.g_varchar2_table(1463) := 'METRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-83.01018, 42.40933, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAM';
wwv_flow_imp.g_varchar2_table(1464) := 'PLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_';
wwv_flow_imp.g_varchar2_table(1465) := 'DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) value';
wwv_flow_imp.g_varchar2_table(1466) := 's (8303,''DTW'',''AIRPORT'',''DETROIT METROPOLITAN WAYNE COUNTY'',''DETROIT'',''MICHIGAN'',''Apr-40'',to_timesta';
wwv_flow_imp.g_varchar2_table(1467) := 'mp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),645,15,4850,315995,71412,MDSYS.SDO_GEOMETRY(2001,';
wwv_flow_imp.g_varchar2_table(1468) := ' 4326, MDSYS.SDO_POINT_TYPE(-83.35339, 42.21244, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIR';
wwv_flow_imp.g_varchar2_table(1469) := 'PORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELE';
wwv_flow_imp.g_varchar2_table(1470) := 'VATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8304,''YI';
wwv_flow_imp.g_varchar2_table(1471) := 'P'',''AIRPORT'',''WILLOW RUN'',''DETROIT'',''MICHIGAN'',''Dec-42'',to_timestamp(''01.12.1942 00:00:00'',''DD.MM.RR';
wwv_flow_imp.g_varchar2_table(1472) := ' HH24:MI:SSXFF''),716,24,2600,3604,7829,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-83.53089';
wwv_flow_imp.g_varchar2_table(1473) := ', 42.24003, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRP';
wwv_flow_imp.g_varchar2_table(1474) := 'ORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA';
wwv_flow_imp.g_varchar2_table(1475) := '_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8314,''D22'',''SEAPLANE BASE'',''YACHT HAVEN'',''DRU';
wwv_flow_imp.g_varchar2_table(1476) := 'MMOND ISLAND'',''MICHIGAN'',''Feb-12'',to_timestamp(''01.02.2012 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),580,1';
wwv_flow_imp.g_varchar2_table(1477) := ',null,0,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-83.75251, 46.02479, NULL), NULL, NULL';
wwv_flow_imp.g_varchar2_table(1478) := '));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTI';
wwv_flow_imp.g_varchar2_table(1479) := 'VATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_T';
wwv_flow_imp.g_varchar2_table(1480) := 'AXI_OPS,GEOMETRY) values (8327,''ESC'',''AIRPORT'',''DELTA COUNTY'',''ESCANABA'',''MICHIGAN'',''Apr-40'',to_time';
wwv_flow_imp.g_varchar2_table(1481) := 'stamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),609,2,944,1260,7476,MDSYS.SDO_GEOMETRY(2001, 4';
wwv_flow_imp.g_varchar2_table(1482) := '326, MDSYS.SDO_POINT_TYPE(-87.09372, 45.72267, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPO';
wwv_flow_imp.g_varchar2_table(1483) := 'RTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVA';
wwv_flow_imp.g_varchar2_table(1484) := 'TION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8334,''FNT''';
wwv_flow_imp.g_varchar2_table(1485) := ',''AIRPORT'',''BISHOP INTL'',''FLINT'',''MICHIGAN'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH';
wwv_flow_imp.g_varchar2_table(1486) := '24:MI:SSXFF''),782,3,1550,5785,7057,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-83.74475, 42';
wwv_flow_imp.g_varchar2_table(1487) := '.96547, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(1488) := 'NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COV';
wwv_flow_imp.g_varchar2_table(1489) := 'ERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8353,''3GM'',''AIRPORT'',''GRAND HAVEN MEMORIAL AIRPAR';
wwv_flow_imp.g_varchar2_table(1490) := 'K'',''GRAND HAVEN'',''MICHIGAN'',''Aug-49'',to_timestamp(''01.08.1949 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),60';
wwv_flow_imp.g_varchar2_table(1491) := '4,2,280,0,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-86.19817, 43.03406, NULL), NULL,';
wwv_flow_imp.g_varchar2_table(1492) := ' NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME';
wwv_flow_imp.g_varchar2_table(1493) := ',ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,';
wwv_flow_imp.g_varchar2_table(1494) := 'AIR_TAXI_OPS,GEOMETRY) values (8361,''GRR'',''AIRPORT'',''GERALD R FORD INTL'',''GRAND RAPIDS'',''MICHIGAN'',''';
wwv_flow_imp.g_varchar2_table(1495) := 'May-63'',to_timestamp(''01.05.1963 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),794,6,3127,30975,15821,MDSYS.SD';
wwv_flow_imp.g_varchar2_table(1496) := 'O_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-85.52281, 42.88083, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EB';
wwv_flow_imp.g_varchar2_table(1497) := 'A_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVA';
wwv_flow_imp.g_varchar2_table(1498) := 'TION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) ';
wwv_flow_imp.g_varchar2_table(1499) := 'values (8374,''CMX'',''AIRPORT'',''HOUGHTON COUNTY MEMORIAL'',''HANCOCK'',''MICHIGAN'',null,null,1095,4,1996,3';
wwv_flow_imp.g_varchar2_table(1500) := '000,2164,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-88.48906, 47.16842, NULL), NULL, NULL)';
null;
end;
/
begin
wwv_flow_imp.g_varchar2_table(1501) := ');'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIV';
wwv_flow_imp.g_varchar2_table(1502) := 'ATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TA';
wwv_flow_imp.g_varchar2_table(1503) := 'XI_OPS,GEOMETRY) values (8411,''IMT'',''AIRPORT'',''FORD'',''IRON MOUNTAIN KINGSFORD'',''MICHIGAN'',''Apr-40'',t';
wwv_flow_imp.g_varchar2_table(1504) := 'o_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1182,3,720,1440,4316,MDSYS.SDO_GEOMETRY(';
wwv_flow_imp.g_varchar2_table(1505) := '2001, 4326, MDSYS.SDO_POINT_TYPE(-88.11456, 45.81836, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MA';
wwv_flow_imp.g_varchar2_table(1506) := 'P_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_D';
wwv_flow_imp.g_varchar2_table(1507) := 'T,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (841';
wwv_flow_imp.g_varchar2_table(1508) := '4,''IWD'',''AIRPORT'',''GOGEBIC-IRON COUNTY'',''IRONWOOD'',''MICHIGAN'',''Apr-40'',to_timestamp(''01.04.1940 00:0';
wwv_flow_imp.g_varchar2_table(1509) := '0:00'',''DD.MM.RR HH24:MI:SSXFF''),1230,7,1180,1706,500,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_';
wwv_flow_imp.g_varchar2_table(1510) := 'TYPE(-90.13139, 46.52747, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIR';
wwv_flow_imp.g_varchar2_table(1511) := 'PORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIR';
wwv_flow_imp.g_varchar2_table(1512) := 'PORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8425,''AZO'',''AIRPORT'',''KALAMAZOO';
wwv_flow_imp.g_varchar2_table(1513) := '/BATTLE CREEK INTL'',''KALAMAZOO'',''MICHIGAN'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH2';
wwv_flow_imp.g_varchar2_table(1514) := '4:MI:SSXFF''),874,3,832,1362,6945,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-85.55156, 42.2';
wwv_flow_imp.g_varchar2_table(1515) := '3439, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NA';
wwv_flow_imp.g_varchar2_table(1516) := 'ME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVER';
wwv_flow_imp.g_varchar2_table(1517) := 'ED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8436,''LAN'',''AIRPORT'',''CAPITAL REGION INTL'',''LANSING';
wwv_flow_imp.g_varchar2_table(1518) := ''',''MICHIGAN'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),861,3,2160,2396,1';
wwv_flow_imp.g_varchar2_table(1519) := '4446,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-84.58619, 42.77864, NULL), NULL, NULL));'||wwv_flow.LF||
'I';
wwv_flow_imp.g_varchar2_table(1520) := 'nsert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(1521) := 'N_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_O';
wwv_flow_imp.g_varchar2_table(1522) := 'PS,GEOMETRY) values (8460,''MBL'',''AIRPORT'',''MANISTEE CO-BLACKER'',''MANISTEE'',''MICHIGAN'',''Apr-40'',to_ti';
wwv_flow_imp.g_varchar2_table(1523) := 'mestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),621,3,290,1000,250,MDSYS.SDO_GEOMETRY(2001, ';
wwv_flow_imp.g_varchar2_table(1524) := '4326, MDSYS.SDO_POINT_TYPE(-86.24689, 44.27247, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRP';
wwv_flow_imp.g_varchar2_table(1525) := 'ORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEV';
wwv_flow_imp.g_varchar2_table(1526) := 'ATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8470,''SAW';
wwv_flow_imp.g_varchar2_table(1527) := ''',''AIRPORT'',''SAWYER INTL'',''MARQUETTE'',''MICHIGAN'',null,null,1205,17,2100,2219,5304,MDSYS.SDO_GEOMETRY';
wwv_flow_imp.g_varchar2_table(1528) := '(2001, 4326, MDSYS.SDO_POINT_TYPE(-87.39637, 46.34916, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_M';
wwv_flow_imp.g_varchar2_table(1529) := 'AP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_';
wwv_flow_imp.g_varchar2_table(1530) := 'DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (85';
wwv_flow_imp.g_varchar2_table(1531) := '01,''MKG'',''AIRPORT'',''MUSKEGON COUNTY'',''MUSKEGON'',''MICHIGAN'',''Apr-40'',to_timestamp(''01.04.1940 00:00:0';
wwv_flow_imp.g_varchar2_table(1532) := '0'',''DD.MM.RR HH24:MI:SSXFF''),629,4,1200,76,2141,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(';
wwv_flow_imp.g_varchar2_table(1533) := '-86.23544, 43.16767, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(1534) := 'TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,';
wwv_flow_imp.g_varchar2_table(1535) := 'LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8510,''6Y5'',''AIRPORT'',''TWO HEARTED AI';
wwv_flow_imp.g_varchar2_table(1536) := 'RSTRIP'',''NEWBERRY'',''MICHIGAN'',''Mar-18'',to_timestamp(''01.03.2018 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),';
wwv_flow_imp.g_varchar2_table(1537) := '680,20,5,0,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-85.4221, 46.69335, NULL), NULL, NU';
wwv_flow_imp.g_varchar2_table(1538) := 'LL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,AC';
wwv_flow_imp.g_varchar2_table(1539) := 'TIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR';
wwv_flow_imp.g_varchar2_table(1540) := '_TAXI_OPS,GEOMETRY) values (8543,''PLN'',''AIRPORT'',''PELLSTON RGNL AIRPORT OF EMMET COUNTY'',''PELLSTON'',';
wwv_flow_imp.g_varchar2_table(1541) := '''MICHIGAN'',''Mar-41'',to_timestamp(''01.03.1941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),721,1,1675,2104,0,M';
wwv_flow_imp.g_varchar2_table(1542) := 'DSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-84.79672, 45.57092, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert ';
wwv_flow_imp.g_varchar2_table(1543) := 'into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(1544) := ',ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEO';
wwv_flow_imp.g_varchar2_table(1545) := 'METRY) values (8555,''PTK'',''AIRPORT'',''OAKLAND COUNTY INTL'',''PONTIAC'',''MICHIGAN'',''Apr-40'',to_timestamp';
wwv_flow_imp.g_varchar2_table(1546) := '(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),981,5,750,571,10406,MDSYS.SDO_GEOMETRY(2001, 4326, ';
wwv_flow_imp.g_varchar2_table(1547) := 'MDSYS.SDO_POINT_TYPE(-83.42051, 42.66564, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (';
wwv_flow_imp.g_varchar2_table(1548) := 'ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,';
wwv_flow_imp.g_varchar2_table(1549) := 'DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8561,''M86'',''AIR';
wwv_flow_imp.g_varchar2_table(1550) := 'PORT'',''WALLE FIELD'',''PULLMAN'',''MICHIGAN'',''Oct-90'',to_timestamp(''01.10.1990 00:00:00'',''DD.MM.RR HH24:';
wwv_flow_imp.g_varchar2_table(1551) := 'MI:SSXFF''),635,2,80,0,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-86.12564, 42.47097, NUL';
wwv_flow_imp.g_varchar2_table(1552) := 'L), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,S';
wwv_flow_imp.g_varchar2_table(1553) := 'TATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMER';
wwv_flow_imp.g_varchar2_table(1554) := 'CIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8581,''MBS'',''AIRPORT'',''MBS INTL'',''SAGINAW'',''MICHIGAN'',''Mar-43';
wwv_flow_imp.g_varchar2_table(1555) := ''',to_timestamp(''01.03.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),668,9,3200,1133,5902,MDSYS.SDO_GEOMET';
wwv_flow_imp.g_varchar2_table(1556) := 'RY(2001, 4326, MDSYS.SDO_POINT_TYPE(-84.07964, 43.53293, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE';
wwv_flow_imp.g_varchar2_table(1557) := '_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DAT';
wwv_flow_imp.g_varchar2_table(1558) := 'E_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (';
wwv_flow_imp.g_varchar2_table(1559) := '8597,''CIU'',''AIRPORT'',''CHIPPEWA COUNTY INTL'',''SAULT STE MARIE'',''MICHIGAN'',null,null,799,15,1850,1424,';
wwv_flow_imp.g_varchar2_table(1560) := '1180,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-84.47238, 46.25075, NULL), NULL, NULL));'||wwv_flow.LF||
'I';
wwv_flow_imp.g_varchar2_table(1561) := 'nsert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(1562) := 'N_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_O';
wwv_flow_imp.g_varchar2_table(1563) := 'PS,GEOMETRY) values (8629,''TVC'',''AIRPORT'',''CHERRY CAPITAL'',''TRAVERSE CITY'',''MICHIGAN'',''Apr-40'',to_ti';
wwv_flow_imp.g_varchar2_table(1564) := 'mestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),624,2,1026,9979,7868,MDSYS.SDO_GEOMETRY(2001';
wwv_flow_imp.g_varchar2_table(1565) := ', 4326, MDSYS.SDO_POINT_TYPE(-85.58186, 44.74158, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AI';
wwv_flow_imp.g_varchar2_table(1566) := 'RPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,EL';
wwv_flow_imp.g_varchar2_table(1567) := 'EVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8708,''B';
wwv_flow_imp.g_varchar2_table(1568) := 'JI'',''AIRPORT'',''BEMIDJI RGNL'',''BEMIDJI'',''MINNESOTA'',''Sep-46'',to_timestamp(''01.09.1946 00:00:00'',''DD.M';
wwv_flow_imp.g_varchar2_table(1569) := 'M.RR HH24:MI:SSXFF''),1391,3,1740,1514,2101,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-94.9';
wwv_flow_imp.g_varchar2_table(1570) := '3472, 47.51072, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,';
wwv_flow_imp.g_varchar2_table(1571) := 'AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_';
wwv_flow_imp.g_varchar2_table(1572) := 'AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8729,''BRD'',''AIRPORT'',''BRAINERD LAKES RGNL';
wwv_flow_imp.g_varchar2_table(1573) := ''',''BRAINERD'',''MINNESOTA'',''Oct-48'',to_timestamp(''01.10.1948 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1232,';
wwv_flow_imp.g_varchar2_table(1574) := '3,2597,3100,1400,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-94.13381, 46.40422, NULL), NUL';
wwv_flow_imp.g_varchar2_table(1575) := 'L, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NA';
wwv_flow_imp.g_varchar2_table(1576) := 'ME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OP';
wwv_flow_imp.g_varchar2_table(1577) := 'S,AIR_TAXI_OPS,GEOMETRY) values (8778,''DLH'',''AIRPORT'',''DULUTH INTL'',''DULUTH'',''MINNESOTA'',''Apr-40'',to';
wwv_flow_imp.g_varchar2_table(1578) := '_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1428,5,3020,1427,7767,MDSYS.SDO_GEOMETRY(';
wwv_flow_imp.g_varchar2_table(1579) := '2001, 4326, MDSYS.SDO_POINT_TYPE(-92.19324, 46.84207, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MA';
wwv_flow_imp.g_varchar2_table(1580) := 'P_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_D';
wwv_flow_imp.g_varchar2_table(1581) := 'T,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (879';
wwv_flow_imp.g_varchar2_table(1582) := '3,''ELO'',''AIRPORT'',''ELY MUNI'',''ELY'',''MINNESOTA'',''May-72'',to_timestamp(''01.05.1972 00:00:00'',''DD.MM.RR';
wwv_flow_imp.g_varchar2_table(1583) := ' HH24:MI:SSXFF''),1456,4,560,0,200,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-91.82932, 47.';
wwv_flow_imp.g_varchar2_table(1584) := '82401, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_N';
wwv_flow_imp.g_varchar2_table(1585) := 'AME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVE';
wwv_flow_imp.g_varchar2_table(1586) := 'RED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8864,''HIB'',''AIRPORT'',''RANGE RGNL'',''HIBBING'',''MINNE';
wwv_flow_imp.g_varchar2_table(1587) := 'SOTA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1354,4,1600,2516,2634,MD';
wwv_flow_imp.g_varchar2_table(1588) := 'SYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-92.83897, 47.38658, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert i';
wwv_flow_imp.g_varchar2_table(1589) := 'nto EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,';
wwv_flow_imp.g_varchar2_table(1590) := 'ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOM';
wwv_flow_imp.g_varchar2_table(1591) := 'ETRY) values (8878,''INL'',''AIRPORT'',''FALLS INTL-EINARSON FIELD'',''INTERNATIONAL FALLS'',''MINNESOTA'',''Ma';
wwv_flow_imp.g_varchar2_table(1592) := 'r-42'',to_timestamp(''01.03.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1185,0,681,1250,2500,MDSYS.SDO_GE';
wwv_flow_imp.g_varchar2_table(1593) := 'OMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-93.40217, 48.56558, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SA';
wwv_flow_imp.g_varchar2_table(1594) := 'MPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION';
wwv_flow_imp.g_varchar2_table(1595) := '_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) valu';
wwv_flow_imp.g_varchar2_table(1596) := 'es (8884,''10MN'',''SEAPLANE BASE'',''LOOKOUT LAKE'',''IRONTON'',''MINNESOTA'',''Feb-01'',to_timestamp(''01.02.20';
wwv_flow_imp.g_varchar2_table(1597) := '01 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1200,2,null,1,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_P';
wwv_flow_imp.g_varchar2_table(1598) := 'OINT_TYPE(-93.95611, 46.4375, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE';
wwv_flow_imp.g_varchar2_table(1599) := ',AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO';
wwv_flow_imp.g_varchar2_table(1600) := '_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (8953,''MSP'',''AIRPORT'',''MINNE';
wwv_flow_imp.g_varchar2_table(1601) := 'APOLIS-ST PAUL INTL/WOLD-CHAMBERLAIN'',''MINNEAPOLIS'',''MINNESOTA'',''Apr-40'',to_timestamp(''01.04.1940 00';
wwv_flow_imp.g_varchar2_table(1602) := ':00:00'',''DD.MM.RR HH24:MI:SSXFF''),842,6,2930,372138,14399,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_P';
wwv_flow_imp.g_varchar2_table(1603) := 'OINT_TYPE(-93.22178, 44.88197, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_COD';
wwv_flow_imp.g_varchar2_table(1604) := 'E,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_T';
wwv_flow_imp.g_varchar2_table(1605) := 'O_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9040,''RST'',''AIRPORT'',''ROCH';
wwv_flow_imp.g_varchar2_table(1606) := 'ESTER INTL'',''ROCHESTER'',''MINNESOTA'',''Apr-61'',to_timestamp(''01.04.1961 00:00:00'',''DD.MM.RR HH24:MI:SS';
wwv_flow_imp.g_varchar2_table(1607) := 'XFF''),1317,7,2400,13150,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-92.50003, 43.90828';
wwv_flow_imp.g_varchar2_table(1608) := ', NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,C';
wwv_flow_imp.g_varchar2_table(1609) := 'ITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,C';
wwv_flow_imp.g_varchar2_table(1610) := 'OMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9056,''STC'',''AIRPORT'',''ST CLOUD RGNL'',''ST CLOUD'',''MINNES';
wwv_flow_imp.g_varchar2_table(1611) := 'OTA'',''Aug-70'',to_timestamp(''01.08.1970 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1031,4,1414,305,549,MDSYS';
wwv_flow_imp.g_varchar2_table(1612) := '.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-94.05939, 45.54622, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into';
wwv_flow_imp.g_varchar2_table(1613) := ' EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACT';
wwv_flow_imp.g_varchar2_table(1614) := 'IVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETR';
wwv_flow_imp.g_varchar2_table(1615) := 'Y) values (9089,''TVF'',''AIRPORT'',''THIEF RIVER FALLS RGNL'',''THIEF RIVER FALLS'',''MINNESOTA'',''Jul-45'',to';
wwv_flow_imp.g_varchar2_table(1616) := '_timestamp(''01.07.1945 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1119,3,916,333,1910,MDSYS.SDO_GEOMETRY(20';
wwv_flow_imp.g_varchar2_table(1617) := '01, 4326, MDSYS.SDO_POINT_TYPE(-96.185, 48.06567, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AI';
wwv_flow_imp.g_varchar2_table(1618) := 'RPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,EL';
wwv_flow_imp.g_varchar2_table(1619) := 'EVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9182,''B';
wwv_flow_imp.g_varchar2_table(1620) := 'BG'',''AIRPORT'',''BRANSON'',''BRANSON'',''MISSOURI'',''Oct-08'',to_timestamp(''01.10.2008 00:00:00'',''DD.MM.RR H';
wwv_flow_imp.g_varchar2_table(1621) := 'H24:MI:SSXFF''),1302,8,922,136,942,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-93.20054, 36.';
wwv_flow_imp.g_varchar2_table(1622) := '53208, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_N';
wwv_flow_imp.g_varchar2_table(1623) := 'AME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVE';
wwv_flow_imp.g_varchar2_table(1624) := 'RED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9208,''CGI'',''AIRPORT'',''CAPE GIRARDEAU RGNL'',''CAPE G';
wwv_flow_imp.g_varchar2_table(1625) := 'IRARDEAU'',''MISSOURI'',''Apr-43'',to_timestamp(''01.04.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),342,5,557';
wwv_flow_imp.g_varchar2_table(1626) := ',1434,760,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.57075, 37.22531, NULL), NULL, NULL';
wwv_flow_imp.g_varchar2_table(1627) := '));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTI';
wwv_flow_imp.g_varchar2_table(1628) := 'VATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_T';
wwv_flow_imp.g_varchar2_table(1629) := 'AXI_OPS,GEOMETRY) values (9240,''COU'',''AIRPORT'',''COLUMBIA RGNL'',''COLUMBIA'',''MISSOURI'',null,null,889,1';
wwv_flow_imp.g_varchar2_table(1630) := '0,1538,1053,5584,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-92.21803, 38.81733, NULL), NUL';
wwv_flow_imp.g_varchar2_table(1631) := 'L, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NA';
wwv_flow_imp.g_varchar2_table(1632) := 'ME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OP';
wwv_flow_imp.g_varchar2_table(1633) := 'S,AIR_TAXI_OPS,GEOMETRY) values (9287,''TBN'',''AIRPORT'',''WAYNESVILLE-ST ROBERT RGNL FORNEY FLD'',''FORT ';
wwv_flow_imp.g_varchar2_table(1634) := 'LEONARD WOOD'',''MISSOURI'',''Apr-44'',to_timestamp(''01.04.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1160,';
wwv_flow_imp.g_varchar2_table(1635) := '0,237,4637,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-92.14072, 37.74164, NULL), NULL, N';
wwv_flow_imp.g_varchar2_table(1636) := 'ULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,A';
wwv_flow_imp.g_varchar2_table(1637) := 'CTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AI';
wwv_flow_imp.g_varchar2_table(1638) := 'R_TAXI_OPS,GEOMETRY) values (9346,''JEF'',''AIRPORT'',''JEFFERSON CITY MEMORIAL'',''JEFFERSON CITY'',''MISSOU';
wwv_flow_imp.g_varchar2_table(1639) := 'RI'',''Feb-49'',to_timestamp(''01.02.1949 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),549,2,469,0,879,MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(1640) := 'GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-92.15614, 38.59117, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_';
wwv_flow_imp.g_varchar2_table(1641) := 'SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATI';
wwv_flow_imp.g_varchar2_table(1642) := 'ON_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) va';
wwv_flow_imp.g_varchar2_table(1643) := 'lues (9351,''JLN'',''AIRPORT'',''JOPLIN RGNL'',''JOPLIN'',''MISSOURI'',''Apr-40'',to_timestamp(''01.04.1940 00:00';
wwv_flow_imp.g_varchar2_table(1644) := ':00'',''DD.MM.RR HH24:MI:SSXFF''),978,4,970,1588,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TY';
wwv_flow_imp.g_varchar2_table(1645) := 'PE(-94.49881, 37.15317, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPO';
wwv_flow_imp.g_varchar2_table(1646) := 'RT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPO';
wwv_flow_imp.g_varchar2_table(1647) := 'RT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9356,''MKC'',''AIRPORT'',''CHARLES B W';
wwv_flow_imp.g_varchar2_table(1648) := 'HEELER DOWNTOWN'',''KANSAS CITY'',''MISSOURI'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24';
wwv_flow_imp.g_varchar2_table(1649) := ':MI:SSXFF''),757,0,700,188,15899,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-94.59283, 39.12';
wwv_flow_imp.g_varchar2_table(1650) := '294, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAM';
wwv_flow_imp.g_varchar2_table(1651) := 'E,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERE';
wwv_flow_imp.g_varchar2_table(1652) := 'D,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9372,''MCI'',''AIRPORT'',''KANSAS CITY INTL'',''KANSAS CITY';
wwv_flow_imp.g_varchar2_table(1653) := ''',''MISSOURI'',''May-56'',to_timestamp(''01.05.1956 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1027,15,10680,107';
wwv_flow_imp.g_varchar2_table(1654) := '375,5000,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-94.71389, 39.29761, NULL), NULL, NULL)';
wwv_flow_imp.g_varchar2_table(1655) := ');'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIV';
wwv_flow_imp.g_varchar2_table(1656) := 'ATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TA';
wwv_flow_imp.g_varchar2_table(1657) := 'XI_OPS,GEOMETRY) values (9380,''IRK'',''AIRPORT'',''KIRKSVILLE RGNL'',''KIRKSVILLE'',''MISSOURI'',''May-41'',to_';
wwv_flow_imp.g_varchar2_table(1658) := 'timestamp(''01.05.1941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),966,6,476,2175,4000,MDSYS.SDO_GEOMETRY(200';
wwv_flow_imp.g_varchar2_table(1659) := '1, 4326, MDSYS.SDO_POINT_TYPE(-92.54492, 40.09347, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_A';
wwv_flow_imp.g_varchar2_table(1660) := 'IRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,E';
wwv_flow_imp.g_varchar2_table(1661) := 'LEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9537,''';
wwv_flow_imp.g_varchar2_table(1662) := 'STJ'',''AIRPORT'',''ROSECRANS MEMORIAL'',''ST JOSEPH'',''MISSOURI'',''Apr-40'',to_timestamp(''01.04.1940 00:00:0';
wwv_flow_imp.g_varchar2_table(1663) := '0'',''DD.MM.RR HH24:MI:SSXFF''),827,3,1707,0,292,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-9';
wwv_flow_imp.g_varchar2_table(1664) := '4.90971, 39.77194, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TY';
wwv_flow_imp.g_varchar2_table(1665) := 'PE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LA';
wwv_flow_imp.g_varchar2_table(1666) := 'ND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9546,''STL'',''AIRPORT'',''ST LOUIS LAMBERT';
wwv_flow_imp.g_varchar2_table(1667) := ' INTL'',''ST LOUIS'',''MISSOURI'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),6';
wwv_flow_imp.g_varchar2_table(1668) := '18,10,2800,139321,46025,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-90.37003, 38.7487, NULL';
wwv_flow_imp.g_varchar2_table(1669) := '), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,ST';
wwv_flow_imp.g_varchar2_table(1670) := 'ATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERC';
wwv_flow_imp.g_varchar2_table(1671) := 'IAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9555,''SUS'',''AIRPORT'',''SPIRIT OF ST LOUIS'',''ST LOUIS'',''MISSOUR';
wwv_flow_imp.g_varchar2_table(1672) := 'I'',''Sep-64'',to_timestamp(''01.09.1964 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),463,17,1300,34,11612,MDSYS.';
wwv_flow_imp.g_varchar2_table(1673) := 'SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-90.65206, 38.66211, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into ';
wwv_flow_imp.g_varchar2_table(1674) := 'EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTI';
wwv_flow_imp.g_varchar2_table(1675) := 'VATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY';
wwv_flow_imp.g_varchar2_table(1676) := ') values (9588,''SGF'',''AIRPORT'',''SPRINGFIELD-BRANSON NATIONAL'',''SPRINGFIELD'',''MISSOURI'',null,null,126';
wwv_flow_imp.g_varchar2_table(1677) := '8,5,2750,8673,23944,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-93.38864, 37.24567, NULL), ';
wwv_flow_imp.g_varchar2_table(1678) := 'NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE';
wwv_flow_imp.g_varchar2_table(1679) := '_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL';
wwv_flow_imp.g_varchar2_table(1680) := '_OPS,AIR_TAXI_OPS,GEOMETRY) values (9654,''MDY'',''AIRPORT'',''HENDERSON FIELD'',''MIDWAY ATOLL'',''MIDWAY AT';
wwv_flow_imp.g_varchar2_table(1681) := 'OLL'',''Dec-46'',to_timestamp(''01.12.1946 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),18,0,1200,0,20,MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(1682) := 'GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-177.38131, 28.20148, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA';
wwv_flow_imp.g_varchar2_table(1683) := '_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVAT';
wwv_flow_imp.g_varchar2_table(1684) := 'ION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) v';
wwv_flow_imp.g_varchar2_table(1685) := 'alues (9706,''GTR'',''AIRPORT'',''GOLDEN TRIANGLE RGNL'',''COLUMBUS/W POINT/STARKVILLE'',''MISSISSIPPI'',''Aug-';
wwv_flow_imp.g_varchar2_table(1686) := '71'',to_timestamp(''01.08.1971 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),264,10,1000,96,3067,MDSYS.SDO_GEOME';
wwv_flow_imp.g_varchar2_table(1687) := 'TRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-88.59139, 33.44828, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPL';
wwv_flow_imp.g_varchar2_table(1688) := 'E_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DA';
wwv_flow_imp.g_varchar2_table(1689) := 'TE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values ';
wwv_flow_imp.g_varchar2_table(1690) := '(9708,''CBM'',''AIRPORT'',''COLUMBUS AFB'',''COLUMBUS'',''MISSISSIPPI'',''Jan-43'',to_timestamp(''01.01.1943 00:0';
wwv_flow_imp.g_varchar2_table(1691) := '0:00'',''DD.MM.RR HH24:MI:SSXFF''),218,9,null,700,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_T';
wwv_flow_imp.g_varchar2_table(1692) := 'YPE(-88.44592, 33.64518, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRP';
wwv_flow_imp.g_varchar2_table(1693) := 'ORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRP';
wwv_flow_imp.g_varchar2_table(1694) := 'ORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9730,''GLH'',''AIRPORT'',''GREENVILLE';
wwv_flow_imp.g_varchar2_table(1695) := ' MID-DELTA'',''GREENVILLE'',''MISSISSIPPI'',''Jun-42'',to_timestamp(''01.06.1942 00:00:00'',''DD.MM.RR HH24:MI';
wwv_flow_imp.g_varchar2_table(1696) := ':SSXFF''),131,5,2000,10,1389,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-90.98561, 33.48288,';
wwv_flow_imp.g_varchar2_table(1697) := ' NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CI';
wwv_flow_imp.g_varchar2_table(1698) := 'TY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,CO';
wwv_flow_imp.g_varchar2_table(1699) := 'MMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9737,''GPT'',''AIRPORT'',''GULFPORT-BILOXI INTL'',''GULFPORT'',''';
wwv_flow_imp.g_varchar2_table(1700) := 'MISSISSIPPI'',null,null,29,3,1400,7652,3858,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.0';
wwv_flow_imp.g_varchar2_table(1701) := '7008, 30.40728, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,';
wwv_flow_imp.g_varchar2_table(1702) := 'AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_';
wwv_flow_imp.g_varchar2_table(1703) := 'AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9740,''HBG'',''AIRPORT'',''HATTIESBURG BOBBY L';
wwv_flow_imp.g_varchar2_table(1704) := ' CHAIN MUNI'',''HATTIESBURG'',''MISSISSIPPI'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:';
wwv_flow_imp.g_varchar2_table(1705) := 'MI:SSXFF''),151,4,420,1510,340,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.25289, 31.2649';
wwv_flow_imp.g_varchar2_table(1706) := '4, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,';
wwv_flow_imp.g_varchar2_table(1707) := 'CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,';
wwv_flow_imp.g_varchar2_table(1708) := 'COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9743,''PIB'',''AIRPORT'',''HATTIESBURG-LAUREL RGNL'',''HATTIE';
wwv_flow_imp.g_varchar2_table(1709) := 'SBURG-LAUREL'',''MISSISSIPPI'',''May-74'',to_timestamp(''01.05.1974 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),29';
wwv_flow_imp.g_varchar2_table(1710) := '8,9,1170,1460,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.33706, 31.46714, NULL), NULL';
wwv_flow_imp.g_varchar2_table(1711) := ', NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAM';
wwv_flow_imp.g_varchar2_table(1712) := 'E,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS';
wwv_flow_imp.g_varchar2_table(1713) := ',AIR_TAXI_OPS,GEOMETRY) values (9761,''JAN'',''AIRPORT'',''JACKSON-MEDGAR WILEY EVERS INTL'',''JACKSON'',''MI';
wwv_flow_imp.g_varchar2_table(1714) := 'SSISSIPPI'',''Jul-63'',to_timestamp(''01.07.1963 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),346,5,3381,11338,77';
wwv_flow_imp.g_varchar2_table(1715) := '66,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-90.07589, 32.31117, NULL), NULL, NULL));'||wwv_flow.LF||
'Ins';
wwv_flow_imp.g_varchar2_table(1716) := 'ert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_';
wwv_flow_imp.g_varchar2_table(1717) := 'DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS';
wwv_flow_imp.g_varchar2_table(1718) := ',GEOMETRY) values (9792,''MEI'',''AIRPORT'',''KEY FIELD'',''MERIDIAN'',''MISSISSIPPI'',''Apr-40'',to_timestamp(''';
wwv_flow_imp.g_varchar2_table(1719) := '01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),298,3,1000,0,3125,MDSYS.SDO_GEOMETRY(2001, 4326, MDSY';
wwv_flow_imp.g_varchar2_table(1720) := 'S.SDO_POINT_TYPE(-88.75186, 32.33261, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,I';
wwv_flow_imp.g_varchar2_table(1721) := 'ATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST';
wwv_flow_imp.g_varchar2_table(1722) := '_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9810,''UOX'',''AIRPORT';
wwv_flow_imp.g_varchar2_table(1723) := ''',''UNIVERSITY-OXFORD'',''OXFORD'',''MISSISSIPPI'',''May-57'',to_timestamp(''01.05.1957 00:00:00'',''DD.MM.RR H';
wwv_flow_imp.g_varchar2_table(1724) := 'H24:MI:SSXFF''),452,2,297,28,5146,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.53681, 34.3';
wwv_flow_imp.g_varchar2_table(1725) := '8433, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NA';
wwv_flow_imp.g_varchar2_table(1726) := 'ME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVER';
wwv_flow_imp.g_varchar2_table(1727) := 'ED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9869,''UTA'',''AIRPORT'',''TUNICA MUNI'',''TUNICA'',''MISSIS';
wwv_flow_imp.g_varchar2_table(1728) := 'SIPPI'',''Nov-81'',to_timestamp(''01.11.1981 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),194,1,863,326,240,MDSYS';
wwv_flow_imp.g_varchar2_table(1729) := '.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-90.34778, 34.68506, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into';
wwv_flow_imp.g_varchar2_table(1730) := ' EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACT';
wwv_flow_imp.g_varchar2_table(1731) := 'IVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETR';
wwv_flow_imp.g_varchar2_table(1732) := 'Y) values (9872,''TUP'',''AIRPORT'',''TUPELO RGNL'',''TUPELO'',''MISSISSIPPI'',''Apr-40'',to_timestamp(''01.04.19';
wwv_flow_imp.g_varchar2_table(1733) := '40 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),347,3,1061,39,4780,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_P';
wwv_flow_imp.g_varchar2_table(1734) := 'OINT_TYPE(-88.76989, 34.269, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,';
wwv_flow_imp.g_varchar2_table(1735) := 'AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_';
wwv_flow_imp.g_varchar2_table(1736) := 'AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9915,''BIL'',''AIRPORT'',''BILLIN';
wwv_flow_imp.g_varchar2_table(1737) := 'GS LOGAN INTL'',''BILLINGS'',''MONTANA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SS';
wwv_flow_imp.g_varchar2_table(1738) := 'XFF''),3662,2,2300,11682,26314,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-108.54354, 45.807';
wwv_flow_imp.g_varchar2_table(1739) := '85, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME';
wwv_flow_imp.g_varchar2_table(1740) := ',CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED';
wwv_flow_imp.g_varchar2_table(1741) := ',COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (9934,''BZN'',''AIRPORT'',''BOZEMAN YELLOWSTONE INTL'',''BOZE';
wwv_flow_imp.g_varchar2_table(1742) := 'MAN'',''MONTANA'',''Jul-42'',to_timestamp(''01.07.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4473,7,2481,134';
wwv_flow_imp.g_varchar2_table(1743) := '08,10238,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-111.15026, 45.77724, NULL), NULL, NULL';
wwv_flow_imp.g_varchar2_table(1744) := '));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTI';
wwv_flow_imp.g_varchar2_table(1745) := 'VATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_T';
wwv_flow_imp.g_varchar2_table(1746) := 'AXI_OPS,GEOMETRY) values (9938,''BTM'',''AIRPORT'',''BERT MOONEY'',''BUTTE'',''MONTANA'',''Apr-40'',to_timestamp';
wwv_flow_imp.g_varchar2_table(1747) := '(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),5551,3,890,821,1920,MDSYS.SDO_GEOMETRY(2001, 4326, ';
wwv_flow_imp.g_varchar2_table(1748) := 'MDSYS.SDO_POINT_TYPE(-112.49747, 45.95481, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS ';
wwv_flow_imp.g_varchar2_table(1749) := '(ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION';
wwv_flow_imp.g_varchar2_table(1750) := ',DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10005,''GTF'',''A';
wwv_flow_imp.g_varchar2_table(1751) := 'IRPORT'',''GREAT FALLS INTL'',''GREAT FALLS'',''MONTANA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.M';
wwv_flow_imp.g_varchar2_table(1752) := 'M.RR HH24:MI:SSXFF''),3680,3,2113,3944,11229,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-111';
wwv_flow_imp.g_varchar2_table(1753) := '.37028, 47.4823, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE';
wwv_flow_imp.g_varchar2_table(1754) := ',AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND';
wwv_flow_imp.g_varchar2_table(1755) := '_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10023,''HVR'',''AIRPORT'',''HAVRE CITY-COUNTY';
wwv_flow_imp.g_varchar2_table(1756) := ''',''HAVRE'',''MONTANA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2591,3,720';
wwv_flow_imp.g_varchar2_table(1757) := ',1460,1450,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-109.76233, 48.54297, NULL), NULL, NU';
wwv_flow_imp.g_varchar2_table(1758) := 'LL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,AC';
wwv_flow_imp.g_varchar2_table(1759) := 'TIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR';
wwv_flow_imp.g_varchar2_table(1760) := '_TAXI_OPS,GEOMETRY) values (10033,''HLN'',''AIRPORT'',''HELENA RGNL'',''HELENA'',''MONTANA'',''Apr-40'',to_times';
wwv_flow_imp.g_varchar2_table(1761) := 'tamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),3877,2,1224,3421,4728,MDSYS.SDO_GEOMETRY(2001, ';
wwv_flow_imp.g_varchar2_table(1762) := '4326, MDSYS.SDO_POINT_TYPE(-111.98328, 46.60672, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIR';
wwv_flow_imp.g_varchar2_table(1763) := 'PORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELE';
wwv_flow_imp.g_varchar2_table(1764) := 'VATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10059,''G';
wwv_flow_imp.g_varchar2_table(1765) := 'PI'',''AIRPORT'',''GLACIER PARK INTL'',''KALISPELL'',''MONTANA'',''Feb-44'',to_timestamp(''01.02.1944 00:00:00'',';
wwv_flow_imp.g_varchar2_table(1766) := '''DD.MM.RR HH24:MI:SSXFF''),2977,6,1525,7083,5603,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(';
wwv_flow_imp.g_varchar2_table(1767) := '-114.256, 48.3105, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TY';
wwv_flow_imp.g_varchar2_table(1768) := 'PE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LA';
wwv_flow_imp.g_varchar2_table(1769) := 'ND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10069,''LWT'',''AIRPORT'',''LEWISTOWN MUNI''';
wwv_flow_imp.g_varchar2_table(1770) := ',''LEWISTOWN'',''MONTANA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4170,2,';
wwv_flow_imp.g_varchar2_table(1771) := '2200,0,1800,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-109.46669, 47.04925, NULL), NULL, N';
wwv_flow_imp.g_varchar2_table(1772) := 'ULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,A';
wwv_flow_imp.g_varchar2_table(1773) := 'CTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AI';
wwv_flow_imp.g_varchar2_table(1774) := 'R_TAXI_OPS,GEOMETRY) values (10090,''MSO'',''AIRPORT'',''MISSOULA INTL'',''MISSOULA'',''MONTANA'',''Jul-41'',to_';
wwv_flow_imp.g_varchar2_table(1775) := 'timestamp(''01.07.1941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),3206,4,2700,8263,6218,MDSYS.SDO_GEOMETRY(2';
wwv_flow_imp.g_varchar2_table(1776) := '001, 4326, MDSYS.SDO_POINT_TYPE(-114.09056, 46.91631, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MA';
wwv_flow_imp.g_varchar2_table(1777) := 'P_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_D';
wwv_flow_imp.g_varchar2_table(1778) := 'T,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (101';
wwv_flow_imp.g_varchar2_table(1779) := '35,''SDY'',''AIRPORT'',''SIDNEY-RICHLAND RGNL'',''SIDNEY'',''MONTANA'',''Jan-51'',to_timestamp(''01.01.1951 00:00';
wwv_flow_imp.g_varchar2_table(1780) := ':00'',''DD.MM.RR HH24:MI:SSXFF''),1985,1,335,0,4670,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE';
wwv_flow_imp.g_varchar2_table(1781) := '(-104.19256, 47.70686, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPOR';
wwv_flow_imp.g_varchar2_table(1782) := 'T_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPOR';
wwv_flow_imp.g_varchar2_table(1783) := 'T,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10170,''WYS'',''AIRPORT'',''YELLOWSTONE';
wwv_flow_imp.g_varchar2_table(1784) := ''',''WEST YELLOWSTONE'',''MONTANA'',''Nov-79'',to_timestamp(''01.11.1979 00:00:00'',''DD.MM.RR HH24:MI:SSXFF'')';
wwv_flow_imp.g_varchar2_table(1785) := ',6649,1,735,0,530,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-111.11764, 44.68839, NULL), N';
wwv_flow_imp.g_varchar2_table(1786) := 'ULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_';
wwv_flow_imp.g_varchar2_table(1787) := 'NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_';
wwv_flow_imp.g_varchar2_table(1788) := 'OPS,AIR_TAXI_OPS,GEOMETRY) values (10214,''AVL'',''AIRPORT'',''ASHEVILLE RGNL'',''ASHEVILLE'',''NORTH CAROLIN';
wwv_flow_imp.g_varchar2_table(1789) := 'A'',''Jan-61'',to_timestamp(''01.01.1961 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2162,9,900,9230,10140,MDSYS';
wwv_flow_imp.g_varchar2_table(1790) := '.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-82.54273, 35.43444, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into';
wwv_flow_imp.g_varchar2_table(1791) := ' EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACT';
wwv_flow_imp.g_varchar2_table(1792) := 'IVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETR';
wwv_flow_imp.g_varchar2_table(1793) := 'Y) values (10274,''CLT'',''AIRPORT'',''CHARLOTTE/DOUGLAS INTL'',''CHARLOTTE'',''NORTH CAROLINA'',''Sep-37'',to_t';
wwv_flow_imp.g_varchar2_table(1794) := 'imestamp(''01.09.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),748,5,5558,454153,77200,MDSYS.SDO_GEOMETRY(';
wwv_flow_imp.g_varchar2_table(1795) := '2001, 4326, MDSYS.SDO_POINT_TYPE(-80.94906, 35.21375, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MA';
wwv_flow_imp.g_varchar2_table(1796) := 'P_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_D';
wwv_flow_imp.g_varchar2_table(1797) := 'T,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (102';
wwv_flow_imp.g_varchar2_table(1798) := '94,''JQF'',''AIRPORT'',''CONCORD-PADGETT RGNL'',''CONCORD'',''NORTH CAROLINA'',''Nov-93'',to_timestamp(''01.11.19';
wwv_flow_imp.g_varchar2_table(1799) := '93 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),704,7,750,3134,6201,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(1800) := 'POINT_TYPE(-80.70913, 35.38777, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CO';
wwv_flow_imp.g_varchar2_table(1801) := 'DE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_';
wwv_flow_imp.g_varchar2_table(1802) := 'TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10332,''FAY'',''AIRPORT'',''FA';
wwv_flow_imp.g_varchar2_table(1803) := 'YETTEVILLE RGNL/GRANNIS FIELD'',''FAYETTEVILLE'',''NORTH CAROLINA'',''May-49'',to_timestamp(''01.05.1949 00:';
wwv_flow_imp.g_varchar2_table(1804) := '00:00'',''DD.MM.RR HH24:MI:SSXFF''),189,3,1343,10102,6369,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POIN';
wwv_flow_imp.g_varchar2_table(1805) := 'T_TYPE(-78.88028, 34.99122, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,A';
wwv_flow_imp.g_varchar2_table(1806) := 'IRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_A';
wwv_flow_imp.g_varchar2_table(1807) := 'IRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10369,''GSO'',''AIRPORT'',''PIEDMO';
wwv_flow_imp.g_varchar2_table(1808) := 'NT TRIAD INTL'',''GREENSBORO'',''NORTH CAROLINA'',''Dec-41'',to_timestamp(''01.12.1941 00:00:00'',''DD.MM.RR H';
wwv_flow_imp.g_varchar2_table(1809) := 'H24:MI:SSXFF''),926,7,3770,25175,29454,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-79.94112,';
wwv_flow_imp.g_varchar2_table(1810) := ' 36.10133, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPO';
wwv_flow_imp.g_varchar2_table(1811) := 'RT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_';
wwv_flow_imp.g_varchar2_table(1812) := 'COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10370,''PGV'',''AIRPORT'',''PITT-GREENVILLE'',''GREEN';
wwv_flow_imp.g_varchar2_table(1813) := 'VILLE'',''NORTH CAROLINA'',''Jun-41'',to_timestamp(''01.06.1941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),26,2,8';
wwv_flow_imp.g_varchar2_table(1814) := '72,2720,12500,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-77.38408, 35.63569, NULL), NULL, ';
wwv_flow_imp.g_varchar2_table(1815) := 'NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,';
wwv_flow_imp.g_varchar2_table(1816) := 'ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,A';
wwv_flow_imp.g_varchar2_table(1817) := 'IR_TAXI_OPS,GEOMETRY) values (10391,''HKY'',''AIRPORT'',''HICKORY RGNL'',''HICKORY'',''NORTH CAROLINA'',''Jun-4';
wwv_flow_imp.g_varchar2_table(1818) := '0'',to_timestamp(''01.06.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1190,3,739,1693,6883,MDSYS.SDO_GEOME';
wwv_flow_imp.g_varchar2_table(1819) := 'TRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.38955, 35.74115, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPL';
wwv_flow_imp.g_varchar2_table(1820) := 'E_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DA';
wwv_flow_imp.g_varchar2_table(1821) := 'TE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values ';
wwv_flow_imp.g_varchar2_table(1822) := '(10410,''OAJ'',''AIRPORT'',''ALBERT J ELLIS'',''JACKSONVILLE'',''NORTH CAROLINA'',''Feb-71'',to_timestamp(''01.02';
wwv_flow_imp.g_varchar2_table(1823) := '.1971 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),93,10,675,6342,2280,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.S';
wwv_flow_imp.g_varchar2_table(1824) := 'DO_POINT_TYPE(-77.61214, 34.82917, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA';
wwv_flow_imp.g_varchar2_table(1825) := '_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CI';
wwv_flow_imp.g_varchar2_table(1826) := 'TY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10428,''ISO'',''AIRPORT'',';
wwv_flow_imp.g_varchar2_table(1827) := '''KINSTON RGNL JETPORT AT STALLINGS FLD'',''KINSTON'',''NORTH CAROLINA'',''Aug-44'',to_timestamp(''01.08.1944';
wwv_flow_imp.g_varchar2_table(1828) := ' 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),93,3,1255,39,359,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT';
wwv_flow_imp.g_varchar2_table(1829) := '_TYPE(-77.60883, 35.33144, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AI';
wwv_flow_imp.g_varchar2_table(1830) := 'RPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AI';
wwv_flow_imp.g_varchar2_table(1831) := 'RPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10460,''00NC'',''AIRPORT'',''NORTH ';
wwv_flow_imp.g_varchar2_table(1832) := 'RALEIGH'',''LOUISBURG'',''NORTH CAROLINA'',''Jan-72'',to_timestamp(''01.01.1972 00:00:00'',''DD.MM.RR HH24:MI:';
wwv_flow_imp.g_varchar2_table(1833) := 'SSXFF''),348,3,140,1200,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-78.37139, 36.08515,';
wwv_flow_imp.g_varchar2_table(1834) := ' NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CI';
wwv_flow_imp.g_varchar2_table(1835) := 'TY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,CO';
wwv_flow_imp.g_varchar2_table(1836) := 'MMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10508,''EWN'',''AIRPORT'',''COASTAL CAROLINA REGIONAL'',''NEW B';
wwv_flow_imp.g_varchar2_table(1837) := 'ERN'',''NORTH CAROLINA'',''Jul-41'',to_timestamp(''01.07.1941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),18,3,785';
wwv_flow_imp.g_varchar2_table(1838) := ',2210,6069,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-77.04302, 35.07285, NULL), NULL, NUL';
wwv_flow_imp.g_varchar2_table(1839) := 'L));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACT';
wwv_flow_imp.g_varchar2_table(1840) := 'IVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_';
wwv_flow_imp.g_varchar2_table(1841) := 'TAXI_OPS,GEOMETRY) values (10529,''SOP'',''AIRPORT'',''MOORE COUNTY'',''PINEHURST/SOUTHERN PINES'',''NORTH CA';
wwv_flow_imp.g_varchar2_table(1842) := 'ROLINA'',''Sep-37'',to_timestamp(''01.09.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),459,3,500,0,1000,MDSYS';
wwv_flow_imp.g_varchar2_table(1843) := '.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-79.38903, 35.23742, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into';
wwv_flow_imp.g_varchar2_table(1844) := ' EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACT';
wwv_flow_imp.g_varchar2_table(1845) := 'IVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETR';
wwv_flow_imp.g_varchar2_table(1846) := 'Y) values (10554,''RDU'',''AIRPORT'',''RALEIGH-DURHAM INTL'',''RALEIGH/DURHAM'',''NORTH CAROLINA'',''Apr-43'',to';
wwv_flow_imp.g_varchar2_table(1847) := '_timestamp(''01.04.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),435,9,5000,106157,24886,MDSYS.SDO_GEOMETR';
wwv_flow_imp.g_varchar2_table(1848) := 'Y(2001, 4326, MDSYS.SDO_POINT_TYPE(-78.78747, 35.87764, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_';
wwv_flow_imp.g_varchar2_table(1849) := 'MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(1850) := '_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1';
wwv_flow_imp.g_varchar2_table(1851) := '0565,''RWI'',''AIRPORT'',''ROCKY MOUNT-WILSON RGNL'',''ROCKY MOUNT'',''NORTH CAROLINA'',null,null,158,7,364,90';
wwv_flow_imp.g_varchar2_table(1852) := ',1276,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-77.89193, 35.85625, NULL), NULL, NULL));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1853) := 'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATI';
wwv_flow_imp.g_varchar2_table(1854) := 'ON_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_';
wwv_flow_imp.g_varchar2_table(1855) := 'OPS,GEOMETRY) values (10653,''ILM'',''AIRPORT'',''WILMINGTON INTL'',''WILMINGTON'',''NORTH CAROLINA'',''Jul-37''';
wwv_flow_imp.g_varchar2_table(1856) := ',to_timestamp(''01.07.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),32,3,1800,8626,13912,MDSYS.SDO_GEOMETR';
wwv_flow_imp.g_varchar2_table(1857) := 'Y(2001, 4326, MDSYS.SDO_POINT_TYPE(-77.90289, 34.27114, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_';
wwv_flow_imp.g_varchar2_table(1858) := 'MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(1859) := '_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1';
wwv_flow_imp.g_varchar2_table(1860) := '0663,''INT'',''AIRPORT'',''SMITH REYNOLDS'',''WINSTON SALEM'',''NORTH CAROLINA'',''Jan-38'',to_timestamp(''01.01.';
wwv_flow_imp.g_varchar2_table(1861) := '1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),969,3,702,60,7905,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(1862) := 'POINT_TYPE(-80.22199, 36.13371, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CO';
wwv_flow_imp.g_varchar2_table(1863) := 'DE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_';
wwv_flow_imp.g_varchar2_table(1864) := 'TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10701,''BIS'',''AIRPORT'',''BI';
wwv_flow_imp.g_varchar2_table(1865) := 'SMARCK MUNI'',''BISMARCK'',''NORTH DAKOTA'',''Dec-37'',to_timestamp(''01.12.1937 00:00:00'',''DD.MM.RR HH24:MI';
wwv_flow_imp.g_varchar2_table(1866) := ':SSXFF''),1661,3,2425,3537,10919,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-100.74575, 46.7';
wwv_flow_imp.g_varchar2_table(1867) := '7272, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NA';
wwv_flow_imp.g_varchar2_table(1868) := 'ME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVER';
wwv_flow_imp.g_varchar2_table(1869) := 'ED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10740,''DVL'',''AIRPORT'',''DEVILS LAKE RGNL'',''DEVILS LA';
wwv_flow_imp.g_varchar2_table(1870) := 'KE'',''NORTH DAKOTA'',null,null,1470,2,730,1230,2450,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYP';
wwv_flow_imp.g_varchar2_table(1871) := 'E(-98.91, 48.11658, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_T';
wwv_flow_imp.g_varchar2_table(1872) := 'YPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,L';
wwv_flow_imp.g_varchar2_table(1873) := 'AND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10742,''DIK'',''AIRPORT'',''DICKINSON - TH';
wwv_flow_imp.g_varchar2_table(1874) := 'EODORE ROOSEVELT RGNL'',''DICKINSON'',''NORTH DAKOTA'',''Oct-38'',to_timestamp(''01.10.1938 00:00:00'',''DD.MM';
wwv_flow_imp.g_varchar2_table(1875) := '.RR HH24:MI:SSXFF''),2592,5,626,1460,1044,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-102.80';
wwv_flow_imp.g_varchar2_table(1876) := '186, 46.79733, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,A';
wwv_flow_imp.g_varchar2_table(1877) := 'IRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_A';
wwv_flow_imp.g_varchar2_table(1878) := 'REA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10758,''FAR'',''AIRPORT'',''HECTOR INTL'',''FARGO';
wwv_flow_imp.g_varchar2_table(1879) := ''',''NORTH DAKOTA'',''Aug-37'',to_timestamp(''01.08.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),901,3,2500,81';
wwv_flow_imp.g_varchar2_table(1880) := '86,24023,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-96.81575, 46.92064, NULL), NULL, NULL)';
wwv_flow_imp.g_varchar2_table(1881) := ');'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIV';
wwv_flow_imp.g_varchar2_table(1882) := 'ATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TA';
wwv_flow_imp.g_varchar2_table(1883) := 'XI_OPS,GEOMETRY) values (10777,''GFK'',''AIRPORT'',''GRAND FORKS INTL'',''GRAND FORKS'',''NORTH DAKOTA'',''Dec-';
wwv_flow_imp.g_varchar2_table(1884) := '63'',to_timestamp(''01.12.1963 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),845,5,1618,883,108675,MDSYS.SDO_GEO';
wwv_flow_imp.g_varchar2_table(1885) := 'METRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.17378, 47.94728, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAM';
wwv_flow_imp.g_varchar2_table(1886) := 'PLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_';
wwv_flow_imp.g_varchar2_table(1887) := 'DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) value';
wwv_flow_imp.g_varchar2_table(1888) := 's (10810,''JMS'',''AIRPORT'',''JAMESTOWN RGNL'',''JAMESTOWN'',''NORTH DAKOTA'',''Mar-38'',to_timestamp(''01.03.19';
wwv_flow_imp.g_varchar2_table(1889) := '38 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1500,2,1500,2128,728,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(1890) := '_POINT_TYPE(-98.67819, 46.92972, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_C';
wwv_flow_imp.g_varchar2_table(1891) := 'ODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY';
wwv_flow_imp.g_varchar2_table(1892) := '_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10864,''MOT'',''AIRPORT'',''M';
wwv_flow_imp.g_varchar2_table(1893) := 'INOT INTL'',''MINOT'',''NORTH DAKOTA'',''Mar-40'',to_timestamp(''01.03.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXF';
wwv_flow_imp.g_varchar2_table(1894) := 'F''),1716,2,1563,1199,7580,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-101.27803, 48.25764, ';
wwv_flow_imp.g_varchar2_table(1895) := 'NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CIT';
wwv_flow_imp.g_varchar2_table(1896) := 'Y,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COM';
wwv_flow_imp.g_varchar2_table(1897) := 'MERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (10958,''AIA'',''AIRPORT'',''ALLIANCE MUNI'',''ALLIANCE'',''NEBRASK';
wwv_flow_imp.g_varchar2_table(1898) := 'A'',''Feb-44'',to_timestamp(''01.02.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),3931,3,3500,0,102,MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(1899) := '_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-102.80375, 42.05322, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EB';
wwv_flow_imp.g_varchar2_table(1900) := 'A_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVA';
wwv_flow_imp.g_varchar2_table(1901) := 'TION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) ';
wwv_flow_imp.g_varchar2_table(1902) := 'values (11000,''CDR'',''AIRPORT'',''CHADRON MUNI'',''CHADRON'',''NEBRASKA'',''Apr-40'',to_timestamp(''01.04.1940 ';
wwv_flow_imp.g_varchar2_table(1903) := '00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),3298,4,716,1249,667,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POI';
wwv_flow_imp.g_varchar2_table(1904) := 'NT_TYPE(-103.0954, 42.83756, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,';
wwv_flow_imp.g_varchar2_table(1905) := 'AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_';
wwv_flow_imp.g_varchar2_table(1906) := 'AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11043,''GRI'',''AIRPORT'',''CENTR';
wwv_flow_imp.g_varchar2_table(1907) := 'AL NEBRASKA RGNL'',''GRAND ISLAND'',''NEBRASKA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.RR HH';
wwv_flow_imp.g_varchar2_table(1908) := '24:MI:SSXFF''),1847,3,1847,4440,2294,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-98.30964, 4';
wwv_flow_imp.g_varchar2_table(1909) := '0.96754, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT';
wwv_flow_imp.g_varchar2_table(1910) := '_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_CO';
wwv_flow_imp.g_varchar2_table(1911) := 'VERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11076,''EAR'',''AIRPORT'',''KEARNEY RGNL'',''KEARNEY'',''';
wwv_flow_imp.g_varchar2_table(1912) := 'NEBRASKA'',''Mar-43'',to_timestamp(''01.03.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2132,4,2500,2190,550';
wwv_flow_imp.g_varchar2_table(1913) := ',MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-99.00677, 40.72704, NULL), NULL, NULL));'||wwv_flow.LF||
'Inser';
wwv_flow_imp.g_varchar2_table(1914) := 't into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DA';
wwv_flow_imp.g_varchar2_table(1915) := 'TE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,G';
wwv_flow_imp.g_varchar2_table(1916) := 'EOMETRY) values (11090,''LNK'',''AIRPORT'',''LINCOLN'',''LINCOLN'',''NEBRASKA'',''Apr-40'',to_timestamp(''01.04.1';
wwv_flow_imp.g_varchar2_table(1917) := '940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1219,4,5000,7250,6643,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.S';
wwv_flow_imp.g_varchar2_table(1918) := 'DO_POINT_TYPE(-96.75911, 40.85089, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA';
wwv_flow_imp.g_varchar2_table(1919) := '_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CI';
wwv_flow_imp.g_varchar2_table(1920) := 'TY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11095,''MCK'',''AIRPORT'',';
wwv_flow_imp.g_varchar2_table(1921) := '''MC COOK BEN NELSON RGNL'',''MC COOK'',''NEBRASKA'',''May-46'',to_timestamp(''01.05.1946 00:00:00'',''DD.MM.RR';
wwv_flow_imp.g_varchar2_table(1922) := ' HH24:MI:SSXFF''),2583,2,667,1500,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-100.59208, 4';
wwv_flow_imp.g_varchar2_table(1923) := '0.20628, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT';
wwv_flow_imp.g_varchar2_table(1924) := '_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_CO';
wwv_flow_imp.g_varchar2_table(1925) := 'VERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11117,''LBF'',''AIRPORT'',''NORTH PLATTE RGNL AIRPORT';
wwv_flow_imp.g_varchar2_table(1926) := ' LEE BIRD FIELD'',''NORTH PLATTE'',''NEBRASKA'',null,null,2777,3,1544,1300,3500,MDSYS.SDO_GEOMETRY(2001, ';
wwv_flow_imp.g_varchar2_table(1927) := '4326, MDSYS.SDO_POINT_TYPE(-100.68367, 41.12622, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIR';
wwv_flow_imp.g_varchar2_table(1928) := 'PORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELE';
wwv_flow_imp.g_varchar2_table(1929) := 'VATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11130,''O';
wwv_flow_imp.g_varchar2_table(1930) := 'MA'',''AIRPORT'',''EPPLEY AIRFIELD'',''OMAHA'',''NEBRASKA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.M';
wwv_flow_imp.g_varchar2_table(1931) := 'M.RR HH24:MI:SSXFF''),985,3,2650,55843,18296,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-95.';
wwv_flow_imp.g_varchar2_table(1932) := '89406, 41.30317, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE';
wwv_flow_imp.g_varchar2_table(1933) := ',AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND';
wwv_flow_imp.g_varchar2_table(1934) := '_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11157,''BFF'',''AIRPORT'',''WESTERN NEBRASKA ';
wwv_flow_imp.g_varchar2_table(1935) := 'RGNL/WILLIAM B HEILIG FIELD'',''SCOTTSBLUFF'',''NEBRASKA'',''Feb-44'',to_timestamp(''01.02.1944 00:00:00'',''D';
wwv_flow_imp.g_varchar2_table(1936) := 'D.MM.RR HH24:MI:SSXFF''),3967,3,1806,3589,627,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-10';
wwv_flow_imp.g_varchar2_table(1937) := '3.59564, 41.87403, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TY';
wwv_flow_imp.g_varchar2_table(1938) := 'PE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LA';
wwv_flow_imp.g_varchar2_table(1939) := 'ND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11253,''2G8'',''AIRPORT'',''GORHAM'',''GORHAM';
wwv_flow_imp.g_varchar2_table(1940) := ''',''NEW HAMPSHIRE'',''Sep-61'',to_timestamp(''01.09.1961 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),835,1,15,0,0';
wwv_flow_imp.g_varchar2_table(1941) := ',MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-71.19809, 44.39358, NULL), NULL, NULL));'||wwv_flow.LF||
'Inser';
wwv_flow_imp.g_varchar2_table(1942) := 't into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DA';
wwv_flow_imp.g_varchar2_table(1943) := 'TE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,G';
wwv_flow_imp.g_varchar2_table(1944) := 'EOMETRY) values (11275,''AFN'',''AIRPORT'',''JAFFREY AIRPORT-SILVER RANCH'',''JAFFREY'',''NEW HAMPSHIRE'',''Feb';
wwv_flow_imp.g_varchar2_table(1945) := '-47'',to_timestamp(''01.02.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1040,1,80,0,400,MDSYS.SDO_GEOMETRY';
wwv_flow_imp.g_varchar2_table(1946) := '(2001, 4326, MDSYS.SDO_POINT_TYPE(-72.00302, 42.80513, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_M';
wwv_flow_imp.g_varchar2_table(1947) := 'AP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_';
wwv_flow_imp.g_varchar2_table(1948) := 'DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11';
wwv_flow_imp.g_varchar2_table(1949) := '287,''LEB'',''AIRPORT'',''LEBANON MUNI'',''LEBANON'',''NEW HAMPSHIRE'',''Nov-46'',to_timestamp(''01.11.1946 00:00';
wwv_flow_imp.g_varchar2_table(1950) := ':00'',''DD.MM.RR HH24:MI:SSXFF''),603,3,563,4125,6203,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TY';
wwv_flow_imp.g_varchar2_table(1951) := 'PE(-72.30419, 43.62611, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPO';
wwv_flow_imp.g_varchar2_table(1952) := 'RT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPO';
wwv_flow_imp.g_varchar2_table(1953) := 'RT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11298,''MHT'',''AIRPORT'',''MANCHESTER';
wwv_flow_imp.g_varchar2_table(1954) := ''',''MANCHESTER'',''NEW HAMPSHIRE'',''Sep-43'',to_timestamp(''01.09.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF'')';
wwv_flow_imp.g_varchar2_table(1955) := ',266,3,1500,20893,13466,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-71.43575, 42.93281, NUL';
wwv_flow_imp.g_varchar2_table(1956) := 'L), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,S';
wwv_flow_imp.g_varchar2_table(1957) := 'TATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMER';
wwv_flow_imp.g_varchar2_table(1958) := 'CIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11323,''ASH'',''AIRPORT'',''BOIRE FIELD'',''NASHUA'',''NEW HAMPSHIRE''';
wwv_flow_imp.g_varchar2_table(1959) := ',''Mar-47'',to_timestamp(''01.03.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),200,3,400,0,200,MDSYS.SDO_GEO';
wwv_flow_imp.g_varchar2_table(1960) := 'METRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-71.51409, 42.78241, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAM';
wwv_flow_imp.g_varchar2_table(1961) := 'PLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_';
wwv_flow_imp.g_varchar2_table(1962) := 'DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) value';
wwv_flow_imp.g_varchar2_table(1963) := 's (11332,''2B3'',''AIRPORT'',''PARLIN FIELD'',''NEWPORT'',''NEW HAMPSHIRE'',''Feb-47'',to_timestamp(''01.02.1947 ';
wwv_flow_imp.g_varchar2_table(1964) := '00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),785,2,125,0,50,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TY';
wwv_flow_imp.g_varchar2_table(1965) := 'PE(-72.18761, 43.38707, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPO';
wwv_flow_imp.g_varchar2_table(1966) := 'RT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPO';
wwv_flow_imp.g_varchar2_table(1967) := 'RT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11344,''NH33'',''HELIPORT'',''BRIGHAM''';
wwv_flow_imp.g_varchar2_table(1968) := ',''PEMBROKE'',''NEW HAMPSHIRE'',''May-89'',to_timestamp(''01.05.1989 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),36';
wwv_flow_imp.g_varchar2_table(1969) := '0,1,6,55,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-71.47729, 43.19591, NULL), NULL, ';
wwv_flow_imp.g_varchar2_table(1970) := 'NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,';
wwv_flow_imp.g_varchar2_table(1971) := 'ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,A';
wwv_flow_imp.g_varchar2_table(1972) := 'IR_TAXI_OPS,GEOMETRY) values (11355,''PSM'',''AIRPORT'',''PORTSMOUTH INTL AT PEASE'',''PORTSMOUTH'',''NEW HAM';
wwv_flow_imp.g_varchar2_table(1973) := 'PSHIRE'',''Jan-46'',to_timestamp(''01.01.1946 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),100,1,3000,1842,7275,M';
wwv_flow_imp.g_varchar2_table(1974) := 'DSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-70.82328, 43.07794, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert ';
wwv_flow_imp.g_varchar2_table(1975) := 'into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(1976) := ',ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEO';
wwv_flow_imp.g_varchar2_table(1977) := 'METRY) values (11358,''DAW'',''AIRPORT'',''SKYHAVEN'',''ROCHESTER'',''NEW HAMPSHIRE'',''Aug-47'',to_timestamp(''0';
wwv_flow_imp.g_varchar2_table(1978) := '1.08.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),322,3,195,0,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(1979) := '_POINT_TYPE(-70.92955, 43.28423, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_C';
wwv_flow_imp.g_varchar2_table(1980) := 'ODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY';
wwv_flow_imp.g_varchar2_table(1981) := '_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11394,''ACY'',''AIRPORT'',''A';
wwv_flow_imp.g_varchar2_table(1982) := 'TLANTIC CITY INTL'',''ATLANTIC CITY'',''NEW JERSEY'',''Jun-43'',to_timestamp(''01.06.1943 00:00:00'',''DD.MM.R';
wwv_flow_imp.g_varchar2_table(1983) := 'R HH24:MI:SSXFF''),75,9,5000,7102,4671,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-74.57717,';
wwv_flow_imp.g_varchar2_table(1984) := ' 39.45758, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPO';
wwv_flow_imp.g_varchar2_table(1985) := 'RT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_';
wwv_flow_imp.g_varchar2_table(1986) := 'COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11433,''CDW'',''AIRPORT'',''ESSEX COUNTY'',''CALDWELL';
wwv_flow_imp.g_varchar2_table(1987) := ''',''NEW JERSEY'',''Feb-38'',to_timestamp(''01.02.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),172,2,275,1,175';
wwv_flow_imp.g_varchar2_table(1988) := '0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-74.28136, 40.87522, NULL), NULL, NULL));'||wwv_flow.LF||
'Inse';
wwv_flow_imp.g_varchar2_table(1989) := 'rt into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(1990) := 'ATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,';
wwv_flow_imp.g_varchar2_table(1991) := 'GEOMETRY) values (11562,''MMU'',''AIRPORT'',''MORRISTOWN MUNI'',''MORRISTOWN'',''NEW JERSEY'',''May-43'',to_time';
wwv_flow_imp.g_varchar2_table(1992) := 'stamp(''01.05.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),187,3,625,9,11228,MDSYS.SDO_GEOMETRY(2001, 432';
wwv_flow_imp.g_varchar2_table(1993) := '6, MDSYS.SDO_POINT_TYPE(-74.41489, 40.79933, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORT';
wwv_flow_imp.g_varchar2_table(1994) := 'S (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATI';
wwv_flow_imp.g_varchar2_table(1995) := 'ON,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11574,''EWR'',';
wwv_flow_imp.g_varchar2_table(1996) := '''AIRPORT'',''NEWARK LIBERTY INTL'',''NEWARK'',''NEW JERSEY'',''Nov-39'',to_timestamp(''01.11.1939 00:00:00'',''D';
wwv_flow_imp.g_varchar2_table(1997) := 'D.MM.RR HH24:MI:SSXFF''),17,3,2027,351188,85397,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-';
wwv_flow_imp.g_varchar2_table(1998) := '74.16869, 40.69248, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_T';
wwv_flow_imp.g_varchar2_table(1999) := 'YPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,L';
wwv_flow_imp.g_varchar2_table(2000) := 'AND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11660,''TEB'',''AIRPORT'',''TETERBORO'',''TE';
wwv_flow_imp.g_varchar2_table(2001) := 'TERBORO'',''NEW JERSEY'',''Jan-47'',to_timestamp(''01.01.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),8,1,827,';
wwv_flow_imp.g_varchar2_table(2002) := '112,78921,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-74.06083, 40.85011, NULL), NULL, NULL';
wwv_flow_imp.g_varchar2_table(2003) := '));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTI';
wwv_flow_imp.g_varchar2_table(2004) := 'VATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_T';
wwv_flow_imp.g_varchar2_table(2005) := 'AXI_OPS,GEOMETRY) values (11672,''TTN'',''AIRPORT'',''TRENTON MERCER'',''TRENTON'',''NEW JERSEY'',''Mar-43'',to_';
wwv_flow_imp.g_varchar2_table(2006) := 'timestamp(''01.03.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),213,4,1345,4546,4218,MDSYS.SDO_GEOMETRY(20';
wwv_flow_imp.g_varchar2_table(2007) := '01, 4326, MDSYS.SDO_POINT_TYPE(-74.81347, 40.27669, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_';
wwv_flow_imp.g_varchar2_table(2008) := 'AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,';
wwv_flow_imp.g_varchar2_table(2009) := 'ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11719';
wwv_flow_imp.g_varchar2_table(2010) := ',''ABQ'',''AIRPORT'',''ALBUQUERQUE INTL SUNPORT'',''ALBUQUERQUE'',''NEW MEXICO'',''Nov-38'',to_timestamp(''01.11.';
wwv_flow_imp.g_varchar2_table(2011) := '1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),5355,3,2039,58685,27345,MDSYS.SDO_GEOMETRY(2001, 4326, MDSY';
wwv_flow_imp.g_varchar2_table(2012) := 'S.SDO_POINT_TYPE(-106.60826, 35.03893, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,';
wwv_flow_imp.g_varchar2_table(2013) := 'IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIS';
wwv_flow_imp.g_varchar2_table(2014) := 'T_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11740,''CNM'',''AIRPO';
wwv_flow_imp.g_varchar2_table(2015) := 'RT'',''CAVERN CITY AIR TRML'',''CARLSBAD'',''NEW MEXICO'',''Apr-41'',to_timestamp(''01.04.1941 00:00:00'',''DD.M';
wwv_flow_imp.g_varchar2_table(2016) := 'M.RR HH24:MI:SSXFF''),3295,5,1980,2669,303,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-104.2';
wwv_flow_imp.g_varchar2_table(2017) := '6336, 32.33744, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,';
wwv_flow_imp.g_varchar2_table(2018) := 'AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_';
wwv_flow_imp.g_varchar2_table(2019) := 'AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11753,''CVN'',''AIRPORT'',''CLOVIS MUNI'',''CLOV';
wwv_flow_imp.g_varchar2_table(2020) := 'IS'',''NEW MEXICO'',''Apr-59'',to_timestamp(''01.04.1959 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4216,6,1480,0';
wwv_flow_imp.g_varchar2_table(2021) := ',1905,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-103.07758, 34.42659, NULL), NULL, NULL));';
wwv_flow_imp.g_varchar2_table(2022) := ''||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVAT';
wwv_flow_imp.g_varchar2_table(2023) := 'ION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI';
wwv_flow_imp.g_varchar2_table(2024) := '_OPS,GEOMETRY) values (11772,''FMN'',''AIRPORT'',''FOUR CORNERS RGNL'',''FARMINGTON'',''NEW MEXICO'',null,null';
wwv_flow_imp.g_varchar2_table(2025) := ',5506,1,603,0,3331,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-108.22994, 36.74125, NULL), ';
wwv_flow_imp.g_varchar2_table(2026) := 'NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE';
wwv_flow_imp.g_varchar2_table(2027) := '_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL';
wwv_flow_imp.g_varchar2_table(2028) := '_OPS,AIR_TAXI_OPS,GEOMETRY) values (11779,''GUP'',''AIRPORT'',''GALLUP MUNI'',''GALLUP'',''NEW MEXICO'',null,n';
wwv_flow_imp.g_varchar2_table(2029) := 'ull,6472,3,359,0,3000,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-108.78931, 35.51106, NULL';
wwv_flow_imp.g_varchar2_table(2030) := '), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,ST';
wwv_flow_imp.g_varchar2_table(2031) := 'ATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERC';
wwv_flow_imp.g_varchar2_table(2032) := 'IAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11786,''HOB'',''AIRPORT'',''LEA COUNTY RGNL'',''HOBBS'',''NEW MEXICO'',';
wwv_flow_imp.g_varchar2_table(2033) := '''Jun-42'',to_timestamp(''01.06.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),3661,4,898,1362,2076,MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(2034) := '_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-103.21733, 32.6875, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA';
wwv_flow_imp.g_varchar2_table(2035) := '_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVAT';
wwv_flow_imp.g_varchar2_table(2036) := 'ION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) v';
wwv_flow_imp.g_varchar2_table(2037) := 'alues (11840,''ROW'',''AIRPORT'',''ROSWELL AIR CENTER'',''ROSWELL'',''NEW MEXICO'',''Oct-67'',to_timestamp(''01.1';
wwv_flow_imp.g_varchar2_table(2038) := '0.1967 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),3671,3,5029,1638,4314,MDSYS.SDO_GEOMETRY(2001, 4326, MDSY';
wwv_flow_imp.g_varchar2_table(2039) := 'S.SDO_POINT_TYPE(-104.5294, 33.29987, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,I';
wwv_flow_imp.g_varchar2_table(2040) := 'ATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST';
wwv_flow_imp.g_varchar2_table(2041) := '_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11843,''SRR'',''AIRPOR';
wwv_flow_imp.g_varchar2_table(2042) := 'T'',''SIERRA BLANCA RGNL'',''RUIDOSO'',''NEW MEXICO'',''Dec-87'',to_timestamp(''01.12.1987 00:00:00'',''DD.MM.RR';
wwv_flow_imp.g_varchar2_table(2043) := ' HH24:MI:SSXFF''),6814,15,1665,125,1004,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-105.5301';
wwv_flow_imp.g_varchar2_table(2044) := '4, 33.46094, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIR';
wwv_flow_imp.g_varchar2_table(2045) := 'PORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_ARE';
wwv_flow_imp.g_varchar2_table(2046) := 'A_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11845,''SAF'',''AIRPORT'',''SANTA FE MUNI'',''SANTA';
wwv_flow_imp.g_varchar2_table(2047) := ' FE'',''NEW MEXICO'',''Jun-42'',to_timestamp(''01.06.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),6349,9,2128,';
wwv_flow_imp.g_varchar2_table(2048) := '2911,4989,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-106.08942, 35.61711, NULL), NULL, NUL';
wwv_flow_imp.g_varchar2_table(2049) := 'L));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACT';
wwv_flow_imp.g_varchar2_table(2050) := 'IVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_';
wwv_flow_imp.g_varchar2_table(2051) := 'TAXI_OPS,GEOMETRY) values (11858,''SVC'',''AIRPORT'',''GRANT COUNTY'',''SILVER CITY'',''NEW MEXICO'',''Jul-42'',';
wwv_flow_imp.g_varchar2_table(2052) := 'to_timestamp(''01.07.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),5446,10,740,1250,375,MDSYS.SDO_GEOMETRY';
wwv_flow_imp.g_varchar2_table(2053) := '(2001, 4326, MDSYS.SDO_POINT_TYPE(-108.15639, 32.63655, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_';
wwv_flow_imp.g_varchar2_table(2054) := 'MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(2055) := '_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1';
wwv_flow_imp.g_varchar2_table(2056) := '1906,''EKO'',''AIRPORT'',''ELKO RGNL'',''ELKO'',''NEVADA'',''Apr-40'',to_timestamp(''01.04.1940 00:00:00'',''DD.MM.';
wwv_flow_imp.g_varchar2_table(2057) := 'RR HH24:MI:SSXFF''),5140,1,700,2350,3834,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-115.791';
wwv_flow_imp.g_varchar2_table(2058) := '33, 40.825, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRP';
wwv_flow_imp.g_varchar2_table(2059) := 'ORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA';
wwv_flow_imp.g_varchar2_table(2060) := '_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11909,''ELY'',''AIRPORT'',''ELY ARPT /YELLAND FLD/';
wwv_flow_imp.g_varchar2_table(2061) := ''',''ELY'',''NEVADA'',''Nov-38'',to_timestamp(''01.11.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),6260,3,4999,0';
wwv_flow_imp.g_varchar2_table(2062) := ',1095,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-114.84188, 39.29969, NULL), NULL, NULL));';
wwv_flow_imp.g_varchar2_table(2063) := ''||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVAT';
wwv_flow_imp.g_varchar2_table(2064) := 'ION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI';
wwv_flow_imp.g_varchar2_table(2065) := '_OPS,GEOMETRY) values (11937,''VGT'',''AIRPORT'',''NORTH LAS VEGAS'',''LAS VEGAS'',''NEVADA'',''Jan-42'',to_time';
wwv_flow_imp.g_varchar2_table(2066) := 'stamp(''01.01.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2205,3,920,18,19956,MDSYS.SDO_GEOMETRY(2001, 4';
wwv_flow_imp.g_varchar2_table(2067) := '326, MDSYS.SDO_POINT_TYPE(-115.19444, 36.2107, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPO';
wwv_flow_imp.g_varchar2_table(2068) := 'RTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVA';
wwv_flow_imp.g_varchar2_table(2069) := 'TION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11943,''LAS';
wwv_flow_imp.g_varchar2_table(2070) := ''',''AIRPORT'',''MC CARRAN INTL'',''LAS VEGAS'',''NEVADA'',''Jan-47'',to_timestamp(''01.01.1947 00:00:00'',''DD.MM';
wwv_flow_imp.g_varchar2_table(2071) := '.RR HH24:MI:SSXFF''),2181,5,2800,366704,128828,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-1';
wwv_flow_imp.g_varchar2_table(2072) := '15.15223, 36.08004, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_T';
wwv_flow_imp.g_varchar2_table(2073) := 'YPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,L';
wwv_flow_imp.g_varchar2_table(2074) := 'AND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (11946,''HND'',''AIRPORT'',''HENDERSON EXEC';
wwv_flow_imp.g_varchar2_table(2075) := 'UTIVE'',''LAS VEGAS'',''NEVADA'',''Oct-70'',to_timestamp(''01.10.1970 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),24';
wwv_flow_imp.g_varchar2_table(2076) := '92,11,760,0,16408,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-115.13444, 35.97286, NULL), N';
wwv_flow_imp.g_varchar2_table(2077) := 'ULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_';
wwv_flow_imp.g_varchar2_table(2078) := 'NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_';
wwv_flow_imp.g_varchar2_table(2079) := 'OPS,AIR_TAXI_OPS,GEOMETRY) values (11979,''RNO'',''AIRPORT'',''RENO/TAHOE INTL'',''RENO'',''NEVADA'',''Nov-38'',';
wwv_flow_imp.g_varchar2_table(2080) := 'to_timestamp(''01.11.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4415,3,1450,47970,11063,MDSYS.SDO_GEOME';
wwv_flow_imp.g_varchar2_table(2081) := 'TRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-119.76811, 39.49911, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMP';
wwv_flow_imp.g_varchar2_table(2082) := 'LE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(2083) := 'ATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values';
wwv_flow_imp.g_varchar2_table(2084) := ' (12019,''0NY2'',''HELIPORT'',''AMAR'',''STONY POINT'',''NEW YORK'',''Apr-16'',to_timestamp(''01.04.2016 00:00:00';
wwv_flow_imp.g_varchar2_table(2085) := ''',''DD.MM.RR HH24:MI:SSXFF''),507,2,0,0,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-74.0473';
wwv_flow_imp.g_varchar2_table(2086) := '3, 41.23103, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIR';
wwv_flow_imp.g_varchar2_table(2087) := 'PORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_ARE';
wwv_flow_imp.g_varchar2_table(2088) := 'A_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12024,''ALB'',''AIRPORT'',''ALBANY INTL'',''ALBANY''';
wwv_flow_imp.g_varchar2_table(2089) := ',''NEW YORK'',''Mar-41'',to_timestamp(''01.03.1941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),285,6,1000,24729,1';
wwv_flow_imp.g_varchar2_table(2090) := '9212,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-73.80198, 42.74912, NULL), NULL, NULL));'||wwv_flow.LF||
'I';
wwv_flow_imp.g_varchar2_table(2091) := 'nsert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(2092) := 'N_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_O';
wwv_flow_imp.g_varchar2_table(2093) := 'PS,GEOMETRY) values (12063,''BGM'',''AIRPORT'',''GREATER BINGHAMTON/EDWIN A LINK FIELD'',''BINGHAMTON'',''NEW';
wwv_flow_imp.g_varchar2_table(2094) := ' YORK'',''Sep-50'',to_timestamp(''01.09.1950 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1636,7,1199,16,2756,MDS';
wwv_flow_imp.g_varchar2_table(2095) := 'YS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-75.97961, 42.20844, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert in';
wwv_flow_imp.g_varchar2_table(2096) := 'to EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,A';
wwv_flow_imp.g_varchar2_table(2097) := 'CTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOME';
wwv_flow_imp.g_varchar2_table(2098) := 'TRY) values (12079,''BUF'',''AIRPORT'',''BUFFALO NIAGARA INTL'',''BUFFALO'',''NEW YORK'',''Mar-40'',to_timestamp';
wwv_flow_imp.g_varchar2_table(2099) := '(''01.03.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),727,5,1000,54405,17713,MDSYS.SDO_GEOMETRY(2001, 432';
wwv_flow_imp.g_varchar2_table(2100) := '6, MDSYS.SDO_POINT_TYPE(-78.73058, 42.94042, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORT';
wwv_flow_imp.g_varchar2_table(2101) := 'S (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATI';
wwv_flow_imp.g_varchar2_table(2102) := 'ON,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12160,''ELM'',';
wwv_flow_imp.g_varchar2_table(2103) := '''AIRPORT'',''ELMIRA/CORNING RGNL'',''ELMIRA/CORNING'',''NEW YORK'',''Nov-40'',to_timestamp(''01.11.1940 00:00:';
wwv_flow_imp.g_varchar2_table(2104) := '00'',''DD.MM.RR HH24:MI:SSXFF''),955,6,1000,3904,4348,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TY';
wwv_flow_imp.g_varchar2_table(2105) := 'PE(-76.89175, 42.15986, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPO';
wwv_flow_imp.g_varchar2_table(2106) := 'RT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPO';
wwv_flow_imp.g_varchar2_table(2107) := 'RT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12173,''FRG'',''AIRPORT'',''REPUBLIC'',';
wwv_flow_imp.g_varchar2_table(2108) := '''FARMINGDALE'',''NEW YORK'',''Mar-40'',to_timestamp(''01.03.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),80,1,';
wwv_flow_imp.g_varchar2_table(2109) := '526,78,11771,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-73.41342, 40.72878, NULL), NULL, N';
wwv_flow_imp.g_varchar2_table(2110) := 'ULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,A';
wwv_flow_imp.g_varchar2_table(2111) := 'CTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AI';
wwv_flow_imp.g_varchar2_table(2112) := 'R_TAXI_OPS,GEOMETRY) values (12211,''1H4'',''AIRPORT'',''GREENVILLE-RAINBOW'',''GREENVILLE'',''NEW YORK'',''Jun';
wwv_flow_imp.g_varchar2_table(2113) := '-48'',to_timestamp(''01.06.1948 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),840,1,12,75,null,MDSYS.SDO_GEOMETR';
wwv_flow_imp.g_varchar2_table(2114) := 'Y(2001, 4326, MDSYS.SDO_POINT_TYPE(-74.00689, 42.4197, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_M';
wwv_flow_imp.g_varchar2_table(2115) := 'AP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_';
wwv_flow_imp.g_varchar2_table(2116) := 'DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12';
wwv_flow_imp.g_varchar2_table(2117) := '249,''ITH'',''AIRPORT'',''ITHACA TOMPKINS RGNL'',''ITHACA'',''NEW YORK'',''Oct-47'',to_timestamp(''01.10.1947 00:';
wwv_flow_imp.g_varchar2_table(2118) := '00:00'',''DD.MM.RR HH24:MI:SSXFF''),1099,3,531,3,6958,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TY';
wwv_flow_imp.g_varchar2_table(2119) := 'PE(-76.45872, 42.49136, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPO';
wwv_flow_imp.g_varchar2_table(2120) := 'RT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPO';
wwv_flow_imp.g_varchar2_table(2121) := 'RT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12252,''JHW'',''AIRPORT'',''CHAUTAUQUA';
wwv_flow_imp.g_varchar2_table(2122) := ' COUNTY/JAMESTOWN'',''JAMESTOWN'',''NEW YORK'',''Dec-38'',to_timestamp(''01.12.1938 00:00:00'',''DD.MM.RR HH24';
wwv_flow_imp.g_varchar2_table(2123) := ':MI:SSXFF''),1723,3,788,0,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-79.25802, 42.1533';
wwv_flow_imp.g_varchar2_table(2124) := '9, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,';
wwv_flow_imp.g_varchar2_table(2125) := 'CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,';
wwv_flow_imp.g_varchar2_table(2126) := 'COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12342,''SWF'',''AIRPORT'',''NEW YORK STEWART INTL'',''NEW YOR';
wwv_flow_imp.g_varchar2_table(2127) := 'K'',''NEW YORK'',''May-41'',to_timestamp(''01.05.1941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),491,44,1552,5016';
wwv_flow_imp.g_varchar2_table(2128) := ',6921,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-74.10483, 41.50411, NULL), NULL, NULL));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2129) := 'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATI';
wwv_flow_imp.g_varchar2_table(2130) := 'ON_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_';
wwv_flow_imp.g_varchar2_table(2131) := 'OPS,GEOMETRY) values (12347,''ISP'',''AIRPORT'',''LONG ISLAND MAC ARTHUR'',''NEW YORK'',''NEW YORK'',''May-43'',';
wwv_flow_imp.g_varchar2_table(2132) := 'to_timestamp(''01.05.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),99,40,1311,11445,7116,MDSYS.SDO_GEOMETR';
wwv_flow_imp.g_varchar2_table(2133) := 'Y(2001, 4326, MDSYS.SDO_POINT_TYPE(-73.10067, 40.79614, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_';
wwv_flow_imp.g_varchar2_table(2134) := 'MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(2135) := '_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1';
wwv_flow_imp.g_varchar2_table(2136) := '2354,''JFK'',''AIRPORT'',''JOHN F KENNEDY INTL'',''NEW YORK'',''NEW YORK'',''Jan-39'',to_timestamp(''01.01.1939 0';
wwv_flow_imp.g_varchar2_table(2137) := '0:00:00'',''DD.MM.RR HH24:MI:SSXFF''),13,13,5200,423230,30903,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(2138) := 'POINT_TYPE(-73.77869, 40.63993, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CO';
wwv_flow_imp.g_varchar2_table(2139) := 'DE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_';
wwv_flow_imp.g_varchar2_table(2140) := 'TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12355,''LGA'',''AIRPORT'',''LA';
wwv_flow_imp.g_varchar2_table(2141) := 'GUARDIA'',''NEW YORK'',''NEW YORK'',null,null,21,4,680,317955,51178,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.';
wwv_flow_imp.g_varchar2_table(2142) := 'SDO_POINT_TYPE(-73.87261, 40.77725, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IAT';
wwv_flow_imp.g_varchar2_table(2143) := 'A_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_C';
wwv_flow_imp.g_varchar2_table(2144) := 'ITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12356,''IAG'',''AIRPORT''';
wwv_flow_imp.g_varchar2_table(2145) := ',''NIAGARA FALLS INTL'',''NIAGARA FALLS'',''NEW YORK'',''Nov-46'',to_timestamp(''01.11.1946 00:00:00'',''DD.MM.';
wwv_flow_imp.g_varchar2_table(2146) := 'RR HH24:MI:SSXFF''),592,4,1067,1084,633,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-78.94585';
wwv_flow_imp.g_varchar2_table(2147) := ', 43.10756, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRP';
wwv_flow_imp.g_varchar2_table(2148) := 'ORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA';
wwv_flow_imp.g_varchar2_table(2149) := '_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12371,''OGS'',''AIRPORT'',''OGDENSBURG INTL'',''OGDE';
wwv_flow_imp.g_varchar2_table(2150) := 'NSBURG'',''NEW YORK'',''Aug-47'',to_timestamp(''01.08.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),302,2,500,1';
wwv_flow_imp.g_varchar2_table(2151) := '31,1065,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-75.46325, 44.68225, NULL), NULL, NULL))';
wwv_flow_imp.g_varchar2_table(2152) := ';'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVA';
wwv_flow_imp.g_varchar2_table(2153) := 'TION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAX';
wwv_flow_imp.g_varchar2_table(2154) := 'I_OPS,GEOMETRY) values (12411,''PBG'',''AIRPORT'',''PLATTSBURGH INTL'',''PLATTSBURGH'',''NEW YORK'',null,null,';
wwv_flow_imp.g_varchar2_table(2155) := '234,3,1912,2348,2304,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-73.46814, 44.65094, NULL),';
wwv_flow_imp.g_varchar2_table(2156) := ' NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STAT';
wwv_flow_imp.g_varchar2_table(2157) := 'E_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIA';
wwv_flow_imp.g_varchar2_table(2158) := 'L_OPS,AIR_TAXI_OPS,GEOMETRY) values (12418,''POU'',''AIRPORT'',''HUDSON VALLEY RGNL'',''POUGHKEEPSIE'',''NEW ';
wwv_flow_imp.g_varchar2_table(2159) := 'YORK'',''Apr-41'',to_timestamp(''01.04.1941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),164,4,640,10,1632,MDSYS.';
wwv_flow_imp.g_varchar2_table(2160) := 'SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-73.88419, 41.62658, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into ';
wwv_flow_imp.g_varchar2_table(2161) := 'EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTI';
wwv_flow_imp.g_varchar2_table(2162) := 'VATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY';
wwv_flow_imp.g_varchar2_table(2163) := ') values (12441,''ROC'',''AIRPORT'',''GREATER ROCHESTER INTL'',''ROCHESTER'',''NEW YORK'',''Mar-40'',to_timestam';
wwv_flow_imp.g_varchar2_table(2164) := 'p(''01.03.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),559,3,1136,23026,22647,MDSYS.SDO_GEOMETRY(2001, 43';
wwv_flow_imp.g_varchar2_table(2165) := '26, MDSYS.SDO_POINT_TYPE(-77.67187, 43.11914, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPOR';
wwv_flow_imp.g_varchar2_table(2166) := 'TS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVAT';
wwv_flow_imp.g_varchar2_table(2167) := 'ION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12443,''RME''';
wwv_flow_imp.g_varchar2_table(2168) := ',''AIRPORT'',''GRIFFISS INTL'',''ROME'',''NEW YORK'',''Jun-47'',to_timestamp(''01.06.1947 00:00:00'',''DD.MM.RR H';
wwv_flow_imp.g_varchar2_table(2169) := 'H24:MI:SSXFF''),504,1,1680,10,577,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-75.40703, 43.2';
wwv_flow_imp.g_varchar2_table(2170) := '3381, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NA';
wwv_flow_imp.g_varchar2_table(2171) := 'ME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVER';
wwv_flow_imp.g_varchar2_table(2172) := 'ED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12465,''SCH'',''AIRPORT'',''SCHENECTADY COUNTY'',''SCHENEC';
wwv_flow_imp.g_varchar2_table(2173) := 'TADY'',''NEW YORK'',''Jan-40'',to_timestamp(''01.01.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),378,3,680,0,1';
wwv_flow_imp.g_varchar2_table(2174) := '133,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-73.92897, 42.85256, NULL), NULL, NULL));'||wwv_flow.LF||
'In';
wwv_flow_imp.g_varchar2_table(2175) := 'sert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION';
wwv_flow_imp.g_varchar2_table(2176) := '_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OP';
wwv_flow_imp.g_varchar2_table(2177) := 'S,GEOMETRY) values (12513,''SYR'',''AIRPORT'',''SYRACUSE HANCOCK INTL'',''SYRACUSE'',''NEW YORK'',''Aug-43'',to_';
wwv_flow_imp.g_varchar2_table(2178) := 'timestamp(''01.08.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),421,4,2000,27894,15047,MDSYS.SDO_GEOMETRY(';
wwv_flow_imp.g_varchar2_table(2179) := '2001, 4326, MDSYS.SDO_POINT_TYPE(-76.10631, 43.11119, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MA';
wwv_flow_imp.g_varchar2_table(2180) := 'P_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_D';
wwv_flow_imp.g_varchar2_table(2181) := 'T,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (125';
wwv_flow_imp.g_varchar2_table(2182) := '39,''ART'',''AIRPORT'',''WATERTOWN INTL'',''WATERTOWN'',''NEW YORK'',''Mar-40'',to_timestamp(''01.03.1940 00:00:0';
wwv_flow_imp.g_varchar2_table(2183) := '0'',''DD.MM.RR HH24:MI:SSXFF''),331,5,1060,1456,1200,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYP';
wwv_flow_imp.g_varchar2_table(2184) := 'E(-76.01942, 43.99183, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPOR';
wwv_flow_imp.g_varchar2_table(2185) := 'T_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPOR';
wwv_flow_imp.g_varchar2_table(2186) := 'T,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12558,''HPN'',''AIRPORT'',''WESTCHESTER';
wwv_flow_imp.g_varchar2_table(2187) := ' COUNTY'',''WHITE PLAINS'',''NEW YORK'',''Nov-43'',to_timestamp(''01.11.1943 00:00:00'',''DD.MM.RR HH24:MI:SSX';
wwv_flow_imp.g_varchar2_table(2188) := 'FF''),439,3,702,8413,13724,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-73.70757, 41.06695, N';
wwv_flow_imp.g_varchar2_table(2189) := 'ULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY';
wwv_flow_imp.g_varchar2_table(2190) := ',STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMM';
wwv_flow_imp.g_varchar2_table(2191) := 'ERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12573,''CAK'',''AIRPORT'',''AKRON-CANTON RGNL'',''AKRON'',''OHIO'',n';
wwv_flow_imp.g_varchar2_table(2192) := 'ull,null,1226,10,2300,4045,14589,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.44364, 40.9';
wwv_flow_imp.g_varchar2_table(2193) := '1506, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NA';
wwv_flow_imp.g_varchar2_table(2194) := 'ME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVER';
wwv_flow_imp.g_varchar2_table(2195) := 'ED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12697,''LUK'',''AIRPORT'',''CINCINNATI MUNI AIRPORT LUNK';
wwv_flow_imp.g_varchar2_table(2196) := 'EN FIELD'',''CINCINNATI'',''OHIO'',null,null,483,3,1140,22,13236,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(2197) := '_POINT_TYPE(-84.41861, 39.10333, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_C';
wwv_flow_imp.g_varchar2_table(2198) := 'ODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY';
wwv_flow_imp.g_varchar2_table(2199) := '_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12706,''CLE'',''AIRPORT'',''C';
wwv_flow_imp.g_varchar2_table(2200) := 'LEVELAND-HOPKINS INTL'',''CLEVELAND'',''OHIO'',''Nov-38'',to_timestamp(''01.11.1938 00:00:00'',''DD.MM.RR HH24';
wwv_flow_imp.g_varchar2_table(2201) := ':MI:SSXFF''),799,9,1717,84147,34651,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.85469, 41';
wwv_flow_imp.g_varchar2_table(2202) := '.40942, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(2203) := 'NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COV';
wwv_flow_imp.g_varchar2_table(2204) := 'ERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12715,''BKL'',''AIRPORT'',''BURKE LAKEFRONT'',''CLEVELAN';
wwv_flow_imp.g_varchar2_table(2205) := 'D'',''OHIO'',''Apr-48'',to_timestamp(''01.04.1948 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),584,1,450,526,11105,';
wwv_flow_imp.g_varchar2_table(2206) := 'MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.68264, 41.51786, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert';
wwv_flow_imp.g_varchar2_table(2207) := ' into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DAT';
wwv_flow_imp.g_varchar2_table(2208) := 'E,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GE';
wwv_flow_imp.g_varchar2_table(2209) := 'OMETRY) values (12745,''LCK'',''AIRPORT'',''RICKENBACKER INTL'',''COLUMBUS'',''OHIO'',''Jul-43'',to_timestamp(''0';
wwv_flow_imp.g_varchar2_table(2210) := '1.07.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),744,10,4342,14173,null,MDSYS.SDO_GEOMETRY(2001, 4326, ';
wwv_flow_imp.g_varchar2_table(2211) := 'MDSYS.SDO_POINT_TYPE(-82.92781, 39.81378, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (';
wwv_flow_imp.g_varchar2_table(2212) := 'ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,';
wwv_flow_imp.g_varchar2_table(2213) := 'DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12746,''OSU'',''AI';
wwv_flow_imp.g_varchar2_table(2214) := 'RPORT'',''OHIO STATE UNIVERSITY'',''COLUMBUS'',''OHIO'',''Aug-43'',to_timestamp(''01.08.1943 00:00:00'',''DD.MM.';
wwv_flow_imp.g_varchar2_table(2215) := 'RR HH24:MI:SSXFF''),906,10,1080,5,15720,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-83.07321';
wwv_flow_imp.g_varchar2_table(2216) := ', 40.07952, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRP';
wwv_flow_imp.g_varchar2_table(2217) := 'ORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA';
wwv_flow_imp.g_varchar2_table(2218) := '_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (12747,''CMH'',''AIRPORT'',''JOHN GLENN COLUMBUS IN';
wwv_flow_imp.g_varchar2_table(2219) := 'TL'',''COLUMBUS'',''OHIO'',''Oct-37'',to_timestamp(''01.10.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),815,6,22';
wwv_flow_imp.g_varchar2_table(2220) := '65,83816,29404,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-82.89216, 39.99695, NULL), NULL,';
wwv_flow_imp.g_varchar2_table(2221) := ' NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME';
wwv_flow_imp.g_varchar2_table(2222) := ',ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,';
wwv_flow_imp.g_varchar2_table(2223) := 'AIR_TAXI_OPS,GEOMETRY) values (12765,''DAY'',''AIRPORT'',''JAMES M COX DAYTON INTL'',''DAYTON'',''OHIO'',''Oct-';
wwv_flow_imp.g_varchar2_table(2224) := '37'',to_timestamp(''01.10.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1009,9,4200,16967,21771,MDSYS.SDO_G';
wwv_flow_imp.g_varchar2_table(2225) := 'EOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-84.21942, 39.90225, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_S';
wwv_flow_imp.g_varchar2_table(2226) := 'AMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(2227) := 'N_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) val';
wwv_flow_imp.g_varchar2_table(2228) := 'ues (12939,''MFD'',''AIRPORT'',''MANSFIELD LAHM RGNL'',''MANSFIELD'',''OHIO'',''Dec-37'',to_timestamp(''01.12.193';
wwv_flow_imp.g_varchar2_table(2229) := '7 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1297,3,2340,8,1106,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_PO';
wwv_flow_imp.g_varchar2_table(2230) := 'INT_TYPE(-82.51664, 40.82142, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE';
wwv_flow_imp.g_varchar2_table(2231) := ',AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO';
wwv_flow_imp.g_varchar2_table(2232) := '_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (13133,''TOL'',''AIRPORT'',''TOLE';
wwv_flow_imp.g_varchar2_table(2233) := 'DO EXPRESS'',''TOLEDO'',''OHIO'',''Jan-55'',to_timestamp(''01.01.1955 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),68';
wwv_flow_imp.g_varchar2_table(2234) := '3,10,2345,1902,1175,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-83.80783, 41.58681, NULL), ';
wwv_flow_imp.g_varchar2_table(2235) := 'NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE';
wwv_flow_imp.g_varchar2_table(2236) := '_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL';
wwv_flow_imp.g_varchar2_table(2237) := '_OPS,AIR_TAXI_OPS,GEOMETRY) values (13193,''ILN'',''AIRPORT'',''WILMINGTON AIR PARK'',''WILMINGTON'',''OHIO'',';
wwv_flow_imp.g_varchar2_table(2238) := '''Sep-72'',to_timestamp(''01.09.1972 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1077,2,2000,100,900,MDSYS.SDO_';
wwv_flow_imp.g_varchar2_table(2239) := 'GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-83.79211, 39.42792, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_';
wwv_flow_imp.g_varchar2_table(2240) := 'SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATI';
wwv_flow_imp.g_varchar2_table(2241) := 'ON_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) va';
wwv_flow_imp.g_varchar2_table(2242) := 'lues (13213,''YNG'',''AIRPORT'',''YOUNGSTOWN-WARREN RGNL'',''YOUNGSTOWN/WARREN'',''OHIO'',''Jan-38'',to_timestam';
wwv_flow_imp.g_varchar2_table(2243) := 'p(''01.01.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1192,10,1468,99,2582,MDSYS.SDO_GEOMETRY(2001, 4326';
wwv_flow_imp.g_varchar2_table(2244) := ', MDSYS.SDO_POINT_TYPE(-80.68036, 41.26158, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS';
wwv_flow_imp.g_varchar2_table(2245) := ' (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATIO';
wwv_flow_imp.g_varchar2_table(2246) := 'N,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (13329,''OK06'',';
wwv_flow_imp.g_varchar2_table(2247) := '''AIRPORT'',''SNAKE CREEK WILDERNESS'',''COOKSON'',''OKLAHOMA'',''Oct-05'',to_timestamp(''01.10.2005 00:00:00'',';
wwv_flow_imp.g_varchar2_table(2248) := '''DD.MM.RR HH24:MI:SSXFF''),1130,3,1500,4,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-94';
wwv_flow_imp.g_varchar2_table(2249) := '.95, 35.64778, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,A';
wwv_flow_imp.g_varchar2_table(2250) := 'IRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_A';
wwv_flow_imp.g_varchar2_table(2251) := 'REA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (13396,''GUY'',''AIRPORT'',''GUYMON MUNI'',''GUYMO';
wwv_flow_imp.g_varchar2_table(2252) := 'N'',''OKLAHOMA'',''May-49'',to_timestamp(''01.05.1949 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),3125,1,480,0,120';
wwv_flow_imp.g_varchar2_table(2253) := '0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-101.50697, 36.68416, NULL), NULL, NULL));'||wwv_flow.LF||
'Ins';
wwv_flow_imp.g_varchar2_table(2254) := 'ert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_';
wwv_flow_imp.g_varchar2_table(2255) := 'DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS';
wwv_flow_imp.g_varchar2_table(2256) := ',GEOMETRY) values (13454,''LAW'',''AIRPORT'',''LAWTON-FORT SILL RGNL'',''LAWTON'',''OKLAHOMA'',''Dec-48'',to_tim';
wwv_flow_imp.g_varchar2_table(2257) := 'estamp(''01.12.1948 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1110,2,1300,121,1867,MDSYS.SDO_GEOMETRY(2001,';
wwv_flow_imp.g_varchar2_table(2258) := ' 4326, MDSYS.SDO_POINT_TYPE(-98.41664, 34.56771, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIR';
wwv_flow_imp.g_varchar2_table(2259) := 'PORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELE';
wwv_flow_imp.g_varchar2_table(2260) := 'VATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (13523,''O';
wwv_flow_imp.g_varchar2_table(2261) := 'UN'',''AIRPORT'',''UNIVERSITY OF OKLAHOMA WESTHEIMER'',''NORMAN'',''OKLAHOMA'',''Jan-41'',to_timestamp(''01.01.1';
wwv_flow_imp.g_varchar2_table(2262) := '941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1182,3,727,2,677,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_PO';
wwv_flow_imp.g_varchar2_table(2263) := 'INT_TYPE(-97.47214, 35.24556, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE';
wwv_flow_imp.g_varchar2_table(2264) := ',AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO';
wwv_flow_imp.g_varchar2_table(2265) := '_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (13546,''OKC'',''AIRPORT'',''WILL';
wwv_flow_imp.g_varchar2_table(2266) := ' ROGERS WORLD'',''OKLAHOMA CITY'',''OKLAHOMA'',''Dec-38'',to_timestamp(''01.12.1938 00:00:00'',''DD.MM.RR HH24';
wwv_flow_imp.g_varchar2_table(2267) := ':MI:SSXFF''),1296,6,8081,49323,8525,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.60076, 35';
wwv_flow_imp.g_varchar2_table(2268) := '.39307, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(2269) := 'NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COV';
wwv_flow_imp.g_varchar2_table(2270) := 'ERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (13618,''SWO'',''AIRPORT'',''STILLWATER RGNL'',''STILLWAT';
wwv_flow_imp.g_varchar2_table(2271) := 'ER'',''OKLAHOMA'',''May-43'',to_timestamp(''01.05.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1000,3,1571,26,';
wwv_flow_imp.g_varchar2_table(2272) := '2495,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.08589, 36.16139, NULL), NULL, NULL));'||wwv_flow.LF||
'I';
wwv_flow_imp.g_varchar2_table(2273) := 'nsert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(2274) := 'N_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_O';
wwv_flow_imp.g_varchar2_table(2275) := 'PS,GEOMETRY) values (13644,''RVS'',''AIRPORT'',''RICHARD LLOYD JONES JR'',''TULSA'',''OKLAHOMA'',''Jul-58'',to_t';
wwv_flow_imp.g_varchar2_table(2276) := 'imestamp(''01.07.1958 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),638,5,664,25,2680,MDSYS.SDO_GEOMETRY(2001, ';
wwv_flow_imp.g_varchar2_table(2277) := '4326, MDSYS.SDO_POINT_TYPE(-95.9846, 36.03958, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPO';
wwv_flow_imp.g_varchar2_table(2278) := 'RTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVA';
wwv_flow_imp.g_varchar2_table(2279) := 'TION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (13652,''TUL';
wwv_flow_imp.g_varchar2_table(2280) := ''',''AIRPORT'',''TULSA INTL'',''TULSA'',''OKLAHOMA'',''Aug-42'',to_timestamp(''01.08.1942 00:00:00'',''DD.MM.RR HH';
wwv_flow_imp.g_varchar2_table(2281) := '24:MI:SSXFF''),678,5,4360,34711,15633,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-95.88811, ';
wwv_flow_imp.g_varchar2_table(2282) := '36.19839, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPOR';
wwv_flow_imp.g_varchar2_table(2283) := 'T_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_C';
wwv_flow_imp.g_varchar2_table(2284) := 'OVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (13820,''EUG'',''AIRPORT'',''MAHLON SWEET FIELD'',''EUG';
wwv_flow_imp.g_varchar2_table(2285) := 'ENE'',''OREGON'',''Feb-43'',to_timestamp(''01.02.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),374,7,2600,8658,';
wwv_flow_imp.g_varchar2_table(2286) := '10125,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-123.21197, 44.12458, NULL), NULL, NULL));';
wwv_flow_imp.g_varchar2_table(2287) := ''||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVAT';
wwv_flow_imp.g_varchar2_table(2288) := 'ION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI';
wwv_flow_imp.g_varchar2_table(2289) := '_OPS,GEOMETRY) values (13882,''LMT'',''AIRPORT'',''CRATER LAKE-KLAMATH RGNL'',''KLAMATH FALLS'',''OREGON'',''No';
wwv_flow_imp.g_varchar2_table(2290) := 'v-37'',to_timestamp(''01.11.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4095,4,1166,0,3491,MDSYS.SDO_GEOM';
wwv_flow_imp.g_varchar2_table(2291) := 'ETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-121.7332, 42.15614, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMP';
wwv_flow_imp.g_varchar2_table(2292) := 'LE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(2293) := 'ATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values';
wwv_flow_imp.g_varchar2_table(2294) := ' (13922,''MFR'',''AIRPORT'',''ROGUE VALLEY INTL - MEDFORD'',''MEDFORD'',''OREGON'',null,null,1335,3,905,11154,';
wwv_flow_imp.g_varchar2_table(2295) := '8754,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-122.8735, 42.37422, NULL), NULL, NULL));'||wwv_flow.LF||
'I';
wwv_flow_imp.g_varchar2_table(2296) := 'nsert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(2297) := 'N_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_O';
wwv_flow_imp.g_varchar2_table(2298) := 'PS,GEOMETRY) values (13947,''OTH'',''AIRPORT'',''SOUTHWEST OREGON RGNL'',''NORTH BEND'',''OREGON'',''Jan-40'',to';
wwv_flow_imp.g_varchar2_table(2299) := '_timestamp(''01.01.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),17,1,619,67,7058,MDSYS.SDO_GEOMETRY(2001,';
wwv_flow_imp.g_varchar2_table(2300) := ' 4326, MDSYS.SDO_POINT_TYPE(-124.24703, 43.41694, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AI';
wwv_flow_imp.g_varchar2_table(2301) := 'RPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,EL';
wwv_flow_imp.g_varchar2_table(2302) := 'EVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (13970,''';
wwv_flow_imp.g_varchar2_table(2303) := 'PDT'',''AIRPORT'',''EASTERN OREGON RGNL AT PENDLETON'',''PENDLETON'',''OREGON'',''Oct-37'',to_timestamp(''01.10.';
wwv_flow_imp.g_varchar2_table(2304) := '1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1497,3,2273,0,4171,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(2305) := '_POINT_TYPE(-118.84301, 45.69477, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_';
wwv_flow_imp.g_varchar2_table(2306) := 'CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CIT';
wwv_flow_imp.g_varchar2_table(2307) := 'Y_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (13985,''PDX'',''AIRPORT'',''';
wwv_flow_imp.g_varchar2_table(2308) := 'PORTLAND INTL'',''PORTLAND'',''OREGON'',''Mar-40'',to_timestamp(''01.03.1940 00:00:00'',''DD.MM.RR HH24:MI:SSX';
wwv_flow_imp.g_varchar2_table(2309) := 'FF''),31,4,3000,195797,20635,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-122.59687, 45.58871';
wwv_flow_imp.g_varchar2_table(2310) := ', NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,C';
wwv_flow_imp.g_varchar2_table(2311) := 'ITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,C';
wwv_flow_imp.g_varchar2_table(2312) := 'OMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14002,''RDM'',''AIRPORT'',''ROBERTS FIELD'',''REDMOND'',''OREGON';
wwv_flow_imp.g_varchar2_table(2313) := ''',''Sep-38'',to_timestamp(''01.09.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),3082,1,2518,10812,7341,MDSYS';
wwv_flow_imp.g_varchar2_table(2314) := '.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-121.14997, 44.25407, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert int';
wwv_flow_imp.g_varchar2_table(2315) := 'o EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,AC';
wwv_flow_imp.g_varchar2_table(2316) := 'TIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMET';
wwv_flow_imp.g_varchar2_table(2317) := 'RY) values (14019,''SLE'',''AIRPORT'',''MCNARY FLD'',''SALEM'',''OREGON'',''Nov-37'',to_timestamp(''01.11.1937 00';
wwv_flow_imp.g_varchar2_table(2318) := ':00:00'',''DD.MM.RR HH24:MI:SSXFF''),213,2,751,0,3776,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TY';
wwv_flow_imp.g_varchar2_table(2319) := 'PE(-123.0025, 44.90953, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPO';
wwv_flow_imp.g_varchar2_table(2320) := 'RT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPO';
wwv_flow_imp.g_varchar2_table(2321) := 'RT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14116,''ABE'',''AIRPORT'',''LEHIGH VAL';
wwv_flow_imp.g_varchar2_table(2322) := 'LEY INTL'',''ALLENTOWN'',''PENNSYLVANIA'',''Jun-38'',to_timestamp(''01.06.1938 00:00:00'',''DD.MM.RR HH24:MI:S';
wwv_flow_imp.g_varchar2_table(2323) := 'SXFF''),394,3,2278,11642,9596,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-75.44041, 40.65236';
wwv_flow_imp.g_varchar2_table(2324) := ', NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,C';
wwv_flow_imp.g_varchar2_table(2325) := 'ITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,C';
wwv_flow_imp.g_varchar2_table(2326) := 'OMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14169,''BFD'',''AIRPORT'',''BRADFORD RGNL'',''BRADFORD'',''PENNS';
wwv_flow_imp.g_varchar2_table(2327) := 'YLVANIA'',''Nov-77'',to_timestamp(''01.11.1977 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2143,10,1015,2302,298';
wwv_flow_imp.g_varchar2_table(2328) := ',MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-78.63997, 41.80295, NULL), NULL, NULL));'||wwv_flow.LF||
'Inser';
wwv_flow_imp.g_varchar2_table(2329) := 't into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DA';
wwv_flow_imp.g_varchar2_table(2330) := 'TE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,G';
wwv_flow_imp.g_varchar2_table(2331) := 'EOMETRY) values (14272,''DUJ'',''AIRPORT'',''DUBOIS RGNL'',''DUBOIS'',''PENNSYLVANIA'',''May-60'',to_timestamp(''';
wwv_flow_imp.g_varchar2_table(2332) := '01.05.1960 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1817,7,399,4122,1806,MDSYS.SDO_GEOMETRY(2001, 4326, M';
wwv_flow_imp.g_varchar2_table(2333) := 'DSYS.SDO_POINT_TYPE(-78.89869, 41.17828, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (I';
wwv_flow_imp.g_varchar2_table(2334) := 'D,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,D';
wwv_flow_imp.g_varchar2_table(2335) := 'IST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14302,''ERI'',''AIR';
wwv_flow_imp.g_varchar2_table(2336) := 'PORT'',''ERIE INTL/TOM RIDGE FIELD'',''ERIE'',''PENNSYLVANIA'',''May-38'',to_timestamp(''01.05.1938 00:00:00'',';
wwv_flow_imp.g_varchar2_table(2337) := '''DD.MM.RR HH24:MI:SSXFF''),732,5,450,0,6098,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-80.1';
wwv_flow_imp.g_varchar2_table(2338) := '7394, 42.08308, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,';
wwv_flow_imp.g_varchar2_table(2339) := 'AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_';
wwv_flow_imp.g_varchar2_table(2340) := 'AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14335,''FKL'',''AIRPORT'',''VENANGO RGNL'',''FRA';
wwv_flow_imp.g_varchar2_table(2341) := 'NKLIN'',''PENNSYLVANIA'',null,null,1540,2,420,0,1883,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYP';
wwv_flow_imp.g_varchar2_table(2342) := 'E(-79.86064, 41.37742, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPOR';
wwv_flow_imp.g_varchar2_table(2343) := 'T_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPOR';
wwv_flow_imp.g_varchar2_table(2344) := 'T,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14382,''MDT'',''AIRPORT'',''HARRISBURG ';
wwv_flow_imp.g_varchar2_table(2345) := 'INTL'',''HARRISBURG'',''PENNSYLVANIA'',''Jul-42'',to_timestamp(''01.07.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXF';
wwv_flow_imp.g_varchar2_table(2346) := 'F''),310,8,680,30696,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-76.76262, 40.19319, NU';
wwv_flow_imp.g_varchar2_table(2347) := 'LL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,';
wwv_flow_imp.g_varchar2_table(2348) := 'STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMME';
wwv_flow_imp.g_varchar2_table(2349) := 'RCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14420,''JST'',''AIRPORT'',''JOHN MURTHA JOHNSTOWN-CAMBRIA CO'',''J';
wwv_flow_imp.g_varchar2_table(2350) := 'OHNSTOWN'',''PENNSYLVANIA'',''Jun-48'',to_timestamp(''01.06.1948 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2284,';
wwv_flow_imp.g_varchar2_table(2351) := '3,650,3666,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-78.83467, 40.31556, NULL), NULL, N';
wwv_flow_imp.g_varchar2_table(2352) := 'ULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,A';
wwv_flow_imp.g_varchar2_table(2353) := 'CTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AI';
wwv_flow_imp.g_varchar2_table(2354) := 'R_TAXI_OPS,GEOMETRY) values (14441,''LNS'',''AIRPORT'',''LANCASTER'',''LANCASTER'',''PENNSYLVANIA'',null,null,';
wwv_flow_imp.g_varchar2_table(2355) := '403,4,850,0,4483,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-76.29436, 40.12236, NULL), NUL';
wwv_flow_imp.g_varchar2_table(2356) := 'L, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NA';
wwv_flow_imp.g_varchar2_table(2357) := 'ME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OP';
wwv_flow_imp.g_varchar2_table(2358) := 'S,AIR_TAXI_OPS,GEOMETRY) values (14455,''LBE'',''AIRPORT'',''ARNOLD PALMER RGNL'',''LATROBE'',''PENNSYLVANIA''';
wwv_flow_imp.g_varchar2_table(2359) := ',''Apr-38'',to_timestamp(''01.04.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1199,2,945,1973,5117,MDSYS.SD';
wwv_flow_imp.g_varchar2_table(2360) := 'O_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-79.41033, 40.2731, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA';
wwv_flow_imp.g_varchar2_table(2361) := '_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVAT';
wwv_flow_imp.g_varchar2_table(2362) := 'ION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) v';
wwv_flow_imp.g_varchar2_table(2363) := 'alues (14632,''PHL'',''AIRPORT'',''PHILADELPHIA INTL'',''PHILADELPHIA'',''PENNSYLVANIA'',''Oct-40'',to_timestamp';
wwv_flow_imp.g_varchar2_table(2364) := '(''01.10.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),36,5,2302,259799,104919,MDSYS.SDO_GEOMETRY(2001, 43';
wwv_flow_imp.g_varchar2_table(2365) := '26, MDSYS.SDO_POINT_TYPE(-75.24066, 39.87208, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPOR';
wwv_flow_imp.g_varchar2_table(2366) := 'TS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVAT';
wwv_flow_imp.g_varchar2_table(2367) := 'ION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14657,''AGC''';
wwv_flow_imp.g_varchar2_table(2368) := ',''AIRPORT'',''ALLEGHENY COUNTY'',''PITTSBURGH'',''PENNSYLVANIA'',''Nov-37'',to_timestamp(''01.11.1937 00:00:00';
wwv_flow_imp.g_varchar2_table(2369) := ''',''DD.MM.RR HH24:MI:SSXFF''),1252,4,432,11,19591,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(';
wwv_flow_imp.g_varchar2_table(2370) := '-79.92905, 40.35444, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_';
wwv_flow_imp.g_varchar2_table(2371) := 'TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,';
wwv_flow_imp.g_varchar2_table(2372) := 'LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14658,''PIT'',''AIRPORT'',''PITTSBURGH IN';
wwv_flow_imp.g_varchar2_table(2373) := 'TL'',''PITTSBURGH'',''PENNSYLVANIA'',''Mar-44'',to_timestamp(''01.03.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''';
wwv_flow_imp.g_varchar2_table(2374) := '),1203,12,10000,100765,35630,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-80.23269, 40.49142';
wwv_flow_imp.g_varchar2_table(2375) := ', NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,C';
wwv_flow_imp.g_varchar2_table(2376) := 'ITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,C';
wwv_flow_imp.g_varchar2_table(2377) := 'OMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14685,''RDG'',''AIRPORT'',''READING RGNL/CARL A SPAATZ FIELD';
wwv_flow_imp.g_varchar2_table(2378) := ''',''READING'',''PENNSYLVANIA'',''Apr-38'',to_timestamp(''01.04.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),344';
wwv_flow_imp.g_varchar2_table(2379) := ',3,888,45,4479,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-75.96525, 40.3785, NULL), NULL, ';
wwv_flow_imp.g_varchar2_table(2380) := 'NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,';
wwv_flow_imp.g_varchar2_table(2381) := 'ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,A';
wwv_flow_imp.g_varchar2_table(2382) := 'IR_TAXI_OPS,GEOMETRY) values (14745,''UNV'',''AIRPORT'',''UNIVERSITY PARK'',''STATE COLLEGE'',''PENNSYLVANIA''';
wwv_flow_imp.g_varchar2_table(2383) := ',''Mar-59'',to_timestamp(''01.03.1959 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1231,3,1091,171,13153,MDSYS.S';
wwv_flow_imp.g_varchar2_table(2384) := 'DO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-77.84758, 40.85, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_';
wwv_flow_imp.g_varchar2_table(2385) := 'SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATI';
wwv_flow_imp.g_varchar2_table(2386) := 'ON_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) va';
wwv_flow_imp.g_varchar2_table(2387) := 'lues (14838,''AVP'',''AIRPORT'',''WILKES-BARRE/SCRANTON INTL'',''WILKES-BARRE/SCRANTON'',''PENNSYLVANIA'',''Jan';
wwv_flow_imp.g_varchar2_table(2388) := '-47'',to_timestamp(''01.01.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),962,5,910,3782,13006,MDSYS.SDO_GEO';
wwv_flow_imp.g_varchar2_table(2389) := 'METRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-75.72339, 41.33847, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAM';
wwv_flow_imp.g_varchar2_table(2390) := 'PLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_';
wwv_flow_imp.g_varchar2_table(2391) := 'DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) value';
wwv_flow_imp.g_varchar2_table(2392) := 's (14844,''IPT'',''AIRPORT'',''WILLIAMSPORT RGNL'',''WILLIAMSPORT'',''PENNSYLVANIA'',''Apr-38'',to_timestamp(''01';
wwv_flow_imp.g_varchar2_table(2393) := '.04.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),528,4,535,3,2967,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.S';
wwv_flow_imp.g_varchar2_table(2394) := 'DO_POINT_TYPE(-76.92181, 41.24167, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA';
wwv_flow_imp.g_varchar2_table(2395) := '_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CI';
wwv_flow_imp.g_varchar2_table(2396) := 'TY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14869,''BQN'',''AIRPORT'',';
wwv_flow_imp.g_varchar2_table(2397) := '''RAFAEL HERNANDEZ'',''AGUADILLA'',''PUERTO RICO'',null,null,237,3,1600,4418,2777,MDSYS.SDO_GEOMETRY(2001,';
wwv_flow_imp.g_varchar2_table(2398) := ' 4326, MDSYS.SDO_POINT_TYPE(-67.12944, 18.49486, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIR';
wwv_flow_imp.g_varchar2_table(2399) := 'PORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELE';
wwv_flow_imp.g_varchar2_table(2400) := 'VATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14886,''V';
wwv_flow_imp.g_varchar2_table(2401) := 'QS'',''AIRPORT'',''ANTONIO RIVERA RODRIGUEZ'',''ISLA DE VIEQUES'',''PUERTO RICO'',''Aug-68'',to_timestamp(''01.0';
wwv_flow_imp.g_varchar2_table(2402) := '8.1968 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),49,3,124,8046,20352,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.';
wwv_flow_imp.g_varchar2_table(2403) := 'SDO_POINT_TYPE(-65.49362, 18.13481, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IAT';
wwv_flow_imp.g_varchar2_table(2404) := 'A_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_C';
wwv_flow_imp.g_varchar2_table(2405) := 'ITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14894,''PSE'',''AIRPORT''';
wwv_flow_imp.g_varchar2_table(2406) := ',''MERCEDITA'',''PONCE'',''PUERTO RICO'',''Apr-48'',to_timestamp(''01.04.1948 00:00:00'',''DD.MM.RR HH24:MI:SSX';
wwv_flow_imp.g_varchar2_table(2407) := 'FF''),28,3,274,1594,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-66.56452, 18.00878, NULL),';
wwv_flow_imp.g_varchar2_table(2408) := ' NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STAT';
wwv_flow_imp.g_varchar2_table(2409) := 'E_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIA';
wwv_flow_imp.g_varchar2_table(2410) := 'L_OPS,AIR_TAXI_OPS,GEOMETRY) values (14901,''SJU'',''AIRPORT'',''LUIS MUNOZ MARIN INTL'',''SAN JUAN'',''PUERT';
wwv_flow_imp.g_varchar2_table(2411) := 'O RICO'',''Aug-52'',to_timestamp(''01.08.1952 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),10,3,1600,71636,51754,';
wwv_flow_imp.g_varchar2_table(2412) := 'MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-66.00213, 18.4394, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert ';
wwv_flow_imp.g_varchar2_table(2413) := 'into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(2414) := ',ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEO';
wwv_flow_imp.g_varchar2_table(2415) := 'METRY) values (14926,''PVD'',''AIRPORT'',''THEODORE FRANCIS GREEN STATE'',''PROVIDENCE'',''RHODE ISLAND'',''Sep';
wwv_flow_imp.g_varchar2_table(2416) := '-37'',to_timestamp(''01.09.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),54,6,1111,39323,11466,MDSYS.SDO_GE';
wwv_flow_imp.g_varchar2_table(2417) := 'OMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-71.42772, 41.72233, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SA';
wwv_flow_imp.g_varchar2_table(2418) := 'MPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION';
wwv_flow_imp.g_varchar2_table(2419) := '_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) valu';
wwv_flow_imp.g_varchar2_table(2420) := 'es (14945,''AND'',''AIRPORT'',''ANDERSON RGNL'',''ANDERSON'',''SOUTH CAROLINA'',''Sep-37'',to_timestamp(''01.09.1';
wwv_flow_imp.g_varchar2_table(2421) := '937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),782,3,704,0,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT';
wwv_flow_imp.g_varchar2_table(2422) := '_TYPE(-82.70939, 34.49458, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AI';
wwv_flow_imp.g_varchar2_table(2423) := 'RPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AI';
wwv_flow_imp.g_varchar2_table(2424) := 'RPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14968,''CHS'',''AIRPORT'',''CHARLES';
wwv_flow_imp.g_varchar2_table(2425) := 'TON AFB/INTL'',''CHARLESTON'',''SOUTH CAROLINA'',''Oct-37'',to_timestamp(''01.10.1937 00:00:00'',''DD.MM.RR HH';
wwv_flow_imp.g_varchar2_table(2426) := '24:MI:SSXFF''),46,9,2060,49965,15576,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-80.04053, 3';
wwv_flow_imp.g_varchar2_table(2427) := '2.89864, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT';
wwv_flow_imp.g_varchar2_table(2428) := '_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_CO';
wwv_flow_imp.g_varchar2_table(2429) := 'VERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (14981,''CAE'',''AIRPORT'',''COLUMBIA METROPOLITAN'',''C';
wwv_flow_imp.g_varchar2_table(2430) := 'OLUMBIA'',''SOUTH CAROLINA'',''Jun-42'',to_timestamp(''01.06.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),236,';
wwv_flow_imp.g_varchar2_table(2431) := '5,2600,14542,17135,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.11954, 33.93884, NULL), N';
wwv_flow_imp.g_varchar2_table(2432) := 'ULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_';
wwv_flow_imp.g_varchar2_table(2433) := 'NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_';
wwv_flow_imp.g_varchar2_table(2434) := 'OPS,AIR_TAXI_OPS,GEOMETRY) values (15002,''FLO'',''AIRPORT'',''FLORENCE RGNL'',''FLORENCE'',''SOUTH CAROLINA''';
wwv_flow_imp.g_varchar2_table(2435) := ',''Oct-37'',to_timestamp(''01.10.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),147,3,1436,124,2748,MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(2436) := '_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-79.72389, 34.18536, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA';
wwv_flow_imp.g_varchar2_table(2437) := '_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVAT';
wwv_flow_imp.g_varchar2_table(2438) := 'ION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) v';
wwv_flow_imp.g_varchar2_table(2439) := 'alues (15017,''GMU'',''AIRPORT'',''GREENVILLE DOWNTOWN'',''GREENVILLE'',''SOUTH CAROLINA'',''Sep-37'',to_timesta';
wwv_flow_imp.g_varchar2_table(2440) := 'mp(''01.09.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1048,3,385,0,11710,MDSYS.SDO_GEOMETRY(2001, 4326,';
wwv_flow_imp.g_varchar2_table(2441) := ' MDSYS.SDO_POINT_TYPE(-82.35, 34.84794, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID';
wwv_flow_imp.g_varchar2_table(2442) := ',IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DI';
wwv_flow_imp.g_varchar2_table(2443) := 'ST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15021,''GYH'',''AIRP';
wwv_flow_imp.g_varchar2_table(2444) := 'ORT'',''DONALDSON FIELD'',''GREENVILLE'',''SOUTH CAROLINA'',''Apr-43'',to_timestamp(''01.04.1943 00:00:00'',''DD';
wwv_flow_imp.g_varchar2_table(2445) := '.MM.RR HH24:MI:SSXFF''),956,6,1300,0,9415,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-82.376';
wwv_flow_imp.g_varchar2_table(2446) := '42, 34.75831, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AI';
wwv_flow_imp.g_varchar2_table(2447) := 'RPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AR';
wwv_flow_imp.g_varchar2_table(2448) := 'EA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15023,''GSP'',''AIRPORT'',''GREENVILLE SPARTANBU';
wwv_flow_imp.g_varchar2_table(2449) := 'RG INTL'',''GREER'',''SOUTH CAROLINA'',''Nov-62'',to_timestamp(''01.11.1962 00:00:00'',''DD.MM.RR HH24:MI:SSXF';
wwv_flow_imp.g_varchar2_table(2450) := 'F''),964,3,3500,30642,13384,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-82.21886, 34.89567, ';
wwv_flow_imp.g_varchar2_table(2451) := 'NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CIT';
wwv_flow_imp.g_varchar2_table(2452) := 'Y,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COM';
wwv_flow_imp.g_varchar2_table(2453) := 'MERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15035,''SC17'',''AIRPORT'',''RUSSELL'',''HOLLY HILL'',''SOUTH CARO';
wwv_flow_imp.g_varchar2_table(2454) := 'LINA'',''Nov-66'',to_timestamp(''01.11.1966 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),110,3,null,7000,1215,MDS';
wwv_flow_imp.g_varchar2_table(2455) := 'YS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-80.45981, 33.35794, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert in';
wwv_flow_imp.g_varchar2_table(2456) := 'to EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,A';
wwv_flow_imp.g_varchar2_table(2457) := 'CTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOME';
wwv_flow_imp.g_varchar2_table(2458) := 'TRY) values (15073,''MYR'',''AIRPORT'',''MYRTLE BEACH INTL'',''MYRTLE BEACH'',''SOUTH CAROLINA'',''Oct-37'',to_t';
wwv_flow_imp.g_varchar2_table(2459) := 'imestamp(''01.10.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),25,3,3795,23320,74433,MDSYS.SDO_GEOMETRY(20';
wwv_flow_imp.g_varchar2_table(2460) := '01, 4326, MDSYS.SDO_POINT_TYPE(-78.92832, 33.67974, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_';
wwv_flow_imp.g_varchar2_table(2461) := 'AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,';
wwv_flow_imp.g_varchar2_table(2462) := 'ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15078';
wwv_flow_imp.g_varchar2_table(2463) := ',''CRE'',''AIRPORT'',''GRAND STRAND'',''NORTH MYRTLE BEACH'',''SOUTH CAROLINA'',null,null,32,1,427,0,6053,MDSY';
wwv_flow_imp.g_varchar2_table(2464) := 'S.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-78.72394, 33.81175, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert int';
wwv_flow_imp.g_varchar2_table(2465) := 'o EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,AC';
wwv_flow_imp.g_varchar2_table(2466) := 'TIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMET';
wwv_flow_imp.g_varchar2_table(2467) := 'RY) values (15132,''ABR'',''AIRPORT'',''ABERDEEN RGNL'',''ABERDEEN'',''SOUTH DAKOTA'',''Dec-37'',to_timestamp(''0';
wwv_flow_imp.g_varchar2_table(2468) := '1.12.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1302,2,1284,1486,5000,MDSYS.SDO_GEOMETRY(2001, 4326, M';
wwv_flow_imp.g_varchar2_table(2469) := 'DSYS.SDO_POINT_TYPE(-98.42244, 45.4468, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID';
wwv_flow_imp.g_varchar2_table(2470) := ',IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DI';
wwv_flow_imp.g_varchar2_table(2471) := 'ST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15149,''BKX'',''AIRP';
wwv_flow_imp.g_varchar2_table(2472) := 'ORT'',''BROOKINGS RGNL'',''BROOKINGS'',''SOUTH DAKOTA'',''Nov-49'',to_timestamp(''01.11.1949 00:00:00'',''DD.MM.';
wwv_flow_imp.g_varchar2_table(2473) := 'RR HH24:MI:SSXFF''),1648,0,576,0,650,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-96.81892, 4';
wwv_flow_imp.g_varchar2_table(2474) := '4.30453, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT';
wwv_flow_imp.g_varchar2_table(2475) := '_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_CO';
wwv_flow_imp.g_varchar2_table(2476) := 'VERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15254,''PIR'',''AIRPORT'',''PIERRE RGNL'',''PIERRE'',''SO';
wwv_flow_imp.g_varchar2_table(2477) := 'UTH DAKOTA'',''Dec-37'',to_timestamp(''01.12.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1744,3,1834,1460,7';
wwv_flow_imp.g_varchar2_table(2478) := '500,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-100.28597, 44.38269, NULL), NULL, NULL));'||wwv_flow.LF||
'I';
wwv_flow_imp.g_varchar2_table(2479) := 'nsert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(2480) := 'N_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_O';
wwv_flow_imp.g_varchar2_table(2481) := 'PS,GEOMETRY) values (15266,''RAP'',''AIRPORT'',''RAPID CITY RGNL'',''RAPID CITY'',''SOUTH DAKOTA'',''Aug-50'',to';
wwv_flow_imp.g_varchar2_table(2482) := '_timestamp(''01.08.1950 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),3204,8,1655,3579,11815,MDSYS.SDO_GEOMETRY';
wwv_flow_imp.g_varchar2_table(2483) := '(2001, 4326, MDSYS.SDO_POINT_TYPE(-103.05736, 44.04533, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_';
wwv_flow_imp.g_varchar2_table(2484) := 'MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(2485) := '_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1';
wwv_flow_imp.g_varchar2_table(2486) := '5276,''FSD'',''AIRPORT'',''JOE FOSS FIELD'',''SIOUX FALLS'',''SOUTH DAKOTA'',''Nov-38'',to_timestamp(''01.11.1938';
wwv_flow_imp.g_varchar2_table(2487) := ' 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1430,3,1570,11180,27847,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SD';
wwv_flow_imp.g_varchar2_table(2488) := 'O_POINT_TYPE(-96.74192, 43.58201, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_';
wwv_flow_imp.g_varchar2_table(2489) := 'CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CIT';
wwv_flow_imp.g_varchar2_table(2490) := 'Y_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15304,''ATY'',''AIRPORT'',''';
wwv_flow_imp.g_varchar2_table(2491) := 'WATERTOWN RGNL'',''WATERTOWN'',''SOUTH DAKOTA'',''Dec-37'',to_timestamp(''01.12.1937 00:00:00'',''DD.MM.RR HH2';
wwv_flow_imp.g_varchar2_table(2492) := '4:MI:SSXFF''),1749,2,919,676,600,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.15472, 44.91';
wwv_flow_imp.g_varchar2_table(2493) := '397, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAM';
wwv_flow_imp.g_varchar2_table(2494) := 'E,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERE';
wwv_flow_imp.g_varchar2_table(2495) := 'D,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15336,''TRI'',''AIRPORT'',''TRI-CITIES'',''BRISTOL/JOHNSON/';
wwv_flow_imp.g_varchar2_table(2496) := 'KINGSPORT'',''TENNESSEE'',''Dec-37'',to_timestamp(''01.12.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1519,12';
wwv_flow_imp.g_varchar2_table(2497) := ',1250,1587,9441,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-82.40742, 36.47521, NULL), NULL';
wwv_flow_imp.g_varchar2_table(2498) := ', NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAM';
wwv_flow_imp.g_varchar2_table(2499) := 'E,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS';
wwv_flow_imp.g_varchar2_table(2500) := ',AIR_TAXI_OPS,GEOMETRY) values (15350,''CHA'',''AIRPORT'',''LOVELL FIELD'',''CHATTANOOGA'',''TENNESSEE'',''Nov-';
wwv_flow_imp.g_varchar2_table(2501) := '37'',to_timestamp(''01.11.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),683,5,950,8476,14748,MDSYS.SDO_GEOM';
wwv_flow_imp.g_varchar2_table(2502) := 'ETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-85.20356, 35.03519, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMP';
wwv_flow_imp.g_varchar2_table(2503) := 'LE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(2504) := 'ATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values';
wwv_flow_imp.g_varchar2_table(2505) := ' (15443,''MKL'',''AIRPORT'',''MC KELLAR-SIPES RGNL'',''JACKSON'',''TENNESSEE'',''Jul-42'',to_timestamp(''01.07.19';
wwv_flow_imp.g_varchar2_table(2506) := '42 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),434,4,807,0,1564,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POI';
wwv_flow_imp.g_varchar2_table(2507) := 'NT_TYPE(-88.91561, 35.59989, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,';
wwv_flow_imp.g_varchar2_table(2508) := 'AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_';
wwv_flow_imp.g_varchar2_table(2509) := 'AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15472,''TYS'',''AIRPORT'',''MC GH';
wwv_flow_imp.g_varchar2_table(2510) := 'EE TYSON'',''KNOXVILLE'',''TENNESSEE'',''Jan-70'',to_timestamp(''01.01.1970 00:00:00'',''DD.MM.RR HH24:MI:SSXF';
wwv_flow_imp.g_varchar2_table(2511) := 'F''),979,10,2250,22564,23320,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-83.99532, 35.80937,';
wwv_flow_imp.g_varchar2_table(2512) := ' NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CI';
wwv_flow_imp.g_varchar2_table(2513) := 'TY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,CO';
wwv_flow_imp.g_varchar2_table(2514) := 'MMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15520,''MEM'',''AIRPORT'',''MEMPHIS INTL'',''MEMPHIS'',''TENNESSE';
wwv_flow_imp.g_varchar2_table(2515) := 'E'',''Aug-37'',to_timestamp(''01.08.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),341,3,3900,204061,18424,MDS';
wwv_flow_imp.g_varchar2_table(2516) := 'YS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.97668, 35.04241, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert in';
wwv_flow_imp.g_varchar2_table(2517) := 'to EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,A';
wwv_flow_imp.g_varchar2_table(2518) := 'CTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOME';
wwv_flow_imp.g_varchar2_table(2519) := 'TRY) values (15523,''NQA'',''AIRPORT'',''MILLINGTON-MEMPHIS'',''MILLINGTON'',''TENNESSEE'',''Dec-74'',to_timesta';
wwv_flow_imp.g_varchar2_table(2520) := 'mp(''01.12.1974 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),319,1,400,22,325,MDSYS.SDO_GEOMETRY(2001, 4326, M';
wwv_flow_imp.g_varchar2_table(2521) := 'DSYS.SDO_POINT_TYPE(-89.87042, 35.35664, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (I';
wwv_flow_imp.g_varchar2_table(2522) := 'D,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,D';
wwv_flow_imp.g_varchar2_table(2523) := 'IST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15542,''BNA'',''AIR';
wwv_flow_imp.g_varchar2_table(2524) := 'PORT'',''NASHVILLE INTL'',''NASHVILLE'',''TENNESSEE'',''Dec-37'',to_timestamp(''01.12.1937 00:00:00'',''DD.MM.RR';
wwv_flow_imp.g_varchar2_table(2525) := ' HH24:MI:SSXFF''),599,5,3900,147743,31084,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-86.678';
wwv_flow_imp.g_varchar2_table(2526) := '18, 36.12447, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AI';
wwv_flow_imp.g_varchar2_table(2527) := 'RPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AR';
wwv_flow_imp.g_varchar2_table(2528) := 'EA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15613,''MQY'',''AIRPORT'',''SMYRNA'',''SMYRNA'',''TE';
wwv_flow_imp.g_varchar2_table(2529) := 'NNESSEE'',''Oct-42'',to_timestamp(''01.10.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),543,2,1700,229,4503,M';
wwv_flow_imp.g_varchar2_table(2530) := 'DSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-86.52008, 36.00897, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert ';
wwv_flow_imp.g_varchar2_table(2531) := 'into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(2532) := ',ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEO';
wwv_flow_imp.g_varchar2_table(2533) := 'METRY) values (15666,''ABI'',''AIRPORT'',''ABILENE RGNL'',''ABILENE'',''TEXAS'',''Nov-53'',to_timestamp(''01.11.1';
wwv_flow_imp.g_varchar2_table(2534) := '953 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1791,3,1644,272,8522,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SD';
wwv_flow_imp.g_varchar2_table(2535) := 'O_POINT_TYPE(-99.68189, 32.41133, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_';
wwv_flow_imp.g_varchar2_table(2536) := 'CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CIT';
wwv_flow_imp.g_varchar2_table(2537) := 'Y_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15703,''AMA'',''AIRPORT'',''';
wwv_flow_imp.g_varchar2_table(2538) := 'RICK HUSBAND AMARILLO INTL'',''AMARILLO'',''TEXAS'',''Oct-37'',to_timestamp(''01.10.1937 00:00:00'',''DD.MM.RR';
wwv_flow_imp.g_varchar2_table(2539) := ' HH24:MI:SSXFF''),3607,7,3547,8152,6603,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-101.7059';
wwv_flow_imp.g_varchar2_table(2540) := '2, 35.21936, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIR';
wwv_flow_imp.g_varchar2_table(2541) := 'PORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_ARE';
wwv_flow_imp.g_varchar2_table(2542) := 'A_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15710,''LBX'',''AIRPORT'',''TEXAS GULF COAST RGNL';
wwv_flow_imp.g_varchar2_table(2543) := ''',''ANGLETON/LAKE JACKSON'',''TEXAS'',''Mar-80'',to_timestamp(''01.03.1980 00:00:00'',''DD.MM.RR HH24:MI:SSXF';
wwv_flow_imp.g_varchar2_table(2544) := 'F''),25,4,674,520,2890,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-95.46208, 29.10864, NULL)';
wwv_flow_imp.g_varchar2_table(2545) := ', NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STA';
wwv_flow_imp.g_varchar2_table(2546) := 'TE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCI';
wwv_flow_imp.g_varchar2_table(2547) := 'AL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15729,''GKY'',''AIRPORT'',''ARLINGTON MUNI'',''ARLINGTON'',''TEXAS'',''Ma';
wwv_flow_imp.g_varchar2_table(2548) := 'y-71'',to_timestamp(''01.05.1971 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),628,4,500,66,970,MDSYS.SDO_GEOMET';
wwv_flow_imp.g_varchar2_table(2549) := 'RY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.09428, 32.66386, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE';
wwv_flow_imp.g_varchar2_table(2550) := '_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DAT';
wwv_flow_imp.g_varchar2_table(2551) := 'E_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (';
wwv_flow_imp.g_varchar2_table(2552) := '15748,''AUS'',''AIRPORT'',''AUSTIN-BERGSTROM INTL'',''AUSTIN'',''TEXAS'',''Jul-43'',to_timestamp(''01.07.1943 00:';
wwv_flow_imp.g_varchar2_table(2553) := '00:00'',''DD.MM.RR HH24:MI:SSXFF''),542,5,4242,140426,16025,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_PO';
wwv_flow_imp.g_varchar2_table(2554) := 'INT_TYPE(-97.66988, 30.19453, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE';
wwv_flow_imp.g_varchar2_table(2555) := ',AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO';
wwv_flow_imp.g_varchar2_table(2556) := '_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15807,''BPT'',''AIRPORT'',''JACK';
wwv_flow_imp.g_varchar2_table(2557) := ' BROOKS RGNL'',''BEAUMONT/PORT ARTHUR'',''TEXAS'',''Apr-44'',to_timestamp(''01.04.1944 00:00:00'',''DD.MM.RR H';
wwv_flow_imp.g_varchar2_table(2558) := 'H24:MI:SSXFF''),15,9,1799,10,2280,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-94.02069, 29.9';
wwv_flow_imp.g_varchar2_table(2559) := '5083, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NA';
wwv_flow_imp.g_varchar2_table(2560) := 'ME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVER';
wwv_flow_imp.g_varchar2_table(2561) := 'ED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (15901,''BRO'',''AIRPORT'',''BROWNSVILLE/SOUTH PADRE ISLA';
wwv_flow_imp.g_varchar2_table(2562) := 'ND INTL'',''BROWNSVILLE'',''TEXAS'',''Sep-37'',to_timestamp(''01.09.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF'')';
wwv_flow_imp.g_varchar2_table(2563) := ',22,4,1700,4080,7143,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.426, 25.90614, NULL), N';
wwv_flow_imp.g_varchar2_table(2564) := 'ULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_';
wwv_flow_imp.g_varchar2_table(2565) := 'NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_';
wwv_flow_imp.g_varchar2_table(2566) := 'OPS,AIR_TAXI_OPS,GEOMETRY) values (15972,''CVB'',''AIRPORT'',''CASTROVILLE MUNI'',''CASTROVILLE'',''TEXAS'',''J';
wwv_flow_imp.g_varchar2_table(2567) := 'an-51'',to_timestamp(''01.01.1951 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),774,2,459,20,null,MDSYS.SDO_GEOM';
wwv_flow_imp.g_varchar2_table(2568) := 'ETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-98.85122, 29.34239, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMP';
wwv_flow_imp.g_varchar2_table(2569) := 'LE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(2570) := 'ATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values';
wwv_flow_imp.g_varchar2_table(2571) := ' (16024,''CLL'',''AIRPORT'',''EASTERWOOD FIELD'',''COLLEGE STATION'',''TEXAS'',''May-40'',to_timestamp(''01.05.19';
wwv_flow_imp.g_varchar2_table(2572) := '40 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),321,3,700,148,5001,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_P';
wwv_flow_imp.g_varchar2_table(2573) := 'OINT_TYPE(-96.36254, 30.58804, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_COD';
wwv_flow_imp.g_varchar2_table(2574) := 'E,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_T';
wwv_flow_imp.g_varchar2_table(2575) := 'O_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16055,''CRP'',''AIRPORT'',''COR';
wwv_flow_imp.g_varchar2_table(2576) := 'PUS CHRISTI INTL'',''CORPUS CHRISTI'',''TEXAS'',''Jul-60'',to_timestamp(''01.07.1960 00:00:00'',''DD.MM.RR HH2';
wwv_flow_imp.g_varchar2_table(2577) := '4:MI:SSXFF''),46,5,2457,7559,7423,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.50242, 27.7';
wwv_flow_imp.g_varchar2_table(2578) := '7219, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NA';
wwv_flow_imp.g_varchar2_table(2579) := 'ME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVER';
wwv_flow_imp.g_varchar2_table(2580) := 'ED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16088,''4XS8'',''HELIPORT'',''STS VIP'',''CREEDMOOR'',''TEXA';
wwv_flow_imp.g_varchar2_table(2581) := 'S'',''Jul-18'',to_timestamp(''01.07.2018 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),600,1,null,40,null,MDSYS.SD';
wwv_flow_imp.g_varchar2_table(2582) := 'O_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.72675, 30.09989, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EB';
wwv_flow_imp.g_varchar2_table(2583) := 'A_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVA';
wwv_flow_imp.g_varchar2_table(2584) := 'TION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) ';
wwv_flow_imp.g_varchar2_table(2585) := 'values (16135,''ADS'',''AIRPORT'',''ADDISON'',''DALLAS'',''TEXAS'',''Nov-56'',to_timestamp(''01.11.1956 00:00:00''';
wwv_flow_imp.g_varchar2_table(2586) := ',''DD.MM.RR HH24:MI:SSXFF''),645,9,368,68,7385,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-96';
wwv_flow_imp.g_varchar2_table(2587) := '.83644, 32.96856, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYP';
wwv_flow_imp.g_varchar2_table(2588) := 'E,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAN';
wwv_flow_imp.g_varchar2_table(2589) := 'D_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16147,''DFW'',''AIRPORT'',''DALLAS-FORT WORT';
wwv_flow_imp.g_varchar2_table(2590) := 'H INTL'',''DALLAS-FORT WORTH'',''TEXAS'',''Jan-74'',to_timestamp(''01.01.1974 00:00:00'',''DD.MM.RR HH24:MI:SS';
wwv_flow_imp.g_varchar2_table(2591) := 'XFF''),607,12,17207,615799,86854,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.03769, 32.89';
wwv_flow_imp.g_varchar2_table(2592) := '723, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAM';
wwv_flow_imp.g_varchar2_table(2593) := 'E,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERE';
wwv_flow_imp.g_varchar2_table(2594) := 'D,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16148,''DAL'',''AIRPORT'',''DALLAS LOVE FIELD'',''DALLAS'',''';
wwv_flow_imp.g_varchar2_table(2595) := 'TEXAS'',''Oct-37'',to_timestamp(''01.10.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),487,5,1300,144308,30144';
wwv_flow_imp.g_varchar2_table(2596) := ',MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-96.85088, 32.84594, NULL), NULL, NULL));'||wwv_flow.LF||
'Inser';
wwv_flow_imp.g_varchar2_table(2597) := 't into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DA';
wwv_flow_imp.g_varchar2_table(2598) := 'TE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,G';
wwv_flow_imp.g_varchar2_table(2599) := 'EOMETRY) values (16190,''DRT'',''AIRPORT'',''DEL RIO INTL'',''DEL RIO'',''TEXAS'',''Nov-37'',to_timestamp(''01.11';
wwv_flow_imp.g_varchar2_table(2600) := '.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1002,2,268,1053,2190,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.';
wwv_flow_imp.g_varchar2_table(2601) := 'SDO_POINT_TYPE(-100.92716, 29.37421, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IA';
wwv_flow_imp.g_varchar2_table(2602) := 'TA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_';
wwv_flow_imp.g_varchar2_table(2603) := 'CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16200,''DTO'',''AIRPORT';
wwv_flow_imp.g_varchar2_table(2604) := ''',''DENTON ENTERPRISE'',''DENTON'',''TEXAS'',''Dec-46'',to_timestamp(''01.12.1946 00:00:00'',''DD.MM.RR HH24:MI';
wwv_flow_imp.g_varchar2_table(2605) := ':SSXFF''),643,3,929,54,1390,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.1991, 33.20196, N';
wwv_flow_imp.g_varchar2_table(2606) := 'ULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY';
wwv_flow_imp.g_varchar2_table(2607) := ',STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMM';
wwv_flow_imp.g_varchar2_table(2608) := 'ERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16266,''ELP'',''AIRPORT'',''EL PASO INTL'',''EL PASO'',''TEXAS'',''No';
wwv_flow_imp.g_varchar2_table(2609) := 'v-38'',to_timestamp(''01.11.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),3962,4,6670,41195,14514,MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(2610) := '_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-106.37636, 31.80733, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EB';
wwv_flow_imp.g_varchar2_table(2611) := 'A_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVA';
wwv_flow_imp.g_varchar2_table(2612) := 'TION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) ';
wwv_flow_imp.g_varchar2_table(2613) := 'values (16313,''GRK'',''AIRPORT'',''ROBERT GRAY AAF'',''FORT HOOD/KILLEEN'',''TEXAS'',null,null,1015,6,null,13';
wwv_flow_imp.g_varchar2_table(2614) := '397,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.82892, 31.06725, NULL), NULL, NULL)';
wwv_flow_imp.g_varchar2_table(2615) := ');'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIV';
wwv_flow_imp.g_varchar2_table(2616) := 'ATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TA';
wwv_flow_imp.g_varchar2_table(2617) := 'XI_OPS,GEOMETRY) values (16320,''FTW'',''AIRPORT'',''FORT WORTH MEACHAM INTL'',''FORT WORTH'',''TEXAS'',''Feb-3';
wwv_flow_imp.g_varchar2_table(2618) := '8'',to_timestamp(''01.02.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),710,5,745,181,11467,MDSYS.SDO_GEOMET';
wwv_flow_imp.g_varchar2_table(2619) := 'RY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.36245, 32.81977, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE';
wwv_flow_imp.g_varchar2_table(2620) := '_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DAT';
wwv_flow_imp.g_varchar2_table(2621) := 'E_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (';
wwv_flow_imp.g_varchar2_table(2622) := '16330,''TE30'',''HELIPORT'',''HARRIS HOSPITAL'',''FORT WORTH'',''TEXAS'',''Nov-87'',to_timestamp(''01.11.1987 00:';
wwv_flow_imp.g_varchar2_table(2623) := '00:00'',''DD.MM.RR HH24:MI:SSXFF''),753,0,null,1,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TY';
wwv_flow_imp.g_varchar2_table(2624) := 'PE(-97.3381, 32.73679, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPOR';
wwv_flow_imp.g_varchar2_table(2625) := 'T_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPOR';
wwv_flow_imp.g_varchar2_table(2626) := 'T,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16347,''AFW'',''AIRPORT'',''FORT WORTH ';
wwv_flow_imp.g_varchar2_table(2627) := 'ALLIANCE'',''FORT WORTH'',''TEXAS'',''Dec-89'',to_timestamp(''01.12.1989 00:00:00'',''DD.MM.RR HH24:MI:SSXFF'')';
wwv_flow_imp.g_varchar2_table(2628) := ',723,14,1198,7874,5436,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.31944, 32.99039, NULL';
wwv_flow_imp.g_varchar2_table(2629) := '), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,ST';
wwv_flow_imp.g_varchar2_table(2630) := 'ATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERC';
wwv_flow_imp.g_varchar2_table(2631) := 'IAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16385,''GLS'',''AIRPORT'',''SCHOLES INTL AT GALVESTON'',''GALVESTON''';
wwv_flow_imp.g_varchar2_table(2632) := ',''TEXAS'',''Aug-38'',to_timestamp(''01.08.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),6,3,966,10,5712,MDSYS';
wwv_flow_imp.g_varchar2_table(2633) := '.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-94.86042, 29.26533, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into';
wwv_flow_imp.g_varchar2_table(2634) := ' EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACT';
wwv_flow_imp.g_varchar2_table(2635) := 'IVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETR';
wwv_flow_imp.g_varchar2_table(2636) := 'Y) values (16493,''HRL'',''AIRPORT'',''VALLEY INTL'',''HARLINGEN'',''TEXAS'',''Jul-43'',to_timestamp(''01.07.1943';
wwv_flow_imp.g_varchar2_table(2637) := ' 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),36,3,2428,7899,1647,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_PO';
wwv_flow_imp.g_varchar2_table(2638) := 'INT_TYPE(-97.65514, 26.22711, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE';
wwv_flow_imp.g_varchar2_table(2639) := ',AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO';
wwv_flow_imp.g_varchar2_table(2640) := '_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16559,''EFD'',''AIRPORT'',''ELLI';
wwv_flow_imp.g_varchar2_table(2641) := 'NGTON'',''HOUSTON'',''TEXAS'',''Jun-42'',to_timestamp(''01.06.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),33,15';
wwv_flow_imp.g_varchar2_table(2642) := ',2362,2154,9185,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-95.15875, 29.60733, NULL), NULL';
wwv_flow_imp.g_varchar2_table(2643) := ', NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAM';
wwv_flow_imp.g_varchar2_table(2644) := 'E,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS';
wwv_flow_imp.g_varchar2_table(2645) := ',AIR_TAXI_OPS,GEOMETRY) values (16619,''HOU'',''AIRPORT'',''WILLIAM P HOBBY'',''HOUSTON'',''TEXAS'',''Jan-39'',t';
wwv_flow_imp.g_varchar2_table(2646) := 'o_timestamp(''01.01.1939 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),46,8,1304,123823,36791,MDSYS.SDO_GEOMETR';
wwv_flow_imp.g_varchar2_table(2647) := 'Y(2001, 4326, MDSYS.SDO_POINT_TYPE(-95.27889, 29.64542, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_';
wwv_flow_imp.g_varchar2_table(2648) := 'MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(2649) := '_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1';
wwv_flow_imp.g_varchar2_table(2650) := '6620,''IAH'',''AIRPORT'',''GEORGE BUSH INTERCONTINENTAL/HOUSTON'',''HOUSTON'',''TEXAS'',''Jan-63'',to_timestamp(';
wwv_flow_imp.g_varchar2_table(2651) := '''01.01.1963 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),96,15,10000,362947,96051,MDSYS.SDO_GEOMETRY(2001, 43';
wwv_flow_imp.g_varchar2_table(2652) := '26, MDSYS.SDO_POINT_TYPE(-95.34144, 29.98444, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPOR';
wwv_flow_imp.g_varchar2_table(2653) := 'TS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVAT';
wwv_flow_imp.g_varchar2_table(2654) := 'ION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16628,''DWH''';
wwv_flow_imp.g_varchar2_table(2655) := ',''AIRPORT'',''DAVID WAYNE HOOKS MEMORIAL'',''HOUSTON'',''TEXAS'',''Sep-63'',to_timestamp(''01.09.1963 00:00:00';
wwv_flow_imp.g_varchar2_table(2656) := ''',''DD.MM.RR HH24:MI:SSXFF''),152,17,480,5,3279,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-9';
wwv_flow_imp.g_varchar2_table(2657) := '5.55279, 30.06178, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TY';
wwv_flow_imp.g_varchar2_table(2658) := 'PE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LA';
wwv_flow_imp.g_varchar2_table(2659) := 'ND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16762,''E58'',''AIRPORT'',''BIRD DOG AIRFIE';
wwv_flow_imp.g_varchar2_table(2660) := 'LD'',''KRUM'',''TEXAS'',''Feb-99'',to_timestamp(''01.02.1999 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),895,8,20,0,';
wwv_flow_imp.g_varchar2_table(2661) := 'null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.34713, 33.30646, NULL), NULL, NULL));'||wwv_flow.LF||
'I';
wwv_flow_imp.g_varchar2_table(2662) := 'nsert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(2663) := 'N_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_O';
wwv_flow_imp.g_varchar2_table(2664) := 'PS,GEOMETRY) values (16800,''LRD'',''AIRPORT'',''LAREDO INTL'',''LAREDO'',''TEXAS'',null,null,508,3,1796,6689,';
wwv_flow_imp.g_varchar2_table(2665) := '7941,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-99.46158, 27.54419, NULL), NULL, NULL));'||wwv_flow.LF||
'I';
wwv_flow_imp.g_varchar2_table(2666) := 'nsert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(2667) := 'N_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_O';
wwv_flow_imp.g_varchar2_table(2668) := 'PS,GEOMETRY) values (16857,''GGG'',''AIRPORT'',''EAST TEXAS RGNL'',''LONGVIEW'',''TEXAS'',''Jul-45'',to_timestam';
wwv_flow_imp.g_varchar2_table(2669) := 'p(''01.07.1945 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),366,8,1300,53,9612,MDSYS.SDO_GEOMETRY(2001, 4326, ';
wwv_flow_imp.g_varchar2_table(2670) := 'MDSYS.SDO_POINT_TYPE(-94.7115, 32.384, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,';
wwv_flow_imp.g_varchar2_table(2671) := 'IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIS';
wwv_flow_imp.g_varchar2_table(2672) := 'T_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16875,''LBB'',''AIRPO';
wwv_flow_imp.g_varchar2_table(2673) := 'RT'',''LUBBOCK PRESTON SMITH INTL'',''LUBBOCK'',''TEXAS'',''Nov-37'',to_timestamp(''01.11.1937 00:00:00'',''DD.M';
wwv_flow_imp.g_varchar2_table(2674) := 'M.RR HH24:MI:SSXFF''),3282,4,3000,12901,17933,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-10';
wwv_flow_imp.g_varchar2_table(2675) := '1.82056, 33.66367, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TY';
wwv_flow_imp.g_varchar2_table(2676) := 'PE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LA';
wwv_flow_imp.g_varchar2_table(2677) := 'ND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16885,''MFE'',''AIRPORT'',''MC ALLEN MILLER';
wwv_flow_imp.g_varchar2_table(2678) := ' INTL'',''MC ALLEN'',''TEXAS'',''Jan-40'',to_timestamp(''01.01.1940 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),107,';
wwv_flow_imp.g_varchar2_table(2679) := '2,370,9569,4072,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-98.23861, 26.17583, NULL), NULL';
wwv_flow_imp.g_varchar2_table(2680) := ', NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAM';
wwv_flow_imp.g_varchar2_table(2681) := 'E,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS';
wwv_flow_imp.g_varchar2_table(2682) := ',AIR_TAXI_OPS,GEOMETRY) values (16959,''HQZ'',''AIRPORT'',''MESQUITE METRO'',''MESQUITE'',''TEXAS'',''Aug-76'',t';
wwv_flow_imp.g_varchar2_table(2683) := 'o_timestamp(''01.08.1976 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),447,3,448,9,1527,MDSYS.SDO_GEOMETRY(2001';
wwv_flow_imp.g_varchar2_table(2684) := ', 4326, MDSYS.SDO_POINT_TYPE(-96.53042, 32.74696, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AI';
wwv_flow_imp.g_varchar2_table(2685) := 'RPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,EL';
wwv_flow_imp.g_varchar2_table(2686) := 'EVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16971,''';
wwv_flow_imp.g_varchar2_table(2687) := 'MAF'',''AIRPORT'',''MIDLAND INTL AIR AND SPACE PORT'',''MIDLAND'',''TEXAS'',''Sep-37'',to_timestamp(''01.09.1937';
wwv_flow_imp.g_varchar2_table(2688) := ' 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2872,8,1600,15911,7163,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(2689) := '_POINT_TYPE(-102.20192, 31.94253, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_';
wwv_flow_imp.g_varchar2_table(2690) := 'CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CIT';
wwv_flow_imp.g_varchar2_table(2691) := 'Y_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (16977,''JWY'',''AIRPORT'',''';
wwv_flow_imp.g_varchar2_table(2692) := 'MID-WAY RGNL'',''MIDLOTHIAN/WAXAHACHIE'',''TEXAS'',''Jul-92'',to_timestamp(''01.07.1992 00:00:00'',''DD.MM.RR ';
wwv_flow_imp.g_varchar2_table(2693) := 'HH24:MI:SSXFF''),727,5,243,0,200,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-96.91253, 32.45';
wwv_flow_imp.g_varchar2_table(2694) := '829, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAM';
wwv_flow_imp.g_varchar2_table(2695) := 'E,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERE';
wwv_flow_imp.g_varchar2_table(2696) := 'D,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (17301,''SJT'',''AIRPORT'',''SAN ANGELO RGNL/MATHIS FIELD''';
wwv_flow_imp.g_varchar2_table(2697) := ',''SAN ANGELO'',''TEXAS'',''Sep-43'',to_timestamp(''01.09.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1919,7,1';
wwv_flow_imp.g_varchar2_table(2698) := '503,3070,5149,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-100.49631, 31.35775, NULL), NULL,';
wwv_flow_imp.g_varchar2_table(2699) := ' NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME';
wwv_flow_imp.g_varchar2_table(2700) := ',ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,';
wwv_flow_imp.g_varchar2_table(2701) := 'AIR_TAXI_OPS,GEOMETRY) values (17328,''SAT'',''AIRPORT'',''SAN ANTONIO INTL'',''SAN ANTONIO'',''TEXAS'',''Jul-4';
wwv_flow_imp.g_varchar2_table(2702) := '2'',to_timestamp(''01.07.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),809,7,2305,97068,20546,MDSYS.SDO_GEO';
wwv_flow_imp.g_varchar2_table(2703) := 'METRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-98.46906, 29.53396, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAM';
wwv_flow_imp.g_varchar2_table(2704) := 'PLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_';
wwv_flow_imp.g_varchar2_table(2705) := 'DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) value';
wwv_flow_imp.g_varchar2_table(2706) := 's (17529,''TYR'',''AIRPORT'',''TYLER POUNDS RGNL'',''TYLER'',''TEXAS'',''Nov-37'',to_timestamp(''01.11.1937 00:00';
wwv_flow_imp.g_varchar2_table(2707) := ':00'',''DD.MM.RR HH24:MI:SSXFF''),544,3,1200,2443,4016,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_T';
wwv_flow_imp.g_varchar2_table(2708) := 'YPE(-95.40297, 32.35356, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRP';
wwv_flow_imp.g_varchar2_table(2709) := 'ORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRP';
wwv_flow_imp.g_varchar2_table(2710) := 'ORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (17572,''ACT'',''AIRPORT'',''WACO RGNL';
wwv_flow_imp.g_varchar2_table(2711) := ''',''WACO'',''TEXAS'',''Jul-43'',to_timestamp(''01.07.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),516,5,1369,12';
wwv_flow_imp.g_varchar2_table(2712) := '2,4252,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-97.23031, 31.61219, NULL), NULL, NULL));';
wwv_flow_imp.g_varchar2_table(2713) := ''||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVAT';
wwv_flow_imp.g_varchar2_table(2714) := 'ION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI';
wwv_flow_imp.g_varchar2_table(2715) := '_OPS,GEOMETRY) values (17650,''SPS'',''AIRPORT'',''SHEPPARD AFB/WICHITA FALLS MUNI'',''WICHITA FALLS'',''TEXA';
wwv_flow_imp.g_varchar2_table(2716) := 'S'',null,null,1019,5,3800,5476,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-98.4919, 33.';
wwv_flow_imp.g_varchar2_table(2717) := '9888, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NA';
wwv_flow_imp.g_varchar2_table(2718) := 'ME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVER';
wwv_flow_imp.g_varchar2_table(2719) := 'ED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (17707,''BCE'',''AIRPORT'',''BRYCE CANYON'',''BRYCE CANYON''';
wwv_flow_imp.g_varchar2_table(2720) := ',''UTAH'',''Nov-38'',to_timestamp(''01.11.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),7590,4,215,0,140,MDSYS';
wwv_flow_imp.g_varchar2_table(2721) := '.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-112.1458, 37.70645, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into';
wwv_flow_imp.g_varchar2_table(2722) := ' EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACT';
wwv_flow_imp.g_varchar2_table(2723) := 'IVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETR';
wwv_flow_imp.g_varchar2_table(2724) := 'Y) values (17708,''CDC'',''AIRPORT'',''CEDAR CITY RGNL'',''CEDAR CITY'',''UTAH'',''Jan-38'',to_timestamp(''01.01.';
wwv_flow_imp.g_varchar2_table(2725) := '1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),5622,2,1040,42,5790,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SD';
wwv_flow_imp.g_varchar2_table(2726) := 'O_POINT_TYPE(-113.09886, 37.70097, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA';
wwv_flow_imp.g_varchar2_table(2727) := '_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CI';
wwv_flow_imp.g_varchar2_table(2728) := 'TY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (17737,''HCR'',''AIRPORT'',';
wwv_flow_imp.g_varchar2_table(2729) := '''HEBER VALLEY'',''HEBER'',''UTAH'',''Nov-47'',to_timestamp(''01.11.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),';
wwv_flow_imp.g_varchar2_table(2730) := '5637,1,401,0,1550,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-111.42881, 40.48181, NULL), N';
wwv_flow_imp.g_varchar2_table(2731) := 'ULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_';
wwv_flow_imp.g_varchar2_table(2732) := 'NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_';
wwv_flow_imp.g_varchar2_table(2733) := 'OPS,AIR_TAXI_OPS,GEOMETRY) values (17762,''LGU'',''AIRPORT'',''LOGAN-CACHE'',''LOGAN'',''UTAH'',''Nov-37'',to_ti';
wwv_flow_imp.g_varchar2_table(2734) := 'mestamp(''01.11.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4457,3,739,38,1210,MDSYS.SDO_GEOMETRY(2001, ';
wwv_flow_imp.g_varchar2_table(2735) := '4326, MDSYS.SDO_POINT_TYPE(-111.85165, 41.79178, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIR';
wwv_flow_imp.g_varchar2_table(2736) := 'PORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELE';
wwv_flow_imp.g_varchar2_table(2737) := 'VATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (17792,''O';
wwv_flow_imp.g_varchar2_table(2738) := 'GD'',''AIRPORT'',''OGDEN-HINCKLEY'',''OGDEN'',''UTAH'',''Dec-41'',to_timestamp(''01.12.1941 00:00:00'',''DD.MM.RR ';
wwv_flow_imp.g_varchar2_table(2739) := 'HH24:MI:SSXFF''),4473,3,720,229,3890,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-112.01219, ';
wwv_flow_imp.g_varchar2_table(2740) := '41.19507, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPOR';
wwv_flow_imp.g_varchar2_table(2741) := 'T_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_C';
wwv_flow_imp.g_varchar2_table(2742) := 'OVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (17804,''PVU'',''AIRPORT'',''PROVO MUNI'',''PROVO'',''UTA';
wwv_flow_imp.g_varchar2_table(2743) := 'H'',''Sep-42'',to_timestamp(''01.09.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4497,2,869,3045,300,MDSYS.S';
wwv_flow_imp.g_varchar2_table(2744) := 'DO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-111.72336, 40.21917, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into ';
wwv_flow_imp.g_varchar2_table(2745) := 'EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTI';
wwv_flow_imp.g_varchar2_table(2746) := 'VATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY';
wwv_flow_imp.g_varchar2_table(2747) := ') values (17813,''SGU'',''AIRPORT'',''ST GEORGE RGNL'',''ST GEORGE'',''UTAH'',''Jan-11'',to_timestamp(''01.01.201';
wwv_flow_imp.g_varchar2_table(2748) := '1 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2884,5,1204,6580,2600,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(2749) := '_POINT_TYPE(-113.5103, 37.03638, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_C';
wwv_flow_imp.g_varchar2_table(2750) := 'ODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY';
wwv_flow_imp.g_varchar2_table(2751) := '_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (17814,''44U'',''AIRPORT'',''S';
wwv_flow_imp.g_varchar2_table(2752) := 'ALINA-GUNNISON'',''SALINA'',''UTAH'',''Jan-47'',to_timestamp(''01.01.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''';
wwv_flow_imp.g_varchar2_table(2753) := '),5159,5,610,0,10,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-111.83826, 39.02913, NULL), N';
wwv_flow_imp.g_varchar2_table(2754) := 'ULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_';
wwv_flow_imp.g_varchar2_table(2755) := 'NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_';
wwv_flow_imp.g_varchar2_table(2756) := 'OPS,AIR_TAXI_OPS,GEOMETRY) values (17818,''SLC'',''AIRPORT'',''SALT LAKE CITY INTL'',''SALT LAKE CITY'',''UTA';
wwv_flow_imp.g_varchar2_table(2757) := 'H'',''Nov-38'',to_timestamp(''01.11.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4231,3,7700,231232,57191,MD';
wwv_flow_imp.g_varchar2_table(2758) := 'SYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-111.97777, 40.78839, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert ';
wwv_flow_imp.g_varchar2_table(2759) := 'into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(2760) := ',ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEO';
wwv_flow_imp.g_varchar2_table(2761) := 'METRY) values (17845,''ENV'',''AIRPORT'',''WENDOVER'',''WENDOVER'',''UTAH'',''Feb-73'',to_timestamp(''01.02.1973 ';
wwv_flow_imp.g_varchar2_table(2762) := '00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4237,1,1960,810,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_PO';
wwv_flow_imp.g_varchar2_table(2763) := 'INT_TYPE(-114.02867, 40.71873, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_COD';
wwv_flow_imp.g_varchar2_table(2764) := 'E,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_T';
wwv_flow_imp.g_varchar2_table(2765) := 'O_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (17913,''CHO'',''AIRPORT'',''CHA';
wwv_flow_imp.g_varchar2_table(2766) := 'RLOTTESVILLE-ALBEMARLE'',''CHARLOTTESVILLE'',''VIRGINIA'',null,null,640,7,710,6826,23944,MDSYS.SDO_GEOMET';
wwv_flow_imp.g_varchar2_table(2767) := 'RY(2001, 4326, MDSYS.SDO_POINT_TYPE(-78.45234, 38.13964, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE';
wwv_flow_imp.g_varchar2_table(2768) := '_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DAT';
wwv_flow_imp.g_varchar2_table(2769) := 'E_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (';
wwv_flow_imp.g_varchar2_table(2770) := '17949,''DAN'',''AIRPORT'',''DANVILLE RGNL'',''DANVILLE'',''VIRGINIA'',''Oct-37'',to_timestamp(''01.10.1937 00:00:';
wwv_flow_imp.g_varchar2_table(2771) := '00'',''DD.MM.RR HH24:MI:SSXFF''),571,3,800,0,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-79.';
wwv_flow_imp.g_varchar2_table(2772) := '33625, 36.57247, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE';
wwv_flow_imp.g_varchar2_table(2773) := ',AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND';
wwv_flow_imp.g_varchar2_table(2774) := '_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (18063,''LYH'',''AIRPORT'',''LYNCHBURG RGNL/PR';
wwv_flow_imp.g_varchar2_table(2775) := 'ESTON GLENN FLD'',''LYNCHBURG'',''VIRGINIA'',''Aug-37'',to_timestamp(''01.08.1937 00:00:00'',''DD.MM.RR HH24:M';
wwv_flow_imp.g_varchar2_table(2776) := 'I:SSXFF''),938,5,872,1233,4780,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-79.20122, 37.3253';
wwv_flow_imp.g_varchar2_table(2777) := '9, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,';
wwv_flow_imp.g_varchar2_table(2778) := 'CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,';
wwv_flow_imp.g_varchar2_table(2779) := 'COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (18107,''PHF'',''AIRPORT'',''NEWPORT NEWS/WILLIAMSBURG INTL''';
wwv_flow_imp.g_varchar2_table(2780) := ',''NEWPORT NEWS'',''VIRGINIA'',''Nov-48'',to_timestamp(''01.11.1948 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),42,';
wwv_flow_imp.g_varchar2_table(2781) := '9,1800,3451,7403,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-76.49297, 37.13189, NULL), NUL';
wwv_flow_imp.g_varchar2_table(2782) := 'L, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NA';
wwv_flow_imp.g_varchar2_table(2783) := 'ME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OP';
wwv_flow_imp.g_varchar2_table(2784) := 'S,AIR_TAXI_OPS,GEOMETRY) values (18116,''ORF'',''AIRPORT'',''NORFOLK INTL'',''NORFOLK'',''VIRGINIA'',''Mar-38'',';
wwv_flow_imp.g_varchar2_table(2785) := 'to_timestamp(''01.03.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),26,3,1300,35987,20296,MDSYS.SDO_GEOMETR';
wwv_flow_imp.g_varchar2_table(2786) := 'Y(2001, 4326, MDSYS.SDO_POINT_TYPE(-76.20123, 36.8946, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_M';
wwv_flow_imp.g_varchar2_table(2787) := 'AP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_';
wwv_flow_imp.g_varchar2_table(2788) := 'DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (18';
wwv_flow_imp.g_varchar2_table(2789) := '167,''RIC'',''AIRPORT'',''RICHMOND INTL'',''RICHMOND'',''VIRGINIA'',''Dec-31'',to_timestamp(''01.12.1931 00:00:00';
wwv_flow_imp.g_varchar2_table(2790) := ''',''DD.MM.RR HH24:MI:SSXFF''),168,6,2500,45671,23090,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TY';
wwv_flow_imp.g_varchar2_table(2791) := 'PE(-77.31974, 37.50518, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPO';
wwv_flow_imp.g_varchar2_table(2792) := 'RT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPO';
wwv_flow_imp.g_varchar2_table(2793) := 'RT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (18176,''ROA'',''AIRPORT'',''ROANOKE-BL';
wwv_flow_imp.g_varchar2_table(2794) := 'ACKSBURG RGNL/WOODRUM FIELD'',''ROANOKE'',''VIRGINIA'',''May-30'',to_timestamp(''01.05.1930 00:00:00'',''DD.MM';
wwv_flow_imp.g_varchar2_table(2795) := '.RR HH24:MI:SSXFF''),1175,3,912,3784,14819,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-79.97';
wwv_flow_imp.g_varchar2_table(2796) := '542, 37.32547, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,A';
wwv_flow_imp.g_varchar2_table(2797) := 'IRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_A';
wwv_flow_imp.g_varchar2_table(2798) := 'REA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (18195,''65VA'',''AIRPORT'',''GRAYSON'',''SCOTTSVI';
wwv_flow_imp.g_varchar2_table(2799) := 'LLE'',''VIRGINIA'',''Sep-10'',to_timestamp(''01.09.2010 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),445,5,2,1,null';
wwv_flow_imp.g_varchar2_table(2800) := ',MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-78.547, 37.84467, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert ';
wwv_flow_imp.g_varchar2_table(2801) := 'into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(2802) := ',ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEO';
wwv_flow_imp.g_varchar2_table(2803) := 'METRY) values (18208,''SHD'',''AIRPORT'',''SHENANDOAH VALLEY RGNL'',''STAUNTON/WAYNESBORO/HARRISONBURG'',''VI';
wwv_flow_imp.g_varchar2_table(2804) := 'RGINIA'',''Aug-58'',to_timestamp(''01.08.1958 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1201,10,433,12,1360,MD';
wwv_flow_imp.g_varchar2_table(2805) := 'SYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-78.89644, 38.26383, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert i';
wwv_flow_imp.g_varchar2_table(2806) := 'nto EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,';
wwv_flow_imp.g_varchar2_table(2807) := 'ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOM';
wwv_flow_imp.g_varchar2_table(2808) := 'ETRY) values (18220,''XSA'',''AIRPORT'',''TAPPAHANNOCK-ESSEX COUNTY'',''TAPPAHANNOCK'',''VIRGINIA'',''Aug-07'',t';
wwv_flow_imp.g_varchar2_table(2809) := 'o_timestamp(''01.08.2007 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),135,5,423,0,2663,MDSYS.SDO_GEOMETRY(2001';
wwv_flow_imp.g_varchar2_table(2810) := ', 4326, MDSYS.SDO_POINT_TYPE(-76.89411, 37.85961, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AI';
wwv_flow_imp.g_varchar2_table(2811) := 'RPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,EL';
wwv_flow_imp.g_varchar2_table(2812) := 'EVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (18279,''';
wwv_flow_imp.g_varchar2_table(2813) := 'STT'',''AIRPORT'',''CYRIL E KING'',''CHARLOTTE AMALIE'',''VIRGIN ISLANDS'',''Sep-48'',to_timestamp(''01.09.1948 ';
wwv_flow_imp.g_varchar2_table(2814) := '00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),24,2,280,2920,8445,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POIN';
wwv_flow_imp.g_varchar2_table(2815) := 'T_TYPE(-64.97333, 18.33731, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,A';
wwv_flow_imp.g_varchar2_table(2816) := 'IRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_A';
wwv_flow_imp.g_varchar2_table(2817) := 'IRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (18283,''STX'',''AIRPORT'',''HENRY ';
wwv_flow_imp.g_varchar2_table(2818) := 'E ROHLSEN'',''CHRISTIANSTED'',''VIRGIN ISLANDS'',''Sep-48'',to_timestamp(''01.09.1948 00:00:00'',''DD.MM.RR HH';
wwv_flow_imp.g_varchar2_table(2819) := '24:MI:SSXFF''),74,6,1455,1241,6935,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-64.80194, 17.';
wwv_flow_imp.g_varchar2_table(2820) := '7015, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NA';
wwv_flow_imp.g_varchar2_table(2821) := 'ME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVER';
wwv_flow_imp.g_varchar2_table(2822) := 'ED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (18302,''BTV'',''AIRPORT'',''BURLINGTON INTL'',''BURLINGTON';
wwv_flow_imp.g_varchar2_table(2823) := ''',''VERMONT'',''Sep-37'',to_timestamp(''01.09.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),335,3,942,13818,14';
wwv_flow_imp.g_varchar2_table(2824) := '356,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-73.15328, 44.47196, NULL), NULL, NULL));'||wwv_flow.LF||
'In';
wwv_flow_imp.g_varchar2_table(2825) := 'sert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION';
wwv_flow_imp.g_varchar2_table(2826) := '_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OP';
wwv_flow_imp.g_varchar2_table(2827) := 'S,GEOMETRY) values (18349,''RUT'',''AIRPORT'',''RUTLAND - SOUTHERN VERMONT RGNL'',''RUTLAND'',''VERMONT'',''Dec';
wwv_flow_imp.g_varchar2_table(2828) := '-42'',to_timestamp(''01.12.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),787,5,345,0,1813,MDSYS.SDO_GEOMETR';
wwv_flow_imp.g_varchar2_table(2829) := 'Y(2001, 4326, MDSYS.SDO_POINT_TYPE(-72.94963, 43.52973, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_';
wwv_flow_imp.g_varchar2_table(2830) := 'MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(2831) := '_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1';
wwv_flow_imp.g_varchar2_table(2832) := '8412,''BLI'',''AIRPORT'',''BELLINGHAM INTL'',''BELLINGHAM'',''WASHINGTON'',''Nov-38'',to_timestamp(''01.11.1938 0';
wwv_flow_imp.g_varchar2_table(2833) := '0:00:00'',''DD.MM.RR HH24:MI:SSXFF''),171,3,2190,6537,14764,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_PO';
wwv_flow_imp.g_varchar2_table(2834) := 'INT_TYPE(-122.53753, 48.79269, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_COD';
wwv_flow_imp.g_varchar2_table(2835) := 'E,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_T';
wwv_flow_imp.g_varchar2_table(2836) := 'O_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (18505,''ORS'',''AIRPORT'',''ORC';
wwv_flow_imp.g_varchar2_table(2837) := 'AS ISLAND'',''EASTSOUND'',''WASHINGTON'',''Nov-45'',to_timestamp(''01.11.1945 00:00:00'',''DD.MM.RR HH24:MI:SS';
wwv_flow_imp.g_varchar2_table(2838) := 'XFF''),35,1,64,6800,1900,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-122.91058, 48.70833, NU';
wwv_flow_imp.g_varchar2_table(2839) := 'LL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,';
wwv_flow_imp.g_varchar2_table(2840) := 'STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMME';
wwv_flow_imp.g_varchar2_table(2841) := 'RCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (18528,''PAE'',''AIRPORT'',''SNOHOMISH COUNTY (PAINE FLD)'',''EVERE';
wwv_flow_imp.g_varchar2_table(2842) := 'TT'',''WASHINGTON'',''Nov-38'',to_timestamp(''01.11.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),608,6,1315,29';
wwv_flow_imp.g_varchar2_table(2843) := '17,1091,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-122.28158, 47.907, NULL), NULL, NULL));';
wwv_flow_imp.g_varchar2_table(2844) := ''||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVAT';
wwv_flow_imp.g_varchar2_table(2845) := 'ION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI';
wwv_flow_imp.g_varchar2_table(2846) := '_OPS,GEOMETRY) values (18643,''MWH'',''AIRPORT'',''GRANT CO INTL'',''MOSES LAKE'',''WASHINGTON'',null,null,118';
wwv_flow_imp.g_varchar2_table(2847) := '9,5,4650,7468,11028,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-119.31914, 47.20858, NULL),';
wwv_flow_imp.g_varchar2_table(2848) := ' NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STAT';
wwv_flow_imp.g_varchar2_table(2849) := 'E_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIA';
wwv_flow_imp.g_varchar2_table(2850) := 'L_OPS,AIR_TAXI_OPS,GEOMETRY) values (18691,''PSC'',''AIRPORT'',''TRI-CITIES'',''PASCO'',''WASHINGTON'',''Nov-37';
wwv_flow_imp.g_varchar2_table(2851) := ''',to_timestamp(''01.11.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),410,2,2235,9154,4453,MDSYS.SDO_GEOMET';
wwv_flow_imp.g_varchar2_table(2852) := 'RY(2001, 4326, MDSYS.SDO_POINT_TYPE(-119.11902, 46.26468, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPL';
wwv_flow_imp.g_varchar2_table(2853) := 'E_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DA';
wwv_flow_imp.g_varchar2_table(2854) := 'TE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values ';
wwv_flow_imp.g_varchar2_table(2855) := '(18699,''CLM'',''AIRPORT'',''WILLIAM R FAIRCHILD INTL'',''PORT ANGELES'',''WASHINGTON'',''Aug-37'',to_timestamp(';
wwv_flow_imp.g_varchar2_table(2856) := '''01.08.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),291,3,797,0,4958,MDSYS.SDO_GEOMETRY(2001, 4326, MDSY';
wwv_flow_imp.g_varchar2_table(2857) := 'S.SDO_POINT_TYPE(-123.49969, 48.12019, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,';
wwv_flow_imp.g_varchar2_table(2858) := 'IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIS';
wwv_flow_imp.g_varchar2_table(2859) := 'T_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (18716,''PUW'',''AIRPO';
wwv_flow_imp.g_varchar2_table(2860) := 'RT'',''PULLMAN/MOSCOW RGNL'',''PULLMAN/MOSCOW'',''WASHINGTON'',''Feb-38'',to_timestamp(''01.02.1938 00:00:00'',';
wwv_flow_imp.g_varchar2_table(2861) := '''DD.MM.RR HH24:MI:SSXFF''),2567,3,467,0,4270,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-117';
wwv_flow_imp.g_varchar2_table(2862) := '.11162, 46.74169, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYP';
wwv_flow_imp.g_varchar2_table(2863) := 'E,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAN';
wwv_flow_imp.g_varchar2_table(2864) := 'D_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (18737,''RNT'',''AIRPORT'',''RENTON MUNI'',''RE';
wwv_flow_imp.g_varchar2_table(2865) := 'NTON'',''WASHINGTON'',''Apr-45'',to_timestamp(''01.04.1945 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),32,0,170,48';
wwv_flow_imp.g_varchar2_table(2866) := '8,1519,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-122.21575, 47.49314, NULL), NULL, NULL))';
wwv_flow_imp.g_varchar2_table(2867) := ';'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVA';
wwv_flow_imp.g_varchar2_table(2868) := 'TION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAX';
wwv_flow_imp.g_varchar2_table(2869) := 'I_OPS,GEOMETRY) values (18776,''SEA'',''AIRPORT'',''SEATTLE-TACOMA INTL'',''SEATTLE'',''WASHINGTON'',''Jan-44'',';
wwv_flow_imp.g_varchar2_table(2870) := 'to_timestamp(''01.01.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),432,10,2500,427170,8509,MDSYS.SDO_GEOME';
wwv_flow_imp.g_varchar2_table(2871) := 'TRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-122.31178, 47.44989, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMP';
wwv_flow_imp.g_varchar2_table(2872) := 'LE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(2873) := 'ATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values';
wwv_flow_imp.g_varchar2_table(2874) := ' (18778,''BFI'',''AIRPORT'',''BOEING FIELD/KING COUNTY INTL'',''SEATTLE'',''WASHINGTON'',''Nov-38'',to_timestamp';
wwv_flow_imp.g_varchar2_table(2875) := '(''01.11.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),22,4,634,10142,27913,MDSYS.SDO_GEOMETRY(2001, 4326,';
wwv_flow_imp.g_varchar2_table(2876) := ' MDSYS.SDO_POINT_TYPE(-122.30194, 47.52997, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS';
wwv_flow_imp.g_varchar2_table(2877) := ' (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATIO';
wwv_flow_imp.g_varchar2_table(2878) := 'N,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (18812,''GEG'',''';
wwv_flow_imp.g_varchar2_table(2879) := 'AIRPORT'',''SPOKANE INTL'',''SPOKANE'',''WASHINGTON'',''Aug-43'',to_timestamp(''01.08.1943 00:00:00'',''DD.MM.RR';
wwv_flow_imp.g_varchar2_table(2880) := ' HH24:MI:SSXFF''),2385,5,6140,46134,7423,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-117.535';
wwv_flow_imp.g_varchar2_table(2881) := '22, 47.61903, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AI';
wwv_flow_imp.g_varchar2_table(2882) := 'RPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AR';
wwv_flow_imp.g_varchar2_table(2883) := 'EA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (18871,''ALW'',''AIRPORT'',''WALLA WALLA RGNL'',''W';
wwv_flow_imp.g_varchar2_table(2884) := 'ALLA WALLA'',''WASHINGTON'',''Oct-37'',to_timestamp(''01.10.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1194,';
wwv_flow_imp.g_varchar2_table(2885) := '3,2319,927,1122,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-118.28408, 46.09254, NULL), NUL';
wwv_flow_imp.g_varchar2_table(2886) := 'L, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NA';
wwv_flow_imp.g_varchar2_table(2887) := 'ME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OP';
wwv_flow_imp.g_varchar2_table(2888) := 'S,AIR_TAXI_OPS,GEOMETRY) values (18885,''EAT'',''AIRPORT'',''PANGBORN MEMORIAL'',''WENATCHEE'',''WASHINGTON'',';
wwv_flow_imp.g_varchar2_table(2889) := '''Aug-42'',to_timestamp(''01.08.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1249,4,665,2072,2424,MDSYS.SDO';
wwv_flow_imp.g_varchar2_table(2890) := '_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-120.20683, 47.39881, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EB';
wwv_flow_imp.g_varchar2_table(2891) := 'A_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVA';
wwv_flow_imp.g_varchar2_table(2892) := 'TION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) ';
wwv_flow_imp.g_varchar2_table(2893) := 'values (18906,''YKM'',''AIRPORT'',''YAKIMA AIR TERMINAL/MCALLISTER FIELD'',''YAKIMA'',''WASHINGTON'',''Nov-37'',';
wwv_flow_imp.g_varchar2_table(2894) := 'to_timestamp(''01.11.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1099,3,825,2026,4034,MDSYS.SDO_GEOMETRY';
wwv_flow_imp.g_varchar2_table(2895) := '(2001, 4326, MDSYS.SDO_POINT_TYPE(-120.54406, 46.56817, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_';
wwv_flow_imp.g_varchar2_table(2896) := 'MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(2897) := '_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (1';
wwv_flow_imp.g_varchar2_table(2898) := '8927,''ATW'',''AIRPORT'',''APPLETON INTL'',''APPLETON'',''WISCONSIN'',''May-65'',to_timestamp(''01.05.1965 00:00:';
wwv_flow_imp.g_varchar2_table(2899) := '00'',''DD.MM.RR HH24:MI:SSXFF''),918,3,1638,6518,8529,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TY';
wwv_flow_imp.g_varchar2_table(2900) := 'PE(-88.51908, 44.25808, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPO';
wwv_flow_imp.g_varchar2_table(2901) := 'RT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPO';
wwv_flow_imp.g_varchar2_table(2902) := 'RT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19046,''EGV'',''AIRPORT'',''EAGLE RIVE';
wwv_flow_imp.g_varchar2_table(2903) := 'R UNION'',''EAGLE RIVER'',''WISCONSIN'',''Feb-38'',to_timestamp(''01.02.1938 00:00:00'',''DD.MM.RR HH24:MI:SSX';
wwv_flow_imp.g_varchar2_table(2904) := 'FF''),1642,0,588,88,1500,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.26828, 45.93233, NUL';
wwv_flow_imp.g_varchar2_table(2905) := 'L), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,S';
wwv_flow_imp.g_varchar2_table(2906) := 'TATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMER';
wwv_flow_imp.g_varchar2_table(2907) := 'CIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19051,''EAU'',''AIRPORT'',''CHIPPEWA VALLEY RGNL'',''EAU CLAIRE'',''W';
wwv_flow_imp.g_varchar2_table(2908) := 'ISCONSIN'',''Nov-44'',to_timestamp(''01.11.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),913,3,1100,60,2364,M';
wwv_flow_imp.g_varchar2_table(2909) := 'DSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-91.48425, 44.86581, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert ';
wwv_flow_imp.g_varchar2_table(2910) := 'into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE';
wwv_flow_imp.g_varchar2_table(2911) := ',ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEO';
wwv_flow_imp.g_varchar2_table(2912) := 'METRY) values (19101,''GRB'',''AIRPORT'',''GREEN BAY-AUSTIN STRAUBEL INTL'',''GREEN BAY'',''WISCONSIN'',''Dec-4';
wwv_flow_imp.g_varchar2_table(2913) := '8'',to_timestamp(''01.12.1948 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),695,7,2441,6344,8490,MDSYS.SDO_GEOME';
wwv_flow_imp.g_varchar2_table(2914) := 'TRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-88.12971, 44.48463, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPL';
wwv_flow_imp.g_varchar2_table(2915) := 'E_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DA';
wwv_flow_imp.g_varchar2_table(2916) := 'TE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values ';
wwv_flow_imp.g_varchar2_table(2917) := '(19131,''JVL'',''AIRPORT'',''SOUTHERN WISCONSIN RGNL'',''JANESVILLE'',''WISCONSIN'',''Apr-46'',to_timestamp(''01.';
wwv_flow_imp.g_varchar2_table(2918) := '04.1946 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),808,3,1343,11,5140,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.';
wwv_flow_imp.g_varchar2_table(2919) := 'SDO_POINT_TYPE(-89.04156, 42.62025, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IAT';
wwv_flow_imp.g_varchar2_table(2920) := 'A_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_C';
wwv_flow_imp.g_varchar2_table(2921) := 'ITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19137,''ENW'',''AIRPORT''';
wwv_flow_imp.g_varchar2_table(2922) := ',''KENOSHA RGNL'',''KENOSHA'',''WISCONSIN'',''May-59'',to_timestamp(''01.05.1959 00:00:00'',''DD.MM.RR HH24:MI:';
wwv_flow_imp.g_varchar2_table(2923) := 'SSXFF''),742,4,974,22,3342,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-87.92781, 42.59569, N';
wwv_flow_imp.g_varchar2_table(2924) := 'ULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY';
wwv_flow_imp.g_varchar2_table(2925) := ',STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMM';
wwv_flow_imp.g_varchar2_table(2926) := 'ERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19144,''LSE'',''AIRPORT'',''LA CROSSE RGNL'',''LA CROSSE'',''WISCON';
wwv_flow_imp.g_varchar2_table(2927) := 'SIN'',''Feb-38'',to_timestamp(''01.02.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),656,4,1380,1282,4204,MDSY';
wwv_flow_imp.g_varchar2_table(2928) := 'S.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-91.25664, 43.87928, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert int';
wwv_flow_imp.g_varchar2_table(2929) := 'o EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,AC';
wwv_flow_imp.g_varchar2_table(2930) := 'TIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMET';
wwv_flow_imp.g_varchar2_table(2931) := 'RY) values (19170,''MSN'',''AIRPORT'',''DANE COUNTY RGNL-TRUAX FIELD'',''MADISON'',''WISCONSIN'',''Sep-37'',to_t';
wwv_flow_imp.g_varchar2_table(2932) := 'imestamp(''01.09.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),887,5,3500,24163,11687,MDSYS.SDO_GEOMETRY(2';
wwv_flow_imp.g_varchar2_table(2933) := '001, 4326, MDSYS.SDO_POINT_TYPE(-89.3375, 43.13988, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_';
wwv_flow_imp.g_varchar2_table(2934) := 'AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,';
wwv_flow_imp.g_varchar2_table(2935) := 'ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19200';
wwv_flow_imp.g_varchar2_table(2936) := ',''MWC'',''AIRPORT'',''LAWRENCE J TIMMERMAN'',''MILWAUKEE'',''WISCONSIN'',''Aug-37'',to_timestamp(''01.08.1937 00';
wwv_flow_imp.g_varchar2_table(2937) := ':00:00'',''DD.MM.RR HH24:MI:SSXFF''),745,5,420,2,499,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYP';
wwv_flow_imp.g_varchar2_table(2938) := 'E(-88.03442, 43.11039, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPOR';
wwv_flow_imp.g_varchar2_table(2939) := 'T_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPOR';
wwv_flow_imp.g_varchar2_table(2940) := 'T,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19204,''MKE'',''AIRPORT'',''GENERAL MIT';
wwv_flow_imp.g_varchar2_table(2941) := 'CHELL INTL'',''MILWAUKEE'',''WISCONSIN'',null,null,728,5,2180,63472,32832,MDSYS.SDO_GEOMETRY(2001, 4326, ';
wwv_flow_imp.g_varchar2_table(2942) := 'MDSYS.SDO_POINT_TYPE(-87.89706, 42.94693, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (';
wwv_flow_imp.g_varchar2_table(2943) := 'ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,';
wwv_flow_imp.g_varchar2_table(2944) := 'DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19219,''CWA'',''AI';
wwv_flow_imp.g_varchar2_table(2945) := 'RPORT'',''CENTRAL WISCONSIN'',''MOSINEE'',''WISCONSIN'',''Oct-69'',to_timestamp(''01.10.1969 00:00:00'',''DD.MM.';
wwv_flow_imp.g_varchar2_table(2946) := 'RR HH24:MI:SSXFF''),1277,3,1800,161,7933,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.6667';
wwv_flow_imp.g_varchar2_table(2947) := '8, 44.77762, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIR';
wwv_flow_imp.g_varchar2_table(2948) := 'PORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_ARE';
wwv_flow_imp.g_varchar2_table(2949) := 'A_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19267,''OSH'',''AIRPORT'',''WITTMAN RGNL'',''OSHKOS';
wwv_flow_imp.g_varchar2_table(2950) := 'H'',''WISCONSIN'',''Oct-37'',to_timestamp(''01.10.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),808,2,1392,0,17';
wwv_flow_imp.g_varchar2_table(2951) := '30,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-88.55693, 43.98449, NULL), NULL, NULL));'||wwv_flow.LF||
'Ins';
wwv_flow_imp.g_varchar2_table(2952) := 'ert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_';
wwv_flow_imp.g_varchar2_table(2953) := 'DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS';
wwv_flow_imp.g_varchar2_table(2954) := ',GEOMETRY) values (19317,''RHI'',''AIRPORT'',''RHINELANDER-ONEIDA COUNTY'',''RHINELANDER'',''WISCONSIN'',''May-';
wwv_flow_imp.g_varchar2_table(2955) := '44'',to_timestamp(''01.05.1944 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1624,2,1259,1460,1400,MDSYS.SDO_GEO';
wwv_flow_imp.g_varchar2_table(2956) := 'METRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-89.46663, 45.6309, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMP';
wwv_flow_imp.g_varchar2_table(2957) := 'LE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(2958) := 'ATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values';
wwv_flow_imp.g_varchar2_table(2959) := ' (19389,''40D'',''AIRPORT'',''THREE LAKES MUNI'',''THREE LAKES'',''WISCONSIN'',''Jan-56'',to_timestamp(''01.01.19';
wwv_flow_imp.g_varchar2_table(2960) := '56 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1636,3,60,0,0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_';
wwv_flow_imp.g_varchar2_table(2961) := 'TYPE(-89.12096, 45.79024, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIR';
wwv_flow_imp.g_varchar2_table(2962) := 'PORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIR';
wwv_flow_imp.g_varchar2_table(2963) := 'PORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19462,''BKW'',''AIRPORT'',''RALEIGH ';
wwv_flow_imp.g_varchar2_table(2964) := 'COUNTY MEMORIAL'',''BECKLEY'',''WEST VIRGINIA'',''Sep-52'',to_timestamp(''01.09.1952 00:00:00'',''DD.MM.RR HH2';
wwv_flow_imp.g_varchar2_table(2965) := '4:MI:SSXFF''),2504,3,1433,0,1481,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.12417, 37.78';
wwv_flow_imp.g_varchar2_table(2966) := '733, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAM';
wwv_flow_imp.g_varchar2_table(2967) := 'E,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERE';
wwv_flow_imp.g_varchar2_table(2968) := 'D,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19471,''BLF'',''AIRPORT'',''MERCER COUNTY'',''BLUEFIELD'',''W';
wwv_flow_imp.g_varchar2_table(2969) := 'EST VIRGINIA'',''May-54'',to_timestamp(''01.05.1954 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),2857,3,511,0,180';
wwv_flow_imp.g_varchar2_table(2970) := '0,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.20752, 37.29595, NULL), NULL, NULL));'||wwv_flow.LF||
'Inse';
wwv_flow_imp.g_varchar2_table(2971) := 'rt into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_D';
wwv_flow_imp.g_varchar2_table(2972) := 'ATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,';
wwv_flow_imp.g_varchar2_table(2973) := 'GEOMETRY) values (19478,''CRW'',''AIRPORT'',''YEAGER'',''CHARLESTON'',''WEST VIRGINIA'',''Aug-47'',to_timestamp(';
wwv_flow_imp.g_varchar2_table(2974) := '''01.08.1947 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),947,3,767,1364,13729,MDSYS.SDO_GEOMETRY(2001, 4326, ';
wwv_flow_imp.g_varchar2_table(2975) := 'MDSYS.SDO_POINT_TYPE(-81.59289, 38.37601, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (';
wwv_flow_imp.g_varchar2_table(2976) := 'ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,';
wwv_flow_imp.g_varchar2_table(2977) := 'DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19482,''CKB'',''AI';
wwv_flow_imp.g_varchar2_table(2978) := 'RPORT'',''NORTH CENTRAL WEST VIRGINIA'',''CLARKSBURG'',''WEST VIRGINIA'',''Jun-38'',to_timestamp(''01.06.1938 ';
wwv_flow_imp.g_varchar2_table(2979) := '00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1224,1,434,716,1752,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POI';
wwv_flow_imp.g_varchar2_table(2980) := 'NT_TYPE(-80.22753, 39.29765, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,';
wwv_flow_imp.g_varchar2_table(2981) := 'AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_';
wwv_flow_imp.g_varchar2_table(2982) := 'AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19505,''HTS'',''AIRPORT'',''TRI-S';
wwv_flow_imp.g_varchar2_table(2983) := 'TATE/MILTON J FERGUSON FIELD'',''HUNTINGTON'',''WEST VIRGINIA'',''Dec-52'',to_timestamp(''01.12.1952 00:00:0';
wwv_flow_imp.g_varchar2_table(2984) := '0'',''DD.MM.RR HH24:MI:SSXFF''),828,3,1300,2027,3963,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYP';
wwv_flow_imp.g_varchar2_table(2985) := 'E(-82.56036, 38.36851, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPOR';
wwv_flow_imp.g_varchar2_table(2986) := 'T_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPOR';
wwv_flow_imp.g_varchar2_table(2987) := 'T,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19515,''LWB'',''AIRPORT'',''GREENBRIER ';
wwv_flow_imp.g_varchar2_table(2988) := 'VALLEY'',''LEWISBURG'',''WEST VIRGINIA'',null,null,2302,3,472,1370,1926,MDSYS.SDO_GEOMETRY(2001, 4326, MD';
wwv_flow_imp.g_varchar2_table(2989) := 'SYS.SDO_POINT_TYPE(-80.39948, 37.85831, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID';
wwv_flow_imp.g_varchar2_table(2990) := ',IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DI';
wwv_flow_imp.g_varchar2_table(2991) := 'ST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19526,''MGW'',''AIRP';
wwv_flow_imp.g_varchar2_table(2992) := 'ORT'',''MORGANTOWN MUNI-WALTER L BILL HART FLD'',''MORGANTOWN'',''WEST VIRGINIA'',''Jun-38'',to_timestamp(''01';
wwv_flow_imp.g_varchar2_table(2993) := '.06.1938 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),1244,3,494,0,22080,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS';
wwv_flow_imp.g_varchar2_table(2994) := '.SDO_POINT_TYPE(-79.91755, 39.6436, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IAT';
wwv_flow_imp.g_varchar2_table(2995) := 'A_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_C';
wwv_flow_imp.g_varchar2_table(2996) := 'ITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19538,''PKB'',''AIRPORT''';
wwv_flow_imp.g_varchar2_table(2997) := ',''MID-OHIO VALLEY RGNL'',''PARKERSBURG'',''WEST VIRGINIA'',''Oct-38'',to_timestamp(''01.10.1938 00:00:00'',''D';
wwv_flow_imp.g_varchar2_table(2998) := 'D.MM.RR HH24:MI:SSXFF''),859,6,1103,0,3193,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-81.43';
wwv_flow_imp.g_varchar2_table(2999) := '929, 39.34496, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,A';
wwv_flow_imp.g_varchar2_table(3000) := 'IRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_A';
null;
end;
/
begin
wwv_flow_imp.g_varchar2_table(3001) := 'REA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19552,''I18'',''AIRPORT'',''JACKSON COUNTY'',''RA';
wwv_flow_imp.g_varchar2_table(3002) := 'VENSWOOD'',''WEST VIRGINIA'',null,null,758,6,217,0,102,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_T';
wwv_flow_imp.g_varchar2_table(3003) := 'YPE(-81.81947, 38.92978, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRP';
wwv_flow_imp.g_varchar2_table(3004) := 'ORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRP';
wwv_flow_imp.g_varchar2_table(3005) := 'ORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19580,''HLG'',''AIRPORT'',''WHEELING ';
wwv_flow_imp.g_varchar2_table(3006) := 'OHIO CO'',''WHEELING'',''WEST VIRGINIA'',''Nov-45'',to_timestamp(''01.11.1945 00:00:00'',''DD.MM.RR HH24:MI:SS';
wwv_flow_imp.g_varchar2_table(3007) := 'XFF''),1194,8,1000,0,1488,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-80.64627, 40.17501, NU';
wwv_flow_imp.g_varchar2_table(3008) := 'LL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,';
wwv_flow_imp.g_varchar2_table(3009) := 'STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMME';
wwv_flow_imp.g_varchar2_table(3010) := 'RCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19599,''CPR'',''AIRPORT'',''CASPER/NATRONA COUNTY INTL'',''CASPER''';
wwv_flow_imp.g_varchar2_table(3011) := ',''WYOMING'',''Nov-43'',to_timestamp(''01.11.1943 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),5344,7,5150,2176,10';
wwv_flow_imp.g_varchar2_table(3012) := '280,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-106.46364, 42.90586, NULL), NULL, NULL));'||wwv_flow.LF||
'I';
wwv_flow_imp.g_varchar2_table(3013) := 'nsert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATIO';
wwv_flow_imp.g_varchar2_table(3014) := 'N_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_O';
wwv_flow_imp.g_varchar2_table(3015) := 'PS,GEOMETRY) values (19601,''CYS'',''AIRPORT'',''CHEYENNE RGNL/JERRY OLSON FIELD'',''CHEYENNE'',''WYOMING'',''O';
wwv_flow_imp.g_varchar2_table(3016) := 'ct-37'',to_timestamp(''01.10.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),6160,1,1060,261,2511,MDSYS.SDO_G';
wwv_flow_imp.g_varchar2_table(3017) := 'EOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-104.81047, 41.15564, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_';
wwv_flow_imp.g_varchar2_table(3018) := 'SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATI';
wwv_flow_imp.g_varchar2_table(3019) := 'ON_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) va';
wwv_flow_imp.g_varchar2_table(3020) := 'lues (19606,''COD'',''AIRPORT'',''YELLOWSTONE RGNL'',''CODY'',''WYOMING'',''Nov-37'',to_timestamp(''01.11.1937 00';
wwv_flow_imp.g_varchar2_table(3021) := ':00:00'',''DD.MM.RR HH24:MI:SSXFF''),5102,2,694,4,2142,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_T';
wwv_flow_imp.g_varchar2_table(3022) := 'YPE(-109.02381, 44.52019, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIR';
wwv_flow_imp.g_varchar2_table(3023) := 'PORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIR';
wwv_flow_imp.g_varchar2_table(3024) := 'PORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19631,''GCC'',''AIRPORT'',''GILLETTE';
wwv_flow_imp.g_varchar2_table(3025) := '-CAMPBELL COUNTY'',''GILLETTE'',''WYOMING'',''Nov-37'',to_timestamp(''01.11.1937 00:00:00'',''DD.MM.RR HH24:MI';
wwv_flow_imp.g_varchar2_table(3026) := ':SSXFF''),4365,4,894,10,2843,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-105.53937, 44.34891';
wwv_flow_imp.g_varchar2_table(3027) := ', NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,C';
wwv_flow_imp.g_varchar2_table(3028) := 'ITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,C';
wwv_flow_imp.g_varchar2_table(3029) := 'OMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19643,''JAC'',''AIRPORT'',''JACKSON HOLE'',''JACKSON'',''WYOMING';
wwv_flow_imp.g_varchar2_table(3030) := ''',''Oct-41'',to_timestamp(''01.10.1941 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),6451,7,533,7467,8062,MDSYS.S';
wwv_flow_imp.g_varchar2_table(3031) := 'DO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-110.73775, 43.60733, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into ';
wwv_flow_imp.g_varchar2_table(3032) := 'EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTI';
wwv_flow_imp.g_varchar2_table(3033) := 'VATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY';
wwv_flow_imp.g_varchar2_table(3034) := ') values (19657,''LAR'',''AIRPORT'',''LARAMIE RGNL'',''LARAMIE'',''WYOMING'',''Oct-38'',to_timestamp(''01.10.1938';
wwv_flow_imp.g_varchar2_table(3035) := ' 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),7284,3,1580,36,1520,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_PO';
wwv_flow_imp.g_varchar2_table(3036) := 'INT_TYPE(-105.675, 41.31206, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,';
wwv_flow_imp.g_varchar2_table(3037) := 'AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_';
wwv_flow_imp.g_varchar2_table(3038) := 'AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19678,''RIW'',''AIRPORT'',''RIVER';
wwv_flow_imp.g_varchar2_table(3039) := 'TON RGNL'',''RIVERTON'',''WYOMING'',''Nov-37'',to_timestamp(''01.11.1937 00:00:00'',''DD.MM.RR HH24:MI:SSXFF'')';
wwv_flow_imp.g_varchar2_table(3040) := ',5516,3,1250,0,1003,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-108.45983, 43.06425, NULL),';
wwv_flow_imp.g_varchar2_table(3041) := ' NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STAT';
wwv_flow_imp.g_varchar2_table(3042) := 'E_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIA';
wwv_flow_imp.g_varchar2_table(3043) := 'L_OPS,AIR_TAXI_OPS,GEOMETRY) values (19680,''RKS'',''AIRPORT'',''SOUTHWEST WYOMING RGNL'',''ROCK SPRINGS'',''';
wwv_flow_imp.g_varchar2_table(3044) := 'WYOMING'',''Jul-42'',to_timestamp(''01.07.1942 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),6765,7,1242,24,4550,M';
wwv_flow_imp.g_varchar2_table(3045) := 'DSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-109.06519, 41.59422, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert';
wwv_flow_imp.g_varchar2_table(3046) := ' into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DAT';
wwv_flow_imp.g_varchar2_table(3047) := 'E,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GE';
wwv_flow_imp.g_varchar2_table(3048) := 'OMETRY) values (19700,''EAN'',''AIRPORT'',''PHIFER AIRFIELD'',''WHEATLAND'',''WYOMING'',''Aug-46'',to_timestamp(';
wwv_flow_imp.g_varchar2_table(3049) := '''01.08.1946 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),4779,1,84,0,180,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS';
wwv_flow_imp.g_varchar2_table(3050) := '.SDO_POINT_TYPE(-104.92828, 42.05552, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,I';
wwv_flow_imp.g_varchar2_table(3051) := 'ATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST';
wwv_flow_imp.g_varchar2_table(3052) := '_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19703,''WRL'',''AIRPOR';
wwv_flow_imp.g_varchar2_table(3053) := 'T'',''WORLAND MUNI'',''WORLAND'',''WYOMING'',''Jan-45'',to_timestamp(''01.01.1945 00:00:00'',''DD.MM.RR HH24:MI:';
wwv_flow_imp.g_varchar2_table(3054) := 'SSXFF''),4252,3,690,0,995,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(-107.95053, 43.96289, N';
wwv_flow_imp.g_varchar2_table(3055) := 'ULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY';
wwv_flow_imp.g_varchar2_table(3056) := ',STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMM';
wwv_flow_imp.g_varchar2_table(3057) := 'ERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19711,''ROR'',''AIRPORT'',''BABELTHUAP/KOROR'',''BABELTHUAP ISLAN';
wwv_flow_imp.g_varchar2_table(3058) := 'D'',null,''Jun-64'',to_timestamp(''01.06.1964 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),177,4,480,890,115,MDSY';
wwv_flow_imp.g_varchar2_table(3059) := 'S.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(134.54425, 7.36731, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into';
wwv_flow_imp.g_varchar2_table(3060) := ' EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACT';
wwv_flow_imp.g_varchar2_table(3061) := 'IVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETR';
wwv_flow_imp.g_varchar2_table(3062) := 'Y) values (19717,''TTK'',''AIRPORT'',''KOSRAE'',''KOSRAE'',null,''Jan-84'',to_timestamp(''01.01.1984 00:00:00'',';
wwv_flow_imp.g_varchar2_table(3063) := '''DD.MM.RR HH24:MI:SSXFF''),12,6,null,600,100,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(162.';
wwv_flow_imp.g_varchar2_table(3064) := '95839, 5.35697, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,';
wwv_flow_imp.g_varchar2_table(3065) := 'AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_';
wwv_flow_imp.g_varchar2_table(3066) := 'AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19720,''MAJ'',''AIRPORT'',''MARSHALL ISLANDS I';
wwv_flow_imp.g_varchar2_table(3067) := 'NTL'',''MAJURO ATOLL'',null,''Nov-72'',to_timestamp(''01.11.1972 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),7,7,1';
wwv_flow_imp.g_varchar2_table(3068) := '35,1040,2496,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(171.27203, 7.06497, NULL), NULL, NU';
wwv_flow_imp.g_varchar2_table(3069) := 'LL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,AC';
wwv_flow_imp.g_varchar2_table(3070) := 'TIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR';
wwv_flow_imp.g_varchar2_table(3071) := '_TAXI_OPS,GEOMETRY) values (19724,''PNI'',''AIRPORT'',''POHNPEI INTL'',''POHNPEI ISLAND'',null,''Jan-70'',to_t';
wwv_flow_imp.g_varchar2_table(3072) := 'imestamp(''01.01.1970 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),9,1,80,1576,716,MDSYS.SDO_GEOMETRY(2001, 43';
wwv_flow_imp.g_varchar2_table(3073) := '26, MDSYS.SDO_POINT_TYPE(158.20981, 6.98508, NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORT';
wwv_flow_imp.g_varchar2_table(3074) := 'S (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,CITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATI';
wwv_flow_imp.g_varchar2_table(3075) := 'ON,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,COMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19728,''TKK'',';
wwv_flow_imp.g_varchar2_table(3076) := '''AIRPORT'',''CHUUK INTL'',''WENO ISLAND'',null,''Jun-64'',to_timestamp(''01.06.1964 00:00:00'',''DD.MM.RR HH24';
wwv_flow_imp.g_varchar2_table(3077) := ':MI:SSXFF''),10,0,120,558,null,MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(151.84302, 7.46189';
wwv_flow_imp.g_varchar2_table(3078) := ', NULL), NULL, NULL));'||wwv_flow.LF||
'Insert into EBA_SAMPLE_MAP_AIRPORTS (ID,IATA_CODE,AIRPORT_TYPE,AIRPORT_NAME,C';
wwv_flow_imp.g_varchar2_table(3079) := 'ITY,STATE_NAME,ACTIVATION_DATE,ACTIVATION_DATE_DT,ELEVATION,DIST_CITY_TO_AIRPORT,LAND_AREA_COVERED,C';
wwv_flow_imp.g_varchar2_table(3080) := 'OMMERCIAL_OPS,AIR_TAXI_OPS,GEOMETRY) values (19730,''T11'',''AIRPORT'',''YAP INTL'',''YAP ISLAND'',null,''Nov';
wwv_flow_imp.g_varchar2_table(3081) := '-83'',to_timestamp(''01.11.1983 00:00:00'',''DD.MM.RR HH24:MI:SSXFF''),91,0,275,404,225,MDSYS.SDO_GEOMETR';
wwv_flow_imp.g_varchar2_table(3082) := 'Y(2001, 4326, MDSYS.SDO_POINT_TYPE(138.08248, 9.49891, NULL), NULL, NULL));'||wwv_flow.LF||
''||wwv_flow.LF||
'commit'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1557517979197737396)
,p_install_id=>wwv_flow_imp.id(1556278723360956933)
,p_name=>'Table EBA_SAMPLE_MAP_AIRPORTS'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
