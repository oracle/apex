prompt --application/deployment/install/install_create_spatial_indexes
begin
--   Manifest
--     INSTALL: INSTALL-Create Spatial Indexes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    apex_spatial.insert_geom_metadata_lonlat('||wwv_flow.LF||
'        p_table_name => ''EBA_SAMPLE_MAP_STATES'',';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'        p_column_name => ''GEOMETRY'','||wwv_flow.LF||
'        p_tolerance => 0.05 );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    apex_spatial.';
wwv_flow_imp.g_varchar2_table(3) := 'insert_geom_metadata_lonlat('||wwv_flow.LF||
'        p_table_name => ''EBA_SAMPLE_MAP_SIMPLE_STATES'','||wwv_flow.LF||
'        p_colum';
wwv_flow_imp.g_varchar2_table(4) := 'n_name => ''GEOMETRY'','||wwv_flow.LF||
'        p_tolerance => 0.05 );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    apex_spatial.insert_geom_meta';
wwv_flow_imp.g_varchar2_table(5) := 'data_lonlat('||wwv_flow.LF||
'        p_table_name => ''EBA_SAMPLE_MAP_AIRPORTS'','||wwv_flow.LF||
'        p_column_name => ''GEOMETRY'',';
wwv_flow_imp.g_varchar2_table(6) := ''||wwv_flow.LF||
'        p_tolerance => 0.05 );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sample_map_airports_sx on eba_sample_map_ai';
wwv_flow_imp.g_varchar2_table(7) := 'rports(geometry)'||wwv_flow.LF||
'indextype is mdsys.spatial_index_v2'||wwv_flow.LF||
'parameters( ''layer_gtype=POINT'')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create inde';
wwv_flow_imp.g_varchar2_table(8) := 'x eba_sample_map_simplestates_sx on eba_sample_map_simple_states(geometry)'||wwv_flow.LF||
'indextype is mdsys.spatia';
wwv_flow_imp.g_varchar2_table(9) := 'l_index_v2'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sample_map_states_sx on eba_sample_map_states(geometry)'||wwv_flow.LF||
'indextype is ';
wwv_flow_imp.g_varchar2_table(10) := 'mdsys.spatial_index_v2'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1550517362030861782)
,p_install_id=>wwv_flow_imp.id(1556278723360956933)
,p_name=>'Create Spatial Indexes'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
