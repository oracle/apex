prompt --application/deployment/install/install_table_eba_sample_map_states
begin
--   Manifest
--     INSTALL: INSTALL-Table EBA_SAMPLE_MAP_STATES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '--'||wwv_flow.LF||
'-- create table'||wwv_flow.LF||
'--'||wwv_flow.LF||
'create table eba_sample_map_states ('||wwv_flow.LF||
'   	id                     number not nul';
wwv_flow_imp.g_varchar2_table(2) := 'l primary key,'||wwv_flow.LF||
'	name                   varchar2(255),'||wwv_flow.LF||
'	state_code             varchar2(2),'||wwv_flow.LF||
'    land_';
wwv_flow_imp.g_varchar2_table(3) := 'area              number,'||wwv_flow.LF||
'    water_area             number,'||wwv_flow.LF||
'    geometry               sdo_geometry';
wwv_flow_imp.g_varchar2_table(4) := ' )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_sample_map_simple_states('||wwv_flow.LF||
'   	id                     number not null primary ';
wwv_flow_imp.g_varchar2_table(5) := 'key,'||wwv_flow.LF||
'	name                   varchar2(255),'||wwv_flow.LF||
'	state_code             varchar2(2),'||wwv_flow.LF||
'    land_area      ';
wwv_flow_imp.g_varchar2_table(6) := '        number,'||wwv_flow.LF||
'    water_area             number,'||wwv_flow.LF||
'    geometry               sdo_geometry )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1556517841053911586)
,p_install_id=>wwv_flow_imp.id(1556278723360956933)
,p_name=>'Table EBA_SAMPLE_MAP_STATES'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
