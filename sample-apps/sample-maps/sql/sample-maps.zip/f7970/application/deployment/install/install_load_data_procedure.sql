prompt --application/deployment/install/install_load_data_procedure
begin
--   Manifest
--     INSTALL: INSTALL-Load Data Procedure
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace procedure eba_sample_map_load_data('||wwv_flow.LF||
'    p_load_from          in varchar2,'||wwv_flow.LF||
'    p_st';
wwv_flow_imp.g_varchar2_table(2) := 'ates_file_name   in varchar2,'||wwv_flow.LF||
'    p_airports_file_name in varchar2,'||wwv_flow.LF||
'    p_proxy_override     in varc';
wwv_flow_imp.g_varchar2_table(3) := 'har2 default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_states_json   blob;'||wwv_flow.LF||
'    l_airports_json blob;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_load_from ';
wwv_flow_imp.g_varchar2_table(4) := '= ''FILE'' then'||wwv_flow.LF||
'        if p_states_file_name is not null then'||wwv_flow.LF||
'            select blob_content'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(5) := '       into l_states_json'||wwv_flow.LF||
'              from apex_application_temp_files'||wwv_flow.LF||
'             where name = p';
wwv_flow_imp.g_varchar2_table(6) := '_states_file_name;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if p_airports_file_name is not null then'||wwv_flow.LF||
'            sele';
wwv_flow_imp.g_varchar2_table(7) := 'ct blob_content'||wwv_flow.LF||
'              into l_airports_json'||wwv_flow.LF||
'              from apex_application_temp_files'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(8) := '           where name = p_airports_file_name;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        apex_web_service.set_';
wwv_flow_imp.g_varchar2_table(9) := 'request_headers('||wwv_flow.LF||
'            p_name_01  => ''User-Agent'','||wwv_flow.LF||
'            p_value_01 => ''APEX'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(10) := '  l_states_json := apex_web_service.make_rest_request_b('||wwv_flow.LF||
'                             p_url         ';
wwv_flow_imp.g_varchar2_table(11) := '   => ''https://raw.githubusercontent.com/oracle/apex/22.1/sample-apps/sample-maps/states-full.json'',';
wwv_flow_imp.g_varchar2_table(12) := ''||wwv_flow.LF||
'                             p_http_method    => ''GET'','||wwv_flow.LF||
'                             p_proxy_overri';
wwv_flow_imp.g_varchar2_table(13) := 'de => p_proxy_override );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'        l_airports_json := apex_web_service.make_rest_request_b('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(14) := '                               p_url            => ''https://raw.githubusercontent.com/oracle/apex/22';
wwv_flow_imp.g_varchar2_table(15) := '.1/sample-apps/sample-maps/airports-full.json'','||wwv_flow.LF||
'                               p_http_method    => ''';
wwv_flow_imp.g_varchar2_table(16) := 'GET'','||wwv_flow.LF||
'                               p_proxy_override => p_proxy_override );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_s';
wwv_flow_imp.g_varchar2_table(17) := 'tates_json is not null then'||wwv_flow.LF||
'        delete from eba_sample_map_states;'||wwv_flow.LF||
'        delete from eba_sampl';
wwv_flow_imp.g_varchar2_table(18) := 'e_map_simple_states;'||wwv_flow.LF||
''||wwv_flow.LF||
'        insert into eba_sample_map_states (id, name, state_code, land_area, wa';
wwv_flow_imp.g_varchar2_table(19) := 'ter_area, geometry )'||wwv_flow.LF||
'        ( '||wwv_flow.LF||
'            select id, name, state_code, land_area, water_area, geom';
wwv_flow_imp.g_varchar2_table(20) := 'etry'||wwv_flow.LF||
'              from json_table('||wwv_flow.LF||
'                       l_states_json format json,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(21) := '         ''$[*]'''||wwv_flow.LF||
'                       columns ('||wwv_flow.LF||
'                                 id          number';
wwv_flow_imp.g_varchar2_table(22) := '             path ''$.id'','||wwv_flow.LF||
'                                 name        varchar2(255)      path ''$.na';
wwv_flow_imp.g_varchar2_table(23) := 'me'','||wwv_flow.LF||
'                                 state_code  varchar2(255)      path ''$.state_code'','||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(24) := '                       land_area   number             path ''$.land_area'','||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(25) := '       water_area  number             path ''$.water_area'','||wwv_flow.LF||
'                                 geometry';
wwv_flow_imp.g_varchar2_table(26) := '    mdsys.sdo_geometry path ''$.geometry'' ) ) );'||wwv_flow.LF||
''||wwv_flow.LF||
'        insert into eba_sample_map_simple_states (i';
wwv_flow_imp.g_varchar2_table(27) := 'd, name, state_code, land_area, water_area, geometry )'||wwv_flow.LF||
'        ( select id, name, state_code, land_a';
wwv_flow_imp.g_varchar2_table(28) := 'rea, water_area, mdsys.sdo_util.simplify( geometry, 75 ) '||wwv_flow.LF||
'            from eba_sample_map_states);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(29) := '   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_airports_json is not null then'||wwv_flow.LF||
'        delete from eba_sample_map_airports;'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(30) := '      insert into eba_sample_map_airports (id, iata_code, airport_type, airport_name, city, state_na';
wwv_flow_imp.g_varchar2_table(31) := 'me, activation_date, activation_date_dt, elevation, dist_city_to_airport, land_area_covered, commerc';
wwv_flow_imp.g_varchar2_table(32) := 'ial_ops, air_taxi_ops, geometry )'||wwv_flow.LF||
'            (select rownum, iata_code, airport_type, airport_name,';
wwv_flow_imp.g_varchar2_table(33) := ' city, state_name, to_char(to_date(activation_date, ''YYYY-MM-DD"T"HH24:MI:SS"Z"''), ''MON-RR''),to_date';
wwv_flow_imp.g_varchar2_table(34) := '(activation_date, ''YYYY-MM-DD"T"HH24:MI:SS"Z"''), elevation, dist_city_to_airport, land_area_covered,';
wwv_flow_imp.g_varchar2_table(35) := ' commercial_ops, air_taxi_ops, geometry'||wwv_flow.LF||
'               from json_table('||wwv_flow.LF||
'                        l_ai';
wwv_flow_imp.g_varchar2_table(36) := 'rports_json format json,'||wwv_flow.LF||
'                        ''$[*]'''||wwv_flow.LF||
'                        columns('||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(37) := '                      iata_code             varchar2(255)      path ''$.iata'','||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(38) := '           airport_type          varchar2(255)      path ''$.airport_type'','||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(39) := '        airport_name          varchar2(255)      path ''$.airport_name'','||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(40) := '     city                  varchar2(255)      path ''$.city'','||wwv_flow.LF||
'                                 state_';
wwv_flow_imp.g_varchar2_table(41) := 'name            varchar2(255)      path ''$.state_name'','||wwv_flow.LF||
'                                 activation_';
wwv_flow_imp.g_varchar2_table(42) := 'date       varchar2(50)       path ''$.act_date_dt'','||wwv_flow.LF||
'                                 elevation      ';
wwv_flow_imp.g_varchar2_table(43) := '       number             path ''$.elevation'','||wwv_flow.LF||
'                                 dist_city_to_airport ';
wwv_flow_imp.g_varchar2_table(44) := ' number             path ''$.dist_city_to_airport'','||wwv_flow.LF||
'                                 land_area_covere';
wwv_flow_imp.g_varchar2_table(45) := 'd     number             path ''$.land_area'','||wwv_flow.LF||
'                                 commercial_ops        ';
wwv_flow_imp.g_varchar2_table(46) := 'number             path ''$.commercial_ops'','||wwv_flow.LF||
'                                 air_taxi_ops          n';
wwv_flow_imp.g_varchar2_table(47) := 'umber             path ''$.air_taxi_ops'','||wwv_flow.LF||
'                                 geometry              sdo_';
wwv_flow_imp.g_varchar2_table(48) := 'geometry       path ''$.geometry'' ) ) );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(792072527358509329)
,p_install_id=>wwv_flow_imp.id(1556278723360956933)
,p_name=>'Load Data Procedure'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
