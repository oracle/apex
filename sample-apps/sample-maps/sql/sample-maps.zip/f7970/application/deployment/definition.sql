prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7970
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7970
,p_default_id_offset=>7801147223886292
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop table eba_sample_map_airports purge'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba_sample_map_states purge'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba';
wwv_flow_imp.g_varchar2_table(2) := '_sample_map_simple_states purge'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- remove tables from Spatial Registry (USER_SDO_GEOM_METADAT';
wwv_flow_imp.g_varchar2_table(3) := 'A)'||wwv_flow.LF||
'--'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    apex_spatial.delete_geom_metadata('||wwv_flow.LF||
'        p_table_name  => ''EBA_SAMPLE_MAP_STATES'',';
wwv_flow_imp.g_varchar2_table(4) := ''||wwv_flow.LF||
'        p_column_name => ''GEOMETRY'' );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    apex_spatial.delete_geom_metadata('||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(5) := ' p_table_name  => ''EBA_SAMPLE_MAP_SIMPLE_STATES'','||wwv_flow.LF||
'        p_column_name => ''GEOMETRY'' );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'beg';
wwv_flow_imp.g_varchar2_table(6) := 'in'||wwv_flow.LF||
'    apex_spatial.delete_geom_metadata('||wwv_flow.LF||
'        p_table_name  => ''EBA_SAMPLE_MAP_AIRPORTS'','||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(7) := '  p_column_name => ''GEOMETRY'' );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop procedure eba_sample_map_load_data'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(1556278723360956933)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
