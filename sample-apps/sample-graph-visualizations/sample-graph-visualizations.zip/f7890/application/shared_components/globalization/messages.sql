prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7890
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>857863501405308376
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
