prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7890
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>997204501598367911
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(9335649764085565863)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DROP TABLE "EBA_GRAPHVIZ_REGIONS";',
'DROP TABLE "EBA_GRAPHVIZ_COUNTRIES";',
'DROP TABLE "EBA_GRAPHVIZ_LOCATIONS";',
'DROP TABLE "EBA_GRAPHVIZ_DEPARTMENTS";',
'DROP TABLE "EBA_GRAPHVIZ_JOBS";',
'DROP TABLE "EBA_GRAPHVIZ_EMPLOYEES";',
'DROP TABLE "EBA_GRAPHVIZ_JOB_HISTORY";',
'DROP TABLE "EBA_GRAPHVIZ_GRAPH_ACTION"; ',
'',
'DROP SEQUENCE "EBA_GRAPHVIZ_GRAPH_ACTION_SEQ";',
''))
);
wwv_flow_imp.component_end;
end;
/
