prompt --application/deployment/install/install_eba_graphviz_ddl
begin
--   Manifest
--     INSTALL: INSTALL-EBA_GRAPHVIZ_DDL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>997204501598367911
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(26951284114886471840)
,p_install_id=>wwv_flow_imp.id(9335649764085565863)
,p_name=>'EBA_GRAPHVIZ_DDL'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'CREATE TABLE "EBA_GRAPHVIZ_REGIONS" ',
'   (	"REGION_ID" NUMBER CONSTRAINT "EBA_GRAPHVIZ_REGION_ID_NN" NOT NULL ENABLE, ',
'	"REGION_NAME" VARCHAR2(25), ',
'	 CONSTRAINT "EBA_GRAPHVIZ_REG_ID_PK" PRIMARY KEY ("REGION_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "EBA_GRAPHVIZ_COUNTRIES" ',
'   (	"COUNTRY_ID" CHAR(2) CONSTRAINT "EBA_GRAPHVIZ_COUNTRY_ID_NN" NOT NULL ENABLE, ',
'	"COUNTRY_NAME" VARCHAR2(40), ',
'	"REGION_ID" NUMBER, ',
'	 CONSTRAINT "EBA_GRAPHVIZ_COUNTRY_C_ID_PK" PRIMARY KEY ("COUNTRY_ID") ENABLE',
'   ) ORGANIZATION INDEX NOCOMPRESS ;',
'',
'CREATE TABLE "EBA_GRAPHVIZ_LOCATIONS" ',
'   (	"LOCATION_ID" NUMBER(4,0), ',
'	"STREET_ADDRESS" VARCHAR2(40), ',
'	"POSTAL_CODE" VARCHAR2(12), ',
'	"CITY" VARCHAR2(30) CONSTRAINT "EBA_GRAPHVIZ_LOC_CITY_NN" NOT NULL ENABLE, ',
'	"STATE_PROVINCE" VARCHAR2(25), ',
'	"COUNTRY_ID" CHAR(2), ',
'	 CONSTRAINT "EBA_GRAPHVIZ_LOC_ID_PK" PRIMARY KEY ("LOCATION_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "EBA_GRAPHVIZ_DEPARTMENTS" ',
'   (	"DEPARTMENT_ID" NUMBER(4,0), ',
'	"DEPARTMENT_NAME" VARCHAR2(30) CONSTRAINT "EBA_GRAPHVIZ_DEPT_NAME_NN" NOT NULL ENABLE, ',
'	"MANAGER_ID" NUMBER(6,0), ',
'	"LOCATION_ID" NUMBER(4,0), ',
'	 CONSTRAINT "EBA_GRAPHVIZ_DEPT_ID_PK" PRIMARY KEY ("DEPARTMENT_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "EBA_GRAPHVIZ_JOBS" ',
'   (	"JOB_ID" VARCHAR2(10), ',
'	"JOB_TITLE" VARCHAR2(35) CONSTRAINT "EBA_GRAPHVIZ_JOB_TITLE_NN" NOT NULL ENABLE, ',
'	"MIN_SALARY" NUMBER(6,0), ',
'	"MAX_SALARY" NUMBER(6,0), ',
'	 CONSTRAINT "EBA_GRAPHVIZ_JOB_ID_PK" PRIMARY KEY ("JOB_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "EBA_GRAPHVIZ_EMPLOYEES" ',
'   (	"EMPLOYEE_ID" NUMBER(6,0), ',
'	"FIRST_NAME" VARCHAR2(20), ',
'	"LAST_NAME" VARCHAR2(25) CONSTRAINT "EBA_GRAPHVIZ_EMP_LAST_NAME_NN" NOT NULL ENABLE, ',
'	"EMAIL" VARCHAR2(25) CONSTRAINT "EBA_GRAPHVIZ_EMP_EMAIL_NN" NOT NULL ENABLE, ',
'	"PHONE_NUMBER" VARCHAR2(20), ',
'	"HIRE_DATE" DATE CONSTRAINT "EBA_GRAPHVIZ_EMP_HIRE_DATE_NN" NOT NULL ENABLE, ',
'	"JOB_ID" VARCHAR2(10) CONSTRAINT "EBA_GRAPHVIZ_EMP_JOB_NN" NOT NULL ENABLE, ',
'	"SALARY" NUMBER(8,2), ',
'	"COMMISSION_PCT" NUMBER(2,2), ',
'	"MANAGER_ID" NUMBER(6,0), ',
'	"DEPARTMENT_ID" NUMBER(4,0), ',
'	 CONSTRAINT "EBA_GRAPHVIZ_EMP_SALARY_MIN" CHECK (salary > 0) ENABLE, ',
'	 CONSTRAINT "EBA_GRAPHVIZ_EMP_EMP_ID_PK" PRIMARY KEY ("EMPLOYEE_ID")',
'  USING INDEX  ENABLE, ',
'	 CONSTRAINT "EBA_GRAPHVIZ_EMP_EMAIL_UK" UNIQUE ("EMAIL")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "EBA_GRAPHVIZ_JOB_HISTORY" ',
'   (	"EMPLOYEE_ID" NUMBER(6,0) CONSTRAINT "EBA_GRAPHVIZ_JHIST_EMPLOYEE_NN" NOT NULL ENABLE, ',
'	"START_DATE" DATE CONSTRAINT "EBA_GRAPHVIZ_JHIST_START_DATE_NN" NOT NULL ENABLE, ',
'	"END_DATE" DATE CONSTRAINT "EBA_GRAPHVIZ_JHIST_END_DATE_NN" NOT NULL ENABLE, ',
'	"JOB_ID" VARCHAR2(10) CONSTRAINT "EBA_GRAPHVIZ_JHIST_JOB_NN" NOT NULL ENABLE, ',
'	"DEPARTMENT_ID" NUMBER(4,0), ',
'	 CONSTRAINT "EBA_GRAPHVIZ_JHIST_DATE_INTERVAL" CHECK (end_date >= start_date) ENABLE',
'   ) ;',
'',
'CREATE TABLE "EBA_GRAPHVIZ_GRAPH_ACTION" ',
'   (	"ID" NUMBER(10,0) NOT NULL ENABLE, ',
'	"ACTION" CLOB, ',
'	"USER_ID" VARCHAR2(50) NOT NULL ENABLE, ',
'	 CONSTRAINT "EBA_GRAPHVIZ_GRAPH_ACTION_PK" PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE SEQUENCE  "EBA_GRAPHVIZ_GRAPH_ACTION_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1261 NOCACHE  NOORDER  NOCYCLE  NOKEEP  GLOBAL ;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "EBA_GRAPHVIZ_GRAPH_ACTION_TRIGGER" ',
'BEFORE INSERT ON EBA_GRAPHVIZ_GRAPH_ACTION ',
'FOR EACH ROW',
'BEGIN',
'  SELECT EBA_GRAPHVIZ_GRAPH_ACTION_SEQ.NEXTVAL',
'  INTO   :new.id',
'  FROM   dual;',
'END;',
'',
'/',
'',
'ALTER TRIGGER "EBA_GRAPHVIZ_GRAPH_ACTION_TRIGGER" ENABLE;'))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(26951284266278471847)
,p_script_id=>wwv_flow_imp.id(26951284114886471840)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'OEHR_COUNTRIES'
,p_last_updated_by=>'SAJU.ASOKAN@ORACLE.COM'
,p_last_updated_on=>to_date('20230203070421','YYYYMMDDHH24MISS')
,p_created_by=>'SAJU.ASOKAN@ORACLE.COM'
,p_created_on=>to_date('20230203070421','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(26951284482752471850)
,p_script_id=>wwv_flow_imp.id(26951284114886471840)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'OEHR_DEPARTMENTS'
,p_last_updated_by=>'SAJU.ASOKAN@ORACLE.COM'
,p_last_updated_on=>to_date('20230203070421','YYYYMMDDHH24MISS')
,p_created_by=>'SAJU.ASOKAN@ORACLE.COM'
,p_created_on=>to_date('20230203070421','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(26951284689962471850)
,p_script_id=>wwv_flow_imp.id(26951284114886471840)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'OEHR_EMPLOYEES'
,p_last_updated_by=>'SAJU.ASOKAN@ORACLE.COM'
,p_last_updated_on=>to_date('20230203070421','YYYYMMDDHH24MISS')
,p_created_by=>'SAJU.ASOKAN@ORACLE.COM'
,p_created_on=>to_date('20230203070421','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(26951284869481471850)
,p_script_id=>wwv_flow_imp.id(26951284114886471840)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'OEHR_JOBS'
,p_last_updated_by=>'SAJU.ASOKAN@ORACLE.COM'
,p_last_updated_on=>to_date('20230203070421','YYYYMMDDHH24MISS')
,p_created_by=>'SAJU.ASOKAN@ORACLE.COM'
,p_created_on=>to_date('20230203070421','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(26951285088807471850)
,p_script_id=>wwv_flow_imp.id(26951284114886471840)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'OEHR_JOB_HISTORY'
,p_last_updated_by=>'SAJU.ASOKAN@ORACLE.COM'
,p_last_updated_on=>to_date('20230203070421','YYYYMMDDHH24MISS')
,p_created_by=>'SAJU.ASOKAN@ORACLE.COM'
,p_created_on=>to_date('20230203070421','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(26951285212698471850)
,p_script_id=>wwv_flow_imp.id(26951284114886471840)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'OEHR_LOCATIONS'
,p_last_updated_by=>'SAJU.ASOKAN@ORACLE.COM'
,p_last_updated_on=>to_date('20230203070421','YYYYMMDDHH24MISS')
,p_created_by=>'SAJU.ASOKAN@ORACLE.COM'
,p_created_on=>to_date('20230203070421','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(26951285466901471851)
,p_script_id=>wwv_flow_imp.id(26951284114886471840)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'OEHR_REGIONS'
,p_last_updated_by=>'SAJU.ASOKAN@ORACLE.COM'
,p_last_updated_on=>to_date('20230203070421','YYYYMMDDHH24MISS')
,p_created_by=>'SAJU.ASOKAN@ORACLE.COM'
,p_created_on=>to_date('20230203070421','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
