prompt --application/deployment/install/install_eba_graphviz_data
begin
--   Manifest
--     INSTALL: INSTALL-EBA_GRAPHVIZ_DATA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>997204501598367911
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(26968730524282851721)
,p_install_id=>wwv_flow_imp.id(9335649764085565863)
,p_name=>'EBA_GRAPHVIZ_DATA'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --EBA_GRAPHVIZ_COUNTRIES: 25/10000 rows exported, APEX$DATA$PKG/EBA_GRAPHVIZ_COUNTRIES$655846',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_GRAPHVIZ_COUNTRIES'', p_delete_after_install => false );',
'    --EBA_GRAPHVIZ_DEPARTMENTS: 27/10000 rows exported, APEX$DATA$PKG/EBA_GRAPHVIZ_DEPARTMENTS$300836',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_GRAPHVIZ_DEPARTMENTS'', p_delete_after_install => false );',
'    --EBA_GRAPHVIZ_EMPLOYEES: 107/10000 rows exported, APEX$DATA$PKG/EBA_GRAPHVIZ_EMPLOYEES$828178',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_GRAPHVIZ_EMPLOYEES'', p_delete_after_install => false );',
'    --EBA_GRAPHVIZ_JOBS: 19/10000 rows exported, APEX$DATA$PKG/EBA_GRAPHVIZ_JOBS$113840',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_GRAPHVIZ_JOBS'', p_delete_after_install => false );',
'    --EBA_GRAPHVIZ_JOB_HISTORY: 10/10000 rows exported, APEX$DATA$PKG/EBA_GRAPHVIZ_JOB_HISTORY$762237',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_GRAPHVIZ_JOB_HISTORY'', p_delete_after_install => false );',
'    --EBA_GRAPHVIZ_LOCATIONS: 23/10000 rows exported, APEX$DATA$PKG/EBA_GRAPHVIZ_LOCATIONS$916165',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_GRAPHVIZ_LOCATIONS'', p_delete_after_install => false );',
'    --EBA_GRAPHVIZ_REGIONS: 4/10000 rows exported, APEX$DATA$PKG/EBA_GRAPHVIZ_REGIONS$917117',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_GRAPHVIZ_REGIONS'', p_delete_after_install => false );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
