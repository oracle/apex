prompt --application/comments
begin
--   Manifest
--     APPLICATION COMMENTS: 7890
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>606820219092768229
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
