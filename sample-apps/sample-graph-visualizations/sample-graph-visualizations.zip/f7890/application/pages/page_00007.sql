prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>857863501405308376
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Styling'
,p_alias=>'STYLING'
,p_step_title=>'Styling - &APP_NAME.'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'ANDRE.CURIEL@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20230727175700'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7499623936694282543)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12653427163797746442)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'USER'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9610614385055989978)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12653492835355746496)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(12653389315424746351)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(12653555117577746591)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14971015143635750150)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>wwv_flow_imp.id(12653420510670746425)
,p_plug_display_sequence=>10
,p_plug_source=>'This use case extends the previous ''Basic graph'' example, by adding styling to the graph component. Different ways to achieve styling are demonstrated with examples.'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152330681457147545)
,p_plug_name=>'Dynamic Expressions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(12653453941494746464)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'Dynamic expressions uses the same ''Attributes->Settings->Styles'' property used in the above example, but extends it further by using expressions inside Styles that evaluates at run-time.<br><br>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17746182859346308762)
,p_plug_name=>'Dynamic Expressions Graph'
,p_parent_plug_id=>wwv_flow_imp.id(24152330681457147545)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:i-h320:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653480208122746486)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*  Query populates the JSON for a simple graph with just 10 edges.',
'    The graph shows employee manager reporting structure.',
'*/',
'WITH edges as (',
'    SELECT',
'        EMPLOYEE_ID as source,',
'        MANAGER_ID as target',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        MANAGER_ID IS NOT NULL OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY',
'),',
'vertices AS (',
'    SELECT',
'        JSON_OBJECT(''id'' VALUE EMPLOYEE_ID) AS vertex',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        EMPLOYEE_ID in (',
'            SELECT',
'                source',
'            from',
'                edges',
'        )',
'        or EMPLOYEE_ID in (',
'            SELECT',
'                target',
'            from',
'                edges',
'        )',
')',
'SELECT',
'    JSON_OBJECT(',
'        ''vertices'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(vertex returning clob)',
'            FROM',
'                vertices',
'        ),',
'        ''edges'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(',
'                    JSON_OBJECT(''source'' VALUE source, ''target'' VALUE target)',
'                )',
'            FROM',
'                edges',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    "vertex[id % 3 === 0]": {',
'        "color": "red",',
'        "border": {',
'            "width": 3',
'        }',
'    }',
'}'))
,p_attribute_05=>'N'
,p_attribute_14=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152332069778147559)
,p_plug_name=>'Dynamic Expressions Details'
,p_parent_plug_id=>wwv_flow_imp.id(24152330681457147545)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653444443787746457)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'In the below Styles JSON, dynamic expression is used to define the color of the vertices (will be red if the vertex id is a multiple of 3). Query doesn''t contain any styling info.',
'<br><br>',
'<strong>Settings > Styles JSON</strong>',
'<br>',
'<code>',
'{',
'    "vertex[id % 3 === 0]": {',
'        "color": "red",',
'        "border": {',
'            "width": 3',
'        }',
'    }',
'}',
'</code>',
'<br><br>',
'<strong>Query</strong>',
'<br>',
'<code>/*  Query populates the JSON for a simple graph with just 10 edges.',
'    The graph shows employee manager reporting structure.',
'*/',
'WITH edges as (',
'    SELECT',
'        EMPLOYEE_ID as source,',
'        MANAGER_ID as target',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        MANAGER_ID IS NOT NULL OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY',
'),',
'vertices AS (',
'    SELECT',
'        JSON_OBJECT(''id'' VALUE EMPLOYEE_ID) AS vertex',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        EMPLOYEE_ID in (',
'            SELECT',
'                source',
'            from',
'                edges',
'        )',
'        or EMPLOYEE_ID in (',
'            SELECT',
'                target',
'            from',
'                edges',
'        )',
')',
'SELECT',
'    JSON_OBJECT(',
'        ''vertices'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(vertex returning clob)',
'            FROM',
'                vertices',
'        ),',
'        ''edges'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(',
'                    JSON_OBJECT(''source'' VALUE source, ''target'' VALUE target)',
'                )',
'            FROM',
'                edges',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL',
'</code>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152332193954147560)
,p_plug_name=>'Using the Settings Attribute'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(12653453941494746464)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This example demonstrates styling the graph using the ''Attributes->Settings->Styles'' panel in APEX, the values of which gets applied to the settings parameter of the Graph Visualization Toolkit (GVT) component. ',
'<br>',
'Some styles applied in this example includes  <b>size, color, icon, children</b> etc. Interpolation in the below example interprets properties like JobId, Salary etc and derive values like color from it, for use in styling the graph.',
'<br><br>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152330159993147540)
,p_plug_name=>'Vertex Styles'
,p_parent_plug_id=>wwv_flow_imp.id(24152332193954147560)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:i-h640:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653480208122746486)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH query as (',
'    -- source and target constitutes the edge direction and thus',
'    -- represents the reporting structure of employee to their managers.',
'    SELECT',
'        EMPLOYEE_ID as source,',
'        MANAGER_ID as target',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        MANAGER_ID IS NOT NULL',
'),',
'page AS (',
'    -- pagination',
'    SELECT',
'        *',
'    FROM',
'        query',
'    ORDER BY',
'        source,',
'        target OFFSET :page_start ROWS FETCH NEXT :page_size ROWS ONLY',
'),',
'vertices AS (',
'    -- fetch employee details and construct JSON',
'    SELECT',
'        JSON_OBJECT(',
'            ''id'' VALUE employees.EMPLOYEE_ID,',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE employees.FIRST_NAME,',
'                ''LastName'' VALUE employees.LAST_NAME,',
'                ''Salary'' VALUE employees.SALARY,',
'                ''Department'' VALUE employees.DEPARTMENT_ID,',
'                ''HireDate'' VALUE employees.HIRE_DATE,',
'                ''JobId'' VALUE jobs.JOB_ID,',
'                ''JobTitle'' VALUE jobs.JOB_TITLE,',
'                ''Country'' VALUE locations.COUNTRY_ID',
'            )',
'        ) AS vertex',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES employees',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_JOBS jobs ON employees.JOB_ID = jobs.JOB_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_DEPARTMENTS departments ON employees.DEPARTMENT_ID = departments.DEPARTMENT_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_LOCATIONS locations ON departments.LOCATION_ID = locations.LOCATION_ID',
'    WHERE',
'        employees.EMPLOYEE_ID in (',
'            SELECT',
'                source',
'            from',
'                page',
'        )',
'        or employees.EMPLOYEE_ID in (',
'            SELECT',
'                target',
'            from',
'                page',
'        )',
'),',
'edges AS (',
'    -- source (employee) and target (manager) constitutes the directed edge',
'    SELECT',
'        JSON_OBJECT(''source'' VALUE source, ''target'' VALUE target) AS edge',
'    FROM',
'        page',
')',
'SELECT',
'    -- construct the final JSON that GVT accepts.',
'    JSON_OBJECT(',
'        ''vertices'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(vertex returning clob)',
'            FROM',
'                vertices',
'        ),',
'        ''edges'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(edge returning clob)',
'            FROM',
'                edges',
'        ),',
'        ''numResults'' VALUE (',
'            SELECT',
'                COUNT(*)',
'            FROM',
'                query',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attribute_02=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'  "legendWidth": 300',
'}'))
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'   "vertex":{',
'      "size":12,',
'      "label":"${properties.FirstName} ${properties.LastName}",',
'      "color":"${interpolate.discrete(''properties.JobId'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
'      "icon":"fa-user",',
'      "legend":"${properties.JobTitle}",',
'      "children":{',
'         "salary":{',
'            "size":8,',
'            "color":"${interpolate.color(''properties.Salary'', ''white'', ''#FB8500'')}",',
'            "icon":{',
'               "class":"fa-money",',
'               "color":"black"',
'            },',
'            "border":{',
'               "width":1,',
'               "color":"#FB8500"',
'            }',
'         }',
'      }',
'   },',
'   "vertex[!!properties.Country]":{',
'      "children":{',
'         "flag":{',
'            "size":10,',
'            "image":{',
'               "url":"https://flagcdn.com/40x30/${(properties.Country === ''UK'' ? ''GB'' : properties.Country).toLowerCase()}.png",',
'               "scale":0.8',
'            }',
'         }',
'      }',
'   },',
'   "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JobId) >= 0]":{',
'      "icon":"fa-user-secret"',
'   }',
'}'))
,p_attribute_05=>'N'
,p_attribute_10=>'modes:exploration'
,p_attribute_14=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152330517638147544)
,p_plug_name=>'Settings Attribute Details'
,p_parent_plug_id=>wwv_flow_imp.id(24152332193954147560)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653444443787746457)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Settings > Styles JSON</strong>',
'<br>',
'<code>',
'{',
'   "vertex":{',
'      "size":12,',
'      "label":"${properties.FirstName} ${properties.LastName}",',
'      "color":"${interpolate.discrete(''properties.JobId'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
'      "icon":"fa-user",',
'      "legend":"${properties.JobTitle}",',
'      "children":{',
'         "salary":{',
'            "size":8,',
'            "color":"${interpolate.color(''properties.Salary'', ''white'', ''#FB8500'')}",',
'            "icon":{',
'               "class":"fa-money",',
'               "color":"black"',
'            },',
'            "border":{',
'               "width":1,',
'               "color":"#FB8500"',
'            }',
'         }',
'      }',
'   },',
'   "vertex[!!properties.Country]":{',
'      "children":{',
'         "flag":{',
'            "size":10,',
'            "image":{',
'               "url":"https://flagcdn.com/40x30/${(properties.Country === ''UK'' ? ''GB'' : properties.Country).toLowerCase()}.png",',
'               "scale":0.8',
'            }',
'         }',
'      }',
'   },',
'   "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JobId) >= 0]":{',
'      "icon":"fa-user-secret"',
'   }',
'}',
'</code>',
'<br>',
'<strong>Settings JSON</strong>',
'<br>',
'The legendWidth property can be used to customize the legend area''s width. ',
'<code>',
'{',
'    "legendWidth":300',
'}',
'</code>',
'<br>',
'',
'<br><br>',
'<strong>Query:</strong>',
'<br>',
'',
'',
'<code>WITH query as (',
'    -- source and target constitutes the edge direction and thus',
'    -- represents the reporting structure of employee to their managers.',
'    SELECT',
'        EMPLOYEE_ID as source,',
'        MANAGER_ID as target',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        MANAGER_ID IS NOT NULL',
'),',
'page AS (',
'    -- pagination',
'    SELECT',
'        *',
'    FROM',
'        query',
'    ORDER BY',
'        source,',
'        target OFFSET :page_start ROWS FETCH NEXT :page_size ROWS ONLY',
'),',
'vertices AS (',
'    -- fetch employee details and construct JSON',
'    SELECT',
'        JSON_OBJECT(',
'            ''id'' VALUE employees.EMPLOYEE_ID,',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE employees.FIRST_NAME,',
'                ''LastName'' VALUE employees.LAST_NAME,',
'                ''Salary'' VALUE employees.SALARY,',
'                ''Department'' VALUE employees.DEPARTMENT_ID,',
'                ''HireDate'' VALUE employees.HIRE_DATE,',
'                ''JobId'' VALUE jobs.JOB_ID,',
'                ''JobTitle'' VALUE jobs.JOB_TITLE,',
'                ''Country'' VALUE locations.COUNTRY_ID',
'            )',
'        ) AS vertex',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES employees',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_JOBS jobs ON employees.JOB_ID = jobs.JOB_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_DEPARTMENTS departments ON employees.DEPARTMENT_ID = departments.DEPARTMENT_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_LOCATIONS locations ON departments.LOCATION_ID = locations.LOCATION_ID',
'    WHERE',
'        employees.EMPLOYEE_ID in (',
'            SELECT',
'                source',
'            from',
'                page',
'        )',
'        or employees.EMPLOYEE_ID in (',
'            SELECT',
'                target',
'            from',
'                page',
'        )',
'),',
'edges AS (',
'    -- source (employee) and target (manager) constitutes the directed edge',
'    SELECT',
'        JSON_OBJECT(''source'' VALUE source, ''target'' VALUE target) AS edge',
'    FROM',
'        page',
')',
'SELECT',
'    -- construct the final JSON that GVT accepts.',
'    JSON_OBJECT(',
'        ''vertices'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(vertex returning clob)',
'            FROM',
'                vertices',
'        ),',
'        ''edges'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(edge returning clob)',
'            FROM',
'                edges',
'        ),',
'        ''numResults'' VALUE (',
'            SELECT',
'                COUNT(*)',
'            FROM',
'                query',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL',
'</code>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152332256164147561)
,p_plug_name=>'Inline Styles'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(12653453941494746464)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'Inline styles refers to adding ''style'' property in the SQL selection query itself, rather than passing it through the Settings parameter.<br><br>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17745962273033888498)
,p_plug_name=>'Inline Styles Graph'
,p_parent_plug_id=>wwv_flow_imp.id(24152332256164147561)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:i-h320:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653480208122746486)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*  The query has ''style'' property in the JSON Object that defines styling (color) of vertices.',
'    In this query, the vertex color will be red when EMPLOYEE_ID is a multiple of 3.',
'    The graph shows employee manager reporting structure.',
'*/',
'WITH edges as (',
'    SELECT',
'        EMPLOYEE_ID as source,',
'        MANAGER_ID as target',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        MANAGER_ID IS NOT NULL OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY',
'),',
'vertices AS (',
'    SELECT',
'        JSON_OBJECT(',
'            ''id'' VALUE EMPLOYEE_ID,',
'            ''style'' VALUE JSON_OBJECT(',
'                ''color'' VALUE CASE',
'                    WHEN MOD(EMPLOYEE_ID, 3) = 0 THEN ''red''',
'                    ELSE ''lightgray''',
'                END',
'            )',
'        ) AS vertex',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        EMPLOYEE_ID in (',
'            SELECT',
'                source',
'            from',
'                edges',
'        )',
'        or EMPLOYEE_ID in (',
'            SELECT',
'                target',
'            from',
'                edges',
'        )',
')',
'SELECT',
'    JSON_OBJECT(',
'        ''vertices'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(vertex returning clob)',
'            FROM',
'                vertices',
'        ),',
'        ''edges'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(',
'                    JSON_OBJECT(''source'' VALUE source, ''target'' VALUE target)',
'                )',
'            FROM',
'                edges',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attribute_05=>'N'
,p_attribute_14=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152330771102147546)
,p_plug_name=>'Inline Style Details'
,p_parent_plug_id=>wwv_flow_imp.id(24152332256164147561)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653444443787746457)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Query</strong>',
'<br>',
'<code>',
'/*  The query has ''style'' property in the JSON Object that defines styling (color) of vertices.',
'    In this query, the vertex color will be red when EMPLOYEE_ID is a multiple of 3.',
'    The graph shows employee manager reporting structure.',
'*/',
'WITH edges as (',
'    SELECT',
'        EMPLOYEE_ID as source,',
'        MANAGER_ID as target',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        MANAGER_ID IS NOT NULL OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY',
'),',
'vertices AS (',
'    SELECT',
'        JSON_OBJECT(',
'            ''id'' VALUE EMPLOYEE_ID,',
'            ''style'' VALUE JSON_OBJECT(',
'                ''color'' VALUE CASE',
'                    WHEN MOD(EMPLOYEE_ID, 3) = 0 THEN ''red''',
'                    ELSE ''lightgray''',
'                END',
'            )',
'        ) AS vertex',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        EMPLOYEE_ID in (',
'            SELECT',
'                source',
'            from',
'                edges',
'        )',
'        or EMPLOYEE_ID in (',
'            SELECT',
'                target',
'            from',
'                edges',
'        )',
')',
'SELECT',
'    JSON_OBJECT(',
'        ''vertices'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(vertex returning clob)',
'            FROM',
'                vertices',
'        ),',
'        ''edges'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(',
'                    JSON_OBJECT(''source'' VALUE source, ''target'' VALUE target)',
'                )',
'            FROM',
'                edges',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL',
'</code>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152332339215147562)
,p_plug_name=>'Classes'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(12653453941494746464)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'This method is similar to ''Inline Styles'', and styling is achieved here by adding ''classes'' property directly in the SQL selection query. The classes used are defined in the Settings > Styles property.<br><br>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17746494164244324765)
,p_plug_name=>'Classes Graph'
,p_parent_plug_id=>wwv_flow_imp.id(24152332339215147562)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:i-h320:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653480208122746486)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*  The query has ''classes'' property in the JSON Object to define styling (color) of vertices.',
'    In this example, the vertex will be assigned the class ''marked'' when EMPLOYEE_ID is a multiple of 3.',
'    ',
'    The graph shows employee manager reporting structure.',
'*/',
'WITH edges as (',
'    SELECT',
'        EMPLOYEE_ID as source,',
'        MANAGER_ID as target',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        MANAGER_ID IS NOT NULL OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY',
'),',
'vertices AS (',
'    -- ''classes'' styling added in JSON',
'    SELECT',
'        JSON_OBJECT(',
'            ''id'' VALUE EMPLOYEE_ID,',
'            ''classes'' VALUE JSON_ARRAY(',
'                CASE',
'                    WHEN MOD(EMPLOYEE_ID, 3) = 0 THEN ''marked''',
'                    ELSE null',
'                END',
'            )',
'        ) AS vertex',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        EMPLOYEE_ID in (',
'            SELECT',
'                source',
'            from',
'                edges',
'        )',
'        or EMPLOYEE_ID in (',
'            SELECT',
'                target',
'            from',
'                edges',
'        )',
')',
'SELECT',
'    JSON_OBJECT(',
'        ''vertices'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(vertex returning clob)',
'            FROM',
'                vertices',
'        ),',
'        ''edges'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(',
'                    JSON_OBJECT(''source'' VALUE source, ''target'' VALUE target)',
'                )',
'            FROM',
'                edges',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    ".marked": {',
'        "color": "red"',
'    }',
'}'))
,p_attribute_05=>'N'
,p_attribute_14=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152330794792147547)
,p_plug_name=>'Class Details'
,p_parent_plug_id=>wwv_flow_imp.id(24152332339215147562)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653444443787746457)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The ''class'' used in the SQL query gets defined in Styles.',
'',
'<br><br>',
'<strong>Settings > Styles JSON</strong>',
'<br>',
'<code>',
'{',
'    ".marked": {',
'        "color": "red"',
'    }',
'}',
'</code>',
'<br><br>',
'<strong>Query</strong>',
'<br>',
'<code>',
'',
'/*  The query has ''classes'' property in the JSON Object to define styling (color) of vertices.',
'    In this example, the vertex will be assigned the class ''marked'' when EMPLOYEE_ID is a multiple of 3.',
'    ',
'    The graph shows employee manager reporting structure.',
'*/',
'WITH edges as (',
'    SELECT',
'        EMPLOYEE_ID as source,',
'        MANAGER_ID as target',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        MANAGER_ID IS NOT NULL OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY',
'),',
'vertices AS (',
'    -- ''classes'' styling added in JSON',
'    SELECT',
'        JSON_OBJECT(',
'            ''id'' VALUE EMPLOYEE_ID,',
'            ''classes'' VALUE JSON_ARRAY(',
'                CASE',
'                    WHEN MOD(EMPLOYEE_ID, 3) = 0 THEN ''marked''',
'                    ELSE null',
'                END',
'            )',
'        ) AS vertex',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        EMPLOYEE_ID in (',
'            SELECT',
'                source',
'            from',
'                edges',
'        )',
'        or EMPLOYEE_ID in (',
'            SELECT',
'                target',
'            from',
'                edges',
'        )',
')',
'SELECT',
'    JSON_OBJECT(',
'        ''vertices'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(vertex returning clob)',
'            FROM',
'                vertices',
'        ),',
'        ''edges'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(',
'                    JSON_OBJECT(''source'' VALUE source, ''target'' VALUE target)',
'                )',
'            FROM',
'                edges',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL',
'</code>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
