prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>997204501598367911
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'Keyboard Navigation Shortcuts'
,p_alias=>'KEYBOARD-NAVIGATION-SHORTCUTS'
,p_step_title=>'Keyboard Navigation Shortcuts'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'ANDRE.CURIEL@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20231101154027'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11984315687751298679)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12792833835548806031)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(12792730315617805886)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(12792896117770806126)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31307053996153707358)
,p_plug_name=>'Keyboard Navigation Shortcuts'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(12792794941687805999)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The below example shows how you can interact with the graph by keyboard shortcuts.',
'<br/><br/>',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24880860552609073605)
,p_plug_name=>'Interaction'
,p_region_name=>'graph'
,p_parent_plug_id=>wwv_flow_imp.id(31307053996153707358)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:i-h640:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12792821208315806021)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*  ',
'    Interaction depicted by this example, is achieved via ''Settings'' parameter',
'    controlled via buttons in the page, and isn''t affected by the query.',
'',
'    In the below query, data is selected from database tables and ',
'    made into JSON format that GVT accepts.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the reporting structure of employees to their managers.*/',
'    ',
'WITH query as (',
'    -- source and target constitutes the edge direction and thus',
'    -- represents the reporting structure of employee to their managers.',
'    SELECT',
'        EMPLOYEE_ID as source,',
'        MANAGER_ID as target',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        MANAGER_ID IS NOT NULL',
'),',
'page AS (',
'    -- pagination',
'    SELECT',
'        *',
'    FROM',
'        query',
'    ORDER BY',
'        source,',
'        target OFFSET :page_start ROWS FETCH NEXT :page_size ROWS ONLY',
'),',
'vertices AS (',
'    -- fetch employee details and construct JSON',
'    SELECT',
'        JSON_OBJECT(',
'            ''id'' VALUE employees.EMPLOYEE_ID,',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE employees.FIRST_NAME,',
'                ''LastName'' VALUE employees.LAST_NAME,',
'                ''Salary'' VALUE employees.SALARY,',
'                ''Department'' VALUE employees.DEPARTMENT_ID,',
'                ''HireDate'' VALUE employees.HIRE_DATE,',
'                ''JobId'' VALUE jobs.JOB_ID,',
'                ''JobTitle'' VALUE jobs.JOB_TITLE,',
'                ''Country'' VALUE locations.COUNTRY_ID',
'            )',
'        ) AS vertex',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES employees',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_JOBS jobs ON employees.JOB_ID = jobs.JOB_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_DEPARTMENTS departments ON employees.DEPARTMENT_ID = departments.DEPARTMENT_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_LOCATIONS locations ON departments.LOCATION_ID = locations.LOCATION_ID',
'    WHERE',
'        employees.EMPLOYEE_ID in (',
'            SELECT',
'                source',
'            from',
'                page',
'        )',
'        or employees.EMPLOYEE_ID in (',
'            SELECT',
'                target',
'            from',
'                page',
'        )',
'),',
'edges AS (',
'    -- source (employee) and target (manager) constitutes the directed edge',
'    SELECT',
'        JSON_OBJECT(''source'' VALUE source, ''target'' VALUE target) AS edge',
'    FROM',
'        page',
')',
'SELECT',
'    -- construct the final JSON that GVT accepts.',
'    JSON_OBJECT(',
'        ''vertices'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(vertex returning clob)',
'            FROM',
'                vertices',
'        ),',
'        ''edges'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(edge returning clob)',
'            FROM',
'                edges',
'        ),',
'        ''numResults'' VALUE (',
'            SELECT',
'                COUNT(*)',
'            FROM',
'                query',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    "vertex": {',
'        "size": 12,',
'        "label": "${properties.FirstName} ${properties.LastName}",',
'        "color": "${interpolate.discrete(''properties.JobId'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
'        "icon": "fa-user",',
'        "legend": "${properties.JobTitle}",',
'        "children": {',
'            "salary": {',
'                "size": 8,',
'                "color": "${interpolate.color(''properties.Salary'', ''white'', ''#FB8500'')}",',
'                "icon": {',
'                    "class": "fa-money",',
'                    "color": "black"',
'                },',
'                "border": {',
'                    "width": 1,',
'                    "color": "#FB8500"',
'                }',
'            }',
'        }',
'    },',
'    "vertex[!!properties.Country]": {',
'        "children": {',
'            "flag": {',
'                "size": 10,',
'                "image": {',
'                    "url": "https://flagcdn.com/40x30/${(properties.Country === ''UK'' ? ''GB'' : properties.Country).toLowerCase()}.png",',
'                    "scale": 0.8',
'                }',
'            }',
'        }',
'    },',
'    "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JobId) >= 0]": {',
'        "icon": "fa-user-secret"',
'    }',
'}'))
,p_attribute_05=>'N'
,p_attribute_10=>'modes:exploration'
,p_attribute_14=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31307050912622707327)
,p_plug_name=>'Details'
,p_parent_plug_id=>wwv_flow_imp.id(31307053996153707358)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12792785443980805992)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Graph Visualization Toolkit supports keyboard-only support for all major graph operations and navigations that can otherwise be performed using a mouse. The main key combinations are:<br>',
'<br>',
'<b>Tab</b>: Move focus to next element.<br>',
'<br>',
'<b>Shift + Tab</b>: Move focus to previous element.<br>',
'<br>',
'<b>LeftArrow or RightArrow</b>: When focus is on a node, move focus and selection to nearest node left/right.<br>',
'<br>',
'<b>UpArrow or DownArrow</b>: When focus is on a node, move focus and selection to nearest node up/down.<br>',
'<br>',
'<b>Alt + Arrow Keys</b>: Switch from Vertex to edge and vice versa<br>',
'<br>',
'<b>Ctrl + Alt + Arrow Keys</b>: Pan in the direction of the arrow.<br>',
'<br>',
'<b>Alt + Spacebar / Menu key</b>: Opens tooltip<br>',
'<br>',
'<b>Esc/Escape key</b>: Exit tooltip<br>',
'<br>',
'<b>+ Key</b>: Zoom in one level.<br>',
'<br>',
'<b>- Key</b>: Zoom out one level.'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11985198051880378335)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(24880860552609073605)
,p_button_name=>'Force'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(12792894644015806124)
,p_button_image_alt=>'Force'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-network-hub'
,p_button_cattributes=>'title="Force - Force correlation arrows to point at their inner-related vertices with all vertices ultimately pointing at the root vertex"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11985196808115378332)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(24880860552609073605)
,p_button_name=>'Radial'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(12792894644015806124)
,p_button_image_alt=>'Radial'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-network-hub'
,p_button_cattributes=>'title="Radial - Display graph with outer vertices in a circle encompassing inner vertices and ultimately the root vertex centered in the middle"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11985197284573378334)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(24880860552609073605)
,p_button_name=>'GroupEdges'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(12792893828628806119)
,p_button_image_alt=>'Group Edges'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-object-group'
,p_button_cattributes=>'title="Group edges"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11985197676854378335)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(24880860552609073605)
,p_button_name=>'UnGroupEdges'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(12792893828628806119)
,p_button_image_alt=>'Ungroup Edges'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-object-ungroup'
,p_button_cattributes=>'title="Ungroup edges"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11985199250203378337)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(24880860552609073605)
,p_button_name=>'First'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(12792894644015806124)
,p_button_image_alt=>'First'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-align-left'
,p_button_cattributes=>'title="Change vertices'' labels to display first name only"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11985198413743378336)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(24880860552609073605)
,p_button_name=>'Last'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(12792894644015806124)
,p_button_image_alt=>'Last'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-align-left'
,p_button_cattributes=>'title="Change vertices'' labels to display last name only"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11985198807060378336)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(24880860552609073605)
,p_button_name=>'Full'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(12792894644015806124)
,p_button_image_alt=>'Full'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-align-left'
,p_button_cattributes=>'title="Change vertices'' labels to display full name"'
);
wwv_flow_imp.component_end;
end;
/
