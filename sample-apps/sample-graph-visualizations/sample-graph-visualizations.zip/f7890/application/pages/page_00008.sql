prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>857863501405308376
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'Saving Graph State'
,p_alias=>'SAVING-GRAPH-STATE'
,p_step_title=>'Saving graph state - &APP_NAME.'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'KORBI.SCHMID@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20230602215837'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13855935405547239397)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12653492835355746496)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(12653389315424746351)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(12653555117577746591)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19236774113710911311)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>wwv_flow_imp.id(12653420510670746425)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_source=>'The below example shows how various actions in the graph can be persisted. When the page reloads, all the persisted actions are retrieved from the database and applied back to the graph. '
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21991421527295566453)
,p_plug_name=>'Saving Graph State'
,p_region_name=>'graph'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:i-h640:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653480208122746486)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*  In the below query, data is selected from database tables and ',
'    made into JSON format that GVT accepts.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the reporting structure of employees to their managers.*/',
'    ',
'WITH query as (',
'    -- source and target constitutes the edge direction and thus',
'    -- represents the reporting structure of employee to their managers.',
'    SELECT',
'        EMPLOYEE_ID as source,',
'        MANAGER_ID as target',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        MANAGER_ID IS NOT NULL',
'),',
'page AS (',
'    -- pagination',
'    SELECT',
'        *',
'    FROM',
'        query',
'    ORDER BY',
'        source,',
'        target OFFSET :page_start ROWS FETCH NEXT :page_size ROWS ONLY',
'),',
'vertices AS (',
'    -- fetch employee details and construct JSON',
'    SELECT',
'        JSON_OBJECT(',
'            ''id'' VALUE employees.EMPLOYEE_ID,',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE employees.FIRST_NAME,',
'                ''LastName'' VALUE employees.LAST_NAME,',
'                ''Salary'' VALUE employees.SALARY,',
'                ''Department'' VALUE employees.DEPARTMENT_ID,',
'                ''HireDate'' VALUE employees.HIRE_DATE,',
'                ''JobId'' VALUE jobs.JOB_ID,',
'                ''JobTitle'' VALUE jobs.JOB_TITLE,',
'                ''Country'' VALUE locations.COUNTRY_ID',
'            )',
'        ) AS vertex',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES employees',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_JOBS jobs ON employees.JOB_ID = jobs.JOB_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_DEPARTMENTS departments ON employees.DEPARTMENT_ID = departments.DEPARTMENT_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_LOCATIONS locations ON departments.LOCATION_ID = locations.LOCATION_ID',
'    WHERE',
'        employees.EMPLOYEE_ID in (',
'            SELECT',
'                source',
'            from',
'                page',
'        )',
'        or employees.EMPLOYEE_ID in (',
'            SELECT',
'                target',
'            from',
'                page',
'        )',
'),',
'edges AS (',
'    -- source (employee) and target (manager) constitutes the directed edge',
'    SELECT',
'        JSON_OBJECT(''source'' VALUE source, ''target'' VALUE target) AS edge',
'    FROM',
'        page',
')',
'SELECT',
'    -- construct the final JSON that GVT accepts.',
'    JSON_OBJECT(',
'        ''vertices'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(vertex returning clob)',
'            FROM',
'                vertices',
'        ),',
'        ''edges'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(edge returning clob)',
'            FROM',
'                edges',
'        ),',
'        ''numResults'' VALUE (',
'            SELECT',
'                COUNT(*)',
'            FROM',
'                query',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    "vertex": {',
'        "size": 12,',
'        "label": "${properties.FirstName} ${properties.LastName}",',
'        "color": "${interpolate.discrete(''properties.JobId'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
'        "icon": "fa-user",',
'        "legend": "${properties.JobTitle}",',
'        "children": {',
'            "salary": {',
'                "size": 8,',
'                "color": "${interpolate.color(''properties.Salary'', ''white'', ''#FB8500'')}",',
'                "icon": {',
'                    "class": "fa-money",',
'                    "color": "black"',
'                },',
'                "border": {',
'                    "width": 1,',
'                    "color": "#FB8500"',
'                }',
'            }',
'        }',
'    },',
'    "vertex[!!properties.Country]": {',
'        "children": {',
'            "flag": {',
'                "size": 10,',
'                "image": {',
'                    "url": "https://flagcdn.com/40x30/${(properties.Country === ''UK'' ? ''GB'' : properties.Country).toLowerCase()}.png",',
'                    "scale": 0.8',
'                }',
'            }',
'        }',
'    },',
'    "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JobId) >= 0]": {',
'        "icon": "fa-user-secret"',
'    },',
'    ',
'  "edge": {',
'    "color": "gray",',
'    "legend": "edge",',
'    "width": 2,',
'    "label": {',
'      "color": "gray",',
'      "text": "edge",',
'      "font": {',
'        "size": 12',
'      }',
'    }',
'  }',
'}'))
,p_attribute_05=>'N'
,p_attribute_10=>'modes:exploration'
,p_attribute_12=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    const actions = await apex.server.process(''Fetch'',null, {dataType: ''text''});',
'    try {',
'        return JSON.parse(actions);',
'    } catch (error) {',
'        return [];',
'    }',
''))
,p_attribute_13=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    await apex.server.process(''Persist'', {',
'        x01: JSON.stringify(action)',
'    }, {dataType: ''text''});',
''))
,p_attribute_14=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152332973200147568)
,p_plug_name=>'Details'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653444443787746457)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The state saving is done by making use of the scripts passed via the two attributes <b>FetchActions</b> ',
'and <b>Persist</b> (Settings > Fetch Actions, Persist in APEX). The data during save is persisted in the GRAPH_ACTION database table.',
'<br><br><strong>Fetch Actions:</strong><br>',
'<code>',
' const actions = await apex.server.process(''Fetch'',null, {dataType: ''text''});',
'    try {',
'        return JSON.parse(actions)',
'    } catch (error) {',
'        return [];',
'    }',
'',
'</code>',
'<br><strong>Persist:</strong><br>',
'<code>',
'    await apex.server.process(''Persist'', {',
'        x01: JSON.stringify(action)',
'    }, {dataType: ''text''});',
'',
'</code>',
'<br>',
'Please note that :page_start and :page_size bind parameters when added to the query, needs the GVT plugin instance''s Attributes > ''SQL Query supports Pagination'' property to be turned on in APEX.<br><br>',
'<br><strong>Query:</strong><br>',
'<code>/*  In the below query, data is selected from database tables and ',
'    made into JSON format that GVT accepts.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the reporting structure of employees to their managers.*/',
'    ',
'WITH query as (',
'    -- source and target constitutes the edge direction and thus',
'    -- represents the reporting structure of employee to their managers.',
'    SELECT',
'        EMPLOYEE_ID as source,',
'        MANAGER_ID as target',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        MANAGER_ID IS NOT NULL',
'),',
'page AS (',
'    -- pagination',
'    SELECT',
'        *',
'    FROM',
'        query',
'    ORDER BY',
'        source,',
'        target OFFSET :page_start ROWS FETCH NEXT :page_size ROWS ONLY',
'),',
'vertices AS (',
'    -- fetch employee details and construct JSON',
'    SELECT',
'        JSON_OBJECT(',
'            ''id'' VALUE employees.EMPLOYEE_ID,',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE employees.FIRST_NAME,',
'                ''LastName'' VALUE employees.LAST_NAME,',
'                ''Salary'' VALUE employees.SALARY,',
'                ''Department'' VALUE employees.DEPARTMENT_ID,',
'                ''HireDate'' VALUE employees.HIRE_DATE,',
'                ''JobId'' VALUE jobs.JOB_ID,',
'                ''JobTitle'' VALUE jobs.JOB_TITLE,',
'                ''Country'' VALUE locations.COUNTRY_ID',
'            )',
'        ) AS vertex',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES employees',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_JOBS jobs ON employees.JOB_ID = jobs.JOB_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_DEPARTMENTS departments ON employees.DEPARTMENT_ID = departments.DEPARTMENT_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_LOCATIONS locations ON departments.LOCATION_ID = locations.LOCATION_ID',
'    WHERE',
'        employees.EMPLOYEE_ID in (',
'            SELECT',
'                source',
'            from',
'                page',
'        )',
'        or employees.EMPLOYEE_ID in (',
'            SELECT',
'                target',
'            from',
'                page',
'        )',
'),',
'edges AS (',
'    -- source (employee) and target (manager) constitutes the directed edge',
'    SELECT',
'        JSON_OBJECT(''source'' VALUE source, ''target'' VALUE target) AS edge',
'    FROM',
'        page',
')',
'SELECT',
'    -- construct the final JSON that GVT accepts.',
'    JSON_OBJECT(',
'        ''vertices'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(vertex returning clob)',
'            FROM',
'                vertices',
'        ),',
'        ''edges'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(edge returning clob)',
'            FROM',
'                edges',
'        ),',
'        ''numResults'' VALUE (',
'            SELECT',
'                COUNT(*)',
'            FROM',
'                query',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL',
'</code>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9096435804439987499)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Persist'
,p_process_sql_clob=>'INSERT INTO EBA_GRAPHVIZ_GRAPH_ACTION(ACTION, USER_ID) VALUES(apex_application.g_x01, v(''APP_USER''));'
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'error occured during persist'
,p_internal_uid=>4265959710424168963
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9096436225274987502)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fetch'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    data clob;',
'BEGIN',
'    SELECT JSON_ARRAYAGG(action FORMAT JSON ORDER BY ID ASC returning clob) INTO data FROM EBA_GRAPHVIZ_GRAPH_ACTION WHERE USER_ID = v(''APP_USER'');',
'    htp.p(data);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>4265960131259168966
);
wwv_flow_imp.component_end;
end;
/
