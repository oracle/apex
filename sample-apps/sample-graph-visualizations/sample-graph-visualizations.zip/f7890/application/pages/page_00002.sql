prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>857863501405308376
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Basic Graph'
,p_alias=>'BASICGRAPH'
,p_step_title=>'Basic Graph - &APP_NAME.'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'KORBI.SCHMID@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20230602215837'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8248163203267721060)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>wwv_flow_imp.id(12653420510670746425)
,p_plug_display_sequence=>10
,p_plug_source=>'In this page we see examples of graphs constructed from plain JSON and also from database tables. <p>Below are some ways by which you can interact with the graph: <ul><li>Click on the graph''s vertices to select them individually. </li><li>Draw select'
||'ion around vertices to perform multi-select.</li><li>Click and drag vertices to move them within the graph.</li><li>Right click a vertex to see more details.</li></ul>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9589883567545450528)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12653492835355746496)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(12653389315424746351)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(12653555117577746591)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152332426037147563)
,p_plug_name=>'Graph from JSON'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(12653453941494746464)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'In the below example, data is embedded directly in the JSON (without involving data sources like tables) and passed in a format that Graph Visualization Toolkit (GVT) plugin accepts, i.e., as vertices, edges, etc.<br><br>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152330402014147543)
,p_plug_name=>'JSON Details'
,p_region_name=>'json-details'
,p_parent_plug_id=>wwv_flow_imp.id(24152332426037147563)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653444443787746457)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>JSON based Query:</strong>',
'<br>',
'',
'<code>/* In the below query, data is constructed as plain JSON in a ',
'format that the GVT component accepts */',
'',
'SELECT',
'    JSON_OBJECT(',
'        -- vertices of the graph passed as JSON array',
'        ''vertices'' VALUE JSON_ARRAY(',
'            JSON_OBJECT(',
'            ''id'' VALUE ''1'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''Steven'',',
'                ''LastName'' VALUE ''Markle'',',
'                ''Salary'' VALUE ''2200'',',
'                ''Department'' VALUE ''50'',',
'                ''HireDate'' VALUE ''2021-07-03T00:00:00'',',
'                ''JobId'' VALUE ''ST_CLERK'',',
'                ''JobTitle'' VALUE ''Stock Clerk'',',
'                ''Country'' VALUE ''US''',
'                )',
'            ),',
'            JSON_OBJECT(',
'            ''id'' VALUE ''2'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''Matthew'',',
'                ''LastName'' VALUE ''Weiss'',',
'                ''Salary'' VALUE ''8000'',',
'                ''Department'' VALUE ''50'',',
'                ''HireDate'' VALUE ''2017-11-12T00:00:00'',',
'                ''JobId'' VALUE ''ST_MAN'',',
'                ''JobTitle'' VALUE ''Stock Manager'',',
'                ''Country'' VALUE ''US''',
'                )',
'            ),',
'            JSON_OBJECT(',
'            ''id'' VALUE ''3'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''Irene'',',
'                ''LastName'' VALUE ''Mikkilineni'',',
'                ''Salary'' VALUE ''2700'',',
'                ''Department'' VALUE ''50'',',
'                ''HireDate'' VALUE ''2020-01-23T00:00:00'',',
'                ''JobId'' VALUE ''ST_CLERK'',',
'                ''JobTitle'' VALUE ''Stock Clerk'',',
'                ''Country'' VALUE ''US''',
'                )',
'            ),',
'            JSON_OBJECT(',
'            ''id'' VALUE ''4'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''James'',',
'                ''LastName'' VALUE ''Landry'',',
'                ''Salary'' VALUE ''2400'',',
'                ''Department'' VALUE ''50'',',
'                ''HireDate'' VALUE ''2020-05-10T00:00:00'',',
'                ''JobId'' VALUE ''ST_CLERK'',',
'                ''JobTitle'' VALUE ''Stock Clerk'',',
'                ''Country'' VALUE ''US''',
'                )',
'            ),',
'            JSON_OBJECT(',
'            ''id'' VALUE ''5'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''Julia'',',
'                ''LastName'' VALUE ''Nayer'',',
'                ''Salary'' VALUE ''3200'',',
'                ''Department'' VALUE ''50'',',
'                ''HireDate'' VALUE ''2018-11-10T00:00:00'',',
'                ''JobId'' VALUE ''ST_CLERK'',',
'                ''JobTitle'' VALUE ''Stock Clerk'',',
'                ''Country'' VALUE ''US''',
'                )',
'            ),',
'            JSON_OBJECT(',
'            ''id'' VALUE ''6'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''Lex'',',
'                ''LastName'' VALUE ''De Haan'',',
'                ''Salary'' VALUE ''17000'',',
'                ''Department'' VALUE ''90'',',
'                ''HireDate'' VALUE ''2018-11-10T00:00:00'',',
'                ''JobId'' VALUE ''AD_VP'',',
'                ''JobTitle'' VALUE ''Administration Vice President'',',
'                ''Country'' VALUE ''US''',
'                )',
'            ),',
'            JSON_OBJECT(',
'            ''id'' VALUE ''7'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''Alexander'',',
'                ''LastName'' VALUE ''Hunold'',',
'                ''Salary'' VALUE ''9000'',',
'                ''Department'' VALUE ''60'',',
'                ''HireDate'' VALUE ''2018-11-10T00:00:00'',',
'                ''JobId'' VALUE ''IT_PROG'',',
'                ''JobTitle'' VALUE ''Programmer'',',
'                ''Country'' VALUE ''US''',
'                )',
'            ),',
'            JSON_OBJECT(',
'            ''id'' VALUE ''8'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''Nancy'',',
'                ''LastName'' VALUE ''Greenberg'',',
'                ''Salary'' VALUE ''12000'',',
'                ''Department'' VALUE ''100'',',
'                ''HireDate'' VALUE ''2018-11-10T00:00:00'',',
'                ''JobId'' VALUE ''FI_MGR'',',
'                ''JobTitle'' VALUE ''Finance Manager'',',
'                ''Country'' VALUE ''US''',
'                )',
'            )',
'        ),',
'        -- edges of the graph passed as JSON array',
'        ''edges'' VALUE JSON_ARRAY(',
'            JSON_OBJECT(',
'                ''id'' VALUE ''1'',',
'                ''source'' VALUE ''1'', ',
'                ''target''  VALUE ''2''',
'            ),',
'            JSON_OBJECT(',
'                ''id'' VALUE ''2'',',
'                ''source'' VALUE ''2'', ',
'                ''target''  VALUE ''3''',
'            ),',
'            JSON_OBJECT(',
'                ''id'' VALUE ''2'',',
'                ''source'' VALUE ''2'', ',
'                ''target''  VALUE ''4''',
'            ),',
'            JSON_OBJECT(',
'                ''id'' VALUE ''2'',',
'                ''source'' VALUE ''2'', ',
'                ''target''  VALUE ''5''',
'            )',
'        ),',
'        ''numResults'' VALUE (',
'            5',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL ',
'</code>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152331675542147555)
,p_plug_name=>'Graph from JSON'
,p_parent_plug_id=>wwv_flow_imp.id(24152332426037147563)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:i-h640:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653480208122746486)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* In the below query, data is constructed as plain JSON in a ',
'format that the GVT component accepts */',
'',
'SELECT',
'    JSON_OBJECT(',
'        -- vertices of the graph passed as JSON array',
'        ''vertices'' VALUE JSON_ARRAY(',
'            JSON_OBJECT(',
'            ''id'' VALUE ''v1'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''Steven'',',
'                ''LastName'' VALUE ''Markle'',',
'                ''Salary'' VALUE ''2200'',',
'                ''Department'' VALUE ''50'',',
'                ''HireDate'' VALUE ''2021-07-03T00:00:00'',',
'                ''JobId'' VALUE ''ST_CLERK'',',
'                ''JobTitle'' VALUE ''Stock Clerk'',',
'                ''Country'' VALUE ''US''',
'                )',
'            ),',
'            JSON_OBJECT(',
'            ''id'' VALUE ''v2'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''Matthew'',',
'                ''LastName'' VALUE ''Weiss'',',
'                ''Salary'' VALUE ''8000'',',
'                ''Department'' VALUE ''50'',',
'                ''HireDate'' VALUE ''2017-11-12T00:00:00'',',
'                ''JobId'' VALUE ''ST_MAN'',',
'                ''JobTitle'' VALUE ''Stock Manager'',',
'                ''Country'' VALUE ''US''',
'                )',
'            ),',
'            JSON_OBJECT(',
'            ''id'' VALUE ''v3'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''Irene'',',
'                ''LastName'' VALUE ''Mikkilineni'',',
'                ''Salary'' VALUE ''2700'',',
'                ''Department'' VALUE ''50'',',
'                ''HireDate'' VALUE ''2020-01-23T00:00:00'',',
'                ''JobId'' VALUE ''ST_CLERK'',',
'                ''JobTitle'' VALUE ''Stock Clerk'',',
'                ''Country'' VALUE ''US''',
'                )',
'            ),',
'            JSON_OBJECT(',
'            ''id'' VALUE ''v4'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''James'',',
'                ''LastName'' VALUE ''Landry'',',
'                ''Salary'' VALUE ''2400'',',
'                ''Department'' VALUE ''50'',',
'                ''HireDate'' VALUE ''2020-05-10T00:00:00'',',
'                ''JobId'' VALUE ''ST_CLERK'',',
'                ''JobTitle'' VALUE ''Stock Clerk'',',
'                ''Country'' VALUE ''US''',
'                )',
'            ),',
'            JSON_OBJECT(',
'            ''id'' VALUE ''v5'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''Julia'',',
'                ''LastName'' VALUE ''Nayer'',',
'                ''Salary'' VALUE ''3200'',',
'                ''Department'' VALUE ''50'',',
'                ''HireDate'' VALUE ''2018-11-10T00:00:00'',',
'                ''JobId'' VALUE ''ST_CLERK'',',
'                ''JobTitle'' VALUE ''Stock Clerk'',',
'                ''Country'' VALUE ''US''',
'                )',
'            ),',
'            JSON_OBJECT(',
'            ''id'' VALUE ''v6'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''Lex'',',
'                ''LastName'' VALUE ''De Haan'',',
'                ''Salary'' VALUE ''17000'',',
'                ''Department'' VALUE ''90'',',
'                ''HireDate'' VALUE ''2018-11-10T00:00:00'',',
'                ''JobId'' VALUE ''AD_VP'',',
'                ''JobTitle'' VALUE ''Administration Vice President'',',
'                ''Country'' VALUE ''US''',
'                )',
'            ),',
'            JSON_OBJECT(',
'            ''id'' VALUE ''v7'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''Alexander'',',
'                ''LastName'' VALUE ''Hunold'',',
'                ''Salary'' VALUE ''9000'',',
'                ''Department'' VALUE ''60'',',
'                ''HireDate'' VALUE ''2018-11-10T00:00:00'',',
'                ''JobId'' VALUE ''IT_PROG'',',
'                ''JobTitle'' VALUE ''Programmer'',',
'                ''Country'' VALUE ''US''',
'                )',
'            ),',
'            JSON_OBJECT(',
'            ''id'' VALUE ''v8'',',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE ''Nancy'',',
'                ''LastName'' VALUE ''Greenberg'',',
'                ''Salary'' VALUE ''12000'',',
'                ''Department'' VALUE ''100'',',
'                ''HireDate'' VALUE ''2018-11-10T00:00:00'',',
'                ''JobId'' VALUE ''FI_MGR'',',
'                ''JobTitle'' VALUE ''Finance Manager'',',
'                ''Country'' VALUE ''US''',
'                )',
'            )',
'        ),',
'        -- edges of the graph passed as JSON array',
'        ''edges'' VALUE JSON_ARRAY(',
'            JSON_OBJECT(',
'                ''id'' VALUE ''e1'',',
'                ''source'' VALUE ''v1'', ',
'                ''target''  VALUE ''v2''',
'            ),',
'            JSON_OBJECT(',
'                ''id'' VALUE ''e2'',',
'                ''source'' VALUE ''v2'', ',
'                ''target''  VALUE ''v3''',
'            ),',
'            JSON_OBJECT(',
'                ''id'' VALUE ''e3'',',
'                ''source'' VALUE ''v2'', ',
'                ''target''  VALUE ''v4''',
'            ),',
'            JSON_OBJECT(',
'                ''id'' VALUE ''e4'',',
'                ''source'' VALUE ''v2'', ',
'                ''target''  VALUE ''v5''',
'            )',
'        ),',
'        ''numResults'' VALUE (',
'            5',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL '))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attribute_05=>'N'
,p_attribute_07=>'FirstName'
,p_attribute_10=>'modes:exploration'
,p_attribute_14=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152332496281147564)
,p_plug_name=>'Graph from Database Tables'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_imp.id(12653453941494746464)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'In the below example, data is selected from database tables and is made into JSON format that the Graph Visualization Toolkit (GVT) plugin accepts, i.e., as vertices, edges, etc.<br><br>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17414024338970226889)
,p_plug_name=>'Graph from tables'
,p_parent_plug_id=>wwv_flow_imp.id(24152332496281147564)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:i-h640:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653480208122746486)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*  In the below query, data is selected from database tables and ',
'    made into JSON format that GVT accepts.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the reporting structure of employees to their managers.*/',
'    ',
'WITH query as (',
'    -- source and target constitutes the edge direction and thus',
'    -- represents the reporting structure of employee to their managers.',
'    SELECT',
'        EMPLOYEE_ID as source,',
'        MANAGER_ID as target',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        MANAGER_ID IS NOT NULL',
'),',
'page AS (',
'    -- pagination',
'    SELECT',
'        *',
'    FROM',
'        query',
'    ORDER BY',
'        source,',
'        target OFFSET :page_start ROWS FETCH NEXT :page_size ROWS ONLY',
'),',
'vertices AS (',
'    -- fetch employee details and construct JSON',
'    SELECT',
'        JSON_OBJECT(',
'            ''id'' VALUE employees.EMPLOYEE_ID,',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE employees.FIRST_NAME,',
'                ''LastName'' VALUE employees.LAST_NAME,',
'                ''Salary'' VALUE employees.SALARY,',
'                ''Department'' VALUE employees.DEPARTMENT_ID,',
'                ''HireDate'' VALUE employees.HIRE_DATE,',
'                ''JobId'' VALUE jobs.JOB_ID,',
'                ''JobTitle'' VALUE jobs.JOB_TITLE,',
'                ''Country'' VALUE locations.COUNTRY_ID',
'            )',
'        ) AS vertex',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES employees',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_JOBS jobs ON employees.JOB_ID = jobs.JOB_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_DEPARTMENTS departments ON employees.DEPARTMENT_ID = departments.DEPARTMENT_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_LOCATIONS locations ON departments.LOCATION_ID = locations.LOCATION_ID',
'    WHERE',
'        employees.EMPLOYEE_ID in (',
'            SELECT',
'                source',
'            from',
'                page',
'        )',
'        or employees.EMPLOYEE_ID in (',
'            SELECT',
'                target',
'            from',
'                page',
'        )',
'),',
'edges AS (',
'    -- source (employee) and target (manager) constitutes the directed edge',
'    SELECT',
'        JSON_OBJECT(''source'' VALUE source, ''target'' VALUE target) AS edge',
'    FROM',
'        page',
')',
'SELECT',
'    -- construct the final JSON that GVT accepts.',
'    JSON_OBJECT(',
'        ''vertices'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(vertex returning clob)',
'            FROM',
'                vertices',
'        ),',
'        ''edges'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(edge returning clob)',
'            FROM',
'                edges',
'        ),',
'        ''numResults'' VALUE (',
'            SELECT',
'                COUNT(*)',
'            FROM',
'                query',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attribute_05=>'N'
,p_attribute_07=>'FirstName'
,p_attribute_10=>'modes:exploration'
,p_attribute_14=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24152331971802147558)
,p_plug_name=>'Table Query Details'
,p_region_name=>'dbt-details'
,p_parent_plug_id=>wwv_flow_imp.id(24152332496281147564)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653444443787746457)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Please note that :page_start and :page_size bind parameters when added to the query, needs the GVT plugin instance''s Attributes > ''SQL Query supports Pagination'' property to be turned on in APEX.<br><br>',
'',
'<strong>Table based Query:</strong>',
'<br>',
'<code>/*  In the below query, data is selected from database tables and ',
'    made into JSON format that GVT accepts.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the reporting structure of employees to their managers.*/',
'    ',
'WITH query as (',
'    -- source and target constitutes the edge direction and thus',
'    -- represents the reporting structure of employee to their managers.',
'    SELECT',
'        EMPLOYEE_ID as source,',
'        MANAGER_ID as target',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES',
'    WHERE',
'        MANAGER_ID IS NOT NULL',
'),',
'page AS (',
'    -- pagination',
'    SELECT',
'        *',
'    FROM',
'        query',
'    ORDER BY',
'        source,',
'        target OFFSET :page_start ROWS FETCH NEXT :page_size ROWS ONLY',
'),',
'vertices AS (',
'    -- fetch employee details and construct JSON',
'    SELECT',
'        JSON_OBJECT(',
'            ''id'' VALUE employees.EMPLOYEE_ID,',
'            ''properties'' VALUE JSON_OBJECT(',
'                ''FirstName'' VALUE employees.FIRST_NAME,',
'                ''LastName'' VALUE employees.LAST_NAME,',
'                ''Salary'' VALUE employees.SALARY,',
'                ''Department'' VALUE employees.DEPARTMENT_ID,',
'                ''HireDate'' VALUE employees.HIRE_DATE,',
'                ''JobId'' VALUE jobs.JOB_ID,',
'                ''JobTitle'' VALUE jobs.JOB_TITLE,',
'                ''Country'' VALUE locations.COUNTRY_ID',
'            )',
'        ) AS vertex',
'    FROM',
'        EBA_GRAPHVIZ_EMPLOYEES employees',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_JOBS jobs ON employees.JOB_ID = jobs.JOB_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_DEPARTMENTS departments ON employees.DEPARTMENT_ID = departments.DEPARTMENT_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_LOCATIONS locations ON departments.LOCATION_ID = locations.LOCATION_ID',
'    WHERE',
'        employees.EMPLOYEE_ID in (',
'            SELECT',
'                source',
'            from',
'                page',
'        )',
'        or employees.EMPLOYEE_ID in (',
'            SELECT',
'                target',
'            from',
'                page',
'        )',
'),',
'edges AS (',
'    -- source (employee) and target (manager) constitutes the directed edge',
'    SELECT',
'        JSON_OBJECT(''source'' VALUE source, ''target'' VALUE target) AS edge',
'    FROM',
'        page',
')',
'SELECT',
'    -- construct the final JSON that GVT accepts.',
'    JSON_OBJECT(',
'        ''vertices'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(vertex returning clob)',
'            FROM',
'                vertices',
'        ),',
'        ''edges'' VALUE (',
'            SELECT',
'                JSON_ARRAYAGG(edge returning clob)',
'            FROM',
'                edges',
'        ),',
'        ''numResults'' VALUE (',
'            SELECT',
'                COUNT(*)',
'            FROM',
'                query',
'        ) returning clob',
'    ) json',
'FROM',
'    SYS.DUAL',
'</code>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30292837028130546684)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12653427163797746442)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'USER'
,p_attribute_04=>'N'
);
wwv_flow_imp.component_end;
end;
/
