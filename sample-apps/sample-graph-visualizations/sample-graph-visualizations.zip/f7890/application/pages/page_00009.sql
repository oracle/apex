prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>857863501405308376
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'ORA_SQLGRAPH_TO_JSON Query'
,p_alias=>'ORA_SQLGRAPH_TO_JSON'
,p_step_title=>'ORA_SQLGRAPH_TO_JSON - &APP_NAME.'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(6969891954399591183)
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'KORBI.SCHMID@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20230602215837'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33305228824297491943)
,p_plug_name=>'Use ORA_SQLGRAPH_TO_JSON function instead of plain SQL'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653480208122746486)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ORA_SQLGRAPHL_TO_JSON accepts CURSOR as input. Here is an example helper function you can use which takes a SQL/PGQ query as VARCHAR2, converts it into a cursor and passes it into the ORA_SQLGRAPH_TO_JSON function.<br>',
'<code>CREATE OR REPLACE FUNCTION CUST_SQLGRAPH_JSON (',
'  QUERY VARCHAR2',
') RETURN CLOB',
'  AUTHID CURRENT_USER IS',
'  INCUR    SYS_REFCURSOR;',
'  L_CUR    NUMBER;',
'  RETVALUE CLOB;',
'BEGIN',
'  OPEN INCUR FOR QUERY;',
'  L_CUR := DBMS_SQL.TO_CURSOR_NUMBER(INCUR);',
'  RETVALUE := ORA_SQLGRAPH_TO_JSON(L_CUR);',
'  DBMS_SQL.CLOSE_CURSOR(L_CUR);',
'  RETURN RETVALUE;',
'END;',
'</code>',
'Here is an example of using the helper function. <br>',
'<code>SELECT CUST_SQLGRAPH_JSON(''SELECT employee, e, manager',
'    FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'    MATCH (worker is employee) -[w is works_for]-> (boss is employee)',
'    COLUMNS (vertex_id(worker) AS employee, edge_id(w) AS e, vertex_id(boss) AS manager )',
')'') as result_column FROM DUAL;',
'</code>',
'The function will return the result in the JSON format the APEX plugin uses to visualize graphs. See the sample app for an example how plugin and function can be used together.',
'',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33305228923594491944)
,p_plug_name=>'Graph Using ORA_SQLGRAPH_TO_JSON Function'
,p_parent_plug_id=>wwv_flow_imp.id(33305228824297491943)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653480208122746486)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'SELECT CUST_SQLGRAPH_JSON(''SELECT employee, e, manager',
'    FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'    MATCH (worker is employee) -[w is works_for]-> (boss is employee)',
'    COLUMNS (vertex_id(worker) AS employee, edge_id(w) AS e, vertex_id(boss) AS manager )',
')'') as result_column FROM DUAL;',
'*/',
'select * from eba_graphviz_countries;'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attribute_02=>'{}'
,p_attribute_03=>'{}'
,p_attribute_05=>'N'
,p_attribute_10=>'modes:exploration'
,p_attribute_14=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33305229049682491945)
,p_plug_name=>'Details'
,p_parent_plug_id=>wwv_flow_imp.id(33305228824297491943)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12653480208122746486)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Query:</strong>',
'<br>',
'',
'<code>/* In the below query, query is put in GRAPH_QUERY_TO_JSON function and it will return the result in a ',
'format that the GVT component accepts */',
'',
'SELECT CUST_SQLGRAPH_JSON(''SELECT employee, e, manager',
'    FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'    MATCH (worker is employee) -[w is works_for]-> (boss is employee)',
'    COLUMNS (vertex_id(worker) AS employee, edge_id(w) AS e, vertex_id(boss) AS manager )',
')'') as result_column FROM DUAL',
'</code>',
'The function will return the result in the JSON format the APEX plugin uses to visualize graphs. See the sample app for an example how plugin and function can be used together.',
'<br>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33305229148326491946)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12653492835355746496)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(12653389315424746351)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(12653555117577746591)
);
wwv_flow_imp.component_end;
end;
/
