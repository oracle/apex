prompt --application/shared_components/user_interface/lovs/session_types
begin
--   Manifest
--     SESSION_TYPES
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(778365973370454349)
,p_lov_name=>'SESSION_TYPES'
,p_lov_query=>'.'||wwv_flow_api.id(778365973370454349)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(778366336881454349)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Business'
,p_lov_return_value=>'BUSINESS'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(778366676246454351)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Technical'
,p_lov_return_value=>'TECHNICAL'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(778367088587454351)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'General Session'
,p_lov_return_value=>'GENERAL'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(778367547441454351)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Break'
,p_lov_return_value=>'BREAK'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(778367929689454352)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Hands On Session'
,p_lov_return_value=>'Hands On'
);
wwv_flow_api.component_end;
end;
/
