prompt --application/shared_components/user_interface/lovs/valid_status_codes
begin
--   Manifest
--     VALID STATUS CODES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>4421054519883540
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2661056819897279509)
,p_lov_name=>'VALID STATUS CODES'
,p_lov_query=>'.'||wwv_flow_imp.id(2661056819897279509)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089078457
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(2661057027642279512)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Closed'
,p_lov_return_value=>'Closed'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(2661057212353279520)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'On-Hold'
,p_lov_return_value=>'On-Hold'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(2661057407916279520)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Open'
,p_lov_return_value=>'Open'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(2661057617620279520)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Pending'
,p_lov_return_value=>'Pending'
);
wwv_flow_imp.component_end;
end;
/
