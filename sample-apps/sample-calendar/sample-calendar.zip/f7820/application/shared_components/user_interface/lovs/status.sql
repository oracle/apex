prompt --application/shared_components/user_interface/lovs/status
begin
--   Manifest
--     STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>4421054519883540
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(332761733338626435)
,p_lov_name=>'STATUS'
,p_lov_query=>'.'||wwv_flow_imp.id(332761733338626435)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089078457
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(332761967048626436)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Active'
,p_lov_return_value=>'ACTIVE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(332762452009626436)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Inactive'
,p_lov_return_value=>'INACTIVE'
);
wwv_flow_imp.component_end;
end;
/
