prompt --application/shared_components/navigation/tabs/parent
begin
--   Manifest
--     TOP LEVEL TABS: 7820
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_toplevel_tab(
 p_id=>wwv_flow_api.id(3165482748569719879)
,p_tab_set=>'TS1'
,p_tab_sequence=>10
,p_tab_name=>'T_ADMINISTRATION'
,p_tab_text=>'TS1'
,p_tab_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_current_on_tabset=>'TS1'
);
wwv_flow_api.component_end;
end;
/
