prompt --application/shared_components/navigation/lists/date_picker
begin
--   Manifest
--     LIST: Date Picker
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(638586443475857952)
,p_name=>'Date Picker'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(638586641449857952)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Display Modes'
,p_list_item_link_target=>'f?p=&APP_ID.:510:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-clock'
,p_list_text_01=>'This page shows the different display modes of the Date Picker.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(638587078218857953)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Advanced Attributes'
,p_list_item_link_target=>'f?p=&APP_ID.:520:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-accordion'
,p_list_text_01=>'This page shows date pickers with different attribute settings.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(638587418424857953)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Min/Max'
,p_list_item_link_target=>'f?p=&APP_ID.:530:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-fit-to-width'
,p_list_text_01=>'This page reviews how to use the min/max attributes of the Date Picker'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(638587899174857953)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Day Formatting (Plug-in)'
,p_list_item_link_target=>'f?p=&APP_ID.:540:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plug'
,p_list_text_01=>'This page reviews how to use the day formatter plug-in or how to use this API in JavaScript.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
