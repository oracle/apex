prompt --application/shared_components/navigation/lists/calendars_and_javascript
begin
--   Manifest
--     LIST: Calendars and Javascript
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>9797958909058847
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(792136833765057608)
,p_name=>'Calendars and Javascript'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089078457
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(792137040684057609)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Custom Navigation'
,p_list_item_link_target=>'f?p=&APP_ID.:71:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-user'
,p_list_text_01=>'Use APEX components like buttons or page items to navigate within your Calendar.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(792137480817057610)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Query Calendar Status'
,p_list_item_link_target=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-search'
,p_list_text_01=>'This page shows how to get the current calendar status with the FullCalendar JavaScript API.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(792137851111057610)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Calendar Client Events'
,p_list_item_link_target=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-plus-o'
,p_list_text_01=>'Add "client-only" events" to your calendar view with JavaScript. Edit them and when ready, save to the database.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(796235462519286547)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Schedule Builder'
,p_list_item_link_target=>'f?p=&APP_ID.:74:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-apex'
,p_list_text_01=>'Explore how to create a <i>Schedule Builder</i> with Application Express'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
