prompt --application/shared_components/navigation/lists/calendars_and_dynamic_actions
begin
--   Manifest
--     LIST: Calendars and Dynamic Actions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>4421054519883540
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(792131669906999604)
,p_name=>'Calendars and Dynamic Actions'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089078457
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(792131878283999605)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Calendar with Report'
,p_list_item_link_target=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>'This page contains a classic report region which is always in sync with the Calendar view, i.e. shows only data which is also visible on the calendar.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(792132282140999605)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Create Calendar Events'
,p_list_item_link_target=>'f?p=&APP_ID.:52:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-plus-o'
,p_list_text_01=>'Select a date range in the calendar and have a new event being created in the database immediately.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(792132655887999605)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Delete Events By Click'
,p_list_item_link_target=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-times-o'
,p_list_text_01=>'Delete a calendar event in the database by simply clicking it in the Calendar.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(792167498918368405)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Copy Events by Click'
,p_list_item_link_target=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-files-o'
,p_list_text_01=>'This page shows, how existing calendar events can be copied with a simple mouse click.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(980697952865461060)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Custom Drag and Drop Handlers'
,p_list_item_link_target=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-pointer'
,p_list_text_01=>'Explore how to capture drag and drop events with dynamic actions.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
