prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(8193437692093634486)
,p_name=>' Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(609176268274557545)
,p_parent_id=>wwv_flow_imp.id(782332865453920686)
,p_short_name=>'Faceted Search: Projects'
,p_link=>'f?p=&APP_ID.:36:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>36
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(638541390237805087)
,p_short_name=>'Date Picker'
,p_link=>'f?p=&APP_ID.:500:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(638546825291825763)
,p_parent_id=>wwv_flow_imp.id(638541390237805087)
,p_short_name=>'Display Modes'
,p_link=>'f?p=&APP_ID.:510:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>510
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(684226381558914506)
,p_parent_id=>wwv_flow_imp.id(638541390237805087)
,p_short_name=>'Day Formatting (Plug-in)'
,p_link=>'f?p=&APP_ID.:540:&SESSION.::&DEBUG.:::'
,p_page_id=>540
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782311361429670088)
,p_parent_id=>wwv_flow_imp.id(782332865453920686)
,p_short_name=>'Monthly Calendar: Projects'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782311598003681933)
,p_parent_id=>wwv_flow_imp.id(782332865453920686)
,p_short_name=>'Weekly Calendar: Conference'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782311799341683976)
,p_parent_id=>wwv_flow_imp.id(782332865453920686)
,p_short_name=>'Weekly Calendar: Edit Sessions'
,p_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
,p_page_id=>33
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782312006081685680)
,p_parent_id=>wwv_flow_imp.id(782332865453920686)
,p_short_name=>'Weekly Calendar: Drag & Drop'
,p_link=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:::'
,p_page_id=>34
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782312184585686845)
,p_parent_id=>wwv_flow_imp.id(782332865453920686)
,p_short_name=>'Weekly Calendar: Time Format'
,p_link=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:::'
,p_page_id=>35
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782312436430690698)
,p_parent_id=>wwv_flow_imp.id(782337913531983814)
,p_short_name=>'Calendar and Report'
,p_link=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:::'
,p_page_id=>51
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782312606577692460)
,p_parent_id=>wwv_flow_imp.id(782337913531983814)
,p_short_name=>'Create Calendar Events'
,p_link=>'f?p=&APP_ID.:52:&SESSION.::&DEBUG.:::'
,p_page_id=>52
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782312832514694625)
,p_parent_id=>wwv_flow_imp.id(782337913531983814)
,p_short_name=>'Delete Events By Click'
,p_link=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.:::'
,p_page_id=>53
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782313030650696948)
,p_parent_id=>wwv_flow_imp.id(782344054552034415)
,p_short_name=>'Custom Navigation'
,p_link=>'f?p=&APP_ID.:71:&SESSION.::&DEBUG.:::'
,p_page_id=>71
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782313185827699148)
,p_parent_id=>wwv_flow_imp.id(782344054552034415)
,p_short_name=>'Query Calendar Status'
,p_link=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.:::'
,p_page_id=>72
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782313451563700270)
,p_parent_id=>wwv_flow_imp.id(782344054552034415)
,p_short_name=>'Calendar Client Events'
,p_link=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:::'
,p_page_id=>73
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782313579966702608)
,p_parent_id=>wwv_flow_imp.id(782348078688066492)
,p_short_name=>'Custom CSS Classes'
,p_link=>'f?p=&APP_ID.:91:&SESSION.::&DEBUG.:::'
,p_page_id=>91
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782313819609704284)
,p_parent_id=>wwv_flow_imp.id(782348078688066492)
,p_short_name=>'Custom Event Icons'
,p_link=>'f?p=&APP_ID.:92:&SESSION.::&DEBUG.:::'
,p_page_id=>92
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782332865453920686)
,p_parent_id=>0
,p_short_name=>'Standard Calendars'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782337913531983814)
,p_parent_id=>0
,p_short_name=>'Dynamic Action Examples'
,p_link=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:::'
,p_page_id=>50
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782344054552034415)
,p_parent_id=>0
,p_short_name=>'Calendars and Javascript'
,p_link=>'f?p=&APP_ID.:70:&SESSION.::&DEBUG.:::'
,p_page_id=>70
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782348078688066492)
,p_parent_id=>0
,p_short_name=>'Calendar Styling'
,p_link=>'f?p=&APP_ID.:90:&SESSION.::&DEBUG.:::'
,p_page_id=>90
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(782369174156301734)
,p_parent_id=>wwv_flow_imp.id(782337913531983814)
,p_short_name=>'Copy Events By Click'
,p_link=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.:::'
,p_page_id=>54
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(817522944206630502)
,p_parent_id=>wwv_flow_imp.id(782337913531983814)
,p_short_name=>'Custom Drag and Drop Handlers'
,p_link=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:::'
,p_page_id=>112
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(840122432493272070)
,p_parent_id=>0
,p_short_name=>'Custom Calendar Initialization'
,p_link=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:::'
,p_page_id=>110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(840122665638275335)
,p_parent_id=>wwv_flow_imp.id(840122432493272070)
,p_short_name=>'Custom weekly schedule'
,p_link=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:::'
,p_page_id=>111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(885213270790374087)
,p_parent_id=>wwv_flow_imp.id(782344054552034415)
,p_short_name=>'Schedule Builder'
,p_link=>'f?p=&FLOW_ID.:74:&SESSION.'
,p_page_id=>74
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1303240276334355603)
,p_short_name=>'Mini Calendar'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1303240949497355607)
,p_parent_id=>wwv_flow_imp.id(1303240276334355603)
,p_short_name=>'&P14_PROJECT.'
,p_link=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:::'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1862082105698112763)
,p_parent_id=>wwv_flow_imp.id(1862563588638597012)
,p_short_name=>'Application Theme Style'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1862563588638597012)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:15:&SESSION.'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2570386476906598398)
,p_short_name=>'Calendar Entry'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2570795153438681939)
,p_short_name=>'Time Line'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2583518155994520739)
,p_parent_id=>wwv_flow_imp.id(1862563588638597012)
,p_short_name=>'Manage Sample Data'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2585129857687740659)
,p_parent_id=>wwv_flow_imp.id(2583518155994520739)
,p_short_name=>'Report'
,p_link=>'f?p=&APP_ID.:7:&SESSION.'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2650854250621157679)
,p_short_name=>'Project Due Dates'
,p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2650854580297157680)
,p_parent_id=>wwv_flow_imp.id(2650854250621157679)
,p_short_name=>'Project Detail'
,p_link=>'f?p=&FLOW_ID.:10:&SESSION.'
,p_page_id=>10
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3240307067832668303)
,p_short_name=>'Help'
,p_link=>'f?p=&FLOW_ID.:12:&SESSION.'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8193438103941634489)
,p_parent_id=>0
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp.component_end;
end;
/
