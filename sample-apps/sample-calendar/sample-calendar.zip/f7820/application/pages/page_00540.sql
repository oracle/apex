prompt --application/pages/page_00540
begin
--   Manifest
--     PAGE: 00540
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>540
,p_name=>'Day Formatting (Plug-in)'
,p_alias=>'DAY-FORMATTING-PLUG-IN'
,p_step_title=>'Day Formatting (Plug-in)'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
,p_last_updated_by=>'RONNY'
,p_last_upd_yyyymmddhh24miss=>'20221102154107'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(638593749940917301)
,p_plug_name=>'Info'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(1697137420567726451)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ul>',
'    <li>Formatting of days works not for Native Date Picker.</li>',
'    <li>The "disabled" attribute is only used to prevent that value can be selected in calendar table.</li>',
'    <li>It''s not validated or respected by keyboard navigation at the moment. In Popup mode the value can be set by item, so serverside validation is needed.</li>',
'</ul>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(684135374137782244)
,p_plug_name=>'Tabs'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(1856583932984088052)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(684131018896782201)
,p_plug_name=>'Date Picker'
,p_parent_plug_id=>wwv_flow_imp.id(684135374137782244)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1697139266786726476)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1909638516590996323)
,p_plug_name=>'Plug-in'
,p_parent_plug_id=>wwv_flow_imp.id(684131018896782201)
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(1697149780406726492)
,p_plug_display_sequence=>10
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1909638613243996324)
,p_plug_name=>'JavaScript Function'
,p_parent_plug_id=>wwv_flow_imp.id(684131018896782201)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(1697149780406726492)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(684131162452782202)
,p_plug_name=>'Interactive Grid'
,p_parent_plug_id=>wwv_flow_imp.id(684135374137782244)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1697148346025726487)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       TASK_NAME,',
'       START_DATE,',
'       END_DATE',
'  from EBA_DEMO_CAL_PROJECTS'))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Interactive Grid'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(684134010201782231)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(684134378157782234)
,p_name=>'START_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'START_DATE'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Start Date'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(684135015811782241)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(684135154094782242)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(684135948690782250)
,p_name=>'END_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'END_DATE'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'End Date'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_static_id=>'IG_END_DATE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(684216968430871107)
,p_name=>'TASK_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TASK_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Task Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>true
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(684131200506782203)
,p_internal_uid=>684131200506782203
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(684138966521788151)
,p_interactive_grid_id=>wwv_flow_imp.id(684131200506782203)
,p_static_id=>'6841390'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>15
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(684139176155788153)
,p_report_id=>wwv_flow_imp.id(684138966521788151)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(684165424691816792)
,p_view_id=>wwv_flow_imp.id(684139176155788153)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(684134010201782231)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(684168038142816806)
,p_view_id=>wwv_flow_imp.id(684139176155788153)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(684134378157782234)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(684199765826824661)
,p_view_id=>wwv_flow_imp.id(684139176155788153)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(684135015811782241)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(684215898806869933)
,p_view_id=>wwv_flow_imp.id(684139176155788153)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(684135948690782250)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(684231639005929948)
,p_view_id=>wwv_flow_imp.id(684139176155788153)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(684216968430871107)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(684216827622871106)
,p_plug_name=>'Breadmcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1697152395490726495)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(8193437692093634486)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(1697173368772726572)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(687982512277267501)
,p_plug_name=>'Example JavaScript'
,p_region_template_options=>'#DEFAULT#:js-dialog-size720x480'
,p_plug_template=>wwv_flow_imp.id(1697148815010726490)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'apex.items.<i>{Item Name}</i>.dayFormatter = function (pDateISOString) {',
'    return {',
'        // disable when day is selected',
'        disabled: [1, 2].includes( new Date(pDateISOString).getDay() ),',
'        // set a predefined color to the cell from ut theme for Saturday and Sunday',
'        class: [0, 6].includes(new Date(pDateISOString).getDay()) ? "u-color-12-text" : "",',
'        // set a tooltip that is shown on hover',
'        tooltip: "You can add tooltip to days"',
'    };',
'};',
'apex.items.<i>{Item Name}</i>.refresh();',
'</pre>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(687982640652267502)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1909638613243996324)
,p_button_name=>'SHOW_EXAMPLE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(1697172708132726568)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Show Example'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(638564387033838814)
,p_name=>'P540_US_HOLIDAYS_PLUGIN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1909638516590996323)
,p_prompt=>'US Holidays (Plug-in)'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(270104037966250638)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'INLINE'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(638565082429838815)
,p_name=>'P540_JAVASCRIPT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1909638613243996324)
,p_prompt=>'JavaScript'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(270104037966250638)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'INLINE'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(638565446112838816)
,p_name=>'P540_DISABLED_DAYS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1909638613243996324)
,p_prompt=>'Disabled Days'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC2:Sun;0,Mon;1,Tue;2,Wed;3,Thu;4,Fri;5,Sat;6'
,p_field_template=>wwv_flow_imp.id(270104037966250638)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'7'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(638567481051838819)
,p_name=>'Load US Holidays into Date Picker'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(687982954422267505)
,p_event_id=>wwv_flow_imp.id(638567481051838819)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.ORACLE.APEX.FORMAT_DATEPICKER_DAYS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P540_US_HOLIDAYS_PLUGIN'
,p_attribute_01=>'ics'
,p_attribute_02=>'https://calendar.google.com/calendar/ical/en.usa%23holiday@group.v.calendar.google.com/public/basic.ics'
,p_attribute_10=>'u-hot-text'
,p_attribute_11=>'server'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(684216485454871102)
,p_name=>'Load dayFormatters for IG'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(684131162452782202)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|apexbeginrecordedit'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(687983097215267506)
,p_event_id=>wwv_flow_imp.id(684216485454871102)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.ORACLE.APEX.FORMAT_DATEPICKER_DAYS'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'START_DATE'
,p_attribute_01=>'ics'
,p_attribute_02=>'https://calendar.google.com/calendar/ical/en.usa%23holiday@group.v.calendar.google.com/public/basic.ics'
,p_attribute_10=>'u-hot-text'
,p_attribute_11=>'server'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(638568343979838820)
,p_name=>'Add Day Formatter JS Function'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P540_DISABLED_DAYS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(638568885083838820)
,p_event_id=>wwv_flow_imp.id(638568343979838820)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.items.P540_JAVASCRIPT.dayFormatter = function (pDateISOString) {',
'    return {',
'        // disable when day is selected',
'        disabled: $v("P540_DISABLED_DAYS").split(":").includes("" + new Date(pDateISOString).getDay()),',
'        // set a predefined color to the cell from ut theme for Saturday and Sunday',
'        class: [0, 6].includes(new Date(pDateISOString).getDay()) ? "u-color-12-text" : "",',
'        // set a tooltip that is shown on hover',
'        tooltip: "You can add tooltip to days"',
'    };',
'};',
'apex.items.P540_JAVASCRIPT.refresh();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(687982762909267503)
,p_name=>'Open Example Dialog'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(687982640652267502)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(687982874870267504)
,p_event_id=>wwv_flow_imp.id(687982762909267503)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(687982512277267501)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(701929777051904302)
,p_name=>'Load dayFormatter for IG'
,p_event_sequence=>60
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(684216794527871105)
,p_event_id=>wwv_flow_imp.id(701929777051904302)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// To work with Interactive Grid Columns in JavaScript you have to set a static id',
'// on the column',
'apex.items.IG_END_DATE.dayFormatter = function (pDateISOString) {',
'    return {',
'        // disable when day is Monday and Tuesday',
'        disabled: [1, 2].includes(new Date(pDateISOString).getDay()),',
'        // set a predefined color to the cell from ut theme for Saturday and Sunday',
'        class: [0, 6].includes(new Date(pDateISOString).getDay()) ? "u-color-12-text" : "",',
'        // set a tooltip that is shown on hover',
'        tooltip: "You can add tooltip to days"',
'    };',
'};',
'apex.items.IG_END_DATE.refresh();'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(684135247685782243)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(684131162452782202)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Interactive Grid - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
