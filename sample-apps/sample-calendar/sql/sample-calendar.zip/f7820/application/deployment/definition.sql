prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7820
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>4421054519883540
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'DROP TABLE  "EBA_DEMO_CAL_PROJECTS" cascade constraints;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table "EBA_DEMO_CAL_SESSIONS" cascade';
wwv_flow_imp.g_varchar2_table(2) := ' constraints;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table "EBA_DEMO_CAL_MYSESSIONS" cascade constraints;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'drop procedure EBA_DEMO_C';
wwv_flow_imp.g_varchar2_table(3) := 'AL_DATA;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(2575266633949852551)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'EBA_DEMO_CAL_DATA:EBA_DEMO_CAL_PROJECTS'
);
wwv_flow_imp.component_end;
end;
/
