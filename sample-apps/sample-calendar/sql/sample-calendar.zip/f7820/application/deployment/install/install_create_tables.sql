prompt --application/deployment/install/install_create_tables
begin
--   Manifest
--     INSTALL: INSTALL-create tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>4421054519883540
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE EBA_DEMO_CAL_PROJECTS'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    "ID" NUMBER, '||wwv_flow.LF||
'    row_version_number number,'||wwv_flow.LF||
'    "PROJEC';
wwv_flow_imp.g_varchar2_table(2) := 'T" VARCHAR2(30) not null, '||wwv_flow.LF||
'    "TASK_NAME" VARCHAR2(255) not null, '||wwv_flow.LF||
'    "START_DATE" DATE not null, ';
wwv_flow_imp.g_varchar2_table(3) := ''||wwv_flow.LF||
'    "END_DATE" DATE not null, '||wwv_flow.LF||
'    "STATUS" VARCHAR2(30) not null, '||wwv_flow.LF||
'    "ASSIGNED_TO" VARCHAR2(30),';
wwv_flow_imp.g_varchar2_table(4) := ' '||wwv_flow.LF||
'    "COST" NUMBER, '||wwv_flow.LF||
'    "BUDGET" NUMBER, '||wwv_flow.LF||
'     CONSTRAINT EBA_DEMO_CAL_PROJECTS_PK PRIMARY KEY ("I';
wwv_flow_imp.g_varchar2_table(5) := 'D") ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER  BIU_EBA_DEMO_CAL_PROJECTS'||wwv_flow.LF||
'   before insert or update o';
wwv_flow_imp.g_varchar2_table(6) := 'n EBA_DEMO_CAL_PROJECTS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys';
wwv_flow_imp.g_varchar2_table(7) := '_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(8) := '       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:o';
wwv_flow_imp.g_varchar2_table(9) := 'ld.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.start_date > :new.end_date then'||wwv_flow.LF||
'       RAISE_APP';
wwv_flow_imp.g_varchar2_table(10) := 'LICATION_ERROR(-20001, ''Error start date must be before end date'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TRIGGER ';
wwv_flow_imp.g_varchar2_table(11) := 'BIU_EBA_DEMO_CAL_PROJECTS ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE TABLE EBA_DEMO_CAL_SESSIONS'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    "ID"               ';
wwv_flow_imp.g_varchar2_table(12) := '  NUMBER, '||wwv_flow.LF||
'    "ROW_VERSION_NUMBER" NUMBER,'||wwv_flow.LF||
'    "TITLE"              VARCHAR2(50)  not null, '||wwv_flow.LF||
'    "S';
wwv_flow_imp.g_varchar2_table(13) := 'ESSION_TYPE"       VARCHAR2(30)  not null,'||wwv_flow.LF||
'    "SPEAKER"            VARCHAR2(255),'||wwv_flow.LF||
'    "START_DATE" ';
wwv_flow_imp.g_varchar2_table(14) := '        DATE          not null, '||wwv_flow.LF||
'    "END_DATE"           DATE          not null, '||wwv_flow.LF||
'    "STATUS"     ';
wwv_flow_imp.g_varchar2_table(15) := '        VARCHAR2(30)  not null, '||wwv_flow.LF||
'     CONSTRAINT EBA_DEMO_CAL_EVENTS_PK PRIMARY KEY ("ID") ENABLE'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(16) := ' ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER  BIU_EBA_DEMO_CAL_SESSIONS'||wwv_flow.LF||
'   before insert or update on EBA_DEMO_CA';
wwv_flow_imp.g_varchar2_table(17) := 'L_SESSIONS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXX';
wwv_flow_imp.g_varchar2_table(18) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.r';
wwv_flow_imp.g_varchar2_table(19) := 'ow_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_versio';
wwv_flow_imp.g_varchar2_table(20) := 'n_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.start_date > :new.end_date then'||wwv_flow.LF||
'       RAISE_APPLICATION_ERRO';
wwv_flow_imp.g_varchar2_table(21) := 'R(-20001, ''Error start date must be before end date'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE TABLE EBA_DEMO_CAL';
wwv_flow_imp.g_varchar2_table(22) := '_MYSESSIONS'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    "ID"                 NUMBER, '||wwv_flow.LF||
'    "ROW_VERSION_NUMBER" NUMBER,'||wwv_flow.LF||
'    "TITLE"     ';
wwv_flow_imp.g_varchar2_table(23) := '         VARCHAR2(50)  not null, '||wwv_flow.LF||
'    "SESSION_TYPE"       VARCHAR2(30)  not null,'||wwv_flow.LF||
'    "SPEAKER"    ';
wwv_flow_imp.g_varchar2_table(24) := '        VARCHAR2(255),'||wwv_flow.LF||
'    "START_DATE"         DATE          not null, '||wwv_flow.LF||
'    "END_DATE"           DA';
wwv_flow_imp.g_varchar2_table(25) := 'TE          not null, '||wwv_flow.LF||
'    "STATUS"             VARCHAR2(30)  not null, '||wwv_flow.LF||
'     CONSTRAINT EBA_DEMO_CA';
wwv_flow_imp.g_varchar2_table(26) := 'L_MYEVENTS_PK PRIMARY KEY ("ID") ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2579188023203524298)
,p_install_id=>wwv_flow_imp.id(2575266633949852551)
,p_name=>'create tables'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
