prompt --application/deployment/install/install_insert_data
begin
--   Manifest
--     INSTALL: INSTALL-insert data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>4421054519883540
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace procedure EBA_DEMO_CAL_DATA as'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  delete from EBA_DEMO_CAL_PROJECTS;'||wwv_flow.LF||
'  '||wwv_flow.LF||
'  ins';
wwv_flow_imp.g_varchar2_table(2) := 'ert into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget';
wwv_flow_imp.g_varchar2_table(3) := ') values (''ACME Web Express Configuration'',''Identify server requirements'',to_date(''12/20/2015'',''MM/D';
wwv_flow_imp.g_varchar2_table(4) := 'D/YYYY''),to_date(''12/21/2015'',''MM/DD/YYYY''),''Closed'',''John Watson'',''200'',''500'');'||wwv_flow.LF||
'  insert into eba_d';
wwv_flow_imp.g_varchar2_table(5) := 'emo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''ACM';
wwv_flow_imp.g_varchar2_table(6) := 'E Web Express Configuration'',''Determine Web listener configuration(s)'',to_date(''12/22/2015'',''MM/DD/Y';
wwv_flow_imp.g_varchar2_table(7) := 'YYY''),to_date(''12/22/2015'',''MM/DD/YYYY''),''Closed'',''James Cassidy'',''600'',''500'');'||wwv_flow.LF||
'  insert into eba_de';
wwv_flow_imp.g_varchar2_table(8) := 'mo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''ACME';
wwv_flow_imp.g_varchar2_table(9) := ' Web Express Configuration'',''Run installation'',to_date(''12/25/2015'',''MM/DD/YYYY''),to_date(''12/25/201';
wwv_flow_imp.g_varchar2_table(10) := '5'',''MM/DD/YYYY''),''Closed'',''James Cassidy'',''200'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project';
wwv_flow_imp.g_varchar2_table(11) := ',task_name,start_date,end_date,status,assigned_to,cost,budget) values (''ACME Web Express Configurati';
wwv_flow_imp.g_varchar2_table(12) := 'on'',''Create pilot workspace'',to_date(''12/27/2015'',''MM/DD/YYYY''),to_date(''12/27/2015'',''MM/DD/YYYY''),''';
wwv_flow_imp.g_varchar2_table(13) := 'Closed'',''John Watson'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_dat';
wwv_flow_imp.g_varchar2_table(14) := 'e,end_date,status,assigned_to,cost,budget) values (''ACME Web Express Configuration'',''Specify securit';
wwv_flow_imp.g_varchar2_table(15) := 'y authentication scheme(s)'',to_date(''01/01/2016'',''MM/DD/YYYY''),to_date(''01/01/2016'',''MM/DD/YYYY''),''O';
wwv_flow_imp.g_varchar2_table(16) := 'pen'',''John Watson'',''200'',''300'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,e';
wwv_flow_imp.g_varchar2_table(17) := 'nd_date,status,assigned_to,cost,budget) values (''ACME Web Express Configuration'',''Configure Workspac';
wwv_flow_imp.g_varchar2_table(18) := 'e provisioning'',to_date(''01/02/2016'',''MM/DD/YYYY''),to_date(''01/02/2016'',''MM/DD/YYYY''),''Open'',''John W';
wwv_flow_imp.g_varchar2_table(19) := 'atson'',''200'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,stat';
wwv_flow_imp.g_varchar2_table(20) := 'us,assigned_to,cost,budget) values (''ACME Web Express Configuration'',''Select servers for Development';
wwv_flow_imp.g_varchar2_table(21) := ', Test, Production'',to_date(''01/05/2016'',''MM/DD/YYYY''),to_date(''01/07/2016'',''MM/DD/YYYY''),''Open'',''Ja';
wwv_flow_imp.g_varchar2_table(22) := 'mes Cassidy'',''200'',''600'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_dat';
wwv_flow_imp.g_varchar2_table(23) := 'e,status,assigned_to,cost,budget) values (''Bug Tracker'',''Document quality assurance procedures'',to_d';
wwv_flow_imp.g_varchar2_table(24) := 'ate(''11/05/2015'',''MM/DD/YYYY''),to_date(''11/08/2015'',''MM/DD/YYYY''),''Closed'',''Myra Sutcliff'',''3000'',''2';
wwv_flow_imp.g_varchar2_table(25) := '000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to';
wwv_flow_imp.g_varchar2_table(26) := ',cost,budget) values (''Bug Tracker'',''Review automated testing tools'',to_date(''11/09/2015'',''MM/DD/YYY';
wwv_flow_imp.g_varchar2_table(27) := 'Y''),to_date(''11/11/2015'',''MM/DD/YYYY''),''Closed'',''Myra Sutcliff'',''750'',''1500'');'||wwv_flow.LF||
'  insert into eba_dem';
wwv_flow_imp.g_varchar2_table(28) := 'o_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Bug T';
wwv_flow_imp.g_varchar2_table(29) := 'racker'',''Implement bug tracking software'',to_date(''11/24/2015'',''MM/DD/YYYY''),to_date(''11/24/2015'',''M';
wwv_flow_imp.g_varchar2_table(30) := 'M/DD/YYYY''),''Closed'',''Myra Sutcliff'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task';
wwv_flow_imp.g_varchar2_table(31) := '_name,start_date,end_date,status,assigned_to,cost,budget) values (''Bug Tracker'',''Train developers on';
wwv_flow_imp.g_varchar2_table(32) := ' tracking bugs'',to_date(''12/01/2015'',''MM/DD/YYYY''),to_date(''12/06/2015'',''MM/DD/YYYY''),''On-Hold'',''Myr';
wwv_flow_imp.g_varchar2_table(33) := 'a Sutcliff'',''1000'',''2000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_da';
wwv_flow_imp.g_varchar2_table(34) := 'te,status,assigned_to,cost,budget) values (''Bug Tracker'',''Measure effectiveness of improved QA'',to_d';
wwv_flow_imp.g_varchar2_table(35) := 'ate(''12/13/2015'',''MM/DD/YYYY''),to_date(''12/13/2015'',''MM/DD/YYYY''),''Pending'',''Myra Sutcliff'',''0'',''500';
wwv_flow_imp.g_varchar2_table(36) := ''');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,co';
wwv_flow_imp.g_varchar2_table(37) := 'st,budget) values (''Convert Spreadsheets'',''Collect mission-critical spreadsheets'',to_date(''12/19/201';
wwv_flow_imp.g_varchar2_table(38) := '5'',''MM/DD/YYYY''),to_date(''12/20/2015'',''MM/DD/YYYY''),''Closed'',''Pam King'',''2500'',''4000'');'||wwv_flow.LF||
'  insert int';
wwv_flow_imp.g_varchar2_table(39) := 'o eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) value';
wwv_flow_imp.g_varchar2_table(40) := 's (''Convert Spreadsheets'',''Lock spreadsheets'',to_date(''12/22/2015'',''MM/DD/YYYY''),to_date(''12/22/2015';
wwv_flow_imp.g_varchar2_table(41) := ''',''MM/DD/YYYY''),''Closed'',''Pam King'',''300'',''800'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_';
wwv_flow_imp.g_varchar2_table(42) := 'name,start_date,end_date,status,assigned_to,cost,budget) values (''Convert Spreadsheets'',''Create ACME';
wwv_flow_imp.g_varchar2_table(43) := ' Web Express applications from spreadsheets'',to_date(''12/30/2015'',''MM/DD/YYYY''),to_date(''01/03/2016''';
wwv_flow_imp.g_varchar2_table(44) := ',''MM/DD/YYYY''),''Open'',''Pam King'',''6000'',''10000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_';
wwv_flow_imp.g_varchar2_table(45) := 'name,start_date,end_date,status,assigned_to,cost,budget) values (''Convert Spreadsheets'',''Send links ';
wwv_flow_imp.g_varchar2_table(46) := 'to previous spreadsheet owners'',to_date(''01/05/2016'',''MM/DD/YYYY''),to_date(''01/05/2016'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(47) := '),''Pending'',''Pam King'',''0'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date';
wwv_flow_imp.g_varchar2_table(48) := ',end_date,status,assigned_to,cost,budget) values (''Discussion Forum'',''Identify owners'',to_date(''11/2';
wwv_flow_imp.g_varchar2_table(49) := '5/2015'',''MM/DD/YYYY''),to_date(''11/25/2015'',''MM/DD/YYYY''),''Closed'',''Hank Davis'',''250'',''300'');'||wwv_flow.LF||
'  inser';
wwv_flow_imp.g_varchar2_table(50) := 't into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) ';
wwv_flow_imp.g_varchar2_table(51) := 'values (''Discussion Forum'',''Install ACME Web Express application on internet server'',to_date(''12/01/';
wwv_flow_imp.g_varchar2_table(52) := '2015'',''MM/DD/YYYY''),to_date(''12/01/2015'',''MM/DD/YYYY''),''Closed'',''Hank Davis'',''100'',''100'');'||wwv_flow.LF||
'  insert ';
wwv_flow_imp.g_varchar2_table(53) := 'into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) va';
wwv_flow_imp.g_varchar2_table(54) := 'lues (''Discussion Forum'',''Monitor participation'',to_date(''12/31/2015'',''MM/DD/YYYY''),to_date(''01/01/2';
wwv_flow_imp.g_varchar2_table(55) := '016'',''MM/DD/YYYY''),''Open'',''Hank Davis'',''450'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,ta';
wwv_flow_imp.g_varchar2_table(56) := 'sk_name,start_date,end_date,status,assigned_to,cost,budget) values (''Email Integration'',''Complete pl';
wwv_flow_imp.g_varchar2_table(57) := 'an'',to_date(''12/12/2015'',''MM/DD/YYYY''),to_date(''12/13/2015'',''MM/DD/YYYY''),''Closed'',''Bob Nile'',''3000''';
wwv_flow_imp.g_varchar2_table(58) := ',''1500'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned';
wwv_flow_imp.g_varchar2_table(59) := '_to,cost,budget) values (''Email Integration'',''Check software licenses'',to_date(''12/15/2015'',''MM/DD/Y';
wwv_flow_imp.g_varchar2_table(60) := 'YYY''),to_date(''12/15/2015'',''MM/DD/YYYY''),''Closed'',''Bob Nile'',''200'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_ca';
wwv_flow_imp.g_varchar2_table(61) := 'l_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Email Int';
wwv_flow_imp.g_varchar2_table(62) := 'egration'',''Get RFPs for new server'',to_date(''12/29/2015'',''MM/DD/YYYY''),to_date(''12/30/2015'',''MM/DD/Y';
wwv_flow_imp.g_varchar2_table(63) := 'YYY''),''Closed'',''Bob Nile'',''2000'',''1000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,sta';
wwv_flow_imp.g_varchar2_table(64) := 'rt_date,end_date,status,assigned_to,cost,budget) values (''Email Integration'',''Purchase backup server';
wwv_flow_imp.g_varchar2_table(65) := ''',to_date(''01/15/2016'',''MM/DD/YYYY''),to_date(''01/17/2016'',''MM/DD/YYYY''),''Pending'',''Bob Nile'',''0'',''30';
wwv_flow_imp.g_varchar2_table(66) := '00'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,';
wwv_flow_imp.g_varchar2_table(67) := 'cost,budget) values (''Employee Satisfaction Survey'',''Complete questionnaire'',to_date(''12/05/2015'',''M';
wwv_flow_imp.g_varchar2_table(68) := 'M/DD/YYYY''),to_date(''12/06/2015'',''MM/DD/YYYY''),''Closed'',''Irene Jones'',''1200'',''800'');'||wwv_flow.LF||
'  insert into e';
wwv_flow_imp.g_varchar2_table(69) := 'ba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (';
wwv_flow_imp.g_varchar2_table(70) := '''Employee Satisfaction Survey'',''Review with legal'',to_date(''12/07/2015'',''MM/DD/YYYY''),to_date(''12/07';
wwv_flow_imp.g_varchar2_table(71) := '/2015'',''MM/DD/YYYY''),''On-Hold'',''Irene Jones'',''200'',''400'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (proj';
wwv_flow_imp.g_varchar2_table(72) := 'ect,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Employee Satisfaction Sur';
wwv_flow_imp.g_varchar2_table(73) := 'vey'',''Plan rollout schedule'',to_date(''12/08/2015'',''MM/DD/YYYY''),to_date(''12/08/2015'',''MM/DD/YYYY''),''';
wwv_flow_imp.g_varchar2_table(74) := 'On-Hold'',''Irene Jones'',''0'',''750'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date';
wwv_flow_imp.g_varchar2_table(75) := ',end_date,status,assigned_to,cost,budget) values (''Client Server Conversion'',''Identify pilot Client ';
wwv_flow_imp.g_varchar2_table(76) := 'Server applications'',to_date(''12/17/2015'',''MM/DD/YYYY''),to_date(''12/17/2015'',''MM/DD/YYYY''),''Closed'',';
wwv_flow_imp.g_varchar2_table(77) := '''Scott Spencer'',''200'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_';
wwv_flow_imp.g_varchar2_table(78) := 'date,status,assigned_to,cost,budget) values (''Client Server Conversion'',''Migrate pilot Client Server';
wwv_flow_imp.g_varchar2_table(79) := ' to ACME Web Express'',to_date(''12/19/2015'',''MM/DD/YYYY''),to_date(''12/22/2015'',''MM/DD/YYYY''),''Closed''';
wwv_flow_imp.g_varchar2_table(80) := ',''Scott Spencer'',''4500'',''5000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,e';
wwv_flow_imp.g_varchar2_table(81) := 'nd_date,status,assigned_to,cost,budget) values (''Client Server Conversion'',''Post-migration review'',t';
wwv_flow_imp.g_varchar2_table(82) := 'o_date(''12/23/2015'',''MM/DD/YYYY''),to_date(''12/23/2015'',''MM/DD/YYYY''),''Closed'',''Pam King'',''500'',''300''';
wwv_flow_imp.g_varchar2_table(83) := ');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cos';
wwv_flow_imp.g_varchar2_table(84) := 't,budget) values (''Client Server Conversion'',''Plan migration schedule'',to_date(''12/26/2015'',''MM/DD/Y';
wwv_flow_imp.g_varchar2_table(85) := 'YYY''),to_date(''12/26/2015'',''MM/DD/YYYY''),''Closed'',''Pam King'',''1000'',''1000'');'||wwv_flow.LF||
'  insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(86) := 'cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Client ';
wwv_flow_imp.g_varchar2_table(87) := 'Server Conversion'',''Migrate Client Server applications'',to_date(''12/31/2015'',''MM/DD/YYYY''),to_date(''';
wwv_flow_imp.g_varchar2_table(88) := '01/03/2016'',''MM/DD/YYYY''),''Open'',''Pam King'',''300'',''12000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (pro';
wwv_flow_imp.g_varchar2_table(89) := 'ject,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Client Server Conversion';
wwv_flow_imp.g_varchar2_table(90) := ''',''Test migrated applications'',to_date(''01/05/2016'',''MM/DD/YYYY''),to_date(''01/06/2016'',''MM/DD/YYYY'')';
wwv_flow_imp.g_varchar2_table(91) := ',''Pending'',''Russ Saunders'',''0'',''6000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start';
wwv_flow_imp.g_varchar2_table(92) := '_date,end_date,status,assigned_to,cost,budget) values (''Client Server Conversion'',''User acceptance t';
wwv_flow_imp.g_varchar2_table(93) := 'esting'',to_date(''01/09/2016'',''MM/DD/YYYY''),to_date(''01/11/2016'',''MM/DD/YYYY''),''Pending'',''Russ Saunde';
wwv_flow_imp.g_varchar2_table(94) := 'rs'',''0'',''2500'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,status,a';
wwv_flow_imp.g_varchar2_table(95) := 'ssigned_to,cost,budget) values (''Client Server Conversion'',''End-user Training'',to_date(''01/15/2016'',';
wwv_flow_imp.g_varchar2_table(96) := '''MM/DD/YYYY''),to_date(''01/15/2016'',''MM/DD/YYYY''),''Pending'',''Myra Sutcliff'',''0'',''2500'');'||wwv_flow.LF||
'  insert int';
wwv_flow_imp.g_varchar2_table(97) := 'o eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) value';
wwv_flow_imp.g_varchar2_table(98) := 's (''Client Server Conversion'',''Rollout migrated Client Server in ACME Web Express'',to_date(''01/16/20';
wwv_flow_imp.g_varchar2_table(99) := '16'',''MM/DD/YYYY''),to_date(''01/16/2016'',''MM/DD/YYYY''),''Pending'',''Pam King'',''0'',''200'');'||wwv_flow.LF||
'  insert into ';
wwv_flow_imp.g_varchar2_table(100) := 'eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values ';
wwv_flow_imp.g_varchar2_table(101) := '(''Load Packaged Apps'',''Identify point solutions required'',to_date(''12/19/2015'',''MM/DD/YYYY''),to_date';
wwv_flow_imp.g_varchar2_table(102) := '(''12/19/2015'',''MM/DD/YYYY''),''Closed'',''John Watson'',''200'',''300'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects';
wwv_flow_imp.g_varchar2_table(103) := ' (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Load Packaged Apps''';
wwv_flow_imp.g_varchar2_table(104) := ',''Install in development'',to_date(''12/20/2015'',''MM/DD/YYYY''),to_date(''12/20/2015'',''MM/DD/YYYY''),''Clo';
wwv_flow_imp.g_varchar2_table(105) := 'sed'',''John Watson'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,e';
wwv_flow_imp.g_varchar2_table(106) := 'nd_date,status,assigned_to,cost,budget) values (''Load Packaged Apps'',''Customize solutions'',to_date(''';
wwv_flow_imp.g_varchar2_table(107) := '12/23/2015'',''MM/DD/YYYY''),to_date(''12/25/2015'',''MM/DD/YYYY''),''Open'',''John Watson'',''1500'',''4000'');'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(108) := 'insert into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,bud';
wwv_flow_imp.g_varchar2_table(109) := 'get) values (''Load Packaged Apps'',''Implement in Production'',to_date(''12/26/2015'',''MM/DD/YYYY''),to_da';
wwv_flow_imp.g_varchar2_table(110) := 'te(''12/26/2015'',''MM/DD/YYYY''),''On-Hold'',''John Watson'',''200'',''1500'');'||wwv_flow.LF||
'  insert into eba_demo_cal_proj';
wwv_flow_imp.g_varchar2_table(111) := 'ects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Load Packaged A';
wwv_flow_imp.g_varchar2_table(112) := 'pps'',''Train Administrators of Packaged Apps'',to_date(''12/28/2015'',''MM/DD/YYYY''),to_date(''12/28/2015''';
wwv_flow_imp.g_varchar2_table(113) := ',''MM/DD/YYYY''),''Pending'',''John Watson'',''0'',''1000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,tas';
wwv_flow_imp.g_varchar2_table(114) := 'k_name,start_date,end_date,status,assigned_to,cost,budget) values (''Maintain Support Systems'',''HR so';
wwv_flow_imp.g_varchar2_table(115) := 'ftware upgrades'',to_date(''11/28/2015'',''MM/DD/YYYY''),to_date(''12/01/2015'',''MM/DD/YYYY''),''Closed'',''Pam';
wwv_flow_imp.g_varchar2_table(116) := ' King'',''8000'',''7000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,st';
wwv_flow_imp.g_varchar2_table(117) := 'atus,assigned_to,cost,budget) values (''Maintain Support Systems'',''Apply Billing System updates'',to_d';
wwv_flow_imp.g_varchar2_table(118) := 'ate(''12/02/2015'',''MM/DD/YYYY''),to_date(''12/04/2015'',''MM/DD/YYYY''),''Closed'',''Russ Saunders'',''9500'',''7';
wwv_flow_imp.g_varchar2_table(119) := '000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to';
wwv_flow_imp.g_varchar2_table(120) := ',cost,budget) values (''Maintain Support Systems'',''Arrange for vacation coverage'',to_date(''12/06/2015';
wwv_flow_imp.g_varchar2_table(121) := ''',''MM/DD/YYYY''),to_date(''12/06/2015'',''MM/DD/YYYY''),''Open'',''Al Bines'',''300'',''500'');'||wwv_flow.LF||
'  insert into eba';
wwv_flow_imp.g_varchar2_table(122) := '_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''M';
wwv_flow_imp.g_varchar2_table(123) := 'aintain Support Systems'',''Investigate new Virus Protection software'',to_date(''01/15/2016'',''MM/DD/YYY';
wwv_flow_imp.g_varchar2_table(124) := 'Y''),to_date(''01/16/2016'',''MM/DD/YYYY''),''Open'',''Pam King'',''1700'',''1500'');'||wwv_flow.LF||
'  insert into eba_demo_cal_';
wwv_flow_imp.g_varchar2_table(125) := 'projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate Des';
wwv_flow_imp.g_varchar2_table(126) := 'ktop Application'',''Identify pilot desktop applications'',to_date(''12/10/2015'',''MM/DD/YYYY''),to_date(''';
wwv_flow_imp.g_varchar2_table(127) := '12/10/2015'',''MM/DD/YYYY''),''Closed'',''Bob Nile'',''300'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (pro';
wwv_flow_imp.g_varchar2_table(128) := 'ject,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate Desktop Applicat';
wwv_flow_imp.g_varchar2_table(129) := 'ion'',''Migrate pilot applications to ACME Web Express'',to_date(''12/12/2015'',''MM/DD/YYYY''),to_date(''12';
wwv_flow_imp.g_varchar2_table(130) := '/13/2015'',''MM/DD/YYYY''),''Closed'',''Bob Nile'',''1250'',''1500'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (pro';
wwv_flow_imp.g_varchar2_table(131) := 'ject,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate Desktop Applicat';
wwv_flow_imp.g_varchar2_table(132) := 'ion'',''Plan migration schedule'',to_date(''12/16/2015'',''MM/DD/YYYY''),to_date(''12/16/2015'',''MM/DD/YYYY'')';
wwv_flow_imp.g_varchar2_table(133) := ',''Closed'',''Bob Nile'',''600'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date';
wwv_flow_imp.g_varchar2_table(134) := ',end_date,status,assigned_to,cost,budget) values (''Migrate Desktop Application'',''Migrate desktop app';
wwv_flow_imp.g_varchar2_table(135) := 'lications'',to_date(''01/08/2016'',''MM/DD/YYYY''),to_date(''01/12/2016'',''MM/DD/YYYY''),''Open'',''Bob Nile'',''';
wwv_flow_imp.g_varchar2_table(136) := '1000'',''8000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,status,ass';
wwv_flow_imp.g_varchar2_table(137) := 'igned_to,cost,budget) values (''Migrate Desktop Application'',''User acceptance testing'',to_date(''01/14';
wwv_flow_imp.g_varchar2_table(138) := '/2016'',''MM/DD/YYYY''),to_date(''01/15/2016'',''MM/DD/YYYY''),''Open'',''Bob Nile'',''1500'',''6000'');'||wwv_flow.LF||
'  insert i';
wwv_flow_imp.g_varchar2_table(139) := 'nto eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) val';
wwv_flow_imp.g_varchar2_table(140) := 'ues (''Migrate Desktop Application'',''End-user Training'',to_date(''01/18/2016'',''MM/DD/YYYY''),to_date(''0';
wwv_flow_imp.g_varchar2_table(141) := '1/19/2016'',''MM/DD/YYYY''),''Open'',''John Watson'',''0'',''2000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (proj';
wwv_flow_imp.g_varchar2_table(142) := 'ect,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate Desktop Applicati';
wwv_flow_imp.g_varchar2_table(143) := 'on'',''Post-migration review'',to_date(''02/01/2016'',''MM/DD/YYYY''),to_date(''02/02/2016'',''MM/DD/YYYY''),''P';
wwv_flow_imp.g_varchar2_table(144) := 'ending'',''Bob Nile'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,e';
wwv_flow_imp.g_varchar2_table(145) := 'nd_date,status,assigned_to,cost,budget) values (''Migrate from Legacy Server'',''Obtain Legacy Server c';
wwv_flow_imp.g_varchar2_table(146) := 'redentials'',to_date(''01/20/2016'',''MM/DD/YYYY''),to_date(''01/20/2016'',''MM/DD/YYYY''),''Pending'',''James C';
wwv_flow_imp.g_varchar2_table(147) := 'assidy'',''0'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,statu';
wwv_flow_imp.g_varchar2_table(148) := 's,assigned_to,cost,budget) values (''Migrate from Legacy Server'',''Map data usage'',to_date(''01/22/2016';
wwv_flow_imp.g_varchar2_table(149) := ''',''MM/DD/YYYY''),to_date(''01/24/2016'',''MM/DD/YYYY''),''Pending'',''Bob Nile'',''0'',''8000'');'||wwv_flow.LF||
'  insert into e';
wwv_flow_imp.g_varchar2_table(150) := 'ba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (';
wwv_flow_imp.g_varchar2_table(151) := '''Migrate from Legacy Server'',''Identify integration points'',to_date(''01/25/2016'',''MM/DD/YYYY''),to_dat';
wwv_flow_imp.g_varchar2_table(152) := 'e(''01/26/2016'',''MM/DD/YYYY''),''Pending'',''Bob Nile'',''0'',''2000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (';
wwv_flow_imp.g_varchar2_table(153) := 'project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate from Legacy S';
wwv_flow_imp.g_varchar2_table(154) := 'erver'',''Create DB Connection to new server'',to_date(''01/25/2016'',''MM/DD/YYYY''),to_date(''01/25/2016'',';
wwv_flow_imp.g_varchar2_table(155) := '''MM/DD/YYYY''),''Pending'',''Scott Spencer'',''0'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,tas';
wwv_flow_imp.g_varchar2_table(156) := 'k_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate from Legacy Server'',''Mig';
wwv_flow_imp.g_varchar2_table(157) := 'rate table structures'',to_date(''01/19/2016'',''MM/DD/YYYY''),to_date(''01/20/2016'',''MM/DD/YYYY''),''Pendin';
wwv_flow_imp.g_varchar2_table(158) := 'g'',''John Watson'',''0'',''2500'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_';
wwv_flow_imp.g_varchar2_table(159) := 'date,status,assigned_to,cost,budget) values (''Migrate from Legacy Server'',''Import data'',to_date(''01/';
wwv_flow_imp.g_varchar2_table(160) := '31/2016'',''MM/DD/YYYY''),to_date(''02/01/2016'',''MM/DD/YYYY''),''Pending'',''John Watson'',''0'',''1000'');'||wwv_flow.LF||
'  ins';
wwv_flow_imp.g_varchar2_table(161) := 'ert into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget';
wwv_flow_imp.g_varchar2_table(162) := ') values (''Migrate from Legacy Server'',''Convert processes'',to_date(''01/31/2016'',''MM/DD/YYYY''),to_dat';
wwv_flow_imp.g_varchar2_table(163) := 'e(''02/02/2016'',''MM/DD/YYYY''),''Pending'',''Pam King'',''0'',''3000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (';
wwv_flow_imp.g_varchar2_table(164) := 'project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate from Legacy S';
wwv_flow_imp.g_varchar2_table(165) := 'erver'',''Notify users'',to_date(''02/05/2016'',''MM/DD/YYYY''),to_date(''02/05/2016'',''MM/DD/YYYY''),''Pending';
wwv_flow_imp.g_varchar2_table(166) := ''',''Bob Nile'',''0'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,';
wwv_flow_imp.g_varchar2_table(167) := 'status,assigned_to,cost,budget) values (''Migrate from Legacy Server'',''Cut over to new database'',to_d';
wwv_flow_imp.g_varchar2_table(168) := 'ate(''02/06/2016'',''MM/DD/YYYY''),to_date(''02/06/2016'',''MM/DD/YYYY''),''Pending'',''Bob Nile'',''0'',''1500'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(169) := '  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,b';
wwv_flow_imp.g_varchar2_table(170) := 'udget) values (''Migrate from Legacy Server'',''Decommission Legacy Server'',to_date(''02/20/2016'',''MM/DD';
wwv_flow_imp.g_varchar2_table(171) := '/YYYY''),to_date(''02/20/2016'',''MM/DD/YYYY''),''Pending'',''Al Bines'',''0'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_c';
wwv_flow_imp.g_varchar2_table(172) := 'al_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Public W';
wwv_flow_imp.g_varchar2_table(173) := 'ebsite'',''Determine host server'',to_date(''12/05/2015'',''MM/DD/YYYY''),to_date(''12/05/2015'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(174) := '),''Closed'',''Tiger Scott'',''200'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_';
wwv_flow_imp.g_varchar2_table(175) := 'date,end_date,status,assigned_to,cost,budget) values (''Public Website'',''Check software licenses'',to_';
wwv_flow_imp.g_varchar2_table(176) := 'date(''12/05/2015'',''MM/DD/YYYY''),to_date(''12/05/2015'',''MM/DD/YYYY''),''Closed'',''Tom Suess'',''100'',''100'')';
wwv_flow_imp.g_varchar2_table(177) := ';'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost';
wwv_flow_imp.g_varchar2_table(178) := ',budget) values (''Public Website'',''Purchase additional software licenses, if needed'',to_date(''12/06/';
wwv_flow_imp.g_varchar2_table(179) := '2015'',''MM/DD/YYYY''),to_date(''12/07/2015'',''MM/DD/YYYY''),''On-Hold'',''Al Bines'',''300'',''1000'');'||wwv_flow.LF||
'  insert ';
wwv_flow_imp.g_varchar2_table(180) := 'into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) va';
wwv_flow_imp.g_varchar2_table(181) := 'lues (''Public Website'',''Develop web pages'',to_date(''01/01/2016'',''MM/DD/YYYY''),to_date(''01/02/2016'',''';
wwv_flow_imp.g_varchar2_table(182) := 'MM/DD/YYYY''),''Open'',''Tiger Scott'',''0'',''2000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_nam';
wwv_flow_imp.g_varchar2_table(183) := 'e,start_date,end_date,status,assigned_to,cost,budget) values (''Public Website'',''Plan rollout schedul';
wwv_flow_imp.g_varchar2_table(184) := 'e'',to_date(''01/03/2016'',''MM/DD/YYYY''),to_date(''01/03/2016'',''MM/DD/YYYY''),''Open'',''Tom Suess'',''0'',''100';
wwv_flow_imp.g_varchar2_table(185) := ''');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,co';
wwv_flow_imp.g_varchar2_table(186) := 'st,budget) values (''Software Project Tracking'',''Conduct project kickoff meeting'',to_date(''12/28/2015';
wwv_flow_imp.g_varchar2_table(187) := ''',''MM/DD/YYYY''),to_date(''12/28/2015'',''MM/DD/YYYY''),''Closed'',''Pam King'',''100'',''100'');'||wwv_flow.LF||
'  insert into e';
wwv_flow_imp.g_varchar2_table(188) := 'ba_demo_cal_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (';
wwv_flow_imp.g_varchar2_table(189) := '''Software Project Tracking'',''Customize Software Projects software'',to_date(''12/31/2015'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(190) := '),to_date(''01/01/2016'',''MM/DD/YYYY''),''Open'',''Tom Suess'',''600'',''1000'');'||wwv_flow.LF||
'  insert into eba_demo_cal_pr';
wwv_flow_imp.g_varchar2_table(191) := 'ojects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Software Proj';
wwv_flow_imp.g_varchar2_table(192) := 'ect Tracking'',''Enter base data (Projects, Milestones, etc.)'',to_date(''01/02/2016'',''MM/DD/YYYY''),to_d';
wwv_flow_imp.g_varchar2_table(193) := 'ate(''01/02/2016'',''MM/DD/YYYY''),''Open'',''Tom Suess'',''200'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects ';
wwv_flow_imp.g_varchar2_table(194) := '(project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Software Project Tra';
wwv_flow_imp.g_varchar2_table(195) := 'cking'',''Load current tasks and enhancements'',to_date(''01/04/2016'',''MM/DD/YYYY''),to_date(''01/04/2016''';
wwv_flow_imp.g_varchar2_table(196) := ',''MM/DD/YYYY''),''Open'',''Tom Suess'',''400'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_na';
wwv_flow_imp.g_varchar2_table(197) := 'me,start_date,end_date,status,assigned_to,cost,budget) values (''Training for ACME Web Express'',''Crea';
wwv_flow_imp.g_varchar2_table(198) := 'te training workspace'',to_date(''12/17/2015'',''MM/DD/YYYY''),to_date(''12/18/2015'',''MM/DD/YYYY''),''Closed';
wwv_flow_imp.g_varchar2_table(199) := ''',''James Cassidy'',''500'',''700'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,en';
wwv_flow_imp.g_varchar2_table(200) := 'd_date,status,assigned_to,cost,budget) values (''Training for ACME Web Express'',''Publish links to sel';
wwv_flow_imp.g_varchar2_table(201) := 'f-study courses'',to_date(''12/19/2015'',''MM/DD/YYYY''),to_date(''12/19/2015'',''MM/DD/YYYY''),''Closed'',''Joh';
wwv_flow_imp.g_varchar2_table(202) := 'n Watson'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_cal_projects (project,task_name,start_date,end_date,s';
wwv_flow_imp.g_varchar2_table(203) := 'tatus,assigned_to,cost,budget) values (''Training for ACME Web Express'',''Publish development standard';
wwv_flow_imp.g_varchar2_table(204) := 's'',to_date(''12/19/2015'',''MM/DD/YYYY''),to_date(''12/20/2015'',''MM/DD/YYYY''),''On-Hold'',''John Watson'',''10';
wwv_flow_imp.g_varchar2_table(205) := '00'',''2000'');'||wwv_flow.LF||
'  '||wwv_flow.LF||
'  update eba_demo_cal_projects'||wwv_flow.LF||
'  set start_date = start_date + (SYSDATE - TO_DATE(''0';
wwv_flow_imp.g_varchar2_table(206) := '1012016'',''MMDDYYYY''))'||wwv_flow.LF||
'  ,   end_date = end_date + (SYSDATE - TO_DATE(''01012016'',''MMDDYYYY''));'||wwv_flow.LF||
'  '||wwv_flow.LF||
'  d';
wwv_flow_imp.g_varchar2_table(207) := 'elete from eba_demo_cal_sessions;'||wwv_flow.LF||
''||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speaker';
wwv_flow_imp.g_varchar2_table(208) := ', start_date, end_date, status) values (''Keynote'',                             ''GENERAL'',   ''Irene J';
wwv_flow_imp.g_varchar2_table(209) := 'ones'',   to_date(''20160101100000'',''YYYYMMDDHH24MISS''),to_date(''20160101110000'',''YYYYMMDDHH24MISS''),''';
wwv_flow_imp.g_varchar2_table(210) := 'ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speaker, start_date, end_date, ';
wwv_flow_imp.g_varchar2_table(211) := 'status) values (''Current Product Overview'',            ''GENERAL'',   ''Scott Spencer'', to_date(''201601';
wwv_flow_imp.g_varchar2_table(212) := '01110000'',''YYYYMMDDHH24MISS''),to_date(''20160101120000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into';
wwv_flow_imp.g_varchar2_table(213) := ' eba_demo_cal_sessions (title, session_type, speaker, start_date, end_date, status) values (''Lunch'',';
wwv_flow_imp.g_varchar2_table(214) := '                               ''BREAK'',     null,            to_date(''20160101120000'',''YYYYMMDDHH24M';
wwv_flow_imp.g_varchar2_table(215) := 'ISS''),to_date(''20160101133000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (';
wwv_flow_imp.g_varchar2_table(216) := 'title, session_type, speaker, start_date, end_date, status) values (''New Features Overview'',        ';
wwv_flow_imp.g_varchar2_table(217) := '       ''GENERAL'',   ''John  Watson'',  to_date(''20160101133000'',''YYYYMMDDHH24MISS''),to_date(''201601011';
wwv_flow_imp.g_varchar2_table(218) := '43000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, spe';
wwv_flow_imp.g_varchar2_table(219) := 'aker, start_date, end_date, status) values (''Planned / Upcoming Features'',         ''GENERAL'',   ''Sco';
wwv_flow_imp.g_varchar2_table(220) := 'tt Spencer'', to_date(''20160101143000'',''YYYYMMDDHH24MISS''),to_date(''20160101153000'',''YYYYMMDDHH24MISS';
wwv_flow_imp.g_varchar2_table(221) := '''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speaker, start_date, end_da';
wwv_flow_imp.g_varchar2_table(222) := 'te, status) values (''Coffe Break'',                         ''BREAK'',     null,            to_date(''20';
wwv_flow_imp.g_varchar2_table(223) := '160101153000'',''YYYYMMDDHH24MISS''),to_date(''20160101154500'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert ';
wwv_flow_imp.g_varchar2_table(224) := 'into eba_demo_cal_sessions (title, session_type, speaker, start_date, end_date, status) values (''Ask';
wwv_flow_imp.g_varchar2_table(225) := ' the Experts'',                     ''GENERAL'',   ''John Watson'',   to_date(''20160101154500'',''YYYYMMDDH';
wwv_flow_imp.g_varchar2_table(226) := 'H24MISS''),to_date(''20160101170000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessio';
wwv_flow_imp.g_varchar2_table(227) := 'ns (title, session_type, speaker, start_date, end_date, status) values (''Open Mic Night'',           ';
wwv_flow_imp.g_varchar2_table(228) := '           ''GENERAL'',   null,            to_date(''20160101190000'',''YYYYMMDDHH24MISS''),to_date(''20160';
wwv_flow_imp.g_varchar2_table(229) := '101214500'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'                 '||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (ti';
wwv_flow_imp.g_varchar2_table(230) := 'tle, session_type, speaker, start_date, end_date, status) values (''Networking Breakfast'',           ';
wwv_flow_imp.g_varchar2_table(231) := '     ''BREAK'',     null,            to_date(''20160102073000'',''YYYYMMDDHH24MISS''),to_date(''20160102084';
wwv_flow_imp.g_varchar2_table(232) := '500'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speak';
wwv_flow_imp.g_varchar2_table(233) := 'er, start_date, end_date, status) values (''Technical Overview'',                  ''TECHNICAL'', ''Tom S';
wwv_flow_imp.g_varchar2_table(234) := 'uess'',     to_date(''20160102084500'',''YYYYMMDDHH24MISS''),to_date(''20160102094500'',''YYYYMMDDHH24MISS'')';
wwv_flow_imp.g_varchar2_table(235) := ',''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speaker, start_date, end_date';
wwv_flow_imp.g_varchar2_table(236) := ', status) values (''Common Use Cases'',                    ''BUSINESS'',  ''Russ Saunders'', to_date(''2016';
wwv_flow_imp.g_varchar2_table(237) := '0102084500'',''YYYYMMDDHH24MISS''),to_date(''20160102094500'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert in';
wwv_flow_imp.g_varchar2_table(238) := 'to eba_demo_cal_sessions (title, session_type, speaker, start_date, end_date, status) values (''Build';
wwv_flow_imp.g_varchar2_table(239) := 'ing your first Web application'', ''HANDS_ON'',  ''Pam King'',      to_date(''20160102090000'',''YYYYMMDDHH2';
wwv_flow_imp.g_varchar2_table(240) := '4MISS''),to_date(''20160102110000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions';
wwv_flow_imp.g_varchar2_table(241) := ' (title, session_type, speaker, start_date, end_date, status) values (''Installation Tips and Tricks''';
wwv_flow_imp.g_varchar2_table(242) := ',        ''TECHNICAL'', ''Hank Davis'',    to_date(''20160102094500'',''YYYYMMDDHH24MISS''),to_date(''2016010';
wwv_flow_imp.g_varchar2_table(243) := '2104500'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, s';
wwv_flow_imp.g_varchar2_table(244) := 'peaker, start_date, end_date, status) values (''Success Stories'',                     ''BUSINESS'',  ''R';
wwv_flow_imp.g_varchar2_table(245) := 'uss Saunders'', to_date(''20160102094500'',''YYYYMMDDHH24MISS''),to_date(''20160102104500'',''YYYYMMDDHH24MI';
wwv_flow_imp.g_varchar2_table(246) := 'SS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speaker, start_date, end_';
wwv_flow_imp.g_varchar2_table(247) := 'date, status) values (''Coffee Break'',                        ''BREAK'',     null,            to_date(''';
wwv_flow_imp.g_varchar2_table(248) := '20160102104500'',''YYYYMMDDHH24MISS''),to_date(''20160102110000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  inser';
wwv_flow_imp.g_varchar2_table(249) := 't into eba_demo_cal_sessions (title, session_type, speaker, start_date, end_date, status) values (''E';
wwv_flow_imp.g_varchar2_table(250) := 'xpanding with Plug-Ins'',             ''TECHNICAL'', ''Bob Nile'',      to_date(''20160102110000'',''YYYYMMD';
wwv_flow_imp.g_varchar2_table(251) := 'DHH24MISS''),to_date(''20160102120000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sess';
wwv_flow_imp.g_varchar2_table(252) := 'ions (title, session_type, speaker, start_date, end_date, status) values (''Differentiated Data Repor';
wwv_flow_imp.g_varchar2_table(253) := 'ting'',       ''BUSINESS'',  ''Hank Davis'',    to_date(''20160102110000'',''YYYYMMDDHH24MISS''),to_date(''201';
wwv_flow_imp.g_varchar2_table(254) := '60102120000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_typ';
wwv_flow_imp.g_varchar2_table(255) := 'e, speaker, start_date, end_date, status) values (''Lunch'',                               ''BREAK'',   ';
wwv_flow_imp.g_varchar2_table(256) := '  null,            to_date(''20160102120000'',''YYYYMMDDHH24MISS''),to_date(''20160102133000'',''YYYYMMDDHH';
wwv_flow_imp.g_varchar2_table(257) := '24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speaker, start_date, ';
wwv_flow_imp.g_varchar2_table(258) := 'end_date, status) values (''Integrating External Frameworks'',     ''TECHNICAL'', ''Bob Nile'',      to_da';
wwv_flow_imp.g_varchar2_table(259) := 'te(''20160102133000'',''YYYYMMDDHH24MISS''),to_date(''20160102144500'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  i';
wwv_flow_imp.g_varchar2_table(260) := 'nsert into eba_demo_cal_sessions (title, session_type, speaker, start_date, end_date, status) values';
wwv_flow_imp.g_varchar2_table(261) := ' (''From Zero to Hero for the Noob'',      ''TECHNICAL'', ''Myra Sutcliff'', to_date(''20160102133000'',''YYY';
wwv_flow_imp.g_varchar2_table(262) := 'YMMDDHH24MISS''),to_date(''20160102144500'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_';
wwv_flow_imp.g_varchar2_table(263) := 'sessions (title, session_type, speaker, start_date, end_date, status) values (''Mobilizng Apps'',     ';
wwv_flow_imp.g_varchar2_table(264) := '                 ''HANDS_ON'',  ''Pam King'',      to_date(''20160102133000'',''YYYYMMDDHH24MISS''),to_date(';
wwv_flow_imp.g_varchar2_table(265) := '''20160102144500'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session';
wwv_flow_imp.g_varchar2_table(266) := '_type, speaker, start_date, end_date, status) values (''Coffee Break'',                        ''BREAK''';
wwv_flow_imp.g_varchar2_table(267) := ',     null,            to_date(''20160102144500'',''YYYYMMDDHH24MISS''),to_date(''20160102150000'',''YYYYMM';
wwv_flow_imp.g_varchar2_table(268) := 'DDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speaker, start_da';
wwv_flow_imp.g_varchar2_table(269) := 'te, end_date, status) values (''Client-Side Interactivity'',           ''TECHNICAL'', ''Al Bines'',      t';
wwv_flow_imp.g_varchar2_table(270) := 'o_date(''20160102150000'',''YYYYMMDDHH24MISS''),to_date(''20160102160000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );';
wwv_flow_imp.g_varchar2_table(271) := ''||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speaker, start_date, end_date, status) va';
wwv_flow_imp.g_varchar2_table(272) := 'lues (''Showing ROI on your investment'',      ''BUSINESS'',  ''Hank Davis'',    to_date(''20160102150000'',';
wwv_flow_imp.g_varchar2_table(273) := '''YYYYMMDDHH24MISS''),to_date(''20160102160000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(274) := 'cal_sessions (title, session_type, speaker, start_date, end_date, status) values (''Server-Side Logic';
wwv_flow_imp.g_varchar2_table(275) := ' Utilization'',       ''TECHNICAL'', ''Myra Sutcliff'', to_date(''20160102160000'',''YYYYMMDDHH24MISS''),to_d';
wwv_flow_imp.g_varchar2_table(276) := 'ate(''20160102170000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, ses';
wwv_flow_imp.g_varchar2_table(277) := 'sion_type, speaker, start_date, end_date, status) values (''Upselling to C-Level Executives'',     ''BU';
wwv_flow_imp.g_varchar2_table(278) := 'SINESS'',  ''Irene Jones'',   to_date(''20160102160000'',''YYYYMMDDHH24MISS''),to_date(''20160102170000'',''YY';
wwv_flow_imp.g_varchar2_table(279) := 'YYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speaker, star';
wwv_flow_imp.g_varchar2_table(280) := 't_date, end_date, status) values (''Appreciation Event'',                  ''BREAK'',     null,         ';
wwv_flow_imp.g_varchar2_table(281) := '   to_date(''20160102190000'',''YYYYMMDDHH24MISS''),to_date(''20160102223000'',''YYYYMMDDHH24MISS''),''ACTIVE';
wwv_flow_imp.g_varchar2_table(282) := ''' );'||wwv_flow.LF||
'  '||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speaker, start_date, end_date, sta';
wwv_flow_imp.g_varchar2_table(283) := 'tus) values (''Networking Breakfast'',                ''BREAK'',     null,            to_date(''201601030';
wwv_flow_imp.g_varchar2_table(284) := '73000'',''YYYYMMDDHH24MISS''),to_date(''20160103084500'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eb';
wwv_flow_imp.g_varchar2_table(285) := 'a_demo_cal_sessions (title, session_type, speaker, start_date, end_date, status) values (''Upgrading ';
wwv_flow_imp.g_varchar2_table(286) := 'your Apps'',                 ''TECHNICAL'', ''James Cassidy'', to_date(''20160103084500'',''YYYYMMDDHH24MISS';
wwv_flow_imp.g_varchar2_table(287) := '''),to_date(''20160103094500'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (tit';
wwv_flow_imp.g_varchar2_table(288) := 'le, session_type, speaker, start_date, end_date, status) values (''Redevloping Legacy Apps'',         ';
wwv_flow_imp.g_varchar2_table(289) := '    ''BUSINESS'',  ''John Watson'',   to_date(''20160103084500'',''YYYYMMDDHH24MISS''),to_date(''201601030945';
wwv_flow_imp.g_varchar2_table(290) := '00'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speake';
wwv_flow_imp.g_varchar2_table(291) := 'r, start_date, end_date, status) values (''Building an Advanced App'',            ''HANDS_ON'',  ''Pam Ki';
wwv_flow_imp.g_varchar2_table(292) := 'ng'',      to_date(''20160103090000'',''YYYYMMDDHH24MISS''),to_date(''20160103110000'',''YYYYMMDDHH24MISS''),';
wwv_flow_imp.g_varchar2_table(293) := '''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speaker, start_date, end_date,';
wwv_flow_imp.g_varchar2_table(294) := ' status) values (''Application Globalization'',           ''TECHNICAL'', ''Tom Suess'',     to_date(''20160';
wwv_flow_imp.g_varchar2_table(295) := '103094500'',''YYYYMMDDHH24MISS''),to_date(''20160103104500'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert int';
wwv_flow_imp.g_varchar2_table(296) := 'o eba_demo_cal_sessions (title, session_type, speaker, start_date, end_date, status) values (''The im';
wwv_flow_imp.g_varchar2_table(297) := 'portance of UX and UI'',         ''BUSINESS'',  ''Russ Saunders'', to_date(''20160103094500'',''YYYYMMDDHH24';
wwv_flow_imp.g_varchar2_table(298) := 'MISS''),to_date(''20160103104500'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions ';
wwv_flow_imp.g_varchar2_table(299) := '(title, session_type, speaker, start_date, end_date, status) values (''Coffee Break'',                ';
wwv_flow_imp.g_varchar2_table(300) := '        ''BREAK'',     null,            to_date(''20160103104500'',''YYYYMMDDHH24MISS''),to_date(''20160103';
wwv_flow_imp.g_varchar2_table(301) := '110000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, sp';
wwv_flow_imp.g_varchar2_table(302) := 'eaker, start_date, end_date, status) values (''Enhancing Usability'',                 ''TECHNICAL'', ''Ja';
wwv_flow_imp.g_varchar2_table(303) := 'mes Cassidy'', to_date(''20160103110000'',''YYYYMMDDHH24MISS''),to_date(''20160103120000'',''YYYYMMDDHH24MIS';
wwv_flow_imp.g_varchar2_table(304) := 'S''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speaker, start_date, end_d';
wwv_flow_imp.g_varchar2_table(305) := 'ate, status) values (''Why is Accessibility Important?'',     ''BUSINESS'',  ''Scott Spencer'', to_date(''2';
wwv_flow_imp.g_varchar2_table(306) := '0160103110000'',''YYYYMMDDHH24MISS''),to_date(''20160103120000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert';
wwv_flow_imp.g_varchar2_table(307) := ' into eba_demo_cal_sessions (title, session_type, speaker, start_date, end_date, status) values (''Lu';
wwv_flow_imp.g_varchar2_table(308) := 'nch'',                               ''BREAK'',     null,            to_date(''20160103120000'',''YYYYMMDD';
wwv_flow_imp.g_varchar2_table(309) := 'HH24MISS''),to_date(''20160103133000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessi';
wwv_flow_imp.g_varchar2_table(310) := 'ons (title, session_type, speaker, start_date, end_date, status) values (''Vendor Presnetations'',    ';
wwv_flow_imp.g_varchar2_table(311) := '            ''GENERAL'',   null,            to_date(''20160103133000'',''YYYYMMDDHH24MISS''),to_date(''2016';
wwv_flow_imp.g_varchar2_table(312) := '0103144500'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type';
wwv_flow_imp.g_varchar2_table(313) := ', speaker, start_date, end_date, status) values (''Coffee Break'',                        ''BREAK'',    ';
wwv_flow_imp.g_varchar2_table(314) := ' null,            to_date(''20160103144500'',''YYYYMMDDHH24MISS''),to_date(''20160103150000'',''YYYYMMDDHH2';
wwv_flow_imp.g_varchar2_table(315) := '4MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speaker, start_date, e';
wwv_flow_imp.g_varchar2_table(316) := 'nd_date, status) values (''Testing Applications'',                ''TECHNICAL'', ''Al Bines'',      to_dat';
wwv_flow_imp.g_varchar2_table(317) := 'e(''20160103150000'',''YYYYMMDDHH24MISS''),to_date(''20160103160000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  in';
wwv_flow_imp.g_varchar2_table(318) := 'sert into eba_demo_cal_sessions (title, session_type, speaker, start_date, end_date, status) values ';
wwv_flow_imp.g_varchar2_table(319) := '(''The Power of Citizen Developers'',     ''BUSINESS'',  ''Myra Sutcliff'', to_date(''20160103150000'',''YYYY';
wwv_flow_imp.g_varchar2_table(320) := 'MMDDHH24MISS''),to_date(''20160103160000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_s';
wwv_flow_imp.g_varchar2_table(321) := 'essions (title, session_type, speaker, start_date, end_date, status) values (''Upgrading to the Lates';
wwv_flow_imp.g_varchar2_table(322) := 't Version'',     ''HANDS_ON'',  ''Pam King'',      to_date(''20160103150000'',''YYYYMMDDHH24MISS''),to_date(''';
wwv_flow_imp.g_varchar2_table(323) := '20160103160000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_';
wwv_flow_imp.g_varchar2_table(324) := 'type, speaker, start_date, end_date, status) values (''Deploying Applications'',              ''TECHNIC';
wwv_flow_imp.g_varchar2_table(325) := 'AL'', ''Hank Davis'',    to_date(''20160103160000'',''YYYYMMDDHH24MISS''),to_date(''20160103170000'',''YYYYMMD';
wwv_flow_imp.g_varchar2_table(326) := 'DHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  insert into eba_demo_cal_sessions (title, session_type, speaker, start_dat';
wwv_flow_imp.g_varchar2_table(327) := 'e, end_date, status) values (''Managing Agile Development Projects'', ''BUSINESS'',  ''Bob Nile'',      to';
wwv_flow_imp.g_varchar2_table(328) := '_date(''20160103160000'',''YYYYMMDDHH24MISS''),to_date(''20160103170000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(329) := '  insert into eba_demo_cal_sessions (title, session_type, speaker, start_date, end_date, status) val';
wwv_flow_imp.g_varchar2_table(330) := 'ues (''Wowing End Users Easily'',             ''HANDS_ON'',  ''Pam King'',      to_date(''20160103160000'',''';
wwv_flow_imp.g_varchar2_table(331) := 'YYYYMMDDHH24MISS''),to_date(''20160103170000'',''YYYYMMDDHH24MISS''),''ACTIVE'' );'||wwv_flow.LF||
'  '||wwv_flow.LF||
'  update eba_demo_cal';
wwv_flow_imp.g_varchar2_table(332) := '_sessions'||wwv_flow.LF||
'  set start_date = start_date + (trunc(SYSDATE) - TO_DATE(''01012016'',''MMDDYYYY''))'||wwv_flow.LF||
'  ,   en';
wwv_flow_imp.g_varchar2_table(333) := 'd_date = end_date + (trunc(SYSDATE) - TO_DATE(''01012016'',''MMDDYYYY''));'||wwv_flow.LF||
'  '||wwv_flow.LF||
'  delete from eba_demo_cal';
wwv_flow_imp.g_varchar2_table(334) := '_mysessions;'||wwv_flow.LF||
''||wwv_flow.LF||
'end EBA_DEMO_CAL_DATA;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  EBA_DEMO_CAL_DATA;'||wwv_flow.LF||
'  commit;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2579259408096529312)
,p_install_id=>wwv_flow_imp.id(2575266633949852551)
,p_name=>'insert data'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
