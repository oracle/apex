prompt --application/shared_components/navigation/lists/calendar_styling
begin
--   Manifest
--     LIST: Calendar Styling
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>4421054519883540
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(792142473996102806)
,p_name=>'Calendar Styling'
,p_static_id=>'calendar-styling'
,p_version_scn=>'1089078457'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(792142716223102806)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Custom CSS Classes'
,p_static_id=>'custom-css-classes'
,p_list_item_link_target=>'f?p=&APP_ID.:91:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-paint-brush'
,p_list_text_01=>'This page shows custom styling of calendar events using your own CSS classes.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(792143042701102807)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Custom Event Icons'
,p_static_id=>'custom-event-icons'
,p_list_item_link_target=>'f?p=&APP_ID.:92:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-square-o'
,p_list_text_01=>'Add custom icons to your calendar events. '
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
