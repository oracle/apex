prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>4421054519883540
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(8203235651002693333)
,p_name=>' Breadcrumb'
,p_static_id=>'breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1872361547547655859)
,p_short_name=>'Administration'
,p_static_id=>'administration'
,p_link=>'f?p=&APP_ID.:15:&SESSION.'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1871880064607171610)
,p_parent_id=>wwv_flow_imp.id(1872361547547655859)
,p_short_name=>'Application Theme Style'
,p_static_id=>'application-theme-style'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792110395339749545)
,p_parent_id=>wwv_flow_imp.id(792135872441042661)
,p_short_name=>'Calendar and Report'
,p_static_id=>'calendar-and-report'
,p_link=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:::'
,p_page_id=>51
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792111410472759117)
,p_parent_id=>wwv_flow_imp.id(792142013461093262)
,p_short_name=>'Calendar Client Events'
,p_static_id=>'calendar-client-events'
,p_link=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:::'
,p_page_id=>73
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2580184435815657245)
,p_short_name=>'Calendar Entry'
,p_static_id=>'calendar-entry'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792146037597125339)
,p_short_name=>'Calendar Styling'
,p_static_id=>'calendar-styling'
,p_link=>'f?p=&APP_ID.:90:&SESSION.::&DEBUG.:::'
,p_page_id=>90
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792142013461093262)
,p_short_name=>'Calendars and Javascript'
,p_static_id=>'calendars-and-javascript'
,p_link=>'f?p=&APP_ID.:70:&SESSION.::&DEBUG.:::'
,p_page_id=>70
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792167133065360581)
,p_parent_id=>wwv_flow_imp.id(792135872441042661)
,p_short_name=>'Copy Events By Click'
,p_static_id=>'copy-events-by-click'
,p_link=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.:::'
,p_page_id=>54
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792110565486751307)
,p_parent_id=>wwv_flow_imp.id(792135872441042661)
,p_short_name=>'Create Calendar Events'
,p_static_id=>'create-calendar-events'
,p_link=>'f?p=&APP_ID.:52:&SESSION.::&DEBUG.:::'
,p_page_id=>52
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(849920391402330917)
,p_short_name=>'Custom Calendar Initialization'
,p_static_id=>'custom-calendar-initialization'
,p_link=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:::'
,p_page_id=>110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792111538875761455)
,p_parent_id=>wwv_flow_imp.id(792146037597125339)
,p_short_name=>'Custom CSS Classes'
,p_static_id=>'custom-css-classes'
,p_link=>'f?p=&APP_ID.:91:&SESSION.::&DEBUG.:::'
,p_page_id=>91
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(827320903115689349)
,p_parent_id=>wwv_flow_imp.id(792135872441042661)
,p_short_name=>'Custom Drag and Drop Handlers'
,p_static_id=>'custom-drag-and-drop-handlers'
,p_link=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:::'
,p_page_id=>112
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792111778518763131)
,p_parent_id=>wwv_flow_imp.id(792146037597125339)
,p_short_name=>'Custom Event Icons'
,p_static_id=>'custom-event-icons'
,p_link=>'f?p=&APP_ID.:92:&SESSION.::&DEBUG.:::'
,p_page_id=>92
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792110989559755795)
,p_parent_id=>wwv_flow_imp.id(792142013461093262)
,p_short_name=>'Custom Navigation'
,p_static_id=>'custom-navigation'
,p_link=>'f?p=&APP_ID.:71:&SESSION.::&DEBUG.:::'
,p_page_id=>71
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(849920624547334182)
,p_parent_id=>wwv_flow_imp.id(849920391402330917)
,p_short_name=>'Custom weekly schedule'
,p_static_id=>'custom-weekly-schedule'
,p_link=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:::'
,p_page_id=>111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792110791423753472)
,p_parent_id=>wwv_flow_imp.id(792135872441042661)
,p_short_name=>'Delete Events By Click'
,p_static_id=>'delete-events-by-click'
,p_link=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.:::'
,p_page_id=>53
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792135872441042661)
,p_short_name=>'Dynamic Action Examples'
,p_static_id=>'dynamic-action-examples'
,p_link=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:::'
,p_page_id=>50
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(618974227183616392)
,p_parent_id=>wwv_flow_imp.id(792130824362979533)
,p_short_name=>'Faceted Search: Projects'
,p_static_id=>'faceted-search-projects'
,p_link=>'f?p=&APP_ID.:36:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>36
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3250105026741727150)
,p_short_name=>'Help'
,p_static_id=>'help'
,p_link=>'f?p=&FLOW_ID.:12:&SESSION.'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8203236062850693336)
,p_short_name=>'Home'
,p_static_id=>'home'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2593316114903579586)
,p_parent_id=>wwv_flow_imp.id(1872361547547655859)
,p_short_name=>'Manage Sample Data'
,p_static_id=>'manage-sample-data'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313038235243414450)
,p_short_name=>'Mini Calendar'
,p_static_id=>'mini-calendar'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792109320338728935)
,p_parent_id=>wwv_flow_imp.id(792130824362979533)
,p_short_name=>'Monthly Calendar: Projects'
,p_static_id=>'monthly-calendar-projects'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313038908406414454)
,p_parent_id=>wwv_flow_imp.id(1313038235243414450)
,p_short_name=>'&P14_PROJECT.'
,p_static_id=>'p14-project'
,p_link=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:::'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2660652539206216527)
,p_parent_id=>wwv_flow_imp.id(2660652209530216526)
,p_short_name=>'Project Detail'
,p_static_id=>'project-detail'
,p_link=>'f?p=&FLOW_ID.:10:&SESSION.'
,p_page_id=>10
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2660652209530216526)
,p_short_name=>'Project Due Dates'
,p_static_id=>'project-due-dates'
,p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792111144736757995)
,p_parent_id=>wwv_flow_imp.id(792142013461093262)
,p_short_name=>'Query Calendar Status'
,p_static_id=>'query-calendar-status'
,p_link=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.:::'
,p_page_id=>72
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2594927816596799506)
,p_parent_id=>wwv_flow_imp.id(2593316114903579586)
,p_short_name=>'Report'
,p_static_id=>'report'
,p_link=>'f?p=&APP_ID.:7:&SESSION.'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(895011229699432934)
,p_parent_id=>wwv_flow_imp.id(792142013461093262)
,p_short_name=>'Schedule Builder'
,p_static_id=>'schedule-builder'
,p_link=>'f?p=&FLOW_ID.:74:&SESSION.'
,p_page_id=>74
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792130824362979533)
,p_short_name=>'Standard Calendars'
,p_static_id=>'standard-calendars'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2580593112347740786)
,p_short_name=>'Time Line'
,p_static_id=>'time-line'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792109556912740780)
,p_parent_id=>wwv_flow_imp.id(792130824362979533)
,p_short_name=>'Weekly Calendar: Conference'
,p_static_id=>'weekly-calendar-conference'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792109964990744527)
,p_parent_id=>wwv_flow_imp.id(792130824362979533)
,p_short_name=>'Weekly Calendar: Drag & Drop'
,p_static_id=>'weekly-calendar-drag-drop'
,p_link=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:::'
,p_page_id=>34
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792109758250742823)
,p_parent_id=>wwv_flow_imp.id(792130824362979533)
,p_short_name=>'Weekly Calendar: Edit Sessions'
,p_static_id=>'weekly-calendar-edit-sessions'
,p_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
,p_page_id=>33
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(792110143494745692)
,p_parent_id=>wwv_flow_imp.id(792130824362979533)
,p_short_name=>'Weekly Calendar: Time Format'
,p_static_id=>'weekly-calendar-time-format'
,p_link=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:::'
,p_page_id=>35
);
wwv_flow_imp.component_end;
end;
/
