prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7820
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>4421054519883540
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3175280217820753313)
,p_name=>'ADMINISTRATION'
,p_message_text=>'Administration'
,p_version_scn=>'37166093867993'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2577965435005404623)
,p_name=>'HELP'
,p_message_text=>'Help'
,p_version_scn=>'37166093867993'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2577957432928404003)
,p_name=>'LOGOUT'
,p_message_text=>'Logout'
,p_version_scn=>'37166093867993'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2686048933097880540)
,p_name=>'USER'
,p_message_text=>'User'
,p_version_scn=>'37166093867993'
);
wwv_flow_imp.component_end;
end;
/
