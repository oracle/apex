prompt --application/shared_components/user_interface/lovs/distinct_projects
begin
--   Manifest
--     DISTINCT PROJECTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>4421054519883540
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2582001537793906958)
,p_lov_name=>'DISTINCT PROJECTS'
,p_static_id=>'distinct-projects'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select project || '' ('' || count(*) ||'' tasks from '' || to_char(min(start_date),''Mon RR'') ||'' to '' ||to_char(max(start_date), ''Mon RR'')||'')'' d, project r',
'from eba_demo_cal_projects',
'group by project',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'1089078457'
);
wwv_flow_imp.component_end;
end;
/
