prompt --application/pages/page_00091
begin
--   Manifest
--     PAGE: 00091
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7820
,p_default_id_offset=>4421054519883540
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>91
,p_name=>'Week Calendar: Conference'
,p_alias=>'WEEK-CALENDAR-CONFERENCE2'
,p_step_title=>'Week Calendar: Conference'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.fc-event .fc-content div.fc-time { display: none;}',
'',
'.fc-event.my-cal-blue {',
'    background-color: lightblue;',
'    border: 0.5pt solid black;',
'    opacity: 0.7;',
'}',
'',
'.fc-event.my-cal-blue .fc-event-title {',
'    color: darkblue;',
'    font-weight: bold;',
'}',
'',
'.fc-event.my-cal-orange {',
'    background-color: orange;',
'    border: 0.5pt solid black;',
'    opacity: 0.7;',
'}',
'',
'.fc-event.my-cal-orange .fc-title {',
'    color: darkred;',
'    font-weight: bold;',
'}',
'',
'.fc-event.my-cal-dark-orange {',
'    background-color: #8B5A00;',
'    border: 0.5pt solid black;',
'    opacity: 0.7;',
'}',
'',
'.fc-event.my-cal-dark-orange .fc-title {',
'    color: white;',
'    font-weight: bold;',
'}',
'',
'.fc-event.my-cal-white {',
'    background-color: white;',
'    border: 0.5pt solid black;',
'    opacity: 0.7;',
'}',
'',
'.fc-event.my-cal-white .fc-title {',
'    color: black;',
'    font-weight: bold;',
'}',
'',
'.fc-event.my-cal-green {',
'    background-color: lightgreen;',
'    border: 0.5pt solid black;',
'    opacity: 0.7;',
'}',
'',
'.fc-event.my-cal-green .fc-title {',
'    color: darkgreen;',
'    font-weight: bold;',
'}',
''))
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'08'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3252822230589003278)
,p_plug_name=>'About this page'
,p_static_id=>'about-this-page'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page shows custom styling of calendar events using own CSS classes. Define your CSS classes (e.g. in the page attribute <b>CSS - Inline</b>) and use them as the <b>CSS_CLASS</b> column in your SQL query. An example CSS class definition (setti'
||'ng a light-blue background with black border and a dark-blue, bold font) looks as follows.</p>',
'<pre>',
'.fc-event.my-cal-blue {',
'    background-color: lightblue;',
'    border: 0.5pt solid black;',
'    opacity: 0.7;',
'}',
'',
'.fc-event.my-cal-blue .fc-event-title {',
'    color: darkblue;',
'    font-weight: bold;',
'}',
'</pre>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(792089243124540605)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(8203235651002693333)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3252823362399003284)
,p_plug_name=>'Sessions'
,p_static_id=>'sessions'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--hiddenOverflow'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'   id,',
'   case when speaker is not null then ',
'       title || '' ('' || speaker || '')'' ',
'       else title',
'   end as title,',
'   speaker,',
'   start_date,',
'   end_date,',
'   case',
'      when session_type = ''BREAK''    then ''my-cal-green''',
'      when session_type = ''BUSINESS'' then ''my-cal-blue''',
'      when session_type = ''GENERAL''  then ''my-cal-white''',
'      when session_type = ''TECHNICAL'' then ''my-cal-orange''',
'      when session_type = ''HANDS_ON'' then ''my-cal-dark-orange''',
'   end as css_class',
'from eba_demo_cal_sessions',
'where status=''ACTIVE''',
''))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function ( pOptions) {',
'    pOptions.slotMinTime      = "07:00:00";                               // hide slots before minTime',
'    pOptions.slotMaxTime      = "18:00:00";                               // hide slots after maxTime',
'    pOptions.slotDuration     = "00:15:00";                               // custom slot duration',
'    return pOptions;',
'}',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'calendar_views_and_navigation', 'week:day:list:navigation',
  'css_class', 'CSS_CLASS',
  'display_column', 'TITLE',
  'end_date_column', 'END_DATE',
  'event_sorting', 'AUTOMATIC',
  'first_hour', '9',
  'maximum_events_day', '10',
  'multiple_line_event', 'Y',
  'responsive_list_view', 'Y',
  'show_time', 'Y',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'START_DATE',
  'time_format', '00')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(788339999394928099)
,p_name=>'Change Project - Refresh Calendar'
,p_static_id=>'change-project-refresh-calendar'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P91_PROJECTS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(788340498748928105)
,p_event_id=>wwv_flow_imp.id(788339999394928099)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3252823362399003284)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
