prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>1658580677483859081
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>18
,p_name=>'Load Status'
,p_alias=>'LOAD-STATUS'
,p_step_title=>'Load Status'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_upd_yyyymmddhh24miss=>'20220823161416'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1665842802504216320)
,p_plug_name=>'Timer Container'
,p_region_name=>'timer-container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3417064373541605810)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1668634519172411291)
,p_name=>'Load Error'
,p_region_name=>'loadError'
,p_template=>wwv_flow_imp.id(3417074881209605828)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--horizontalBorders:t-Report--hideNoPagination'
,p_region_attributes=>'style="display:none;"'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select n001 row_number, c001 error_message',
'   from apex_collections',
' where collection_name = ''SALES_DATA_LOAD_ERR'';'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3417084559652605852)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1668634571248411292)
,p_query_column_id=>1
,p_column_alias=>'ROW_NUMBER'
,p_column_display_sequence=>10
,p_column_heading=>'Row Number'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1668634725988411293)
,p_query_column_id=>2
,p_column_alias=>'ERROR_MESSAGE'
,p_column_display_sequence=>20
,p_column_heading=>'Error Message'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(2495483046832301653)
,p_name=>'Load Status'
,p_region_name=>'loadStatus'
,p_template=>wwv_flow_imp.id(3417074881209605828)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--xlarge:t-BadgeList--circular:t-BadgeList--fixed'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c001 as status,',
'       n001 as rows_processed,',
'       n002 as rows_with_error',
'from apex_collections ',
'where collection_name = :P17_STATUS_COLLECTION'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(3417079215097605838)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1666671245168890028)
,p_query_column_id=>1
,p_column_alias=>'STATUS'
,p_column_display_sequence=>10
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(1667151537928092877)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1666671635955890026)
,p_query_column_id=>2
,p_column_alias=>'ROWS_PROCESSED'
,p_column_display_sequence=>20
,p_column_heading=>'Rows Processed'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1665842747763216319)
,p_query_column_id=>3
,p_column_alias=>'ROWS_WITH_ERROR'
,p_column_display_sequence=>30
,p_column_heading=>'Rows With Error'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P18_LOAD_STATUS'
,p_display_when_condition2=>'FAILED'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2543937110353148235)
,p_plug_name=>'Sales'
,p_region_name=>'sales'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(3417070866510605821)
,p_plug_display_sequence=>40
,p_query_type=>'TABLE'
,p_query_table=>'EBA_DEMO_LOAD_SALES'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Sales'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1667237154502275698)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No sales data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'CBCHO'
,p_internal_uid=>830208900339471008
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667237314872275699)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667237427249275700)
,p_db_column_name=>'REGION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Region'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667237516510275701)
,p_db_column_name=>'COUNTRY'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Country'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667237622488275702)
,p_db_column_name=>'ITEM_TYPE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Item Type'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667237691899275703)
,p_db_column_name=>'SALES_CHANNEL'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Sales Channel'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667237812166275704)
,p_db_column_name=>'ORDER_PRIORITY'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Order Priority'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667237870221275705)
,p_db_column_name=>'ORDER_DATE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Order Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667237993654275706)
,p_db_column_name=>'ORDER_ID'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Order Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667238100818275707)
,p_db_column_name=>'SHIP_DATE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Ship Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667238167780275708)
,p_db_column_name=>'UNITS_SOLD'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Units Sold'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667238273203275709)
,p_db_column_name=>'UNIT_PRICE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Unit Price'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667238366190275710)
,p_db_column_name=>'UNIT_COST'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Unit Cost'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667238487076275711)
,p_db_column_name=>'TOTAL_REVENUE'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Total Revenue'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667238620091275712)
,p_db_column_name=>'TOTAL_COST'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Total Cost'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667238726697275713)
,p_db_column_name=>'TOTAL_PROFIT'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Total Profit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667238819712275714)
,p_db_column_name=>'CREATED'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1667238901856275715)
,p_db_column_name=>'LAST_UPDATED'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Last Updated'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1667265132737047248)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8302369'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'REGION:COUNTRY:ITEM_TYPE:SALES_CHANNEL:ORDER_PRIORITY:UNITS_SOLD:UNIT_PRICE:UNIT_COST:TOTAL_PROFIT:LAST_UPDATED:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4997401499128892920)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(3417077481154605831)
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(9852204960688511480)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(3417098360065605892)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1665843583059216328)
,p_name=>'P18_STATUS_COLLECTION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2495483046832301653)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1666671977628890020)
,p_name=>'P18_LOAD_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2495483046832301653)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1666672407136890009)
,p_name=>'P18_PROCESSED_ROW_CNT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2495483046832301653)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1666672832168890009)
,p_name=>'P18_ERROR_ROW_CNT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2495483046832301653)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1665842929482216321)
,p_name=>'Refresh Load Status on Timer'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#timer-container'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'job_timer'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1666680650331882300)
,p_event_id=>wwv_flow_imp.id(1665842929482216321)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_job_is_running boolean := false;',
'begin',
'    --',
'    -- Step 1: Determine whether the scheduler job is running',
'    --',
'    for j in (',
'        select 1',
'          from sys.user_scheduler_jobs',
'         where job_name like ''DATA_LOAD$%''',
'           and regexp_substr( comments, ''(\:)(.*?)(\:)'',1,5,''i'',2 ) = :P17_STATUS_COLLECTION',
'           and state    = ''RUNNING'' ',
'           and rownum   = 1 )',
'    loop',
'        l_job_is_running := true;',
'    end loop;',
'',
'    --',
'    -- Step 2: Determine the current status from the status collection',
'    --',
'    for l_load in (',
'        select seq_id,',
'               c001 as status,',
'               n001 as processed_rows, ',
'               n002 as error_rows',
'        from apex_collections ',
'        where collection_name = :P17_STATUS_COLLECTION )',
'    loop',
'        :P18_LOAD_STATUS       := l_load.status;',
'        :P18_PROCESSED_ROW_CNT := l_load.processed_rows;',
'        :P18_ERROR_ROW_CNT     := l_load.error_rows;',
'',
'        -- if load is running, get committed row so far',
'        if l_load.status = ''RUNNING'' then',
'            select count(*)',
'            into :P18_PROCESSED_ROW_CNT',
'            from EBA_DEMO_LOAD_SALES;',
'',
'            apex_collection.update_member_attribute(',
'                p_collection_name => :P17_STATUS_COLLECTION,',
'                p_seq             => l_load.seq_id,',
'                p_attr_number     => 1,',
'                p_number_value    => :P18_PROCESSED_ROW_CNT );',
'        end if;',
'    end loop;',
'',
'    if :P18_LOAD_STATUS is null and not l_job_is_running then',
'        :P18_LOAD_STATUS := ''FAILED'';',
'        :P18_PROCESSED_ROW_CNT := 0;',
'        :P18_ERROR_ROW_CNT     := 0;',
'    end if;',
'',
'end;'))
,p_attribute_03=>'P18_LOAD_STATUS,P18_PROCESSED_ROW_CNT,P18_ERROR_ROW_CNT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1665843208440216324)
,p_name=>'Refresh Load Status Timer'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1665843315587216325)
,p_event_id=>wwv_flow_imp.id(1665843208440216324)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lSpinner$ = apex.util.showSpinner( $( "#loadStatus" ) );',
'',
'var triggerRefresh = function(){ ',
'    var lstatus = apex.item("P18_LOAD_STATUS").getValue() ?? "STARTED";',
'    var lprocessedCnt = apex.item("P18_PROCESSED_ROW_CNT").getValue();',
'',
'    apex.event.trigger( apex.jQuery("#timer-container"), "job_timer" );',
'',
'    console.log( "current satus " + lstatus );',
'    console.log( "processed so far " + lprocessedCnt );',
'',
'    if (  lstatus === ''FINISHED''  || ',
'          lstatus === ''FAILED'' ) {',
'      apex.region( "loadStatus" ).refresh();',
'      apex.region( "sales" ).refresh();',
'      ',
'      if ( lstatus === ''FAILED'' ) {',
'          apex.region( "loadError" ).element.show();',
'          apex.region( "loadError" ).refresh();',
'      }',
'',
'      clearInterval( refreshInterval );',
'      lSpinner$.remove();',
'    } else {',
'      apex.region( "loadStatus" ).refresh();',
'      apex.region( "sales" ).refresh(); ',
'    }',
'};',
'',
'var refreshInterval = setInterval( triggerRefresh, 1000);'))
);
wwv_flow_imp.component_end;
end;
/
