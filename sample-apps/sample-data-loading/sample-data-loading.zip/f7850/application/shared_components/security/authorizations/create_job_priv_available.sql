prompt --application/shared_components/security/authorizations/create_job_priv_available
begin
--   Manifest
--     SECURITY SCHEME: CREATE JOB priv available
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>11008923455465249
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(3338778276393463645)
,p_name=>'CREATE JOB priv available'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attribute_01=>'select 1 from session_privs where privilege = ''CREATE JOB'''
,p_error_message=>'CREATE JOB privilege is not available.'
,p_version_scn=>1089079098
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
