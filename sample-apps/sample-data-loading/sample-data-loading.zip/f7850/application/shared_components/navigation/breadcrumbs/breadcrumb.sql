prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>1658580677483859081
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(11510785638172370561)
,p_name=>' Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3327796762825829369)
,p_short_name=>'Data Loading'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3327799327948802916)
,p_parent_id=>wwv_flow_imp.id(3327796762825829369)
,p_short_name=>'CSV Load'
,p_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_page_id=>11
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3327800076945789817)
,p_parent_id=>wwv_flow_imp.id(3327796762825829369)
,p_short_name=>'Transformation and Lookup'
,p_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3327800556296783639)
,p_parent_id=>wwv_flow_imp.id(3327796762825829369)
,p_short_name=>'Multiple File Types Load'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3327801325066776551)
,p_parent_id=>wwv_flow_imp.id(3327796762825829369)
,p_short_name=>'Background Load'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3327801792330771965)
,p_parent_id=>wwv_flow_imp.id(3327801325066776551)
,p_short_name=>'Load Status'
,p_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3327802716407758713)
,p_short_name=>'Manual Data Loading'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3523401952729623178)
,p_parent_id=>wwv_flow_imp.id(3327802716407758713)
,p_short_name=>'PL/SQL Parser'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3523421697814870644)
,p_parent_id=>wwv_flow_imp.id(3327802716407758713)
,p_short_name=>'Load Data using PL/SQL API'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4329557622278346758)
,p_parent_id=>wwv_flow_imp.id(3327796762825829369)
,p_short_name=>'Load Employees'
,p_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4329558014307352688)
,p_parent_id=>wwv_flow_imp.id(4329557622278346758)
,p_short_name=>'Column Mapping'
,p_link=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:::'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4329559788587357615)
,p_parent_id=>wwv_flow_imp.id(4329557622278346758)
,p_short_name=>'Data Validation'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4329560274138360027)
,p_parent_id=>wwv_flow_imp.id(4329557622278346758)
,p_short_name=>'Data Load Results'
,p_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:::'
,p_page_id=>24
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5444167398892758354)
,p_parent_id=>wwv_flow_imp.id(5460628651244318006)
,p_short_name=>'Application Theme Style'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5460628651244318006)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:9:&SESSION.'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6557507020673544417)
,p_parent_id=>wwv_flow_imp.id(11510786050020370564)
,p_short_name=>'Help'
,p_link=>'f?p=&FLOW_ID.:6:&SESSION.'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6559331714110935184)
,p_parent_id=>wwv_flow_imp.id(5460628651244318006)
,p_short_name=>'Reset Data'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11510786050020370564)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp.component_end;
end;
/
