prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>11008923455465249
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(11521794561627835810)
,p_name=>' Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3338805686281294618)
,p_short_name=>'Data Loading'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3338808251404268165)
,p_parent_id=>wwv_flow_imp.id(3338805686281294618)
,p_short_name=>'CSV Load'
,p_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_page_id=>11
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3338809000401255066)
,p_parent_id=>wwv_flow_imp.id(3338805686281294618)
,p_short_name=>'Transformation and Lookup'
,p_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3338809479752248888)
,p_parent_id=>wwv_flow_imp.id(3338805686281294618)
,p_short_name=>'Multiple File Types Load'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3338810248522241800)
,p_parent_id=>wwv_flow_imp.id(3338805686281294618)
,p_short_name=>'Background Load'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3338810715786237214)
,p_parent_id=>wwv_flow_imp.id(3338810248522241800)
,p_short_name=>'Load Status'
,p_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3338811639863223962)
,p_short_name=>'Manual Data Loading'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3534410876185088427)
,p_parent_id=>wwv_flow_imp.id(3338811639863223962)
,p_short_name=>'PL/SQL Parser'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3534430621270335893)
,p_parent_id=>wwv_flow_imp.id(3338811639863223962)
,p_short_name=>'Load Data using PL/SQL API'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4340566545733812007)
,p_parent_id=>wwv_flow_imp.id(3338805686281294618)
,p_short_name=>'Load Employees'
,p_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4340566937762817937)
,p_parent_id=>wwv_flow_imp.id(4340566545733812007)
,p_short_name=>'Column Mapping'
,p_link=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:::'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4340568712042822864)
,p_parent_id=>wwv_flow_imp.id(4340566545733812007)
,p_short_name=>'Data Validation'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4340569197593825276)
,p_parent_id=>wwv_flow_imp.id(4340566545733812007)
,p_short_name=>'Data Load Results'
,p_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:::'
,p_page_id=>24
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5455176322348223603)
,p_parent_id=>wwv_flow_imp.id(5471637574699783255)
,p_short_name=>'Application Theme Style'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5471637574699783255)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:9:&SESSION.'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6568515944129009666)
,p_parent_id=>wwv_flow_imp.id(11521794973475835813)
,p_short_name=>'Help'
,p_link=>'f?p=&FLOW_ID.:6:&SESSION.'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6570340637566400433)
,p_parent_id=>wwv_flow_imp.id(5471637574699783255)
,p_short_name=>'Reset Data'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11521794973475835813)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp.component_end;
end;
/
