prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>1658580677483859081
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_menu(
 p_id=>wwv_flow_api.id(9852204960688511480)
,p_name=>' Breadcrumb'
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1669216085341970288)
,p_parent_id=>0
,p_short_name=>'Data Loading'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1669218650464943835)
,p_parent_id=>wwv_flow_api.id(1669216085341970288)
,p_short_name=>'CSV Load'
,p_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_page_id=>11
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1669219399461930736)
,p_parent_id=>wwv_flow_api.id(1669216085341970288)
,p_short_name=>'Transformation and Lookup'
,p_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1669219878812924558)
,p_parent_id=>wwv_flow_api.id(1669216085341970288)
,p_short_name=>'Multiple File Types Load'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1669220647582917470)
,p_parent_id=>wwv_flow_api.id(1669216085341970288)
,p_short_name=>'Background Load'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17::'
,p_page_id=>17
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1669221114846912884)
,p_parent_id=>wwv_flow_api.id(1669220647582917470)
,p_short_name=>'Load Status'
,p_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1669222038923899632)
,p_parent_id=>0
,p_short_name=>'Manual Data Loading'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1864821275245764097)
,p_parent_id=>wwv_flow_api.id(1669222038923899632)
,p_short_name=>'PL/SQL Parser'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1864841020331011563)
,p_parent_id=>wwv_flow_api.id(1669222038923899632)
,p_short_name=>'Load Data using PL/SQL API'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2670976944794487677)
,p_parent_id=>wwv_flow_api.id(1669216085341970288)
,p_short_name=>'Load Employees'
,p_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::'
,p_page_id=>21
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2670977336823493607)
,p_parent_id=>wwv_flow_api.id(2670976944794487677)
,p_short_name=>'Column Mapping'
,p_link=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:::'
,p_page_id=>22
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2670979111103498534)
,p_parent_id=>wwv_flow_api.id(2670976944794487677)
,p_short_name=>'Data Validation'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2670979596654500946)
,p_parent_id=>wwv_flow_api.id(2670976944794487677)
,p_short_name=>'Data Load Results'
,p_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:::'
,p_page_id=>24
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(3785586721408899273)
,p_parent_id=>wwv_flow_api.id(3802047973760458925)
,p_short_name=>'Application Theme Style'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(3802047973760458925)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:9:&SESSION.'
,p_page_id=>9
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(4898926343189685336)
,p_parent_id=>wwv_flow_api.id(9852205372536511483)
,p_short_name=>'Help'
,p_link=>'f?p=&FLOW_ID.:6:&SESSION.'
,p_page_id=>6
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(4900751036627076103)
,p_parent_id=>wwv_flow_api.id(3802047973760458925)
,p_short_name=>'Reset Data'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(9852205372536511483)
,p_parent_id=>0
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_api.component_end;
end;
/
