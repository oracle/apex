prompt --application/shared_components/navigation/lists/data_load_examples
begin
--   Manifest
--     LIST: Data Load Examples
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(206296648582453383)
,p_name=>'Data Load Examples'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(206297251290453385)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Parse Files (PL/SQL)'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31:::'
,p_list_item_icon=>'fa-file-text-o'
,p_list_text_01=>'Use the APEX_DATA_PARSER.PARSE table function to parse an XML, XLSX, CSV or JSON file and to review data in an APEX report. All done on-the-fly, no data is stored.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'31'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(206297643750453386)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Load Data (PL/SQL)'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:32:::'
,p_list_item_icon=>'fa-database-arrow-up'
,p_list_text_01=>'Use a SQL INSERT statement in combination with the APEX_DATA_PARSER.PARSE table function to upload a file directly into a table - as a one-step operation.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'32'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(206298041145453386)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Data Loading Wizard'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-wizard'
,p_list_text_01=>'Load data using the APEX Data Loading Wizard. Upload a file and allow end users to specify column mappings individually.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'21'
);
wwv_flow_api.component_end;
end;
/
