prompt --application/shared_components/navigation/lists/data_load_process_train_load_employees
begin
--   Manifest
--     LIST: Data Load Process Train - Load Employees
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(2178555521513205250)
,p_name=>'Data Load Process Train - Load Employees'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.component_end;
end;
/
