prompt --application/shared_components/navigation/lists/data_load_process_train_load_employees
begin
--   Manifest
--     LIST: Data Load Process Train - Load Employees
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>1658580677483859081
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3837136198997064331)
,p_name=>'Data Load Process Train - Load Employees'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp.component_end;
end;
/
