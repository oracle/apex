prompt --application/shared_components/navigation/lists/data_loading
begin
--   Manifest
--     LIST: Data Loading
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>1658580677483859081
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3317208713883250855)
,p_name=>'Data Loading'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3317208851589250856)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'CSV Load'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:11:::'
,p_list_item_icon=>'fa-file-csv'
,p_list_text_01=>'Upload or copy and paste CSV data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3317210527389250857)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Transformation and Lookup'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15:::'
,p_list_item_icon=>'fa-dynamic-content'
,p_list_text_01=>'Define <strong>Transformation Rules</strong> and <strong>Lookups</strong> to convert the data when loading.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3318409943376038368)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Multiple File Types Load'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:16:::'
,p_list_item_icon=>'fa-files-o'
,p_list_text_01=>'Use <strong>APEX_DATA_LOADING</strong> package to support loading multiple file types.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3325729424067134886)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Background Loading'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17:::'
,p_list_item_icon=>'fa-clock-o'
,p_list_text_01=>'For a large data load, use the <strong>Execution Chain</strong> process type to perform loading in the background.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3327776068190967083)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Legacy Data Loading'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-archive'
,p_list_text_01=>'Allow end users to specify column mappings using the <strong>Legacy Data Loading Wizard</strong>.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
