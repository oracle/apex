prompt --application/shared_components/navigation/lists/data_loading
begin
--   Manifest
--     LIST: Data Loading
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>11008923455465249
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3328217637338716104)
,p_name=>'Data Loading'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089079098
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3328217775044716105)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'CSV Load'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:11:::'
,p_list_item_icon=>'fa-file-csv'
,p_list_text_01=>'Upload or copy and paste CSV data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3328219450844716106)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Transformation and Lookup'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15:::'
,p_list_item_icon=>'fa-dynamic-content'
,p_list_text_01=>'Define <strong>Transformation Rules</strong> and <strong>Lookups</strong> to convert the data when loading.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3329418866831503617)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Multiple File Types Load'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:16:::'
,p_list_item_icon=>'fa-files-o'
,p_list_text_01=>'Use <strong>APEX_DATA_LOADING</strong> package to support loading multiple file types.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3336738347522600135)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Background Loading'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17:::'
,p_list_item_icon=>'fa-clock-o'
,p_list_text_01=>'For a large data load, use the <strong>Execution Chain</strong> process type to perform loading in the background.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3338784991646432332)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Legacy Data Loading'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-archive'
,p_list_text_01=>'Allow end users to specify column mappings using the <strong>Legacy Data Loading Wizard</strong>.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
