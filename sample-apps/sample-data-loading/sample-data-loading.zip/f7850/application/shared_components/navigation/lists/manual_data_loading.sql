prompt --application/shared_components/navigation/lists/manual_data_loading
begin
--   Manifest
--     LIST: Manual Data Loading
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>1658580677483859081
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1658619331230181551)
,p_name=>'Manual Data Loading'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1658619507389181552)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'PL/SQL Parser'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-sql'
,p_list_text_01=>'Parse uploaded file and discover the columns manually using APEX_DATA_PARSER package.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1658619854454181554)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'PL/SQL Load'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-upload'
,p_list_text_01=>'Use a SQL INSERT statement in combination with the APEX_DATA_PARSER.PARSE table function to upload a file directly into a table.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
