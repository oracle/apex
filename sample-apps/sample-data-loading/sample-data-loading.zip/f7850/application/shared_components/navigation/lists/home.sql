prompt --application/shared_components/navigation/lists/home
begin
--   Manifest
--     LIST: Home
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>1658580677483859081
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3523458003550171545)
,p_name=>'Home'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3317170821419815933)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Data Loading'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database-arrow-up'
,p_list_text_01=>'Load data using declarative data loading process type.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3523458998718171548)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Manual Data Loading'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:32:::'
,p_list_item_icon=>'fa-wrench'
,p_list_text_01=>'Parse upload data manually using APEX_DATA_PARSER package and upload the data maually with DML.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'32'
);
wwv_flow_imp.component_end;
end;
/
