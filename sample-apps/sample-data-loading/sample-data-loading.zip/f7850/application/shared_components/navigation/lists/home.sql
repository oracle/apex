prompt --application/shared_components/navigation/lists/home
begin
--   Manifest
--     LIST: Home
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>1658580677483859081
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1864877326066312464)
,p_name=>'Home'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1658590143935956852)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Data Loading'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database-arrow-up'
,p_list_text_01=>'Load data using declarative data loading process type.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1864878321234312467)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Manual Data Loading'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:32:::'
,p_list_item_icon=>'fa-wrench'
,p_list_text_01=>'Parse upload data manually using APEX_DATA_PARSER package and upload the data maually with DML.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'32'
);
wwv_flow_imp.component_end;
end;
/
