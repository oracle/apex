prompt --application/shared_components/legacy_data_loads/eba_demo_load_emp
begin
--   Manifest
--     EBA_DEMO_LOAD_EMP
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>1658580677483859081
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_load_table(
 p_id=>wwv_flow_imp.id(4301999553172289957)
,p_name=>'Load Employees'
,p_owner=>'#OWNER#'
,p_table_name=>'EBA_DEMO_LOAD_EMP'
,p_unique_column_1=>'ENAME'
,p_is_uk1_case_sensitive=>'N'
,p_is_uk2_case_sensitive=>'N'
,p_is_uk3_case_sensitive=>'N'
,p_skip_validation=>'N'
);
wwv_flow_imp_shared.create_load_table_lookup(
 p_id=>wwv_flow_imp.id(4301999622628289969)
,p_load_table_id=>wwv_flow_imp.id(4301999553172289957)
,p_load_column_name=>'DEPTNO'
,p_lookup_owner=>'#OWNER#'
,p_lookup_table_name=>'EBA_DEMO_LOAD_DEPT'
,p_key_column=>'DEPTNO'
,p_display_column=>'DNAME'
,p_insert_new_value=>'N'
);
wwv_flow_imp_shared.create_load_table_lookup(
 p_id=>wwv_flow_imp.id(4302176521667356571)
,p_load_table_id=>wwv_flow_imp.id(4301999553172289957)
,p_load_column_name=>'MGR'
,p_lookup_owner=>'#OWNER#'
,p_lookup_table_name=>'EBA_DEMO_LOAD_EMP'
,p_key_column=>'EMPNO'
,p_display_column=>'ENAME'
,p_insert_new_value=>'N'
);
wwv_flow_imp_shared.create_load_table_rule(
 p_id=>wwv_flow_imp.id(4301999828925289979)
,p_load_table_id=>wwv_flow_imp.id(4301999553172289957)
,p_load_column_name=>'ENAME'
,p_rule_name=>'Name in Uppercase'
,p_rule_type=>'TO_UPPER_CASE'
,p_rule_sequence=>10
);
wwv_flow_imp.component_end;
end;
/
