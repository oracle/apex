prompt --application/deployment/checks
begin
--   Manifest
--     INSTALL CHECKS: 7850
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>11008923455465249
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
