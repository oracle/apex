prompt --application/deployment/install/install_seed_sample_data
begin
--   Manifest
--     INSTALL: INSTALL-seed sample data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>11008923455465249
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3338860105472874619)
,p_install_id=>wwv_flow_imp.id(5900922254569070958)
,p_name=>'seed sample data'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    eba_demo_data_load.reset_sample;',
'end;',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
