prompt --application/deployment/install/install_seed_sample_data
begin
--   Manifest
--     INSTALL: INSTALL-seed sample data
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>1658580677483859081
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(1669270504533550289)
,p_install_id=>wwv_flow_api.id(4231332653629746628)
,p_name=>'seed sample data'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    eba_demo_data_load.reset_sample;',
'end;',
'/',
''))
);
wwv_flow_api.component_end;
end;
/
