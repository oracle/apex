prompt --application/deployment/install/install_create_tables
begin
--   Manifest
--     INSTALL: INSTALL-Create Tables
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(2577921674422662962)
,p_install_id=>wwv_flow_api.id(2572751976145887547)
,p_name=>'Create Tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  CREATE TABLE "EBA_DEMO_LOAD_DEPT" ',
'   (    "DEPTNO" NUMBER(2,0), ',
'    "DNAME" VARCHAR2(14 BYTE), ',
'    "LOC" VARCHAR2(13 BYTE)',
'   ) ;',
'  ALTER TABLE "EBA_DEMO_LOAD_DEPT" ADD PRIMARY KEY ("DEPTNO");',
'',
'  CREATE TABLE "EBA_DEMO_LOAD_EMP" ',
'   (    "EMPNO" NUMBER(4,0) NOT NULL, ',
'    "ENAME" VARCHAR2(10 BYTE), ',
'    "JOB" VARCHAR2(9 BYTE), ',
'    "MGR" NUMBER(4,0), ',
'    "HIREDATE" DATE, ',
'    "SAL" NUMBER(7,2), ',
'    "COMM" NUMBER(7,2), ',
'    "DEPTNO" NUMBER(2,0),',
'    "CREATED" DATE,',
'    "LAST_UPDATED" DATE',
'   ) ;',
'  ALTER TABLE "EBA_DEMO_LOAD_EMP" ADD PRIMARY KEY ("EMPNO");',
'',
'  ALTER TABLE "EBA_DEMO_LOAD_EMP" ADD FOREIGN KEY ("MGR")',
'      REFERENCES "EBA_DEMO_LOAD_EMP" ("EMPNO") ENABLE;',
' ',
'  ALTER TABLE "EBA_DEMO_LOAD_EMP" ADD FOREIGN KEY ("DEPTNO")',
'      REFERENCES "EBA_DEMO_LOAD_DEPT" ("DEPTNO") ENABLE;',
'      ',
'  CREATE INDEX "EBA_DEMO_LOAD_EMP_1" ON "EBA_DEMO_LOAD_EMP" ("MGR");',
'  CREATE INDEX "EBA_DEMO_LOAD_EMP_2" ON "EBA_DEMO_LOAD_EMP" ("DEPTNO");',
'  ',
'create or replace TRIGGER BIU_EBA_DEMO_LOAD_EMP',
'    BEFORE INSERT OR UPDATE ON EBA_DEMO_LOAD_EMP',
'FOR EACH ROW',
'BEGIN',
'   if :new."CREATED" is null then',
'     select sysdate into :new.created from dual;',
'   end if;',
'   select sysdate into :new.last_updated from dual;',
'END;',
'/',
'',
'begin',
'    sys.dbms_errlog.create_error_log( dml_table_name=> ''EBA_DEMO_LOAD_EMP'', err_log_table_name=> ''EBA_DEMO_LOAD_EMP_ERR$'' );',
'end;',
'/',
''))
);
wwv_flow_api.component_end;
end;
/
