prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7850
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>11008923455465249
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(5901020934268074541)
,p_name=>'HELP'
,p_message_text=>'Help'
,p_version_scn=>'37166093876542'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(5901025436346075186)
,p_name=>'LOGOUT'
,p_message_text=>'Logout'
,p_version_scn=>'37166093876542'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(6004616350005054078)
,p_name=>'USER'
,p_message_text=>'User'
,p_version_scn=>'37166093876542'
);
wwv_flow_imp.component_end;
end;
/
