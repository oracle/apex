prompt --application/shared_components/user_interface/lovs/date_format_option
begin
--   Manifest
--     DATE_FORMAT_OPTION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>11008923455465249
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(5506733972308388679)
,p_lov_name=>'DATE_FORMAT_OPTION'
,p_static_id=>'date-format-option'
,p_lov_query=>'.'||wwv_flow_imp.id(5506733972308388679)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089079098'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(5506734426871388680)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Yes'
,p_lov_return_value=>'Y'
,p_static_id=>'yes'
);
wwv_flow_imp.component_end;
end;
/
