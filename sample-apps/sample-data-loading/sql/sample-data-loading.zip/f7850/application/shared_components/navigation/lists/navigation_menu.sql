prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>11008923455465249
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(5086718860665940449)
,p_name=>'Navigation Menu'
,p_static_id=>'navigation-menu'
,p_version_scn=>'1089079098'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5471638519183787716)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Administration'
,p_static_id=>'administration'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gear'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3331539848506254601)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Background Load'
,p_static_id=>'background-load'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17:::'
,p_list_item_icon=>'fa-clock-o'
,p_parent_list_item_id=>wwv_flow_imp.id(3328190522479449967)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'17,18'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3328214772772662681)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'CSV Load'
,p_static_id=>'csv-load'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:11:::'
,p_list_item_icon=>'fa-file-csv'
,p_parent_list_item_id=>wwv_flow_imp.id(3328190522479449967)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3328190522479449967)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Data Loading'
,p_static_id=>'data-loading'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database-arrow-up'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5086719015929940450)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_static_id=>'home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'1,6,8'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4340447317347684065)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Legacy Data Loading'
,p_static_id=>'legacy-data-loading'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-archive'
,p_parent_list_item_id=>wwv_flow_imp.id(3328190522479449967)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'21,22,23,24'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3534425923008304154)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Manual Data Loading'
,p_static_id=>'manual-data-loading'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:32:::'
,p_list_item_icon=>'fa-wrench'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3329317700409052430)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Multiple File Type Load'
,p_static_id=>'multiple-file-type-load'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:16:::'
,p_list_item_icon=>'fa-files-o'
,p_parent_list_item_id=>wwv_flow_imp.id(3328190522479449967)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'16'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3328211317446528693)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'PL/SQL Data Load'
,p_static_id=>'pl-sql-data-load'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(3534425923008304154)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3328211018903526358)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'PL/SQL Parser'
,p_static_id=>'pl-sql-parser'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(3534425923008304154)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5102711755637925517)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Reset Data'
,p_static_id=>'reset-data'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(5471638519183787716)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5455172720393223596)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Theme Style'
,p_static_id=>'theme-style'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(5471638519183787716)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'7'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3328215103027666558)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Transformation and Lookup'
,p_static_id=>'transformation-and-lookup'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15:::'
,p_list_item_icon=>'fa-dynamic-content'
,p_parent_list_item_id=>wwv_flow_imp.id(3328190522479449967)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
