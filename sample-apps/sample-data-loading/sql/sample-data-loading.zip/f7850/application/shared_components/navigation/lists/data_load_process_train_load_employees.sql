prompt --application/shared_components/navigation/lists/data_load_process_train_load_employees
begin
--   Manifest
--     LIST: Data Load Process Train - Load Employees
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>11008923455465249
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(5506725799936388661)
,p_name=>'Data Load Process Train - Load Employees'
,p_static_id=>'data-load-process-train-load-employees'
,p_version_scn=>'1089079098'
);
wwv_flow_imp.component_end;
end;
/
