prompt --application/shared_components/navigation/lists/data_load_wizard_progress_load_employees
begin
--   Manifest
--     LIST: Data Load Wizard Progress - Load Employees
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>11008923455465249
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4340445102949684061)
,p_name=>'Data Load Wizard Progress - Load Employees'
,p_static_id=>'data-load-wizard-progress-load-employees'
,p_version_scn=>'1089079098'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4340446591694684064)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Data Load Results'
,p_static_id=>'data-load-results'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4340445354483684063)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Data Load Source'
,p_static_id=>'data-load-source'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4340445784307684063)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Data / Table Mapping'
,p_static_id=>'data-table-mapping'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4340446188094684064)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Data Validation'
,p_static_id=>'data-validation'
,p_list_item_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
