prompt --application/deployment/install/install_eba_demo_data_load
begin
--   Manifest
--     INSTALL: INSTALL-eba_demo_data_load
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7850
,p_default_id_offset=>11008923455465249
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_demo_data_load as'||wwv_flow.LF||
'    procedure reset_sample;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function zip_to_csv';
wwv_flow_imp.g_varchar2_table(2) := ' ('||wwv_flow.LF||
'        p_blob_content  in blob,'||wwv_flow.LF||
'        p_mime_type     in varchar2 ) return blob;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedur';
wwv_flow_imp.g_varchar2_table(3) := 'e set_file_blob( p_blob in blob );'||wwv_flow.LF||
''||wwv_flow.LF||
'    function get_file_blob return blob;'||wwv_flow.LF||
'end eba_demo_data_load;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(4) := '/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package body eba_demo_data_load as'||wwv_flow.LF||
''||wwv_flow.LF||
'    --------------------------------------';
wwv_flow_imp.g_varchar2_table(5) := '------------------------------------------'||wwv_flow.LF||
'    -- global variable to hold the CSV contents being ext';
wwv_flow_imp.g_varchar2_table(6) := 'racted from the uploaded'||wwv_flow.LF||
'    -- ZIP archive; see page 17.'||wwv_flow.LF||
'    --------------------------------------';
wwv_flow_imp.g_varchar2_table(7) := '------------------------------------------'||wwv_flow.LF||
'    g_current_blob blob;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ---------------------------';
wwv_flow_imp.g_varchar2_table(8) := '-----------------------------------------------------'||wwv_flow.LF||
'    -- constants'||wwv_flow.LF||
'    -------------------------';
wwv_flow_imp.g_varchar2_table(9) := '-------------------------------------------------------'||wwv_flow.LF||
'    c_mime_application_zip  constant varchar';
wwv_flow_imp.g_varchar2_table(10) := '2(30) := ''application/zip'' ;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(11) := '--------------'||wwv_flow.LF||
'    -- resets all sample tables'||wwv_flow.LF||
'    -------------------------------------------------';
wwv_flow_imp.g_varchar2_table(12) := '-------------------------------'||wwv_flow.LF||
'    procedure reset_sample'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        delete eba_demo_';
wwv_flow_imp.g_varchar2_table(13) := 'load_emp;'||wwv_flow.LF||
'        delete eba_demo_load_dept;'||wwv_flow.LF||
'        delete eba_demo_load_emp_err$;'||wwv_flow.LF||
'        '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(14) := ' Insert into EBA_DEMO_LOAD_DEPT (DEPTNO,DNAME,LOC) values (10,''ACCOUNTING'',''NEW YORK'');'||wwv_flow.LF||
'        Inse';
wwv_flow_imp.g_varchar2_table(15) := 'rt into EBA_DEMO_LOAD_DEPT (DEPTNO,DNAME,LOC) values (20,''RESEARCH'',''DALLAS'');'||wwv_flow.LF||
'        Insert into E';
wwv_flow_imp.g_varchar2_table(16) := 'BA_DEMO_LOAD_DEPT (DEPTNO,DNAME,LOC) values (30,''SALES'',''CHICAGO'');'||wwv_flow.LF||
'        Insert into EBA_DEMO_LOA';
wwv_flow_imp.g_varchar2_table(17) := 'D_DEPT (DEPTNO,DNAME,LOC) values (40,''OPERATIONS'',''BOSTON'');'||wwv_flow.LF||
'        '||wwv_flow.LF||
'        Insert into EBA_DEMO_L';
wwv_flow_imp.g_varchar2_table(18) := 'OAD_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7839,''KING'',''PRESIDENT'',null,to_date(';
wwv_flow_imp.g_varchar2_table(19) := '''17-11-81'',''DD-MM-RR''),5000,null,10);'||wwv_flow.LF||
'        Insert into EBA_DEMO_LOAD_EMP (EMPNO,ENAME,JOB,MGR,HIR';
wwv_flow_imp.g_varchar2_table(20) := 'EDATE,SAL,COMM,DEPTNO) values (7698,''BLAKE'',''MANAGER'',7839,to_date(''01-05-81'',''DD-MM-RR''),2850,null,';
wwv_flow_imp.g_varchar2_table(21) := '30);'||wwv_flow.LF||
'        Insert into EBA_DEMO_LOAD_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (77';
wwv_flow_imp.g_varchar2_table(22) := '82,''CLARK'',''MANAGER'',7839,to_date(''09-06-81'',''DD-MM-RR''),2450,null,10);'||wwv_flow.LF||
'        Insert into EBA_DEMO';
wwv_flow_imp.g_varchar2_table(23) := '_LOAD_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7566,''JONES'',''MANAGER'',7839,to_date';
wwv_flow_imp.g_varchar2_table(24) := '(''02-04-81'',''DD-MM-RR''),2975,null,20);'||wwv_flow.LF||
'        Insert into EBA_DEMO_LOAD_EMP (EMPNO,ENAME,JOB,MGR,HI';
wwv_flow_imp.g_varchar2_table(25) := 'REDATE,SAL,COMM,DEPTNO) values (7788,''SCOTT'',''ANALYST'',7566,to_date(''09-12-82'',''DD-MM-RR''),3000,null';
wwv_flow_imp.g_varchar2_table(26) := ',20);'||wwv_flow.LF||
'        Insert into EBA_DEMO_LOAD_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7';
wwv_flow_imp.g_varchar2_table(27) := '902,''FORD'',''ANALYST'',7566,to_date(''03-12-81'',''DD-MM-RR''),3000,null,20);'||wwv_flow.LF||
'        Insert into EBA_DEMO';
wwv_flow_imp.g_varchar2_table(28) := '_LOAD_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7369,''SMITH'',''CLERK'',7902,to_date(''';
wwv_flow_imp.g_varchar2_table(29) := '17-12-80'',''DD-MM-RR''),800,null,20);'||wwv_flow.LF||
'        Insert into EBA_DEMO_LOAD_EMP (EMPNO,ENAME,JOB,MGR,HIRED';
wwv_flow_imp.g_varchar2_table(30) := 'ATE,SAL,COMM,DEPTNO) values (7499,''ALLEN'',''SALESMAN'',7698,to_date(''20-02-81'',''DD-MM-RR''),1600,300,30';
wwv_flow_imp.g_varchar2_table(31) := ');'||wwv_flow.LF||
'        Insert into EBA_DEMO_LOAD_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7521';
wwv_flow_imp.g_varchar2_table(32) := ',''WARD'',''SALESMAN'',7698,to_date(''22-02-81'',''DD-MM-RR''),1250,500,30);'||wwv_flow.LF||
'        Insert into EBA_DEMO_LO';
wwv_flow_imp.g_varchar2_table(33) := 'AD_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7654,''MARTIN'',''SALESMAN'',7698,to_date(';
wwv_flow_imp.g_varchar2_table(34) := '''28-09-81'',''DD-MM-RR''),1250,1400,30);'||wwv_flow.LF||
'        Insert into EBA_DEMO_LOAD_EMP (EMPNO,ENAME,JOB,MGR,HIR';
wwv_flow_imp.g_varchar2_table(35) := 'EDATE,SAL,COMM,DEPTNO) values (7844,''TURNER'',''SALESMAN'',7698,to_date(''08-09-81'',''DD-MM-RR''),1500,0,3';
wwv_flow_imp.g_varchar2_table(36) := '0);'||wwv_flow.LF||
'        Insert into EBA_DEMO_LOAD_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (787';
wwv_flow_imp.g_varchar2_table(37) := '6,''ADAMS'',''CLERK'',7788,to_date(''12-01-83'',''DD-MM-RR''),1100,null,20);'||wwv_flow.LF||
'        Insert into EBA_DEMO_LO';
wwv_flow_imp.g_varchar2_table(38) := 'AD_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7900,''JAMES'',''CLERK'',7698,to_date(''03-';
wwv_flow_imp.g_varchar2_table(39) := '12-81'',''DD-MM-RR''),950,null,30);'||wwv_flow.LF||
'        Insert into EBA_DEMO_LOAD_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE';
wwv_flow_imp.g_varchar2_table(40) := ',SAL,COMM,DEPTNO) values (7934,''MILLER'',''CLERK'',7782,to_date(''23-01-82'',''DD-MM-RR''),1300,null,10);'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(41) := '        delete eba_demo_load_sales;'||wwv_flow.LF||
'    end reset_sample;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -------------------------------------';
wwv_flow_imp.g_varchar2_table(42) := '-------------------------------------------'||wwv_flow.LF||
'    -- extracts the CSV file from an uploaded ZIP archiv';
wwv_flow_imp.g_varchar2_table(43) := 'e. Only the first CSV file'||wwv_flow.LF||
'    -- is returned.'||wwv_flow.LF||
'    -------------------------------------------------';
wwv_flow_imp.g_varchar2_table(44) := '-------------------------------'||wwv_flow.LF||
'    function zip_to_csv ('||wwv_flow.LF||
'        p_blob_content  in blob,'||wwv_flow.LF||
'        p';
wwv_flow_imp.g_varchar2_table(45) := '_mime_type     in varchar2 ) return blob'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_zipped_file   blob;'||wwv_flow.LF||
'        l_unzipped_fil';
wwv_flow_imp.g_varchar2_table(46) := 'e blob;'||wwv_flow.LF||
'        l_zip_files     apex_zip.t_files;'||wwv_flow.LF||
'        l_file          blob;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        ap';
wwv_flow_imp.g_varchar2_table(47) := 'ex_debug.enter ('||wwv_flow.LF||
'            ''zip_to_csv'' ,'||wwv_flow.LF||
'            ''p_mime_type''  , p_mime_type );'||wwv_flow.LF||
''||wwv_flow.LF||
'        if ';
wwv_flow_imp.g_varchar2_table(48) := 'p_mime_type = c_mime_application_zip then'||wwv_flow.LF||
'            l_zipped_file := p_blob_content;'||wwv_flow.LF||
'            l';
wwv_flow_imp.g_varchar2_table(49) := '_zip_files := apex_zip.get_files( l_zipped_file );'||wwv_flow.LF||
' '||wwv_flow.LF||
'            for i in 1 .. l_zip_files.count'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(50) := '         loop'||wwv_flow.LF||
'                apex_debug.info( ''Zip Entry %s = %s'', i, l_zip_files( i ));'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(51) := '      if lower( l_zip_files( i ) ) like ''%.csv'' then'||wwv_flow.LF||
'                    -- accept one unzipped CSV ';
wwv_flow_imp.g_varchar2_table(52) := 'file'||wwv_flow.LF||
'                    l_unzipped_file := apex_zip.get_file_content( l_zipped_file, l_zip_files( i';
wwv_flow_imp.g_varchar2_table(53) := ' ) );'||wwv_flow.LF||
'                    exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'            l_file := ';
wwv_flow_imp.g_varchar2_table(54) := 'l_unzipped_file;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            l_file := p_blob_content;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        return l';
wwv_flow_imp.g_varchar2_table(55) := '_file;'||wwv_flow.LF||
'    end zip_to_csv;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(56) := '------------'||wwv_flow.LF||
'    -- store a BLOB in the package global for later use.'||wwv_flow.LF||
'    --------------------------';
wwv_flow_imp.g_varchar2_table(57) := '------------------------------------------------------'||wwv_flow.LF||
'    procedure set_file_blob( p_blob in blob )';
wwv_flow_imp.g_varchar2_table(58) := ''||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        g_current_blob := p_blob;'||wwv_flow.LF||
'    end set_file_blob;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --------------------';
wwv_flow_imp.g_varchar2_table(59) := '------------------------------------------------------------'||wwv_flow.LF||
'    -- get the BLOB from the package gl';
wwv_flow_imp.g_varchar2_table(60) := 'obal.'||wwv_flow.LF||
'    --------------------------------------------------------------------------------'||wwv_flow.LF||
'    funct';
wwv_flow_imp.g_varchar2_table(61) := 'ion get_file_blob return blob'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        return g_current_blob;'||wwv_flow.LF||
'    end get_file_blob;';
wwv_flow_imp.g_varchar2_table(62) := ''||wwv_flow.LF||
'end eba_demo_data_load;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3331533574844208903)
,p_install_id=>wwv_flow_imp.id(5900922254569070958)
,p_name=>'eba_demo_data_load'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
