prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7310
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'Forms Patterns'
,p_alias=>'FORMS-PATTERNS'
,p_step_title=>'Forms Patterns'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><strong>Purpose:</strong> Forms Patterns is a reference catalog for developers and designers choosing how users enter and maintain records in Oracle APEX. Four examples use the same fictional expense dataset so you can compare the interaction and '
||'native components.</p>',
'<h3>When to use this catalog</h3>',
'<p>Use the catalog to choose between a short modal form, a form with attachments, a full-page form with grouped fields, and an editable grid for several records.</p>',
'<h3>Components used on the home page</h3>',
'<ul>',
'<li><strong>Cards:</strong> Introduce each pattern and open its example.</li>',
'<li><strong>Navigation Menu:</strong> Provides direct access to the four patterns.</li>',
'<li><strong>Shared Page Help:</strong> Reads the current page''s Help text through the global page 0 popup.</li>',
'</ul>',
'<h3>How to explore the app</h3>',
'<ol>',
'<li><strong>FP-01 - Simple Form:</strong> Open a category in a modal. Try required validation, an optional description, and the Active switch.</li>',
'<li><strong>FP-02 - Form with Attachment:</strong> Upload an image or PDF receipt, preview it, and edit its details.</li>',
'<li><strong>FP-03 - Advanced Form:</strong> Filter reports, then explore grouped fields, dates, signed amounts, long text, and an Add Expense drawer.</li>',
'<li><strong>FP-04 - Editable Grid:</strong> Enter or update several expense lines and save the pending changes together.</li>',
'</ol>',
'<h3>Understanding the examples</h3>',
'<p>Reports have expense lines; lines reference categories and can have receipts. Changes made in one pattern appear in the others. The app is open without sign-in and saves changes to the shared sample data. Use fictional values and demonstration doc'
||'uments. Status and policy fields illustrate data entry; the sample does not implement expense approvals or payments.</p>'))
,p_page_comment=>'Native cards compare four form patterns using the shared fictional expense dataset.'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2808650805491063)
,p_plug_name=>'Available Patterns'
,p_static_id=>'pattern-index'
,p_region_template_options=>'u-colors:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2076152157930740558
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 pattern_id, ''FP-01 - Simple Form'' pattern_title, ''Core'' pattern_badge,',
'       ''A focused modal'' pattern_subtitle,',
'       ''Create and edit a category with a few fields, required validation, and an Active switch.'' pattern_description,',
'       ''fa fa-edit'' pattern_icon, 7 target_page from dual',
'union all',
'select 2, ''FP-02 - Form with Attachment'', ''Core'', ''Upload and preview'',',
'       ''Add image or PDF receipts with a drop zone, preview the stored document, and edit its details.'',',
'       ''fa fa-paperclip'', 5 from dual',
'union all',
'select 3, ''FP-03 - Advanced Form'', ''Extension'', ''Organize many fields'',',
'       ''Edit an expense report with grouped sections, dates, choices, signed amounts, and long text.'',',
'       ''fa fa-list-alt'', 1 from dual',
'union all',
'select 4, ''FP-04 - Editable Grid'', ''Extension'', ''Edit several records'',',
'       ''Add, edit, and delete expense lines in a native grid with report and category lookups.'',',
'       ''fa fa-table-edit'', 11 from dual',
'order by pattern_id'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(2808756598491064)
,p_region_id=>wwv_flow_imp.id(2808650805491063)
,p_layout_type=>'GRID'
,p_grid_column_count=>4
,p_title_adv_formatting=>false
,p_title_column_name=>'PATTERN_TITLE'
,p_title_css_classes=>'u-color-44-text'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'PATTERN_SUBTITLE'
,p_body_adv_formatting=>false
,p_body_column_name=>'PATTERN_DESCRIPTION'
,p_body_css_classes=>'u-text-muted-color'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'PATTERN_ICON'
,p_icon_position=>'START'
,p_badge_column_name=>'PATTERN_BADGE'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'PATTERN_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(2808809915491065)
,p_card_id=>wwv_flow_imp.id(2808756598491064)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>10
,p_label=>'Open example'
,p_static_id=>'open'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'f?p=&APP_ID.:&TARGET_PAGE.:&SESSION.::&DEBUG.:::'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-external-link'
,p_action_css_classes=>'t-Button--primary t-Button--simple'
,p_is_hot=>false
);
wwv_flow_imp.component_end;
end;
/
