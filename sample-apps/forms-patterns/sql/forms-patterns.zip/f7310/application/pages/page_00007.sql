prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7310
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'FP-01 - Simple Form'
,p_alias=>'CATEGORIES'
,p_step_title=>'FP-01 - Simple Form'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>When to use</h3>',
'<p>Use a simple modal form for a small record that users can create or edit without leaving a list. This pattern suits categories, lookup values, and other records with only a few fields.</p>',
'<h3>About this pattern page</h3>',
'<p>The Interactive Report lists categories, their descriptions, and their Active values. Search the list, choose a row''s Edit icon, or select New Category to open the modal. Category Name is required and unique; Description is optional. The native Ac'
||'tive switch stores Yes or No as Y or N.</p>',
'<h3>Components used</h3>',
'<ul>',
'<li><strong>Interactive Report:</strong> Finds records and passes the selected category identifier to the modal.</li>',
'<li><strong>Form region and native page items:</strong> Present a text field, textarea, and switch.</li>',
'<li><strong>Form Initialization and Automatic Row Processing:</strong> Load and save the selected record. A dialog-closed action refreshes the list.</li>',
'</ul>',
'<p>Create or Save Changes persists the record; Cancel discards unsaved changes. Delete asks for confirmation. A category referenced by expense lines cannot be deleted until those references are changed or removed.</p>'))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2419901167162109)
,p_plug_name=>'FP-01 - Simple Form'
,p_static_id=>'page-heading'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useRegionTitle'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2420166735162117)
,p_plug_name=>'Categories'
,p_static_id=>'records'
,p_region_name=>'categories-report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2103954283454391425
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>'select category_id,category_name,description,active_yn from sfm_expense_categories'
,p_plug_source_type=>'NATIVE_IR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2420288453162117)
,p_no_data_found_message=>'No records found. Use the create button to add one.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:8:P8_CATEGORY_ID:#CATEGORY_ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_internal_uid=>2420288453162117
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2420610526162117)
,p_db_column_name=>'ACTIVE_YN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Active'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_column_comment=>'Active for the categories report.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2420349755162117)
,p_db_column_name=>'CATEGORY_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Category ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_column_comment=>'Category ID for the categories report.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2420407852162117)
,p_db_column_name=>'CATEGORY_NAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Category'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'Y'
,p_available_clientside=>'N'
,p_column_comment=>'Category for the categories report.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2420501972162117)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_column_comment=>'Description for the categories report.'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2420746589162117)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'primary'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'CATEGORY_NAME:DESCRIPTION:ACTIVE_YN'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2420887208162117)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2419901167162109)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_is_hot=>'Y'
,p_button_image_alt=>'New Category'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:8'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2420992459162118)
,p_name=>'Refresh after editing'
,p_static_id=>'refresh-records'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'body'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2421049277162118)
,p_event_id=>wwv_flow_imp.id(2420992459162118)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2420166735162117)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
