prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7310
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Expense'
,p_alias=>'EXPENSE'
,p_page_mode=>'MODAL'
,p_step_title=>'Expense'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1664614232864994871
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_width=>'760'
,p_dialog_chained=>'N'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>When to use</h3>',
'<p>Use this drawer to add or edit a child record while retaining the parent report''s form context.</p>',
'<h3>About this form</h3>',
'<p>Select the Expense Report and Category, then enter the Expense Date, Merchant, optional Description, Amount, and Reimbursable choice. The amount uses the parent report''s currency: positive values represent expenses, negative values represent refun'
||'ds, and zero is valid.</p>',
'<h3>How the components work together</h3>',
'<p>Add Expense passes the current report identifier into the drawer. Native select lists provide report and category lookups. Form Initialization loads an existing line, and Automatic Row Processing saves its fields. The Close Dialog process returns '
||'to the report form after a successful save.</p>',
'<p>Cancel closes the drawer without saving its edits. Delete asks for confirmation and removes the expense line and its attached receipts. A line saved here remains saved even if you later cancel unsaved edits on the parent report.</p>'))
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2413007053162107)
,p_plug_name=>'Buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2129856781885180476
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2412919296162107)
,p_plug_name=>'Expense'
,p_static_id=>'form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'TABLE'
,p_query_table=>'SFM_EXPENSE_REPORT_LINES'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2414822393162107)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2413007053162107)
,p_button_name=>'APPLY-CHANGES'
,p_static_id=>'apply-changes'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Save Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P4_REPORT_LINE_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2414644550162107)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2413007053162107)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_show_as_disabled=>false
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2414737405162107)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2413007053162107)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P4_REPORT_LINE_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2414986553162107)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2413007053162107)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'Delete this record and its dependent sample records?'
,p_confirm_style=>'danger'
,p_button_condition=>'P4_REPORT_LINE_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2414264926162107)
,p_name=>'P4_AMOUNT'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_item_source_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_prompt=>'Amount (refunds are negative)'
,p_format_mask=>'FM9G999G999G990D00'
,p_source=>'AMOUNT'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Enter positive expenses, negative refunds, or zero. Use the currency of the parent expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'max_value', '9999999999.99',
  'min_value', '-9999999999.99',
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2413415284162107)
,p_name=>'P4_CATEGORY_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_item_source_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_prompt=>'Category'
,p_source=>'CATEGORY_ID'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select category_name d, category_id r from sfm_expense_categories order by category_name'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_help_text=>'Provide the category for this expense.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2414095767162107)
,p_name=>'P4_DESCRIPTION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_item_source_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_prompt=>'Description'
,p_source=>'DESCRIPTION'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>500
,p_cHeight=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Provide the description for this expense.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2413655220162107)
,p_name=>'P4_EXPENSE_DATE'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_item_source_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_prompt=>'Expense Date'
,p_format_mask=>'YYYY-MM-DD'
,p_source=>'EXPENSE_DATE'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Provide the expense date for this expense.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2413850681162107)
,p_name=>'P4_MERCHANT'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_item_source_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_prompt=>'Merchant'
,p_source=>'MERCHANT'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cMaxlength=>150
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Provide the merchant for this expense.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2414445655162107)
,p_name=>'P4_REIMBURSABLE_YN'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_item_source_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_item_default=>'Y'
,p_prompt=>'Reimbursable'
,p_source=>'REIMBURSABLE_YN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Yes;Y,No;N'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_help_text=>'Provide the reimbursable for this expense.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2413287924162107)
,p_name=>'P4_REPORT_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_item_source_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_prompt=>'Expense Report'
,p_source=>'REPORT_ID'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select report_title || '' ('' || currency_code || '')'' d, report_id r from sfm_expense_reports order by report_title'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_help_text=>'Provide the expense report for this expense.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2413124317162107)
,p_name=>'P4_REPORT_LINE_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_item_source_plug_id=>wwv_flow_imp.id(2412919296162107)
,p_source=>'REPORT_LINE_ID'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2415084150162107)
,p_name=>'Cancel Dialog'
,p_static_id=>'cancel-dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2414644550162107)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2415105073162107)
,p_event_id=>wwv_flow_imp.id(2415084150162107)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'cancel'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2415472970162107)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_static_id=>'close-dialog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'Y')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,APPLY-CHANGES,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>731000403
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2415222716162107)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(2412919296162107)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize Expense'
,p_static_id=>'initialize'
,p_internal_uid=>731000401
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2415365474162107)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(2412919296162107)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Save Expense'
,p_static_id=>'save'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'prevent_lost_updates', 'Y',
  'return_primary_keys_after_insert', 'Y',
  'target_type', 'REGION_SOURCE')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Expense saved.'
,p_internal_uid=>731000402
);
wwv_flow_imp.component_end;
end;
/
