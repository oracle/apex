prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7310
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'FP-03 - Advanced Form'
,p_alias=>'EXPENSE-REPORTS'
,p_step_title=>'FP-03 - Advanced Form'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2530071015796209513
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>When to use</h3>',
'<p>Use this pattern to find a record before opening a larger form with related groups of fields. It suits data entry that combines identity, dates, choices, amounts, and a longer explanation.</p>',
'<h3>About this pattern page</h3>',
'<p>Search matches report titles and employee names. Status, Employee, and Currency facets narrow the results. Content Rows show the employee, title, status, creation date, number of expense lines, and their total in the report''s currency. Reports are'
||' ordered by creation date descending, with the report identifier as the tie-breaker.</p>',
'<p>Choose the Edit Report icon to open the full-page form, or New Expense Report to create a report. Inside the form, use the section selector to focus on one group of fields or Show All to see the complete form.</p>',
'<h3>Components used</h3>',
'<ul>',
'<li><strong>Faceted Search and Content Row:</strong> Filter records and present summaries with a row action.</li>',
'<li><strong>Full-page Form and Region Display Selector:</strong> Organize nineteen editable fields into four sections.</li>',
'<li><strong>Add Expense drawer:</strong> Adds a line to a saved report while keeping the report form open.</li>',
'</ul>',
'<p>The report total sums expense lines, including negative refunds and zero amounts. The advance or credit field is recorded separately.</p>'))
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2433556375212840)
,p_plug_name=>'Filter Reports'
,p_static_id=>'filters'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(2406540345162072)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'show_charts', 'Y',
  'show_current_facets', 'Y',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2433914012212843)
,p_name=>'P1_CURRENCY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2433556375212840)
,p_prompt=>'Currency'
,p_source=>'CURRENCY_CODE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2433890056212843)
,p_name=>'P1_EMPLOYEE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2433556375212840)
,p_prompt=>'Employee'
,p_source=>'EMPLOYEE_NAME'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2433614657212841)
,p_name=>'P1_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2433556375212840)
,p_prompt=>'Search'
,p_source=>'REPORT_TITLE,EMPLOYEE_NAME'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2433739366212843)
,p_name=>'P1_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2433556375212840)
,p_prompt=>'Status'
,p_source=>'STATUS_LABEL'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2406372830162048)
,p_plug_name=>'FP-03 - Advanced Form'
,p_static_id=>'page-heading'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useRegionTitle'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2406540345162072)
,p_plug_name=>'Expense Reports'
,p_static_id=>'records'
,p_region_name=>'expense-reports'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c.report_id,c.report_title,c.employee_name,c.status,c.currency_code,c.created_on,',
'       initcap(c.status) status_label,',
'       case c.status when ''PAID'' then ''success'' when ''APPROVED'' then ''success''',
'            when ''RETURNED'' then ''danger'' when ''SUBMITTED'' then ''info'' else ''warning'' end status_state,',
'       ''Created '' || to_char(c.created_on,''Mon DD, YYYY'') || '' - '' ||',
'           (select count(*) from sfm_expense_report_lines l where l.report_id=c.report_id) ||',
'           case when (select count(*) from sfm_expense_report_lines l where l.report_id=c.report_id)=1 then '' expense'' else '' expenses'' end report_summary,',
'       c.currency_code || '' '' || to_char((select nvl(sum(l.amount),0)',
'           from sfm_expense_report_lines l where l.report_id=c.report_id),''FM999G999G999G990D00'') amount_label,',
'       apex_page.get_url(p_page=>2,p_items=>''P2_REPORT_ID'',p_values=>c.report_id,p_clear_cache=>''2'') edit_url',
'from sfm_expense_reports c'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'CREATED_ON DESC, REPORT_ID DESC'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--md',
  'BADGE_LABEL', 'Status',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_STATE', 'STATUS_STATE',
  'BADGE_VALUE', 'STATUS_LABEL',
  'DESCRIPTION', '&REPORT_SUMMARY.',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'MISC', '&AMOUNT_LABEL.',
  'OVERLINE', '&EMPLOYEE_NAME.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&REPORT_TITLE.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2433276080212839)
,p_name=>'AMOUNT_LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AMOUNT_LABEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2432827459212839)
,p_name=>'CREATED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_ON'
,p_data_type=>'TIMESTAMP'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2432799546212839)
,p_name=>'CURRENCY_CODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CURRENCY_CODE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2433329195212839)
,p_name=>'EDIT_URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EDIT_URL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>110
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2432593019212839)
,p_name=>'EMPLOYEE_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMPLOYEE_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2432325812212836)
,p_name=>'REPORT_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REPORT_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2433164092212839)
,p_name=>'REPORT_SUMMARY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REPORT_SUMMARY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2432451745212839)
,p_name=>'REPORT_TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REPORT_TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2432640452212839)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2432910716212839)
,p_name=>'STATUS_LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS_LABEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(2433037858212839)
,p_name=>'STATUS_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(2433490009212839)
,p_region_id=>wwv_flow_imp.id(2406540345162072)
,p_position_id=>365743646611256091
,p_display_sequence=>10
,p_template_id=>365744248288287220
,p_label=>'Edit Report'
,p_static_id=>'edit'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'&EDIT_URL.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-edit'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2407637650162075)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2406372830162048)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_is_hot=>'Y'
,p_button_image_alt=>'New Expense Report'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:2'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2407739997162076)
,p_name=>'Refresh after editing'
,p_static_id=>'refresh-records'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'body'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2407849049162076)
,p_event_id=>wwv_flow_imp.id(2407739997162076)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2406540345162072)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2438635038232157)
,p_event_id=>wwv_flow_imp.id(2407739997162076)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'refresh-facets'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2433556375212840)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
