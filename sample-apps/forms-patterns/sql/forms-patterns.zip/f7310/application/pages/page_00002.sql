prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7310
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Expense Report'
,p_alias=>'EXPENSE-REPORT'
,p_step_title=>'Expense Report'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>When to use</h3>',
'<p>Use a full-page form when a record has enough fields to benefit from named sections and more space than a modal provides.</p>',
'<h3>About this form</h3>',
'<p>The native section selector offers Show All, Report and Employee, Trip Details, Accounting and Approval Contact, and Justification and Reimbursement. The fields demonstrate required text, email and phone inputs, dates, lookup choices, a CLOB-backe'
||'d justification longer than 32 KB, and signed advances or credits. Travel End must be on or after Travel Start when both dates are provided.</p>',
'<h3>How the components work together</h3>',
'<ul>',
'<li><strong>Form Initialization:</strong> Uses the hidden report identifier to load a record.</li>',
'<li><strong>Form region and native items:</strong> Bind fields to the report table and apply their validation settings.</li>',
'<li><strong>Automatic Row Processing and a page branch:</strong> Save the record and return to the report list after Create, Save, or Delete.</li>',
'</ul>',
'<p>Cancel returns without saving report-field edits. Add Expense is available for a saved report and opens a drawer with that report selected. Saving an expense is separate from saving the report; canceling the report does not undo an expense already'
||' saved in the drawer.</p>',
'<p>Delete requires confirmation and also removes the report''s expense lines and receipts. Status and Policy Reviewed are demonstration fields; no approval or payment workflow is executed.</p>'))
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2803236556491017)
,p_plug_name=>'Justification and Reimbursement'
,p_static_id=>'approval'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>42
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2408103736162077)
,p_plug_name=>'Expense Report'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useRegionTitle'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>22
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2803144611491017)
,p_plug_name=>'Accounting and Approval Contact'
,p_static_id=>'coding'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>32
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2408018776162077)
,p_plug_name=>'Report and Employee'
,p_static_id=>'form'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'TABLE'
,p_query_table=>'SFM_EXPENSE_REPORTS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4602769448071763)
,p_plug_name=>'Sections'
,p_static_id=>'sections'
,p_region_name=>'rds'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>32
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2803034776491017)
,p_plug_name=>'Trip Details'
,p_static_id=>'trip'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>12
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2601054558567312)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2408103736162077)
,p_button_name=>'ADD_EXPENSE'
,p_static_id=>'add-expense'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Add Expense'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:4:P4_REPORT_ID:&P2_REPORT_ID.'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P2_REPORT_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2410239398162080)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(2408103736162077)
,p_button_name=>'APPLY-CHANGES'
,p_static_id=>'apply-changes'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Save'
,p_button_position=>'NEXT'
,p_button_condition=>'P2_REPORT_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2410013314162080)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2408103736162077)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2410124938162080)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(2408103736162077)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P2_REPORT_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2410311167162081)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2408103736162077)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Delete'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'Delete this record and its dependent sample records?'
,p_confirm_style=>'danger'
,p_button_condition=>'P2_REPORT_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(4612186822193913)
,p_branch_name=>'Return to expense reports'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:2&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>50
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'CREATE,APPLY-CHANGES,DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2805790864491037)
,p_name=>'P2_ADVANCE_AMOUNT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(2803236556491017)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Advance or Credit'
,p_format_mask=>'FM9G999G999G990D00'
,p_source=>'ADVANCE_AMOUNT'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Enter a positive advance or a negative credit, in the report currency. Zero is valid.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'max_value', '9999999999.99',
  'min_value', '-9999999999.99',
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2409538292162080)
,p_name=>'P2_BUSINESS_JUSTIFICATION'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2803236556491017)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Business Justification'
,p_source=>'BUSINESS_JUSTIFICATION'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cHeight=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Explain the business purpose. This CLOB-backed field supports text longer than 32 KB.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2806125764491037)
,p_name=>'P2_CONTACT_PHONE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Contact Phone'
,p_source=>'CONTACT_PHONE'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cMaxlength=>40
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_icon_css_classes=>'fa-mobile'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Optional contact phone for this fictional expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEL',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2804339152491037)
,p_name=>'P2_COST_CENTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(2803144611491017)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Cost Center'
,p_source=>'COST_CENTER'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Optional cost center for this fictional expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2409987301162080)
,p_name=>'P2_CREATED_ON'
,p_source_data_type=>'TIMESTAMP'
,p_is_query_only=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_source=>'CREATED_ON'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2409107163162079)
,p_name=>'P2_CURRENCY_CODE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_item_default=>'USD'
,p_prompt=>'Currency'
,p_source=>'CURRENCY_CODE'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:USD;USD,EUR;EUR,GBP;GBP,CAD;CAD'
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#:margin-bottom-md'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_help_text=>'Provide the currency for this expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2804185179491037)
,p_name=>'P2_DEPARTMENT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(2803144611491017)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Department'
,p_source=>'DEPARTMENT'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cMaxlength=>100
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Optional department for this fictional expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2804974624491037)
,p_name=>'P2_DESTINATION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(2803034776491017)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Destination'
,p_source=>'DESTINATION'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cMaxlength=>150
,p_colspan=>12
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_icon_css_classes=>'fa-map-marker-o'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Optional destination for this fictional expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2408748561162079)
,p_name=>'P2_EMPLOYEE_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Employee Email'
,p_source=>'EMPLOYEE_EMAIL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cMaxlength=>254
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549789555753698
,p_item_icon_css_classes=>'fa-envelope-o'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Provide the employee email for this expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'EMAIL',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2408596530162079)
,p_name=>'P2_EMPLOYEE_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Employee Name'
,p_source=>'EMPLOYEE_NAME'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cMaxlength=>100
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549789555753698
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Provide the employee name for this expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2804751343491037)
,p_name=>'P2_MANAGER_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(2803144611491017)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Manager Email'
,p_source=>'MANAGER_EMAIL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cMaxlength=>254
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Use a fictional manager email address for the approval contact.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'EMAIL',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2805506912491037)
,p_name=>'P2_PAYMENT_METHOD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(2803236556491017)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Payment Method'
,p_source=>'PAYMENT_METHOD'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Bank Transfer;BANK_TRANSFER,Payroll;PAYROLL,Corporate Card;CORPORATE_CARD'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_help_text=>'Optional payment method for this fictional expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2805922857491037)
,p_name=>'P2_POLICY_ACCEPTED_YN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(2803236556491017)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_item_default=>'N'
,p_prompt=>'Policy Reviewed'
,p_source=>'POLICY_ACCEPTED_YN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Yes;Y,No;N'
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_help_text=>'Record whether the expense policy has been reviewed; this sample does not submit approvals.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2804569230491037)
,p_name=>'P2_PROJECT_CODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(2803144611491017)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Project Code'
,p_source=>'PROJECT_CODE'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cMaxlength=>40
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Optional project code for this fictional expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2408962883162079)
,p_name=>'P2_REPORT_DATE'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Report Date'
,p_format_mask=>'YYYY-MM-DD'
,p_source=>'REPORT_DATE'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Provide the expense report date for this expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2408225226162077)
,p_name=>'P2_REPORT_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_source=>'REPORT_ID'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2408303590162079)
,p_name=>'P2_REPORT_TITLE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Report Title'
,p_source=>'REPORT_TITLE'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cMaxlength=>200
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Provide the expense report title for this expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2409369736162080)
,p_name=>'P2_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_item_default=>'DRAFT'
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Draft;DRAFT,Submitted;SUBMITTED,Approved;APPROVED,Paid;PAID,Returned;RETURNED'
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_help_text=>'Provide the status for this expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2409737437162080)
,p_name=>'P2_SUBMITTED_ON'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(2803236556491017)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Submitted On'
,p_format_mask=>'YYYY-MM-DD HH24:MI'
,p_source=>'SUBMITTED_ON'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Provide the submitted on for this expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2805332354491037)
,p_name=>'P2_TRAVEL_END'
,p_source_data_type=>'DATE'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(2803034776491017)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Travel End'
,p_format_mask=>'YYYY-MM-DD'
,p_source=>'TRAVEL_END'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Choose the last travel date. It cannot be before Travel Start.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2805162203491037)
,p_name=>'P2_TRAVEL_START'
,p_source_data_type=>'DATE'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(2803034776491017)
,p_item_source_plug_id=>wwv_flow_imp.id(2408018776162077)
,p_prompt=>'Travel Start'
,p_format_mask=>'YYYY-MM-DD'
,p_source=>'TRAVEL_START'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_colspan=>6
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Optional travel start for this fictional expense report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(2813965350540114)
,p_validation_name=>'Travel dates in order'
,p_static_id=>'travel-dates'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P2_TRAVEL_START is null or :P2_TRAVEL_END is null',
'or to_date(:P2_TRAVEL_END,''YYYY-MM-DD'') >= to_date(:P2_TRAVEL_START,''YYYY-MM-DD'')'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Travel End must be on or after Travel Start.'
,p_associated_item=>wwv_flow_imp.id(2805332354491037)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2410679476162105)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(2408018776162077)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize Expense Report'
,p_static_id=>'initialize'
,p_internal_uid=>731000201
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2410702715162106)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(2408018776162077)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Save Expense Report'
,p_static_id=>'save'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'prevent_lost_updates', 'Y',
  'return_primary_keys_after_insert', 'Y',
  'target_type', 'REGION_SOURCE')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Expense Report saved.'
,p_internal_uid=>731000202
);
wwv_flow_imp.component_end;
end;
/
