prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7310
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Receipt'
,p_alias=>'RECEIPT'
,p_page_mode=>'MODAL'
,p_step_title=>'Receipt'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1664614232864994871
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_width=>'760'
,p_dialog_chained=>'N'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>When to use</h3>',
'<p>Use this drawer to attach a document to an expense and maintain its details without navigating away from the receipt report.</p>',
'<h3>About this form</h3>',
'<p>Expense identifies the parent expense line. Description explains the purchase or document. The native drop zone accepts PNG, JPEG, and PDF files up to 10 MB; a file is required for a new receipt. The save process also checks the file type, signatu'
||'re, size, and filename length.</p>',
'<h3>How the components work together</h3>',
'<p>The upload first enters application temporary storage. The save process copies it to the receipt BLOB and records its filename and MIME type. Conditional preview regions display the saved image or PDF through the receipt-file page.</p>',
'<p>For an existing receipt, leave Receipt File empty to retain the current document while editing its details. Select another file to replace it. Cancel discards unsaved edits. Delete requires confirmation and removes only this receipt, keeping its p'
||'arent expense.</p>'))
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2417477495162108)
,p_plug_name=>'Buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2129856781885180476
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2417364149162108)
,p_plug_name=>'Receipt'
,p_static_id=>'form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'TABLE'
,p_query_table=>'SFM_EXPENSE_RECEIPTS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2442110964270279)
,p_plug_name=>'Image Preview'
,p_static_id=>'image-preview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h3:t-ContentBlock--shadowBG:margin-top-md'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<img src="&P6_PREVIEW_URL!ATTR." alt="Uploaded receipt" class="sfm-receipt-image">'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P6_RECEIPT_ID is not null and :P6_MIME_TYPE like ''image/%'''
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2417594237162108)
,p_plug_name=>'PDF Preview'
,p_static_id=>'preview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:margin-top-md'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<iframe src="&P6_PREVIEW_URL!ATTR." title="Receipt preview" class="sfm-receipt-pdf"></iframe>'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P6_RECEIPT_ID is not null and :P6_MIME_TYPE = ''application/pdf'''
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2419055542162109)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2417477495162108)
,p_button_name=>'APPLY-CHANGES'
,p_static_id=>'apply-changes'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Save Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P6_RECEIPT_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2418830076162109)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2417477495162108)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_show_as_disabled=>false
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2418988266162109)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(2417477495162108)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P6_RECEIPT_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2419138728162109)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2417477495162108)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'Delete this record and its dependent sample records?'
,p_confirm_style=>'danger'
,p_button_condition=>'P6_RECEIPT_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2417922746162108)
,p_name=>'P6_CAPTION'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_item_source_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_prompt=>'Description'
,p_source=>'CAPTION'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cMaxlength=>200
,p_cHeight=>5
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>'Describe the purchase or expense shown on the receipt.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2418493940162108)
,p_name=>'P6_FILENAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_item_source_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_source=>'FILENAME'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2418557349162109)
,p_name=>'P6_FILE_CHARSET'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_item_source_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_source=>'FILE_CHARSET'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2418121425162108)
,p_name=>'P6_FILE_CONTENT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_prompt=>'Receipt File'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_FILE'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>'Maximum file size is 10 MB. Leave blank when editing to keep the existing file.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_copy_paste', 'N',
  'allow_multiple_files', 'N',
  'display_as', 'DROPZONE_BLOCK',
  'dropzone_description', 'PNG, JPEG or PDF - up to 10 MB',
  'dropzone_title', 'Drop your receipt here',
  'file_types', 'image/png,image/jpeg,application/pdf',
  'max_file_size', '10240',
  'purge_file_at', 'SESSION',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2418666940162109)
,p_name=>'P6_FILE_UPDATED_ON'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_item_source_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_source=>'FILE_UPDATED_ON'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2418354599162108)
,p_name=>'P6_MIME_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_item_source_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_source=>'MIME_TYPE'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2418777758162109)
,p_name=>'P6_PREVIEW_URL'
,p_item_sequence=>1000
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2417671356162108)
,p_name=>'P6_RECEIPT_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_item_source_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_source=>'RECEIPT_ID'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2417791717162108)
,p_name=>'P6_REPORT_LINE_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_item_source_plug_id=>wwv_flow_imp.id(2417364149162108)
,p_prompt=>'Expense'
,p_source=>'REPORT_LINE_ID'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select c.report_title || '' - '' || l.merchant || '' ('' || to_char(l.amount,''FM9G999G999G990D00'') || '')'' d,l.report_line_id r from sfm_expense_report_lines l join sfm_expense_reports c on c.report_id=l.report_id order by l.report_line_id'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_field_alignment=>'LEFT-CENTER'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2419249774162109)
,p_name=>'Cancel Dialog'
,p_static_id=>'cancel-dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2418830076162109)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2419375240162109)
,p_event_id=>wwv_flow_imp.id(2419249774162109)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'cancel'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2419505010162109)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_static_id=>'close-dialog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'Y')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,APPLY-CHANGES,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>731000602
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2419430209162109)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(2417364149162108)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize Receipt'
,p_static_id=>'initialize'
,p_internal_uid=>731000601
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2419773624162109)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Receipt Preview'
,p_static_id=>'preview-url'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if apex_application.g_request is null then',
'    :P6_FILE_CONTENT := null;',
'end if;',
'if :P6_RECEIPT_ID is not null then',
'    :P6_PREVIEW_URL := apex_page.get_url(p_page=>9,p_clear_cache=>''9'',',
'        p_items=>''P9_RECEIPT_ID'',p_values=>:P6_RECEIPT_ID,p_plain_url=>true);',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>731000621
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2419604852162109)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Receipt'
,p_static_id=>'save-receipt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_blob blob;',
'    l_mime varchar2(128);',
'    l_name varchar2(255);',
'    l_sig varchar2(16);',
'begin',
'    if :REQUEST = ''DELETE'' then',
'        delete from sfm_expense_receipts where receipt_id = :P6_RECEIPT_ID;',
'    else',
'        if :P6_FILE_CONTENT is not null then',
'            select blob_content, mime_type, filename into l_blob, l_mime, l_name',
'              from apex_application_temp_files where name = :P6_FILE_CONTENT',
'               and application_id = :APP_ID;',
'            if length(l_name) > 255 then',
'                raise_application_error(-20001,''Choose a receipt with a file name of 255 characters or fewer.'');',
'            end if;',
'            l_sig := rawtohex(sys.dbms_lob.substr(l_blob,4,1));',
'            if sys.dbms_lob.getlength(l_blob) > 10485760 then',
'                raise_application_error(-20001,''The receipt must be 10 MB or smaller.'');',
'            end if;',
'            if not (',
'                (l_mime=''application/pdf'' and l_sig=''25504446'') or',
'                (l_mime=''image/png'' and l_sig=''89504E47'') or',
'                (l_mime=''image/jpeg'' and substr(l_sig,1,6)=''FFD8FF'')) then',
'                raise_application_error(-20001,''Choose a PNG, JPEG or PDF receipt.'');',
'            end if;',
'        end if;',
'        if :P6_RECEIPT_ID is null then',
'            if l_blob is null then',
'                raise_application_error(-20001,''Choose a receipt file before saving.'');',
'            end if;',
'            insert into sfm_expense_receipts(report_line_id,caption,file_content,mime_type,filename)',
'            values (:P6_REPORT_LINE_ID,:P6_CAPTION,l_blob,l_mime,l_name)',
'            returning receipt_id into :P6_RECEIPT_ID;',
'        else',
'            update sfm_expense_receipts',
'               set report_line_id=:P6_REPORT_LINE_ID,caption=:P6_CAPTION',
'             where receipt_id=:P6_RECEIPT_ID;',
'            if l_blob is not null then',
'                update sfm_expense_receipts',
'                   set file_content=l_blob,mime_type=l_mime,filename=l_name,file_updated_on=systimestamp',
'                 where receipt_id=:P6_RECEIPT_ID;',
'            end if;',
'        end if;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,APPLY-CHANGES,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_process_success_message=>'Receipt saved.'
,p_internal_uid=>731000620
);
wwv_flow_imp.component_end;
end;
/
