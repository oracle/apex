prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7310
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'FP-02 - Form with Attachment'
,p_alias=>'RECEIPTS'
,p_step_title=>'FP-02 - Form with Attachment'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>When to use</h3>',
'<p>Use this pattern when a record needs an image or PDF as well as editable details. It suits receipts, invoices, and supporting documents that users need to upload, review, and describe.</p>',
'<h3>About this pattern page</h3>',
'<p>The Interactive Report shows each receipt''s report, expense, description, filename, type, size, and update time. Open a filename to view its stored document, use Edit to open the receipt drawer, or choose Upload Receipt to add one.</p>',
'<p>In the drawer, select an expense line, enter a description, and choose or drop a PNG, JPEG, or PDF of up to 10 MB. Existing receipts show an image or PDF preview. Save Changes can update the description or expense association without replacing the'
||' file; choose another file to replace its contents.</p>',
'<h3>Components used</h3>',
'<ul>',
'<li><strong>Interactive Report and drawer form:</strong> Combine document browsing with focused editing.</li>',
'<li><strong>Native File Upload and temporary files:</strong> Receive the selected attachment before the save process validates and stores its BLOB, filename, and MIME type.</li>',
'<li><strong>Preview regions and a download page:</strong> Present the saved file using a checksummed link.</li>',
'</ul>',
'<p>Use demonstration documents. Deleting a receipt removes that receipt and its stored file; the associated expense line remains.</p>'))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2415697853162107)
,p_plug_name=>'FP-02 - Form with Attachment'
,p_static_id=>'page-heading'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useRegionTitle'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2415844550162107)
,p_plug_name=>'Receipts'
,p_static_id=>'records'
,p_region_name=>'receipts-report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2103954283454391425
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>'select a.receipt_id,c.report_title,l.merchant,a.caption,a.filename,a.mime_type,round(dbms_lob.getlength(a.file_content)/1024,1) size_kb,a.file_updated_on from sfm_expense_receipts a join sfm_expense_report_lines l on l.report_line_id=a.report_line_id'
||' join sfm_expense_reports c on c.report_id=l.report_id'
,p_plug_source_type=>'NATIVE_IR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2415997723162107)
,p_no_data_found_message=>'No records found. Use the create button to add one.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_RECEIPT_ID:#RECEIPT_ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_internal_uid=>2415997723162107
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2416391555162107)
,p_db_column_name=>'CAPTION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Receipt'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'Y'
,p_available_clientside=>'N'
,p_column_comment=>'Receipt for the receipts report.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2416453222162107)
,p_db_column_name=>'FILENAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'File'
,p_column_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:9:P9_RECEIPT_ID:#RECEIPT_ID#'
,p_column_linktext=>'#FILENAME#'
,p_column_link_attr=>'target="_blank" rel="noopener"'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_column_comment=>'File for the receipts report.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2416731842162108)
,p_db_column_name=>'FILE_UPDATED_ON'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'YYYY-MM-DD HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_column_comment=>'Updated for the receipts report.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2416250400162107)
,p_db_column_name=>'MERCHANT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Expense'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_column_comment=>'Expense for the receipts report.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2416580512162108)
,p_db_column_name=>'MIME_TYPE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_column_comment=>'Type for the receipts report.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2416017063162107)
,p_db_column_name=>'RECEIPT_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Receipt ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_column_comment=>'Receipt ID for the receipts report.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2416199984162107)
,p_db_column_name=>'REPORT_TITLE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Expense Report'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_column_comment=>'Expense Report for the receipts report.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2416619926162108)
,p_db_column_name=>'SIZE_KB'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Size (KB)'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_column_comment=>'Size (KB) for the receipts report.'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2416891895162108)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'primary'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'REPORT_TITLE:MERCHANT:CAPTION:FILENAME:MIME_TYPE:SIZE_KB:FILE_UPDATED_ON'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2416979580162108)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2415697853162107)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Upload Receipt'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2417048936162108)
,p_name=>'Refresh after editing'
,p_static_id=>'refresh-records'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'body'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2417122578162108)
,p_event_id=>wwv_flow_imp.id(2417048936162108)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2415844550162107)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
