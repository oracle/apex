prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7310
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'Receipt File'
,p_alias=>'RECEIPT-FILE'
,p_step_title=>'Receipt File'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4075783602716660119
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2423153073162118)
,p_name=>'P9_RECEIPT_ID'
,p_item_sequence=>1000
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(2423244921162118)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Open Receipt'
,p_static_id=>'download'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_blob blob;',
'    l_mime varchar2(128);',
'    l_name varchar2(255);',
'begin',
'    select file_content,mime_type,filename into l_blob,l_mime,l_name',
'      from sfm_expense_receipts where receipt_id=:P9_RECEIPT_ID;',
'    apex_http.download(p_blob=>l_blob,p_content_type=>l_mime,',
'        p_filename=>l_name,p_is_inline=>true);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>731000910
);
wwv_flow_imp.component_end;
end;
/
