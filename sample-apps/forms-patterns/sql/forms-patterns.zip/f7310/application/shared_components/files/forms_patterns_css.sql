prompt --application/shared_components/files/forms_patterns_css
begin
--   Manifest
--     APP STATIC FILES: 7310
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7310
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E73666D2D726563656970742D706466207B0A2020202077696474683A20313030253B0A202020206865696768743A2033343070783B0A20202020626F726465723A20303B0A7D0A2E73666D2D726563656970742D696D616765207B0A202020206D6178';
wwv_flow_imp.g_varchar2_table(2) := '2D77696474683A20313030253B0A202020206D61782D6865696768743A2033363070783B0A20202020646973706C61793A20626C6F636B3B0A202020206D617267696E3A206175746F3B0A7D0A';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(4201536753430587)
,p_file_name=>'forms-patterns.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
