prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7310
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(2404778558162046)
,p_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2802042372490998)
,p_parent_id=>wwv_flow_imp.id(2801712209490998)
,p_option_sequence=>40
,p_short_name=>'FP-03 - Advanced Form'
,p_static_id=>'advanced'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2801939830490998)
,p_parent_id=>wwv_flow_imp.id(2801712209490998)
,p_option_sequence=>30
,p_short_name=>'FP-02 - Form with Attachment'
,p_static_id=>'attachment'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2802125163490998)
,p_parent_id=>wwv_flow_imp.id(2801712209490998)
,p_option_sequence=>50
,p_short_name=>'FP-04 - Editable Grid'
,p_static_id=>'grid'
,p_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.'
,p_page_id=>11
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2801712209490998)
,p_short_name=>'Home'
,p_static_id=>'home'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.'
,p_page_id=>10
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2801856954490998)
,p_parent_id=>wwv_flow_imp.id(2801712209490998)
,p_option_sequence=>20
,p_short_name=>'FP-01 - Simple Form'
,p_static_id=>'simple'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.'
,p_page_id=>7
);
wwv_flow_imp.component_end;
end;
/
