prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7310
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7310
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- Remove only this application''s tables, children before parents.'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for t in (select column';
wwv_flow_imp.g_varchar2_table(2) := '_value table_name'||wwv_flow.LF||
'                from table(sys.odcivarchar2list('||wwv_flow.LF||
'                    ''SFM_EXPENSE_';
wwv_flow_imp.g_varchar2_table(3) := 'RECEIPTS'',''SFM_EXPENSE_REPORT_LINES'','||wwv_flow.LF||
'                    ''SFM_EXPENSE_REPORTS'',''SFM_EXPENSE_CATEGOR';
wwv_flow_imp.g_varchar2_table(4) := 'IES''))) loop'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            execute immediate ''drop table '' || t.table_name || '' cascade ';
wwv_flow_imp.g_varchar2_table(5) := 'constraints purge'';'||wwv_flow.LF||
'        exception'||wwv_flow.LF||
'            when others then'||wwv_flow.LF||
'                if sqlcode != -94';
wwv_flow_imp.g_varchar2_table(6) := '2 then'||wwv_flow.LF||
'                    raise;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'        end;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(2406003813162048)
,p_welcome_message=>'Install the Forms Patterns tables and fictional sample data, including image and PDF receipts.'
,p_install_message=>'Install supporting objects in a parsing schema that does not already contain the SFM expense tables.'
,p_install_success_message=>'Forms Patterns supporting objects and sample data installed.'
,p_install_failure_message=>'Supporting objects could not be installed. Review the installation log before running the application.'
,p_deinstall_success_message=>'Forms Patterns supporting objects removed.'
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_sys_privs=>'CREATE TABLE'
,p_deinstall_message=>'Remove the four SFM expense tables and all of their data? This also removes their indexes and constraints.'
);
wwv_flow_imp.component_end;
end;
/
