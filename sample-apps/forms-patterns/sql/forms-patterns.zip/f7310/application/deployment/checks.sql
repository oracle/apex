prompt --application/deployment/checks
begin
--   Manifest
--     INSTALL CHECKS: 7310
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7310
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_check(
 p_id=>wwv_flow_imp.id(4201658268430591)
,p_install_id=>wwv_flow_imp.id(2406003813162048)
,p_name=>'no-existing-expense-tables'
,p_sequence=>10
,p_check_type=>'NOT_EXISTS'
,p_check_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from user_tables',
' where table_name in (''SFM_EXPENSE_CATEGORIES'',''SFM_EXPENSE_REPORTS'',',
'                      ''SFM_EXPENSE_REPORT_LINES'',''SFM_EXPENSE_RECEIPTS'')'))
,p_failure_message=>'The parsing schema already contains Forms Patterns expense tables. Use a fresh schema or reuse the existing supporting objects.'
);
wwv_flow_imp.component_end;
end;
/
