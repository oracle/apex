prompt --application/deployment/install/install_forms_patterns_sample_data
begin
--   Manifest
--     INSTALL: INSTALL-forms-patterns-sample-data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7310
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into sfm_expense_categories(category_id,category_name,description) values(1,''Travel'',''Airfare';
wwv_flow_imp.g_varchar2_table(2) := ', rail, and local transit'');'||wwv_flow.LF||
'insert into sfm_expense_categories(category_id,category_name,descriptio';
wwv_flow_imp.g_varchar2_table(3) := 'n) values(2,''Accommodation'',''Hotel and overnight stays'');'||wwv_flow.LF||
'insert into sfm_expense_categories(categor';
wwv_flow_imp.g_varchar2_table(4) := 'y_id,category_name,description) values(3,''Meals'',''Business meals and refreshments'');'||wwv_flow.LF||
'insert into sfm';
wwv_flow_imp.g_varchar2_table(5) := '_expense_categories(category_id,category_name,description) values(4,''Office'',''Office supplies and eq';
wwv_flow_imp.g_varchar2_table(6) := 'uipment'');'||wwv_flow.LF||
'insert into sfm_expense_categories(category_id,category_name,description) values(5,''Train';
wwv_flow_imp.g_varchar2_table(7) := 'ing'',''Courses and learning materials'');'||wwv_flow.LF||
'insert into sfm_expense_categories(category_id,category_name';
wwv_flow_imp.g_varchar2_table(8) := ',description) values(6,''Other'',''Other business expenses'');'||wwv_flow.LF||
'insert into sfm_expense_reports(report_id';
wwv_flow_imp.g_varchar2_table(9) := ',report_title,employee_name,employee_email,report_date,currency_code,status,business_justification,s';
wwv_flow_imp.g_varchar2_table(10) := 'ubmitted_on) values (1,''Developer Summit - San Francisco'',''Avery Chen'',''avery.chen@example.com'',trun';
wwv_flow_imp.g_varchar2_table(11) := 'c(sysdate)-1,''USD'',''SUBMITTED'',to_clob(''Conference attendance and customer workshops. Includes hotel';
wwv_flow_imp.g_varchar2_table(12) := ', transit and meals. Receipts are attached.''),systimestamp-interval ''2'' day);'||wwv_flow.LF||
'insert into sfm_expens';
wwv_flow_imp.g_varchar2_table(13) := 'e_reports(report_id,report_title,employee_name,employee_email,report_date,currency_code,status,busin';
wwv_flow_imp.g_varchar2_table(14) := 'ess_justification,submitted_on) values (2,''Customer workshop - London'',''Jordan Morgan'',''jordan.morga';
wwv_flow_imp.g_varchar2_table(15) := 'n@example.com'',trunc(sysdate)-2,''GBP'',''APPROVED'',to_clob(''On-site discovery and solution design work';
wwv_flow_imp.g_varchar2_table(16) := 'shop. All figures are in GBP.''),systimestamp-interval ''2'' day);'||wwv_flow.LF||
'insert into sfm_expense_reports(repo';
wwv_flow_imp.g_varchar2_table(17) := 'rt_id,report_title,employee_name,employee_email,report_date,currency_code,status,business_justificat';
wwv_flow_imp.g_varchar2_table(18) := 'ion,submitted_on) values (3,''Home office refresh'',''Sam Rivera'',''sam.rivera@example.com'',trunc(sysdat';
wwv_flow_imp.g_varchar2_table(19) := 'e)-3,''USD'',''DRAFT'',to_clob(''Replacement keyboard and home office accessories. Includes a negative re';
wwv_flow_imp.g_varchar2_table(20) := 'fund for a returned item and a zero-cost replacement.''),null);'||wwv_flow.LF||
'insert into sfm_expense_reports(repor';
wwv_flow_imp.g_varchar2_table(21) := 't_id,report_title,employee_name,employee_email,report_date,currency_code,status,business_justificati';
wwv_flow_imp.g_varchar2_table(22) := 'on,submitted_on) values (4,''Training and certification'',''Taylor Brooks'',''taylor.brooks@example.com'',';
wwv_flow_imp.g_varchar2_table(23) := 'trunc(sysdate)-4,''USD'',''PAID'',to_clob(''Professional development expenses and course materials.''),sys';
wwv_flow_imp.g_varchar2_table(24) := 'timestamp-interval ''2'' day);'||wwv_flow.LF||
'insert into sfm_expense_reports(report_id,report_title,employee_name,em';
wwv_flow_imp.g_varchar2_table(25) := 'ployee_email,report_date,currency_code,status,business_justification,submitted_on) values (5,''Octobe';
wwv_flow_imp.g_varchar2_table(26) := 'r team planning'',''Casey Patel'',''casey.patel@example.com'',trunc(sysdate)-5,''USD'',''RETURNED'',to_clob(''';
wwv_flow_imp.g_varchar2_table(27) := 'Planning session expenses. Please add the missing receipt before resubmitting.''),systimestamp-interv';
wwv_flow_imp.g_varchar2_table(28) := 'al ''2'' day);'||wwv_flow.LF||
'insert into sfm_expense_reports(report_id,report_title,employee_name,employee_email,rep';
wwv_flow_imp.g_varchar2_table(29) := 'ort_date,currency_code,status,business_justification,submitted_on) values (6,''Long-text form example';
wwv_flow_imp.g_varchar2_table(30) := ''',''Alex Kim'',''alex.kim@example.com'',trunc(sysdate)-6,''USD'',''DRAFT'',to_clob(''This record demonstrates';
wwv_flow_imp.g_varchar2_table(31) := ' a CLOB justification exceeding 32 KB.''),null);'||wwv_flow.LF||
'declare l_text clob; begin select business_justifica';
wwv_flow_imp.g_varchar2_table(32) := 'tion into l_text from sfm_expense_reports where report_id=6 for update; for i in 1..700 loop dbms_lo';
wwv_flow_imp.g_varchar2_table(33) := 'b.writeappend(l_text,length(chr(10)||''Sample paragraph ''||i||'': Meeting goals, outcomes, customer fe';
wwv_flow_imp.g_varchar2_table(34) := 'edback, and business justification.''),chr(10)||''Sample paragraph ''||i||'': Meeting goals, outcomes, c';
wwv_flow_imp.g_varchar2_table(35) := 'ustomer feedback, and business justification.''); end loop; end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'insert into sfm_expense_report_lin';
wwv_flow_imp.g_varchar2_table(36) := 'es(report_line_id,report_id,category_id,expense_date,merchant,description,amount,reimbursable_yn) va';
wwv_flow_imp.g_varchar2_table(37) := 'lues(1,1,2,trunc(sysdate)-2,''Harbor Hotel'',''Three nights near the conference venue'',785.5,''Y'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(38) := 'rt into sfm_expense_report_lines(report_line_id,report_id,category_id,expense_date,merchant,descript';
wwv_flow_imp.g_varchar2_table(39) := 'ion,amount,reimbursable_yn) values(2,1,1,trunc(sysdate)-2,''Metro Transit'',''Airport and local rail tr';
wwv_flow_imp.g_varchar2_table(40) := 'avel'',32.75,''Y'');'||wwv_flow.LF||
'insert into sfm_expense_report_lines(report_line_id,report_id,category_id,expense_';
wwv_flow_imp.g_varchar2_table(41) := 'date,merchant,description,amount,reimbursable_yn) values(3,1,3,trunc(sysdate)-2,''Market Street Cafe''';
wwv_flow_imp.g_varchar2_table(42) := ',''Working lunch with project team'',48.6,''Y'');'||wwv_flow.LF||
'insert into sfm_expense_report_lines(report_line_id,re';
wwv_flow_imp.g_varchar2_table(43) := 'port_id,category_id,expense_date,merchant,description,amount,reimbursable_yn) values(4,1,1,trunc(sys';
wwv_flow_imp.g_varchar2_table(44) := 'date)-2,''Airline refund'',''Refund for unused seat upgrade'',-85.0,''Y'');'||wwv_flow.LF||
'insert into sfm_expense_report';
wwv_flow_imp.g_varchar2_table(45) := '_lines(report_line_id,report_id,category_id,expense_date,merchant,description,amount,reimbursable_yn';
wwv_flow_imp.g_varchar2_table(46) := ') values(5,2,1,trunc(sysdate)-3,''City Rail'',''Return rail ticket'',64.2,''Y'');'||wwv_flow.LF||
'insert into sfm_expense_';
wwv_flow_imp.g_varchar2_table(47) := 'report_lines(report_line_id,report_id,category_id,expense_date,merchant,description,amount,reimbursa';
wwv_flow_imp.g_varchar2_table(48) := 'ble_yn) values(6,2,2,trunc(sysdate)-3,''Riverside Hotel'',''Two nights for customer workshop'',410.0,''Y''';
wwv_flow_imp.g_varchar2_table(49) := ');'||wwv_flow.LF||
'insert into sfm_expense_report_lines(report_line_id,report_id,category_id,expense_date,merchant,d';
wwv_flow_imp.g_varchar2_table(50) := 'escription,amount,reimbursable_yn) values(7,2,3,trunc(sysdate)-3,''Workshop Catering'',''Team lunch'',12';
wwv_flow_imp.g_varchar2_table(51) := '5.5,''Y'');'||wwv_flow.LF||
'insert into sfm_expense_report_lines(report_line_id,report_id,category_id,expense_date,mer';
wwv_flow_imp.g_varchar2_table(52) := 'chant,description,amount,reimbursable_yn) values(8,3,4,trunc(sysdate)-4,''Desk Supply Co'',''Ergonomic ';
wwv_flow_imp.g_varchar2_table(53) := 'keyboard'',129.99,''Y'');'||wwv_flow.LF||
'insert into sfm_expense_report_lines(report_line_id,report_id,category_id,exp';
wwv_flow_imp.g_varchar2_table(54) := 'ense_date,merchant,description,amount,reimbursable_yn) values(9,3,4,trunc(sysdate)-4,''Desk Supply Co';
wwv_flow_imp.g_varchar2_table(55) := ' - return'',''Refund for incompatible adapter'',-39.95,''Y'');'||wwv_flow.LF||
'insert into sfm_expense_report_lines(repor';
wwv_flow_imp.g_varchar2_table(56) := 't_line_id,report_id,category_id,expense_date,merchant,description,amount,reimbursable_yn) values(10,';
wwv_flow_imp.g_varchar2_table(57) := '3,4,trunc(sysdate)-4,''Warranty replacement'',''Replacement at no additional charge'',0.0,''Y'');'||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(58) := 'nto sfm_expense_report_lines(report_line_id,report_id,category_id,expense_date,merchant,description,';
wwv_flow_imp.g_varchar2_table(59) := 'amount,reimbursable_yn) values(11,4,5,trunc(sysdate)-5,''Learning Academy'',''Technical certification c';
wwv_flow_imp.g_varchar2_table(60) := 'ourse'',299.0,''Y'');'||wwv_flow.LF||
'insert into sfm_expense_report_lines(report_line_id,report_id,category_id,expense';
wwv_flow_imp.g_varchar2_table(61) := '_date,merchant,description,amount,reimbursable_yn) values(12,4,5,trunc(sysdate)-5,''Bookshop'',''Refere';
wwv_flow_imp.g_varchar2_table(62) := 'nce materials'',54.8,''Y'');'||wwv_flow.LF||
'insert into sfm_expense_report_lines(report_line_id,report_id,category_id,';
wwv_flow_imp.g_varchar2_table(63) := 'expense_date,merchant,description,amount,reimbursable_yn) values(13,5,3,trunc(sysdate)-6,''Corner Kit';
wwv_flow_imp.g_varchar2_table(64) := 'chen'',''Team planning lunch'',186.45,''Y'');'||wwv_flow.LF||
'insert into sfm_expense_report_lines(report_line_id,report_';
wwv_flow_imp.g_varchar2_table(65) := 'id,category_id,expense_date,merchant,description,amount,reimbursable_yn) values(14,5,6,trunc(sysdate';
wwv_flow_imp.g_varchar2_table(66) := ')-6,''Meeting Supplies'',''Whiteboard supplies'',22.3,''Y'');'||wwv_flow.LF||
'insert into sfm_expense_report_lines(report_';
wwv_flow_imp.g_varchar2_table(67) := 'line_id,report_id,category_id,expense_date,merchant,description,amount,reimbursable_yn) values(15,6,';
wwv_flow_imp.g_varchar2_table(68) := '6,trunc(sysdate)-7,''Documentation example'',''Long CLOB content demonstration'',15.0,''Y'');'||wwv_flow.LF||
'insert into ';
wwv_flow_imp.g_varchar2_table(69) := 'sfm_expense_reports(report_id,report_title,employee_name,employee_email,report_date,currency_code,st';
wwv_flow_imp.g_varchar2_table(70) := 'atus,business_justification,submitted_on)'||wwv_flow.LF||
'values(7,''Regional planning workshop'',''Morgan Lee'',''morgan';
wwv_flow_imp.g_varchar2_table(71) := '.lee@example.com'',trunc(sysdate),''USD'',''SUBMITTED'',to_clob(''Travel and working meals for the regiona';
wwv_flow_imp.g_varchar2_table(72) := 'l planning workshop. Includes image and PDF receipts.''),systimestamp);'||wwv_flow.LF||
'insert into sfm_expense_repor';
wwv_flow_imp.g_varchar2_table(73) := 't_lines(report_line_id,report_id,category_id,expense_date,merchant,description,amount,reimbursable_y';
wwv_flow_imp.g_varchar2_table(74) := 'n)'||wwv_flow.LF||
'values(16,7,3,trunc(sysdate),''Workshop Cafe'',''Working lunch after the regional planning session'',';
wwv_flow_imp.g_varchar2_table(75) := '48.60,''Y'');'||wwv_flow.LF||
'commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'update sfm_expense_reports'||wwv_flow.LF||
'set department=case when mod(report_id,2)=0 then ''Pr';
wwv_flow_imp.g_varchar2_table(76) := 'oduct Development'' else ''Customer Success'' end,'||wwv_flow.LF||
'    cost_center=''CC-410'', project_code=''APEX-262'', m';
wwv_flow_imp.g_varchar2_table(77) := 'anager_email=''manager@example.com'','||wwv_flow.LF||
'    destination=case when currency_code=''GBP'' then ''London'' else';
wwv_flow_imp.g_varchar2_table(78) := ' ''San Francisco'' end,'||wwv_flow.LF||
'    travel_start=report_date-3, travel_end=report_date,'||wwv_flow.LF||
'    payment_method=''BA';
wwv_flow_imp.g_varchar2_table(79) := 'NK_TRANSFER'', advance_amount=case when mod(report_id,2)=0 then -25 else 100 end,'||wwv_flow.LF||
'    policy_accepted';
wwv_flow_imp.g_varchar2_table(80) := '_yn=''Y'', contact_phone=''+1 415 555 0100'';'||wwv_flow.LF||
'commit;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(4202292531430592)
,p_install_id=>wwv_flow_imp.id(2406003813162048)
,p_name=>'forms-patterns-sample-data'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
