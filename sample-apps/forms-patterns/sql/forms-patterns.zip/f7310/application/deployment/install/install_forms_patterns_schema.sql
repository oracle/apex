prompt --application/deployment/install/install_forms_patterns_schema
begin
--   Manifest
--     INSTALL: INSTALL-forms-patterns-schema
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7310
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sfm_expense_categories ('||wwv_flow.LF||
' category_id number default on null to_number(sys_guid(),''XXXX';
wwv_flow_imp.g_varchar2_table(2) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXX'') primary key,'||wwv_flow.LF||
' category_name varchar2(80 char) not null unique,'||wwv_flow.LF||
' descr';
wwv_flow_imp.g_varchar2_table(3) := 'iption varchar2(500 char),'||wwv_flow.LF||
' active_yn varchar2(1 char) default ''Y'' not null check (active_yn in (''Y''';
wwv_flow_imp.g_varchar2_table(4) := ',''N''))'||wwv_flow.LF||
');'||wwv_flow.LF||
'create table sfm_expense_reports ('||wwv_flow.LF||
' report_id number default on null to_number(sys_guid(),';
wwv_flow_imp.g_varchar2_table(5) := '''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') primary key,'||wwv_flow.LF||
' report_title varchar2(200 char) not null,'||wwv_flow.LF||
' employe';
wwv_flow_imp.g_varchar2_table(6) := 'e_name varchar2(100 char) not null,'||wwv_flow.LF||
' employee_email varchar2(254 char) not null,'||wwv_flow.LF||
' report_date date d';
wwv_flow_imp.g_varchar2_table(7) := 'efault trunc(sysdate) not null,'||wwv_flow.LF||
' currency_code varchar2(3 char) default ''USD'' not null check (curren';
wwv_flow_imp.g_varchar2_table(8) := 'cy_code in (''USD'',''EUR'',''GBP'',''CAD'')),'||wwv_flow.LF||
' status varchar2(20 char) default ''DRAFT'' not null check (sta';
wwv_flow_imp.g_varchar2_table(9) := 'tus in (''DRAFT'',''SUBMITTED'',''APPROVED'',''PAID'',''RETURNED'')),'||wwv_flow.LF||
' business_justification clob,'||wwv_flow.LF||
' submitted';
wwv_flow_imp.g_varchar2_table(10) := '_on timestamp,'||wwv_flow.LF||
' created_on timestamp default systimestamp not null,'||wwv_flow.LF||
' department varchar2(100 char),'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(11) := ' cost_center varchar2(30 char),'||wwv_flow.LF||
' project_code varchar2(40 char),'||wwv_flow.LF||
' manager_email varchar2(254 char),'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(12) := ' destination varchar2(150 char),'||wwv_flow.LF||
' travel_start date,'||wwv_flow.LF||
' travel_end date,'||wwv_flow.LF||
' payment_method varchar2(20 c';
wwv_flow_imp.g_varchar2_table(13) := 'har) default ''BANK_TRANSFER'','||wwv_flow.LF||
' advance_amount number(12,2),'||wwv_flow.LF||
' policy_accepted_yn varchar2(1 char) def';
wwv_flow_imp.g_varchar2_table(14) := 'ault ''N'' not null,'||wwv_flow.LF||
' contact_phone varchar2(40 char),'||wwv_flow.LF||
' constraint sfm_reports_payment_ck check (payme';
wwv_flow_imp.g_varchar2_table(15) := 'nt_method in (''BANK_TRANSFER'',''PAYROLL'',''CORPORATE_CARD'')),'||wwv_flow.LF||
' constraint sfm_reports_policy_ck check ';
wwv_flow_imp.g_varchar2_table(16) := '(policy_accepted_yn in (''Y'',''N'')),'||wwv_flow.LF||
' constraint sfm_reports_travel_ck check (travel_end >= travel_sta';
wwv_flow_imp.g_varchar2_table(17) := 'rt)'||wwv_flow.LF||
');'||wwv_flow.LF||
'create table sfm_expense_report_lines ('||wwv_flow.LF||
' report_line_id number default on null to_number(sys_';
wwv_flow_imp.g_varchar2_table(18) := 'guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') primary key,'||wwv_flow.LF||
' report_id number not null references sfm_ex';
wwv_flow_imp.g_varchar2_table(19) := 'pense_reports(report_id) on delete cascade,'||wwv_flow.LF||
' category_id number not null references sfm_expense_cate';
wwv_flow_imp.g_varchar2_table(20) := 'gories(category_id),'||wwv_flow.LF||
' expense_date date not null,'||wwv_flow.LF||
' merchant varchar2(150 char) not null,'||wwv_flow.LF||
' descriptio';
wwv_flow_imp.g_varchar2_table(21) := 'n varchar2(500 char),'||wwv_flow.LF||
' amount number(12,2) not null,'||wwv_flow.LF||
' reimbursable_yn varchar2(1 char) default ''Y'' n';
wwv_flow_imp.g_varchar2_table(22) := 'ot null check (reimbursable_yn in (''Y'',''N''))'||wwv_flow.LF||
');'||wwv_flow.LF||
'create index sfm_lines_report_ix on sfm_expense_repo';
wwv_flow_imp.g_varchar2_table(23) := 'rt_lines(report_id);'||wwv_flow.LF||
'create index sfm_lines_category_ix on sfm_expense_report_lines(category_id);'||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(24) := 'eate table sfm_expense_receipts ('||wwv_flow.LF||
' receipt_id number default on null to_number(sys_guid(),''XXXXXXXXX';
wwv_flow_imp.g_varchar2_table(25) := 'XXXXXXXXXXXXXXXXXXXXXXX'') primary key,'||wwv_flow.LF||
' report_line_id number not null references sfm_expense_report';
wwv_flow_imp.g_varchar2_table(26) := '_lines(report_line_id) on delete cascade,'||wwv_flow.LF||
' caption varchar2(200 char) not null,'||wwv_flow.LF||
' file_content blob n';
wwv_flow_imp.g_varchar2_table(27) := 'ot null,'||wwv_flow.LF||
' mime_type varchar2(128 char) not null check (mime_type in (''image/png'',''image/jpeg'',''appli';
wwv_flow_imp.g_varchar2_table(28) := 'cation/pdf'')),'||wwv_flow.LF||
' filename varchar2(255 char) not null,'||wwv_flow.LF||
' file_charset varchar2(40 char),'||wwv_flow.LF||
' file_updated';
wwv_flow_imp.g_varchar2_table(29) := '_on timestamp default systimestamp not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'create index sfm_expense_receipts_line_ix on sfm_expe';
wwv_flow_imp.g_varchar2_table(30) := 'nse_receipts(report_line_id);'||wwv_flow.LF||
'comment on table sfm_expense_reports is ''Forms Patterns: expense repor';
wwv_flow_imp.g_varchar2_table(31) := 't headers; fictional demonstration data.'';'||wwv_flow.LF||
'comment on column sfm_expense_reports.business_justificat';
wwv_flow_imp.g_varchar2_table(32) := 'ion is ''Long plain-text justification; includes a sample exceeding 32 KB.'';'||wwv_flow.LF||
'comment on column sfm_ex';
wwv_flow_imp.g_varchar2_table(33) := 'pense_report_lines.amount is ''Signed amount in the parent expense report currency. Negative amounts ';
wwv_flow_imp.g_varchar2_table(34) := 'are refunds; zero is valid.'';'||wwv_flow.LF||
'comment on column sfm_expense_receipts.file_content is ''Receipt image ';
wwv_flow_imp.g_varchar2_table(35) := 'or PDF stored as a BLOB.'';'||wwv_flow.LF||
'commit;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(4201748328430591)
,p_install_id=>wwv_flow_imp.id(2406003813162048)
,p_name=>'forms-patterns-schema'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(4609525904193794)
,p_script_id=>wwv_flow_imp.id(4201748328430591)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'SFM_EXPENSE_CATEGORIES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(4609680886193794)
,p_script_id=>wwv_flow_imp.id(4201748328430591)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'SFM_EXPENSE_REPORTS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(4609786307193794)
,p_script_id=>wwv_flow_imp.id(4201748328430591)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'SFM_EXPENSE_REPORT_LINES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(4609854091193794)
,p_script_id=>wwv_flow_imp.id(4201748328430591)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'SFM_EXPENSE_RECEIPTS'
);
wwv_flow_imp.component_end;
end;
/
