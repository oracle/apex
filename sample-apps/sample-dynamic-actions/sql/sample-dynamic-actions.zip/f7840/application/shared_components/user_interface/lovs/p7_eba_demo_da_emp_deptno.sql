prompt --application/shared_components/user_interface/lovs/p7_eba_demo_da_emp_deptno
begin
--   Manifest
--     P7_EBA_DEMO_DA_EMP_DEPTNO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7840
,p_default_id_offset=>1555159707774264
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2656799856082119519)
,p_lov_name=>'P7_EBA_DEMO_DA_EMP_DEPTNO'
,p_static_id=>'p7-eba-demo-da-emp-deptno'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select dname d, deptno r',
'from eba_demo_da_dept',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'1089078642'
);
wwv_flow_imp.component_end;
end;
/
