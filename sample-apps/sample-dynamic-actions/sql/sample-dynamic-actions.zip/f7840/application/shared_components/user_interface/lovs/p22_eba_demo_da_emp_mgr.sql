prompt --application/shared_components/user_interface/lovs/p22_eba_demo_da_emp_mgr
begin
--   Manifest
--     P22_EBA_DEMO_DA_EMP_MGR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7840
,p_default_id_offset=>1555159707774264
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2674869849148092549)
,p_lov_name=>'P22_EBA_DEMO_DA_EMP_MGR'
,p_static_id=>'p22-eba-demo-da-emp-mgr'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ename d, empno r',
'from eba_demo_da_emp',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'1089078642'
);
wwv_flow_imp.component_end;
end;
/
