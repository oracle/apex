prompt --application/shared_components/navigation/lists/administration_options
begin
--   Manifest
--     LIST: Administration Options
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7840
,p_default_id_offset=>1555159707774264
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2177343443554308181)
,p_name=>'Administration Options'
,p_static_id=>'administration-options'
,p_version_scn=>'1089078642'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2177343722175308183)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Reset Data'
,p_static_id=>'reset-data'
,p_list_item_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database'
,p_list_text_01=>'Reset the sample data provided in this application to the default.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2177344102453308183)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Theme Style'
,p_static_id=>'theme-style'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-laptop'
,p_list_text_01=>'Change user interface theme style for all users.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
