prompt --application/deployment/install/upgrade_refresh_data
begin
--   Manifest
--     INSTALL: UPGRADE-Refresh Data
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7840
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(2577222332949616189)
,p_install_id=>wwv_flow_api.id(2577052746755591819)
,p_name=>'Refresh Data'
,p_sequence=>10
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  eba_demo_da_data;',
'end;',
'/',
''))
);
wwv_flow_api.component_end;
end;
/
