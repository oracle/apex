prompt --application/deployment/install/install_create_tables
begin
--   Manifest
--     INSTALL: INSTALL-Create Tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7840
,p_default_id_offset=>1555159707774264
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '  CREATE TABLE "EBA_DEMO_DA_DEPT" '||wwv_flow.LF||
'   (    "DEPTNO" NUMBER(2,0), '||wwv_flow.LF||
'    "DNAME" VARCHAR2(14 BYTE), '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(2) := '  "LOC" VARCHAR2(13 BYTE)'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
'  ALTER TABLE "EBA_DEMO_DA_DEPT" ADD PRIMARY KEY ("DEPTNO");'||wwv_flow.LF||
''||wwv_flow.LF||
'  CRE';
wwv_flow_imp.g_varchar2_table(3) := 'ATE TABLE "EBA_DEMO_DA_EMP" '||wwv_flow.LF||
'   (    "EMPNO" NUMBER(4,0) NOT NULL, '||wwv_flow.LF||
'    "ENAME" VARCHAR2(10 BYTE), '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(4) := '    "JOB" VARCHAR2(9 BYTE), '||wwv_flow.LF||
'    "MGR" NUMBER(4,0), '||wwv_flow.LF||
'    "HIREDATE" DATE, '||wwv_flow.LF||
'    "SAL" NUMBER(7,2), '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(5) := '   "COMM" NUMBER(7,2), '||wwv_flow.LF||
'    "DEPTNO" NUMBER(2,0)'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
'  ALTER TABLE "EBA_DEMO_DA_EMP" ADD PRIMARY ';
wwv_flow_imp.g_varchar2_table(6) := 'KEY ("EMPNO");'||wwv_flow.LF||
''||wwv_flow.LF||
'  ALTER TABLE "EBA_DEMO_DA_EMP" ADD FOREIGN KEY ("MGR")'||wwv_flow.LF||
'      REFERENCES "EBA_DEMO_D';
wwv_flow_imp.g_varchar2_table(7) := 'A_EMP" ("EMPNO") ENABLE;'||wwv_flow.LF||
' '||wwv_flow.LF||
'  ALTER TABLE "EBA_DEMO_DA_EMP" ADD FOREIGN KEY ("DEPTNO")'||wwv_flow.LF||
'      REFERENC';
wwv_flow_imp.g_varchar2_table(8) := 'ES "EBA_DEMO_DA_DEPT" ("DEPTNO") ENABLE;'||wwv_flow.LF||
'      '||wwv_flow.LF||
'  CREATE INDEX "EBA_DEMO_DA_EMP_1" ON "EBA_DEMO_DA_E';
wwv_flow_imp.g_varchar2_table(9) := 'MP" ("MGR");'||wwv_flow.LF||
'  CREATE INDEX "EBA_DEMO_DA_EMP_2" ON "EBA_DEMO_DA_EMP" ("DEPTNO");'||wwv_flow.LF||
'  '||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2583259138554578633)
,p_install_id=>wwv_flow_imp.id(2583209151583572944)
,p_name=>'Create Tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
