prompt --application/deployment/install/install_insert_data
begin
--   Manifest
--     INSTALL: INSTALL-Insert Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7840
,p_default_id_offset=>1555159707774264
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace procedure eba_demo_da_data as'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'delete eba_demo_da_emp;'||wwv_flow.LF||
'delete eba_demo_da_dep';
wwv_flow_imp.g_varchar2_table(2) := 't;'||wwv_flow.LF||
''||wwv_flow.LF||
'Insert into EBA_DEMO_DA_DEPT (DEPTNO,DNAME,LOC) values (10,''ACCOUNTING'',''NEW YORK'');'||wwv_flow.LF||
'Insert into';
wwv_flow_imp.g_varchar2_table(3) := ' EBA_DEMO_DA_DEPT (DEPTNO,DNAME,LOC) values (20,''RESEARCH'',''DALLAS'');'||wwv_flow.LF||
'Insert into EBA_DEMO_DA_DEPT (';
wwv_flow_imp.g_varchar2_table(4) := 'DEPTNO,DNAME,LOC) values (30,''SALES'',''CHICAGO'');'||wwv_flow.LF||
'Insert into EBA_DEMO_DA_DEPT (DEPTNO,DNAME,LOC) val';
wwv_flow_imp.g_varchar2_table(5) := 'ues (40,''OPERATIONS'',''BOSTON'');'||wwv_flow.LF||
''||wwv_flow.LF||
'Insert into EBA_DEMO_DA_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,';
wwv_flow_imp.g_varchar2_table(6) := 'DEPTNO) values (7839,''KING'',''PRESIDENT'',null,to_date(''17-11-81'',''DD-MM-RR''),5000,null,10);'||wwv_flow.LF||
'Insert in';
wwv_flow_imp.g_varchar2_table(7) := 'to EBA_DEMO_DA_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7698,''BLAKE'',''MANAGER'',783';
wwv_flow_imp.g_varchar2_table(8) := '9,to_date(''01-05-81'',''DD-MM-RR''),2850,null,30);'||wwv_flow.LF||
'Insert into EBA_DEMO_DA_EMP (EMPNO,ENAME,JOB,MGR,HIR';
wwv_flow_imp.g_varchar2_table(9) := 'EDATE,SAL,COMM,DEPTNO) values (7782,''CLARK'',''MANAGER'',7839,to_date(''09-06-81'',''DD-MM-RR''),2450,null,';
wwv_flow_imp.g_varchar2_table(10) := '10);'||wwv_flow.LF||
'Insert into EBA_DEMO_DA_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7566,''JONES''';
wwv_flow_imp.g_varchar2_table(11) := ',''MANAGER'',7839,to_date(''02-04-81'',''DD-MM-RR''),2975,null,20);'||wwv_flow.LF||
'Insert into EBA_DEMO_DA_EMP (EMPNO,ENA';
wwv_flow_imp.g_varchar2_table(12) := 'ME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7788,''SCOTT'',''ANALYST'',7566,to_date(''09-12-82'',''DD-MM-R';
wwv_flow_imp.g_varchar2_table(13) := 'R''),3000,null,20);'||wwv_flow.LF||
'Insert into EBA_DEMO_DA_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values';
wwv_flow_imp.g_varchar2_table(14) := ' (7902,''FORD'',''ANALYST'',7566,to_date(''03-12-81'',''DD-MM-RR''),3000,null,20);'||wwv_flow.LF||
'Insert into EBA_DEMO_DA_E';
wwv_flow_imp.g_varchar2_table(15) := 'MP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7369,''SMITH'',''CLERK'',7902,to_date(''17-12-8';
wwv_flow_imp.g_varchar2_table(16) := '0'',''DD-MM-RR''),800,null,20);'||wwv_flow.LF||
'Insert into EBA_DEMO_DA_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPT';
wwv_flow_imp.g_varchar2_table(17) := 'NO) values (7499,''ALLEN'',''SALESMAN'',7698,to_date(''20-02-81'',''DD-MM-RR''),1600,300,30);'||wwv_flow.LF||
'Insert into EB';
wwv_flow_imp.g_varchar2_table(18) := 'A_DEMO_DA_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7521,''WARD'',''SALESMAN'',7698,to_';
wwv_flow_imp.g_varchar2_table(19) := 'date(''22-02-81'',''DD-MM-RR''),1250,500,30);'||wwv_flow.LF||
'Insert into EBA_DEMO_DA_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,';
wwv_flow_imp.g_varchar2_table(20) := 'SAL,COMM,DEPTNO) values (7654,''MARTIN'',''SALESMAN'',7698,to_date(''28-09-81'',''DD-MM-RR''),1250,1400,30);';
wwv_flow_imp.g_varchar2_table(21) := ''||wwv_flow.LF||
'Insert into EBA_DEMO_DA_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7844,''TURNER'',''S';
wwv_flow_imp.g_varchar2_table(22) := 'ALESMAN'',7698,to_date(''08-09-81'',''DD-MM-RR''),1500,0,30);'||wwv_flow.LF||
'Insert into EBA_DEMO_DA_EMP (EMPNO,ENAME,JO';
wwv_flow_imp.g_varchar2_table(23) := 'B,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7876,''ADAMS'',''CLERK'',7788,to_date(''12-01-83'',''DD-MM-RR''),110';
wwv_flow_imp.g_varchar2_table(24) := '0,null,20);'||wwv_flow.LF||
'Insert into EBA_DEMO_DA_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7900,';
wwv_flow_imp.g_varchar2_table(25) := '''JAMES'',''CLERK'',7698,to_date(''03-12-81'',''DD-MM-RR''),950,null,30);'||wwv_flow.LF||
'Insert into EBA_DEMO_DA_EMP (EMPNO';
wwv_flow_imp.g_varchar2_table(26) := ',ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7934,''MILLER'',''CLERK'',7782,to_date(''23-01-82'',''DD-M';
wwv_flow_imp.g_varchar2_table(27) := 'M-RR''),1300,null,10);'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  eba_demo_da_data;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2583286656216583716)
,p_install_id=>wwv_flow_imp.id(2583209151583572944)
,p_name=>'Insert Data'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
