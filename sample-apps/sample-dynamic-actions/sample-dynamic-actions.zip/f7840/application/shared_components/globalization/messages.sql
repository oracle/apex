prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7840
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7840
,p_default_id_offset=>1555159707774264
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2578651465042848211)
,p_name=>'HELP'
,p_message_text=>'Help'
,p_version_scn=>37166093875331
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2578655567120848765)
,p_name=>'LOGOUT'
,p_message_text=>'Logout'
,p_version_scn=>37166093875331
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2682569256237848961)
,p_name=>'USER'
,p_message_text=>'User'
,p_version_scn=>37166093875331
);
wwv_flow_imp.component_end;
end;
/
