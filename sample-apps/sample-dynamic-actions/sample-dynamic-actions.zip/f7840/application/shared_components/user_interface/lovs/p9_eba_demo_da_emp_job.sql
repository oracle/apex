prompt --application/shared_components/user_interface/lovs/p9_eba_demo_da_emp_job
begin
--   Manifest
--     P9_EBA_DEMO_DA_EMP_JOB
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7840
,p_default_id_offset=>1555159707774264
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2658350562464433889)
,p_lov_name=>'P9_EBA_DEMO_DA_EMP_JOB'
,p_static_id=>'p9-eba-demo-da-emp-job'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct job d, job r',
'from eba_demo_da_emp',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'1089078642'
);
wwv_flow_imp.component_end;
end;
/
