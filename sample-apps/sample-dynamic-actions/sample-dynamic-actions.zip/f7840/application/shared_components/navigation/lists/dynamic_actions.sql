prompt --application/shared_components/navigation/lists/dynamic_actions
begin
--   Manifest
--     LIST: Dynamic Actions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7840
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1909185957300227171)
,p_name=>'Dynamic Actions'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1909188942249227174)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Disable/Enable'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-table-ban'
,p_list_text_01=>'Disable and enable items automatically'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2,3'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1909189317829227175)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Hide/Show'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-eye-slash'
,p_list_text_01=>'Declaratively hide and show items based on user input'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4,5'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1909189689949227175)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Add/Remove Class (Error)'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-exclamation-triangle-o'
,p_list_text_01=>'Using the Add and Remove Class actions to highlight errors'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6,7'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1909190093834227175)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Add/Remove Class (Focus)'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-info-circle-o'
,p_list_text_01=>'Using the Add and Remove Class actions to show focus'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'8,9'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1909190512695227175)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Stripe Report'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>'Using a dynamic action plug-in to enhance a report'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1909190921069227176)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Execute PL/SQL Code'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-code'
,p_list_text_01=>'Executing PL/SQL as part of a dynamic action'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1909191310889227176)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Set Values (SQL)'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-table-edit'
,p_list_text_01=>'Using a dynamic action to execute SQL'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'12,13'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1909191763386227176)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Set Values (PL/SQL)'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-table-user'
,p_list_text_01=>'Automatically calculate values via PL/SQL based on user input'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'14,15'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1909192078657227176)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Timer'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-table-clock'
,p_list_text_01=>'Utilize a timer for repeating dynamic actions'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1909192543579227176)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Refresh'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-refresh'
,p_list_text_01=>'Refresh a report based on user interactions with an interactive report'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1909193358583227182)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Filter and Refresh'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-table-arrow-down'
,p_list_text_01=>'Use a dynamic action to filter a report'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1909193677773227182)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Shuttle Refresh'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-table-pointer'
,p_list_text_01=>'Use a dynamic action with a shuttle page item to control a report'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1909192882057227176)
,p_list_item_display_sequence=>135
,p_list_item_link_text=>'Delete and Refresh'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-table-x'
,p_list_text_01=>'Use a multi-part dynamic action to confirm deletions and refresh a report'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(599941371729246761)
,p_list_item_display_sequence=>145
,p_list_item_link_text=>'Debounce and Throttle'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clock-o'
,p_list_text_01=>'Execute dynamic actions immediately or after a delay'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
