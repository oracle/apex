prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 7840
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7840
,p_default_id_offset=>1555159707774264
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
