prompt --application/shared_components/navigation/lists/3d_effect
begin
--   Manifest
--     LIST: 3D Effect
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3943415097018836072)
,p_name=>'3D Effect'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3943415343514836074)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Funnel Chart (3D Effect) - Page 22'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>'This example demonstrates how to render a 3D Funnel chart, by setting the threeDEffect attribute of the ojChart API via custom JavaScript code'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3943415763555836075)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Pie Chart (Master Detail Chart Links) - Page 4'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-line-chart'
,p_list_text_01=>'This example demonstrates how to render a 3D Pie chart, by setting the threeDEffect attribute of the ojChart API via custom JavaScript code'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
