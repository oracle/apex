prompt --application/shared_components/navigation/lists/sorting
begin
--   Manifest
--     LIST: Sorting
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(541276815410066516)
,p_name=>'Sorting'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089078564
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(541276980130066518)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Bar Chart (Series Colors) - Page 9'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>'Four Bar charts demonstrate the various methods of defining colors on a chart, and each of the charts demonstrates a different style of sorting.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(541277408651066519)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Area Chart (Stacked) - Page 2'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-line-chart'
,p_list_text_01=>'This example demonstrates sorting the chart by the x-axis labels, descending.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(541278729781088879)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Donut Chart (Sorting) - Page 9'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_text_01=>'This example demonstrates sorting the chart by the values, ascending.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
