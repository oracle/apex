prompt --application/shared_components/navigation/lists/styling_tooltip_labels
begin
--   Manifest
--     LIST: Styling Tooltip Labels
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(992560352702421053)
,p_name=>'Styling Tooltip Labels'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(992560545167421058)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Line with Area Chart ( Custom Tooltip Labels ) - Page 18'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-line-area-chart'
,p_list_text_01=>'This example demonstrates a Line with Area chart, rendering customised tooltip labels using JavaScript, via the JavaScript Initialization Code attribute'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(992561872750454070)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Area Chart (Legend JavaScript Code Customization) - Page 2'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>'This example demonstrates an Area chart, rendering a customised tooltip on the Acme series of the multi-series chart, via the SQL query and use of the declarative Custom Tooltip attribute'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
