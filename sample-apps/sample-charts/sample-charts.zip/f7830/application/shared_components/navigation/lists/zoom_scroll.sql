prompt --application/shared_components/navigation/lists/zoom_scroll
begin
--   Manifest
--     LIST: Zoom & Scroll
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(3652544635672746563)
,p_name=>'Zoom & Scroll'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3652545244861746564)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Line Chart (Time Axis) - Page 15'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-line-chart'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This example demonstrates:',
'a) a Line chart rendering DateTime information on the x-axis, using the Time Axis Type attribute',
'b) reset Zoom option - resetting the viewport settings of the chart xAxis'))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3652545639330746564)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Stock - Page 7'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-stock-chart'
,p_list_text_01=>'This example demonstrates a Donut chart with custom labels defined'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
