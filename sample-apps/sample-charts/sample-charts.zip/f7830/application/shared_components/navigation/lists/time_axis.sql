prompt --application/shared_components/navigation/lists/time_axis
begin
--   Manifest
--     LIST: Time Axis
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3652538583378709356)
,p_name=>'Time Axis'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(992536978194183134)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Combination Chart (Regular v Mixed Frequency Time Axis) - Page 25'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>'This example demonstrates the use of the Time Axis Type attribute, to render DATETIME information on a multi-series Combination chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3652539262384709356)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Line Chart (Time Axis) - Page 15'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-line-chart'
,p_list_text_01=>'This example demonstrates the use of the Time Axis Type attribute, to render DATETIME information on a Line chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
