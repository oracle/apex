prompt --application/shared_components/navigation/lists/reference_js
begin
--   Manifest
--     LIST: Reference - JS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(3652116539339177338)
,p_name=>'Reference - JS'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1029838857084657189)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'New in 20.2'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-folder-new'
,p_list_text_01=>'See a list of the chart examples demonstrating the use of Interactive Grid URL filtering.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3652116756291177340)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'JavaScript Code Customizations'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_list_text_01=>'See a list of the chart examples demonstrating the use of JavaScript Code to customize the chart at initialization'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(541276319553053748)
,p_list_item_display_sequence=>12
,p_list_item_link_text=>'Sorting'
,p_list_item_link_target=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-sort-alpha-asc'
,p_list_text_01=>'See a list of chart examples demonstrating how to sort chart values and labels, using the new <strong>Fill Gaps in Chart Data</strong> and <strong>Sort Order</strong> chart-level attributes.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3652117103007177344)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Dynamic Actions'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bolt'
,p_list_text_01=>'See a list of the chart examples demonstrating the use of Dynamic Actions'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3652119773846219818)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Datetime x-axis'
,p_list_item_link_target=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'See a list of the chart examples demonstrating the use of the Time Axis Type attribute, to render DATETIME information on the x-axis of a chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3652119304780213612)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'JET Plug-in Component'
,p_list_item_link_target=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plug'
,p_list_text_01=>'See a list of the chart examples demonstrating the use of an APEX plug-in, to incorporate other Oracle JET components in your application'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3652117542131177344)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Y2 Axis'
,p_list_item_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-y2-axis'
,p_list_text_01=>'See a list of the chart examples demonstrating the use of an extra, y2 axis'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(992558792936401159)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Customizing Tooltip Labels'
,p_list_item_link_target=>'f?p=&APP_ID.:48:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-alert'
,p_list_text_01=>'See a list of the chart examples demonstrating how to customise the labels displayed in a tooltip, both declaratively and via JavaScript customization'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3654932514094501289)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Formatting Values'
,p_list_item_link_target=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-eur'
,p_list_text_01=>'See a list of chart examples demonstrating how to format the values on your chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3654892901485371069)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Customizing Data Labels'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-text-height'
,p_list_text_01=>'See a list of the chart examples demonstrating how to declaratively style chart data labels using CSS, or customize the labels using JavaScript'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3652120364185230649)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Zoom & Scroll'
,p_list_item_link_target=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search-plus'
,p_list_text_01=>'See a list of the chart examples demonstrating the use of Zoom and Scroll, making it easier to view charts rendering large volumes of data'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(389264893458986430)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Chart Links'
,p_list_item_link_target=>'f?p=&APP_ID.:49:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-link'
,p_list_text_01=>'See a list of chart examples demonstrating how to link from chart to reports and charts'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3652117861255177344)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Series Color'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-paint-brush'
,p_list_text_01=>'See a list of the chart examples demonstrating how to set the color of chart series'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4000469909572383076)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Data Densification'
,p_list_item_link_target=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plus'
,p_list_text_01=>'See a list of chart examples demonstrating how a multi-series chart with differing series lengths, use new data densification handling to render the data points correctly on your chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(177056129676777961)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Font Formatting'
,p_list_item_link_target=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-text-height'
,p_list_text_01=>'See a list of examples demonstrating the declarative styling of text rendered on a chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(177020230975514364)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Stack Grouping'
,p_list_item_link_target=>'f?p=&APP_ID.:44:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-line-area-chart'
,p_list_text_01=>'See a list of examples demonstrating the declarative grouping and labeling of stacked charts.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3943412686210786620)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'3D Effect'
,p_list_item_link_target=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cube'
,p_list_text_01=>'See a list of chart examples demonstrating how to apply the 3D effect on your chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(242390224984253730)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Style Chart Title'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-font-size'
,p_list_text_01=>'See chart examples demonstrating the use of JavaScript Code to customize the chart title at initialization'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
