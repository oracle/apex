prompt --application/shared_components/navigation/lists/data_densify
begin
--   Manifest
--     LIST: Data Densify
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(4000472705785412813)
,p_name=>'Data Densify'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(355549087507809403)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'Data Densification - Page 14'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code-group'
,p_list_text_01=>'This page demonstrates the behaviour of the new <strong>Fill Gaps in Chart Data</strong> and associated <strong>Sort Order</strong> attributes, in the densification of a multi-series chart.  There are also examples of opting out of the densification '
||'logic, to base the chart data and ordering solely on the chart query provided.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4000472937283412815)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Bar Chart (Series Colors) - Page 9'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>'This example demonstrates how to render a single-series Bar chart, with the ordering controlled via the series SQL query'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(176111231801927205)
,p_list_item_display_sequence=>11
,p_list_item_link_text=>'Bar Chart (Series Name Column Mapping)  - Page 9'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>'This example demonstrates how to render a multi-series Bar chart, with differing numbers of data points per series, using <strong>Fill Gaps in Chart Data</strong> chart-level attribute.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4000473310417412816)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Line Chart (Mixed Series Length - Quantity > 40) - Page 15'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-line-chart'
,p_list_text_01=>'This example demonstrates how to render a multi-series Line with Area chart, with series of differing lengths'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
