prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7830
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>2654143468017583
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop procedure eba_demo_chart_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba_demo_chart_tasks cascade constraints;'||wwv_flow.LF||
'drop table';
wwv_flow_imp.g_varchar2_table(2) := ' eba_demo_chart_projects cascade constraints;'||wwv_flow.LF||
'drop table eba_demo_chart_emp cascade constraints;'||wwv_flow.LF||
'dro';
wwv_flow_imp.g_varchar2_table(3) := 'p table eba_demo_chart_dept cascade constraints;'||wwv_flow.LF||
'drop table eba_demo_chart_population cascade constr';
wwv_flow_imp.g_varchar2_table(4) := 'aints;'||wwv_flow.LF||
'drop table eba_demo_chart_stocks cascade constraints;'||wwv_flow.LF||
'drop table eba_demo_chart_bball cascade';
wwv_flow_imp.g_varchar2_table(5) := ' constraints;'||wwv_flow.LF||
'drop table eba_demo_chart_orders cascade constraints;'||wwv_flow.LF||
'drop table eba_demo_chart_produc';
wwv_flow_imp.g_varchar2_table(6) := 'ts cascade constraints;'||wwv_flow.LF||
'drop table eba_demo_chart_stats cascade constraints;'||wwv_flow.LF||
'drop table eba_demo_cha';
wwv_flow_imp.g_varchar2_table(7) := 'rt_grades;'||wwv_flow.LF||
'drop table eba_demo_chart_samples;'||wwv_flow.LF||
'drop table eba_demo_chart_sample_data cascade constrai';
wwv_flow_imp.g_varchar2_table(8) := 'nts;'||wwv_flow.LF||
'drop table eba_demo_chart_sample_names;'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(9) := ' p_location => ''APPLICATION'','||wwv_flow.LF||
'        p_name     => ''charts_candlestick.jpg'','||wwv_flow.LF||
'        p_mode     => ';
wwv_flow_imp.g_varchar2_table(10) := '''REMOVE'','||wwv_flow.LF||
'        p_type     => ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(11) := '     p_location => ''APPLICATION'','||wwv_flow.LF||
'        p_name     => ''charts_bar.jpg'','||wwv_flow.LF||
'        p_mode     => ''REM';
wwv_flow_imp.g_varchar2_table(12) := 'OVE'','||wwv_flow.LF||
'        p_type     => ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(13) := ' p_location => ''APPLICATION'','||wwv_flow.LF||
'        p_name     => ''charts_combination.jpg'','||wwv_flow.LF||
'        p_mode     => ';
wwv_flow_imp.g_varchar2_table(14) := '''REMOVE'','||wwv_flow.LF||
'        p_type     => ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(15) := '      p_location => ''APPLICATION'','||wwv_flow.LF||
'        p_name     => ''charts_gantt.jpg'','||wwv_flow.LF||
'        p_mode     => ''';
wwv_flow_imp.g_varchar2_table(16) := 'REMOVE'','||wwv_flow.LF||
'        p_type     => ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(17) := '    p_location => ''APPLICATION'','||wwv_flow.LF||
'        p_name     => ''charts_gauge.jpg'','||wwv_flow.LF||
'        p_mode     => ''RE';
wwv_flow_imp.g_varchar2_table(18) := 'MOVE'','||wwv_flow.LF||
'        p_type     => ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(19) := '  p_location => ''APPLICATION'','||wwv_flow.LF||
'        p_name     => ''charts_map.jpg'','||wwv_flow.LF||
'        p_mode     => ''REMOVE';
wwv_flow_imp.g_varchar2_table(20) := ''','||wwv_flow.LF||
'        p_type     => ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'        p_';
wwv_flow_imp.g_varchar2_table(21) := 'location => ''APPLICATION'','||wwv_flow.LF||
'        p_name     => ''charts_pie.jpg'','||wwv_flow.LF||
'        p_mode     => ''REMOVE'','||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(22) := '       p_type     => ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'        p_loc';
wwv_flow_imp.g_varchar2_table(23) := 'ation => ''APPLICATION'','||wwv_flow.LF||
'        p_name     => ''charts_scatter.jpg'','||wwv_flow.LF||
'        p_mode     => ''REMOVE'','||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(24) := '        p_type     => ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(2579186863174088443)
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'EBA_DEMO_CHART_TASKS:EBA_DEMO_CHART_PROJECTS:EBA_DEMO_CHART_EMP:EBA_DEMO_CHART_DEPT:EBA_DEMO_CHART_POPULATION:EBA_DEMO_CHART_STOCKS:EBA_DEMO_CHART_GRADES:EBA_DEMO_CHART_SAMPLES:EBA_DEMO_CHART_SAMPLE_NAMES:EBA_DEMO_CHART_SAMPLE_DATA'
);
wwv_flow_imp.component_end;
end;
/
