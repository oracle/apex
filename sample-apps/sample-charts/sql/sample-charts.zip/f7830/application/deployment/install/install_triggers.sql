prompt --application/deployment/install/install_triggers
begin
--   Manifest
--     INSTALL: INSTALL-Triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>2654143468017583
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger biu_eba_demo_chart_proj '||wwv_flow.LF||
'   before insert or update on eba_demo_chart_proj';
wwv_flow_imp.g_varchar2_table(2) := 'ects'||wwv_flow.LF||
'   for each row '||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXX';
wwv_flow_imp.g_varchar2_table(3) := 'XXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.crea';
wwv_flow_imp.g_varchar2_table(4) := 'ted := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated :';
wwv_flow_imp.g_varchar2_table(5) := '= current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting';
wwv_flow_imp.g_varchar2_table(6) := ' or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g';
wwv_flow_imp.g_varchar2_table(7) := '_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating ';
wwv_flow_imp.g_varchar2_table(8) := 'then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(9) := 'ter trigger biu_eba_demo_chart_proj enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'create or replace trigger biu_eba_demo_chart_tasks';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
'   before insert or update on eba_demo_chart_tasks'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'   if :new."ID" is null ';
wwv_flow_imp.g_varchar2_table(11) := 'then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(12) := ' end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nv';
wwv_flow_imp.g_varchar2_table(13) := 'l(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv';
wwv_flow_imp.g_varchar2_table(14) := '_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_times';
wwv_flow_imp.g_varchar2_table(15) := 'tamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :n';
wwv_flow_imp.g_varchar2_table(16) := 'ew.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_ve';
wwv_flow_imp.g_varchar2_table(17) := 'rsion_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigger biu_eba_demo_chart_tasks enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(18) := 'or replace trigger biu_eba_demo_chart_stocks'||wwv_flow.LF||
'   before insert or update on eba_demo_chart_stocks'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(19) := 'for each row'||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(20) := 'XXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := cu';
wwv_flow_imp.g_varchar2_table(21) := 'rrent_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current';
wwv_flow_imp.g_varchar2_table(22) := '_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updat';
wwv_flow_imp.g_varchar2_table(23) := 'ing then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,use';
wwv_flow_imp.g_varchar2_table(24) := 'r);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(25) := '   :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigg';
wwv_flow_imp.g_varchar2_table(26) := 'er biu_eba_demo_chart_stocks enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_demo_chart_pop'||wwv_flow.LF||
'   befo';
wwv_flow_imp.g_varchar2_table(27) := 're insert or update on eba_demo_chart_population'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'   if :new."ID" is null the';
wwv_flow_imp.g_varchar2_table(28) := 'n'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   en';
wwv_flow_imp.g_varchar2_table(29) := 'd if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(w';
wwv_flow_imp.g_varchar2_table(30) := 'wv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_fl';
wwv_flow_imp.g_varchar2_table(31) := 'ow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestam';
wwv_flow_imp.g_varchar2_table(32) := 'p;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.';
wwv_flow_imp.g_varchar2_table(33) := 'row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_versi';
wwv_flow_imp.g_varchar2_table(34) := 'on_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigger biu_eba_demo_chart_pop enable'||wwv_flow.LF||
'/    '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(35) := 'or replace trigger biu_eba_demo_chart_bball'||wwv_flow.LF||
'   before insert or update on eba_demo_chart_bball'||wwv_flow.LF||
'   fo';
wwv_flow_imp.g_varchar2_table(36) := 'r each row'||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(37) := 'XXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := curr';
wwv_flow_imp.g_varchar2_table(38) := 'ent_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_t';
wwv_flow_imp.g_varchar2_table(39) := 'imestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updatin';
wwv_flow_imp.g_varchar2_table(40) := 'g then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user)';
wwv_flow_imp.g_varchar2_table(41) := ';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigger biu_eba_demo_chart_bball enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger ';
wwv_flow_imp.g_varchar2_table(42) := 'biu_eba_demo_chart_products'||wwv_flow.LF||
'   before insert or update on eba_demo_chart_products'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'be';
wwv_flow_imp.g_varchar2_table(43) := 'gin  '||wwv_flow.LF||
'   if :new."PRODUCT_ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(44) := 'XXXXXXXXX'') into :new.product_id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := c';
wwv_flow_imp.g_varchar2_table(45) := 'urrent_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := curren';
wwv_flow_imp.g_varchar2_table(46) := 't_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or upda';
wwv_flow_imp.g_varchar2_table(47) := 'ting then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,us';
wwv_flow_imp.g_varchar2_table(48) := 'er);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigger biu_eba_demo_chart_products enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace tr';
wwv_flow_imp.g_varchar2_table(49) := 'igger biu_eba_demo_chart_orders'||wwv_flow.LF||
'   before insert or update on eba_demo_chart_orders'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(50) := 'begin  '||wwv_flow.LF||
'   if :new."ORDER_ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(51) := 'XXXXXXXXX'') into :new.order_id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := cur';
wwv_flow_imp.g_varchar2_table(52) := 'rent_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_';
wwv_flow_imp.g_varchar2_table(53) := 'timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updati';
wwv_flow_imp.g_varchar2_table(54) := 'ng then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user';
wwv_flow_imp.g_varchar2_table(55) := ');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigger biu_eba_demo_chart_orders enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigge';
wwv_flow_imp.g_varchar2_table(56) := 'r biu_eba_demo_chart_stats'||wwv_flow.LF||
'   before insert or update on eba_demo_chart_stats'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin ';
wwv_flow_imp.g_varchar2_table(57) := ' '||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') ';
wwv_flow_imp.g_varchar2_table(58) := 'into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(59) := '     :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(60) := ':new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :ne';
wwv_flow_imp.g_varchar2_table(61) := 'w.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;';
wwv_flow_imp.g_varchar2_table(62) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigger biu_eba_demo_chart_stats enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_demo_char';
wwv_flow_imp.g_varchar2_table(63) := 't_sample_data '||wwv_flow.LF||
'   before insert or update on eba_demo_chart_sample_data'||wwv_flow.LF||
'   for each row '||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(64) := 'if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into ';
wwv_flow_imp.g_varchar2_table(65) := ':new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(66) := ':new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.';
wwv_flow_imp.g_varchar2_table(67) := 'updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.upd';
wwv_flow_imp.g_varchar2_table(68) := 'ated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(69) := '  '||wwv_flow.LF||
'alter trigger biu_eba_demo_chart_sample_data enable'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2579519469688260612)
,p_install_id=>wwv_flow_imp.id(2579186863174088443)
,p_name=>'Triggers'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
