prompt --application/deployment/install/install_tables
begin
--   Manifest
--     INSTALL: INSTALL-Tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>2654143468017583
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'REM eba_demo_chart_projects'||wwv_flow.LF||
'create table  eba_demo_chart_projects ('||wwv_flow.LF||
'    id                   number ';
wwv_flow_imp.g_varchar2_table(2) := '        not null'||wwv_flow.LF||
'                                        constraint eba_demo_charts_proj_pk'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(3) := '                                primary key,'||wwv_flow.LF||
'    project              varchar2(30)   not null,'||wwv_flow.LF||
'    r';
wwv_flow_imp.g_varchar2_table(4) := 'ow_version_number   number,'||wwv_flow.LF||
'    created              timestamp(6) with time zone,'||wwv_flow.LF||
'    created_by    ';
wwv_flow_imp.g_varchar2_table(5) := '       varchar2(255),'||wwv_flow.LF||
'    updated              timestamp(6) with time zone,'||wwv_flow.LF||
'    updated_by          ';
wwv_flow_imp.g_varchar2_table(6) := ' varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'REM eba_demo_chart_tasks    '||wwv_flow.LF||
'create table  eba_demo_chart_tasks ('||wwv_flow.LF||
'    id     ';
wwv_flow_imp.g_varchar2_table(7) := '                  number         not null'||wwv_flow.LF||
'                                            constraint eba';
wwv_flow_imp.g_varchar2_table(8) := '_demo_chart_tasks_pk'||wwv_flow.LF||
'                                            primary key,'||wwv_flow.LF||
'    project           ';
wwv_flow_imp.g_varchar2_table(9) := '       number         constraint eba_demo_chart_tasks_fk'||wwv_flow.LF||
'                                           ';
wwv_flow_imp.g_varchar2_table(10) := ' references eba_demo_chart_projects on delete cascade,'||wwv_flow.LF||
'    parent_task              number,'||wwv_flow.LF||
'    task';
wwv_flow_imp.g_varchar2_table(11) := '_name                varchar2(255),'||wwv_flow.LF||
'    row_version_number       number,'||wwv_flow.LF||
'    start_date             ';
wwv_flow_imp.g_varchar2_table(12) := '  date,'||wwv_flow.LF||
'    end_date                 date,'||wwv_flow.LF||
'    status                   varchar2(30),'||wwv_flow.LF||
'    assigned_t';
wwv_flow_imp.g_varchar2_table(13) := 'o              varchar2(30),'||wwv_flow.LF||
'    cost                     number,'||wwv_flow.LF||
'    budget                   numbe';
wwv_flow_imp.g_varchar2_table(14) := 'r,'||wwv_flow.LF||
'    created                  timestamp(6) with time zone,'||wwv_flow.LF||
'    created_by               varchar2(2';
wwv_flow_imp.g_varchar2_table(15) := '55),'||wwv_flow.LF||
'    updated                  timestamp(6) with time zone,'||wwv_flow.LF||
'    updated_by               varchar2';
wwv_flow_imp.g_varchar2_table(16) := '(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_chart_tasks_idx1 on eba_demo_chart_tasks (project)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'REM eb';
wwv_flow_imp.g_varchar2_table(17) := 'a_demo_chart_stocks    '||wwv_flow.LF||
'create table eba_demo_chart_stocks ('||wwv_flow.LF||
'    id                     number      ';
wwv_flow_imp.g_varchar2_table(18) := ' not null'||wwv_flow.LF||
'                                        constraint eba_demo_chart_stocks_pk'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(19) := '                          primary key,'||wwv_flow.LF||
'    row_version_number     number,'||wwv_flow.LF||
'    stock_code            ';
wwv_flow_imp.g_varchar2_table(20) := ' varchar2(4),'||wwv_flow.LF||
'    stock_name             varchar2(130),'||wwv_flow.LF||
'    pricing_date           date,'||wwv_flow.LF||
'    pricing';
wwv_flow_imp.g_varchar2_table(21) := '_timestamp      timestamp(6),'||wwv_flow.LF||
'    pricing_timestamp_tz   timestamp(6) with time zone,'||wwv_flow.LF||
'    opening_va';
wwv_flow_imp.g_varchar2_table(22) := 'l            number,'||wwv_flow.LF||
'    high                   number,'||wwv_flow.LF||
'    low                    number,'||wwv_flow.LF||
'    closi';
wwv_flow_imp.g_varchar2_table(23) := 'ng_val            number,'||wwv_flow.LF||
'    volume                 number,'||wwv_flow.LF||
'    created                timestamp(6)';
wwv_flow_imp.g_varchar2_table(24) := ' with time zone,'||wwv_flow.LF||
'    created_by             varchar2(255),'||wwv_flow.LF||
'    updated                timestamp(6) w';
wwv_flow_imp.g_varchar2_table(25) := 'ith time zone,'||wwv_flow.LF||
'    updated_by             varchar2(255)    '||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'REM eba_demo_chart_populatio';
wwv_flow_imp.g_varchar2_table(26) := 'n    '||wwv_flow.LF||
'create table eba_demo_chart_population ('||wwv_flow.LF||
'    id                  number          not null'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(27) := '                                    constraint eba_demo_chart_pop_pk'||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(28) := '         primary key,'||wwv_flow.LF||
'    row_version_number  number,'||wwv_flow.LF||
'    state_name          varchar2(100),'||wwv_flow.LF||
'    sta';
wwv_flow_imp.g_varchar2_table(29) := 'te_code          varchar2(2),'||wwv_flow.LF||
'    population          number,'||wwv_flow.LF||
'    region              number,'||wwv_flow.LF||
'    cr';
wwv_flow_imp.g_varchar2_table(30) := 'eated             timestamp(6) with time zone,'||wwv_flow.LF||
'    created_by          varchar2(255),'||wwv_flow.LF||
'    updated   ';
wwv_flow_imp.g_varchar2_table(31) := '          timestamp(6) with time zone,'||wwv_flow.LF||
'    updated_by          varchar2(255)    '||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'REM eba_dem';
wwv_flow_imp.g_varchar2_table(32) := 'o_chart_dept'||wwv_flow.LF||
'create table eba_demo_chart_dept ('||wwv_flow.LF||
'    deptno  NUMBER(2,0) not null'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(33) := '     constraint eba_demo_chart_dept_pk'||wwv_flow.LF||
'                        primary key, '||wwv_flow.LF||
'    dname   VARCHAR2(14';
wwv_flow_imp.g_varchar2_table(34) := ' BYTE), '||wwv_flow.LF||
'    loc     VARCHAR2(13 BYTE)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'REM eba_demo_chart_emp'||wwv_flow.LF||
'create table eba_demo_chart_emp ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(35) := '    empno     NUMBER(4,0) not null'||wwv_flow.LF||
'                          constraint eba_demo_chart_emp_pk'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(36) := '                    primary key, '||wwv_flow.LF||
'    ename     VARCHAR2(10 BYTE), '||wwv_flow.LF||
'    job       VARCHAR2(9 BYTE), ';
wwv_flow_imp.g_varchar2_table(37) := ''||wwv_flow.LF||
'    mgr       NUMBER(4,0), '||wwv_flow.LF||
'    hiredate  DATE, '||wwv_flow.LF||
'    sal       NUMBER(7,2), '||wwv_flow.LF||
'    comm      NUMBER(7';
wwv_flow_imp.g_varchar2_table(38) := ',2), '||wwv_flow.LF||
'    deptno    NUMBER(2,0)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_chart_emp add foreign key (MGR) references';
wwv_flow_imp.g_varchar2_table(39) := ' eba_demo_chart_emp (EMPNO) ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_chart_emp_1 ON eba_demo_chart_emp (MGR)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(40) := '/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'create index eba_demo_chart_emp_2 ON eba_demo_chart_emp (DEPTNO)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'REM eba_demo_chart_bball'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(41) := 'create table eba_demo_chart_bball ('||wwv_flow.LF||
'    id                  number          not null'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(42) := '                         constraint eba_demo_chart_bball_pk'||wwv_flow.LF||
'                                        ';
wwv_flow_imp.g_varchar2_table(43) := 'primary key,'||wwv_flow.LF||
'    city                varchar2(20),'||wwv_flow.LF||
'    team                varchar2(30), '||wwv_flow.LF||
'    confer';
wwv_flow_imp.g_varchar2_table(44) := 'ence          varchar2(5), '||wwv_flow.LF||
'    wins                number,'||wwv_flow.LF||
'    created             timestamp(6) wit';
wwv_flow_imp.g_varchar2_table(45) := 'h time zone,'||wwv_flow.LF||
'    created_by          varchar2(255),'||wwv_flow.LF||
'    updated             timestamp(6) with time z';
wwv_flow_imp.g_varchar2_table(46) := 'one,'||wwv_flow.LF||
'    updated_by          varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_chart_bball_1 ON eba_demo_c';
wwv_flow_imp.g_varchar2_table(47) := 'hart_bball (WINS)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'Rem eba_demo_chart_products'||wwv_flow.LF||
'create table eba_demo_chart_products (  '||wwv_flow.LF||
'    produc';
wwv_flow_imp.g_varchar2_table(48) := 't_id            number       not null'||wwv_flow.LF||
'                                       constraint eba_demo_cha';
wwv_flow_imp.g_varchar2_table(49) := 'rt_prod_pk'||wwv_flow.LF||
'                                       primary key,'||wwv_flow.LF||
'    product_name          varchar2(50';
wwv_flow_imp.g_varchar2_table(50) := '),'||wwv_flow.LF||
'    product_description   varchar2(2000),'||wwv_flow.LF||
'    list_price            number(8,2),'||wwv_flow.LF||
'    created     ';
wwv_flow_imp.g_varchar2_table(51) := '          timestamp(6) with time zone,'||wwv_flow.LF||
'    created_by            varchar2(255),'||wwv_flow.LF||
'    updated         ';
wwv_flow_imp.g_varchar2_table(52) := '      timestamp(6) with time zone,'||wwv_flow.LF||
'    updated_by            varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_';
wwv_flow_imp.g_varchar2_table(53) := 'demo_chart_prod_1 ON eba_demo_chart_products (list_price)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_chart_orders (  '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(54) := '    order_id            number          not null'||wwv_flow.LF||
'                                        constraint ';
wwv_flow_imp.g_varchar2_table(55) := 'eba_demo_chart_order_pk'||wwv_flow.LF||
'                                        primary key,'||wwv_flow.LF||
'    product_id         ';
wwv_flow_imp.g_varchar2_table(56) := ' number          constraint eba_demo_chart_order_fk'||wwv_flow.LF||
'                                        referenc';
wwv_flow_imp.g_varchar2_table(57) := 'es eba_demo_chart_products on delete cascade,'||wwv_flow.LF||
'    quantity            number(8,0),'||wwv_flow.LF||
'    customer     ';
wwv_flow_imp.g_varchar2_table(58) := '       varchar2(30),'||wwv_flow.LF||
'    sales_date          date,'||wwv_flow.LF||
'    created             timestamp(6) with time zo';
wwv_flow_imp.g_varchar2_table(59) := 'ne,'||wwv_flow.LF||
'    created_by          varchar2(255),'||wwv_flow.LF||
'    updated             timestamp(6) with time zone,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(60) := 'updated_by          varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_chart_ord_1 ON eba_demo_chart_orders';
wwv_flow_imp.g_varchar2_table(61) := ' (quantity)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_chart_ord_2 ON eba_demo_chart_orders (product_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create tab';
wwv_flow_imp.g_varchar2_table(62) := 'le eba_demo_chart_stats ('||wwv_flow.LF||
'    id                  number         not null'||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(63) := '             constraint eba_demo_chart_stats_pk'||wwv_flow.LF||
'                                       primary key,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(64) := '    name                varchar2(2),'||wwv_flow.LF||
'    country             varchar2(30),'||wwv_flow.LF||
'    employee            n';
wwv_flow_imp.g_varchar2_table(65) := 'umber,'||wwv_flow.LF||
'    employer            number,'||wwv_flow.LF||
'    total               number,'||wwv_flow.LF||
'    created             times';
wwv_flow_imp.g_varchar2_table(66) := 'tamp(6) with time zone,'||wwv_flow.LF||
'    created_by          varchar2(255),'||wwv_flow.LF||
'    updated             timestamp(6) ';
wwv_flow_imp.g_varchar2_table(67) := 'with time zone,'||wwv_flow.LF||
'    updated_by          varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_chart_stats_1 ON';
wwv_flow_imp.g_varchar2_table(68) := ' eba_demo_chart_stats (employee)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_chart_stats_2 ON eba_demo_chart_stats (emp';
wwv_flow_imp.g_varchar2_table(69) := 'loyer)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_chart_stats_3 ON eba_demo_chart_stats (total)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'REM eba_demo_chart_';
wwv_flow_imp.g_varchar2_table(70) := 'grades'||wwv_flow.LF||
'create table eba_demo_chart_grades ('||wwv_flow.LF||
'    id      number,'||wwv_flow.LF||
'    course  varchar2(10),'||wwv_flow.LF||
'    school';
wwv_flow_imp.g_varchar2_table(71) := 'a number,'||wwv_flow.LF||
'	schoolb number not null enable,'||wwv_flow.LF||
'	schoolc number,'||wwv_flow.LF||
'    created                  timestamp(6';
wwv_flow_imp.g_varchar2_table(72) := ') with time zone,'||wwv_flow.LF||
'    created_by               varchar2(255),'||wwv_flow.LF||
'    updated                  timestamp';
wwv_flow_imp.g_varchar2_table(73) := '(6) with time zone,'||wwv_flow.LF||
'    updated_by               varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'REM eba_demo_chart_samples'||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(74) := 'eate table eba_demo_chart_samples ('||wwv_flow.LF||
'    sample1      number,'||wwv_flow.LF||
'    sample2      number,'||wwv_flow.LF||
'    sample3   ';
wwv_flow_imp.g_varchar2_table(75) := '   number,'||wwv_flow.LF||
'    sample4      number,'||wwv_flow.LF||
'    sample5      number'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'REM eba_demo_chart_sample_names'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(76) := 'create table eba_demo_chart_sample_names ('||wwv_flow.LF||
'    id            number not null '||wwv_flow.LF||
'                  cons';
wwv_flow_imp.g_varchar2_table(77) := 'traint eba_demo_samples_pk '||wwv_flow.LF||
'                  primary key,'||wwv_flow.LF||
'    sample_name   varchar2(30) not null e';
wwv_flow_imp.g_varchar2_table(78) := 'nable,'||wwv_flow.LF||
'    sample_date   date,'||wwv_flow.LF||
'    created       timestamp(6) with time zone,'||wwv_flow.LF||
'    created_by    varc';
wwv_flow_imp.g_varchar2_table(79) := 'har2(255),'||wwv_flow.LF||
'    updated       timestamp(6) with time zone,'||wwv_flow.LF||
'    updated_by    varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'RE';
wwv_flow_imp.g_varchar2_table(80) := 'M eba_demo_chart_sample_data'||wwv_flow.LF||
'create table eba_demo_chart_sample_data ('||wwv_flow.LF||
'    id            number not ';
wwv_flow_imp.g_varchar2_table(81) := 'null '||wwv_flow.LF||
'                  constraint eba_demo_sample_data_pk '||wwv_flow.LF||
'                  primary key,'||wwv_flow.LF||
'    sampl';
wwv_flow_imp.g_varchar2_table(82) := 'e_id     number constraint eba_demo_sample_fk'||wwv_flow.LF||
'                  references eba_demo_chart_sample_nam';
wwv_flow_imp.g_varchar2_table(83) := 'es on delete cascade,'||wwv_flow.LF||
'    response      number,'||wwv_flow.LF||
'    created       timestamp(6) with time zone,'||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(84) := 'reated_by    varchar2(255),'||wwv_flow.LF||
'    updated       timestamp(6) with time zone,'||wwv_flow.LF||
'    updated_by    varchar';
wwv_flow_imp.g_varchar2_table(85) := '2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_chart_sample_idx1 on eba_demo_chart_sample_data (sample_id)'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2579290461489116305)
,p_install_id=>wwv_flow_imp.id(2579186863174088443)
,p_name=>'Tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
