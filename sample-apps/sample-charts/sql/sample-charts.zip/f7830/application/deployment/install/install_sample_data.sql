prompt --application/deployment/install/install_sample_data
begin
--   Manifest
--     INSTALL: INSTALL-Sample Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>2654143468017583
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace procedure eba_demo_chart_data'||wwv_flow.LF||
'as'||wwv_flow.LF||
'  l_open   number;'||wwv_flow.LF||
'  l_close  number;'||wwv_flow.LF||
'  l_high   ';
wwv_flow_imp.g_varchar2_table(2) := 'number;'||wwv_flow.LF||
'  l_low    number;'||wwv_flow.LF||
'  l_volume number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from eba_demo_chart_projects;'||wwv_flow.LF||
'    de';
wwv_flow_imp.g_varchar2_table(3) := 'lete from eba_demo_chart_tasks;'||wwv_flow.LF||
'    delete from eba_demo_chart_population;'||wwv_flow.LF||
'    delete from eba_demo_';
wwv_flow_imp.g_varchar2_table(4) := 'chart_emp;'||wwv_flow.LF||
'    delete from eba_demo_chart_dept;'||wwv_flow.LF||
'    delete from eba_demo_chart_bball;'||wwv_flow.LF||
'    delete fro';
wwv_flow_imp.g_varchar2_table(5) := 'm eba_demo_chart_orders;'||wwv_flow.LF||
'    delete from eba_demo_chart_products;'||wwv_flow.LF||
'    delete from eba_demo_chart_sta';
wwv_flow_imp.g_varchar2_table(6) := 'ts;'||wwv_flow.LF||
'    delete from eba_demo_chart_stocks;'||wwv_flow.LF||
'    delete from eba_demo_chart_grades;'||wwv_flow.LF||
'    delete from eb';
wwv_flow_imp.g_varchar2_table(7) := 'a_demo_chart_samples;'||wwv_flow.LF||
'    delete from eba_demo_chart_sample_data;'||wwv_flow.LF||
'    delete from eba_demo_chart_sam';
wwv_flow_imp.g_varchar2_table(8) := 'ple_names;'||wwv_flow.LF||
''||wwv_flow.LF||
'/* Charts Projects Table Data */'||wwv_flow.LF||
'    insert into eba_demo_chart_projects (ID,PROJECT,CRE';
wwv_flow_imp.g_varchar2_table(9) := 'ATED,CREATED_BY) values (1,''Maintain Support Systems'',to_date(''01-11-2011'',''DD-MM-YYYY''), to_date(''3';
wwv_flow_imp.g_varchar2_table(10) := '0-12-2011'',''DD-MM-YYYY''));'||wwv_flow.LF||
'    insert into eba_demo_chart_projects (ID,PROJECT,CREATED,CREATED_BY) v';
wwv_flow_imp.g_varchar2_table(11) := 'alues (2,''Load Software'',to_date(''03-12-2011'',''DD-MM-YYYY''), to_date(''10-12-2011'',''DD-MM-YYYY''));'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(12) := '  insert into eba_demo_chart_projects (ID,PROJECT,CREATED,CREATED_BY) values (3,''Email Integration'',';
wwv_flow_imp.g_varchar2_table(13) := 'to_date(''12-01-2012'',''DD-MM-YYYY''), to_date(''17-02-2012'',''DD-MM-YYYY''));'||wwv_flow.LF||
'    insert into eba_demo_ch';
wwv_flow_imp.g_varchar2_table(14) := 'art_projects (ID,PROJECT,CREATED,CREATED_BY) values (4,''Documentation'',to_date(''19-11-2011'',''DD-MM-Y';
wwv_flow_imp.g_varchar2_table(15) := 'YYY''), to_date(''25-11-2011'',''DD-MM-YYYY''));'||wwv_flow.LF||
'    insert into eba_demo_chart_projects (ID,PROJECT,CREA';
wwv_flow_imp.g_varchar2_table(16) := 'TED,CREATED_BY) values (5,''Training'',to_date(''01-12-2011'',''DD-MM-YYYY''), to_date(''08-12-2011'',''DD-MM';
wwv_flow_imp.g_varchar2_table(17) := '-YYYY''));'||wwv_flow.LF||
'    insert into eba_demo_chart_projects (ID,PROJECT,CREATED,CREATED_BY) values (6,''Bug Tra';
wwv_flow_imp.g_varchar2_table(18) := 'cker'',to_date(''16-12-2011'',''DD-MM-YYYY''), to_date(''19-01-2012'',''DD-MM-YYYY''));'||wwv_flow.LF||
'    insert into eba_d';
wwv_flow_imp.g_varchar2_table(19) := 'emo_chart_projects (ID,PROJECT,CREATED,CREATED_BY) values (7,''Migrate Old Systems'',to_date(''28-12-20';
wwv_flow_imp.g_varchar2_table(20) := '11'',''DD-MM-YYYY''), to_date(''22-02-2012'',''DD-MM-YYYY''));'||wwv_flow.LF||
'    insert into eba_demo_chart_projects (ID,';
wwv_flow_imp.g_varchar2_table(21) := 'PROJECT,CREATED,CREATED_BY) values (8,''Software Projects Tracking'',to_date(''15-12-2012'',''DD-MM-YYYY''';
wwv_flow_imp.g_varchar2_table(22) := '), to_date(''20-01-2012'',''DD-MM-YYYY''));'||wwv_flow.LF||
'    insert into eba_demo_chart_projects (ID,PROJECT,CREATED,';
wwv_flow_imp.g_varchar2_table(23) := 'CREATED_BY) values (9,''Public Website'',to_date(''06-12-2011'',''DD-MM-YYYY''), to_date(''09-12-2011'',''DD-';
wwv_flow_imp.g_varchar2_table(24) := 'MM-YYYY''));'||wwv_flow.LF||
'    insert into eba_demo_chart_projects (ID,PROJECT,CREATED,CREATED_BY) values (10,''Earl';
wwv_flow_imp.g_varchar2_table(25) := 'y Adopter Release'',to_date(''05-12-2011'',''DD-MM-YYYY''), to_date(''06-02-2012'',''DD-MM-YYYY''));'||wwv_flow.LF||
'    inse';
wwv_flow_imp.g_varchar2_table(26) := 'rt into eba_demo_chart_projects (ID,PROJECT,CREATED,CREATED_BY) values (11,''Environment Configuratio';
wwv_flow_imp.g_varchar2_table(27) := 'n'',to_date(''01-11-2011'',''DD-MM-YYYY''), to_date(''22-11-2011'',''DD-MM-YYYY''));'||wwv_flow.LF||
'    insert into eba_demo';
wwv_flow_imp.g_varchar2_table(28) := '_chart_projects (ID,PROJECT,CREATED,CREATED_BY) values (12,''Customer Satisfaction Survey'',to_date(''1';
wwv_flow_imp.g_varchar2_table(29) := '8-12-2011'',''DD-MM-YYYY''), to_date(''01-01-2011'',''DD-MM-YYYY''));'||wwv_flow.LF||
'    insert into eba_demo_chart_projec';
wwv_flow_imp.g_varchar2_table(30) := 'ts (ID,PROJECT,CREATED,CREATED_BY) values (13,''Convert Excel Spreadsheet'',to_date(''15-12-2011'',''DD-M';
wwv_flow_imp.g_varchar2_table(31) := 'M-YYYY''), to_date(''15-03-2012'',''DD-MM-YYYY''));'||wwv_flow.LF||
'    insert into eba_demo_chart_projects (ID,PROJECT,C';
wwv_flow_imp.g_varchar2_table(32) := 'REATED,CREATED_BY) values (14,''Upgrade Equipment'',to_date(''01-02-2012'',''DD-MM-YYYY''), to_date(''30-05';
wwv_flow_imp.g_varchar2_table(33) := '-2012'',''DD-MM-YYYY''));'||wwv_flow.LF||
'    '||wwv_flow.LF||
''||wwv_flow.LF||
'/* Charts Tasks Table Data */'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,';
wwv_flow_imp.g_varchar2_table(34) := 'PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (74,14,''Dec';
wwv_flow_imp.g_varchar2_table(35) := 'ommission servers'',to_date(''01-02-12'',''DD-MM-RR''),to_date(''30-04-12'',''DD-MM-RR''),''Pending'',''Al Bines';
wwv_flow_imp.g_varchar2_table(36) := ''',0,500,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS';
wwv_flow_imp.g_varchar2_table(37) := ',ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (75,6,''Measure effectiveness of improved QA'',to_date(''0';
wwv_flow_imp.g_varchar2_table(38) := '1-02-12'',''DD-MM-RR''),to_date(''02-03-12'',''DD-MM-RR''),''Pending'',''Myra Sutcliff'',0,1500,18);'||wwv_flow.LF||
'    insert';
wwv_flow_imp.g_varchar2_table(39) := ' into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,';
wwv_flow_imp.g_varchar2_table(40) := 'PARENT_TASK) values (76,10,''Response to Customer Feedback'',to_date(''01-02-12'',''DD-MM-RR''),to_date(''2';
wwv_flow_imp.g_varchar2_table(41) := '5-05-12'',''DD-MM-RR''),''Pending'',''Russ Saunders'',0,6000,33);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,';
wwv_flow_imp.g_varchar2_table(42) := 'PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (77,10,''Use';
wwv_flow_imp.g_varchar2_table(43) := 'r acceptance testing'',to_date(''16-02-12'',''DD-MM-RR''),to_date(''20-05-12'',''DD-MM-RR''),''Pending'',''Russ ';
wwv_flow_imp.g_varchar2_table(44) := 'Saunders'',0,2500,33);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE';
wwv_flow_imp.g_varchar2_table(45) := ',STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (78,10,''End-user Training'',to_date(''20-03-12'',''D';
wwv_flow_imp.g_varchar2_table(46) := 'D-MM-RR''),to_date(''01-06-12'',''DD-MM-RR''),''Pending'',''Myra Sutcliff'',0,2500,79);'||wwv_flow.LF||
'    insert into eba_d';
wwv_flow_imp.g_varchar2_table(47) := 'emo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK';
wwv_flow_imp.g_varchar2_table(48) := ') values (79,10,''Rollout sample applications'',to_date(''23-05-12'',''DD-MM-RR''),to_date(''03-06-12'',''DD-';
wwv_flow_imp.g_varchar2_table(49) := 'MM-RR''),''Pending'',''Pam King'',0,500,32);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,S';
wwv_flow_imp.g_varchar2_table(50) := 'TART_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (72,14,''Installation'',to_date(';
wwv_flow_imp.g_varchar2_table(51) := '''03-02-12'',''DD-MM-RR''),to_date(''04-03-12'',''DD-MM-RR''),''Pending'',''Mark Nile'',0,1500,67);'||wwv_flow.LF||
'    insert i';
wwv_flow_imp.g_varchar2_table(52) := 'nto eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PA';
wwv_flow_imp.g_varchar2_table(53) := 'RENT_TASK) values (73,14,''Notify users'',to_date(''06-03-12'',''DD-MM-RR''),to_date(''09-03-12'',''DD-MM-RR''';
wwv_flow_imp.g_varchar2_table(54) := '),''Pending'',''Mark Nile'',0,200,67);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_';
wwv_flow_imp.g_varchar2_table(55) := 'DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (34,10,''Plan production release sch';
wwv_flow_imp.g_varchar2_table(56) := 'edule'',to_date(''22-12-11'',''DD-MM-RR''),to_date(''22-12-11'',''DD-MM-RR''),''Closed'',''Pam King'',100,100,32)';
wwv_flow_imp.g_varchar2_table(57) := ';'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,';
wwv_flow_imp.g_varchar2_table(58) := 'COST,BUDGET,PARENT_TASK) values (37,12,''Complete questionnaire'',to_date(''18-12-11'',''DD-MM-RR''),to_da';
wwv_flow_imp.g_varchar2_table(59) := 'te(''01-01-12'',''DD-MM-RR''),''On-Hold'',''Irene Jones'',1200,800,38);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks';
wwv_flow_imp.g_varchar2_table(60) := ' (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (59,11';
wwv_flow_imp.g_varchar2_table(61) := ',''Select servers for Development, Test, Production'',to_date(''03-11-11'',''DD-MM-RR''),to_date(''08-11-11';
wwv_flow_imp.g_varchar2_table(62) := ''',''DD-MM-RR''),''Closed'',''James Cassidy'',200,600,61);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT';
wwv_flow_imp.g_varchar2_table(63) := ',TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (3,1,''HR Support S';
wwv_flow_imp.g_varchar2_table(64) := 'ystems'',to_date(''01-11-11'',''DD-MM-RR''),to_date(''12-03-12'',''DD-MM-RR''),''Closed'',''Al Bines'',300,500,nu';
wwv_flow_imp.g_varchar2_table(65) := 'll);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_';
wwv_flow_imp.g_varchar2_table(66) := 'TO,COST,BUDGET,PARENT_TASK) values (1,1,''HR software upgrades'',to_date(''01-11-11'',''DD-MM-RR''),to_dat';
wwv_flow_imp.g_varchar2_table(67) := 'e(''27-02-12'',''DD-MM-RR''),''On-Hold'',''Pam King'',8000,7000,3);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID';
wwv_flow_imp.g_varchar2_table(68) := ',PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (2,1,''Arra';
wwv_flow_imp.g_varchar2_table(69) := 'nge for vacation coverage'',to_date(''01-11-11'',''DD-MM-RR''),to_date(''31-12-11'',''DD-MM-RR''),''On-Hold'',''';
wwv_flow_imp.g_varchar2_table(70) := 'Russ Sanders'',9500,7000,3);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,EN';
wwv_flow_imp.g_varchar2_table(71) := 'D_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (4,3,''Complete plan'',to_date(''08-11-11'',''D';
wwv_flow_imp.g_varchar2_table(72) := 'D-MM-RR''),to_date(''14-12-11'',''DD-MM-RR''),''Closed'',''Mark Nile'',3000,1500,44);'||wwv_flow.LF||
'    insert into eba_dem';
wwv_flow_imp.g_varchar2_table(73) := 'o_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) ';
wwv_flow_imp.g_varchar2_table(74) := 'values (5,3,''Check software licenses'',to_date(''12-12-11'',''DD-MM-RR''),to_date(''13-12-11'',''DD-MM-RR''),';
wwv_flow_imp.g_varchar2_table(75) := '''Closed'',''Mark Nile'',200,200,44);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_D';
wwv_flow_imp.g_varchar2_table(76) := 'ATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (6,5,''Create training workspace'',to_';
wwv_flow_imp.g_varchar2_table(77) := 'date(''01-12-11'',''DD-MM-RR''),to_date(''08-12-11'',''DD-MM-RR''),''Closed'',''James Cassidy'',500,700,36);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(78) := ' insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,';
wwv_flow_imp.g_varchar2_table(79) := 'BUDGET,PARENT_TASK) values (7,5,''Publish links to self-study courses'',to_date(''01-12-11'',''DD-MM-RR'')';
wwv_flow_imp.g_varchar2_table(80) := ',to_date(''01-12-11'',''DD-MM-RR''),''Closed'',''John Watson'',100,100,36);'||wwv_flow.LF||
'    insert into eba_demo_chart_t';
wwv_flow_imp.g_varchar2_table(81) := 'asks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (8';
wwv_flow_imp.g_varchar2_table(82) := ',2,''Identify point solutions required'',to_date(''03-12-11'',''DD-MM-RR''),to_date(''05-12-11'',''DD-MM-RR'')';
wwv_flow_imp.g_varchar2_table(83) := ',''Closed'',''John Watson'',200,300,49);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,STAR';
wwv_flow_imp.g_varchar2_table(84) := 'T_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (9,2,''Install in development'',to_';
wwv_flow_imp.g_varchar2_table(85) := 'date(''07-12-11'',''DD-MM-RR''),to_date(''07-12-11'',''DD-MM-RR''),''Closed'',''John Watson'',100,100,49);'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(86) := 'nsert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BU';
wwv_flow_imp.g_varchar2_table(87) := 'DGET,PARENT_TASK) values (15,4,''Identify owners'',to_date(''19-11-11'',''DD-MM-RR''),to_date(''22-11-11'',''';
wwv_flow_imp.g_varchar2_table(88) := 'DD-MM-RR''),''Closed'',''Hank Davis'',250,300,17);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_';
wwv_flow_imp.g_varchar2_table(89) := 'NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (16,4,''Initial Draft Rev';
wwv_flow_imp.g_varchar2_table(90) := 'iew'',to_date(''23-11-11'',''DD-MM-RR''),to_date(''23-11-11'',''DD-MM-RR''),''Closed'',''Hank Davis'',100,100,17)';
wwv_flow_imp.g_varchar2_table(91) := ';'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,';
wwv_flow_imp.g_varchar2_table(92) := 'COST,BUDGET,PARENT_TASK) values (17,4,''Monitor Review Comments'',to_date(''23-11-11'',''DD-MM-RR''),to_da';
wwv_flow_imp.g_varchar2_table(93) := 'te(''31-12-11'',''DD-MM-RR''),''Closed'',''Hank Davis'',450,500,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks ';
wwv_flow_imp.g_varchar2_table(94) := '(ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (18,6,''';
wwv_flow_imp.g_varchar2_table(95) := 'Implement bug tracking software'',to_date(''15-11-11'',''DD-MM-RR''),to_date(''15-11-11'',''DD-MM-RR''),''Clos';
wwv_flow_imp.g_varchar2_table(96) := 'ed'',''Myra Sutcliff'',100,100,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_';
wwv_flow_imp.g_varchar2_table(97) := 'DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (19,6,''Review automated testing too';
wwv_flow_imp.g_varchar2_table(98) := 'ls'',to_date(''16-11-11'',''DD-MM-RR''),to_date(''15-12-11'',''DD-MM-RR''),''Closed'',''Myra Sutcliff'',2750,1500';
wwv_flow_imp.g_varchar2_table(99) := ',18);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED';
wwv_flow_imp.g_varchar2_table(100) := '_TO,COST,BUDGET,PARENT_TASK) values (20,7,''Identify pilot applications'',to_date(''10-11-11'',''DD-MM-RR';
wwv_flow_imp.g_varchar2_table(101) := '''),to_date(''15-11-11'',''DD-MM-RR''),''Closed'',''Mark Nile'',300,500,53);'||wwv_flow.LF||
'    insert into eba_demo_chart_t';
wwv_flow_imp.g_varchar2_table(102) := 'asks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (2';
wwv_flow_imp.g_varchar2_table(103) := '1,7,''Migrate pilot applications to '',to_date(''20-11-11'',''DD-MM-RR''),to_date(''25-11-11'',''DD-MM-RR''),''';
wwv_flow_imp.g_varchar2_table(104) := 'Closed'',''Mark Nile'',500,500,53);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DA';
wwv_flow_imp.g_varchar2_table(105) := 'TE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (22,8,''Customize Software Projects so';
wwv_flow_imp.g_varchar2_table(106) := 'ftware'',to_date(''15-12-11'',''DD-MM-RR''),to_date(''20-01-12'',''DD-MM-RR''),''Open'',''Tom Suess'',600,1000,28';
wwv_flow_imp.g_varchar2_table(107) := ');'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO';
wwv_flow_imp.g_varchar2_table(108) := ',COST,BUDGET,PARENT_TASK) values (23,7,''Post-migration review'',to_date(''01-12-11'',''DD-MM-RR''),to_dat';
wwv_flow_imp.g_varchar2_table(109) := 'e(''01-12-11'',''DD-MM-RR''),''Closed'',''Mark Nile'',100,100,53);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,';
wwv_flow_imp.g_varchar2_table(110) := 'PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (24,7,''User';
wwv_flow_imp.g_varchar2_table(111) := ' acceptance testing'',to_date(''03-12-11'',''DD-MM-RR''),to_date(''04-12-11'',''DD-MM-RR''),''Closed'',''Mark Ni';
wwv_flow_imp.g_varchar2_table(112) := 'le'',600,200,23);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STAT';
wwv_flow_imp.g_varchar2_table(113) := 'US,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (25,8,''Enter base data (Projects, Milestones, etc.)'',';
wwv_flow_imp.g_varchar2_table(114) := 'to_date(''10-12-11'',''DD-MM-RR''),to_date(''11-12-11'',''DD-MM-RR''),''Closed'',''Tom Suess'',200,200,28);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(115) := 'insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,B';
wwv_flow_imp.g_varchar2_table(116) := 'UDGET,PARENT_TASK) values (26,8,''Load current tasks and enhancements'',to_date(''12-12-11'',''DD-MM-RR'')';
wwv_flow_imp.g_varchar2_table(117) := ',to_date(''16-12-11'',''DD-MM-RR''),''Closed'',''Tom Suess'',400,500,28);'||wwv_flow.LF||
'    insert into eba_demo_chart_tas';
wwv_flow_imp.g_varchar2_table(118) := 'ks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (27,';
wwv_flow_imp.g_varchar2_table(119) := '6,''Document quality assurance procedures'',to_date(''16-12-11'',''DD-MM-RR''),to_date(''19-01-12'',''DD-MM-R';
wwv_flow_imp.g_varchar2_table(120) := 'R''),''On-Hold'',''Myra Sutcliff'',3500,4000,18);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_N';
wwv_flow_imp.g_varchar2_table(121) := 'AME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (28,8,''Conduct project ki';
wwv_flow_imp.g_varchar2_table(122) := 'ckoff meeting'',to_date(''05-12-11'',''DD-MM-RR''),to_date(''05-12-11'',''DD-MM-RR''),''Closed'',''Pam King'',100';
wwv_flow_imp.g_varchar2_table(123) := ',100,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,AS';
wwv_flow_imp.g_varchar2_table(124) := 'SIGNED_TO,COST,BUDGET,PARENT_TASK) values (29,9,''Determine host server'',to_date(''06-12-11'',''DD-MM-RR';
wwv_flow_imp.g_varchar2_table(125) := '''),to_date(''07-12-11'',''DD-MM-RR''),''Closed'',''Tiger Scott'',200,200,40);'||wwv_flow.LF||
'    insert into eba_demo_chart';
wwv_flow_imp.g_varchar2_table(126) := '_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values ';
wwv_flow_imp.g_varchar2_table(127) := '(30,9,''Check software licenses'',to_date(''07-12-11'',''DD-MM-RR''),to_date(''07-12-11'',''DD-MM-RR''),''Close';
wwv_flow_imp.g_varchar2_table(128) := 'd'',''Tom Suess'',100,100,40);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,EN';
wwv_flow_imp.g_varchar2_table(129) := 'D_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (31,10,''Identify pilot users'',to_date(''05-';
wwv_flow_imp.g_varchar2_table(130) := '12-11'',''DD-MM-RR''),to_date(''06-12-11'',''DD-MM-RR''),''Closed'',''Scott Spencer'',200,200,33);'||wwv_flow.LF||
'    insert i';
wwv_flow_imp.g_varchar2_table(131) := 'nto eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PA';
wwv_flow_imp.g_varchar2_table(132) := 'RENT_TASK) values (32,10,''Software Deliverable'',to_date(''07-12-11'',''DD-MM-RR''),to_date(''20-12-11'',''D';
wwv_flow_imp.g_varchar2_table(133) := 'D-MM-RR''),''Closed'',''Scott Spencer'',400,500,33);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TAS';
wwv_flow_imp.g_varchar2_table(134) := 'K_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (33,10,''Early Adopter ';
wwv_flow_imp.g_varchar2_table(135) := 'Release'',to_date(''21-12-11'',''DD-MM-RR''),to_date(''21-12-11'',''DD-MM-RR''),''Closed'',''Pam King'',100,100,n';
wwv_flow_imp.g_varchar2_table(136) := 'ull);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED';
wwv_flow_imp.g_varchar2_table(137) := '_TO,COST,BUDGET,PARENT_TASK) values (35,11,''Determine midtier configuration(s)'',to_date(''02-11-11'',''';
wwv_flow_imp.g_varchar2_table(138) := 'DD-MM-RR''),to_date(''02-11-11'',''DD-MM-RR''),''Closed'',''James Cassidy'',100,100,61);'||wwv_flow.LF||
'    insert into eba_';
wwv_flow_imp.g_varchar2_table(139) := 'demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TAS';
wwv_flow_imp.g_varchar2_table(140) := 'K) values (36,5,''Manage Training Activities'',to_date(''28-11-11'',''DD-MM-RR''),to_date(''03-02-12'',''DD-M';
wwv_flow_imp.g_varchar2_table(141) := 'M-RR''),''On-Hold'',''John Watson'',1000,2000,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TAS';
wwv_flow_imp.g_varchar2_table(142) := 'K_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (38,12,''Review feedbac';
wwv_flow_imp.g_varchar2_table(143) := 'k'',to_date(''09-01-12'',''DD-MM-RR''),to_date(''15-01-12'',''DD-MM-RR''),''On-Hold'',''Irene Jones'',200,400,nul';
wwv_flow_imp.g_varchar2_table(144) := 'l);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_T';
wwv_flow_imp.g_varchar2_table(145) := 'O,COST,BUDGET,PARENT_TASK) values (39,12,''Plan rollout schedule'',to_date(''16-01-12'',''DD-MM-RR''),to_d';
wwv_flow_imp.g_varchar2_table(146) := 'ate(''24-01-12'',''DD-MM-RR''),''On-Hold'',''Irene Jones'',0,750,38);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (';
wwv_flow_imp.g_varchar2_table(147) := 'ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (40,9,''P';
wwv_flow_imp.g_varchar2_table(148) := 'lan rollout schedule'',to_date(''10-12-11'',''DD-MM-RR''),to_date(''02-01-12'',''DD-MM-RR''),''On-Hold'',''Al Bi';
wwv_flow_imp.g_varchar2_table(149) := 'nes'',300,1000,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,';
wwv_flow_imp.g_varchar2_table(150) := 'STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (41,9,''Develop web pages'',to_date(''10-01-12'',''DD-';
wwv_flow_imp.g_varchar2_table(151) := 'MM-RR''),to_date(''15-02-12'',''DD-MM-RR''),''On-Hold'',''Tiger Scott'',800,2000,40);'||wwv_flow.LF||
'    insert into eba_dem';
wwv_flow_imp.g_varchar2_table(152) := 'o_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) ';
wwv_flow_imp.g_varchar2_table(153) := 'values (42,9,''Purchase additional software licenses, if needed'',to_date(''17-02-12'',''DD-MM-RR''),to_da';
wwv_flow_imp.g_varchar2_table(154) := 'te(''17-02-12'',''DD-MM-RR''),''On-Hold'',''Tom Suess'',0,100,40);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,';
wwv_flow_imp.g_varchar2_table(155) := 'PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (43,1,''Inve';
wwv_flow_imp.g_varchar2_table(156) := 'stigate new Virus Protection software'',to_date(''29-12-11'',''DD-MM-RR''),to_date(''13-01-12'',''DD-MM-RR'')';
wwv_flow_imp.g_varchar2_table(157) := ',''Open'',''Pam King'',1700,1500,3);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DA';
wwv_flow_imp.g_varchar2_table(158) := 'TE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (44,3,''Get RFPs for new server'',to_da';
wwv_flow_imp.g_varchar2_table(159) := 'te(''13-12-11'',''DD-MM-RR''),to_date(''03-01-12'',''DD-MM-RR''),''Open'',''Mark Nile'',2000,1000,null);'||wwv_flow.LF||
'    ins';
wwv_flow_imp.g_varchar2_table(160) := 'ert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDG';
wwv_flow_imp.g_varchar2_table(161) := 'ET,PARENT_TASK) values (45,13,''Collect mission-critical spreadsheets'',to_date(''15-12-11'',''DD-MM-RR'')';
wwv_flow_imp.g_varchar2_table(162) := ',to_date(''15-02-12'',''DD-MM-RR''),''Open'',''Pam King'',2500,4000,46);'||wwv_flow.LF||
'    insert into eba_demo_chart_task';
wwv_flow_imp.g_varchar2_table(163) := 's (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (46,1';
wwv_flow_imp.g_varchar2_table(164) := '3,''Create  applications from spreadsheets'',to_date(''15-12-11'',''DD-MM-RR''),to_date(''30-05-12'',''DD-MM-';
wwv_flow_imp.g_varchar2_table(165) := 'RR''),''Open'',''Pam King'',6000,10000,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,';
wwv_flow_imp.g_varchar2_table(166) := 'START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (47,13,''Lock spreadsheets'',to';
wwv_flow_imp.g_varchar2_table(167) := '_date(''15-12-11'',''DD-MM-RR''),to_date(''30-05-12'',''DD-MM-RR''),''Open'',''Pam King'',1000,800,46);'||wwv_flow.LF||
'    inse';
wwv_flow_imp.g_varchar2_table(168) := 'rt into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGE';
wwv_flow_imp.g_varchar2_table(169) := 'T,PARENT_TASK) values (48,13,''Send links to previous spreadsheet owners'',to_date(''16-12-11'',''DD-MM-R';
wwv_flow_imp.g_varchar2_table(170) := 'R''),to_date(''01-06-12'',''DD-MM-RR''),''Open'',''Pam King'',1000,1500,46);'||wwv_flow.LF||
'    insert into eba_demo_chart_t';
wwv_flow_imp.g_varchar2_table(171) := 'asks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (4';
wwv_flow_imp.g_varchar2_table(172) := '9,2,''Customize solutions'',to_date(''08-12-11'',''DD-MM-RR''),to_date(''01-03-12'',''DD-MM-RR''),''Open'',''John';
wwv_flow_imp.g_varchar2_table(173) := ' Watson'',1500,4000,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_';
wwv_flow_imp.g_varchar2_table(174) := 'DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (50,2,''Train developers / users'',to_date(''10';
wwv_flow_imp.g_varchar2_table(175) := '-01-12'',''DD-MM-RR''),to_date(''25-03-12'',''DD-MM-RR''),''Pending'',''John Watson'',0,8000,49);'||wwv_flow.LF||
'    insert in';
wwv_flow_imp.g_varchar2_table(176) := 'to eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PAR';
wwv_flow_imp.g_varchar2_table(177) := 'ENT_TASK) values (51,2,''Implement in Production'',to_date(''27-12-11'',''DD-MM-RR''),to_date(''03-05-12'',''';
wwv_flow_imp.g_varchar2_table(178) := 'DD-MM-RR''),''Open'',''John Watson'',200,1500,49);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_';
wwv_flow_imp.g_varchar2_table(179) := 'NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (52,7,''Migrate applicati';
wwv_flow_imp.g_varchar2_table(180) := 'ons'',to_date(''15-12-11'',''DD-MM-RR''),to_date(''20-02-12'',''DD-MM-RR''),''Open'',''Mark Nile'',1000,8000,53);';
wwv_flow_imp.g_varchar2_table(181) := ''||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,C';
wwv_flow_imp.g_varchar2_table(182) := 'OST,BUDGET,PARENT_TASK) values (53,7,''Plan migration schedule'',to_date(''22-12-11'',''DD-MM-RR''),to_dat';
wwv_flow_imp.g_varchar2_table(183) := 'e(''03-03-12'',''DD-MM-RR''),''Open'',''Mark Nile'',1500,6000,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (I';
wwv_flow_imp.g_varchar2_table(184) := 'D,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (54,10,''P';
wwv_flow_imp.g_varchar2_table(185) := 'ublish Feedback application'',to_date(''26-12-11'',''DD-MM-RR''),to_date(''04-05-12'',''DD-MM-RR''),''Open'',''P';
wwv_flow_imp.g_varchar2_table(186) := 'am King'',300,12000,33);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DA';
wwv_flow_imp.g_varchar2_table(187) := 'TE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (55,6,''Train developers on tracking bugs'',to_d';
wwv_flow_imp.g_varchar2_table(188) := 'ate(''20-01-12'',''DD-MM-RR''),to_date(''10-03-12'',''DD-MM-RR''),''On-Hold'',''Myra Sutcliff'',0,2000,18);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(189) := 'insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,B';
wwv_flow_imp.g_varchar2_table(190) := 'UDGET,PARENT_TASK) values (56,7,''End-user Training'',to_date(''28-12-11'',''DD-MM-RR''),to_date(''22-02-12';
wwv_flow_imp.g_varchar2_table(191) := ''',''DD-MM-RR''),''Open'',''John Watson'',0,2000,53);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK';
wwv_flow_imp.g_varchar2_table(192) := '_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (57,11,''Identify server';
wwv_flow_imp.g_varchar2_table(193) := ' requirements'',to_date(''01-11-11'',''DD-MM-RR''),to_date(''02-11-11'',''DD-MM-RR''),''Closed'',''John Watson'',';
wwv_flow_imp.g_varchar2_table(194) := '100,200,61);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,A';
wwv_flow_imp.g_varchar2_table(195) := 'SSIGNED_TO,COST,BUDGET,PARENT_TASK) values (58,11,''Specify security authentication scheme(s)'',to_dat';
wwv_flow_imp.g_varchar2_table(196) := 'e(''03-11-11'',''DD-MM-RR''),to_date(''05-11-11'',''DD-MM-RR''),''Closed'',''John Watson'',200,300,61);'||wwv_flow.LF||
'    inse';
wwv_flow_imp.g_varchar2_table(197) := 'rt into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGE';
wwv_flow_imp.g_varchar2_table(198) := 'T,PARENT_TASK) values (60,11,''Create pilot workspace'',to_date(''10-11-11'',''DD-MM-RR''),to_date(''10-11-';
wwv_flow_imp.g_varchar2_table(199) := '11'',''DD-MM-RR''),''Closed'',''John Watson'',100,100,61);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT';
wwv_flow_imp.g_varchar2_table(200) := ',TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (61,11,''Configure ';
wwv_flow_imp.g_varchar2_table(201) := 'Workspace provisioning'',to_date(''10-11-11'',''DD-MM-RR''),to_date(''10-11-11'',''DD-MM-RR''),''Closed'',''John';
wwv_flow_imp.g_varchar2_table(202) := ' Watson'',200,100,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DA';
wwv_flow_imp.g_varchar2_table(203) := 'TE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (62,11,''Run installation'',to_date(''11-11-11'',''';
wwv_flow_imp.g_varchar2_table(204) := 'DD-MM-RR''),to_date(''11-11-11'',''DD-MM-RR''),''Closed'',''James Cassidy'',100,100,57);'||wwv_flow.LF||
'    insert into eba_';
wwv_flow_imp.g_varchar2_table(205) := 'demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TAS';
wwv_flow_imp.g_varchar2_table(206) := 'K) values (64,14,''Obtain equipment specifications'',to_date(''03-01-12'',''DD-MM-RR''),to_date(''06-01-12''';
wwv_flow_imp.g_varchar2_table(207) := ',''DD-MM-RR''),''Pending'',''James Cassidy'',0,500,67);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,T';
wwv_flow_imp.g_varchar2_table(208) := 'ASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (65,3,''Purchase back';
wwv_flow_imp.g_varchar2_table(209) := 'up server'',to_date(''12-01-12'',''DD-MM-RR''),to_date(''07-02-12'',''DD-MM-RR''),''Pending'',''Mark Nile'',0,300';
wwv_flow_imp.g_varchar2_table(210) := '0,44);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNE';
wwv_flow_imp.g_varchar2_table(211) := 'D_TO,COST,BUDGET,PARENT_TASK) values (66,14,''Identify integration points'',to_date(''08-01-12'',''DD-MM-';
wwv_flow_imp.g_varchar2_table(212) := 'RR''),to_date(''28-01-12'',''DD-MM-RR''),''Pending'',''Mark Nile'',0,2000,67);'||wwv_flow.LF||
'    insert into eba_demo_chart';
wwv_flow_imp.g_varchar2_table(213) := '_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values ';
wwv_flow_imp.g_varchar2_table(214) := '(67,14,''Decommission machines'',to_date(''08-01-12'',''DD-MM-RR''),to_date(''08-01-12'',''DD-MM-RR''),''Pendin';
wwv_flow_imp.g_varchar2_table(215) := 'g'',''Scott Spencer'',0,100,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DAT';
wwv_flow_imp.g_varchar2_table(216) := 'E,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (68,14,''Map data usage'',to_date(''20-01';
wwv_flow_imp.g_varchar2_table(217) := '-12'',''DD-MM-RR''),to_date(''03-03-12'',''DD-MM-RR''),''Pending'',''Mark Nile'',0,8000,67);'||wwv_flow.LF||
'    insert into eb';
wwv_flow_imp.g_varchar2_table(218) := 'a_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_T';
wwv_flow_imp.g_varchar2_table(219) := 'ASK) values (69,14,''Purchase new machines'',to_date(''24-02-12'',''DD-MM-RR''),to_date(''20-03-12'',''DD-MM-';
wwv_flow_imp.g_varchar2_table(220) := 'RR''),''Pending'',''John Watson'',0,2500,67);'||wwv_flow.LF||
'    insert into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,';
wwv_flow_imp.g_varchar2_table(221) := 'START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,PARENT_TASK) values (70,14,''Import data'',to_date(';
wwv_flow_imp.g_varchar2_table(222) := '''25-02-12'',''DD-MM-RR''),to_date(''23-03-12'',''DD-MM-RR''),''Pending'',''John Watson'',0,1000,67);'||wwv_flow.LF||
'    insert';
wwv_flow_imp.g_varchar2_table(223) := ' into eba_demo_chart_tasks (ID,PROJECT,TASK_NAME,START_DATE,END_DATE,STATUS,ASSIGNED_TO,COST,BUDGET,';
wwv_flow_imp.g_varchar2_table(224) := 'PARENT_TASK) values (71,14,''Convert processes'',to_date(''02-02-12'',''DD-MM-RR''),to_date(''01-04-12'',''DD';
wwv_flow_imp.g_varchar2_table(225) := '-MM-RR''),''Pending'',''Pam King'',0,3000,67);'||wwv_flow.LF||
''||wwv_flow.LF||
'update eba_demo_chart_tasks'||wwv_flow.LF||
'   set start_date = start_dat';
wwv_flow_imp.g_varchar2_table(226) := 'e + (SYSDATE - TO_DATE(''01012012'',''MMDDYYYY'')),'||wwv_flow.LF||
'       end_date = end_date + (SYSDATE - TO_DATE(''010';
wwv_flow_imp.g_varchar2_table(227) := '12012'',''MMDDYYYY''));'||wwv_flow.LF||
''||wwv_flow.LF||
'/* Charts Population Table Data */'||wwv_flow.LF||
'    insert into eba_demo_chart_population (';
wwv_flow_imp.g_varchar2_table(228) := 'ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (51,''Wyoming'',''WY'',563626,4);'||wwv_flow.LF||
'    insert into eba';
wwv_flow_imp.g_varchar2_table(229) := '_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (9,''Georgia'',''GA'',9687653';
wwv_flow_imp.g_varchar2_table(230) := ',3);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (';
wwv_flow_imp.g_varchar2_table(231) := '17,''Tennessee'',''TN'',6346105,3);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,';
wwv_flow_imp.g_varchar2_table(232) := 'POPULATION,REGION) values (18,''Missouri'',''MO'',5988927,2);'||wwv_flow.LF||
'    insert into eba_demo_chart_population ';
wwv_flow_imp.g_varchar2_table(233) := '(ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (19,''Maryland'',''MD'',5773552,3);'||wwv_flow.LF||
'    insert into ';
wwv_flow_imp.g_varchar2_table(234) := 'eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (21,''Minnesota'',''MN'',5';
wwv_flow_imp.g_varchar2_table(235) := '303925,2);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) va';
wwv_flow_imp.g_varchar2_table(236) := 'lues (36,''New Mexico'',''NM'',2059179,4);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STAT';
wwv_flow_imp.g_varchar2_table(237) := 'E_CODE,POPULATION,REGION) values (1,''California'',''CA'',37253956,4);'||wwv_flow.LF||
'    insert into eba_demo_chart_po';
wwv_flow_imp.g_varchar2_table(238) := 'pulation (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (2,''Texas'',''TX'',25145561,3);'||wwv_flow.LF||
'    insert';
wwv_flow_imp.g_varchar2_table(239) := ' into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (3,''New York'',''N';
wwv_flow_imp.g_varchar2_table(240) := 'Y'',19378102,1);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGIO';
wwv_flow_imp.g_varchar2_table(241) := 'N) values (4,''Florida'',''FL'',18801310,3);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,ST';
wwv_flow_imp.g_varchar2_table(242) := 'ATE_CODE,POPULATION,REGION) values (5,''Illinois'',''IL'',12830310,2);'||wwv_flow.LF||
'    insert into eba_demo_chart_po';
wwv_flow_imp.g_varchar2_table(243) := 'pulation (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (6,''Pennsylvania'',''PA'',12702379,1);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(244) := ' insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (7,''Ohio''';
wwv_flow_imp.g_varchar2_table(245) := ',''OH'',11536504,2);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,RE';
wwv_flow_imp.g_varchar2_table(246) := 'GION) values (8,''Michigan'',''MI'',9883640,2);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME';
wwv_flow_imp.g_varchar2_table(247) := ',STATE_CODE,POPULATION,REGION) values (10,''North Carolina'',''NC'',9535483,3);'||wwv_flow.LF||
'    insert into eba_demo';
wwv_flow_imp.g_varchar2_table(248) := '_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (11,''New Jersey'',''NJ'',8791894,';
wwv_flow_imp.g_varchar2_table(249) := '1);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (1';
wwv_flow_imp.g_varchar2_table(250) := '2,''Virginia'',''VA'',8001024,3);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,PO';
wwv_flow_imp.g_varchar2_table(251) := 'PULATION,REGION) values (13,''Washington'',''WA'',6724540,4);'||wwv_flow.LF||
'    insert into eba_demo_chart_population ';
wwv_flow_imp.g_varchar2_table(252) := '(ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (14,''Arizona'',''AZ'',6392017,4);'||wwv_flow.LF||
'    insert into e';
wwv_flow_imp.g_varchar2_table(253) := 'ba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (15,''Massachusetts'',''MA';
wwv_flow_imp.g_varchar2_table(254) := ''',6547629,1);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION)';
wwv_flow_imp.g_varchar2_table(255) := ' values (16,''Indiana'',''IN'',6483802,2);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STAT';
wwv_flow_imp.g_varchar2_table(256) := 'E_CODE,POPULATION,REGION) values (20,''Wisconsin'',''WI'',5686986,2);'||wwv_flow.LF||
'    insert into eba_demo_chart_pop';
wwv_flow_imp.g_varchar2_table(257) := 'ulation (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (22,''Colorado'',''CO'',5029196,4);'||wwv_flow.LF||
'    inse';
wwv_flow_imp.g_varchar2_table(258) := 'rt into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (23,''Alabama'',';
wwv_flow_imp.g_varchar2_table(259) := '''AL'',4779736,3);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGI';
wwv_flow_imp.g_varchar2_table(260) := 'ON) values (24,''South Carolina'',''SC'',4625364,3);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE';
wwv_flow_imp.g_varchar2_table(261) := '_NAME,STATE_CODE,POPULATION,REGION) values (25,''Louisiana'',''LA'',4533372,3);'||wwv_flow.LF||
'    insert into eba_demo';
wwv_flow_imp.g_varchar2_table(262) := '_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (26,''Kentucky'',''KY'',4339367,3)';
wwv_flow_imp.g_varchar2_table(263) := ';'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (27,';
wwv_flow_imp.g_varchar2_table(264) := '''Oregon'',''OR'',3831074,4);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULA';
wwv_flow_imp.g_varchar2_table(265) := 'TION,REGION) values (28,''Oklahoma'',''OK'',3751351,3);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,ST';
wwv_flow_imp.g_varchar2_table(266) := 'ATE_NAME,STATE_CODE,POPULATION,REGION) values (29,''Connecticut'',''CT'',3574097,1);'||wwv_flow.LF||
'    insert into eba';
wwv_flow_imp.g_varchar2_table(267) := '_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (30,''Iowa'',''IA'',3046355,2';
wwv_flow_imp.g_varchar2_table(268) := ');'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (31';
wwv_flow_imp.g_varchar2_table(269) := ',''Mississippi'',''MS'',2967297,3);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,';
wwv_flow_imp.g_varchar2_table(270) := 'POPULATION,REGION) values (32,''Arkansas'',''AR'',2915918,3);'||wwv_flow.LF||
'    insert into eba_demo_chart_population ';
wwv_flow_imp.g_varchar2_table(271) := '(ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (33,''Kansas'',''KS'',2853118,2);'||wwv_flow.LF||
'    insert into eb';
wwv_flow_imp.g_varchar2_table(272) := 'a_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (34,''Utah'',''UT'',2763885,';
wwv_flow_imp.g_varchar2_table(273) := '4);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (3';
wwv_flow_imp.g_varchar2_table(274) := '5,''Nevada'',''NV'',2700551,4);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPU';
wwv_flow_imp.g_varchar2_table(275) := 'LATION,REGION) values (37,''West Virginia'',''WV'',1852994,3);'||wwv_flow.LF||
'    insert into eba_demo_chart_population';
wwv_flow_imp.g_varchar2_table(276) := ' (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (38,''Nebraska'',''NE'',1826341,2);'||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(277) := ' eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (39,''Idaho'',''ID'',1567';
wwv_flow_imp.g_varchar2_table(278) := '582,4);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) value';
wwv_flow_imp.g_varchar2_table(279) := 's (40,''Maine'',''ME'',1328361,1);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,P';
wwv_flow_imp.g_varchar2_table(280) := 'OPULATION,REGION) values (41,''New Hampshire'',''NH'',1316470,1);'||wwv_flow.LF||
'    insert into eba_demo_chart_populat';
wwv_flow_imp.g_varchar2_table(281) := 'ion (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (42,''Hawaii'',''HI'',1360301,4);'||wwv_flow.LF||
'    insert int';
wwv_flow_imp.g_varchar2_table(282) := 'o eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (43,''Rhode Island'',''';
wwv_flow_imp.g_varchar2_table(283) := 'RI'',1052567,1);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGIO';
wwv_flow_imp.g_varchar2_table(284) := 'N) values (44,''Montana'',''MT'',989415,4);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STA';
wwv_flow_imp.g_varchar2_table(285) := 'TE_CODE,POPULATION,REGION) values (45,''Delaware'',''DE'',897934,3);'||wwv_flow.LF||
'    insert into eba_demo_chart_popu';
wwv_flow_imp.g_varchar2_table(286) := 'lation (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (46,''South Dakota'',''SD'',814180,2);'||wwv_flow.LF||
'    in';
wwv_flow_imp.g_varchar2_table(287) := 'sert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (47,''Alaska''';
wwv_flow_imp.g_varchar2_table(288) := ',''AK'',710231,4);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGI';
wwv_flow_imp.g_varchar2_table(289) := 'ON) values (48,''North Dakota'',''ND'',672591,2);'||wwv_flow.LF||
'    insert into eba_demo_chart_population (ID,STATE_NA';
wwv_flow_imp.g_varchar2_table(290) := 'ME,STATE_CODE,POPULATION,REGION) values (49,''Vermont'',''VT'',625741,1);'||wwv_flow.LF||
'    insert into eba_demo_chart';
wwv_flow_imp.g_varchar2_table(291) := '_population (ID,STATE_NAME,STATE_CODE,POPULATION,REGION) values (50,''District of Columbia'',''DC'',6017';
wwv_flow_imp.g_varchar2_table(292) := '23,3);'||wwv_flow.LF||
''||wwv_flow.LF||
'/* Charts Dept Table */'||wwv_flow.LF||
'    insert into eba_demo_chart_dept (DEPTNO,DNAME,LOC) values (10,''A';
wwv_flow_imp.g_varchar2_table(293) := 'CCOUNTING'',''NEW YORK'');'||wwv_flow.LF||
'    insert into eba_demo_chart_dept (DEPTNO,DNAME,LOC) values (20,''RESEARCH''';
wwv_flow_imp.g_varchar2_table(294) := ',''DALLAS'');'||wwv_flow.LF||
'    insert into eba_demo_chart_dept (DEPTNO,DNAME,LOC) values (30,''SALES'',''CHICAGO'');'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(295) := '  insert into eba_demo_chart_dept (DEPTNO,DNAME,LOC) values (40,''OPERATIONS'',''BOSTON'');'||wwv_flow.LF||
''||wwv_flow.LF||
'/* Charts E';
wwv_flow_imp.g_varchar2_table(296) := 'mp Table */'||wwv_flow.LF||
'    insert into eba_demo_chart_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values';
wwv_flow_imp.g_varchar2_table(297) := ' (7839,''KING'',''PRESIDENT'',null,to_date(''17-11-81'',''DD-MM-RR''),5000,null,10);'||wwv_flow.LF||
'    insert into eba_dem';
wwv_flow_imp.g_varchar2_table(298) := 'o_chart_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7698,''BLAKE'',''MANAGER'',7839,to_da';
wwv_flow_imp.g_varchar2_table(299) := 'te(''01-05-81'',''DD-MM-RR''),2850,null,30);'||wwv_flow.LF||
'    insert into eba_demo_chart_emp (EMPNO,ENAME,JOB,MGR,HIR';
wwv_flow_imp.g_varchar2_table(300) := 'EDATE,SAL,COMM,DEPTNO) values (7782,''CLARK'',''MANAGER'',7839,to_date(''09-06-81'',''DD-MM-RR''),2450,null,';
wwv_flow_imp.g_varchar2_table(301) := '10);'||wwv_flow.LF||
'    insert into eba_demo_chart_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7566,';
wwv_flow_imp.g_varchar2_table(302) := '''JONES'',''MANAGER'',7839,to_date(''02-04-81'',''DD-MM-RR''),2975,null,20);'||wwv_flow.LF||
'    insert into eba_demo_chart_';
wwv_flow_imp.g_varchar2_table(303) := 'emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7788,''SCOTT'',''ANALYST'',7566,to_date(''09-1';
wwv_flow_imp.g_varchar2_table(304) := '2-82'',''DD-MM-RR''),3000,null,20);'||wwv_flow.LF||
'    insert into eba_demo_chart_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SA';
wwv_flow_imp.g_varchar2_table(305) := 'L,COMM,DEPTNO) values (7902,''FORD'',''ANALYST'',7566,to_date(''03-12-81'',''DD-MM-RR''),3000,null,20);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(306) := 'insert into eba_demo_chart_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7369,''SMITH'',''';
wwv_flow_imp.g_varchar2_table(307) := 'CLERK'',7902,to_date(''17-12-80'',''DD-MM-RR''),800,null,20);'||wwv_flow.LF||
'    insert into eba_demo_chart_emp (EMPNO,E';
wwv_flow_imp.g_varchar2_table(308) := 'NAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7499,''ALLEN'',''SALESMAN'',7698,to_date(''20-02-81'',''DD-M';
wwv_flow_imp.g_varchar2_table(309) := 'M-RR''),1600,300,30);'||wwv_flow.LF||
'    insert into eba_demo_chart_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTN';
wwv_flow_imp.g_varchar2_table(310) := 'O) values (7521,''WARD'',''SALESMAN'',7698,to_date(''22-02-81'',''DD-MM-RR''),1250,500,30);'||wwv_flow.LF||
'    insert into ';
wwv_flow_imp.g_varchar2_table(311) := 'eba_demo_chart_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7654,''MARTIN'',''SALESMAN'',7';
wwv_flow_imp.g_varchar2_table(312) := '698,to_date(''28-09-81'',''DD-MM-RR''),1250,1400,30);'||wwv_flow.LF||
'    insert into eba_demo_chart_emp (EMPNO,ENAME,JO';
wwv_flow_imp.g_varchar2_table(313) := 'B,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7844,''TURNER'',''SALESMAN'',7698,to_date(''08-09-81'',''DD-MM-RR'')';
wwv_flow_imp.g_varchar2_table(314) := ',1500,0,30);'||wwv_flow.LF||
'    insert into eba_demo_chart_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) value';
wwv_flow_imp.g_varchar2_table(315) := 's (7876,''ADAMS'',''CLERK'',7788,to_date(''12-01-83'',''DD-MM-RR''),1100,null,20);'||wwv_flow.LF||
'    insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(316) := 'chart_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7900,''JAMES'',''CLERK'',7698,to_date(''';
wwv_flow_imp.g_varchar2_table(317) := '03-12-81'',''DD-MM-RR''),950,null,30);'||wwv_flow.LF||
'    insert into eba_demo_chart_emp (EMPNO,ENAME,JOB,MGR,HIREDATE';
wwv_flow_imp.g_varchar2_table(318) := ',SAL,COMM,DEPTNO) values (7934,''MILLER'',''CLERK'',7782,to_date(''23-01-82'',''DD-MM-RR''),1300,null,10);'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(319) := '/* Charts BBall Table */'||wwv_flow.LF||
'    insert into eba_demo_chart_bball (ID,CITY,TEAM,CONFERENCE,WINS) values ';
wwv_flow_imp.g_varchar2_table(320) := '(1,''Boston'',''Celtics'',''East'',17);'||wwv_flow.LF||
'    insert into eba_demo_chart_bball (ID,CITY,TEAM,CONFERENCE,WINS';
wwv_flow_imp.g_varchar2_table(321) := ') values (2,''Los Angeles'',''Lakers'',''West'',16);'||wwv_flow.LF||
'    insert into eba_demo_chart_bball (ID,CITY,TEAM,CO';
wwv_flow_imp.g_varchar2_table(322) := 'NFERENCE,WINS) values (3,''Chicago'',''Bulls'',''East'',6);'||wwv_flow.LF||
'    insert into eba_demo_chart_bball (ID,CITY,';
wwv_flow_imp.g_varchar2_table(323) := 'TEAM,CONFERENCE,WINS) values (4,''San Antonio'',''Spurs'',''West'',5);'||wwv_flow.LF||
'    insert into eba_demo_chart_bbal';
wwv_flow_imp.g_varchar2_table(324) := 'l (ID,CITY,TEAM,CONFERENCE,WINS) values (5,''Golden Gate'',''Warriors'',''West'',4);'||wwv_flow.LF||
'    insert into eba_d';
wwv_flow_imp.g_varchar2_table(325) := 'emo_chart_bball (ID,CITY,TEAM,CONFERENCE,WINS) values (6,''Philadelphia'',''76ers'',''East'',3);'||wwv_flow.LF||
'    inser';
wwv_flow_imp.g_varchar2_table(326) := 't into eba_demo_chart_bball (ID,CITY,TEAM,CONFERENCE,WINS) values (7,''Detroit'',''Pistons'',''East'',3);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(327) := '    insert into eba_demo_chart_bball (ID,CITY,TEAM,CONFERENCE,WINS) values (8,''Miami'',''Heat'',''East'',';
wwv_flow_imp.g_varchar2_table(328) := '3);'||wwv_flow.LF||
'    insert into eba_demo_chart_bball (ID,CITY,TEAM,CONFERENCE,WINS) values (9,''New York'',''Knicks';
wwv_flow_imp.g_varchar2_table(329) := ''',''East'',2);'||wwv_flow.LF||
'    insert into eba_demo_chart_bball (ID,CITY,TEAM,CONFERENCE,WINS) values (10,''Houston';
wwv_flow_imp.g_varchar2_table(330) := ''',''Rockets'',''West'',2);'||wwv_flow.LF||
''||wwv_flow.LF||
'/* Charts Products Tables */'||wwv_flow.LF||
'    insert into eba_demo_chart_products(product';
wwv_flow_imp.g_varchar2_table(331) := '_id, product_name, product_description, list_price) values(1,''Apples'',''Red pink lady apples'',1.20);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(332) := '    insert into eba_demo_chart_products(product_id, product_name, product_description, list_price) v';
wwv_flow_imp.g_varchar2_table(333) := 'alues(2,''Bananas'',''Bunches of yellow bananas'',3.80);'||wwv_flow.LF||
'    insert into eba_demo_chart_products(product';
wwv_flow_imp.g_varchar2_table(334) := '_id, product_name, product_description, list_price) values(3,''Cantaloupe'',''Coral coloured melon'',2.9';
wwv_flow_imp.g_varchar2_table(335) := '5);'||wwv_flow.LF||
'    insert into eba_demo_chart_products(product_id, product_name, product_description, list_pric';
wwv_flow_imp.g_varchar2_table(336) := 'e) values(4,''Dates'',''Dried dates'',3.30);'||wwv_flow.LF||
'    insert into eba_demo_chart_products(product_id, product';
wwv_flow_imp.g_varchar2_table(337) := '_name, product_description, list_price) values(5,''Grapes'',''Punnet of Red Seedless Grapes'',2.05);'||wwv_flow.LF||
''||wwv_flow.LF||
'/*';
wwv_flow_imp.g_varchar2_table(338) := ' Charts Orders Table */'||wwv_flow.LF||
'    insert into eba_demo_chart_orders(order_id,product_id, quantity,customer';
wwv_flow_imp.g_varchar2_table(339) := ', sales_date) values (1,1,42,''Store A'',to_date(''08-04-16'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_cha';
wwv_flow_imp.g_varchar2_table(340) := 'rt_orders(order_id,product_id, quantity,customer, sales_date) values (2,2,55,''Store A'',to_date(''09-0';
wwv_flow_imp.g_varchar2_table(341) := '4-16'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_orders(order_id,product_id, quantity,customer, sa';
wwv_flow_imp.g_varchar2_table(342) := 'les_date) values (3,3,36,''Store A'',to_date(''11-04-16'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_o';
wwv_flow_imp.g_varchar2_table(343) := 'rders(order_id,product_id, quantity,customer, sales_date) values (4,4,22,''Store A'',to_date(''12-04-16';
wwv_flow_imp.g_varchar2_table(344) := ''',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_orders(order_id,product_id, quantity,customer, sales_';
wwv_flow_imp.g_varchar2_table(345) := 'date) values (5,5,42,''Store A'',to_date(''14-04-16'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_order';
wwv_flow_imp.g_varchar2_table(346) := 's(order_id,product_id, quantity,customer, sales_date) values (6,1,32,''Acme Store'',to_date(''03-04-16''';
wwv_flow_imp.g_varchar2_table(347) := ',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_orders(order_id,product_id, quantity,customer, sales_d';
wwv_flow_imp.g_varchar2_table(348) := 'ate) values (7,2,39,''Acme Store'',to_date(''04-04-16'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_ord';
wwv_flow_imp.g_varchar2_table(349) := 'ers(order_id,product_id, quantity,customer, sales_date) values (8,3,36,''Acme Store'',to_date(''07-04-1';
wwv_flow_imp.g_varchar2_table(350) := '6'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_orders(order_id,product_id, quantity,customer, sales';
wwv_flow_imp.g_varchar2_table(351) := '_date) values (9,4,27,''Acme Store'',to_date(''13-04-16'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_o';
wwv_flow_imp.g_varchar2_table(352) := 'rders(order_id,product_id, quantity,customer, sales_date) values (10,5,50,''Acme Store'',to_date(''14-0';
wwv_flow_imp.g_varchar2_table(353) := '4-16'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_orders(order_id,product_id, quantity,customer, sa';
wwv_flow_imp.g_varchar2_table(354) := 'les_date) values (11,1,34,''Shop C'',to_date(''08-04-16'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_o';
wwv_flow_imp.g_varchar2_table(355) := 'rders(order_id,product_id, quantity,customer, sales_date) values (12,2,30,''Shop C'',to_date(''09-04-16';
wwv_flow_imp.g_varchar2_table(356) := ''',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_orders(order_id,product_id, quantity,customer, sales_';
wwv_flow_imp.g_varchar2_table(357) := 'date) values (13,3,50,''Shop C'',to_date(''11-04-16'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_order';
wwv_flow_imp.g_varchar2_table(358) := 's(order_id,product_id, quantity,customer, sales_date) values (14,4,46,''Shop C'',to_date(''12-04-16'',''D';
wwv_flow_imp.g_varchar2_table(359) := 'D-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_orders(order_id,product_id, quantity,customer, sales_date';
wwv_flow_imp.g_varchar2_table(360) := ') values (15,5,36,''Shop C'',to_date(''14-04-16'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_orders(or';
wwv_flow_imp.g_varchar2_table(361) := 'der_id,product_id, quantity,customer, sales_date) values (16,1,74,''Deli'',to_date(''02-04-16'',''DD-MM-R';
wwv_flow_imp.g_varchar2_table(362) := 'R''));'||wwv_flow.LF||
'    insert into eba_demo_chart_orders(order_id,product_id, quantity,customer, sales_date) valu';
wwv_flow_imp.g_varchar2_table(363) := 'es (17,2,42,''Deli'',to_date(''04-04-16'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_orders(order_id,p';
wwv_flow_imp.g_varchar2_table(364) := 'roduct_id, quantity,customer, sales_date) values (18,3,70,''Deli'',to_date(''06-04-16'',''DD-MM-RR''));'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(365) := '  insert into eba_demo_chart_orders(order_id,product_id, quantity,customer, sales_date) values (19,4';
wwv_flow_imp.g_varchar2_table(366) := ',46,''Deli'',to_date(''08-04-16'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_orders(order_id,product_i';
wwv_flow_imp.g_varchar2_table(367) := 'd, quantity,customer, sales_date) values (20,5,22,''Deli'',to_date(''10-04-16'',''DD-MM-RR''));'||wwv_flow.LF||
''||wwv_flow.LF||
'/* Charts';
wwv_flow_imp.g_varchar2_table(368) := ' Stats Table */'||wwv_flow.LF||
'    insert into eba_demo_chart_stats (name,country,employee,employer,total) values (';
wwv_flow_imp.g_varchar2_table(369) := '''AU'',''Australia'',0,0,0);'||wwv_flow.LF||
'    insert into eba_demo_chart_stats (name,country,employee,employer,total)';
wwv_flow_imp.g_varchar2_table(370) := ' values (''BE'',''Belgium'',3.5,3.7,7.8);'||wwv_flow.LF||
'    insert into eba_demo_chart_stats (name,country,employee,em';
wwv_flow_imp.g_varchar2_table(371) := 'ployer,total) values (''CA'',''Canada'',2.3,2,4.7);'||wwv_flow.LF||
'    insert into eba_demo_chart_stats (name,country,e';
wwv_flow_imp.g_varchar2_table(372) := 'mployee,employer,total) values (''CZ'',''Czech Republic'',1.8,6,8.3);'||wwv_flow.LF||
'    insert into eba_demo_chart_sta';
wwv_flow_imp.g_varchar2_table(373) := 'ts (name,country,employee,employer,total) values (''DK'',''Denmark'',0,0,0);'||wwv_flow.LF||
'    insert into eba_demo_ch';
wwv_flow_imp.g_varchar2_table(374) := 'art_stats (name,country,employee,employer,total) values (''FI'',''Finland'',1.8,6.8,9);'||wwv_flow.LF||
'    insert into ';
wwv_flow_imp.g_varchar2_table(375) := 'eba_demo_chart_stats (name,country,employee,employer,total) values (''DE'',''Germany'',2.8,3.2,6.9);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(376) := ' insert into eba_demo_chart_stats (name,country,employee,employer,total) values (''GR'',''Greece'',3.4,4';
wwv_flow_imp.g_varchar2_table(377) := '.3,9.2);'||wwv_flow.LF||
'    insert into eba_demo_chart_stats (name,country,employee,employer,total) values (''HU'',''H';
wwv_flow_imp.g_varchar2_table(378) := 'ungary'',1.4,6.4,8.3);'||wwv_flow.LF||
'    insert into eba_demo_chart_stats (name,country,employee,employer,total) va';
wwv_flow_imp.g_varchar2_table(379) := 'lues (''IT'',''Italy'',2.2,6.8,9);'||wwv_flow.LF||
'    insert into eba_demo_chart_stats (name,country,employee,employer,';
wwv_flow_imp.g_varchar2_table(380) := 'total) values (''JA'',''Japan'',3.2,3.1,6.3);'||wwv_flow.LF||
'    insert into eba_demo_chart_stats (name,country,employe';
wwv_flow_imp.g_varchar2_table(381) := 'e,employer,total) values (''KO'',''Korea'',1.2,0.9,2.1);'||wwv_flow.LF||
'    insert into eba_demo_chart_stats (name,coun';
wwv_flow_imp.g_varchar2_table(382) := 'try,employee,employer,total) values (''LU'',''Luxembourg'',2.8,2.4,5.9);'||wwv_flow.LF||
'    insert into eba_demo_chart_';
wwv_flow_imp.g_varchar2_table(383) := 'stats (name,country,employee,employer,total) values (''MX'',''Mexico'',0,0,0);'||wwv_flow.LF||
'    insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(384) := 'chart_stats (name,country,employee,employer,total) values (''NZ'',''New Zealand'',0,0,0);'||wwv_flow.LF||
'    insert int';
wwv_flow_imp.g_varchar2_table(385) := 'o eba_demo_chart_stats (name,country,employee,employer,total) values (''PO'',''Poland'',3,2.6,6.8);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(386) := 'insert into eba_demo_chart_stats (name,country,employee,employer,total) values (''SK'',''Slovakia'',0.9,';
wwv_flow_imp.g_varchar2_table(387) := '2.5,4.3);'||wwv_flow.LF||
'    insert into eba_demo_chart_stats (name,country,employee,employer,total) values (''ES'',''';
wwv_flow_imp.g_varchar2_table(388) := 'Spain'',1.4,6.8,9.2);'||wwv_flow.LF||
'    insert into eba_demo_chart_stats (name,country,employee,employer,total) val';
wwv_flow_imp.g_varchar2_table(389) := 'ues (''SE'',''Sweden'',2.5,3.6,6.2);'||wwv_flow.LF||
'    insert into eba_demo_chart_stats (name,country,employee,employe';
wwv_flow_imp.g_varchar2_table(390) := 'r,total) values (''CH'',''Switzerland'',2.7,2.7,5.9);'||wwv_flow.LF||
'    insert into eba_demo_chart_stats (name,country';
wwv_flow_imp.g_varchar2_table(391) := ',employee,employer,total) values (''TR'',''Turkey'',1.1,1.3,2.4);'||wwv_flow.LF||
'    insert into eba_demo_chart_stats (';
wwv_flow_imp.g_varchar2_table(392) := 'name,country,employee,employer,total) values (''US'',''United States'',1.8,3,5.2);'||wwv_flow.LF||
''||wwv_flow.LF||
'/* Charts Stocks Tab';
wwv_flow_imp.g_varchar2_table(393) := 'le Data */'||wwv_flow.LF||
'    l_open  := 200;'||wwv_flow.LF||
'    l_close := dbms_random.value*5+200;'||wwv_flow.LF||
'    insert into eba_demo_char';
wwv_flow_imp.g_varchar2_table(394) := 't_stocks (ID, STOCK_CODE, STOCK_NAME, PRICING_DATE, PRICING_TIMESTAMP, PRICING_TIMESTAMP_TZ,OPENING_';
wwv_flow_imp.g_varchar2_table(395) := 'VAL,HIGH,LOW,CLOSING_VAL,VOLUME) values (1,''METR'',''Metro Trading'',SYSDATE - 500, SYSTIMESTAMP - 500,';
wwv_flow_imp.g_varchar2_table(396) := 'LOCALTIMESTAMP -500,200,202,199,l_close,1000000);'||wwv_flow.LF||
'    for i in 1..500 loop  '||wwv_flow.LF||
'        l_open   := l_c';
wwv_flow_imp.g_varchar2_table(397) := 'lose;'||wwv_flow.LF||
'        l_close  := l_open + dbms_random.value * 5 * power(-1, round(dbms_random.value));'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(398) := '    l_high   := greatest(l_open, l_close) + dbms_random.value * 2;'||wwv_flow.LF||
'        l_low    := least(l_open,';
wwv_flow_imp.g_varchar2_table(399) := ' l_close) - dbms_random.value * 2;'||wwv_flow.LF||
'        l_volume := 1000000 + dbms_random.value * 10000000;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(400) := '   '||wwv_flow.LF||
'        insert into eba_demo_chart_stocks (ID, STOCK_CODE, STOCK_NAME, PRICING_DATE, PRICING_TIM';
wwv_flow_imp.g_varchar2_table(401) := 'ESTAMP, PRICING_TIMESTAMP_TZ,OPENING_VAL,HIGH,LOW,CLOSING_VAL,VOLUME) values (i+1,''METR'',''Metro Trad';
wwv_flow_imp.g_varchar2_table(402) := 'ing'', SYSDATE-500+i, SYSTIMESTAMP-500+i,CURRENT_TIMESTAMP-500+i,l_open,l_high,l_low,l_close,l_volume';
wwv_flow_imp.g_varchar2_table(403) := ');'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'/* Box Plot Grades Table Data */'||wwv_flow.LF||
'    insert into eba_demo_chart_grades (ID,COU';
wwv_flow_imp.g_varchar2_table(404) := 'RSE,SCHOOLA,SCHOOLB,SCHOOLC) values (1,''English'',93,53,71);'||wwv_flow.LF||
'    insert into eba_demo_chart_grades (I';
wwv_flow_imp.g_varchar2_table(405) := 'D,COURSE,SCHOOLA,SCHOOLB,SCHOOLC) values (2,''Physics'',61,55,65);'||wwv_flow.LF||
'    insert into eba_demo_chart_grad';
wwv_flow_imp.g_varchar2_table(406) := 'es (ID,COURSE,SCHOOLA,SCHOOLB,SCHOOLC) values (3,''English'',70,50,90);'||wwv_flow.LF||
'    insert into eba_demo_chart';
wwv_flow_imp.g_varchar2_table(407) := '_grades (ID,COURSE,SCHOOLA,SCHOOLB,SCHOOLC) values (4,''Math'',50,70,45);'||wwv_flow.LF||
'    insert into eba_demo_cha';
wwv_flow_imp.g_varchar2_table(408) := 'rt_grades (ID,COURSE,SCHOOLA,SCHOOLB,SCHOOLC) values (5,''English'',30,67,90);'||wwv_flow.LF||
'    insert into eba_dem';
wwv_flow_imp.g_varchar2_table(409) := 'o_chart_grades (ID,COURSE,SCHOOLA,SCHOOLB,SCHOOLC) values (6,''English'',85,56,67);'||wwv_flow.LF||
'    insert into eb';
wwv_flow_imp.g_varchar2_table(410) := 'a_demo_chart_grades (ID,COURSE,SCHOOLA,SCHOOLB,SCHOOLC) values (7,''Math'',70,45,59);'||wwv_flow.LF||
'    insert into ';
wwv_flow_imp.g_varchar2_table(411) := 'eba_demo_chart_grades (ID,COURSE,SCHOOLA,SCHOOLB,SCHOOLC) values (8,''Math'',62,53,66);'||wwv_flow.LF||
'    insert int';
wwv_flow_imp.g_varchar2_table(412) := 'o eba_demo_chart_grades (ID,COURSE,SCHOOLA,SCHOOLB,SCHOOLC) values (9,''English'',77,50,60);'||wwv_flow.LF||
'    inser';
wwv_flow_imp.g_varchar2_table(413) := 't into eba_demo_chart_grades (ID,COURSE,SCHOOLA,SCHOOLB,SCHOOLC) values (10,''English'',90,54,69);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(414) := ' insert into eba_demo_chart_grades (ID,COURSE,SCHOOLA,SCHOOLB,SCHOOLC) values (11,''Physics'',60,40,64';
wwv_flow_imp.g_varchar2_table(415) := ');'||wwv_flow.LF||
'    insert into eba_demo_chart_grades (ID,COURSE,SCHOOLA,SCHOOLB,SCHOOLC) values (12,''English'',88';
wwv_flow_imp.g_varchar2_table(416) := ',28,67);'||wwv_flow.LF||
'    insert into eba_demo_chart_grades (ID,COURSE,SCHOOLA,SCHOOLB,SCHOOLC) values (13,''Math''';
wwv_flow_imp.g_varchar2_table(417) := ',71,56,45);'||wwv_flow.LF||
'    insert into eba_demo_chart_grades (ID,COURSE,SCHOOLA,SCHOOLB,SCHOOLC) values (14,''Ma';
wwv_flow_imp.g_varchar2_table(418) := 'th'',63,58,64);'||wwv_flow.LF||
'    insert into eba_demo_chart_grades (ID,COURSE,SCHOOLA,SCHOOLB,SCHOOLC) values (15,';
wwv_flow_imp.g_varchar2_table(419) := '''English'',59,54,65);'||wwv_flow.LF||
'    '||wwv_flow.LF||
'/* Box Plot Samples Table Data */'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (';
wwv_flow_imp.g_varchar2_table(420) := 'SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.64,6.48,9.36,6.48,9.36);'||wwv_flow.LF||
'    insert into eba_demo';
wwv_flow_imp.g_varchar2_table(421) := '_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.47,9.81,16.31,9.81,16.31);'||wwv_flow.LF||
'    in';
wwv_flow_imp.g_varchar2_table(422) := 'sert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.03,8.95,4.02,8.';
wwv_flow_imp.g_varchar2_table(423) := '95,4.02);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9';
wwv_flow_imp.g_varchar2_table(424) := '.44,12.79,8.4,12.79,8.4);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SA';
wwv_flow_imp.g_varchar2_table(425) := 'MPLE5) values (11.07,16.17,16.42,16.17,16.42);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPL';
wwv_flow_imp.g_varchar2_table(426) := 'E2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.11,16.54,15.81,16.54,15.81);'||wwv_flow.LF||
'    insert into eba_demo_chart_sa';
wwv_flow_imp.g_varchar2_table(427) := 'mples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.23,12.93,3.76,12.93,3.76);'||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(428) := ' eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.55,9.23,7.17,9.23,7.17);';
wwv_flow_imp.g_varchar2_table(429) := ''||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (11.17,18.9';
wwv_flow_imp.g_varchar2_table(430) := '3,12.78,18.93,12.78);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE';
wwv_flow_imp.g_varchar2_table(431) := '5) values (9.84,14.94,13.57,14.94,13.57);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SA';
wwv_flow_imp.g_varchar2_table(432) := 'MPLE3,SAMPLE4,SAMPLE5) values (11,0.21,16.99,0.21,16.99);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SA';
wwv_flow_imp.g_varchar2_table(433) := 'MPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.01,12.13,0.72,12.13,0.72);'||wwv_flow.LF||
'    insert into eba_dem';
wwv_flow_imp.g_varchar2_table(434) := 'o_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.12,16.18,5.64,16.18,5.64);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(435) := 'insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.24,12.78,16.1';
wwv_flow_imp.g_varchar2_table(436) := '6,12.78,16.16);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) val';
wwv_flow_imp.g_varchar2_table(437) := 'ues (11.32,12.29,9.98,12.29,9.98);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,S';
wwv_flow_imp.g_varchar2_table(438) := 'AMPLE4,SAMPLE5) values (9.55,10.85,-1.45,10.85,-1.45);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPL';
wwv_flow_imp.g_varchar2_table(439) := 'E1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.37,16.72,null,16.72,13.97);'||wwv_flow.LF||
'    insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(440) := 'chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.49,13.36,null,13.36,13.37);'||wwv_flow.LF||
'    in';
wwv_flow_imp.g_varchar2_table(441) := 'sert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (8.99,6.99,null,6.';
wwv_flow_imp.g_varchar2_table(442) := '99,3.39);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9';
wwv_flow_imp.g_varchar2_table(443) := '.66,15.18,null,15.18,9.12);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,';
wwv_flow_imp.g_varchar2_table(444) := 'SAMPLE5) values (10.78,10.86,null,10.86,-2.9);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPL';
wwv_flow_imp.g_varchar2_table(445) := 'E2,SAMPLE3,SAMPLE4,SAMPLE5) values (11.31,13.78,null,13.78,10.52);'||wwv_flow.LF||
'    insert into eba_demo_chart_sa';
wwv_flow_imp.g_varchar2_table(446) := 'mples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.71,8.31,null,8.31,15.04);'||wwv_flow.LF||
'    insert into ';
wwv_flow_imp.g_varchar2_table(447) := 'eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.86,6.82,null,6.82,7.24);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(448) := '    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.42,6.75,';
wwv_flow_imp.g_varchar2_table(449) := 'null,6.75,13.87);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) v';
wwv_flow_imp.g_varchar2_table(450) := 'alues (9.57,10.13,null,10.13,11.42);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3';
wwv_flow_imp.g_varchar2_table(451) := ',SAMPLE4,SAMPLE5) values (8.92,17.08,null,17.08,12.79);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMP';
wwv_flow_imp.g_varchar2_table(452) := 'LE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.8,14.56,null,14.56,17.91);'||wwv_flow.LF||
'    insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(453) := 'chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.31,18.52,null,18.52,12.5);'||wwv_flow.LF||
'    in';
wwv_flow_imp.g_varchar2_table(454) := 'sert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (8.64,11.66,null,1';
wwv_flow_imp.g_varchar2_table(455) := '1.66,7.41);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values ';
wwv_flow_imp.g_varchar2_table(456) := '(11.06,18.01,null,18.01,21.19);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMP';
wwv_flow_imp.g_varchar2_table(457) := 'LE4,SAMPLE5) values (8.65,13.39,null,13.39,9.69);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SA';
wwv_flow_imp.g_varchar2_table(458) := 'MPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.5,14.9,null,14.9,6.79);'||wwv_flow.LF||
'    insert into eba_demo_chart_sam';
wwv_flow_imp.g_varchar2_table(459) := 'ples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (8.3,20.97,null,20.97,15.16);'||wwv_flow.LF||
'    insert into ';
wwv_flow_imp.g_varchar2_table(460) := 'eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (7.87,11,null,11,3.19);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(461) := 'insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.5,3.85,null,3';
wwv_flow_imp.g_varchar2_table(462) := '.85,15.05);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values ';
wwv_flow_imp.g_varchar2_table(463) := '(9.54,4.18,null,4.18,13.83);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4';
wwv_flow_imp.g_varchar2_table(464) := ',SAMPLE5) values (11.24,15.34,null,15.34,7.2);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPL';
wwv_flow_imp.g_varchar2_table(465) := 'E2,SAMPLE3,SAMPLE4,SAMPLE5) values (8.96,12.6,null,12.6,7);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (';
wwv_flow_imp.g_varchar2_table(466) := 'SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.5,18.48,null,18.48,8);'||wwv_flow.LF||
'    insert into eba_demo_c';
wwv_flow_imp.g_varchar2_table(467) := 'hart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.51,17.22,null,17.22,9);'||wwv_flow.LF||
'    insert ';
wwv_flow_imp.g_varchar2_table(468) := 'into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.29,15.53,null,15.53,';
wwv_flow_imp.g_varchar2_table(469) := 'null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.63';
wwv_flow_imp.g_varchar2_table(470) := ',10.44,null,10.44,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAM';
wwv_flow_imp.g_varchar2_table(471) := 'PLE5) values (9.09,10.31,null,10.31,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,S';
wwv_flow_imp.g_varchar2_table(472) := 'AMPLE3,SAMPLE4,SAMPLE5) values (10.36,5.24,null,5.24,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (';
wwv_flow_imp.g_varchar2_table(473) := 'SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.21,18.02,null,18.02,null);'||wwv_flow.LF||
'    insert into eba_de';
wwv_flow_imp.g_varchar2_table(474) := 'mo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.46,6.82,null,6.82,null);'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(475) := 'nsert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.09,9.07,null,9';
wwv_flow_imp.g_varchar2_table(476) := '.07,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (';
wwv_flow_imp.g_varchar2_table(477) := '9.68,12.86,null,12.86,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4';
wwv_flow_imp.g_varchar2_table(478) := ',SAMPLE5) values (10.51,10.73,null,10.73,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMP';
wwv_flow_imp.g_varchar2_table(479) := 'LE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.78,17.69,null,17.69,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_sa';
wwv_flow_imp.g_varchar2_table(480) := 'mples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.27,12.12,null,12.12,null);'||wwv_flow.LF||
'    insert int';
wwv_flow_imp.g_varchar2_table(481) := 'o eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.61,12.21,null,12.21,nu';
wwv_flow_imp.g_varchar2_table(482) := 'll);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.59,5';
wwv_flow_imp.g_varchar2_table(483) := '.66,null,5.66,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5';
wwv_flow_imp.g_varchar2_table(484) := ') values (9.61,9.3,null,9.3,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,S';
wwv_flow_imp.g_varchar2_table(485) := 'AMPLE4,SAMPLE5) values (10.6,13.49,null,13.49,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1';
wwv_flow_imp.g_varchar2_table(486) := ',SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.2,13.67,null,13.67,null);'||wwv_flow.LF||
'    insert into eba_demo_char';
wwv_flow_imp.g_varchar2_table(487) := 't_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.31,9.06,null,9.06,null);'||wwv_flow.LF||
'    insert in';
wwv_flow_imp.g_varchar2_table(488) := 'to eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (8.47,16.6,null,16.6,null';
wwv_flow_imp.g_varchar2_table(489) := ');'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.71,14';
wwv_flow_imp.g_varchar2_table(490) := '.83,null,14.83,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE';
wwv_flow_imp.g_varchar2_table(491) := '5) values (7.98,12.6,null,12.6,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE';
wwv_flow_imp.g_varchar2_table(492) := '3,SAMPLE4,SAMPLE5) values (11.25,15.25,null,15.25,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAM';
wwv_flow_imp.g_varchar2_table(493) := 'PLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (8.19,9.22,null,9.22,null);'||wwv_flow.LF||
'    insert into eba_demo_ch';
wwv_flow_imp.g_varchar2_table(494) := 'art_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.97,12.11,null,12.11,null);'||wwv_flow.LF||
'    inser';
wwv_flow_imp.g_varchar2_table(495) := 't into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.86,7.43,null,7.43,';
wwv_flow_imp.g_varchar2_table(496) := 'null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (12.0';
wwv_flow_imp.g_varchar2_table(497) := '7,12.19,null,12.19,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SA';
wwv_flow_imp.g_varchar2_table(498) := 'MPLE5) values (11.09,16.49,null,16.49,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2';
wwv_flow_imp.g_varchar2_table(499) := ',SAMPLE3,SAMPLE4,SAMPLE5) values (10.53,9.41,null,9.41,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples';
wwv_flow_imp.g_varchar2_table(500) := ' (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.74,10.49,null,10.49,null);'||wwv_flow.LF||
'    insert into eba_';
wwv_flow_imp.g_varchar2_table(501) := 'demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.92,18.6,null,18.6,null);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(502) := ' insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (8.65,16.65,nul';
wwv_flow_imp.g_varchar2_table(503) := 'l,16.65,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) valu';
wwv_flow_imp.g_varchar2_table(504) := 'es (9.31,11.17,null,11.17,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAM';
wwv_flow_imp.g_varchar2_table(505) := 'PLE4,SAMPLE5) values (11.2,14.49,null,14.49,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,S';
wwv_flow_imp.g_varchar2_table(506) := 'AMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (8.6,16.34,null,16.34,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_s';
wwv_flow_imp.g_varchar2_table(507) := 'amples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (12.55,10.31,null,10.31,null);'||wwv_flow.LF||
'    insert in';
wwv_flow_imp.g_varchar2_table(508) := 'to eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (11.95,11.37,null,11.37,n';
wwv_flow_imp.g_varchar2_table(509) := 'ull);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.9,';
wwv_flow_imp.g_varchar2_table(510) := 'null,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE';
wwv_flow_imp.g_varchar2_table(511) := '5) values (10.97,null,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPL';
wwv_flow_imp.g_varchar2_table(512) := 'E3,SAMPLE4,SAMPLE5) values (9.26,null,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPL';
wwv_flow_imp.g_varchar2_table(513) := 'E1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.32,null,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_cha';
wwv_flow_imp.g_varchar2_table(514) := 'rt_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (8.74,null,null,null,null);'||wwv_flow.LF||
'    insert i';
wwv_flow_imp.g_varchar2_table(515) := 'nto eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (11.06,null,null,null,nu';
wwv_flow_imp.g_varchar2_table(516) := 'll);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (8.99,n';
wwv_flow_imp.g_varchar2_table(517) := 'ull,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5';
wwv_flow_imp.g_varchar2_table(518) := ') values (9.74,null,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3';
wwv_flow_imp.g_varchar2_table(519) := ',SAMPLE4,SAMPLE5) values (9.59,null,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1';
wwv_flow_imp.g_varchar2_table(520) := ',SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.55,null,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart';
wwv_flow_imp.g_varchar2_table(521) := '_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.95,null,null,null,null);'||wwv_flow.LF||
'    insert in';
wwv_flow_imp.g_varchar2_table(522) := 'to eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.8,null,null,null,null';
wwv_flow_imp.g_varchar2_table(523) := ');'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.69,nul';
wwv_flow_imp.g_varchar2_table(524) := 'l,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) ';
wwv_flow_imp.g_varchar2_table(525) := 'values (11.75,null,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,';
wwv_flow_imp.g_varchar2_table(526) := 'SAMPLE4,SAMPLE5) values (10,null,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SA';
wwv_flow_imp.g_varchar2_table(527) := 'MPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.14,null,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_sam';
wwv_flow_imp.g_varchar2_table(528) := 'ples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.06,null,null,null,null);'||wwv_flow.LF||
'    insert into e';
wwv_flow_imp.g_varchar2_table(529) := 'ba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.69,null,null,null,null);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(530) := '   insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.11,null,n';
wwv_flow_imp.g_varchar2_table(531) := 'ull,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) val';
wwv_flow_imp.g_varchar2_table(532) := 'ues (11.15,null,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAM';
wwv_flow_imp.g_varchar2_table(533) := 'PLE4,SAMPLE5) values (10.73,null,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_samples (SAMPLE1,SA';
wwv_flow_imp.g_varchar2_table(534) := 'MPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.6,null,null,null,null);'||wwv_flow.LF||
'    insert into eba_demo_chart_sam';
wwv_flow_imp.g_varchar2_table(535) := 'ples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (10.33,null,null,null,null);'||wwv_flow.LF||
'    insert into e';
wwv_flow_imp.g_varchar2_table(536) := 'ba_demo_chart_samples (SAMPLE1,SAMPLE2,SAMPLE3,SAMPLE4,SAMPLE5) values (9.63,null,null,null,null);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(537) := '   '||wwv_flow.LF||
'/* Box Plot Sample Names Table Data */'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_names (ID,SAMPLE_NA';
wwv_flow_imp.g_varchar2_table(538) := 'ME,SAMPLE_DATE) values (1,''Sample 1'',to_date(''20-07-17'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart';
wwv_flow_imp.g_varchar2_table(539) := '_sample_names (ID,SAMPLE_NAME,SAMPLE_DATE) values (2,''Sample 2'',to_date(''27-07-17'',''DD-MM-RR''));'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(540) := ' insert into eba_demo_chart_sample_names (ID,SAMPLE_NAME,SAMPLE_DATE) values (3,''Sample 3'',to_date(''';
wwv_flow_imp.g_varchar2_table(541) := '30-07-17'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_names (ID,SAMPLE_NAME,SAMPLE_DATE) val';
wwv_flow_imp.g_varchar2_table(542) := 'ues (4,''Sample 4'',to_date(''03-08-17'',''DD-MM-RR''));'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_names (ID,S';
wwv_flow_imp.g_varchar2_table(543) := 'AMPLE_NAME,SAMPLE_DATE) values (5,''Sample 5'',to_date(''10-08-17'',''DD-MM-RR''));'||wwv_flow.LF||
'    '||wwv_flow.LF||
'/* Box Plot Sampl';
wwv_flow_imp.g_varchar2_table(544) := 'e Data Table Data */'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (321,';
wwv_flow_imp.g_varchar2_table(545) := '1,9.64);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (322,2,6.48);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(546) := ' insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (323,3,9.36);'||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(547) := ' eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (324,4,6.48);'||wwv_flow.LF||
'    insert into eba_demo_ch';
wwv_flow_imp.g_varchar2_table(548) := 'art_sample_data (ID,SAMPLE_ID,RESPONSE) values (325,5,9.36);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_d';
wwv_flow_imp.g_varchar2_table(549) := 'ata (ID,SAMPLE_ID,RESPONSE) values (326,1,9.47);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMP';
wwv_flow_imp.g_varchar2_table(550) := 'LE_ID,RESPONSE) values (327,2,9.81);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPON';
wwv_flow_imp.g_varchar2_table(551) := 'SE) values (328,3,16.31);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values ';
wwv_flow_imp.g_varchar2_table(552) := '(329,4,9.81);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (330,5,16.31';
wwv_flow_imp.g_varchar2_table(553) := ');'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (331,1,9.03);'||wwv_flow.LF||
'    inser';
wwv_flow_imp.g_varchar2_table(554) := 't into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (332,2,8.95);'||wwv_flow.LF||
'    insert into eba_d';
wwv_flow_imp.g_varchar2_table(555) := 'emo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (333,3,4.02);'||wwv_flow.LF||
'    insert into eba_demo_chart_sa';
wwv_flow_imp.g_varchar2_table(556) := 'mple_data (ID,SAMPLE_ID,RESPONSE) values (334,4,8.95);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (I';
wwv_flow_imp.g_varchar2_table(557) := 'D,SAMPLE_ID,RESPONSE) values (335,5,4.02);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,';
wwv_flow_imp.g_varchar2_table(558) := 'RESPONSE) values (336,1,9.44);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) va';
wwv_flow_imp.g_varchar2_table(559) := 'lues (337,2,12.79);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (338,3';
wwv_flow_imp.g_varchar2_table(560) := ',8.4);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (339,4,12.79);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(561) := 'insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (340,5,8.4);'||wwv_flow.LF||
'    insert into e';
wwv_flow_imp.g_varchar2_table(562) := 'ba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (341,1,11.07);'||wwv_flow.LF||
'    insert into eba_demo_cha';
wwv_flow_imp.g_varchar2_table(563) := 'rt_sample_data (ID,SAMPLE_ID,RESPONSE) values (342,2,16.17);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_d';
wwv_flow_imp.g_varchar2_table(564) := 'ata (ID,SAMPLE_ID,RESPONSE) values (343,3,16.42);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAM';
wwv_flow_imp.g_varchar2_table(565) := 'PLE_ID,RESPONSE) values (344,4,16.17);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESP';
wwv_flow_imp.g_varchar2_table(566) := 'ONSE) values (345,5,16.42);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) value';
wwv_flow_imp.g_varchar2_table(567) := 's (346,1,9.11);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (347,2,16.';
wwv_flow_imp.g_varchar2_table(568) := '54);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (348,3,15.81);'||wwv_flow.LF||
'    in';
wwv_flow_imp.g_varchar2_table(569) := 'sert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (349,4,16.54);'||wwv_flow.LF||
'    insert into e';
wwv_flow_imp.g_varchar2_table(570) := 'ba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (350,5,15.81);'||wwv_flow.LF||
'    insert into eba_demo_cha';
wwv_flow_imp.g_varchar2_table(571) := 'rt_sample_data (ID,SAMPLE_ID,RESPONSE) values (351,1,9.23);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_da';
wwv_flow_imp.g_varchar2_table(572) := 'ta (ID,SAMPLE_ID,RESPONSE) values (352,2,12.93);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMP';
wwv_flow_imp.g_varchar2_table(573) := 'LE_ID,RESPONSE) values (353,3,3.76);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPON';
wwv_flow_imp.g_varchar2_table(574) := 'SE) values (354,4,12.93);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values ';
wwv_flow_imp.g_varchar2_table(575) := '(355,5,3.76);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (356,1,9.55)';
wwv_flow_imp.g_varchar2_table(576) := ';'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (357,2,9.23);'||wwv_flow.LF||
'    insert';
wwv_flow_imp.g_varchar2_table(577) := ' into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (358,3,7.17);'||wwv_flow.LF||
'    insert into eba_de';
wwv_flow_imp.g_varchar2_table(578) := 'mo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (359,4,9.23);'||wwv_flow.LF||
'    insert into eba_demo_chart_sam';
wwv_flow_imp.g_varchar2_table(579) := 'ple_data (ID,SAMPLE_ID,RESPONSE) values (360,5,7.17);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID';
wwv_flow_imp.g_varchar2_table(580) := ',SAMPLE_ID,RESPONSE) values (361,1,11.17);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,';
wwv_flow_imp.g_varchar2_table(581) := 'RESPONSE) values (362,2,18.93);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) v';
wwv_flow_imp.g_varchar2_table(582) := 'alues (363,3,12.78);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (364,';
wwv_flow_imp.g_varchar2_table(583) := '4,18.93);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (365,5,12.78);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(584) := '   insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (366,1,9.84);'||wwv_flow.LF||
'    insert in';
wwv_flow_imp.g_varchar2_table(585) := 'to eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (367,2,14.94);'||wwv_flow.LF||
'    insert into eba_demo';
wwv_flow_imp.g_varchar2_table(586) := '_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (368,3,13.57);'||wwv_flow.LF||
'    insert into eba_demo_chart_samp';
wwv_flow_imp.g_varchar2_table(587) := 'le_data (ID,SAMPLE_ID,RESPONSE) values (369,4,14.94);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID';
wwv_flow_imp.g_varchar2_table(588) := ',SAMPLE_ID,RESPONSE) values (370,5,13.57);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,';
wwv_flow_imp.g_varchar2_table(589) := 'RESPONSE) values (371,1,11);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) valu';
wwv_flow_imp.g_varchar2_table(590) := 'es (372,2,0.21);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (373,3,16';
wwv_flow_imp.g_varchar2_table(591) := '.99);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (374,4,0.21);'||wwv_flow.LF||
'    in';
wwv_flow_imp.g_varchar2_table(592) := 'sert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (375,5,16.99);'||wwv_flow.LF||
'    insert into e';
wwv_flow_imp.g_varchar2_table(593) := 'ba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (376,1,10.01);'||wwv_flow.LF||
'    insert into eba_demo_cha';
wwv_flow_imp.g_varchar2_table(594) := 'rt_sample_data (ID,SAMPLE_ID,RESPONSE) values (377,2,12.13);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_d';
wwv_flow_imp.g_varchar2_table(595) := 'ata (ID,SAMPLE_ID,RESPONSE) values (378,3,0.72);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMP';
wwv_flow_imp.g_varchar2_table(596) := 'LE_ID,RESPONSE) values (379,4,12.13);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPO';
wwv_flow_imp.g_varchar2_table(597) := 'NSE) values (380,5,0.72);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values ';
wwv_flow_imp.g_varchar2_table(598) := '(381,1,10.12);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (382,2,16.1';
wwv_flow_imp.g_varchar2_table(599) := '8);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (383,3,5.64);'||wwv_flow.LF||
'    inse';
wwv_flow_imp.g_varchar2_table(600) := 'rt into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (384,4,16.18);'||wwv_flow.LF||
'    insert into eba';
wwv_flow_imp.g_varchar2_table(601) := '_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (385,5,5.64);'||wwv_flow.LF||
'    insert into eba_demo_chart_';
wwv_flow_imp.g_varchar2_table(602) := 'sample_data (ID,SAMPLE_ID,RESPONSE) values (386,1,9.24);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data ';
wwv_flow_imp.g_varchar2_table(603) := '(ID,SAMPLE_ID,RESPONSE) values (387,2,12.78);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_';
wwv_flow_imp.g_varchar2_table(604) := 'ID,RESPONSE) values (388,3,16.16);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE';
wwv_flow_imp.g_varchar2_table(605) := ') values (389,4,12.78);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (3';
wwv_flow_imp.g_varchar2_table(606) := '90,5,16.16);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (391,1,11.32)';
wwv_flow_imp.g_varchar2_table(607) := ';'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (392,2,12.29);'||wwv_flow.LF||
'    inser';
wwv_flow_imp.g_varchar2_table(608) := 't into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (393,3,9.98);'||wwv_flow.LF||
'    insert into eba_d';
wwv_flow_imp.g_varchar2_table(609) := 'emo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (394,4,12.29);'||wwv_flow.LF||
'    insert into eba_demo_chart_s';
wwv_flow_imp.g_varchar2_table(610) := 'ample_data (ID,SAMPLE_ID,RESPONSE) values (395,5,9.98);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (';
wwv_flow_imp.g_varchar2_table(611) := 'ID,SAMPLE_ID,RESPONSE) values (396,1,9.55);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID';
wwv_flow_imp.g_varchar2_table(612) := ',RESPONSE) values (397,2,10.85);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) ';
wwv_flow_imp.g_varchar2_table(613) := 'values (398,3,-1.45);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (399';
wwv_flow_imp.g_varchar2_table(614) := ',4,10.85);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (400,5,-1.45);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(615) := '    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (401,1,10.37);'||wwv_flow.LF||
'    insert ';
wwv_flow_imp.g_varchar2_table(616) := 'into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (402,2,16.72);'||wwv_flow.LF||
'    insert into eba_de';
wwv_flow_imp.g_varchar2_table(617) := 'mo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (403,4,16.72);'||wwv_flow.LF||
'    insert into eba_demo_chart_sa';
wwv_flow_imp.g_varchar2_table(618) := 'mple_data (ID,SAMPLE_ID,RESPONSE) values (404,5,13.97);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (';
wwv_flow_imp.g_varchar2_table(619) := 'ID,SAMPLE_ID,RESPONSE) values (405,1,9.49);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID';
wwv_flow_imp.g_varchar2_table(620) := ',RESPONSE) values (406,2,13.36);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) ';
wwv_flow_imp.g_varchar2_table(621) := 'values (407,4,13.36);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (408';
wwv_flow_imp.g_varchar2_table(622) := ',5,13.37);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (409,1,8.99);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(623) := '   insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (410,2,6.99);'||wwv_flow.LF||
'    insert in';
wwv_flow_imp.g_varchar2_table(624) := 'to eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (411,4,6.99);'||wwv_flow.LF||
'    insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(625) := 'chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (412,5,3.39);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample';
wwv_flow_imp.g_varchar2_table(626) := '_data (ID,SAMPLE_ID,RESPONSE) values (413,1,9.66);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SA';
wwv_flow_imp.g_varchar2_table(627) := 'MPLE_ID,RESPONSE) values (414,2,15.18);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RES';
wwv_flow_imp.g_varchar2_table(628) := 'PONSE) values (415,4,15.18);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) valu';
wwv_flow_imp.g_varchar2_table(629) := 'es (416,5,9.12);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (417,1,10';
wwv_flow_imp.g_varchar2_table(630) := '.78);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (418,2,10.86);'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(631) := 'nsert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (419,4,10.86);'||wwv_flow.LF||
'    insert into ';
wwv_flow_imp.g_varchar2_table(632) := 'eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (420,5,-2.9);'||wwv_flow.LF||
'    insert into eba_demo_cha';
wwv_flow_imp.g_varchar2_table(633) := 'rt_sample_data (ID,SAMPLE_ID,RESPONSE) values (421,1,11.31);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_d';
wwv_flow_imp.g_varchar2_table(634) := 'ata (ID,SAMPLE_ID,RESPONSE) values (422,2,13.78);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAM';
wwv_flow_imp.g_varchar2_table(635) := 'PLE_ID,RESPONSE) values (423,4,13.78);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESP';
wwv_flow_imp.g_varchar2_table(636) := 'ONSE) values (424,5,10.52);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) value';
wwv_flow_imp.g_varchar2_table(637) := 's (425,1,9.71);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (426,2,8.3';
wwv_flow_imp.g_varchar2_table(638) := '1);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (427,4,8.31);'||wwv_flow.LF||
'    inse';
wwv_flow_imp.g_varchar2_table(639) := 'rt into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (428,5,15.04);'||wwv_flow.LF||
'    insert into eba';
wwv_flow_imp.g_varchar2_table(640) := '_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (429,1,9.86);'||wwv_flow.LF||
'    insert into eba_demo_chart_';
wwv_flow_imp.g_varchar2_table(641) := 'sample_data (ID,SAMPLE_ID,RESPONSE) values (430,2,6.82);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data ';
wwv_flow_imp.g_varchar2_table(642) := '(ID,SAMPLE_ID,RESPONSE) values (431,4,6.82);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_I';
wwv_flow_imp.g_varchar2_table(643) := 'D,RESPONSE) values (432,5,7.24);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) ';
wwv_flow_imp.g_varchar2_table(644) := 'values (433,1,10.42);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (434';
wwv_flow_imp.g_varchar2_table(645) := ',2,6.75);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (435,4,6.75);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(646) := '  insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (436,5,13.87);'||wwv_flow.LF||
'    insert in';
wwv_flow_imp.g_varchar2_table(647) := 'to eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (437,1,9.57);'||wwv_flow.LF||
'    insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(648) := 'chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (438,2,10.13);'||wwv_flow.LF||
'    insert into eba_demo_chart_sampl';
wwv_flow_imp.g_varchar2_table(649) := 'e_data (ID,SAMPLE_ID,RESPONSE) values (439,4,10.13);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,';
wwv_flow_imp.g_varchar2_table(650) := 'SAMPLE_ID,RESPONSE) values (440,5,11.42);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,R';
wwv_flow_imp.g_varchar2_table(651) := 'ESPONSE) values (441,1,8.92);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) val';
wwv_flow_imp.g_varchar2_table(652) := 'ues (442,2,17.08);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (443,4,';
wwv_flow_imp.g_varchar2_table(653) := '17.08);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (444,5,12.79);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(654) := ' insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (445,1,10.8);'||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(655) := ' eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (446,2,14.56);'||wwv_flow.LF||
'    insert into eba_demo_c';
wwv_flow_imp.g_varchar2_table(656) := 'hart_sample_data (ID,SAMPLE_ID,RESPONSE) values (447,4,14.56);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample';
wwv_flow_imp.g_varchar2_table(657) := '_data (ID,SAMPLE_ID,RESPONSE) values (448,5,17.91);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,S';
wwv_flow_imp.g_varchar2_table(658) := 'AMPLE_ID,RESPONSE) values (449,1,10.31);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RE';
wwv_flow_imp.g_varchar2_table(659) := 'SPONSE) values (450,2,18.52);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) val';
wwv_flow_imp.g_varchar2_table(660) := 'ues (451,4,18.52);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (452,5,';
wwv_flow_imp.g_varchar2_table(661) := '12.5);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (453,1,8.64);'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(662) := 'nsert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (454,2,11.66);'||wwv_flow.LF||
'    insert into ';
wwv_flow_imp.g_varchar2_table(663) := 'eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (455,4,11.66);'||wwv_flow.LF||
'    insert into eba_demo_ch';
wwv_flow_imp.g_varchar2_table(664) := 'art_sample_data (ID,SAMPLE_ID,RESPONSE) values (456,5,7.41);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_d';
wwv_flow_imp.g_varchar2_table(665) := 'ata (ID,SAMPLE_ID,RESPONSE) values (457,1,11.06);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAM';
wwv_flow_imp.g_varchar2_table(666) := 'PLE_ID,RESPONSE) values (458,2,18.01);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESP';
wwv_flow_imp.g_varchar2_table(667) := 'ONSE) values (459,4,18.01);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) value';
wwv_flow_imp.g_varchar2_table(668) := 's (460,5,21.19);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (461,1,8.';
wwv_flow_imp.g_varchar2_table(669) := '65);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (462,2,13.39);'||wwv_flow.LF||
'    in';
wwv_flow_imp.g_varchar2_table(670) := 'sert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (463,4,13.39);'||wwv_flow.LF||
'    insert into e';
wwv_flow_imp.g_varchar2_table(671) := 'ba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (464,5,9.69);'||wwv_flow.LF||
'    insert into eba_demo_char';
wwv_flow_imp.g_varchar2_table(672) := 't_sample_data (ID,SAMPLE_ID,RESPONSE) values (465,1,10.5);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_dat';
wwv_flow_imp.g_varchar2_table(673) := 'a (ID,SAMPLE_ID,RESPONSE) values (466,2,14.9);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE';
wwv_flow_imp.g_varchar2_table(674) := '_ID,RESPONSE) values (467,4,14.9);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE';
wwv_flow_imp.g_varchar2_table(675) := ') values (468,5,6.79);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (46';
wwv_flow_imp.g_varchar2_table(676) := '9,1,8.3);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (470,2,20.97);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(677) := '   insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (471,4,20.97);'||wwv_flow.LF||
'    insert i';
wwv_flow_imp.g_varchar2_table(678) := 'nto eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (472,5,15.16);'||wwv_flow.LF||
'    insert into eba_dem';
wwv_flow_imp.g_varchar2_table(679) := 'o_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (473,1,7.87);'||wwv_flow.LF||
'    insert into eba_demo_chart_samp';
wwv_flow_imp.g_varchar2_table(680) := 'le_data (ID,SAMPLE_ID,RESPONSE) values (474,2,11);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SA';
wwv_flow_imp.g_varchar2_table(681) := 'MPLE_ID,RESPONSE) values (475,4,11);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPON';
wwv_flow_imp.g_varchar2_table(682) := 'SE) values (476,5,3.19);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (';
wwv_flow_imp.g_varchar2_table(683) := '477,1,9.5);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (478,2,3.85);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(684) := '    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (479,4,3.85);'||wwv_flow.LF||
'    insert i';
wwv_flow_imp.g_varchar2_table(685) := 'nto eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (480,5,15.05);'||wwv_flow.LF||
'    insert into eba_dem';
wwv_flow_imp.g_varchar2_table(686) := 'o_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (481,1,9.54);'||wwv_flow.LF||
'    insert into eba_demo_chart_samp';
wwv_flow_imp.g_varchar2_table(687) := 'le_data (ID,SAMPLE_ID,RESPONSE) values (482,2,4.18);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,';
wwv_flow_imp.g_varchar2_table(688) := 'SAMPLE_ID,RESPONSE) values (483,4,4.18);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RE';
wwv_flow_imp.g_varchar2_table(689) := 'SPONSE) values (484,5,13.83);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) val';
wwv_flow_imp.g_varchar2_table(690) := 'ues (485,1,11.24);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (486,2,';
wwv_flow_imp.g_varchar2_table(691) := '15.34);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (487,4,15.34);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(692) := ' insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (488,5,7.2);'||wwv_flow.LF||
'    insert into ';
wwv_flow_imp.g_varchar2_table(693) := 'eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (489,1,8.96);'||wwv_flow.LF||
'    insert into eba_demo_cha';
wwv_flow_imp.g_varchar2_table(694) := 'rt_sample_data (ID,SAMPLE_ID,RESPONSE) values (490,2,12.6);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_da';
wwv_flow_imp.g_varchar2_table(695) := 'ta (ID,SAMPLE_ID,RESPONSE) values (491,4,12.6);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPL';
wwv_flow_imp.g_varchar2_table(696) := 'E_ID,RESPONSE) values (492,5,7);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) ';
wwv_flow_imp.g_varchar2_table(697) := 'values (493,1,9.5);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (494,2';
wwv_flow_imp.g_varchar2_table(698) := ',18.48);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (495,4,18.48);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(699) := '  insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (496,5,8);'||wwv_flow.LF||
'    insert into e';
wwv_flow_imp.g_varchar2_table(700) := 'ba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (497,1,9.51);'||wwv_flow.LF||
'    insert into eba_demo_char';
wwv_flow_imp.g_varchar2_table(701) := 't_sample_data (ID,SAMPLE_ID,RESPONSE) values (498,2,17.22);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_da';
wwv_flow_imp.g_varchar2_table(702) := 'ta (ID,SAMPLE_ID,RESPONSE) values (499,4,17.22);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMP';
wwv_flow_imp.g_varchar2_table(703) := 'LE_ID,RESPONSE) values (500,5,9);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE)';
wwv_flow_imp.g_varchar2_table(704) := ' values (501,1,9.29);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (502';
wwv_flow_imp.g_varchar2_table(705) := ',2,15.53);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (503,4,15.53);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(706) := '    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (504,1,9.63);'||wwv_flow.LF||
'    insert i';
wwv_flow_imp.g_varchar2_table(707) := 'nto eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (505,2,10.44);'||wwv_flow.LF||
'    insert into eba_dem';
wwv_flow_imp.g_varchar2_table(708) := 'o_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (506,4,10.44);'||wwv_flow.LF||
'    insert into eba_demo_chart_sam';
wwv_flow_imp.g_varchar2_table(709) := 'ple_data (ID,SAMPLE_ID,RESPONSE) values (507,1,9.09);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID';
wwv_flow_imp.g_varchar2_table(710) := ',SAMPLE_ID,RESPONSE) values (508,2,10.31);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,';
wwv_flow_imp.g_varchar2_table(711) := 'RESPONSE) values (509,4,10.31);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) v';
wwv_flow_imp.g_varchar2_table(712) := 'alues (510,1,10.36);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (511,';
wwv_flow_imp.g_varchar2_table(713) := '2,5.24);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (512,4,5.24);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(714) := ' insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (513,1,9.21);'||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(715) := ' eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (514,2,18.02);'||wwv_flow.LF||
'    insert into eba_demo_c';
wwv_flow_imp.g_varchar2_table(716) := 'hart_sample_data (ID,SAMPLE_ID,RESPONSE) values (515,4,18.02);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample';
wwv_flow_imp.g_varchar2_table(717) := '_data (ID,SAMPLE_ID,RESPONSE) values (516,1,10.46);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,S';
wwv_flow_imp.g_varchar2_table(718) := 'AMPLE_ID,RESPONSE) values (517,2,6.82);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RES';
wwv_flow_imp.g_varchar2_table(719) := 'PONSE) values (518,4,6.82);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) value';
wwv_flow_imp.g_varchar2_table(720) := 's (519,1,9.09);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (520,2,9.0';
wwv_flow_imp.g_varchar2_table(721) := '7);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (521,4,9.07);'||wwv_flow.LF||
'    inse';
wwv_flow_imp.g_varchar2_table(722) := 'rt into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (522,1,9.68);'||wwv_flow.LF||
'    insert into eba_';
wwv_flow_imp.g_varchar2_table(723) := 'demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (523,2,12.86);'||wwv_flow.LF||
'    insert into eba_demo_chart_';
wwv_flow_imp.g_varchar2_table(724) := 'sample_data (ID,SAMPLE_ID,RESPONSE) values (524,4,12.86);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data';
wwv_flow_imp.g_varchar2_table(725) := ' (ID,SAMPLE_ID,RESPONSE) values (525,1,10.51);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE';
wwv_flow_imp.g_varchar2_table(726) := '_ID,RESPONSE) values (526,2,10.73);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONS';
wwv_flow_imp.g_varchar2_table(727) := 'E) values (527,4,10.73);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (';
wwv_flow_imp.g_varchar2_table(728) := '528,1,10.78);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (529,2,17.69';
wwv_flow_imp.g_varchar2_table(729) := ');'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (530,4,17.69);'||wwv_flow.LF||
'    inse';
wwv_flow_imp.g_varchar2_table(730) := 'rt into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (531,1,10.27);'||wwv_flow.LF||
'    insert into eba';
wwv_flow_imp.g_varchar2_table(731) := '_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (532,2,12.12);'||wwv_flow.LF||
'    insert into eba_demo_chart';
wwv_flow_imp.g_varchar2_table(732) := '_sample_data (ID,SAMPLE_ID,RESPONSE) values (533,4,12.12);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_dat';
wwv_flow_imp.g_varchar2_table(733) := 'a (ID,SAMPLE_ID,RESPONSE) values (534,1,10.61);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPL';
wwv_flow_imp.g_varchar2_table(734) := 'E_ID,RESPONSE) values (535,2,12.21);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPON';
wwv_flow_imp.g_varchar2_table(735) := 'SE) values (536,4,12.21);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values ';
wwv_flow_imp.g_varchar2_table(736) := '(537,1,9.59);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (538,2,5.66)';
wwv_flow_imp.g_varchar2_table(737) := ';'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (539,4,5.66);'||wwv_flow.LF||
'    insert';
wwv_flow_imp.g_varchar2_table(738) := ' into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (540,1,9.61);'||wwv_flow.LF||
'    insert into eba_de';
wwv_flow_imp.g_varchar2_table(739) := 'mo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (541,2,9.3);'||wwv_flow.LF||
'    insert into eba_demo_chart_samp';
wwv_flow_imp.g_varchar2_table(740) := 'le_data (ID,SAMPLE_ID,RESPONSE) values (542,4,9.3);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,S';
wwv_flow_imp.g_varchar2_table(741) := 'AMPLE_ID,RESPONSE) values (543,1,10.6);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RES';
wwv_flow_imp.g_varchar2_table(742) := 'PONSE) values (544,2,13.49);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) valu';
wwv_flow_imp.g_varchar2_table(743) := 'es (545,4,13.49);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (546,1,1';
wwv_flow_imp.g_varchar2_table(744) := '0.2);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (547,2,13.67);'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(745) := 'nsert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (548,4,13.67);'||wwv_flow.LF||
'    insert into ';
wwv_flow_imp.g_varchar2_table(746) := 'eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (549,1,9.31);'||wwv_flow.LF||
'    insert into eba_demo_cha';
wwv_flow_imp.g_varchar2_table(747) := 'rt_sample_data (ID,SAMPLE_ID,RESPONSE) values (550,2,9.06);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_da';
wwv_flow_imp.g_varchar2_table(748) := 'ta (ID,SAMPLE_ID,RESPONSE) values (551,4,9.06);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPL';
wwv_flow_imp.g_varchar2_table(749) := 'E_ID,RESPONSE) values (552,1,8.47);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONS';
wwv_flow_imp.g_varchar2_table(750) := 'E) values (553,2,16.6);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (5';
wwv_flow_imp.g_varchar2_table(751) := '54,4,16.6);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (555,1,10.71);';
wwv_flow_imp.g_varchar2_table(752) := ''||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (556,2,14.83);'||wwv_flow.LF||
'    insert';
wwv_flow_imp.g_varchar2_table(753) := ' into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (557,4,14.83);'||wwv_flow.LF||
'    insert into eba_d';
wwv_flow_imp.g_varchar2_table(754) := 'emo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (558,1,7.98);'||wwv_flow.LF||
'    insert into eba_demo_chart_sa';
wwv_flow_imp.g_varchar2_table(755) := 'mple_data (ID,SAMPLE_ID,RESPONSE) values (559,2,12.6);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (I';
wwv_flow_imp.g_varchar2_table(756) := 'D,SAMPLE_ID,RESPONSE) values (560,4,12.6);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,';
wwv_flow_imp.g_varchar2_table(757) := 'RESPONSE) values (561,1,11.25);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) v';
wwv_flow_imp.g_varchar2_table(758) := 'alues (562,2,15.25);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (563,';
wwv_flow_imp.g_varchar2_table(759) := '4,15.25);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (564,1,8.19);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(760) := '  insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (565,2,9.22);'||wwv_flow.LF||
'    insert int';
wwv_flow_imp.g_varchar2_table(761) := 'o eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (566,4,9.22);'||wwv_flow.LF||
'    insert into eba_demo_c';
wwv_flow_imp.g_varchar2_table(762) := 'hart_sample_data (ID,SAMPLE_ID,RESPONSE) values (567,1,9.97);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_';
wwv_flow_imp.g_varchar2_table(763) := 'data (ID,SAMPLE_ID,RESPONSE) values (568,2,12.11);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SA';
wwv_flow_imp.g_varchar2_table(764) := 'MPLE_ID,RESPONSE) values (569,4,12.11);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RES';
wwv_flow_imp.g_varchar2_table(765) := 'PONSE) values (570,1,9.86);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) value';
wwv_flow_imp.g_varchar2_table(766) := 's (571,2,7.43);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (572,4,7.4';
wwv_flow_imp.g_varchar2_table(767) := '3);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (573,1,12.07);'||wwv_flow.LF||
'    ins';
wwv_flow_imp.g_varchar2_table(768) := 'ert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (574,2,12.19);'||wwv_flow.LF||
'    insert into eb';
wwv_flow_imp.g_varchar2_table(769) := 'a_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (575,4,12.19);'||wwv_flow.LF||
'    insert into eba_demo_char';
wwv_flow_imp.g_varchar2_table(770) := 't_sample_data (ID,SAMPLE_ID,RESPONSE) values (576,1,11.09);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_da';
wwv_flow_imp.g_varchar2_table(771) := 'ta (ID,SAMPLE_ID,RESPONSE) values (577,2,16.49);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMP';
wwv_flow_imp.g_varchar2_table(772) := 'LE_ID,RESPONSE) values (578,4,16.49);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPO';
wwv_flow_imp.g_varchar2_table(773) := 'NSE) values (579,1,10.53);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values';
wwv_flow_imp.g_varchar2_table(774) := ' (580,2,9.41);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (581,4,9.41';
wwv_flow_imp.g_varchar2_table(775) := ');'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (582,1,9.74);'||wwv_flow.LF||
'    inser';
wwv_flow_imp.g_varchar2_table(776) := 't into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (583,2,10.49);'||wwv_flow.LF||
'    insert into eba_';
wwv_flow_imp.g_varchar2_table(777) := 'demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (584,4,10.49);'||wwv_flow.LF||
'    insert into eba_demo_chart_';
wwv_flow_imp.g_varchar2_table(778) := 'sample_data (ID,SAMPLE_ID,RESPONSE) values (585,1,10.92);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data';
wwv_flow_imp.g_varchar2_table(779) := ' (ID,SAMPLE_ID,RESPONSE) values (586,2,18.6);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_';
wwv_flow_imp.g_varchar2_table(780) := 'ID,RESPONSE) values (587,4,18.6);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE)';
wwv_flow_imp.g_varchar2_table(781) := ' values (588,1,8.65);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (589';
wwv_flow_imp.g_varchar2_table(782) := ',2,16.65);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (590,4,16.65);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(783) := '    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (591,1,9.31);'||wwv_flow.LF||
'    insert i';
wwv_flow_imp.g_varchar2_table(784) := 'nto eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (592,2,11.17);'||wwv_flow.LF||
'    insert into eba_dem';
wwv_flow_imp.g_varchar2_table(785) := 'o_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (593,4,11.17);'||wwv_flow.LF||
'    insert into eba_demo_chart_sam';
wwv_flow_imp.g_varchar2_table(786) := 'ple_data (ID,SAMPLE_ID,RESPONSE) values (594,1,11.2);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID';
wwv_flow_imp.g_varchar2_table(787) := ',SAMPLE_ID,RESPONSE) values (595,2,14.49);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,';
wwv_flow_imp.g_varchar2_table(788) := 'RESPONSE) values (596,4,14.49);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) v';
wwv_flow_imp.g_varchar2_table(789) := 'alues (597,1,8.6);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (598,2,';
wwv_flow_imp.g_varchar2_table(790) := '16.34);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (599,4,16.34);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(791) := ' insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (600,1,12.55);'||wwv_flow.LF||
'    insert int';
wwv_flow_imp.g_varchar2_table(792) := 'o eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (601,2,10.31);'||wwv_flow.LF||
'    insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(793) := 'chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (602,4,10.31);'||wwv_flow.LF||
'    insert into eba_demo_chart_sampl';
wwv_flow_imp.g_varchar2_table(794) := 'e_data (ID,SAMPLE_ID,RESPONSE) values (603,1,11.95);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,';
wwv_flow_imp.g_varchar2_table(795) := 'SAMPLE_ID,RESPONSE) values (604,2,11.37);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,R';
wwv_flow_imp.g_varchar2_table(796) := 'ESPONSE) values (605,4,11.37);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) va';
wwv_flow_imp.g_varchar2_table(797) := 'lues (606,1,10.9);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (607,1,';
wwv_flow_imp.g_varchar2_table(798) := '10.97);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (608,1,9.26);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(799) := 'insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (609,1,10.32);'||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(800) := ' eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (610,1,8.74);'||wwv_flow.LF||
'    insert into eba_demo_ch';
wwv_flow_imp.g_varchar2_table(801) := 'art_sample_data (ID,SAMPLE_ID,RESPONSE) values (611,1,11.06);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_';
wwv_flow_imp.g_varchar2_table(802) := 'data (ID,SAMPLE_ID,RESPONSE) values (612,1,8.99);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAM';
wwv_flow_imp.g_varchar2_table(803) := 'PLE_ID,RESPONSE) values (613,1,9.74);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPO';
wwv_flow_imp.g_varchar2_table(804) := 'NSE) values (614,1,9.59);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values ';
wwv_flow_imp.g_varchar2_table(805) := '(615,1,10.55);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (616,1,10.9';
wwv_flow_imp.g_varchar2_table(806) := '5);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (617,1,10.8);'||wwv_flow.LF||
'    inse';
wwv_flow_imp.g_varchar2_table(807) := 'rt into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (618,1,9.69);'||wwv_flow.LF||
'    insert into eba_';
wwv_flow_imp.g_varchar2_table(808) := 'demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (619,1,11.75);'||wwv_flow.LF||
'    insert into eba_demo_chart_';
wwv_flow_imp.g_varchar2_table(809) := 'sample_data (ID,SAMPLE_ID,RESPONSE) values (620,1,10);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (I';
wwv_flow_imp.g_varchar2_table(810) := 'D,SAMPLE_ID,RESPONSE) values (621,1,9.14);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,';
wwv_flow_imp.g_varchar2_table(811) := 'RESPONSE) values (622,1,10.06);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) v';
wwv_flow_imp.g_varchar2_table(812) := 'alues (623,1,9.69);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (624,1';
wwv_flow_imp.g_varchar2_table(813) := ',10.11);'||wwv_flow.LF||
'    insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (625,1,11.15);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(814) := '  insert into eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (626,1,10.73);'||wwv_flow.LF||
'    insert in';
wwv_flow_imp.g_varchar2_table(815) := 'to eba_demo_chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (627,1,10.6);'||wwv_flow.LF||
'    insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(816) := 'chart_sample_data (ID,SAMPLE_ID,RESPONSE) values (628,1,10.33);'||wwv_flow.LF||
'    insert into eba_demo_chart_sampl';
wwv_flow_imp.g_varchar2_table(817) := 'e_data (ID,SAMPLE_ID,RESPONSE) values (629,1,9.63);    '||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'eba_demo_chart_da';
wwv_flow_imp.g_varchar2_table(818) := 'ta;'||wwv_flow.LF||
'commit;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2579539176445300363)
,p_install_id=>wwv_flow_imp.id(2579186863174088443)
,p_name=>'Sample Data'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
