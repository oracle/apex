prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7830
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>2654143468017583
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2581472186103400822)
,p_name=>'HELP'
,p_message_text=>'Help'
,p_version_scn=>'37166093873590'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2581510860261402788)
,p_name=>'LOGOUT'
,p_message_text=>'Logout'
,p_version_scn=>'37166093873590'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2673835561118635336)
,p_name=>'USER'
,p_message_text=>'User'
,p_version_scn=>'37166093873590'
);
wwv_flow_imp.component_end;
end;
/
