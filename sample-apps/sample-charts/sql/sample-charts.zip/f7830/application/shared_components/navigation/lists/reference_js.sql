prompt --application/shared_components/navigation/lists/reference_js
begin
--   Manifest
--     LIST: Reference - JS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>2654143468017583
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3665579497986240048)
,p_name=>'Reference - JS'
,p_static_id=>'reference-js'
,p_version_scn=>'1089078564'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3956875644857849330)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'3D Effect'
,p_static_id=>'3d-effect'
,p_list_item_link_target=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cube'
,p_list_text_01=>'See a list of chart examples demonstrating how to apply the 3D effect on your chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(402727852106049140)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Chart Links'
,p_static_id=>'chart-links'
,p_list_item_link_target=>'f?p=&APP_ID.:49:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-link'
,p_list_text_01=>'See a list of chart examples demonstrating how to link from chart to reports and charts'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3668355860132433779)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Customizing Data Labels'
,p_static_id=>'customizing-data-labels'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-text-height'
,p_list_text_01=>'See a list of the chart examples demonstrating how to declaratively style chart data labels using CSS, or customize the labels using JavaScript'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1006021751583463869)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Customizing Tooltip Labels'
,p_static_id=>'customizing-tooltip-labels'
,p_list_item_link_target=>'f?p=&APP_ID.:48:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-alert'
,p_list_text_01=>'See a list of the chart examples demonstrating how to customise the labels displayed in a tooltip, both declaratively and via JavaScript customization'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4013932868219445786)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Data Densification'
,p_static_id=>'data-densification'
,p_list_item_link_target=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plus'
,p_list_text_01=>'See a list of chart examples demonstrating how a multi-series chart with differing series lengths, use new data densification handling to render the data points correctly on your chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3665582732493282528)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Datetime x-axis'
,p_static_id=>'datetime-x-axis'
,p_list_item_link_target=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'See a list of the chart examples demonstrating the use of the Time Axis Type attribute, to render DATETIME information on the x-axis of a chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3665580061654240054)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Dynamic Actions'
,p_static_id=>'dynamic-actions'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bolt'
,p_list_text_01=>'See a list of the chart examples demonstrating the use of Dynamic Actions'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(190519088323840671)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Font Formatting'
,p_static_id=>'font-formatting'
,p_list_item_link_target=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-text-height'
,p_list_text_01=>'See a list of examples demonstrating the declarative styling of text rendered on a chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3668395472741563999)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Formatting Values'
,p_static_id=>'formatting-values'
,p_list_item_link_target=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-eur'
,p_list_text_01=>'See a list of chart examples demonstrating how to format the values on your chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3665579714938240050)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'JavaScript Code Customizations'
,p_static_id=>'javascript-code-customizations'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_list_text_01=>'See a list of the chart examples demonstrating the use of JavaScript Code to customize the chart at initialization'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3665582263427276322)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'JET Plug-in Component'
,p_static_id=>'jet-plug-in-component'
,p_list_item_link_target=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plug'
,p_list_text_01=>'See a list of the chart examples demonstrating the use of an APEX plug-in, to incorporate other Oracle JET components in your application'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3665580819902240054)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Series Color'
,p_static_id=>'series-color'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-paint-brush'
,p_list_text_01=>'See a list of the chart examples demonstrating how to set the color of chart series'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(554739278200116458)
,p_list_item_display_sequence=>12
,p_list_item_link_text=>'Sorting'
,p_static_id=>'sorting'
,p_list_item_link_target=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-sort-alpha-asc'
,p_list_text_01=>'See a list of chart examples demonstrating how to sort chart values and labels, using the new <strong>Fill Gaps in Chart Data</strong> and <strong>Sort Order</strong> chart-level attributes.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(190483189622577074)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Stack Grouping'
,p_static_id=>'stack-grouping'
,p_list_item_link_target=>'f?p=&APP_ID.:44:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-line-area-chart'
,p_list_text_01=>'See a list of examples demonstrating the declarative grouping and labeling of stacked charts.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(255853183631316440)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Style Chart Title'
,p_static_id=>'style-chart-title'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-font-size'
,p_list_text_01=>'See chart examples demonstrating the use of JavaScript Code to customize the chart title at initialization'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3665580500778240054)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Y2 Axis'
,p_static_id=>'y2-axis'
,p_list_item_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-y2-axis'
,p_list_text_01=>'See a list of the chart examples demonstrating the use of an extra, y2 axis'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3665583322832293359)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Zoom & Scroll'
,p_static_id=>'zoom-scroll'
,p_list_item_link_target=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search-plus'
,p_list_text_01=>'See a list of the chart examples demonstrating the use of Zoom and Scroll, making it easier to view charts rendering large volumes of data'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
