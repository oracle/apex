prompt --application/shared_components/navigation/lists/series_color
begin
--   Manifest
--     LIST: Series Color
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>2654143468017583
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3665985903059646611)
,p_name=>'Series Color'
,p_static_id=>'series-color'
,p_version_scn=>'1089078564'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3665986433330646615)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Bar Chart (Series Colors) - Page 9'
,p_static_id=>'bar-chart-series-colors-page'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bar-chart'
,p_list_text_01=>'This example demonstrates the various options available to define a color on a chart series'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1005998714029216280)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Pie Chart (Series Colors) - Page 4'
,p_static_id=>'pie-chart-series-colors-page'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pie-chart'
,p_list_text_01=>'This example demonstrates the various options available to define a color on a chart series'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
