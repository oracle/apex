prompt --application/shared_components/navigation/lists/y2_axis
begin
--   Manifest
--     LIST: Y2 Axis
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>2654143468017583
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3665995520776704875)
,p_name=>'Y2 Axis'
,p_static_id=>'y2-axis'
,p_version_scn=>'1089078564'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3665995648576704875)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Bar Chart (Dual Y Axis with custom Labels) - Page 9'
,p_static_id=>'bar-chart-dual-y-axis-with-custom-labels-page'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bar-chart'
,p_list_text_01=>'This example demonstrates a Bar Chart with a y2 Axis, and dual-axis setting'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3665996450249728648)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Line with Area Chart (Data Labels & Line Styles) - Page 18'
,p_static_id=>'line-with-area-chart-data-labels-line-styles-page'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-line-area-chart'
,p_list_text_01=>'This example demonstrates a Line with Area Chart with a y2 Axis'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
