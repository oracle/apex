prompt --application/shared_components/navigation/navigation_bar
begin
--   Manifest
--     ICON BAR ITEMS: 7830
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>2654143468017583
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_icon_bar_item(
 p_id=>wwv_flow_imp.id(3212998661769337453)
,p_icon_sequence=>10
,p_icon_image=>'fa-question-circle'
,p_icon_subtext=>'Help'
,p_static_id=>'help'
,p_icon_target=>'f?p=&APP_ID.:help:&SESSION.::&DEBUG.::::'
,p_icon_image_alt=>'fa-question'
,p_nav_entry_is_feedback_yn=>'N'
,p_begins_on_new_line=>'NO'
,p_cell_colspan=>1
);
wwv_flow_imp_shared.create_icon_bar_item(
 p_id=>wwv_flow_imp.id(8206960025390704331)
,p_icon_sequence=>20
,p_icon_subtext=>'Logout'
,p_static_id=>'logout'
,p_icon_target=>'&LOGOUT_URL.'
,p_icon_height=>32
,p_icon_width=>32
,p_nav_entry_is_feedback_yn=>'N'
,p_begins_on_new_line=>'NO'
,p_cell_colspan=>1
);
wwv_flow_imp.component_end;
end;
/
