prompt --application/shared_components/navigation/lists/stack_grouping
begin
--   Manifest
--     LIST: Stack Grouping
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7830
,p_default_id_offset=>2654143468017583
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(190483713318588156)
,p_name=>'Stack Grouping'
,p_static_id=>'stack-grouping'
,p_version_scn=>'1089078564'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(190483900971588156)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Bar Chart (Stack Label & Stack Category) - Page 9'
,p_static_id=>'bar-chart-stack-label-stack-category-page'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dial-gauge-chart'
,p_list_text_01=>'This example demonstrates the new Stack Category and Stack Label attributes on a Bar chart, to render multiple stacks on a given chart and display the stack total value as a label above each stack.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
