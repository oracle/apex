prompt --application/deployment/install/install_emp_and_dept_tables
begin
--   Manifest
--     INSTALL: INSTALL-EMP and DEPT tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>1566231327207194
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_demo_ir_dept ('||wwv_flow.LF||
'    deptno  NUMBER(2) not null'||wwv_flow.LF||
'                        constraint eb';
wwv_flow_imp.g_varchar2_table(2) := 'a_demo_ir_dept_pk'||wwv_flow.LF||
'                        primary key,'||wwv_flow.LF||
'    dname   VARCHAR2(14),'||wwv_flow.LF||
'    loc     VARCHAR';
wwv_flow_imp.g_varchar2_table(3) := '2(13)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_ir_emp ('||wwv_flow.LF||
'    empno     NUMBER(4) not null'||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(4) := ' constraint eba_demo_ir_emp_pk'||wwv_flow.LF||
'                          primary key,'||wwv_flow.LF||
'    ename     VARCHAR2(10),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(5) := '  job       VARCHAR2(9),'||wwv_flow.LF||
'    mgr       NUMBER(4),'||wwv_flow.LF||
'    hiredate  DATE,'||wwv_flow.LF||
'    sal       NUMBER(7),'||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(6) := 'omm      NUMBER(7),'||wwv_flow.LF||
'    deptno    NUMBER(2)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_ir_emp add foreign key (MGR) r';
wwv_flow_imp.g_varchar2_table(7) := 'eferences eba_demo_ir_emp (EMPNO) ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_ir_emp_1 ON eba_demo_ir_emp (MGR)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(8) := '/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'create index eba_demo_ir_emp_2 ON eba_demo_ir_emp (DEPTNO)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1313798488066914641)
,p_install_id=>wwv_flow_imp.id(2562539889212995876)
,p_name=>'EMP and DEPT tables'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
