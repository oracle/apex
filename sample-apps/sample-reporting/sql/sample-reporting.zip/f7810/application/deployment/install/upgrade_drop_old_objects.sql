prompt --application/deployment/install/upgrade_drop_old_objects
begin
--   Manifest
--     INSTALL: UPGRADE-Drop old objects
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>1566231327207194
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- remove old packages'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ( select object_name'||wwv_flow.LF||
'                from user_objects'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(2) := '              where object_type = ''PACKAGE'''||wwv_flow.LF||
'                    and object_name in ( ''EBA_DEMO_IR_FI';
wwv_flow_imp.g_varchar2_table(3) := 'LTER_FW'', ''EBA_DEMO_IR_FILTER2_FW'' ) )'||wwv_flow.LF||
'    loop'||wwv_flow.LF||
'        execute immediate ''drop package ''||c1.object';
wwv_flow_imp.g_varchar2_table(4) := '_name;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    -- Hide the error if the package cannot be dropped due to bug #21';
wwv_flow_imp.g_varchar2_table(5) := '770724'||wwv_flow.LF||
'    when others then null;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- remove old types'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ( select object_na';
wwv_flow_imp.g_varchar2_table(6) := 'me'||wwv_flow.LF||
'                from user_objects'||wwv_flow.LF||
'                where object_type = ''TYPE'''||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(7) := 'and object_name in (''EBA_DEMO_IR_ACTIVE_FILTERS_TBL'', ''EBA_DEMO_IR_FILTER_COL_TBL'') )'||wwv_flow.LF||
'    loop'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(8) := '   execute immediate ''drop type ''||c1.object_name;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    -- Hide the error if ';
wwv_flow_imp.g_varchar2_table(9) := 'the package cannot be dropped due to bug #21770724'||wwv_flow.LF||
'    when others then null;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- remove old ';
wwv_flow_imp.g_varchar2_table(10) := 'types'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ( select object_name'||wwv_flow.LF||
'                from user_objects'||wwv_flow.LF||
'                whe';
wwv_flow_imp.g_varchar2_table(11) := 're object_type = ''TYPE'''||wwv_flow.LF||
'                    and object_name in (''EBA_DEMO_IR_FILTER_COLUMN_T'', ''EBA_';
wwv_flow_imp.g_varchar2_table(12) := 'DEMO_IR_ACTIVE_FILTERS_T'') )'||wwv_flow.LF||
'    loop'||wwv_flow.LF||
'        execute immediate ''drop type ''||c1.object_name;'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(13) := 'd loop;'||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    -- Hide the error if the package cannot be dropped due to bug #21770724'||wwv_flow.LF||
'    wh';
wwv_flow_imp.g_varchar2_table(14) := 'en others then null;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(171013465951084156)
,p_install_id=>wwv_flow_imp.id(2562539889212995876)
,p_name=>'Drop old objects'
,p_sequence=>59
,p_script_type=>'UPGRADE'
,p_condition_type=>'EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select object_name',
'from user_objects',
'where object_type = ''PACKAGE''',
'    and object_name in ( ''EBA_DEMO_IR_FILTER_FW'', ''EBA_DEMO_IR_FILTER2_FW'' )',
'union all',
'select object_name',
'from user_objects',
'where object_type = ''TYPE''',
'    and object_name in ( ''EBA_DEMO_IR_ACTIVE_FILTERS_TBL'', ''EBA_DEMO_IR_FILTER_COL_TBL'',',
'                        ''EBA_DEMO_IR_FILTER_COLUMN_T'', ''EBA_DEMO_IR_ACTIVE_FILTERS_T'' )'))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
