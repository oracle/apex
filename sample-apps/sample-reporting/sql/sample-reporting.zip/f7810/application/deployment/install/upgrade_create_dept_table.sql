prompt --application/deployment/install/upgrade_create_dept_table
begin
--   Manifest
--     INSTALL: UPGRADE-Create Dept Table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>1566231327207194
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_demo_ir_dept ('||wwv_flow.LF||
'    deptno  NUMBER(2) not null'||wwv_flow.LF||
'                        constraint eb';
wwv_flow_imp.g_varchar2_table(2) := 'a_demo_ir_dept_pk'||wwv_flow.LF||
'                        primary key,'||wwv_flow.LF||
'    dname   VARCHAR2(14),'||wwv_flow.LF||
'    loc     VARCHAR';
wwv_flow_imp.g_varchar2_table(3) := '2(13)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'insert into eba_demo_ir_dept (DEPTNO,DNAME,LOC) values (10,''ACCOUNTING'',''NEW YORK'');'||wwv_flow.LF||
'inser';
wwv_flow_imp.g_varchar2_table(4) := 't into eba_demo_ir_dept (DEPTNO,DNAME,LOC) values (20,''RESEARCH'',''DALLAS'');'||wwv_flow.LF||
'insert into eba_demo_ir_';
wwv_flow_imp.g_varchar2_table(5) := 'dept (DEPTNO,DNAME,LOC) values (30,''SALES'',''CHICAGO'');'||wwv_flow.LF||
'insert into eba_demo_ir_dept (DEPTNO,DNAME,LO';
wwv_flow_imp.g_varchar2_table(6) := 'C) values (40,''OPERATIONS'',''BOSTON'');'||wwv_flow.LF||
''||wwv_flow.LF||
'commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1313801519580923666)
,p_install_id=>wwv_flow_imp.id(2562539889212995876)
,p_name=>'Create Dept Table'
,p_sequence=>10
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select table_name',
'from user_tables',
'where table_name = ''EBA_DEMO_IR_DEPT'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
