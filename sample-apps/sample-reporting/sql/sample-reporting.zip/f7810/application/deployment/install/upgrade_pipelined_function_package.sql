prompt --application/deployment/install/upgrade_pipelined_function_package
begin
--   Manifest
--     INSTALL: UPGRADE-Pipelined Function Package
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>1566231327207194
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_demo_ir_pkg as'||wwv_flow.LF||
'    ---------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '----------------------'||wwv_flow.LF||
'    -- This package is used to demonstrate the power of PL/SQL pipelined'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(3) := '-- funcitons. While functional, it is not complete.'||wwv_flow.LF||
'    -- DEMONSTRATION PURPOSES ONLY'||wwv_flow.LF||
'    ---------';
wwv_flow_imp.g_varchar2_table(4) := '----------------------------------------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'    ------------------------------';
wwv_flow_imp.g_varchar2_table(5) := '-------------------------------------------'||wwv_flow.LF||
'    -- Helper functions for parsing links out of breadcr';
wwv_flow_imp.g_varchar2_table(6) := 'umbs'||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    type page_ref';
wwv_flow_imp.g_varchar2_table(7) := 's_t is record( source_page_id number, source_id number, target_page_id number );'||wwv_flow.LF||
'    type page_refs_';
wwv_flow_imp.g_varchar2_table(8) := 'tbl is table of page_refs_t;'||wwv_flow.LF||
'    function getPageIDNum ( p_app_id in number, p_link in varchar2 ) re';
wwv_flow_imp.g_varchar2_table(9) := 'turn number;'||wwv_flow.LF||
'    -- Breadcrumb references need to be accessed through hierarchical SQL; creating a'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(10) := '   -- separate function helps with performance.'||wwv_flow.LF||
'    function getBreadPageRefsTable ( p_app_id in num';
wwv_flow_imp.g_varchar2_table(11) := 'ber ) return page_refs_tbl PIPELINED;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ---------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(12) := '----------------'||wwv_flow.LF||
'    -- The row definition for the piped result set.'||wwv_flow.LF||
'    ---------------------------';
wwv_flow_imp.g_varchar2_table(13) := '----------------------------------------------'||wwv_flow.LF||
'    type page_refs_rep_t is record('||wwv_flow.LF||
'        page_id n';
wwv_flow_imp.g_varchar2_table(14) := 'umber,'||wwv_flow.LF||
'        list_link_count number,'||wwv_flow.LF||
'        branch_count number,'||wwv_flow.LF||
'        button_count number,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(15) := '     breadcrumb_count number,'||wwv_flow.LF||
'        reportcol_count number,'||wwv_flow.LF||
'        irepcol_count number,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(16) := 'ireplink_count number,'||wwv_flow.LF||
'        tab_count number,'||wwv_flow.LF||
'        total number'||wwv_flow.LF||
'        );'||wwv_flow.LF||
'    -- The table de';
wwv_flow_imp.g_varchar2_table(17) := 'finition for the piped result set.'||wwv_flow.LF||
'    type page_refs_rep_tbl is table of page_refs_rep_t;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ----';
wwv_flow_imp.g_varchar2_table(18) := '---------------------------------------------------------------------'||wwv_flow.LF||
'    -- The pipelined function ';
wwv_flow_imp.g_varchar2_table(19) := 'itself; returns a table of the pages within'||wwv_flow.LF||
'    -- the current application and counts of the various';
wwv_flow_imp.g_varchar2_table(20) := ' ways those pages'||wwv_flow.LF||
'    -- can be accessed from other pages.'||wwv_flow.LF||
'    -------------------------------------';
wwv_flow_imp.g_varchar2_table(21) := '------------------------------------'||wwv_flow.LF||
'    function incomingPageRefsReport return page_refs_rep_tbl PI';
wwv_flow_imp.g_varchar2_table(22) := 'PELINED;'||wwv_flow.LF||
'end eba_demo_ir_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package body eba_demo_ir_pkg as'||wwv_flow.LF||
'    -------------';
wwv_flow_imp.g_varchar2_table(23) := '------------------------------------------------------------'||wwv_flow.LF||
'    -- This package is used to demonstr';
wwv_flow_imp.g_varchar2_table(24) := 'ate the power of PL/SQL pipelined'||wwv_flow.LF||
'    -- funcitons. While functional, it is not complete.'||wwv_flow.LF||
'    -- DEM';
wwv_flow_imp.g_varchar2_table(25) := 'ONSTRATION PURPOSES ONLY'||wwv_flow.LF||
'    -----------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(26) := '--'||wwv_flow.LF||
''||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    -- Function: g';
wwv_flow_imp.g_varchar2_table(27) := 'etPageID'||wwv_flow.LF||
'    -- Helper function to get the page number or alias out of a link.'||wwv_flow.LF||
'    -----------------';
wwv_flow_imp.g_varchar2_table(28) := '--------------------------------------------------------'||wwv_flow.LF||
'    function getPageID ( p_app_id in number';
wwv_flow_imp.g_varchar2_table(29) := ', p_link in varchar2 ) return varchar2 is'||wwv_flow.LF||
'        PREFIX constant varchar2(20) := ''F?P=#APP_ID#:'';'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(30) := '       l_link varchar2(32767) := upper(p_link);'||wwv_flow.LF||
'        l_start binary_integer;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        --';
wwv_flow_imp.g_varchar2_table(31) := '----------------------------------------------------------------------'||wwv_flow.LF||
'        -- APEX generates dif';
wwv_flow_imp.g_varchar2_table(32) := 'ferent versions for a page link...'||wwv_flow.LF||
'        ---------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(33) := '---------------'||wwv_flow.LF||
'        l_link  := replace(l_link, '' '',  ''''); -- if link like ''f?p=''||:APP_ID||...'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(34) := '       l_link  := replace(l_link, '''''''', '''');'||wwv_flow.LF||
'        l_link  := replace(l_link, ''|'',  '''');'||wwv_flow.LF||
'        l';
wwv_flow_imp.g_varchar2_table(35) := '_link  := replace(l_link, chr(38)||''FLOW_ID.'',      ''#APP_ID#''  );'||wwv_flow.LF||
'        l_link  := replace(l_link';
wwv_flow_imp.g_varchar2_table(36) := ', chr(38)||''APP_ID.'',       ''#APP_ID#''  );'||wwv_flow.LF||
'        l_link  := replace(l_link, '':APP_ID'',            ';
wwv_flow_imp.g_varchar2_table(37) := '    ''#APP_ID#''  );'||wwv_flow.LF||
'        l_link  := replace(l_link, ''=''||p_app_id||'':'',      ''=#APP_ID#:'');'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(38) := '  --'||wwv_flow.LF||
'        l_start := INSTR(l_link, PREFIX);'||wwv_flow.LF||
'        ---------------------------------------------';
wwv_flow_imp.g_varchar2_table(39) := '---------------------------'||wwv_flow.LF||
'        -- Try to extract the page id, if it fails because a substitutio';
wwv_flow_imp.g_varchar2_table(40) := 'n'||wwv_flow.LF||
'        -- variables is used for page id we will get a VALUE_ERROR => dynamic call.'||wwv_flow.LF||
'        ------';
wwv_flow_imp.g_varchar2_table(41) := '------------------------------------------------------------------'||wwv_flow.LF||
'        if l_start > 0 then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(42) := '       return substr(l_link, l_start+13, instr(l_link, '':'', l_start+13)-l_start-13);'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(43) := '          return null;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    exception when value_error then'||wwv_flow.LF||
'        return null;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(44) := 'end getPageID;'||wwv_flow.LF||
' '||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(45) := '- Function: getPageIDNum'||wwv_flow.LF||
'    -- Helper function to get the page number out of a link, even if the li';
wwv_flow_imp.g_varchar2_table(46) := 'nk'||wwv_flow.LF||
'    --  uses the page alias.'||wwv_flow.LF||
'    ----------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(47) := '---------'||wwv_flow.LF||
'    function getPageIDNum( p_app_id in number, p_link in varchar2 ) return number is'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(48) := '   l_page varchar2(255) := getPageID( p_app_id, p_link );'||wwv_flow.LF||
'        l_pageid number;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(49) := ' select page_id into l_pageid'||wwv_flow.LF||
'        from apex_application_pages'||wwv_flow.LF||
'        where application_id = p_a';
wwv_flow_imp.g_varchar2_table(50) := 'pp_id'||wwv_flow.LF||
'            and (to_char(page_id) = l_page'||wwv_flow.LF||
'                or upper(page_alias) = upper(l_page';
wwv_flow_imp.g_varchar2_table(51) := '));'||wwv_flow.LF||
'        return l_pageid;'||wwv_flow.LF||
'    end getPageIDNum;'||wwv_flow.LF||
' '||wwv_flow.LF||
'    -------------------------------------------';
wwv_flow_imp.g_varchar2_table(52) := '------------------------------'||wwv_flow.LF||
'    -- Function: getBreadRefsTable'||wwv_flow.LF||
'    -- Pipelined function to get a';
wwv_flow_imp.g_varchar2_table(53) := 'll breadcrumbs in an application, the page(s)'||wwv_flow.LF||
'    --  they''re visible on, and the page they link to.';
wwv_flow_imp.g_varchar2_table(54) := ''||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    function getBread';
wwv_flow_imp.g_varchar2_table(55) := 'PageRefsTable( p_app_id in number ) return page_refs_tbl PIPELINED is'||wwv_flow.LF||
'        cursor bc_csr is'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(56) := '       with data as (  select breadcrumb_id, parent_breadcrumb_id, breadcrumb_entry_id, defined_for_';
wwv_flow_imp.g_varchar2_table(57) := 'page'||wwv_flow.LF||
'                            from apex_application_bc_entries'||wwv_flow.LF||
'                            where ';
wwv_flow_imp.g_varchar2_table(58) := 'application_id = p_app_id )'||wwv_flow.LF||
'            select defined_for_page,'||wwv_flow.LF||
'                breadcrumb_entry_id';
wwv_flow_imp.g_varchar2_table(59) := ','||wwv_flow.LF||
'                substr(sys_connect_by_path(defined_for_page,'':''),1,instr(sys_connect_by_path(defin';
wwv_flow_imp.g_varchar2_table(60) := 'ed_for_page,'':''),'':'',-1)-1) parent_pages'||wwv_flow.LF||
'            from data'||wwv_flow.LF||
'            start with parent_breadcr';
wwv_flow_imp.g_varchar2_table(61) := 'umb_id = 0'||wwv_flow.LF||
'            connect by prior breadcrumb_id = breadcrumb_id'||wwv_flow.LF||
'                and prior brea';
wwv_flow_imp.g_varchar2_table(62) := 'dcrumb_entry_id = parent_breadcrumb_id;'||wwv_flow.LF||
' '||wwv_flow.LF||
'        bc_rec bc_csr%ROWTYPE;'||wwv_flow.LF||
'        l_pages APEX_APPLIC';
wwv_flow_imp.g_varchar2_table(63) := 'ATION_GLOBAL.VC_ARR2;'||wwv_flow.LF||
'        l_pageref page_refs_t;'||wwv_flow.LF||
'        type ref_tbl_t is table of number index';
wwv_flow_imp.g_varchar2_table(64) := ' by binary_integer;'||wwv_flow.LF||
'        l_bc ref_tbl_t;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        for bc_rec in bc_csr loop'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(65) := 'l_pages := APEX_UTIL.STRING_TO_TABLE( bc_rec.parent_pages );'||wwv_flow.LF||
'            for x in 1..l_pages.count l';
wwv_flow_imp.g_varchar2_table(66) := 'oop'||wwv_flow.LF||
'                if l_pages(x) is not null then'||wwv_flow.LF||
'                    select bc_rec.defined_for_pag';
wwv_flow_imp.g_varchar2_table(67) := 'e, bc_rec.breadcrumb_entry_id, pg.page_id into l_pageref'||wwv_flow.LF||
'                    from apex_application_p';
wwv_flow_imp.g_varchar2_table(68) := 'ages pg'||wwv_flow.LF||
'                    where pg.application_id = p_app_id'||wwv_flow.LF||
'                        and ( to_char';
wwv_flow_imp.g_varchar2_table(69) := '(pg.page_id) = l_pages(x) or pg.page_alias = l_pages(x) );'||wwv_flow.LF||
'                    pipe row (l_pageref);';
wwv_flow_imp.g_varchar2_table(70) := ''||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    end getBreadPageRefsTable;'||wwv_flow.LF||
' '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(71) := '  -------------------------------------------------------------------------'||wwv_flow.LF||
'    -- Function: incomin';
wwv_flow_imp.g_varchar2_table(72) := 'gPageRefsReport'||wwv_flow.LF||
'    -- Pipelined function to get all pages in an application and a count of'||wwv_flow.LF||
'    --  ';
wwv_flow_imp.g_varchar2_table(73) := 'the different ways each page is linked to from other pages.'||wwv_flow.LF||
'    ------------------------------------';
wwv_flow_imp.g_varchar2_table(74) := '-------------------------------------'||wwv_flow.LF||
'    function incomingPageRefsReport return page_refs_rep_tbl P';
wwv_flow_imp.g_varchar2_table(75) := 'IPELINED is'||wwv_flow.LF||
'        l_app constant number := v(''APP_ID'');'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_report page_refs_rep_t;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(76) := ' --'||wwv_flow.LF||
'        cursor pg_csr is'||wwv_flow.LF||
'            select page_id,'||wwv_flow.LF||
'                nvl2(page_alias,''(''||to_cha';
wwv_flow_imp.g_varchar2_table(77) := 'r(page_id)||''|''||page_alias||'')'',to_char(page_id)) page_alias,'||wwv_flow.LF||
'                page_name'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(78) := ' from apex_application_pages'||wwv_flow.LF||
'            where application_id = l_app'||wwv_flow.LF||
'            order by page_id;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(79) := '        pg_rec pg_csr%ROWTYPE;'||wwv_flow.LF||
'        l_regexp varchar2(2000);'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        cursor bc_csr is'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(80) := '            select target_page_id, count(*) c'||wwv_flow.LF||
'            from table(getBreadPageRefsTable( l_app ))';
wwv_flow_imp.g_varchar2_table(81) := ' refs'||wwv_flow.LF||
'            group by target_page_id;'||wwv_flow.LF||
'        bc_rec bc_csr%ROWTYPE;'||wwv_flow.LF||
'        l_bc_arr apex_appl';
wwv_flow_imp.g_varchar2_table(82) := 'ication_global.vc_arr2;'||wwv_flow.LF||
'        type ref_tbl_t is table of number index by binary_integer;'||wwv_flow.LF||
'        l';
wwv_flow_imp.g_varchar2_table(83) := '_bc ref_tbl_t;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        for bc_rec in bc_csr loop'||wwv_flow.LF||
'            l_bc(bc_rec.target_page_id) :';
wwv_flow_imp.g_varchar2_table(84) := '= bc_rec.c;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        for pg_rec in pg_csr loop'||wwv_flow.LF||
'            l_regexp := ''';
wwv_flow_imp.g_varchar2_table(85) := 'f?p=(''||l_app||''|[&]APP_ID.):''||pg_rec.page_alias||''(:|$)'';'||wwv_flow.LF||
'            l_report.page_id := pg_rec.p';
wwv_flow_imp.g_varchar2_table(86) := 'age_id;'||wwv_flow.LF||
'            -- List Entries'||wwv_flow.LF||
'            select count(*) into l_report.list_link_count'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(87) := '      from apex_application_list_entries lst'||wwv_flow.LF||
'            where lst.application_id = l_app'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(88) := '      and regexp_like(lst.entry_target, l_regexp);'||wwv_flow.LF||
'            -- Branches'||wwv_flow.LF||
'            select count(';
wwv_flow_imp.g_varchar2_table(89) := '*) into l_report.branch_count'||wwv_flow.LF||
'            from apex_application_page_branches brn'||wwv_flow.LF||
'            where ';
wwv_flow_imp.g_varchar2_table(90) := 'brn.application_id = l_app'||wwv_flow.LF||
'                and brn.page_id <> pg_rec.page_id'||wwv_flow.LF||
'                and reg';
wwv_flow_imp.g_varchar2_table(91) := 'exp_like(brn.branch_action, l_regexp);'||wwv_flow.LF||
'            -- Buttons'||wwv_flow.LF||
'            select count(*) into l_rep';
wwv_flow_imp.g_varchar2_table(92) := 'ort.button_count'||wwv_flow.LF||
'            from apex_application_page_buttons btn'||wwv_flow.LF||
'            where btn.applicatio';
wwv_flow_imp.g_varchar2_table(93) := 'n_id = l_app'||wwv_flow.LF||
'                and btn.page_id <> pg_rec.page_id'||wwv_flow.LF||
'                and regexp_like(btn.r';
wwv_flow_imp.g_varchar2_table(94) := 'edirect_url, l_regexp);'||wwv_flow.LF||
'            -- Breadcrumbs'||wwv_flow.LF||
'            if l_bc.EXISTS( pg_rec.page_id ) then';
wwv_flow_imp.g_varchar2_table(95) := ''||wwv_flow.LF||
'                l_report.breadcrumb_count := l_bc(pg_rec.page_id);'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(96) := ' l_report.breadcrumb_count := 0;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            -- Report Columns (standard)'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(97) := '      select count(*) into l_report.reportcol_count'||wwv_flow.LF||
'            from apex_application_page_rpt_cols ';
wwv_flow_imp.g_varchar2_table(98) := 'rc'||wwv_flow.LF||
'            where rc.application_id = l_app'||wwv_flow.LF||
'                and rc.page_id <> pg_rec.page_id'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(99) := '            and regexp_like(rc.column_link_url, l_regexp);'||wwv_flow.LF||
'            -- Report Columns (interactiv';
wwv_flow_imp.g_varchar2_table(100) := 'e)'||wwv_flow.LF||
'            select count(*) into l_report.irepcol_count'||wwv_flow.LF||
'            from apex_application_page_ir';
wwv_flow_imp.g_varchar2_table(101) := '_col rc'||wwv_flow.LF||
'            where rc.application_id = l_app'||wwv_flow.LF||
'                and rc.page_id <> pg_rec.page_id';
wwv_flow_imp.g_varchar2_table(102) := ''||wwv_flow.LF||
'                and regexp_like(rc.column_link, l_regexp);'||wwv_flow.LF||
'            -- Interactive Report detail';
wwv_flow_imp.g_varchar2_table(103) := ' links'||wwv_flow.LF||
'            select count(*) into l_report.ireplink_count'||wwv_flow.LF||
'            from apex_application_pa';
wwv_flow_imp.g_varchar2_table(104) := 'ge_ir api'||wwv_flow.LF||
'            where api.application_id = l_app'||wwv_flow.LF||
'                and api.page_id <> pg_rec.pag';
wwv_flow_imp.g_varchar2_table(105) := 'e_id'||wwv_flow.LF||
'                and pg_rec.page_id = getPageIDNum( api.application_id, api.detail_link_target )';
wwv_flow_imp.g_varchar2_table(106) := ';'||wwv_flow.LF||
'            -- Tabs'||wwv_flow.LF||
'            select count(*) into l_report.tab_count'||wwv_flow.LF||
'            from apex_appl';
wwv_flow_imp.g_varchar2_table(107) := 'ication_tabs tb'||wwv_flow.LF||
'            where tb.application_id = l_app'||wwv_flow.LF||
'                and tb.tab_page = pg_rec';
wwv_flow_imp.g_varchar2_table(108) := '.page_id;'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            l_report.total := l_report.list_link_count'||wwv_flow.LF||
'                + l_';
wwv_flow_imp.g_varchar2_table(109) := 'report.branch_count'||wwv_flow.LF||
'                + l_report.button_count'||wwv_flow.LF||
'                + l_report.breadcrumb_co';
wwv_flow_imp.g_varchar2_table(110) := 'unt'||wwv_flow.LF||
'                + l_report.reportcol_count'||wwv_flow.LF||
'                + l_report.irepcol_count'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(111) := '    + l_report.ireplink_count'||wwv_flow.LF||
'                + l_report.tab_count'||wwv_flow.LF||
'                ;'||wwv_flow.LF||
'            pip';
wwv_flow_imp.g_varchar2_table(112) := 'e row( l_report );'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    end incomingPageRefsReport;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_demo_ir_pkg;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1314045697123771776)
,p_install_id=>wwv_flow_imp.id(2562539889212995876)
,p_name=>'Pipelined Function Package'
,p_sequence=>50
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
