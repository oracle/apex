prompt --application/deployment/install/upgrade_create_emp_table
begin
--   Manifest
--     INSTALL: UPGRADE-Create Emp Table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>1566231327207194
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_demo_ir_emp ('||wwv_flow.LF||
'    empno     NUMBER(4) not null'||wwv_flow.LF||
'                          constraint';
wwv_flow_imp.g_varchar2_table(2) := ' eba_demo_ir_emp_pk'||wwv_flow.LF||
'                          primary key,'||wwv_flow.LF||
'    ename     VARCHAR2(10),'||wwv_flow.LF||
'    job      ';
wwv_flow_imp.g_varchar2_table(3) := ' VARCHAR2(9),'||wwv_flow.LF||
'    mgr       NUMBER(4),'||wwv_flow.LF||
'    hiredate  DATE,'||wwv_flow.LF||
'    sal       NUMBER(7),'||wwv_flow.LF||
'    comm      NU';
wwv_flow_imp.g_varchar2_table(4) := 'MBER(7),'||wwv_flow.LF||
'    deptno    NUMBER(2)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_ir_emp add foreign key (MGR) references e';
wwv_flow_imp.g_varchar2_table(5) := 'ba_demo_ir_emp (EMPNO) ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_ir_emp_1 ON eba_demo_ir_emp (MGR)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'crea';
wwv_flow_imp.g_varchar2_table(6) := 'te index eba_demo_ir_emp_2 ON eba_demo_ir_emp (DEPTNO)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,J';
wwv_flow_imp.g_varchar2_table(7) := 'OB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7839,''KING'',''PRESIDENT'',null,to_date(''17-11-81'',''DD-MM-RR'')';
wwv_flow_imp.g_varchar2_table(8) := ',5000,null,10);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7';
wwv_flow_imp.g_varchar2_table(9) := '698,''BLAKE'',''MANAGER'',7839,to_date(''01-05-81'',''DD-MM-RR''),2850,null,30);'||wwv_flow.LF||
'insert into eba_demo_ir_emp';
wwv_flow_imp.g_varchar2_table(10) := ' (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7782,''CLARK'',''MANAGER'',7839,to_date(''09-06-8';
wwv_flow_imp.g_varchar2_table(11) := '1'',''DD-MM-RR''),2450,null,10);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEP';
wwv_flow_imp.g_varchar2_table(12) := 'TNO) values (7566,''JONES'',''MANAGER'',7839,to_date(''02-04-81'',''DD-MM-RR''),2975,null,20);'||wwv_flow.LF||
'insert into e';
wwv_flow_imp.g_varchar2_table(13) := 'ba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7788,''SCOTT'',''ANALYST'',7566,to';
wwv_flow_imp.g_varchar2_table(14) := '_date(''09-12-82'',''DD-MM-RR''),3000,null,20);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDAT';
wwv_flow_imp.g_varchar2_table(15) := 'E,SAL,COMM,DEPTNO) values (7902,''FORD'',''ANALYST'',7566,to_date(''03-12-81'',''DD-MM-RR''),3000,null,20);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(16) := 'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7369,''SMITH'',''CLE';
wwv_flow_imp.g_varchar2_table(17) := 'RK'',7902,to_date(''17-12-80'',''DD-MM-RR''),800,null,20);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,M';
wwv_flow_imp.g_varchar2_table(18) := 'GR,HIREDATE,SAL,COMM,DEPTNO) values (7499,''ALLEN'',''SALESMAN'',7698,to_date(''20-02-81'',''DD-MM-RR''),160';
wwv_flow_imp.g_varchar2_table(19) := '0,300,30);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7521,''';
wwv_flow_imp.g_varchar2_table(20) := 'WARD'',''SALESMAN'',7698,to_date(''22-02-81'',''DD-MM-RR''),1250,500,30);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPN';
wwv_flow_imp.g_varchar2_table(21) := 'O,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7654,''MARTIN'',''SALESMAN'',7698,to_date(''28-09-81'',''';
wwv_flow_imp.g_varchar2_table(22) := 'DD-MM-RR''),1250,1400,30);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO)';
wwv_flow_imp.g_varchar2_table(23) := ' values (7844,''TURNER'',''SALESMAN'',7698,to_date(''08-09-81'',''DD-MM-RR''),1500,0,30);'||wwv_flow.LF||
'insert into eba_de';
wwv_flow_imp.g_varchar2_table(24) := 'mo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7876,''ADAMS'',''CLERK'',7788,to_date(''';
wwv_flow_imp.g_varchar2_table(25) := '12-01-83'',''DD-MM-RR''),1100,null,20);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,C';
wwv_flow_imp.g_varchar2_table(26) := 'OMM,DEPTNO) values (7900,''JAMES'',''CLERK'',7698,to_date(''03-12-81'',''DD-MM-RR''),950,null,30);'||wwv_flow.LF||
'insert in';
wwv_flow_imp.g_varchar2_table(27) := 'to eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7934,''MILLER'',''CLERK'',7782';
wwv_flow_imp.g_varchar2_table(28) := ',to_date(''23-01-82'',''DD-MM-RR''),1300,null,10);'||wwv_flow.LF||
''||wwv_flow.LF||
'commit;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1313800300186918064)
,p_install_id=>wwv_flow_imp.id(2562539889212995876)
,p_name=>'Create Emp Table'
,p_sequence=>20
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select table_name',
'from user_tables',
'where table_name = ''EBA_DEMO_IR_EMP'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
