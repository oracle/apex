prompt --application/deployment/install/install_create_table
begin
--   Manifest
--     INSTALL: INSTALL-Create Table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>1566231327207194
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_DEMO_IR_PROJECTS"'||wwv_flow.LF||
'   ("ID" NUMBER, '||wwv_flow.LF||
'    "ROW_VERSION_NUMBER" NUMBER,'||wwv_flow.LF||
'    "PROJECT"';
wwv_flow_imp.g_varchar2_table(2) := ' VARCHAR2(30), '||wwv_flow.LF||
'    "TASK_NAME" VARCHAR2(255), '||wwv_flow.LF||
'    "START_DATE" DATE, '||wwv_flow.LF||
'    "END_DATE" DATE, '||wwv_flow.LF||
'    "S';
wwv_flow_imp.g_varchar2_table(3) := 'TATUS" VARCHAR2(30), '||wwv_flow.LF||
'    "ASSIGNED_TO" VARCHAR2(30), '||wwv_flow.LF||
'    "COST" NUMBER, '||wwv_flow.LF||
'    "BUDGET" NUMBER '||wwv_flow.LF||
'   )';
wwv_flow_imp.g_varchar2_table(4) := ' ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE UNIQUE INDEX "EBA_DEMO_IR_PROJECTS_PK" ON "EBA_DEMO_IR_PROJECTS" ("ID");'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or repl';
wwv_flow_imp.g_varchar2_table(5) := 'ace TRIGGER "BIU_EBA_DEMO_IR_PROJECTS"'||wwv_flow.LF||
'BEFORE INSERT OR UPDATE ON EBA_DEMO_IR_PROJECTS'||wwv_flow.LF||
'FOR EACH ROW'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(6) := 'BEGIN'||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(7) := 'X'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(8) := 'elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;';
wwv_flow_imp.g_varchar2_table(9) := ''||wwv_flow.LF||
'   if :new.start_date > :new.end_date then'||wwv_flow.LF||
'       RAISE_APPLICATION_ERROR(-20001, ''Error start date';
wwv_flow_imp.g_varchar2_table(10) := ' must be before end date'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'END;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2582837511840337511)
,p_install_id=>wwv_flow_imp.id(2562539889212995876)
,p_name=>'Create Table'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
