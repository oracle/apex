prompt --application/deployment/install/upgrade_update_data_script
begin
--   Manifest
--     INSTALL: UPGRADE-Update Data Script
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>1566231327207194
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace procedure EBA_DEMO_IR_DATA'||wwv_flow.LF||
'as'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'delete from EBA_DEMO_IR_PROJECTS;'||wwv_flow.LF||
''||wwv_flow.LF||
'  insert in';
wwv_flow_imp.g_varchar2_table(2) := 'to eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) value';
wwv_flow_imp.g_varchar2_table(3) := 's (''ACME Web Express Configuration'',''Identify server requirements'',to_date(''12/20/2015'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(4) := '),to_date(''12/21/2015'',''MM/DD/YYYY''),''Closed'',''John Watson'',''200'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_';
wwv_flow_imp.g_varchar2_table(5) := 'projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''ACME Web Ex';
wwv_flow_imp.g_varchar2_table(6) := 'press Configuration'',''Determine Web listener configuration(s)'',to_date(''12/22/2015'',''MM/DD/YYYY''),to';
wwv_flow_imp.g_varchar2_table(7) := '_date(''12/22/2015'',''MM/DD/YYYY''),''Closed'',''James Cassidy'',''600'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_pr';
wwv_flow_imp.g_varchar2_table(8) := 'ojects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''ACME Web Expr';
wwv_flow_imp.g_varchar2_table(9) := 'ess Configuration'',''Run installation'',to_date(''12/25/2015'',''MM/DD/YYYY''),to_date(''12/25/2015'',''MM/DD';
wwv_flow_imp.g_varchar2_table(10) := '/YYYY''),''Closed'',''James Cassidy'',''200'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name';
wwv_flow_imp.g_varchar2_table(11) := ',start_date,end_date,status,assigned_to,cost,budget) values (''ACME Web Express Configuration'',''Creat';
wwv_flow_imp.g_varchar2_table(12) := 'e pilot workspace'',to_date(''12/27/2015'',''MM/DD/YYYY''),to_date(''12/27/2015'',''MM/DD/YYYY''),''Closed'',''J';
wwv_flow_imp.g_varchar2_table(13) := 'ohn Watson'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,';
wwv_flow_imp.g_varchar2_table(14) := 'status,assigned_to,cost,budget) values (''ACME Web Express Configuration'',''Specify security authentic';
wwv_flow_imp.g_varchar2_table(15) := 'ation scheme(s)'',to_date(''01/01/2015'',''MM/DD/YYYY''),to_date(''01/01/2015'',''MM/DD/YYYY''),''Open'',''John ';
wwv_flow_imp.g_varchar2_table(16) := 'Watson'',''200'',''300'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,stat';
wwv_flow_imp.g_varchar2_table(17) := 'us,assigned_to,cost,budget) values (''ACME Web Express Configuration'',''Configure Workspace provisioni';
wwv_flow_imp.g_varchar2_table(18) := 'ng'',to_date(''01/02/2015'',''MM/DD/YYYY''),to_date(''01/02/2015'',''MM/DD/YYYY''),''Open'',''John Watson'',''200''';
wwv_flow_imp.g_varchar2_table(19) := ',''100'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_t';
wwv_flow_imp.g_varchar2_table(20) := 'o,cost,budget) values (''ACME Web Express Configuration'',''Select servers for Development, Test, Produ';
wwv_flow_imp.g_varchar2_table(21) := 'ction'',to_date(''01/05/2015'',''MM/DD/YYYY''),to_date(''01/07/2015'',''MM/DD/YYYY''),''Open'',''James Cassidy'',';
wwv_flow_imp.g_varchar2_table(22) := '''200'',''600'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assig';
wwv_flow_imp.g_varchar2_table(23) := 'ned_to,cost,budget) values (''Bug Tracker'',''Document quality assurance procedures'',to_date(''11/05/201';
wwv_flow_imp.g_varchar2_table(24) := '5'',''MM/DD/YYYY''),to_date(''11/08/2015'',''MM/DD/YYYY''),''Closed'',''Myra Sutcliff'',''3000'',''2000'');'||wwv_flow.LF||
'  inser';
wwv_flow_imp.g_varchar2_table(25) := 't into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) v';
wwv_flow_imp.g_varchar2_table(26) := 'alues (''Bug Tracker'',''Review automated testing tools'',to_date(''11/09/2015'',''MM/DD/YYYY''),to_date(''11';
wwv_flow_imp.g_varchar2_table(27) := '/11/2015'',''MM/DD/YYYY''),''Closed'',''Myra Sutcliff'',''750'',''1500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (';
wwv_flow_imp.g_varchar2_table(28) := 'project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Bug Tracker'',''Impleme';
wwv_flow_imp.g_varchar2_table(29) := 'nt bug tracking software'',to_date(''11/24/2015'',''MM/DD/YYYY''),to_date(''11/24/2015'',''MM/DD/YYYY''),''Clo';
wwv_flow_imp.g_varchar2_table(30) := 'sed'',''Myra Sutcliff'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,';
wwv_flow_imp.g_varchar2_table(31) := 'end_date,status,assigned_to,cost,budget) values (''Bug Tracker'',''Train developers on tracking bugs'',t';
wwv_flow_imp.g_varchar2_table(32) := 'o_date(''12/01/2015'',''MM/DD/YYYY''),to_date(''12/06/2015'',''MM/DD/YYYY''),''On-Hold'',''Myra Sutcliff'',''1000';
wwv_flow_imp.g_varchar2_table(33) := ''',''2000'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned';
wwv_flow_imp.g_varchar2_table(34) := '_to,cost,budget) values (''Bug Tracker'',''Measure effectiveness of improved QA'',to_date(''12/13/2015'',''';
wwv_flow_imp.g_varchar2_table(35) := 'MM/DD/YYYY''),to_date(''12/13/2015'',''MM/DD/YYYY''),''Pending'',''Myra Sutcliff'',''0'',''500'');'||wwv_flow.LF||
'  insert into ';
wwv_flow_imp.g_varchar2_table(36) := 'eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (';
wwv_flow_imp.g_varchar2_table(37) := '''Convert Spreadsheets'',''Collect mission-critical spreadsheets'',to_date(''12/19/2015'',''MM/DD/YYYY''),to';
wwv_flow_imp.g_varchar2_table(38) := '_date(''12/20/2015'',''MM/DD/YYYY''),''Closed'',''Pam King'',''2500'',''4000'');'||wwv_flow.LF||
'  insert into eba_demo_ir_proje';
wwv_flow_imp.g_varchar2_table(39) := 'cts (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Convert Spreadsh';
wwv_flow_imp.g_varchar2_table(40) := 'eets'',''Lock spreadsheets'',to_date(''12/22/2015'',''MM/DD/YYYY''),to_date(''12/22/2015'',''MM/DD/YYYY''),''Clo';
wwv_flow_imp.g_varchar2_table(41) := 'sed'',''Pam King'',''300'',''800'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_d';
wwv_flow_imp.g_varchar2_table(42) := 'ate,status,assigned_to,cost,budget) values (''Convert Spreadsheets'',''Create ACME Web Express applicat';
wwv_flow_imp.g_varchar2_table(43) := 'ions from spreadsheets'',to_date(''12/30/2015'',''MM/DD/YYYY''),to_date(''01/03/2016'',''MM/DD/YYYY''),''Open''';
wwv_flow_imp.g_varchar2_table(44) := ',''Pam King'',''6000'',''10000'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_da';
wwv_flow_imp.g_varchar2_table(45) := 'te,status,assigned_to,cost,budget) values (''Convert Spreadsheets'',''Send links to previous spreadshee';
wwv_flow_imp.g_varchar2_table(46) := 't owners'',to_date(''01/05/2016'',''MM/DD/YYYY''),to_date(''01/05/2016'',''MM/DD/YYYY''),''Pending'',''Pam King''';
wwv_flow_imp.g_varchar2_table(47) := ',''0'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assign';
wwv_flow_imp.g_varchar2_table(48) := 'ed_to,cost,budget) values (''Discussion Forum'',''Identify owners'',to_date(''11/25/2015'',''MM/DD/YYYY''),t';
wwv_flow_imp.g_varchar2_table(49) := 'o_date(''11/25/2015'',''MM/DD/YYYY''),''Closed'',''Hank Davis'',''250'',''300'');'||wwv_flow.LF||
'  insert into eba_demo_ir_proj';
wwv_flow_imp.g_varchar2_table(50) := 'ects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Discussion Foru';
wwv_flow_imp.g_varchar2_table(51) := 'm'',''Install ACME Web Express application on internet server'',to_date(''12/01/2015'',''MM/DD/YYYY''),to_d';
wwv_flow_imp.g_varchar2_table(52) := 'ate(''12/01/2015'',''MM/DD/YYYY''),''Closed'',''Hank Davis'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_ir_project';
wwv_flow_imp.g_varchar2_table(53) := 's (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Discussion Forum'',';
wwv_flow_imp.g_varchar2_table(54) := '''Monitor participation'',to_date(''12/31/2015'',''MM/DD/YYYY''),to_date(''01/01/2016'',''MM/DD/YYYY''),''Open''';
wwv_flow_imp.g_varchar2_table(55) := ',''Hank Davis'',''450'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_dat';
wwv_flow_imp.g_varchar2_table(56) := 'e,status,assigned_to,cost,budget) values (''Email Integration'',''Complete plan'',to_date(''12/12/2015'',''';
wwv_flow_imp.g_varchar2_table(57) := 'MM/DD/YYYY''),to_date(''12/13/2015'',''MM/DD/YYYY''),''Closed'',''Bob Nile'',''3000'',''1500'');'||wwv_flow.LF||
'  insert into eb';
wwv_flow_imp.g_varchar2_table(58) := 'a_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''E';
wwv_flow_imp.g_varchar2_table(59) := 'mail Integration'',''Check software licenses'',to_date(''12/15/2015'',''MM/DD/YYYY''),to_date(''12/15/2015'',';
wwv_flow_imp.g_varchar2_table(60) := '''MM/DD/YYYY''),''Closed'',''Bob Nile'',''200'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_nam';
wwv_flow_imp.g_varchar2_table(61) := 'e,start_date,end_date,status,assigned_to,cost,budget) values (''Email Integration'',''Get RFPs for new ';
wwv_flow_imp.g_varchar2_table(62) := 'server'',to_date(''12/29/2015'',''MM/DD/YYYY''),to_date(''12/30/2015'',''MM/DD/YYYY''),''Closed'',''Bob Nile'',''2';
wwv_flow_imp.g_varchar2_table(63) := '000'',''1000'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assig';
wwv_flow_imp.g_varchar2_table(64) := 'ned_to,cost,budget) values (''Email Integration'',''Purchase backup server'',to_date(''01/15/2016'',''MM/DD';
wwv_flow_imp.g_varchar2_table(65) := '/YYYY''),to_date(''01/17/2016'',''MM/DD/YYYY''),''Pending'',''Bob Nile'',''0'',''3000'');'||wwv_flow.LF||
'  insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(66) := 'ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Employee';
wwv_flow_imp.g_varchar2_table(67) := ' Satisfaction Survey'',''Complete questionnaire'',to_date(''12/05/2015'',''MM/DD/YYYY''),to_date(''12/06/201';
wwv_flow_imp.g_varchar2_table(68) := '5'',''MM/DD/YYYY''),''Closed'',''Irene Jones'',''1200'',''800'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,t';
wwv_flow_imp.g_varchar2_table(69) := 'ask_name,start_date,end_date,status,assigned_to,cost,budget) values (''Employee Satisfaction Survey'',';
wwv_flow_imp.g_varchar2_table(70) := '''Review with legal'',to_date(''12/07/2015'',''MM/DD/YYYY''),to_date(''12/07/2015'',''MM/DD/YYYY''),''On-Hold'',';
wwv_flow_imp.g_varchar2_table(71) := '''Irene Jones'',''200'',''400'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_dat';
wwv_flow_imp.g_varchar2_table(72) := 'e,status,assigned_to,cost,budget) values (''Employee Satisfaction Survey'',''Plan rollout schedule'',to_';
wwv_flow_imp.g_varchar2_table(73) := 'date(''12/08/2015'',''MM/DD/YYYY''),to_date(''12/08/2015'',''MM/DD/YYYY''),''On-Hold'',''Irene Jones'',''0'',''750''';
wwv_flow_imp.g_varchar2_table(74) := ');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost';
wwv_flow_imp.g_varchar2_table(75) := ',budget) values (''Client Server Conversion'',''Identify pilot Client Server applications'',to_date(''12/';
wwv_flow_imp.g_varchar2_table(76) := '17/2015'',''MM/DD/YYYY''),to_date(''12/17/2015'',''MM/DD/YYYY''),''Closed'',''Scott Spencer'',''200'',''200'');'||wwv_flow.LF||
'  i';
wwv_flow_imp.g_varchar2_table(77) := 'nsert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budge';
wwv_flow_imp.g_varchar2_table(78) := 't) values (''Client Server Conversion'',''Migrate pilot Client Server to ACME Web Express'',to_date(''12/';
wwv_flow_imp.g_varchar2_table(79) := '19/2015'',''MM/DD/YYYY''),to_date(''12/22/2015'',''MM/DD/YYYY''),''Closed'',''Scott Spencer'',''4500'',''5000'');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(80) := ' insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,bud';
wwv_flow_imp.g_varchar2_table(81) := 'get) values (''Client Server Conversion'',''Post-migration review'',to_date(''12/23/2015'',''MM/DD/YYYY''),t';
wwv_flow_imp.g_varchar2_table(82) := 'o_date(''12/23/2015'',''MM/DD/YYYY''),''Closed'',''Pam King'',''500'',''300'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projec';
wwv_flow_imp.g_varchar2_table(83) := 'ts (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Client Server Con';
wwv_flow_imp.g_varchar2_table(84) := 'version'',''Plan migration schedule'',to_date(''12/26/2015'',''MM/DD/YYYY''),to_date(''12/26/2015'',''MM/DD/YY';
wwv_flow_imp.g_varchar2_table(85) := 'YY''),''Closed'',''Pam King'',''1000'',''1000'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start';
wwv_flow_imp.g_varchar2_table(86) := '_date,end_date,status,assigned_to,cost,budget) values (''Client Server Conversion'',''Migrate Client Se';
wwv_flow_imp.g_varchar2_table(87) := 'rver applications'',to_date(''12/31/2015'',''MM/DD/YYYY''),to_date(''01/03/2016'',''MM/DD/YYYY''),''Open'',''Pam';
wwv_flow_imp.g_varchar2_table(88) := ' King'',''300'',''12000'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,sta';
wwv_flow_imp.g_varchar2_table(89) := 'tus,assigned_to,cost,budget) values (''Client Server Conversion'',''Test migrated applications'',to_date';
wwv_flow_imp.g_varchar2_table(90) := '(''01/05/2016'',''MM/DD/YYYY''),to_date(''01/06/2016'',''MM/DD/YYYY''),''Pending'',''Russ Saunders'',''0'',''6000'')';
wwv_flow_imp.g_varchar2_table(91) := ';'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,';
wwv_flow_imp.g_varchar2_table(92) := 'budget) values (''Client Server Conversion'',''User acceptance testing'',to_date(''01/09/2016'',''MM/DD/YYY';
wwv_flow_imp.g_varchar2_table(93) := 'Y''),to_date(''01/11/2016'',''MM/DD/YYYY''),''Pending'',''Russ Saunders'',''0'',''2500'');'||wwv_flow.LF||
'  insert into eba_demo';
wwv_flow_imp.g_varchar2_table(94) := '_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Client ';
wwv_flow_imp.g_varchar2_table(95) := 'Server Conversion'',''End-user Training'',to_date(''01/15/2016'',''MM/DD/YYYY''),to_date(''01/15/2016'',''MM/D';
wwv_flow_imp.g_varchar2_table(96) := 'D/YYYY''),''Pending'',''Myra Sutcliff'',''0'',''2500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_nam';
wwv_flow_imp.g_varchar2_table(97) := 'e,start_date,end_date,status,assigned_to,cost,budget) values (''Client Server Conversion'',''Rollout mi';
wwv_flow_imp.g_varchar2_table(98) := 'grated Client Server in ACME Web Express'',to_date(''01/16/2016'',''MM/DD/YYYY''),to_date(''01/16/2016'',''M';
wwv_flow_imp.g_varchar2_table(99) := 'M/DD/YYYY''),''Pending'',''Pam King'',''0'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,s';
wwv_flow_imp.g_varchar2_table(100) := 'tart_date,end_date,status,assigned_to,cost,budget) values (''Load Packaged Apps'',''Identify point solu';
wwv_flow_imp.g_varchar2_table(101) := 'tions required'',to_date(''12/19/2015'',''MM/DD/YYYY''),to_date(''12/19/2015'',''MM/DD/YYYY''),''Closed'',''John';
wwv_flow_imp.g_varchar2_table(102) := ' Watson'',''200'',''300'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,sta';
wwv_flow_imp.g_varchar2_table(103) := 'tus,assigned_to,cost,budget) values (''Load Packaged Apps'',''Install in development'',to_date(''12/20/20';
wwv_flow_imp.g_varchar2_table(104) := '15'',''MM/DD/YYYY''),to_date(''12/20/2015'',''MM/DD/YYYY''),''Closed'',''John Watson'',''100'',''100'');'||wwv_flow.LF||
'  insert i';
wwv_flow_imp.g_varchar2_table(105) := 'nto eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) valu';
wwv_flow_imp.g_varchar2_table(106) := 'es (''Load Packaged Apps'',''Customize solutions'',to_date(''12/23/2015'',''MM/DD/YYYY''),to_date(''12/25/201';
wwv_flow_imp.g_varchar2_table(107) := '5'',''MM/DD/YYYY''),''Open'',''John Watson'',''1500'',''4000'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,ta';
wwv_flow_imp.g_varchar2_table(108) := 'sk_name,start_date,end_date,status,assigned_to,cost,budget) values (''Load Packaged Apps'',''Implement ';
wwv_flow_imp.g_varchar2_table(109) := 'in Production'',to_date(''12/26/2015'',''MM/DD/YYYY''),to_date(''12/26/2015'',''MM/DD/YYYY''),''On-Hold'',''John';
wwv_flow_imp.g_varchar2_table(110) := ' Watson'',''200'',''1500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,st';
wwv_flow_imp.g_varchar2_table(111) := 'atus,assigned_to,cost,budget) values (''Load Packaged Apps'',''Train Administrators of Packaged Apps'',t';
wwv_flow_imp.g_varchar2_table(112) := 'o_date(''12/28/2015'',''MM/DD/YYYY''),to_date(''12/28/2015'',''MM/DD/YYYY''),''Pending'',''John Watson'',''0'',''10';
wwv_flow_imp.g_varchar2_table(113) := '00'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,c';
wwv_flow_imp.g_varchar2_table(114) := 'ost,budget) values (''Maintain Support Systems'',''HR software upgrades'',to_date(''11/28/2015'',''MM/DD/YY';
wwv_flow_imp.g_varchar2_table(115) := 'YY''),to_date(''12/01/2015'',''MM/DD/YYYY''),''Closed'',''Pam King'',''8000'',''7000'');'||wwv_flow.LF||
'  insert into eba_demo_i';
wwv_flow_imp.g_varchar2_table(116) := 'r_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Maintain ';
wwv_flow_imp.g_varchar2_table(117) := 'Support Systems'',''Apply Billing System updates'',to_date(''12/02/2015'',''MM/DD/YYYY''),to_date(''12/04/20';
wwv_flow_imp.g_varchar2_table(118) := '15'',''MM/DD/YYYY''),''Closed'',''Russ Saunders'',''9500'',''7000'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (proje';
wwv_flow_imp.g_varchar2_table(119) := 'ct,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Maintain Support Systems'',';
wwv_flow_imp.g_varchar2_table(120) := '''Arrange for vacation coverage'',to_date(''12/06/2015'',''MM/DD/YYYY''),to_date(''12/06/2015'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(121) := '),''Open'',''Al Bines'',''300'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,e';
wwv_flow_imp.g_varchar2_table(122) := 'nd_date,status,assigned_to,cost,budget) values (''Maintain Support Systems'',''Investigate new Virus Pr';
wwv_flow_imp.g_varchar2_table(123) := 'otection software'',to_date(''01/15/2016'',''MM/DD/YYYY''),to_date(''01/16/2016'',''MM/DD/YYYY''),''Open'',''Pam';
wwv_flow_imp.g_varchar2_table(124) := ' King'',''1700'',''1500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,sta';
wwv_flow_imp.g_varchar2_table(125) := 'tus,assigned_to,cost,budget) values (''Migrate Desktop Application'',''Identify pilot desktop applicati';
wwv_flow_imp.g_varchar2_table(126) := 'ons'',to_date(''12/10/2015'',''MM/DD/YYYY''),to_date(''12/10/2015'',''MM/DD/YYYY''),''Closed'',''Bob Nile'',''300''';
wwv_flow_imp.g_varchar2_table(127) := ',''500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_t';
wwv_flow_imp.g_varchar2_table(128) := 'o,cost,budget) values (''Migrate Desktop Application'',''Migrate pilot applications to ACME Web Express';
wwv_flow_imp.g_varchar2_table(129) := ''',to_date(''12/12/2015'',''MM/DD/YYYY''),to_date(''12/13/2015'',''MM/DD/YYYY''),''Closed'',''Bob Nile'',''1250'',''';
wwv_flow_imp.g_varchar2_table(130) := '1500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to';
wwv_flow_imp.g_varchar2_table(131) := ',cost,budget) values (''Migrate Desktop Application'',''Plan migration schedule'',to_date(''12/16/2015'',''';
wwv_flow_imp.g_varchar2_table(132) := 'MM/DD/YYYY''),to_date(''12/16/2015'',''MM/DD/YYYY''),''Closed'',''Bob Nile'',''600'',''200'');'||wwv_flow.LF||
'  insert into eba_';
wwv_flow_imp.g_varchar2_table(133) := 'demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Mig';
wwv_flow_imp.g_varchar2_table(134) := 'rate Desktop Application'',''Migrate desktop applications'',to_date(''01/08/2016'',''MM/DD/YYYY''),to_date(';
wwv_flow_imp.g_varchar2_table(135) := '''01/12/2016'',''MM/DD/YYYY''),''Open'',''Bob Nile'',''1000'',''8000'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (pro';
wwv_flow_imp.g_varchar2_table(136) := 'ject,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate Desktop Applicat';
wwv_flow_imp.g_varchar2_table(137) := 'ion'',''User acceptance testing'',to_date(''01/14/2016'',''MM/DD/YYYY''),to_date(''01/15/2016'',''MM/DD/YYYY'')';
wwv_flow_imp.g_varchar2_table(138) := ',''Open'',''Bob Nile'',''1500'',''6000'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,';
wwv_flow_imp.g_varchar2_table(139) := 'end_date,status,assigned_to,cost,budget) values (''Migrate Desktop Application'',''End-user Training'',t';
wwv_flow_imp.g_varchar2_table(140) := 'o_date(''01/18/2016'',''MM/DD/YYYY''),to_date(''01/19/2016'',''MM/DD/YYYY''),''Open'',''John Watson'',''0'',''2000''';
wwv_flow_imp.g_varchar2_table(141) := ');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost';
wwv_flow_imp.g_varchar2_table(142) := ',budget) values (''Migrate Desktop Application'',''Post-migration review'',to_date(''02/01/2016'',''MM/DD/Y';
wwv_flow_imp.g_varchar2_table(143) := 'YYY''),to_date(''02/02/2016'',''MM/DD/YYYY''),''Pending'',''Bob Nile'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_i';
wwv_flow_imp.g_varchar2_table(144) := 'r_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate f';
wwv_flow_imp.g_varchar2_table(145) := 'rom Legacy Server'',''Obtain Legacy Server credentials'',to_date(''01/20/2016'',''MM/DD/YYYY''),to_date(''01';
wwv_flow_imp.g_varchar2_table(146) := '/20/2016'',''MM/DD/YYYY''),''Pending'',''James Cassidy'',''0'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (pr';
wwv_flow_imp.g_varchar2_table(147) := 'oject,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate from Legacy Ser';
wwv_flow_imp.g_varchar2_table(148) := 'ver'',''Map data usage'',to_date(''01/22/2016'',''MM/DD/YYYY''),to_date(''01/24/2016'',''MM/DD/YYYY''),''Pending';
wwv_flow_imp.g_varchar2_table(149) := ''',''Bob Nile'',''0'',''8000'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,';
wwv_flow_imp.g_varchar2_table(150) := 'status,assigned_to,cost,budget) values (''Migrate from Legacy Server'',''Identify integration points'',t';
wwv_flow_imp.g_varchar2_table(151) := 'o_date(''01/25/2016'',''MM/DD/YYYY''),to_date(''01/26/2016'',''MM/DD/YYYY''),''Pending'',''Bob Nile'',''0'',''2000''';
wwv_flow_imp.g_varchar2_table(152) := ');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost';
wwv_flow_imp.g_varchar2_table(153) := ',budget) values (''Migrate from Legacy Server'',''Create DB Connection to new server'',to_date(''01/25/20';
wwv_flow_imp.g_varchar2_table(154) := '16'',''MM/DD/YYYY''),to_date(''01/25/2016'',''MM/DD/YYYY''),''Pending'',''Scott Spencer'',''0'',''100'');'||wwv_flow.LF||
'  insert ';
wwv_flow_imp.g_varchar2_table(155) := 'into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) val';
wwv_flow_imp.g_varchar2_table(156) := 'ues (''Migrate from Legacy Server'',''Migrate table structures'',to_date(''01/19/2016'',''MM/DD/YYYY''),to_d';
wwv_flow_imp.g_varchar2_table(157) := 'ate(''01/20/2016'',''MM/DD/YYYY''),''Pending'',''John Watson'',''0'',''2500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projec';
wwv_flow_imp.g_varchar2_table(158) := 'ts (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate from Lega';
wwv_flow_imp.g_varchar2_table(159) := 'cy Server'',''Import data'',to_date(''01/31/2016'',''MM/DD/YYYY''),to_date(''02/01/2016'',''MM/DD/YYYY''),''Pend';
wwv_flow_imp.g_varchar2_table(160) := 'ing'',''John Watson'',''0'',''1000'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end';
wwv_flow_imp.g_varchar2_table(161) := '_date,status,assigned_to,cost,budget) values (''Migrate from Legacy Server'',''Convert processes'',to_da';
wwv_flow_imp.g_varchar2_table(162) := 'te(''01/31/2016'',''MM/DD/YYYY''),to_date(''02/02/2016'',''MM/DD/YYYY''),''Pending'',''Pam King'',''0'',''3000'');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(163) := ' insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,bud';
wwv_flow_imp.g_varchar2_table(164) := 'get) values (''Migrate from Legacy Server'',''Notify users'',to_date(''02/05/2016'',''MM/DD/YYYY''),to_date(';
wwv_flow_imp.g_varchar2_table(165) := '''02/05/2016'',''MM/DD/YYYY''),''Pending'',''Bob Nile'',''0'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (proj';
wwv_flow_imp.g_varchar2_table(166) := 'ect,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate from Legacy Serve';
wwv_flow_imp.g_varchar2_table(167) := 'r'',''Cut over to new database'',to_date(''02/06/2016'',''MM/DD/YYYY''),to_date(''02/06/2016'',''MM/DD/YYYY''),';
wwv_flow_imp.g_varchar2_table(168) := '''Pending'',''Bob Nile'',''0'',''1500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,e';
wwv_flow_imp.g_varchar2_table(169) := 'nd_date,status,assigned_to,cost,budget) values (''Migrate from Legacy Server'',''Decommission Legacy Se';
wwv_flow_imp.g_varchar2_table(170) := 'rver'',to_date(''02/20/2016'',''MM/DD/YYYY''),to_date(''02/20/2016'',''MM/DD/YYYY''),''Pending'',''Al Bines'',''0''';
wwv_flow_imp.g_varchar2_table(171) := ',''500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_t';
wwv_flow_imp.g_varchar2_table(172) := 'o,cost,budget) values (''Public Website'',''Determine host server'',to_date(''12/05/2015'',''MM/DD/YYYY''),t';
wwv_flow_imp.g_varchar2_table(173) := 'o_date(''12/05/2015'',''MM/DD/YYYY''),''Closed'',''Tiger Scott'',''200'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_ir_pro';
wwv_flow_imp.g_varchar2_table(174) := 'jects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Public Website';
wwv_flow_imp.g_varchar2_table(175) := ''',''Check software licenses'',to_date(''12/05/2015'',''MM/DD/YYYY''),to_date(''12/05/2015'',''MM/DD/YYYY''),''C';
wwv_flow_imp.g_varchar2_table(176) := 'losed'',''Tom Suess'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,en';
wwv_flow_imp.g_varchar2_table(177) := 'd_date,status,assigned_to,cost,budget) values (''Public Website'',''Purchase additional software licens';
wwv_flow_imp.g_varchar2_table(178) := 'es, if needed'',to_date(''12/06/2015'',''MM/DD/YYYY''),to_date(''12/07/2015'',''MM/DD/YYYY''),''On-Hold'',''Al B';
wwv_flow_imp.g_varchar2_table(179) := 'ines'',''300'',''1000'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,statu';
wwv_flow_imp.g_varchar2_table(180) := 's,assigned_to,cost,budget) values (''Public Website'',''Develop web pages'',to_date(''01/01/2016'',''MM/DD/';
wwv_flow_imp.g_varchar2_table(181) := 'YYYY''),to_date(''01/02/2016'',''MM/DD/YYYY''),''Open'',''Tiger Scott'',''0'',''2000'');'||wwv_flow.LF||
'  insert into eba_demo_i';
wwv_flow_imp.g_varchar2_table(182) := 'r_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Public We';
wwv_flow_imp.g_varchar2_table(183) := 'bsite'',''Plan rollout schedule'',to_date(''01/03/2016'',''MM/DD/YYYY''),to_date(''01/03/2016'',''MM/DD/YYYY'')';
wwv_flow_imp.g_varchar2_table(184) := ',''Open'',''Tom Suess'',''0'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end';
wwv_flow_imp.g_varchar2_table(185) := '_date,status,assigned_to,cost,budget) values (''Software Project Tracking'',''Conduct project kickoff m';
wwv_flow_imp.g_varchar2_table(186) := 'eeting'',to_date(''12/28/2015'',''MM/DD/YYYY''),to_date(''12/28/2015'',''MM/DD/YYYY''),''Closed'',''Pam King'',''1';
wwv_flow_imp.g_varchar2_table(187) := '00'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigne';
wwv_flow_imp.g_varchar2_table(188) := 'd_to,cost,budget) values (''Software Project Tracking'',''Customize Software Projects software'',to_date';
wwv_flow_imp.g_varchar2_table(189) := '(''12/31/2015'',''MM/DD/YYYY''),to_date(''01/01/2016'',''MM/DD/YYYY''),''Open'',''Tom Suess'',''600'',''1000'');'||wwv_flow.LF||
'  i';
wwv_flow_imp.g_varchar2_table(190) := 'nsert into eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budge';
wwv_flow_imp.g_varchar2_table(191) := 't) values (''Software Project Tracking'',''Enter base data (Projects, Milestones, etc.)'',to_date(''01/02';
wwv_flow_imp.g_varchar2_table(192) := '/2016'',''MM/DD/YYYY''),to_date(''01/02/2016'',''MM/DD/YYYY''),''Open'',''Tom Suess'',''200'',''200'');'||wwv_flow.LF||
'  insert in';
wwv_flow_imp.g_varchar2_table(193) := 'to eba_demo_ir_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) value';
wwv_flow_imp.g_varchar2_table(194) := 's (''Software Project Tracking'',''Load current tasks and enhancements'',to_date(''01/04/2016'',''MM/DD/YYY';
wwv_flow_imp.g_varchar2_table(195) := 'Y''),to_date(''01/04/2016'',''MM/DD/YYYY''),''Open'',''Tom Suess'',''400'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_ir_pr';
wwv_flow_imp.g_varchar2_table(196) := 'ojects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Training for ';
wwv_flow_imp.g_varchar2_table(197) := 'ACME Web Express'',''Create training workspace'',to_date(''12/17/2015'',''MM/DD/YYYY''),to_date(''12/18/2015';
wwv_flow_imp.g_varchar2_table(198) := ''',''MM/DD/YYYY''),''Closed'',''James Cassidy'',''500'',''700'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,t';
wwv_flow_imp.g_varchar2_table(199) := 'ask_name,start_date,end_date,status,assigned_to,cost,budget) values (''Training for ACME Web Express''';
wwv_flow_imp.g_varchar2_table(200) := ',''Publish links to self-study courses'',to_date(''12/19/2015'',''MM/DD/YYYY''),to_date(''12/19/2015'',''MM/D';
wwv_flow_imp.g_varchar2_table(201) := 'D/YYYY''),''Closed'',''John Watson'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_ir_projects (project,task_name,';
wwv_flow_imp.g_varchar2_table(202) := 'start_date,end_date,status,assigned_to,cost,budget) values (''Training for ACME Web Express'',''Publish';
wwv_flow_imp.g_varchar2_table(203) := ' development standards'',to_date(''12/19/2015'',''MM/DD/YYYY''),to_date(''12/20/2015'',''MM/DD/YYYY''),''On-Ho';
wwv_flow_imp.g_varchar2_table(204) := 'ld'',''John Watson'',''1000'',''2000'');'||wwv_flow.LF||
''||wwv_flow.LF||
'update eba_demo_ir_projects'||wwv_flow.LF||
'set start_date = start_date + (SYSDAT';
wwv_flow_imp.g_varchar2_table(205) := 'E - TO_DATE(''01012012'',''MMDDYYYY''))'||wwv_flow.LF||
',   end_date = end_date + (SYSDATE - TO_DATE(''01012012'',''MMDDYYY';
wwv_flow_imp.g_varchar2_table(206) := 'Y''));'||wwv_flow.LF||
''||wwv_flow.LF||
'delete from eba_demo_ir_dept;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_demo_ir_dept (DEPTNO,DNAME,LOC) values (10,''AC';
wwv_flow_imp.g_varchar2_table(207) := 'COUNTING'',''NEW YORK'');'||wwv_flow.LF||
'insert into eba_demo_ir_dept (DEPTNO,DNAME,LOC) values (20,''RESEARCH'',''DALLAS';
wwv_flow_imp.g_varchar2_table(208) := ''');'||wwv_flow.LF||
'insert into eba_demo_ir_dept (DEPTNO,DNAME,LOC) values (30,''SALES'',''CHICAGO'');'||wwv_flow.LF||
'insert into eba_d';
wwv_flow_imp.g_varchar2_table(209) := 'emo_ir_dept (DEPTNO,DNAME,LOC) values (40,''OPERATIONS'',''BOSTON'');'||wwv_flow.LF||
''||wwv_flow.LF||
'delete from eba_demo_ir_emp;'||wwv_flow.LF||
''||wwv_flow.LF||
'ins';
wwv_flow_imp.g_varchar2_table(210) := 'ert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7839,''KING'',''PRESIDE';
wwv_flow_imp.g_varchar2_table(211) := 'NT'',null,to_date(''17-11-81'',''DD-MM-RR''),5000,null,10);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,';
wwv_flow_imp.g_varchar2_table(212) := 'MGR,HIREDATE,SAL,COMM,DEPTNO) values (7698,''BLAKE'',''MANAGER'',7839,to_date(''01-05-81'',''DD-MM-RR''),285';
wwv_flow_imp.g_varchar2_table(213) := '0,null,30);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7782,';
wwv_flow_imp.g_varchar2_table(214) := '''CLARK'',''MANAGER'',7839,to_date(''09-06-81'',''DD-MM-RR''),2450,null,10);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EM';
wwv_flow_imp.g_varchar2_table(215) := 'PNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7566,''JONES'',''MANAGER'',7839,to_date(''02-04-81'',''';
wwv_flow_imp.g_varchar2_table(216) := 'DD-MM-RR''),2975,null,20);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO)';
wwv_flow_imp.g_varchar2_table(217) := ' values (7788,''SCOTT'',''ANALYST'',7566,to_date(''09-12-82'',''DD-MM-RR''),3000,null,20);'||wwv_flow.LF||
'insert into eba_d';
wwv_flow_imp.g_varchar2_table(218) := 'emo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7902,''FORD'',''ANALYST'',7566,to_date';
wwv_flow_imp.g_varchar2_table(219) := '(''03-12-81'',''DD-MM-RR''),3000,null,20);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL';
wwv_flow_imp.g_varchar2_table(220) := ',COMM,DEPTNO) values (7369,''SMITH'',''CLERK'',7902,to_date(''17-12-80'',''DD-MM-RR''),800,null,20);'||wwv_flow.LF||
'insert ';
wwv_flow_imp.g_varchar2_table(221) := 'into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7499,''ALLEN'',''SALESMAN'',';
wwv_flow_imp.g_varchar2_table(222) := '7698,to_date(''20-02-81'',''DD-MM-RR''),1600,300,30);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,H';
wwv_flow_imp.g_varchar2_table(223) := 'IREDATE,SAL,COMM,DEPTNO) values (7521,''WARD'',''SALESMAN'',7698,to_date(''22-02-81'',''DD-MM-RR''),1250,500';
wwv_flow_imp.g_varchar2_table(224) := ',30);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7654,''MARTI';
wwv_flow_imp.g_varchar2_table(225) := 'N'',''SALESMAN'',7698,to_date(''28-09-81'',''DD-MM-RR''),1250,1400,30);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,';
wwv_flow_imp.g_varchar2_table(226) := 'ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7844,''TURNER'',''SALESMAN'',7698,to_date(''08-09-81'',''DD';
wwv_flow_imp.g_varchar2_table(227) := '-MM-RR''),1500,0,30);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) valu';
wwv_flow_imp.g_varchar2_table(228) := 'es (7876,''ADAMS'',''CLERK'',7788,to_date(''12-01-83'',''DD-MM-RR''),1100,null,20);'||wwv_flow.LF||
'insert into eba_demo_ir_';
wwv_flow_imp.g_varchar2_table(229) := 'emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7900,''JAMES'',''CLERK'',7698,to_date(''03-12-';
wwv_flow_imp.g_varchar2_table(230) := '81'',''DD-MM-RR''),950,null,30);'||wwv_flow.LF||
'insert into eba_demo_ir_emp (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEP';
wwv_flow_imp.g_varchar2_table(231) := 'TNO) values (7934,''MILLER'',''CLERK'',7782,to_date(''23-01-82'',''DD-MM-RR''),1300,null,10);'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show e';
wwv_flow_imp.g_varchar2_table(232) := 'rrors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1313846304492430339)
,p_install_id=>wwv_flow_imp.id(2562539889212995876)
,p_name=>'Update Data Script'
,p_sequence=>30
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
