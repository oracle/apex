prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7810
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>1566231327207194
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'DROP TRIGGER "BIU_EBA_DEMO_IR_PROJECTS";'||wwv_flow.LF||
''||wwv_flow.LF||
'DROP TABLE  "EBA_DEMO_IR_PROJECTS";'||wwv_flow.LF||
''||wwv_flow.LF||
'DROP PROCEDURE "EBA_D';
wwv_flow_imp.g_varchar2_table(2) := 'EMO_IR_DATA";'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba_demo_ir_dept;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba_demo_ir_emp;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop package EBA_DEMO_IR_P';
wwv_flow_imp.g_varchar2_table(3) := 'KG;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Remove Images'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'        p_location => ''APPLICA';
wwv_flow_imp.g_varchar2_table(4) := 'TION'','||wwv_flow.LF||
'        p_name     => ''reports_ir.png'','||wwv_flow.LF||
'        p_mode     => ''REMOVE'','||wwv_flow.LF||
'        p_type     =>';
wwv_flow_imp.g_varchar2_table(5) := ' ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'        p_location => ''APPLICATION';
wwv_flow_imp.g_varchar2_table(6) := ''','||wwv_flow.LF||
'        p_name     => ''reports_classic.png'','||wwv_flow.LF||
'        p_mode     => ''REMOVE'','||wwv_flow.LF||
'        p_type     =';
wwv_flow_imp.g_varchar2_table(7) := '> ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'        p_location => ''APPLICATIO';
wwv_flow_imp.g_varchar2_table(8) := 'N'','||wwv_flow.LF||
'        p_name     => ''reports_drilldown.png'','||wwv_flow.LF||
'        p_mode     => ''REMOVE'','||wwv_flow.LF||
'        p_type   ';
wwv_flow_imp.g_varchar2_table(9) := '  => ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'        p_location => ''APPLICA';
wwv_flow_imp.g_varchar2_table(10) := 'TION'','||wwv_flow.LF||
'        p_name     => ''reports_filter.png'','||wwv_flow.LF||
'        p_mode     => ''REMOVE'','||wwv_flow.LF||
'        p_type   ';
wwv_flow_imp.g_varchar2_table(11) := '  => ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'        p_location => ''APPLICA';
wwv_flow_imp.g_varchar2_table(12) := 'TION'','||wwv_flow.LF||
'        p_name     => ''reports_usecases.jpg'','||wwv_flow.LF||
'        p_mode     => ''REMOVE'','||wwv_flow.LF||
'        p_type ';
wwv_flow_imp.g_varchar2_table(13) := '    => ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'        p_location => ''A';
wwv_flow_imp.g_varchar2_table(14) := 'PPLICATION'','||wwv_flow.LF||
'        p_name     => ''fs-sprite.png'','||wwv_flow.LF||
'        p_mode     => ''REMOVE'','||wwv_flow.LF||
'        p_type  ';
wwv_flow_imp.g_varchar2_table(15) := '   => ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(2562539889212995876)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_get_version_sql_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from user_tables',
' where table_name like ''EBA_DEMO_IR_%'''))
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE TYPE :CREATE VIEW'
,p_required_names_available=>'EBA_DEMO_IR_PKG:EBA_DEMO_IR_EMP:EBA_DEMO_IR_DEPT:EBA_DEMO_IR_DATA:EBA_DEMO_IR_PROJECTS'
);
wwv_flow_imp.component_end;
end;
/
