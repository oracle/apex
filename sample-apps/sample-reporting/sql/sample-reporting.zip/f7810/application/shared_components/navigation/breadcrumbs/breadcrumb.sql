prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>1566231327207194
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(6286073638733369676)
,p_name=>' Breadcrumb'
,p_static_id=>'breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1875961938920973783)
,p_short_name=>'Administration'
,p_static_id=>'administration'
,p_link=>'f?p=&APP_ID.:36:&SESSION.'
,p_page_id=>36
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1599100513320638355)
,p_short_name=>'Analytic Function Examples'
,p_static_id=>'analytic-function-examples'
,p_link=>'f?p=&APP_ID.:21:&SESSION.'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1875955629759957446)
,p_parent_id=>wwv_flow_imp.id(1875961938920973783)
,p_short_name=>'Application Theme Style'
,p_static_id=>'application-theme-style'
,p_link=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:::'
,p_page_id=>34
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1334051004801735759)
,p_parent_id=>wwv_flow_imp.id(1313321096694043353)
,p_short_name=>'Bind Variables'
,p_static_id=>'bind-variables'
,p_link=>'f?p=&APP_ID.:15:&SESSION.'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(616861507167110709)
,p_short_name=>'Cards'
,p_static_id=>'cards'
,p_link=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:::'
,p_page_id=>41
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313701796478266667)
,p_parent_id=>wwv_flow_imp.id(1333983017714517343)
,p_short_name=>'CASE Statement'
,p_static_id=>'case-statement'
,p_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2673741692637394549)
,p_short_name=>'Classic Report'
,p_static_id=>'classic-report'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313780506782717019)
,p_parent_id=>wwv_flow_imp.id(1333983017714517343)
,p_short_name=>'Connect By'
,p_static_id=>'connect-by'
,p_link=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:::'
,p_page_id=>26
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313573017866108085)
,p_parent_id=>wwv_flow_imp.id(1313321096694043353)
,p_short_name=>'Custom Buttons'
,p_static_id=>'custom-buttons'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1045425790941376774)
,p_parent_id=>wwv_flow_imp.id(1313321096694043353)
,p_short_name=>'Drill Down Reporting using Interactive Grid'
,p_static_id=>'drill-down-reporting-using-interactive-grid'
,p_link=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:::'
,p_page_id=>40
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2680062394325834252)
,p_parent_id=>wwv_flow_imp.id(1313321096694043353)
,p_short_name=>'Drill Down Reporting using Interactive Report'
,p_static_id=>'drill-down-reporting-using-interactive-report'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(658619341383985791)
,p_short_name=>'Faceted Search'
,p_static_id=>'faceted-search'
,p_link=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:::'
,p_page_id=>42
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2677772805360489887)
,p_parent_id=>wwv_flow_imp.id(1313321096694043353)
,p_short_name=>'Filtering using Classic Report'
,p_static_id=>'filtering-using-classic-report'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3057105913857676486)
,p_parent_id=>wwv_flow_imp.id(1313321096694043353)
,p_short_name=>'Format Masks using Interactive Reports'
,p_static_id=>'format-masks-using-interactive-reports'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313717498865338263)
,p_parent_id=>wwv_flow_imp.id(1333983017714517343)
,p_short_name=>'Group By Clause'
,p_static_id=>'group-by-clause'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3255268008353645983)
,p_short_name=>'Help'
,p_static_id=>'help'
,p_link=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:::'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2680446393834981138)
,p_parent_id=>wwv_flow_imp.id(1313321096694043353)
,p_short_name=>'Highlighting using Interactive Reports'
,p_static_id=>'highlighting-using-interactive-reports'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3166525593786055065)
,p_short_name=>'Home'
,p_static_id=>'home'
,p_link=>'f?p=&FLOW_ID.:10:&SESSION.'
,p_page_id=>10
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313713519018308713)
,p_parent_id=>wwv_flow_imp.id(1333983017714517343)
,p_short_name=>'Inline Views'
,p_static_id=>'inline-views'
,p_link=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:::'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1956345153538200044)
,p_short_name=>'Interactive Grid'
,p_static_id=>'interactive-grid'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313326492109057322)
,p_parent_id=>wwv_flow_imp.id(1313321096694043353)
,p_short_name=>'Interactive Report'
,p_static_id=>'interactive-report'
,p_link=>'f?p=&APP_ID.:11:&SESSION.'
,p_page_id=>11
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6286074050581369679)
,p_short_name=>'Interactive Report'
,p_static_id=>'interactive-report-2'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313725916843403447)
,p_parent_id=>wwv_flow_imp.id(1599100513320638355)
,p_short_name=>'LEAD and LAG'
,p_static_id=>'lead-and-lag'
,p_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:::'
,p_page_id=>24
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1045395583534835218)
,p_parent_id=>wwv_flow_imp.id(1313321096694043353)
,p_short_name=>'Linking to Interactive Grids'
,p_static_id=>'linking-to-interactive-grids'
,p_link=>'f?p=&APP_ID.:37:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>37
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313686189568103674)
,p_parent_id=>wwv_flow_imp.id(1313321096694043353)
,p_short_name=>'Linking to Interactive Reports'
,p_static_id=>'linking-to-interactive-reports'
,p_link=>'f?p=&APP_ID.:18:&SESSION.'
,p_page_id=>18
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313899802845699836)
,p_parent_id=>wwv_flow_imp.id(1599100513320638355)
,p_short_name=>'LISTAGG'
,p_static_id=>'listagg'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2673848808743409163)
,p_parent_id=>wwv_flow_imp.id(1875961938920973783)
,p_short_name=>'Manage Sample Data'
,p_static_id=>'manage-sample-data'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1237486010236767893)
,p_parent_id=>wwv_flow_imp.id(1313321096694043353)
,p_short_name=>'Non-Tabular Templates'
,p_static_id=>'non-tabular-templates'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313946001132941452)
,p_parent_id=>wwv_flow_imp.id(1333983017714517343)
,p_short_name=>'Pipelined Functions'
,p_static_id=>'pipelined-functions'
,p_link=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:::'
,p_page_id=>35
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313729211031417765)
,p_parent_id=>wwv_flow_imp.id(1333983017714517343)
,p_short_name=>'Pivot Syntax'
,p_static_id=>'pivot-syntax'
,p_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::'
,p_page_id=>25
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313934499639911448)
,p_parent_id=>wwv_flow_imp.id(1599100513320638355)
,p_short_name=>'RANK and DENSE_RANK'
,p_static_id=>'rank-and-dense-rank'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313938209198919147)
,p_parent_id=>wwv_flow_imp.id(1599100513320638355)
,p_short_name=>'RATIO_TO_REPORT'
,p_static_id=>'ratio-to-report'
,p_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
,p_page_id=>33
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313787815164768428)
,p_parent_id=>wwv_flow_imp.id(1333983017714517343)
,p_short_name=>'Regular Expressions'
,p_static_id=>'regular-expressions'
,p_link=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_page_id=>28
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1332638105359512393)
,p_parent_id=>wwv_flow_imp.id(1313321096694043353)
,p_short_name=>'Report from Collection'
,p_static_id=>'report-from-collection'
,p_link=>'f?p=&APP_ID.:38:&SESSION.'
,p_page_id=>38
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313942208454930460)
,p_parent_id=>wwv_flow_imp.id(1599100513320638355)
,p_short_name=>'ROW_NUMBER'
,p_static_id=>'row-number'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313832997801413271)
,p_parent_id=>wwv_flow_imp.id(1333983017714517343)
,p_short_name=>'Soundex'
,p_static_id=>'soundex'
,p_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:::'
,p_page_id=>29
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1333983017714517343)
,p_short_name=>'SQL Examples'
,p_static_id=>'sql-examples'
,p_link=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:::'
,p_page_id=>39
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313784192881733417)
,p_parent_id=>wwv_flow_imp.id(1333983017714517343)
,p_short_name=>'String Functions'
,p_static_id=>'string-functions'
,p_link=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:::'
,p_page_id=>27
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313710413258300952)
,p_parent_id=>wwv_flow_imp.id(1599100513320638355)
,p_short_name=>'Top N Queries'
,p_static_id=>'top-n-queries'
,p_link=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::'
,p_page_id=>20
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1313321096694043353)
,p_short_name=>'Use Cases'
,p_static_id=>'use-cases'
,p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_imp.component_end;
end;
/
