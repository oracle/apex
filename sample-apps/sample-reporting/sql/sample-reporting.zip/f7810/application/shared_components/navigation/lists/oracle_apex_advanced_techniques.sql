prompt --application/shared_components/navigation/lists/oracle_apex_advanced_techniques
begin
--   Manifest
--     LIST: Oracle APEX Advanced Techniques
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>1566231327207194
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1313763319149592446)
,p_name=>'Oracle APEX Advanced Techniques'
,p_static_id=>'oracle-apex-advanced-techniques'
,p_version_scn=>'1089078416'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1313763516560592446)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'10. Reporting from Oracle APEX Collections'
,p_static_id=>'10-reporting-from-oracle-apex-collections'
,p_list_item_link_target=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:RP,38:::'
,p_list_text_01=>'Demonstrates the technique of building reports based upon Oracle APEX collections.  This allows for result sets to be manipulated and cached before being reporting on.'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
