prompt --application/shared_components/navigation/lists/report_use_cases
begin
--   Manifest
--     LIST: Report Use Cases
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>1566231327207194
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1313465816989842740)
,p_name=>'Report Use Cases'
,p_static_id=>'report-use-cases'
,p_version_scn=>'1089078416'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2916592050962586260)
,p_list_item_display_sequence=>55
,p_list_item_link_text=>'Bind Variables'
,p_static_id=>'bind-variables'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:RP,15:::'
,p_list_item_icon=>'fa-wrench'
,p_list_text_01=>'Shows how to filter an interactive report using a bind variable which derives its value from an Oracle APEX page item.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2896303573961237617)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Column Format Masks'
,p_static_id=>'column-format-masks'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-columns'
,p_list_text_01=>'See various formatting options for dates, numbers, and percent bar charts which are available from within classic and interactive reports.  This example uses an interactive report but the format masks are common between interactive reports and classi'
||'c reports.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2896304173210237617)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Custom Buttons'
,p_static_id=>'custom-buttons'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-external-link'
,p_list_text_01=>'An example of how to turn report cells into buttons via CSS.  This example uses an interactive report.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1046047604924691158)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Drill Down to Interactive Grid'
,p_static_id=>'drill-down-to-interactive-grid'
,p_list_item_link_target=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-level-down'
,p_list_text_01=>'Includes drill down links from one interactive grid to another.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2895992944536595579)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Drill Down to Interactive Report'
,p_static_id=>'drill-down-to-interactive-report'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-level-down'
,p_list_text_01=>'Includes drill down links from one interactive report to another.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1313466611495842743)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Filtering'
,p_static_id=>'filtering'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-filter'
,p_list_text_01=>'Filter classic report results using a left hand side-bar control region.  Uses bind variable references to properly constrain the report.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2895861940000854208)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Interactive Report Query API'
,p_static_id=>'interactive-report-query-api'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-terminal'
,p_list_text_01=>'This example shows how to call an Oracle APEX runtime API to get the SQL statement that corresponds to the current user''s interactive report filters and use this to drive a chart on another page.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1045410666582888807)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Linking to Interactive Grids'
,p_static_id=>'linking-to-interactive-grids'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-chain'
,p_list_text_01=>'Shows how to link to an interactive grid, including syntax to clear settings, reset settings, call named reports, pass filters, etc.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2896225931621899524)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Linking to Interactive Reports'
,p_static_id=>'linking-to-interactive-reports'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-chain'
,p_list_text_01=>'Shows how to link to an interactive report, including syntax to clear settings, reset settings, call named reports, pass filters, etc.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1313486689375262720)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Non-Tabular Templates'
,p_static_id=>'non-tabular-templates'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-comment-o'
,p_list_text_01=>'Classic reports are template based, Interactive Reports are not.  This example demonstrates the use of a classic report template.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2895997735035615189)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Report Highlighting'
,p_static_id=>'report-highlighting'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-lightbulb-o'
,p_list_text_01=>'Shows how to use the built in row and column highlighting capabilities of Interactive Reports.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2896342359961416097)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Reporting from Oracle APEX Collections'
,p_static_id=>'reporting-from-oracle-apex-collections'
,p_list_item_link_target=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:RP,38:::'
,p_list_item_icon=>'fa-paste'
,p_list_text_01=>'Demonstrates the technique of building reports based upon Oracle APEX collections.  This allows for result sets to be manipulated and cached before being reporting on.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
