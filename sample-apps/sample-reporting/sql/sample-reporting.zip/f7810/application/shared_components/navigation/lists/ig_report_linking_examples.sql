prompt --application/shared_components/navigation/lists/ig_report_linking_examples
begin
--   Manifest
--     LIST: IG Report Linking Examples
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>1566231327207194
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1045386530688825993)
,p_name=>'IG Report Linking Examples'
,p_static_id=>'ig-report-linking-examples'
,p_version_scn=>'1089078416'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1045386653679825994)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Clearing report settings'
,p_static_id=>'clearing-report-settings'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:CR:::'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1045388258626825995)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Filtering Report for budgets greater than 5000'
,p_static_id=>'filtering-report-for-budgets-greater-than'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:18,RR:IGGT_BUDGET:5000:'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1045387469096825995)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Invoking a Saved Report'
,p_static_id=>'invoking-a-saved-report'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.:IG_Status:&DEBUG.:RR:::'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1045460164636540039)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Linking to a Saved Report'
,p_static_id=>'linking-to-a-saved-report'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.:IG[projects_report]_Costings:&DEBUG.:CR:IGGT_BUDGET:6000:'
,p_list_item_icon=>'fa-link'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1045387130966825995)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Resetting to Developer Defaults'
,p_static_id=>'resetting-to-developer-defaults'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:RR:::'
,p_list_item_icon=>'fa-refresh'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
