prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7810
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2548643070186089540)
,p_name=>'ADMINISTRATION'
,p_message_text=>'Administration'
,p_version_scn=>37166093866984
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2548647171918090082)
,p_name=>'HELP'
,p_message_text=>'Help'
,p_version_scn=>37166093866984
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2548651274688090822)
,p_name=>'LOGOUT'
,p_message_text=>'Logout'
,p_version_scn=>37166093866984
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2676373956356863921)
,p_name=>'USER'
,p_message_text=>'User'
,p_version_scn=>37166093866984
);
wwv_flow_imp.component_end;
end;
/
