prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7810
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>1566231327207194
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2562639411376002236)
,p_name=>'ADMINISTRATION'
,p_message_text=>'Administration'
,p_version_scn=>37166093866984
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2562643513108002778)
,p_name=>'HELP'
,p_message_text=>'Help'
,p_version_scn=>37166093866984
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2562647615878003518)
,p_name=>'LOGOUT'
,p_message_text=>'Logout'
,p_version_scn=>37166093866984
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2690370297546776617)
,p_name=>'USER'
,p_message_text=>'User'
,p_version_scn=>37166093866984
);
wwv_flow_imp.component_end;
end;
/
