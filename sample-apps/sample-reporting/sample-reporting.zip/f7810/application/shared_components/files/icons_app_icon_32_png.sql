prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 7810
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE90000010E49444154584763B40BCBFDCF30808071D401A321306843405E5A9C41415A0C237F28C9CB302CBDF48D81818111432E5A8F13';
wwv_flow_imp.g_varchar2_table(2) := 'ABDCBF8F2F18FEBCB88135AFE1CC05F5B951583538D95830782F7D8B556E6BB43056B9FFBFBF337CDDDE35700E00D9FC6553E35073405E2CF628B0366558B8F70A56B978671D9C72F366CD222D0426E49A61D5606813C3B0EFE8699C8EC325D738693169';
wwv_flow_imp.g_varchar2_table(3) := '0E3898B1177B0DE1789561DF91133813282EB9C6C9CB461D405A0880D2C0FFFF9835B5916D2C7DD2C068221CCD05039A083958FE3174645A8C9684C3A728FEF1EB1743E7CC35A495847EEAF71804387F636A52CC66B8FFE80956C314E564B0CA3D7FF58E';
wwv_flow_imp.g_varchar2_table(4) := 'E1CEE357A439805E9DA5D19ED168080C7808000018CF12301806AF7F0000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(530981404634036383)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
