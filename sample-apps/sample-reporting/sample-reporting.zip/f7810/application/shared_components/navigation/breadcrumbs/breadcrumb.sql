prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_menu(
 p_id=>wwv_flow_api.id(6272077297543456980)
,p_name=>' Breadcrumb'
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(602865165977198013)
,p_parent_id=>0
,p_short_name=>'Cards'
,p_link=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:::'
,p_page_id=>41
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(644623000194073095)
,p_parent_id=>0
,p_short_name=>'Faceted Search'
,p_link=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:::'
,p_page_id=>42
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1031399242344922522)
,p_parent_id=>wwv_flow_api.id(1299324755504130657)
,p_short_name=>'Linking to Interactive Grids'
,p_link=>'f?p=&APP_ID.:37:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>37
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1031429449751464078)
,p_parent_id=>wwv_flow_api.id(1299324755504130657)
,p_short_name=>'Drill Down Reporting using Interactive Grid'
,p_link=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:::'
,p_page_id=>40
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1223489669046855197)
,p_parent_id=>wwv_flow_api.id(1299324755504130657)
,p_short_name=>'Non-Tabular Templates'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299324755504130657)
,p_parent_id=>0
,p_short_name=>'Use Cases'
,p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299330150919144626)
,p_parent_id=>wwv_flow_api.id(1299324755504130657)
,p_short_name=>'Interactive Report'
,p_link=>'f?p=&APP_ID.:11:&SESSION.'
,p_page_id=>11
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299576676676195389)
,p_parent_id=>wwv_flow_api.id(1299324755504130657)
,p_short_name=>'Custom Buttons'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299689848378190978)
,p_parent_id=>wwv_flow_api.id(1299324755504130657)
,p_short_name=>'Linking to Interactive Reports'
,p_link=>'f?p=&APP_ID.:18:&SESSION.'
,p_page_id=>18
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299705455288353971)
,p_parent_id=>wwv_flow_api.id(1319986676524604647)
,p_short_name=>'CASE Statement'
,p_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_page_id=>19
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299714072068388256)
,p_parent_id=>wwv_flow_api.id(1585104172130725659)
,p_short_name=>'Top N Queries'
,p_link=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::'
,p_page_id=>20
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299717177828396017)
,p_parent_id=>wwv_flow_api.id(1319986676524604647)
,p_short_name=>'Inline Views'
,p_link=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:::'
,p_page_id=>22
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299721157675425567)
,p_parent_id=>wwv_flow_api.id(1319986676524604647)
,p_short_name=>'Group By Clause'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299729575653490751)
,p_parent_id=>wwv_flow_api.id(1585104172130725659)
,p_short_name=>'LEAD and LAG'
,p_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:::'
,p_page_id=>24
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299732869841505069)
,p_parent_id=>wwv_flow_api.id(1319986676524604647)
,p_short_name=>'Pivot Syntax'
,p_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::'
,p_page_id=>25
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299784165592804323)
,p_parent_id=>wwv_flow_api.id(1319986676524604647)
,p_short_name=>'Connect By'
,p_link=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:::'
,p_page_id=>26
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299787851691820721)
,p_parent_id=>wwv_flow_api.id(1319986676524604647)
,p_short_name=>'String Functions'
,p_link=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:::'
,p_page_id=>27
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299791473974855732)
,p_parent_id=>wwv_flow_api.id(1319986676524604647)
,p_short_name=>'Regular Expressions'
,p_link=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_page_id=>28
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299836656611500575)
,p_parent_id=>wwv_flow_api.id(1319986676524604647)
,p_short_name=>'Soundex'
,p_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:::'
,p_page_id=>29
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299903461655787140)
,p_parent_id=>wwv_flow_api.id(1585104172130725659)
,p_short_name=>'LISTAGG'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299938158449998752)
,p_parent_id=>wwv_flow_api.id(1585104172130725659)
,p_short_name=>'RANK and DENSE_RANK'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299941868009006451)
,p_parent_id=>wwv_flow_api.id(1585104172130725659)
,p_short_name=>'RATIO_TO_REPORT'
,p_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
,p_page_id=>33
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299945867265017764)
,p_parent_id=>wwv_flow_api.id(1585104172130725659)
,p_short_name=>'ROW_NUMBER'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1299949659943028756)
,p_parent_id=>wwv_flow_api.id(1319986676524604647)
,p_short_name=>'Pipelined Functions'
,p_link=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:::'
,p_page_id=>35
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1318641764169599697)
,p_parent_id=>wwv_flow_api.id(1299324755504130657)
,p_short_name=>'Report from Collection'
,p_link=>'f?p=&APP_ID.:38:&SESSION.'
,p_page_id=>38
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1319986676524604647)
,p_parent_id=>0
,p_short_name=>'SQL Examples'
,p_link=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:::'
,p_page_id=>39
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1320054663611823063)
,p_parent_id=>wwv_flow_api.id(1299324755504130657)
,p_short_name=>'Bind Variables'
,p_link=>'f?p=&APP_ID.:15:&SESSION.'
,p_page_id=>15
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1585104172130725659)
,p_short_name=>'Analytic Function Examples'
,p_link=>'f?p=&APP_ID.:21:&SESSION.'
,p_page_id=>21
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1861959288570044750)
,p_parent_id=>wwv_flow_api.id(1861965597731061087)
,p_short_name=>'Application Theme Style'
,p_link=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:::'
,p_page_id=>34
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1861965597731061087)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:36:&SESSION.'
,p_page_id=>36
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1942348812348287348)
,p_parent_id=>0
,p_short_name=>'Interactive Grid'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2659745351447481853)
,p_short_name=>'Classic Report'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2659852467553496467)
,p_parent_id=>wwv_flow_api.id(1861965597731061087)
,p_short_name=>'Manage Sample Data'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2663776464170577191)
,p_parent_id=>wwv_flow_api.id(1299324755504130657)
,p_short_name=>'Filtering using Classic Report'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2666066053135921556)
,p_parent_id=>wwv_flow_api.id(1299324755504130657)
,p_short_name=>'Drill Down Reporting using Interactive Report'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2666450052645068442)
,p_parent_id=>wwv_flow_api.id(1299324755504130657)
,p_short_name=>'Highlighting using Interactive Reports'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(3043109572667763790)
,p_parent_id=>wwv_flow_api.id(1299324755504130657)
,p_short_name=>'Format Masks using Interactive Reports'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(3152529252596142369)
,p_parent_id=>0
,p_short_name=>'Home'
,p_link=>'f?p=&FLOW_ID.:10:&SESSION.'
,p_page_id=>10
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(3241271667163733287)
,p_short_name=>'Help'
,p_link=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:::'
,p_page_id=>14
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(6272077709391456983)
,p_parent_id=>0
,p_short_name=>'Interactive Report'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_api.component_end;
end;
/
