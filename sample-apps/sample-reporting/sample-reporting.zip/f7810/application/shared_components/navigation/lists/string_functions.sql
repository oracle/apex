prompt --application/shared_components/navigation/lists/string_functions
begin
--   Manifest
--     LIST: String Functions
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(1299831547803494250)
,p_name=>'String Functions'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1299831755814494250)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'substr()'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::P27_FUNCTION:SUBSTR:'
,p_list_item_current_type=>'EXPRESSION'
,p_list_item_current_for_pages=>':P27_FUNCTION = ''SUBSTR'''
,p_list_item_current_language=>'PLSQL'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1299832054059494250)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'instr()'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::P27_FUNCTION:INSTR:'
,p_list_item_current_type=>'EXPRESSION'
,p_list_item_current_for_pages=>':P27_FUNCTION = ''INSTR'''
,p_list_item_current_language=>'PLSQL'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1299832368117494251)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'nvl()'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::P27_FUNCTION:NVL:'
,p_list_item_current_type=>'EXPRESSION'
,p_list_item_current_for_pages=>':P27_FUNCTION = ''NVL'''
,p_list_item_current_language=>'PLSQL'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1299832675098494251)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'nvl2()'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::P27_FUNCTION:NVL2:'
,p_list_item_current_type=>'EXPRESSION'
,p_list_item_current_for_pages=>':P27_FUNCTION = ''NVL2'''
,p_list_item_current_language=>'PLSQL'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1299832955805494251)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'coalesce()'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::P27_FUNCTION:COALESCE:'
,p_list_item_current_type=>'EXPRESSION'
,p_list_item_current_for_pages=>':P27_FUNCTION = ''COALESCE'''
,p_list_item_current_language=>'PLSQL'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1299837071660503091)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'replace()'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::P27_FUNCTION:REPLACE:'
,p_list_item_current_type=>'EXPRESSION'
,p_list_item_current_for_pages=>':P27_FUNCTION = ''REPLACE'''
,p_list_item_current_language=>'PLSQL'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1299837272070503091)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'trim()'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::P27_FUNCTION:TRIM:'
,p_list_item_current_type=>'EXPRESSION'
,p_list_item_current_for_pages=>':P27_FUNCTION = ''TRIM'''
,p_list_item_current_language=>'PLSQL'
);
wwv_flow_api.component_end;
end;
/
