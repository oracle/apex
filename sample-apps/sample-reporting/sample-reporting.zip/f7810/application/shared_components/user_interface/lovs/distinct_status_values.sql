prompt --application/shared_components/user_interface/lovs/distinct_status_values
begin
--   Manifest
--     DISTINCT STATUS VALUES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2663570071138541881)
,p_lov_name=>'DISTINCT STATUS VALUES'
,p_lov_query=>'select distinct status d, status r from EBA_DEMO_IR_PROJECTS order by 1'
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1089078416
);
wwv_flow_imp.component_end;
end;
/
