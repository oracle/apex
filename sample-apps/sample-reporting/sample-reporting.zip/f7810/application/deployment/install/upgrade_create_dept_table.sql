prompt --application/deployment/install/upgrade_create_dept_table
begin
--   Manifest
--     INSTALL: UPGRADE-Create Dept Table
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-13'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(1299805178391010970)
,p_install_id=>wwv_flow_api.id(2548543548023083180)
,p_name=>'Create Dept Table'
,p_sequence=>10
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select table_name',
'from user_tables',
'where table_name = ''EBA_DEMO_IR_DEPT'''))
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table eba_demo_ir_dept (',
'    deptno  NUMBER(2) not null',
'                        constraint eba_demo_ir_dept_pk',
'                        primary key,',
'    dname   VARCHAR2(14),',
'    loc     VARCHAR2(13)',
')',
'/',
'insert into eba_demo_ir_dept (DEPTNO,DNAME,LOC) values (10,''ACCOUNTING'',''NEW YORK'');',
'insert into eba_demo_ir_dept (DEPTNO,DNAME,LOC) values (20,''RESEARCH'',''DALLAS'');',
'insert into eba_demo_ir_dept (DEPTNO,DNAME,LOC) values (30,''SALES'',''CHICAGO'');',
'insert into eba_demo_ir_dept (DEPTNO,DNAME,LOC) values (40,''OPERATIONS'',''BOSTON'');',
'',
'commit;',
'',
''))
);
wwv_flow_api.component_end;
end;
/
