prompt --application/deployment/install/upgrade_refresh_data
begin
--   Manifest
--     INSTALL: UPGRADE-Refresh Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7810
,p_default_id_offset=>1566231327207194
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2582954291783346819)
,p_install_id=>wwv_flow_imp.id(2562539889212995876)
,p_name=>'Refresh Data'
,p_sequence=>40
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'EBA_DEMO_IR_DATA;',
'commit;',
'end;',
'/',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
