prompt --application/deployment/install/install_create_tables
begin
--   Manifest
--     INSTALL: INSTALL-Create Tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7860
,p_default_id_offset=>11438353329529351
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '------------------------------------------------------------'||wwv_flow.LF||
'-- Demo Project Status table'||wwv_flow.LF||
'----------';
wwv_flow_imp.g_varchar2_table(2) := '-------------------------------------------------'||wwv_flow.LF||
'create table eba_demo_md_status ('||wwv_flow.LF||
'    cd          ';
wwv_flow_imp.g_varchar2_table(3) := '        varchar2(15)        not null'||wwv_flow.LF||
'                        constraint eba_demo_md_status_pk '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(4) := '                   primary key,'||wwv_flow.LF||
'    description         varchar2(255) not null,'||wwv_flow.LF||
'    display_order   ';
wwv_flow_imp.g_varchar2_table(5) := '    number not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                 timestamp with time zone  not null,'||wwv_flow.LF||
'    crea';
wwv_flow_imp.g_varchar2_table(6) := 'ted_by              varchar2(255)                   not null,'||wwv_flow.LF||
'    updated                 timestamp ';
wwv_flow_imp.g_varchar2_table(7) := 'with time zone  not null,'||wwv_flow.LF||
'    updated_by              varchar2(255)                   not null )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(8) := 'create or replace trigger biu_eba_demo_md_status'||wwv_flow.LF||
'    before insert or update on eba_demo_md_status'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(9) := '   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := current_timestamp;'||wwv_flow.LF||
'        :n';
wwv_flow_imp.g_varchar2_table(10) := 'ew.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.cd         := upper(:new.cd);'||wwv_flow.LF||
'    :';
wwv_flow_imp.g_varchar2_table(11) := 'new.updated    := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-----';
wwv_flow_imp.g_varchar2_table(12) := '-------------------------------------------------------'||wwv_flow.LF||
'-- Demo Project Team Members table'||wwv_flow.LF||
'---------';
wwv_flow_imp.g_varchar2_table(13) := '--------------------------------------------------'||wwv_flow.LF||
'create table eba_demo_md_team_members ('||wwv_flow.LF||
'    id   ';
wwv_flow_imp.g_varchar2_table(14) := '               number        not null'||wwv_flow.LF||
'                        constraint eba_demo_md_team_members_pk';
wwv_flow_imp.g_varchar2_table(15) := ' '||wwv_flow.LF||
'                        primary key,'||wwv_flow.LF||
'    username            varchar2(255) not null,'||wwv_flow.LF||
'    full_name';
wwv_flow_imp.g_varchar2_table(16) := '           varchar2(255) not null,'||wwv_flow.LF||
'    email               varchar2(255),'||wwv_flow.LF||
'    profile             va';
wwv_flow_imp.g_varchar2_table(17) := 'rchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                 timestamp with time zone  not null,'||wwv_flow.LF||
'    created_by ';
wwv_flow_imp.g_varchar2_table(18) := '             varchar2(255)                   not null,'||wwv_flow.LF||
'    updated                 timestamp with ti';
wwv_flow_imp.g_varchar2_table(19) := 'me zone  not null,'||wwv_flow.LF||
'    updated_by              varchar2(255)                   not null )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter t';
wwv_flow_imp.g_varchar2_table(20) := 'able eba_demo_md_team_members add constraint eba_demo_md_team_members_uk'||wwv_flow.LF||
'  unique (username);'||wwv_flow.LF||
''||wwv_flow.LF||
'creat';
wwv_flow_imp.g_varchar2_table(21) := 'e or replace trigger biu_eba_demo_md_team_members'||wwv_flow.LF||
'    before insert or update on eba_demo_md_team_me';
wwv_flow_imp.g_varchar2_table(22) := 'mbers'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(), ''X';
wwv_flow_imp.g_varchar2_table(23) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := cur';
wwv_flow_imp.g_varchar2_table(24) := 'rent_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.username ';
wwv_flow_imp.g_varchar2_table(25) := '  := upper(:new.username);'||wwv_flow.LF||
'    :new.updated    := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(wwv_';
wwv_flow_imp.g_varchar2_table(26) := 'flow.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-----------------------------------------------------------'||wwv_flow.LF||
'-- Demo Proje';
wwv_flow_imp.g_varchar2_table(27) := 'cts table'||wwv_flow.LF||
'-----------------------------------------------------------'||wwv_flow.LF||
'create table eba_demo_md_proje';
wwv_flow_imp.g_varchar2_table(28) := 'cts ('||wwv_flow.LF||
'    id                   number        not null'||wwv_flow.LF||
'                         constraint eba_demo_m';
wwv_flow_imp.g_varchar2_table(29) := 'd_projects_pk '||wwv_flow.LF||
'                         primary key,'||wwv_flow.LF||
'    project_lead         number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    nam';
wwv_flow_imp.g_varchar2_table(30) := 'e                 varchar2(255) not null,'||wwv_flow.LF||
'    description          varchar2(4000),'||wwv_flow.LF||
'    status_cd    ';
wwv_flow_imp.g_varchar2_table(31) := '        varchar2(15) not null,'||wwv_flow.LF||
'    completed_date       date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created              timest';
wwv_flow_imp.g_varchar2_table(32) := 'amp with time zone  not null,'||wwv_flow.LF||
'    created_by           varchar2(255)                   not null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(33) := ' updated              timestamp with time zone  not null,'||wwv_flow.LF||
'    updated_by           varchar2(255)    ';
wwv_flow_imp.g_varchar2_table(34) := '               not null )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_md_projects add constraint eba_demo_md_projects_uk';
wwv_flow_imp.g_varchar2_table(35) := ''||wwv_flow.LF||
'  unique (name);'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_md_projects add constraint eba_demo_md_team_member_fk'||wwv_flow.LF||
'  fore';
wwv_flow_imp.g_varchar2_table(36) := 'ign key (project_lead) references eba_demo_md_team_members (id)'||wwv_flow.LF||
'  on delete set null;'||wwv_flow.LF||
''||wwv_flow.LF||
'create index ';
wwv_flow_imp.g_varchar2_table(37) := 'eba_demo_md_project_idx on eba_demo_md_projects (project_lead);'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_md_projects ad';
wwv_flow_imp.g_varchar2_table(38) := 'd constraint eba_demo_md_status_fk'||wwv_flow.LF||
'  foreign key (status_cd) references eba_demo_md_status (cd)'||wwv_flow.LF||
'  on';
wwv_flow_imp.g_varchar2_table(39) := ' delete set null;'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_md_status_idx on eba_demo_md_projects (status_cd);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create';
wwv_flow_imp.g_varchar2_table(40) := ' or replace trigger biu_eba_demo_md_projects'||wwv_flow.LF||
'    before insert or update on eba_demo_md_projects'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(41) := ' for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(), ''XXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(42) := 'XXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := current_time';
wwv_flow_imp.g_varchar2_table(43) := 'stamp;'||wwv_flow.LF||
'        :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated    := curr';
wwv_flow_imp.g_varchar2_table(44) := 'ent_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'---------------------------';
wwv_flow_imp.g_varchar2_table(45) := '--------------------------------'||wwv_flow.LF||
'-- Demo Project Milestones table'||wwv_flow.LF||
'----------------------------------';
wwv_flow_imp.g_varchar2_table(46) := '-------------------------'||wwv_flow.LF||
'create table eba_demo_md_milestones ('||wwv_flow.LF||
'    id                   number     ';
wwv_flow_imp.g_varchar2_table(47) := '   not null'||wwv_flow.LF||
'                         constraint eba_demo_md_milestones_pk '||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(48) := 'primary key,'||wwv_flow.LF||
'    project_id           number not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    name                 varchar2(255)';
wwv_flow_imp.g_varchar2_table(49) := ' not null,'||wwv_flow.LF||
'    description          varchar2(4000),'||wwv_flow.LF||
'    due_date             date not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(50) := '   created              timestamp with time zone  not null,'||wwv_flow.LF||
'    created_by           varchar2(255)  ';
wwv_flow_imp.g_varchar2_table(51) := '                 not null,'||wwv_flow.LF||
'    updated              timestamp with time zone  not null,'||wwv_flow.LF||
'    updated_';
wwv_flow_imp.g_varchar2_table(52) := 'by           varchar2(255)                   not null )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_md_milestones add co';
wwv_flow_imp.g_varchar2_table(53) := 'nstraint eba_demo_md_mstone_md_fk'||wwv_flow.LF||
'  foreign key (project_id) references eba_demo_md_projects (id) '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(54) := ' on delete cascade;'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_md_mstone_prj_idx on eba_demo_md_milestones (project_id);';
wwv_flow_imp.g_varchar2_table(55) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_demo_md_milestones'||wwv_flow.LF||
'    before insert or update on eba_demo_md_mi';
wwv_flow_imp.g_varchar2_table(56) := 'lestones'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(),';
wwv_flow_imp.g_varchar2_table(57) := ' ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := ';
wwv_flow_imp.g_varchar2_table(58) := 'current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.update';
wwv_flow_imp.g_varchar2_table(59) := 'd    := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'---------------';
wwv_flow_imp.g_varchar2_table(60) := '--------------------------------------------'||wwv_flow.LF||
'-- Demo Project Tasks table'||wwv_flow.LF||
'---------------------------';
wwv_flow_imp.g_varchar2_table(61) := '--------------------------------'||wwv_flow.LF||
'create table eba_demo_md_tasks ('||wwv_flow.LF||
'    id                   number   ';
wwv_flow_imp.g_varchar2_table(62) := '     not null'||wwv_flow.LF||
'                         constraint eba_demo_md_tasks_pk '||wwv_flow.LF||
'                         pri';
wwv_flow_imp.g_varchar2_table(63) := 'mary key,'||wwv_flow.LF||
'    project_id           number not null,'||wwv_flow.LF||
'    milestone_id         number,'||wwv_flow.LF||
'    assignee   ';
wwv_flow_imp.g_varchar2_table(64) := '          number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    name                 varchar2(255) not null,'||wwv_flow.LF||
'    description          v';
wwv_flow_imp.g_varchar2_table(65) := 'archar2(4000),'||wwv_flow.LF||
'    start_date           date not null,'||wwv_flow.LF||
'    end_date             date not null,'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(66) := 's_complete_yn       varchar2(1),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                 timestamp with time zone  not nu';
wwv_flow_imp.g_varchar2_table(67) := 'll,'||wwv_flow.LF||
'    created_by              varchar2(255)                   not null,'||wwv_flow.LF||
'    updated               ';
wwv_flow_imp.g_varchar2_table(68) := '  timestamp with time zone  not null,'||wwv_flow.LF||
'    updated_by              varchar2(255)                   no';
wwv_flow_imp.g_varchar2_table(69) := 't null )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_md_tasks add constraint eba_demo_md_tasks_uk'||wwv_flow.LF||
'  unique (project_id, ';
wwv_flow_imp.g_varchar2_table(70) := 'name);'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_md_tasks add constraint eba_demo_md_task_project_fk'||wwv_flow.LF||
'  foreign key (proj';
wwv_flow_imp.g_varchar2_table(71) := 'ect_id) references eba_demo_md_projects (id) '||wwv_flow.LF||
'  on delete cascade;'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_md_task_pr';
wwv_flow_imp.g_varchar2_table(72) := 'oject_idx on eba_demo_md_tasks (project_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_md_tasks add constraint eba_demo_';
wwv_flow_imp.g_varchar2_table(73) := 'md_task_mstone_fk'||wwv_flow.LF||
'  foreign key (milestone_id) references eba_demo_md_milestones (id) '||wwv_flow.LF||
'  on delete s';
wwv_flow_imp.g_varchar2_table(74) := 'et null;'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_md_task_mstone_idx on eba_demo_md_tasks (milestone_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table';
wwv_flow_imp.g_varchar2_table(75) := ' eba_demo_md_tasks add constraint eba_demo_md_task_team_mem_fk'||wwv_flow.LF||
'  foreign key (assignee) references e';
wwv_flow_imp.g_varchar2_table(76) := 'ba_demo_md_team_members (id) '||wwv_flow.LF||
'  on delete set null;'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_md_task_team_mm_idx on eb';
wwv_flow_imp.g_varchar2_table(77) := 'a_demo_md_tasks (assignee);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_demo_md_tasks'||wwv_flow.LF||
'    before insert or up';
wwv_flow_imp.g_varchar2_table(78) := 'date on eba_demo_md_tasks'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := to_n';
wwv_flow_imp.g_varchar2_table(79) := 'umber(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :n';
wwv_flow_imp.g_varchar2_table(80) := 'ew.created    := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(81) := ';'||wwv_flow.LF||
'    :new.updated    := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(82) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'-----------------------------------------------------------'||wwv_flow.LF||
'-- Demo Project Task ToDos table'||wwv_flow.LF||
'-----';
wwv_flow_imp.g_varchar2_table(83) := '------------------------------------------------------'||wwv_flow.LF||
'create table eba_demo_md_task_todos ('||wwv_flow.LF||
'    id ';
wwv_flow_imp.g_varchar2_table(84) := '                number        not null'||wwv_flow.LF||
'                         constraint eba_demo_md_task_todos_pk';
wwv_flow_imp.g_varchar2_table(85) := ' '||wwv_flow.LF||
'                         primary key,'||wwv_flow.LF||
'    project_id           number not null,'||wwv_flow.LF||
'    task_id       ';
wwv_flow_imp.g_varchar2_table(86) := '       number not null,'||wwv_flow.LF||
'    assignee             number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    name                 varchar2(25';
wwv_flow_imp.g_varchar2_table(87) := '5) not null,'||wwv_flow.LF||
'    description          varchar2(4000),'||wwv_flow.LF||
'    is_complete_yn       varchar2(1),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(88) := '   created                 timestamp with time zone  not null,'||wwv_flow.LF||
'    created_by              varchar2(';
wwv_flow_imp.g_varchar2_table(89) := '255)                   not null,'||wwv_flow.LF||
'    updated                 timestamp with time zone  not null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(90) := ' updated_by              varchar2(255)                   not null )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_md_task_';
wwv_flow_imp.g_varchar2_table(91) := 'todos add constraint eba_demo_md_task_todo_prj_fk'||wwv_flow.LF||
'  foreign key (project_id) references eba_demo_md_';
wwv_flow_imp.g_varchar2_table(92) := 'projects (id) '||wwv_flow.LF||
'  on delete cascade;'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_md_tsk_todo_prj_idx  on eba_demo_md_task_';
wwv_flow_imp.g_varchar2_table(93) := 'todos (project_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_md_task_todos add constraint eba_demo_md_task_todo_tsk_fk'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(94) := '  foreign key (task_id) references eba_demo_md_tasks (id) '||wwv_flow.LF||
'  on delete cascade;'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_de';
wwv_flow_imp.g_varchar2_table(95) := 'mo_md_tsk_todo_tsk_idx on eba_demo_md_task_todos (task_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_md_task_todos add ';
wwv_flow_imp.g_varchar2_table(96) := 'constraint eba_demo_md_task_todo_tm_fk'||wwv_flow.LF||
'  foreign key (assignee) references eba_demo_md_team_members ';
wwv_flow_imp.g_varchar2_table(97) := '(id) '||wwv_flow.LF||
'  on delete set null;'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_md_task_todo_tm_idx on eba_demo_md_task_todos (as';
wwv_flow_imp.g_varchar2_table(98) := 'signee);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_demo_md_task_todos'||wwv_flow.LF||
'    before insert or update on eba_de';
wwv_flow_imp.g_varchar2_table(99) := 'mo_md_task_todos'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := to_number(sys';
wwv_flow_imp.g_varchar2_table(100) := '_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.create';
wwv_flow_imp.g_varchar2_table(101) := 'd    := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :ne';
wwv_flow_imp.g_varchar2_table(102) := 'w.updated    := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-------';
wwv_flow_imp.g_varchar2_table(103) := '----------------------------------------------------'||wwv_flow.LF||
'-- Demo Project Task Links table'||wwv_flow.LF||
'--------------';
wwv_flow_imp.g_varchar2_table(104) := '---------------------------------------------'||wwv_flow.LF||
'create table eba_demo_md_task_links ('||wwv_flow.LF||
'    id          ';
wwv_flow_imp.g_varchar2_table(105) := '       number        not null'||wwv_flow.LF||
'                         constraint eba_demo_md_task_links_pk '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(106) := '                  primary key,'||wwv_flow.LF||
'    project_id         number not null,'||wwv_flow.LF||
'    task_id            number';
wwv_flow_imp.g_varchar2_table(107) := ' not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    link_type          varchar2(20) not null,'||wwv_flow.LF||
'    url                varchar2(255)';
wwv_flow_imp.g_varchar2_table(108) := ','||wwv_flow.LF||
'    application_id     number,'||wwv_flow.LF||
'    application_page   number,'||wwv_flow.LF||
'    description        varchar2(4000';
wwv_flow_imp.g_varchar2_table(109) := '),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                 timestamp with time zone  not null,'||wwv_flow.LF||
'    created_by            ';
wwv_flow_imp.g_varchar2_table(110) := '  varchar2(255)                   not null,'||wwv_flow.LF||
'    updated                 timestamp with time zone  no';
wwv_flow_imp.g_varchar2_table(111) := 't null,'||wwv_flow.LF||
'    updated_by              varchar2(255)                   not null )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_de';
wwv_flow_imp.g_varchar2_table(112) := 'mo_md_task_links add constraint eba_demo_md_task_link_prj_fk'||wwv_flow.LF||
'  foreign key (project_id) references e';
wwv_flow_imp.g_varchar2_table(113) := 'ba_demo_md_projects (id) '||wwv_flow.LF||
'  on delete cascade;'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_md_tsk_link_prj_idx  on eba_de';
wwv_flow_imp.g_varchar2_table(114) := 'mo_md_task_links (project_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_md_task_links add constraint eba_demo_md_task_l';
wwv_flow_imp.g_varchar2_table(115) := 'ink_tsk_fk'||wwv_flow.LF||
'  foreign key (task_id) references eba_demo_md_tasks (id) '||wwv_flow.LF||
'  on delete cascade;'||wwv_flow.LF||
''||wwv_flow.LF||
'create i';
wwv_flow_imp.g_varchar2_table(116) := 'ndex eba_demo_md_tsk_link_tsk_idx on eba_demo_md_task_links (task_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_md_task';
wwv_flow_imp.g_varchar2_table(117) := '_links add constraint eba_demo_md_task_link_lty_ch '||wwv_flow.LF||
'   check ( link_type in (''URL'',''Application''));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(118) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_demo_md_task_links'||wwv_flow.LF||
'    before insert or update on eba_demo_md_ta';
wwv_flow_imp.g_varchar2_table(119) := 'sk_links'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(),';
wwv_flow_imp.g_varchar2_table(120) := ' ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := ';
wwv_flow_imp.g_varchar2_table(121) := 'current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.update';
wwv_flow_imp.g_varchar2_table(122) := 'd    := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'---------------';
wwv_flow_imp.g_varchar2_table(123) := '--------------------------------------------'||wwv_flow.LF||
'-- Demo Project Comments table'||wwv_flow.LF||
'------------------------';
wwv_flow_imp.g_varchar2_table(124) := '-----------------------------------'||wwv_flow.LF||
'create table eba_demo_md_comments ('||wwv_flow.LF||
'    id                   num';
wwv_flow_imp.g_varchar2_table(125) := 'ber        not null'||wwv_flow.LF||
'                         constraint eba_demo_md_comments_pk '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(126) := '      primary key,'||wwv_flow.LF||
'    project_id           number not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    comment_text         varchar';
wwv_flow_imp.g_varchar2_table(127) := '2(4000) not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                 timestamp with time zone  not null,'||wwv_flow.LF||
'    created';
wwv_flow_imp.g_varchar2_table(128) := '_by              varchar2(255)                   not null,'||wwv_flow.LF||
'    updated                 timestamp wit';
wwv_flow_imp.g_varchar2_table(129) := 'h time zone  not null,'||wwv_flow.LF||
'    updated_by              varchar2(255)                   not null )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alt';
wwv_flow_imp.g_varchar2_table(130) := 'er table eba_demo_md_comments add constraint eba_demo_md_comment_md_fk'||wwv_flow.LF||
'  foreign key (project_id) re';
wwv_flow_imp.g_varchar2_table(131) := 'ferences eba_demo_md_projects (id) '||wwv_flow.LF||
'  on delete cascade;'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_md_comment_md_idx on';
wwv_flow_imp.g_varchar2_table(132) := ' eba_demo_md_comments (project_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_demo_md_comments'||wwv_flow.LF||
'    before i';
wwv_flow_imp.g_varchar2_table(133) := 'nsert or update on eba_demo_md_comments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :';
wwv_flow_imp.g_varchar2_table(134) := 'new.id := to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if inserting t';
wwv_flow_imp.g_varchar2_table(135) := 'hen'||wwv_flow.LF||
'        :new.created    := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(wwv_flow.g_user,use';
wwv_flow_imp.g_varchar2_table(136) := 'r);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated    := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(wwv_flow.g_user';
wwv_flow_imp.g_varchar2_table(137) := ',user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(27396636214562055171)
,p_install_id=>wwv_flow_imp.id(49288120094371048011)
,p_name=>'Create Tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
