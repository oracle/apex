prompt --application/deployment/install/install_create_data_package
begin
--   Manifest
--     INSTALL: INSTALL-Create Data Package
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7860
,p_default_id_offset=>11438353329529351
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_demo_md_data_pkg as'||wwv_flow.LF||
'  function varchar2_to_blob(p_varchar2_tab in dbms';
wwv_flow_imp.g_varchar2_table(2) := '_sql.varchar2_table) return blob;'||wwv_flow.LF||
'  procedure load_sample_data;'||wwv_flow.LF||
'  procedure remove_sample_data;'||wwv_flow.LF||
'end ';
wwv_flow_imp.g_varchar2_table(3) := 'eba_demo_md_data_pkg; '||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package body eba_demo_md_data_pkg as '||wwv_flow.LF||
'  function varchar';
wwv_flow_imp.g_varchar2_table(4) := '2_to_blob(p_varchar2_tab in dbms_sql.varchar2_table) '||wwv_flow.LF||
'    return blob '||wwv_flow.LF||
'  is '||wwv_flow.LF||
'    l_blob blob; '||wwv_flow.LF||
'    l';
wwv_flow_imp.g_varchar2_table(5) := '_raw  raw(500); '||wwv_flow.LF||
'    l_size number; '||wwv_flow.LF||
'  begin '||wwv_flow.LF||
'    dbms_lob.createtemporary(l_blob, true, dbms_lob.se';
wwv_flow_imp.g_varchar2_table(6) := 'ssion); '||wwv_flow.LF||
'    for i in 1 .. p_varchar2_tab.count loop '||wwv_flow.LF||
'      l_size := length(p_varchar2_tab(i)) / 2;';
wwv_flow_imp.g_varchar2_table(7) := ' '||wwv_flow.LF||
'      dbms_lob.writeappend(l_blob, l_size, hextoraw(p_varchar2_tab(i))); '||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
'    retur';
wwv_flow_imp.g_varchar2_table(8) := 'n l_blob; '||wwv_flow.LF||
'  exception '||wwv_flow.LF||
'    when others then '||wwv_flow.LF||
'      dbms_lob.close(l_blob); '||wwv_flow.LF||
'  end varchar2_to_blob;';
wwv_flow_imp.g_varchar2_table(9) := '   '||wwv_flow.LF||
' '||wwv_flow.LF||
'  procedure load_sample_data is '||wwv_flow.LF||
'    i               dbms_sql.varchar2_table; '||wwv_flow.LF||
'    j          ';
wwv_flow_imp.g_varchar2_table(10) := '     dbms_sql.varchar2_table default wwv_flow_api.empty_varchar2_table; '||wwv_flow.LF||
'    l_blob          blob; '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(11) := '    l_full_name         varchar2(255); '||wwv_flow.LF||
'    l_email             varchar2(255); '||wwv_flow.LF||
'    l_add_days      ';
wwv_flow_imp.g_varchar2_table(12) := '    number; '||wwv_flow.LF||
'  begin '||wwv_flow.LF||
'    -- Remove any data currenlty in the tables '||wwv_flow.LF||
'    remove_sample_data; '||wwv_flow.LF||
' '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(13) := ' ---------------------------------- '||wwv_flow.LF||
'    --<< Load statuses >>-- '||wwv_flow.LF||
'    ------------------------------';
wwv_flow_imp.g_varchar2_table(14) := '---- '||wwv_flow.LF||
'    delete from eba_demo_md_status; '||wwv_flow.LF||
'    insert into eba_demo_md_status (cd, description, disp';
wwv_flow_imp.g_varchar2_table(15) := 'lay_order) '||wwv_flow.LF||
'      values (''ASSIGNED'', ''Assigned'', 1); '||wwv_flow.LF||
'    insert into eba_demo_md_status (cd, descr';
wwv_flow_imp.g_varchar2_table(16) := 'iption, display_order) '||wwv_flow.LF||
'      values (''IN-PROGRESS'', ''In-Progress'', 2); '||wwv_flow.LF||
'    insert into eba_demo_md';
wwv_flow_imp.g_varchar2_table(17) := '_status (cd, description, display_order) '||wwv_flow.LF||
'      values (''COMPLETED'', ''Completed'', 3);'||wwv_flow.LF||
'      '||wwv_flow.LF||
'    ---';
wwv_flow_imp.g_varchar2_table(18) := '------------------------------------- '||wwv_flow.LF||
'    --<< Load remaining 12 Team Members >>--   '||wwv_flow.LF||
'    ---------';
wwv_flow_imp.g_varchar2_table(19) := '------------------------------- '||wwv_flow.LF||
'    -- Load Team Member 1 '||wwv_flow.LF||
'    insert into eba_demo_md_team_members';
wwv_flow_imp.g_varchar2_table(20) := '  '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , full_name '||wwv_flow.LF||
'       , username  '||wwv_flow.LF||
'       , email     '||wwv_flow.LF||
'       , profile   '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(21) := '  ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  1 '||wwv_flow.LF||
'       , ''Lucille Beatie'' '||wwv_flow.LF||
'       , ''lbeatie'' '||wwv_flow.LF||
'       , ''lucy.beattie@e';
wwv_flow_imp.g_varchar2_table(22) := 'mail.com'' '||wwv_flow.LF||
'       , ''I have extensive experience running development teams. If I can''''t bring in a p';
wwv_flow_imp.g_varchar2_table(23) := 'roject on time and on budget it can''''t be done.'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'     '||wwv_flow.LF||
'    -- Load Team Member 2 '||wwv_flow.LF||
'    ins';
wwv_flow_imp.g_varchar2_table(24) := 'ert into eba_demo_md_team_members  '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , full_name '||wwv_flow.LF||
'       , username  '||wwv_flow.LF||
'       , em';
wwv_flow_imp.g_varchar2_table(25) := 'ail     '||wwv_flow.LF||
'       , profile   '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  2 '||wwv_flow.LF||
'       , ''Nina Herschel'' '||wwv_flow.LF||
'       , ''ni';
wwv_flow_imp.g_varchar2_table(26) := 'na'' '||wwv_flow.LF||
'       , ''nina.herschel@email.com'' '||wwv_flow.LF||
'       , ''I''''m a consumate team player who likes to explore';
wwv_flow_imp.g_varchar2_table(27) := ' and learn new things. My belief is to work hard and play hard.'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'     '||wwv_flow.LF||
'    -- Load Team M';
wwv_flow_imp.g_varchar2_table(28) := 'ember 3 '||wwv_flow.LF||
'    insert into eba_demo_md_team_members  '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , full_name '||wwv_flow.LF||
'       , userna';
wwv_flow_imp.g_varchar2_table(29) := 'me  '||wwv_flow.LF||
'       , email     '||wwv_flow.LF||
'       , profile   '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  3 '||wwv_flow.LF||
'       , ''Tameka Hall''';
wwv_flow_imp.g_varchar2_table(30) := ' '||wwv_flow.LF||
'       , ''thall'' '||wwv_flow.LF||
'       , ''tamika.hall@email.com'' '||wwv_flow.LF||
'       , ''I am all business and thrive on deve';
wwv_flow_imp.g_varchar2_table(31) := 'loping the lowest-level code. Point me at some obtuse security bug or framework API, step back, send';
wwv_flow_imp.g_varchar2_table(32) := ' in pizza and coke (not diet coke - YUK) occassionally, and consider it done!'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'     '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(33) := '-- Load Team Member 4 '||wwv_flow.LF||
'    insert into eba_demo_md_team_members  '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , full_name '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(34) := '      , username  '||wwv_flow.LF||
'       , email     '||wwv_flow.LF||
'       , profile   '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  4 '||wwv_flow.LF||
'       ,';
wwv_flow_imp.g_varchar2_table(35) := ' ''Eva Jelinek'' '||wwv_flow.LF||
'       , ''eva'' '||wwv_flow.LF||
'       , ''eva.jelinek@email.com'' '||wwv_flow.LF||
'       , ''I will tell you directly';
wwv_flow_imp.g_varchar2_table(36) := ' what I think and expect you to tell me the same. If you are sensitive then it may be best you don''''';
wwv_flow_imp.g_varchar2_table(37) := 't talk to me. '' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'     '||wwv_flow.LF||
'    -- Load Team Member 5 '||wwv_flow.LF||
'    insert into eba_demo_md_team_members';
wwv_flow_imp.g_varchar2_table(38) := '  '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , full_name '||wwv_flow.LF||
'       , username  '||wwv_flow.LF||
'       , email     '||wwv_flow.LF||
'       , profile   '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(39) := '  ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  5 '||wwv_flow.LF||
'       , ''Mei Yu'' '||wwv_flow.LF||
'       , ''meiyu'' '||wwv_flow.LF||
'       , ''mei.yu@email.com'' '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(40) := '  , ''I have extensive experience in all aspects of application development. If you need help then co';
wwv_flow_imp.g_varchar2_table(41) := 'me and see me.'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'     '||wwv_flow.LF||
'    -- Load Team Member 6 '||wwv_flow.LF||
'    insert into eba_demo_md_team_members';
wwv_flow_imp.g_varchar2_table(42) := '  '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , full_name '||wwv_flow.LF||
'       , username  '||wwv_flow.LF||
'       , email     '||wwv_flow.LF||
'       , profile   '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(43) := '  ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  6 '||wwv_flow.LF||
'       , ''Madison Smith'' '||wwv_flow.LF||
'       , ''mady'' '||wwv_flow.LF||
'       , ''madison.smith@emai';
wwv_flow_imp.g_varchar2_table(44) := 'l.com'' '||wwv_flow.LF||
'       , ''Mady to my friends - I love being creative and coming up with beautiful solutions.';
wwv_flow_imp.g_varchar2_table(45) := ''' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'     '||wwv_flow.LF||
'    -- Load Team Member 7 '||wwv_flow.LF||
'    insert into eba_demo_md_team_members  '||wwv_flow.LF||
'      (  id';
wwv_flow_imp.g_varchar2_table(46) := ' '||wwv_flow.LF||
'       , full_name '||wwv_flow.LF||
'       , username  '||wwv_flow.LF||
'       , email     '||wwv_flow.LF||
'       , profile   '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    value';
wwv_flow_imp.g_varchar2_table(47) := 's '||wwv_flow.LF||
'      (  7 '||wwv_flow.LF||
'       , ''Tyson King'' '||wwv_flow.LF||
'       , ''tking'' '||wwv_flow.LF||
'       , ''alonso.king@email.com'' '||wwv_flow.LF||
'       , ''';
wwv_flow_imp.g_varchar2_table(48) := 'No problem too big, no problem too small!'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'     '||wwv_flow.LF||
'    -- Load Team Member 8 '||wwv_flow.LF||
'    insert in';
wwv_flow_imp.g_varchar2_table(49) := 'to eba_demo_md_team_members  '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , full_name '||wwv_flow.LF||
'       , username  '||wwv_flow.LF||
'       , email   ';
wwv_flow_imp.g_varchar2_table(50) := '  '||wwv_flow.LF||
'       , profile   '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  8 '||wwv_flow.LF||
'       , ''Daniel James Lee'' '||wwv_flow.LF||
'       , ''dj'' '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(51) := '       , ''daniel.lee@email.com'' '||wwv_flow.LF||
'       , ''I am a DJ, I am what I say. If you ask me a question and ';
wwv_flow_imp.g_varchar2_table(52) := 'I don''''t answer, it is not because I''''m rude, it is probably because I have my earbuds in and am roc';
wwv_flow_imp.g_varchar2_table(53) := 'king out to some gangsta rap.'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'     '||wwv_flow.LF||
'    -- Load Team Member 9 '||wwv_flow.LF||
'    insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(54) := 'md_team_members  '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , full_name '||wwv_flow.LF||
'       , username  '||wwv_flow.LF||
'       , email     '||wwv_flow.LF||
'       , ';
wwv_flow_imp.g_varchar2_table(55) := 'profile   '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  9 '||wwv_flow.LF||
'       , ''Brock Shilling'' '||wwv_flow.LF||
'       , ''thebrock'' '||wwv_flow.LF||
'       ,';
wwv_flow_imp.g_varchar2_table(56) := ' ''brock.shilling@email.com'' '||wwv_flow.LF||
'       , ''I am your man! Let me solve that for you.'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'     '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(57) := '   -- Load Team Member 10 '||wwv_flow.LF||
'    insert into eba_demo_md_team_members  '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , full_nam';
wwv_flow_imp.g_varchar2_table(58) := 'e '||wwv_flow.LF||
'       , username  '||wwv_flow.LF||
'       , email     '||wwv_flow.LF||
'       , profile   '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  10 '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(59) := '    , ''Miyazaki Yokohama'' '||wwv_flow.LF||
'       , ''miyazaki'' '||wwv_flow.LF||
'       , ''miyazaki.yokohama@email.com'' '||wwv_flow.LF||
'       , ''My';
wwv_flow_imp.g_varchar2_table(60) := ' motto is to lead by example. I run a tight ship where everyone knows where we are heading.'' '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(61) := '); '||wwv_flow.LF||
'     '||wwv_flow.LF||
'    -- Load Team Member 11 '||wwv_flow.LF||
'    insert into eba_demo_md_team_members  '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(62) := ' , full_name '||wwv_flow.LF||
'       , username  '||wwv_flow.LF||
'       , email     '||wwv_flow.LF||
'       , profile   '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(63) := ' (  11 '||wwv_flow.LF||
'       , ''Bernard Jackman'' '||wwv_flow.LF||
'       , ''bernie'' '||wwv_flow.LF||
'       , ''bernard.jackman@email.com'' '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(64) := ', ''I am a great believer in the fact there is no "i" in TEAM.'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'     '||wwv_flow.LF||
'    -- Load Team Mem';
wwv_flow_imp.g_varchar2_table(65) := 'ber 12 '||wwv_flow.LF||
'    insert into eba_demo_md_team_members  '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , full_name '||wwv_flow.LF||
'       , usernam';
wwv_flow_imp.g_varchar2_table(66) := 'e  '||wwv_flow.LF||
'       , email     '||wwv_flow.LF||
'       , profile   '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  12 '||wwv_flow.LF||
'       , ''Harold Young';
wwv_flow_imp.g_varchar2_table(67) := 'blood'' '||wwv_flow.LF||
'       , ''harry'' '||wwv_flow.LF||
'       , ''harold.youngblood@email.com'' '||wwv_flow.LF||
'       , ''Providing I have my soy ';
wwv_flow_imp.g_varchar2_table(68) := 'latte, falafel, and my MacBook - Bring It!'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'     '||wwv_flow.LF||
' '||wwv_flow.LF||
'    --*******************************';
wwv_flow_imp.g_varchar2_table(69) := '************-- '||wwv_flow.LF||
'    --*** Load Projects, Milestones and Tasks ***--  '||wwv_flow.LF||
'    --************************';
wwv_flow_imp.g_varchar2_table(70) := '*******************-- '||wwv_flow.LF||
'    -- Need to insert a project and all of its releated child records at once';
wwv_flow_imp.g_varchar2_table(71) := ' and then move to the next project '||wwv_flow.LF||
' '||wwv_flow.LF||
'    ----------------------------------- '||wwv_flow.LF||
'    --<< Determine th';
wwv_flow_imp.g_varchar2_table(72) := 'e data offset >>-- '||wwv_flow.LF||
'    ----------------------------------- '||wwv_flow.LF||
'    l_add_days := sysdate - to_date(''20';
wwv_flow_imp.g_varchar2_table(73) := '150101'',''YYYYMMDD''); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -------------------------- '||wwv_flow.LF||
'    --<< Insert Project 1 >>-- '||wwv_flow.LF||
'    --------';
wwv_flow_imp.g_varchar2_table(74) := '------------------ '||wwv_flow.LF||
'    insert into eba_demo_md_projects '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , descr';
wwv_flow_imp.g_varchar2_table(75) := 'iption '||wwv_flow.LF||
'       , project_lead '||wwv_flow.LF||
'       , completed_date '||wwv_flow.LF||
'       , status_cd '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'      values '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(76) := '     (  1 '||wwv_flow.LF||
'       , ''Configure Web Development Tool Environment'' '||wwv_flow.LF||
'       , ''Determine the hardware a';
wwv_flow_imp.g_varchar2_table(77) := 'nd software required to develop with Web development tool.'' '||wwv_flow.LF||
'       , 7 '||wwv_flow.LF||
'       , to_date(''20141205''';
wwv_flow_imp.g_varchar2_table(78) := ', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , ''COMPLETED'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Tasks for Project 1  '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(79) := '  insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name ';
wwv_flow_imp.g_varchar2_table(80) := ''||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       ,';
wwv_flow_imp.g_varchar2_table(81) := ' end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  51 '||wwv_flow.LF||
'       , 1 '||wwv_flow.LF||
'       , 7'||wwv_flow.LF||
'       , ''Identify Server Requir';
wwv_flow_imp.g_varchar2_table(82) := 'ements'' '||wwv_flow.LF||
'       , ''Determine which databases will be used to install Web development tool for Develo';
wwv_flow_imp.g_varchar2_table(83) := 'pment, QA, and Production.  '||wwv_flow.LF||
'          Also specify which Web Listeners will be used for the three e';
wwv_flow_imp.g_varchar2_table(84) := 'nvironments.'' '||wwv_flow.LF||
'       , null '||wwv_flow.LF||
'       , ''Y'' '||wwv_flow.LF||
'       , to_date(''20141201'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(85) := '      , to_date(''20141202'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(86) := '      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , m';
wwv_flow_imp.g_varchar2_table(87) := 'ilestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(88) := '     (  52 '||wwv_flow.LF||
'       , 1 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , ''Install Web development tool'' '||wwv_flow.LF||
'       , ''Install the l';
wwv_flow_imp.g_varchar2_table(89) := 'atest version of Web development tool from the vendor into the databases for Development, QA, and Pr';
wwv_flow_imp.g_varchar2_table(90) := 'oduction. '||wwv_flow.LF||
'          Note: For QA and Production, Web development tool should be configured as "run ';
wwv_flow_imp.g_varchar2_table(91) := 'time" only.'' '||wwv_flow.LF||
'       , null '||wwv_flow.LF||
'       , ''Y'' '||wwv_flow.LF||
'       , to_date(''20141203'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(92) := '     , to_date(''20141203'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_task_to';
wwv_flow_imp.g_varchar2_table(93) := 'dos'||wwv_flow.LF||
'      (  id'||wwv_flow.LF||
'       , project_id'||wwv_flow.LF||
'       , task_id'||wwv_flow.LF||
'       , assignee'||wwv_flow.LF||
'       , name'||wwv_flow.LF||
'       , descri';
wwv_flow_imp.g_varchar2_table(94) := 'ption'||wwv_flow.LF||
'       , is_complete_yn'||wwv_flow.LF||
'      )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  1'||wwv_flow.LF||
'       , 1'||wwv_flow.LF||
'       , 52'||wwv_flow.LF||
'       , 7'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(95) := ' , ''Download tool from vendor'''||wwv_flow.LF||
'       , ''Download the latest available version of the Web developmen';
wwv_flow_imp.g_varchar2_table(96) := 't tool from the vendor site.'''||wwv_flow.LF||
'       , ''Y'''||wwv_flow.LF||
'      );'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into eba_demo_md_task_links'||wwv_flow.LF||
'      ( ';
wwv_flow_imp.g_varchar2_table(97) := ' id'||wwv_flow.LF||
'       , project_id'||wwv_flow.LF||
'       , task_id'||wwv_flow.LF||
'       , link_type'||wwv_flow.LF||
'       , url'||wwv_flow.LF||
'       , application_id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(98) := '    , application_page'||wwv_flow.LF||
'       , description'||wwv_flow.LF||
'      )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  1'||wwv_flow.LF||
'       , 1'||wwv_flow.LF||
'       , 52'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(99) := '    , ''URL'''||wwv_flow.LF||
'       , ''http://Web-tool.download.com'''||wwv_flow.LF||
'       , null'||wwv_flow.LF||
'       , null'||wwv_flow.LF||
'       , ''Ficticous ';
wwv_flow_imp.g_varchar2_table(100) := 'download page for Web development tool'' '||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_task_links'||wwv_flow.LF||
'      (  ';
wwv_flow_imp.g_varchar2_table(101) := 'id'||wwv_flow.LF||
'       , project_id'||wwv_flow.LF||
'       , task_id'||wwv_flow.LF||
'       , link_type'||wwv_flow.LF||
'       , url'||wwv_flow.LF||
'       , application_id'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(102) := '   , application_page'||wwv_flow.LF||
'       , description'||wwv_flow.LF||
'      )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  2'||wwv_flow.LF||
'       , 1'||wwv_flow.LF||
'       , 52'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(103) := '   , ''URL'''||wwv_flow.LF||
'       , ''http://Web-tool.install.com'''||wwv_flow.LF||
'       , null'||wwv_flow.LF||
'       , null'||wwv_flow.LF||
'       , ''Ficticous in';
wwv_flow_imp.g_varchar2_table(104) := 'stallation guide for Web development tool'' '||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  i';
wwv_flow_imp.g_varchar2_table(105) := 'd '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_i';
wwv_flow_imp.g_varchar2_table(106) := 'd '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  53';
wwv_flow_imp.g_varchar2_table(107) := ' '||wwv_flow.LF||
'       , 1 '||wwv_flow.LF||
'       , 12 '||wwv_flow.LF||
'       , ''Configure Web Listeners'' '||wwv_flow.LF||
'       , ''Configure the three Web Lis';
wwv_flow_imp.g_varchar2_table(108) := 'teners for Web development tool to support the Dev, QA, and Prod environments.'' '||wwv_flow.LF||
'       , null '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(109) := '   , ''Y'' '||wwv_flow.LF||
'       , to_date(''20141203'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20141203'', ''YYYYM';
wwv_flow_imp.g_varchar2_table(110) := 'MDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_task_todos'||wwv_flow.LF||
'      (  id'||wwv_flow.LF||
'       , project_';
wwv_flow_imp.g_varchar2_table(111) := 'id'||wwv_flow.LF||
'       , task_id'||wwv_flow.LF||
'       , assignee'||wwv_flow.LF||
'       , name'||wwv_flow.LF||
'       , description'||wwv_flow.LF||
'       , is_complete_yn'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(112) := '   )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  2'||wwv_flow.LF||
'       , 1'||wwv_flow.LF||
'       , 53'||wwv_flow.LF||
'       , 12'||wwv_flow.LF||
'       , ''Download Web Listener from v';
wwv_flow_imp.g_varchar2_table(113) := 'endor'''||wwv_flow.LF||
'       , ''Download the latest available version of the Web Listener from the vendor site.'''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(114) := '     , ''Y'''||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_task_links'||wwv_flow.LF||
'      (  id'||wwv_flow.LF||
'       , project_id'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(115) := ', task_id'||wwv_flow.LF||
'       , link_type'||wwv_flow.LF||
'       , url'||wwv_flow.LF||
'       , application_id'||wwv_flow.LF||
'       , application_page'||wwv_flow.LF||
'       ,';
wwv_flow_imp.g_varchar2_table(116) := ' description'||wwv_flow.LF||
'      )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  3'||wwv_flow.LF||
'       , 1'||wwv_flow.LF||
'       , 53'||wwv_flow.LF||
'       , ''URL'''||wwv_flow.LF||
'       , ''http://We';
wwv_flow_imp.g_varchar2_table(117) := 'b-Listener.download.com'''||wwv_flow.LF||
'       , null'||wwv_flow.LF||
'       , null'||wwv_flow.LF||
'       , ''Ficticous download page for Web Liste';
wwv_flow_imp.g_varchar2_table(118) := 'ner'' '||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_task_links'||wwv_flow.LF||
'      (  id'||wwv_flow.LF||
'       , project_id'||wwv_flow.LF||
'       , tas';
wwv_flow_imp.g_varchar2_table(119) := 'k_id'||wwv_flow.LF||
'       , link_type'||wwv_flow.LF||
'       , url'||wwv_flow.LF||
'       , application_id'||wwv_flow.LF||
'       , application_page'||wwv_flow.LF||
'       , desc';
wwv_flow_imp.g_varchar2_table(120) := 'ription'||wwv_flow.LF||
'      )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  4'||wwv_flow.LF||
'       , 1'||wwv_flow.LF||
'       , 53'||wwv_flow.LF||
'       , ''URL'''||wwv_flow.LF||
'       , ''http://Web-Lis';
wwv_flow_imp.g_varchar2_table(121) := 'tener.install.com'''||wwv_flow.LF||
'       , null'||wwv_flow.LF||
'       , null'||wwv_flow.LF||
'       , ''Ficticous installation guide for Web Listen';
wwv_flow_imp.g_varchar2_table(122) := 'er'' '||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assign';
wwv_flow_imp.g_varchar2_table(123) := 'ee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , st';
wwv_flow_imp.g_varchar2_table(124) := 'art_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  54 '||wwv_flow.LF||
'       , 1 '||wwv_flow.LF||
'       , 11 '||wwv_flow.LF||
'       , ''Co';
wwv_flow_imp.g_varchar2_table(125) := 'nfigure Web development tool Instance Administration Settings'' '||wwv_flow.LF||
'       , ''Set the appropriate securi';
wwv_flow_imp.g_varchar2_table(126) := 'ty and configuration settings for the development instance using specified tools. '||wwv_flow.LF||
'          Also se';
wwv_flow_imp.g_varchar2_table(127) := 't instance settings for QA and Production using the available APIs.'' '||wwv_flow.LF||
'       , null '||wwv_flow.LF||
'       , ''Y'' '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(128) := '      , to_date(''20141204'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20141204'', ''YYYYMMDD'') + l_a';
wwv_flow_imp.g_varchar2_table(129) := 'dd_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_task_links'||wwv_flow.LF||
'      (  id'||wwv_flow.LF||
'       , project_id'||wwv_flow.LF||
'       ,';
wwv_flow_imp.g_varchar2_table(130) := ' task_id'||wwv_flow.LF||
'       , link_type'||wwv_flow.LF||
'       , url'||wwv_flow.LF||
'       , application_id'||wwv_flow.LF||
'       , application_page'||wwv_flow.LF||
'       , ';
wwv_flow_imp.g_varchar2_table(131) := 'description'||wwv_flow.LF||
'      )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  6'||wwv_flow.LF||
'       , 1'||wwv_flow.LF||
'       , 54'||wwv_flow.LF||
'       , ''URL'''||wwv_flow.LF||
'       , ''https://We';
wwv_flow_imp.g_varchar2_table(132) := 'b-tool.admin.com'''||wwv_flow.LF||
'       , null'||wwv_flow.LF||
'       , null'||wwv_flow.LF||
'       , ''Ficticous administration guide for Web devel';
wwv_flow_imp.g_varchar2_table(133) := 'opment tool'' '||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(134) := ' , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(135) := '     , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  55 '||wwv_flow.LF||
'       , 1 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(136) := '   , ''Define Workspaces'' '||wwv_flow.LF||
'       , ''Define workspaces needed for different application development t';
wwv_flow_imp.g_varchar2_table(137) := 'eams. '||wwv_flow.LF||
'          It is important that access be granted to the necessary schemas and/or new schemas ';
wwv_flow_imp.g_varchar2_table(138) := 'created as appropriate. '||wwv_flow.LF||
'          Then export these workspaces and import them into QA and Producti';
wwv_flow_imp.g_varchar2_table(139) := 'on environments.'' '||wwv_flow.LF||
'       , null '||wwv_flow.LF||
'       , ''Y'' '||wwv_flow.LF||
'       , to_date(''20141205'', ''YYYYMMDD'') + l_add_day';
wwv_flow_imp.g_varchar2_table(140) := 's '||wwv_flow.LF||
'       , to_date(''20141205'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_ta';
wwv_flow_imp.g_varchar2_table(141) := 'sks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(142) := '  , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    valu';
wwv_flow_imp.g_varchar2_table(143) := 'es '||wwv_flow.LF||
'      (  56 '||wwv_flow.LF||
'       , 1 '||wwv_flow.LF||
'       , 12 '||wwv_flow.LF||
'       , ''Assign Workspace Administrators'' '||wwv_flow.LF||
'       , ''In d';
wwv_flow_imp.g_varchar2_table(144) := 'evelopment assign a minimum of two Workspace administators to each workspace. '||wwv_flow.LF||
'          These admin';
wwv_flow_imp.g_varchar2_table(145) := 'istrators will then be responsible for maintaining developer access within their own workspaces.'' '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(146) := '      , null '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20141205'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(';
wwv_flow_imp.g_varchar2_table(147) := '''20141205'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Project Comments for Project 1 '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(148) := 'insert into eba_demo_md_comments '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , comment_text '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(149) := '    values '||wwv_flow.LF||
'      (  1 '||wwv_flow.LF||
'       , 1 '||wwv_flow.LF||
'       , ''We have decided to use the Web Listener included with ';
wwv_flow_imp.g_varchar2_table(150) := 'the database for Dev Only and a separate Web Listener for QA and Prod.'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'    update eba_de';
wwv_flow_imp.g_varchar2_table(151) := 'mo_md_comments '||wwv_flow.LF||
'      set created = to_date(''20141202'', ''YYYYMMDD'') + l_add_days'||wwv_flow.LF||
'      ,   created_b';
wwv_flow_imp.g_varchar2_table(152) := 'y = ''TKING'''||wwv_flow.LF||
'      where id = 1; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_comments '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , proje';
wwv_flow_imp.g_varchar2_table(153) := 'ct_id '||wwv_flow.LF||
'       , comment_text '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  2 '||wwv_flow.LF||
'       , 1 '||wwv_flow.LF||
'       , ''Installed lates';
wwv_flow_imp.g_varchar2_table(154) := 't version of Web development tool.'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'    update eba_demo_md_comments '||wwv_flow.LF||
'      set created = ';
wwv_flow_imp.g_varchar2_table(155) := 'to_date(''20141204'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ,   created_by = ''MEIYU'' '||wwv_flow.LF||
'      where id = 2; '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(156) := ''||wwv_flow.LF||
'    insert into eba_demo_md_comments '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , comment_text '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(157) := '  ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  3 '||wwv_flow.LF||
'       , 1 '||wwv_flow.LF||
'       , ''Installed latest version of Web Listener in QA an';
wwv_flow_imp.g_varchar2_table(158) := 'd Prod environments'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'    update eba_demo_md_comments '||wwv_flow.LF||
'      set created = to_date(''201412';
wwv_flow_imp.g_varchar2_table(159) := '04'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ,   created_by = ''HARRY'' '||wwv_flow.LF||
'      where id = 3; '||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
' '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(160) := '   -------------------------- '||wwv_flow.LF||
'    --<< Insert Project 2 >>-- '||wwv_flow.LF||
'    -------------------------- '||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(161) := 'nsert into eba_demo_md_projects '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , project_';
wwv_flow_imp.g_varchar2_table(162) := 'lead '||wwv_flow.LF||
'       , completed_date '||wwv_flow.LF||
'       , status_cd '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'      values '||wwv_flow.LF||
'      (  2 '||wwv_flow.LF||
'       , ''Trai';
wwv_flow_imp.g_varchar2_table(163) := 'n Developers on Web development tool'' '||wwv_flow.LF||
'       , ''Ensure all developers who will be developing with t';
wwv_flow_imp.g_varchar2_table(164) := 'he new tool get the appropriate training.'' '||wwv_flow.LF||
'       , 1 '||wwv_flow.LF||
'       , to_date(''20141220'', ''YYYYMMDD'') + l';
wwv_flow_imp.g_varchar2_table(165) := '_add_days '||wwv_flow.LF||
'       , ''COMPLETED'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Milestone 1 for Project 2 '||wwv_flow.LF||
'    insert int';
wwv_flow_imp.g_varchar2_table(166) := 'o eba_demo_md_milestones '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(167) := '    , due_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  11 '||wwv_flow.LF||
'       , 2 '||wwv_flow.LF||
'       , ''Train the Trainers'' '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(168) := ', ''Rather than all developers being trained centrally, a select group will be trained. '||wwv_flow.LF||
'          Th';
wwv_flow_imp.g_varchar2_table(169) := 'ese people will then be responsible for training other developers in their group.'' '||wwv_flow.LF||
'       , to_date';
wwv_flow_imp.g_varchar2_table(170) := '(''20141211'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Tasks for Project 2 / Milestone 1 '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(171) := '    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , nam';
wwv_flow_imp.g_varchar2_table(172) := 'e '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(173) := ' , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  57 '||wwv_flow.LF||
'       , 2 '||wwv_flow.LF||
'       , 6 '||wwv_flow.LF||
'       , ''Prepare Course Outl';
wwv_flow_imp.g_varchar2_table(174) := 'ine'' '||wwv_flow.LF||
'       , ''Creation of the training syllabus'' '||wwv_flow.LF||
'       , 11 '||wwv_flow.LF||
'       , ''Y'' '||wwv_flow.LF||
'       , to_date(''201';
wwv_flow_imp.g_varchar2_table(175) := '41201'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20141205'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(176) := ''||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , na';
wwv_flow_imp.g_varchar2_table(177) := 'me '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(178) := '  , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  58 '||wwv_flow.LF||
'       , 2 '||wwv_flow.LF||
'       , 6 '||wwv_flow.LF||
'       , ''Write Training Gui';
wwv_flow_imp.g_varchar2_table(179) := 'de'' '||wwv_flow.LF||
'       , ''Produce the powerpoint deck (with notes) for the training instructor.'' '||wwv_flow.LF||
'       , 11 '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(180) := '       , ''N'' '||wwv_flow.LF||
'       , to_date(''20141206'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20141208'', ''Y';
wwv_flow_imp.g_varchar2_table(181) := 'YYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_task_todos'||wwv_flow.LF||
'      (  id'||wwv_flow.LF||
'       , proj';
wwv_flow_imp.g_varchar2_table(182) := 'ect_id'||wwv_flow.LF||
'       , task_id'||wwv_flow.LF||
'       , assignee'||wwv_flow.LF||
'       , name'||wwv_flow.LF||
'       , description'||wwv_flow.LF||
'       , is_complete_yn';
wwv_flow_imp.g_varchar2_table(183) := ''||wwv_flow.LF||
'      )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  4'||wwv_flow.LF||
'       , 2'||wwv_flow.LF||
'       , 58'||wwv_flow.LF||
'       , 6'||wwv_flow.LF||
'       , ''Review the online example';
wwv_flow_imp.g_varchar2_table(184) := 's hosted by the vendor'''||wwv_flow.LF||
'       , ''Run through the numerous examples available from the vendor to get';
wwv_flow_imp.g_varchar2_table(185) := ' course content.'''||wwv_flow.LF||
'       , ''Y'''||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_task_links'||wwv_flow.LF||
'      (  id'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(186) := ', project_id'||wwv_flow.LF||
'       , task_id'||wwv_flow.LF||
'       , link_type'||wwv_flow.LF||
'       , url'||wwv_flow.LF||
'       , application_id'||wwv_flow.LF||
'       , appli';
wwv_flow_imp.g_varchar2_table(187) := 'cation_page'||wwv_flow.LF||
'       , description'||wwv_flow.LF||
'      )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  7'||wwv_flow.LF||
'       , 2'||wwv_flow.LF||
'       , 58'||wwv_flow.LF||
'       , ''URL''';
wwv_flow_imp.g_varchar2_table(188) := ''||wwv_flow.LF||
'       , ''https://Web-tool.examples.com'''||wwv_flow.LF||
'       , null'||wwv_flow.LF||
'       , null'||wwv_flow.LF||
'       , ''Ficticous examples p';
wwv_flow_imp.g_varchar2_table(189) := 'age for Web development tool'' '||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , p';
wwv_flow_imp.g_varchar2_table(190) := 'roject_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , i';
wwv_flow_imp.g_varchar2_table(191) := 's_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  59 '||wwv_flow.LF||
'       , 2 ';
wwv_flow_imp.g_varchar2_table(192) := ''||wwv_flow.LF||
'       , 6 '||wwv_flow.LF||
'       , ''Develop Training Exercises'' '||wwv_flow.LF||
'       , ''Create scripts for sample data and pro';
wwv_flow_imp.g_varchar2_table(193) := 'blem statements with solutions.'' '||wwv_flow.LF||
'       , 11 '||wwv_flow.LF||
'       , ''Y'' '||wwv_flow.LF||
'       , to_date(''20141202'', ''YYYYMMDD''';
wwv_flow_imp.g_varchar2_table(194) := ') + l_add_days '||wwv_flow.LF||
'       , to_date(''20141208'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into e';
wwv_flow_imp.g_varchar2_table(195) := 'ba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , descr';
wwv_flow_imp.g_varchar2_table(196) := 'iption '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(197) := '  ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  60 '||wwv_flow.LF||
'       , 2 '||wwv_flow.LF||
'       , 7'||wwv_flow.LF||
'       , ''Conduct Train-the-Trainer session'' '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(198) := '      , ''Give the training material to the selected developers.'' '||wwv_flow.LF||
'       , 11 '||wwv_flow.LF||
'       , ''Y'' '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(199) := ', to_date(''20141209'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20141211'', ''YYYYMMDD'') + l_add_day';
wwv_flow_imp.g_varchar2_table(200) := 's '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Milestone 2 for Project 2 '||wwv_flow.LF||
'    insert into eba_demo_md_milestones '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(201) := '  (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , due_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    v';
wwv_flow_imp.g_varchar2_table(202) := 'alues '||wwv_flow.LF||
'      (  12 '||wwv_flow.LF||
'       , 2 '||wwv_flow.LF||
'       , ''All Developers Trained'' '||wwv_flow.LF||
'       , ''Train the Trainers will';
wwv_flow_imp.g_varchar2_table(203) := ' have successfully trained the remaining development team members.'' '||wwv_flow.LF||
'       , to_date(''20141215'', ''Y';
wwv_flow_imp.g_varchar2_table(204) := 'YYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Tasks for Project 2 / Milestone 2 '||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(205) := ' eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , des';
wwv_flow_imp.g_varchar2_table(206) := 'cription '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(207) := '    ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  61 '||wwv_flow.LF||
'       , 2 '||wwv_flow.LF||
'       , 7 '||wwv_flow.LF||
'       , ''Train Developers I'' '||wwv_flow.LF||
'       , ''Giv';
wwv_flow_imp.g_varchar2_table(208) := 'e the training to developers within your group.'' '||wwv_flow.LF||
'       , 12 '||wwv_flow.LF||
'       , ''Y'' '||wwv_flow.LF||
'       , to_date(''20141';
wwv_flow_imp.g_varchar2_table(209) := '212'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20141214'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(210) := '   insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name';
wwv_flow_imp.g_varchar2_table(211) := ' '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(212) := ', end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  62 '||wwv_flow.LF||
'       , 2 '||wwv_flow.LF||
'       , 8 '||wwv_flow.LF||
'       , ''Train Developers II''';
wwv_flow_imp.g_varchar2_table(213) := ' '||wwv_flow.LF||
'       , ''Give the training to developers within your group.'' '||wwv_flow.LF||
'       , 12 '||wwv_flow.LF||
'       , ''Y'' '||wwv_flow.LF||
'       ,';
wwv_flow_imp.g_varchar2_table(214) := ' to_date(''20141214'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20141216'', ''YYYYMMDD'') + l_add_days';
wwv_flow_imp.g_varchar2_table(215) := ' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Project Comments for Project 2 '||wwv_flow.LF||
'    insert into eba_demo_md_comments '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(216) := '    (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , comment_text '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  4 '||wwv_flow.LF||
'       , 2 '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(217) := '       , ''The exercises had some errors that need correcting ASAP.'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'    update eba_demo_m';
wwv_flow_imp.g_varchar2_table(218) := 'd_comments '||wwv_flow.LF||
'      set created = to_date(''20141211'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      where id = 4; '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(219) := ''||wwv_flow.LF||
'    insert into eba_demo_md_comments '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , comment_text '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(220) := '  ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  5 '||wwv_flow.LF||
'       , 2 '||wwv_flow.LF||
'       , ''Thanks for the feedback, Exercises corrected.'' '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(221) := '     ); '||wwv_flow.LF||
'    update eba_demo_md_comments '||wwv_flow.LF||
'      set created = to_date(''20141212'', ''YYYYMMDD'') + l_ad';
wwv_flow_imp.g_varchar2_table(222) := 'd_days '||wwv_flow.LF||
'      ,   created_by = ''TKING'' '||wwv_flow.LF||
'      where id = 5; '||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -------------------';
wwv_flow_imp.g_varchar2_table(223) := '------- '||wwv_flow.LF||
'    --<< Insert Project 3 >>-- '||wwv_flow.LF||
'    -------------------------- '||wwv_flow.LF||
'    insert into eba_demo_md';
wwv_flow_imp.g_varchar2_table(224) := '_projects '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , project_lead '||wwv_flow.LF||
'       , complet';
wwv_flow_imp.g_varchar2_table(225) := 'ed_date '||wwv_flow.LF||
'       , status_cd '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'      values '||wwv_flow.LF||
'      (  3 '||wwv_flow.LF||
'       , ''Migrate Legacy Application';
wwv_flow_imp.g_varchar2_table(226) := 's'' '||wwv_flow.LF||
'       , ''Move the data and redevelop the applications currently running on top of legacy server';
wwv_flow_imp.g_varchar2_table(227) := 's'' '||wwv_flow.LF||
'       , 10 '||wwv_flow.LF||
'       , null '||wwv_flow.LF||
'       , ''IN-PROGRESS'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Milestone 1 for Pr';
wwv_flow_imp.g_varchar2_table(228) := 'oject 3 '||wwv_flow.LF||
'    insert into eba_demo_md_milestones '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(229) := '     , description '||wwv_flow.LF||
'       , due_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  13 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'       , ''Move ';
wwv_flow_imp.g_varchar2_table(230) := 'Data Structures'' '||wwv_flow.LF||
'       , ''Move all of the tables and program logic across to the new database'' '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(231) := '     , to_date(''20141220'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Tasks for Project 3 /';
wwv_flow_imp.g_varchar2_table(232) := ' Milestone 1 '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee';
wwv_flow_imp.g_varchar2_table(233) := ' '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , star';
wwv_flow_imp.g_varchar2_table(234) := 't_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  63 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'       , ''Creat';
wwv_flow_imp.g_varchar2_table(235) := 'e New Tables'' '||wwv_flow.LF||
'       , ''Create table scripts to replicate the legacy tables'' '||wwv_flow.LF||
'       , 13 '||wwv_flow.LF||
'       ,';
wwv_flow_imp.g_varchar2_table(236) := ' ''Y'' '||wwv_flow.LF||
'       , to_date(''20141214'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20141214'', ''YYYYMMDD''';
wwv_flow_imp.g_varchar2_table(237) := ') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_task_todos'||wwv_flow.LF||
'      (  id'||wwv_flow.LF||
'       , project_id'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(238) := '      , task_id'||wwv_flow.LF||
'       , assignee'||wwv_flow.LF||
'       , name'||wwv_flow.LF||
'       , description'||wwv_flow.LF||
'       , is_complete_yn'||wwv_flow.LF||
'      )';
wwv_flow_imp.g_varchar2_table(239) := ''||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  5'||wwv_flow.LF||
'       , 3'||wwv_flow.LF||
'       , 63'||wwv_flow.LF||
'       , 3'||wwv_flow.LF||
'       , ''Reverse engineer the legacy table';
wwv_flow_imp.g_varchar2_table(240) := 's into the data modeling tool'''||wwv_flow.LF||
'       , ''Connect the data modeling tool to the legacy dev instance a';
wwv_flow_imp.g_varchar2_table(241) := 'nd suck in all of the required DB objects.'''||wwv_flow.LF||
'       , ''Y'''||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_task';
wwv_flow_imp.g_varchar2_table(242) := '_links'||wwv_flow.LF||
'      (  id'||wwv_flow.LF||
'       , project_id'||wwv_flow.LF||
'       , task_id'||wwv_flow.LF||
'       , link_type'||wwv_flow.LF||
'       , url'||wwv_flow.LF||
'       , app';
wwv_flow_imp.g_varchar2_table(243) := 'lication_id'||wwv_flow.LF||
'       , application_page'||wwv_flow.LF||
'       , description'||wwv_flow.LF||
'      )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  8'||wwv_flow.LF||
'       , 3'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(244) := '       , 63'||wwv_flow.LF||
'       , ''URL'''||wwv_flow.LF||
'       , ''http://Web-data-modeler.info.com'''||wwv_flow.LF||
'       , null'||wwv_flow.LF||
'       , null'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(245) := '      , ''Ficticous information site for the data mdoeling tool'' '||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo';
wwv_flow_imp.g_varchar2_table(246) := '_md_task_todos'||wwv_flow.LF||
'      (  id'||wwv_flow.LF||
'       , project_id'||wwv_flow.LF||
'       , task_id'||wwv_flow.LF||
'       , assignee'||wwv_flow.LF||
'       , name'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(247) := '   , description'||wwv_flow.LF||
'       , is_complete_yn'||wwv_flow.LF||
'      )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  6'||wwv_flow.LF||
'       , 3'||wwv_flow.LF||
'       , 63'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(248) := ' , 3'||wwv_flow.LF||
'       , ''Add proper integrity constraints to the entities'''||wwv_flow.LF||
'       , ''Add foreign keys as neede';
wwv_flow_imp.g_varchar2_table(249) := 'd to correctly integrate referential integrity.'''||wwv_flow.LF||
'       , ''Y'''||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md';
wwv_flow_imp.g_varchar2_table(250) := '_task_todos'||wwv_flow.LF||
'      (  id'||wwv_flow.LF||
'       , project_id'||wwv_flow.LF||
'       , task_id'||wwv_flow.LF||
'       , assignee'||wwv_flow.LF||
'       , name'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(251) := ', description'||wwv_flow.LF||
'       , is_complete_yn'||wwv_flow.LF||
'      )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  7'||wwv_flow.LF||
'       , 3'||wwv_flow.LF||
'       , 63'||wwv_flow.LF||
'       , ';
wwv_flow_imp.g_varchar2_table(252) := '3'||wwv_flow.LF||
'       , ''Generate DDL Scripts for new tables'''||wwv_flow.LF||
'       , ''Generate the DDL scripts from the data mo';
wwv_flow_imp.g_varchar2_table(253) := 'deling tool to create the DB objects in the new database.'''||wwv_flow.LF||
'       , ''Y'''||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into e';
wwv_flow_imp.g_varchar2_table(254) := 'ba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , descr';
wwv_flow_imp.g_varchar2_table(255) := 'iption '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(256) := '  ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  64 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'       , 2 '||wwv_flow.LF||
'       , ''Migrate data from Legacy Server'' '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(257) := '     , ''Develop scripts to populate the new database tables from the legacy database.'' '||wwv_flow.LF||
'       , 13'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(258) := '       , ''Y'' '||wwv_flow.LF||
'       , to_date(''20141215'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20141218'', ''Y';
wwv_flow_imp.g_varchar2_table(259) := 'YYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project';
wwv_flow_imp.g_varchar2_table(260) := '_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_comp';
wwv_flow_imp.g_varchar2_table(261) := 'lete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  65 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(262) := '  , 3 '||wwv_flow.LF||
'       , ''Convert transaction logic'' '||wwv_flow.LF||
'       , ''Convert the legacy database transactional obj';
wwv_flow_imp.g_varchar2_table(263) := 'ects across to the new database'' '||wwv_flow.LF||
'       , 13'||wwv_flow.LF||
'       , ''Y'' '||wwv_flow.LF||
'       , to_date(''20141215'', ''YYYYMMDD'')';
wwv_flow_imp.g_varchar2_table(264) := ' + l_add_days '||wwv_flow.LF||
'       , to_date(''20141217'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Mile';
wwv_flow_imp.g_varchar2_table(265) := 'stone 2 for Project 3 '||wwv_flow.LF||
'    insert into eba_demo_md_milestones '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(266) := '    , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , due_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  14 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(267) := '      , ''Redevelop HR Applications'' '||wwv_flow.LF||
'       , ''Build applications to replace the HR functionality cu';
wwv_flow_imp.g_varchar2_table(268) := 'rrently implemented in older technologies'' '||wwv_flow.LF||
'       , to_date(''20141228'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(269) := '     ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Tasks for Project 3 / Milestone 2 '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(270) := ' (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milest';
wwv_flow_imp.g_varchar2_table(271) := 'one_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(272) := '(  66 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'       , 4 '||wwv_flow.LF||
'       , ''Redevelop Timesheet App'' '||wwv_flow.LF||
'       , ''Develop desktop and mob';
wwv_flow_imp.g_varchar2_table(273) := 'ile app for entering timesheets'' '||wwv_flow.LF||
'       , 14 '||wwv_flow.LF||
'       , ''Y'' '||wwv_flow.LF||
'       , to_date(''20141217'', ''YYYYMMDD''';
wwv_flow_imp.g_varchar2_table(274) := ') + l_add_days '||wwv_flow.LF||
'       , to_date(''20141222'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into e';
wwv_flow_imp.g_varchar2_table(275) := 'ba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , descr';
wwv_flow_imp.g_varchar2_table(276) := 'iption '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(277) := '  ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  67 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'       , 8 '||wwv_flow.LF||
'       , ''Create Shift Schedule App'' '||wwv_flow.LF||
'       ,';
wwv_flow_imp.g_varchar2_table(278) := ' ''Create an app for defining when people are scheduled to work different shifts.'' '||wwv_flow.LF||
'       , 14 '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(279) := '   , ''Y'' '||wwv_flow.LF||
'       , to_date(''20141217'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20141225'', ''YYYYM';
wwv_flow_imp.g_varchar2_table(280) := 'MDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id ';
wwv_flow_imp.g_varchar2_table(281) := ''||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete';
wwv_flow_imp.g_varchar2_table(282) := '_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  68 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'       , ';
wwv_flow_imp.g_varchar2_table(283) := '8 '||wwv_flow.LF||
'       , ''Reengineer Employee App'' '||wwv_flow.LF||
'       , ''Create an app for employee details and benefits.'' '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(284) := '       , 14 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20141226'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''';
wwv_flow_imp.g_varchar2_table(285) := '20141228'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Milestone 3 for Project 3 '||wwv_flow.LF||
'    insert';
wwv_flow_imp.g_varchar2_table(286) := ' into eba_demo_md_milestones '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description ';
wwv_flow_imp.g_varchar2_table(287) := ''||wwv_flow.LF||
'       , due_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  15 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'       , ''Redevelop Project Tracki';
wwv_flow_imp.g_varchar2_table(288) := 'ng Applications'' '||wwv_flow.LF||
'       , ''Build applications to replace the project tracking functionality current';
wwv_flow_imp.g_varchar2_table(289) := 'ly running on legacy servers'' '||wwv_flow.LF||
'       , to_date(''20150103'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(290) := '  -- Insert Tasks for Project 3 / Milestone 3 '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(291) := '  , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(292) := '  , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  69 '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(293) := ' , 3 '||wwv_flow.LF||
'       , 9 '||wwv_flow.LF||
'       , ''Customize Customer Tracker Packaged App'' '||wwv_flow.LF||
'       , ''Install Customer Tra';
wwv_flow_imp.g_varchar2_table(294) := 'cker and use flex fields to meet requirements.'' '||wwv_flow.LF||
'       , 15 '||wwv_flow.LF||
'       , ''Y'' '||wwv_flow.LF||
'       , to_date(''201412';
wwv_flow_imp.g_varchar2_table(295) := '28'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20141228'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(296) := '  insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name ';
wwv_flow_imp.g_varchar2_table(297) := ''||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       ,';
wwv_flow_imp.g_varchar2_table(298) := ' end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  70 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'       , 9 '||wwv_flow.LF||
'       , ''Migrate data into Cus';
wwv_flow_imp.g_varchar2_table(299) := 'tomer Tracker tables'' '||wwv_flow.LF||
'       , ''Move previous project tracking data into the Customer Tracker EBA_C';
wwv_flow_imp.g_varchar2_table(300) := 'UST_xxx tables.'' '||wwv_flow.LF||
'       , 15 '||wwv_flow.LF||
'       , ''Y'' '||wwv_flow.LF||
'       , to_date(''20141229'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(301) := '       , to_date(''20141230'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks';
wwv_flow_imp.g_varchar2_table(302) := ' '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       ,';
wwv_flow_imp.g_varchar2_table(303) := ' milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values ';
wwv_flow_imp.g_varchar2_table(304) := ''||wwv_flow.LF||
'      (  71 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'       , 11 '||wwv_flow.LF||
'       , ''Pilot new Customer Tracker application'' '||wwv_flow.LF||
'       , ''';
wwv_flow_imp.g_varchar2_table(305) := 'Use Customer Tracker to ensure it meets requirements.'' '||wwv_flow.LF||
'       , 15 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(';
wwv_flow_imp.g_varchar2_table(306) := '''20141231'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150109'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      )';
wwv_flow_imp.g_varchar2_table(307) := '; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Project Comments for Project 3 '||wwv_flow.LF||
'    insert into eba_demo_md_comments '||wwv_flow.LF||
'      (  id';
wwv_flow_imp.g_varchar2_table(308) := ' '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , comment_text '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  6 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'       , ';
wwv_flow_imp.g_varchar2_table(309) := '''Bernie - I have migrated all of the projects data across, so you can start your pilot now.'' '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(310) := '); '||wwv_flow.LF||
'    update eba_demo_md_comments '||wwv_flow.LF||
'      set created = to_date(''201412310100'', ''YYYYMMDDHH24MI'') +';
wwv_flow_imp.g_varchar2_table(311) := ' l_add_days '||wwv_flow.LF||
'      ,   created_by = ''THEBROCK'' '||wwv_flow.LF||
'      where id = 6; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_c';
wwv_flow_imp.g_varchar2_table(312) := 'omments '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , comment_text '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  7 '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(313) := '      , 3 '||wwv_flow.LF||
'       , ''I''''m telling you now, this Customer Tracker thing had better be good'' '||wwv_flow.LF||
'      );';
wwv_flow_imp.g_varchar2_table(314) := ' '||wwv_flow.LF||
'    update eba_demo_md_comments '||wwv_flow.LF||
'      set created = to_date(''201412310200'', ''YYYYMMDDHH24MI'') + l';
wwv_flow_imp.g_varchar2_table(315) := '_add_days '||wwv_flow.LF||
'      ,   created_by = ''BERNIE'' '||wwv_flow.LF||
'      where id = 7; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_comme';
wwv_flow_imp.g_varchar2_table(316) := 'nts '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , comment_text '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  8 '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(317) := '  , 3 '||wwv_flow.LF||
'       , ''This guy Mike told me this app is brilliant.'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'    update eba_demo_md_com';
wwv_flow_imp.g_varchar2_table(318) := 'ments '||wwv_flow.LF||
'      set created = to_date(''201412310300'', ''YYYYMMDDHH24MI'') + l_add_days '||wwv_flow.LF||
'      ,   created';
wwv_flow_imp.g_varchar2_table(319) := '_by = ''THEBROCK'' '||wwv_flow.LF||
'      where id = 8; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_comments '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       ,';
wwv_flow_imp.g_varchar2_table(320) := ' project_id '||wwv_flow.LF||
'       , comment_text '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  9 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'       , ''So far Cu';
wwv_flow_imp.g_varchar2_table(321) := 'stomer Tracker is working out great - better than the old apps. Brocky, my boy, you are the man!'' '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(322) := '     ); '||wwv_flow.LF||
'    update eba_demo_md_comments '||wwv_flow.LF||
'      set created = to_date(''201501010100'', ''YYYYMMDDHH24M';
wwv_flow_imp.g_varchar2_table(323) := 'I'') + l_add_days '||wwv_flow.LF||
'      ,   created_by = ''BERNIE'' '||wwv_flow.LF||
'      where id = 9; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_m';
wwv_flow_imp.g_varchar2_table(324) := 'd_comments '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , comment_text '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  1';
wwv_flow_imp.g_varchar2_table(325) := '0 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'       , ''Bernie, I told you that you were going to be impressed.'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'    upd';
wwv_flow_imp.g_varchar2_table(326) := 'ate eba_demo_md_comments '||wwv_flow.LF||
'      set created = to_date(''201501010200'', ''YYYYMMDDHH24MI'') + l_add_days';
wwv_flow_imp.g_varchar2_table(327) := ' '||wwv_flow.LF||
'      ,   created_by = ''THEBROCK'' '||wwv_flow.LF||
'      where id = 10; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_comments '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(328) := '     (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , comment_text '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  11 '||wwv_flow.LF||
'       , 3';
wwv_flow_imp.g_varchar2_table(329) := ' '||wwv_flow.LF||
'       , ''All of the old tables and transactional logic now migrated and ready for developers to u';
wwv_flow_imp.g_varchar2_table(330) := 'se in the new database.'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
'    update eba_demo_md_comments '||wwv_flow.LF||
'      set created = to_date(''20';
wwv_flow_imp.g_varchar2_table(331) := '141217'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ,   created_by = ''THALL'' '||wwv_flow.LF||
'      where id = 11; '||wwv_flow.LF||
'    commit;';
wwv_flow_imp.g_varchar2_table(332) := ''||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -------------------------- '||wwv_flow.LF||
'    --<< Insert Project 4 >>-- '||wwv_flow.LF||
'    -------------------------- ';
wwv_flow_imp.g_varchar2_table(333) := ''||wwv_flow.LF||
'    insert into eba_demo_md_projects '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , pr';
wwv_flow_imp.g_varchar2_table(334) := 'oject_lead '||wwv_flow.LF||
'       , completed_date '||wwv_flow.LF||
'       , status_cd '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'      values '||wwv_flow.LF||
'      (  4 '||wwv_flow.LF||
'       ,';
wwv_flow_imp.g_varchar2_table(335) := ' ''Develop Partner Portal POC'' '||wwv_flow.LF||
'       , ''Develop a proof of concept that partners can use to work mo';
wwv_flow_imp.g_varchar2_table(336) := 're collaboratively with us.'' '||wwv_flow.LF||
'       , 7'||wwv_flow.LF||
'       , null '||wwv_flow.LF||
'       , ''IN-PROGRESS'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- I';
wwv_flow_imp.g_varchar2_table(337) := 'nsert Milestone 1 for Project 4 '||wwv_flow.LF||
'    insert into eba_demo_md_milestones '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , proje';
wwv_flow_imp.g_varchar2_table(338) := 'ct_id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , due_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  16 '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(339) := '    , 4 '||wwv_flow.LF||
'       , ''Define Requirements'' '||wwv_flow.LF||
'       , ''Work with key stakeholders to define the scope of';
wwv_flow_imp.g_varchar2_table(340) := ' the project, and design screen flow and data requirements.'' '||wwv_flow.LF||
'       , to_date(''20150106'', ''YYYYMMDD';
wwv_flow_imp.g_varchar2_table(341) := ''') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Tasks for Project 4 / Milestone 1 '||wwv_flow.LF||
'    insert into eba_de';
wwv_flow_imp.g_varchar2_table(342) := 'mo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , descriptio';
wwv_flow_imp.g_varchar2_table(343) := 'n '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(344) := '    values '||wwv_flow.LF||
'      (  72 '||wwv_flow.LF||
'       , 4 '||wwv_flow.LF||
'       , 7'||wwv_flow.LF||
'       , ''Define scope of Partner Portal App.'' '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(345) := '   , ''Meet with internal and external SMEs and define the requirements'' '||wwv_flow.LF||
'       , 16 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(346) := '       , to_date(''20141228'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150104'', ''YYYYMMDD'') + l_';
wwv_flow_imp.g_varchar2_table(347) := 'add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_task_todos'||wwv_flow.LF||
'      (  id'||wwv_flow.LF||
'       , project_id'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(348) := ', task_id'||wwv_flow.LF||
'       , assignee'||wwv_flow.LF||
'       , name'||wwv_flow.LF||
'       , description'||wwv_flow.LF||
'       , is_complete_yn'||wwv_flow.LF||
'      )'||wwv_flow.LF||
'    v';
wwv_flow_imp.g_varchar2_table(349) := 'alues'||wwv_flow.LF||
'      (  8'||wwv_flow.LF||
'       , 4'||wwv_flow.LF||
'       , 72'||wwv_flow.LF||
'       , 7'||wwv_flow.LF||
'       , ''Meet key Partners for input'''||wwv_flow.LF||
'       , ''';
wwv_flow_imp.g_varchar2_table(350) := 'Determine the most important functionality for Partners.'''||wwv_flow.LF||
'       , ''Y'''||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eb';
wwv_flow_imp.g_varchar2_table(351) := 'a_demo_md_task_todos'||wwv_flow.LF||
'      (  id'||wwv_flow.LF||
'       , project_id'||wwv_flow.LF||
'       , task_id'||wwv_flow.LF||
'       , assignee'||wwv_flow.LF||
'       , nam';
wwv_flow_imp.g_varchar2_table(352) := 'e'||wwv_flow.LF||
'       , description'||wwv_flow.LF||
'       , is_complete_yn'||wwv_flow.LF||
'      )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  9'||wwv_flow.LF||
'       , 4'||wwv_flow.LF||
'       , 72'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(353) := '       , 7'||wwv_flow.LF||
'       , ''Meet internal Partner liason reps'''||wwv_flow.LF||
'       , ''Determine the most important funct';
wwv_flow_imp.g_varchar2_table(354) := 'ionality for internal stakeholders.'''||wwv_flow.LF||
'       , ''Y'''||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_task_todos'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(355) := '      (  id'||wwv_flow.LF||
'       , project_id'||wwv_flow.LF||
'       , task_id'||wwv_flow.LF||
'       , assignee'||wwv_flow.LF||
'       , name'||wwv_flow.LF||
'       , descriptio';
wwv_flow_imp.g_varchar2_table(356) := 'n'||wwv_flow.LF||
'       , is_complete_yn'||wwv_flow.LF||
'      )'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      (  10'||wwv_flow.LF||
'       , 4'||wwv_flow.LF||
'       , 72'||wwv_flow.LF||
'       , 7'||wwv_flow.LF||
'       , ';
wwv_flow_imp.g_varchar2_table(357) := '''Develop inital screen designs'''||wwv_flow.LF||
'       , ''Prototype new screens using Web development tool to get bu';
wwv_flow_imp.g_varchar2_table(358) := 'y-in from SMEs.'''||wwv_flow.LF||
'       , ''Y'''||wwv_flow.LF||
'      );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , pr';
wwv_flow_imp.g_varchar2_table(359) := 'oject_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is';
wwv_flow_imp.g_varchar2_table(360) := '_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  73 '||wwv_flow.LF||
'       , 4 '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(361) := '       , 8 '||wwv_flow.LF||
'       , ''Define Partner App Data Structures'' '||wwv_flow.LF||
'       , ''Design the data model for new a';
wwv_flow_imp.g_varchar2_table(362) := 'nd existing entities required to support the Partner Portal.'' '||wwv_flow.LF||
'       , 16 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , t';
wwv_flow_imp.g_varchar2_table(363) := 'o_date(''20150104'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150107'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(364) := '      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(365) := '       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_';
wwv_flow_imp.g_varchar2_table(366) := 'date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  74 '||wwv_flow.LF||
'       , 4 '||wwv_flow.LF||
'       , 6 '||wwv_flow.LF||
'       , ''Design ';
wwv_flow_imp.g_varchar2_table(367) := 'User Experience'' '||wwv_flow.LF||
'       , ''Define how partners will interact with the application.'' '||wwv_flow.LF||
'       , 16 '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(368) := '      , ''N'' '||wwv_flow.LF||
'       , to_date(''20150105'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150106'', ''YY';
wwv_flow_imp.g_varchar2_table(369) := 'YYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Milestone 2 for Project 4 '||wwv_flow.LF||
'    insert into eba_de';
wwv_flow_imp.g_varchar2_table(370) := 'mo_md_milestones '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , du';
wwv_flow_imp.g_varchar2_table(371) := 'e_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  17 '||wwv_flow.LF||
'       , 4 '||wwv_flow.LF||
'       , ''Build Proof-of-Concept'' '||wwv_flow.LF||
'       , ''C';
wwv_flow_imp.g_varchar2_table(372) := 'reate the initial screens and populate with data so key stakeholders can review proposed solution.'' ';
wwv_flow_imp.g_varchar2_table(373) := ''||wwv_flow.LF||
'       , to_date(''20150113'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Tasks for Project ';
wwv_flow_imp.g_varchar2_table(374) := '4 / Milestone 2 '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assig';
wwv_flow_imp.g_varchar2_table(375) := 'nee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , s';
wwv_flow_imp.g_varchar2_table(376) := 'tart_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  75 '||wwv_flow.LF||
'       , 4 '||wwv_flow.LF||
'       , 2 '||wwv_flow.LF||
'       , ''De';
wwv_flow_imp.g_varchar2_table(377) := 'velop Admin Screens for Partner Portal'' '||wwv_flow.LF||
'       , ''Develop the screens needed to maintain all of the';
wwv_flow_imp.g_varchar2_table(378) := ' base tables for the Partner Portal app.'' '||wwv_flow.LF||
'       , 17 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150108'', ''';
wwv_flow_imp.g_varchar2_table(379) := 'YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150110'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    inse';
wwv_flow_imp.g_varchar2_table(380) := 'rt into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(381) := '  , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_d';
wwv_flow_imp.g_varchar2_table(382) := 'ate '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  76 '||wwv_flow.LF||
'       , 4 '||wwv_flow.LF||
'       , 12 '||wwv_flow.LF||
'       , ''Populate Data Structures f';
wwv_flow_imp.g_varchar2_table(383) := 'or Partner Portal'' '||wwv_flow.LF||
'       , ''Upload sample data provided by key partner, and ensure existing tables';
wwv_flow_imp.g_varchar2_table(384) := ' accessible.'' '||wwv_flow.LF||
'       , 17 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150108'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(385) := '    , to_date(''20150109'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(386) := '     (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , mi';
wwv_flow_imp.g_varchar2_table(387) := 'lestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(388) := '    (  77 '||wwv_flow.LF||
'       , 4 '||wwv_flow.LF||
'       , 6 '||wwv_flow.LF||
'       , ''Design first-cut of main Partner Portal app'' '||wwv_flow.LF||
'       , ';
wwv_flow_imp.g_varchar2_table(389) := '''Implement the major functional areas and ensure navigation between pages is working correctly.'' '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(390) := '     , 17 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150107'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20';
wwv_flow_imp.g_varchar2_table(391) := '150111'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(392) := '  , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(393) := '  , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  78 '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(394) := ' , 4 '||wwv_flow.LF||
'       , 7'||wwv_flow.LF||
'       , ''Present POC to Key Stakeholders'' '||wwv_flow.LF||
'       , ''Walk key stakeholders through';
wwv_flow_imp.g_varchar2_table(395) := ' the proof of concept and obtain their feedback.'' '||wwv_flow.LF||
'       , 17 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''2015';
wwv_flow_imp.g_varchar2_table(396) := '0112'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150112'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(397) := ' '||wwv_flow.LF||
'    -------------------------- '||wwv_flow.LF||
'    --<< Insert Project 5 >>-- '||wwv_flow.LF||
'    -------------------------- '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(398) := '  insert into eba_demo_md_projects '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , proje';
wwv_flow_imp.g_varchar2_table(399) := 'ct_lead '||wwv_flow.LF||
'       , completed_date '||wwv_flow.LF||
'       , status_cd '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'      values '||wwv_flow.LF||
'      (  5 '||wwv_flow.LF||
'       , ''D';
wwv_flow_imp.g_varchar2_table(400) := 'evelop Production Partner Portal'' '||wwv_flow.LF||
'       , ''Develop the production app that partners can use to wor';
wwv_flow_imp.g_varchar2_table(401) := 'k more collaboratively with us.'' '||wwv_flow.LF||
'       , 1 '||wwv_flow.LF||
'       , null '||wwv_flow.LF||
'       , ''ASSIGNED'' '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(402) := ' Insert Milestone 1 for Project 5 '||wwv_flow.LF||
'    insert into eba_demo_md_milestones '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , pro';
wwv_flow_imp.g_varchar2_table(403) := 'ject_id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , due_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  18 '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(404) := '      , 5 '||wwv_flow.LF||
'       , ''Define Production App Scope'' '||wwv_flow.LF||
'       , ''Based on the results of the POC, define';
wwv_flow_imp.g_varchar2_table(405) := ' the requirements for the production app.'' '||wwv_flow.LF||
'       , to_date(''20150114'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(406) := '    ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Tasks for Project 5 / Milestone 1 '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(407) := '(  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milesto';
wwv_flow_imp.g_varchar2_table(408) := 'ne_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (';
wwv_flow_imp.g_varchar2_table(409) := '  79 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , 7'||wwv_flow.LF||
'       , ''Define production scope of Partner Portal App.'' '||wwv_flow.LF||
'       , ''De';
wwv_flow_imp.g_varchar2_table(410) := 'fine the scope and timelines for the development of the production app.'' '||wwv_flow.LF||
'       , 18 '||wwv_flow.LF||
'       , ''N'' ';
wwv_flow_imp.g_varchar2_table(411) := ''||wwv_flow.LF||
'       , to_date(''20150113'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150114'', ''YYYYMMDD'') + l';
wwv_flow_imp.g_varchar2_table(412) := '_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       ,';
wwv_flow_imp.g_varchar2_table(413) := ' assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(414) := '   , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  80 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , 8 '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(415) := ' , ''Finalize Partner App Data Model'' '||wwv_flow.LF||
'       , ''Refine the data model for new and existing entities ';
wwv_flow_imp.g_varchar2_table(416) := 'required to support the Partner Portal.'' '||wwv_flow.LF||
'       , 18 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150113'', ''Y';
wwv_flow_imp.g_varchar2_table(417) := 'YYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150114'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    inser';
wwv_flow_imp.g_varchar2_table(418) := 't into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(419) := ' , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_da';
wwv_flow_imp.g_varchar2_table(420) := 'te '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  81 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , 6 '||wwv_flow.LF||
'       , ''Finalize User Experience'' '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(421) := '      , ''Write developer standards on UX and development standards on how partners will interact wit';
wwv_flow_imp.g_varchar2_table(422) := 'h the application.'' '||wwv_flow.LF||
'       , 18 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150113'', ''YYYYMMDD'') + l_add_day';
wwv_flow_imp.g_varchar2_table(423) := 's '||wwv_flow.LF||
'       , to_date(''20150114'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Milestone 2 fo';
wwv_flow_imp.g_varchar2_table(424) := 'r Project 5 '||wwv_flow.LF||
'    insert into eba_demo_md_milestones '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , name';
wwv_flow_imp.g_varchar2_table(425) := ' '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , due_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  19 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , ''B';
wwv_flow_imp.g_varchar2_table(426) := 'uild Phase 1 of Production Partner Portal App'' '||wwv_flow.LF||
'       , ''Develop the modules defined in the first p';
wwv_flow_imp.g_varchar2_table(427) := 'hase of the application.'' '||wwv_flow.LF||
'       , to_date(''20150121'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(428) := ' Insert Tasks for Project 5 / Milestone 2 '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , ';
wwv_flow_imp.g_varchar2_table(429) := 'project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , ';
wwv_flow_imp.g_varchar2_table(430) := 'is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  82 '||wwv_flow.LF||
'       , 5';
wwv_flow_imp.g_varchar2_table(431) := ' '||wwv_flow.LF||
'       , 6 '||wwv_flow.LF||
'       , ''Refine Admin Screens for Partner Portal'' '||wwv_flow.LF||
'       , ''Refine screens developed';
wwv_flow_imp.g_varchar2_table(432) := ' in the POC to be fully operational to maintain all of the base tables for the Partner Portal app.'' ';
wwv_flow_imp.g_varchar2_table(433) := ''||wwv_flow.LF||
'       , 19 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150115'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(';
wwv_flow_imp.g_varchar2_table(434) := '''20150118'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(435) := '     , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(436) := '     , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  83 '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(437) := '    , 5 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , ''Populate Data Structures for Production Partner Portal'' '||wwv_flow.LF||
'       , ''Up';
wwv_flow_imp.g_varchar2_table(438) := 'load actual data provided by key partner, and ensure existing tables accessible.'' '||wwv_flow.LF||
'       , 19 '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(439) := '   , ''N'' '||wwv_flow.LF||
'       , to_date(''20150115'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150117'', ''YYYYM';
wwv_flow_imp.g_varchar2_table(440) := 'MDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id ';
wwv_flow_imp.g_varchar2_table(441) := ''||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete';
wwv_flow_imp.g_varchar2_table(442) := '_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  84 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , ';
wwv_flow_imp.g_varchar2_table(443) := '7 '||wwv_flow.LF||
'       , ''Design production screens for main Partner Portal app'' '||wwv_flow.LF||
'       , ''Implement fully funct';
wwv_flow_imp.g_varchar2_table(444) := 'ional and complete screens to cover the major functional areas in Phase 1.'' '||wwv_flow.LF||
'       , 19 '||wwv_flow.LF||
'       , ''';
wwv_flow_imp.g_varchar2_table(445) := 'N'' '||wwv_flow.LF||
'       , to_date(''20150117'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150123'', ''YYYYMMDD'') ';
wwv_flow_imp.g_varchar2_table(446) := '+ l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Milestone 3 for Project 5 '||wwv_flow.LF||
'    insert into eba_demo_md_miles';
wwv_flow_imp.g_varchar2_table(447) := 'tones '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , due_date '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(448) := '   ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  20 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , ''Perform Beta testing with select Partners'' '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(449) := '    , ''Work with a few key partners to trial Phase 1 of the Partner Portal app.'' '||wwv_flow.LF||
'       , to_date(''';
wwv_flow_imp.g_varchar2_table(450) := '20150129'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Tasks for Project 5 / Milestone 3 '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(451) := '  insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name ';
wwv_flow_imp.g_varchar2_table(452) := ''||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       ,';
wwv_flow_imp.g_varchar2_table(453) := ' end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  85 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , 10 '||wwv_flow.LF||
'       , ''Train Partners'' '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(454) := '    , ''Train selected partners in how to use the Partner Portal app.'' '||wwv_flow.LF||
'       , 20 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(455) := '     , to_date(''20150122'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150122'', ''YYYYMMDD'') + l_ad';
wwv_flow_imp.g_varchar2_table(456) := 'd_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , as';
wwv_flow_imp.g_varchar2_table(457) := 'signee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(458) := ', start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  86 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , 4 '||wwv_flow.LF||
'       , ';
wwv_flow_imp.g_varchar2_table(459) := '''Monitor Partners'' '||wwv_flow.LF||
'       , ''Monitor partners selected for the Beta and provide assistance as neces';
wwv_flow_imp.g_varchar2_table(460) := 'sary.'' '||wwv_flow.LF||
'       , 20 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150123'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , t';
wwv_flow_imp.g_varchar2_table(461) := 'o_date(''20150128'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      ( ';
wwv_flow_imp.g_varchar2_table(462) := ' id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone';
wwv_flow_imp.g_varchar2_table(463) := '_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  ';
wwv_flow_imp.g_varchar2_table(464) := '87 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , 7'||wwv_flow.LF||
'       , ''Review Beta Feedback'' '||wwv_flow.LF||
'       , ''Analyse feedback from the part';
wwv_flow_imp.g_varchar2_table(465) := 'ners who participated in the Beta program.'' '||wwv_flow.LF||
'       , 20 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150129'',';
wwv_flow_imp.g_varchar2_table(466) := ' ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150129'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(467) := ' Insert Milestone 4 for Project 5 '||wwv_flow.LF||
'    insert into eba_demo_md_milestones '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , pro';
wwv_flow_imp.g_varchar2_table(468) := 'ject_id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , due_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  21 '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(469) := '      , 5 '||wwv_flow.LF||
'       , ''Complete Phase 1 Development of Partner Portal app'' '||wwv_flow.LF||
'       , ''Based on the res';
wwv_flow_imp.g_varchar2_table(470) := 'ults of the Beta program, enhance the application to make production ready.'' '||wwv_flow.LF||
'       , to_date(''2015';
wwv_flow_imp.g_varchar2_table(471) := '0225'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Tasks for Project 5 / Milestone 4 '||wwv_flow.LF||
'    in';
wwv_flow_imp.g_varchar2_table(472) := 'sert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(473) := '    , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end';
wwv_flow_imp.g_varchar2_table(474) := '_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  88 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , ''Improve existing feature ';
wwv_flow_imp.g_varchar2_table(475) := 'functions'' '||wwv_flow.LF||
'       , ''Enhance existing features based on responses from Beta partners.'' '||wwv_flow.LF||
'       , 21';
wwv_flow_imp.g_varchar2_table(476) := ' '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150201'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150220'', ';
wwv_flow_imp.g_varchar2_table(477) := '''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , proje';
wwv_flow_imp.g_varchar2_table(478) := 'ct_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_co';
wwv_flow_imp.g_varchar2_table(479) := 'mplete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  89 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(480) := '    , 3 '||wwv_flow.LF||
'       , ''Add required feature functions'' '||wwv_flow.LF||
'       , ''Add missing features outlined in respo';
wwv_flow_imp.g_varchar2_table(481) := 'nses from Beta partners.'' '||wwv_flow.LF||
'       , 21 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150201'', ''YYYYMMDD'') + l_a';
wwv_flow_imp.g_varchar2_table(482) := 'dd_days '||wwv_flow.LF||
'       , to_date(''20150220'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo';
wwv_flow_imp.g_varchar2_table(483) := '_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description ';
wwv_flow_imp.g_varchar2_table(484) := ''||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(485) := '  values '||wwv_flow.LF||
'      (  90 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , 12 '||wwv_flow.LF||
'       , ''Load full production data'' '||wwv_flow.LF||
'       , ''Ensu';
wwv_flow_imp.g_varchar2_table(486) := 're all data required for production roll out are inserted and maintained.'' '||wwv_flow.LF||
'       , 21 '||wwv_flow.LF||
'       , ''N';
wwv_flow_imp.g_varchar2_table(487) := ''' '||wwv_flow.LF||
'       , to_date(''20150215'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150220'', ''YYYYMMDD'') +';
wwv_flow_imp.g_varchar2_table(488) := ' l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(489) := ' , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(490) := '     , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  91 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , 8 '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(491) := '   , ''Test Production Partner Portal'' '||wwv_flow.LF||
'       , ''Do full scale testing on the Partner Portal applica';
wwv_flow_imp.g_varchar2_table(492) := 'tion.'' '||wwv_flow.LF||
'       , 21 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150221'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , t';
wwv_flow_imp.g_varchar2_table(493) := 'o_date(''20150225'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Milestone 5 for Project 5 '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(494) := '  insert into eba_demo_md_milestones '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , desc';
wwv_flow_imp.g_varchar2_table(495) := 'ription '||wwv_flow.LF||
'       , due_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  22 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , ''Roll out Phase 1';
wwv_flow_imp.g_varchar2_table(496) := ' of Partner Portal app'' '||wwv_flow.LF||
'       , ''Go-Live for the Partner Portal application to all partners.'' '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(497) := '    , to_date(''20150301'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- Insert Tasks for Project 5 / ';
wwv_flow_imp.g_varchar2_table(498) := 'Milestone 5 '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee ';
wwv_flow_imp.g_varchar2_table(499) := ''||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start';
wwv_flow_imp.g_varchar2_table(500) := '_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  92 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , 3 '||wwv_flow.LF||
'       , ''Instal';
wwv_flow_imp.g_varchar2_table(501) := 'l Partner Portal app onto Production Server'' '||wwv_flow.LF||
'       , ''Install the database objects and application';
wwv_flow_imp.g_varchar2_table(502) := '(s) into the production environment.'' '||wwv_flow.LF||
'       , 22 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150226'', ''YYYY';
wwv_flow_imp.g_varchar2_table(503) := 'MMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150226'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert i';
wwv_flow_imp.g_varchar2_table(504) := 'nto eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , ';
wwv_flow_imp.g_varchar2_table(505) := 'description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date ';
wwv_flow_imp.g_varchar2_table(506) := ''||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  93 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , 12 '||wwv_flow.LF||
'       , ''Configure production data load';
wwv_flow_imp.g_varchar2_table(507) := ' procedures'' '||wwv_flow.LF||
'       , ''Install and test data load procedures from internal and external data source';
wwv_flow_imp.g_varchar2_table(508) := 's into production environment.'' '||wwv_flow.LF||
'       , 22 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150227'', ''YYYYMMDD'')';
wwv_flow_imp.g_varchar2_table(509) := ' + l_add_days '||wwv_flow.LF||
'       , to_date(''20150228'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eb';
wwv_flow_imp.g_varchar2_table(510) := 'a_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'       , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , descri';
wwv_flow_imp.g_varchar2_table(511) := 'ption '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'       , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(512) := ' ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  94 '||wwv_flow.LF||
'       , 5 '||wwv_flow.LF||
'       , 7'||wwv_flow.LF||
'       , ''Provide user credentials for partners''';
wwv_flow_imp.g_varchar2_table(513) := ' '||wwv_flow.LF||
'       , ''Define user credentials for each partner to allow access to the Partner Portal app.'' '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(514) := '     , 22 '||wwv_flow.LF||
'       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150228'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20';
wwv_flow_imp.g_varchar2_table(515) := '150228'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_demo_md_tasks '||wwv_flow.LF||
'      (  id '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(516) := '  , project_id '||wwv_flow.LF||
'       , assignee '||wwv_flow.LF||
'       , name '||wwv_flow.LF||
'       , description '||wwv_flow.LF||
'       , milestone_id '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(517) := '  , is_complete_yn '||wwv_flow.LF||
'       , start_date '||wwv_flow.LF||
'       , end_date '||wwv_flow.LF||
'      ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'      (  95 '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(518) := ' , 5 '||wwv_flow.LF||
'       , 1 '||wwv_flow.LF||
'       , ''Announce Partner Portal app to all partners'' '||wwv_flow.LF||
'       , ''Email or call pa';
wwv_flow_imp.g_varchar2_table(519) := 'rtners to inform them of the new application and instructions on how to get started.'' '||wwv_flow.LF||
'       , 22 '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(520) := '       , ''N'' '||wwv_flow.LF||
'       , to_date(''20150301'', ''YYYYMMDD'') + l_add_days '||wwv_flow.LF||
'       , to_date(''20150301'', ''Y';
wwv_flow_imp.g_varchar2_table(521) := 'YYYMMDD'') + l_add_days '||wwv_flow.LF||
'      ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'  end load_sample_data; '||wwv_flow.LF||
' '||wwv_flow.LF||
'  procedure remove_sample_data is '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(522) := 'begin '||wwv_flow.LF||
'    delete from eba_demo_md_team_members;'||wwv_flow.LF||
'    delete from eba_demo_md_projects; '||wwv_flow.LF||
'      -- Cas';
wwv_flow_imp.g_varchar2_table(523) := 'cade delete will delete Milestones, Tasks, Task ToDos, Task Links and Comment records '||wwv_flow.LF||
'  end remove_';
wwv_flow_imp.g_varchar2_table(524) := 'sample_data; '||wwv_flow.LF||
' '||wwv_flow.LF||
'end eba_demo_md_data_pkg; '||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-----------------------'||wwv_flow.LF||
'--<< Load the Data >>--'||wwv_flow.LF||
'-----';
wwv_flow_imp.g_varchar2_table(525) := '------------------'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  eba_demo_md_data_pkg.load_sample_data;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(27396689229659065939)
,p_install_id=>wwv_flow_imp.id(49288120094371048011)
,p_name=>'Create Data Package'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
