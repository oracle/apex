prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7860
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7860
,p_default_id_offset=>11438353329529351
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '--<< Drop existing DB Objects >>--'||wwv_flow.LF||
'drop table eba_demo_md_status cascade constraints;'||wwv_flow.LF||
'drop table eba';
wwv_flow_imp.g_varchar2_table(2) := '_demo_md_team_members cascade constraints;'||wwv_flow.LF||
'drop table eba_demo_md_projects cascade constraints;'||wwv_flow.LF||
'drop';
wwv_flow_imp.g_varchar2_table(3) := ' table eba_demo_md_milestones cascade constraints;'||wwv_flow.LF||
'drop table eba_demo_md_tasks cascade constraints;';
wwv_flow_imp.g_varchar2_table(4) := ''||wwv_flow.LF||
'drop table eba_demo_md_task_todos cascade constraints;'||wwv_flow.LF||
'drop table eba_demo_md_task_links cascade co';
wwv_flow_imp.g_varchar2_table(5) := 'nstraints;'||wwv_flow.LF||
'drop table eba_demo_md_comments cascade constraints;'||wwv_flow.LF||
'drop package eba_demo_md_data_pkg;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(49288120094371048011)
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
);
wwv_flow_imp.component_end;
end;
/
