prompt --application/shared_components/navigation/lists/task_actions
begin
--   Manifest
--     LIST: Task Actions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7860
,p_default_id_offset=>11438353329529351
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4627088936615946135)
,p_name=>'Task Actions'
,p_static_id=>'task-actions'
,p_version_scn=>'1089079371'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4627090356478946139)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Add Link'
,p_static_id=>'add-link'
,p_list_item_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:23:P23_PROJECT_ID,P23_TASK_ID:&P31_PROJECT_ID.,&P31_TASK_ID.:'
,p_list_item_icon=>'fa-link'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4627089968362946138)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Add To Do'
,p_static_id=>'add-to-do'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15:P15_PROJECT_ID,P15_TASK_ID:&P31_PROJECT_ID.,&P31_TASK_ID.:'
,p_list_item_icon=>'fa-list'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
