prompt --application/shared_components/security/authorizations/team_members
begin
--   Manifest
--     SECURITY SCHEME: Team Members
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7860
,p_default_id_offset=>11438353329529351
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(27400947937091918504)
,p_name=>'Team Members'
,p_static_id=>'team-members'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'sql_query', wwv_flow_string.join(wwv_flow_t_varchar2(
    'select 1',
    'from eba_demo_md_team_members',
    'where upper(username) = upper(:APP_USER)')))).to_clob
,p_error_message=>'You must be a team member to use this application.'
,p_version_scn=>'1089079371'
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
