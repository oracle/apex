prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7860
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7860
,p_default_id_offset=>11438353329529351
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(49288120094371048011)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--<< Drop existing DB Objects >>--',
'drop table eba_demo_md_status cascade constraints;',
'drop table eba_demo_md_team_members cascade constraints;',
'drop table eba_demo_md_projects cascade constraints;',
'drop table eba_demo_md_milestones cascade constraints;',
'drop table eba_demo_md_tasks cascade constraints;',
'drop table eba_demo_md_task_todos cascade constraints;',
'drop table eba_demo_md_task_links cascade constraints;',
'drop table eba_demo_md_comments cascade constraints;',
'drop package eba_demo_md_data_pkg;',
''))
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
);
wwv_flow_imp.component_end;
end;
/
