prompt --application/shared_components/user_interface/lovs/p18_milestones
begin
--   Manifest
--     P18_MILESTONES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7860
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(77087910827834232)
,p_lov_name=>'P18_MILESTONES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select name || '' ['' || due_date || '']'' as display',
', id as return',
'from eba_demo_md_milestones',
'where project_id = :P18_PROJECT_ID',
'order by due_date'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
);
wwv_flow_imp.component_end;
end;
/
