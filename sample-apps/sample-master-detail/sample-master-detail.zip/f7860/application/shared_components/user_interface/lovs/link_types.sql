prompt --application/shared_components/user_interface/lovs/link_types
begin
--   Manifest
--     LINK TYPES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7860
,p_default_id_offset=>11438353329529351
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(4917069923468576034)
,p_lov_name=>'LINK TYPES'
,p_lov_query=>'.'||wwv_flow_imp.id(4917069923468576034)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089079371
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(4917070214053576039)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'URL'
,p_lov_return_value=>'URL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(4917070655571576045)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Application'
,p_lov_return_value=>'Application'
);
wwv_flow_imp.component_end;
end;
/
