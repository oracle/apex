prompt --application/shared_components/navigation/lists/master_detail_pages
begin
--   Manifest
--     LIST: Master Detail Pages
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7860
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(4619340949342823680)
,p_name=>'Master Detail Pages'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5399073350479673577)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Stacked'
,p_list_item_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layers'
,p_list_text_01=>'A single page master-detail utilizing editable Interactive Grids.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3938625902193493419)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Stacked with Sub Detail'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layers'
,p_list_text_01=>'A single page master-detail-subdetail utilizing editable Interactive Grids.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(77251932042980598)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Side by Side'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header-sidebar-left'
,p_list_text_01=>'A single page master-detail utilizing side by side layout and report regions with modal edit windows.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5403098029093072824)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Drill Down'
,p_list_item_link_target=>'f?p=&APP_ID.:48:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clone'
,p_list_text_01=>'Consists of a report page that drills down to a page where the selected master is standard form items, and the detail tables use editable Interactive Grids.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'48,49'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(49142184473448297189)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Report and Marquee'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cards'
,p_list_text_01=>'Consists of a report page that drills down to a marquee page. On the marquee page each of the detail tables are shown using a classic report.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4,5,11'
);
wwv_flow_api.component_end;
end;
/
