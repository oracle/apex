prompt --application/shared_components/navigation/listentry
begin
--   Manifest
--     LIST ENTRY: 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7860
,p_default_id_offset=>11438353329529351
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
