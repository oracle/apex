prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7860
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(48358384961973028554)
,p_name=>' Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(76141687990660463)
,p_short_name=>'Side by Side'
,p_link=>'f?p=&APP_ID.:2:&SESSION.'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3903044138303471644)
,p_parent_id=>0
,p_short_name=>'To Dos'
,p_link=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:::'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3903054602954496852)
,p_parent_id=>0
,p_short_name=>'Links'
,p_link=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:::'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3905587492626784325)
,p_parent_id=>0
,p_short_name=>'Milestones'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3905602593655798541)
,p_short_name=>'Tasks'
,p_link=>'f?p=&APP_ID.:8:&SESSION.'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3938622366000479022)
,p_parent_id=>0
,p_short_name=>'Stacked with Sub Detail'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4534421848678362227)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:24:&SESSION.'
,p_page_id=>24
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4549858048124154330)
,p_parent_id=>wwv_flow_imp.id(4534421848678362227)
,p_short_name=>'Preferences'
,p_link=>'f?p=&APP_ID.:25:&SESSION.'
,p_page_id=>25
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4549866595452162483)
,p_parent_id=>wwv_flow_imp.id(4534421848678362227)
,p_short_name=>'Manage Sample Data'
,p_link=>'f?p=&APP_ID.:26:&SESSION.'
,p_page_id=>26
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4549875096339168617)
,p_parent_id=>wwv_flow_imp.id(4534421848678362227)
,p_short_name=>'Application Theme Style'
,p_link=>'f?p=&APP_ID.:27:&SESSION.'
,p_page_id=>27
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4553320290561560507)
,p_parent_id=>wwv_flow_imp.id(4534421848678362227)
,p_short_name=>'Activity Calendar'
,p_link=>'f?p=&APP_ID.:28:&SESSION.'
,p_page_id=>28
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4553354132756627517)
,p_parent_id=>wwv_flow_imp.id(4534421848678362227)
,p_short_name=>'Page Views'
,p_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:::'
,p_page_id=>29
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4553354290808629006)
,p_parent_id=>wwv_flow_imp.id(4534421848678362227)
,p_short_name=>'Top Users'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4615332483694500632)
,p_parent_id=>0
,p_short_name=>'Stacked'
,p_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
,p_page_id=>33
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4615568669507010079)
,p_parent_id=>wwv_flow_imp.id(30704410149770129503)
,p_short_name=>'&P31_TASK_NAME.'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4619313852079804482)
,p_parent_id=>0
,p_short_name=>'Drill Down'
,p_link=>'f?p=&APP_ID.:48:&SESSION.::&DEBUG.:::'
,p_page_id=>48
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4619328060767804596)
,p_parent_id=>wwv_flow_imp.id(4619313852079804482)
,p_short_name=>'&P49_NAME.'
,p_link=>'f?p=&APP_ID.:49:&SESSION.::&DEBUG.:::'
,p_page_id=>49
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4904853910391528202)
,p_parent_id=>wwv_flow_imp.id(4904852746544528196)
,p_short_name=>'Maintain To Do'
,p_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4905631049973031106)
,p_parent_id=>wwv_flow_imp.id(4905629884547031103)
,p_short_name=>'Maintain Link'
,p_link=>'f?p=&APP_ID.:23:&SESSION.'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(30704410149770129503)
,p_parent_id=>wwv_flow_imp.id(48358394064207028833)
,p_short_name=>'&P11_PROJECT_NAME.'
,p_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_page_id=>11
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(32134399708790739821)
,p_parent_id=>wwv_flow_imp.id(32134398525263739819)
,p_short_name=>'Add Comment'
,p_link=>'f?p=&APP_ID.:13:&SESSION.'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48358385344036028561)
,p_parent_id=>0
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48358394064207028833)
,p_parent_id=>0
,p_option_sequence=>30
,p_short_name=>'Report and Marquee'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48358408906001029233)
,p_parent_id=>wwv_flow_imp.id(48358405080990029092)
,p_option_sequence=>60
,p_short_name=>'Maintain Task'
,p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_imp.component_end;
end;
/
