prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_imp.id(1121353497734510372)
,p_name=>'Project Tracking'
,p_alias=>'PROJECT-TRACKING'
,p_step_title=>'Project Tracking'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_step_template=>wwv_flow_imp.id(1585422579688301441)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'17'
,p_last_upd_yyyymmddhh24miss=>'20210301103216'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1320216890151221838)
,p_plug_name=>'SQL Source'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(1585435226411301463)
,p_plug_display_sequence=>30
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.DISPLAY_SOURCE'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'task_tree'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3158114294271612928)
,p_plug_name=>'Task Tree'
,p_region_name=>'task_tree'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(1585439443339301476)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when connect_by_isleaf = 1 then 0',
'            when level = 1             then 1',
'            else                           -1',
'       end as status, ',
'       level, ',
'       label||'': ''||name as title, ',
'       case when item_type = ''P'' then ''fa-file-text-o''',
'            when item_type = ''S'' then ''fa-caret-square-o-right''',
'            when item_type = ''T'' then ''fa-minus-square-o''',
'       else null',
'       end as icon, ',
'       id as value, ',
'       case when tooltip is not null then name||'' - ''||tooltip||''% complete''',
'            else name',
'       end as tooltip,',
'       case when item_type = ''P'' then ',
'               apex_util.prepare_url(''f?p=''||:app_id||'':7:''||:app_session||'':T:::P3_SELECTED_NODE,P7_PROJ_ID:''||id||'',''||id)',
'            when item_type = ''T'' then',
'               apex_util.prepare_url(''f?p=''||:app_id||'':9:''||:app_session||'':T:::P3_SELECTED_NODE,P9_PROJ_ID,P9_TASK_ID:''||id||'',''||link)',
'            when item_type = ''S'' then ',
'               apex_util.prepare_url(''f?p=''||:app_id||'':10:''||:app_session||'':T:::P3_SELECTED_NODE,P10_PROJ_ID,P10_ROWID:''||id||'',''||link)',
'       end as link ',
' from (',
'select ''P'' item_type,',
'       t.label label,',
'       to_char(a.PROJ_ID) id,',
'       null parent,',
'       a.project_name name,',
'       a.status tooltip,',
'       null link',
'  from eba_demo_tree_projects a, (select wwv_flow_lang.system_message(''PROJECT'') label from dual) t',
'union all',
'select ''T'' item_type,',
'       u.label label,',
'       to_char(b.proj_id)||''-''||to_char(b.task_id) id,',
'       to_char(b.proj_id) parent,',
'       b.task_name name,',
'       null tooltip,',
'       b.proj_id||'',''||b.task_id link',
'  from eba_demo_tree_task b, (select wwv_flow_lang.system_message(''TASK'') label from dual) u',
'union all',
'select ''S'' item_type,',
'       v.label label,',
'       to_char(c.proj_id)||''-''||to_char(c.task_id)||''-''||to_char(c.sub_id) id,',
'       to_char(c.proj_id)||''-''||to_char(c.task_id) parent,',
'       c.sub_name name,',
'       null tooltip,',
'       c.proj_id||'',''||c.rowid link',
'  from eba_demo_tree_subtask c, (select wwv_flow_lang.system_message(''SUBTASK'') label from dual) v',
')',
'start with parent is null',
'connect by prior id = parent',
'order siblings by name'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_attribute_02=>'S'
,p_attribute_03=>'P3_SELECTED_NODE'
,p_attribute_04=>'DB'
,p_attribute_06=>'projTrackTree'
,p_attribute_08=>'fa'
,p_attribute_10=>'TITLE'
,p_attribute_11=>'LEVEL'
,p_attribute_12=>'ICON'
,p_attribute_15=>'STATUS'
,p_attribute_20=>'VALUE'
,p_attribute_22=>'TOOLTIP'
,p_attribute_23=>'LEVEL'
,p_attribute_24=>'LINK'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3167901386699608550)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1585442034806301480)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(7263491457246758706)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(1585462806460301546)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3171026984006106783)
,p_plug_name=>'Task_Tracking_Tabs'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody:t-Region--hideHeader'
,p_component_template_options=>'#DEFAULT#:t-MediaList--cols t-MediaList--2cols'
,p_plug_template=>wwv_flow_imp.id(1585439443339301476)
,p_plug_display_sequence=>10
,p_list_id=>wwv_flow_imp.id(3171026188574106764)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(1585457829790301522)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3158114693431612930)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3158114294271612928)
,p_button_name=>'CONTRACT_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1585462573223301545)
,p_button_image_alt=>'Collapse All'
,p_button_position=>'EDIT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3158114893870612930)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(3158114294271612928)
,p_button_name=>'EXPAND_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1585462573223301545)
,p_button_image_alt=>'Expand All'
,p_button_position=>'EDIT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3175346484539183756)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(3158114294271612928)
,p_button_name=>'RESET_TREE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(1585462019447301543)
,p_button_image_alt=>'Reset Tree'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3167896610875435725)
,p_name=>'P3_SELECTED_NODE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3158114294271612928)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1497681166888823947)
,p_name=>'collapse'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3158114693431612930)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1497681265053823948)
,p_event_id=>wwv_flow_imp.id(1497681166888823947)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_COLLAPSE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3158114294271612928)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1497681296337823949)
,p_name=>'expand'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3158114893870612930)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1497681393196823950)
,p_event_id=>wwv_flow_imp.id(1497681296337823949)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3158114294271612928)
);
wwv_flow_imp.component_end;
end;
/
