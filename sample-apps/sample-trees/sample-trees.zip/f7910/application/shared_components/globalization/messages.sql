prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7910
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>12904184294728383
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7537772545338448612)
,p_name=>'AC_CONFIGURATION_INFO'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><b>Enabling Access Control</b> means that access to the application and its features are controlled by the current <b>Access Control List</b>, as defined by the application administrator. There are 3 access levels available that can be granted to '
||'a user; Administrator, Contributor and Reader. Please see the Manager User pages for further details on what each level provides.</p>',
'<p>In addition, if you don''t want to have to define every ''Reader'' of your application, you can select <b>Any Authenticated User</b> from the <b>Reader Access</b> configuration option. This opens read-only access to any user who can authenticate into'
||' your application.</p>',
'<br />',
'<p><b>Disabling Access Control</b> means that access to the application and all of its features including Administration are open to any user who can authenticate to the application.</p>',
'<br />',
'<p>Note: Irrespective of whether Access Control is enabled or disabled, a user still has to authenticate successfully into the application.</p>'))
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7491699122021744602)
,p_name=>'ADMINISTRATION'
,p_message_text=>'Administration'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3183926378793439526)
,p_name=>'APPROVED'
,p_message_text=>'Approved'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3183926581218440192)
,p_name=>'ASSIGNED'
,p_message_text=>'Assigned'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3183927983773450376)
,p_name=>'COMPLETE'
,p_message_text=>'Complete'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3183927371652446912)
,p_name=>'DEMONSTRABLE'
,p_message_text=>'Demonstrable'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3183927576154448167)
,p_name=>'FUNCTIONALLY_COMPLETE'
,p_message_text=>'Functionally Complete'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7491714527909746247)
,p_name=>'HELP'
,p_message_text=>'Help'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3183927781349449642)
,p_name=>'INTEGRATION_COMPLETE'
,p_message_text=>'Integration Complete'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3178811996398596534)
,p_name=>'LOGOUT'
,p_message_text=>'Logout'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7491738142800750618)
,p_name=>'MOBILE'
,p_message_text=>'Mobile'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3183925971521437405)
,p_name=>'NOT_STARTED'
,p_message_text=>'Not Started'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3183934172793929796)
,p_name=>'PROJECT'
,p_message_text=>'Project'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3183927168189445892)
,p_name=>'SIGNIFICANT_PROGRESS'
,p_message_text=>'Significant Progress'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3183934578334931396)
,p_name=>'SUBTASK'
,p_message_text=>'Subtask'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3183934375217930460)
,p_name=>'TASK'
,p_message_text=>'Task'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3183926176369438815)
,p_name=>'UNDER_CONSIDERATION'
,p_message_text=>'Under Consideration'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7491691149941743163)
,p_name=>'USER'
,p_message_text=>'User'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3183926790568442923)
,p_name=>'WORK_INITIATED'
,p_message_text=>'Work Initiated'
,p_version_scn=>37166093906763
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3183926995416444237)
,p_name=>'WORK_PROGRESSING'
,p_message_text=>'Work Progressing'
,p_version_scn=>37166093906763
);
wwv_flow_imp.component_end;
end;
/
