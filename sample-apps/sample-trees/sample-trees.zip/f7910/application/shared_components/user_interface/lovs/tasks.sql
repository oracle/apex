prompt --application/shared_components/user_interface/lovs/tasks
begin
--   Manifest
--     TASKS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>12904184294728383
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(3183806270457091876)
,p_lov_name=>'TASKS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TASK_NAME d, task_id r',
'from   eba_demo_tree_task',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1089079920
);
wwv_flow_imp.component_end;
end;
/
