prompt --application/shared_components/navigation/lists/task_tracking_tabs
begin
--   Manifest
--     LIST: Task_Tracking_Tabs
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>12904184294728383
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3183930372868835147)
,p_name=>'Task_Tracking_Tabs'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089079920
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3183930574651835156)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Task Tree'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3183930877199835163)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Project Dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.:'
,p_list_item_current_for_pages=>'6'
);
wwv_flow_imp.component_end;
end;
/
