prompt --application/shared_components/navigation/lists/trees
begin
--   Manifest
--     LIST: Trees
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>12904184294728383
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3236423369926764802)
,p_name=>'Trees'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089079920
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3236423576293764803)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Project Tracking'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'#APP_IMAGES#trees_project_tracking.jpg'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
