prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7910
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install(
 p_id=>wwv_flow_api.id(5648055138759944877)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop procedure eba_demo_tree_data;',
'drop function varchar2_to_blob;',
'REM Drop tables',
'drop table eba_demo_tree_subtask cascade constraints;',
'drop table eba_demo_tree_task cascade constraints;',
'drop table eba_demo_tree_stocks cascade constraints;',
'drop table eba_demo_tree_emp cascade constraints;',
'drop table eba_demo_tree_dept cascade constraints;',
'drop table eba_demo_tree_population cascade constraints;',
'drop table eba_demo_tree_proj_files cascade constraints;',
'drop table eba_demo_tree_projects cascade constraints;',
'drop view eba_demo_tree_def_st_codes;',
''))
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'EBA_DEMO_TREE_SUBTASK:EBA_DEMO_TREE_TASK:EBA_DEMO_TREE_STOCKS:EBA_DEMO_TREE_EMP:EBA_DEMO_TREE_DEPT:EBA_DEMO_TREE_POPULATION:EBA_DEMO_TREE_PROJ_FILES:EBA_DEMO_TREE_PROJECTS:EBA_DEMO_TREE_DEF_ST_CODES:EBA_DEMO_TREE_DATA'
);
wwv_flow_api.component_end;
end;
/
