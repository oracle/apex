prompt --application/deployment/install/install_create_funtion
begin
--   Manifest
--     INSTALL: INSTALL-Create funtion
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>12904184294728383
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3285974489903843354)
,p_install_id=>wwv_flow_imp.id(5660959323054673260)
,p_name=>'Create funtion'
,p_sequence=>27
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* varchar2_to_blob function */',
'create or replace function varchar2_to_blob(p_varchar2_tab in dbms_sql.varchar2_table)',
'    return blob',
'is',
'  l_blob blob;',
'  l_raw  raw(500);',
'  l_size number;',
'begin',
'  dbms_lob.createtemporary(l_blob, true, dbms_lob.session);',
'  for i in 1 .. p_varchar2_tab.count loop',
'    l_size := length(p_varchar2_tab(i)) / 2;',
'    dbms_lob.writeappend(l_blob, l_size, hextoraw(p_varchar2_tab(i)));',
'  end loop;',
'  return l_blob;',
'exception',
'  when others then',
'    dbms_lob.close(l_blob);',
'end;  ',
'/',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
