prompt --application/deployment/install/install_create_view
begin
--   Manifest
--     INSTALL: INSTALL-Create View
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3171024089912728699)
,p_install_id=>wwv_flow_imp.id(5648055138759944877)
,p_name=>'Create View'
,p_sequence=>25
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE FORCE VIEW  "EBA_DEMO_TREE_DEF_ST_CODES" ("PCT_COMPLETE", "STATUS_NAME") AS ',
'select 0   pct_complete, wwv_flow_lang.system_message(''NOT_STARTED'')                  status_name from dual union all',
'select 10  pct_complete, wwv_flow_lang.system_message(''UNDER_CONSIDERATION'')          status_name from dual union all',
'select 20  pct_complete, wwv_flow_lang.system_message(''APPROVED'')                     status_name from dual union all',
'select 30  pct_complete, wwv_flow_lang.system_message(''ASSIGNED'')                     status_name from dual union all',
'select 40  pct_complete, wwv_flow_lang.system_message(''WORK_INITIATED'')               status_name from dual union all',
'select 50  pct_complete, wwv_flow_lang.system_message(''WORK_PROGRESSING'')             status_name from dual union all',
'select 60  pct_complete, wwv_flow_lang.system_message(''SIGNIFICANT_PROGRESS'')         status_name from dual union all',
'select 70  pct_complete, wwv_flow_lang.system_message(''DEMONSTRABLE'')                 status_name from dual union all',
'select 80  pct_complete, wwv_flow_lang.system_message(''FUNCTIONALLY_COMPLETE'')        status_name from dual union all',
'select 90  pct_complete, wwv_flow_lang.system_message(''INTEGRATION_COMPLETE'')         status_name from dual union all',
'select 100 pct_complete, wwv_flow_lang.system_message(''COMPLETE'')                     status_name from dual',
'/'))
);
wwv_flow_imp.component_end;
end;
/
