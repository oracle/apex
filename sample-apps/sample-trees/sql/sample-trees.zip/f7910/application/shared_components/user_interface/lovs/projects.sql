prompt --application/shared_components/user_interface/lovs/projects
begin
--   Manifest
--     PROJECTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>12904184294728383
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(3183763179049564503)
,p_lov_name=>'PROJECTS'
,p_static_id=>'projects'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select project_name d, proj_id r',
'from   eba_demo_tree_projects',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'1089079920'
);
wwv_flow_imp.component_end;
end;
/
