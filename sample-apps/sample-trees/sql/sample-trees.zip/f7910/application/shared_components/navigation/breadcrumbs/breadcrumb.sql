prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>12904184294728383
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(7276395641541487089)
,p_name=>' Breadcrumb'
,p_static_id=>'breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2140028562873923323)
,p_short_name=>'Administration'
,p_static_id=>'administration'
,p_link=>'f?p=&APP_ID.:5:&SESSION.'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2140041806945948481)
,p_parent_id=>wwv_flow_imp.id(2140028562873923323)
,p_short_name=>'Application Theme Style'
,p_static_id=>'application-theme-style'
,p_link=>'f?p=&APP_ID.:8:&SESSION.'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3183716694837686566)
,p_parent_id=>wwv_flow_imp.id(3183718782267768413)
,p_short_name=>'Create/Edit Project'
,p_static_id=>'create-edit-project'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3183727288374386258)
,p_short_name=>'Create/Edit Tasks'
,p_static_id=>'create-edit-tasks'
,p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3178811187683584795)
,p_parent_id=>wwv_flow_imp.id(7276396053389487092)
,p_short_name=>'Help'
,p_static_id=>'help'
,p_link=>'f?p=&FLOW_ID.:4:&SESSION.'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(7276396053389487092)
,p_short_name=>'Home'
,p_static_id=>'home'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3285972593295792186)
,p_parent_id=>wwv_flow_imp.id(2140028562873923323)
,p_short_name=>'Manage Sample Data'
,p_static_id=>'manage-sample-data'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3183727370586386258)
,p_parent_id=>wwv_flow_imp.id(3183727288374386258)
,p_short_name=>'Modify Subtask Information'
,p_static_id=>'modify-subtask-information'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3183718782267768413)
,p_parent_id=>wwv_flow_imp.id(3180805869152336944)
,p_short_name=>'Project Dashboard'
,p_static_id=>'project-dashboard'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3180805869152336944)
,p_short_name=>'Project Tracking'
,p_static_id=>'project-tracking'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp.component_end;
end;
/
