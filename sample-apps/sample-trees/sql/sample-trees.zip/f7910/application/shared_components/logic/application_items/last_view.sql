prompt --application/shared_components/logic/application_items/last_view
begin
--   Manifest
--     APPLICATION ITEM: LAST_VIEW
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>12904184294728383
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(3183941073777176084)
,p_name=>'LAST_VIEW'
,p_protection_level=>'I'
,p_version_scn=>'SH256:J_BYmc1EWxTg8Bn7yWX19lhE6KuJKGGMZ9krhWcjnD8'
);
wwv_flow_imp.component_end;
end;
/
