prompt --application/deployment/install/install_create_tables
begin
--   Manifest
--     INSTALL: INSTALL-Create Tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>12904184294728383
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'REM eba_demo_tree_projects'||wwv_flow.LF||
'create table  eba_demo_tree_projects ('||wwv_flow.LF||
'    proj_id              number   ';
wwv_flow_imp.g_varchar2_table(2) := '      not null'||wwv_flow.LF||
'                                        constraint eba_demo_tree_proj_pk'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(3) := '                            primary key,'||wwv_flow.LF||
'    project_name         varchar2(4000) not null,'||wwv_flow.LF||
'    start';
wwv_flow_imp.g_varchar2_table(4) := '_date           date,'||wwv_flow.LF||
'    estimated_completion date,'||wwv_flow.LF||
'    completion_date      date,'||wwv_flow.LF||
'    status      ';
wwv_flow_imp.g_varchar2_table(5) := '         number,'||wwv_flow.LF||
'    description          clob,'||wwv_flow.LF||
'    row_version_number   number,'||wwv_flow.LF||
'    created        ';
wwv_flow_imp.g_varchar2_table(6) := '      timestamp(6) with time zone,'||wwv_flow.LF||
'    created_by           varchar2(255),'||wwv_flow.LF||
'    updated              ';
wwv_flow_imp.g_varchar2_table(7) := 'timestamp(6) with time zone,'||wwv_flow.LF||
'    updated_by           varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'REM eba_demo_tree_task  ';
wwv_flow_imp.g_varchar2_table(8) := '  '||wwv_flow.LF||
'create table  eba_demo_tree_task ('||wwv_flow.LF||
'    task_id                  number         not null'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(9) := '                                   constraint eba_demo_tree_task_pk'||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(10) := '            primary key,'||wwv_flow.LF||
'    proj_id                  number         not null'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(11) := '                      constraint eba_demo_tree_task_fk'||wwv_flow.LF||
'                                            r';
wwv_flow_imp.g_varchar2_table(12) := 'eferences eba_demo_tree_projects on delete cascade,'||wwv_flow.LF||
'    task_name                varchar2(4000),'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(13) := ' task_start               date,'||wwv_flow.LF||
'    task_est_comp            date,'||wwv_flow.LF||
'    task_comp                date';
wwv_flow_imp.g_varchar2_table(14) := ','||wwv_flow.LF||
'    task_priority            number,'||wwv_flow.LF||
'    task_status              number,'||wwv_flow.LF||
'    task_assign         ';
wwv_flow_imp.g_varchar2_table(15) := '     number,'||wwv_flow.LF||
'    task_desc                clob,'||wwv_flow.LF||
'    row_version_number       number,'||wwv_flow.LF||
'    created    ';
wwv_flow_imp.g_varchar2_table(16) := '              timestamp(6) with time zone,'||wwv_flow.LF||
'    created_by               varchar2(255),'||wwv_flow.LF||
'    updated  ';
wwv_flow_imp.g_varchar2_table(17) := '                timestamp(6) with time zone,'||wwv_flow.LF||
'    updated_by               varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'crea';
wwv_flow_imp.g_varchar2_table(18) := 'te index eba_demo_tree_task_idx1 on eba_demo_tree_task (proj_id);'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'REM eba_demo_tree_subtask    '||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(19) := 'reate table eba_demo_tree_subtask ('||wwv_flow.LF||
'    sub_id               number         not null,'||wwv_flow.LF||
'    proj_id   ';
wwv_flow_imp.g_varchar2_table(20) := '           number         not null,'||wwv_flow.LF||
'    task_id              number         not null,'||wwv_flow.LF||
'    sub_name  ';
wwv_flow_imp.g_varchar2_table(21) := '           varchar2(4000),'||wwv_flow.LF||
'    sub_start            date,'||wwv_flow.LF||
'    sub_est_comp         date,'||wwv_flow.LF||
'    sub_com';
wwv_flow_imp.g_varchar2_table(22) := 'p             date,'||wwv_flow.LF||
'    sub_priority         varchar2(400),'||wwv_flow.LF||
'    sub_status           varchar2(400),'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(23) := '    sub_assign           varchar2(400),'||wwv_flow.LF||
'    sub_desc             clob,'||wwv_flow.LF||
'    row_version_number   numb';
wwv_flow_imp.g_varchar2_table(24) := 'er,'||wwv_flow.LF||
'    created              timestamp(6) with time zone,'||wwv_flow.LF||
'    created_by           varchar2(255),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(25) := '  updated              timestamp(6) with time zone,'||wwv_flow.LF||
'    updated_by           varchar2(255),'||wwv_flow.LF||
'    cons';
wwv_flow_imp.g_varchar2_table(26) := 'traint eba_demo_tree_subtask_pk primary key (sub_id, proj_id, task_id)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/    '||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_';
wwv_flow_imp.g_varchar2_table(27) := 'demo_tree_subtask_idx1 on eba_demo_tree_subtask (task_id);'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_tree_subtask_idx';
wwv_flow_imp.g_varchar2_table(28) := '2 on eba_demo_tree_subtask (proj_id);'||wwv_flow.LF||
'/    '||wwv_flow.LF||
'    '||wwv_flow.LF||
'REM eba_demo_tree_stocks    '||wwv_flow.LF||
'create table eba_demo_';
wwv_flow_imp.g_varchar2_table(29) := 'tree_stocks ('||wwv_flow.LF||
'    id                  number       not null'||wwv_flow.LF||
'                                     con';
wwv_flow_imp.g_varchar2_table(30) := 'straint eba_demo_tree_stocks_pk'||wwv_flow.LF||
'                                     primary key,'||wwv_flow.LF||
'    row_version_nu';
wwv_flow_imp.g_varchar2_table(31) := 'mber  number,'||wwv_flow.LF||
'    stock_code          varchar2(4),'||wwv_flow.LF||
'    stock_name          varchar2(130),'||wwv_flow.LF||
'    pricin';
wwv_flow_imp.g_varchar2_table(32) := 'g_date        date,'||wwv_flow.LF||
'    opening_val         number,'||wwv_flow.LF||
'    high                number,'||wwv_flow.LF||
'    low         ';
wwv_flow_imp.g_varchar2_table(33) := '        number,'||wwv_flow.LF||
'    closing_val         number,'||wwv_flow.LF||
'    created             timestamp(6) with time zone,';
wwv_flow_imp.g_varchar2_table(34) := ''||wwv_flow.LF||
'    created_by          varchar2(255),'||wwv_flow.LF||
'    updated             timestamp(6) with time zone,'||wwv_flow.LF||
'    upd';
wwv_flow_imp.g_varchar2_table(35) := 'ated_by          varchar2(255)    '||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'REM eba_demo_tree_population    '||wwv_flow.LF||
'create table eba_dem';
wwv_flow_imp.g_varchar2_table(36) := 'o_tree_population ('||wwv_flow.LF||
'    id                  number          not null'||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(37) := '         constraint eba_demo_tree_pop_pk'||wwv_flow.LF||
'                                        primary key,'||wwv_flow.LF||
'    ro';
wwv_flow_imp.g_varchar2_table(38) := 'w_version_number  number,'||wwv_flow.LF||
'    state_name          varchar2(100),'||wwv_flow.LF||
'    state_code          varchar2(2)';
wwv_flow_imp.g_varchar2_table(39) := ','||wwv_flow.LF||
'    population          number,'||wwv_flow.LF||
'    region              number,'||wwv_flow.LF||
'    created             timestamp(';
wwv_flow_imp.g_varchar2_table(40) := '6) with time zone,'||wwv_flow.LF||
'    created_by          varchar2(255),'||wwv_flow.LF||
'    updated             timestamp(6) with ';
wwv_flow_imp.g_varchar2_table(41) := 'time zone,'||wwv_flow.LF||
'    updated_by          varchar2(255)    '||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'REM eba_demo_tree_dept'||wwv_flow.LF||
'create table eba';
wwv_flow_imp.g_varchar2_table(42) := '_demo_tree_dept ('||wwv_flow.LF||
'    deptno  NUMBER(2,0) not null'||wwv_flow.LF||
'                        constraint eba_demo_tree_';
wwv_flow_imp.g_varchar2_table(43) := 'dept_pk'||wwv_flow.LF||
'                        primary key,'||wwv_flow.LF||
'    dname   VARCHAR2(14 BYTE),'||wwv_flow.LF||
'    loc     VARCHAR2(13 ';
wwv_flow_imp.g_varchar2_table(44) := 'BYTE)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'REM eba_demo_tree_emp'||wwv_flow.LF||
'create table eba_demo_tree_emp ('||wwv_flow.LF||
'    empno     NUMBER(4,0) not null'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(45) := '                          constraint eba_demo_tree_emp_pk'||wwv_flow.LF||
'                          primary key,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(46) := ' ename     VARCHAR2(10 BYTE),'||wwv_flow.LF||
'    job       VARCHAR2(9 BYTE),'||wwv_flow.LF||
'    mgr       NUMBER(4,0),'||wwv_flow.LF||
'    hiredat';
wwv_flow_imp.g_varchar2_table(47) := 'e  DATE,'||wwv_flow.LF||
'    sal       NUMBER(7,2),'||wwv_flow.LF||
'    comm      NUMBER(7,2),'||wwv_flow.LF||
'    deptno    NUMBER(2,0)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter ';
wwv_flow_imp.g_varchar2_table(48) := 'table eba_demo_tree_emp add foreign key (MGR) references eba_demo_tree_emp (EMPNO) ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(49) := 'index eba_demo_tree_emp_1 ON eba_demo_tree_emp (MGR)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'create index eba_demo_tree_emp_2 ON eba_';
wwv_flow_imp.g_varchar2_table(50) := 'demo_tree_emp (DEPTNO)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_tree_proj_files ('||wwv_flow.LF||
'    id                      number';
wwv_flow_imp.g_varchar2_table(51) := '         not null,'||wwv_flow.LF||
'    row_version_number      number         not null,'||wwv_flow.LF||
'    project_id              ';
wwv_flow_imp.g_varchar2_table(52) := 'number         not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    file_name               varchar2(512),'||wwv_flow.LF||
'    file_mimetype        ';
wwv_flow_imp.g_varchar2_table(53) := '   varchar2(512),'||wwv_flow.LF||
'    file_charset            varchar2(512),'||wwv_flow.LF||
'    file_lastupd            date,'||wwv_flow.LF||
'    f';
wwv_flow_imp.g_varchar2_table(54) := 'ile_blob               blob,'||wwv_flow.LF||
'    file_comments           varchar2(4000),'||wwv_flow.LF||
'    tags                   ';
wwv_flow_imp.g_varchar2_table(55) := ' varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created               timestamp with time zone not null,'||wwv_flow.LF||
'    created_by ';
wwv_flow_imp.g_varchar2_table(56) := '           varchar2(255) not null,'||wwv_flow.LF||
'    updated               timestamp with time zone,'||wwv_flow.LF||
'    updated_b';
wwv_flow_imp.g_varchar2_table(57) := 'y            varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_demo_tree_proj_files'||wwv_flow.LF||
'   add constraint eba_demo_tr';
wwv_flow_imp.g_varchar2_table(58) := 'ee_proj_files_pk'||wwv_flow.LF||
'       primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_demo_tree_proj_files'||wwv_flow.LF||
'   add constraint eb';
wwv_flow_imp.g_varchar2_table(59) := 'a_demo_tree_files_fk'||wwv_flow.LF||
'       foreign key (project_id)'||wwv_flow.LF||
'       references eba_demo_tree_projects (proj_';
wwv_flow_imp.g_varchar2_table(60) := 'id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_demo_tree_files_idx1 on eba_demo_tree_proj_files (project_';
wwv_flow_imp.g_varchar2_table(61) := 'id)'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3170997889833220717)
,p_install_id=>wwv_flow_imp.id(5660959323054673260)
,p_name=>'Create Tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
