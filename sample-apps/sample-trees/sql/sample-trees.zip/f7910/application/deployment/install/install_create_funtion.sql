prompt --application/deployment/install/install_create_funtion
begin
--   Manifest
--     INSTALL: INSTALL-Create funtion
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>12904184294728383
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '/* varchar2_to_blob function */'||wwv_flow.LF||
'create or replace function varchar2_to_blob(p_varchar2_tab in dbms_s';
wwv_flow_imp.g_varchar2_table(2) := 'ql.varchar2_table)'||wwv_flow.LF||
'    return blob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'  l_blob blob;'||wwv_flow.LF||
'  l_raw  raw(500);'||wwv_flow.LF||
'  l_size number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  dbm';
wwv_flow_imp.g_varchar2_table(3) := 's_lob.createtemporary(l_blob, true, dbms_lob.session);'||wwv_flow.LF||
'  for i in 1 .. p_varchar2_tab.count loop'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := ' l_size := length(p_varchar2_tab(i)) / 2;'||wwv_flow.LF||
'    dbms_lob.writeappend(l_blob, l_size, hextoraw(p_varcha';
wwv_flow_imp.g_varchar2_table(5) := 'r2_tab(i)));'||wwv_flow.LF||
'  end loop;'||wwv_flow.LF||
'  return l_blob;'||wwv_flow.LF||
'exception'||wwv_flow.LF||
'  when others then'||wwv_flow.LF||
'    dbms_lob.close(l_blob);'||wwv_flow.LF||
'e';
wwv_flow_imp.g_varchar2_table(6) := 'nd;  '||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3285974489903843354)
,p_install_id=>wwv_flow_imp.id(5660959323054673260)
,p_name=>'Create funtion'
,p_sequence=>27
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
