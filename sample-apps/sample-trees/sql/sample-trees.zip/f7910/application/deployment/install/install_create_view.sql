prompt --application/deployment/install/install_create_view
begin
--   Manifest
--     INSTALL: INSTALL-Create View
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>12904184294728383
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE OR REPLACE FORCE VIEW  "EBA_DEMO_TREE_DEF_ST_CODES" ("PCT_COMPLETE", "STATUS_NAME") AS '||wwv_flow.LF||
'selec';
wwv_flow_imp.g_varchar2_table(2) := 't 0   pct_complete, wwv_flow_lang.system_message(''NOT_STARTED'')                  status_name from du';
wwv_flow_imp.g_varchar2_table(3) := 'al union all'||wwv_flow.LF||
'select 10  pct_complete, wwv_flow_lang.system_message(''UNDER_CONSIDERATION'')          s';
wwv_flow_imp.g_varchar2_table(4) := 'tatus_name from dual union all'||wwv_flow.LF||
'select 20  pct_complete, wwv_flow_lang.system_message(''APPROVED'')    ';
wwv_flow_imp.g_varchar2_table(5) := '                 status_name from dual union all'||wwv_flow.LF||
'select 30  pct_complete, wwv_flow_lang.system_messa';
wwv_flow_imp.g_varchar2_table(6) := 'ge(''ASSIGNED'')                     status_name from dual union all'||wwv_flow.LF||
'select 40  pct_complete, wwv_flow';
wwv_flow_imp.g_varchar2_table(7) := '_lang.system_message(''WORK_INITIATED'')               status_name from dual union all'||wwv_flow.LF||
'select 50  pct_';
wwv_flow_imp.g_varchar2_table(8) := 'complete, wwv_flow_lang.system_message(''WORK_PROGRESSING'')             status_name from dual union a';
wwv_flow_imp.g_varchar2_table(9) := 'll'||wwv_flow.LF||
'select 60  pct_complete, wwv_flow_lang.system_message(''SIGNIFICANT_PROGRESS'')         status_name';
wwv_flow_imp.g_varchar2_table(10) := ' from dual union all'||wwv_flow.LF||
'select 70  pct_complete, wwv_flow_lang.system_message(''DEMONSTRABLE'')          ';
wwv_flow_imp.g_varchar2_table(11) := '       status_name from dual union all'||wwv_flow.LF||
'select 80  pct_complete, wwv_flow_lang.system_message(''FUNCTI';
wwv_flow_imp.g_varchar2_table(12) := 'ONALLY_COMPLETE'')        status_name from dual union all'||wwv_flow.LF||
'select 90  pct_complete, wwv_flow_lang.syst';
wwv_flow_imp.g_varchar2_table(13) := 'em_message(''INTEGRATION_COMPLETE'')         status_name from dual union all'||wwv_flow.LF||
'select 100 pct_complete, ';
wwv_flow_imp.g_varchar2_table(14) := 'wwv_flow_lang.system_message(''COMPLETE'')                     status_name from dual'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3183928274207457082)
,p_install_id=>wwv_flow_imp.id(5660959323054673260)
,p_name=>'Create View'
,p_sequence=>25
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
