prompt --application/deployment/install/install_create_triggers
begin
--   Manifest
--     INSTALL: INSTALL-Create Triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7910
,p_default_id_offset=>12904184294728383
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger biu_eba_demo_tree_proj'||wwv_flow.LF||
'   before insert or update on eba_demo_tree_project';
wwv_flow_imp.g_varchar2_table(2) := 's'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'   if :new."PROJ_ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXX';
wwv_flow_imp.g_varchar2_table(3) := 'XXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.proj_id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :ne';
wwv_flow_imp.g_varchar2_table(4) := 'w.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.upd';
wwv_flow_imp.g_varchar2_table(5) := 'ated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if ins';
wwv_flow_imp.g_varchar2_table(6) := 'erting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_';
wwv_flow_imp.g_varchar2_table(7) := 'flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif upd';
wwv_flow_imp.g_varchar2_table(8) := 'ating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(9) := '   '||wwv_flow.LF||
'alter trigger biu_eba_demo_tree_proj enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'create or replace trigger biu_eba_demo_tree_t';
wwv_flow_imp.g_varchar2_table(10) := 'ask'||wwv_flow.LF||
'   before insert or update on eba_demo_tree_task'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'   if :new."TASK_ID" is';
wwv_flow_imp.g_varchar2_table(11) := ' null then'||wwv_flow.LF||
'     select max(task_id)+1 into :new.task_id from eba_demo_tree_task;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if in';
wwv_flow_imp.g_varchar2_table(12) := 'serting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user';
wwv_flow_imp.g_varchar2_table(13) := ',user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user';
wwv_flow_imp.g_varchar2_table(14) := ');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new';
wwv_flow_imp.g_varchar2_table(15) := '.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.row_version_nu';
wwv_flow_imp.g_varchar2_table(16) := 'mber := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) +';
wwv_flow_imp.g_varchar2_table(17) := ' 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigger biu_eba_demo_tree_task enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger ';
wwv_flow_imp.g_varchar2_table(18) := 'biu_eba_demo_tree_stocks'||wwv_flow.LF||
'   before insert or update on eba_demo_tree_stocks'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(19) := '   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') in';
wwv_flow_imp.g_varchar2_table(20) := 'to :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(21) := '   :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :n';
wwv_flow_imp.g_varchar2_table(22) := 'ew.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.';
wwv_flow_imp.g_varchar2_table(23) := 'updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if ';
wwv_flow_imp.g_varchar2_table(24) := 'inserting then'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_n';
wwv_flow_imp.g_varchar2_table(25) := 'umber := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigger biu_eba_demo_tree_';
wwv_flow_imp.g_varchar2_table(26) := 'stocks enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_demo_tree_pop'||wwv_flow.LF||
'   before insert or update on ';
wwv_flow_imp.g_varchar2_table(27) := 'eba_demo_tree_population'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(';
wwv_flow_imp.g_varchar2_table(28) := 'sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting th';
wwv_flow_imp.g_varchar2_table(29) := 'en'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(30) := '     :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end ';
wwv_flow_imp.g_varchar2_table(31) := 'if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_b';
wwv_flow_imp.g_varchar2_table(32) := 'y := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.row_version_number := 1;';
wwv_flow_imp.g_varchar2_table(33) := ''||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end';
wwv_flow_imp.g_varchar2_table(34) := ' if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigger biu_eba_demo_tree_pop enable'||wwv_flow.LF||
'/    '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE OR REPLACE TRIGGER BIU_';
wwv_flow_imp.g_varchar2_table(35) := 'EBA_DEMO_TREE_FILES'||wwv_flow.LF||
'   before insert or update on eba_demo_tree_proj_files'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(36) := '      if :NEW.ID is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''';
wwv_flow_imp.g_varchar2_table(37) := ') into :new.id from dual;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         :new.created := current_tim';
wwv_flow_imp.g_varchar2_table(38) := 'estamp;'||wwv_flow.LF||
'         :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'         :new.updated := current_time';
wwv_flow_imp.g_varchar2_table(39) := 'stamp;'||wwv_flow.LF||
'         :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if inserting or up';
wwv_flow_imp.g_varchar2_table(40) := 'dating then'||wwv_flow.LF||
'         :new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.updated_by := nvl(wwv_flow.g_u';
wwv_flow_imp.g_varchar2_table(41) := 'ser,user);'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      elsif ';
wwv_flow_imp.g_varchar2_table(42) := 'updating then'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(43) := '   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'ALTER TRIGGER BIU_EBA_DEMO_TREE_FILES ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_d';
wwv_flow_imp.g_varchar2_table(44) := 'emo_tree_subtask'||wwv_flow.LF||
'   before insert or update on eba_demo_tree_subtask'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'   if ';
wwv_flow_imp.g_varchar2_table(45) := ':new."SUB_ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into';
wwv_flow_imp.g_varchar2_table(46) := ' :new.sub_id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(47) := '     :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(48) := ':new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :ne';
wwv_flow_imp.g_varchar2_table(49) := 'w.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   i';
wwv_flow_imp.g_varchar2_table(50) := 'f inserting then'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version';
wwv_flow_imp.g_varchar2_table(51) := '_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigger biu_eba_demo_tre';
wwv_flow_imp.g_varchar2_table(52) := 'e_subtask enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3170999572433234589)
,p_install_id=>wwv_flow_imp.id(5660959323054673260)
,p_name=>'Create Triggers'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
