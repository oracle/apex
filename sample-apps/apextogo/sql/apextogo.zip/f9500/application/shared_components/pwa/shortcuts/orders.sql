prompt --application/shared_components/pwa/shortcuts/orders
begin
--   Manifest
--     PWA SHORTCUT: Orders
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_shortcut(
 p_id=>wwv_flow_imp.id(697205323633906356)
,p_name=>'Orders'
,p_static_id=>'orders'
,p_display_sequence=>40
,p_target_url=>'f?p=&APP_ID.:4:&SESSION.'
,p_icon_url=>'pwa/shortcut-icon-40.png'
);
wwv_flow_imp.component_end;
end;
/
