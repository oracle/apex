prompt --application/shared_components/logic/application_items/shopping_cart_icon
begin
--   Manifest
--     APPLICATION ITEM: SHOPPING_CART_ICON
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(772720898783128928)
,p_name=>'SHOPPING_CART_ICON'
,p_protection_level=>'I'
,p_version_scn=>'37166223624529'
);
wwv_flow_imp.component_end;
end;
/
