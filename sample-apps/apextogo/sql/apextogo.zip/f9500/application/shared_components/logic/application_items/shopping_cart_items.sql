prompt --application/shared_components/logic/application_items/shopping_cart_items
begin
--   Manifest
--     APPLICATION ITEM: SHOPPING_CART_ITEMS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(772721098201129960)
,p_name=>'SHOPPING_CART_ITEMS'
,p_protection_level=>'I'
,p_version_scn=>'37166223624976'
);
wwv_flow_imp.component_end;
end;
/
