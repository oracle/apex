prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Item Details'
,p_alias=>'ITEM-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Item Details'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Hero */',
'.c-HeroCard {',
'  --a-cv-placeholder-color: transparent; /* Hide Placeholders */',
'  --a-cv-background-color: transparent; /* Remove Hero Card Background */',
'  --a-cv-border-width: 0px; /* Remove Hero Card Borders */',
'  --a-cv-shadow: none; /* Remove Hero Card Shadow */',
'  --a-cv-media-border-radius: .5rem;',
'  --a-cv-header-padding-x: 0rem;',
'  --a-cv-grid-gap: 0rem;',
'',
'  min-block-size: 15.75rem; /* Set Initial Hero Card Size */',
'}',
'',
'/* Set Hero Card Grid */',
'.a-CardView-items--grid {',
'  grid-template-columns: auto;',
'  padding: 0;',
'}',
'',
'/* Set Max-Height for Hero Card Image */',
'.c-HeroCard .a-CardView-media {',
'  max-block-size: 10rem;',
'}',
'',
'/* Show Only First Hero Card */',
'.c-HeroCard .is-placeholder li:not(:first-child) {',
'  display: none;',
'}'))
,p_step_template=>1662662927374504442
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(111198076645216721)
,p_plug_name=>'Actions'
,p_static_id=>'actions'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>160
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(59985344455157311)
,p_plug_name=>'Item Information'
,p_static_id=>'item-information'
,p_region_css_classes=>'c-HeroCard'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleC'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       image_url as image,',
'       name,',
'       description,',
'       price',
'  from sample_restaurant_items',
' where id = :P7_ITEM_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(59985371267157312)
,p_region_id=>wwv_flow_imp.id(59985344455157311)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="a-CardView-title">',
'  &NAME.<br />',
'  $&PRICE.',
'</div>'))
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'<div class="a-CardView-subTitle">&DESCRIPTION.</div>'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'STATIC_URL'
,p_media_url=>'#APP_FILES#&IMAGE.'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'COVER'
,p_media_description=>'&DESCRIPTION.'
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(999998158765011551)
,p_plug_name=>'Quantity Container'
,p_static_id=>'quantity-container'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI:margin-top-sm'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>60
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59679603033507410)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(999998158765011551)
,p_button_name=>'ADD'
,p_static_id=>'add'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--pillEnd'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'+'
,p_warn_on_unsaved_changes=>null
,p_grid_column_css_classes=>'padding-none u-flex'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59677611237507407)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(111198076645216721)
,p_button_name=>'ADD_CART'
,p_static_id=>'add-cart'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch:t-Button--padTop'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add to Cart'
,p_button_condition=>'sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) = 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59678386139507408)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(111198076645216721)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--danger:t-Button--link:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Remove from Cart'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) > 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59678021309507408)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(111198076645216721)
,p_button_name=>'EDIT'
,p_static_id=>'edit'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch:t-Button--padTop'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update Cart'
,p_button_condition=>'sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) > 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59679988497507410)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(999998158765011551)
,p_button_name=>'SHARE'
,p_static_id=>'share'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Share'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-share-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59679165603507409)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(999998158765011551)
,p_button_name=>'SUBSTRACT'
,p_static_id=>'substract'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--pillStart'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'-'
,p_warn_on_unsaved_changes=>null
,p_grid_column_css_classes=>'padding-none u-flex'
,p_grid_new_row=>'Y'
,p_grid_row_css_classes=>'u-flex u-align-items-stretch'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710675243281948757)
,p_name=>'P7_ITEM_DESCRIPTION'
,p_item_sequence=>50
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select description',
'  from sample_restaurant_items',
' where id = :P7_ITEM_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(707340616720878255)
,p_name=>'P7_ITEM_ID'
,p_item_sequence=>20
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710675170509948756)
,p_name=>'P7_ITEM_NAME'
,p_item_sequence=>40
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(151934115025783343)
,p_name=>'P7_NOTE'
,p_item_sequence=>80
,p_prompt=>'Add Note'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>2
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1000003181669011543)
,p_name=>'P7_QUANTITY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(999998158765011551)
,p_prompt=>'Quantity'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>3
,p_tag_css_classes=>'rounded-none'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_grid_column_css_classes=>'padding-none t-Button--pillEnd'
,p_field_template=>2042262243893469891
,p_item_css_classes=>'margin-none t-Form-fieldContainer--noPadding rounded-none'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'min_value', '1',
  'number_alignment', 'center',
  'virtual_keyboard', 'numeric')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(856441932577559134)
,p_name=>'P7_SHOPPING_CART_ITEMS'
,p_item_sequence=>30
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(151934084293783342)
,p_name=>'P7_UTENSILS'
,p_item_sequence=>70
,p_prompt=>'<span class="fa fa-cutlery" aria-hidden="true"></span> Request utensils, etc.'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'unchecked_value', 'N',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(59921733326621125)
,p_computation_sequence=>30
,p_computation_item=>'P7_NOTE'
,p_static_id=>'p7-note'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) > 0 then',
'    return sample_restaurant_manage_orders.get_note( p_item_id => :P7_ITEM_ID );',
'else',
'    return '''';',
'end if;'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(59684135526507416)
,p_computation_sequence=>10
,p_computation_item=>'P7_QUANTITY'
,p_static_id=>'p7-quantity'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) > 0 then',
'    return sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID );',
'else',
'    return 1;',
'end if;'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(59921625002621124)
,p_computation_sequence=>20
,p_computation_item=>'P7_UTENSILS'
,p_static_id=>'p7-utensils'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) > 0 then',
'    return sample_restaurant_manage_orders.get_utensils( p_item_id => :P7_ITEM_ID );',
'else',
'    return ''N'';',
'end if;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(59689619543507421)
,p_name=>'Add Action'
,p_static_id=>'add-action'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(59679603033507410)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59690091153507421)
,p_event_id=>wwv_flow_imp.id(59689619543507421)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', 'apex.items.P7_QUANTITY.setValue( parseInt( apex.items.P7_QUANTITY.value ) + 1 )')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(59687318342507419)
,p_name=>'Confirm Delete'
,p_static_id=>'confirm-delete'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(59678386139507408)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59687773741507419)
,p_event_id=>wwv_flow_imp.id(59687318342507419)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-confirm'
,p_action=>'NATIVE_CONFIRM'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'confirm_label', 'Confirm',
  'message', 'Confirm to remove from cart',
  'style', 'warning')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59688334353507420)
,p_event_id=>wwv_flow_imp.id(59687318342507419)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-submit-page'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'request_button_name', 'DELETE',
  'show_processing', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(59686383129507418)
,p_name=>'Share Page'
,p_static_id=>'share-page'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(59679988497507410)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59686933013507418)
,p_event_id=>wwv_flow_imp.id(59686383129507418)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-share'
,p_action=>'NATIVE_SHARE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'share_type', 'url',
  'text', 'I recommend this: &P7_ITEM_DESCRIPTION.',
  'title', '&P7_ITEM_NAME.',
  'url', 'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(59688765326507420)
,p_name=>'Substract Action'
,p_static_id=>'substract-action'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(59679165603507409)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59689180423507420)
,p_event_id=>wwv_flow_imp.id(59688765326507420)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', 'apex.items.P7_QUANTITY.setValue( Math.max ( parseInt( apex.items.P7_QUANTITY.value ) - 1, 1 ) )')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59684434387507416)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add Item'
,p_static_id=>'add-item'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) = 0 then',
'    sample_restaurant_manage_orders.add_item( p_item_id  => :P7_ITEM_ID,',
'                                              p_quantity => :P7_QUANTITY,',
'                                              p_utensils => :P7_UTENSILS,',
'                                              p_note     => :P7_NOTE );',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(59677611237507407)
,p_internal_uid=>46387968857646736
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59684790876507416)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Calculate Shopping Cart Items'
,p_static_id=>'calculate-shopping-cart-items'
,p_process_sql_clob=>':P7_SHOPPING_CART_ITEMS := sample_restaurant_manage_orders.get_quantity;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>46388325346646736
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59686009534507417)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_static_id=>'close-dialog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'items_to_return', 'P7_SHOPPING_CART_ITEMS',
  'show_success_messages', 'Y')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>46389544004646737
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59685253575507417)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Item'
,p_static_id=>'delete-item'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) > 0 then',
'    sample_restaurant_manage_orders.remove_item( p_item_id => :P7_ITEM_ID );',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(59678386139507408)
,p_internal_uid=>46388788045646737
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59685617593507417)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Edit Item'
,p_static_id=>'edit-item'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if sample_restaurant_manage_orders.item_quantity( p_item_id => :P7_ITEM_ID ) > 0 then',
'    sample_restaurant_manage_orders.remove_item( p_item_id => :P7_ITEM_ID );',
'    sample_restaurant_manage_orders.add_item( p_item_id  => :P7_ITEM_ID,',
'                                              p_quantity => :P7_QUANTITY,',
'                                              p_utensils => :P7_UTENSILS,',
'                                              p_note     => :P7_NOTE );',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(59678021309507408)
,p_internal_uid=>46389152063646737
);
wwv_flow_imp.component_end;
end;
/
