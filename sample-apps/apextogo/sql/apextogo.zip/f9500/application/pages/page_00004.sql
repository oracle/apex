prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Home'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Categories */',
'.c-Categories {',
'  --a-cv-placeholder-color: transparent; /* Hide Placeholders */',
'  --a-cv-background-color: transparent; /* Remove Card Background */',
'  --a-cv-border-width: 0px; /* Remove Card Borders */',
'  --a-cv-header-padding-y: .5rem;',
'  --a-cv-title-font-size: .875rem;',
'  --a-cv-title-font-weight: 400;',
'  --a-cv-shadow: none;',
'  --a-cv-icon-image-size: 4rem;',
'',
'  min-block-size: 8rem; /* Set Initial Size of Cards */',
'}',
'',
'/* Align Category Image */',
'.c-Categories .a-CardView-iconImg {',
'  margin-inline: auto;',
'}',
'',
'/* Misc Category Styles */',
'.c-Categories .a-CardView-items {',
'  padding-inline: .25rem;',
'  padding-block: 0;',
'  margin-inline: auto;',
'  text-align: center;',
'  inline-size: max-content;',
'}',
'',
'/* Misc Category Item Styles */',
'.c-Categories .a-CardView-item {',
'  flex-shrink: 0;',
'  padding-block: .5rem;',
'  min-inline-size: 0;',
'}',
'',
'/* Set Carousel Aspect Ratio */',
'.t-Region-carouselRegions {',
'  aspect-ratio: 2.5 / 1;',
'  overflow: hidden;',
'}',
'',
'/* Cards */',
'.a-CardView-items {',
'  max-inline-size: 100%;',
'  scrollbar-width: 0;',
'  scroll-snap-type: x mandatory;',
'  overflow-x: auto;',
'  display: flex;',
'  flex-wrap: nowrap;',
'}',
'',
'/* Hide Scrollbars for Webkit Browsers */',
'.a-CardView-items::-webkit-scrollbar {',
'  display: none;',
'}',
'',
'.a-CardView-item {',
'  scroll-snap-align: start;',
'  min-inline-size: 17.5rem;',
'}',
'',
'/* Rating Badge */',
'.a-CardView-badge {',
'  background-color: var(--a-palette-warning-shade);',
'  color: var(--a-palette-warning);',
'}',
'',
'.a-CardView-badgeValue {',
'  color: initial;',
'}',
''))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326918892364611778)
,p_plug_name=>'Categories'
,p_static_id=>'categories'
,p_region_css_classes=>'c-Categories'
,p_region_template_options=>'#DEFAULT#:margin-top-none:margin-bottom-none'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c.id,',
'       c.name,',
'       c.image_url,',
'       c.created,',
'       c.created_by,',
'       c.updated,',
'       c.updated_by',
'  from sample_restaurant_categories c',
' where exists ( select 1',
'                  from sample_restaurant r ',
'                 where r.category_id = c.id )',
' order by c.name'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'The categories are empty!'
,p_no_data_found_icon_classes=>'fa-emoji-grin-sweat'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(59634227208488045)
,p_region_id=>wwv_flow_imp.id(326918892364611778)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_title_css_classes=>'u-textCenter'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'URL'
,p_icon_image_url=>'#APP_FILES#&IMAGE_URL.'
,p_icon_position=>'TOP'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(59634673758488047)
,p_card_id=>wwv_flow_imp.id(59634227208488045)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$open-search?category=&NAME.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(713813334774394986)
,p_plug_name=>'Credits'
,p_static_id=>'credits'
,p_parent_plug_id=>wwv_flow_imp.id(655193210004571181)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--stretch:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1676876785387892020
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_region_image=>'#APP_FILES#slides/slide-2.jpg'
,p_region_image_alt_text=>'APEXToGo credits'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(760078009537632201)
,p_plug_name=>'Delivery Free'
,p_static_id=>'delivery-free'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>80
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.id,',
'       r.hero_url as image,',
'       r.name as name,',
'       c.name as category,',
'       r.rating,',
'       r.delivery_time,',
'       r.delivery_fee',
'  from sample_restaurant r,',
'       sample_restaurant_categories c ',
' where c.id = r.category_id',
'   and delivery_fee = 0'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'This category is empty!'
,p_no_data_found_icon_classes=>'fa-emoji-grin-sweat'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(59642966581488061)
,p_region_id=>wwv_flow_imp.id(760078009537632201)
,p_layout_type=>'GRID'
,p_card_css_classes=>'a-CardView-item-mobile rounded rounded-lg'
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'{if !=DELIVERY_FEE/}Free Delivery{else/}$&DELIVERY_FEE. Delivery Fee{endif/} &bull; &DELIVERY_TIME. min'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'RATING'
,p_badge_css_classes=>'fa fa-star u-color-7-text'
,p_media_adv_formatting=>false
,p_media_source_type=>'STATIC_URL'
,p_media_url=>'#APP_FILES#&IMAGE.'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'COVER'
,p_media_css_classes=>'rounded-top rounded-top-lg'
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(59643465663488062)
,p_card_id=>wwv_flow_imp.id(59642966581488061)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::P5_RESTAURANT_ID:&ID.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326919170797611781)
,p_plug_name=>'Favorites'
,p_static_id=>'favorites'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:margin-top-none'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.id,',
'       r.hero_url as image,',
'       r.name as name,',
'       c.name as category,',
'       r.rating,',
'       r.delivery_time,',
'       r.delivery_fee',
'  from sample_restaurant r,',
'       sample_restaurant_categories c',
' where c.id = r.category_id',
' order by dbms_random.value',
' fetch first 3 rows only'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'This category is empty!'
,p_no_data_found_icon_classes=>'fa-emoji-grin-sweat'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(59635744751488049)
,p_region_id=>wwv_flow_imp.id(326919170797611781)
,p_layout_type=>'GRID'
,p_card_css_classes=>'a-CardView-item-mobile rounded rounded-lg'
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'{if !=DELIVERY_FEE/}Free Delivery{else/}$&DELIVERY_FEE. Delivery Fee{endif/} &bull; &DELIVERY_TIME. min'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'RATING'
,p_badge_css_classes=>'fa fa-star u-color-7-text'
,p_media_adv_formatting=>false
,p_media_source_type=>'STATIC_URL'
,p_media_url=>'#APP_FILES#&IMAGE.'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'COVER'
,p_media_css_classes=>'rounded-top rounded-top-lg'
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(59636170355488050)
,p_card_id=>wwv_flow_imp.id(59635744751488049)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::P5_RESTAURANT_ID:&ID.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(931185119032294516)
,p_plug_name=>'Info'
,p_static_id=>'info'
,p_parent_plug_id=>wwv_flow_imp.id(655193210004571181)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--stretch:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1676876785387892020
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_region_image=>'#APP_FILES#slides/slide-3.jpg'
,p_region_image_alt_text=>'APEXToGo info'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(655193495123571184)
,p_plug_name=>'Popular near you'
,p_static_id=>'popular-near-you'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>60
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.id,',
'       r.hero_url as image,',
'       r.name as name,',
'       c.name as category,',
'       r.rating,',
'       r.delivery_time,',
'       r.delivery_fee',
'  from sample_restaurant r,',
'       sample_restaurant_categories c',
' where c.id = r.category_id',
' order by dbms_random.value',
' fetch first 8 rows only'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'This category is empty!'
,p_no_data_found_icon_classes=>'fa-emoji-grin-sweat'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(59639217925488054)
,p_region_id=>wwv_flow_imp.id(655193495123571184)
,p_layout_type=>'GRID'
,p_card_css_classes=>'a-CardView-item-mobile rounded rounded-lg'
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'{if !=DELIVERY_FEE/}Free Delivery{else/}$&DELIVERY_FEE. Delivery Fee{endif/} &bull; &DELIVERY_TIME. min'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'RATING'
,p_badge_css_classes=>'fa fa-star u-color-7-text'
,p_media_adv_formatting=>false
,p_media_source_type=>'STATIC_URL'
,p_media_url=>'#APP_FILES#&IMAGE.'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'COVER'
,p_media_css_classes=>'rounded-top rounded-top-lg'
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(59639762679488055)
,p_card_id=>wwv_flow_imp.id(59639217925488054)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::P5_RESTAURANT_ID:&ID.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(655193263886571182)
,p_plug_name=>'Premium'
,p_static_id=>'premium'
,p_parent_plug_id=>wwv_flow_imp.id(655193210004571181)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--stretch:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1676876785387892020
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_region_image=>'#APP_FILES#slides/slide-1.jpg'
,p_region_image_alt_text=>'APEXToGo premium'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(655193210004571181)
,p_plug_name=>'Promotionals'
,p_static_id=>'promotionals'
,p_region_css_classes=>'rounded rounded-lg'
,p_region_template_options=>'#DEFAULT#:js-cycle5s:t-Region--carouselSlide:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--hiddenOverflow:margin-top-sm:margin-bottom-md'
,p_plug_template=>2868763615067669172
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_landmark_type=>'exclude_landmark'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(760077742287632198)
,p_plug_name=>'Today''s offers'
,p_static_id=>'today-s-offers'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>70
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.id,',
'       r.hero_url as image,',
'       r.name as name,',
'       c.name as category,',
'       r.rating,',
'       r.delivery_time,',
'       r.delivery_fee',
'  from sample_restaurant r,',
'       sample_restaurant_categories c',
' where c.id = r.category_id',
' order by dbms_random.value',
' fetch first 8 rows only'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'This category is empty!'
,p_no_data_found_icon_classes=>'fa-emoji-grin-sweat'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(59641162795488058)
,p_region_id=>wwv_flow_imp.id(760077742287632198)
,p_layout_type=>'GRID'
,p_card_css_classes=>'a-CardView-item-mobile rounded rounded-lg'
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'{if !=DELIVERY_FEE/}Free Delivery{else/}$&DELIVERY_FEE. Delivery Fee{endif/} &bull; &DELIVERY_TIME. min'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'RATING'
,p_badge_css_classes=>'fa fa-star u-color-7-text'
,p_media_adv_formatting=>false
,p_media_source_type=>'STATIC_URL'
,p_media_url=>'#APP_FILES#&IMAGE.'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'COVER'
,p_media_css_classes=>'rounded-top rounded-top-lg'
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(59641615142488059)
,p_card_id=>wwv_flow_imp.id(59641162795488058)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::P5_RESTAURANT_ID:&ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59633480428488044)
,p_button_sequence=>20
,p_button_name=>'SEARCH'
,p_static_id=>'search'
,p_button_static_id=>'SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--simple:t-Button--iconLeft:t-Button--stretch:t-Button--gapTop:t-Button--padBottom'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Search APEXToGo...'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'margin-top-md u-textStart '
,p_icon_css_classes=>'fa-search'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59983026366157288)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(760078009537632201)
,p_button_name=>'SHOW_ALL_DELIVERY_FREE'
,p_static_id=>'show-all-delivery-free'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Show All'
,p_button_position=>'CHANGE'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22397926944956292)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(326919170797611781)
,p_button_name=>'SHOW_ALL_FAVORITES'
,p_static_id=>'show-all-favorites'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Show All'
,p_button_position=>'CHANGE'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59982779424157286)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(655193495123571184)
,p_button_name=>'SHOW_ALL_POPULAR'
,p_static_id=>'show-all-popular'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Show All'
,p_button_position=>'CHANGE'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59982893262157287)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(760077742287632198)
,p_button_name=>'SHOW_ALL_TODAYS_OFFERS'
,p_static_id=>'show-all-todays-offers'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Show All'
,p_button_position=>'CHANGE'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(59858239725809711)
,p_name=>'Open Search Region'
,p_static_id=>'open-search-region'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(59633480428488044)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22398261429956295)
,p_event_id=>wwv_flow_imp.id(59858239725809711)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', 'apex.actions.invoke( ''open-search'' );')).to_clob
);
wwv_flow_imp.component_end;
end;
/
