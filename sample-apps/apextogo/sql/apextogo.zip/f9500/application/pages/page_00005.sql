prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Restaurant'
,p_alias=>'RESTAURANT'
,p_step_title=>'Restaurant'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Hero */',
'.c-HeroCard {',
'  --a-cv-placeholder-color: transparent; /* Hide Placeholders */',
'  --a-cv-background-color: transparent; /* Remove Hero Card Background */',
'  --a-cv-border-width: 0px; /* Remove Hero Card Borders */',
'  --a-cv-shadow: none; /* Remove Hero Card Shadow */',
'  --a-cv-icon-image-border-radius: .5rem;',
'  --a-cv-icon-image-size: 6rem;',
'',
'  min-block-size: 16.875rem; /* Set Initial Hero Card Size */',
'}',
'',
'/* Hero Card Icon */',
'.c-HeroCard .a-CardView-iconImg {',
'  margin-block-start: -5rem;',
'  position: relative;',
'  box-shadow: var(--ut-body-background-color) 0 0 0 .25rem;',
'}',
'',
'/* Set Hero Card Grid */',
'.a-CardView-items--grid {',
'  grid-template-columns: auto;',
'  padding: 0;',
'}',
'',
'/* Set Max-Height for Hero Card Image */',
'.c-HeroCard .a-CardView-media {',
'  max-block-size: 10rem;',
'}',
'',
'/* Show Only First Hero Card */',
'.c-HeroCard .is-placeholder li:not(:first-child) {',
'  display: none;',
'}',
'',
'/* Content Row */',
'.t-ContentRow-wrap {',
'  flex-direction: row-reverse; /* Flip Order of Avatar */',
'}',
'',
'/* Content Row Actions */',
'.t-ContentRow-actions {',
'  align-self: flex-end;',
'  position: absolute;',
'  inset-block-end: .375rem;',
'  inset-inline-end: .25rem;',
'}',
''))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326953551932619277)
,p_plug_name=>'Restaurant Information'
,p_static_id=>'restaurant-information'
,p_region_css_classes=>'c-HeroCard'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2074200852440250129
,p_plug_display_sequence=>10
,p_plug_grid_row_css_classes=>'margin-none'
,p_plug_grid_column_css_classes=>'padding-none'
,p_plug_display_point=>'REGION_POSITION_08'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.id,',
'       r.hero_url as image,',
'       r.logo_url as icon,',
'       r.name as name,',
'       c.name as category,',
'       r.rating,',
'       r.delivery_time,',
'       r.delivery_fee',
'  from sample_restaurant r,',
'       sample_restaurant_categories c',
' where c.id = r.category_id',
'   and r.id = :P5_RESTAURANT_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'No details found!'
,p_no_data_found_icon_classes=>'fa-emoji-grin-sweat'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(59654829570492938)
,p_region_id=>wwv_flow_imp.id(326953551932619277)
,p_layout_type=>'GRID'
,p_card_css_classes=>'a-CardView--noUI'
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="a-CardView-subTitle">',
'  <div class="margin-bottom-sm">&CATEGORY.</div>',
'  <div><span class="fa fa-star u-alignBaseline" aria-hidden="true"></span> &RATING. &bull; {if !=DELIVERY_FEE/}Free Delivery{else/}$&DELIVERY_FEE. Delivery Fee{endif/} &bull; &DELIVERY_TIME. min</div>',
'</div>'))
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'URL'
,p_icon_image_url=>'#APP_FILES#&ICON.'
,p_icon_css_classes=>'u-color-14-bg'
,p_icon_position=>'TOP'
,p_media_adv_formatting=>false
,p_media_source_type=>'STATIC_URL'
,p_media_url=>'#APP_FILES#&IMAGE.'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'COVER'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326953792569619280)
,p_plug_name=>'Restaurant Items'
,p_static_id=>'restaurant-items'
,p_region_template_options=>'#DEFAULT#:margin-top-none'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>60
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       image_url as image,',
'       name,',
'       description,',
'       price,',
'       rating',
'  from sample_restaurant_items',
' order by dbms_random.value',
' fetch first 6 rows only'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_IMAGE', '{"source":"URL","url":"#APP_FILES#&IMAGE."}',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_SIZE', 't-Avatar--md',
  'AVATAR_TYPE', 'image',
  'DESCRIPTION', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<div>$&PRICE. &bull; <span class="fa fa-thumbs-up u-alignBaseline" aria-hidden="true"></span> &RATING.</div>',
    '<div>&DESCRIPTION.</div>')),
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'TITLE', '&NAME.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(326954097054619283)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(707284317051853977)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(707285173556853986)
,p_name=>'IMAGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IMAGE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(326954036481619282)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(713850330453402509)
,p_name=>'PRICE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRICE'
,p_data_type=>'NUMBER'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(108971496496465100)
,p_name=>'RATING'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RATING'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(326954331966619285)
,p_region_id=>wwv_flow_imp.id(326953792569619280)
,p_position_id=>350878614853473162
,p_display_sequence=>10
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:7:P7_ITEM_ID,P7_ITEM_NAME:&ID.,&NAME.'
,p_link_attributes=>'aria-label="&NAME."'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(999952325128987306)
,p_region_id=>wwv_flow_imp.id(326953792569619280)
,p_position_id=>363792341120765662
,p_display_sequence=>30
,p_template_id=>363792942797796791
,p_label=>'Add'
,p_static_id=>'add'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:7:P7_ITEM_ID,P7_ITEM_NAME:&ID.,&NAME.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-plus'
,p_action_css_classes=>'padding-sm t-Button--tiny'
,p_is_hot=>true
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326967565570619319)
,p_name=>'P5_RESTAURANT_ID'
,p_item_sequence=>20
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(59659426387492952)
,p_name=>'Send Push Notification'
,p_static_id=>'send-push-notification'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'apex_pwa.has_push_subscription'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59659958339492953)
,p_event_id=>wwv_flow_imp.id(59659426387492952)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_static_id=>'native-execute-plsql-code'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'language', 'PLSQL',
  'plsql_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'apex_pwa.send_push_notification (',
    '    p_user_name      => :APP_USER,',
    '    p_title          => ''Offer Available'',',
    '    p_body           => ''Buy 1, Get 1 Free. Complete your order!'',',
    '    p_icon_url       => apex_mail.get_instance_url || ''#APP_FILES#icons/app-icon-512.png'' );',
    'apex_pwa.push_queue;')),
  'show_processing', 'N')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(59660267929492953)
,p_name=>'Update Cart Badge on Dialog Close'
,p_static_id=>'update-cart-badge-on-dialog-close'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(326953792569619280)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'parseInt(this.data.P7_SHOPPING_CART_ITEMS) > 0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59661334023492954)
,p_event_id=>wwv_flow_imp.id(59660267929492953)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Remove Cart Badge'
,p_static_id=>'remove-cart-badge'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    '// Update Badge Text',
    'apex.jQuery( ''.js-shopping-cart-item .t-Button-badge'' ).text( '''' );',
    '',
    '// Update Icon',
    'apex.jQuery( ''.js-shopping-cart-item .t-Icon'' ).toggleClass( ''fa-cart-full fa-cart-empty'' );')))).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59660781539492954)
,p_event_id=>wwv_flow_imp.id(59660267929492953)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Update Cart Badge'
,p_static_id=>'update-cart-badge'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    '// Update Badge Text',
    'apex.jQuery( ''.js-shopping-cart-item .t-Button-badge'' ).text( this.data.P7_SHOPPING_CART_ITEMS );',
    '',
    '// Update Icon',
    'apex.jQuery( ''.js-shopping-cart-item .t-Icon'' ).toggleClass( ''fa-cart-empty fa-cart-full'' );')))).to_clob
);
wwv_flow_imp.component_end;
end;
/
