prompt --application/deployment/install/install_install_manage_orders_package
begin
--   Manifest
--     INSTALL: INSTALL-Install Manage Orders Package
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sample_restaurant_manage_orders'||wwv_flow.LF||
'as'||wwv_flow.LF||
'  -------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '-------------------------'||wwv_flow.LF||
'  -- constant name for collection'||wwv_flow.LF||
'  c_items constant varchar2(30) := ''ITEM';
wwv_flow_imp.g_varchar2_table(3) := 'S'';'||wwv_flow.LF||
'  --------------------------------------------------------------'||wwv_flow.LF||
'  -- create procedure for add a';
wwv_flow_imp.g_varchar2_table(4) := ' item temporarily'||wwv_flow.LF||
'  procedure add_item ('||wwv_flow.LF||
'    p_item_id  in number,'||wwv_flow.LF||
'    p_quantity in number,'||wwv_flow.LF||
'    p_u';
wwv_flow_imp.g_varchar2_table(5) := 'tensils in varchar2,'||wwv_flow.LF||
'    p_note     in varchar2 );'||wwv_flow.LF||
'  -----------------------------------------------';
wwv_flow_imp.g_varchar2_table(6) := '---------------'||wwv_flow.LF||
'  -- create procedure for remove a item temporarily'||wwv_flow.LF||
'  procedure remove_item ('||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(7) := 'item_id in number );'||wwv_flow.LF||
'  --------------------------------------------------------------'||wwv_flow.LF||
'  -- create fu';
wwv_flow_imp.g_varchar2_table(8) := 'nction to get the number of items in the shopping cart'||wwv_flow.LF||
'  function get_quantity'||wwv_flow.LF||
'  return number;'||wwv_flow.LF||
'  --';
wwv_flow_imp.g_varchar2_table(9) := '------------------------------------------------------------'||wwv_flow.LF||
'  -- create procedure for validate if a';
wwv_flow_imp.g_varchar2_table(10) := ' item exists in the shopping cart'||wwv_flow.LF||
'  function get_utensils ('||wwv_flow.LF||
'    p_item_id in number )'||wwv_flow.LF||
'  return varch';
wwv_flow_imp.g_varchar2_table(11) := 'ar2;'||wwv_flow.LF||
'  --------------------------------------------------------------'||wwv_flow.LF||
'  -- create procedure for vali';
wwv_flow_imp.g_varchar2_table(12) := 'date if a item exists in the shopping cart'||wwv_flow.LF||
'  function get_note ('||wwv_flow.LF||
'    p_item_id in number )'||wwv_flow.LF||
'  return ';
wwv_flow_imp.g_varchar2_table(13) := 'varchar2;'||wwv_flow.LF||
'  --------------------------------------------------------------'||wwv_flow.LF||
'  -- create procedure for';
wwv_flow_imp.g_varchar2_table(14) := ' validate the item quantity in the shopping cart'||wwv_flow.LF||
'  function item_quantity ('||wwv_flow.LF||
'    p_item_id in number ';
wwv_flow_imp.g_varchar2_table(15) := ')'||wwv_flow.LF||
'  return number;'||wwv_flow.LF||
'  --------------------------------------------------------------'||wwv_flow.LF||
'  -- create proc';
wwv_flow_imp.g_varchar2_table(16) := 'edure for clear the cart'||wwv_flow.LF||
'  procedure clear_cart;'||wwv_flow.LF||
'  -------------------------------------------------';
wwv_flow_imp.g_varchar2_table(17) := '-------------'||wwv_flow.LF||
'  -- create procedure to insert orders'||wwv_flow.LF||
'  procedure create_order ('||wwv_flow.LF||
'    p_order_id out s';
wwv_flow_imp.g_varchar2_table(18) := 'ample_restaurant_orders.order_id%type,'||wwv_flow.LF||
'    p_session_id in number );'||wwv_flow.LF||
'end sample_restaurant_manage_or';
wwv_flow_imp.g_varchar2_table(19) := 'ders;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace package body sample_restaurant_manage_orders'||wwv_flow.LF||
'as'||wwv_flow.LF||
'  procedure add_item ( p_i';
wwv_flow_imp.g_varchar2_table(20) := 'tem_id  in number,'||wwv_flow.LF||
'                       p_quantity in number,'||wwv_flow.LF||
'                       p_utensils in';
wwv_flow_imp.g_varchar2_table(21) := ' varchar2,'||wwv_flow.LF||
'                       p_note     in varchar2 )'||wwv_flow.LF||
'  is'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    if not apex_collection.c';
wwv_flow_imp.g_varchar2_table(22) := 'ollection_exists ( p_collection_name => c_items ) then'||wwv_flow.LF||
'      apex_collection.create_collection( p_co';
wwv_flow_imp.g_varchar2_table(23) := 'llection_name => c_items );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      apex_collection.add_member( p_collection_name => c_it';
wwv_flow_imp.g_varchar2_table(24) := 'ems,'||wwv_flow.LF||
'                                  p_n001 => p_item_id,'||wwv_flow.LF||
'                                  p_n002';
wwv_flow_imp.g_varchar2_table(25) := ' => p_quantity,'||wwv_flow.LF||
'                                  p_c001 => p_utensils,'||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(26) := '      p_c002 => p_note );'||wwv_flow.LF||
'  end add_item;'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedure remove_item ( p_item_id in number )'||wwv_flow.LF||
'  is'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(27) := 'l_id number;'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    if apex_collection.collection_exists ( p_collection_name => c_items ) then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(28) := '        select seq_id'||wwv_flow.LF||
'          into l_id'||wwv_flow.LF||
'          from apex_collections a'||wwv_flow.LF||
'         where collectio';
wwv_flow_imp.g_varchar2_table(29) := 'n_name = c_items'||wwv_flow.LF||
'           and a.n001 = p_item_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'        apex_collection.delete_member( p_collec';
wwv_flow_imp.g_varchar2_table(30) := 'tion_name => c_items,'||wwv_flow.LF||
'                                       p_seq => l_id );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  end remo';
wwv_flow_imp.g_varchar2_table(31) := 've_item;'||wwv_flow.LF||
''||wwv_flow.LF||
'  function get_quantity'||wwv_flow.LF||
'  return number'||wwv_flow.LF||
'  is'||wwv_flow.LF||
'    l_items number := 0;'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    if apex_';
wwv_flow_imp.g_varchar2_table(32) := 'collection.collection_exists ( p_collection_name => c_items ) then'||wwv_flow.LF||
'        select sum( n002 )'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(33) := '    into l_items'||wwv_flow.LF||
'          from apex_collections a'||wwv_flow.LF||
'         where collection_name = c_items;'||wwv_flow.LF||
'    end';
wwv_flow_imp.g_varchar2_table(34) := ' if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_items;'||wwv_flow.LF||
'  end get_quantity;'||wwv_flow.LF||
''||wwv_flow.LF||
'  function get_utensils( p_item_id in number )'||wwv_flow.LF||
'  retu';
wwv_flow_imp.g_varchar2_table(35) := 'rn varchar2'||wwv_flow.LF||
'  is'||wwv_flow.LF||
'    l_utensils varchar2(2);'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    if apex_collection.collection_exists ( p_co';
wwv_flow_imp.g_varchar2_table(36) := 'llection_name => c_items ) then'||wwv_flow.LF||
'        select a.c001'||wwv_flow.LF||
'          into l_utensils'||wwv_flow.LF||
'          from apex_';
wwv_flow_imp.g_varchar2_table(37) := 'collections a'||wwv_flow.LF||
'         where collection_name = c_items'||wwv_flow.LF||
'           and a.n001 = p_item_id;'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(38) := ';'||wwv_flow.LF||
'    return l_utensils;'||wwv_flow.LF||
'  end get_utensils;'||wwv_flow.LF||
''||wwv_flow.LF||
'  function get_note( p_item_id in number )'||wwv_flow.LF||
'  return va';
wwv_flow_imp.g_varchar2_table(39) := 'rchar2'||wwv_flow.LF||
'  is'||wwv_flow.LF||
'    l_note varchar2(4000);'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    if apex_collection.collection_exists ( p_collecti';
wwv_flow_imp.g_varchar2_table(40) := 'on_name => c_items ) then'||wwv_flow.LF||
'        select a.c002'||wwv_flow.LF||
'          into l_note'||wwv_flow.LF||
'          from apex_collection';
wwv_flow_imp.g_varchar2_table(41) := 's a'||wwv_flow.LF||
'         where collection_name = c_items'||wwv_flow.LF||
'           and a.n001 = p_item_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    retu';
wwv_flow_imp.g_varchar2_table(42) := 'rn l_note;'||wwv_flow.LF||
'  end get_note;'||wwv_flow.LF||
''||wwv_flow.LF||
'  function item_quantity( p_item_id in number )'||wwv_flow.LF||
'  return number'||wwv_flow.LF||
'  is'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(43) := ' l_quantity number;'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    if apex_collection.collection_exists ( p_collection_name => c_items ';
wwv_flow_imp.g_varchar2_table(44) := ') then'||wwv_flow.LF||
'        select a.n002'||wwv_flow.LF||
'          into l_quantity'||wwv_flow.LF||
'          from apex_collections a'||wwv_flow.LF||
'         wh';
wwv_flow_imp.g_varchar2_table(45) := 'ere collection_name = c_items'||wwv_flow.LF||
'           and a.n001 = p_item_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'        return l_quantity;'||wwv_flow.LF||
'    els';
wwv_flow_imp.g_varchar2_table(46) := 'e'||wwv_flow.LF||
'        return 0;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  exception when others then return 0;'||wwv_flow.LF||
'  end item_quantity;'||wwv_flow.LF||
''||wwv_flow.LF||
'  proce';
wwv_flow_imp.g_varchar2_table(47) := 'dure clear_cart'||wwv_flow.LF||
'  is'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    if apex_collection.collection_exists ( p_collection_name => c_items';
wwv_flow_imp.g_varchar2_table(48) := ' ) then'||wwv_flow.LF||
'        apex_collection.truncate_collection( p_collection_name => c_items );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  e';
wwv_flow_imp.g_varchar2_table(49) := 'nd clear_cart;'||wwv_flow.LF||
''||wwv_flow.LF||
'  procedure create_order ( p_order_id out sample_restaurant_orders.order_id%type,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(50) := '                         p_session_id in number  )'||wwv_flow.LF||
'  is'||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'      insert into sample_restaurant_';
wwv_flow_imp.g_varchar2_table(51) := 'orders'||wwv_flow.LF||
'                  ( order_datetime,'||wwv_flow.LF||
'                    order_status,'||wwv_flow.LF||
'                    ses';
wwv_flow_imp.g_varchar2_table(52) := 'sion_id )'||wwv_flow.LF||
'      values      ( sysdate,'||wwv_flow.LF||
'                    ''IN PROGRESS'','||wwv_flow.LF||
'                    p_sess';
wwv_flow_imp.g_varchar2_table(53) := 'ion_id )'||wwv_flow.LF||
'      returning order_id into p_order_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if apex_collection.collection_exists ( p_c';
wwv_flow_imp.g_varchar2_table(54) := 'ollection_name => c_items ) then'||wwv_flow.LF||
'        insert into sample_restaurant_order_items'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(55) := '   ( order_id,'||wwv_flow.LF||
'                      line_item_id,'||wwv_flow.LF||
'                      item_id,'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(56) := '    unit_price,'||wwv_flow.LF||
'                      quantity,'||wwv_flow.LF||
'                      utensils,'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(57) := '  note )'||wwv_flow.LF||
'        select p_order_id,'||wwv_flow.LF||
'               seq_id,'||wwv_flow.LF||
'               p.id,'||wwv_flow.LF||
'               p.pri';
wwv_flow_imp.g_varchar2_table(58) := 'ce,'||wwv_flow.LF||
'               n002,'||wwv_flow.LF||
'               c001,'||wwv_flow.LF||
'               c002'||wwv_flow.LF||
'          from apex_collections a,';
wwv_flow_imp.g_varchar2_table(59) := ''||wwv_flow.LF||
'               sample_restaurant_items p'||wwv_flow.LF||
'         where collection_name = c_items'||wwv_flow.LF||
'           and p.';
wwv_flow_imp.g_varchar2_table(60) := 'id = a.n001;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      apex_collection.delete_collection( p_collection_name => c_items );';
wwv_flow_imp.g_varchar2_table(61) := ''||wwv_flow.LF||
'  end create_order;'||wwv_flow.LF||
'end sample_restaurant_manage_orders;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(60164636175735402)
,p_install_id=>wwv_flow_imp.id(697223373646968968)
,p_name=>'Install Manage Orders Package'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
