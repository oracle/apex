prompt --application/deployment/install/install_install_data
begin
--   Manifest
--     INSTALL: INSTALL-Install Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'delete from sample_restaurant_order_items;'||wwv_flow.LF||
'delete from sample_restaurant_orders;'||wwv_flow.LF||
'delete from sample_';
wwv_flow_imp.g_varchar2_table(2) := 'restaurant_items;'||wwv_flow.LF||
'delete from sample_restaurant;'||wwv_flow.LF||
'delete from sample_restaurant_categories;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(3) := 'nto sample_restaurant_categories(id,name,image_url,created,created_by,updated,updated_by)values(1,''B';
wwv_flow_imp.g_varchar2_table(4) := 'reakfast'',''category/category-1.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sa';
wwv_flow_imp.g_varchar2_table(5) := 'mple_restaurant_categories(id,name,image_url,created,created_by,updated,updated_by)values(2,''Fast Fo';
wwv_flow_imp.g_varchar2_table(6) := 'od'',''category/category-2.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_r';
wwv_flow_imp.g_varchar2_table(7) := 'estaurant_categories(id,name,image_url,created,created_by,updated,updated_by)values(3,''Indian'',''cate';
wwv_flow_imp.g_varchar2_table(8) := 'gory/category-3.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant';
wwv_flow_imp.g_varchar2_table(9) := '_categories(id,name,image_url,created,created_by,updated,updated_by)values(4,''Healthy'',''category/cat';
wwv_flow_imp.g_varchar2_table(10) := 'egory-4.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_categor';
wwv_flow_imp.g_varchar2_table(11) := 'ies(id,name,image_url,created,created_by,updated,updated_by)values(5,''Pizza'',''category/category-5.pn';
wwv_flow_imp.g_varchar2_table(12) := 'g'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_categories(id,nam';
wwv_flow_imp.g_varchar2_table(13) := 'e,image_url,created,created_by,updated,updated_by)values(6,''Chicken'',''category/category-6.png'',SYSTI';
wwv_flow_imp.g_varchar2_table(14) := 'MESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_categories(id,name,image_';
wwv_flow_imp.g_varchar2_table(15) := 'url,created,created_by,updated,updated_by)values(7,''Thai'',''category/category-7.png'',SYSTIMESTAMP,''AP';
wwv_flow_imp.g_varchar2_table(16) := 'EXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_categories(id,name,image_url,created';
wwv_flow_imp.g_varchar2_table(17) := ',created_by,updated,updated_by)values(8,''Mexican'',''category/category-8.png'',SYSTIMESTAMP,''APEXTOGO'',';
wwv_flow_imp.g_varchar2_table(18) := 'SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_categories(id,name,image_url,created,created';
wwv_flow_imp.g_varchar2_table(19) := '_by,updated,updated_by)values(9,''Asian'',''category/category-9.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTA';
wwv_flow_imp.g_varchar2_table(20) := 'MP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_categories(id,name,image_url,created,created_by,update';
wwv_flow_imp.g_varchar2_table(21) := 'd,updated_by)values(10,''Desserts'',''category/category-10.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''A';
wwv_flow_imp.g_varchar2_table(22) := 'PEXTOGO'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,creat';
wwv_flow_imp.g_varchar2_table(23) := 'ed,created_by,updated,updated_by,delivery_fee,delivery_time)values(1,''ByteStart Breakfast Nook'',''Add';
wwv_flow_imp.g_varchar2_table(24) := 'ress #123'',''4.0'',''restaurant/bytestart-breakfast-nook.jpg'',''restaurant/restaurant-hero-1.jpg'',1,SYST';
wwv_flow_imp.g_varchar2_table(25) := 'IMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',0,50);'||wwv_flow.LF||
'insert into sample_restaurant(id,name,address,rat';
wwv_flow_imp.g_varchar2_table(26) := 'ing,logo_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,delivery_time)v';
wwv_flow_imp.g_varchar2_table(27) := 'alues(2,''SQLicious Bistro'',''Address #724'',''3.2'',''restaurant/sqlicious-bistro.jpg'',''restaurant/restau';
wwv_flow_imp.g_varchar2_table(28) := 'rant-hero-2.jpg'',2,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',1,60);'||wwv_flow.LF||
'insert into sample_restaur';
wwv_flow_imp.g_varchar2_table(29) := 'ant(id,name,address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_by,deliv';
wwv_flow_imp.g_varchar2_table(30) := 'ery_fee,delivery_time)values(3,''PL/SQLovely Diner'',''Address #335'',''5.0'',''restaurant/sqlovely-diner.j';
wwv_flow_imp.g_varchar2_table(31) := 'pg'',''restaurant/restaurant-hero-3.jpg'',2,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',0,60);'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(32) := 'rt into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,created,created_by,up';
wwv_flow_imp.g_varchar2_table(33) := 'dated,updated_by,delivery_fee,delivery_time)values(4,''Oracool Cafe'',''Address #294'',''4.5'',''restaurant';
wwv_flow_imp.g_varchar2_table(34) := '/oracool-cafe.jpg'',''restaurant/restaurant-hero-4.jpg'',1,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTO';
wwv_flow_imp.g_varchar2_table(35) := 'GO'',1,45);'||wwv_flow.LF||
'insert into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,create';
wwv_flow_imp.g_varchar2_table(36) := 'd,created_by,updated,updated_by,delivery_fee,delivery_time)values(5,''APEXquisite Delights'',''Address ';
wwv_flow_imp.g_varchar2_table(37) := '#513'',''4.3'',''restaurant/apexquisite-delights.jpg'',''restaurant/restaurant-hero-5.jpg'',6,SYSTIMESTAMP,';
wwv_flow_imp.g_varchar2_table(38) := '''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',2,45);'||wwv_flow.LF||
'insert into sample_restaurant(id,name,address,rating,logo_';
wwv_flow_imp.g_varchar2_table(39) := 'url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,delivery_time)values(6,''';
wwv_flow_imp.g_varchar2_table(40) := 'SQLtastic Grill'',''Address #367'',''3.7'',''restaurant/sqltastic-grill.jpg'',''restaurant/restaurant-hero-6';
wwv_flow_imp.g_varchar2_table(41) := '.jpg'',5,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',6,30);'||wwv_flow.LF||
'insert into sample_restaurant(id,name';
wwv_flow_imp.g_varchar2_table(42) := ',address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,del';
wwv_flow_imp.g_varchar2_table(43) := 'ivery_time)values(7,''PL/SQL Paradise'',''Address #211'',''4.9'',''restaurant/sql-paradise.jpg'',''restaurant';
wwv_flow_imp.g_varchar2_table(44) := '/restaurant-hero-7.jpg'',3,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',8,33);'||wwv_flow.LF||
'insert into sample_';
wwv_flow_imp.g_varchar2_table(45) := 'restaurant(id,name,address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_b';
wwv_flow_imp.g_varchar2_table(46) := 'y,delivery_fee,delivery_time)values(8,''APEXtraordinary Fare'',''Address #841'',''2.9'',''restaurant/apextr';
wwv_flow_imp.g_varchar2_table(47) := 'aordinary-fare.jpg'',''restaurant/restaurant-hero-8.jpg'',9,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXT';
wwv_flow_imp.g_varchar2_table(48) := 'OGO'',0,60);'||wwv_flow.LF||
'insert into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,creat';
wwv_flow_imp.g_varchar2_table(49) := 'ed,created_by,updated,updated_by,delivery_fee,delivery_time)values(9,''Oraculicious Cuisine'',''Address';
wwv_flow_imp.g_varchar2_table(50) := ' #751'',''4.7'',''restaurant/oraculicious-cuisine.jpg'',''restaurant/restaurant-hero-9.jpg'',8,SYSTIMESTAMP';
wwv_flow_imp.g_varchar2_table(51) := ',''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',9,45);'||wwv_flow.LF||
'insert into sample_restaurant(id,name,address,rating,logo';
wwv_flow_imp.g_varchar2_table(52) := '_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,delivery_time)values(10';
wwv_flow_imp.g_varchar2_table(53) := ',''APEX Mex Grill'',''Address #571'',''5.0'',''restaurant/apex-mex-grill.jpg'',''restaurant/restaurant-hero-1';
wwv_flow_imp.g_varchar2_table(54) := '0.jpg'',4,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',7,40);'||wwv_flow.LF||
'insert into sample_restaurant(id,nam';
wwv_flow_imp.g_varchar2_table(55) := 'e,address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,de';
wwv_flow_imp.g_varchar2_table(56) := 'livery_time)values(11,''SQL Sushi Bar'',''Address #382'',''4.7'',''restaurant/sql-sushi-grill.jpg'',''restaur';
wwv_flow_imp.g_varchar2_table(57) := 'ant/restaurant-hero-11.jpg'',6,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',0,30);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sa';
wwv_flow_imp.g_varchar2_table(58) := 'mple_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_';
wwv_flow_imp.g_varchar2_table(59) := 'by)values(1,''PL/SQL Paradise Pasta'',''Paradise Pasta cooked in PL/SQL heaven'',''92% (13)'',5.99,''item/p';
wwv_flow_imp.g_varchar2_table(60) := 'asta.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_items(id,n';
wwv_flow_imp.g_varchar2_table(61) := 'ame,description,rating,price,image_url,created,created_by,updated,updated_by)values(2,''APEXtraordina';
wwv_flow_imp.g_varchar2_table(62) := 'ry Steak'',''Extraordinary Steak with an APEX touch'',''93% (100)'',9.99,''item/steak.jpg'',SYSTIMESTAMP,''A';
wwv_flow_imp.g_varchar2_table(63) := 'PEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_items(id,name,description,rating,pr';
wwv_flow_imp.g_varchar2_table(64) := 'ice,image_url,created,created_by,updated,updated_by)values(3,''SQLtimate Seafood Platter'',''Ultimate S';
wwv_flow_imp.g_varchar2_table(65) := 'eafood Platter seasoned with SQLtimate perfection'',''100% (123)'',6.99,''item/seafood.jpg'',SYSTIMESTAMP';
wwv_flow_imp.g_varchar2_table(66) := ',''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_items(id,name,description,rating';
wwv_flow_imp.g_varchar2_table(67) := ',price,image_url,created,created_by,updated,updated_by)values(4,''Oraculicious Chicken'',''Chicken made';
wwv_flow_imp.g_varchar2_table(68) := ' Oraculicious'',''56% (5)'',2.99,''item/chicken.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(69) := 'nsert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,upd';
wwv_flow_imp.g_varchar2_table(70) := 'ated,updated_by)values(5,''SQLtastic Tacos'',''Tacos filled with SQLtastic flavors'',''89% (210)'',6.99,''i';
wwv_flow_imp.g_varchar2_table(71) := 'tem/taco.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_items(';
wwv_flow_imp.g_varchar2_table(72) := 'id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(6,''SQLicious';
wwv_flow_imp.g_varchar2_table(73) := ' Salad'',''Salad made with SQL magic'',''88% (23)'',8.99,''item/salad.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIME';
wwv_flow_imp.g_varchar2_table(74) := 'STAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,cr';
wwv_flow_imp.g_varchar2_table(75) := 'eated,created_by,updated,updated_by)values(7,''Oracool Wrap'',''Refreshing Wrap inspired by Oracle'',''96';
wwv_flow_imp.g_varchar2_table(76) := '% (322)'',3.99,''item/wrap.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_r';
wwv_flow_imp.g_varchar2_table(77) := 'estaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)val';
wwv_flow_imp.g_varchar2_table(78) := 'ues(8,''PL/SQLovely Pizza'',''Lovely Pizza infused with PL/SQL goodness'',''99% (12)'',4.99,''item/pizza.jp';
wwv_flow_imp.g_varchar2_table(79) := 'g'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_items(id,name,des';
wwv_flow_imp.g_varchar2_table(80) := 'cription,rating,price,image_url,created,created_by,updated,updated_by)values(9,''APEXquisite Sushi Ro';
wwv_flow_imp.g_varchar2_table(81) := 'll'',''Exquisite Sushi Roll with an APEX twist'',''85% (211)'',12.99,''item/sushi.jpg'',SYSTIMESTAMP,''APEXT';
wwv_flow_imp.g_varchar2_table(82) := 'OGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_items(id,name,description,rating,price,';
wwv_flow_imp.g_varchar2_table(83) := 'image_url,created,created_by,updated,updated_by)values(10,''APEXcellent Burger'',''Delicious Burger wit';
wwv_flow_imp.g_varchar2_table(84) := 'h APEX flavor'',''76% (29)'',5.99,''item/burger.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(85) := 'nsert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,upd';
wwv_flow_imp.g_varchar2_table(86) := 'ated,updated_by)values(11,''APEX Crunchy Byte'',''Crispy vada that crunches like data in an Oracle data';
wwv_flow_imp.g_varchar2_table(87) := 'base'',''49% (34)'',2.99,''item/vada.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into ';
wwv_flow_imp.g_varchar2_table(88) := 'sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,update';
wwv_flow_imp.g_varchar2_table(89) := 'd_by)values(12,''Data Delight Yogurt'',''Smooth and creamy treat just as seamless as Oracle APEX'',''45% ';
wwv_flow_imp.g_varchar2_table(90) := '(90)'',6.99,''item/yogurt.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_re';
wwv_flow_imp.g_varchar2_table(91) := 'staurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)valu';
wwv_flow_imp.g_varchar2_table(92) := 'es(13,''Oracle Brownie Bliss'',''Sweet indulgence that is as reliable as a well-structured database'',''1';
wwv_flow_imp.g_varchar2_table(93) := '00% (11)'',8.99,''item/brownie.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into samp';
wwv_flow_imp.g_varchar2_table(94) := 'le_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by';
wwv_flow_imp.g_varchar2_table(95) := ')values(14,''Database Brewed Coffee'',''Energizing drink as robust as your database architecture'',''84% ';
wwv_flow_imp.g_varchar2_table(96) := '(189)'',9.99,''item/coffee.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_r';
wwv_flow_imp.g_varchar2_table(97) := 'estaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)val';
wwv_flow_imp.g_varchar2_table(98) := 'ues(15,''APEX Dumpling Delight'',''Flavorful journey akin to navigating Oracle APEX'',''67% (455)'',2.99,''';
wwv_flow_imp.g_varchar2_table(99) := 'item/dumplin.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_it';
wwv_flow_imp.g_varchar2_table(100) := 'ems(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(16,''Data';
wwv_flow_imp.g_varchar2_table(101) := '-Driven Eggs'',''Protein-packed delight inspired by the efficiency of Oracle databases'',''69% (11)'',12.';
wwv_flow_imp.g_varchar2_table(102) := '99,''item/eggs.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_i';
wwv_flow_imp.g_varchar2_table(103) := 'tems(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(17,''Ora';
wwv_flow_imp.g_varchar2_table(104) := 'cle Fruit Fusion'',''Fresh flavors organized with the precision of a database'',''100% (1)'',2.99,''item/f';
wwv_flow_imp.g_varchar2_table(105) := 'ruits.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_items(id,';
wwv_flow_imp.g_varchar2_table(106) := 'name,description,rating,price,image_url,created,created_by,updated,updated_by)values(18,''APEX Hotcak';
wwv_flow_imp.g_varchar2_table(107) := 'e Heaven'',''Fluffy delight as satisfying as using Oracle APEX'',''88% (15)'',5.99,''item/hotcake.jpg'',SYS';
wwv_flow_imp.g_varchar2_table(108) := 'TIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_items(id,name,descripti';
wwv_flow_imp.g_varchar2_table(109) := 'on,rating,price,image_url,created,created_by,updated,updated_by)values(19,''Tech Ice Cream'',''Where te';
wwv_flow_imp.g_varchar2_table(110) := 'chnology meets sweetness in a blend reminiscent of Oracle'',''79% (56)'',7.99,''item/icecream.jpg'',SYSTI';
wwv_flow_imp.g_varchar2_table(111) := 'MESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_items(id,name,description';
wwv_flow_imp.g_varchar2_table(112) := ',rating,price,image_url,created,created_by,updated,updated_by)values(20,''APEXpresso Latte'',''Coffee d';
wwv_flow_imp.g_varchar2_table(113) := 'elight as smooth and efficient as Oracle APEX'',''96% (222)'',7.99,''item/latte.jpg'',SYSTIMESTAMP,''APEXT';
wwv_flow_imp.g_varchar2_table(114) := 'OGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_items(id,name,description,rating,price,';
wwv_flow_imp.g_varchar2_table(115) := 'image_url,created,created_by,updated,updated_by)values(21,''Data Explorers Poke Bowl'',''Culinary adven';
wwv_flow_imp.g_varchar2_table(116) := 'ture inspired by the precision of data management'',''78% (33)'',6.99,''item/poke.jpg'',SYSTIMESTAMP,''APE';
wwv_flow_imp.g_varchar2_table(117) := 'XTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_items(id,name,description,rating,pric';
wwv_flow_imp.g_varchar2_table(118) := 'e,image_url,created,created_by,updated,updated_by)values(22,''Oracle Salmon Symphony'',''Seafood sensat';
wwv_flow_imp.g_varchar2_table(119) := 'ion as harmonious as a well-optimized database'',''97% (85)'',9.99,''item/salmon.jpg'',SYSTIMESTAMP,''APEX';
wwv_flow_imp.g_varchar2_table(120) := 'TOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_items(id,name,description,rating,price';
wwv_flow_imp.g_varchar2_table(121) := ',image_url,created,created_by,updated,updated_by)values(23,''Tech-Crisp Shrimp'',''Where the crunch is ';
wwv_flow_imp.g_varchar2_table(122) := 'as satisfying as the data security of Oracle technology'',''91% (12)'',1.99,''item/shrimp.jpg'',SYSTIMEST';
wwv_flow_imp.g_varchar2_table(123) := 'AMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
'insert into sample_restaurant_items(id,name,description,rat';
wwv_flow_imp.g_varchar2_table(124) := 'ing,price,image_url,created,created_by,updated,updated_by)values(24,''Database Comfort Soup'',''Hearty ';
wwv_flow_imp.g_varchar2_table(125) := 'bowl of comfort as reliable as an Oracle database.'',''82% (47)'',2.99,''item/soup.jpg'',SYSTIMESTAMP,''AP';
wwv_flow_imp.g_varchar2_table(126) := 'EXTOGO'',SYSTIMESTAMP,''APEXTOGO'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sample_restaurant_orders(order_id,order_datetime,orde';
wwv_flow_imp.g_varchar2_table(127) := 'r_status)values(77,SYSTIMESTAMP,''IN PROGRESS'');'||wwv_flow.LF||
'insert into sample_restaurant_orders(order_id,order_';
wwv_flow_imp.g_varchar2_table(128) := 'datetime,order_status)values(12,SYSTIMESTAMP - DBMS_RANDOM.VALUE(0, 60),''PAST ORDERS'');'||wwv_flow.LF||
'insert into ';
wwv_flow_imp.g_varchar2_table(129) := 'sample_restaurant_orders(order_id,order_datetime,order_status)values(24,SYSTIMESTAMP - DBMS_RANDOM.V';
wwv_flow_imp.g_varchar2_table(130) := 'ALUE(0, 60),''PAST ORDERS'');'||wwv_flow.LF||
'insert into sample_restaurant_orders(order_id,order_datetime,order_statu';
wwv_flow_imp.g_varchar2_table(131) := 's)values(36,SYSTIMESTAMP - DBMS_RANDOM.VALUE(0, 60),''PAST ORDERS'');'||wwv_flow.LF||
'insert into sample_restaurant_or';
wwv_flow_imp.g_varchar2_table(132) := 'ders(order_id,order_datetime,order_status)values(48,SYSTIMESTAMP - DBMS_RANDOM.VALUE(0, 60),''PAST OR';
wwv_flow_imp.g_varchar2_table(133) := 'DERS'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sample_restaurant_order_items(order_id,item_id,unit_price,quantity,line_item_id';
wwv_flow_imp.g_varchar2_table(134) := ',utensils,note)values(77,1,34.99,1,2,''Y'',''Please add extra chesse!'');'||wwv_flow.LF||
'insert into sample_restaurant_';
wwv_flow_imp.g_varchar2_table(135) := 'order_items(order_id,item_id,unit_price,quantity,line_item_id,utensils,note)values(77,4,5.99,4,3,''N''';
wwv_flow_imp.g_varchar2_table(136) := ',''Without salad'');'||wwv_flow.LF||
'insert into sample_restaurant_order_items(order_id,item_id,unit_price,quantity,li';
wwv_flow_imp.g_varchar2_table(137) := 'ne_item_id,utensils,note)values(12,9,46.99,2,1,''Y'',''I only need napkins'');'||wwv_flow.LF||
'insert into sample_restau';
wwv_flow_imp.g_varchar2_table(138) := 'rant_order_items(order_id,item_id,unit_price,quantity,line_item_id,utensils,note)values(12,12,20.99,';
wwv_flow_imp.g_varchar2_table(139) := '1,2,''N'',''Please add spicy'');'||wwv_flow.LF||
'insert into sample_restaurant_order_items(order_id,item_id,unit_price,q';
wwv_flow_imp.g_varchar2_table(140) := 'uantity,line_item_id,utensils,note)values(24,15,24.99,2,3,''Y'',''Without Mustard'');'||wwv_flow.LF||
'insert into sample';
wwv_flow_imp.g_varchar2_table(141) := '_restaurant_order_items(order_id,item_id,unit_price,quantity,line_item_id,utensils,note)values(24,3,';
wwv_flow_imp.g_varchar2_table(142) := '17.99,2,1,''N'',''Do not ring doorbell'');'||wwv_flow.LF||
'insert into sample_restaurant_order_items(order_id,item_id,un';
wwv_flow_imp.g_varchar2_table(143) := 'it_price,quantity,line_item_id,utensils,note)values(36,19,19.99,3,2,''Y'',''Do not ring doorbell'');'||wwv_flow.LF||
'ins';
wwv_flow_imp.g_varchar2_table(144) := 'ert into sample_restaurant_order_items(order_id,item_id,unit_price,quantity,line_item_id,utensils,no';
wwv_flow_imp.g_varchar2_table(145) := 'te)values(48,22,36.99,4,3,''N'',''Do not ring doorbell'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(848216811124745416)
,p_install_id=>wwv_flow_imp.id(697223373646968968)
,p_name=>'Install Data'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
