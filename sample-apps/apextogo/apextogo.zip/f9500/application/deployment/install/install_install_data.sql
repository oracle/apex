prompt --application/deployment/install/install_install_data
begin
--   Manifest
--     INSTALL: INSTALL-Install Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(848216811124745416)
,p_install_id=>wwv_flow_imp.id(697223373646968968)
,p_name=>'Install Data'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from sample_restaurant_order_items;',
'delete from sample_restaurant_orders;',
'delete from sample_restaurant_items;',
'delete from sample_restaurant;',
'delete from sample_restaurant_categories;',
'',
'insert into sample_restaurant_categories(id,name,image_url,created,created_by,updated,updated_by)values(1,''Breakfast'',''category/category-1.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_categories(id,name,image_url,created,created_by,updated,updated_by)values(2,''Fast Food'',''category/category-2.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_categories(id,name,image_url,created,created_by,updated,updated_by)values(3,''Indian'',''category/category-3.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_categories(id,name,image_url,created,created_by,updated,updated_by)values(4,''Healthy'',''category/category-4.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_categories(id,name,image_url,created,created_by,updated,updated_by)values(5,''Pizza'',''category/category-5.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_categories(id,name,image_url,created,created_by,updated,updated_by)values(6,''Chicken'',''category/category-6.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_categories(id,name,image_url,created,created_by,updated,updated_by)values(7,''Thai'',''category/category-7.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_categories(id,name,image_url,created,created_by,updated,updated_by)values(8,''Mexican'',''category/category-8.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_categories(id,name,image_url,created,created_by,updated,updated_by)values(9,''Asian'',''category/category-9.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_categories(id,name,image_url,created,created_by,updated,updated_by)values(10,''Desserts'',''category/category-10.png'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'',
'insert into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,delivery_time)values(1,''ByteStart Breakfast Nook'',''Address #123'',''4.0'',''restaurant/bytestart-breakfast-nook.jpg'',''re'
||'staurant/restaurant-hero-1.jpg'',1,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',0,50);',
'insert into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,delivery_time)values(2,''SQLicious Bistro'',''Address #724'',''3.2'',''restaurant/sqlicious-bistro.jpg'',''restaurant/restaur'
||'ant-hero-2.jpg'',2,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',1,60);',
'insert into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,delivery_time)values(3,''PL/SQLovely Diner'',''Address #335'',''5.0'',''restaurant/sqlovely-diner.jpg'',''restaurant/restaura'
||'nt-hero-3.jpg'',2,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',0,60);',
'insert into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,delivery_time)values(4,''Oracool Cafe'',''Address #294'',''4.5'',''restaurant/oracool-cafe.jpg'',''restaurant/restaurant-hero'
||'-4.jpg'',1,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',1,45);',
'insert into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,delivery_time)values(5,''APEXquisite Delights'',''Address #513'',''4.3'',''restaurant/apexquisite-delights.jpg'',''restaurant'
||'/restaurant-hero-5.jpg'',6,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',2,45);',
'insert into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,delivery_time)values(6,''SQLtastic Grill'',''Address #367'',''3.7'',''restaurant/sqltastic-grill.jpg'',''restaurant/restauran'
||'t-hero-6.jpg'',5,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',6,30);',
'insert into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,delivery_time)values(7,''PL/SQL Paradise'',''Address #211'',''4.9'',''restaurant/sql-paradise.jpg'',''restaurant/restaurant-h'
||'ero-7.jpg'',3,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',8,33);',
'insert into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,delivery_time)values(8,''APEXtraordinary Fare'',''Address #841'',''2.9'',''restaurant/apextraordinary-fare.jpg'',''restaurant'
||'/restaurant-hero-8.jpg'',9,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',0,60);',
'insert into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,delivery_time)values(9,''Oraculicious Cuisine'',''Address #751'',''4.7'',''restaurant/oraculicious-cuisine.jpg'',''restaurant'
||'/restaurant-hero-9.jpg'',8,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',9,45);',
'insert into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,delivery_time)values(10,''APEX Mex Grill'',''Address #571'',''5.0'',''restaurant/apex-mex-grill.jpg'',''restaurant/restaurant'
||'-hero-10.jpg'',4,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',7,40);',
'insert into sample_restaurant(id,name,address,rating,logo_url,hero_url,category_id,created,created_by,updated,updated_by,delivery_fee,delivery_time)values(11,''SQL Sushi Bar'',''Address #382'',''4.7'',''restaurant/sql-sushi-grill.jpg'',''restaurant/restaurant'
||'-hero-11.jpg'',6,SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'',0,30);',
'',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(1,''PL/SQL Paradise Pasta'',''Paradise Pasta cooked in PL/SQL heaven'',''92% (13)'',5.99,''item/pasta.jpg'',SYSTIMESTAMP,''APEXTOGO'',SY'
||'STIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(2,''APEXtraordinary Steak'',''Extraordinary Steak with an APEX touch'',''93% (100)'',9.99,''item/steak.jpg'',SYSTIMESTAMP,''APEXTOGO'',S'
||'YSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(3,''SQLtimate Seafood Platter'',''Ultimate Seafood Platter seasoned with SQLtimate perfection'',''100% (123)'',6.99,''item/seafood.jp'
||'g'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(4,''Oraculicious Chicken'',''Chicken made Oraculicious'',''56% (5)'',2.99,''item/chicken.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''A'
||'PEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(5,''SQLtastic Tacos'',''Tacos filled with SQLtastic flavors'',''89% (210)'',6.99,''item/taco.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAM'
||'P,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(6,''SQLicious Salad'',''Salad made with SQL magic'',''88% (23)'',8.99,''item/salad.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOG'
||'O'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(7,''Oracool Wrap'',''Refreshing Wrap inspired by Oracle'',''96% (322)'',3.99,''item/wrap.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''A'
||'PEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(8,''PL/SQLovely Pizza'',''Lovely Pizza infused with PL/SQL goodness'',''99% (12)'',4.99,''item/pizza.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYS'
||'TIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(9,''APEXquisite Sushi Roll'',''Exquisite Sushi Roll with an APEX twist'',''85% (211)'',12.99,''item/sushi.jpg'',SYSTIMESTAMP,''APEXTOGO'
||''',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(10,''APEXcellent Burger'',''Delicious Burger with APEX flavor'',''76% (29)'',5.99,''item/burger.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMES'
||'TAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(11,''APEX Crunchy Byte'',''Crispy vada that crunches like data in an Oracle database'',''49% (34)'',2.99,''item/vada.jpg'',SYSTIMESTAM'
||'P,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(12,''Data Delight Yogurt'',''Smooth and creamy treat just as seamless as Oracle APEX'',''45% (90)'',6.99,''item/yogurt.jpg'',SYSTIMEST'
||'AMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(13,''Oracle Brownie Bliss'',''Sweet indulgence that is as reliable as a well-structured database'',''100% (11)'',8.99,''item/brownie.'
||'jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(14,''Database Brewed Coffee'',''Energizing drink as robust as your database architecture'',''84% (189)'',9.99,''item/coffee.jpg'',SYST'
||'IMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(15,''APEX Dumpling Delight'',''Flavorful journey akin to navigating Oracle APEX'',''67% (455)'',2.99,''item/dumplin.jpg'',SYSTIMESTAMP'
||',''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(16,''Data-Driven Eggs'',''Protein-packed delight inspired by the efficiency of Oracle databases'',''69% (11)'',12.99,''item/eggs.jpg'''
||',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(17,''Oracle Fruit Fusion'',''Fresh flavors organized with the precision of a database'',''100% (1)'',2.99,''item/fruits.jpg'',SYSTIMES'
||'TAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(18,''APEX Hotcake Heaven'',''Fluffy delight as satisfying as using Oracle APEX'',''88% (15)'',5.99,''item/hotcake.jpg'',SYSTIMESTAMP,'''
||'APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(19,''Tech Ice Cream'',''Where technology meets sweetness in a blend reminiscent of Oracle'',''79% (56)'',7.99,''item/icecream.jpg'',SY'
||'STIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(20,''APEXpresso Latte'',''Coffee delight as smooth and efficient as Oracle APEX'',''96% (222)'',7.99,''item/latte.jpg'',SYSTIMESTAMP,'''
||'APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(21,''Data Explorers Poke Bowl'',''Culinary adventure inspired by the precision of data management'',''78% (33)'',6.99,''item/poke.jpg'
||''',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(22,''Oracle Salmon Symphony'',''Seafood sensation as harmonious as a well-optimized database'',''97% (85)'',9.99,''item/salmon.jpg'',S'
||'YSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(23,''Tech-Crisp Shrimp'',''Where the crunch is as satisfying as the data security of Oracle technology'',''91% (12)'',1.99,''item/shr'
||'imp.jpg'',SYSTIMESTAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'insert into sample_restaurant_items(id,name,description,rating,price,image_url,created,created_by,updated,updated_by)values(24,''Database Comfort Soup'',''Hearty bowl of comfort as reliable as an Oracle database.'',''82% (47)'',2.99,''item/soup.jpg'',SYSTIME'
||'STAMP,''APEXTOGO'',SYSTIMESTAMP,''APEXTOGO'');',
'',
'insert into sample_restaurant_orders(order_id,order_datetime,order_status)values(77,SYSTIMESTAMP,''IN PROGRESS'');',
'insert into sample_restaurant_orders(order_id,order_datetime,order_status)values(12,SYSTIMESTAMP - DBMS_RANDOM.VALUE(0, 60),''PAST ORDERS'');',
'insert into sample_restaurant_orders(order_id,order_datetime,order_status)values(24,SYSTIMESTAMP - DBMS_RANDOM.VALUE(0, 60),''PAST ORDERS'');',
'insert into sample_restaurant_orders(order_id,order_datetime,order_status)values(36,SYSTIMESTAMP - DBMS_RANDOM.VALUE(0, 60),''PAST ORDERS'');',
'insert into sample_restaurant_orders(order_id,order_datetime,order_status)values(48,SYSTIMESTAMP - DBMS_RANDOM.VALUE(0, 60),''PAST ORDERS'');',
'',
'insert into sample_restaurant_order_items(order_id,item_id,unit_price,quantity,line_item_id,utensils,note)values(77,1,34.99,1,2,''Y'',''Please add extra chesse!'');',
'insert into sample_restaurant_order_items(order_id,item_id,unit_price,quantity,line_item_id,utensils,note)values(77,4,5.99,4,3,''N'',''Without salad'');',
'insert into sample_restaurant_order_items(order_id,item_id,unit_price,quantity,line_item_id,utensils,note)values(12,9,46.99,2,1,''Y'',''I only need napkins'');',
'insert into sample_restaurant_order_items(order_id,item_id,unit_price,quantity,line_item_id,utensils,note)values(12,12,20.99,1,2,''N'',''Please add spicy'');',
'insert into sample_restaurant_order_items(order_id,item_id,unit_price,quantity,line_item_id,utensils,note)values(24,15,24.99,2,3,''Y'',''Without Mustard'');',
'insert into sample_restaurant_order_items(order_id,item_id,unit_price,quantity,line_item_id,utensils,note)values(24,3,17.99,2,1,''N'',''Do not ring doorbell'');',
'insert into sample_restaurant_order_items(order_id,item_id,unit_price,quantity,line_item_id,utensils,note)values(36,19,19.99,3,2,''Y'',''Do not ring doorbell'');',
'insert into sample_restaurant_order_items(order_id,item_id,unit_price,quantity,line_item_id,utensils,note)values(48,22,36.99,4,3,''N'',''Do not ring doorbell'');'))
);
wwv_flow_imp.component_end;
end;
/
