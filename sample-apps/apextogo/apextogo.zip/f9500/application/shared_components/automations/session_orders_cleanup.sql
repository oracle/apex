prompt --application/shared_components/automations/session_orders_cleanup
begin
--   Manifest
--     AUTOMATION: Session orders cleanup
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_automation(
 p_id=>wwv_flow_imp.id(64120875142590344)
,p_name=>'Session orders cleanup'
,p_static_id=>'session-orders-cleanup'
,p_trigger_type=>'POLLING'
,p_polling_interval=>'FREQ=DAILY;INTERVAL=1;BYHOUR=0;BYMINUTE=0'
,p_polling_status=>'DISABLED'
,p_result_type=>'ALWAYS'
,p_use_local_sync_table=>false
,p_include_rowid_column=>false
,p_commit_each_row=>false
,p_error_handling_type=>'IGNORE'
);
wwv_flow_imp_shared.create_automation_action(
 p_id=>wwv_flow_imp.id(64121238454590347)
,p_automation_id=>wwv_flow_imp.id(64120875142590344)
,p_name=>'Delete Orders'
,p_execution_sequence=>10
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete sample_restaurant_order_items',
' where order_id in (',
'       select order_id',
'         from sample_restaurant_orders',
'        where session_id is not null );',
'',
'delete sample_restaurant_orders',
' where session_id is not null;',
''))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp.component_end;
end;
/
