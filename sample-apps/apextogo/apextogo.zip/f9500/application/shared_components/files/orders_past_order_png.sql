prompt --application/shared_components/files/orders_past_order_png
begin
--   Manifest
--     APP STATIC FILES: 9500
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000064000000640803000000473C656600000024504C5445DE5334FFFFFFFDF5F2FDF4F2FBE9E6F9DFD9F5C9BFEFA999ED9F8CE4745AE2694EE05E41647CCBFE000000794944415478DAEDD7A911C03010C550';
wwv_flow_imp.g_varchar2_table(2) := '6FEED8FDF79B99900F8C852C35F0B09A999999999999ADD9687CF7D179A32A0A6744C18CBF8B37EA1C1A1ACB1B4FE78DBB8ECE1B158533A240467BB7289301289341289381289381289C11658FC12931288534A2C4209518A41283546280CA702FCCCCCC';
wwv_flow_imp.g_varchar2_table(3) := 'CCCCCC56EA039A3C043E6639F6570000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(63032919802227559)
,p_file_name=>'orders/past-order.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
