prompt --application/shared_components/pwa/shortcuts/cart
begin
--   Manifest
--     PWA SHORTCUT: Cart
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_shortcut(
 p_id=>wwv_flow_imp.id(683907686941041659)
,p_name=>'Cart'
,p_display_sequence=>30
,p_target_url=>'f?p=&APP_ID.:7:&SESSION.'
,p_icon_url=>'pwa/shortcut-icon-30.png'
);
wwv_flow_imp.component_end;
end;
/
