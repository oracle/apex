prompt --application/shared_components/pwa/shortcuts/home
begin
--   Manifest
--     PWA SHORTCUT: Home
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_shortcut(
 p_id=>wwv_flow_imp.id(697202324536896623)
,p_name=>'Home'
,p_display_sequence=>10
,p_target_url=>'f?p=&APP_ID.:1:&SESSION.'
,p_icon_url=>'pwa/shortcut-icon-10.png'
);
wwv_flow_imp.component_end;
end;
/
