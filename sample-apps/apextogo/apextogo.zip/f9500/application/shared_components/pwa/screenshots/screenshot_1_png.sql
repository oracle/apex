prompt --application/shared_components/pwa/screenshots/screenshot_1_png
begin
--   Manifest
--     PWA SCREENSHOT: screenshot-1.png
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_pwa_screenshot(
 p_id=>wwv_flow_imp.id(63046121139251297)
,p_label=>'screenshot-1.png'
,p_display_sequence=>10
,p_screenshot_url=>'pwa/screenshot-1.png'
);
wwv_flow_imp.component_end;
end;
/
