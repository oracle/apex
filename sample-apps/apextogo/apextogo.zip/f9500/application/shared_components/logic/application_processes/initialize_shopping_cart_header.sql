prompt --application/shared_components/logic/application_processes/initialize_shopping_cart_header
begin
--   Manifest
--     APPLICATION PROCESS: Initialize Shopping Cart Header
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(759424993482273227)
,p_process_sequence=>1
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize Shopping Cart Header'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':SHOPPING_CART_ITEMS := sample_restaurant_manage_orders.get_quantity;',
':SHOPPING_CART_ICON  := case',
'                          when :SHOPPING_CART_ITEMS > 0',
'                          then ''fa-cart-full''',
'                          else ''fa-cart-empty''',
'                        end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>37167838126044
);
wwv_flow_imp.component_end;
end;
/
