prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'Cart'
,p_alias=>'CART'
,p_step_title=>'Cart'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(885416234377983904)
,p_name=>'Total'
,p_region_name=>'CartTotal'
,p_template=>2322115667525957943
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:t-Region--removeHeader js-removeLandmark'
,p_component_template_options=>'#DEFAULT#:t-AVPList--fixedLabelLarge:t-AVPList--rightAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sum( p.price* n002 ) total',
'  from apex_collections a,',
'       sample_restaurant_items p',
' where collection_name = ''ITEMS''',
'   and p.id = a.n001',
' order by p.id'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from apex_collections a,',
'       sample_restaurant_items p',
' where collection_name = ''ITEMS''',
'   and p.id = a.n001'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(59706686154517643)
,p_query_column_id=>1
,p_column_alias=>'TOTAL'
,p_column_display_sequence=>10
,p_column_heading=>'Total'
,p_use_as_row_header=>'Y'
,p_column_html_expression=>'<strong>$#TOTAL#</strong>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(885416542199983907)
,p_plug_name=>'Cart'
,p_region_name=>'CartRegion'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select seq_id item,',
'       p.image_url,',
'       p.id,',
'       p.name,',
'       p.price,',
'       n002 quantity,',
'       p.price * n002 subtotal,',
'       c001 utensils,',
'       c002 note',
'  from apex_collections a,',
'       sample_restaurant_items p',
' where collection_name = ''ITEMS''',
'   and p.id = a.n001',
' order by p.id'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P8_SHOPPING_CART_ITEMS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>'Your cart is empty'
,p_no_data_found_icon_classes=>'fa-cart-empty'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_IMAGE', '{"source":"URL","url":"#APP_FILES#&IMAGE_URL."}',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_SIZE', 't-Avatar--md',
  'AVATAR_TYPE', 'image',
  'DESCRIPTION', wwv_flow_string.join(wwv_flow_t_varchar2(
    'Quantity: &QUANTITY.<br />',
    'Subtotal: $&SUBTOTAL.')),
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'TITLE', '&NAME.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(151979809943798903)
,p_name=>'UTENSILS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UTENSILS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(151979904091798904)
,p_name=>'NOTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NOTE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(885416844354983910)
,p_name=>'ITEM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITEM'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(885416869119983911)
,p_name=>'IMAGE_URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IMAGE_URL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(885416990022983912)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(885417063402983913)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(885417173339983914)
,p_name=>'PRICE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRICE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(885417318774983915)
,p_name=>'QUANTITY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QUANTITY'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(885417453969983916)
,p_name=>'SUBTOTAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SUBTOTAL'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2004557949994494431)
,p_plug_name=>'Actions'
,p_region_css_classes=>'t-ButtonRegion--stickToBottom padding-sm'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--hiddenOverflow'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>80
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59712702240517661)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2004557949994494431)
,p_button_name=>'CLEAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--link:t-Button--stretch:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Clear Cart'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'SHOPPING_CART_ITEMS'
,p_button_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59713106273517661)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2004557949994494431)
,p_button_name=>'CHECKOUT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Checkout'
,p_button_condition=>'SHOPPING_CART_ITEMS'
,p_button_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_icon_css_classes=>'fa-cart-empty'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(59727695990517674)
,p_branch_name=>'Go to Orders'
,p_branch_action=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(59713106273517661)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(59728127541517674)
,p_branch_name=>'Go to Home'
,p_branch_action=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(59712702240517661)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59809052682907799)
,p_name=>'P8_SHOPPING_CART_ITEMS'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(894722674915798733)
,p_name=>'P8_ORDER_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(59719446068517667)
,p_name=>'Update Shopping Cart'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(885416542199983907)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'parseInt( $v( "P8_SHOPPING_CART_ITEMS" ) ) > 0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59719895284517667)
,p_event_id=>wwv_flow_imp.id(59719446068517667)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Update Badge Text',
'apex.jQuery( ''.js-shopping-cart-item .t-Button-badge'' ).text( this.data.P7_SHOPPING_CART_ITEMS );',
'',
'// Update Icon',
'apex.jQuery( ''.js-shopping-cart-item .t-Icon'' ).toggleClass( ''fa-cart-empty fa-cart-full'' );'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59720418305517668)
,p_event_id=>wwv_flow_imp.id(59719446068517667)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Update Badge Text',
'apex.jQuery( ''.js-shopping-cart-item .t-Button-badge'' ).text( '''' );',
'',
'// Update Icon',
'apex.jQuery( ''.js-shopping-cart-item .t-Icon'' ).toggleClass( ''fa-cart-full fa-cart-empty'' );'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59720924111517668)
,p_event_id=>wwv_flow_imp.id(59719446068517667)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(885416542199983907)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59721405320517669)
,p_event_id=>wwv_flow_imp.id(59719446068517667)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(885416542199983907)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59721894217517669)
,p_event_id=>wwv_flow_imp.id(59719446068517667)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(885416234377983904)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59722390206517670)
,p_event_id=>wwv_flow_imp.id(59719446068517667)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_name=>'Refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(885416234377983904)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59722869092517670)
,p_event_id=>wwv_flow_imp.id(59719446068517667)
,p_event_result=>'FALSE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_name=>'Hide Buttons'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2004557949994494431)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59723426378517670)
,p_event_id=>wwv_flow_imp.id(59719446068517667)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_name=>'Show Buttons'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2004557949994494431)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59723935299517671)
,p_event_id=>wwv_flow_imp.id(59719446068517667)
,p_event_result=>'FALSE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_name=>'Hide Total'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(885416234377983904)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59724425303517671)
,p_event_id=>wwv_flow_imp.id(59719446068517667)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_name=>'Show Total'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(885416234377983904)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59982279562157281)
,p_event_id=>wwv_flow_imp.id(59719446068517667)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P8_SHOPPING_CART_ITEMS'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P7_SHOPPING_CART_ITEMS'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(59724808939517672)
,p_name=>'Clear Cart'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(59712702240517661)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59725293372517672)
,p_event_id=>wwv_flow_imp.id(59724808939517672)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Confirm to clear the cart'
,p_attribute_03=>'warning'
,p_attribute_06=>'Confirm'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59725826457517672)
,p_event_id=>wwv_flow_imp.id(59724808939517672)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CLEAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59718592538517666)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Clear Shopping Cart'
,p_process_sql_clob=>'sample_restaurant_manage_orders.clear_cart;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(59712702240517661)
,p_internal_uid=>46422127008656986
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59719054925517666)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Checkout'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sample_restaurant_manage_orders.create_order( p_order_id =>   :P8_ORDER_ID,',
'                                              p_session_id => :APP_SESSION );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(59713106273517661)
,p_internal_uid=>46422589395656986
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59714448121517662)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Send Notification'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_PWA'
,p_attribute_04=>'SEND_PUSH_NOTIFICATION'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(59713106273517661)
,p_process_when=>'apex_pwa.has_push_subscription'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>46417982591656982
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(59714940137517663)
,p_page_process_id=>wwv_flow_imp.id(59714448121517662)
,p_page_id=>8
,p_name=>'p_application_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>10
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(59715446562517663)
,p_page_process_id=>wwv_flow_imp.id(59714448121517662)
,p_page_id=>8
,p_name=>'p_user_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'APP_USER'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(59715868322517664)
,p_page_process_id=>wwv_flow_imp.id(59714448121517662)
,p_page_id=>8
,p_name=>'p_title'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'STATIC'
,p_value=>'We are preparing your order.'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(59716386373517664)
,p_page_process_id=>wwv_flow_imp.id(59714448121517662)
,p_page_id=>8
,p_name=>'p_body'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'STATIC'
,p_value=>'Get 5% Off on your next Order!'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(59716940713517665)
,p_page_process_id=>wwv_flow_imp.id(59714448121517662)
,p_page_id=>8
,p_name=>'p_icon_url'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>50
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(59717430703517665)
,p_page_process_id=>wwv_flow_imp.id(59714448121517662)
,p_page_id=>8
,p_name=>'p_target_url'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59718196844517666)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Push Queue'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_PWA'
,p_attribute_04=>'PUSH_QUEUE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(59713106273517661)
,p_process_when=>'apex_pwa.has_push_subscription'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>46421731314656986
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59902479007210551)
,p_process_sequence=>80
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Calculate Shopping Cart Items'
,p_process_sql_clob=>':P8_SHOPPING_CART_ITEMS := sample_restaurant_manage_orders.get_quantity;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>46606013477349871
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59717843255517665)
,p_process_sequence=>60
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'edit_cart'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if sample_restaurant_manage_orders.item_quantity( p_item_id => apex_application.g_x01 ) > 0 then',
'    sample_restaurant_manage_orders.remove_item( p_item_id => apex_application.g_x01 );',
'    sample_restaurant_manage_orders.add_item( p_item_id  => apex_application.g_x01,',
'                                              p_quantity => apex_application.g_x02,',
'                                              p_utensils => apex_application.g_x03,',
'                                              p_note     => apex_application.g_x04 );',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>46421377725656985
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(109070024995504903)
,p_region_id=>wwv_flow_imp.id(885416542199983907)
,p_position_id=>362316004162771045
,p_display_sequence=>20
,p_template_id=>362316605839802174
,p_label=>'Decrease Item Quantity'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$cart?id=&ID.&quantity=&QUANTITY.&utensils=&UTENSILS.&note=&NOTE.&action=minus'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-minus'
,p_action_css_classes=>'padding-sm'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(109070217949504905)
,p_region_id=>wwv_flow_imp.id(885416542199983907)
,p_position_id=>362316004162771045
,p_display_sequence=>30
,p_template_id=>362316605839802174
,p_label=>'Increase Item Quantity'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$cart?id=&ID.&quantity=&QUANTITY.&utensils=&UTENSILS.&note=&NOTE.&action=add'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-plus'
,p_action_css_classes=>'padding-sm'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(885417481462983917)
,p_region_id=>wwv_flow_imp.id(885416542199983907)
,p_position_id=>349402277895478545
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:7:P7_ITEM_ID,P7_ITEM_NAME:&ID.,&NAME.'
,p_link_attributes=>'aria-label="&NAME."'
);
wwv_flow_imp.component_end;
end;
/
