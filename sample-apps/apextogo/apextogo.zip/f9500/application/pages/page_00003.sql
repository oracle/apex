prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Get Started'
,p_alias=>'GET-STARTED'
,p_step_title=>'Get Started'
,p_autocomplete_on_off=>'ON'
,p_step_template=>2101157952850466385
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(290152954779766656)
,p_plug_name=>'Background Image'
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>70
,p_plug_display_point=>'BACKGROUND_IMAGE'
,p_location=>null
,p_region_image=>'#APP_FILES#background.jpg'
,p_landmark_type=>'exclude_landmark'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3760082554616460809)
,p_plug_name=>'Get Started Image'
,p_region_css_classes=>'u-flex u-justify-content-center'
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter:margin-top-none'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>20
,p_location=>null
,p_region_image=>'#APP_FILES#splash/splash-3.png'
,p_landmark_type=>'exclude_landmark'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3760083103447461576)
,p_plug_name=>'Get Started Text'
,p_region_css_classes=>'u-textCenter'
,p_region_template_options=>'#DEFAULT#:margin-top-md:margin-bottom-lg'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>'<p>Get the best experience on your mobile device<a href="#action$a-pwa-install"> by installing this app</a>.</p>'
,p_landmark_type=>'exclude_landmark'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59630824288480950)
,p_button_sequence=>50
,p_button_name=>'GO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Go!'
,p_button_redirect_url=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'mxw320 margin-auto'
,p_grid_new_row=>'Y'
,p_grid_column_span=>4
,p_grid_column=>5
);
wwv_flow_imp.component_end;
end;
/
