prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Discover'
,p_alias=>'DISCOVER'
,p_step_title=>'Discover'
,p_autocomplete_on_off=>'ON'
,p_step_template=>wwv_flow_imp.id(131811224088261402)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(273699084813319944)
,p_plug_name=>'Background Image'
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>wwv_flow_imp.id(131873353997261480)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BACKGROUND_IMAGE'
,p_location=>null
,p_region_image=>'#APP_FILES#background.jpg'
,p_landmark_type=>'exclude_landmark'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3746780793231592104)
,p_plug_name=>'Discover Image'
,p_region_css_classes=>'u-flex u-justify-content-center'
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(131873353997261480)
,p_plug_display_sequence=>20
,p_location=>null
,p_region_image=>'#APP_FILES#splash/splash-2.png'
,p_landmark_type=>'exclude_landmark'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3746781331818593112)
,p_plug_name=>'Discover Text'
,p_region_css_classes=>'u-textCenter'
,p_region_template_options=>'#DEFAULT#:margin-top-md:margin-bottom-lg'
,p_plug_template=>wwv_flow_imp.id(131836564587261436)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>'<p>This app contains mobile patterns that you can use in your own development.</p>'
,p_landmark_type=>'exclude_landmark'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46332620443616354)
,p_button_sequence=>40
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(131976309924261555)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'mxw320 margin-auto'
,p_grid_new_row=>'Y'
,p_grid_column_span=>4
,p_grid_column=>5
);
wwv_flow_imp.component_end;
end;
/
