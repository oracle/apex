prompt --application/pages/page_20000
begin
--   Manifest
--     PAGE: 20000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>20000
,p_name=>'Account'
,p_alias=>'ACCOUNT'
,p_page_mode=>'MODAL'
,p_step_title=>'Account'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(132102163325261813)
,p_step_template=>wwv_flow_imp.id(131800650008261391)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_required_patch=>wwv_flow_imp.id(132102674914261813)
,p_protection_level=>'C'
,p_help_text=>'This page contains a list of settings applicable to the current application user.'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46689417721296637)
,p_plug_name=>'User Info'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(131843690211261447)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl( :P11_NAME, :APP_USER ) USER_NAME,',
'       nvl( :P11_EMAIL, :APP_USER || ''@domain.com'' ) EMAIL',
'  from sys.dual'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'  from apex_application_temp_files',
' where name = :P11_PROFILE_PIC'))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(46689505984296638)
,p_region_id=>wwv_flow_imp.id(46689417721296637)
,p_layout_type=>'ROW'
,p_card_css_classes=>'a-CardView--noUI'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3 class="a-CardView-title">&USER_NAME.</h3>'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'<h4 class="a-CardView-subTitle u-textLower">&EMAIL.</h4>'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-user fa-2x'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(132108682433261821)
,p_plug_name=>'Settings'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'t-MediaList--showIcons:t-MediaList--showBadges:u-colors'
,p_plug_template=>wwv_flow_imp.id(131903197077261504)
,p_plug_display_sequence=>70
,p_location=>null
,p_list_id=>wwv_flow_imp.id(132106201782261817)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(131959309672261543)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(604726990724856733)
,p_plug_name=>'Actions'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(131903197077261504)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1832193233617733430)
,p_plug_name=>'User Info'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(131843690211261447)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'  from apex_application_temp_files',
' where name = :P11_PROFILE_PIC'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'  from apex_application_temp_files',
' where name = :P11_PROFILE_PIC'))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(1832193341396733431)
,p_region_id=>wwv_flow_imp.id(1832193233617733430)
,p_layout_type=>'ROW'
,p_card_css_classes=>'a-CardView--noUI'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3 class="a-CardView-title">&P11_NAME.</h3>'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'<h4 class="a-CardView-subTitle u-textLower">&P11_EMAIL.</h4>'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'BLOB'
,p_icon_blob_column_name=>'BLOB_CONTENT'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(604726848514856732)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(604726990724856733)
,p_button_name=>'SIGN_OUT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--simple:t-Button--iconLeft:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(131976446813261555)
,p_button_image_alt=>'Sign Out'
,p_icon_css_classes=>'fa-sign-out'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(604727273436856736)
,p_branch_name=>'Go To Page &LOGOUT_URL.'
,p_branch_action=>'&LOGOUT_URL.'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(604726848514856732)
,p_branch_sequence=>10
);
wwv_flow_imp.component_end;
end;
/
