prompt --application/pages/page_20000
begin
--   Manifest
--     PAGE: 20000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>20000
,p_name=>'Account'
,p_alias=>'ACCOUNT'
,p_page_mode=>'MODAL'
,p_step_title=>'Account'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(145398628855122493)
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_required_patch=>wwv_flow_imp.id(145399140444122493)
,p_protection_level=>'C'
,p_help_text=>'This page contains a list of settings applicable to the current application user.'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(59985883251157317)
,p_plug_name=>'User Info'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl( :P11_NAME, :APP_USER ) USER_NAME,',
'       nvl( :P11_EMAIL, :APP_USER || ''@domain.com'' ) EMAIL',
'  from sys.dual'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'  from apex_application_temp_files',
' where name = :P11_PROFILE_PIC'))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(59985971514157318)
,p_region_id=>wwv_flow_imp.id(59985883251157317)
,p_layout_type=>'ROW'
,p_card_css_classes=>'a-CardView--noUI'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3 class="a-CardView-title">&USER_NAME.</h3>'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'<h4 class="a-CardView-subTitle u-textLower">&EMAIL.</h4>'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-user fa-2x'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(145405147963122501)
,p_plug_name=>'Settings'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'t-MediaList--showIcons:t-MediaList--showBadges:u-colors'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>70
,p_location=>null
,p_list_id=>wwv_flow_imp.id(145402667312122497)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2067994871570597190
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(618023456254717413)
,p_plug_name=>'Actions'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1845489699147594110)
,p_plug_name=>'User Info'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'  from apex_application_temp_files',
' where name = :P11_PROFILE_PIC'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'  from apex_application_temp_files',
' where name = :P11_PROFILE_PIC'))
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(1845489806926594111)
,p_region_id=>wwv_flow_imp.id(1845489699147594110)
,p_layout_type=>'ROW'
,p_card_css_classes=>'a-CardView--noUI'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3 class="a-CardView-title">&P11_NAME.</h3>'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'<h4 class="a-CardView-subTitle u-textLower">&P11_EMAIL.</h4>'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'BLOB'
,p_icon_blob_column_name=>'BLOB_CONTENT'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(618023314044717412)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(618023456254717413)
,p_button_name=>'SIGN_OUT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--simple:t-Button--iconLeft:t-Button--stretch'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Sign Out'
,p_icon_css_classes=>'fa-sign-out'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(618023738966717416)
,p_branch_name=>'Go To Page &LOGOUT_URL.'
,p_branch_action=>'&LOGOUT_URL.'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(618023314044717412)
,p_branch_sequence=>10
);
wwv_flow_imp.component_end;
end;
/
