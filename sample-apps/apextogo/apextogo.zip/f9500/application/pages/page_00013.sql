prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>13
,p_name=>'FAQ'
,p_alias=>'FAQ'
,p_page_mode=>'MODAL'
,p_step_title=>'FAQ'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(145398628855122493)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Fix Alignment on Mobile */',
'.t-Region-titleButton {',
'  text-align: inherit;',
'}'))
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1891957938275275229)
,p_plug_name=>'General'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105749012324233103)
,p_plug_name=>'Can I see a history of my previous orders?'
,p_parent_plug_id=>wwv_flow_imp.id(1891957938275275229)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>70
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'',
'    Yes, you can view your order history by logging into your account.',
'    Simply navigate to the Orders section and select "Past Orders".',
'    There, you can see details of all your previous orders.',
'',
'</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105749125543233104)
,p_plug_name=>'How do I report a problem with my delivery?'
,p_parent_plug_id=>wwv_flow_imp.id(1891957938275275229)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>80
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    ',
'    If you encounter any issues with your delivery driver, please contact',
'    our customer support team immediately. Provide details of the incident',
'    so we can address it promptly.',
'',
'</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1958328518857928645)
,p_plug_name=>'Is there a minimum order amount?'
,p_parent_plug_id=>wwv_flow_imp.id(1891957938275275229)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    ',
'    No, there is no minimum order amount. You can order as little or as much',
'    as you like. We aim to provide flexibility and convenience for all our',
'    customers.',
'',
'</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1958328660036928646)
,p_plug_name=>'How do I place an order?'
,p_parent_plug_id=>wwv_flow_imp.id(1891957938275275229)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    ',
'    Placing an order with APEXToGo is simple! Just look for a restaurant,',
'    add your desired items to the cart, and proceed to checkout.',
'',
'</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1958328731459928647)
,p_plug_name=>'What is APEXToGo?'
,p_parent_plug_id=>wwv_flow_imp.id(1891957938275275229)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    ',
'    APEXToGo is a convenient food delivery service that brings your favorite',
'    meals from local restaurants right to your doorstep. Whether you''re craving',
'    a quick snack or a full meal, we''ve got you covered.',
'',
'</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59764785365541798)
,p_button_sequence=>20
,p_button_name=>'BACK'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--iconLeft:t-Button--gapBottom'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Account'
,p_button_redirect_url=>'f?p=&APP_ID.:20000:&APP_SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-chevron-left'
,p_grid_new_row=>'Y'
);
wwv_flow_imp.component_end;
end;
/
