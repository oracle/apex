prompt --workspace/credentials/app_9500_push_notifications_credentials
begin
--   Manifest
--     CREDENTIAL: App 9500 Push Notifications Credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>9500
,p_default_id_offset=>13296465529860680
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(22564482807709646)
,p_name=>'App 9500 Push Notifications Credentials'
,p_static_id=>'App_9500_Push_Notifications_Credentials'
,p_authentication_type=>'KEY_PAIR'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
