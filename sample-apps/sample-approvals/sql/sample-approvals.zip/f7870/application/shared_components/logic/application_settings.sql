prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 7870
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7870
,p_default_id_offset=>2857746861534931
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(1173232814365282026)
,p_name=>'DEMO_NOTIFICATION_EMAIL'
,p_is_required=>'N'
,p_version_scn=>'37166426849919'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(329999556239791989)
,p_name=>'EMP_APPRAISAL_EXTRA_VP_REVIEWERS'
,p_is_required=>'N'
,p_version_scn=>'SH256:mL3d0Q7SfmjZVbfVZPM3jUrP5lrk9hK4YLf1obPtxfc'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(330002440590995393)
,p_name=>'TEMPORARY_BUSINESS_ADMIN'
,p_is_required=>'N'
,p_version_scn=>'SH256:3vBOVFBEtExZ8_h4odqFJ-XSxJzg4Ym_iQ0z9-YF-5w'
);
wwv_flow_imp.component_end;
end;
/
