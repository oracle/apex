prompt --application/shared_components/user_interface/lovs/unified_task_list_lov_type
begin
--   Manifest
--     UNIFIED_TASK_LIST.LOV.TYPE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7870
,p_default_id_offset=>2857746861534931
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(1223246745619412912)
,p_lov_name=>'UNIFIED_TASK_LIST.LOV.TYPE'
,p_static_id=>'unified-task-list-lov-type'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select disp,',
'       val',
'  from table ( apex_approval.get_lov_type )',
' order by insert_order'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'VAL'
,p_display_column_name=>'DISP'
,p_version_scn=>'738866194'
);
wwv_flow_imp.component_end;
end;
/
