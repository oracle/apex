prompt --application/deployment/install/install_installsampledata
begin
--   Manifest
--     INSTALL: INSTALL-InstallSampleData
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7870
,p_default_id_offset=>2857746861534931
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(958084337515276614)
,p_install_id=>wwv_flow_imp.id(1263916967436750173)
,p_name=>'InstallSampleData'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    eba_demo_appr_data.install_sample_data;',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
