prompt --application/deployment/install/install_droptables
begin
--   Manifest
--     INSTALL: INSTALL-DropTables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7870
,p_default_id_offset=>2857746861534931
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'declare'||wwv_flow.LF||
'    l_tables_to_drop apex_t_varchar2 := apex_t_varchar2(''eba_demo_appr_laptop_requests'','||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2) := '                                                     ''eba_demo_appr_laptop_stock'','||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(3) := '                                       ''eba_demo_appr_sal_history'','||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(4) := '                        ''eba_demo_appr_emp'','||wwv_flow.LF||
'                                                       ';
wwv_flow_imp.g_varchar2_table(5) := ' ''eba_demo_appr_dept'','||wwv_flow.LF||
'                                                        ''eba_demo_appr_approv';
wwv_flow_imp.g_varchar2_table(6) := 'ers'','||wwv_flow.LF||
'                                                        ''eba_demo_appr_appraisals'','||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(7) := '                                              ''eba_demo_appr_vacation'');'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for j in 1..l_ta';
wwv_flow_imp.g_varchar2_table(8) := 'bles_to_drop.count loop'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            execute immediate apex_string.format(''drop table %';
wwv_flow_imp.g_varchar2_table(9) := 's cascade constraints'',l_tables_to_drop(j));'||wwv_flow.LF||
'        exception'||wwv_flow.LF||
'            when others then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(10) := '        if sqlcode != -942 then'||wwv_flow.LF||
'                    raise;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'        end;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(11) := 'end loop;'||wwv_flow.LF||
'end;   '||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(958486853927045601)
,p_install_id=>wwv_flow_imp.id(1263916967436750173)
,p_name=>'DropTables'
,p_sequence=>1
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
