prompt --application/deployment/install/install_installlaptoprequeststrigger
begin
--   Manifest
--     INSTALL: INSTALL-InstallLaptopRequestsTrigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7870
,p_default_id_offset=>2857746861534931
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger "EBA_DEMO_APPR_LAPTOP_REQUESTS_T"'||wwv_flow.LF||
'before'||wwv_flow.LF||
'update on "EBA_DEMO_APPR_LAPTOP_R';
wwv_flow_imp.g_varchar2_table(2) := 'EQUESTS"'||wwv_flow.LF||
'for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :old.delivered_date is null and :new.delivered_date is not null t';
wwv_flow_imp.g_varchar2_table(3) := 'hen'||wwv_flow.LF||
'        eba_demo_appr.laptop_delivered(:new.id);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/ ';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1524334814897172006)
,p_install_id=>wwv_flow_imp.id(1263916967436750173)
,p_name=>'InstallLaptopRequestsTrigger'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(1524340311275221417)
,p_script_id=>wwv_flow_imp.id(1524334814897172006)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'EBA_DEMO_APPR_LAPTOP_REQUESTS_T'
);
wwv_flow_imp.component_end;
end;
/
