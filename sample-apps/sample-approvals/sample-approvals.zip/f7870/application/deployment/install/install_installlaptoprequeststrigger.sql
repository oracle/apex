prompt --application/deployment/install/install_installlaptoprequeststrigger
begin
--   Manifest
--     INSTALL: INSTALL-InstallLaptopRequestsTrigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7870
,p_default_id_offset=>315735426453268570
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(882607549488625290)
,p_install_id=>wwv_flow_imp.id(622189702028203457)
,p_name=>'InstallLaptopRequestsTrigger'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace trigger "EBA_DEMO_APPR_LAPTOP_REQUESTS_T"',
'before',
'update on "EBA_DEMO_APPR_LAPTOP_REQUESTS"',
'for each row',
'begin',
'    if :old.delivered_date is null and :new.delivered_date is not null then',
'        eba_demo_appr.laptop_delivered(apex_workflow.get_variable_value(:new.workflow_id,''V_DELIVERY_ACTION_TASK_ID''));',
'    end if;',
'end;',
'/ '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(882613045866674701)
,p_script_id=>wwv_flow_imp.id(882607549488625290)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'EBA_DEMO_APPR_LAPTOP_REQUESTS_T'
,p_last_updated_by=>'STEVE'
,p_last_updated_on=>to_date('20231030092900','YYYYMMDDHH24MISS')
,p_created_by=>'STEVE'
,p_created_on=>to_date('20231030092900','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
