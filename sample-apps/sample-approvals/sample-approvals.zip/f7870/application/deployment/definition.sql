prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7870
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7870
,p_default_id_offset=>2857746861534931
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'DROP TABLE EBA_DEMO_APPR_EMP CASCADE CONSTRAINTS;'||wwv_flow.LF||
'DROP TABLE EBA_DEMO_APPR_DEPT CASCADE CONSTRAINTS;';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'DROP TABLE EBA_DEMO_APPR_APPROVERS CASCADE CONSTRAINTS;'||wwv_flow.LF||
'DROP TABLE EBA_DEMO_APPR_LAPTOP_REQUESTS CA';
wwv_flow_imp.g_varchar2_table(3) := 'SCADE CONSTRAINTS;'||wwv_flow.LF||
'DROP TABLE EBA_DEMO_APPR_LAPTOP_STOCK CASCADE CONSTRAINTS;'||wwv_flow.LF||
'DROP TABLE EBA_DEMO_AP';
wwv_flow_imp.g_varchar2_table(4) := 'PR_APPRAISALS CASCADE CONSTRAINTS;'||wwv_flow.LF||
'DROP TABLE EBA_DEMO_APPR_SAL_HISTORY CASCADE CONSTRAINTS;'||wwv_flow.LF||
'DROP TA';
wwv_flow_imp.g_varchar2_table(5) := 'BLE EBA_DEMO_APPR_VACATION CASCADE CONSTRAINTS;'||wwv_flow.LF||
'DROP PACKAGE EBA_DEMO_APPR;'||wwv_flow.LF||
'DROP PACKAGE EBA_DEMO_AP';
wwv_flow_imp.g_varchar2_table(6) := 'PR_DATA;';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(1263916967436750173)
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
);
wwv_flow_imp.component_end;
end;
/
