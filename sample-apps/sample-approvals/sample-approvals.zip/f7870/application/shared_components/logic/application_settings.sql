prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 7870
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7870
,p_default_id_offset=>1574570415568221
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(321317714153350634)
,p_name=>'EMP_APPRAISAL_EXTRA_VP_REVIEWERS'
,p_is_required=>'N'
,p_version_scn=>175271526
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(321320598504554038)
,p_name=>'TEMPORARY_BUSINESS_ADMIN'
,p_is_required=>'N'
,p_version_scn=>175271527
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(1164550972278840671)
,p_name=>'DEMO_NOTIFICATION_EMAIL'
,p_is_required=>'N'
,p_version_scn=>37166426849919
);
wwv_flow_imp.component_end;
end;
/
