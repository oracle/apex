prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 7870
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7870
,p_default_id_offset=>315735426453268570
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(319743143737782413)
,p_name=>'EMP_APPRAISAL_EXTRA_VP_REVIEWERS'
,p_is_required=>'N'
,p_version_scn=>796148630
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(319746028088985817)
,p_name=>'TEMPORARY_BUSINESS_ADMIN'
,p_is_required=>'N'
,p_version_scn=>796148631
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(1162976401863272450)
,p_name=>'DEMO_NOTIFICATION_EMAIL'
,p_is_required=>'N'
,p_version_scn=>37166426849919
);
wwv_flow_imp.component_end;
end;
/
