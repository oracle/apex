prompt --application/shared_components/security/authorizations/operations_team
begin
--   Manifest
--     SECURITY SCHEME: Operations Team
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7870
,p_default_id_offset=>315735426453268570
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(1241650055756021748)
,p_name=>'Operations Team'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from eba_demo_appr_emp',
'where ename = :APP_USER',
'and deptno  = 40 /* OPERATIONS */'))
,p_error_message=>'Insufficient privileges, user is not on the Operations team'
,p_version_scn=>738866192
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
