prompt --application/shared_components/user_interface/lovs/available_laptop_types
begin
--   Manifest
--     AVAILABLE_LAPTOP_TYPES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7870
,p_default_id_offset=>2857746861534931
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(1258728977813551175)
,p_lov_name=>'AVAILABLE_LAPTOP_TYPES'
,p_lov_query=>'.'||wwv_flow_imp.id(1258728977813551175)||'.'
,p_location=>'STATIC'
,p_version_scn=>738866192
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1258729325002551176)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'MacBook Pro 14"'
,p_lov_return_value=>'MAC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1258729740444551176)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Lenovo T490'
,p_lov_return_value=>'WIN'
);
wwv_flow_imp.component_end;
end;
/
