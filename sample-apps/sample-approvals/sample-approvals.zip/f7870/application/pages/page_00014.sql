prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7870
,p_default_id_offset=>315735426453268570
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_name=>'More Information'
,p_alias=>'MORE-INFORMATION'
,p_step_title=>'More Information'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.is-markdownified code {',
'   background-color: inherit !important;',
'   border-style: none !important;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'STEVE'
,p_last_upd_yyyymmddhh24miss=>'20231031120543'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(534682042838664925)
,p_plug_name=>'More Information'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(610088540915484463)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    The <em>Sample Workflow, Approvals, and Tasks</em> app illustrates',
'    the key functionality of the Oracle APEX Workflow, Approvals, and Tasks components. ',
'    It lets users manage requests to change employees'' salaries and jobs, as well',
'    as request a new laptop, after getting the approval of an appropriate individual. ',
'    Managers can also initiate a subordinate''s appraisal process.',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(534682189475664926)
,p_plug_name=>'Sample Application'
,p_parent_plug_id=>wwv_flow_imp.id(534682042838664925)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(610019741429484400)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_MARKDOWN_REGION'
,p_attribute_01=>'APP_STATIC_FILE'
,p_attribute_03=>'AboutTheSampleApplication.md'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(538907667913186377)
,p_plug_name=>'Approvals and Tasks Features'
,p_parent_plug_id=>wwv_flow_imp.id(534682042838664925)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(610019741429484400)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_MARKDOWN_REGION'
,p_attribute_01=>'APP_STATIC_FILE'
,p_attribute_03=>'AboutTheApprovalsFeature.md'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(880107023588015010)
,p_plug_name=>'Workflow Features'
,p_parent_plug_id=>wwv_flow_imp.id(534682042838664925)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(610019741429484400)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_MARKDOWN_REGION'
,p_attribute_01=>'APP_STATIC_FILE'
,p_attribute_03=>'AboutTheWorkflowFeature.md'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(880109357117015033)
,p_plug_name=>'Using the Sample'
,p_parent_plug_id=>wwv_flow_imp.id(534682042838664925)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(610019741429484400)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_MARKDOWN_REGION'
,p_attribute_01=>'APP_STATIC_FILE'
,p_attribute_03=>'UsingTheSample.md'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(538907048899186375)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(610091155190484464)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(609981627112484341)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(610153317970484536)
);
wwv_flow_imp.component_end;
end;
/
