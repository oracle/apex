prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7870
,p_default_id_offset=>315735426453268570
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>18
,p_name=>'Manage Sample Data'
,p_alias=>'MANAGE-SAMPLE-DATA'
,p_step_title=>'Manage Sample Data'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'STEVE'
,p_last_upd_yyyymmddhh24miss=>'20231112120244'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(316726027897151131)
,p_plug_name=>'Manage Sample Data'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(610091155190484464)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(609981627112484341)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(610153317970484536)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3755065322340111441)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(610037236084484413)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    This page allows you to reset the sample employee, approver, salary history, ',
'    laptop request, and appraisal data. It also deletes the workflows created in',
'    development mode and any tasks created by those workflows. However, it does',
'    not affect the <em>Job Change</em> and <em>Salary Change</em> approval task',
'    instances created. The latter two kinds were created as standalone tasks',
'    and <em>will</em> be deleted when the sample application is deleted.',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(268648297516404249)
,p_button_sequence=>20
,p_button_name=>'Reset_Sample_Data'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(610151629562484533)
,p_button_image_alt=>'Reset Sample Data'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(268648326815404250)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reset_Sample_Data'
,p_process_sql_clob=>'eba_demo_appr_data.install_sample_data;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(268648297516404249)
,p_process_success_message=>'Sample Data Reset.'
,p_internal_uid=>268648326815404250
);
wwv_flow_imp.component_end;
end;
/
