prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-16'
,p_default_workspace_id=>20
,p_default_application_id=>7870
,p_default_id_offset=>315735426453268570
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>21
,p_user_interface_id=>wwv_flow_imp.id(610176407793484581)
,p_name=>'Setup'
,p_alias=>'SETUP'
,p_step_title=>'Setup'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(610179202849484608)
,p_protection_level=>'C'
,p_page_component_map=>'06'
,p_last_updated_by=>'STEVE'
,p_last_upd_yyyymmddhh24miss=>'20220408121932'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(316743953128370095)
,p_plug_name=>'Setup'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(610091155190484464)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(609981627112484341)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(610153317970484536)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(316752585712381938)
,p_plug_name=>'Setup'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_plug_template=>wwv_flow_imp.id(610078774492484454)
,p_plug_display_sequence=>20
,p_list_id=>wwv_flow_imp.id(316751812164381937)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(610134691035484509)
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_required_role=>wwv_flow_imp.id(610179202849484608)
,p_required_patch=>wwv_flow_imp.id(316745850141381870)
);
wwv_flow_imp.component_end;
end;
/
