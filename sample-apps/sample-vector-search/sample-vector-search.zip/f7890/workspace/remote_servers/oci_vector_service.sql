prompt --workspace/remote_servers/oci_vector_service
begin
--   Manifest
--     REMOTE SERVER: OCI Vector Service
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(16013343297879238)
,p_name=>'OCI Vector Service'
,p_static_id=>'EBA_VECTOR_OCI'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('EBA_VECTOR_OCI'),'https://inference.generativeai.us-chicago-1.oci.oraclecloud.com')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('EBA_VECTOR_OCI'),'')
,p_server_type=>'VECTOR'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('EBA_VECTOR_OCI'),'')
,p_credential_id=>wwv_flow_imp.id(14610758767804040)
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('EBA_VECTOR_OCI'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('EBA_VECTOR_OCI'),'')
,p_prompt_on_install=>false
,p_ai_provider_type=>'OCI_GENAI'
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('EBA_VECTOR_OCI'),'cohere.embed-english-v3.0')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('EBA_VECTOR_OCI'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('EBA_VECTOR_OCI'),'{"compartmentId":"ocid1.compartment.oc1","servingMode":{"modelId":"cohere.embed-english-v3.0","servingType":"ON_DEMAND"}}')
,p_embedding_type=>'GENAI_PROVIDER'
);
wwv_flow_imp.component_end;
end;
/
