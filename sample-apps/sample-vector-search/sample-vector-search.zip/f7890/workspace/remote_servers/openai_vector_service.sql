prompt --workspace/remote_servers/openai_vector_service
begin
--   Manifest
--     REMOTE SERVER: OpenAI Vector Service
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(15639632983805312)
,p_name=>'OpenAI Vector Service'
,p_static_id=>'EBA_VECTOR_OPENAI'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('EBA_VECTOR_OPENAI'),'https://api.openai.com/v1')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('EBA_VECTOR_OPENAI'),'')
,p_server_type=>'VECTOR'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('EBA_VECTOR_OPENAI'),'')
,p_credential_id=>wwv_flow_imp.id(14611336591828962)
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('EBA_VECTOR_OPENAI'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('EBA_VECTOR_OPENAI'),'')
,p_prompt_on_install=>false
,p_ai_provider_type=>'OPENAI'
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('EBA_VECTOR_OPENAI'),'text-embedding-3-small')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('EBA_VECTOR_OPENAI'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('EBA_VECTOR_OPENAI'),'')
,p_embedding_type=>'GENAI_PROVIDER'
);
wwv_flow_imp.component_end;
end;
/
