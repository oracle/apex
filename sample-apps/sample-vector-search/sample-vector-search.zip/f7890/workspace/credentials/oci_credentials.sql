prompt --workspace/credentials/oci_credentials
begin
--   Manifest
--     CREDENTIAL: OCI Credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(14610758767804040)
,p_name=>'OCI Credentials'
,p_static_id=>'EBA_CREDENTIALS_OCI'
,p_authentication_type=>'OCI'
,p_namespace=>'ocid1.tenancy.oc1'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
