prompt --workspace/credentials/openai_credentials
begin
--   Manifest
--     CREDENTIAL: OpenAI Credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_credential(
 p_id=>14611336591828962
,p_name=>'OpenAI Credentials'
,p_static_id=>'EBA_CREDENTIALS_OPENAI'
,p_authentication_type=>'HTTP_HEADER'
,p_valid_for_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://api.openai.com/v1',
''))
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
