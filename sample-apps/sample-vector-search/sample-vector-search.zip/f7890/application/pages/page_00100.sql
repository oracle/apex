prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>100
,p_name=>'Getting Started'
,p_alias=>'GETTING-STARTED'
,p_step_title=>'Getting Started'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.step-container { max-width: 1168px; margin: 1.6rem auto }',
'.step-container .t-HeroRegion:not(.t-HeroRegion--featured) .t-HeroRegion-wrap { padding: 0 }',
'.t-Alert--info .t-Alert-icon { vertical-align: top }',
'.t-Alert--horizontal .t-Alert-title { line-height: 2.8rem }',
'.content-well { background: rgba(0, 0, 0, .05); border-radius: 2px; padding: 1.6rem }',
'.users-table .t-Report-report thead { display: none }',
'.users-table .t-Report-cell { padding: 0.8rem 0; font-size: 1.4rem; line-height: 1.5 }',
'.cta-button {padding: 16px 32px; font-size: 16px;}',
'.t-Card-info {',
'  margin-top: 0;',
'}',
'',
'.t-Card-desc {',
'  display: none;',
'}',
'',
'.t-Card-title {',
'  font-weight: 400;',
'}',
'.apex-item-yes-no {white-space:pre;}'))
,p_step_template=>2979075366320325194
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'Use this items on this page to configure the app.'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1959079330331701)
,p_plug_name=>'Introduction Wizard Container'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'sys.dbms_db_version.version >= 23'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14836719044424747)
,p_plug_name=>'Button OPENAI'
,p_parent_plug_id=>wwv_flow_imp.id(1959079330331701)
,p_region_css_classes=>'step-container'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21770302707887447)
,p_plug_name=>'Introduction Wizard'
,p_parent_plug_id=>wwv_flow_imp.id(1959079330331701)
,p_region_css_classes=>'step-container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21770314222887448)
,p_plug_name=>'Welcome to Sample Vector Search'
,p_parent_plug_id=>wwv_flow_imp.id(21770302707887447)
,p_region_template_options=>'t-HeroRegion--noPadding'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>'Please take a moment to complete this first time setup.'
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21770443850887449)
,p_plug_name=>'Select Provider'
,p_title=>'Select AI Provider'
,p_parent_plug_id=>wwv_flow_imp.id(1959079330331701)
,p_region_css_classes=>'step-container'
,p_icon_css_classes=>'fa-number-1'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<p>Select an AI provider you want to use for generating data and creating vector embeddings.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21770559592887450)
,p_plug_name=>'Enter OCI Web Credentials'
,p_title=>'Enter Web Credentials'
,p_parent_plug_id=>wwv_flow_imp.id(1959079330331701)
,p_region_css_classes=>'step-container'
,p_icon_css_classes=>'fa-number-2'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<p>Enter the OCI credentials you would like to use for this application.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39607175268708201)
,p_plug_name=>'Web Credentials'
,p_parent_plug_id=>wwv_flow_imp.id(21770559592887450)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--hiddenOverflow'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21770654502887451)
,p_plug_name=>'Enter OpenAI Web Credentials'
,p_title=>'Enter Web Credentials'
,p_parent_plug_id=>wwv_flow_imp.id(1959079330331701)
,p_region_css_classes=>'step-container'
,p_icon_css_classes=>'fa-number-2'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<p>Enter the OpenAI API key you would like to use for this application.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21770716045887452)
,p_plug_name=>'Button OCI'
,p_parent_plug_id=>wwv_flow_imp.id(1959079330331701)
,p_region_css_classes=>'step-container'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1959184970331702)
,p_plug_name=>'Unsupported Database Version'
,p_region_css_classes=>'u-tC'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>'<p>This app showcases Vector Search in <strong>Oracle Database 23ai</strong> and is not compatible with earlier versions of the database. <a href="https://www.oracle.com/database/ai-vector-search/" target="_blank">Learn more about Oracle AI Vector Se'
||'arch</a></p>'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'sys.dbms_db_version.version < 23'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14836858994424748)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(14836719044424747)
,p_button_name=>'COMPLETE_OPENAI'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Complete Setup'
,p_button_position=>'CHANGE'
,p_show_processing=>'Y'
,p_button_css_classes=>'cta-button'
,p_icon_css_classes=>'fa-check-circle'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21770872189887453)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(21770716045887452)
,p_button_name=>'COMPLETE_OCI'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Complete Setup'
,p_button_position=>'CHANGE'
,p_show_processing=>'Y'
,p_button_css_classes=>'cta-button'
,p_icon_css_classes=>'fa-check-circle'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(21771006914887454)
,p_branch_name=>'Go to Home Page'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'INITIALIZED_AI_PROVIDER'
,p_branch_condition_text=>'YES'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28668382788000117)
,p_name=>'P100_OPENAI_WEB_CRED_HEADER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(21770654502887451)
,p_prompt=>'Web Credential'
,p_source=>'OpenAI Credentials'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Denotes the name of the Web Credential which is used for accessing the <strong>OpenAI Generative AI</strong>. Navigate to <strong>Workspace Utilities</strong>, <strong>Web Credential</strong> to review existing Web Credentials.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39607604709708204)
,p_name=>'P100_SHOW_WEB_CREDENTIALS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(21770559592887450)
,p_item_default=>'Y'
,p_prompt=>'Edit Web Credentials'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use the <em>Edit Web Credentials</em> switch to manage your OCI Web Credentials.</p>',
'<p>Disabling the switch allows you to only edit the <em>Compartment ID</em> after successfully entering the web credentials for the first time.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39609608909708206)
,p_name=>'P100_OCI_WEB_CRED_HEADER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(39607175268708201)
,p_prompt=>'Web Credential'
,p_source=>'OCI Credentials'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Denotes the name of the Web Credential which is used for accessing the <strong>OCI Generative AI</strong>. Navigate to <strong>Workspace Utilities</strong>, <strong>Web Credential</strong> to review existing Web Credentials.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46532116191531270)
,p_name=>'P100_AI_PROVIDER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(21770443850887449)
,p_item_default=>'CURRENT_AI_PROVIDER'
,p_item_default_type=>'ITEM'
,p_prompt=>'AI Provider'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:OCI Generative AI;OCI,Open AI;OPENAI'
,p_grid_label_column_span=>0
,p_field_template=>2040785906935475274
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46566025085632200)
,p_name=>'P100_OCI_USER_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(39607175268708201)
,p_prompt=>'OCI User ID'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#:margin-top-md'
,p_help_text=>'<p>Enter the Oracle Cloud Infrastructure <em>User OCID</em>. &PRODUCT_NAME. does not store this information encrypted.</p> <p><a rel="noopener noreferrer" target="_blank" href="https://docs.cloud.oracle.com/iaas/Content/API/Concepts/apisigningkey.htm'
||'">Oracle Cloud Infrastructure Documentation</a></p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46566101290632201)
,p_name=>'P100_OCI_PRIVATE_KEY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(39607175268708201)
,p_prompt=>'OCI Private Key'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'<p>Enter the private key in PEM format for OCI authentication. &PRODUCT_NAME. stores this information encrypted and secure, so it cannot be retrieved back in clear text.</p><p><a rel="noopener noreferrer" target="_blank" href="https://docs.cloud.orac'
||'le.com/iaas/Content/API/Concepts/apisigningkey.htm">Oracle Cloud Infrastructure Documentation</a></p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46566204338632202)
,p_name=>'P100_OCI_TENANCY_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(39607175268708201)
,p_prompt=>'OCI Tenancy ID'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Enter the Oracle Cloud Infrastructure <em>Tenancy''s OCID</em>.</p>',
'<p><a rel="noopener noreferrer" target="_blank" href="https://docs.cloud.oracle.com/iaas/Content/API/Concepts/apisigningkey.htm">Oracle Cloud Infrastructure Documentation</a></p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46566329413632203)
,p_name=>'P100_OCI_FINGERPRINT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(39607175268708201)
,p_prompt=>'OCI Public Key Fingerprint'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'<p>Enter the <em>public RSA key fingerprint</em> for OCI authentication. </p><p><a rel="noopener noreferrer" target="_blank" href="https://docs.cloud.oracle.com/iaas/Content/API/Concepts/apisigningkey.htm">Oracle Cloud Infrastructure Documentation</a'
||'></p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46567480196633702)
,p_name=>'P100_OPENAI_API_KEY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(21770654502887451)
,p_prompt=>'OpenAI API Key'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>80
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Enter the <em>API Key</em> to authenticate against the AI Provider.</p>',
'<p>Example: "sk-pr..."</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47536814991214696)
,p_name=>'P100_OCI_REGION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(21770559592887450)
,p_item_default=>'us-chicago-1'
,p_prompt=>'Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'The Oracle Cloud Infrastructure Region. The default is us-chicago-1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_show_quick_picks=>'Y'
,p_quick_pick_label_01=>'US Midwest (Chicago)'
,p_quick_pick_value_01=>'us-chicago-1'
,p_quick_pick_label_02=>'US East (Ashburn)'
,p_quick_pick_value_02=>'us-ashburn-1'
,p_quick_pick_label_03=>'US West (Phoenix)'
,p_quick_pick_value_03=>'us-phoenix-1'
,p_quick_pick_label_04=>'Germany Central (Frankfurt)'
,p_quick_pick_value_04=>'eu-frankfurt-1'
,p_quick_pick_label_05=>'UK South (London)'
,p_quick_pick_value_05=>'uk-london-1'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47536889862214697)
,p_name=>'P100_OCI_COMPARTMENT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(21770559592887450)
,p_prompt=>'Compartment ID'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'The Oracle Cloud Infrastructure Compartment ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(14507982378375032)
,p_validation_name=>'P100_OCI_USER_ID not null'
,p_validation_sequence=>10
,p_validation=>'P100_OCI_USER_ID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_validation_condition=>'P100_SHOW_WEB_CREDENTIALS'
,p_validation_condition2=>'Y'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(21770872189887453)
,p_associated_item=>wwv_flow_imp.id(46566025085632200)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(14508621485375039)
,p_validation_name=>'P100_OCI_COMPARTMENT_ID not null'
,p_validation_sequence=>20
,p_validation=>'P100_OCI_COMPARTMENT_ID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_when_button_pressed=>wwv_flow_imp.id(21770872189887453)
,p_associated_item=>wwv_flow_imp.id(47536889862214697)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(14508782550375040)
,p_validation_name=>'P100_OCI_REGION not null'
,p_validation_sequence=>30
,p_validation=>'P100_OCI_REGION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_when_button_pressed=>wwv_flow_imp.id(21770872189887453)
,p_associated_item=>wwv_flow_imp.id(47536814991214696)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(14508864895375041)
,p_validation_name=>'P100_OPENAI_API_KEY not null'
,p_validation_sequence=>40
,p_validation=>'P100_OPENAI_API_KEY'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_when_button_pressed=>wwv_flow_imp.id(14836858994424748)
,p_associated_item=>wwv_flow_imp.id(46567480196633702)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(14508050783375033)
,p_validation_name=>'P100_OCI_PRIVATE_KEY not null'
,p_validation_sequence=>50
,p_validation=>'P100_OCI_PRIVATE_KEY'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_validation_condition=>'P100_SHOW_WEB_CREDENTIALS'
,p_validation_condition2=>'Y'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(21770872189887453)
,p_associated_item=>wwv_flow_imp.id(46566101290632201)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(14508455160375037)
,p_validation_name=>'P100_OCI_TENANCY_ID not null'
,p_validation_sequence=>60
,p_validation=>'P100_OCI_TENANCY_ID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_validation_condition=>'P100_SHOW_WEB_CREDENTIALS'
,p_validation_condition2=>'Y'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(21770872189887453)
,p_associated_item=>wwv_flow_imp.id(46566204338632202)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(14508545572375038)
,p_validation_name=>'P100_OCI_FINGERPRINT not null'
,p_validation_sequence=>70
,p_validation=>'P100_OCI_FINGERPRINT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_validation_condition=>'P100_SHOW_WEB_CREDENTIALS'
,p_validation_condition2=>'Y'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(21770872189887453)
,p_associated_item=>wwv_flow_imp.id(46566329413632203)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(21839852193558462)
,p_name=>'Toggle Switch Visibility'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_SHOW_WEB_CREDENTIALS'
,p_condition_element=>'P100_SHOW_WEB_CREDENTIALS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Y'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21840290627558464)
,p_event_id=>wwv_flow_imp.id(21839852193558462)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39607175268708201)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21840719608558465)
,p_event_id=>wwv_flow_imp.id(21839852193558462)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39607175268708201)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17089523668838218)
,p_name=>'Change AI Provider'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_AI_PROVIDER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17089458085838217)
,p_event_id=>wwv_flow_imp.id(17089523668838218)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_app_setting.set_value(''AI_PROVIDER'', :P100_AI_PROVIDER);',
':CURRENT_AI_PROVIDER := :P100_AI_PROVIDER;'))
,p_attribute_02=>'P100_AI_PROVIDER'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14509288267375045)
,p_event_id=>wwv_flow_imp.id(17089523668838218)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_name=>'Hide OCI Web Credentials'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(21770559592887450)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14509520900375048)
,p_event_id=>wwv_flow_imp.id(17089523668838218)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_name=>'Hide OpenAI Web Credentials'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(21770654502887451)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14509669091375049)
,p_event_id=>wwv_flow_imp.id(17089523668838218)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_name=>'Hide Complete Button OCI'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(21770716045887452)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14836941891424749)
,p_event_id=>wwv_flow_imp.id(17089523668838218)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_name=>'Hide Complete Button OPENAI'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(14836719044424747)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14509470960375047)
,p_event_id=>wwv_flow_imp.id(17089523668838218)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_name=>'Show OCI Web Credentials'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(21770559592887450)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P100_AI_PROVIDER'
,p_client_condition_expression=>'OCI'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14509360679375046)
,p_event_id=>wwv_flow_imp.id(17089523668838218)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'Y'
,p_name=>'Show OpenAI Web Credentials'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(21770654502887451)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P100_AI_PROVIDER'
,p_client_condition_expression=>'OPENAI'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14509755533375050)
,p_event_id=>wwv_flow_imp.id(17089523668838218)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'Y'
,p_name=>'Show Complete Button OCI'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(21770716045887452)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P100_AI_PROVIDER'
,p_client_condition_expression=>'OCI'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14837039380424750)
,p_event_id=>wwv_flow_imp.id(17089523668838218)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'Y'
,p_name=>'Show Complete Button OpenAI'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(14836719044424747)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P100_AI_PROVIDER'
,p_client_condition_expression=>'OPENAI'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(21771143214887456)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Complete OCI'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_vector    vector;',
'    l_response  clob;',
'begin',
'     ',
'    apex_application_admin.set_remote_server(',
'        p_static_id              => ''EBA_GENAI_OCI'',',
'        p_base_url               => ''https://inference.generativeai.'' || :P100_OCI_REGION || ''.oci.oraclecloud.com'', ',
'        p_ai_model_name          => ''cohere.command-r-16k'',',
'        p_ai_attributes          => ''{"compartmentId":"'' || apex_escape.json(:P100_OCI_COMPARTMENT_ID) || ''","servingMode":{"modelId":"cohere.command-r-16k","servingType":"ON_DEMAND"}}'' ',
'    );',
'    apex_application_admin.set_remote_server(',
'        p_static_id              => ''EBA_VECTOR_OCI'',',
'        p_base_url               => ''https://inference.generativeai.'' || :P100_OCI_REGION || ''.oci.oraclecloud.com'', ',
'        p_ai_model_name          => ''cohere.embed-english-v3.0'',',
'        p_ai_attributes          => ''{"compartmentId":"'' || apex_escape.json(:P100_OCI_COMPARTMENT_ID) || ''","servingMode":{"modelId":"cohere.embed-english-v3.0","servingType":"ON_DEMAND"}}''',
'    );',
'    ',
'    ',
'    if :P100_SHOW_WEB_CREDENTIALS = ''Y'' then',
'        apex_credential.set_persistent_credentials (',
'            p_credential_static_id  =>  ''EBA_CREDENTIALS_OCI'',',
'            p_client_id             =>  :P100_OCI_USER_ID,',
'            p_client_secret         =>  :P100_OCI_PRIVATE_KEY,',
'            p_namespace             =>  :P100_OCI_TENANCY_ID,',
'            p_fingerprint           =>  :P100_OCI_FINGERPRINT',
'        );',
'',
'        :P100_OCI_PRIVATE_KEY := '' '';',
'    end if;',
'    ',
'',
'    -- Test AI Provider',
'    l_vector := apex_ai.get_vector_embeddings(',
'        p_value             => ''apex'',',
'        p_service_static_id => case when :CURRENT_AI_PROVIDER = ''OCI'' then ''EBA_VECTOR_OCI'' else ''EBA_VECTOR_OPENAI'' end',
'    );',
'',
'    l_response := apex_ai.generate(',
'        p_prompt            =>  ''apex'',',
'        p_system_prompt     =>  ''test'',',
'        p_service_static_id =>  case when :CURRENT_AI_PROVIDER = ''OCI'' then ''EBA_GENAI_OCI'' else ''EBA_GENAI_OPENAI'' end',
'    );',
'',
'',
'    -- To turn the switch off by default from now on, since the web credentials have been entered successfully.',
'    if :P100_SHOW_WEB_CREDENTIALS = ''Y'' then',
'        apex_app_setting.set_value(''WC_STATUS'', ''ENTERED'');',
'    end if;',
'',
'    -- To Complete Setup',
'    :INITIALIZED_AI_PROVIDER := ''YES'';',
'    apex_app_setting.set_value(''AI_PROVIDER_INITIALIZED'' ,''YES'');',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Invalid web credentials: #SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(21770872189887453)
,p_process_success_message=>'Success: Web credentials verified successfully.'
,p_internal_uid=>7713632804735014
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14837132247424751)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Complete Open AI'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_vector    vector;',
'    l_response  clob;',
'begin',
'     ',
'    apex_credential.set_persistent_credentials(',
'        p_credential_static_id   => ''EBA_CREDENTIALS_OPENAI'',',
'        p_key                    => ''Authorization'',',
'        p_value                  => ''Bearer '' || :P100_OPENAI_API_KEY );',
'    ',
'',
'',
'',
'    -- Test AI Provider',
'    l_vector := apex_ai.get_vector_embeddings(',
'        p_value             => ''apex'',',
'        p_service_static_id => case when :CURRENT_AI_PROVIDER = ''OCI'' then ''EBA_VECTOR_OCI'' else ''EBA_VECTOR_OPENAI'' end',
'    );',
'',
'    l_response := apex_ai.generate(',
'        p_prompt            =>  ''apex'',',
'        p_system_prompt     =>  ''test'',',
'        p_service_static_id =>  case when :CURRENT_AI_PROVIDER = ''OCI'' then ''EBA_GENAI_OCI'' else ''EBA_GENAI_OPENAI'' end',
'    );',
'',
'',
'',
'    ',
'    -- To Complete Setup',
'    :INITIALIZED_AI_PROVIDER := ''YES'';',
'    apex_app_setting.set_value(''AI_PROVIDER_INITIALIZED'' ,''YES'');',
'    ',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Invalid web credentials: #SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(14836858994424748)
,p_process_success_message=>'Success: Web credentials verified successfully.'
,p_internal_uid=>11528234420693128
);
wwv_flow_imp.component_end;
end;
/
