prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Prepare Movie Data'
,p_alias=>'PREPARE-MOVIE-DATA-1'
,p_page_mode=>'MODAL'
,p_step_title=>'Prepare Movie Data'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1024'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22282466764071002)
,p_plug_name=>'Progress'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayCurrentLabelOnly'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(14190948692845326)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2010149141494510257
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38097210988502918)
,p_plug_name=>'Data Generation'
,p_title=>'What kind of movie data should AI create for you?'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38097892114502925)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14568394528335985)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38097892114502925)
,p_button_name=>'GENERATE_DATA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Generate Data'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(14570159192335999)
,p_branch_name=>'Go To Data Preview'
,p_branch_action=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(14568394528335985)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34665337840655796)
,p_name=>'P11_EXE_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(38097210988502918)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38098379999502938)
,p_name=>'P11_PROMPT_INPUT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38097210988502918)
,p_prompt=>'Prompt Input'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'Y',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
,p_show_quick_picks=>'Y'
,p_quick_pick_label_01=>'Hollywood Movies'
,p_quick_pick_value_01=>'Generate data on the most successful Hollywood movies.'
,p_quick_pick_label_02=>'European Movies'
,p_quick_pick_value_02=>'Generate data on the most famous European movies.'
,p_quick_pick_label_03=>'Anime and Manga'
,p_quick_pick_value_03=>'Generate data on popular Asian anime and manga.'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(14194594206496968)
,p_validation_name=>'P11_PROMPT_INPUT not null'
,p_validation_sequence=>10
,p_validation=>'P11_PROMPT_INPUT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_when_button_pressed=>wwv_flow_imp.id(14568394528335985)
,p_associated_item=>wwv_flow_imp.id(38098379999502938)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14569310656335997)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Generate Sample Data'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'P11_EXE_ID'
,p_attribute_04=>'IGNORE'
,p_attribute_06=>'1'
,p_attribute_09=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(14568394528335985)
,p_internal_uid=>11260412829604374
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14568974290335994)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(14569310656335997)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Ask AI'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response          clob            := ''TITLE;MOVIEDESCRIPTION;ACTORS;GENRE;RELEASE_DATE;RATING'' || chr(10);',
'    l_genre_list        apex_t_varchar2 := apex_t_varchar2( ''Action'',''Comedy'',''Drama'',''Sci-Fi'',''Horror'',''Education'',''Western'', ''Crime'',''Mystery'',''Romance'' ); ',
'    l_prompt            varchar2( 32767 );',
'    l_exec              apex_background_process.t_execution;',
'    l_exec_id           number;',
'    l_current_ai_prov   varchar2( 20 )    := case when :CURRENT_AI_PROVIDER = ''OCI'' ',
'                                                 then ''EBA_GENAI_OCI''',
'                                                 else ''EBA_GENAI_OPENAI''',
'                                             end ;',
'',
'begin',
'    apex_background_process.set_progress( l_genre_list.count, 0);',
'',
'    for i in 1 .. l_genre_list.count loop',
'',
'        l_prompt := ''',
'        ### ROLE:',
'        You are a helpful assistant that provides concise and accurate responses in generating real Data on existing Movies in CSV Format. Exactly 5 lines in CSV format are needed. Return only the pure CSV content, and nothing else.',
'        The CSV content must adhere strictly to the following structure and format. You are a CSV generator that will always output the data in a schema, using the following columns:',
'        - Column 1: TITLE alphanumeric, up to 50 characters',
'        - Column 2: MOVIEDESCRIPTION alphanumeric, up to 2000 characters',
'        - Column 3: ACTORS Varchar2 space-separated list, up to 100 characters',
'        - Column 4: GENRE Varchar2 space-separated list, up to 25 characters - only generate Movies from the GENRE: '' || l_genre_list( i ) || ''!',
'        - Column 5: RELEASE_DATE Date, values between 1980-01-01 and 2024-12-31',
'        - Column 6: RATING Number(2,1), values between 1.0 and 5.0',
'',
'        ### EXAMPLE:',
'        "Movie-Title Placeholder";Description of the first Movie; Lisa Example, Robert Placeholder;'' || l_genre_list( i ) || '';1999-03-31;4.9',
'        "Movie-Title Placeholder";Description of the second Movie; Lisa Example, Robert Placeholder;'' || l_genre_list( i ) || '';1999-03-31;2.7',
'        ...',
'        "Movie-Title Placeholder";Description of the eight Movie; Lisa Example, Robert Placeholder;'' || l_genre_list( i ) || '';1999-03-31;3.0',
'        "Movie-Title Placeholder";Description of the ninth Movie; Lisa Example, Robert Placeholder;'' || l_genre_list( i ) || '';1999-03-31;3.9',
'',
'        ### GUARDRAILS:',
'        1.	Do not generate any information that deviates from the Rules provided.',
'        2.	If a user asks for additional or different information, always use the fixed format, never adding new columns or different data.',
'        3.	Avoid any assumptions about additional fields; limit the response strictly to the given format.',
'        4.  Ensure there are no extra line breaks between rows.',
'',
'',
'        ### RULES:',
'        1. Return data in "text" format.',
'        2. Each row must be separated by exactly one line break. No additional shifts, spaces, tabs, or other characters are allowed between rows.',
'        3. Complete Lines: Always write each line from start to finish, ensuring no incomplete or partial lines in the output.',
'        4. Data Format: Each subsequent line must follow the order of TITLE, DESCRIPTION, ACTORS, GENRE, RELEASE_DATE, and RATING.',
'        5. Consistency: Always use a semicolon (;) as the delimiter.',
'        '';',
'',
'        --',
'        -- GenAI Request',
'        --',
'        l_response :=   l_response',
'                      ',
'                     -- Replace multiple line breaks with a single line break after each AI response message',
'                     || rtrim(',
'',
'                            -- Replace multiple line breaks with a single line break within an AI response message',
'                            regexp_replace( ',
'                                ',
'                                apex_ai.generate(',
'                                    p_prompt            => :P11_PROMPT_INPUT,',
'                                    p_system_prompt     => l_prompt,',
'                                    p_service_static_id => l_current_ai_prov ),',
'',
'                                ''('' || chr(10) || ''){2,}'', chr(10) ),',
'',
'                            chr(10) )',
'                     || chr(10);',
'',
'        apex_background_process.set_progress( l_genre_list.count, i);                             ',
'',
'    end loop;',
'',
'    l_exec    := apex_background_process.get_current_execution;',
'    l_exec_id := l_exec.id;',
'    ',
'    insert into eba_vector_ai_helper (',
'        execution_id, ',
'        output',
'    ) values (',
'        l_exec_id, ',
'        l_response',
'    );',
'',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>11260076463604371
);
wwv_flow_imp.component_end;
end;
/
