prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Prepare Movie Data (Step 2: Preview)'
,p_alias=>'PREPARE-MOVIE-DATA-STEP-2'
,p_page_mode=>'MODAL'
,p_step_title=>'Prepare Movie Data'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'gInterval = window.setInterval( function() {apex.event.trigger( document, "updateProgress" ); }, 3700 );'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.csv {',
'   white-space: pre-line;',
'   font-family: monospace;',
'   font-size: 8pt;',
'   overflow-x: scroll; }'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32639107158105792)
,p_plug_name=>'Data Generated Successfully'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--defaultIcons:t-Alert--success'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>'<p>Your data has been successfully generated and is available to preview below. The next step is to upload this data into the datatable.</p>'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33173023509243007)
,p_plug_name=>'Progress'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayCurrentLabelOnly'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(14190948692845326)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2010149141494510257
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34668921069660517)
,p_plug_name=>'Generating Data...'
,p_region_name=>'progress'
,p_icon_css_classes=>'fa-refresh fa-anim-spin'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>'<p role="alert" id="status" class="u-tC">Data generation initiated.</p>'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40814205352681026)
,p_plug_name=>'Generated CSV'
,p_title=>'Generated Data Preview'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>50
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40814269386681027)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14573911687340709)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(40814269386681027)
,p_button_name=>'UPLOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Upload Data'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14574367277340709)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(40814269386681027)
,p_button_name=>'PREV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Back'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(14584036743340720)
,p_branch_name=>'Go To Vector Generation'
,p_branch_action=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:11,12::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(14573911687340709)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34671259649660526)
,p_name=>'P12_SOFAR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(40814205352681026)
,p_item_default=>'-1'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34671325090660527)
,p_name=>'P12_TOTALWORK'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(40814205352681026)
,p_item_default=>'-2'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40818182020681039)
,p_name=>'P12_AI_OUTPUT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(40814205352681026)
,p_prompt=>'AI Generated Data'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>12
,p_tag_css_classes=>'csv'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large:margin-bottom-sm'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'Y',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14576704386340712)
,p_name=>'Generation Running Update'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'updateProgress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14577226974340714)
,p_event_id=>wwv_flow_imp.id(14576704386340712)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Get Execution Progress'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_SOFAR,P12_TOTALWORK'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sofar, totalwork',
'  from apex_appl_page_bg_proc_status',
' where application_id = :APP_ID',
'   and execution_id = :P11_EXE_ID'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14577781429340715)
,p_event_id=>wwv_flow_imp.id(14576704386340712)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Show Execution Progress'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#status").text( apex.lang.formatMessage( "EBA_VECTOR.STATUS_UPDATE_AI_GENERATION", $v("P12_SOFAR"), $v("P12_TOTALWORK") ) );'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14578277480340716)
,p_event_id=>wwv_flow_imp.id(14576704386340712)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_name=>'Trigger "Finished" When All Done'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.event.trigger( document, "generationFinished" )'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'$v("P12_SOFAR") === $v("P12_TOTALWORK")'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14578684029340716)
,p_name=>'Toggle Text Field Visibility on Page Load'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14579116069340717)
,p_event_id=>wwv_flow_imp.id(14578684029340716)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(40814205352681026)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14579679132340717)
,p_event_id=>wwv_flow_imp.id(14578684029340716)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(40814269386681027)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14580176143340718)
,p_event_id=>wwv_flow_imp.id(14578684029340716)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(32639107158105792)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14580564340340718)
,p_name=>'Toggle Generation Finished Indicator'
,p_event_sequence=>40
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'generationFinished'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14581020687340718)
,p_event_id=>wwv_flow_imp.id(14580564340340718)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Stop the Refresh Timer'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.clearInterval( gInterval );'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14581583979340718)
,p_event_id=>wwv_flow_imp.id(14580564340340718)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Get the Generated Content'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_AI_OUTPUT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select output ',
'  from eba_vector_ai_helper',
' where execution_id = :P11_EXE_ID'))
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14582057462340719)
,p_event_id=>wwv_flow_imp.id(14580564340340718)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Show the Text Area with CSV '
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(40814205352681026)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14582551223340719)
,p_event_id=>wwv_flow_imp.id(14580564340340718)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_name=>'Show the Button Bar with CSV '
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(40814269386681027)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14583018624340719)
,p_event_id=>wwv_flow_imp.id(14580564340340718)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_name=>'Show the Success Text Area'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(32639107158105792)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14583545813340720)
,p_event_id=>wwv_flow_imp.id(14580564340340718)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_name=>'Hide the Execution Progress Text Area'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(34668921069660517)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14575331415340711)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Load Data'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(14573911687340709)
,p_internal_uid=>11266433588609088
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14574983600340710)
,p_process_sequence=>60
,p_parent_process_id=>wwv_flow_imp.id(14575331415340711)
,p_process_type=>'NATIVE_DATA_LOADING'
,p_process_name=>'Data Load'
,p_attribute_01=>wwv_flow_imp.id(26865649864699185)
,p_attribute_02=>'TEXT'
,p_attribute_04=>'P12_AI_OUTPUT'
,p_internal_uid=>11266085773609087
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14575701106340711)
,p_process_sequence=>80
,p_parent_process_id=>wwv_flow_imp.id(14575331415340711)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Clean Data'
,p_process_sql_clob=>'eba_sample_vector_search_pkg.delete_invalid_movie_data'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>11266803279609088
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14511031555375063)
,p_process_sequence=>90
,p_parent_process_id=>wwv_flow_imp.id(14575331415340711)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Clear Success Message'
,p_process_sql_clob=>'apex_application.g_print_success_message := null;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>11202133728643440
);
wwv_flow_imp.component_end;
end;
/
