prompt --application/pages/page_00054
begin
--   Manifest
--     PAGE: 00054
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>54
,p_name=>'Set AI Provider'
,p_alias=>'SET-AI-PROVIDER'
,p_step_title=>'Set AI Provider'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.step-container { max-width: 1168px; margin: 1.6rem auto }',
'.step-container .t-HeroRegion:not(.t-HeroRegion--featured) .t-HeroRegion-wrap { padding: 0 }',
'.t-Alert--info .t-Alert-icon { vertical-align: top }',
'.t-Alert--horizontal .t-Alert-title { line-height: 2.8rem }',
'.content-well { background: rgba(0, 0, 0, .05); border-radius: 2px; padding: 1.6rem }',
'.users-table .t-Report-report thead { display: none }',
'.users-table .t-Report-cell { padding: 0.8rem 0; font-size: 1.4rem; line-height: 1.5 }',
'.cta-button {padding: 16px 32px; font-size: 16px;}',
'.t-Card-info {',
'  margin-top: 0;',
'}',
'',
'.t-Card-desc {',
'  display: none;',
'}',
'',
'.t-Card-title {',
'  font-weight: 400;',
'}',
'.apex-item-yes-no {white-space:pre;}'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'Use this items on this page to configure the app.'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15189452908504083)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(26568570669740916)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33639146378659846)
,p_plug_name=>'Button OCI'
,p_static_id=>'button-oci'
,p_region_css_classes=>'step-container'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26705149377197141)
,p_plug_name=>'Button OPENAI'
,p_static_id=>'button-openai'
,p_region_css_classes=>'step-container'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33638989925659844)
,p_plug_name=>'Enter OCI Web Credentials'
,p_static_id=>'enter-oci-web-credentials'
,p_title=>'Enter Web Credentials'
,p_region_css_classes=>'step-container'
,p_icon_css_classes=>'fa-number-2'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info'
,p_plug_template=>2042159785845301134
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<p>Enter the OCI credentials you would like to use for this application.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33639084835659845)
,p_plug_name=>'Enter OpenAI Web Credentials'
,p_static_id=>'enter-openai-web-credentials'
,p_title=>'Enter Web Credentials'
,p_region_css_classes=>'step-container'
,p_icon_css_classes=>'fa-number-2'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info'
,p_plug_template=>2042159785845301134
,p_plug_display_sequence=>60
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<p>Enter the OpenAI API key you would like to use for this application.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33638874183659843)
,p_plug_name=>'Select Provider'
,p_static_id=>'select-provider'
,p_title=>'Select AI Provider'
,p_region_css_classes=>'step-container'
,p_icon_css_classes=>'fa-number-1'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info'
,p_plug_template=>2042159785845301134
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<p>Select an AI provider you want to use for generating data and creating vector embeddings.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(51475605601480595)
,p_plug_name=>'Web Credentials'
,p_static_id=>'web-credentials'
,p_parent_plug_id=>wwv_flow_imp.id(33638989925659844)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--hiddenOverflow'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15188932049504081)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(33639146378659846)
,p_button_name=>'COMPLETE_OCI'
,p_static_id=>'complete-oci'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CHANGE'
,p_button_css_classes=>'cta-button'
,p_icon_css_classes=>'fa-check-circle'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15177933232504052)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(26705149377197141)
,p_button_name=>'COMPLETE_OPENAI'
,p_static_id=>'complete-openai'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CHANGE'
,p_button_css_classes=>'cta-button'
,p_icon_css_classes=>'fa-check-circle'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(15201208139504111)
,p_branch_name=>'Go to Home Page'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'INITIALIZED_AI_PROVIDER'
,p_branch_condition_text=>'YES'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58402811483303711)
,p_name=>'P54_AI_PROVIDER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(33638874183659843)
,p_use_cache_before_default=>'NO'
,p_prompt=>'AI Provider'
,p_source=>'CURRENT_AI_PROVIDER'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:OCI Generative AI;OCI,Open AI;OPENAI'
,p_grid_label_column_span=>0
,p_field_template=>2042262243893469891
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59408243085987141)
,p_name=>'P54_OCI_COMPARTMENT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(33638989925659844)
,p_prompt=>'Compartment ID'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'The Oracle Cloud Infrastructure Compartment ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58439977837404652)
,p_name=>'P54_OCI_FINGERPRINT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(51475605601480595)
,p_prompt=>'OCI Public Key Fingerprint'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'<p>Enter the <em>public RSA key fingerprint</em> for OCI authentication. </p><p><a rel="noopener noreferrer" target="_blank" href="https://docs.cloud.oracle.com/iaas/Content/API/Concepts/apisigningkey.htm">Oracle Cloud Infrastructure Documentation</a'
||'></p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58439749714404650)
,p_name=>'P54_OCI_PRIVATE_KEY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(51475605601480595)
,p_prompt=>'OCI Private Key'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'<p>Enter the private key in PEM format for OCI authentication. &PRODUCT_NAME. stores this information encrypted and secure, so it cannot be retrieved back in clear text.</p><p><a rel="noopener noreferrer" target="_blank" href="https://docs.cloud.orac'
||'le.com/iaas/Content/API/Concepts/apisigningkey.htm">Oracle Cloud Infrastructure Documentation</a></p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59408168214987140)
,p_name=>'P54_OCI_REGION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(33638989925659844)
,p_item_default=>'us-chicago-1'
,p_prompt=>'Region'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'The Oracle Cloud Infrastructure Region. The default is us-chicago-1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_quick_pick_type=>'STATIC'
,p_quick_pick_label_01=>'US Midwest (Chicago)'
,p_quick_pick_value_01=>'us-chicago-1'
,p_quick_pick_label_02=>'US East (Ashburn)'
,p_quick_pick_value_02=>'us-ashburn-1'
,p_quick_pick_label_03=>'US West (Phoenix)'
,p_quick_pick_value_03=>'us-phoenix-1'
,p_quick_pick_label_04=>'Germany Central (Frankfurt)'
,p_quick_pick_value_04=>'eu-frankfurt-1'
,p_quick_pick_label_05=>'UK South (London)'
,p_quick_pick_value_05=>'uk-london-1'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58439852762404651)
,p_name=>'P54_OCI_TENANCY_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(51475605601480595)
,p_prompt=>'OCI Tenancy ID'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Enter the Oracle Cloud Infrastructure <em>Tenancy''s OCID</em>.</p>',
'<p><a rel="noopener noreferrer" target="_blank" href="https://docs.cloud.oracle.com/iaas/Content/API/Concepts/apisigningkey.htm">Oracle Cloud Infrastructure Documentation</a></p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58439673509404649)
,p_name=>'P54_OCI_USER_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(51475605601480595)
,p_prompt=>'OCI User ID'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#:margin-top-md'
,p_help_text=>'<p>Enter the Oracle Cloud Infrastructure <em>User OCID</em>. &PRODUCT_NAME. does not store this information encrypted.</p> <p><a rel="noopener noreferrer" target="_blank" href="https://docs.cloud.oracle.com/iaas/Content/API/Concepts/apisigningkey.htm'
||'">Oracle Cloud Infrastructure Documentation</a></p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51483257333480655)
,p_name=>'P54_OCI_WEB_CREDENTIALS_HEADER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(51475605601480595)
,p_prompt=>'Web Credential'
,p_source=>'OCI Credentials'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Denotes the name of the Web Credential which is used for accessing the <strong>OCI Generative AI</strong>. Navigate to <strong>Workspace Utilities</strong>, <strong>Web Credential</strong> to review existing Web Credentials.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58445549313406156)
,p_name=>'P54_OPENAI_API_KEY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(33639084835659845)
,p_prompt=>'OpenAI API Key'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>80
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Enter the <em>API Key</em> to authenticate against the AI Provider.</p>',
'<p>Example: "sk-pr..."</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40546451904772571)
,p_name=>'P54_OPENAI_WEB_CRED_HEADER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(33639084835659845)
,p_prompt=>'Web Credential'
,p_source=>'OpenAI Credentials'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Denotes the name of the Web Credential which is used for accessing the <strong>OpenAI Generative AI</strong>. Navigate to <strong>Workspace Utilities</strong>, <strong>Web Credential</strong> to review existing Web Credentials.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51478957933480648)
,p_name=>'P54_SHOW_WEB_CREDENTIALS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(33638989925659844)
,p_prompt=>'Edit Web Credentials'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(15192962804504100)
,p_validation_name=>'P54_OCI_COMPARTMENT_ID not null'
,p_static_id=>'p54-oci-compartment-id-not-null'
,p_validation_sequence=>20
,p_validation=>'P54_OCI_COMPARTMENT_ID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_when_button_pressed=>wwv_flow_imp.id(15188932049504081)
,p_associated_item=>wwv_flow_imp.id(59408243085987141)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(15192511410504100)
,p_validation_name=>'P54_OCI_FINGERPRINT not null'
,p_static_id=>'p54-oci-fingerprint-not-null'
,p_validation_sequence=>80
,p_validation=>'P54_OCI_FINGERPRINT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_validation_condition=>'P54_SHOW_WEB_CREDENTIALS'
,p_validation_condition2=>'Y'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(15188932049504081)
,p_associated_item=>wwv_flow_imp.id(58439977837404652)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(15191353488504099)
,p_validation_name=>'P54_OCI_PRIVATE_KEY not null'
,p_static_id=>'p54-oci-private-key-not-null'
,p_validation_sequence=>60
,p_validation=>'P54_OCI_PRIVATE_KEY'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_validation_condition=>'P54_SHOW_WEB_CREDENTIALS'
,p_validation_condition2=>'Y'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(15188932049504081)
,p_associated_item=>wwv_flow_imp.id(58439749714404650)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(15191773681504100)
,p_validation_name=>'P54_OCI_REGION not null'
,p_static_id=>'p54-oci-region-not-null'
,p_validation_sequence=>30
,p_validation=>'P54_OCI_REGION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_when_button_pressed=>wwv_flow_imp.id(15188932049504081)
,p_associated_item=>wwv_flow_imp.id(59408168214987140)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(15192177011504100)
,p_validation_name=>'P54_OCI_TENANCY_ID not null'
,p_static_id=>'p54-oci-tenancy-id-not-null'
,p_validation_sequence=>70
,p_validation=>'P54_OCI_TENANCY_ID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_validation_condition=>'P54_SHOW_WEB_CREDENTIALS'
,p_validation_condition2=>'Y'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(15188932049504081)
,p_associated_item=>wwv_flow_imp.id(58439852762404651)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(15190955860504099)
,p_validation_name=>'P54_OCI_USER_ID not null'
,p_static_id=>'p54-oci-user-id-not-null'
,p_validation_sequence=>40
,p_validation=>'P54_OCI_USER_ID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_validation_condition=>'P54_SHOW_WEB_CREDENTIALS'
,p_validation_condition2=>'Y'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(15188932049504081)
,p_associated_item=>wwv_flow_imp.id(58439673509404649)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(15193332543504101)
,p_validation_name=>'P54_OPENAI_API_KEY not null'
,p_static_id=>'p54-openai-api-key-not-null'
,p_validation_sequence=>50
,p_validation=>'P54_OPENAI_API_KEY'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have a value.'
,p_when_button_pressed=>wwv_flow_imp.id(15177933232504052)
,p_associated_item=>wwv_flow_imp.id(58445549313406156)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15196296129504107)
,p_name=>'Change AI Provider'
,p_static_id=>'change-ai-provider'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P54_AI_PROVIDER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15200216334504109)
,p_event_id=>wwv_flow_imp.id(15196296129504107)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_name=>'Hide Complete Button OCI'
,p_static_id=>'hide-complete-button-oci'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33639146378659846)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15196697895504107)
,p_event_id=>wwv_flow_imp.id(15196296129504107)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_name=>'Hide Complete Button OPENAI'
,p_static_id=>'hide-complete-button-openai'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(26705149377197141)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15199727448504109)
,p_event_id=>wwv_flow_imp.id(15196296129504107)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_name=>'Hide OCI Web Credentials'
,p_static_id=>'hide-oci-web-credentials'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33638989925659844)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15199241408504109)
,p_event_id=>wwv_flow_imp.id(15196296129504107)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_name=>'Hide OpenAI Web Credentials'
,p_static_id=>'hide-openai-web-credentials'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33639084835659845)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15198219005504108)
,p_event_id=>wwv_flow_imp.id(15196296129504107)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-execute-plsql-code'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'items_to_submit', 'P54_AI_PROVIDER',
  'language', 'PLSQL',
  'plsql_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'apex_app_setting.set_value(''AI_PROVIDER'', :P54_AI_PROVIDER);',
    ':CURRENT_AI_PROVIDER := :P54_AI_PROVIDER;')),
  'show_processing', 'N')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15200750794504110)
,p_event_id=>wwv_flow_imp.id(15196296129504107)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'Y'
,p_name=>'Show Complete Button OCI'
,p_static_id=>'show-complete-button-oci'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33639146378659846)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P54_AI_PROVIDER'
,p_client_condition_expression=>'OCI'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15197275277504107)
,p_event_id=>wwv_flow_imp.id(15196296129504107)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'Y'
,p_name=>'Show Complete Button OpenAI'
,p_static_id=>'show-complete-button-openai'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(26705149377197141)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P54_AI_PROVIDER'
,p_client_condition_expression=>'OPENAI'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15198744368504109)
,p_event_id=>wwv_flow_imp.id(15196296129504107)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_name=>'Show OCI Web Credentials'
,p_static_id=>'show-oci-web-credentials'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33638989925659844)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P54_AI_PROVIDER'
,p_client_condition_expression=>'OCI'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15197778618504108)
,p_event_id=>wwv_flow_imp.id(15196296129504107)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'Y'
,p_name=>'Show OpenAI Web Credentials'
,p_static_id=>'show-openai-web-credentials'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33639084835659845)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P54_AI_PROVIDER'
,p_client_condition_expression=>'OPENAI'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15194872093504104)
,p_name=>'Toggle Switch Visibility'
,p_static_id=>'toggle-switch-visibility'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P54_SHOW_WEB_CREDENTIALS'
,p_condition_element=>'P54_SHOW_WEB_CREDENTIALS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Y'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15195855846504106)
,p_event_id=>wwv_flow_imp.id(15194872093504104)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(51475605601480595)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15195391747504106)
,p_event_id=>wwv_flow_imp.id(15194872093504104)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(51475605601480595)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14607965374680021)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Clear Data OCI'
,p_static_id=>'clear-data-oci'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from eba_vector_moviedata;',
'delete from eba_vector_datatable;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(15188932049504081)
,p_internal_uid=>11528594944693131
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14608099313680022)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Clear Data Open AI'
,p_static_id=>'clear-data-open-ai'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from eba_vector_moviedata;',
'delete from eba_vector_datatable;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(15177933232504052)
,p_internal_uid=>11528461005693130
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15194041126504102)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Complete OCI'
,p_static_id=>'complete-oci'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_vector    vector;',
'    l_response  clob;',
'begin',
'     ',
'    apex_application_admin.set_remote_server(',
'        p_static_id              => ''EBA_GENAI_OCI'',',
'        p_base_url               => ''https://inference.generativeai.'' || :P54_OCI_REGION || ''.oci.oraclecloud.com'', ',
'        p_ai_model_name          => ''cohere.command-r-08-2024'',',
'        p_ai_attributes          => ''{"compartmentId":"'' || apex_escape.json(:P54_OCI_COMPARTMENT_ID) || ''","servingMode":{"modelId":"cohere.command-r-08-2024","servingType":"ON_DEMAND"}}'' ',
'    );',
'    apex_application_admin.set_remote_server(',
'        p_static_id              => ''EBA_VECTOR_OCI'',',
'        p_base_url               => ''https://inference.generativeai.'' || :P54_OCI_REGION || ''.oci.oraclecloud.com'', ',
'        p_ai_model_name          => ''cohere.embed-english-v3.0'',',
'        p_ai_attributes          => ''{"compartmentId":"'' || apex_escape.json(:P54_OCI_COMPARTMENT_ID) || ''","servingMode":{"modelId":"cohere.embed-english-v3.0","servingType":"ON_DEMAND"}}''',
'    );',
'    ',
'    if :P54_SHOW_WEB_CREDENTIALS = ''Y'' then',
'        apex_credential.set_persistent_credentials (',
'            p_credential_static_id  =>  ''EBA_CREDENTIALS_OCI'',',
'            p_client_id             =>  :P54_OCI_USER_ID,',
'            p_client_secret         =>  :P54_OCI_PRIVATE_KEY,',
'            p_namespace             =>  :P54_OCI_TENANCY_ID,',
'            p_fingerprint           =>  :P54_OCI_FINGERPRINT',
'        );',
'',
'        :P54_OCI_PRIVATE_KEY := '' '';',
'    end if;',
'    ',
'',
'    -- Test AI Provider',
'    l_vector := apex_ai.get_vector_embeddings(',
'        p_value             => ''apex'',',
'        p_service_static_id => case when :CURRENT_AI_PROVIDER = ''OCI'' then ''EBA_VECTOR_OCI'' else ''EBA_VECTOR_OPENAI'' end',
'    );',
'',
'    l_response := apex_ai.generate(',
'        p_prompt            =>  ''apex'',',
'        p_system_prompt     =>  ''test'',',
'        p_service_static_id =>  case when :CURRENT_AI_PROVIDER = ''OCI'' then ''EBA_GENAI_OCI'' else ''EBA_GENAI_OPENAI'' end',
'    );',
'    ',
'    -- To turn the switch off by default from now on, since the web credentials have been entered successfully.',
'    if :P100_SHOW_WEB_CREDENTIALS = ''Y'' then',
'        apex_app_setting.set_value(''WC_STATUS'', ''ENTERED'');',
'    end if;',
'',
'    -- To Complete Setup',
'    :INITIALIZED_AI_PROVIDER := ''YES'';',
'    apex_app_setting.set_value(''AI_PROVIDER_INITIALIZED'' ,''YES'');    ',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Invalid web credentials: #SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(15188932049504081)
,p_process_success_message=>'Success: Web credentials verified successfully.'
,p_internal_uid=>11885143299772479
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15193695525504101)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Complete Open AI'
,p_static_id=>'complete-open-ai'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_vector    vector;',
'    l_response  clob;',
'begin',
'     ',
'    apex_credential.set_persistent_credentials(',
'        p_credential_static_id   => ''EBA_CREDENTIALS_OPENAI'',',
'        p_key                    => ''Authorization'',',
'        p_value                  => ''Bearer '' || :P54_OPENAI_API_KEY );',
'    ',
'',
'',
'',
'    -- Test AI Provider',
'    l_vector := apex_ai.get_vector_embeddings(',
'        p_value             => ''apex'',',
'        p_service_static_id => case when :CURRENT_AI_PROVIDER = ''OCI'' then ''EBA_VECTOR_OCI'' else ''EBA_VECTOR_OPENAI'' end',
'    );',
'',
'    l_response := apex_ai.generate(',
'        p_prompt            =>  ''apex'',',
'        p_system_prompt     =>  ''test'',',
'        p_service_static_id =>  case when :CURRENT_AI_PROVIDER = ''OCI'' then ''EBA_GENAI_OCI'' else ''EBA_GENAI_OPENAI'' end',
'    );',
'',
'',
'    ',
'    -- To Complete Setup',
'    :INITIALIZED_AI_PROVIDER := ''YES'';',
'    apex_app_setting.set_value(''AI_PROVIDER_INITIALIZED'' ,''YES'');',
'    ',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Invalid web credentials: #SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(15177933232504052)
,p_process_success_message=>'Success: Web credentials verified successfully.'
,p_internal_uid=>11884797698772478
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14607868140680020)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Items'
,p_static_id=>'set-items'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if apex_app_setting.get_value(''WC_STATUS'') = ''ENTERED'' then',
'        :P54_SHOW_WEB_CREDENTIALS := ''N'';',
'    else',
'        :P54_SHOW_WEB_CREDENTIALS := ''Y'';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>11528692178693132
);
wwv_flow_imp.component_end;
end;
/
