prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>15
,p_name=>'Basic Vector Search'
,p_alias=>'BASIC-VECTOR-SEARCH1'
,p_step_title=>'Basic Vector Search'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'26'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33055233406586716)
,p_plug_name=>'About Basic Vector Search'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This example performs a vector search on the <em>TITLE</em>, <em>MOVIEDESCRIPTION</em>, and <em>ACTORS</em> columns and returns movies that are similar to your search terms.</p>',
'',
'<p>Vector search leverages <strong>context aware embeddings</strong> to identify similar results beyond simple keyword matching. This results in more accurate and meaningful results.</p>',
'',
'<p>Note that performing a vector search will always yield results, regardless of the quality of the match. The best matches will be displayed at the top of the resultset.</p>',
'',
'<p>To search, start typing your query, and the results will be displayed immediately. Here are a few example search terms to get started:</p>',
'',
'<ul>',
'    <li>Subconscious Mind</li>',
'    <li>Darth Vader</li>',
'    <li>Superheroes</li>',
'</ul>'))
,p_landmark_type=>'complementary'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33055346574586717)
,p_plug_name=>'Content'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33055474593586718)
,p_plug_name=>'Search'
,p_parent_plug_id=>wwv_flow_imp.id(33055346574586717)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_landmark_type=>'search'
,p_landmark_label=>'Basic Vector'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38126732829597867)
,p_plug_name=>'Search Results OCI'
,p_parent_plug_id=>wwv_flow_imp.id(33055346574586717)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1555738898046108210
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'CURRENT_AI_PROVIDER'
,p_plug_display_when_cond2=>'OCI'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'custom_layout', 'N',
  'lazy_loading', 'Y',
  'minimum_characters', '0',
  'no_query_entered_message', 'Please enter a search term.',
  'no_results_found_message', 'No results found.',
  'results_per_page', '15',
  'results_per_page_type', 'STATIC',
  'search_as_you_type', 'Y',
  'search_page_item', 'P15_SEARCH',
  'show_result_count', 'N',
  'use_pagination', 'Y')).to_clob
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(14594193404430880)
,p_region_id=>wwv_flow_imp.id(38126732829597867)
,p_search_config_id=>wwv_flow_imp.id(26879557964827740)
,p_use_as_initial_result=>false
,p_display_sequence=>10
,p_name=>'Basic Vector Search OCI'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43125422376089354)
,p_plug_name=>'Search Results OPENAI'
,p_parent_plug_id=>wwv_flow_imp.id(33055346574586717)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1555738898046108210
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'CURRENT_AI_PROVIDER'
,p_plug_display_when_cond2=>'OPENAI'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'custom_layout', 'N',
  'lazy_loading', 'Y',
  'minimum_characters', '0',
  'no_query_entered_message', 'Please enter a search term.',
  'no_results_found_message', 'No results found.',
  'results_per_page', '15',
  'results_per_page_type', 'STATIC',
  'search_as_you_type', 'Y',
  'search_page_item', 'P15_SEARCH',
  'show_result_count', 'N',
  'use_pagination', 'Y')).to_clob
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(14595052793430880)
,p_region_id=>wwv_flow_imp.id(43125422376089354)
,p_search_config_id=>wwv_flow_imp.id(32205139326725138)
,p_use_as_initial_result=>false
,p_display_sequence=>10
,p_name=>'Basic Vector Search OPENAI'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(60678821071162837)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(26568570669740916)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38127809386597867)
,p_name=>'P15_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(33055474593586718)
,p_prompt=>'Search'
,p_placeholder=>'Enter your search term, e.g. Subconscious Mind or Darth Vader'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>2040785906935475274
,p_item_css_classes=>'mxw800 t-Form-fieldContainer--noPadding'
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'send_on_page_submit', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp.component_end;
end;
/
