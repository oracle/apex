prompt --application/pages/page_00026
begin
--   Manifest
--     PAGE: 00026
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>26
,p_name=>'Prepare Custom Data (Step 2: Upload Data)'
,p_alias=>'PREPARE-CUSTOM-DATA-2'
,p_page_mode=>'MODAL'
,p_step_title=>'Prepare Custom Data'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>'.t-Report-colHead {white-space: nowrap }'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21911973181641905)
,p_plug_name=>'Progress'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayCurrentLabelOnly'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(14193624344893271)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2010149141494510257
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37797973635988355)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37798012258988356)
,p_plug_name=>'Upload File'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37798981850988365)
,p_plug_name=>'Loaded File'
,p_parent_plug_id=>wwv_flow_imp.id(37798012258988356)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P25_FILE'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(38656586767560102)
,p_name=>'Preview'
,p_parent_plug_id=>wwv_flow_imp.id(37798012258988356)
,p_template=>4072358936313175081
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--horizontalBorders:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select col001 as TITLE,',
'       col002 as SUBTITLE,',
'       col003 as DESCRIPTION,',
'       col004 as COL4,',
'       col005 as COL5,',
'       col006 as COL6,',
'       col007 as COL7,',
'       col008 as COL8,',
'       col009 as COL9,',
'       col010 as COL10',
'  from apex_application_temp_files f, ',
'       TABLE( apex_data_parser.parse(',
'                  p_content          => f.blob_content,',
'                  p_file_name        => f.filename,',
'                  p_add_headers_row  => ''Y'',',
'                  p_csv_enclosed     => ''"'',',
'                  p_file_charset     => ''WE8ISO8859P1'',',
'                  p_max_rows         => 10 )',
'            ) p',
' where f.name = :P25_FILE',
'   and p.line_number > 1;'))
,p_display_when_condition=>'P25_FILE'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14510619842375059)
,p_query_column_id=>1
,p_column_alias=>'TITLE'
,p_column_display_sequence=>10
,p_column_heading=>'Title'
,p_use_as_row_header=>'Y'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14510908948375062)
,p_query_column_id=>2
,p_column_alias=>'SUBTITLE'
,p_column_display_sequence=>20
,p_column_heading=>'Subtitle'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14510881185375061)
,p_query_column_id=>3
,p_column_alias=>'DESCRIPTION'
,p_column_display_sequence=>30
,p_column_heading=>'Description'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27750809117106043)
,p_query_column_id=>4
,p_column_alias=>'COL4'
,p_column_display_sequence=>40
,p_column_heading=>'Column 4'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27751238748106044)
,p_query_column_id=>5
,p_column_alias=>'COL5'
,p_column_display_sequence=>50
,p_column_heading=>'Column 5'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27751657632106044)
,p_query_column_id=>6
,p_column_alias=>'COL6'
,p_column_display_sequence=>60
,p_column_heading=>'Column 6'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27752024984106044)
,p_query_column_id=>7
,p_column_alias=>'COL7'
,p_column_display_sequence=>70
,p_column_heading=>'Column 7'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27752466792106044)
,p_query_column_id=>8
,p_column_alias=>'COL8'
,p_column_display_sequence=>80
,p_column_heading=>'Column 8'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27752856862106045)
,p_query_column_id=>9
,p_column_alias=>'COL9'
,p_column_display_sequence=>90
,p_column_heading=>'Column 9'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(27753267838106045)
,p_query_column_id=>10
,p_column_alias=>'COL10'
,p_column_display_sequence=>100
,p_column_heading=>'Column 10'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39807535890677615)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27754092685106046)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(39807535890677615)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Load Data'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(27688085497837174)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(39807535890677615)
,p_button_name=>'PREV'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Back'
,p_button_position=>'PREVIOUS'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(27768793086487794)
,p_branch_name=>'Go Back To File Upload'
,p_branch_action=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(27688085497837174)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28662661892419690)
,p_branch_name=>'Go To File Vector Embeddings'
,p_branch_action=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(27754092685106046)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37808285505988413)
,p_name=>'P26_FILE_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(37798981850988365)
,p_item_default=>'''EBA_VECTOR_DATATABLE'''
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(27754718490106046)
,p_computation_sequence=>10
,p_computation_item=>'P26_FILE_NAME'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select filename',
'  from apex_application_temp_files ',
' where name = :P25_FILE;'))
,p_compute_when=>':P25_FILE is not null and :REQUEST = ''LOAD_FILE'''
,p_compute_when_text=>'PLSQL'
,p_compute_when_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28699339955689196)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Upload Sample Data'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(27754092685106046)
,p_internal_uid=>3692637774827129
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28700621602696679)
,p_process_sequence=>80
,p_parent_process_id=>wwv_flow_imp.id(28699339955689196)
,p_process_type=>'NATIVE_DATA_LOADING'
,p_process_name=>'Load File Data'
,p_attribute_01=>wwv_flow_imp.id(26872215558699189)
,p_attribute_02=>'FILE'
,p_attribute_03=>'P25_FILE'
,p_internal_uid=>3693919421834612
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27755480462106047)
,p_process_sequence=>90
,p_parent_process_id=>wwv_flow_imp.id(28699339955689196)
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear File Cache'
,p_attribute_01=>'CLEAR_CACHE_FOR_PAGES'
,p_attribute_04=>'25,26'
,p_internal_uid=>2748778281243980
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14511256575375065)
,p_process_sequence=>100
,p_parent_process_id=>wwv_flow_imp.id(28699339955689196)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Clear Success Message'
,p_process_sql_clob=>'apex_application.g_print_success_message := null;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>11202358748643442
);
wwv_flow_imp.component_end;
end;
/
