prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_name=>'Prepare Movie Data (Step 4: Overview)'
,p_alias=>'PREPARE-MOVIE-DATA-4'
,p_page_mode=>'MODAL'
,p_step_title=>'Prepare Movie Data'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'06'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38162426588792420)
,p_plug_name=>'Movie Vector Search Navigation'
,p_static_id=>'movie-vector-search-navigation'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-MediaList--showBadges'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(26891210267974065)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2069471208528591807
,p_landmark_label=>'Movie Vector Search'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(48038482978707646)
,p_plug_name=>'Progress'
,p_static_id=>'progress'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayCurrentLabelOnly'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(14190948692845326)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2011625478452504874
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38162359480793925)
,p_plug_name=>'Ready for Vector Search'
,p_static_id=>'ready-for-vector-search'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--defaultIcons:t-Alert--success'
,p_plug_template=>2042159785845301134
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Vector embeddings for your data have been generated! You can now perform vector searches on your data.</p>',
'<p>Select a vector search example below to get started.</p>'))
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from eba_vector_moviedata where embedding_vector is not null and rownum = 1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
