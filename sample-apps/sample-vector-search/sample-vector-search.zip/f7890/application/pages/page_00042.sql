prompt --application/pages/page_00042
begin
--   Manifest
--     PAGE: 00042
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>42
,p_name=>'Mixed Languages'
,p_alias=>'MIXED-LANGUAGES'
,p_step_title=>'Mixed Languages'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'26'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26856399650041913)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(26568570669740916)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30645238262805830)
,p_plug_name=>'Content'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27122217795811373)
,p_plug_name=>'Search Results OCI'
,p_parent_plug_id=>wwv_flow_imp.id(30645238262805830)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1555738898046108210
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_ajax_items_to_submit=>'P42_SEARCH'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'CURRENT_AI_PROVIDER'
,p_plug_display_when_cond2=>'OCI'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'custom_layout', 'N',
  'lazy_loading', 'Y',
  'minimum_characters', '0',
  'no_query_entered_message', 'Please enter a search term.',
  'no_results_found_message', 'No results found.',
  'results_per_page', '15',
  'results_per_page_type', 'STATIC',
  'search_as_you_type', 'Y',
  'search_page_item', 'P42_SEARCH',
  'show_result_count', 'N',
  'use_pagination', 'Y')).to_clob
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(27122316953811374)
,p_region_id=>wwv_flow_imp.id(27122217795811373)
,p_search_config_id=>wwv_flow_imp.id(26879557964827740)
,p_use_as_initial_result=>false
,p_display_sequence=>10
,p_name=>'Vector Comparison'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30644571663795758)
,p_plug_name=>'Search'
,p_parent_plug_id=>wwv_flow_imp.id(30645238262805830)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_landmark_type=>'search'
,p_landmark_label=>'Mixed Languages'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31843226561390113)
,p_plug_name=>'Search Results OPENAI'
,p_parent_plug_id=>wwv_flow_imp.id(30645238262805830)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1555738898046108210
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_ajax_items_to_submit=>'P42_SEARCH'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'CURRENT_AI_PROVIDER'
,p_plug_display_when_cond2=>'OPENAI'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'custom_layout', 'N',
  'lazy_loading', 'Y',
  'minimum_characters', '0',
  'no_query_entered_message', 'Please enter a search term.',
  'no_results_found_message', 'No results found.',
  'results_per_page', '15',
  'results_per_page_type', 'STATIC',
  'search_as_you_type', 'Y',
  'search_page_item', 'P42_SEARCH',
  'show_result_count', 'N',
  'use_pagination', 'Y')).to_clob
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(31843383893390114)
,p_region_id=>wwv_flow_imp.id(31843226561390113)
,p_search_config_id=>wwv_flow_imp.id(32205139326725138)
,p_use_as_initial_result=>false
,p_display_sequence=>10
,p_name=>'Vector Comparison'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30647332777816884)
,p_plug_name=>'About Mixed Languages'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Each language yields unique results, as it connects to different attributes or contexts, enhancing the diversity and relevance of search outcomes.</p>',
'',
unistr('<p>The system leverages vector embeddings to identify semantically similar results across multiple languages, even if the query combines different languages (e.g., <strong><span lang="zh-Hans">\592A\7A7A</span> and Star Wars</strong>).</p>'),
'',
'<p>Note that performing a vector search will always yield results, regardless of the quality of the match. The best matches will be displayed at the top of the resultset.</p>',
'',
'<p>To search, start typing your query, and the results will be displayed immediately. ',
'    Try out the Arabic, Mandarin, German, or French term for "Space":</p>',
'',
'<ul>',
unistr('    <li><span lang="ar">\0627\0644\0641\0636\0627\0621</span></li>'),
unistr('    <li><span lang="zh-Hans">\592A\7A7A</span></li>'),
'    <li><span lang="de">Weltraum</span></li>',
'    <li><span lang="fr">espace</span></li>',
'</ul>'))
,p_landmark_type=>'complementary'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27122188783811372)
,p_name=>'P42_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(30644571663795758)
,p_prompt=>'Search'
,p_placeholder=>'Enter your search term'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>2040785906935475274
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'send_on_page_submit', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp.component_end;
end;
/
