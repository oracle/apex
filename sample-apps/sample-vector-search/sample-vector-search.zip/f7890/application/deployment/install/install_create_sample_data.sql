prompt --application/deployment/install/install_create_sample_data
begin
--   Manifest
--     INSTALL: INSTALL-create sample data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '----------------------------------------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '---'||wwv_flow.LF||
'-- Create Sample Dataset'||wwv_flow.LF||
'-----------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(3) := '--------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_vector_datatable ('||wwv_flow.LF||
'    id               number ge';
wwv_flow_imp.g_varchar2_table(4) := 'nerated by default as identity primary key,'||wwv_flow.LF||
'    col1             varchar(255),'||wwv_flow.LF||
'    col2             ';
wwv_flow_imp.g_varchar2_table(5) := 'varchar(255),'||wwv_flow.LF||
'    col3             varchar(255),'||wwv_flow.LF||
'    col4             varchar(255),'||wwv_flow.LF||
'    col5        ';
wwv_flow_imp.g_varchar2_table(6) := '     varchar(255),'||wwv_flow.LF||
'    col6             varchar(255),'||wwv_flow.LF||
'    col7             varchar(255),'||wwv_flow.LF||
'    col8   ';
wwv_flow_imp.g_varchar2_table(7) := '          varchar(255),'||wwv_flow.LF||
'    col9             varchar(255),'||wwv_flow.LF||
'    col10            varchar(255),'||wwv_flow.LF||
'    em';
wwv_flow_imp.g_varchar2_table(8) := 'bedding_vector vector )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_vector_moviedata ('||wwv_flow.LF||
'    id               number generated';
wwv_flow_imp.g_varchar2_table(9) := ' by default as identity primary key,'||wwv_flow.LF||
'    title            varchar2(255),'||wwv_flow.LF||
'    moviedescription varcha';
wwv_flow_imp.g_varchar2_table(10) := 'r2(4000),'||wwv_flow.LF||
'    actors           varchar2(1000),'||wwv_flow.LF||
'    genre            varchar2(255),'||wwv_flow.LF||
'    release_date ';
wwv_flow_imp.g_varchar2_table(11) := '    date,'||wwv_flow.LF||
'    rating           number,'||wwv_flow.LF||
'    embedding_vector vector )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_vector_ai_h';
wwv_flow_imp.g_varchar2_table(12) := 'elper ('||wwv_flow.LF||
'    execution_id     number primary key,'||wwv_flow.LF||
'    output           clob )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------';
wwv_flow_imp.g_varchar2_table(13) := '------------------------------------------------------------------------------------'||wwv_flow.LF||
'-- Create Oracl';
wwv_flow_imp.g_varchar2_table(14) := 'e Text Index for the movie data (AI generated data) table.'||wwv_flow.LF||
'-----------------------------------------';
wwv_flow_imp.g_varchar2_table(15) := '--------------------------------------------------------------'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    execute immediate ''drop ind';
wwv_flow_imp.g_varchar2_table(16) := 'ex if exists eba_vector_moviedata_desc_ftx force'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    execute immediate ''begin ctxsys.ctx_ddl.drop';
wwv_flow_imp.g_varchar2_table(17) := '_preference( ''''eba_vector_ds'''' ); exception when others then null; end;'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    execute immediate    ';
wwv_flow_imp.g_varchar2_table(18) := '''begin '''||wwv_flow.LF||
'                      || ''ctxsys.ctx_ddl.create_preference( ''''eba_vector_ds'''', ''''MULTI_COLU';
wwv_flow_imp.g_varchar2_table(19) := 'MN_DATASTORE'''');'''||wwv_flow.LF||
'                      || ''ctxsys.ctx_ddl.set_attribute( ''''eba_vector_ds'''', ''''COLUM';
wwv_flow_imp.g_varchar2_table(20) := 'NS'''', ''''TITLE,MOVIEDESCRIPTION,ACTORS'''' );'''||wwv_flow.LF||
'                      || ''end;'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    execute immediate ';
wwv_flow_imp.g_varchar2_table(21) := '   ''create index eba_vector_moviedata_desc_ftx on eba_vector_moviedata (moviedescription)'''||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(22) := '             || ''indextype is ctxsys.context '''||wwv_flow.LF||
'                      || ''parameters (''''datastore eba';
wwv_flow_imp.g_varchar2_table(23) := '_vector_ds sync (on commit) memory 500M'''')'';'||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        -- Oracle TEXT i';
wwv_flow_imp.g_varchar2_table(24) := 's not available. Ignore the error.'||wwv_flow.LF||
'        null;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------------------------------';
wwv_flow_imp.g_varchar2_table(25) := '------------------------------------------------------------'||wwv_flow.LF||
'-- Create Oracle Text Index for the "da';
wwv_flow_imp.g_varchar2_table(26) := 'ta" (manually uploaded data) table.'||wwv_flow.LF||
'----------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(27) := '---------------------------------------'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    execute immediate ''drop index if exists eba_vector';
wwv_flow_imp.g_varchar2_table(28) := '_datatable_desc_ftx force'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    execute immediate ''begin ctx_ddl.drop_preference( ''''eba_vector_2_ds';
wwv_flow_imp.g_varchar2_table(29) := ''''' ); exception when others then null; end;'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    execute immediate    ''begin '''||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(30) := '   || ''ctxsys.ctx_ddl.create_preference( ''''eba_vector_2_ds'''', ''''MULTI_COLUMN_DATASTORE'''');'''||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(31) := '              || ''ctxsys.ctx_ddl.set_attribute( ''''eba_vector_2_ds'''', ''''COLUMNS'''', ''''col1,col2,col3,c';
wwv_flow_imp.g_varchar2_table(32) := 'ol4,col5,col6,col7,col8,col9,col10'''' );'''||wwv_flow.LF||
'                      || ''end;'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    execute immediate    ';
wwv_flow_imp.g_varchar2_table(33) := '''create index eba_vector_datatable_desc_ftx on eba_vector_datatable (col1)'''||wwv_flow.LF||
'                      ||';
wwv_flow_imp.g_varchar2_table(34) := ' ''indextype is ctxsys.context '''||wwv_flow.LF||
'                      || ''parameters (''''datastore eba_vector_2_ds sy';
wwv_flow_imp.g_varchar2_table(35) := 'nc (on commit) memory 500M'''')'';'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        -- Oracle TEXT is not availa';
wwv_flow_imp.g_varchar2_table(36) := 'ble. Ignore the error.'||wwv_flow.LF||
'        null;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(37) := '------------------------------------------------'||wwv_flow.LF||
'-- Add Sample Data'||wwv_flow.LF||
'--------------------------------';
wwv_flow_imp.g_varchar2_table(38) := '-----------------------------------------------------------------------'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- Star Wars movie';
wwv_flow_imp.g_varchar2_table(39) := ' data'||wwv_flow.LF||
'    insert into eba_vector_moviedata ('||wwv_flow.LF||
'        title,'||wwv_flow.LF||
'        moviedescription,'||wwv_flow.LF||
'        actors';
wwv_flow_imp.g_varchar2_table(40) := ','||wwv_flow.LF||
'        genre,'||wwv_flow.LF||
'        release_date,'||wwv_flow.LF||
'        rating )'||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        ''Star Wars: A New Hope''';
wwv_flow_imp.g_varchar2_table(41) := ','||wwv_flow.LF||
'        ''A farm boy joins a rebellion against a tyrannical empire and discovers the power of the F';
wwv_flow_imp.g_varchar2_table(42) := 'orce'','||wwv_flow.LF||
'        ''Mark Hamill Carrie Fisher Harrison Ford'','||wwv_flow.LF||
'        ''Sci-Fi'','||wwv_flow.LF||
'        to_date(''1977-05';
wwv_flow_imp.g_varchar2_table(43) := '-25'', ''YYYY-MM-DD''),'||wwv_flow.LF||
'        4.7 );'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into eba_vector_moviedata ('||wwv_flow.LF||
'        title,'||wwv_flow.LF||
'        m';
wwv_flow_imp.g_varchar2_table(44) := 'oviedescription,'||wwv_flow.LF||
'        actors,'||wwv_flow.LF||
'        genre,'||wwv_flow.LF||
'        release_date,'||wwv_flow.LF||
'        rating )'||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(45) := '        ''Star Wars: The Empire Strikes Back'','||wwv_flow.LF||
'        ''The Rebel Alliance battles the Empire as Dart';
wwv_flow_imp.g_varchar2_table(46) := 'h Vader pursues Luke Skywalker'','||wwv_flow.LF||
'        ''Mark Hamill Carrie Fisher Harrison Ford'','||wwv_flow.LF||
'        ''Sci-Fi''';
wwv_flow_imp.g_varchar2_table(47) := ','||wwv_flow.LF||
'        to_date(''1980-05-21'', ''YYYY-MM-DD''),'||wwv_flow.LF||
'        4.8 );'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into eba_vector_moviedata ';
wwv_flow_imp.g_varchar2_table(48) := '('||wwv_flow.LF||
'        title,'||wwv_flow.LF||
'        moviedescription,'||wwv_flow.LF||
'        actors,'||wwv_flow.LF||
'        genre,'||wwv_flow.LF||
'        release_date,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(49) := '    rating )'||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        ''Star Wars: Return of the Jedi'','||wwv_flow.LF||
'        ''Luke Skywalker leads a m';
wwv_flow_imp.g_varchar2_table(50) := 'ission to rescue Han Solo while preparing for a final confrontation with Darth Vader'','||wwv_flow.LF||
'        ''Mark';
wwv_flow_imp.g_varchar2_table(51) := ' Hamill Carrie Fisher Harrison Ford'','||wwv_flow.LF||
'        ''Sci-Fi'', '||wwv_flow.LF||
'        to_date(''1983-05-25'', ''YYYY-MM-DD'')';
wwv_flow_imp.g_varchar2_table(52) := ', '||wwv_flow.LF||
'        4.6 );'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into eba_vector_moviedata ('||wwv_flow.LF||
'        title,'||wwv_flow.LF||
'        moviedescriptio';
wwv_flow_imp.g_varchar2_table(53) := 'n,'||wwv_flow.LF||
'        actors,'||wwv_flow.LF||
'        genre,'||wwv_flow.LF||
'        release_date,'||wwv_flow.LF||
'        rating )'||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        ''Star ';
wwv_flow_imp.g_varchar2_table(54) := 'Wars: The Force Awakens'','||wwv_flow.LF||
'        ''A new threat emerges as a scavenger discovers her connection to t';
wwv_flow_imp.g_varchar2_table(55) := 'he Force'','||wwv_flow.LF||
'        ''Daisy Ridley Adam Driver John Boyega'', '||wwv_flow.LF||
'        ''Sci-Fi'', '||wwv_flow.LF||
'        to_date(''2015';
wwv_flow_imp.g_varchar2_table(56) := '-12-18'', ''YYYY-MM-DD''), '||wwv_flow.LF||
'        4.5 );'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into eba_vector_moviedata ('||wwv_flow.LF||
'        title,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(57) := '       moviedescription,'||wwv_flow.LF||
'        actors,'||wwv_flow.LF||
'        genre,'||wwv_flow.LF||
'        release_date,'||wwv_flow.LF||
'        rating )'||wwv_flow.LF||
'    v';
wwv_flow_imp.g_varchar2_table(58) := 'alues ('||wwv_flow.LF||
'        ''Star Wars: The Last Jedi'', '||wwv_flow.LF||
'        ''The Resistance struggles against the First Ord';
wwv_flow_imp.g_varchar2_table(59) := 'er while Rey seeks guidance from Luke Skywalker'', '||wwv_flow.LF||
'        ''Daisy Ridley Adam Driver Mark Hamill'', '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(60) := '        ''Sci-Fi'', '||wwv_flow.LF||
'        to_date(''2017-12-15'', ''YYYY-MM-DD''), '||wwv_flow.LF||
'        4.3 );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'   -- Other movie';
wwv_flow_imp.g_varchar2_table(61) := ' data'||wwv_flow.LF||
'    insert into eba_vector_moviedata ('||wwv_flow.LF||
'        title,'||wwv_flow.LF||
'        moviedescription,'||wwv_flow.LF||
'        actors';
wwv_flow_imp.g_varchar2_table(62) := ','||wwv_flow.LF||
'        genre,'||wwv_flow.LF||
'        release_date,'||wwv_flow.LF||
'        rating )'||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        ''Interstellar'','||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(63) := ' ''A team of explorers travels through a wormhole in space to ensure humanity''''s survival'','||wwv_flow.LF||
'        ''';
wwv_flow_imp.g_varchar2_table(64) := 'Matthew McConaughey Anne Hathaway Jessica Chastain'', '||wwv_flow.LF||
'        ''Sci-Fi'', '||wwv_flow.LF||
'        to_date(''2014-11-07';
wwv_flow_imp.g_varchar2_table(65) := ''', ''YYYY-MM-DD''), '||wwv_flow.LF||
'        4.8 );'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into eba_vector_moviedata ('||wwv_flow.LF||
'        title,'||wwv_flow.LF||
'        mov';
wwv_flow_imp.g_varchar2_table(66) := 'iedescription,'||wwv_flow.LF||
'        actors,'||wwv_flow.LF||
'        genre,'||wwv_flow.LF||
'        release_date,'||wwv_flow.LF||
'        rating )'||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(67) := '      ''Inception'','||wwv_flow.LF||
'        ''A skilled thief who steals secrets through dream-sharing technology is g';
wwv_flow_imp.g_varchar2_table(68) := 'iven a chance to have his criminal history erased'','||wwv_flow.LF||
'        ''Leonardo DiCaprio Joseph Gordon-Levitt ';
wwv_flow_imp.g_varchar2_table(69) := 'Ellen Page'','||wwv_flow.LF||
'        ''Sci-Fi'', '||wwv_flow.LF||
'        to_date(''2010-07-16'', ''YYYY-MM-DD''), '||wwv_flow.LF||
'        4.7 );'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(70) := ''||wwv_flow.LF||
'    insert into eba_vector_moviedata ('||wwv_flow.LF||
'        title,'||wwv_flow.LF||
'        moviedescription,'||wwv_flow.LF||
'        actors,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(71) := '     genre,'||wwv_flow.LF||
'        release_date,'||wwv_flow.LF||
'        rating )'||wwv_flow.LF||
'    values ('''||wwv_flow.LF||
'        The Matrix'','||wwv_flow.LF||
'        ''A com';
wwv_flow_imp.g_varchar2_table(72) := 'puter hacker discovers the true nature of his reality and his role in the war against its controller';
wwv_flow_imp.g_varchar2_table(73) := 's'','||wwv_flow.LF||
'        ''Keanu Reeves Laurence Fishburne Carrie-Anne Moss'', '||wwv_flow.LF||
'        ''Sci-Fi'', '||wwv_flow.LF||
'        to_date(';
wwv_flow_imp.g_varchar2_table(74) := '''1999-03-31'', ''YYYY-MM-DD''), '||wwv_flow.LF||
'        4.9 );'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    insert into eba_vector_moviedata ('||wwv_flow.LF||
'        tit';
wwv_flow_imp.g_varchar2_table(75) := 'le,'||wwv_flow.LF||
'        moviedescription,'||wwv_flow.LF||
'        actors,'||wwv_flow.LF||
'        genre,'||wwv_flow.LF||
'        release_date,'||wwv_flow.LF||
'        rating )'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(76) := '    values ('||wwv_flow.LF||
'        ''2001: A Space Odyssey'', '||wwv_flow.LF||
'        ''A voyage to Jupiter with a sentient computer';
wwv_flow_imp.g_varchar2_table(77) := ' turns deadly after it begins to malfunction'', '||wwv_flow.LF||
'        ''Keir Dullea Gary Lockwood William Sylvester';
wwv_flow_imp.g_varchar2_table(78) := ''', '||wwv_flow.LF||
'        ''Sci-Fi'', '||wwv_flow.LF||
'        to_date(''1968-04-03'', ''YYYY-MM-DD''), '||wwv_flow.LF||
'        4.6 );'||wwv_flow.LF||
'           '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(79) := 'insert into eba_vector_moviedata ('||wwv_flow.LF||
'        title,'||wwv_flow.LF||
'        moviedescription,'||wwv_flow.LF||
'        actors,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(80) := 'genre,'||wwv_flow.LF||
'        release_date,'||wwv_flow.LF||
'        rating )'||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        ''The Cave'','||wwv_flow.LF||
'        ''A team of di';
wwv_flow_imp.g_varchar2_table(81) := 'vers becomes trapped in an underwater cave system with predatory creatures'', '||wwv_flow.LF||
'        ''Cole Hauser M';
wwv_flow_imp.g_varchar2_table(82) := 'orris Chestnut Eddie Cibrian'', '||wwv_flow.LF||
'        ''Horror'', '||wwv_flow.LF||
'        to_date(''2005-08-26'', ''YYYY-MM-DD''), '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(83) := '     3.2 );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(32061015984982819)
,p_install_id=>wwv_flow_imp.id(32055906392990968)
,p_name=>'create sample data'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
