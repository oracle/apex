prompt --application/deployment/install/install_helper_package
begin
--   Manifest
--     INSTALL: INSTALL-helper package
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_sample_vector_search_pkg authid current_user'||wwv_flow.LF||
'as'||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- using the AUTHID';
wwv_flow_imp.g_varchar2_table(2) := ' CURRENT_USER clause, as the package code references'||wwv_flow.LF||
'-- the CTX_DDL package, which is often only ava';
wwv_flow_imp.g_varchar2_table(3) := 'ilable through the CTXAPP *role*.'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'--------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(4) := '------------------'||wwv_flow.LF||
'-- returns TRUE, if Oracle TEXT and the EBA_VECTOR_MOVIEDATA table is '||wwv_flow.LF||
'-- availab';
wwv_flow_imp.g_varchar2_table(5) := 'le, false otherwise.'||wwv_flow.LF||
'-------------------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(6) := '-'||wwv_flow.LF||
'function has_moviedata_and_oracle_text return boolean;'||wwv_flow.LF||
''||wwv_flow.LF||
'------------------------------------------';
wwv_flow_imp.g_varchar2_table(7) := '--------------------------------------'||wwv_flow.LF||
'-- returns TRUE, if Oracle TEXT and the EBA_VECTOR_DATATABLE ';
wwv_flow_imp.g_varchar2_table(8) := 'table is '||wwv_flow.LF||
'-- available, false otherwise.'||wwv_flow.LF||
'-----------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(9) := '---------------------'||wwv_flow.LF||
'function has_datatable_and_oracle_text return boolean;'||wwv_flow.LF||
''||wwv_flow.LF||
'----------------------';
wwv_flow_imp.g_varchar2_table(10) := '----------------------------------------------------------'||wwv_flow.LF||
' -- deletes rows where mandatory fields a';
wwv_flow_imp.g_varchar2_table(11) := 're null '||wwv_flow.LF||
'--------------------------------------------------------------------------------'||wwv_flow.LF||
'procedure ';
wwv_flow_imp.g_varchar2_table(12) := 'delete_invalid_movie_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_sample_vector_search_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package body eba_';
wwv_flow_imp.g_varchar2_table(13) := 'sample_vector_search_pkg '||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'----------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(14) := '----------'||wwv_flow.LF||
'function has_moviedata_and_oracle_text return boolean '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_count  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(15) := 'select count(*)'||wwv_flow.LF||
'      into l_count'||wwv_flow.LF||
'      from ('||wwv_flow.LF||
'        select 1 '||wwv_flow.LF||
'          from eba_vector_moviedat';
wwv_flow_imp.g_varchar2_table(16) := 'a'||wwv_flow.LF||
'         where embedding_vector is not null'||wwv_flow.LF||
'           and rownum            = 1'||wwv_flow.LF||
'        union all';
wwv_flow_imp.g_varchar2_table(17) := ''||wwv_flow.LF||
'        select 1 '||wwv_flow.LF||
'          from sys.all_objects'||wwv_flow.LF||
'         where owner       = ''CTXSYS'' '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(18) := 'and object_name = ''CTX_DDL'' '||wwv_flow.LF||
'           and rownum      = 1 );'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_count = 2;'||wwv_flow.LF||
''||wwv_flow.LF||
'end has_mov';
wwv_flow_imp.g_varchar2_table(19) := 'iedata_and_oracle_text;'||wwv_flow.LF||
''||wwv_flow.LF||
'---------------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(20) := '-----'||wwv_flow.LF||
'function has_datatable_and_oracle_text return boolean '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_count  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    selec';
wwv_flow_imp.g_varchar2_table(21) := 't count(*)'||wwv_flow.LF||
'      into l_count'||wwv_flow.LF||
'      from ('||wwv_flow.LF||
'        select 1 '||wwv_flow.LF||
'          from eba_vector_datatable'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(22) := '      where embedding_vector is not null'||wwv_flow.LF||
'           and rownum            = 1'||wwv_flow.LF||
'        union all'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(23) := '    select 1 '||wwv_flow.LF||
'          from sys.all_objects'||wwv_flow.LF||
'         where owner       = ''CTXSYS'' '||wwv_flow.LF||
'           and o';
wwv_flow_imp.g_varchar2_table(24) := 'bject_name = ''CTX_DDL'' '||wwv_flow.LF||
'           and rownum      = 1 );'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_count = 2;'||wwv_flow.LF||
''||wwv_flow.LF||
'end has_datatabl';
wwv_flow_imp.g_varchar2_table(25) := 'e_and_oracle_text;'||wwv_flow.LF||
''||wwv_flow.LF||
'--------------------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(26) := ''||wwv_flow.LF||
'procedure delete_invalid_movie_data'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    delete from eba_vector_moviedata'||wwv_flow.LF||
'     where (    t';
wwv_flow_imp.g_varchar2_table(27) := 'itle            is null'||wwv_flow.LF||
'             or moviedescription is null'||wwv_flow.LF||
'             or actors           is';
wwv_flow_imp.g_varchar2_table(28) := ' null'||wwv_flow.LF||
'             or genre            is null'||wwv_flow.LF||
'             or release_date     is null'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(29) := ' or rating           is null );'||wwv_flow.LF||
''||wwv_flow.LF||
'end delete_invalid_movie_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_sample_vector_search_pkg;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(30) := '/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(15355493030024754)
,p_install_id=>wwv_flow_imp.id(32055906392990968)
,p_name=>'helper package'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
