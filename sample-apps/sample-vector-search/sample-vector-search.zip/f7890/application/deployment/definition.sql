prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7890
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(32055906392990968)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'----------------------------------------------------------------',
'-- Remove Tables',
'---------------------------------------------------------------',
'drop table eba_vector_datatable purge;',
'drop table eba_vector_moviedata purge;',
'',
'drop table eba_vector_ai_helper purge;',
'',
'----------------------------------------------------------------',
'-- Remove Package',
'----------------------------------------------------------------',
'drop package eba_sample_vector_search_pkg;'))
);
wwv_flow_imp.component_end;
end;
/
