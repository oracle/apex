prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7890
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '----------------------------------------------------------------'||wwv_flow.LF||
'-- Remove Tables'||wwv_flow.LF||
'------------------';
wwv_flow_imp.g_varchar2_table(2) := '---------------------------------------------'||wwv_flow.LF||
'drop table eba_vector_datatable purge;'||wwv_flow.LF||
'drop table eba_';
wwv_flow_imp.g_varchar2_table(3) := 'vector_moviedata purge;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba_vector_ai_helper purge;'||wwv_flow.LF||
''||wwv_flow.LF||
'-----------------------------------';
wwv_flow_imp.g_varchar2_table(4) := '-----------------------------'||wwv_flow.LF||
'-- Remove Package'||wwv_flow.LF||
'----------------------------------------------------';
wwv_flow_imp.g_varchar2_table(5) := '------------'||wwv_flow.LF||
'drop package eba_sample_vector_search_pkg;';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(32055906392990968)
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
