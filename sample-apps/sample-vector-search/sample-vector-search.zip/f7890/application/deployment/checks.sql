prompt --application/deployment/checks
begin
--   Manifest
--     INSTALL CHECKS: 7890
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_check(
 p_id=>wwv_flow_imp.id(32062519748238492)
,p_install_id=>wwv_flow_imp.id(32055906392990968)
,p_name=>'Database Version is 23ai or higher'
,p_sequence=>10
,p_check_type=>'EXPRESSION'
,p_check_condition=>'sys.dbms_db_version.version >= 23'
,p_check_condition2=>'PLSQL'
,p_failure_message=>'This sample application requires Oracle Database 23ai or later.'
);
wwv_flow_imp_shared.create_install_check(
 p_id=>wwv_flow_imp.id(21718182730517258)
,p_install_id=>wwv_flow_imp.id(32055906392990968)
,p_name=>'VECTOR data type available'
,p_sequence=>20
,p_check_type=>'FUNCTION_BODY'
,p_check_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    execute immediate ''declare l_vector vector; begin null; end;'';',
'    return true;',
'exception',
'    when others then',
'        return false;',
'end;'))
,p_check_condition2=>'PLSQL'
,p_failure_message=>'VECTOR data type is not available in this database.'
);
wwv_flow_imp.component_end;
end;
/
