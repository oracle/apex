prompt --application/shared_components/ai_config/oci
begin
--   Manifest
--     AI CONFIG: OCI
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_ai_config(
 p_id=>wwv_flow_imp.id(32287787472274682)
,p_name=>'OCI'
,p_static_id=>'oci'
,p_remote_server_id=>wwv_flow_imp.id(14610997010804045)
,p_version_scn=>71047988
);
wwv_flow_imp.component_end;
end;
/
