prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 7890
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(21963218092899826)
,p_name=>'AI_PROVIDER_INITIALIZED'
,p_value=>'NO'
,p_is_required=>'N'
,p_valid_values=>'YES,NO'
,p_version_scn=>126100500
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(27640748174547600)
,p_name=>'AI_PROVIDER'
,p_value=>'NONE'
,p_is_required=>'N'
,p_valid_values=>'OPENAI,OCI,NONE'
,p_on_upgrade_keep_value=>true
,p_version_scn=>126100446
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(32161735794884984)
,p_name=>'WC_STATUS'
,p_value=>'VOID'
,p_is_required=>'N'
,p_valid_values=>'ENTERED,VOID'
,p_on_upgrade_keep_value=>true
,p_version_scn=>124430470
);
wwv_flow_imp.component_end;
end;
/
