prompt --application/shared_components/logic/application_computations/web_credentials_entered
begin
--   Manifest
--     APPLICATION COMPUTATION: WEB_CREDENTIALS_ENTERED
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(32162333758902248)
,p_computation_sequence=>10
,p_computation_item=>'WEB_CREDENTIALS_ENTERED'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'apex_app_setting.get_value(''WC_STATUS'')'
,p_version_scn=>119641972
);
wwv_flow_imp.component_end;
end;
/
