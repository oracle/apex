prompt --application/shared_components/logic/application_items/web_credentials_entered
begin
--   Manifest
--     APPLICATION ITEM: WEB_CREDENTIALS_ENTERED
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(32161396166869209)
,p_name=>'WEB_CREDENTIALS_ENTERED'
,p_protection_level=>'I'
,p_version_scn=>69852646
);
wwv_flow_imp.component_end;
end;
/
