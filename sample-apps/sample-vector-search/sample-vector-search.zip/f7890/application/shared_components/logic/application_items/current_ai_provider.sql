prompt --application/shared_components/logic/application_items/current_ai_provider
begin
--   Manifest
--     APPLICATION ITEM: CURRENT_AI_PROVIDER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(28047947230013078)
,p_name=>'CURRENT_AI_PROVIDER'
,p_protection_level=>'I'
,p_version_scn=>100668815
);
wwv_flow_imp.component_end;
end;
/
