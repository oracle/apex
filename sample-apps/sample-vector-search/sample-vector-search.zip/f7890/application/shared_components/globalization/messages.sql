prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7890
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(25025794162201816)
,p_name=>'EBA_VECTOR.STATUS_UPDATE_AI_GENERATION'
,p_message_text=>'%0 out of %1 categories generated.'
,p_is_js_message=>true
,p_version_scn=>'116272461'
);
wwv_flow_imp.component_end;
end;
/
