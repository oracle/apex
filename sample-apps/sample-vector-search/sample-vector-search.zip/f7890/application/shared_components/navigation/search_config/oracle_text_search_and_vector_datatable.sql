prompt --application/shared_components/navigation/search_config/oracle_text_search_and_vector_datatable
begin
--   Manifest
--     SEARCH CONFIG: ORACLE-TEXT-SEARCH-AND-VECTOR-DATATABLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(14705397227405739)
,p_label=>'ORACLE-TEXT-SEARCH-AND-VECTOR-DATATABLE'
,p_static_id=>'oracle_text_search_and_vector_datatable'
,p_search_type=>'TEXT_MANUAL'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_VECTOR_DATATABLE'
,p_oratext_index_column_name=>'COL1'
,p_return_max_results=>10
,p_query_order_by=>wwv_flow_string.join(wwv_flow_t_varchar2(
'VECTOR_DISTANCE(embedding_vector, ',
'    apex_ai.get_vector_embeddings(',
'        p_value =>             :P33_SEARCH, ',
'        p_service_static_id => case when :CURRENT_AI_PROVIDER = ''OCI'' then ''EBA_VECTOR_OCI'' else ''EBA_VECTOR_OPENAI'' end), DOT) ASC'))
,p_pk_column_name=>'ID'
,p_title_column_name=>'COL1'
,p_subtitle_column_name=>'COL2'
,p_description_column_name=>'COL3'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-film'
,p_version_scn=>106554704
);
wwv_flow_imp.component_end;
end;
/
