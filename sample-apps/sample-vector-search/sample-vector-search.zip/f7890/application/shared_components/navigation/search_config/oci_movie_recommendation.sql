prompt --application/shared_components/navigation/search_config/oci_movie_recommendation
begin
--   Manifest
--     SEARCH CONFIG: OCI-MOVIE-RECOMMENDATION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(26877849548749343)
,p_label=>'OCI-MOVIE-RECOMMENDATION'
,p_static_id=>'OCI_MOVIE_RECOMMENDATION'
,p_search_type=>'VECTOR'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_VECTOR_MOVIEDATA'
,p_query_where=>'SUBSTR(moviedescription, 1, 40) <> SUBSTR(:P41_SEARCH, 1, 40)'
,p_oratext_index_column_name=>'EMBEDDING_VECTOR'
,p_vector_provider_id =>wwv_flow_imp.id(16013343297879238)
,p_vector_search_type=>'EXACT'
,p_vector_distance_metric=>'DOT'
,p_return_max_results=>5
,p_pk_column_name=>'ID'
,p_title_column_name=>'TITLE'
,p_subtitle_column_name=>'ACTORS'
,p_description_column_name=>'MOVIEDESCRIPTION'
,p_badge_column_name=>'RATING'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:49:&APP_SESSION.::&DEBUG.:49:P49_SEARCH_ID:&ID.'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-film'
,p_version_scn=>119703015
);
wwv_flow_imp.component_end;
end;
/
