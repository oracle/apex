prompt --application/shared_components/navigation/search_config/oracle_text_search_and_vector_moviedata
begin
--   Manifest
--     SEARCH CONFIG: ORACLE-TEXT-SEARCH-AND-VECTOR-MOVIEDATA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(26878575693785892)
,p_label=>'ORACLE-TEXT-SEARCH-AND-VECTOR-MOVIEDATA'
,p_static_id=>'ORACLE_TEXT_SEARCH_AND_VECTOR'
,p_search_type=>'TEXT_MANUAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_VECTOR_MOVIEDATA'
,p_oratext_index_column_name=>'MOVIEDESCRIPTION'
,p_return_max_results=>10
,p_query_order_by=>wwv_flow_string.join(wwv_flow_t_varchar2(
'VECTOR_DISTANCE(embedding_vector, ',
'    apex_ai.get_vector_embeddings(',
'        p_value =>             :P17_SEARCH, ',
'        p_service_static_id => case when :CURRENT_AI_PROVIDER = ''OCI'' then ''EBA_VECTOR_OCI'' else ''EBA_VECTOR_OPENAI'' end), DOT) ASC'))
,p_pk_column_name=>'ID'
,p_title_column_name=>'TITLE'
,p_subtitle_column_name=>'ACTORS'
,p_description_column_name=>'MOVIEDESCRIPTION'
,p_badge_column_name=>'RATING'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-film'
,p_version_scn=>'106508917'
);
wwv_flow_imp.component_end;
end;
/
