prompt --application/shared_components/navigation/search_config/openai_basic_vector_search_moviedata
begin
--   Manifest
--     SEARCH CONFIG: OPENAI-BASIC-VECTOR-SEARCH-MOVIEDATA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(32205139326725138)
,p_label=>'OPENAI-BASIC-VECTOR-SEARCH-MOVIEDATA'
,p_static_id=>'OPENAI_BASIC_VECTOR_SEARCH'
,p_search_type=>'VECTOR'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_VECTOR_MOVIEDATA'
,p_oratext_index_column_name=>'EMBEDDING_VECTOR'
,p_vector_provider_id =>wwv_flow_imp.id(15639632983805312)
,p_vector_search_type=>'EXACT'
,p_vector_distance_metric=>'DOT'
,p_return_max_results=>10
,p_pk_column_name=>'ID'
,p_title_column_name=>'TITLE'
,p_subtitle_column_name=>'ACTORS'
,p_description_column_name=>'MOVIEDESCRIPTION'
,p_badge_column_name=>'RATING'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-film'
,p_version_scn=>106109376
);
wwv_flow_imp.component_end;
end;
/
