prompt --application/shared_components/navigation/search_config/oracle_text_search_datatable
begin
--   Manifest
--     SEARCH CONFIG: ORACLE-TEXT-SEARCH-DATATABLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(26879025249810515)
,p_label=>'ORACLE-TEXT-SEARCH-DATATABLE'
,p_static_id=>'ORACLE_TEXT_SEARCH'
,p_search_type=>'TEXT_MANUAL'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_VECTOR_DATATABLE'
,p_oratext_index_column_name=>'COL1'
,p_return_max_results=>10
,p_pk_column_name=>'ID'
,p_title_column_name=>'COL1'
,p_subtitle_column_name=>'COL2'
,p_description_column_name=>'COL3'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-sitemap-vertical'
,p_version_scn=>106553931
);
wwv_flow_imp.component_end;
end;
/
