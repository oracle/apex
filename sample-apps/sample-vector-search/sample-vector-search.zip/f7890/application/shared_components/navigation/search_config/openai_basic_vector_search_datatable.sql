prompt --application/shared_components/navigation/search_config/openai_basic_vector_search_datatable
begin
--   Manifest
--     SEARCH CONFIG: OPENAI-BASIC-VECTOR-SEARCH-DATATABLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(32204777597721912)
,p_label=>'OPENAI-BASIC-VECTOR-SEARCH-DATATABLE'
,p_static_id=>'OPENAI_ADVANCED_VECTOR_SEARCH'
,p_search_type=>'VECTOR'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_VECTOR_DATATABLE'
,p_oratext_index_column_name=>'EMBEDDING_VECTOR'
,p_vector_provider_id =>wwv_flow_imp.id(15639632983805312)
,p_vector_search_type=>'EXACT'
,p_vector_distance_metric=>'DOT'
,p_return_max_results=>10
,p_pk_column_name=>'ID'
,p_title_column_name=>'COL1'
,p_subtitle_column_name=>'COL2'
,p_description_column_name=>'COL3'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-sitemap-vertical'
,p_version_scn=>106554312
);
wwv_flow_imp.component_end;
end;
/
