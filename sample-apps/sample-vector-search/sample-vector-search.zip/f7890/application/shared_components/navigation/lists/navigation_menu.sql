prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(26569066502740918)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>124400979
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(26580521863740992)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14561158735185073)
,p_list_item_display_sequence=>11
,p_list_item_link_text=>'Movie Data'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-film'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14630894988604380)
,p_list_item_display_sequence=>13
,p_list_item_link_text=>'Prepare Data'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:11:::'
,p_list_item_icon=>'fa-number-1-o'
,p_parent_list_item_id=>wwv_flow_imp.id(14561158735185073)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'11'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14634257306692820)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'Basic Vector Search'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15:::'
,p_list_item_icon=>'fa-number-2-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from EBA_VECTOR_MOVIEDATA where embedding_vector is not null'
,p_parent_list_item_id=>wwv_flow_imp.id(14561158735185073)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'15'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14634501423697898)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>'Vector vs. Oracle Text'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:16:::'
,p_list_item_icon=>'fa-number-3-o'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'eba_sample_vector_search_pkg.has_moviedata_and_oracle_text'
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(14561158735185073)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'16'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14634890062701571)
,p_list_item_display_sequence=>220
,p_list_item_link_text=>'Vector and Oracle Text'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17:::'
,p_list_item_icon=>'fa-number-4-o'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'eba_sample_vector_search_pkg.has_moviedata_and_oracle_text'
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(14561158735185073)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'17'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14665240187692558)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>'Movie Recommendations'
,p_list_item_link_target=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:41:::'
,p_list_item_icon=>'fa-number-5-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from EBA_VECTOR_MOVIEDATA where embedding_vector is not null'
,p_parent_list_item_id=>wwv_flow_imp.id(14561158735185073)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'41'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14665527565695432)
,p_list_item_display_sequence=>310
,p_list_item_link_text=>'Mixed Languages'
,p_list_item_link_target=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:42:::'
,p_list_item_icon=>'fa-number-6-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from EBA_VECTOR_MOVIEDATA where embedding_vector is not null'
,p_parent_list_item_id=>wwv_flow_imp.id(14561158735185073)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'42'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14561678776197495)
,p_list_item_display_sequence=>12
,p_list_item_link_text=>'Custom Data'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database-user'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14655745548466893)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>'Prepare Data'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25,26,27:::'
,p_list_item_icon=>'fa-number-1-o'
,p_parent_list_item_id=>wwv_flow_imp.id(14561678776197495)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'25'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14656489169511162)
,p_list_item_display_sequence=>270
,p_list_item_link_text=>'Basic Vector Search'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31:::'
,p_list_item_icon=>'fa-number-2-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from EBA_VECTOR_DATATABLE where embedding_vector is not null'
,p_parent_list_item_id=>wwv_flow_imp.id(14561678776197495)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'31'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14656758985517960)
,p_list_item_display_sequence=>280
,p_list_item_link_text=>'Vector vs. Oracle Text'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:32:::'
,p_list_item_icon=>'fa-number-3-o'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'eba_sample_vector_search_pkg.has_datatable_and_oracle_text'
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(14561678776197495)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'32'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14657068075533127)
,p_list_item_display_sequence=>290
,p_list_item_link_text=>'Vector and Oracle Text'
,p_list_item_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:33:::'
,p_list_item_icon=>'fa-number-4-o'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'eba_sample_vector_search_pkg.has_datatable_and_oracle_text'
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(14561678776197495)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'33'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(26857251890048845)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:50:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-gear'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'50'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(31472283758841272)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Set AI Provider'
,p_list_item_link_target=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-key'
,p_parent_list_item_id=>wwv_flow_imp.id(26857251890048845)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(27461772339385625)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Reset Sample Data Tables'
,p_list_item_link_target=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database'
,p_parent_list_item_id=>wwv_flow_imp.id(26857251890048845)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(27481647128509857)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Application Theme Style'
,p_list_item_link_target=>'f?p=&APP_ID.:52:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-design'
,p_parent_list_item_id=>wwv_flow_imp.id(26857251890048845)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
