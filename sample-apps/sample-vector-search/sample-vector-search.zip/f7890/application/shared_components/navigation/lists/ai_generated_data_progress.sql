prompt --application/shared_components/navigation/lists/ai_generated_data_progress
begin
--   Manifest
--     LIST: AI Generated Data Progress
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(14190948692845326)
,p_name=>'AI Generated Data Progress'
,p_list_status=>'PUBLIC'
,p_version_scn=>124383924
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14191102579845330)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Enter Prompt'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14191506670845331)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Preview and Upload Data'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14191928832845331)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Generate Vector Embeddings'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14850751217427267)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Confirmation'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
