prompt --application/shared_components/navigation/lists/vector_search_movie_data
begin
--   Manifest
--     LIST: Vector Search (Movie Data)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(26891210267974065)
,p_name=>'Vector Search (Movie Data)'
,p_list_status=>'PUBLIC'
,p_version_scn=>115119551
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(26891422904974065)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Basic Vector Search'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from EBA_VECTOR_MOVIEDATA where embedding_vector is not null'
,p_list_text_01=>'Search movie data using vector search based on the TITLE, MOVIEDESCRIPTION, and ACTORS fields.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(26891887571974066)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Vector vs. Oracle Text'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'eba_sample_vector_search_pkg.has_moviedata_and_oracle_text'
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_01=>'<strong>Compare</strong> vector based search with traditional Oracle Text search.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(26892265090974066)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Vector and Oracle Text'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'eba_sample_vector_search_pkg.has_moviedata_and_oracle_text'
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_01=>'<strong>Combine</strong> vector and Oracle Text search for a more effective, and targeted search.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
