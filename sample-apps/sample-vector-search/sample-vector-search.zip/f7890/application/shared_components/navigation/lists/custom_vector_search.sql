prompt --application/shared_components/navigation/lists/custom_vector_search
begin
--   Manifest
--     LIST: Custom Vector Search
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(14666527271720723)
,p_name=>'Custom Vector Search'
,p_static_id=>'custom-vector-search'
,p_version_scn=>'124364933'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14667188762720725)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Basic Vector Search'
,p_static_id=>'basic-vector-search'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from EBA_VECTOR_DATATABLE where embedding_vector is not null'
,p_list_text_01=>'Search data using vectors based on the first 10 columns of your uploaded data. '
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14666777652720725)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Prepare Data'
,p_static_id=>'prepare-data'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-csv-o'
,p_list_text_01=>'Upload your custom data to perform vector search on.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14847032842331648)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Vector and Oracle Text'
,p_static_id=>'vector-and-oracle-text'
,p_list_item_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'eba_sample_vector_search_pkg.has_datatable_and_oracle_text'
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_01=>'<strong>Combine</strong> vector and Oracle Text search for a more effective, and targeted search.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14846751772323828)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Vector vs. Oracle Text'
,p_static_id=>'vector-vs-oracle-text'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'eba_sample_vector_search_pkg.has_datatable_and_oracle_text'
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_01=>'<strong>Compare</strong> vector based search with traditional Oracle Text search.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
