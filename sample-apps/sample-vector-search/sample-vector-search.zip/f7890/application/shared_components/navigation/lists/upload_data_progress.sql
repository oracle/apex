prompt --application/shared_components/navigation/lists/upload_data_progress
begin
--   Manifest
--     LIST: Upload Data Progress
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(14193624344893271)
,p_name=>'Upload Data Progress'
,p_list_status=>'PUBLIC'
,p_version_scn=>124384366
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14193861620893271)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Select File'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14194223984893271)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Preview and Load Data'
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14194621990893271)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Generate Vector Embeddings'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14851084142439035)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Confirmation'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
