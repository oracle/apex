prompt --application/shared_components/navigation/lists/movie_vector_search
begin
--   Manifest
--     LIST: Movie Vector Search
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(14563222337261426)
,p_name=>'Movie Vector Search'
,p_list_status=>'PUBLIC'
,p_version_scn=>124378845
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14563448485261426)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Prepare Data'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-code-o'
,p_list_text_01=>'Use AI to generate real movie data to perform vector search on.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14847825791354908)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Basic Vector Search'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from EBA_VECTOR_MOVIEDATA where embedding_vector is not null'
,p_list_text_01=>'Search movie data using vector search based on the TITLE, MOVIEDESCRIPTION, and ACTORS fields.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14848156456360528)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Vector vs. Oracle Text'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'eba_sample_vector_search_pkg.has_moviedata_and_oracle_text'
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_01=>'<strong>Compare</strong> vector based search with traditional Oracle Text search.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14848401703364540)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Vector and Oracle Text'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'eba_sample_vector_search_pkg.has_moviedata_and_oracle_text'
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_01=>'<strong>Combine</strong> vector and Oracle Text search for a more effective, and targeted search.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14848748256378257)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Movie Recommendation'
,p_list_item_link_target=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-rocket'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from EBA_VECTOR_MOVIEDATA where embedding_vector is not null'
,p_list_text_01=>'Use vector search to recommend movies <strong>based on </strong>their<strong> vector similarity</strong>.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14849091016382747)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Mixed Languages'
,p_list_item_link_target=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-rocket'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select 1 from EBA_VECTOR_MOVIEDATA where embedding_vector is not null'
,p_list_text_01=>'Apply vector search to find relevant content across different languages, <strong>bridging language barriers</strong> in your data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
