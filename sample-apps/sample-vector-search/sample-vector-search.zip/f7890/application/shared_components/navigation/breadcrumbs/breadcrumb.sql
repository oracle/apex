prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(26568570669740916)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27093990055480825)
,p_parent_id=>wwv_flow_imp.id(26858156054048846)
,p_option_sequence=>5
,p_short_name=>'Reset Sample Data Tables'
,p_link=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:::'
,p_page_id=>51
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14562568909227184)
,p_short_name=>'Movie Vector Search'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14670765155811488)
,p_parent_id=>wwv_flow_imp.id(14677304043005330)
,p_short_name=>'Basic Vector Search'
,p_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14672144464831674)
,p_parent_id=>wwv_flow_imp.id(14671899167827589)
,p_short_name=>'Vector Search'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14672396837835852)
,p_parent_id=>wwv_flow_imp.id(14672144464831674)
,p_short_name=>'Basic Vector Search'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14677304043005330)
,p_parent_id=>wwv_flow_imp.id(14562568909227184)
,p_short_name=>'Vector Search'
,p_link=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:::'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(15189872847504092)
,p_parent_id=>wwv_flow_imp.id(26858156054048846)
,p_short_name=>'Set AI Provider'
,p_link=>'f?p=&APP_ID.:54:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>54
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(26568793157740916)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(26855551744038223)
,p_short_name=>'Movie Recommendation'
,p_link=>'f?p=&APP_ID.:41:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>41
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27474594849412536)
,p_parent_id=>wwv_flow_imp.id(26858156054048846)
,p_short_name=>'Application Theme Style'
,p_link=>'f?p=&APP_ID.:52:&SESSION.::&DEBUG.:::'
,p_page_id=>52
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14672594412845524)
,p_parent_id=>wwv_flow_imp.id(14672144464831674)
,p_option_sequence=>20
,p_short_name=>'Vector vs. Oracle Text Search'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14671899167827589)
,p_option_sequence=>25
,p_short_name=>'Custom Vector Search'
,p_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:::'
,p_page_id=>24
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14671278596813646)
,p_parent_id=>wwv_flow_imp.id(14677304043005330)
,p_option_sequence=>30
,p_short_name=>'Vector vs. Oracle Text Search'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(26856810898041914)
,p_option_sequence=>30
,p_short_name=>'Mixed Languages'
,p_link=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:::'
,p_page_id=>42
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14672764902847722)
,p_parent_id=>wwv_flow_imp.id(14672144464831674)
,p_option_sequence=>40
,p_short_name=>'Vector and Oracle Text Search'
,p_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
,p_page_id=>33
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(26858156054048846)
,p_option_sequence=>40
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:::'
,p_page_id=>50
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14671422085815292)
,p_parent_id=>wwv_flow_imp.id(14677304043005330)
,p_option_sequence=>50
,p_short_name=>'Vector and Oracle Text Search'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp.component_end;
end;
/
