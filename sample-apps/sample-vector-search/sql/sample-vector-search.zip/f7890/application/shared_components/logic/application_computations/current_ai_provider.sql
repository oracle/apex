prompt --application/shared_components/logic/application_computations/current_ai_provider
begin
--   Manifest
--     APPLICATION COMPUTATION: CURRENT_AI_PROVIDER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(28048520263022833)
,p_computation_sequence=>10
,p_computation_item=>'CURRENT_AI_PROVIDER'
,p_static_id=>'current-ai-provider'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'apex_app_setting.get_value(''AI_PROVIDER'')'
,p_version_scn=>'54048505'
);
wwv_flow_imp.component_end;
end;
/
