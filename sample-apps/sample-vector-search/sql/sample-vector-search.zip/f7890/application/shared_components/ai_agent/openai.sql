prompt --application/shared_components/ai_agent/openai
begin
--   Manifest
--     AI AGENT: OPENAI
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_ai_agent(
 p_id=>wwv_flow_imp.id(32287534921273568)
,p_name=>'OPENAI'
,p_static_id=>'openai'
,p_remote_server_id=>14611575625828962
,p_version_scn=>'71050950'
,p_agent_comment=>'Not used in the application, but needed to connect the application to the AI Service.'
);
wwv_flow_imp.component_end;
end;
/
