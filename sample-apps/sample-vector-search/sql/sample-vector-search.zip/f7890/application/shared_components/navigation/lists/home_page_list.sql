prompt --application/shared_components/navigation/lists/home_page_list
begin
--   Manifest
--     LIST: Home Page List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(32150271482617636)
,p_name=>'Home Page List'
,p_static_id=>'home-page-list'
,p_version_scn=>'126221802'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(32151603707617638)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Administration'
,p_static_id=>'administration'
,p_list_item_link_target=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'Configure the AI provider, reset sample data, or change the application appearance.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(32151249311617638)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Custom Data'
,p_static_id=>'custom-data'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database-user'
,p_list_text_01=>'Experiment with vector search in APEX by uploading your own custom data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(32150823249617638)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Movie Data'
,p_static_id=>'movie-data'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-film'
,p_list_text_01=>'Explore vector search concepts with guided examples based on movies data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
