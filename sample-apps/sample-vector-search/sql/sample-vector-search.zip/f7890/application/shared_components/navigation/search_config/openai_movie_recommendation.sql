prompt --application/shared_components/navigation/search_config/openai_movie_recommendation
begin
--   Manifest
--     SEARCH CONFIG: OPENAI-MOVIE-RECOMMENDATION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(32204106105713615)
,p_label=>'OPENAI-MOVIE-RECOMMENDATION'
,p_static_id=>'OPENAI_MOVIE_RECOMMENDATION'
,p_search_type=>'VECTOR'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_VECTOR_MOVIEDATA'
,p_query_where=>'SUBSTR(moviedescription, 1, 40) <> SUBSTR(:P41_SEARCH, 1, 40)'
,p_oratext_index_column_name=>'EMBEDDING_VECTOR'
,p_vector_provider_id=>15639632983805312
,p_vector_search_type=>'EXACT'
,p_vector_distance_metric=>'DOT'
,p_return_max_results=>5
,p_pk_column_name=>'ID'
,p_title_column_name=>'TITLE'
,p_subtitle_column_name=>'ACTORS'
,p_description_column_name=>'MOVIEDESCRIPTION'
,p_badge_column_name=>'RATING'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:49:&APP_SESSION.::&DEBUG.:49:P49_SEARCH_ID:&ID.'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-film'
,p_version_scn=>'119702249'
);
wwv_flow_imp.component_end;
end;
/
