prompt --workspace/remote_servers/oci_genai_service
begin
--   Manifest
--     REMOTE SERVER: OCI GenAI Service
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7890
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>14610997010804045
,p_name=>'OCI GenAI Service'
,p_static_id=>'EBA_GENAI_OCI'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('EBA_GENAI_OCI'),'https://inference.generativeai.us-chicago-1.oci.oraclecloud.com')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('EBA_GENAI_OCI'),'')
,p_server_type=>'GENERATIVE_AI'
,p_credential_id=>14610758767804040
,p_ai_provider_type=>'OCI_GENAI'
,p_ai_provider_api=>'GENERIC'
,p_ai_is_builder_service=>false
,p_ai_is_default_for_new_apps=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('EBA_GENAI_OCI'),'cohere.command-a-03-2025')
,p_ai_oci_compartment_id=>nvl(wwv_flow_application_install.get_remote_server_ai_oci_comp('EBA_GENAI_OCI'),'ocid1.compartment.oc1')
,p_ai_oci_serving_mode=>nvl(wwv_flow_application_install.get_remote_server_ai_oci_srvmd('EBA_GENAI_OCI'),'ON_DEMAND')
,p_ai_oci_endpoint_id=>nvl(wwv_flow_application_install.get_remote_server_ai_oci_endpt('EBA_GENAI_OCI'),'')
,p_ai_oci_project_id=>nvl(wwv_flow_application_install.get_remote_server_ai_oci_proj('EBA_GENAI_OCI'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('EBA_GENAI_OCI'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('EBA_GENAI_OCI'),'')
,p_ai_max_tokens=>nvl(wwv_flow_application_install.get_remote_server_ai_maxtokens('EBA_GENAI_OCI'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
