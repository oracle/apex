prompt --application/shared_components/user_interface/lovs/availability
begin
--   Manifest
--     AVAILABILITY
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(160414337382963894)
,p_lov_name=>'AVAILABILITY'
,p_lov_query=>'.'||wwv_flow_api.id(160414337382963894)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(160414723240963895)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Immediate'
,p_lov_return_value=>'IMMEDIATE'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(160415176616963895)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Next Month'
,p_lov_return_value=>'NEXTMONTH'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(160415520833963895)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Not Available'
,p_lov_return_value=>'NOTAVAILABLE'
);
wwv_flow_api.component_end;
end;
/
