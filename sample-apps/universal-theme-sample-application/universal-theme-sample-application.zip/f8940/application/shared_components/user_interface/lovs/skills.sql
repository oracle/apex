prompt --application/shared_components/user_interface/lovs/skills
begin
--   Manifest
--     SKILLS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(160409448640963882)
,p_lov_name=>'SKILLS'
,p_lov_query=>'.'||wwv_flow_api.id(160409448640963882)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(160409850103963886)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'APEX'
,p_lov_return_value=>'APEX'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(160410273789963888)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'HTML'
,p_lov_return_value=>'HTML'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(160410626679963888)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'JavaScript'
,p_lov_return_value=>'JS'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(160411086984963888)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'CSS'
,p_lov_return_value=>'CSS'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(160411457066963888)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Java'
,p_lov_return_value=>'Java'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(160411823871963889)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'Scala'
,p_lov_return_value=>'Scala'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(160412272089963889)
,p_lov_disp_sequence=>7
,p_lov_disp_value=>'Ruby on Rails'
,p_lov_return_value=>'Ruby on Rails'
);
wwv_flow_api.component_end;
end;
/
