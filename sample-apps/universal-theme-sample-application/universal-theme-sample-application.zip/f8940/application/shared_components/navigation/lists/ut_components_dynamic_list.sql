prompt --application/shared_components/navigation/lists/ut_components_dynamic_list
begin
--   Manifest
--     LIST: UT - Components Dynamic List
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(879773454971203054)
,p_name=>'UT - Components Dynamic List'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null,',
'       entry_text as label,',
'       entry_target as target,',
'       null is_current',
'from APEX_APPLICATION_LIST_entries',
'where application_id = :APP_ID',
'and list_name = ''UT - Application Navigation''',
'and parent_entry_text = ''Components'''))
,p_list_status=>'PUBLIC'
);
wwv_flow_api.component_end;
end;
/
