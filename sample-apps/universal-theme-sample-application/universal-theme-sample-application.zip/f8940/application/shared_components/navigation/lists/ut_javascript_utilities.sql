prompt --application/shared_components/navigation/lists/ut_javascript_utilities
begin
--   Manifest
--     LIST: UT - JavaScript Utilities
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(713407327666911744)
,p_name=>'UT - JavaScript Utilities'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(713460604663425801)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'JavaScript Events'
,p_list_item_link_target=>'f?p=&APP_ID.:6200:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_list_text_01=>'Listen and respond to these documented events in Universal Theme'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(713407680446911744)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Javascript APIs'
,p_list_item_link_target=>'f?p=&APP_ID.:6201:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_list_text_01=>'Extend Universal Theme with the following widget APIs'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
