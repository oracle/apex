prompt --application/shared_components/navigation/lists/ut_miscellaneous
begin
--   Manifest
--     LIST: UT - Miscellaneous
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(790289546548048869)
,p_name=>'UT - Miscellaneous'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1808782715624849532)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Component Templates'
,p_list_item_link_target=>'f?p=&APP_ID.:6307:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list'
,p_list_text_01=>'See a list of all available templates grouped by component type'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2055910706772108747)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Region Types'
,p_list_item_link_target=>'f?p=&APP_ID.:6308:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list'
,p_list_text_01=>'See a list of the region types available in Application Express and Universal Theme'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(790289728055048870)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Change Log'
,p_list_item_link_target=>'f?p=&APP_ID.:6305:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list-ol'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_text_01=>'See the changes in the new version of Universal Theme'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(790290111386048870)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'FAQ'
,p_list_item_link_target=>'f?p=&APP_ID.:6306:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-question-circle'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_text_01=>'Answers to commonly asked questions.'
,p_list_text_06=>'u-color-13'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
