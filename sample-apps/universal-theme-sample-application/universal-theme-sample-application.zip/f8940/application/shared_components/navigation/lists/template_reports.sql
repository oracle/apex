prompt --application/shared_components/navigation/lists/template_reports
begin
--   Manifest
--     LIST: Template - Reports
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(476579719264733455)
,p_name=>'Template - Reports'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2285561707719536226)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Alerts'
,p_list_item_link_target=>'f?p=&APP_ID.:1202:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-exclamation-triangle'
,p_list_text_01=>'Display alerts, confirmations, and other action-oriented messages.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2285562001417536227)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Badge List'
,p_list_item_link_target=>'f?p=&APP_ID.:1304:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-badge-list'
,p_list_text_01=>'Displaying badges or counters.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2182543778758267099)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Cards'
,p_list_item_link_target=>'f?p=&APP_ID.:3100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cards'
,p_list_text_01=>'This report template provides the Cards UI and is useful for presenting a variety of information. Cards can be displayed in three styles, with icons or initials, and you can control the layout.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(476581538439733458)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Comments'
,p_list_item_link_target=>'f?p=&APP_ID.:1405:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-comments-o'
,p_list_text_01=>'This report template is used to display user comments and status updates.'
,p_list_text_03=>'CM'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(775220668939941719)
,p_list_item_display_sequence=>45
,p_list_item_link_text=>'Contextual Info'
,p_list_item_link_target=>'f?p=&APP_ID.:1307:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-list-right'
,p_list_text_01=>'This report template is best used to display key value pairs.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(476579975751733455)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Standard'
,p_list_item_link_target=>'f?p=&APP_ID.:1401:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>'This is the default report template used for displaying tabular data.'
,p_list_text_03=>'RP'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(476583558130758825)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Timeline'
,p_list_item_link_target=>'f?p=&APP_ID.:1406:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clock-o'
,p_list_text_01=>'This timeline report template is useful for displaying recent updates and interactions within an application.'
,p_list_text_03=>'TL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(476580797814733457)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Value Attribute Pairs'
,p_list_item_link_target=>'f?p=&APP_ID.:1403:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pause'
,p_list_text_01=>'This report template is useful for displaying attribute value / key value pairs and works well with both Row or Column based queries.'
,p_list_text_03=>'VA'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2302998102575626036)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Search Results'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
