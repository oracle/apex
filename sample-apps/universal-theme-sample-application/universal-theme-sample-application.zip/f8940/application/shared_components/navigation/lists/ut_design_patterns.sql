prompt --application/shared_components/navigation/lists/ut_design_patterns
begin
--   Manifest
--     LIST: UT - Design Patterns
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(713419631491967228)
,p_name=>'UT - Design Patterns'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(713419977147967228)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Login Page'
,p_list_item_link_target=>'f?p=&APP_ID.:5001:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-key'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(713420325392967229)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Home and Dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:5002:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(713420748995967229)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Filter Page'
,p_list_item_link_target=>'f?p=&APP_ID.:5003:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header-sidebar-left'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(713421166924967229)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Marquee Page'
,p_list_item_link_target=>'f?p=&APP_ID.:5004:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-check-circle-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(713421594146967229)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Modal Dialogs'
,p_list_item_link_target=>'f?p=&APP_ID.:5005:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-blank'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
