prompt --application/shared_components/navigation/lists/template_forms
begin
--   Manifest
--     LIST: Template - Forms
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(476588768580793809)
,p_name=>'Template - Forms'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(476588928305793810)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Form Modifiers'
,p_list_item_link_target=>'f?p=&APP_ID.:1601:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-forms'
,p_list_text_01=>'This is a basic form which can be customized using Template Options of the Region they are in.'
,p_list_text_03=>'FM'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(476589362742793811)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Multi Column Layout'
,p_list_item_link_target=>'f?p=&APP_ID.:1602:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-columns'
,p_list_text_01=>'These examples show how complex form layout can achieved in Universal Theme.'
,p_list_text_03=>'MC'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(458994195620648265)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Floating Labels'
,p_list_item_link_target=>'f?p=&APP_ID.:1603:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cloud-cursor'
,p_list_text_01=>'This form style features labels that automatically shrink as data is entered.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
