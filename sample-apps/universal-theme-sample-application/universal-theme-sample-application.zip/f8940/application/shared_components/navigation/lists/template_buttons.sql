prompt --application/shared_components/navigation/lists/template_buttons
begin
--   Manifest
--     LIST: Template - Buttons
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(476584406006772879)
,p_name=>'Template - Buttons'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(476584644680772879)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Text Only'
,p_list_item_link_target=>'f?p=&APP_ID.:1501:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-text-o'
,p_list_text_01=>'This is your standard button in Universal Theme'
,p_list_text_03=>'TO'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(476585035303772880)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Icon Only'
,p_list_item_link_target=>'f?p=&APP_ID.:1502:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-photo'
,p_list_text_01=>'This list template provides the Cards UI and is useful for presenting a variety of information. Cards can be displayed in three styles, with icons or initials, and you can control the layout.'
,p_list_text_03=>'IO'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(476585408801772881)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Text With Icon'
,p_list_item_link_target=>'f?p=&APP_ID.:1503:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-picture-o'
,p_list_text_01=>'This template enables you to display an icon next to your button label. You can easily position the icon to the right or left of the label using Template Options.'
,p_list_text_03=>'TI'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
