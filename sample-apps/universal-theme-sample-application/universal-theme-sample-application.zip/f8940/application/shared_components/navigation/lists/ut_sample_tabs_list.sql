prompt --application/shared_components/navigation/lists/ut_sample_tabs_list
begin
--   Manifest
--     LIST: UT - Sample Tabs List
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(2285543718406476760)
,p_name=>'UT - Sample Tabs List'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2285543917158476761)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Tab 1'
,p_list_item_link_target=>'javascript:void(0);'
,p_list_item_icon=>'fa-user'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'1907'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2285544391396476761)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Tab 2'
,p_list_item_link_target=>'javascript:void(0);'
,p_list_item_icon=>'fa-heart-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2285544741435476761)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Tab 3'
,p_list_item_link_target=>'javascript:void(0);'
,p_list_item_icon=>'fa-cloud'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
