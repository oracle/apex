prompt --application/shared_components/navigation/lists/ut_mobile_patterns
begin
--   Manifest
--     LIST: UT - Mobile Patterns
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(608043492397034627)
,p_name=>'UT - Mobile Patterns'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(608043606699034632)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Navigation'
,p_list_item_link_target=>'f?p=&APP_ID.:421:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-breadcrumb'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(608044068623034633)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Headers and Footers'
,p_list_item_link_target=>'f?p=&APP_ID.:422:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header-footer'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(608049594314081832)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Data Entry'
,p_list_item_link_target=>'f?p=&APP_ID.:423:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-forms'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(608044438288034634)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Touch Gestures'
,p_list_item_link_target=>'f?p=&APP_ID.:424:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-hand-o-right'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(608044828577034634)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Mobile Components'
,p_list_item_link_target=>'f?p=&APP_ID.:425:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cubes'
,p_list_text_06=>'u-color-3'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
