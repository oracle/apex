prompt --application/shared_components/navigation/lists/top_modal_dialogs
begin
--   Manifest
--     LIST: Top - Modal Dialogs
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(2011053202038416818)
,p_name=>'Top - Modal Dialogs'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2011053433081416822)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Page Dialog'
,p_list_item_link_target=>'f?p=&APP_ID.:1910:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-header'
,p_list_text_01=>'Include a full page inside another page. You will be able to utilize Page Process and Page Validation from that page.'
,p_list_text_03=>'PM'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2011053895828416824)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Inline Dialog'
,p_list_item_link_target=>'f?p=&APP_ID.:1911:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-header'
,p_list_text_01=>'Essentially a hidden Region on the same page displayed as a dialog.'
,p_list_text_03=>'ID'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(210177198989587652)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Inline Popup'
,p_list_item_link_target=>'f?p=&APP_ID.:1915:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-blank'
,p_list_text_01=>'Essentially a hidden Region on the same page displayed as an inline popup.'
,p_list_text_03=>'IP'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
