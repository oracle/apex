prompt --application/shared_components/navigation/lists/template_pages
begin
--   Manifest
--     LIST: Template - Pages
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(1917756475003302943)
,p_name=>'Template - Pages'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1917854764902086401)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Both Side Columns'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:both_sides:&DEBUG.::::'
,p_list_item_icon=>'fa fa-columns'
,p_list_text_01=>'This page template features both the left side column and the collapsible right-side column and is well suited for very complex pages.'
,p_list_text_03=>'BS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1917758219558302948)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Dialog Page'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:dialog:&DEBUG.::::'
,p_list_item_icon=>'fa-comment'
,p_list_text_01=>'These page templates can be loaded as either modal or non-modal (pop-up) dialogs and are very useful for displaying commonly used forms, reports, and other components.'
,p_list_text_03=>'DP'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1917757070091302947)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Left Side Column'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:left_side:&DEBUG.::::'
,p_list_item_icon=>'fa-layout-2col'
,p_list_text_01=>'Features a left-side display position for search filters, charts, and other interactive widgets.'
,p_list_text_03=>'LC'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1917759284120309798)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Login Page'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:other:&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'The Login page template'
,p_list_text_03=>'LP'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1917757817164302947)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Master Detail'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:master_detail:&DEBUG.::::'
,p_list_item_icon=>'fa-layout-3col-1col'
,p_list_text_01=>'This page template features a collapsible right side column and a title-bar area which contains primary information.'
,p_list_text_03=>'MD'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2285497438316229565)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Minimal (No Navigation)'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:other:&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'It is useful for single page applications or pages where where navigation is not necessary.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2285501589504274877)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Modal Dialog'
,p_list_item_link_target=>'f?p=&APP_ID.:1910:&SESSION.:other:&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-header'
,p_list_text_01=>'Modal dialogs are a great way to get user input, display information, and speed up user interactions without changing context or leaving the current page.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1917757429622302947)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Right Side Column'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:right_side:&DEBUG.::::'
,p_list_item_icon=>'fa-layout-2col'
,p_list_text_01=>'This page template features a collapsible right-side display position and is especially useful for displaying action-oriented controls such as buttons or lists.'
,p_list_text_03=>'RS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1917756637934302944)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Standard'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:standard:&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'The default page template.'
,p_list_text_03=>'ST'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2285503483961293818)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Wizard Modal Dialog'
,p_list_item_link_target=>'f?p=&APP_ID.:1208:&SESSION.:other:&DEBUG.::::'
,p_list_item_icon=>'fa-wizard'
,p_list_text_01=>'Wizards can be very useful in simplifying complex flows into smaller, more manageable steps.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
