prompt --application/shared_components/navigation/lists/ut_migration_guide
begin
--   Manifest
--     LIST: UT - Migration Guide
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(558263404439591029)
,p_name=>'UT - Migration Guide'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(558263675345591030)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Why Migrate'
,p_list_item_link_target=>'f?p=&APP_ID.:2010:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-question'
,p_list_text_06=>'u-color-11'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(558264058382591032)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Migration Steps'
,p_list_item_link_target=>'f?p=&APP_ID.:2020:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list-ol'
,p_list_text_06=>'u-color-11'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(558264495416591033)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Post Migration'
,p_list_item_link_target=>'f?p=&APP_ID.:2030:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-check'
,p_list_text_06=>'u-color-11'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(558264826389591033)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Bookmarklet'
,p_list_item_link_target=>'f?p=&APP_ID.:2040:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bookmark-o'
,p_list_text_06=>'u-color-11'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(558265275145591033)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'FAQ'
,p_list_item_link_target=>'f?p=&APP_ID.:2050:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list'
,p_list_text_06=>'u-color-11'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
