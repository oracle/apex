prompt --application/shared_components/navigation/breadcrumbs/universal_theme_breadcrumb
begin
--   Manifest
--     MENU: Universal Theme Breadcrumb
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_menu(
 p_id=>wwv_flow_api.id(1725934084712570512)
,p_name=>'Universal Theme Breadcrumb'
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(7673360602846008)
,p_parent_id=>wwv_flow_api.id(713441110976327619)
,p_short_name=>'Layout Modifiers'
,p_link=>'f?p=&APP_ID.:6303:&SESSION.'
,p_page_id=>6303
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(7685388498866322)
,p_parent_id=>wwv_flow_api.id(713441110976327619)
,p_short_name=>'Content Modifiers'
,p_link=>'f?p=&APP_ID.:6304:&SESSION.'
,p_page_id=>6304
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(210168877180558147)
,p_parent_id=>wwv_flow_api.id(881157505434754791)
,p_short_name=>'Inline Popup'
,p_link=>'f?p=&APP_ID.:1915:&SESSION.'
,p_page_id=>1915
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(315966332257005007)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'List View'
,p_link=>'f?p=&APP_ID.:1700:&SESSION.::&DEBUG.:::'
,p_page_id=>1700
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(316475931504323548)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Reflow Report'
,p_link=>'f?p=&APP_ID.:1710:&SESSION.::&DEBUG.:::'
,p_page_id=>1710
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(316476488861330022)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Column Toggle Report'
,p_link=>'f?p=&APP_ID.:1720:&SESSION.::&DEBUG.:::'
,p_page_id=>1720
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(350283341012744451)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Content Row'
,p_link=>'f?p=&APP_ID.:1407:&SESSION.'
,p_page_id=>1407
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(405016342125846517)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Standard Region'
,p_link=>'f?p=&APP_ID.:1201:&SESSION.::&DEBUG.:::'
,p_page_id=>1201
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(405040484449865679)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Alert'
,p_link=>'f?p=&APP_ID.:1202:&SESSION.::&DEBUG.:::'
,p_page_id=>1202
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(405062644608003720)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Hero'
,p_link=>'f?p=&APP_ID.:1203:&SESSION.::&DEBUG.:::'
,p_page_id=>1203
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(405108427828686806)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Button Group'
,p_link=>'f?p=&APP_ID.:1204:&SESSION.::&DEBUG.:::'
,p_page_id=>1204
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(405191402701156577)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Carousel'
,p_link=>'f?p=&APP_ID.:1205:&SESSION.::&DEBUG.:::'
,p_page_id=>1205
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(405231916079328330)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Collapsible'
,p_link=>'f?p=&APP_ID.:1206:&SESSION.::&DEBUG.:::'
,p_page_id=>1206
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(405259632803407094)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Title Bar Region'
,p_link=>'f?p=&APP_ID.:1207:&SESSION.::&DEBUG.:::'
,p_page_id=>1207
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(405315415623757810)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Wizards'
,p_link=>'f?p=&APP_ID.:1208:&SESSION.::&DEBUG.:::'
,p_page_id=>1208
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(405358438291967114)
,p_parent_id=>wwv_flow_api.id(1911030665098394574)
,p_short_name=>'Text Only'
,p_link=>'f?p=&APP_ID.:1501:&SESSION.'
,p_page_id=>1501
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(405404246911043708)
,p_parent_id=>wwv_flow_api.id(1911030665098394574)
,p_short_name=>'Icon Only'
,p_link=>'f?p=&APP_ID.:1502:&SESSION.'
,p_page_id=>1502
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(405722108370782715)
,p_parent_id=>wwv_flow_api.id(1911030665098394574)
,p_short_name=>'Text With Icon'
,p_link=>'f?p=&APP_ID.:1503:&SESSION.'
,p_page_id=>1503
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(405776641189895027)
,p_parent_id=>wwv_flow_api.id(405777134403900984)
,p_short_name=>'Media List '
,p_link=>'f?p=&APP_ID.:1301:&SESSION.::&DEBUG.:::'
,p_page_id=>1301
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(405777134403900984)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Lists'
,p_link=>'f?p=&APP_ID.:1300:&SESSION.::&DEBUG.:::'
,p_page_id=>1300
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(415729531119475692)
,p_parent_id=>wwv_flow_api.id(405777134403900984)
,p_short_name=>'Links List'
,p_link=>'f?p=&APP_ID.:1303:&SESSION.::&DEBUG.:::'
,p_page_id=>1303
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(415752454589532129)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Badge List'
,p_link=>'f?p=&APP_ID.:1304:&SESSION.::&DEBUG.:::'
,p_page_id=>1304
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(415772729409701356)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Menu Bar'
,p_link=>'f?p=&APP_ID.:1305:&SESSION.::&DEBUG.:::'
,p_page_id=>1305
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(415798956596821823)
,p_parent_id=>wwv_flow_api.id(881194233909445309)
,p_short_name=>'Classic Report'
,p_link=>'f?p=&APP_ID.:1401:&SESSION.::&DEBUG.:::'
,p_page_id=>1401
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(415955727913117791)
,p_parent_id=>wwv_flow_api.id(881194233909445309)
,p_short_name=>'Interactive Report'
,p_link=>'f?p=&APP_ID.:1402:&SESSION.::&DEBUG.:::'
,p_page_id=>1402
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(416129372898571323)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>' Value Attribute Pairs'
,p_link=>'f?p=&APP_ID.:1403:&SESSION.::&DEBUG.:::'
,p_page_id=>1403
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(416218025971740499)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Comments'
,p_link=>'f?p=&APP_ID.:1405:&SESSION.::&DEBUG.:::'
,p_page_id=>1405
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(416303482217820050)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Timeline'
,p_link=>'f?p=&APP_ID.:1406:&SESSION.::&DEBUG.:::'
,p_page_id=>1406
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(416369132735887980)
,p_parent_id=>wwv_flow_api.id(416370450953899013)
,p_short_name=>'Form Modifiers'
,p_link=>'f?p=&APP_ID.:1601:&SESSION.::&DEBUG.:::'
,p_page_id=>1601
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(416370450953899013)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Forms'
,p_link=>'f?p=&APP_ID.:1600:&SESSION.::&DEBUG.:::'
,p_page_id=>1600
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(416507407538131265)
,p_parent_id=>wwv_flow_api.id(416370450953899013)
,p_short_name=>'Multi Column Layout'
,p_link=>'f?p=&APP_ID.:1602:&SESSION.'
,p_page_id=>1602
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(430904312030166974)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Calendar'
,p_link=>'f?p=&APP_ID.:1800:&SESSION.::&DEBUG.:::'
,p_page_id=>1800
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(431026239113724261)
,p_parent_id=>wwv_flow_api.id(431031703087824044)
,p_short_name=>'Why Migrate'
,p_link=>'f?p=&APP_ID.:2010:&SESSION.::&DEBUG.:::'
,p_page_id=>2010
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(431031703087824044)
,p_parent_id=>0
,p_short_name=>'Migration Guides'
,p_link=>'f?p=&APP_ID.:2000:&SESSION.::&DEBUG.:::'
,p_page_id=>2000
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(431044436003209545)
,p_parent_id=>wwv_flow_api.id(431031703087824044)
,p_short_name=>'Bookmarklet'
,p_link=>'f?p=&APP_ID.:2040:&SESSION.::&DEBUG.:::'
,p_page_id=>2040
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(431272858361902943)
,p_parent_id=>wwv_flow_api.id(431031703087824044)
,p_short_name=>'FAQ'
,p_link=>'f?p=&APP_ID.:2050:&SESSION.'
,p_page_id=>2050
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(435211113342906473)
,p_parent_id=>wwv_flow_api.id(431031703087824044)
,p_short_name=>'Migration Steps'
,p_link=>'f?p=&APP_ID.:2020:&SESSION.::&DEBUG.:::'
,p_page_id=>2020
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(435224098597129018)
,p_parent_id=>wwv_flow_api.id(431031703087824044)
,p_short_name=>'Post Migration'
,p_link=>'f?p=&APP_ID.:2030:&SESSION.'
,p_page_id=>2030
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(459020312700661741)
,p_parent_id=>wwv_flow_api.id(416370450953899013)
,p_short_name=>'Floating Labels'
,p_link=>'f?p=&APP_ID.:1603:&SESSION.'
,p_page_id=>1603
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(480671848759352791)
,p_short_name=>'About'
,p_link=>'f?p=&APP_ID.:600:&SESSION.'
,p_page_id=>600
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Components'
,p_link=>'f?p=&APP_ID.:3000:&SESSION.'
,p_page_id=>3000
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(599865283849044119)
,p_parent_id=>wwv_flow_api.id(431031703087824044)
,p_short_name=>'Migrating from jQuery Mobile'
,p_link=>'f?p=&APP_ID.:2060:&SESSION.'
,p_page_id=>2060
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(662088705999490988)
,p_parent_id=>wwv_flow_api.id(878800086315994991)
,p_short_name=>'Mobile Patterns'
,p_link=>'f?p=&APP_ID.:420:&SESSION.'
,p_page_id=>420
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(673646648036520165)
,p_parent_id=>wwv_flow_api.id(662088705999490988)
,p_short_name=>'Navigation'
,p_link=>'f?p=&APP_ID.:421:&SESSION.'
,p_page_id=>421
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(713440476208313042)
,p_parent_id=>wwv_flow_api.id(713441110976327619)
,p_short_name=>'JavaScript Events'
,p_link=>'f?p=&APP_ID.:6200:&SESSION.::&DEBUG.:::'
,p_page_id=>6200
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(713441110976327619)
,p_parent_id=>0
,p_short_name=>'Reference'
,p_link=>'f?p=&APP_ID.:6000:&SESSION.::&DEBUG.:::'
,p_page_id=>6000
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(713639758730194276)
,p_parent_id=>wwv_flow_api.id(713441110976327619)
,p_short_name=>'Button Builder'
,p_link=>'f?p=&APP_ID.:6100:&SESSION.'
,p_page_id=>6100
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(732954489982714238)
,p_parent_id=>wwv_flow_api.id(1758435596542435858)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1115:&SESSION.'
,p_page_id=>1115
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(736913114356128770)
,p_parent_id=>wwv_flow_api.id(713441110976327619)
,p_short_name=>'Responsive Utilities'
,p_link=>'f?p=&APP_ID.:6301:&SESSION.::&DEBUG.:::'
,p_page_id=>6301
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(747876825088794510)
,p_parent_id=>wwv_flow_api.id(662088705999490988)
,p_short_name=>'Headers and Footers'
,p_link=>'f?p=&APP_ID.:422:&SESSION.'
,p_page_id=>422
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(752552499874333310)
,p_parent_id=>wwv_flow_api.id(713441110976327619)
,p_short_name=>'Color and Status Modifiers'
,p_link=>'f?p=&APP_ID.:6302:&SESSION.'
,p_page_id=>6302
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(756678249191197562)
,p_parent_id=>wwv_flow_api.id(878820395161346399)
,p_short_name=>'Page Footer'
,p_link=>'f?p=&APP_ID.:1117:&SESSION.'
,p_page_id=>1117
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(756755896005683553)
,p_parent_id=>wwv_flow_api.id(662088705999490988)
,p_short_name=>'Data Entry'
,p_link=>'f?p=&APP_ID.:423:&SESSION.'
,p_page_id=>423
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(756768285839753736)
,p_parent_id=>wwv_flow_api.id(756755896005683553)
,p_short_name=>'Mobile Forms Example'
,p_link=>'f?p=&APP_ID.:1604:&SESSION.'
,p_page_id=>1604
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(756831656565273988)
,p_parent_id=>wwv_flow_api.id(662088705999490988)
,p_short_name=>'Touch Gestures'
,p_link=>'f?p=&APP_ID.:424:&SESSION.'
,p_page_id=>424
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(761088222290584702)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Card Regions'
,p_link=>'f?p=&APP_ID.:3110:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>3110
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(775206954383869455)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Contextual Info'
,p_link=>'f?p=&APP_ID.:1307:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1307
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(790468275074051539)
,p_parent_id=>wwv_flow_api.id(662088705999490988)
,p_short_name=>'jQuery Mobile Components'
,p_link=>'f?p=&APP_ID.:425:&SESSION.::&DEBUG.:::'
,p_page_id=>425
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(840826676176747170)
,p_parent_id=>wwv_flow_api.id(878810707644066974)
,p_short_name=>'Menu Bar'
,p_link=>'f?p=&APP_ID.:1120:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1120
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(841294298262783356)
,p_parent_id=>wwv_flow_api.id(878810707644066974)
,p_short_name=>'Tabs'
,p_link=>'f?p=&APP_ID.:1121:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1121
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(842000530060801868)
,p_parent_id=>wwv_flow_api.id(878810707644066974)
,p_short_name=>'Mega Menu'
,p_link=>'f?p=&APP_ID.:1122:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1122
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(842002795877810836)
,p_parent_id=>wwv_flow_api.id(878810707644066974)
,p_short_name=>'Side Tree Navigation'
,p_link=>'f?p=&APP_ID.:1123:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1123
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(842007588900829852)
,p_parent_id=>wwv_flow_api.id(878810707644066974)
,p_short_name=>'Mega Menu Variation 2'
,p_link=>'f?p=&APP_ID.:1124:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1124
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878800086315994991)
,p_parent_id=>0
,p_short_name=>'Design'
,p_link=>'f?p=&APP_ID.:401:&SESSION.::&DEBUG.:::'
,p_page_id=>401
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878803110284040666)
,p_parent_id=>wwv_flow_api.id(878800086315994991)
,p_short_name=>'Colors'
,p_link=>'f?p=&APP_ID.:402:&SESSION.'
,p_page_id=>402
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878805148812052134)
,p_parent_id=>wwv_flow_api.id(878800086315994991)
,p_short_name=>'Customization'
,p_link=>'f?p=&APP_ID.:403:&SESSION.'
,p_page_id=>403
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878806872645056196)
,p_parent_id=>wwv_flow_api.id(878800086315994991)
,p_short_name=>'Data Entry'
,p_link=>'f?p=&APP_ID.:404:&SESSION.'
,p_page_id=>404
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878808536733061977)
,p_parent_id=>wwv_flow_api.id(878800086315994991)
,p_short_name=>'Notifications and Messaging'
,p_link=>'f?p=&APP_ID.:406:&SESSION.'
,p_page_id=>406
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878810707644066974)
,p_parent_id=>wwv_flow_api.id(878800086315994991)
,p_short_name=>'Navigation'
,p_link=>'f?p=&APP_ID.:407:&SESSION.'
,p_page_id=>407
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878820013807343793)
,p_parent_id=>wwv_flow_api.id(878820395161346399)
,p_short_name=>'Login Page'
,p_link=>'f?p=&APP_ID.:5001:&SESSION.::&DEBUG.:::'
,p_page_id=>5001
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878820395161346399)
,p_parent_id=>wwv_flow_api.id(878800086315994991)
,p_short_name=>'UI Patterns'
,p_link=>'f?p=&APP_ID.:5000:&SESSION.::&DEBUG.:::'
,p_page_id=>5000
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878822705619358077)
,p_parent_id=>wwv_flow_api.id(878820395161346399)
,p_short_name=>'Home and Dashboard'
,p_link=>'f?p=&APP_ID.:5002:&SESSION.'
,p_page_id=>5002
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878823819415362574)
,p_parent_id=>wwv_flow_api.id(878820395161346399)
,p_short_name=>'Filter Page'
,p_link=>'f?p=&APP_ID.:5003:&SESSION.::&DEBUG.:::'
,p_page_id=>5003
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878824976710375281)
,p_parent_id=>wwv_flow_api.id(878820395161346399)
,p_short_name=>'Marquee Page'
,p_link=>'f?p=&APP_ID.:5004:&SESSION.'
,p_page_id=>5004
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878826051998379262)
,p_parent_id=>wwv_flow_api.id(878820395161346399)
,p_short_name=>'Modal Dialogs'
,p_link=>'f?p=&APP_ID.:5005:&SESSION.'
,p_page_id=>5005
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878827168982388181)
,p_parent_id=>wwv_flow_api.id(878800086315994991)
,p_short_name=>'Layout'
,p_link=>'f?p=&APP_ID.:700:&SESSION.::&DEBUG.:::'
,p_page_id=>700
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878830369710409691)
,p_parent_id=>wwv_flow_api.id(878827168982388181)
,p_short_name=>'Responsive Design'
,p_link=>'f?p=&APP_ID.:701:&SESSION.'
,p_page_id=>701
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(878835075205587954)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Breadcrumb'
,p_link=>'f?p=&APP_ID.:3810:&SESSION.'
,p_page_id=>3810
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(879740912488795988)
,p_parent_id=>wwv_flow_api.id(878827168982388181)
,p_short_name=>'Grid Layout'
,p_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:::'
,p_page_id=>300
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881066848076282529)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Tree'
,p_link=>'f?p=&APP_ID.:1901:&SESSION.'
,p_page_id=>1901
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881111039740601975)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Charts'
,p_link=>'f?p=&APP_ID.:1902:&SESSION.'
,p_page_id=>1902
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881116326102723830)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Help Text'
,p_link=>'f?p=&APP_ID.:1903:&SESSION.'
,p_page_id=>1903
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881118152890734670)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Map Chart'
,p_link=>'f?p=&APP_ID.:1904:&SESSION.'
,p_page_id=>1904
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881121800279740598)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Static Content'
,p_link=>'f?p=&APP_ID.:1905:&SESSION.::&DEBUG.:::'
,p_page_id=>1905
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881157505434754791)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Modal Dialogs and Popups'
,p_link=>'f?p=&APP_ID.:1906:&SESSION.::&DEBUG.:::'
,p_page_id=>1906
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881163895342772753)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Tabs and Region Display Selector'
,p_link=>'f?p=&APP_ID.:1907:&SESSION.::&DEBUG.:::'
,p_page_id=>1907
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881167366244202617)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'PL/SQL Dynamic Content'
,p_link=>'f?p=&APP_ID.:1908:&SESSION.'
,p_page_id=>1908
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881168623211214610)
,p_parent_id=>wwv_flow_api.id(431031703087824044)
,p_short_name=>'Updating Universal Theme'
,p_link=>'f?p=&APP_ID.:1909:&SESSION.::&DEBUG.:::'
,p_page_id=>1909
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881170097767222220)
,p_parent_id=>wwv_flow_api.id(881157505434754791)
,p_short_name=>'Page Dialog'
,p_link=>'f?p=&APP_ID.:1910:&SESSION.::&DEBUG.:::'
,p_page_id=>1910
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881172314139238857)
,p_parent_id=>wwv_flow_api.id(881157505434754791)
,p_short_name=>'Inline Dialog'
,p_link=>'f?p=&APP_ID.:1911:&SESSION.::&DEBUG.:::'
,p_page_id=>1911
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881194233909445309)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Data Tables and Reports'
,p_link=>'f?p=&APP_ID.:3400:&SESSION.'
,p_page_id=>3400
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881228626406484346)
,p_parent_id=>wwv_flow_api.id(881194233909445309)
,p_short_name=>'Interactive Grid'
,p_link=>'f?p=&APP_ID.:1410:&SESSION.::&DEBUG.:::'
,p_page_id=>1410
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881374476202981669)
,p_parent_id=>wwv_flow_api.id(713441110976327619)
,p_short_name=>'Change Log'
,p_link=>'f?p=&APP_ID.:6305:&SESSION.'
,p_page_id=>6305
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(881376276477993941)
,p_parent_id=>wwv_flow_api.id(713441110976327619)
,p_short_name=>'FAQ'
,p_link=>'f?p=&APP_ID.:6306:&SESSION.'
,p_page_id=>6306
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1758435596542435858)
,p_parent_id=>wwv_flow_api.id(878827168982388181)
,p_short_name=>'Page Templates'
,p_link=>'f?p=&APP_ID.:1100:&SESSION.::&DEBUG.:::'
,p_page_id=>1100
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1773976871138980525)
,p_parent_id=>wwv_flow_api.id(1758435596542435858)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1101:&SESSION.'
,p_page_id=>1101
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1808784107265857503)
,p_parent_id=>wwv_flow_api.id(713441110976327619)
,p_short_name=>'Component Templates'
,p_link=>'f?p=&APP_ID.:6307:&SESSION.'
,p_page_id=>6307
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1885245761685551804)
,p_parent_id=>wwv_flow_api.id(1758435596542435858)
,p_short_name=>'Standard Page Template'
,p_link=>'f?p=&APP_ID.:1102:&SESSION.'
,p_page_id=>1102
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1885259462750625674)
,p_parent_id=>wwv_flow_api.id(1758435596542435858)
,p_short_name=>'Left Column Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1103:&SESSION.'
,p_page_id=>1103
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1885267674882727203)
,p_parent_id=>wwv_flow_api.id(1758435596542435858)
,p_short_name=>'Left Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1104:&SESSION.'
,p_page_id=>1104
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1890860434385160978)
,p_parent_id=>wwv_flow_api.id(1758435596542435858)
,p_short_name=>'Right Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1105:&SESSION.'
,p_page_id=>1105
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1890864473059172587)
,p_parent_id=>wwv_flow_api.id(1758435596542435858)
,p_short_name=>'Right Column Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1106:&SESSION.'
,p_page_id=>1106
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1890868915075211375)
,p_parent_id=>wwv_flow_api.id(1758435596542435858)
,p_short_name=>'Marquee Detail Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1107:&SESSION.::&DEBUG.:::'
,p_page_id=>1107
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1891239718441396761)
,p_parent_id=>wwv_flow_api.id(1758435596542435858)
,p_short_name=>'Marquee Detail Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1108:&SESSION.::&DEBUG.:::'
,p_page_id=>1108
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1897720798714999483)
,p_parent_id=>wwv_flow_api.id(1758435596542435858)
,p_short_name=>'Side Columns Page with Side Navigation'
,p_link=>'f?p=&APP_ID.:1109:&SESSION.'
,p_page_id=>1109
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1897734087043021074)
,p_parent_id=>wwv_flow_api.id(1758435596542435858)
,p_short_name=>'Side Columns Page with Top Navigation'
,p_link=>'f?p=&APP_ID.:1110:&SESSION.'
,p_page_id=>1110
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1898478875532595926)
,p_parent_id=>wwv_flow_api.id(1758435596542435858)
,p_short_name=>'Standard Dialog Page'
,p_link=>'f?p=&APP_ID.:1111:&SESSION.'
,p_page_id=>1111
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1899238584269120733)
,p_parent_id=>wwv_flow_api.id(1758435596542435858)
,p_short_name=>'Minimal Page Template'
,p_link=>'f?p=&APP_ID.:1113:&SESSION.'
,p_page_id=>1113
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(1911030665098394574)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Buttons'
,p_link=>'f?p=&APP_ID.:1500:&SESSION.::&DEBUG.:::'
,p_page_id=>1500
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2055956183257222899)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Menu Popup'
,p_link=>'f?p=&APP_ID.:1306:&SESSION.'
,p_page_id=>1306
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2089777306376286802)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Card Templates'
,p_link=>'f?p=&APP_ID.:3100:&SESSION.::&DEBUG.:::'
,p_page_id=>3100
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2176455778526356925)
,p_parent_id=>wwv_flow_api.id(713441110976327619)
,p_short_name=>'JavaScript APIs'
,p_link=>'f?p=&APP_ID.:6201:&SESSION.'
,p_page_id=>6201
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2182465237568964508)
,p_parent_id=>wwv_flow_api.id(558267818619623839)
,p_short_name=>'Button Container'
,p_link=>'f?p=&APP_ID.:1250:&SESSION.::&DEBUG.:::'
,p_page_id=>1250
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(2190812909868353587)
,p_parent_id=>wwv_flow_api.id(713441110976327619)
,p_short_name=>'Region Types'
,p_link=>'f?p=&APP_ID.:6308:&SESSION.::&DEBUG.:::'
,p_page_id=>6308
);
wwv_flow_api.component_end;
end;
/
