prompt --application/shared_components/plugins/region_type/com_oracle_apex_preview_template_options
begin
--   Manifest
--     PLUGIN: COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_plugin(
 p_id=>wwv_flow_api.id(776877005555146556)
,p_plugin_type=>'REGION TYPE'
,p_name=>'COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'
,p_display_name=>'Preview Template Options'
,p_supported_ui_types=>'DESKTOP:JQM_SMARTPHONE'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('REGION TYPE','COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'),'')
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#apex_ui/js/widget.propertyEditor.js',
'#IMAGE_PREFIX#apex_ui/js/templateOptionsHelper.js',
'#PLUGIN_FILES#js/script#MIN#.js'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#PLUGIN_FILES#css/base#MIN#.css',
'#PLUGIN_FILES#css/style#MIN#.css'))
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'c_workspace constant varchar2(100) := apex_util.find_workspace(:workspace_id);',
'',
'subtype t_region_type is varchar2(40);',
'c_region_type_list_region       constant t_region_type := ''NATIVE_LIST'';',
'c_region_type_breadcrumb_region constant t_region_type := ''NATIVE_BREADCRUMB'';',
'c_region_type_sql_report        constant t_region_type := ''NATIVE_SQL_REPORT'';',
'c_region_type_tabform           constant t_region_type := ''NATIVE_TABFORM'';',
'',
'procedure emit_template_templ_options',
'    ( p_component_id   number',
'    , p_application_id number',
'    , p_theme_id       number',
'    , p_template_id    number',
'    , p_template_type  varchar2',
'    , p_current_values varchar2',
'    )',
'as',
'    type t_groups is table of apex_appl_template_opt_groups%rowtype index by varchar2( 255 );',
'    ',
'    l_groups                 t_groups;',
'    l_group_id               varchar2(255);',
'    l_default                apex_application_temp_page.default_template_options%type;',
'    l_preset                 apex_application_temp_page.preset_template_options%type;',
'    l_emit_template_defaults boolean := true;',
'    ',
'    procedure emit_template_options (',
'        p_d           in varchar2,',
'        p_r           in varchar2,',
'        p_seq         in number,',
'        p_is_advanced in boolean,',
'        p_help_text   in varchar2 default null,',
'        p_group_id    in varchar2 default null )',
'    is',
'    begin',
'        apex_json.open_object;',
'        apex_json.write(''d'',          p_d);',
'        apex_json.write(''r'',          p_r);',
'        apex_json.write(''seq'',        p_seq);',
'        apex_json.write(''isAdvanced'', p_is_advanced);',
'        apex_json.write(''helpText'',   apex_escape.html_whitelist(p_help_text));',
'        apex_json.write(''groupId'',    p_group_id);',
'        ',
'        apex_json.close_object;',
'    end emit_template_options;',
'begin',
'    apex_json.open_object;',
'',
'    apex_json.write(''componentId'', '''' || p_component_id);',
'    apex_json.write(''title'', initcap(p_template_type));',
'',
'    apex_json.open_array( ''values'' );',
'',
'    for l_option in ( select o.display_name,',
'                             o.display_sequence,',
'                             o.is_advanced,',
'                             o.help_text,',
'                             o.css_classes,',
'                             ',
'                             to_char(g.template_opt_group_id)    as group_id,',
'                             g.display_name     as group_display_name,',
'                             g.display_sequence as group_display_sequence,',
'                             g.is_advanced      as group_is_advanced,',
'                             g.help_text        as group_help_text,',
'                             g.null_text        as group_null_text',
'                        from apex_appl_template_options o,',
'                             apex_appl_template_opt_groups g',
'                       where o.application_id    = p_application_id',
'                         and o.theme_number      = p_theme_id',
'                         and o.workspace         = c_workspace',
'                         and (  (   o.virtual_template_id is null',
'                                and instr( o.virtual_template_type, p_template_type ) > 0',
'                                )',
'                             or (   o.virtual_template_id   = p_template_id',
'                                and o.virtual_template_type = p_template_type',
'                                )',
'                             )',
'                         and g.template_opt_group_id (+) = o.group_id',
'                       order by o.display_sequence, o.template_option_id )',
'    loop',
'        if l_emit_template_defaults then',
'            emit_template_options (',
'                p_d           => wwv_flow_lang.system_message(''TEMPLATE_OPTIONS.USE_TEMPLATE_DEFAULTS''),',
'                p_r           => ''#DEFAULT#'',',
'                p_seq         => 0,',
'                p_is_advanced => false );',
'            l_emit_template_defaults := false;',
'        end if;',
'        ',
'        emit_template_options (',
'            p_d           => l_option.display_name,',
'            p_r           => l_option.css_classes,',
'            p_seq         => l_option.display_sequence,',
'            p_is_advanced => ( l_option.is_advanced = ''Y'' ),',
'            p_help_text   => l_option.help_text,',
'            p_group_id    => l_option.group_id );',
'        ',
'        if l_option.group_id is not null and not l_groups.exists( l_option.group_id ) then',
'            l_groups( l_option.group_id ).display_name     := l_option.group_display_name;',
'            l_groups( l_option.group_id ).display_sequence := l_option.group_display_sequence;',
'            l_groups( l_option.group_id ).is_advanced      := l_option.group_is_advanced;',
'            l_groups( l_option.group_id ).help_text        := l_option.group_help_text;',
'            l_groups( l_option.group_id ).null_text        := l_option.group_null_text;',
'        end if;',
'    end loop;',
'    apex_json.close_array;',
'',
'    ',
'    apex_json.open_object( ''groups'' );',
'    l_group_id := l_groups.first;',
'    loop',
'        exit when l_group_id is null;',
'',
'        apex_json.open_object( l_group_id );',
'        apex_json.write(''title'',      l_groups(l_group_id).display_name);',
'        apex_json.write(''seq'',        l_groups(l_group_id).display_sequence);',
'        apex_json.write(''isAdvanced'', (l_groups(l_group_id).is_advanced = ''Y''));',
'        apex_json.write(''helpText'',   wwv_flow_escape.html_whitelist(l_groups(l_group_id).help_text));',
'        apex_json.write(''nullText'',   l_groups(l_group_id).null_text);',
'        apex_json.close_object;',
'        ',
'        l_group_id := l_groups.next( l_group_id );',
'    end loop;',
'    apex_json.close_object;',
'',
'    execute immediate ''select default_template_options, preset_template_options from '' ||',
'                        case p_template_type',
'                        when ''REGION''     then ''apex_application_temp_region''',
'                        when ''BUTTON''     then ''apex_application_temp_button''',
'                        when ''FIELD''      then ''apex_application_temp_label''',
'                        when ''REPORT''     then ''apex_application_temp_report''',
'                        when ''LIST''       then ''apex_application_temp_list''',
'                        when ''BREADCRUMB'' then ''apex_application_temp_bc''',
'                        end ||',
'                    '' where '' ||',
'                        case p_template_type',
'                        when ''REGION''     then ''region_template_id''',
'                        when ''BUTTON''     then ''button_template_id''',
'                        when ''FIELD''      then ''label_template_id''',
'                        when ''REPORT''     then ''template_id''',
'                        when ''LIST''       then ''list_template_id''',
'                        when ''BREADCRUMB'' then ''breadcrumb_template_id''',
'                        end ||',
'                    '' = :p_template_id and workspace = :p_security_group_id''',
'                 into l_default,',
'                      l_preset',
'                using p_template_id,',
'                      c_workspace;',
'',
'    apex_json.write(',
'        p_name       => ''currentValues'',',
'        p_value      => p_current_values,',
'        p_write_null => true );',
'',
'    apex_json.write(',
'        p_name       => ''defaultValues'',',
'        p_values     => apex_string.split(',
'                            p_str => l_default,',
'                            p_sep => '':'' ),',
'        p_write_null => true );',
'',
'    apex_json.write(',
'        p_name       => ''presetValues'',',
'        p_values     => apex_string.split(',
'                            p_str => l_preset,',
'                            p_sep => '':'' ),',
'        p_write_null => true );',
'',
'    apex_json.close_object;',
'',
'end;',
'',
'procedure emit_component_templ_options',
'    ( p_application_id      number',
'    , p_page_id             number',
'    , p_component_type      varchar2',
'    , p_component_static_id varchar2',
'    )',
'as',
'    l_component_id               number;',
'    l_primary_template_id        number;',
'    l_primary_template_type      varchar2(10);',
'    l_primary_template_options   apex_application_page_regions.region_template_options%type;',
'    l_secondary_template_id      number;',
'    l_secondary_template_type    varchar2(10);',
'    l_secondary_template_options apex_application_page_regions.component_template_options%type;',
'    l_theme_id                   number := 42;',
'begin',
'    ',
'    if p_component_type = ''REGION'' then',
'',
'        l_primary_template_type := ''REGION'';',
'        select region_id,',
'               template_id,',
'               region_template_options,',
'               case',
'                 when source_type_plugin_name = c_region_type_list_region                          then list_template_override_id',
'                 when source_type_plugin_name = c_region_type_breadcrumb_region                    then breadcrumb_template_id',
'                 when source_type_plugin_name in (c_region_type_sql_report, c_region_type_tabform) then report_template_id',
'               end,',
'               case',
'                 when source_type_plugin_name = c_region_type_list_region                          then ''LIST''',
'                 when source_type_plugin_name = c_region_type_breadcrumb_region                    then ''BREADCRUMB''',
'                 when source_type_plugin_name in (c_region_type_sql_report, c_region_type_tabform) then ''REPORT''',
'               end,',
'               component_template_options',
'          into l_component_id,',
'               l_primary_template_id,',
'               l_primary_template_options,',
'               l_secondary_template_id,',
'               l_secondary_template_type,',
'               l_secondary_template_options',
'          from apex_application_page_regions',
'         where static_id         = p_component_static_id',
'           and application_id    = p_application_id',
'           and workspace         = c_workspace;',
'        ',
'    elsif p_component_type = ''ITEM'' then',
'',
'        l_primary_template_type := ''FIELD'';',
'        select item_id,',
'               item_label_template_id,',
'               item_template_options',
'          into l_component_id,',
'               l_primary_template_id,',
'               l_primary_template_options',
'          from apex_application_page_items',
'         where item_name        = p_component_static_id',
'           and application_id   = p_application_id',
'           and workspace        = c_workspace;',
'',
'    elsif p_component_type = ''BUTTON'' then',
'',
'        l_primary_template_type := ''BUTTON'';',
'        select button_id,',
'               button_template_id,',
'               button_template_options',
'          into l_component_id,',
'               l_primary_template_id,',
'               l_primary_template_options',
'          from apex_application_page_buttons',
'         where button_static_id = p_component_static_id',
'           and application_id   = p_application_id',
'           and workspace        = c_workspace;',
'               ',
'    end if;',
'    ',
'    -- if there is a secondary template, get that one',
'    if l_secondary_template_id is not null then',
'        emit_template_templ_options (',
'            p_component_id   => l_component_id,',
'            p_application_id => p_application_id,',
'            p_theme_id       => l_theme_id,',
'            p_template_id    => l_secondary_template_id,',
'            p_template_type  => l_secondary_template_type,',
'            p_current_values => l_secondary_template_options );',
'    else',
'    -- if not, get the main template',
'        emit_template_templ_options (',
'            p_component_id   => l_component_id,',
'            p_application_id => p_application_id,',
'            p_theme_id       => l_theme_id,',
'            p_template_id    => l_primary_template_id,',
'            p_template_type  => l_primary_template_type,',
'            p_current_values => l_primary_template_options );',
'    end if;',
'end;',
'',
'function render',
'    ( p_region              apex_plugin.t_region',
'    , p_plugin              apex_plugin.t_plugin',
'    , p_is_printer_friendly boolean',
'    )',
'return apex_plugin.t_region_render_result',
'as',
'',
'    c_component_type                constant varchar2(1000) := p_region.attribute_01;',
'    c_component_static_id           constant varchar2(1000) := p_region.attribute_02;',
'',
'    c_region_id                     constant varchar2(1000) := p_region.static_id;',
'    c_preview_id                    constant varchar2(1000) := c_region_id || ''_preview'';',
'    c_preview_selector              constant varchar2(1000) := apex_escape.html(''#'' || c_preview_id);',
'begin',
'',
'    if apex_application.g_debug then',
'        apex_plugin_util.debug_region',
'            ( p_plugin => p_plugin',
'            , p_region => p_region',
'            );',
'    end if;',
'',
'    htp.p(''<div id="'' || apex_escape.html(c_preview_id) || ''" class="ut-PropertyEditor"></div>'');',
'',
'    apex_json.initialize_clob_output;',
'',
'    emit_component_templ_options',
'        ( p_application_id      => :app_id',
'        , p_page_id             => :app_page_id',
'        , p_component_type      => c_component_type',
'        , p_component_static_id => c_component_static_id',
'        );',
'',
'    apex_javascript.add_onload_code(',
'        p_code => ''apex.theme42demo.initPreviewTemplateOptions("'' || c_preview_selector || ''", ''',
'            || apex_json.get_clob_output(p_free => true) || '');''',
'    );',
'',
'    return null;',
'end;'))
,p_api_version=>1
,p_render_function=>'render'
,p_substitute_attributes=>true
,p_reference_id=>2941579137966323558
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
,p_files_version=>142
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(776877232102146559)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_prompt=>'Component Type'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'REGION'
,p_supported_ui_types=>'DESKTOP:JQM_SMARTPHONE'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
);
wwv_flow_api.create_plugin_attr_value(
 p_id=>wwv_flow_api.id(776877615486146561)
,p_plugin_attribute_id=>wwv_flow_api.id(776877232102146559)
,p_display_sequence=>10
,p_display_value=>'Region'
,p_return_value=>'REGION'
);
wwv_flow_api.create_plugin_attr_value(
 p_id=>wwv_flow_api.id(776878127670146565)
,p_plugin_attribute_id=>wwv_flow_api.id(776877232102146559)
,p_display_sequence=>20
,p_display_value=>'Item'
,p_return_value=>'ITEM'
);
wwv_flow_api.create_plugin_attr_value(
 p_id=>wwv_flow_api.id(776878621074146565)
,p_plugin_attribute_id=>wwv_flow_api.id(776877232102146559)
,p_display_sequence=>30
,p_display_value=>'Button'
,p_return_value=>'BUTTON'
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(776879198784146566)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_prompt=>'Static ID'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_is_translatable=>false
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>For regions and buttons, provide their Static ID.</p>',
'<p>For items, provide their regular names.</p>'))
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '3C73766720786D6C6E733D22687474703A2F2F7777772E77332E6F72672F323030302F737667222077696474683D223422206865696768743D2234223E3C706174682066696C6C3D22236666662220643D224D322E37383720312E3238374C312E363235';
wwv_flow_api.g_varchar2_table(2) := '20322E3434386C2D2E3431322D2E343131612E3132352E3132352030203120302D2E3137372E3137376C2E352E352E3038392E3033362E3038382D2E30333720312E32352D312E3235632E3034392D2E3034392E3034392D2E31323820302D2E31373773';
wwv_flow_api.g_varchar2_table(3) := '2D2E3132372D2E3034382D2E3137362E3030317A222F3E3C2F7376673E';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(776879554611146570)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_file_name=>'assets/checkbox-checked.svg'
,p_mime_type=>'image/svg+xml'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '3C73766720786D6C6E733D22687474703A2F2F7777772E77332E6F72672F323030302F737667222077696474683D2234303022206865696768743D22323030222076696577426F783D222D39392E3520302E352034303020323030223E3C706174682066';
wwv_flow_api.g_varchar2_table(2) := '696C6C3D22233434342220643D224D3135362E32352037332E37633020312E362D2E36313220332E322D312E38323520342E3432354C313030203133322E35352034352E3537352037382E313235632D322E3433382D322E3433382D322E3433382D362E';
wwv_flow_api.g_varchar2_table(3) := '3420302D382E38333773362E342D322E34333820382E38333720304C313030203131342E3836326C34352E3537352D34352E35373561362E32353320362E32353320302030203120382E383337203020362E323320362E323320302030203120312E3833';
wwv_flow_api.g_varchar2_table(4) := '3820342E3431337A222F3E3C2F7376673E';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(776879964009146571)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_file_name=>'assets/select-arrow.svg'
,p_mime_type=>'image/svg+xml'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '2E75742D50726F7065727479456469746F72207B0A20202F2A203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(2) := '0A2020202050726F7065727479202850726F706572747920456469746F722050726F70657274696573290A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(3) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A20202F2A2A0A202020202A2050726F706572747920436F6D706F6E656E740A202020202A0A202020202A205468697320697320612070726F70657274792074686174206973207573656420';
wwv_flow_api.g_varchar2_table(4) := '77697468696E2074686520636F6E74657874206F6620612070726F706572747920656469746F7220746F0A202020202A2070726F766964652061206C6162656C20616E6420696E707574206669656C642E0A202020202A0A202020202A204578616D706C';
wwv_flow_api.g_varchar2_table(5) := '652048544D4C3A0A202020202A0A202020202A203C64697620636C6173733D22612D50726F7065727479223E0A202020202A2020203C64697620636C6173733D22612D50726F70657274792D6C6162656C436F6E7461696E6572223E0A202020202A2020';
wwv_flow_api.g_varchar2_table(6) := '2020203C6C6162656C20636C6173733D22612D50726F70657274792D6C6162656C223E4C6162656C3C2F6C6162656C3E0A202020202A2020203C2F6469763E0A202020202A2020203C64697620636C6173733D22612D50726F70657274792D6669656C64';
wwv_flow_api.g_varchar2_table(7) := '436F6E7461696E6572223E0A202020202A20202020203C696E70757420747970653D22746578742220636C6173733D22612D50726F70657274792D6669656C64223E0A202020202A2020203C2F6469763E0A202020202A203C2F6469763E0A202020202A';
wwv_flow_api.g_varchar2_table(8) := '2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A2020202050726F706572747920457272';
wwv_flow_api.g_varchar2_table(9) := '6F720A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(10) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A2020202050726F7065727479205761726E696E670A202020202A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(11) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(12) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A202020204C6162656C20616E6420507265202F20506F737420546578740A202020202A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(13) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(14) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A2020202050726F7065727479204669656C64202D205573656420666F722070726F706572747920656469746F720A2020';
wwv_flow_api.g_varchar2_table(15) := '20202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2050726F70657274792045646974';
wwv_flow_api.g_varchar2_table(16) := '6F722053656C656374204C6973740A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A20202F';
wwv_flow_api.g_varchar2_table(17) := '2A205465787420417265610A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A20202F2A2A2A';
wwv_flow_api.g_varchar2_table(18) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020436F6D626F20426F78205374796C65730A202020';
wwv_flow_api.g_varchar2_table(19) := '202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(20) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020436865636B626F78202B20526164696F20427574746F6E730A202020202A2A2A2A';
wwv_flow_api.g_varchar2_table(21) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(22) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020436865636B626F782053706563696669630A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(23) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(24) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020526164696F2053706563696669630A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(25) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(26) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020596573202F204E6F20427574746F6E730A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(27) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(28) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020526164696F0A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(29) := '2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A202020205965';
wwv_flow_api.g_varchar2_table(30) := '73202F204E6F20526164696F730A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A2020';
wwv_flow_api.g_varchar2_table(31) := '2F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020537461636B65642050726F7065727469';
wwv_flow_api.g_varchar2_table(32) := '65730A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(33) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020486964652F53686F7720436C61737365730A202020202A2A2A2A2A';
wwv_flow_api.g_varchar2_table(34) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(35) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A202020205661726961626C65204669656C640A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(36) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(37) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020436865636B626F780A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(38) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(39) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020536574204974656D73205461626C650A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(40) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(41) := '2A2A2A2A2A2A0A2020202050726F706572747920456469746F7220696E204469616C6F67730A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(42) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(43) := '2A2A2A0A2020202050726F706572747920456469746F7220427574746F6E730A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(44) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A2020';
wwv_flow_api.g_varchar2_table(45) := '2020537461636B6564205374796C65730A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F';
wwv_flow_api.g_varchar2_table(46) := '0A20202F2A203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D0A202020204869676820436F6E7472617374204D';
wwv_flow_api.g_varchar2_table(47) := '6F64650A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A20202F2A0A202020202464697370';
wwv_flow_api.g_varchar2_table(48) := '6C61792D787878733A2036343070783B0A2020202024646973706C61792D7878733A2038303070783B0A2020202024646973706C61792D78733A203130323470783B0A2020202024646973706C61792D736D616C6C3A203132383070783B0A2020202024';
wwv_flow_api.g_varchar2_table(49) := '646973706C61792D6D656469756D3A203136383070783B0A2020202024646973706C61792D6C617267653A203139323070783B0A202020202A2F0A20202F2A203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(50) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D0A2020202050726F706572747920456469746F720A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(51) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A20202F2A2050726F706572747920456469746F722047726F7570730A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(52) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A20202F2A2A0A202020202A204D6F6469666965723A2069732D656D7074790A202020202A0A202020202A20557365642077';
wwv_flow_api.g_varchar2_table(53) := '68656E20616E206572726F72206D65737361676520697320646973706C617965640A202020202A2F0A20202F2A2046696C746572696E670A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(54) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A20202F2A2050726F70657274792046696C746572204E6F7420466F756E640A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(55) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A20202F2A0A2020202024646973706C61792D787878733A2036343070783B0A2020202024646973706C61792D7878733A20';
wwv_flow_api.g_varchar2_table(56) := '38303070783B0A2020202024646973706C61792D78733A203130323470783B0A2020202024646973706C61792D736D616C6C3A203132383070783B0A2020202024646973706C61792D6D656469756D3A203136383070783B0A2020202024646973706C61';
wwv_flow_api.g_varchar2_table(57) := '792D6C617267653A203139323070783B0A202020202A2F0A20202F2A203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(58) := '3D3D3D0A2020202050726F70657274792047726F7570202850726F706572747920456469746F722047726F757073290A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(59) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A20202F2A2A0A202020202A2050726F70657274792047726F757020436F6D706F6E656E740A202020202A0A202020202A205468697320697320612067726F7570696E67206F66';
wwv_flow_api.g_varchar2_table(60) := '206F6E65206F72206D6F72652070726F7065727469657320696E2074686520636F6E74657874206F6620612070726F70657274790A202020202A20656469746F722E205468697320616C6C6F777320757320746F20636F6E76656E69656E746C79206772';
wwv_flow_api.g_varchar2_table(61) := '6F7570206F75722070726F7065727469657320616E64207573650A202020202A2070737565646F2073656C6563746F727320746F206170706C79207374796C657320746F206669727374202F206C61737420656C656D656E74732077697468696E207468';
wwv_flow_api.g_varchar2_table(62) := '652067726F75702E0A202020202A0A202020202A204578616D706C652048544D4C3A0A202020202A0A202020202A203C64697620636C6173733D22612D50726F706572747947726F7570223E0A202020202A2020203C64697620636C6173733D22612D50';
wwv_flow_api.g_varchar2_table(63) := '726F706572747947726F75702D6974656D223E0A202020202A20202020205B50726F70657274792020486572655D0A202020202A2020203C2F6469763E0A202020202A2020203C64697620636C6173733D22612D50726F706572747947726F75702D6974';
wwv_flow_api.g_varchar2_table(64) := '656D223E0A202020202A20202020205B50726F70657274792020486572655D0A202020202A2020203C2F6469763E0A202020202A2020203C64697620636C6173733D22612D50726F706572747947726F75702D6974656D223E0A202020202A2020202020';
wwv_flow_api.g_varchar2_table(65) := '5B50726F70657274792020486572655D0A202020202A2020203C2F6469763E0A202020202A203C2F6469763E0A202020202A2F0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479207B0A2020706F736974696F6E3A2072';
wwv_flow_api.g_varchar2_table(66) := '656C61746976653B0A2020646973706C61793A207461626C653B0A20206D617267696E3A20303B0A202070616464696E673A20303B0A202077696474683A20313030253B0A20207461626C652D6C61796F75743A206175746F3B0A7D0A2E75742D50726F';
wwv_flow_api.g_varchar2_table(67) := '7065727479456469746F72202E612D50726F7065727479202E612D49636F6E2E69636F6E2D7265717569726564207B0A2020646973706C61793A206E6F6E653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6275';
wwv_flow_api.g_varchar2_table(68) := '74746F6E436F6E7461696E65722C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C436F6E7461696E65722C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D756E6974436F6E';
wwv_flow_api.g_varchar2_table(69) := '7461696E6572207B0A2020646973706C61793A207461626C652D63656C6C3B0A2020766572746963616C2D616C69676E3A206D6964646C653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E';
wwv_flow_api.g_varchar2_table(70) := '7461696E65722C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C436F6E7461696E65722C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E6572';
wwv_flow_api.g_varchar2_table(71) := '2C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D756E6974436F6E7461696E6572207B0A202070616464696E673A20347078203870783B0A7D0A406D65646961206F6E6C792073637265656E20616E6420286D61782D77';
wwv_flow_api.g_varchar2_table(72) := '696474683A2031303234707829207B0A20202E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E65722C0A20202E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C';
wwv_flow_api.g_varchar2_table(73) := '6162656C436F6E7461696E65722C0A20202E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722C0A20202E75742D50726F7065727479456469746F72202E612D50726F70657274792D756E69';
wwv_flow_api.g_varchar2_table(74) := '74436F6E7461696E6572207B0A2020202070616464696E673A20327078203870783B0A20207D0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C436F6E7461696E6572207B0A202070616464696E672D72';
wwv_flow_api.g_varchar2_table(75) := '696768743A20303B0A20206D696E2D77696474683A2031313270783B0A7D0A2E75742D50726F7065727479456469746F72202374656D706C6174654F7074696F6E73446C675045202E612D50726F70657274792D6C6162656C436F6E7461696E6572207B';
wwv_flow_api.g_varchar2_table(76) := '0A20206D696E2D77696474683A2031343470783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274793A6E6F74282E612D50726F70657274792D2D7374';
wwv_flow_api.g_varchar2_table(77) := '61636B656429202E612D50726F70657274792D6C6162656C436F6E7461696E6572207B0A2020646973706C61793A207461626C652D726F773B0A202077696474683A20313030253B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F';
wwv_flow_api.g_varchar2_table(78) := '70657274792D6669656C64436F6E7461696E6572207B0A2020646973706C61793A207461626C652D63656C6C3B0A202077696474683A20313030253B0A2020766572746963616C2D616C69676E3A206D6964646C653B0A7D0A2E75742D50726F70657274';
wwv_flow_api.g_varchar2_table(79) := '79456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D636F6D626F426F78207B0A202070616464696E672D72696768743A20302021696D706F7274616E743B0A7D0A2E75742D50726F7065727479456469746F72202E';
wwv_flow_api.g_varchar2_table(80) := '612D50726F70657274792D627574746F6E436F6E7461696E65722D2D636F6D626F426F78202E612D427574746F6E207B0A20206D617267696E2D6C6566743A202D3170783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F706572';
wwv_flow_api.g_varchar2_table(81) := '74792D636F6C6F7250726576696577207B0A2020646973706C61793A20626C6F636B3B0A202077696474683A20313270783B0A20206865696768743A20313270783B0A2020626F726465722D7261646975733A20313030253B0A7D0A2E75742D50726F70';
wwv_flow_api.g_varchar2_table(82) := '65727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D636F6C6F725069636B6572207B0A202070616464696E672D72696768743A20302021696D706F7274616E743B0A7D0A2E75742D50726F70657274794564';
wwv_flow_api.g_varchar2_table(83) := '69746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D636F6C6F725069636B6572202E612D50726F70657274792D6669656C64207B0A202070616464696E672D6C6566743A20323470783B0A2020626F726465722D746F702D';
wwv_flow_api.g_varchar2_table(84) := '72696768742D7261646975733A20302021696D706F7274616E743B0A2020626F726465722D626F74746F6D2D72696768742D7261646975733A20302021696D706F7274616E743B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70';
wwv_flow_api.g_varchar2_table(85) := '657274792D6669656C64436F6E7461696E65722D2D636F6C6F725069636B6572202E612D50726F70657274792D636F6C6F7250726576696577207B0A2020706F736974696F6E3A206162736F6C7574653B0A20206D617267696E3A203670783B0A202070';
wwv_flow_api.g_varchar2_table(86) := '6F696E7465722D6576656E74733A206E6F6E653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E65722D2D636F6C6F725069636B6572202E612D427574746F6E207B0A20206D6172';
wwv_flow_api.g_varchar2_table(87) := '67696E2D6C6566743A202D3170783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D756E6974436F6E7461696E6572207B0A202070616464696E672D6C6566743A20302021696D706F7274616E743B0A2020776869';
wwv_flow_api.g_varchar2_table(88) := '74652D73706163653A206E6F777261703B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6572726F72202E69636F6E2D6572726F72207B0A20206D617267696E2D72696768743A203470783B0A7D0A2E7574';
wwv_flow_api.g_varchar2_table(89) := '2D50726F7065727479456469746F72202E612D50726F70657274792E69732D7761726E696E67202E69636F6E2D7761726E696E67207B0A20206D617267696E2D72696768743A203470783B0A7D0A2E75742D50726F7065727479456469746F72202E612D';
wwv_flow_api.g_varchar2_table(90) := '50726F70657274792D6C6162656C2C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D734865616465722D6865616465722C0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(91) := '2D756E6974207B0A202070616464696E673A2034707820303B0A2020666F6E742D73697A653A20313270783B0A20206C696E652D6865696768743A20313670783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D63';
wwv_flow_api.g_varchar2_table(92) := '6865636B626F782D6C6162656C2C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F207B0A2020666F6E742D73697A653A20313270783B0A20206C696E652D6865696768743A20313670783B0A7D0A2E75742D';
wwv_flow_api.g_varchar2_table(93) := '50726F7065727479456469746F72202E612D50726F70657274792D756E6974207B0A2020666F6E742D73697A653A20313170783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C2D2D7769746849636F';
wwv_flow_api.g_varchar2_table(94) := '6E207B0A202070616464696E673A2034707820303B0A20206C696E652D6865696768743A20313670783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64207B0A202070616464696E673A203470783B0A';
wwv_flow_api.g_varchar2_table(95) := '20206D696E2D6865696768743A20323470783B0A2020666F6E742D73697A653A20313270783B0A20206C696E652D6865696768743A20313670783B0A2020626F726465722D7261646975733A203270783B0A7D0A2E75742D50726F706572747945646974';
wwv_flow_api.g_varchar2_table(96) := '6F72202E612D50726F70657274792D6669656C643A666F637573207B0A20206F75746C696E653A206E6F6E653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D7661726961626C65202E612D49636F6E2E69';
wwv_flow_api.g_varchar2_table(97) := '636F6E2D7661726961626C65207B0A20206D617267696E2D72696768743A203470783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D7661726961626C65202E612D50726F70657274792D6669656C64207B';
wwv_flow_api.g_varchar2_table(98) := '0A2020626F726465722D7261646975733A203270783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C642D2D73656C656374207B0A20206F766572666C6F773A2068696464656E3B0A202070616464696E';
wwv_flow_api.g_varchar2_table(99) := '672D72696768743A20333070783B0A2020746578742D696E64656E743A20302E303170783B0A2020746578742D6F766572666C6F773A202720273B0A20206261636B67726F756E642D706F736974696F6E3A203130302520303B0A20206261636B67726F';
wwv_flow_api.g_varchar2_table(100) := '756E642D73697A653A203332707820323470783B0A20206261636B67726F756E642D7265706561743A206E6F2D7265706561743B0A20202D7765626B69742D617070656172616E63653A206E6F6E653B0A20202D6D6F7A2D617070656172616E63653A20';
wwv_flow_api.g_varchar2_table(101) := '6E6F6E653B0A2020617070656172616E63653A206E6F6E653B0A7D0A2E75742D50726F7065727479456469746F7220626F64793A6E6F74283A2D6D6F7A2D68616E646C65722D626C6F636B656429202E612D50726F70657274792D6669656C642D2D7365';
wwv_flow_api.g_varchar2_table(102) := '6C656374207B0A202070616464696E673A20327078203234707820327078203270783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C642D2D74657874617265612C0A2E75742D50726F70657274794564';
wwv_flow_api.g_varchar2_table(103) := '69746F7220626F6479202E75692D776964676574202E612D50726F70657274792D6669656C642D2D7465787461726561207B0A202070616464696E673A203470783B0A20206D61782D6865696768743A2033323070783B0A20206865696768743A206175';
wwv_flow_api.g_varchar2_table(104) := '746F3B0A2020666F6E742D73697A653A20313170783B0A2020666F6E742D66616D696C793A2053464D6F6E6F2D526567756C61722C204D656E6C6F2C204D6F6E61636F2C20436F6E736F6C61732C20224C696265726174696F6E204D6F6E6F222C202243';
wwv_flow_api.g_varchar2_table(105) := '6F7572696572204E6577222C206D6F6E6F73706163653B0A20206C696E652D6865696768743A20313470783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726561644F6E6C79207B0A2020666F6E742D77656967';
wwv_flow_api.g_varchar2_table(106) := '68743A20626F6C643B0A2020666F6E742D73697A653A20313270783B0A20206C696E652D6865696768743A20323B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D735461626C652D686561646572';
wwv_flow_api.g_varchar2_table(107) := '207B0A2020666F6E742D7765696768743A206E6F726D616C3B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D735461626C65202E612D50726F70657274792D6669656C64207B0A2020626F726465';
wwv_flow_api.g_varchar2_table(108) := '722D746F702D72696768742D7261646975733A20303B0A2020626F726465722D626F74746F6D2D72696768742D7261646975733A20303B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461';
wwv_flow_api.g_varchar2_table(109) := '696E65722D2D636F6D626F426F78202E612D427574746F6E207B0A20206D617267696E2D6C6566743A203870783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D';
wwv_flow_api.g_varchar2_table(110) := '22636865636B626F78225D2C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D207B0A2020706F736974696F6E3A206162736F6C7574653B0A20206F766572';
wwv_flow_api.g_varchar2_table(111) := '666C6F773A2068696464656E3B0A2020636C69703A20726563742830203020302030293B0A20206D617267696E3A202D3170783B0A202070616464696E673A20303B0A202077696474683A203170783B0A20206865696768743A203170783B0A2020626F';
wwv_flow_api.g_varchar2_table(112) := '726465723A20303B0A20202F2A2044697361626C65642053746174650A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(113) := '3D3D3D3D3D3D3D202A2F0A20202F2A20466F6375730A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(114) := '202A2F0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C2C0A2E75742D50726F7065727479456469746F72202E612D';
wwv_flow_api.g_varchar2_table(115) := '50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C207B0A2020706F736974696F6E3A2072656C61746976653B0A202070616464696E672D72696768743A203870783B0A202070616464696E672D6C';
wwv_flow_api.g_varchar2_table(116) := '6566743A20323070783B0A2020637572736F723A20706F696E7465723B0A7D0A2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F7822';
wwv_flow_api.g_varchar2_table(117) := '5D202B206C6162656C2C0A2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C207B0A202070616464696E672D6C6566743A';
wwv_flow_api.g_varchar2_table(118) := '203870783B0A202070616464696E672D72696768743A20323070783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C616265';
wwv_flow_api.g_varchar2_table(119) := '6C3A6265666F72652C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A61667465722C0A2E75742D50726F7065727479';
wwv_flow_api.g_varchar2_table(120) := '456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C3A6265666F72652C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E';
wwv_flow_api.g_varchar2_table(121) := '7075745B747970653D22726164696F225D202B206C6162656C3A6166746572207B0A2020706F736974696F6E3A206162736F6C7574653B0A2020746F703A203370783B0A20206C6566743A20303B0A2020646973706C61793A20626C6F636B3B0A202077';
wwv_flow_api.g_varchar2_table(122) := '696474683A20313470783B0A20206865696768743A20313470783B0A2020636F6E74656E743A2027273B0A20202D7765626B69742D7472616E736974696F6E3A20302E31323573206F70616369747920656173653B0A20207472616E736974696F6E3A20';
wwv_flow_api.g_varchar2_table(123) := '302E31323573206F70616369747920656173653B0A7D0A2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C';
wwv_flow_api.g_varchar2_table(124) := '3A6265666F72652C0A2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A61667465722C0A2E75742D5072';
wwv_flow_api.g_varchar2_table(125) := '6F7065727479456469746F72202E752D52544C202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C3A6265666F72652C0A2E75742D50726F7065727479456469746F72202E752D52544C20';
wwv_flow_api.g_varchar2_table(126) := '2E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C3A6166746572207B0A20206C6566743A206175746F3B0A202072696768743A20303B0A7D0A2E75742D50726F7065727479456469746F72';
wwv_flow_api.g_varchar2_table(127) := '202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A6265666F72652C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E';
wwv_flow_api.g_varchar2_table(128) := '7075745B747970653D22726164696F225D202B206C6162656C3A6265666F7265207B0A20207A2D696E6465783A2039303B0A2020626F726465723A2031707820736F6C69643B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065';
wwv_flow_api.g_varchar2_table(129) := '7274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A61667465722C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D22';
wwv_flow_api.g_varchar2_table(130) := '726164696F225D202B206C6162656C3A6166746572207B0A20207A2D696E6465783A203130303B0A20206F7061636974793A20303B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075';
wwv_flow_api.g_varchar2_table(131) := '745B747970653D22636865636B626F78225D3A64697361626C6564202B206C6162656C2C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D3A64697361626C';
wwv_flow_api.g_varchar2_table(132) := '6564202B206C6162656C207B0A20206F7061636974793A20302E353B0A2020637572736F723A2064656661756C743B0A2020706F696E7465722D6576656E74733A206E6F6E653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70';
wwv_flow_api.g_varchar2_table(133) := '657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A64697361626C6564202B206C6162656C3A6265666F72652C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D69';
wwv_flow_api.g_varchar2_table(134) := '6E7075745B747970653D22726164696F225D3A64697361626C6564202B206C6162656C3A6265666F7265207B0A20206F7061636974793A20302E353B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B62';
wwv_flow_api.g_varchar2_table(135) := '6F782D696E7075745B747970653D22636865636B626F78225D3A686F7665723A636865636B6564202B206C6162656C3A61667465722C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E707574';
wwv_flow_api.g_varchar2_table(136) := '5B747970653D22636865636B626F78225D3A666F6375733A636865636B6564202B206C6162656C3A61667465722C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D2272616469';
wwv_flow_api.g_varchar2_table(137) := '6F225D3A686F7665723A636865636B6564202B206C6162656C3A61667465722C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D3A666F6375733A63686563';
wwv_flow_api.g_varchar2_table(138) := '6B6564202B206C6162656C3A6166746572207B0A20206F7061636974793A20313B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D207B';
wwv_flow_api.g_varchar2_table(139) := '0A20202F2A20556E636865636B65640A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A2020';
wwv_flow_api.g_varchar2_table(140) := '2F2A20436865636B65640A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A7D0A2E75742D50';
wwv_flow_api.g_varchar2_table(141) := '726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A6265666F7265207B0A2020626F726465722D7261646975733A203270783B0A7D0A2E';
wwv_flow_api.g_varchar2_table(142) := '75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A6166746572207B0A20206261636B67726F756E642D706F736974696F6E3A';
wwv_flow_api.g_varchar2_table(143) := '203530253B0A20206261636B67726F756E642D73697A653A20313670783B0A20206261636B67726F756E642D7265706561743A206E6F2D7265706561743B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D63686563';
wwv_flow_api.g_varchar2_table(144) := '6B626F782D696E7075745B747970653D22636865636B626F78225D3A696E64657465726D696E617465202B206C6162656C3A6166746572207B0A20206F7061636974793A20313B0A20206261636B67726F756E642D696D6167653A206E6F6E653B0A2020';
wwv_flow_api.g_varchar2_table(145) := '77696474683A203870783B0A20206865696768743A203270783B0A2020626F726465722D7261646975733A203270783B0A20206D617267696E3A20367078203370783B0A20202D7765626B69742D7472616E73666F726D3A207363616C6528302E373529';
wwv_flow_api.g_varchar2_table(146) := '3B0A20207472616E73666F726D3A207363616C6528302E3735293B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A636865636B6564';
wwv_flow_api.g_varchar2_table(147) := '202B206C6162656C3A61667465722C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A636865636B6564202B206C6162656C3A6265666F72';
wwv_flow_api.g_varchar2_table(148) := '65207B0A20206F7061636974793A20313B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D207B0A20202F2A20556E636865636B65640A202020203D3D';
wwv_flow_api.g_varchar2_table(149) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A20202F2A20436865636B65640A202020203D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(150) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065';
wwv_flow_api.g_varchar2_table(151) := '7274792D726164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C3A6265666F7265207B0A2020626F726465722D7261646975733A20313670783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F706572';
wwv_flow_api.g_varchar2_table(152) := '74792D726164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C3A6166746572207B0A20206D617267696E3A203570783B0A202077696474683A203470783B0A20206865696768743A203470783B0A2020626F726465722D7261';
wwv_flow_api.g_varchar2_table(153) := '646975733A20313030253B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D3A636865636B6564202B206C6162656C3A6166746572207B0A20206F7061';
wwv_flow_api.g_varchar2_table(154) := '636974793A20313B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574207B0A20207061646469';
wwv_flow_api.g_varchar2_table(155) := '6E673A2030203470783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F207B0A20206D617267696E2D7269676874';
wwv_flow_api.g_varchar2_table(156) := '3A202D3170783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E707574207B0A20202F2A20556E63686563';
wwv_flow_api.g_varchar2_table(157) := '6B6564202A2F0A20202F2A20436865636B6564202A2F0A20202F2A20466F6375736564202A2F0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F';
wwv_flow_api.g_varchar2_table(158) := '70657274792D726164696F2D696E707574202B206C6162656C207B0A202070616464696E673A20327078203870783B0A20202D7765626B69742D7472616E736974696F6E3A206261636B67726F756E642D636F6C6F7220302E31357320656173653B0A20';
wwv_flow_api.g_varchar2_table(159) := '207472616E736974696F6E3A206261636B67726F756E642D636F6C6F7220302E31357320656173653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D';
wwv_flow_api.g_varchar2_table(160) := '50726F70657274792D726164696F2D696E707574202B206C6162656C3A6265666F72652C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274';
wwv_flow_api.g_varchar2_table(161) := '792D726164696F2D696E707574202B206C6162656C3A6166746572207B0A2020636F6E74656E743A20696E697469616C3B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F';
wwv_flow_api.g_varchar2_table(162) := '6E536574202E612D50726F70657274792D726164696F2D696E7075743A636865636B6564202B206C6162656C207B0A2020666F6E742D7765696768743A20626F6C643B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(163) := '2D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A666F637573202B206C6162656C207B0A20207A2D696E6465783A20313B0A20206F75746C696E653A206E6F6E653B0A2020626F7264';
wwv_flow_api.g_varchar2_table(164) := '65722D7261646975733A203270783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75703A666F637573207B0A20206F75746C696E653A206E6F6E653B0A7D0A2E75742D50726F706572747945';
wwv_flow_api.g_varchar2_table(165) := '6469746F72202E612D50726F70657274792D726164696F207B0A2020646973706C61793A20696E6C696E652D626C6F636B3B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E707574207B0A2020';
wwv_flow_api.g_varchar2_table(166) := '646973706C61793A20696E6C696E652D626C6F636B3B0A20206D617267696E3A203270783B0A202077696474683A20313670783B0A20206865696768743A20313670783B0A2020766572746963616C2D616C69676E3A20746F703B0A7D0A2E75742D5072';
wwv_flow_api.g_varchar2_table(167) := '6F7065727479456469746F72202E612D50726F70657274792D726164696F2D6C6162656C207B0A2020646973706C61793A20696E6C696E652D626C6F636B3B0A202070616464696E673A203270783B0A2020766572746963616C2D616C69676E3A20746F';
wwv_flow_api.g_varchar2_table(168) := '703B0A2020666F6E742D73697A653A20313270783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D726164696F47726F7570207B0A202070616464696E672D746F703A2036';
wwv_flow_api.g_varchar2_table(169) := '70783B0A202070616464696E672D626F74746F6D3A203670783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E5365743A6265666F72652C0A2E75742D50726F706572';
wwv_flow_api.g_varchar2_table(170) := '7479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E5365743A6166746572207B0A2020646973706C61793A207461626C653B0A2020636F6E74656E743A2027273B0A7D0A2E75742D50726F70657274794564';
wwv_flow_api.g_varchar2_table(171) := '69746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E5365743A6166746572207B0A2020636C6561723A20626F74683B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F';
wwv_flow_api.g_varchar2_table(172) := '47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F207B0A2020666C6F61743A206C6566743B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574';
wwv_flow_api.g_varchar2_table(173) := '746F6E536574202E612D50726F70657274792D726164696F2D696E707574207B0A2020706F736974696F6E3A206162736F6C7574653B0A20206F766572666C6F773A2068696464656E3B0A2020636C69703A20726563742830203020302030293B0A2020';
wwv_flow_api.g_varchar2_table(174) := '6D617267696E3A202D3170783B0A202070616464696E673A20303B0A202077696474683A203170783B0A20206865696768743A203170783B0A2020626F726465723A20303B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F706572';
wwv_flow_api.g_varchar2_table(175) := '74792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A64697361626C6564202B206C6162656C207B0A20206F7061636974793A20302E353B0A7D0A2E75742D50726F70657274794564';
wwv_flow_api.g_varchar2_table(176) := '69746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E707574202B206C6162656C207B0A20206D696E2D77696474683A20343870783B0A2020746578742D61';
wwv_flow_api.g_varchar2_table(177) := '6C69676E3A2063656E7465723B0A20206C696E652D6865696768743A20323070783B0A2020626F726465722D7261646975733A203270783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F7570';
wwv_flow_api.g_varchar2_table(178) := '2D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E707574202B206C6162656C202E612D49636F6E207B0A20206D617267696E3A203270783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274';
wwv_flow_api.g_varchar2_table(179) := '792D2D737461636B6564207B0A2020706F736974696F6E3A2072656C61746976653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6C6162656C436F6E746169';
wwv_flow_api.g_varchar2_table(180) := '6E65722C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6669656C64436F6E7461696E6572207B0A2020646973706C61793A20626C6F636B3B0A7D0A2E75742D5072';
wwv_flow_api.g_varchar2_table(181) := '6F7065727479456469746F72202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6C6162656C436F6E7461696E6572207B0A20206D617267696E2D72696768743A20363470783B0A202070616464696E672D626F74746F';
wwv_flow_api.g_varchar2_table(182) := '6D3A20303B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6669656C64436F6E7461696E6572207B0A202070616464696E672D746F703A20303B0A7D0A2E7574';
wwv_flow_api.g_varchar2_table(183) := '2D50726F7065727479456469746F72202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E6572207B0A2020706F736974696F6E3A206162736F6C7574653B0A2020746F703A20303B0A20';
wwv_flow_api.g_varchar2_table(184) := '2072696768743A20303B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E6572202B202E612D50726F70657274792D6669656C64';
wwv_flow_api.g_varchar2_table(185) := '436F6E7461696E6572207B0A202070616464696E672D746F703A203470783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E65';
wwv_flow_api.g_varchar2_table(186) := '72202E612D427574746F6E2D2D717569636B5069636B207B0A20206D617267696E2D6C6566743A203870783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D7363726F6C6C61626C65207B0A2020646973706C61';
wwv_flow_api.g_varchar2_table(187) := '793A20626C6F636B3B0A20206F766572666C6F773A206175746F3B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C436F6E7461696E65722D2D77697468427574746F6E73207B0A2020646973706C6179';
wwv_flow_api.g_varchar2_table(188) := '3A207461626C652D63656C6C3B0A20207461626C652D6C61796F75743A206175746F3B0A202070616464696E672D626F74746F6D3A203870783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C436F6E';
wwv_flow_api.g_varchar2_table(189) := '7461696E65722D2D68696464656E4C6162656C207B0A202070616464696E673A20303B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E6572207B0A202070616464696E672D6C6566';
wwv_flow_api.g_varchar2_table(190) := '743A20302021696D706F7274616E743B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E65722D2D70756C6C5269676874207B0A2020666C6F61743A2072696768743B0A7D0A2E7574';
wwv_flow_api.g_varchar2_table(191) := '2D50726F7065727479456469746F72202E612D50726F70657274792E69732D6368616E676564202E612D50726F70657274792D6C6162656C436F6E7461696E65723A6265666F7265207B0A2020706F736974696F6E3A206162736F6C7574653B0A202074';
wwv_flow_api.g_varchar2_table(192) := '6F703A203170783B0A2020626F74746F6D3A20303B0A20206C6566743A203170783B0A2020646973706C61793A20696E6C696E652D626C6F636B3B0A202077696474683A203370783B0A2020636F6E74656E743A2027273B0A20206F7061636974793A20';
wwv_flow_api.g_varchar2_table(193) := '302E353B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6368616E6765643A686F766572202E612D50726F70657274792D6C6162656C436F6E7461696E65723A6265666F72652C0A2E75742D50726F706572';
wwv_flow_api.g_varchar2_table(194) := '7479456469746F72202E612D50726F70657274792E69732D6368616E6765642E69732D666F6375736564202E612D50726F70657274792D6C6162656C436F6E7461696E65723A6265666F7265207B0A20206F7061636974793A20313B0A7D0A2E75742D50';
wwv_flow_api.g_varchar2_table(195) := '726F7065727479456469746F72202E612D50726F70657274792D6C6162656C2C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D756E6974207B0A2020646973706C61793A20626C6F636B3B0A20202D6D732D746578742D';
wwv_flow_api.g_varchar2_table(196) := '6F766572666C6F773A20656C6C69707369733B0A2020746578742D6F766572666C6F773A20656C6C69707369733B0A20206F766572666C6F773A2068696464656E3B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D';
wwv_flow_api.g_varchar2_table(197) := '6669656C64207B0A2020646973706C61793A20626C6F636B3B0A202077696474683A20313030253B0A20206261636B67726F756E642D636C69703A20626F726465722D626F783B0A2020626F726465723A203020736F6C69643B0A7D0A2E75742D50726F';
wwv_flow_api.g_varchar2_table(198) := '7065727479456469746F72202E612D50726F70657274792D6669656C642D2D7465787461726561207B0A20206D696E2D6865696768743A20343870783B0A2020666F6E742D66616D696C793A2053464D6F6E6F2D526567756C61722C204D656E6C6F2C20';
wwv_flow_api.g_varchar2_table(199) := '4D6F6E61636F2C20436F6E736F6C61732C20224C696265726174696F6E204D6F6E6F222C2022436F7572696572204E6577222C206D6F6E6F73706163653B0A2020726573697A653A20766572746963616C3B0A7D0A2E75742D50726F7065727479456469';
wwv_flow_api.g_varchar2_table(200) := '746F72202E612D50726F70657274792E6A732D73686F77416C6C2C0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702E6A732D73686F77416C6C207B0A2020646973706C61';
wwv_flow_api.g_varchar2_table(201) := '793A206E6F6E653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722E6A732D73686F77416C6C202E612D50726F70657274792E6A732D73686F77416C6C2C0A2E75742D50726F7065727479456469746F';
wwv_flow_api.g_varchar2_table(202) := '72202E612D50726F7065727479456469746F722E6A732D73686F77416C6C202E612D50726F7065727479456469746F722D70726F706572747947726F75702E6A732D73686F77416C6C207B0A2020646973706C61793A20626C6F636B3B0A7D0A2E75742D';
wwv_flow_api.g_varchar2_table(203) := '50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461636B65642E6A732D73686F77416C6C202E612D50726F70657274792E6A732D73686F77416C6C207B0A2020646973706C61793A207461626C653B0A7D0A2E75';
wwv_flow_api.g_varchar2_table(204) := '742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F7847726F75703A666F637573207B0A20206F75746C696E653A206E6F6E653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(205) := '2D636865636B626F782D696E707574207B0A2020646973706C61793A20696E6C696E652D626C6F636B3B0A20206D617267696E3A203270783B0A202077696474683A20313670783B0A20206865696768743A20313670783B0A2020766572746963616C2D';
wwv_flow_api.g_varchar2_table(206) := '616C69676E3A20746F703B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D6C6162656C207B0A2020646973706C61793A20696E6C696E652D626C6F636B3B0A202070616464696E673A203270';
wwv_flow_api.g_varchar2_table(207) := '783B0A2020766572746963616C2D616C69676E3A20746F703B0A2020666F6E742D73697A653A20313270783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D735461626C65207B0A202077696474';
wwv_flow_api.g_varchar2_table(208) := '683A20313030253B0A2020626F726465722D73706163696E673A20303B0A2020626F726465722D636F6C6C617073653A20636F6C6C617073653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D73';
wwv_flow_api.g_varchar2_table(209) := '5461626C65207464207B0A202070616464696E672D626F74746F6D3A203470783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D735461626C652074723A6C6173742D6368696C64207464207B0A';
wwv_flow_api.g_varchar2_table(210) := '202070616464696E672D626F74746F6D3A20303B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D734865616465722D686561646572207B0A2020746578742D616C69676E3A206C6566743B0A7D0A';
wwv_flow_api.g_varchar2_table(211) := '2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D735461626C652D72656D6F7665436F6C207B0A202077696474683A20343070783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70';
wwv_flow_api.g_varchar2_table(212) := '657274792D627574746F6E207B0A20202D2D612D627574746F6E2D70616464696E672D793A203670783B0A202077696474683A20313030253B0A202077686974652D73706163653A206E6F726D616C3B0A7D0A2E75742D50726F7065727479456469746F';
wwv_flow_api.g_varchar2_table(213) := '72202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D6C6162656C436F6E7461696E6572202E612D50726F70657274792D6C6162656C207B0A202070616464696E672D72696768743A20313270783B0A20';
wwv_flow_api.g_varchar2_table(214) := '2070616464696E672D626F74746F6D3A203270783B0A202070616464696E672D6C6566743A20313270783B0A2020666F6E742D73697A653A20313170783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F';
wwv_flow_api.g_varchar2_table(215) := '722D2D737461636B6564202E612D50726F70657274792D6669656C64436F6E7461696E65722C0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D627574';
wwv_flow_api.g_varchar2_table(216) := '746F6E436F6E7461696E6572207B0A202070616464696E672D746F703A20303B0A202070616464696E672D626F74746F6D3A203870783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D73746163';
wwv_flow_api.g_varchar2_table(217) := '6B6564202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E6572207B0A202070616464696E672D746F703A203470783B0A202070616464696E672D626F74746F6D3A203470783B0A7D0A';
wwv_flow_api.g_varchar2_table(218) := '2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6C6162656C436F6E7461696E6572202E612D50726F';
wwv_flow_api.g_varchar2_table(219) := '70657274792D6C6162656C207B0A202070616464696E673A2034707820303B0A7D0A2E75742D50726F7065727479456469746F72202E752D48434D202E612D50726F70657274792D6669656C64207B0A2020626F726465723A2031707820736F6C696420';
wwv_flow_api.g_varchar2_table(220) := '21696D706F7274616E743B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D77726170706572202E612D50726F7065727479456469746F722D70726F706572747947726F75703A66697273742D636869';
wwv_flow_api.g_varchar2_table(221) := '6C64207B0A20206D617267696E2D746F703A203870783B0A7D0A2E75742D50726F7065727479456469746F72202E75692D6469616C6F67202E612D50726F7065727479456469746F72207B0A20206F766572666C6F773A206175746F3B0A20206D61782D';
wwv_flow_api.g_varchar2_table(222) := '6865696768743A2034303070783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F7570207B0A2020646973706C61793A20626C6F636B3B0A20206261636B67726F756E64';
wwv_flow_api.g_varchar2_table(223) := '2D636C69703A2070616464696E672D626F783B0A20202D7765626B69742D7472616E736974696F6E3A206261636B67726F756E642D636F6C6F7220302E317320656173652C202D7765626B69742D626F782D736861646F7720302E317320656173653B0A';
wwv_flow_api.g_varchar2_table(224) := '20207472616E736974696F6E3A206261636B67726F756E642D636F6C6F7220302E317320656173652C202D7765626B69742D626F782D736861646F7720302E317320656173653B0A20207472616E736974696F6E3A206261636B67726F756E642D636F6C';
wwv_flow_api.g_varchar2_table(225) := '6F7220302E317320656173652C20626F782D736861646F7720302E317320656173653B0A20207472616E736974696F6E3A206261636B67726F756E642D636F6C6F7220302E317320656173652C20626F782D736861646F7720302E317320656173652C20';
wwv_flow_api.g_varchar2_table(226) := '2D7765626B69742D626F782D736861646F7720302E317320656173653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702E69732D636F6C6C6170736564202E612D50';
wwv_flow_api.g_varchar2_table(227) := '726F7065727479456469746F722D70726F706572747947726F75702D686561646572207B0A2020626F726465722D626F74746F6D3A206E6F6E653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70';
wwv_flow_api.g_varchar2_table(228) := '726F706572747947726F75702E69732D636F6C6C6170736564202E612D50726F7065727479456469746F722D70726F706572747947726F75702D626F6479207B0A2020646973706C61793A206E6F6E653B0A7D0A2E75742D50726F706572747945646974';
wwv_flow_api.g_varchar2_table(229) := '6F72202E612D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75703A66697273742D6368696C64207B0A20206D617267696E2D746F703A203470783B0A7D0A2E75742D50726F7065727479';
wwv_flow_api.g_varchar2_table(230) := '456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572207B0A20206D617267696E2D746F703A203470783B0A202070616464696E673A2031327078203870783B0A2020626F726465722D776964';
wwv_flow_api.g_varchar2_table(231) := '74683A20303B0A20202D7765626B69742D7472616E736974696F6E3A206D617267696E20302E317320656173653B0A20207472616E736974696F6E3A206D617267696E20302E317320656173653B0A7D0A406D65646961206F6E6C792073637265656E20';
wwv_flow_api.g_varchar2_table(232) := '616E6420286D61782D77696474683A2031303234707829207B0A20202E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572207B0A2020202070616464696E672D';
wwv_flow_api.g_varchar2_table(233) := '746F703A203470783B0A2020202070616464696E672D626F74746F6D3A203470783B0A20207D0A7D0A406D65646961206F6E6C792073637265656E20616E6420286D696E2D77696474683A203130323570782920616E6420286D61782D77696474683A20';
wwv_flow_api.g_varchar2_table(234) := '31323739707829207B0A20202E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572207B0A2020202070616464696E672D746F703A203670783B0A202020207061';
wwv_flow_api.g_varchar2_table(235) := '6464696E672D626F74746F6D3A203670783B0A20207D0A7D0A406D65646961206F6E6C792073637265656E20616E6420286D696E2D77696474683A203132383170782920616E6420286D61782D77696474683A2031363739707829207B0A20202E75742D';
wwv_flow_api.g_varchar2_table(236) := '50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572207B0A2020202070616464696E672D746F703A203870783B0A2020202070616464696E672D626F74746F6D3A203870';
wwv_flow_api.g_varchar2_table(237) := '783B0A20207D0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465723A686F766572202E612D49636F6E207B0A20206F7061636974793A20313B0A7D0A2E';
wwv_flow_api.g_varchar2_table(238) := '75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572202E612D49636F6E207B0A20206D617267696E3A20327078203670782032707820303B0A2020626F72646572';
wwv_flow_api.g_varchar2_table(239) := '2D7261646975733A203270783B0A20206F7061636974793A20302E353B0A20202D7765626B69742D7472616E736974696F6E3A20302E327320656173653B0A20207472616E736974696F6E3A20302E327320656173653B0A7D0A2E75742D50726F706572';
wwv_flow_api.g_varchar2_table(240) := '7479456469746F72202E752D52544C202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572202E612D49636F6E207B0A20206D617267696E3A20327078203020327078203670783B0A7D0A2E75742D50726F70';
wwv_flow_api.g_varchar2_table(241) := '65727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572202E612D49636F6E2E69636F6E2D72696768742D6172726F773A6265666F7265207B0A2020636F6E74656E743A20225C453044';
wwv_flow_api.g_varchar2_table(242) := '38223B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572202E612D49636F6E2E69636F6E2D646F776E2D6172726F773A6265666F7265207B0A202063';
wwv_flow_api.g_varchar2_table(243) := '6F6E74656E743A20225C65306332223B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465722E69732D666F6375736564207B0A2020706F736974696F6E';
wwv_flow_api.g_varchar2_table(244) := '3A2072656C61746976653B0A20207A2D696E6465783A203130303B0A20206F75746C696E653A206E6F6E653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865';
wwv_flow_api.g_varchar2_table(245) := '616465722E69732D666F6375736564202E612D49636F6E207B0A20206F7061636974793A20313B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D7469746C65207B';
wwv_flow_api.g_varchar2_table(246) := '0A2020646973706C61793A20696E6C696E652D626C6F636B3B0A20206D617267696E3A20303B0A202070616464696E673A20303B0A2020766572746963616C2D616C69676E3A20746F703B0A2020666F6E742D7765696768743A203630303B0A2020666F';
wwv_flow_api.g_varchar2_table(247) := '6E742D73697A653A20313470783B0A20206C696E652D6865696768743A20323070783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722E69732D656D707479207B0A2020646973706C61793A202D7765';
wwv_flow_api.g_varchar2_table(248) := '626B69742D626F783B0A2020646973706C61793A202D6D732D666C6578626F783B0A2020646973706C61793A20666C65783B0A20206F766572666C6F773A2068696464656E3B0A20206865696768743A20313030253B0A20202D7765626B69742D626F78';
wwv_flow_api.g_varchar2_table(249) := '2D616C69676E3A2063656E7465723B0A20202D6D732D666C65782D616C69676E3A2063656E7465723B0A2020616C69676E2D6974656D733A2063656E7465723B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469';
wwv_flow_api.g_varchar2_table(250) := '746F722D6D657373616765207B0A202070616464696E673A20313270783B0A202077696474683A20313030253B0A2020746578742D616C69676E3A2063656E7465723B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(251) := '456469746F722D6D65737361676554657874207B0A20206D617267696E3A20303B0A7D0A2E75742D50726F7065727479456469746F72202E612D49636F6E202B202E612D50726F7065727479456469746F722D6D65737361676554657874207B0A20206D';
wwv_flow_api.g_varchar2_table(252) := '617267696E2D746F703A203870783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D65646974506172656E74207B0A202070616464696E673A20367078203870783B0A2020746578742D616C69676E';
wwv_flow_api.g_varchar2_table(253) := '3A2063656E7465723B0A7D0A406D65646961206F6E6C792073637265656E20616E6420286D61782D77696474683A2031303234707829207B0A20202E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D65646974';
wwv_flow_api.g_varchar2_table(254) := '506172656E74207B0A2020202070616464696E673A20327078203870783B0A20207D0A7D0A406D65646961206F6E6C792073637265656E20616E6420286D696E2D77696474683A203130323570782920616E6420286D61782D77696474683A2031323739';
wwv_flow_api.g_varchar2_table(255) := '707829207B0A20202E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D65646974506172656E74207B0A2020202070616464696E673A20347078203870783B0A20207D0A7D0A2E75742D50726F70657274794564';
wwv_flow_api.g_varchar2_table(256) := '69746F72202E612D50726F7065727479456469746F722D66696C746572207B0A2020706F736974696F6E3A2072656C61746976653B0A2020646973706C61793A202D7765626B69742D626F783B0A2020646973706C61793A202D6D732D666C6578626F78';
wwv_flow_api.g_varchar2_table(257) := '3B0A2020646973706C61793A20666C65783B0A202070616464696E673A20303B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E612D50726F7065727479456469746F722D66696C';
wwv_flow_api.g_varchar2_table(258) := '7465722D69636F6E207B0A2020706F736974696F6E3A206162736F6C7574653B0A2020746F703A20303B0A20206C6566743A20303B0A20206D617267696E3A203870783B0A20206F7061636974793A20302E353B0A20202D7765626B69742D7472616E73';
wwv_flow_api.g_varchar2_table(259) := '6974696F6E3A20302E317320656173653B0A20207472616E736974696F6E3A20302E317320656173653B0A2020706F696E7465722D6576656E74733A206E6F6E653B0A7D0A2E75742D50726F7065727479456469746F72202E752D52544C202E612D5072';
wwv_flow_api.g_varchar2_table(260) := '6F7065727479456469746F722D66696C746572202E612D50726F7065727479456469746F722D66696C7465722D69636F6E207B0A20206C6566743A206175746F3B0A202072696768743A20303B0A7D0A2E75742D50726F7065727479456469746F72202E';
wwv_flow_api.g_varchar2_table(261) := '612D50726F7065727479456469746F722D66696C746572202E612D50726F70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D7465787429207B0A20202D7765626B69742D626F782D73697A696E673A20626F726465';
wwv_flow_api.g_varchar2_table(262) := '722D626F783B0A2020626F782D73697A696E673A20626F726465722D626F783B0A202070616464696E673A20387078203870782038707820333270783B0A20206865696768743A20333270783B0A20206C696E652D6865696768743A20333270783B0A20';
wwv_flow_api.g_varchar2_table(263) := '20626F726465722D7261646975733A203270783B0A7D0A2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F7065727479456469746F722D66696C746572202E612D50726F70657274792D6669656C643A6E6F74282E612D50';
wwv_flow_api.g_varchar2_table(264) := '726F70657274792D6669656C642D2D7465787429207B0A202070616464696E673A20387078203332707820387078203870783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E61';
wwv_flow_api.g_varchar2_table(265) := '2D50726F70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D74657874293A666F637573202B202E612D49636F6E207B0A20206F7061636974793A20313B0A7D0A2E75742D50726F7065727479456469746F72202E61';
wwv_flow_api.g_varchar2_table(266) := '2D50726F7065727479456469746F722D66696C746572202E612D427574746F6E2D2D737469636B7946696C746572207B0A2020706F736974696F6E3A206162736F6C7574653B0A2020746F703A20303B0A202072696768743A20303B0A2020626F74746F';
wwv_flow_api.g_varchar2_table(267) := '6D3A20303B0A20207A2D696E6465783A2031303B0A20206D617267696E3A203470783B0A202070616464696E673A203470783B0A20206F7061636974793A20303B0A20202D7765626B69742D7472616E736974696F6E3A206F70616369747920302E3173';
wwv_flow_api.g_varchar2_table(268) := '20656173653B0A20207472616E736974696F6E3A206F70616369747920302E317320656173653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C7465723A666F6375732D77697468696E202E';
wwv_flow_api.g_varchar2_table(269) := '612D50726F70657274792D6669656C64202B202E612D49636F6E207B0A20206F7061636974793A20313B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(270) := '2D6669656C643A666F637573207E202E612D427574746F6E2D2D737469636B7946696C7465722C0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E612D427574746F6E2D2D737469636B';
wwv_flow_api.g_varchar2_table(271) := '7946696C7465722E69732D6163746976652C0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E612D427574746F6E2D2D737469636B7946696C7465723A666F637573207B0A20206F7061';
wwv_flow_api.g_varchar2_table(272) := '636974793A20313B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D686967686C69676874207B0A202070616464696E673A2032707820303B0A2020626F726465722D7261646975733A203270783B0A20202D776562';
wwv_flow_api.g_varchar2_table(273) := '6B69742D7472616E736974696F6E3A20302E317320656173653B0A20207472616E736974696F6E3A20302E317320656173653B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6E6F74466F756E64207B0A20207061';
wwv_flow_api.g_varchar2_table(274) := '6464696E673A20312E3672656D3B0A2020746578742D616C69676E3A2063656E7465723B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6E6F74466F756E64202E612D49636F6E207B0A20206D617267696E2D626F';
wwv_flow_api.g_varchar2_table(275) := '74746F6D3A203870783B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F706572747947726F75702D6974656D207B0A2020626F726465722D746F703A2031707820736F6C69643B0A2020626F726465722D626F74746F6D2D776964';
wwv_flow_api.g_varchar2_table(276) := '74683A20303B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D626F6479207B0A202070616464696E673A2034707820303B0A7D0A';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(776880361529146571)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_file_name=>'css/base.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '7B2276657273696F6E223A332C22736F7572636573223A5B22626173652E637373225D2C226E616D6573223A5B5D2C226D617070696E6773223A2241413449412C38422C434143452C69422C434143412C612C434143412C512C434143412C532C434143';
wwv_flow_api.g_varchar2_table(2) := '412C552C434143412C69422C434145462C6F442C434143452C592C434145462C38432C434143412C36432C434143412C34432C434143452C6B422C434143412C71422C434145462C38432C434145412C36432C434144412C36432C434145412C34432C43';
wwv_flow_api.g_varchar2_table(3) := '4143452C652C434145462C30434143452C38432C434145412C36432C434144412C36432C434145412C34432C434143452C694241474A2C36432C434143452C652C434143412C652C434145462C6D452C434143452C652C434145462C3844414138442C67';
wwv_flow_api.g_varchar2_table(4) := '442C43414335442C69422C434143412C552C434145462C36432C434143452C6B422C434143412C552C434143412C71422C434145462C75442C434143452C79422C43414B462C32432C434143452C612C434143412C552C434143412C572C434143412C6B';
wwv_flow_api.g_varchar2_table(5) := '422C434145462C30442C434143452C79422C434145462C34452C434143452C69422C434143412C6D432C434143412C73432C434145462C6D462C434143452C69422C434143412C552C434143412C6D422C434145462C71452C434143452C67422C434145';
wwv_flow_api.g_varchar2_table(6) := '462C34432C434143452C77422C434143412C6B422C434145462C6D442C43416D43412C67452C43416843412C75442C434146452C67422C43414B462C6F432C434143412C6F442C434145452C612C434143412C632C434143412C67422C434148462C6D43';
wwv_flow_api.g_varchar2_table(7) := '2C434143452C612C434145412C67422C434145462C36432C434147452C67422C434146462C6F432C434143452C632C434143412C67422C434145462C6D432C434143452C632C434145462C38432C434143452C612C434143412C67422C434145462C6F43';
wwv_flow_api.g_varchar2_table(8) := '2C434143452C572C434143412C652C434143412C632C434143412C67422C434143412C69422C434145462C30432C434143452C532C43414B462C34442C434143452C69422C434145462C34432C434143452C652C434143412C6B422C434143412C69422C';
wwv_flow_api.g_varchar2_table(9) := '434143412C69422C434143412C30422C434143412C79422C434143412C32422C434143412C75422C434143412C6F422C434143412C652C434145462C3442414134422C67442C43414331422C77422C434145462C38432C434143412C38442C434143452C';
wwv_flow_api.g_varchar2_table(10) := '572C434143412C67422C434143412C572C434143412C632C434145412C67422C43414E462C38442C43414B452C30462C434147462C75432C434143452C652C434143412C632C434143412C612C434145462C6D442C434143452C652C434145462C38442C';
wwv_flow_api.g_varchar2_table(11) := '434143452C79422C434143412C34422C434145462C6B452C434143452C652C434145462C34442C434143412C73442C434143452C69422C434143412C652C434143412C6B422C434143412C572C434143412C532C434143412C532C434143412C552C4341';
wwv_flow_api.g_varchar2_table(12) := '43412C512C43414D462C6B452C434143412C34442C434143452C69422C434143412C69422C434143412C69422C434143412C632C434145462C79452C434143412C6D452C434143452C67422C434143412C6B422C434147462C77452C434144412C79452C';
wwv_flow_api.g_varchar2_table(13) := '434145412C6D452C434145452C69422C434143412C4F2C434143412C4D2C434143412C612C434143412C552C434143412C572C434143412C552C434143412C71432C434143412C36422C434154462C6B452C434143452C69422C434143412C4F2C434143';
wwv_flow_api.g_varchar2_table(14) := '412C4D2C434143412C612C434147412C552C434143412C71432C434143412C36422C434147462C2B452C434144412C67462C434147412C79452C434144412C30452C434145452C532C434143412C4F2C434145462C79452C434143412C6D452C43414345';
wwv_flow_api.g_varchar2_table(15) := '2C552C434143412C67422C434145462C77452C434143412C6B452C434143452C572C434143412C532C434145462C32452C434143412C71452C434143452C552C434143412C632C434143412C6D422C434145462C6B462C434143412C34452C434143452C';
wwv_flow_api.g_varchar2_table(16) := '552C434147462C73462C434144412C73462C434147412C67462C434144412C67462C434145452C532C434151462C79452C434143452C69422C434145462C77452C434143452C75422C434143412C6F422C434143412C32422C434145462C73462C434143';
wwv_flow_api.g_varchar2_table(17) := '452C532C434143412C71422C434143412C532C434143412C552C434143412C69422C434143412C632C434143412C34422C434143412C6F422C434145462C67462C434143412C69462C43416B42412C30452C43416A42452C532C434151462C6D452C4341';
wwv_flow_api.g_varchar2_table(18) := '43452C6B422C434145462C6B452C434143452C552C434143412C532C434143412C552C434143412C6B422C43414B462C2B452C434143452C612C434145462C73452C434143452C69422C43414F462C6B462C434143452C652C434143412C36432C434143';
wwv_flow_api.g_varchar2_table(19) := '412C71432C43413844412C632C434143412C69422C434143412C67422C434143412C69422C43413944462C77462C434144412C79462C434145452C652C434145462C30462C434143452C652C434145462C77462C434143452C532C434143412C532C4341';
wwv_flow_api.g_varchar2_table(20) := '43412C69422C434145462C2B432C434143452C532C434145462C6F432C434143452C6F422C434145462C30432C434143452C6F422C434143412C552C434143412C552C434143412C572C434143412C6B422C434145462C30432C434143452C6F422C4341';
wwv_flow_api.g_varchar2_table(21) := '43412C572C434143412C6B422C434143412C632C434145462C79442C434143452C652C434143412C6B422C434147462C30442C434144412C32442C434145452C612C434143412C552C434145462C30442C434143452C552C434145462C73452C43414345';
wwv_flow_api.g_varchar2_table(22) := '2C552C434145462C34452C434143452C69422C434143412C652C434143412C6B422C434143412C572C434143412C532C434143412C532C434143412C552C434143412C512C434145462C32462C434143452C552C434151462C30462C434143452C552C43';
wwv_flow_api.g_varchar2_table(23) := '4145462C75432C434143452C69422C434147462C6B452C434144412C6B452C43413445412C73452C434143412C30462C43413345452C612C434145462C6B452C434143452C69422C434143412C67422C434145462C6B452C434143452C612C434145462C';
wwv_flow_api.g_varchar2_table(24) := '6D452C434143452C69422C434143412C4B2C434143412C4F2C434145462C38462C434143452C652C434145462C77462C434143452C652C434145462C30432C434143452C612C434143412C612C434145462C30442C434143452C6B422C434143412C6942';
wwv_flow_api.g_varchar2_table(25) := '2C434143412C6B422C434145462C30442C434143452C532C434145462C38432C434143452C77422C434145462C79442C434143452C572C434145462C32452C434143452C69422C434143412C4F2C434143412C512C434143412C512C434143412C6F422C';
wwv_flow_api.g_varchar2_table(26) := '434143412C532C434143412C552C434143412C552C434147462C73462C434144412C69462C434145452C532C434145462C6F432C434143412C6D432C434143452C612C434143412C30422C434143412C73422C434143412C652C434145462C6F432C4341';
wwv_flow_api.g_varchar2_table(27) := '43452C612C434143412C552C434143412C30422C434143412C632C434145462C38432C434143452C652C434143412C30462C434143412C652C434145462C79432C434143412C36442C434143452C592C43414D462C2B452C434143452C612C434145462C';
wwv_flow_api.g_varchar2_table(28) := '6B442C434143452C532C434145462C36432C434143452C6F422C434143412C552C434143412C552C434143412C572C434143412C6B422C434145462C36432C434143452C6F422C434143412C572C434143412C6B422C434143412C632C434145462C3443';
wwv_flow_api.g_varchar2_table(29) := '2C434143452C552C434143412C67422C434143412C77422C434145462C2B432C434143452C6B422C434145462C36442C434143452C67422C434145462C6F442C434143452C652C434145462C73442C434143452C552C434145462C71432C434143452C79';
wwv_flow_api.g_varchar2_table(30) := '422C434143412C552C434143412C6B422C434145462C30462C434143452C6B422C434143412C6B422C434143412C69422C434143412C632C434147462C79452C434144412C77452C434145452C612C434143412C6B422C434145462C38462C434143452C';
wwv_flow_api.g_varchar2_table(31) := '652C434143412C6B422C434145462C2B472C434143452C612C434145462C32432C434143452C30422C434145462C77462C434143452C632C434145462C2B432C434143452C612C434143412C67422C434145462C6B442C434143452C612C434143412C32';
wwv_flow_api.g_varchar2_table(32) := '422C434143412C77452C434145412C77442C434143412C6F462C434145462C73472C434143452C6B422C434145462C6F472C434143452C592C434145462C67462C434143452C632C434145462C79442C434143452C632C434143412C67422C434143412C';
wwv_flow_api.g_varchar2_table(33) := '632C434143412C6B432C434143412C30422C434145462C30434143452C79442C434143452C652C434143412C6F4241474A2C412C69454143452C79442C434143452C652C434143412C6F4241474A2C412C69454143452C79442C434143452C652C434143';
wwv_flow_api.g_varchar2_table(34) := '412C6F4241474A2C75452C434143452C532C434145462C69452C434143452C6F422C434143412C69422C434143412C552C434143412C32422C434143412C6D422C434145462C77452C434143452C6F422C434145462C79462C434143452C652C43414546';
wwv_flow_api.g_varchar2_table(35) := '2C77462C434143452C652C434145462C6F452C434143452C69422C434143412C572C434143412C532C434145462C34452C434143452C532C434145462C77442C434143452C6F422C434143412C512C434143412C532C434143412C6B422C434143412C65';
wwv_flow_api.g_varchar2_table(36) := '2C434143412C632C434143412C67422C434145462C36432C434143452C6D422C434143412C6D422C434143412C592C434143412C652C434143412C572C434143412C77422C434143412C71422C434143412C6B422C434145462C34432C434143452C592C';
wwv_flow_api.g_varchar2_table(37) := '434143412C552C434143412C69422C434145462C67442C434143452C512C434145462C77442C434143452C632C434145462C2B432C434143452C652C434143412C69422C434145462C30434143452C2B432C434143452C694241474A2C412C6945414345';
wwv_flow_api.g_varchar2_table(38) := '2C2B432C434143452C694241474A2C32432C434143452C69422C434143412C6D422C434143412C6D422C434143412C592C434143412C532C434145462C79452C434143452C69422C434143412C4B2C434143412C4D2C434143412C552C434143412C552C';
wwv_flow_api.g_varchar2_table(39) := '434143412C32422C434143412C6D422C434143412C6D422C434145462C67462C434143452C532C434143412C4F2C434145462C6B4541416B452C77422C43414368452C36422C434143412C71422C434143412C77422C434143412C572C434143412C6742';
wwv_flow_api.g_varchar2_table(40) := '2C434143412C69422C434145462C7945414179452C77422C43414376452C77422C434145462C6B4541416B452C73432C43414368452C532C434145462C6D452C434143452C69422C434143412C4B2C434143412C4F2C434143412C512C434143412C552C';
wwv_flow_api.g_varchar2_table(41) := '434143412C552C434143412C572C434143412C532C434143412C6D432C434143412C32422C434145462C6B462C434143452C532C434147462C36452C434143412C79452C434146412C32462C434147452C532C434145462C77432C434143452C612C4341';
wwv_flow_api.g_varchar2_table(42) := '43412C69422C434143412C32422C434143412C6D422C434145462C75432C434143452C632C434143412C69422C434145462C2B432C434143452C69422C434145462C77432C434143452C6F422C434143412C71422C434145462C75442C434143452C6122';
wwv_flow_api.g_varchar2_table(43) := '2C2266696C65223A22626173652E637373222C22736F7572636573436F6E74656E74223A5B222E75742D50726F7065727479456469746F72207B5C6E20202F2A203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(44) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D5C6E2020202050726F7065727479202850726F706572747920456469746F722050726F70657274696573295C6E202020203D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(45) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F5C6E20202F2A2A5C6E202020202A2050726F706572747920436F6D706F6E656E745C6E';
wwv_flow_api.g_varchar2_table(46) := '202020202A5C6E202020202A205468697320697320612070726F7065727479207468617420697320757365642077697468696E2074686520636F6E74657874206F6620612070726F706572747920656469746F7220746F5C6E202020202A2070726F7669';
wwv_flow_api.g_varchar2_table(47) := '64652061206C6162656C20616E6420696E707574206669656C642E5C6E202020202A5C6E202020202A204578616D706C652048544D4C3A5C6E202020202A5C6E202020202A203C64697620636C6173733D5C22612D50726F70657274795C223E5C6E2020';
wwv_flow_api.g_varchar2_table(48) := '20202A2020203C64697620636C6173733D5C22612D50726F70657274792D6C6162656C436F6E7461696E65725C223E5C6E202020202A20202020203C6C6162656C20636C6173733D5C22612D50726F70657274792D6C6162656C5C223E4C6162656C3C2F';
wwv_flow_api.g_varchar2_table(49) := '6C6162656C3E5C6E202020202A2020203C2F6469763E5C6E202020202A2020203C64697620636C6173733D5C22612D50726F70657274792D6669656C64436F6E7461696E65725C223E5C6E202020202A20202020203C696E70757420747970653D5C2274';
wwv_flow_api.g_varchar2_table(50) := '6578745C2220636C6173733D5C22612D50726F70657274792D6669656C645C223E5C6E202020202A2020203C2F6469763E5C6E202020202A203C2F6469763E5C6E202020202A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(51) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E2020202050726F7065727479204572726F725C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(52) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(53) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E2020202050726F7065727479205761726E696E675C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(54) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(55) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E202020204C6162656C20616E6420507265202F20506F737420546578745C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(56) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(57) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E2020202050726F7065727479204669656C64202D205573656420666F722070726F706572747920656469746F725C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(58) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2050726F706572747920456469746F722053656C656374204C6973745C6E20';
wwv_flow_api.g_varchar2_table(59) := '2020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F5C6E20202F2A205465787420417265615C6E2020';
wwv_flow_api.g_varchar2_table(60) := '20203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(61) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E20202020436F6D626F20426F78205374796C65735C6E202020202A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(62) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(63) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E20202020436865636B626F78202B20526164696F20427574746F6E735C6E202020202A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(64) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(65) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E20202020436865636B626F782053706563696669635C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(66) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(67) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E20202020526164696F2053706563696669635C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(68) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(69) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E20202020596573202F204E6F20427574746F6E735C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(70) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(71) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E20202020526164696F5C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(72) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E';
wwv_flow_api.g_varchar2_table(73) := '20202020596573202F204E6F20526164696F735C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(74) := '2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E20202020537461636B6564';
wwv_flow_api.g_varchar2_table(75) := '2050726F706572746965735C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E2020';
wwv_flow_api.g_varchar2_table(76) := '2F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E20202020486964652F53686F7720436C617373';
wwv_flow_api.g_varchar2_table(77) := '65735C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(78) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E202020205661726961626C65204669656C645C6E202020202A2A2A2A';
wwv_flow_api.g_varchar2_table(79) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(80) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E20202020436865636B626F785C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(81) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(82) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E20202020536574204974656D73205461626C655C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(83) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(84) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E2020202050726F706572747920456469746F7220696E204469616C6F67735C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(85) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(86) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E2020202050726F706572747920456469746F7220427574746F6E735C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(87) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(88) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A5C6E20202020537461636B6564205374796C65735C6E202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(89) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F5C6E20202F2A203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(90) := '3D3D3D3D3D3D3D3D3D3D3D3D5C6E202020204869676820436F6E7472617374204D6F64655C6E202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(91) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F5C6E20202F2A5C6E2020202024646973706C61792D787878733A2036343070783B5C6E2020202024646973706C61792D7878733A2038303070783B5C6E2020202024646973706C61792D78733A20313032';
wwv_flow_api.g_varchar2_table(92) := '3470783B5C6E2020202024646973706C61792D736D616C6C3A203132383070783B5C6E2020202024646973706C61792D6D656469756D3A203136383070783B5C6E2020202024646973706C61792D6C617267653A203139323070783B5C6E202020202A2F';
wwv_flow_api.g_varchar2_table(93) := '5C6E20202F2A203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D5C6E2020202050726F70657274792045646974';
wwv_flow_api.g_varchar2_table(94) := '6F725C6E202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F5C6E20202F2A2050726F7065727479';
wwv_flow_api.g_varchar2_table(95) := '20456469746F722047726F7570735C6E202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F5C6E20';
wwv_flow_api.g_varchar2_table(96) := '202F2A2A5C6E202020202A204D6F6469666965723A2069732D656D7074795C6E202020202A5C6E202020202A2055736564207768656E20616E206572726F72206D65737361676520697320646973706C617965645C6E202020202A2F5C6E20202F2A2046';
wwv_flow_api.g_varchar2_table(97) := '696C746572696E675C6E202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F5C6E20202F2A205072';
wwv_flow_api.g_varchar2_table(98) := '6F70657274792046696C746572204E6F7420466F756E645C6E202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(99) := '3D3D3D202A2F5C6E20202F2A5C6E2020202024646973706C61792D787878733A2036343070783B5C6E2020202024646973706C61792D7878733A2038303070783B5C6E2020202024646973706C61792D78733A203130323470783B5C6E20202020246469';
wwv_flow_api.g_varchar2_table(100) := '73706C61792D736D616C6C3A203132383070783B5C6E2020202024646973706C61792D6D656469756D3A203136383070783B5C6E2020202024646973706C61792D6C617267653A203139323070783B5C6E202020202A2F5C6E20202F2A203D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(101) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D5C6E2020202050726F70657274792047726F7570202850726F70657274792045';
wwv_flow_api.g_varchar2_table(102) := '6469746F722047726F757073295C6E202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F5C6E2020';
wwv_flow_api.g_varchar2_table(103) := '2F2A2A5C6E202020202A2050726F70657274792047726F757020436F6D706F6E656E745C6E202020202A5C6E202020202A205468697320697320612067726F7570696E67206F66206F6E65206F72206D6F72652070726F7065727469657320696E207468';
wwv_flow_api.g_varchar2_table(104) := '6520636F6E74657874206F6620612070726F70657274795C6E202020202A20656469746F722E205468697320616C6C6F777320757320746F20636F6E76656E69656E746C792067726F7570206F75722070726F7065727469657320616E64207573655C6E';
wwv_flow_api.g_varchar2_table(105) := '202020202A2070737565646F2073656C6563746F727320746F206170706C79207374796C657320746F206669727374202F206C61737420656C656D656E74732077697468696E207468652067726F75702E5C6E202020202A5C6E202020202A204578616D';
wwv_flow_api.g_varchar2_table(106) := '706C652048544D4C3A5C6E202020202A5C6E202020202A203C64697620636C6173733D5C22612D50726F706572747947726F75705C223E5C6E202020202A2020203C64697620636C6173733D5C22612D50726F706572747947726F75702D6974656D5C22';
wwv_flow_api.g_varchar2_table(107) := '3E5C6E202020202A20202020205B50726F70657274792020486572655D5C6E202020202A2020203C2F6469763E5C6E202020202A2020203C64697620636C6173733D5C22612D50726F706572747947726F75702D6974656D5C223E5C6E202020202A2020';
wwv_flow_api.g_varchar2_table(108) := '2020205B50726F70657274792020486572655D5C6E202020202A2020203C2F6469763E5C6E202020202A2020203C64697620636C6173733D5C22612D50726F706572747947726F75702D6974656D5C223E5C6E202020202A20202020205B50726F706572';
wwv_flow_api.g_varchar2_table(109) := '74792020486572655D5C6E202020202A2020203C2F6469763E5C6E202020202A203C2F6469763E5C6E202020202A2F5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479207B5C6E2020706F736974696F6E3A207265';
wwv_flow_api.g_varchar2_table(110) := '6C61746976653B5C6E2020646973706C61793A207461626C653B5C6E20206D617267696E3A20303B5C6E202070616464696E673A20303B5C6E202077696474683A20313030253B5C6E20207461626C652D6C61796F75743A206175746F3B5C6E7D5C6E2E';
wwv_flow_api.g_varchar2_table(111) := '75742D50726F7065727479456469746F72202E612D50726F7065727479202E612D49636F6E2E69636F6E2D7265717569726564207B5C6E2020646973706C61793A206E6F6E653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D5072';
wwv_flow_api.g_varchar2_table(112) := '6F70657274792D627574746F6E436F6E7461696E65722C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C436F6E7461696E65722C5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065';
wwv_flow_api.g_varchar2_table(113) := '7274792D756E6974436F6E7461696E6572207B5C6E2020646973706C61793A207461626C652D63656C6C3B5C6E2020766572746963616C2D616C69676E3A206D6964646C653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F';
wwv_flow_api.g_varchar2_table(114) := '70657274792D627574746F6E436F6E7461696E65722C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C436F6E7461696E65722C5C6E2E75742D50726F7065727479456469746F72202E612D50726F706572';
wwv_flow_api.g_varchar2_table(115) := '74792D6669656C64436F6E7461696E65722C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D756E6974436F6E7461696E6572207B5C6E202070616464696E673A20347078203870783B5C6E7D5C6E406D65646961206F';
wwv_flow_api.g_varchar2_table(116) := '6E6C792073637265656E20616E6420286D61782D77696474683A2031303234707829207B5C6E20202E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E65722C5C6E20202E75742D50726F7065';
wwv_flow_api.g_varchar2_table(117) := '727479456469746F72202E612D50726F70657274792D6C6162656C436F6E7461696E65722C5C6E20202E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722C5C6E20202E75742D50726F7065';
wwv_flow_api.g_varchar2_table(118) := '727479456469746F72202E612D50726F70657274792D756E6974436F6E7461696E6572207B5C6E2020202070616464696E673A20327078203870783B5C6E20207D5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(119) := '2D6C6162656C436F6E7461696E6572207B5C6E202070616464696E672D72696768743A20303B5C6E20206D696E2D77696474683A2031313270783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202374656D706C6174654F7074696F6E7344';
wwv_flow_api.g_varchar2_table(120) := '6C675045202E612D50726F70657274792D6C6162656C436F6E7461696E6572207B5C6E20206D696E2D77696474683A2031343470783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461';
wwv_flow_api.g_varchar2_table(121) := '636B6564202E612D50726F70657274793A6E6F74282E612D50726F70657274792D2D737461636B656429202E612D50726F70657274792D6C6162656C436F6E7461696E6572207B5C6E2020646973706C61793A207461626C652D726F773B5C6E20207769';
wwv_flow_api.g_varchar2_table(122) := '6474683A20313030253B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E6572207B5C6E2020646973706C61793A207461626C652D63656C6C3B5C6E202077696474683A20313030';
wwv_flow_api.g_varchar2_table(123) := '253B5C6E2020766572746963616C2D616C69676E3A206D6964646C653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D636F6D626F426F78207B5C6E20207061646469';
wwv_flow_api.g_varchar2_table(124) := '6E672D72696768743A20302021696D706F7274616E743B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E65722D2D636F6D626F426F78202E612D427574746F6E207B5C6E2020';
wwv_flow_api.g_varchar2_table(125) := '6D617267696E2D6C6566743A202D3170783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636F6C6F7250726576696577207B5C6E2020646973706C61793A20626C6F636B3B5C6E202077696474683A203132';
wwv_flow_api.g_varchar2_table(126) := '70783B5C6E20206865696768743A20313270783B5C6E2020626F726465722D7261646975733A20313030253B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D636F6C6F';
wwv_flow_api.g_varchar2_table(127) := '725069636B6572207B5C6E202070616464696E672D72696768743A20302021696D706F7274616E743B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D636F6C6F725069';
wwv_flow_api.g_varchar2_table(128) := '636B6572202E612D50726F70657274792D6669656C64207B5C6E202070616464696E672D6C6566743A20323470783B5C6E2020626F726465722D746F702D72696768742D7261646975733A20302021696D706F7274616E743B5C6E2020626F726465722D';
wwv_flow_api.g_varchar2_table(129) := '626F74746F6D2D72696768742D7261646975733A20302021696D706F7274616E743B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D636F6C6F725069636B6572202E61';
wwv_flow_api.g_varchar2_table(130) := '2D50726F70657274792D636F6C6F7250726576696577207B5C6E2020706F736974696F6E3A206162736F6C7574653B5C6E20206D617267696E3A203670783B5C6E2020706F696E7465722D6576656E74733A206E6F6E653B5C6E7D5C6E2E75742D50726F';
wwv_flow_api.g_varchar2_table(131) := '7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E65722D2D636F6C6F725069636B6572202E612D427574746F6E207B5C6E20206D617267696E2D6C6566743A202D3170783B5C6E7D5C6E2E75742D50726F7065';
wwv_flow_api.g_varchar2_table(132) := '727479456469746F72202E612D50726F70657274792D756E6974436F6E7461696E6572207B5C6E202070616464696E672D6C6566743A20302021696D706F7274616E743B5C6E202077686974652D73706163653A206E6F777261703B5C6E7D5C6E2E7574';
wwv_flow_api.g_varchar2_table(133) := '2D50726F7065727479456469746F72202E612D50726F70657274792E69732D6572726F72202E69636F6E2D6572726F72207B5C6E20206D617267696E2D72696768743A203470783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50';
wwv_flow_api.g_varchar2_table(134) := '726F70657274792E69732D7761726E696E67202E69636F6E2D7761726E696E67207B5C6E20206D617267696E2D72696768743A203470783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C2C5C6E';
wwv_flow_api.g_varchar2_table(135) := '2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D734865616465722D6865616465722C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D756E6974207B5C6E202070616464';
wwv_flow_api.g_varchar2_table(136) := '696E673A2034707820303B5C6E2020666F6E742D73697A653A20313270783B5C6E20206C696E652D6865696768743A20313670783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D6C61';
wwv_flow_api.g_varchar2_table(137) := '62656C2C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F207B5C6E2020666F6E742D73697A653A20313270783B5C6E20206C696E652D6865696768743A20313670783B5C6E7D5C6E2E75742D50726F7065';
wwv_flow_api.g_varchar2_table(138) := '727479456469746F72202E612D50726F70657274792D756E6974207B5C6E2020666F6E742D73697A653A20313170783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C2D2D7769746849636F6E20';
wwv_flow_api.g_varchar2_table(139) := '7B5C6E202070616464696E673A2034707820303B5C6E20206C696E652D6865696768743A20313670783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64207B5C6E202070616464696E673A203470';
wwv_flow_api.g_varchar2_table(140) := '783B5C6E20206D696E2D6865696768743A20323470783B5C6E2020666F6E742D73697A653A20313270783B5C6E20206C696E652D6865696768743A20313670783B5C6E2020626F726465722D7261646975733A203270783B5C6E7D5C6E2E75742D50726F';
wwv_flow_api.g_varchar2_table(141) := '7065727479456469746F72202E612D50726F70657274792D6669656C643A666F637573207B5C6E20206F75746C696E653A206E6F6E653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D766172696162';
wwv_flow_api.g_varchar2_table(142) := '6C65202E612D49636F6E2E69636F6E2D7661726961626C65207B5C6E20206D617267696E2D72696768743A203470783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D7661726961626C65202E612D50';
wwv_flow_api.g_varchar2_table(143) := '726F70657274792D6669656C64207B5C6E2020626F726465722D7261646975733A203270783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C642D2D73656C656374207B5C6E20206F766572666C6F';
wwv_flow_api.g_varchar2_table(144) := '773A2068696464656E3B5C6E202070616464696E672D72696768743A20333070783B5C6E2020746578742D696E64656E743A20302E303170783B5C6E2020746578742D6F766572666C6F773A202720273B5C6E20206261636B67726F756E642D706F7369';
wwv_flow_api.g_varchar2_table(145) := '74696F6E3A203130302520303B5C6E20206261636B67726F756E642D73697A653A203332707820323470783B5C6E20206261636B67726F756E642D7265706561743A206E6F2D7265706561743B5C6E20202D7765626B69742D617070656172616E63653A';
wwv_flow_api.g_varchar2_table(146) := '206E6F6E653B5C6E20202D6D6F7A2D617070656172616E63653A206E6F6E653B5C6E2020617070656172616E63653A206E6F6E653B5C6E7D5C6E2E75742D50726F7065727479456469746F7220626F64793A6E6F74283A2D6D6F7A2D68616E646C65722D';
wwv_flow_api.g_varchar2_table(147) := '626C6F636B656429202E612D50726F70657274792D6669656C642D2D73656C656374207B5C6E202070616464696E673A20327078203234707820327078203270783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274';
wwv_flow_api.g_varchar2_table(148) := '792D6669656C642D2D74657874617265612C5C6E2E75742D50726F7065727479456469746F7220626F6479202E75692D776964676574202E612D50726F70657274792D6669656C642D2D7465787461726561207B5C6E202070616464696E673A20347078';
wwv_flow_api.g_varchar2_table(149) := '3B5C6E20206D61782D6865696768743A2033323070783B5C6E20206865696768743A206175746F3B5C6E2020666F6E742D73697A653A20313170783B5C6E2020666F6E742D66616D696C793A2053464D6F6E6F2D526567756C61722C204D656E6C6F2C20';
wwv_flow_api.g_varchar2_table(150) := '4D6F6E61636F2C20436F6E736F6C61732C205C224C696265726174696F6E204D6F6E6F5C222C205C22436F7572696572204E65775C222C206D6F6E6F73706163653B5C6E20206C696E652D6865696768743A20313470783B5C6E7D5C6E2E75742D50726F';
wwv_flow_api.g_varchar2_table(151) := '7065727479456469746F72202E612D50726F70657274792D726561644F6E6C79207B5C6E2020666F6E742D7765696768743A20626F6C643B5C6E2020666F6E742D73697A653A20313270783B5C6E20206C696E652D6865696768743A20323B5C6E7D5C6E';
wwv_flow_api.g_varchar2_table(152) := '2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D735461626C652D686561646572207B5C6E2020666F6E742D7765696768743A206E6F726D616C3B5C6E7D5C6E2E75742D50726F7065727479456469746F72';
wwv_flow_api.g_varchar2_table(153) := '202E612D50726F70657274792D7365744974656D735461626C65202E612D50726F70657274792D6669656C64207B5C6E2020626F726465722D746F702D72696768742D7261646975733A20303B5C6E2020626F726465722D626F74746F6D2D7269676874';
wwv_flow_api.g_varchar2_table(154) := '2D7261646975733A20303B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E65722D2D636F6D626F426F78202E612D427574746F6E207B5C6E20206D617267696E2D6C6566743A';
wwv_flow_api.g_varchar2_table(155) := '203870783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D2C5C6E2E75742D50726F7065727479456469746F72202E612D50';
wwv_flow_api.g_varchar2_table(156) := '726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D207B5C6E2020706F736974696F6E3A206162736F6C7574653B5C6E20206F766572666C6F773A2068696464656E3B5C6E2020636C69703A20726563742830203020';
wwv_flow_api.g_varchar2_table(157) := '302030293B5C6E20206D617267696E3A202D3170783B5C6E202070616464696E673A20303B5C6E202077696474683A203170783B5C6E20206865696768743A203170783B5C6E2020626F726465723A20303B5C6E20202F2A2044697361626C6564205374';
wwv_flow_api.g_varchar2_table(158) := '6174655C6E202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F5C6E20202F2A20466F6375735C6E';
wwv_flow_api.g_varchar2_table(159) := '202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F5C6E7D5C6E2E75742D50726F70657274794564';
wwv_flow_api.g_varchar2_table(160) := '69746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D202B206C6162656C2C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E';
wwv_flow_api.g_varchar2_table(161) := '7075745B747970653D5C22726164696F5C225D202B206C6162656C207B5C6E2020706F736974696F6E3A2072656C61746976653B5C6E202070616464696E672D72696768743A203870783B5C6E202070616464696E672D6C6566743A20323070783B5C6E';
wwv_flow_api.g_varchar2_table(162) := '2020637572736F723A20706F696E7465723B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D202B206C6162';
wwv_flow_api.g_varchar2_table(163) := '656C2C5C6E2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D202B206C6162656C207B5C6E202070616464696E672D6C6566743A203870';
wwv_flow_api.g_varchar2_table(164) := '783B5C6E202070616464696E672D72696768743A20323070783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D202B206C61';
wwv_flow_api.g_varchar2_table(165) := '62656C3A6265666F72652C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D202B206C6162656C3A61667465722C5C6E2E75742D5072';
wwv_flow_api.g_varchar2_table(166) := '6F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D202B206C6162656C3A6265666F72652C5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(167) := '2D726164696F2D696E7075745B747970653D5C22726164696F5C225D202B206C6162656C3A6166746572207B5C6E2020706F736974696F6E3A206162736F6C7574653B5C6E2020746F703A203370783B5C6E20206C6566743A20303B5C6E202064697370';
wwv_flow_api.g_varchar2_table(168) := '6C61793A20626C6F636B3B5C6E202077696474683A20313470783B5C6E20206865696768743A20313470783B5C6E2020636F6E74656E743A2027273B5C6E20202D7765626B69742D7472616E736974696F6E3A20302E31323573206F7061636974792065';
wwv_flow_api.g_varchar2_table(169) := '6173653B5C6E20207472616E736974696F6E3A20302E31323573206F70616369747920656173653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274792D636865636B626F782D696E7075745B7479';
wwv_flow_api.g_varchar2_table(170) := '70653D5C22636865636B626F785C225D202B206C6162656C3A6265666F72652C5C6E2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B62';
wwv_flow_api.g_varchar2_table(171) := '6F785C225D202B206C6162656C3A61667465722C5C6E2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D202B206C6162656C3A6265666F';
wwv_flow_api.g_varchar2_table(172) := '72652C5C6E2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D202B206C6162656C3A6166746572207B5C6E20206C6566743A206175746F';
wwv_flow_api.g_varchar2_table(173) := '3B5C6E202072696768743A20303B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D202B206C6162656C3A6265666F72652C5C';
wwv_flow_api.g_varchar2_table(174) := '6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D202B206C6162656C3A6265666F7265207B5C6E20207A2D696E6465783A2039303B5C6E2020626F7264';
wwv_flow_api.g_varchar2_table(175) := '65723A2031707820736F6C69643B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D202B206C6162656C3A61667465722C5C6E';
wwv_flow_api.g_varchar2_table(176) := '2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D202B206C6162656C3A6166746572207B5C6E20207A2D696E6465783A203130303B5C6E20206F70616369';
wwv_flow_api.g_varchar2_table(177) := '74793A20303B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D3A64697361626C6564202B206C6162656C2C5C6E2E75742D50';
wwv_flow_api.g_varchar2_table(178) := '726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D3A64697361626C6564202B206C6162656C207B5C6E20206F7061636974793A20302E353B5C6E2020637572736F723A';
wwv_flow_api.g_varchar2_table(179) := '2064656661756C743B5C6E2020706F696E7465722D6576656E74733A206E6F6E653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F78';
wwv_flow_api.g_varchar2_table(180) := '5C225D3A64697361626C6564202B206C6162656C3A6265666F72652C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D3A64697361626C6564202B20';
wwv_flow_api.g_varchar2_table(181) := '6C6162656C3A6265666F7265207B5C6E20206F7061636974793A20302E353B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D';
wwv_flow_api.g_varchar2_table(182) := '3A686F7665723A636865636B6564202B206C6162656C3A61667465722C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D3A666F6375';
wwv_flow_api.g_varchar2_table(183) := '733A636865636B6564202B206C6162656C3A61667465722C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D3A686F7665723A636865636B6564202B';
wwv_flow_api.g_varchar2_table(184) := '206C6162656C3A61667465722C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D3A666F6375733A636865636B6564202B206C6162656C3A61667465';
wwv_flow_api.g_varchar2_table(185) := '72207B5C6E20206F7061636974793A20313B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D207B5C6E20202F2A20556E6368';
wwv_flow_api.g_varchar2_table(186) := '65636B65645C6E202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F5C6E20202F2A20436865636B';
wwv_flow_api.g_varchar2_table(187) := '65645C6E202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F5C6E7D5C6E2E75742D50726F706572';
wwv_flow_api.g_varchar2_table(188) := '7479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D202B206C6162656C3A6265666F7265207B5C6E2020626F726465722D7261646975733A203270783B5C6E7D5C6E2E';
wwv_flow_api.g_varchar2_table(189) := '75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D202B206C6162656C3A6166746572207B5C6E20206261636B67726F756E642D706F73697469';
wwv_flow_api.g_varchar2_table(190) := '6F6E3A203530253B5C6E20206261636B67726F756E642D73697A653A20313670783B5C6E20206261636B67726F756E642D7265706561743A206E6F2D7265706561743B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F706572';
wwv_flow_api.g_varchar2_table(191) := '74792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D3A696E64657465726D696E617465202B206C6162656C3A6166746572207B5C6E20206F7061636974793A20313B5C6E20206261636B67726F756E642D696D6167';
wwv_flow_api.g_varchar2_table(192) := '653A206E6F6E653B5C6E202077696474683A203870783B5C6E20206865696768743A203270783B5C6E2020626F726465722D7261646975733A203270783B5C6E20206D617267696E3A20367078203370783B5C6E20202D7765626B69742D7472616E7366';
wwv_flow_api.g_varchar2_table(193) := '6F726D3A207363616C6528302E3735293B5C6E20207472616E73666F726D3A207363616C6528302E3735293B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D';
wwv_flow_api.g_varchar2_table(194) := '5C22636865636B626F785C225D3A636865636B6564202B206C6162656C3A61667465722C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C';
wwv_flow_api.g_varchar2_table(195) := '225D3A636865636B6564202B206C6162656C3A6265666F7265207B5C6E20206F7061636974793A20313B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164';
wwv_flow_api.g_varchar2_table(196) := '696F5C225D207B5C6E20202F2A20556E636865636B65645C6E202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(197) := '3D3D3D202A2F5C6E20202F2A20436865636B65645C6E202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(198) := '202A2F5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D202B206C6162656C3A6265666F7265207B5C6E2020626F726465722D726164697573';
wwv_flow_api.g_varchar2_table(199) := '3A20313670783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D202B206C6162656C3A6166746572207B5C6E20206D617267696E3A203570';
wwv_flow_api.g_varchar2_table(200) := '783B5C6E202077696474683A203470783B5C6E20206865696768743A203470783B5C6E2020626F726465722D7261646975733A20313030253B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D69';
wwv_flow_api.g_varchar2_table(201) := '6E7075745B747970653D5C22726164696F5C225D3A636865636B6564202B206C6162656C3A6166746572207B5C6E20206F7061636974793A20313B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F72';
wwv_flow_api.g_varchar2_table(202) := '2D2D737461636B6564202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574207B5C6E202070616464696E673A2030203470783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D';
wwv_flow_api.g_varchar2_table(203) := '726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F207B5C6E20206D617267696E2D72696768743A202D3170783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D';
wwv_flow_api.g_varchar2_table(204) := '726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E707574207B5C6E20202F2A20556E636865636B6564202A2F5C6E20202F2A20436865636B6564202A2F5C6E20202F2A20466F6375736564202A2F';
wwv_flow_api.g_varchar2_table(205) := '5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E707574202B206C6162656C207B5C6E20207061646469';
wwv_flow_api.g_varchar2_table(206) := '6E673A20327078203870783B5C6E20202D7765626B69742D7472616E736974696F6E3A206261636B67726F756E642D636F6C6F7220302E31357320656173653B5C6E20207472616E736974696F6E3A206261636B67726F756E642D636F6C6F7220302E31';
wwv_flow_api.g_varchar2_table(207) := '357320656173653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E707574202B206C6162656C3A6265';
wwv_flow_api.g_varchar2_table(208) := '666F72652C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E707574202B206C6162656C3A6166746572207B5C';
wwv_flow_api.g_varchar2_table(209) := '6E2020636F6E74656E743A20696E697469616C3B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075';
wwv_flow_api.g_varchar2_table(210) := '743A636865636B6564202B206C6162656C207B5C6E2020666F6E742D7765696768743A20626F6C643B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E';
wwv_flow_api.g_varchar2_table(211) := '612D50726F70657274792D726164696F2D696E7075743A666F637573202B206C6162656C207B5C6E20207A2D696E6465783A20313B5C6E20206F75746C696E653A206E6F6E653B5C6E2020626F726465722D7261646975733A203270783B5C6E7D5C6E2E';
wwv_flow_api.g_varchar2_table(212) := '75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75703A666F637573207B5C6E20206F75746C696E653A206E6F6E653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274';
wwv_flow_api.g_varchar2_table(213) := '792D726164696F207B5C6E2020646973706C61793A20696E6C696E652D626C6F636B3B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E707574207B5C6E2020646973706C61793A20696E6C';
wwv_flow_api.g_varchar2_table(214) := '696E652D626C6F636B3B5C6E20206D617267696E3A203270783B5C6E202077696474683A20313670783B5C6E20206865696768743A20313670783B5C6E2020766572746963616C2D616C69676E3A20746F703B5C6E7D5C6E2E75742D50726F7065727479';
wwv_flow_api.g_varchar2_table(215) := '456469746F72202E612D50726F70657274792D726164696F2D6C6162656C207B5C6E2020646973706C61793A20696E6C696E652D626C6F636B3B5C6E202070616464696E673A203270783B5C6E2020766572746963616C2D616C69676E3A20746F703B5C';
wwv_flow_api.g_varchar2_table(216) := '6E2020666F6E742D73697A653A20313270783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D726164696F47726F7570207B5C6E202070616464696E672D746F703A20';
wwv_flow_api.g_varchar2_table(217) := '3670783B5C6E202070616464696E672D626F74746F6D3A203670783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E5365743A6265666F72652C5C6E2E75742D50';
wwv_flow_api.g_varchar2_table(218) := '726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E5365743A6166746572207B5C6E2020646973706C61793A207461626C653B5C6E2020636F6E74656E743A2027273B5C6E7D5C6E2E75742D50';
wwv_flow_api.g_varchar2_table(219) := '726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E5365743A6166746572207B5C6E2020636C6561723A20626F74683B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D5072';
wwv_flow_api.g_varchar2_table(220) := '6F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F207B5C6E2020666C6F61743A206C6566743B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D';
wwv_flow_api.g_varchar2_table(221) := '726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E707574207B5C6E2020706F736974696F6E3A206162736F6C7574653B5C6E20206F766572666C6F773A2068696464656E3B5C6E2020636C69703A';
wwv_flow_api.g_varchar2_table(222) := '20726563742830203020302030293B5C6E20206D617267696E3A202D3170783B5C6E202070616464696E673A20303B5C6E202077696474683A203170783B5C6E20206865696768743A203170783B5C6E2020626F726465723A20303B5C6E7D5C6E2E7574';
wwv_flow_api.g_varchar2_table(223) := '2D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A64697361626C6564202B206C6162656C207B5C6E20206F706163';
wwv_flow_api.g_varchar2_table(224) := '6974793A20302E353B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E707574202B206C6162656C207B';
wwv_flow_api.g_varchar2_table(225) := '5C6E20206D696E2D77696474683A20343870783B5C6E2020746578742D616C69676E3A2063656E7465723B5C6E20206C696E652D6865696768743A20323070783B5C6E2020626F726465722D7261646975733A203270783B5C6E7D5C6E2E75742D50726F';
wwv_flow_api.g_varchar2_table(226) := '7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E707574202B206C6162656C202E612D49636F6E207B5C6E20206D617267696E3A2032';
wwv_flow_api.g_varchar2_table(227) := '70783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D737461636B6564207B5C6E2020706F736974696F6E3A2072656C61746976653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50';
wwv_flow_api.g_varchar2_table(228) := '726F70657274792D2D737461636B6564202E612D50726F70657274792D6C6162656C436F6E7461696E65722C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6669';
wwv_flow_api.g_varchar2_table(229) := '656C64436F6E7461696E6572207B5C6E2020646973706C61793A20626C6F636B3B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6C6162656C436F6E7461';
wwv_flow_api.g_varchar2_table(230) := '696E6572207B5C6E20206D617267696E2D72696768743A20363470783B5C6E202070616464696E672D626F74746F6D3A20303B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D737461636B6564202E612D50';
wwv_flow_api.g_varchar2_table(231) := '726F70657274792D6669656C64436F6E7461696E6572207B5C6E202070616464696E672D746F703A20303B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D';
wwv_flow_api.g_varchar2_table(232) := '627574746F6E436F6E7461696E6572207B5C6E2020706F736974696F6E3A206162736F6C7574653B5C6E2020746F703A20303B5C6E202072696768743A20303B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D';
wwv_flow_api.g_varchar2_table(233) := '2D737461636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E6572202B202E612D50726F70657274792D6669656C64436F6E7461696E6572207B5C6E202070616464696E672D746F703A203470783B5C6E7D5C6E2E75742D50726F';
wwv_flow_api.g_varchar2_table(234) := '7065727479456469746F72202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E6572202E612D427574746F6E2D2D717569636B5069636B207B5C6E20206D617267696E2D6C6566743A20';
wwv_flow_api.g_varchar2_table(235) := '3870783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D7363726F6C6C61626C65207B5C6E2020646973706C61793A20626C6F636B3B5C6E20206F766572666C6F773A206175746F3B5C6E7D5C6E2E75742D';
wwv_flow_api.g_varchar2_table(236) := '50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C436F6E7461696E65722D2D77697468427574746F6E73207B5C6E2020646973706C61793A207461626C652D63656C6C3B5C6E20207461626C652D6C61796F75743A206175';
wwv_flow_api.g_varchar2_table(237) := '746F3B5C6E202070616464696E672D626F74746F6D3A203870783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C436F6E7461696E65722D2D68696464656E4C6162656C207B5C6E202070616464';
wwv_flow_api.g_varchar2_table(238) := '696E673A20303B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E6572207B5C6E202070616464696E672D6C6566743A20302021696D706F7274616E743B5C6E7D5C6E2E75742D';
wwv_flow_api.g_varchar2_table(239) := '50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E65722D2D70756C6C5269676874207B5C6E2020666C6F61743A2072696768743B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50';
wwv_flow_api.g_varchar2_table(240) := '726F70657274792E69732D6368616E676564202E612D50726F70657274792D6C6162656C436F6E7461696E65723A6265666F7265207B5C6E2020706F736974696F6E3A206162736F6C7574653B5C6E2020746F703A203170783B5C6E2020626F74746F6D';
wwv_flow_api.g_varchar2_table(241) := '3A20303B5C6E20206C6566743A203170783B5C6E2020646973706C61793A20696E6C696E652D626C6F636B3B5C6E202077696474683A203370783B5C6E2020636F6E74656E743A2027273B5C6E20206F7061636974793A20302E353B5C6E7D5C6E2E7574';
wwv_flow_api.g_varchar2_table(242) := '2D50726F7065727479456469746F72202E612D50726F70657274792E69732D6368616E6765643A686F766572202E612D50726F70657274792D6C6162656C436F6E7461696E65723A6265666F72652C5C6E2E75742D50726F7065727479456469746F7220';
wwv_flow_api.g_varchar2_table(243) := '2E612D50726F70657274792E69732D6368616E6765642E69732D666F6375736564202E612D50726F70657274792D6C6162656C436F6E7461696E65723A6265666F7265207B5C6E20206F7061636974793A20313B5C6E7D5C6E2E75742D50726F70657274';
wwv_flow_api.g_varchar2_table(244) := '79456469746F72202E612D50726F70657274792D6C6162656C2C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D756E6974207B5C6E2020646973706C61793A20626C6F636B3B5C6E20202D6D732D746578742D6F7665';
wwv_flow_api.g_varchar2_table(245) := '72666C6F773A20656C6C69707369733B5C6E2020746578742D6F766572666C6F773A20656C6C69707369733B5C6E20206F766572666C6F773A2068696464656E3B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(246) := '2D6669656C64207B5C6E2020646973706C61793A20626C6F636B3B5C6E202077696474683A20313030253B5C6E20206261636B67726F756E642D636C69703A20626F726465722D626F783B5C6E2020626F726465723A203020736F6C69643B5C6E7D5C6E';
wwv_flow_api.g_varchar2_table(247) := '2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C642D2D7465787461726561207B5C6E20206D696E2D6865696768743A20343870783B5C6E2020666F6E742D66616D696C793A2053464D6F6E6F2D526567756C6172';
wwv_flow_api.g_varchar2_table(248) := '2C204D656E6C6F2C204D6F6E61636F2C20436F6E736F6C61732C205C224C696265726174696F6E204D6F6E6F5C222C205C22436F7572696572204E65775C222C206D6F6E6F73706163653B5C6E2020726573697A653A20766572746963616C3B5C6E7D5C';
wwv_flow_api.g_varchar2_table(249) := '6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792E6A732D73686F77416C6C2C5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702E6A732D73';
wwv_flow_api.g_varchar2_table(250) := '686F77416C6C207B5C6E2020646973706C61793A206E6F6E653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722E6A732D73686F77416C6C202E612D50726F70657274792E6A732D73686F77416C';
wwv_flow_api.g_varchar2_table(251) := '6C2C5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722E6A732D73686F77416C6C202E612D50726F7065727479456469746F722D70726F706572747947726F75702E6A732D73686F77416C6C207B5C6E2020';
wwv_flow_api.g_varchar2_table(252) := '646973706C61793A20626C6F636B3B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461636B65642E6A732D73686F77416C6C202E612D50726F70657274792E6A732D73686F77416C6C20';
wwv_flow_api.g_varchar2_table(253) := '7B5C6E2020646973706C61793A207461626C653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F7847726F75703A666F637573207B5C6E20206F75746C696E653A206E6F6E653B5C6E7D5C6E';
wwv_flow_api.g_varchar2_table(254) := '2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E707574207B5C6E2020646973706C61793A20696E6C696E652D626C6F636B3B5C6E20206D617267696E3A203270783B5C6E202077696474683A20';
wwv_flow_api.g_varchar2_table(255) := '313670783B5C6E20206865696768743A20313670783B5C6E2020766572746963616C2D616C69676E3A20746F703B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D6C6162656C207B5C6E';
wwv_flow_api.g_varchar2_table(256) := '2020646973706C61793A20696E6C696E652D626C6F636B3B5C6E202070616464696E673A203270783B5C6E2020766572746963616C2D616C69676E3A20746F703B5C6E2020666F6E742D73697A653A20313270783B5C6E7D5C6E2E75742D50726F706572';
wwv_flow_api.g_varchar2_table(257) := '7479456469746F72202E612D50726F70657274792D7365744974656D735461626C65207B5C6E202077696474683A20313030253B5C6E2020626F726465722D73706163696E673A20303B5C6E2020626F726465722D636F6C6C617073653A20636F6C6C61';
wwv_flow_api.g_varchar2_table(258) := '7073653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D735461626C65207464207B5C6E202070616464696E672D626F74746F6D3A203470783B5C6E7D5C6E2E75742D50726F706572747945';
wwv_flow_api.g_varchar2_table(259) := '6469746F72202E612D50726F70657274792D7365744974656D735461626C652074723A6C6173742D6368696C64207464207B5C6E202070616464696E672D626F74746F6D3A20303B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50';
wwv_flow_api.g_varchar2_table(260) := '726F70657274792D7365744974656D734865616465722D686561646572207B5C6E2020746578742D616C69676E3A206C6566743B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D735461626C';
wwv_flow_api.g_varchar2_table(261) := '652D72656D6F7665436F6C207B5C6E202077696474683A20343070783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E207B5C6E20202D2D612D627574746F6E2D70616464696E672D793A2036';
wwv_flow_api.g_varchar2_table(262) := '70783B5C6E202077696474683A20313030253B5C6E202077686974652D73706163653A206E6F726D616C3B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F';
wwv_flow_api.g_varchar2_table(263) := '70657274792D6C6162656C436F6E7461696E6572202E612D50726F70657274792D6C6162656C207B5C6E202070616464696E672D72696768743A20313270783B5C6E202070616464696E672D626F74746F6D3A203270783B5C6E202070616464696E672D';
wwv_flow_api.g_varchar2_table(264) := '6C6566743A20313270783B5C6E2020666F6E742D73697A653A20313170783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D6669656C6443';
wwv_flow_api.g_varchar2_table(265) := '6F6E7461696E65722C5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E6572207B5C6E202070616464696E672D746F';
wwv_flow_api.g_varchar2_table(266) := '703A20303B5C6E202070616464696E672D626F74746F6D3A203870783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D2D737461636B6564';
wwv_flow_api.g_varchar2_table(267) := '202E612D50726F70657274792D627574746F6E436F6E7461696E6572207B5C6E202070616464696E672D746F703A203470783B5C6E202070616464696E672D626F74746F6D3A203470783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E';
wwv_flow_api.g_varchar2_table(268) := '612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6C6162656C436F6E7461696E6572202E612D50726F70657274792D6C6162656C207B5C6E2020706164';
wwv_flow_api.g_varchar2_table(269) := '64696E673A2034707820303B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E752D48434D202E612D50726F70657274792D6669656C64207B5C6E2020626F726465723A2031707820736F6C69642021696D706F7274616E743B5C6E7D5C6E';
wwv_flow_api.g_varchar2_table(270) := '2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D77726170706572202E612D50726F7065727479456469746F722D70726F706572747947726F75703A66697273742D6368696C64207B5C6E20206D617267696E';
wwv_flow_api.g_varchar2_table(271) := '2D746F703A203870783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E75692D6469616C6F67202E612D50726F7065727479456469746F72207B5C6E20206F766572666C6F773A206175746F3B5C6E20206D61782D6865696768743A2034';
wwv_flow_api.g_varchar2_table(272) := '303070783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F7570207B5C6E2020646973706C61793A20626C6F636B3B5C6E20206261636B67726F756E642D636C6970';
wwv_flow_api.g_varchar2_table(273) := '3A2070616464696E672D626F783B5C6E20202D7765626B69742D7472616E736974696F6E3A206261636B67726F756E642D636F6C6F7220302E317320656173652C202D7765626B69742D626F782D736861646F7720302E317320656173653B5C6E202074';
wwv_flow_api.g_varchar2_table(274) := '72616E736974696F6E3A206261636B67726F756E642D636F6C6F7220302E317320656173652C202D7765626B69742D626F782D736861646F7720302E317320656173653B5C6E20207472616E736974696F6E3A206261636B67726F756E642D636F6C6F72';
wwv_flow_api.g_varchar2_table(275) := '20302E317320656173652C20626F782D736861646F7720302E317320656173653B5C6E20207472616E736974696F6E3A206261636B67726F756E642D636F6C6F7220302E317320656173652C20626F782D736861646F7720302E317320656173652C202D';
wwv_flow_api.g_varchar2_table(276) := '7765626B69742D626F782D736861646F7720302E317320656173653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702E69732D636F6C6C6170736564202E612D';
wwv_flow_api.g_varchar2_table(277) := '50726F7065727479456469746F722D70726F706572747947726F75702D686561646572207B5C6E2020626F726465722D626F74746F6D3A206E6F6E653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F706572747945646974';
wwv_flow_api.g_varchar2_table(278) := '6F722D70726F706572747947726F75702E69732D636F6C6C6170736564202E612D50726F7065727479456469746F722D70726F706572747947726F75702D626F6479207B5C6E2020646973706C61793A206E6F6E653B5C6E7D5C6E2E75742D50726F7065';
wwv_flow_api.g_varchar2_table(279) := '727479456469746F72202E612D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75703A66697273742D6368696C64207B5C6E20206D617267696E2D746F703A203470783B5C6E7D5C6E2E75';
wwv_flow_api.g_varchar2_table(280) := '742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572207B5C6E20206D617267696E2D746F703A203470783B5C6E202070616464696E673A2031327078203870783B5C';
wwv_flow_api.g_varchar2_table(281) := '6E2020626F726465722D77696474683A20303B5C6E20202D7765626B69742D7472616E736974696F6E3A206D617267696E20302E317320656173653B5C6E20207472616E736974696F6E3A206D617267696E20302E317320656173653B5C6E7D5C6E406D';
wwv_flow_api.g_varchar2_table(282) := '65646961206F6E6C792073637265656E20616E6420286D61782D77696474683A2031303234707829207B5C6E20202E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561';
wwv_flow_api.g_varchar2_table(283) := '646572207B5C6E2020202070616464696E672D746F703A203470783B5C6E2020202070616464696E672D626F74746F6D3A203470783B5C6E20207D5C6E7D5C6E406D65646961206F6E6C792073637265656E20616E6420286D696E2D77696474683A2031';
wwv_flow_api.g_varchar2_table(284) := '30323570782920616E6420286D61782D77696474683A2031323739707829207B5C6E20202E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572207B5C6E202020';
wwv_flow_api.g_varchar2_table(285) := '2070616464696E672D746F703A203670783B5C6E2020202070616464696E672D626F74746F6D3A203670783B5C6E20207D5C6E7D5C6E406D65646961206F6E6C792073637265656E20616E6420286D696E2D77696474683A203132383170782920616E64';
wwv_flow_api.g_varchar2_table(286) := '20286D61782D77696474683A2031363739707829207B5C6E20202E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572207B5C6E2020202070616464696E672D74';
wwv_flow_api.g_varchar2_table(287) := '6F703A203870783B5C6E2020202070616464696E672D626F74746F6D3A203870783B5C6E20207D5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465';
wwv_flow_api.g_varchar2_table(288) := '723A686F766572202E612D49636F6E207B5C6E20206F7061636974793A20313B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572202E612D4963';
wwv_flow_api.g_varchar2_table(289) := '6F6E207B5C6E20206D617267696E3A20327078203670782032707820303B5C6E2020626F726465722D7261646975733A203270783B5C6E20206F7061636974793A20302E353B5C6E20202D7765626B69742D7472616E736974696F6E3A20302E32732065';
wwv_flow_api.g_varchar2_table(290) := '6173653B5C6E20207472616E736974696F6E3A20302E327320656173653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F7065727479456469746F722D70726F706572747947726F75702D68656164657220';
wwv_flow_api.g_varchar2_table(291) := '2E612D49636F6E207B5C6E20206D617267696E3A20327078203020327078203670783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572202E61';
wwv_flow_api.g_varchar2_table(292) := '2D49636F6E2E69636F6E2D72696768742D6172726F773A6265666F7265207B5C6E2020636F6E74656E743A205C225C5C453044385C223B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F';
wwv_flow_api.g_varchar2_table(293) := '706572747947726F75702D686561646572202E612D49636F6E2E69636F6E2D646F776E2D6172726F773A6265666F7265207B5C6E2020636F6E74656E743A205C225C5C653063325C223B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E61';
wwv_flow_api.g_varchar2_table(294) := '2D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465722E69732D666F6375736564207B5C6E2020706F736974696F6E3A2072656C61746976653B5C6E20207A2D696E6465783A203130303B5C6E20206F75746C696E65';
wwv_flow_api.g_varchar2_table(295) := '3A206E6F6E653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465722E69732D666F6375736564202E612D49636F6E207B5C6E20206F7061636974';
wwv_flow_api.g_varchar2_table(296) := '793A20313B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D7469746C65207B5C6E2020646973706C61793A20696E6C696E652D626C6F636B3B5C6E20206D61';
wwv_flow_api.g_varchar2_table(297) := '7267696E3A20303B5C6E202070616464696E673A20303B5C6E2020766572746963616C2D616C69676E3A20746F703B5C6E2020666F6E742D7765696768743A203630303B5C6E2020666F6E742D73697A653A20313470783B5C6E20206C696E652D686569';
wwv_flow_api.g_varchar2_table(298) := '6768743A20323070783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722E69732D656D707479207B5C6E2020646973706C61793A202D7765626B69742D626F783B5C6E2020646973706C61793A20';
wwv_flow_api.g_varchar2_table(299) := '2D6D732D666C6578626F783B5C6E2020646973706C61793A20666C65783B5C6E20206F766572666C6F773A2068696464656E3B5C6E20206865696768743A20313030253B5C6E20202D7765626B69742D626F782D616C69676E3A2063656E7465723B5C6E';
wwv_flow_api.g_varchar2_table(300) := '20202D6D732D666C65782D616C69676E3A2063656E7465723B5C6E2020616C69676E2D6974656D733A2063656E7465723B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D6D657373616765207B';
wwv_flow_api.g_varchar2_table(301) := '5C6E202070616464696E673A20313270783B5C6E202077696474683A20313030253B5C6E2020746578742D616C69676E3A2063656E7465723B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D6D';
wwv_flow_api.g_varchar2_table(302) := '65737361676554657874207B5C6E20206D617267696E3A20303B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D49636F6E202B202E612D50726F7065727479456469746F722D6D65737361676554657874207B5C6E20206D61726769';
wwv_flow_api.g_varchar2_table(303) := '6E2D746F703A203870783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D65646974506172656E74207B5C6E202070616464696E673A20367078203870783B5C6E2020746578742D616C69676E';
wwv_flow_api.g_varchar2_table(304) := '3A2063656E7465723B5C6E7D5C6E406D65646961206F6E6C792073637265656E20616E6420286D61782D77696474683A2031303234707829207B5C6E20202E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D65';
wwv_flow_api.g_varchar2_table(305) := '646974506172656E74207B5C6E2020202070616464696E673A20327078203870783B5C6E20207D5C6E7D5C6E406D65646961206F6E6C792073637265656E20616E6420286D696E2D77696474683A203130323570782920616E6420286D61782D77696474';
wwv_flow_api.g_varchar2_table(306) := '683A2031323739707829207B5C6E20202E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D65646974506172656E74207B5C6E2020202070616464696E673A20347078203870783B5C6E20207D5C6E7D5C6E2E75';
wwv_flow_api.g_varchar2_table(307) := '742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572207B5C6E2020706F736974696F6E3A2072656C61746976653B5C6E2020646973706C61793A202D7765626B69742D626F783B5C6E2020646973706C';
wwv_flow_api.g_varchar2_table(308) := '61793A202D6D732D666C6578626F783B5C6E2020646973706C61793A20666C65783B5C6E202070616464696E673A20303B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E61';
wwv_flow_api.g_varchar2_table(309) := '2D50726F7065727479456469746F722D66696C7465722D69636F6E207B5C6E2020706F736974696F6E3A206162736F6C7574653B5C6E2020746F703A20303B5C6E20206C6566743A20303B5C6E20206D617267696E3A203870783B5C6E20206F70616369';
wwv_flow_api.g_varchar2_table(310) := '74793A20302E353B5C6E20202D7765626B69742D7472616E736974696F6E3A20302E317320656173653B5C6E20207472616E736974696F6E3A20302E317320656173653B5C6E2020706F696E7465722D6576656E74733A206E6F6E653B5C6E7D5C6E2E75';
wwv_flow_api.g_varchar2_table(311) := '742D50726F7065727479456469746F72202E752D52544C202E612D50726F7065727479456469746F722D66696C746572202E612D50726F7065727479456469746F722D66696C7465722D69636F6E207B5C6E20206C6566743A206175746F3B5C6E202072';
wwv_flow_api.g_varchar2_table(312) := '696768743A20303B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E612D50726F70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D7465';
wwv_flow_api.g_varchar2_table(313) := '787429207B5C6E20202D7765626B69742D626F782D73697A696E673A20626F726465722D626F783B5C6E2020626F782D73697A696E673A20626F726465722D626F783B5C6E202070616464696E673A20387078203870782038707820333270783B5C6E20';
wwv_flow_api.g_varchar2_table(314) := '206865696768743A20333270783B5C6E20206C696E652D6865696768743A20333270783B5C6E2020626F726465722D7261646975733A203270783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274';
wwv_flow_api.g_varchar2_table(315) := '79456469746F722D66696C746572202E612D50726F70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D7465787429207B5C6E202070616464696E673A20387078203332707820387078203870783B5C6E7D5C6E2E75';
wwv_flow_api.g_varchar2_table(316) := '742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E612D50726F70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D74657874293A666F637573202B202E612D';
wwv_flow_api.g_varchar2_table(317) := '49636F6E207B5C6E20206F7061636974793A20313B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E612D427574746F6E2D2D737469636B7946696C746572207B5C6E202070';
wwv_flow_api.g_varchar2_table(318) := '6F736974696F6E3A206162736F6C7574653B5C6E2020746F703A20303B5C6E202072696768743A20303B5C6E2020626F74746F6D3A20303B5C6E20207A2D696E6465783A2031303B5C6E20206D617267696E3A203470783B5C6E202070616464696E673A';
wwv_flow_api.g_varchar2_table(319) := '203470783B5C6E20206F7061636974793A20303B5C6E20202D7765626B69742D7472616E736974696F6E3A206F70616369747920302E317320656173653B5C6E20207472616E736974696F6E3A206F70616369747920302E317320656173653B5C6E7D5C';
wwv_flow_api.g_varchar2_table(320) := '6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C7465723A666F6375732D77697468696E202E612D50726F70657274792D6669656C64202B202E612D49636F6E207B5C6E20206F7061636974793A20';
wwv_flow_api.g_varchar2_table(321) := '313B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E612D50726F70657274792D6669656C643A666F637573207E202E612D427574746F6E2D2D737469636B7946696C746572';
wwv_flow_api.g_varchar2_table(322) := '2C5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E612D427574746F6E2D2D737469636B7946696C7465722E69732D6163746976652C5C6E2E75742D50726F7065727479456469746F';
wwv_flow_api.g_varchar2_table(323) := '72202E612D50726F7065727479456469746F722D66696C746572202E612D427574746F6E2D2D737469636B7946696C7465723A666F637573207B5C6E20206F7061636974793A20313B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D';
wwv_flow_api.g_varchar2_table(324) := '50726F70657274792D686967686C69676874207B5C6E202070616464696E673A2032707820303B5C6E2020626F726465722D7261646975733A203270783B5C6E20202D7765626B69742D7472616E736974696F6E3A20302E317320656173653B5C6E2020';
wwv_flow_api.g_varchar2_table(325) := '7472616E736974696F6E3A20302E317320656173653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6E6F74466F756E64207B5C6E202070616464696E673A20312E3672656D3B5C6E2020746578742D616C69';
wwv_flow_api.g_varchar2_table(326) := '676E3A2063656E7465723B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6E6F74466F756E64202E612D49636F6E207B5C6E20206D617267696E2D626F74746F6D3A203870783B5C6E7D5C6E2E75742D50726F';
wwv_flow_api.g_varchar2_table(327) := '7065727479456469746F72202E612D50726F706572747947726F75702D6974656D207B5C6E2020626F726465722D746F703A2031707820736F6C69643B5C6E2020626F726465722D626F74746F6D2D77696474683A20303B5C6E7D5C6E2E75742D50726F';
wwv_flow_api.g_varchar2_table(328) := '7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D626F6479207B5C6E202070616464696E673A2034707820303B5C6E7D5C6E225D7D';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(776880780679146571)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_file_name=>'css/base.css.map'
,p_mime_type=>'application/json'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '2E75742D50726F7065727479456469746F72207B0A202020202F2A203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(2) := '3D3D0A2020202050726F7065727479202850726F706572747920456469746F722050726F70657274696573290A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(3) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A202020202F2A2A0A202020202A2050726F706572747920436F6D706F6E656E740A202020202A0A202020202A205468697320697320612070726F706572747920746861742069732075';
wwv_flow_api.g_varchar2_table(4) := '7365642077697468696E2074686520636F6E74657874206F6620612070726F706572747920656469746F7220746F0A202020202A2070726F766964652061206C6162656C20616E6420696E707574206669656C642E0A202020202A0A202020202A204578';
wwv_flow_api.g_varchar2_table(5) := '616D706C652048544D4C3A0A202020202A0A202020202A203C64697620636C6173733D22612D50726F7065727479223E0A202020202A2020203C64697620636C6173733D22612D50726F70657274792D6C6162656C436F6E7461696E6572223E0A202020';
wwv_flow_api.g_varchar2_table(6) := '202A20202020203C6C6162656C20636C6173733D22612D50726F70657274792D6C6162656C223E4C6162656C3C2F6C6162656C3E0A202020202A2020203C2F6469763E0A202020202A2020203C64697620636C6173733D22612D50726F70657274792D66';
wwv_flow_api.g_varchar2_table(7) := '69656C64436F6E7461696E6572223E0A202020202A20202020203C696E70757420747970653D22746578742220636C6173733D22612D50726F70657274792D6669656C64223E0A202020202A2020203C2F6469763E0A202020202A203C2F6469763E0A20';
wwv_flow_api.g_varchar2_table(8) := '2020202A2F0A202020202E612D50726F7065727479207B0A20202020706F736974696F6E3A2072656C61746976653B0A20202020646973706C61793A207461626C653B0A202020206D617267696E3A20303B0A2020202070616464696E673A20303B0A20';
wwv_flow_api.g_varchar2_table(9) := '20202077696474683A20313030253B0A202020207461626C652D6C61796F75743A206175746F3B0A202020207D0A0A202020202E612D50726F7065727479202E612D49636F6E2E69636F6E2D7265717569726564207B0A20202020646973706C61793A20';
wwv_flow_api.g_varchar2_table(10) := '6E6F6E653B0A202020207D0A0A202020202E612D50726F70657274792D627574746F6E436F6E7461696E65722C0A202020202E612D50726F70657274792D6C6162656C436F6E7461696E65722C0A202020202E612D50726F70657274792D756E6974436F';
wwv_flow_api.g_varchar2_table(11) := '6E7461696E6572207B0A20202020646973706C61793A207461626C652D63656C6C3B0A20202020766572746963616C2D616C69676E3A206D6964646C653B0A202020207D0A0A202020202E612D50726F70657274792D627574746F6E436F6E7461696E65';
wwv_flow_api.g_varchar2_table(12) := '722C0A202020202E612D50726F70657274792D6C6162656C436F6E7461696E65722C0A202020202E612D50726F70657274792D6669656C64436F6E7461696E65722C0A202020202E612D50726F70657274792D756E6974436F6E7461696E6572207B0A20';
wwv_flow_api.g_varchar2_table(13) := '20202070616464696E673A20347078203870783B0A202020207D0A0A20202020406D65646961206F6E6C792073637265656E20616E6420286D61782D77696474683A2031303234707829207B0A202020202E612D50726F70657274792D627574746F6E43';
wwv_flow_api.g_varchar2_table(14) := '6F6E7461696E65722C0A202020202E612D50726F70657274792D6C6162656C436F6E7461696E65722C0A202020202E612D50726F70657274792D6669656C64436F6E7461696E65722C0A202020202E612D50726F70657274792D756E6974436F6E746169';
wwv_flow_api.g_varchar2_table(15) := '6E6572207B0A202020202020202070616464696E673A20327078203870783B0A202020207D0A202020207D0A0A202020202E612D50726F70657274792D6C6162656C436F6E7461696E6572207B0A2020202070616464696E672D72696768743A20303B0A';
wwv_flow_api.g_varchar2_table(16) := '202020206D696E2D77696474683A2031313270783B0A202020207D0A0A202020202374656D706C6174654F7074696F6E73446C675045202E612D50726F70657274792D6C6162656C436F6E7461696E6572207B0A202020206D696E2D77696474683A2031';
wwv_flow_api.g_varchar2_table(17) := '343470783B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274793A6E6F74282E612D50726F70657274792D2D737461636B656429202E612D50726F70657274792D6C6162656C43';
wwv_flow_api.g_varchar2_table(18) := '6F6E7461696E6572207B0A20202020646973706C61793A207461626C652D726F773B0A2020202077696474683A20313030253B0A202020207D0A0A202020202E612D50726F70657274792D6669656C64436F6E7461696E6572207B0A2020202064697370';
wwv_flow_api.g_varchar2_table(19) := '6C61793A207461626C652D63656C6C3B0A2020202077696474683A20313030253B0A20202020766572746963616C2D616C69676E3A206D6964646C653B0A202020207D0A0A202020202E612D50726F70657274792D6669656C64436F6E7461696E65722D';
wwv_flow_api.g_varchar2_table(20) := '2D636F6D626F426F78207B0A2020202070616464696E672D72696768743A20302021696D706F7274616E743B0A202020207D0A0A202020202E612D50726F70657274792D627574746F6E436F6E7461696E65722D2D636F6D626F426F78202E612D427574';
wwv_flow_api.g_varchar2_table(21) := '746F6E207B0A202020206D617267696E2D6C6566743A202D3170783B0A202020207D0A0A202020202E612D50726F70657274792D636F6C6F7250726576696577207B0A20202020646973706C61793A20626C6F636B3B0A2020202077696474683A203132';
wwv_flow_api.g_varchar2_table(22) := '70783B0A202020206865696768743A20313270783B0A20202020626F726465722D7261646975733A20313030253B0A202020207D0A0A202020202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D636F6C6F725069636B6572207B0A';
wwv_flow_api.g_varchar2_table(23) := '2020202070616464696E672D72696768743A20302021696D706F7274616E743B0A202020207D0A0A202020202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D636F6C6F725069636B6572202E612D50726F70657274792D6669656C';
wwv_flow_api.g_varchar2_table(24) := '64207B0A2020202070616464696E672D6C6566743A20323470783B0A20202020626F726465722D746F702D72696768742D7261646975733A20302021696D706F7274616E743B0A20202020626F726465722D626F74746F6D2D72696768742D7261646975';
wwv_flow_api.g_varchar2_table(25) := '733A20302021696D706F7274616E743B0A202020207D0A0A202020202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D636F6C6F725069636B6572202E612D50726F70657274792D636F6C6F7250726576696577207B0A2020202070';
wwv_flow_api.g_varchar2_table(26) := '6F736974696F6E3A206162736F6C7574653B0A202020206D617267696E3A203670783B0A20202020706F696E7465722D6576656E74733A206E6F6E653B0A202020207D0A0A202020202E612D50726F70657274792D627574746F6E436F6E7461696E6572';
wwv_flow_api.g_varchar2_table(27) := '2D2D636F6C6F725069636B6572202E612D427574746F6E207B0A202020206D617267696E2D6C6566743A202D3170783B0A202020207D0A0A202020202E612D50726F70657274792D756E6974436F6E7461696E6572207B0A2020202070616464696E672D';
wwv_flow_api.g_varchar2_table(28) := '6C6566743A20302021696D706F7274616E743B0A2020202077686974652D73706163653A206E6F777261703B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(29) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A2020202050726F7065727479204572726F720A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(30) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020202E612D50726F70657274792E69732D6572726F72202E69636F6E2D6572726F72207B0A202020206D617267696E2D72696768743A203470783B';
wwv_flow_api.g_varchar2_table(31) := '0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A2020202050726F70';
wwv_flow_api.g_varchar2_table(32) := '65727479205761726E696E670A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020';
wwv_flow_api.g_varchar2_table(33) := '202E612D50726F70657274792E69732D7761726E696E67202E69636F6E2D7761726E696E67207B0A202020206D617267696E2D72696768743A203470783B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(34) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A202020204C6162656C20616E6420507265202F20506F737420546578740A202020202A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(35) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020202E612D50726F70657274792D6C6162656C2C0A202020202E612D5072';
wwv_flow_api.g_varchar2_table(36) := '6F70657274792D7365744974656D734865616465722D6865616465722C0A202020202E612D50726F70657274792D756E6974207B0A2020202070616464696E673A2034707820303B0A20202020666F6E742D73697A653A20313270783B0A202020206C69';
wwv_flow_api.g_varchar2_table(37) := '6E652D6865696768743A20313670783B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D6C6162656C2C0A202020202E612D50726F70657274792D726164696F207B0A20202020666F6E742D73697A653A20313270783B';
wwv_flow_api.g_varchar2_table(38) := '0A202020206C696E652D6865696768743A20313670783B0A202020207D0A0A202020202E612D50726F70657274792D756E6974207B0A20202020666F6E742D73697A653A20313170783B0A202020207D0A0A202020202E612D50726F70657274792D6C61';
wwv_flow_api.g_varchar2_table(39) := '62656C2D2D7769746849636F6E207B0A2020202070616464696E673A2034707820303B0A202020206C696E652D6865696768743A20313670783B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(40) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A2020202050726F7065727479204669656C64202D205573656420666F722070726F706572747920656469746F720A20202020';
wwv_flow_api.g_varchar2_table(41) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020202E612D50726F70657274792D6669656C';
wwv_flow_api.g_varchar2_table(42) := '64207B0A2020202070616464696E673A203470783B0A202020206D696E2D6865696768743A20323470783B0A20202020666F6E742D73697A653A20313270783B0A202020206C696E652D6865696768743A20313670783B0A20202020626F726465722D72';
wwv_flow_api.g_varchar2_table(43) := '61646975733A203270783B0A202020207D0A0A202020202E612D50726F70657274792D6669656C643A666F637573207B0A202020206F75746C696E653A206E6F6E653B0A202020207D0A0A202020202E612D50726F70657274792E69732D766172696162';
wwv_flow_api.g_varchar2_table(44) := '6C65202E612D49636F6E2E69636F6E2D7661726961626C65207B0A202020206D617267696E2D72696768743A203470783B0A202020207D0A0A202020202E612D50726F70657274792E69732D7661726961626C65202E612D50726F70657274792D666965';
wwv_flow_api.g_varchar2_table(45) := '6C64207B0A20202020626F726465722D7261646975733A203270783B0A202020207D0A0A202020202F2A2050726F706572747920456469746F722053656C656374204C6973740A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(46) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A202020202E612D50726F70657274792D6669656C642D2D73656C656374207B0A202020206F766572666C6F773A2068';
wwv_flow_api.g_varchar2_table(47) := '696464656E3B0A2020202070616464696E672D72696768743A20333070783B0A20202020746578742D696E64656E743A20302E303170783B0A20202020746578742D6F766572666C6F773A202720273B0A202020206261636B67726F756E642D706F7369';
wwv_flow_api.g_varchar2_table(48) := '74696F6E3A203130302520303B0A202020206261636B67726F756E642D73697A653A203332707820323470783B0A202020206261636B67726F756E642D7265706561743A206E6F2D7265706561743B0A202020202D7765626B69742D617070656172616E';
wwv_flow_api.g_varchar2_table(49) := '63653A206E6F6E653B0A20202020202020202D6D6F7A2D617070656172616E63653A206E6F6E653B0A202020202020202020202020617070656172616E63653A206E6F6E653B0A202020207D0A0A20202020626F64793A6E6F74283A2D6D6F7A2D68616E';
wwv_flow_api.g_varchar2_table(50) := '646C65722D626C6F636B656429202E612D50726F70657274792D6669656C642D2D73656C656374207B0A2020202070616464696E673A20327078203234707820327078203270783B0A202020207D0A0A202020202F2A205465787420417265610A202020';
wwv_flow_api.g_varchar2_table(51) := '203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A202020202E612D50726F70657274792D6669656C64';
wwv_flow_api.g_varchar2_table(52) := '2D2D74657874617265612C0A20202020626F6479202E75692D776964676574202E612D50726F70657274792D6669656C642D2D7465787461726561207B0A2020202070616464696E673A203470783B0A202020206D61782D6865696768743A2033323070';
wwv_flow_api.g_varchar2_table(53) := '783B0A202020206865696768743A206175746F3B0A20202020666F6E742D73697A653A20313170783B0A20202020666F6E742D66616D696C793A2053464D6F6E6F2D526567756C61722C204D656E6C6F2C204D6F6E61636F2C20436F6E736F6C61732C20';
wwv_flow_api.g_varchar2_table(54) := '224C696265726174696F6E204D6F6E6F222C2022436F7572696572204E6577222C206D6F6E6F73706163653B0A202020206C696E652D6865696768743A20313470783B0A202020207D0A0A202020202E612D50726F70657274792D726561644F6E6C7920';
wwv_flow_api.g_varchar2_table(55) := '7B0A20202020666F6E742D7765696768743A20626F6C643B0A20202020666F6E742D73697A653A20313270783B0A202020206C696E652D6865696768743A20323B0A202020207D0A0A202020202E612D50726F70657274792D7365744974656D73546162';
wwv_flow_api.g_varchar2_table(56) := '6C652D686561646572207B0A20202020666F6E742D7765696768743A206E6F726D616C3B0A202020207D0A0A202020202E612D50726F70657274792D7365744974656D735461626C65202E612D50726F70657274792D6669656C64207B0A20202020626F';
wwv_flow_api.g_varchar2_table(57) := '726465722D746F702D72696768742D7261646975733A20303B0A20202020626F726465722D626F74746F6D2D72696768742D7261646975733A20303B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(58) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020436F6D626F20426F78205374796C65730A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(59) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020202E612D50726F70657274792D627574746F6E436F6E7461696E65722D2D636F6D626F426F78202E';
wwv_flow_api.g_varchar2_table(60) := '612D427574746F6E207B0A202020206D617267696E2D6C6566743A203870783B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(61) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020436865636B626F78202B20526164696F20427574746F6E730A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(62) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D2C0A202020202E612D50726F70657274';
wwv_flow_api.g_varchar2_table(63) := '792D726164696F2D696E7075745B747970653D22726164696F225D207B0A20202020706F736974696F6E3A206162736F6C7574653B0A202020206F766572666C6F773A2068696464656E3B0A20202020636C69703A20726563742830203020302030293B';
wwv_flow_api.g_varchar2_table(64) := '0A202020206D617267696E3A202D3170783B0A2020202070616464696E673A20303B0A2020202077696474683A203170783B0A202020206865696768743A203170783B0A20202020626F726465723A20303B0A202020202F2A2044697361626C65642053';
wwv_flow_api.g_varchar2_table(65) := '746174650A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A202020202F2A20466F6375730A';
wwv_flow_api.g_varchar2_table(66) := '202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A202020207D0A0A202020202E612D50726F70';
wwv_flow_api.g_varchar2_table(67) := '657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C2C0A202020202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C207B0A2020';
wwv_flow_api.g_varchar2_table(68) := '2020706F736974696F6E3A2072656C61746976653B0A2020202070616464696E672D72696768743A203870783B0A2020202070616464696E672D6C6566743A20323070783B0A20202020637572736F723A20706F696E7465723B0A202020207D0A0A2020';
wwv_flow_api.g_varchar2_table(69) := '20202E752D52544C202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C2C202E752D52544C0A202020202E612D50726F70657274792D726164696F2D696E7075745B747970';
wwv_flow_api.g_varchar2_table(70) := '653D22726164696F225D202B206C6162656C207B0A2020202070616464696E672D6C6566743A203870783B0A2020202070616464696E672D72696768743A20323070783B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F78';
wwv_flow_api.g_varchar2_table(71) := '2D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A6265666F72652C202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A61667465722C0A20';
wwv_flow_api.g_varchar2_table(72) := '2020202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C3A6265666F72652C0A202020202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D202B';
wwv_flow_api.g_varchar2_table(73) := '206C6162656C3A6166746572207B0A20202020706F736974696F6E3A206162736F6C7574653B0A20202020746F703A203370783B0A202020206C6566743A20303B0A20202020646973706C61793A20626C6F636B3B0A2020202077696474683A20313470';
wwv_flow_api.g_varchar2_table(74) := '783B0A202020206865696768743A20313470783B0A20202020636F6E74656E743A2027273B0A202020202D7765626B69742D7472616E736974696F6E3A202E31323573206F70616369747920656173653B0A202020207472616E736974696F6E3A202E31';
wwv_flow_api.g_varchar2_table(75) := '323573206F70616369747920656173653B0A202020207D0A0A202020202E752D52544C202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A6265666F72652C202E752D52';
wwv_flow_api.g_varchar2_table(76) := '544C202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A61667465722C202E752D52544C0A202020202E612D50726F70657274792D726164696F2D696E7075745B747970';
wwv_flow_api.g_varchar2_table(77) := '653D22726164696F225D202B206C6162656C3A6265666F72652C202E752D52544C0A202020202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C3A6166746572207B0A202020206C656674';
wwv_flow_api.g_varchar2_table(78) := '3A206175746F3B0A2020202072696768743A20303B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A6265666F72652C0A202020202E612D';
wwv_flow_api.g_varchar2_table(79) := '50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C3A6265666F7265207B0A202020207A2D696E6465783A2039303B0A20202020626F726465723A2031707820736F6C69643B0A202020207D0A0A20';
wwv_flow_api.g_varchar2_table(80) := '2020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A61667465722C0A202020202E612D50726F70657274792D726164696F2D696E7075745B747970653D2272616469';
wwv_flow_api.g_varchar2_table(81) := '6F225D202B206C6162656C3A6166746572207B0A202020207A2D696E6465783A203130303B0A202020206F7061636974793A20303B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D226368';
wwv_flow_api.g_varchar2_table(82) := '65636B626F78225D3A64697361626C6564202B206C6162656C2C0A202020202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D3A64697361626C6564202B206C6162656C207B0A202020206F7061636974793A';
wwv_flow_api.g_varchar2_table(83) := '202E353B0A20202020637572736F723A2064656661756C743B0A20202020706F696E7465722D6576656E74733A206E6F6E653B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D2263686563';
wwv_flow_api.g_varchar2_table(84) := '6B626F78225D3A64697361626C6564202B206C6162656C3A6265666F72652C0A202020202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D3A64697361626C6564202B206C6162656C3A6265666F7265207B0A';
wwv_flow_api.g_varchar2_table(85) := '202020206F7061636974793A202E353B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A686F7665723A636865636B6564202B206C6162656C3A61667465722C';
wwv_flow_api.g_varchar2_table(86) := '0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A666F6375733A636865636B6564202B206C6162656C3A61667465722C0A202020202E612D50726F70657274792D726164696F2D';
wwv_flow_api.g_varchar2_table(87) := '696E7075745B747970653D22726164696F225D3A686F7665723A636865636B6564202B206C6162656C3A61667465722C0A202020202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D3A666F6375733A636865';
wwv_flow_api.g_varchar2_table(88) := '636B6564202B206C6162656C3A6166746572207B0A202020206F7061636974793A20313B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(89) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020436865636B626F782053706563696669630A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(90) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D207B0A202020202F2A20556E636865636B6564';
wwv_flow_api.g_varchar2_table(91) := '0A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A202020202F2A20436865636B65640A2020';
wwv_flow_api.g_varchar2_table(92) := '20203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A202020207D0A0A202020202E612D50726F706572';
wwv_flow_api.g_varchar2_table(93) := '74792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A6265666F7265207B0A20202020626F726465722D7261646975733A203270783B0A202020207D0A0A202020202E612D50726F70657274792D63';
wwv_flow_api.g_varchar2_table(94) := '6865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A6166746572207B0A202020206261636B67726F756E642D706F736974696F6E3A203530253B0A202020206261636B67726F756E642D73697A653A203136';
wwv_flow_api.g_varchar2_table(95) := '70783B0A202020206261636B67726F756E642D7265706561743A206E6F2D7265706561743B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A696E6465746572';
wwv_flow_api.g_varchar2_table(96) := '6D696E617465202B206C6162656C3A6166746572207B0A202020206F7061636974793A20313B0A202020206261636B67726F756E642D696D6167653A206E6F6E653B0A2020202077696474683A203870783B0A202020206865696768743A203270783B0A';
wwv_flow_api.g_varchar2_table(97) := '20202020626F726465722D7261646975733A203270783B0A202020206D617267696E3A20367078203370783B0A202020202D7765626B69742D7472616E73666F726D3A207363616C6528302E3735293B0A2020202020202020202020207472616E73666F';
wwv_flow_api.g_varchar2_table(98) := '726D3A207363616C6528302E3735293B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A636865636B6564202B206C6162656C3A61667465722C0A202020202E';
wwv_flow_api.g_varchar2_table(99) := '612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A636865636B6564202B206C6162656C3A6265666F7265207B0A202020206F7061636974793A20313B0A202020207D0A0A202020202F2A2A2A2A';
wwv_flow_api.g_varchar2_table(100) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020526164696F2053706563696669630A202020202A2A';
wwv_flow_api.g_varchar2_table(101) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020202E612D50726F70657274792D726164696F2D';
wwv_flow_api.g_varchar2_table(102) := '696E7075745B747970653D22726164696F225D207B0A202020202F2A20556E636865636B65640A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(103) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A202020202F2A20436865636B65640A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(104) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A202020207D0A0A202020202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C3A6265666F7265207B0A20202020626F726465722D7261646975';
wwv_flow_api.g_varchar2_table(105) := '733A20313670783B0A202020207D0A0A202020202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C3A6166746572207B0A202020206D617267696E3A203570783B0A202020207769647468';
wwv_flow_api.g_varchar2_table(106) := '3A203470783B0A202020206865696768743A203470783B0A20202020626F726465722D7261646975733A20313030253B0A202020207D0A0A202020202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D3A6368';
wwv_flow_api.g_varchar2_table(107) := '65636B6564202B206C6162656C3A6166746572207B0A202020206F7061636974793A20313B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(108) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020596573202F204E6F20427574746F6E730A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(109) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574207B';
wwv_flow_api.g_varchar2_table(110) := '0A2020202070616464696E673A2030203470783B0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F207B0A202020206D617267696E2D726967';
wwv_flow_api.g_varchar2_table(111) := '68743A202D3170783B0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E707574207B0A202020202F2A20556E636865636B6564202A2F';
wwv_flow_api.g_varchar2_table(112) := '0A202020202F2A20436865636B6564202A2F0A202020202F2A20466F6375736564202A2F0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D';
wwv_flow_api.g_varchar2_table(113) := '696E707574202B206C6162656C207B0A2020202070616464696E673A20327078203870783B0A202020202D7765626B69742D7472616E736974696F6E3A206261636B67726F756E642D636F6C6F72202E31357320656173653B0A202020207472616E7369';
wwv_flow_api.g_varchar2_table(114) := '74696F6E3A206261636B67726F756E642D636F6C6F72202E31357320656173653B0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E70';
wwv_flow_api.g_varchar2_table(115) := '7574202B206C6162656C3A6265666F72652C202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E707574202B206C6162656C3A6166746572207B0A20202020636F6E';
wwv_flow_api.g_varchar2_table(116) := '74656E743A20696E697469616C3B0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A636865636B6564202B206C6162656C20';
wwv_flow_api.g_varchar2_table(117) := '7B0A20202020666F6E742D7765696768743A20626F6C643B0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A666F63757320';
wwv_flow_api.g_varchar2_table(118) := '2B206C6162656C207B0A202020207A2D696E6465783A20313B0A202020206F75746C696E653A206E6F6E653B0A20202020626F726465722D7261646975733A203270783B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(119) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020526164696F0A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(120) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020202E612D50726F70657274792D726164696F47726F75703A666F637573207B0A202020206F75746C696E65';
wwv_flow_api.g_varchar2_table(121) := '3A206E6F6E653B0A202020207D0A0A202020202E612D50726F70657274792D726164696F207B0A20202020646973706C61793A20696E6C696E652D626C6F636B3B0A202020207D0A0A202020202E612D50726F70657274792D726164696F2D696E707574';
wwv_flow_api.g_varchar2_table(122) := '207B0A20202020646973706C61793A20696E6C696E652D626C6F636B3B0A202020206D617267696E3A203270783B0A2020202077696474683A20313670783B0A202020206865696768743A20313670783B0A20202020766572746963616C2D616C69676E';
wwv_flow_api.g_varchar2_table(123) := '3A20746F703B0A202020207D0A0A202020202E612D50726F70657274792D726164696F2D6C6162656C207B0A20202020646973706C61793A20696E6C696E652D626C6F636B3B0A2020202070616464696E673A203270783B0A2020202076657274696361';
wwv_flow_api.g_varchar2_table(124) := '6C2D616C69676E3A20746F703B0A20202020666F6E742D73697A653A20313270783B0A202020207D0A0A202020202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D726164696F47726F7570207B0A2020202070616464696E672D74';
wwv_flow_api.g_varchar2_table(125) := '6F703A203670783B0A2020202070616464696E672D626F74746F6D3A203670783B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(126) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020596573202F204E6F20526164696F730A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(127) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E5365743A6265666F72652C202E612D50726F70657274792D726164696F47726F75702D2D62';
wwv_flow_api.g_varchar2_table(128) := '7574746F6E5365743A6166746572207B0A20202020646973706C61793A207461626C653B0A20202020636F6E74656E743A2027273B0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E5365743A61';
wwv_flow_api.g_varchar2_table(129) := '66746572207B0A20202020636C6561723A20626F74683B0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F207B0A20202020666C6F61743A20';
wwv_flow_api.g_varchar2_table(130) := '6C6566743B0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E707574207B0A20202020706F736974696F6E3A206162736F6C7574653B';
wwv_flow_api.g_varchar2_table(131) := '0A202020206F766572666C6F773A2068696464656E3B0A20202020636C69703A20726563742830203020302030293B0A202020206D617267696E3A202D3170783B0A2020202070616464696E673A20303B0A2020202077696474683A203170783B0A2020';
wwv_flow_api.g_varchar2_table(132) := '20206865696768743A203170783B0A20202020626F726465723A20303B0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A64';
wwv_flow_api.g_varchar2_table(133) := '697361626C6564202B206C6162656C207B0A202020206F7061636974793A202E353B0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E';
wwv_flow_api.g_varchar2_table(134) := '707574202B206C6162656C207B0A202020206D696E2D77696474683A20343870783B0A20202020746578742D616C69676E3A2063656E7465723B0A202020206C696E652D6865696768743A20323070783B0A20202020626F726465722D7261646975733A';
wwv_flow_api.g_varchar2_table(135) := '203270783B0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E707574202B206C6162656C202E612D49636F6E207B0A202020206D6172';
wwv_flow_api.g_varchar2_table(136) := '67696E3A203270783B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(137) := '0A20202020537461636B65642050726F706572746965730A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(138) := '2A2A2A2A2A2A2F0A202020202E612D50726F70657274792D2D737461636B6564207B0A20202020706F736974696F6E3A2072656C61746976653B0A202020207D0A0A202020202E612D50726F70657274792D2D737461636B6564202E612D50726F706572';
wwv_flow_api.g_varchar2_table(139) := '74792D6C6162656C436F6E7461696E65722C0A202020202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6669656C64436F6E7461696E6572207B0A20202020646973706C61793A20626C6F636B3B0A202020207D0A0A';
wwv_flow_api.g_varchar2_table(140) := '202020202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6C6162656C436F6E7461696E6572207B0A202020206D617267696E2D72696768743A20363470783B0A2020202070616464696E672D626F74746F6D3A20303B';
wwv_flow_api.g_varchar2_table(141) := '0A202020207D0A0A202020202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6669656C64436F6E7461696E6572207B0A2020202070616464696E672D746F703A20303B0A202020207D0A0A202020202E612D50726F70';
wwv_flow_api.g_varchar2_table(142) := '657274792D2D737461636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E6572207B0A20202020706F736974696F6E3A206162736F6C7574653B0A20202020746F703A20303B0A2020202072696768743A20303B0A202020207D0A';
wwv_flow_api.g_varchar2_table(143) := '0A202020202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E6572202B202E612D50726F70657274792D6669656C64436F6E7461696E6572207B0A2020202070616464696E672D746F70';
wwv_flow_api.g_varchar2_table(144) := '3A203470783B0A202020207D0A0A202020202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E6572202E612D427574746F6E2D2D717569636B5069636B207B0A202020206D617267696E';
wwv_flow_api.g_varchar2_table(145) := '2D6C6566743A203870783B0A202020207D0A0A202020202E612D50726F70657274792D2D7363726F6C6C61626C65207B0A20202020646973706C61793A20626C6F636B3B0A202020206F766572666C6F773A206175746F3B0A202020207D0A0A20202020';
wwv_flow_api.g_varchar2_table(146) := '2E612D50726F70657274792D6C6162656C436F6E7461696E65722D2D77697468427574746F6E73207B0A20202020646973706C61793A207461626C652D63656C6C3B0A202020207461626C652D6C61796F75743A206175746F3B0A202020207061646469';
wwv_flow_api.g_varchar2_table(147) := '6E672D626F74746F6D3A203870783B0A202020207D0A0A202020202E612D50726F70657274792D6C6162656C436F6E7461696E65722D2D68696464656E4C6162656C207B0A2020202070616464696E673A20303B0A202020207D0A0A202020202E612D50';
wwv_flow_api.g_varchar2_table(148) := '726F70657274792D627574746F6E436F6E7461696E6572207B0A2020202070616464696E672D6C6566743A20302021696D706F7274616E743B0A202020207D0A0A202020202E612D50726F70657274792D627574746F6E436F6E7461696E65722D2D7075';
wwv_flow_api.g_varchar2_table(149) := '6C6C5269676874207B0A20202020666C6F61743A2072696768743B0A202020207D0A0A202020202E612D50726F70657274792E69732D6368616E676564202E612D50726F70657274792D6C6162656C436F6E7461696E65723A6265666F7265207B0A2020';
wwv_flow_api.g_varchar2_table(150) := '2020706F736974696F6E3A206162736F6C7574653B0A20202020746F703A203170783B0A20202020626F74746F6D3A20303B0A202020206C6566743A203170783B0A20202020646973706C61793A20696E6C696E652D626C6F636B3B0A20202020776964';
wwv_flow_api.g_varchar2_table(151) := '74683A203370783B0A20202020636F6E74656E743A2027273B0A202020206F7061636974793A202E353B0A202020207D0A0A202020202E612D50726F70657274792E69732D6368616E6765643A686F766572202E612D50726F70657274792D6C6162656C';
wwv_flow_api.g_varchar2_table(152) := '436F6E7461696E65723A6265666F72652C202E612D50726F70657274792E69732D6368616E6765642E69732D666F6375736564202E612D50726F70657274792D6C6162656C436F6E7461696E65723A6265666F7265207B0A202020206F7061636974793A';
wwv_flow_api.g_varchar2_table(153) := '20313B0A202020207D0A0A202020202E612D50726F70657274792D6C6162656C2C0A202020202E612D50726F70657274792D756E6974207B0A20202020646973706C61793A20626C6F636B3B0A202020202D6D732D746578742D6F766572666C6F773A20';
wwv_flow_api.g_varchar2_table(154) := '656C6C69707369733B0A20202020746578742D6F766572666C6F773A20656C6C69707369733B0A202020206F766572666C6F773A2068696464656E3B0A202020207D0A0A202020202E612D50726F70657274792D6669656C64207B0A2020202064697370';
wwv_flow_api.g_varchar2_table(155) := '6C61793A20626C6F636B3B0A2020202077696474683A20313030253B0A202020206261636B67726F756E642D636C69703A20626F726465722D626F783B0A20202020626F726465723A203020736F6C69643B0A202020207D0A0A202020202E612D50726F';
wwv_flow_api.g_varchar2_table(156) := '70657274792D6669656C642D2D7465787461726561207B0A202020206D696E2D6865696768743A20343870783B0A20202020666F6E742D66616D696C793A2053464D6F6E6F2D526567756C61722C204D656E6C6F2C204D6F6E61636F2C20436F6E736F6C';
wwv_flow_api.g_varchar2_table(157) := '61732C20224C696265726174696F6E204D6F6E6F222C2022436F7572696572204E6577222C206D6F6E6F73706163653B0A20202020726573697A653A20766572746963616C3B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(158) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020486964652F53686F7720436C61737365730A202020202A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(159) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020202E612D50726F70657274792E6A732D73686F77416C6C2C0A20202020';
wwv_flow_api.g_varchar2_table(160) := '2E612D50726F7065727479456469746F722D70726F706572747947726F75702E6A732D73686F77416C6C207B0A20202020646973706C61793A206E6F6E653B0A202020207D0A0A202020202E612D50726F7065727479456469746F722E6A732D73686F77';
wwv_flow_api.g_varchar2_table(161) := '416C6C202E612D50726F70657274792E6A732D73686F77416C6C2C0A202020202E612D50726F7065727479456469746F722E6A732D73686F77416C6C202E612D50726F7065727479456469746F722D70726F706572747947726F75702E6A732D73686F77';
wwv_flow_api.g_varchar2_table(162) := '416C6C207B0A20202020646973706C61793A20626C6F636B3B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D2D737461636B65642E6A732D73686F77416C6C202E612D50726F70657274792E6A732D73686F77416C6C207B0A';
wwv_flow_api.g_varchar2_table(163) := '20202020646973706C61793A207461626C653B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(164) := '2A2A2A2A2A2A2A2A2A2A0A202020205661726961626C65204669656C640A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(165) := '2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A2020';
wwv_flow_api.g_varchar2_table(166) := '2020436865636B626F780A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020202E';
wwv_flow_api.g_varchar2_table(167) := '612D50726F70657274792D636865636B626F7847726F75703A666F637573207B0A202020206F75746C696E653A206E6F6E653B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D696E707574207B0A2020202064697370';
wwv_flow_api.g_varchar2_table(168) := '6C61793A20696E6C696E652D626C6F636B3B0A202020206D617267696E3A203270783B0A2020202077696474683A20313670783B0A202020206865696768743A20313670783B0A20202020766572746963616C2D616C69676E3A20746F703B0A20202020';
wwv_flow_api.g_varchar2_table(169) := '7D0A0A202020202E612D50726F70657274792D636865636B626F782D6C6162656C207B0A20202020646973706C61793A20696E6C696E652D626C6F636B3B0A2020202070616464696E673A203270783B0A20202020766572746963616C2D616C69676E3A';
wwv_flow_api.g_varchar2_table(170) := '20746F703B0A20202020666F6E742D73697A653A20313270783B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(171) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020536574204974656D73205461626C650A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(172) := '2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A202020202E612D50726F70657274792D7365744974656D735461626C65207B0A2020202077696474683A20313030253B0A20202020626F726465722D73706163696E673A20303B0A20202020626F';
wwv_flow_api.g_varchar2_table(173) := '726465722D636F6C6C617073653A20636F6C6C617073653B0A202020207D0A0A202020202E612D50726F70657274792D7365744974656D735461626C65207464207B0A2020202070616464696E672D626F74746F6D3A203470783B0A202020207D0A0A20';
wwv_flow_api.g_varchar2_table(174) := '2020202E612D50726F70657274792D7365744974656D735461626C652074723A6C6173742D6368696C64207464207B0A2020202070616464696E672D626F74746F6D3A20303B0A202020207D0A0A202020202E612D50726F70657274792D736574497465';
wwv_flow_api.g_varchar2_table(175) := '6D734865616465722D686561646572207B0A20202020746578742D616C69676E3A206C6566743B0A202020207D0A0A202020202E612D50726F70657274792D7365744974656D735461626C652D72656D6F7665436F6C207B0A2020202077696474683A20';
wwv_flow_api.g_varchar2_table(176) := '343070783B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A202020';
wwv_flow_api.g_varchar2_table(177) := '2050726F706572747920456469746F7220696E204469616C6F67730A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(178) := '2A2A2A2A2A2A2A2A2A2A2F0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A20202020';
wwv_flow_api.g_varchar2_table(179) := '50726F706572747920456469746F7220427574746F6E730A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A';
wwv_flow_api.g_varchar2_table(180) := '2A2A2A2A2A2A2F0A202020202E612D50726F70657274792D627574746F6E207B0A202020202D2D612D627574746F6E2D70616464696E672D793A203670783B0A2020202077696474683A20313030253B0A2020202077686974652D73706163653A206E6F';
wwv_flow_api.g_varchar2_table(181) := '726D616C3B0A202020207D0A0A202020202F2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A0A202020';
wwv_flow_api.g_varchar2_table(182) := '20537461636B6564205374796C65730A202020202A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2A2F0A';
wwv_flow_api.g_varchar2_table(183) := '202020202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D6C6162656C436F6E7461696E6572202E612D50726F70657274792D6C6162656C207B0A2020202070616464696E672D72696768743A20313270';
wwv_flow_api.g_varchar2_table(184) := '783B0A2020202070616464696E672D626F74746F6D3A203270783B0A2020202070616464696E672D6C6566743A20313270783B0A20202020666F6E742D73697A653A20313170783B0A202020207D0A0A202020202E612D50726F7065727479456469746F';
wwv_flow_api.g_varchar2_table(185) := '722D2D737461636B6564202E612D50726F70657274792D6669656C64436F6E7461696E65722C0A202020202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E6572207B0A';
wwv_flow_api.g_varchar2_table(186) := '2020202070616464696E672D746F703A20303B0A2020202070616464696E672D626F74746F6D3A203870783B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D2D73746163';
wwv_flow_api.g_varchar2_table(187) := '6B6564202E612D50726F70657274792D627574746F6E436F6E7461696E6572207B0A2020202070616464696E672D746F703A203470783B0A2020202070616464696E672D626F74746F6D3A203470783B0A202020207D0A0A202020202E612D50726F7065';
wwv_flow_api.g_varchar2_table(188) := '727479456469746F722D2D737461636B6564202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6C6162656C436F6E7461696E6572202E612D50726F70657274792D6C6162656C207B0A2020202070616464696E673A20';
wwv_flow_api.g_varchar2_table(189) := '34707820303B0A202020207D0A0A202020202F2A203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D0A20202020';
wwv_flow_api.g_varchar2_table(190) := '4869676820436F6E7472617374204D6F64650A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F';
wwv_flow_api.g_varchar2_table(191) := '0A202020202E752D48434D202E612D50726F70657274792D6669656C64207B0A20202020626F726465723A2031707820736F6C69642021696D706F7274616E743B0A202020207D0A0A202020202F2A0A2020202024646973706C61792D787878733A2036';
wwv_flow_api.g_varchar2_table(192) := '343070783B0A2020202024646973706C61792D7878733A2038303070783B0A2020202024646973706C61792D78733A203130323470783B0A2020202024646973706C61792D736D616C6C3A203132383070783B0A2020202024646973706C61792D6D6564';
wwv_flow_api.g_varchar2_table(193) := '69756D3A203136383070783B0A2020202024646973706C61792D6C617267653A203139323070783B0A202020202A2F0A202020202F2A203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(194) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D0A2020202050726F706572747920456469746F720A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(195) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A202020202E612D50726F7065727479456469746F722D77726170706572202E612D50726F7065727479456469746F722D70726F706572747947726F75703A66697273742D';
wwv_flow_api.g_varchar2_table(196) := '6368696C64207B0A202020206D617267696E2D746F703A203870783B0A202020207D0A0A202020202E75692D6469616C6F67202E612D50726F7065727479456469746F72207B0A202020206F766572666C6F773A206175746F3B0A202020206D61782D68';
wwv_flow_api.g_varchar2_table(197) := '65696768743A2034303070783B0A202020207D0A0A202020202F2A2050726F706572747920456469746F722047726F7570730A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(198) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A202020202E612D50726F7065727479456469746F722D70726F706572747947726F7570207B0A20202020646973706C61793A20626C6F636B3B0A202020206261636B67';
wwv_flow_api.g_varchar2_table(199) := '726F756E642D636C69703A2070616464696E672D626F783B0A202020202D7765626B69742D7472616E736974696F6E3A206261636B67726F756E642D636F6C6F7220302E317320656173652C202D7765626B69742D626F782D736861646F7720302E3173';
wwv_flow_api.g_varchar2_table(200) := '20656173653B0A202020207472616E736974696F6E3A206261636B67726F756E642D636F6C6F7220302E317320656173652C202D7765626B69742D626F782D736861646F7720302E317320656173653B0A202020207472616E736974696F6E3A20626163';
wwv_flow_api.g_varchar2_table(201) := '6B67726F756E642D636F6C6F7220302E317320656173652C20626F782D736861646F7720302E317320656173653B0A202020207472616E736974696F6E3A206261636B67726F756E642D636F6C6F7220302E317320656173652C20626F782D736861646F';
wwv_flow_api.g_varchar2_table(202) := '7720302E317320656173652C202D7765626B69742D626F782D736861646F7720302E317320656173653B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D70726F706572747947726F75702E69732D636F6C6C6170736564202E';
wwv_flow_api.g_varchar2_table(203) := '612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572207B0A20202020626F726465722D626F74746F6D3A206E6F6E653B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D70726F706572';
wwv_flow_api.g_varchar2_table(204) := '747947726F75702E69732D636F6C6C6170736564202E612D50726F7065727479456469746F722D70726F706572747947726F75702D626F6479207B0A20202020646973706C61793A206E6F6E653B0A202020207D0A0A202020202E612D50726F70657274';
wwv_flow_api.g_varchar2_table(205) := '79456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75703A66697273742D6368696C64207B0A202020206D617267696E2D746F703A203470783B0A202020207D0A0A202020202E612D50726F7065727479456469';
wwv_flow_api.g_varchar2_table(206) := '746F722D70726F706572747947726F75702D686561646572207B0A202020206D617267696E2D746F703A203470783B0A2020202070616464696E673A2031327078203870783B0A20202020626F726465722D77696474683A20303B0A202020202D776562';
wwv_flow_api.g_varchar2_table(207) := '6B69742D7472616E736974696F6E3A206D617267696E202E317320656173653B0A202020207472616E736974696F6E3A206D617267696E202E317320656173653B0A202020207D0A0A20202020406D65646961206F6E6C792073637265656E20616E6420';
wwv_flow_api.g_varchar2_table(208) := '286D61782D77696474683A2031303234707829207B0A202020202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572207B0A202020202020202070616464696E672D746F703A203470783B0A20202020202020';
wwv_flow_api.g_varchar2_table(209) := '2070616464696E672D626F74746F6D3A203470783B0A202020207D0A202020207D0A0A20202020406D65646961206F6E6C792073637265656E20616E6420286D696E2D77696474683A203130323570782920616E6420286D61782D77696474683A203132';
wwv_flow_api.g_varchar2_table(210) := '3739707829207B0A202020202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572207B0A202020202020202070616464696E672D746F703A203670783B0A202020202020202070616464696E672D626F74746F';
wwv_flow_api.g_varchar2_table(211) := '6D3A203670783B0A202020207D0A202020207D0A0A20202020406D65646961206F6E6C792073637265656E20616E6420286D696E2D77696474683A203132383170782920616E6420286D61782D77696474683A2031363739707829207B0A202020202E61';
wwv_flow_api.g_varchar2_table(212) := '2D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572207B0A202020202020202070616464696E672D746F703A203870783B0A202020202020202070616464696E672D626F74746F6D3A203870783B0A202020207D0A';
wwv_flow_api.g_varchar2_table(213) := '202020207D0A0A202020202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465723A686F766572202E612D49636F6E207B0A202020206F7061636974793A20313B0A202020207D0A0A202020202E612D50726F70';
wwv_flow_api.g_varchar2_table(214) := '65727479456469746F722D70726F706572747947726F75702D686561646572202E612D49636F6E207B0A202020206D617267696E3A20327078203670782032707820303B0A20202020626F726465722D7261646975733A203270783B0A202020206F7061';
wwv_flow_api.g_varchar2_table(215) := '636974793A20302E353B0A202020202D7765626B69742D7472616E736974696F6E3A202E327320656173653B0A202020207472616E736974696F6E3A202E327320656173653B0A202020207D0A0A202020202E752D52544C202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(216) := '456469746F722D70726F706572747947726F75702D686561646572202E612D49636F6E207B0A202020206D617267696E3A20327078203020327078203670783B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D70726F706572';
wwv_flow_api.g_varchar2_table(217) := '747947726F75702D686561646572202E612D49636F6E2E69636F6E2D72696768742D6172726F773A6265666F7265207B0A20202020636F6E74656E743A20225C45304438223B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D';
wwv_flow_api.g_varchar2_table(218) := '70726F706572747947726F75702D686561646572202E612D49636F6E2E69636F6E2D646F776E2D6172726F773A6265666F7265207B0A20202020636F6E74656E743A20225C65306332223B0A202020207D0A0A202020202E612D50726F70657274794564';
wwv_flow_api.g_varchar2_table(219) := '69746F722D70726F706572747947726F75702D6865616465722E69732D666F6375736564207B0A20202020706F736974696F6E3A2072656C61746976653B0A202020207A2D696E6465783A203130303B0A202020206F75746C696E653A206E6F6E653B0A';
wwv_flow_api.g_varchar2_table(220) := '202020207D0A0A202020202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465722E69732D666F6375736564202E612D49636F6E207B0A202020206F7061636974793A20313B0A202020207D0A0A202020202E61';
wwv_flow_api.g_varchar2_table(221) := '2D50726F7065727479456469746F722D70726F706572747947726F75702D7469746C65207B0A20202020646973706C61793A20696E6C696E652D626C6F636B3B0A202020206D617267696E3A20303B0A2020202070616464696E673A20303B0A20202020';
wwv_flow_api.g_varchar2_table(222) := '766572746963616C2D616C69676E3A20746F703B0A20202020666F6E742D7765696768743A203630303B0A20202020666F6E742D73697A653A20313470783B0A202020206C696E652D6865696768743A20323070783B0A202020207D0A0A202020202F2A';
wwv_flow_api.g_varchar2_table(223) := '2A0A202020202A204D6F6469666965723A2069732D656D7074790A202020202A0A202020202A2055736564207768656E20616E206572726F72206D65737361676520697320646973706C617965640A202020202A2F0A202020202E612D50726F70657274';
wwv_flow_api.g_varchar2_table(224) := '79456469746F722E69732D656D707479207B0A20202020646973706C61793A202D7765626B69742D626F783B0A20202020646973706C61793A202D6D732D666C6578626F783B0A20202020646973706C61793A20666C65783B0A202020206F766572666C';
wwv_flow_api.g_varchar2_table(225) := '6F773A2068696464656E3B0A202020206865696768743A20313030253B0A202020202D7765626B69742D626F782D616C69676E3A2063656E7465723B0A20202020202020202D6D732D666C65782D616C69676E3A2063656E7465723B0A20202020202020';
wwv_flow_api.g_varchar2_table(226) := '2020202020616C69676E2D6974656D733A2063656E7465723B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D6D657373616765207B0A2020202070616464696E673A20313270783B0A2020202077696474683A20313030253B';
wwv_flow_api.g_varchar2_table(227) := '0A20202020746578742D616C69676E3A2063656E7465723B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D6D65737361676554657874207B0A202020206D617267696E3A20303B0A202020207D0A0A202020202E612D49636F';
wwv_flow_api.g_varchar2_table(228) := '6E202B202E612D50726F7065727479456469746F722D6D65737361676554657874207B0A202020206D617267696E2D746F703A203870783B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D65646974506172656E74207B0A20';
wwv_flow_api.g_varchar2_table(229) := '20202070616464696E673A20367078203870783B0A20202020746578742D616C69676E3A2063656E7465723B0A202020207D0A0A20202020406D65646961206F6E6C792073637265656E20616E6420286D61782D77696474683A2031303234707829207B';
wwv_flow_api.g_varchar2_table(230) := '0A202020202E612D50726F7065727479456469746F722D65646974506172656E74207B0A202020202020202070616464696E673A20327078203870783B0A202020207D0A202020207D0A0A20202020406D65646961206F6E6C792073637265656E20616E';
wwv_flow_api.g_varchar2_table(231) := '6420286D696E2D77696474683A203130323570782920616E6420286D61782D77696474683A2031323739707829207B0A202020202E612D50726F7065727479456469746F722D65646974506172656E74207B0A202020202020202070616464696E673A20';
wwv_flow_api.g_varchar2_table(232) := '347078203870783B0A202020207D0A202020207D0A0A202020202F2A2046696C746572696E670A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(233) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A202020202E612D50726F7065727479456469746F722D66696C746572207B0A20202020706F736974696F6E3A2072656C61746976653B0A20202020646973706C61793A202D7765626B69742D626F78';
wwv_flow_api.g_varchar2_table(234) := '3B0A20202020646973706C61793A202D6D732D666C6578626F783B0A20202020646973706C61793A20666C65783B0A2020202070616464696E673A20303B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D66696C746572202E';
wwv_flow_api.g_varchar2_table(235) := '612D50726F7065727479456469746F722D66696C7465722D69636F6E207B0A20202020706F736974696F6E3A206162736F6C7574653B0A20202020746F703A20303B0A202020206C6566743A20303B0A202020206D617267696E3A203870783B0A202020';
wwv_flow_api.g_varchar2_table(236) := '206F7061636974793A202E353B0A202020202D7765626B69742D7472616E736974696F6E3A202E317320656173653B0A202020207472616E736974696F6E3A202E317320656173653B0A20202020706F696E7465722D6576656E74733A206E6F6E653B0A';
wwv_flow_api.g_varchar2_table(237) := '202020207D0A0A202020202E752D52544C202E612D50726F7065727479456469746F722D66696C746572202E612D50726F7065727479456469746F722D66696C7465722D69636F6E207B0A202020206C6566743A206175746F3B0A202020207269676874';
wwv_flow_api.g_varchar2_table(238) := '3A20303B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D66696C746572202E612D50726F70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D7465787429207B0A202020202D7765626B69';
wwv_flow_api.g_varchar2_table(239) := '742D626F782D73697A696E673A20626F726465722D626F783B0A202020202020202020202020626F782D73697A696E673A20626F726465722D626F783B0A2020202070616464696E673A20387078203870782038707820333270783B0A20202020686569';
wwv_flow_api.g_varchar2_table(240) := '6768743A20333270783B0A202020206C696E652D6865696768743A20333270783B0A20202020626F726465722D7261646975733A203270783B0A202020207D0A0A202020202E752D52544C202E612D50726F7065727479456469746F722D66696C746572';
wwv_flow_api.g_varchar2_table(241) := '202E612D50726F70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D7465787429207B0A2020202070616464696E673A20387078203332707820387078203870783B0A202020207D0A0A202020202E612D50726F7065';
wwv_flow_api.g_varchar2_table(242) := '727479456469746F722D66696C746572202E612D50726F70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D74657874293A666F637573202B202E612D49636F6E207B0A202020206F7061636974793A20313B0A2020';
wwv_flow_api.g_varchar2_table(243) := '20207D0A0A202020202E612D50726F7065727479456469746F722D66696C746572202E612D427574746F6E2D2D737469636B7946696C746572207B0A20202020706F736974696F6E3A206162736F6C7574653B0A20202020746F703A20303B0A20202020';
wwv_flow_api.g_varchar2_table(244) := '72696768743A20303B0A20202020626F74746F6D3A20303B0A202020207A2D696E6465783A2031303B0A202020206D617267696E3A203470783B0A2020202070616464696E673A203470783B0A202020206F7061636974793A20303B0A202020202D7765';
wwv_flow_api.g_varchar2_table(245) := '626B69742D7472616E736974696F6E3A206F706163697479202E317320656173653B0A202020207472616E736974696F6E3A206F706163697479202E317320656173653B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D6669';
wwv_flow_api.g_varchar2_table(246) := '6C7465723A666F6375732D77697468696E202E612D50726F70657274792D6669656C64202B202E612D49636F6E207B0A202020206F7061636974793A20313B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D66696C74657220';
wwv_flow_api.g_varchar2_table(247) := '2E612D50726F70657274792D6669656C643A666F637573207E202E612D427574746F6E2D2D737469636B7946696C7465722C0A202020202E612D50726F7065727479456469746F722D66696C746572202E612D427574746F6E2D2D737469636B7946696C';
wwv_flow_api.g_varchar2_table(248) := '7465722E69732D6163746976652C0A202020202E612D50726F7065727479456469746F722D66696C746572202E612D427574746F6E2D2D737469636B7946696C7465723A666F637573207B0A202020206F7061636974793A20313B0A202020207D0A0A20';
wwv_flow_api.g_varchar2_table(249) := '2020202E612D50726F70657274792D686967686C69676874207B0A2020202070616464696E673A2032707820303B0A20202020626F726465722D7261646975733A203270783B0A202020202D7765626B69742D7472616E736974696F6E3A202E31732065';
wwv_flow_api.g_varchar2_table(250) := '6173653B0A202020207472616E736974696F6E3A202E317320656173653B0A202020207D0A0A202020202F2A2050726F70657274792046696C746572204E6F7420466F756E640A202020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(251) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A202020202E612D50726F70657274792D6E6F74466F756E64207B0A2020202070616464696E673A20312E3672656D3B';
wwv_flow_api.g_varchar2_table(252) := '0A20202020746578742D616C69676E3A2063656E7465723B0A202020207D0A0A202020202E612D50726F70657274792D6E6F74466F756E64202E612D49636F6E207B0A202020206D617267696E2D626F74746F6D3A203870783B0A202020207D0A0A2020';
wwv_flow_api.g_varchar2_table(253) := '20202F2A0A2020202024646973706C61792D787878733A2036343070783B0A2020202024646973706C61792D7878733A2038303070783B0A2020202024646973706C61792D78733A203130323470783B0A2020202024646973706C61792D736D616C6C3A';
wwv_flow_api.g_varchar2_table(254) := '203132383070783B0A2020202024646973706C61792D6D656469756D3A203136383070783B0A2020202024646973706C61792D6C617267653A203139323070783B0A202020202A2F0A202020202F2A203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D';
wwv_flow_api.g_varchar2_table(255) := '3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D0A2020202050726F70657274792047726F7570202850726F706572747920456469746F722047726F757073290A20';
wwv_flow_api.g_varchar2_table(256) := '2020203D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D3D202A2F0A202020202F2A2A0A202020202A2050726F7065';
wwv_flow_api.g_varchar2_table(257) := '7274792047726F757020436F6D706F6E656E740A202020202A0A202020202A205468697320697320612067726F7570696E67206F66206F6E65206F72206D6F72652070726F7065727469657320696E2074686520636F6E74657874206F6620612070726F';
wwv_flow_api.g_varchar2_table(258) := '70657274790A202020202A20656469746F722E205468697320616C6C6F777320757320746F20636F6E76656E69656E746C792067726F7570206F75722070726F7065727469657320616E64207573650A202020202A2070737565646F2073656C6563746F';
wwv_flow_api.g_varchar2_table(259) := '727320746F206170706C79207374796C657320746F206669727374202F206C61737420656C656D656E74732077697468696E207468652067726F75702E0A202020202A0A202020202A204578616D706C652048544D4C3A0A202020202A0A202020202A20';
wwv_flow_api.g_varchar2_table(260) := '3C64697620636C6173733D22612D50726F706572747947726F7570223E0A202020202A2020203C64697620636C6173733D22612D50726F706572747947726F75702D6974656D223E0A202020202A20202020205B50726F70657274792020486572655D0A';
wwv_flow_api.g_varchar2_table(261) := '202020202A2020203C2F6469763E0A202020202A2020203C64697620636C6173733D22612D50726F706572747947726F75702D6974656D223E0A202020202A20202020205B50726F70657274792020486572655D0A202020202A2020203C2F6469763E0A';
wwv_flow_api.g_varchar2_table(262) := '202020202A2020203C64697620636C6173733D22612D50726F706572747947726F75702D6974656D223E0A202020202A20202020205B50726F70657274792020486572655D0A202020202A2020203C2F6469763E0A202020202A203C2F6469763E0A2020';
wwv_flow_api.g_varchar2_table(263) := '20202A2F0A202020202E612D50726F706572747947726F75702D6974656D207B0A20202020626F726465722D746F703A2031707820736F6C69643B0A20202020626F726465722D626F74746F6D2D77696474683A20303B0A202020207D0A0A202020202E';
wwv_flow_api.g_varchar2_table(264) := '612D50726F7065727479456469746F722D70726F706572747947726F75702D626F6479207B0A2020202070616464696E673A2034707820303B0A202020207D0A7D';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(776881197476146572)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_file_name=>'css/base.less'
,p_mime_type=>'text/plain'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '2E75742D50726F7065727479456469746F72202E612D50726F70657274797B706F736974696F6E3A72656C61746976653B646973706C61793A7461626C653B6D617267696E3A303B70616464696E673A303B77696474683A313030253B7461626C652D6C';
wwv_flow_api.g_varchar2_table(2) := '61796F75743A6175746F7D2E75742D50726F7065727479456469746F72202E612D50726F7065727479202E612D49636F6E2E69636F6E2D72657175697265647B646973706C61793A6E6F6E657D2E75742D50726F7065727479456469746F72202E612D50';
wwv_flow_api.g_varchar2_table(3) := '726F70657274792D627574746F6E436F6E7461696E65722C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C436F6E7461696E65722C2E75742D50726F7065727479456469746F72202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(4) := '2D756E6974436F6E7461696E65727B646973706C61793A7461626C652D63656C6C3B766572746963616C2D616C69676E3A6D6964646C657D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E';
wwv_flow_api.g_varchar2_table(5) := '65722C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C436F6E7461696E65722C2E75742D50';
wwv_flow_api.g_varchar2_table(6) := '726F7065727479456469746F72202E612D50726F70657274792D756E6974436F6E7461696E65727B70616464696E673A347078203870787D406D65646961206F6E6C792073637265656E20616E6420286D61782D77696474683A313032347078297B2E75';
wwv_flow_api.g_varchar2_table(7) := '742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E65722C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722C2E75742D50726F7065';
wwv_flow_api.g_varchar2_table(8) := '727479456469746F72202E612D50726F70657274792D6C6162656C436F6E7461696E65722C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D756E6974436F6E7461696E65727B70616464696E673A327078203870787D7D2E';
wwv_flow_api.g_varchar2_table(9) := '75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C436F6E7461696E65727B70616464696E672D72696768743A303B6D696E2D77696474683A31313270787D2E75742D50726F7065727479456469746F72202374656D';
wwv_flow_api.g_varchar2_table(10) := '706C6174654F7074696F6E73446C675045202E612D50726F70657274792D6C6162656C436F6E7461696E65727B6D696E2D77696474683A31343470787D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D73';
wwv_flow_api.g_varchar2_table(11) := '7461636B6564202E612D50726F70657274793A6E6F74282E612D50726F70657274792D2D737461636B656429202E612D50726F70657274792D6C6162656C436F6E7461696E65727B646973706C61793A7461626C652D726F773B77696474683A31303025';
wwv_flow_api.g_varchar2_table(12) := '7D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65727B646973706C61793A7461626C652D63656C6C3B77696474683A313030253B766572746963616C2D616C69676E3A6D6964646C657D2E';
wwv_flow_api.g_varchar2_table(13) := '75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D636F6D626F426F787B70616464696E672D72696768743A3021696D706F7274616E747D2E75742D50726F7065727479456469746F7220';
wwv_flow_api.g_varchar2_table(14) := '2E612D50726F70657274792D636F6C6F72507265766965777B646973706C61793A626C6F636B3B77696474683A313270783B6865696768743A313270783B626F726465722D7261646975733A313030257D2E75742D50726F7065727479456469746F7220';
wwv_flow_api.g_varchar2_table(15) := '2E612D50726F70657274792D6669656C64436F6E7461696E65722D2D636F6C6F725069636B65727B70616464696E672D72696768743A3021696D706F7274616E747D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D666965';
wwv_flow_api.g_varchar2_table(16) := '6C64436F6E7461696E65722D2D636F6C6F725069636B6572202E612D50726F70657274792D6669656C647B70616464696E672D6C6566743A323470783B626F726465722D746F702D72696768742D7261646975733A3021696D706F7274616E743B626F72';
wwv_flow_api.g_varchar2_table(17) := '6465722D626F74746F6D2D72696768742D7261646975733A3021696D706F7274616E747D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D636F6C6F725069636B6572202E612D5072';
wwv_flow_api.g_varchar2_table(18) := '6F70657274792D636F6C6F72507265766965777B706F736974696F6E3A6162736F6C7574653B6D617267696E3A3670783B706F696E7465722D6576656E74733A6E6F6E657D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D';
wwv_flow_api.g_varchar2_table(19) := '627574746F6E436F6E7461696E65722D2D636F6C6F725069636B6572202E612D427574746F6E7B6D617267696E2D6C6566743A2D3170787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D756E6974436F6E7461696E6572';
wwv_flow_api.g_varchar2_table(20) := '7B70616464696E672D6C6566743A3021696D706F7274616E743B77686974652D73706163653A6E6F777261707D2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6572726F72202E69636F6E2D6572726F722C2E7574';
wwv_flow_api.g_varchar2_table(21) := '2D50726F7065727479456469746F72202E612D50726F70657274792E69732D7661726961626C65202E612D49636F6E2E69636F6E2D7661726961626C652C2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D7761726E';
wwv_flow_api.g_varchar2_table(22) := '696E67202E69636F6E2D7761726E696E677B6D617267696E2D72696768743A3470787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C2C2E75742D50726F7065727479456469746F72202E612D50726F706572';
wwv_flow_api.g_varchar2_table(23) := '74792D7365744974656D734865616465722D6865616465727B70616464696E673A34707820303B666F6E742D73697A653A313270783B6C696E652D6865696768743A313670787D2E75742D50726F7065727479456469746F72202E612D50726F70657274';
wwv_flow_api.g_varchar2_table(24) := '792D756E69747B70616464696E673A34707820303B6C696E652D6865696768743A313670787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D6C6162656C7B6C696E652D6865696768743A31367078';
wwv_flow_api.g_varchar2_table(25) := '7D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F7B666F6E742D73697A653A313270783B6C696E652D6865696768743A313670787D2E75742D50726F7065727479456469746F72202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(26) := '2D756E69747B666F6E742D73697A653A313170787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C2D2D7769746849636F6E7B70616464696E673A34707820303B6C696E652D6865696768743A313670787D2E';
wwv_flow_api.g_varchar2_table(27) := '75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C647B70616464696E673A3470783B6D696E2D6865696768743A323470783B666F6E742D73697A653A313270783B6C696E652D6865696768743A313670783B626F7264';
wwv_flow_api.g_varchar2_table(28) := '65722D7261646975733A3270787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C643A666F6375737B6F75746C696E653A307D2E75742D50726F7065727479456469746F72202E612D50726F70657274792E6973';
wwv_flow_api.g_varchar2_table(29) := '2D7661726961626C65202E612D50726F70657274792D6669656C647B626F726465722D7261646975733A3270787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C642D2D73656C6563747B6F766572666C6F773A';
wwv_flow_api.g_varchar2_table(30) := '68696464656E3B70616464696E672D72696768743A333070783B746578742D696E64656E743A2E303170783B746578742D6F766572666C6F773A2720273B6261636B67726F756E642D706F736974696F6E3A3130302520303B6261636B67726F756E642D';
wwv_flow_api.g_varchar2_table(31) := '73697A653A3332707820323470783B6261636B67726F756E642D7265706561743A6E6F2D7265706561743B2D7765626B69742D617070656172616E63653A6E6F6E653B2D6D6F7A2D617070656172616E63653A6E6F6E653B617070656172616E63653A6E';
wwv_flow_api.g_varchar2_table(32) := '6F6E657D2E75742D50726F7065727479456469746F7220626F64793A6E6F74283A2D6D6F7A2D68616E646C65722D626C6F636B656429202E612D50726F70657274792D6669656C642D2D73656C6563747B70616464696E673A3270782032347078203270';
wwv_flow_api.g_varchar2_table(33) := '78203270787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C642D2D74657874617265612C2E75742D50726F7065727479456469746F7220626F6479202E75692D776964676574202E612D50726F70657274792D';
wwv_flow_api.g_varchar2_table(34) := '6669656C642D2D74657874617265617B70616464696E673A3470783B6D61782D6865696768743A33323070783B6865696768743A6175746F3B666F6E742D73697A653A313170783B6C696E652D6865696768743A313470787D2E75742D50726F70657274';
wwv_flow_api.g_varchar2_table(35) := '79456469746F7220626F6479202E75692D776964676574202E612D50726F70657274792D6669656C642D2D74657874617265617B666F6E742D66616D696C793A53464D6F6E6F2D526567756C61722C4D656E6C6F2C4D6F6E61636F2C436F6E736F6C6173';
wwv_flow_api.g_varchar2_table(36) := '2C224C696265726174696F6E204D6F6E6F222C22436F7572696572204E6577222C6D6F6E6F73706163657D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726561644F6E6C797B666F6E742D7765696768743A3730303B66';
wwv_flow_api.g_varchar2_table(37) := '6F6E742D73697A653A313270783B6C696E652D6865696768743A327D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D735461626C652D6865616465727B666F6E742D7765696768743A3430307D2E75742D';
wwv_flow_api.g_varchar2_table(38) := '50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D735461626C65202E612D50726F70657274792D6669656C647B626F726465722D746F702D72696768742D7261646975733A303B626F726465722D626F74746F6D2D72';
wwv_flow_api.g_varchar2_table(39) := '696768742D7261646975733A307D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E65722D2D636F6D626F426F78202E612D427574746F6E7B6D617267696E2D6C6566743A3870787D2E7574';
wwv_flow_api.g_varchar2_table(40) := '2D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D2C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E707574';
wwv_flow_api.g_varchar2_table(41) := '5B747970653D726164696F5D7B706F736974696F6E3A6162736F6C7574653B6F766572666C6F773A68696464656E3B636C69703A726563742830203020302030293B6D617267696E3A2D3170783B70616464696E673A303B77696474683A3170783B6865';
wwv_flow_api.g_varchar2_table(42) := '696768743A3170783B626F726465723A307D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D2B6C6162656C2C2E75742D50726F7065727479456469';
wwv_flow_api.g_varchar2_table(43) := '746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F5D2B6C6162656C7B706F736974696F6E3A72656C61746976653B70616464696E672D72696768743A3870783B70616464696E672D6C6566743A323070783B';
wwv_flow_api.g_varchar2_table(44) := '637572736F723A706F696E7465727D2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D2B6C6162656C2C2E75742D50726F70657274';
wwv_flow_api.g_varchar2_table(45) := '79456469746F72202E752D52544C202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F5D2B6C6162656C7B70616464696E672D6C6566743A3870783B70616464696E672D72696768743A323070787D2E75742D50726F';
wwv_flow_api.g_varchar2_table(46) := '7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D2B6C6162656C3A61667465722C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865';
wwv_flow_api.g_varchar2_table(47) := '636B626F782D696E7075745B747970653D636865636B626F785D2B6C6162656C3A6265666F72652C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F5D2B6C6162656C';
wwv_flow_api.g_varchar2_table(48) := '3A6265666F72657B706F736974696F6E3A6162736F6C7574653B746F703A3370783B6C6566743A303B646973706C61793A626C6F636B3B77696474683A313470783B6865696768743A313470783B636F6E74656E743A27273B2D7765626B69742D747261';
wwv_flow_api.g_varchar2_table(49) := '6E736974696F6E3A2E31323573206F70616369747920656173653B7472616E736974696F6E3A2E31323573206F70616369747920656173657D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B';
wwv_flow_api.g_varchar2_table(50) := '747970653D726164696F5D2B6C6162656C3A61667465727B706F736974696F6E3A6162736F6C7574653B746F703A3370783B6C6566743A303B646973706C61793A626C6F636B3B636F6E74656E743A27273B2D7765626B69742D7472616E736974696F6E';
wwv_flow_api.g_varchar2_table(51) := '3A2E31323573206F70616369747920656173653B7472616E736974696F6E3A2E31323573206F70616369747920656173657D2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274792D636865636B626F782D696E70';
wwv_flow_api.g_varchar2_table(52) := '75745B747970653D636865636B626F785D2B6C6162656C3A61667465722C2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D2B6C61';
wwv_flow_api.g_varchar2_table(53) := '62656C3A6265666F72652C2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F5D2B6C6162656C3A61667465722C2E75742D50726F7065727479456469';
wwv_flow_api.g_varchar2_table(54) := '746F72202E752D52544C202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F5D2B6C6162656C3A6265666F72657B6C6566743A6175746F3B72696768743A307D2E75742D50726F7065727479456469746F72202E612D';
wwv_flow_api.g_varchar2_table(55) := '50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D2B6C6162656C3A6265666F72652C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D';
wwv_flow_api.g_varchar2_table(56) := '726164696F5D2B6C6162656C3A6265666F72657B7A2D696E6465783A39303B626F726465723A31707820736F6C69647D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D63';
wwv_flow_api.g_varchar2_table(57) := '6865636B626F785D2B6C6162656C3A61667465722C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F5D2B6C6162656C3A61667465727B7A2D696E6465783A3130303B';
wwv_flow_api.g_varchar2_table(58) := '6F7061636974793A307D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D3A64697361626C65642B6C6162656C2C2E75742D50726F70657274794564';
wwv_flow_api.g_varchar2_table(59) := '69746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F5D3A64697361626C65642B6C6162656C7B6F7061636974793A2E353B637572736F723A64656661756C743B706F696E7465722D6576656E74733A6E6F6E';
wwv_flow_api.g_varchar2_table(60) := '657D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D3A64697361626C65642B6C6162656C3A6265666F72652C2E75742D50726F7065727479456469';
wwv_flow_api.g_varchar2_table(61) := '746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F5D3A64697361626C65642B6C6162656C3A6265666F72657B6F7061636974793A2E357D2E75742D50726F7065727479456469746F72202E612D50726F7065';
wwv_flow_api.g_varchar2_table(62) := '7274792D636865636B626F782D696E7075745B747970653D636865636B626F785D3A666F6375733A636865636B65642B6C6162656C3A61667465722C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D';
wwv_flow_api.g_varchar2_table(63) := '696E7075745B747970653D636865636B626F785D3A686F7665723A636865636B65642B6C6162656C3A61667465722C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F';
wwv_flow_api.g_varchar2_table(64) := '5D3A666F6375733A636865636B65642B6C6162656C3A61667465722C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F5D3A686F7665723A636865636B65642B6C6162';
wwv_flow_api.g_varchar2_table(65) := '656C3A61667465727B6F7061636974793A317D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D2B6C6162656C3A6265666F72657B626F726465722D';
wwv_flow_api.g_varchar2_table(66) := '7261646975733A3270787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D2B6C6162656C3A61667465727B6261636B67726F756E642D706F736974';
wwv_flow_api.g_varchar2_table(67) := '696F6E3A3530253B6261636B67726F756E642D73697A653A313670783B6261636B67726F756E642D7265706561743A6E6F2D7265706561747D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E70';
wwv_flow_api.g_varchar2_table(68) := '75745B747970653D636865636B626F785D3A696E64657465726D696E6174652B6C6162656C3A61667465727B6F7061636974793A313B6261636B67726F756E642D696D6167653A6E6F6E653B77696474683A3870783B6865696768743A3270783B626F72';
wwv_flow_api.g_varchar2_table(69) := '6465722D7261646975733A3270783B6D617267696E3A367078203370783B2D7765626B69742D7472616E73666F726D3A7363616C65282E3735293B7472616E73666F726D3A7363616C65282E3735297D2E75742D50726F7065727479456469746F72202E';
wwv_flow_api.g_varchar2_table(70) := '612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D3A636865636B65642B6C6162656C3A61667465722C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F78';
wwv_flow_api.g_varchar2_table(71) := '2D696E7075745B747970653D636865636B626F785D3A636865636B65642B6C6162656C3A6265666F72652C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F5D3A6368';
wwv_flow_api.g_varchar2_table(72) := '65636B65642B6C6162656C3A61667465727B6F7061636974793A317D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F5D2B6C6162656C3A6265666F72657B626F7264';
wwv_flow_api.g_varchar2_table(73) := '65722D7261646975733A313670787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F5D2B6C6162656C3A61667465727B6D617267696E3A3570783B77696474683A34';
wwv_flow_api.g_varchar2_table(74) := '70783B6865696768743A3470783B626F726465722D7261646975733A313030257D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D726164696F47726F75';
wwv_flow_api.g_varchar2_table(75) := '702D2D627574746F6E5365747B70616464696E673A30203470787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F7B6D61';
wwv_flow_api.g_varchar2_table(76) := '7267696E2D72696768743A2D3170787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075742B6C6162656C7B70';
wwv_flow_api.g_varchar2_table(77) := '616464696E673A327078203870783B2D7765626B69742D7472616E736974696F6E3A6261636B67726F756E642D636F6C6F72202E31357320656173653B7472616E736974696F6E3A6261636B67726F756E642D636F6C6F72202E31357320656173653B6D';
wwv_flow_api.g_varchar2_table(78) := '696E2D77696474683A343870783B746578742D616C69676E3A63656E7465723B6C696E652D6865696768743A323070783B626F726465722D7261646975733A3270787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7261';
wwv_flow_api.g_varchar2_table(79) := '64696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075742B6C6162656C3A61667465722C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D62';
wwv_flow_api.g_varchar2_table(80) := '7574746F6E536574202E612D50726F70657274792D726164696F2D696E7075742B6C6162656C3A6265666F72657B636F6E74656E743A696E697469616C7D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F4772';
wwv_flow_api.g_varchar2_table(81) := '6F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A636865636B65642B6C6162656C7B666F6E742D7765696768743A3730307D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D';
wwv_flow_api.g_varchar2_table(82) := '726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A666F6375732B6C6162656C7B7A2D696E6465783A313B6F75746C696E653A303B626F726465722D7261646975733A3270787D2E75742D';
wwv_flow_api.g_varchar2_table(83) := '50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75703A666F6375737B6F75746C696E653A307D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F7B646973706C61793A69';
wwv_flow_api.g_varchar2_table(84) := '6E6C696E652D626C6F636B7D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075747B646973706C61793A696E6C696E652D626C6F636B3B6D617267696E3A3270783B77696474683A313670783B6865';
wwv_flow_api.g_varchar2_table(85) := '696768743A313670783B766572746963616C2D616C69676E3A746F707D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D6C6162656C7B646973706C61793A696E6C696E652D626C6F636B3B70616464696E67';
wwv_flow_api.g_varchar2_table(86) := '3A3270783B766572746963616C2D616C69676E3A746F703B666F6E742D73697A653A313270787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64436F6E7461696E65722D2D726164696F47726F75707B706164';
wwv_flow_api.g_varchar2_table(87) := '64696E672D746F703A3670783B70616464696E672D626F74746F6D3A3670787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E5365743A61667465722C2E75742D50726F7065';
wwv_flow_api.g_varchar2_table(88) := '727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E5365743A6265666F72657B646973706C61793A7461626C653B636F6E74656E743A27277D2E75742D50726F7065727479456469746F72202E612D5072';
wwv_flow_api.g_varchar2_table(89) := '6F70657274792D726164696F47726F75702D2D627574746F6E5365743A61667465727B636C6561723A626F74687D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E';
wwv_flow_api.g_varchar2_table(90) := '612D50726F70657274792D726164696F7B666C6F61743A6C6566747D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D69';
wwv_flow_api.g_varchar2_table(91) := '6E7075747B706F736974696F6E3A6162736F6C7574653B6F766572666C6F773A68696464656E3B636C69703A726563742830203020302030293B6D617267696E3A2D3170783B70616464696E673A303B77696474683A3170783B6865696768743A317078';
wwv_flow_api.g_varchar2_table(92) := '3B626F726465723A307D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A64697361626C65642B6C616265';
wwv_flow_api.g_varchar2_table(93) := '6C7B6F7061636974793A2E357D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075742B6C6162656C202E612D49';
wwv_flow_api.g_varchar2_table(94) := '636F6E7B6D617267696E3A3270787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D737461636B65647B706F736974696F6E3A72656C61746976657D2E75742D50726F7065727479456469746F72202E612D50726F7065';
wwv_flow_api.g_varchar2_table(95) := '7274792D2D737461636B6564202E612D50726F70657274792D6669656C64436F6E7461696E65722C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6C6162656C436F6E';
wwv_flow_api.g_varchar2_table(96) := '7461696E65722C2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722E6A732D73686F77416C6C202E612D50726F70657274792E6A732D73686F77416C6C2C2E75742D50726F7065727479456469746F72202E612D';
wwv_flow_api.g_varchar2_table(97) := '50726F7065727479456469746F722E6A732D73686F77416C6C202E612D50726F7065727479456469746F722D70726F706572747947726F75702E6A732D73686F77416C6C7B646973706C61793A626C6F636B7D2E75742D50726F7065727479456469746F';
wwv_flow_api.g_varchar2_table(98) := '72202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6C6162656C436F6E7461696E65727B6D617267696E2D72696768743A363470783B70616464696E672D626F74746F6D3A307D2E75742D50726F7065727479456469';
wwv_flow_api.g_varchar2_table(99) := '746F72202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6669656C64436F6E7461696E65727B70616464696E672D746F703A307D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D7374';
wwv_flow_api.g_varchar2_table(100) := '61636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E65727B706F736974696F6E3A6162736F6C7574653B746F703A303B72696768743A307D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D2D7374';
wwv_flow_api.g_varchar2_table(101) := '61636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E65722B2E612D50726F70657274792D6669656C64436F6E7461696E65727B70616464696E672D746F703A3470787D2E75742D50726F7065727479456469746F72202E612D50';
wwv_flow_api.g_varchar2_table(102) := '726F70657274792D2D737461636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E6572202E612D427574746F6E2D2D717569636B5069636B7B6D617267696E2D6C6566743A3870787D2E75742D50726F7065727479456469746F72';
wwv_flow_api.g_varchar2_table(103) := '202E612D50726F70657274792D2D7363726F6C6C61626C657B646973706C61793A626C6F636B3B6F766572666C6F773A6175746F7D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C436F6E7461696E65722D2D';
wwv_flow_api.g_varchar2_table(104) := '77697468427574746F6E737B646973706C61793A7461626C652D63656C6C3B7461626C652D6C61796F75743A6175746F3B70616464696E672D626F74746F6D3A3870787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C';
wwv_flow_api.g_varchar2_table(105) := '6162656C436F6E7461696E65722D2D68696464656E4C6162656C7B70616464696E673A307D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E65727B70616464696E672D6C6566743A302169';
wwv_flow_api.g_varchar2_table(106) := '6D706F7274616E747D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E65722D2D70756C6C52696768747B666C6F61743A72696768747D2E75742D50726F7065727479456469746F72202E61';
wwv_flow_api.g_varchar2_table(107) := '2D50726F70657274792E69732D6368616E676564202E612D50726F70657274792D6C6162656C436F6E7461696E65723A6265666F72657B706F736974696F6E3A6162736F6C7574653B746F703A3170783B626F74746F6D3A303B6C6566743A3170783B64';
wwv_flow_api.g_varchar2_table(108) := '6973706C61793A696E6C696E652D626C6F636B3B77696474683A3370783B636F6E74656E743A27273B6F7061636974793A2E357D2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6368616E6765642E69732D666F63';
wwv_flow_api.g_varchar2_table(109) := '75736564202E612D50726F70657274792D6C6162656C436F6E7461696E65723A6265666F72652C2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6368616E6765643A686F766572202E612D50726F70657274792D6C';
wwv_flow_api.g_varchar2_table(110) := '6162656C436F6E7461696E65723A6265666F72657B6F7061636974793A317D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C2C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D75';
wwv_flow_api.g_varchar2_table(111) := '6E69747B646973706C61793A626C6F636B3B2D6D732D746578742D6F766572666C6F773A656C6C69707369733B746578742D6F766572666C6F773A656C6C69707369733B6F766572666C6F773A68696464656E7D2E75742D50726F706572747945646974';
wwv_flow_api.g_varchar2_table(112) := '6F72202E612D50726F70657274792D6669656C647B646973706C61793A626C6F636B3B77696474683A313030253B6261636B67726F756E642D636C69703A626F726465722D626F783B626F726465723A3020736F6C69647D2E75742D50726F7065727479';
wwv_flow_api.g_varchar2_table(113) := '456469746F72202E612D50726F70657274792D6669656C642D2D74657874617265617B6D696E2D6865696768743A343870783B666F6E742D66616D696C793A53464D6F6E6F2D526567756C61722C4D656E6C6F2C4D6F6E61636F2C436F6E736F6C61732C';
wwv_flow_api.g_varchar2_table(114) := '224C696265726174696F6E204D6F6E6F222C22436F7572696572204E6577222C6D6F6E6F73706163653B726573697A653A766572746963616C7D2E75742D50726F7065727479456469746F72202E612D50726F70657274792E6A732D73686F77416C6C2C';
wwv_flow_api.g_varchar2_table(115) := '2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702E6A732D73686F77416C6C7B646973706C61793A6E6F6E657D2E75742D50726F7065727479456469746F72202E612D50726F';
wwv_flow_api.g_varchar2_table(116) := '7065727479456469746F722D2D737461636B65642E6A732D73686F77416C6C202E612D50726F70657274792E6A732D73686F77416C6C7B646973706C61793A7461626C657D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D';
wwv_flow_api.g_varchar2_table(117) := '636865636B626F7847726F75703A666F6375737B6F75746C696E653A307D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075747B646973706C61793A696E6C696E652D626C6F636B3B6D6172';
wwv_flow_api.g_varchar2_table(118) := '67696E3A3270783B77696474683A313670783B6865696768743A313670783B766572746963616C2D616C69676E3A746F707D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D6C6162656C7B64697370';
wwv_flow_api.g_varchar2_table(119) := '6C61793A696E6C696E652D626C6F636B3B70616464696E673A3270783B766572746963616C2D616C69676E3A746F703B666F6E742D73697A653A313270787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D736574497465';
wwv_flow_api.g_varchar2_table(120) := '6D735461626C657B77696474683A313030253B626F726465722D73706163696E673A303B626F726465722D636F6C6C617073653A636F6C6C617073657D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D73';
wwv_flow_api.g_varchar2_table(121) := '5461626C652074647B70616464696E672D626F74746F6D3A3470787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D735461626C652074723A6C6173742D6368696C642074647B70616464696E672D626F';
wwv_flow_api.g_varchar2_table(122) := '74746F6D3A307D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D734865616465722D6865616465727B746578742D616C69676E3A6C6566747D2E75742D50726F7065727479456469746F72202E612D5072';
wwv_flow_api.g_varchar2_table(123) := '6F70657274792D7365744974656D735461626C652D72656D6F7665436F6C7B77696474683A343070787D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E7B2D2D612D627574746F6E2D70616464696E672D79';
wwv_flow_api.g_varchar2_table(124) := '3A203670783B77696474683A313030253B77686974652D73706163653A6E6F726D616C7D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D6C6162656C43';
wwv_flow_api.g_varchar2_table(125) := '6F6E7461696E6572202E612D50726F70657274792D6C6162656C7B70616464696E672D72696768743A313270783B70616464696E672D626F74746F6D3A3270783B70616464696E672D6C6566743A313270783B666F6E742D73697A653A313170787D2E75';
wwv_flow_api.g_varchar2_table(126) := '742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E65722C2E75742D50726F7065727479456469746F72202E612D50726F706572';
wwv_flow_api.g_varchar2_table(127) := '7479456469746F722D2D737461636B6564202E612D50726F70657274792D6669656C64436F6E7461696E65727B70616464696E672D746F703A303B70616464696E672D626F74746F6D3A3870787D2E75742D50726F7065727479456469746F72202E612D';
wwv_flow_api.g_varchar2_table(128) := '50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D627574746F6E436F6E7461696E65727B70616464696E672D746F703A3470783B70616464696E672D626F74';
wwv_flow_api.g_varchar2_table(129) := '746F6D3A3470787D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D2D737461636B6564202E612D50726F70657274792D2D737461636B6564202E612D50726F70657274792D6C6162656C436F6E7461696E65';
wwv_flow_api.g_varchar2_table(130) := '72202E612D50726F70657274792D6C6162656C7B70616464696E673A34707820307D2E75742D50726F7065727479456469746F72202E752D48434D202E612D50726F70657274792D6669656C647B626F726465723A31707820736F6C696421696D706F72';
wwv_flow_api.g_varchar2_table(131) := '74616E747D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D77726170706572202E612D50726F7065727479456469746F722D70726F706572747947726F75703A66697273742D6368696C647B6D617267696E';
wwv_flow_api.g_varchar2_table(132) := '2D746F703A3870787D2E75742D50726F7065727479456469746F72202E75692D6469616C6F67202E612D50726F7065727479456469746F727B6F766572666C6F773A6175746F3B6D61782D6865696768743A34303070787D2E75742D50726F7065727479';
wwv_flow_api.g_varchar2_table(133) := '456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75707B646973706C61793A626C6F636B3B6261636B67726F756E642D636C69703A70616464696E672D626F783B2D7765626B69742D7472616E736974696F6E3A';
wwv_flow_api.g_varchar2_table(134) := '6261636B67726F756E642D636F6C6F72202E317320656173652C2D7765626B69742D626F782D736861646F77202E317320656173653B7472616E736974696F6E3A6261636B67726F756E642D636F6C6F72202E317320656173652C626F782D736861646F';
wwv_flow_api.g_varchar2_table(135) := '77202E317320656173653B7472616E736974696F6E3A6261636B67726F756E642D636F6C6F72202E317320656173652C626F782D736861646F77202E317320656173652C2D7765626B69742D626F782D736861646F77202E317320656173657D2E75742D';
wwv_flow_api.g_varchar2_table(136) := '50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702E69732D636F6C6C6170736564202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465727B62';
wwv_flow_api.g_varchar2_table(137) := '6F726465722D626F74746F6D3A6E6F6E657D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702E69732D636F6C6C6170736564202E612D50726F7065727479456469746F722D';
wwv_flow_api.g_varchar2_table(138) := '70726F706572747947726F75702D626F64797B646973706C61793A6E6F6E657D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F7570';
wwv_flow_api.g_varchar2_table(139) := '3A66697273742D6368696C647B6D617267696E2D746F703A3470787D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465727B6D617267696E2D746F703A347078';
wwv_flow_api.g_varchar2_table(140) := '3B70616464696E673A31327078203870783B626F726465722D77696474683A303B2D7765626B69742D7472616E736974696F6E3A6D617267696E202E317320656173653B7472616E736974696F6E3A6D617267696E202E317320656173657D406D656469';
wwv_flow_api.g_varchar2_table(141) := '61206F6E6C792073637265656E20616E6420286D61782D77696474683A313032347078297B2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465727B7061646469';
wwv_flow_api.g_varchar2_table(142) := '6E672D746F703A3470783B70616464696E672D626F74746F6D3A3470787D7D406D65646961206F6E6C792073637265656E20616E6420286D696E2D77696474683A3130323570782920616E6420286D61782D77696474683A313237397078297B2E75742D';
wwv_flow_api.g_varchar2_table(143) := '50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465727B70616464696E672D746F703A3670783B70616464696E672D626F74746F6D3A3670787D7D406D65646961206F6E6C';
wwv_flow_api.g_varchar2_table(144) := '792073637265656E20616E6420286D696E2D77696474683A3132383170782920616E6420286D61782D77696474683A313637397078297B2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F7065727479';
wwv_flow_api.g_varchar2_table(145) := '47726F75702D6865616465727B70616464696E672D746F703A3870783B70616464696E672D626F74746F6D3A3870787D7D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D';
wwv_flow_api.g_varchar2_table(146) := '6865616465723A686F766572202E612D49636F6E7B6F7061636974793A317D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572202E612D49636F6E7B6D6172';
wwv_flow_api.g_varchar2_table(147) := '67696E3A327078203670782032707820303B626F726465722D7261646975733A3270783B6F7061636974793A2E353B2D7765626B69742D7472616E736974696F6E3A2E327320656173653B7472616E736974696F6E3A2E327320656173657D2E75742D50';
wwv_flow_api.g_varchar2_table(148) := '726F7065727479456469746F72202E752D52544C202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572202E612D49636F6E7B6D617267696E3A327078203020327078203670787D2E75742D50726F70657274';
wwv_flow_api.g_varchar2_table(149) := '79456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572202E612D49636F6E2E69636F6E2D72696768742D6172726F773A6265666F72657B636F6E74656E743A225C45304438227D2E75742D50';
wwv_flow_api.g_varchar2_table(150) := '726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572202E612D49636F6E2E69636F6E2D646F776E2D6172726F773A6265666F72657B636F6E74656E743A225C65306332227D';
wwv_flow_api.g_varchar2_table(151) := '2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465722E69732D666F63757365647B706F736974696F6E3A72656C61746976653B7A2D696E6465783A3130303B6F';
wwv_flow_api.g_varchar2_table(152) := '75746C696E653A307D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465722E69732D666F6375736564202E612D49636F6E7B6F7061636974793A317D2E75742D';
wwv_flow_api.g_varchar2_table(153) := '50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D7469746C657B646973706C61793A696E6C696E652D626C6F636B3B6D617267696E3A303B70616464696E673A303B76657274696361';
wwv_flow_api.g_varchar2_table(154) := '6C2D616C69676E3A746F703B666F6E742D7765696768743A3630303B666F6E742D73697A653A313470783B6C696E652D6865696768743A323070787D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722E69732D';
wwv_flow_api.g_varchar2_table(155) := '656D7074797B646973706C61793A2D7765626B69742D626F783B646973706C61793A2D6D732D666C6578626F783B646973706C61793A666C65783B6F766572666C6F773A68696464656E3B6865696768743A313030253B2D7765626B69742D626F782D61';
wwv_flow_api.g_varchar2_table(156) := '6C69676E3A63656E7465723B2D6D732D666C65782D616C69676E3A63656E7465723B616C69676E2D6974656D733A63656E7465727D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D6D6573736167657B7061';
wwv_flow_api.g_varchar2_table(157) := '6464696E673A313270783B77696474683A313030253B746578742D616C69676E3A63656E7465727D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D6D657373616765546578747B6D617267696E3A307D2E75';
wwv_flow_api.g_varchar2_table(158) := '742D50726F7065727479456469746F72202E612D49636F6E2B2E612D50726F7065727479456469746F722D6D657373616765546578747B6D617267696E2D746F703A3870787D2E75742D50726F7065727479456469746F72202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(159) := '456469746F722D65646974506172656E747B70616464696E673A367078203870783B746578742D616C69676E3A63656E7465727D406D65646961206F6E6C792073637265656E20616E6420286D61782D77696474683A313032347078297B2E75742D5072';
wwv_flow_api.g_varchar2_table(160) := '6F7065727479456469746F72202E612D50726F7065727479456469746F722D65646974506172656E747B70616464696E673A327078203870787D7D406D65646961206F6E6C792073637265656E20616E6420286D696E2D77696474683A31303235707829';
wwv_flow_api.g_varchar2_table(161) := '20616E6420286D61782D77696474683A313237397078297B2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D65646974506172656E747B70616464696E673A347078203870787D7D2E75742D50726F70657274';
wwv_flow_api.g_varchar2_table(162) := '79456469746F72202E612D50726F7065727479456469746F722D66696C7465727B706F736974696F6E3A72656C61746976653B646973706C61793A2D7765626B69742D626F783B646973706C61793A2D6D732D666C6578626F783B646973706C61793A66';
wwv_flow_api.g_varchar2_table(163) := '6C65783B70616464696E673A307D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E612D50726F7065727479456469746F722D66696C7465722D69636F6E7B706F736974696F6E3A616273';
wwv_flow_api.g_varchar2_table(164) := '6F6C7574653B746F703A303B6C6566743A303B6D617267696E3A3870783B6F7061636974793A2E353B2D7765626B69742D7472616E736974696F6E3A2E317320656173653B7472616E736974696F6E3A2E317320656173653B706F696E7465722D657665';
wwv_flow_api.g_varchar2_table(165) := '6E74733A6E6F6E657D2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F7065727479456469746F722D66696C746572202E612D50726F7065727479456469746F722D66696C7465722D69636F6E7B6C6566743A6175746F3B';
wwv_flow_api.g_varchar2_table(166) := '72696768743A307D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E612D50726F70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D74657874297B2D';
wwv_flow_api.g_varchar2_table(167) := '7765626B69742D626F782D73697A696E673A626F726465722D626F783B626F782D73697A696E673A626F726465722D626F783B70616464696E673A387078203870782038707820333270783B6865696768743A333270783B6C696E652D6865696768743A';
wwv_flow_api.g_varchar2_table(168) := '333270783B626F726465722D7261646975733A3270787D2E75742D50726F7065727479456469746F72202E752D52544C202E612D50726F7065727479456469746F722D66696C746572202E612D50726F70657274792D6669656C643A6E6F74282E612D50';
wwv_flow_api.g_varchar2_table(169) := '726F70657274792D6669656C642D2D74657874297B70616464696E673A387078203332707820387078203870787D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E612D50726F70657274';
wwv_flow_api.g_varchar2_table(170) := '792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D74657874293A666F6375732B2E612D49636F6E7B6F7061636974793A317D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D6669';
wwv_flow_api.g_varchar2_table(171) := '6C746572202E612D427574746F6E2D2D737469636B7946696C7465727B706F736974696F6E3A6162736F6C7574653B746F703A303B72696768743A303B626F74746F6D3A303B7A2D696E6465783A31303B6D617267696E3A3470783B70616464696E673A';
wwv_flow_api.g_varchar2_table(172) := '3470783B6F7061636974793A303B2D7765626B69742D7472616E736974696F6E3A6F706163697479202E317320656173653B7472616E736974696F6E3A6F706163697479202E317320656173657D2E75742D50726F7065727479456469746F72202E612D';
wwv_flow_api.g_varchar2_table(173) := '50726F7065727479456469746F722D66696C7465723A666F6375732D77697468696E202E612D50726F70657274792D6669656C642B2E612D49636F6E7B6F7061636974793A317D2E75742D50726F7065727479456469746F72202E612D50726F70657274';
wwv_flow_api.g_varchar2_table(174) := '79456469746F722D66696C746572202E612D427574746F6E2D2D737469636B7946696C7465722E69732D6163746976652C2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E612D42757474';
wwv_flow_api.g_varchar2_table(175) := '6F6E2D2D737469636B7946696C7465723A666F6375732C2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D66696C746572202E612D50726F70657274792D6669656C643A666F6375737E2E612D427574746F6E';
wwv_flow_api.g_varchar2_table(176) := '2D2D737469636B7946696C7465727B6F7061636974793A317D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D686967686C696768747B70616464696E673A32707820303B626F726465722D7261646975733A3270783B2D77';
wwv_flow_api.g_varchar2_table(177) := '65626B69742D7472616E736974696F6E3A2E317320656173653B7472616E736974696F6E3A2E317320656173657D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6E6F74466F756E647B70616464696E673A312E3672656D';
wwv_flow_api.g_varchar2_table(178) := '3B746578742D616C69676E3A63656E7465727D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6E6F74466F756E64202E612D49636F6E7B6D617267696E2D626F74746F6D3A3870787D2E75742D50726F7065727479456469';
wwv_flow_api.g_varchar2_table(179) := '746F72202E612D50726F706572747947726F75702D6974656D7B626F726465722D746F703A31707820736F6C69643B626F726465722D626F74746F6D2D77696474683A307D2E75742D50726F7065727479456469746F72202E612D50726F706572747945';
wwv_flow_api.g_varchar2_table(180) := '6469746F722D70726F706572747947726F75702D626F64797B70616464696E673A34707820307D0A2F2A2320736F757263654D617070696E6755524C3D626173652E6373732E6D61702A2F';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(776881501923146572)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_file_name=>'css/base.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C642D2D73656C656374207B0A20206261636B67726F756E642D696D6167653A2075726C28222E2E2F6173736574732F73656C6563742D6172726F772E7376672229';
wwv_flow_api.g_varchar2_table(2) := '3B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6572726F72202E612D50726F70657274792D6C6162656C207B0A2020636F6C6F723A20233130304630453B0A7D0A2E75742D50726F706572747945646974';
wwv_flow_api.g_varchar2_table(3) := '6F72202E612D50726F70657274792E69732D6572726F72202E612D50726F70657274792D6669656C643A6E6F74283A666F63757329207B0A2020636F6C6F723A20234337343633343B0A7D0A2E75742D50726F7065727479456469746F72202E612D5072';
wwv_flow_api.g_varchar2_table(4) := '6F70657274792E69732D6572726F72202E69636F6E2D6572726F72207B0A2020636F6C6F723A20234337343633342021696D706F7274616E743B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D7761726E69';
wwv_flow_api.g_varchar2_table(5) := '6E67202E612D50726F70657274792D6C6162656C207B0A2020636F6C6F723A20233130304630453B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D7761726E696E67202E69636F6E2D7761726E696E67207B';
wwv_flow_api.g_varchar2_table(6) := '0A2020636F6C6F723A20234438393734442021696D706F7274616E743B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C2C0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(7) := '2D7365744974656D734865616465722D6865616465722C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D756E6974207B0A2020636F6C6F723A20233130304630453B0A7D0A2E75742D50726F7065727479456469746F72';
wwv_flow_api.g_varchar2_table(8) := '202E612D50726F70657274792D636865636B626F782D6C6162656C2C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F207B0A2020636F6C6F723A20726762612831362C2031352C2031342C20302E38293B0A';
wwv_flow_api.g_varchar2_table(9) := '7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64207B0A2020782D6261636B67726F756E642D636F6C6F723A20234643464246413B0A2020636F6C6F723A20233130304630453B0A2020626F726465722D63';
wwv_flow_api.g_varchar2_table(10) := '6F6C6F723A20234536453345303B0A20202D7765626B69742D626F782D736861646F773A20302031707820327078207267626128302C20302C20302C20302E31293B0A2020626F782D736861646F773A20302031707820327078207267626128302C2030';
wwv_flow_api.g_varchar2_table(11) := '2C20302C20302E31293B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C643A686F766572207B0A2020782D6261636B67726F756E642D636F6C6F723A20234646464646463B0A20202D7765626B69742D62';
wwv_flow_api.g_varchar2_table(12) := '6F782D736861646F773A20302031707820327078207267626128302C20302C20302C20302E31293B0A2020626F782D736861646F773A20302031707820327078207267626128302C20302C20302C20302E31293B0A7D0A2E75742D50726F706572747945';
wwv_flow_api.g_varchar2_table(13) := '6469746F72202E612D50726F70657274792D6669656C643A666F637573207B0A20206F75746C696E652D636F6C6F723A20233337374535353B0A2020782D6261636B67726F756E642D636F6C6F723A20234646464646463B0A20202D7765626B69742D62';
wwv_flow_api.g_varchar2_table(14) := '6F782D736861646F773A20302031707820327078207267626128302C20302C20302C20302E31293B0A2020626F782D736861646F773A20302031707820327078207267626128302C20302C20302C20302E31293B0A20206F75746C696E652D6F66667365';
wwv_flow_api.g_varchar2_table(15) := '743A203270783B0A20206F75746C696E652D77696474683A203270783B0A20206F75746C696E652D7374796C653A20646F747465643B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6572726F722E69732D';
wwv_flow_api.g_varchar2_table(16) := '616374697665202E612D50726F70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D7465787461726561293A666F637573207B0A20202D7765626B69742D626F782D736861646F773A20302030203020317078202345';
wwv_flow_api.g_varchar2_table(17) := '333531334320696E7365742C2030203170782032707820726762612835312C2035312C2035312C20302E31293B0A2020626F782D736861646F773A20302030203020317078202345333531334320696E7365742C20302031707820327078207267626128';
wwv_flow_api.g_varchar2_table(18) := '35312C2035312C2035312C20302E31293B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D736861646F772E69732D616374697665202E612D50726F70657274792D6669656C643A6E6F74282E612D50726F70';
wwv_flow_api.g_varchar2_table(19) := '657274792D6669656C642D2D7465787461726561293A666F637573207B0A20202D7765626B69742D626F782D736861646F773A20302030203020317078202345333531334320696E7365742C2030203170782032707820726762612835312C2035312C20';
wwv_flow_api.g_varchar2_table(20) := '35312C20302E31293B0A2020626F782D736861646F773A20302030203020317078202345333531334320696E7365742C2030203170782032707820726762612835312C2035312C2035312C20302E31293B0A7D0A2E75742D50726F706572747945646974';
wwv_flow_api.g_varchar2_table(21) := '6F72202E612D50726F70657274792E69732D7661726961626C65202E612D49636F6E2E69636F6E2D7661726961626C65207B0A2020636F6C6F723A20233746424546323B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274';
wwv_flow_api.g_varchar2_table(22) := '792E69732D7661726961626C65202E612D50726F70657274792D6669656C64207B0A20202D7765626B69742D626F782D736861646F773A203020302030203170782072676261283132372C203139302C203234322C20302E352920696E7365743B0A2020';
wwv_flow_api.g_varchar2_table(23) := '626F782D736861646F773A203020302030203170782072676261283132372C203139302C203234322C20302E352920696E7365743B0A2020782D6261636B67726F756E642D636F6C6F723A20236633663966653B0A7D0A2E75742D50726F706572747945';
wwv_flow_api.g_varchar2_table(24) := '6469746F72202E612D50726F70657274792E69732D7761726E696E67202E612D50726F70657274792D6669656C642D2D74657874617265613A666F637573207B0A2020626F726465722D636F6C6F723A20234641434436322021696D706F7274616E743B';
wwv_flow_api.g_varchar2_table(25) := '0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6572726F72202E612D50726F70657274792D6669656C642D2D74657874617265613A666F637573207B0A2020626F726465722D636F6C6F723A202345333531';
wwv_flow_api.g_varchar2_table(26) := '33432021696D706F7274616E743B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E6572202E612D427574746F6E207B0A20206261636B67726F756E642D636F6C6F723A2023464646';
wwv_flow_api.g_varchar2_table(27) := '4646463B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A6265666F72652C0A2E75742D50726F70657274794564';
wwv_flow_api.g_varchar2_table(28) := '69746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C3A6265666F7265207B0A20206261636B67726F756E642D636F6C6F723A20234646464646463B0A2020626F726465722D636F';
wwv_flow_api.g_varchar2_table(29) := '6C6F723A20234446444344383B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A666F637573202B206C6162656C3A6265666F72652C';
wwv_flow_api.g_varchar2_table(30) := '0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A696E64657465726D696E617465202B206C6162656C3A6265666F72652C0A2E75742D5072';
wwv_flow_api.g_varchar2_table(31) := '6F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D3A666F637573202B206C6162656C3A6265666F72652C0A2E75742D50726F7065727479456469746F72202E612D50726F7065';
wwv_flow_api.g_varchar2_table(32) := '7274792D726164696F2D696E7075745B747970653D22726164696F225D3A696E64657465726D696E617465202B206C6162656C3A6265666F7265207B0A2020626F726465722D636F6C6F723A20233337374535353B0A20202D7765626B69742D626F782D';
wwv_flow_api.g_varchar2_table(33) := '736861646F773A207267626128302C20302C20302C20302E3129203020317078203170783B0A2020626F782D736861646F773A207267626128302C20302C20302C20302E3129203020317078203170783B0A7D0A2E75742D50726F706572747945646974';
wwv_flow_api.g_varchar2_table(34) := '6F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A666F6375733A636865636B6564202B206C6162656C3A6265666F72652C0A2E75742D50726F7065727479456469746F72202E612D50';
wwv_flow_api.g_varchar2_table(35) := '726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A666F6375733A696E64657465726D696E617465202B206C6162656C3A6265666F72652C0A2E75742D50726F7065727479456469746F72202E612D5072';
wwv_flow_api.g_varchar2_table(36) := '6F70657274792D726164696F2D696E7075745B747970653D22726164696F225D3A666F6375733A636865636B6564202B206C6162656C3A6265666F72652C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D';
wwv_flow_api.g_varchar2_table(37) := '696E7075745B747970653D22726164696F225D3A666F6375733A696E64657465726D696E617465202B206C6162656C3A6265666F7265207B0A2020626F726465722D636F6C6F723A20233337374535353B0A20206261636B67726F756E642D636F6C6F72';
wwv_flow_api.g_varchar2_table(38) := '3A20233337374535353B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A696E64657465726D696E617465202B206C6162656C3A6265';
wwv_flow_api.g_varchar2_table(39) := '666F72652C0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A636865636B6564202B206C6162656C3A6265666F7265207B0A2020626F7264';
wwv_flow_api.g_varchar2_table(40) := '65722D636F6C6F723A20233637363035423B0A20206261636B67726F756E642D636F6C6F723A20233637363035423B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B74797065';
wwv_flow_api.g_varchar2_table(41) := '3D22636865636B626F78225D3A696E64657465726D696E617465202B206C6162656C3A6166746572207B0A20206261636B67726F756E642D636F6C6F723A20234643464246413B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70';
wwv_flow_api.g_varchar2_table(42) := '657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A636865636B6564202B206C6162656C3A6166746572207B0A20206261636B67726F756E642D696D6167653A2075726C28222E2E2F6173736574732F63686563';
wwv_flow_api.g_varchar2_table(43) := '6B626F782D636865636B65642E73766722293B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D3A636865636B6564202B206C6162656C3A6265666F72';
wwv_flow_api.g_varchar2_table(44) := '65207B0A2020626F726465722D636F6C6F723A20726762612831362C2031352C2031342C20302E36293B0A20206261636B67726F756E642D636F6C6F723A20726762612831362C2031352C2031342C20302E36293B0A7D0A2E75742D50726F7065727479';
wwv_flow_api.g_varchar2_table(45) := '456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A636865636B6564202B206C6162656C207B0A20206261636B67726F756E642D636F6C6F';
wwv_flow_api.g_varchar2_table(46) := '723A20234446444344383B0A20202D7765626B69742D626F782D736861646F773A20302030203020317078207267626128302C20302C20302C20302E312920696E7365742C20302032707820317078207267626128302C20302C20302C20302E30352920';
wwv_flow_api.g_varchar2_table(47) := '696E7365743B0A2020626F782D736861646F773A20302030203020317078207267626128302C20302C20302C20302E312920696E7365742C20302032707820317078207267626128302C20302C20302C20302E30352920696E7365743B0A7D0A2E75742D';
wwv_flow_api.g_varchar2_table(48) := '50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A666F637573202B206C6162656C207B0A2020626F726465722D636F';
wwv_flow_api.g_varchar2_table(49) := '6C6F723A20302031707820327078207267626128302C20302C20302C20302E31292021696D706F7274616E743B0A20206261636B67726F756E642D636F6C6F723A20234446444344383B0A20202D7765626B69742D626F782D736861646F773A20302030';
wwv_flow_api.g_varchar2_table(50) := '20302031707820302031707820327078207267626128302C20302C20302C20302E312920696E7365742C20302031707820327078207267626128302C20302C20302C20302E31293B0A2020626F782D736861646F773A2030203020302031707820302031';
wwv_flow_api.g_varchar2_table(51) := '707820327078207267626128302C20302C20302C20302E312920696E7365742C20302031707820327078207267626128302C20302C20302C20302E31293B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D72616469';
wwv_flow_api.g_varchar2_table(52) := '6F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A6E6F74283A636865636B6564293A686F766572202B206C6162656C207B0A20202D7765626B69742D626F782D736861646F773A20302030203020';
wwv_flow_api.g_varchar2_table(53) := '317078207267626128302C20302C20302C20302E31352920696E7365742C20302031707820327078207267626128302C20302C20302C20302E31293B0A2020626F782D736861646F773A20302030203020317078207267626128302C20302C20302C2030';
wwv_flow_api.g_varchar2_table(54) := '2E31352920696E7365742C20302031707820327078207267626128302C20302C20302C20302E31293B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D';
wwv_flow_api.g_varchar2_table(55) := '50726F70657274792D726164696F2D696E7075743A686F7665723A616374697665202B206C6162656C207B0A20202D7765626B69742D626F782D736861646F773A2030203020302031707820302031707820327078207267626128302C20302C20302C20';
wwv_flow_api.g_varchar2_table(56) := '302E312920696E7365742C20302031707820327078207267626128302C20302C20302C20302E31293B0A2020626F782D736861646F773A2030203020302031707820302031707820327078207267626128302C20302C20302C20302E312920696E736574';
wwv_flow_api.g_varchar2_table(57) := '2C20302031707820327078207267626128302C20302C20302C20302E31293B0A20206261636B67726F756E642D636F6C6F723A20234536453345303B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636F6C6F7250';
wwv_flow_api.g_varchar2_table(58) := '726576696577207B0A20202D7765626B69742D626F782D736861646F773A20302030203020317078207267626128302C20302C20302C20302E312920696E7365743B0A2020626F782D736861646F773A20302030203020317078207267626128302C2030';
wwv_flow_api.g_varchar2_table(59) := '2C20302C20302E312920696E7365743B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6368616E676564202E612D50726F70657274792D6C6162656C436F6E7461696E65723A6265666F7265207B0A202062';
wwv_flow_api.g_varchar2_table(60) := '61636B67726F756E642D636F6C6F723A20233337374535353B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F72207B0A2020782D6261636B67726F756E642D636F6C6F723A20234536453345303B0A7D0A';
wwv_flow_api.g_varchar2_table(61) := '2E75742D50726F7065727479456469746F72202E75692D6469616C6F67202E612D50726F7065727479456469746F72207B0A2020782D6261636B67726F756E642D636F6C6F723A207472616E73706172656E743B0A7D0A2E75742D50726F706572747945';
wwv_flow_api.g_varchar2_table(62) := '6469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702C0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465722C0A2E75';
wwv_flow_api.g_varchar2_table(63) := '742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D626F6479207B0A2020626F726465722D636F6C6F723A20234536453345303B0A7D0A2E75742D50726F7065727479456469746F';
wwv_flow_api.g_varchar2_table(64) := '72202E612D50726F7065727479456469746F722D70726F706572747947726F7570207B0A2020782D6261636B67726F756E642D636F6C6F723A20234637463546333B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F706572747945';
wwv_flow_api.g_varchar2_table(65) := '6469746F722D70726F706572747947726F75703A666F6375732D77697468696E2C0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702E6861732D666F637573207B0A202078';
wwv_flow_api.g_varchar2_table(66) := '2D6261636B67726F756E642D636F6C6F723A2072676261283232342C203234352C203231382C20302E33293B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865';
wwv_flow_api.g_varchar2_table(67) := '61646572202E612D49636F6E207B0A2020636F6C6F723A20234643464246413B0A20206261636B67726F756E642D636F6C6F723A20234138413239423B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F72';
wwv_flow_api.g_varchar2_table(68) := '2D70726F706572747947726F75702D7469746C65207B0A2020636F6C6F723A20233130304630453B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D626F6479202E';
wwv_flow_api.g_varchar2_table(69) := '612D50726F7065727479207B0A2020626F726465722D636F6C6F723A20234536453345303B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465722E6973';
wwv_flow_api.g_varchar2_table(70) := '2D666F6375736564207B0A20202D7765626B69742D626F782D736861646F773A20726762612835312C2035312C2035312C20302E31293B0A2020626F782D736861646F773A20726762612835312C2035312C2035312C20302E31293B0A7D0A2E75742D50';
wwv_flow_api.g_varchar2_table(71) := '726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465722E69732D666F6375736564202E612D49636F6E207B0A2020782D6261636B67726F756E642D636F6C6F723A2023333737';
wwv_flow_api.g_varchar2_table(72) := '4535353B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D6D657373616765207B0A2020636F6C6F723A20726762612831362C2031352C2031342C20302E36293B0A7D0A2E75742D50726F7065727479';
wwv_flow_api.g_varchar2_table(73) := '456469746F72202E612D50726F7065727479456469746F722D6D65737361676554657874207B0A2020636F6C6F723A20726762612831362C2031352C2031342C20302E38293B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F7065';
wwv_flow_api.g_varchar2_table(74) := '7274792D686967686C69676874207B0A20206261636B67726F756E642D636F6C6F723A20234645454443333B0A20202D7765626B69742D626F782D736861646F773A20302031707820317078202D31707820726762612835312C2035312C2035312C2030';
wwv_flow_api.g_varchar2_table(75) := '2E31293B0A2020626F782D736861646F773A20302031707820317078202D31707820726762612835312C2035312C2035312C20302E31293B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6E6F74466F756E64207B';
wwv_flow_api.g_varchar2_table(76) := '0A2020636F6C6F723A20726762612831362C2031352C2031342C20302E36293B0A7D0A2E75742D50726F7065727479456469746F72202E612D50726F706572747947726F75702D6974656D207B0A2020626F726465722D746F702D636F6C6F723A202343';
wwv_flow_api.g_varchar2_table(77) := '42433542463B0A7D0A';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(776881932522146573)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_file_name=>'css/style.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '7B2276657273696F6E223A332C22736F7572636573223A5B227374796C652E637373225D2C226E616D6573223A5B5D2C226D617070696E6773223A22414141412C34432C434143452C67442C434145462C79442C434143452C612C434145462C38444141';
wwv_flow_api.g_varchar2_table(2) := '38442C4F2C43414335442C612C434145462C6D442C434143452C75422C434151462C6F432C434143412C6F442C434143412C6D432C434152412C32442C434143452C612C434145462C75442C434143452C75422C43414F462C36432C434143412C6F432C';
wwv_flow_api.g_varchar2_table(3) := '434143452C75422C434145462C6F432C434143452C30422C434143412C612C434143412C6F422C434143412C32432C434143412C6D432C434145462C30432C434143452C75422C434143412C32432C434143412C6D432C434145462C30432C434143452C';
wwv_flow_api.g_varchar2_table(4) := '71422C434143412C75422C434143412C32432C434143412C6D432C434143412C6B422C434143412C69422C434143412C6F422C434145462C7745414177452C6B432C43414978452C7945414179452C6B432C43414876452C73452C434143412C38442C43';
wwv_flow_api.g_varchar2_table(5) := '414D462C67452C434143452C612C434145462C34442C434143452C75442C434143412C2B432C434143412C30422C434145462C32452C434143452C38422C434145462C79452C434143452C38422C434145462C77442C434143452C71422C434145462C79';
wwv_flow_api.g_varchar2_table(6) := '452C434143412C6D452C434143452C71422C434143412C6F422C434145462C2B452C434143412C75462C434143412C79452C434143412C69462C434143452C6F422C434143412C32432C434143412C6D432C434145462C75462C434143412C36462C4341';
wwv_flow_api.g_varchar2_table(7) := '43412C69462C434143412C75462C434143452C6F422C434143412C77422C434147462C69462C434144412C75462C434145452C6F422C434143412C77422C434145462C73462C434143452C77422C434145462C67462C434143452C6F442C434145462C32';
wwv_flow_api.g_varchar2_table(8) := '452C434143452C38422C434143412C6B432C434145462C30462C434143452C77422C434143412C69462C434143412C79452C434145462C77462C434143452C2B432C434143412C77422C434143412C6F462C434143412C34452C434145462C6946414169';
wwv_flow_api.g_varchar2_table(9) := '462C71422C4341432F452C32452C434143412C6D452C434145462C2B462C434143452C6F462C434143412C34452C434143412C77422C434145462C32432C434143452C69442C434143412C79432C434145462C32452C434143452C77422C434145462C6F';
wwv_flow_api.g_varchar2_table(10) := '432C434143452C30422C434145462C2B432C434143452C38422C434145462C6B442C434145412C75442C434144412C79442C434145452C6F422C434145462C6B442C434143452C30422C434147462C34442C434144412C2B442C434145452C75432C4341';
wwv_flow_api.g_varchar2_table(11) := '45462C69452C434143452C612C434143412C77422C434145462C77442C434143452C612C434145462C6D452C434143452C6F422C434145462C6F452C434143452C6F432C434143412C34422C434145462C34452C434143452C30422C434145462C34432C';
wwv_flow_api.g_varchar2_table(12) := '434143452C75422C434145462C67442C434143452C75422C434145462C77432C434143452C77422C434143412C6D442C434143412C32432C434145462C75432C434143452C75422C434145462C77432C434143452C7742222C2266696C65223A22737479';
wwv_flow_api.g_varchar2_table(13) := '6C652E637373222C22736F7572636573436F6E74656E74223A5B222E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C642D2D73656C656374207B5C6E20206261636B67726F756E642D696D6167653A2075726C285C';
wwv_flow_api.g_varchar2_table(14) := '222E2E2F6173736574732F73656C6563742D6172726F772E7376675C22293B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6572726F72202E612D50726F70657274792D6C6162656C207B5C6E202063';
wwv_flow_api.g_varchar2_table(15) := '6F6C6F723A20233130304630453B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6572726F72202E612D50726F70657274792D6669656C643A6E6F74283A666F63757329207B5C6E2020636F6C6F723A';
wwv_flow_api.g_varchar2_table(16) := '20234337343633343B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6572726F72202E69636F6E2D6572726F72207B5C6E2020636F6C6F723A20234337343633342021696D706F7274616E743B5C6E7D';
wwv_flow_api.g_varchar2_table(17) := '5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D7761726E696E67202E612D50726F70657274792D6C6162656C207B5C6E2020636F6C6F723A20233130304630453B5C6E7D5C6E2E75742D50726F706572747945';
wwv_flow_api.g_varchar2_table(18) := '6469746F72202E612D50726F70657274792E69732D7761726E696E67202E69636F6E2D7761726E696E67207B5C6E2020636F6C6F723A20234438393734442021696D706F7274616E743B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E61';
wwv_flow_api.g_varchar2_table(19) := '2D50726F70657274792D6C6162656C2C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D7365744974656D734865616465722D6865616465722C5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065';
wwv_flow_api.g_varchar2_table(20) := '7274792D756E6974207B5C6E2020636F6C6F723A20233130304630453B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D6C6162656C2C5C6E2E75742D50726F7065727479456469746F72';
wwv_flow_api.g_varchar2_table(21) := '202E612D50726F70657274792D726164696F207B5C6E2020636F6C6F723A20726762612831362C2031352C2031342C20302E38293B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C64207B5C6E2020';
wwv_flow_api.g_varchar2_table(22) := '782D6261636B67726F756E642D636F6C6F723A20234643464246413B5C6E2020636F6C6F723A20233130304630453B5C6E2020626F726465722D636F6C6F723A20234536453345303B5C6E20202D7765626B69742D626F782D736861646F773A20302031';
wwv_flow_api.g_varchar2_table(23) := '707820327078207267626128302C20302C20302C20302E31293B5C6E2020626F782D736861646F773A20302031707820327078207267626128302C20302C20302C20302E31293B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D5072';
wwv_flow_api.g_varchar2_table(24) := '6F70657274792D6669656C643A686F766572207B5C6E2020782D6261636B67726F756E642D636F6C6F723A20234646464646463B5C6E20202D7765626B69742D626F782D736861646F773A20302031707820327078207267626128302C20302C20302C20';
wwv_flow_api.g_varchar2_table(25) := '302E31293B5C6E2020626F782D736861646F773A20302031707820327078207267626128302C20302C20302C20302E31293B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C643A666F637573207B5C';
wwv_flow_api.g_varchar2_table(26) := '6E20206F75746C696E652D636F6C6F723A20233337374535353B5C6E2020782D6261636B67726F756E642D636F6C6F723A20234646464646463B5C6E20202D7765626B69742D626F782D736861646F773A20302031707820327078207267626128302C20';
wwv_flow_api.g_varchar2_table(27) := '302C20302C20302E31293B5C6E2020626F782D736861646F773A20302031707820327078207267626128302C20302C20302C20302E31293B5C6E20206F75746C696E652D6F66667365743A203270783B5C6E20206F75746C696E652D77696474683A2032';
wwv_flow_api.g_varchar2_table(28) := '70783B5C6E20206F75746C696E652D7374796C653A20646F747465643B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6572726F722E69732D616374697665202E612D50726F70657274792D6669656C';
wwv_flow_api.g_varchar2_table(29) := '643A6E6F74282E612D50726F70657274792D6669656C642D2D7465787461726561293A666F637573207B5C6E20202D7765626B69742D626F782D736861646F773A20302030203020317078202345333531334320696E7365742C20302031707820327078';
wwv_flow_api.g_varchar2_table(30) := '20726762612835312C2035312C2035312C20302E31293B5C6E2020626F782D736861646F773A20302030203020317078202345333531334320696E7365742C2030203170782032707820726762612835312C2035312C2035312C20302E31293B5C6E7D5C';
wwv_flow_api.g_varchar2_table(31) := '6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D736861646F772E69732D616374697665202E612D50726F70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D74657874617265';
wwv_flow_api.g_varchar2_table(32) := '61293A666F637573207B5C6E20202D7765626B69742D626F782D736861646F773A20302030203020317078202345333531334320696E7365742C2030203170782032707820726762612835312C2035312C2035312C20302E31293B5C6E2020626F782D73';
wwv_flow_api.g_varchar2_table(33) := '6861646F773A20302030203020317078202345333531334320696E7365742C2030203170782032707820726762612835312C2035312C2035312C20302E31293B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792E';
wwv_flow_api.g_varchar2_table(34) := '69732D7661726961626C65202E612D49636F6E2E69636F6E2D7661726961626C65207B5C6E2020636F6C6F723A20233746424546323B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D7661726961626C';
wwv_flow_api.g_varchar2_table(35) := '65202E612D50726F70657274792D6669656C64207B5C6E20202D7765626B69742D626F782D736861646F773A203020302030203170782072676261283132372C203139302C203234322C20302E352920696E7365743B5C6E2020626F782D736861646F77';
wwv_flow_api.g_varchar2_table(36) := '3A203020302030203170782072676261283132372C203139302C203234322C20302E352920696E7365743B5C6E2020782D6261636B67726F756E642D636F6C6F723A20236633663966653B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E';
wwv_flow_api.g_varchar2_table(37) := '612D50726F70657274792E69732D7761726E696E67202E612D50726F70657274792D6669656C642D2D74657874617265613A666F637573207B5C6E2020626F726465722D636F6C6F723A20234641434436322021696D706F7274616E743B5C6E7D5C6E2E';
wwv_flow_api.g_varchar2_table(38) := '75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6572726F72202E612D50726F70657274792D6669656C642D2D74657874617265613A666F637573207B5C6E2020626F726465722D636F6C6F723A202345333531334320';
wwv_flow_api.g_varchar2_table(39) := '21696D706F7274616E743B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E6572202E612D427574746F6E207B5C6E20206261636B67726F756E642D636F6C6F723A2023464646';
wwv_flow_api.g_varchar2_table(40) := '4646463B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D202B206C6162656C3A6265666F72652C5C6E2E75742D50726F7065';
wwv_flow_api.g_varchar2_table(41) := '727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D202B206C6162656C3A6265666F7265207B5C6E20206261636B67726F756E642D636F6C6F723A20234646464646463B5C6E2020';
wwv_flow_api.g_varchar2_table(42) := '626F726465722D636F6C6F723A20234446444344383B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D3A666F637573202B20';
wwv_flow_api.g_varchar2_table(43) := '6C6162656C3A6265666F72652C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D3A696E64657465726D696E617465202B206C616265';
wwv_flow_api.g_varchar2_table(44) := '6C3A6265666F72652C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D3A666F637573202B206C6162656C3A6265666F72652C5C6E2E75742D50726F';
wwv_flow_api.g_varchar2_table(45) := '7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D3A696E64657465726D696E617465202B206C6162656C3A6265666F7265207B5C6E2020626F726465722D636F6C6F723A20';
wwv_flow_api.g_varchar2_table(46) := '233337374535353B5C6E20202D7765626B69742D626F782D736861646F773A207267626128302C20302C20302C20302E3129203020317078203170783B5C6E2020626F782D736861646F773A207267626128302C20302C20302C20302E31292030203170';
wwv_flow_api.g_varchar2_table(47) := '78203170783B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D3A666F6375733A636865636B6564202B206C6162656C3A6265';
wwv_flow_api.g_varchar2_table(48) := '666F72652C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D3A666F6375733A696E64657465726D696E617465202B206C6162656C3A';
wwv_flow_api.g_varchar2_table(49) := '6265666F72652C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D3A666F6375733A636865636B6564202B206C6162656C3A6265666F72652C5C6E2E';
wwv_flow_api.g_varchar2_table(50) := '75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D3A666F6375733A696E64657465726D696E617465202B206C6162656C3A6265666F7265207B5C6E2020626F';
wwv_flow_api.g_varchar2_table(51) := '726465722D636F6C6F723A20233337374535353B5C6E20206261636B67726F756E642D636F6C6F723A20233337374535353B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E707574';
wwv_flow_api.g_varchar2_table(52) := '5B747970653D5C22636865636B626F785C225D3A696E64657465726D696E617465202B206C6162656C3A6265666F72652C5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970';
wwv_flow_api.g_varchar2_table(53) := '653D5C22636865636B626F785C225D3A636865636B6564202B206C6162656C3A6265666F7265207B5C6E2020626F726465722D636F6C6F723A20233637363035423B5C6E20206261636B67726F756E642D636F6C6F723A20233637363035423B5C6E7D5C';
wwv_flow_api.g_varchar2_table(54) := '6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D3A696E64657465726D696E617465202B206C6162656C3A6166746572207B5C6E202062';
wwv_flow_api.g_varchar2_table(55) := '61636B67726F756E642D636F6C6F723A20234643464246413B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D5C22636865636B626F785C225D3A636865636B';
wwv_flow_api.g_varchar2_table(56) := '6564202B206C6162656C3A6166746572207B5C6E20206261636B67726F756E642D696D6167653A2075726C285C222E2E2F6173736574732F636865636B626F782D636865636B65642E7376675C22293B5C6E7D5C6E2E75742D50726F7065727479456469';
wwv_flow_api.g_varchar2_table(57) := '746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D5C22726164696F5C225D3A636865636B6564202B206C6162656C3A6265666F7265207B5C6E2020626F726465722D636F6C6F723A20726762612831362C2031352C2031';
wwv_flow_api.g_varchar2_table(58) := '342C20302E36293B5C6E20206261636B67726F756E642D636F6C6F723A20726762612831362C2031352C2031342C20302E36293B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D';
wwv_flow_api.g_varchar2_table(59) := '627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A636865636B6564202B206C6162656C207B5C6E20206261636B67726F756E642D636F6C6F723A20234446444344383B5C6E20202D7765626B69742D626F782D736861';
wwv_flow_api.g_varchar2_table(60) := '646F773A20302030203020317078207267626128302C20302C20302C20302E312920696E7365742C20302032707820317078207267626128302C20302C20302C20302E30352920696E7365743B5C6E2020626F782D736861646F773A2030203020302031';
wwv_flow_api.g_varchar2_table(61) := '7078207267626128302C20302C20302C20302E312920696E7365742C20302032707820317078207267626128302C20302C20302C20302E30352920696E7365743B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(62) := '2D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A666F637573202B206C6162656C207B5C6E2020626F726465722D636F6C6F723A20302031707820327078207267626128302C20302C';
wwv_flow_api.g_varchar2_table(63) := '20302C20302E31292021696D706F7274616E743B5C6E20206261636B67726F756E642D636F6C6F723A20234446444344383B5C6E20202D7765626B69742D626F782D736861646F773A203020302030203170782030203170782032707820726762612830';
wwv_flow_api.g_varchar2_table(64) := '2C20302C20302C20302E312920696E7365742C20302031707820327078207267626128302C20302C20302C20302E31293B5C6E2020626F782D736861646F773A2030203020302031707820302031707820327078207267626128302C20302C20302C2030';
wwv_flow_api.g_varchar2_table(65) := '2E312920696E7365742C20302031707820327078207267626128302C20302C20302C20302E31293B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E61';
wwv_flow_api.g_varchar2_table(66) := '2D50726F70657274792D726164696F2D696E7075743A6E6F74283A636865636B6564293A686F766572202B206C6162656C207B5C6E20202D7765626B69742D626F782D736861646F773A20302030203020317078207267626128302C20302C20302C2030';
wwv_flow_api.g_varchar2_table(67) := '2E31352920696E7365742C20302031707820327078207267626128302C20302C20302C20302E31293B5C6E2020626F782D736861646F773A20302030203020317078207267626128302C20302C20302C20302E31352920696E7365742C20302031707820';
wwv_flow_api.g_varchar2_table(68) := '327078207267626128302C20302C20302C20302E31293B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D69';
wwv_flow_api.g_varchar2_table(69) := '6E7075743A686F7665723A616374697665202B206C6162656C207B5C6E20202D7765626B69742D626F782D736861646F773A2030203020302031707820302031707820327078207267626128302C20302C20302C20302E312920696E7365742C20302031';
wwv_flow_api.g_varchar2_table(70) := '707820327078207267626128302C20302C20302C20302E31293B5C6E2020626F782D736861646F773A2030203020302031707820302031707820327078207267626128302C20302C20302C20302E312920696E7365742C20302031707820327078207267';
wwv_flow_api.g_varchar2_table(71) := '626128302C20302C20302C20302E31293B5C6E20206261636B67726F756E642D636F6C6F723A20234536453345303B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636F6C6F7250726576696577207B5C6E20';
wwv_flow_api.g_varchar2_table(72) := '202D7765626B69742D626F782D736861646F773A20302030203020317078207267626128302C20302C20302C20302E312920696E7365743B5C6E2020626F782D736861646F773A20302030203020317078207267626128302C20302C20302C20302E3129';
wwv_flow_api.g_varchar2_table(73) := '20696E7365743B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6368616E676564202E612D50726F70657274792D6C6162656C436F6E7461696E65723A6265666F7265207B5C6E20206261636B67726F';
wwv_flow_api.g_varchar2_table(74) := '756E642D636F6C6F723A20233337374535353B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F72207B5C6E2020782D6261636B67726F756E642D636F6C6F723A20234536453345303B5C6E7D5C6E2E';
wwv_flow_api.g_varchar2_table(75) := '75742D50726F7065727479456469746F72202E75692D6469616C6F67202E612D50726F7065727479456469746F72207B5C6E2020782D6261636B67726F756E642D636F6C6F723A207472616E73706172656E743B5C6E7D5C6E2E75742D50726F70657274';
wwv_flow_api.g_varchar2_table(76) := '79456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702C5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465722C';
wwv_flow_api.g_varchar2_table(77) := '5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D626F6479207B5C6E2020626F726465722D636F6C6F723A20234536453345303B5C6E7D5C6E2E75742D50726F706572';
wwv_flow_api.g_varchar2_table(78) := '7479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F7570207B5C6E2020782D6261636B67726F756E642D636F6C6F723A20234637463546333B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E61';
wwv_flow_api.g_varchar2_table(79) := '2D50726F7065727479456469746F722D70726F706572747947726F75703A666F6375732D77697468696E2C5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702E6861732D';
wwv_flow_api.g_varchar2_table(80) := '666F637573207B5C6E2020782D6261636B67726F756E642D636F6C6F723A2072676261283232342C203234352C203231382C20302E33293B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D7072';
wwv_flow_api.g_varchar2_table(81) := '6F706572747947726F75702D686561646572202E612D49636F6E207B5C6E2020636F6C6F723A20234643464246413B5C6E20206261636B67726F756E642D636F6C6F723A20234138413239423B5C6E7D5C6E2E75742D50726F7065727479456469746F72';
wwv_flow_api.g_varchar2_table(82) := '202E612D50726F7065727479456469746F722D70726F706572747947726F75702D7469746C65207B5C6E2020636F6C6F723A20233130304630453B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F72';
wwv_flow_api.g_varchar2_table(83) := '2D70726F706572747947726F75702D626F6479202E612D50726F7065727479207B5C6E2020626F726465722D636F6C6F723A20234536453345303B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F72';
wwv_flow_api.g_varchar2_table(84) := '2D70726F706572747947726F75702D6865616465722E69732D666F6375736564207B5C6E20202D7765626B69742D626F782D736861646F773A20726762612835312C2035312C2035312C20302E31293B5C6E2020626F782D736861646F773A2072676261';
wwv_flow_api.g_varchar2_table(85) := '2835312C2035312C2035312C20302E31293B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465722E69732D666F6375736564202E612D49636F6E20';
wwv_flow_api.g_varchar2_table(86) := '7B5C6E2020782D6261636B67726F756E642D636F6C6F723A20233337374535353B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D6D657373616765207B5C6E2020636F6C6F723A207267626128';
wwv_flow_api.g_varchar2_table(87) := '31362C2031352C2031342C20302E36293B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D6D65737361676554657874207B5C6E2020636F6C6F723A20726762612831362C2031352C2031342C20';
wwv_flow_api.g_varchar2_table(88) := '302E38293B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D686967686C69676874207B5C6E20206261636B67726F756E642D636F6C6F723A20234645454443333B5C6E20202D7765626B69742D626F782D7368';
wwv_flow_api.g_varchar2_table(89) := '61646F773A20302031707820317078202D31707820726762612835312C2035312C2035312C20302E31293B5C6E2020626F782D736861646F773A20302031707820317078202D31707820726762612835312C2035312C2035312C20302E31293B5C6E7D5C';
wwv_flow_api.g_varchar2_table(90) := '6E2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6E6F74466F756E64207B5C6E2020636F6C6F723A20726762612831362C2031352C2031342C20302E36293B5C6E7D5C6E2E75742D50726F7065727479456469746F72202E';
wwv_flow_api.g_varchar2_table(91) := '612D50726F706572747947726F75702D6974656D207B5C6E2020626F726465722D746F702D636F6C6F723A20234342433542463B5C6E7D5C6E225D7D';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(776882396133146573)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_file_name=>'css/style.css.map'
,p_mime_type=>'application/json'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '2E75742D50726F7065727479456469746F72207B0A202020202E612D50726F70657274792D6669656C642D2D73656C656374207B0A202020206261636B67726F756E642D696D6167653A2075726C28222E2E2F6173736574732F73656C6563742D617272';
wwv_flow_api.g_varchar2_table(2) := '6F772E73766722293B0A202020207D0A0A202020202E612D50726F70657274792E69732D6572726F72202E612D50726F70657274792D6C6162656C207B0A20202020636F6C6F723A20233130304630453B0A202020207D0A0A202020202E612D50726F70';
wwv_flow_api.g_varchar2_table(3) := '657274792E69732D6572726F72202E612D50726F70657274792D6669656C643A6E6F74283A666F63757329207B0A20202020636F6C6F723A20234337343633343B0A202020207D0A0A202020202E612D50726F70657274792E69732D6572726F72202E69';
wwv_flow_api.g_varchar2_table(4) := '636F6E2D6572726F72207B0A20202020636F6C6F723A20234337343633342021696D706F7274616E743B0A202020207D0A0A202020202E612D50726F70657274792E69732D7761726E696E67202E612D50726F70657274792D6C6162656C207B0A202020';
wwv_flow_api.g_varchar2_table(5) := '20636F6C6F723A20233130304630453B0A202020207D0A0A202020202E612D50726F70657274792E69732D7761726E696E67202E69636F6E2D7761726E696E67207B0A20202020636F6C6F723A20234438393734442021696D706F7274616E743B0A2020';
wwv_flow_api.g_varchar2_table(6) := '20207D0A0A202020202E612D50726F70657274792D6C6162656C2C0A202020202E612D50726F70657274792D7365744974656D734865616465722D6865616465722C0A202020202E612D50726F70657274792D756E6974207B0A20202020636F6C6F723A';
wwv_flow_api.g_varchar2_table(7) := '20233130304630453B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D6C6162656C2C0A202020202E612D50726F70657274792D726164696F207B0A20202020636F6C6F723A20726762612831362C2031352C2031342C';
wwv_flow_api.g_varchar2_table(8) := '20302E38293B0A202020207D0A0A202020202E612D50726F70657274792D6669656C64207B0A20202020782D6261636B67726F756E642D636F6C6F723A20234643464246413B0A20202020636F6C6F723A20233130304630453B0A20202020626F726465';
wwv_flow_api.g_varchar2_table(9) := '722D636F6C6F723A20234536453345303B0A202020202D7765626B69742D626F782D736861646F773A20302031707820327078207267626128302C20302C20302C20302E31293B0A202020202020202020202020626F782D736861646F773A2030203170';
wwv_flow_api.g_varchar2_table(10) := '7820327078207267626128302C20302C20302C20302E31293B0A202020207D0A0A202020202E612D50726F70657274792D6669656C643A686F766572207B0A20202020782D6261636B67726F756E642D636F6C6F723A20234646464646463B0A20202020';
wwv_flow_api.g_varchar2_table(11) := '2D7765626B69742D626F782D736861646F773A20302031707820327078207267626128302C20302C20302C20302E31293B0A202020202020202020202020626F782D736861646F773A20302031707820327078207267626128302C20302C20302C20302E';
wwv_flow_api.g_varchar2_table(12) := '31293B0A202020207D0A0A202020202E612D50726F70657274792D6669656C643A666F637573207B0A202020206F75746C696E652D636F6C6F723A20233337374535353B0A20202020782D6261636B67726F756E642D636F6C6F723A2023464646464646';
wwv_flow_api.g_varchar2_table(13) := '3B0A202020202D7765626B69742D626F782D736861646F773A20302031707820327078207267626128302C20302C20302C20302E31293B0A202020202020202020202020626F782D736861646F773A20302031707820327078207267626128302C20302C';
wwv_flow_api.g_varchar2_table(14) := '20302C20302E31293B0A202020206F75746C696E652D6F66667365743A203270783B0A202020206F75746C696E652D77696474683A203270783B0A202020206F75746C696E652D7374796C653A20646F747465643B0A202020207D0A0A202020202E612D';
wwv_flow_api.g_varchar2_table(15) := '50726F70657274792E69732D6572726F722E69732D616374697665202E612D50726F70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D7465787461726561293A666F637573207B0A202020202D7765626B69742D62';
wwv_flow_api.g_varchar2_table(16) := '6F782D736861646F773A20302030203020317078202345333531334320696E7365742C2030203170782032707820726762612835312C2035312C2035312C20302E31293B0A202020202020202020202020626F782D736861646F773A2030203020302031';
wwv_flow_api.g_varchar2_table(17) := '7078202345333531334320696E7365742C2030203170782032707820726762612835312C2035312C2035312C20302E31293B0A202020207D0A0A202020202E612D50726F70657274792E69732D736861646F772E69732D616374697665202E612D50726F';
wwv_flow_api.g_varchar2_table(18) := '70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D7465787461726561293A666F637573207B0A202020202D7765626B69742D626F782D736861646F773A20302030203020317078202345333531334320696E736574';
wwv_flow_api.g_varchar2_table(19) := '2C2030203170782032707820726762612835312C2035312C2035312C20302E31293B0A202020202020202020202020626F782D736861646F773A20302030203020317078202345333531334320696E7365742C2030203170782032707820726762612835';
wwv_flow_api.g_varchar2_table(20) := '312C2035312C2035312C20302E31293B0A202020207D0A0A202020202E612D50726F70657274792E69732D7661726961626C65202E612D49636F6E2E69636F6E2D7661726961626C65207B0A20202020636F6C6F723A20233746424546323B0A20202020';
wwv_flow_api.g_varchar2_table(21) := '7D0A0A202020202E612D50726F70657274792E69732D7661726961626C65202E612D50726F70657274792D6669656C64207B0A202020202D7765626B69742D626F782D736861646F773A203020302030203170782072676261283132372C203139302C20';
wwv_flow_api.g_varchar2_table(22) := '3234322C20302E352920696E7365743B0A202020202020202020202020626F782D736861646F773A203020302030203170782072676261283132372C203139302C203234322C20302E352920696E7365743B0A20202020782D6261636B67726F756E642D';
wwv_flow_api.g_varchar2_table(23) := '636F6C6F723A20236633663966653B0A202020207D0A0A202020202E612D50726F70657274792E69732D7761726E696E67202E612D50726F70657274792D6669656C642D2D74657874617265613A666F637573207B0A20202020626F726465722D636F6C';
wwv_flow_api.g_varchar2_table(24) := '6F723A20234641434436322021696D706F7274616E743B0A202020207D0A0A202020202E612D50726F70657274792E69732D6572726F72202E612D50726F70657274792D6669656C642D2D74657874617265613A666F637573207B0A20202020626F7264';
wwv_flow_api.g_varchar2_table(25) := '65722D636F6C6F723A20234533353133432021696D706F7274616E743B0A202020207D0A0A202020202E612D50726F70657274792D627574746F6E436F6E7461696E6572202E612D427574746F6E207B0A202020206261636B67726F756E642D636F6C6F';
wwv_flow_api.g_varchar2_table(26) := '723A20234646464646463B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D202B206C6162656C3A6265666F72652C0A202020202E612D50726F70657274792D72';
wwv_flow_api.g_varchar2_table(27) := '6164696F2D696E7075745B747970653D22726164696F225D202B206C6162656C3A6265666F7265207B0A202020206261636B67726F756E642D636F6C6F723A20234646464646463B0A20202020626F726465722D636F6C6F723A20234446444344383B0A';
wwv_flow_api.g_varchar2_table(28) := '202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A666F637573202B206C6162656C3A6265666F72652C0A202020202E612D50726F70657274792D636865636B626F';
wwv_flow_api.g_varchar2_table(29) := '782D696E7075745B747970653D22636865636B626F78225D3A696E64657465726D696E617465202B206C6162656C3A6265666F72652C0A202020202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D3A666F63';
wwv_flow_api.g_varchar2_table(30) := '7573202B206C6162656C3A6265666F72652C0A202020202E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D3A696E64657465726D696E617465202B206C6162656C3A6265666F7265207B0A20202020626F7264';
wwv_flow_api.g_varchar2_table(31) := '65722D636F6C6F723A20233337374535353B0A202020202D7765626B69742D626F782D736861646F773A207267626128302C20302C20302C20302E3129203020317078203170783B0A202020202020202020202020626F782D736861646F773A20726762';
wwv_flow_api.g_varchar2_table(32) := '6128302C20302C20302C20302E3129203020317078203170783B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A666F6375733A636865636B6564202B206C61';
wwv_flow_api.g_varchar2_table(33) := '62656C3A6265666F72652C0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A666F6375733A696E64657465726D696E617465202B206C6162656C3A6265666F72652C0A20202020';
wwv_flow_api.g_varchar2_table(34) := '2E612D50726F70657274792D726164696F2D696E7075745B747970653D22726164696F225D3A666F6375733A636865636B6564202B206C6162656C3A6265666F72652C0A202020202E612D50726F70657274792D726164696F2D696E7075745B74797065';
wwv_flow_api.g_varchar2_table(35) := '3D22726164696F225D3A666F6375733A696E64657465726D696E617465202B206C6162656C3A6265666F7265207B0A20202020626F726465722D636F6C6F723A20233337374535353B0A202020206261636B67726F756E642D636F6C6F723A2023333737';
wwv_flow_api.g_varchar2_table(36) := '4535353B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A696E64657465726D696E617465202B206C6162656C3A6265666F72652C202E612D50726F70657274';
wwv_flow_api.g_varchar2_table(37) := '792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A636865636B6564202B206C6162656C3A6265666F7265207B0A20202020626F726465722D636F6C6F723A20233637363035423B0A202020206261636B67726F756E64';
wwv_flow_api.g_varchar2_table(38) := '2D636F6C6F723A20233637363035423B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A696E64657465726D696E617465202B206C6162656C3A616674657220';
wwv_flow_api.g_varchar2_table(39) := '7B0A202020206261636B67726F756E642D636F6C6F723A20234643464246413B0A202020207D0A0A202020202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D22636865636B626F78225D3A636865636B6564202B206C61';
wwv_flow_api.g_varchar2_table(40) := '62656C3A6166746572207B0A202020206261636B67726F756E642D696D6167653A2075726C28222E2E2F6173736574732F636865636B626F782D636865636B65642E73766722293B0A202020207D0A0A202020202E612D50726F70657274792D72616469';
wwv_flow_api.g_varchar2_table(41) := '6F2D696E7075745B747970653D22726164696F225D3A636865636B6564202B206C6162656C3A6265666F7265207B0A20202020626F726465722D636F6C6F723A20726762612831362C2031352C2031342C20302E36293B0A202020206261636B67726F75';
wwv_flow_api.g_varchar2_table(42) := '6E642D636F6C6F723A20726762612831362C2031352C2031342C20302E36293B0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075';
wwv_flow_api.g_varchar2_table(43) := '743A636865636B6564202B206C6162656C207B0A202020206261636B67726F756E642D636F6C6F723A20234446444344383B0A202020202D7765626B69742D626F782D736861646F773A20302030203020317078207267626128302C20302C20302C2030';
wwv_flow_api.g_varchar2_table(44) := '2E312920696E7365742C20302032707820317078207267626128302C20302C20302C20302E30352920696E7365743B0A202020202020202020202020626F782D736861646F773A20302030203020317078207267626128302C20302C20302C20302E3129';
wwv_flow_api.g_varchar2_table(45) := '20696E7365742C20302032707820317078207267626128302C20302C20302C20302E30352920696E7365743B0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274';
wwv_flow_api.g_varchar2_table(46) := '792D726164696F2D696E7075743A666F637573202B206C6162656C207B0A20202020626F726465722D636F6C6F723A20302031707820327078207267626128302C20302C20302C20302E31292021696D706F7274616E743B0A202020206261636B67726F';
wwv_flow_api.g_varchar2_table(47) := '756E642D636F6C6F723A20234446444344383B0A202020202D7765626B69742D626F782D736861646F773A2030203020302031707820302031707820327078207267626128302C20302C20302C20302E312920696E7365742C2030203170782032707820';
wwv_flow_api.g_varchar2_table(48) := '7267626128302C20302C20302C20302E31293B0A202020202020202020202020626F782D736861646F773A2030203020302031707820302031707820327078207267626128302C20302C20302C20302E312920696E7365742C2030203170782032707820';
wwv_flow_api.g_varchar2_table(49) := '7267626128302C20302C20302C20302E31293B0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A6E6F74283A636865636B65';
wwv_flow_api.g_varchar2_table(50) := '64293A686F766572202B206C6162656C207B0A202020202D7765626B69742D626F782D736861646F773A20302030203020317078207267626128302C20302C20302C20302E31352920696E7365742C20302031707820327078207267626128302C20302C';
wwv_flow_api.g_varchar2_table(51) := '20302C20302E31293B0A202020202020202020202020626F782D736861646F773A20302030203020317078207267626128302C20302C20302C20302E31352920696E7365742C20302031707820327078207267626128302C20302C20302C20302E31293B';
wwv_flow_api.g_varchar2_table(52) := '0A202020207D0A0A202020202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A686F7665723A616374697665202B206C6162656C207B0A202020202D7765';
wwv_flow_api.g_varchar2_table(53) := '626B69742D626F782D736861646F773A2030203020302031707820302031707820327078207267626128302C20302C20302C20302E312920696E7365742C20302031707820327078207267626128302C20302C20302C20302E31293B0A20202020202020';
wwv_flow_api.g_varchar2_table(54) := '2020202020626F782D736861646F773A2030203020302031707820302031707820327078207267626128302C20302C20302C20302E312920696E7365742C20302031707820327078207267626128302C20302C20302C20302E31293B0A20202020626163';
wwv_flow_api.g_varchar2_table(55) := '6B67726F756E642D636F6C6F723A20234536453345303B0A202020207D0A0A202020202E612D50726F70657274792D636F6C6F7250726576696577207B0A202020202D7765626B69742D626F782D736861646F773A203020302030203170782072676261';
wwv_flow_api.g_varchar2_table(56) := '28302C20302C20302C20302E312920696E7365743B0A202020202020202020202020626F782D736861646F773A20302030203020317078207267626128302C20302C20302C20302E312920696E7365743B0A202020207D0A0A202020202E612D50726F70';
wwv_flow_api.g_varchar2_table(57) := '657274792E69732D6368616E676564202E612D50726F70657274792D6C6162656C436F6E7461696E65723A6265666F7265207B0A202020206261636B67726F756E642D636F6C6F723A20233337374535353B0A202020207D0A0A202020202E612D50726F';
wwv_flow_api.g_varchar2_table(58) := '7065727479456469746F72207B0A20202020782D6261636B67726F756E642D636F6C6F723A20234536453345303B0A202020207D0A0A202020202E75692D6469616C6F67202E612D50726F7065727479456469746F72207B0A20202020782D6261636B67';
wwv_flow_api.g_varchar2_table(59) := '726F756E642D636F6C6F723A207472616E73706172656E743B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D70726F706572747947726F75702C0A202020202E612D50726F7065727479456469746F722D70726F7065727479';
wwv_flow_api.g_varchar2_table(60) := '47726F75702D6865616465722C0A202020202E612D50726F7065727479456469746F722D70726F706572747947726F75702D626F6479207B0A20202020626F726465722D636F6C6F723A20234536453345303B0A202020207D0A0A202020202E612D5072';
wwv_flow_api.g_varchar2_table(61) := '6F7065727479456469746F722D70726F706572747947726F7570207B0A20202020782D6261636B67726F756E642D636F6C6F723A20234637463546333B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D70726F706572747947';
wwv_flow_api.g_varchar2_table(62) := '726F75703A666F6375732D77697468696E2C202E612D50726F7065727479456469746F722D70726F706572747947726F75702E6861732D666F637573207B0A20202020782D6261636B67726F756E642D636F6C6F723A2072676261283232342C20323435';
wwv_flow_api.g_varchar2_table(63) := '2C203231382C20302E33293B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572202E612D49636F6E207B0A20202020636F6C6F723A20234643464246413B0A20202020626163';
wwv_flow_api.g_varchar2_table(64) := '6B67726F756E642D636F6C6F723A20234138413239423B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D70726F706572747947726F75702D7469746C65207B0A20202020636F6C6F723A20233130304630453B0A202020207D';
wwv_flow_api.g_varchar2_table(65) := '0A0A202020202E612D50726F7065727479456469746F722D70726F706572747947726F75702D626F6479202E612D50726F7065727479207B0A20202020626F726465722D636F6C6F723A20234536453345303B0A202020207D0A0A202020202E612D5072';
wwv_flow_api.g_varchar2_table(66) := '6F7065727479456469746F722D70726F706572747947726F75702D6865616465722E69732D666F6375736564207B0A202020202D7765626B69742D626F782D736861646F773A20726762612835312C2035312C2035312C20302E31293B0A202020202020';
wwv_flow_api.g_varchar2_table(67) := '202020202020626F782D736861646F773A20726762612835312C2035312C2035312C20302E31293B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465722E69732D666F63757365';
wwv_flow_api.g_varchar2_table(68) := '64202E612D49636F6E207B0A20202020782D6261636B67726F756E642D636F6C6F723A20233337374535353B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D6D657373616765207B0A20202020636F6C6F723A207267626128';
wwv_flow_api.g_varchar2_table(69) := '31362C2031352C2031342C20302E36293B0A202020207D0A0A202020202E612D50726F7065727479456469746F722D6D65737361676554657874207B0A20202020636F6C6F723A20726762612831362C2031352C2031342C20302E38293B0A202020207D';
wwv_flow_api.g_varchar2_table(70) := '0A0A202020202E612D50726F70657274792D686967686C69676874207B0A202020206261636B67726F756E642D636F6C6F723A20234645454443333B0A202020202D7765626B69742D626F782D736861646F773A20302031707820317078202D31707820';
wwv_flow_api.g_varchar2_table(71) := '726762612835312C2035312C2035312C20302E31293B0A202020202020202020202020626F782D736861646F773A20302031707820317078202D31707820726762612835312C2035312C2035312C20302E31293B0A202020207D0A0A202020202E612D50';
wwv_flow_api.g_varchar2_table(72) := '726F70657274792D6E6F74466F756E64207B0A20202020636F6C6F723A20726762612831362C2031352C2031342C20302E36293B0A202020207D0A0A202020202E612D50726F706572747947726F75702D6974656D207B0A20202020626F726465722D74';
wwv_flow_api.g_varchar2_table(73) := '6F702D636F6C6F723A20234342433542463B0A202020207D0A7D';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(776882772926146573)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_file_name=>'css/style.less'
,p_mime_type=>'text/plain'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C642D2D73656C6563747B6261636B67726F756E642D696D6167653A75726C282E2E2F6173736574732F73656C6563742D6172726F772E737667297D2E75742D5072';
wwv_flow_api.g_varchar2_table(2) := '6F7065727479456469746F72202E612D50726F70657274792E69732D6572726F72202E612D50726F70657274792D6C6162656C7B636F6C6F723A233130306630657D2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D';
wwv_flow_api.g_varchar2_table(3) := '6572726F72202E612D50726F70657274792D6669656C643A6E6F74283A666F637573297B636F6C6F723A236337343633347D2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6572726F72202E69636F6E2D6572726F';
wwv_flow_api.g_varchar2_table(4) := '727B636F6C6F723A2363373436333421696D706F7274616E747D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6C6162656C2C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D736574497465';
wwv_flow_api.g_varchar2_table(5) := '6D734865616465722D6865616465722C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D756E69742C2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D7761726E696E67202E612D50726F';
wwv_flow_api.g_varchar2_table(6) := '70657274792D6C6162656C7B636F6C6F723A233130306630657D2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D7761726E696E67202E69636F6E2D7761726E696E677B636F6C6F723A2364383937346421696D706F';
wwv_flow_api.g_varchar2_table(7) := '7274616E747D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D6C6162656C2C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F7B636F6C6F723A7267626128';
wwv_flow_api.g_varchar2_table(8) := '31362C31352C31342C2E38297D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C647B782D6261636B67726F756E642D636F6C6F723A236663666266613B636F6C6F723A233130306630653B626F726465722D636F';
wwv_flow_api.g_varchar2_table(9) := '6C6F723A236536653365303B2D7765626B69742D626F782D736861646F773A302031707820327078207267626128302C302C302C2E31293B626F782D736861646F773A302031707820327078207267626128302C302C302C2E31297D2E75742D50726F70';
wwv_flow_api.g_varchar2_table(10) := '65727479456469746F72202E612D50726F70657274792D6669656C643A686F7665727B782D6261636B67726F756E642D636F6C6F723A236666663B2D7765626B69742D626F782D736861646F773A302031707820327078207267626128302C302C302C2E';
wwv_flow_api.g_varchar2_table(11) := '31293B626F782D736861646F773A302031707820327078207267626128302C302C302C2E31297D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6669656C643A666F6375737B6F75746C696E652D636F6C6F723A23333737';
wwv_flow_api.g_varchar2_table(12) := '6535353B782D6261636B67726F756E642D636F6C6F723A236666663B2D7765626B69742D626F782D736861646F773A302031707820327078207267626128302C302C302C2E31293B626F782D736861646F773A302031707820327078207267626128302C';
wwv_flow_api.g_varchar2_table(13) := '302C302C2E31293B6F75746C696E652D6F66667365743A3270783B6F75746C696E652D77696474683A3270783B6F75746C696E652D7374796C653A646F747465647D2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D';
wwv_flow_api.g_varchar2_table(14) := '6572726F722E69732D616374697665202E612D50726F70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D7465787461726561293A666F6375732C2E75742D50726F7065727479456469746F72202E612D50726F7065';
wwv_flow_api.g_varchar2_table(15) := '7274792E69732D736861646F772E69732D616374697665202E612D50726F70657274792D6669656C643A6E6F74282E612D50726F70657274792D6669656C642D2D7465787461726561293A666F6375737B2D7765626B69742D626F782D736861646F773A';
wwv_flow_api.g_varchar2_table(16) := '302030203020317078202365333531336320696E7365742C30203170782032707820726762612835312C35312C35312C2E31293B626F782D736861646F773A302030203020317078202365333531336320696E7365742C30203170782032707820726762';
wwv_flow_api.g_varchar2_table(17) := '612835312C35312C35312C2E31297D2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D7661726961626C65202E612D49636F6E2E69636F6E2D7661726961626C657B636F6C6F723A233766626566327D2E75742D5072';
wwv_flow_api.g_varchar2_table(18) := '6F7065727479456469746F72202E612D50726F70657274792E69732D7661726961626C65202E612D50726F70657274792D6669656C647B2D7765626B69742D626F782D736861646F773A3020302030203170782072676261283132372C3139302C323432';
wwv_flow_api.g_varchar2_table(19) := '2C2E352920696E7365743B626F782D736861646F773A3020302030203170782072676261283132372C3139302C3234322C2E352920696E7365743B782D6261636B67726F756E642D636F6C6F723A236633663966657D2E75742D50726F70657274794564';
wwv_flow_api.g_varchar2_table(20) := '69746F72202E612D50726F70657274792E69732D7761726E696E67202E612D50726F70657274792D6669656C642D2D74657874617265613A666F6375737B626F726465722D636F6C6F723A2366616364363221696D706F7274616E747D2E75742D50726F';
wwv_flow_api.g_varchar2_table(21) := '7065727479456469746F72202E612D50726F70657274792E69732D6572726F72202E612D50726F70657274792D6669656C642D2D74657874617265613A666F6375737B626F726465722D636F6C6F723A2365333531336321696D706F7274616E747D2E75';
wwv_flow_api.g_varchar2_table(22) := '742D50726F7065727479456469746F72202E612D50726F70657274792D627574746F6E436F6E7461696E6572202E612D427574746F6E7B6261636B67726F756E642D636F6C6F723A236666667D2E75742D50726F7065727479456469746F72202E612D50';
wwv_flow_api.g_varchar2_table(23) := '726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D2B6C6162656C3A6265666F72652C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D72';
wwv_flow_api.g_varchar2_table(24) := '6164696F5D2B6C6162656C3A6265666F72657B6261636B67726F756E642D636F6C6F723A236666663B626F726465722D636F6C6F723A236466646364387D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F';
wwv_flow_api.g_varchar2_table(25) := '782D696E7075745B747970653D636865636B626F785D3A666F6375732B6C6162656C3A6265666F72652C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F';
wwv_flow_api.g_varchar2_table(26) := '785D3A696E64657465726D696E6174652B6C6162656C3A6265666F72652C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F5D3A666F6375732B6C6162656C3A626566';
wwv_flow_api.g_varchar2_table(27) := '6F72652C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F5D3A696E64657465726D696E6174652B6C6162656C3A6265666F72657B626F726465722D636F6C6F723A23';
wwv_flow_api.g_varchar2_table(28) := '3337376535353B2D7765626B69742D626F782D736861646F773A7267626128302C302C302C2E3129203020317078203170783B626F782D736861646F773A7267626128302C302C302C2E3129203020317078203170787D2E75742D50726F706572747945';
wwv_flow_api.g_varchar2_table(29) := '6469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D3A666F6375733A636865636B65642B6C6162656C3A6265666F72652C2E75742D50726F7065727479456469746F72202E612D50726F';
wwv_flow_api.g_varchar2_table(30) := '70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D3A666F6375733A696E64657465726D696E6174652B6C6162656C3A6265666F72652C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D';
wwv_flow_api.g_varchar2_table(31) := '726164696F2D696E7075745B747970653D726164696F5D3A666F6375733A636865636B65642B6C6162656C3A6265666F72652C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D72';
wwv_flow_api.g_varchar2_table(32) := '6164696F5D3A666F6375733A696E64657465726D696E6174652B6C6162656C3A6265666F72657B626F726465722D636F6C6F723A233337376535353B6261636B67726F756E642D636F6C6F723A233337376535357D2E75742D50726F7065727479456469';
wwv_flow_api.g_varchar2_table(33) := '746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D3A636865636B65642B6C6162656C3A6265666F72652C2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6368';
wwv_flow_api.g_varchar2_table(34) := '65636B626F782D696E7075745B747970653D636865636B626F785D3A696E64657465726D696E6174652B6C6162656C3A6265666F72657B626F726465722D636F6C6F723A233637363035623B6261636B67726F756E642D636F6C6F723A23363736303562';
wwv_flow_api.g_varchar2_table(35) := '7D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D3A696E64657465726D696E6174652B6C6162656C3A61667465727B6261636B67726F756E642D63';
wwv_flow_api.g_varchar2_table(36) := '6F6C6F723A236663666266617D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636865636B626F782D696E7075745B747970653D636865636B626F785D3A636865636B65642B6C6162656C3A61667465727B6261636B6772';
wwv_flow_api.g_varchar2_table(37) := '6F756E642D696D6167653A75726C282E2E2F6173736574732F636865636B626F782D636865636B65642E737667297D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F2D696E7075745B747970653D726164696F';
wwv_flow_api.g_varchar2_table(38) := '5D3A636865636B65642B6C6162656C3A6265666F72657B626F726465722D636F6C6F723A726762612831362C31352C31342C2E36293B6261636B67726F756E642D636F6C6F723A726762612831362C31352C31342C2E36297D2E75742D50726F70657274';
wwv_flow_api.g_varchar2_table(39) := '79456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A636865636B65642B6C6162656C7B6261636B67726F756E642D636F6C6F723A236466';
wwv_flow_api.g_varchar2_table(40) := '646364383B2D7765626B69742D626F782D736861646F773A302030203020317078207267626128302C302C302C2E312920696E7365742C302032707820317078207267626128302C302C302C2E30352920696E7365743B626F782D736861646F773A3020';
wwv_flow_api.g_varchar2_table(41) := '30203020317078207267626128302C302C302C2E312920696E7365742C302032707820317078207267626128302C302C302C2E30352920696E7365747D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F';
wwv_flow_api.g_varchar2_table(42) := '75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A666F6375732B6C6162656C7B626F726465722D636F6C6F723A302031707820327078207267626128302C302C302C2E312921696D706F7274616E743B6261';
wwv_flow_api.g_varchar2_table(43) := '636B67726F756E642D636F6C6F723A236466646364383B2D7765626B69742D626F782D736861646F773A30203020302031707820302031707820327078207267626128302C302C302C2E312920696E7365742C302031707820327078207267626128302C';
wwv_flow_api.g_varchar2_table(44) := '302C302C2E31293B626F782D736861646F773A30203020302031707820302031707820327078207267626128302C302C302C2E312920696E7365742C302031707820327078207267626128302C302C302C2E31297D2E75742D50726F7065727479456469';
wwv_flow_api.g_varchar2_table(45) := '746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164696F2D696E7075743A6E6F74283A636865636B6564293A686F7665722B6C6162656C7B2D7765626B69742D626F782D';
wwv_flow_api.g_varchar2_table(46) := '736861646F773A302030203020317078207267626128302C302C302C2E31352920696E7365742C302031707820327078207267626128302C302C302C2E31293B626F782D736861646F773A302030203020317078207267626128302C302C302C2E313529';
wwv_flow_api.g_varchar2_table(47) := '20696E7365742C302031707820327078207267626128302C302C302C2E31297D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D726164696F47726F75702D2D627574746F6E536574202E612D50726F70657274792D726164';
wwv_flow_api.g_varchar2_table(48) := '696F2D696E7075743A686F7665723A6163746976652B6C6162656C7B2D7765626B69742D626F782D736861646F773A30203020302031707820302031707820327078207267626128302C302C302C2E312920696E7365742C302031707820327078207267';
wwv_flow_api.g_varchar2_table(49) := '626128302C302C302C2E31293B626F782D736861646F773A30203020302031707820302031707820327078207267626128302C302C302C2E312920696E7365742C302031707820327078207267626128302C302C302C2E31293B6261636B67726F756E64';
wwv_flow_api.g_varchar2_table(50) := '2D636F6C6F723A236536653365307D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D636F6C6F72507265766965777B2D7765626B69742D626F782D736861646F773A302030203020317078207267626128302C302C302C2E';
wwv_flow_api.g_varchar2_table(51) := '312920696E7365743B626F782D736861646F773A302030203020317078207267626128302C302C302C2E312920696E7365747D2E75742D50726F7065727479456469746F72202E612D50726F70657274792E69732D6368616E676564202E612D50726F70';
wwv_flow_api.g_varchar2_table(52) := '657274792D6C6162656C436F6E7461696E65723A6265666F72657B6261636B67726F756E642D636F6C6F723A233337376535357D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F727B782D6261636B67726F756E';
wwv_flow_api.g_varchar2_table(53) := '642D636F6C6F723A236536653365307D2E75742D50726F7065727479456469746F72202E75692D6469616C6F67202E612D50726F7065727479456469746F727B782D6261636B67726F756E642D636F6C6F723A7472616E73706172656E747D2E75742D50';
wwv_flow_api.g_varchar2_table(54) := '726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702C2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D626F64';
wwv_flow_api.g_varchar2_table(55) := '792C2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465727B626F726465722D636F6C6F723A236536653365307D2E75742D50726F7065727479456469746F7220';
wwv_flow_api.g_varchar2_table(56) := '2E612D50726F7065727479456469746F722D70726F706572747947726F75707B782D6261636B67726F756E642D636F6C6F723A236637663566337D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F70';
wwv_flow_api.g_varchar2_table(57) := '6572747947726F75702E6861732D666F6375732C2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75703A666F6375732D77697468696E7B782D6261636B67726F756E642D636F6C';
wwv_flow_api.g_varchar2_table(58) := '6F723A72676261283232342C3234352C3231382C2E33297D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D686561646572202E612D49636F6E7B636F6C6F723A23666366';
wwv_flow_api.g_varchar2_table(59) := '6266613B6261636B67726F756E642D636F6C6F723A236138613239627D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D7469746C657B636F6C6F723A233130306630657D';
wwv_flow_api.g_varchar2_table(60) := '2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D626F6479202E612D50726F70657274797B626F726465722D636F6C6F723A236536653365307D2E75742D50726F70657274';
wwv_flow_api.g_varchar2_table(61) := '79456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465722E69732D666F63757365647B2D7765626B69742D626F782D736861646F773A726762612835312C35312C35312C2E31293B626F782D73';
wwv_flow_api.g_varchar2_table(62) := '6861646F773A726762612835312C35312C35312C2E31297D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D70726F706572747947726F75702D6865616465722E69732D666F6375736564202E612D49636F6E';
wwv_flow_api.g_varchar2_table(63) := '7B782D6261636B67726F756E642D636F6C6F723A233337376535357D2E75742D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D6D6573736167657B636F6C6F723A726762612831362C31352C31342C2E36297D2E7574';
wwv_flow_api.g_varchar2_table(64) := '2D50726F7065727479456469746F72202E612D50726F7065727479456469746F722D6D657373616765546578747B636F6C6F723A726762612831362C31352C31342C2E38297D2E75742D50726F7065727479456469746F72202E612D50726F7065727479';
wwv_flow_api.g_varchar2_table(65) := '2D686967686C696768747B6261636B67726F756E642D636F6C6F723A236665656463333B2D7765626B69742D626F782D736861646F773A302031707820317078202D31707820726762612835312C35312C35312C2E31293B626F782D736861646F773A30';
wwv_flow_api.g_varchar2_table(66) := '2031707820317078202D31707820726762612835312C35312C35312C2E31297D2E75742D50726F7065727479456469746F72202E612D50726F70657274792D6E6F74466F756E647B636F6C6F723A726762612831362C31352C31342C2E36297D2E75742D';
wwv_flow_api.g_varchar2_table(67) := '50726F7065727479456469746F72202E612D50726F706572747947726F75702D6974656D7B626F726465722D746F702D636F6C6F723A236362633562667D0A2F2A2320736F757263654D617070696E6755524C3D7374796C652E6373732E6D61702A2F';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(776883123310146574)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_file_name=>'css/style.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '77696E646F772E617065782E7468656D65343264656D6F203D20617065782E7468656D65343264656D6F207C7C207B7D3B0A0A617065782E7468656D65343264656D6F2E696E69745072657669657754656D706C6174654F7074696F6E73203D2066756E';
wwv_flow_api.g_varchar2_table(2) := '6374696F6E2873656C6563746F722C206461746129207B0A202020200A202020206C657420656C656D656E74243B0A202020206C6574207472793124203D202428602E6C746F247B646174612E636F6D706F6E656E7449647D5F3160293B0A202020206C';
wwv_flow_api.g_varchar2_table(3) := '6574207472793024203D202428602E6C746F247B646174612E636F6D706F6E656E7449647D5F3060293B0A2020202069662874727931242E6C656E677468297B0A2020202020202020656C656D656E7424203D2074727931243B0A202020207D20656C73';
wwv_flow_api.g_varchar2_table(4) := '65207B0A2020202020202020656C656D656E7424203D2074727930243B0A202020207D0A0A20202020617065782E74656D706C6174654F7074696F6E7348656C7065722E61646447656E6572616C50726F70657274795479706528293B0A0A2020202063';
wwv_flow_api.g_varchar2_table(5) := '6F6E73742070726F70657274696573203D20617065782E74656D706C6174654F7074696F6E7348656C7065722E67657450726F70657274696573280A2020202020202020646174612C0A202020202020202028646174612E63757272656E7456616C7565';
wwv_flow_api.g_varchar2_table(6) := '73207C7C202727292E73706C697428273A27290A20202020293B0A0A20202020242873656C6563746F72292E70726F7065727479456469746F72287B0A2020202020202020646174613A207B0A20202020202020202020202070726F7065727479536574';
wwv_flow_api.g_varchar2_table(7) := '3A205B7B0A20202020202020202020202020202020646973706C617947726F757049643A2022636F6D6D6F6E222C0A20202020202020202020202020202020646973706C617947726F75705469746C653A2027436F6D6D6F6E272C0A2020202020202020';
wwv_flow_api.g_varchar2_table(8) := '202020202020202070726F706572746965733A2070726F706572746965732E636F6D6D6F6E0A2020202020202020202020207D2C207B0A20202020202020202020202020202020646973706C617947726F757049643A2022616476616E636564222C0A20';
wwv_flow_api.g_varchar2_table(9) := '202020202020202020202020202020646973706C617947726F75705469746C653A2027416476616E636564272C0A2020202020202020202020202020202070726F706572746965733A2070726F706572746965732E616476616E6365640A202020202020';
wwv_flow_api.g_varchar2_table(10) := '2020202020207D5D0A20202020202020207D2C0A20202020202020206368616E67653A2066756E6374696F6E2028704576656E742C20704461746129207B0A20202020202020202020202076617220676574436C6173736573203D2066756E6374696F6E';
wwv_flow_api.g_varchar2_table(11) := '202876616C756529207B0A202020202020202020202020202020207661722068617344656661756C74203D2066616C73653B0A2020202020202020202020202020202076617220636C6173736573203D202876616C7565207C7C202222292E73706C6974';
wwv_flow_api.g_varchar2_table(12) := '28223A22292E66696C7465722866756E6374696F6E2028636C6173734E616D6529207B0A202020202020202020202020202020202020202069662028636C6173734E616D65203D3D3D20222344454641554C54232229207B0A2020202020202020202020';
wwv_flow_api.g_varchar2_table(13) := '2020202020202020202020202068617344656661756C74203D20747275653B0A20202020202020202020202020202020202020202020202072657475726E2066616C73653B0A20202020202020202020202020202020202020207D0A2020202020202020';
wwv_flow_api.g_varchar2_table(14) := '20202020202020202020202072657475726E20747275653B0A202020202020202020202020202020207D292E6A6F696E28222022293B0A202020202020202020202020202020206966202868617344656661756C7429207B0A2020202020202020202020';
wwv_flow_api.g_varchar2_table(15) := '202020202020202020636C6173736573202B3D20222022202B20646174612E64656661756C7456616C7565732E6A6F696E28222022293B0A202020202020202020202020202020207D0A2020202020202020202020202020202072657475726E20636C61';
wwv_flow_api.g_varchar2_table(16) := '737365733B0A2020202020202020202020207D3B0A202020202020202020202020766172206170706C795374617475735374796C696E67203D2066756E6374696F6E202829207B0A20202020202020202020202020202020766172206170706C79537461';
wwv_flow_api.g_varchar2_table(17) := '747573546F50726F7065727479203D2066756E6374696F6E202870726F70657274792429207B0A20202020202020202020202020202020202020206966202870446174612E70726F70657274792E76616C7565203D3D3D2070446174612E70726F706572';
wwv_flow_api.g_varchar2_table(18) := '74792E6F726967696E616C56616C756529207B0A20202020202020202020202020202020202020202020202070726F7065727479242E72656D6F7665436C617373282269732D6368616E67656422292E72656D6F7665436C61737328226861732D776172';
wwv_flow_api.g_varchar2_table(19) := '6E696E6722293B0A20202020202020202020202020202020202020207D20656C7365207B0A20202020202020202020202020202020202020202020202070726F7065727479242E616464436C617373282269732D6368616E67656422293B0A2020202020';
wwv_flow_api.g_varchar2_table(20) := '202020202020202020202020202020202020206966202870446174612E70726F70657274792E72657175697265735F72656C6F616429207B0A2020202020202020202020202020202020202020202020202020202070726F7065727479242E616464436C';
wwv_flow_api.g_varchar2_table(21) := '61737328226861732D7761726E696E6722293B0A2020202020202020202020202020202020202020202020207D0A20202020202020202020202020202020202020207D0A202020202020202020202020202020207D3B0A20202020202020202020202020';
wwv_flow_api.g_varchar2_table(22) := '2020206170706C79537461747573546F50726F70657274792870446174612E70726F706572747924293B0A2020202020202020202020207D3B0A202020202020202020202020766172206E6577436C6173736573203D20676574436C6173736573287044';
wwv_flow_api.g_varchar2_table(23) := '6174612E70726F70657274792E76616C7565293B0A202020202020202020202020766172206F6C64436C6173736573203D20676574436C61737365732870446174612E70726576696F757356616C7565293B0A2020202020202020202020206170706C79';
wwv_flow_api.g_varchar2_table(24) := '5374617475735374796C696E6728293B0A202020202020202020202020656C656D656E74242E72656D6F7665436C617373286F6C64436C6173736573293B0A202020202020202020202020656C656D656E74242E616464436C617373286E6577436C6173';
wwv_flow_api.g_varchar2_table(25) := '736573293B0A20202020202020207D0A202020207D293B0A0A7D3B0A';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(776883506609146574)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_file_name=>'js/script.js'
,p_mime_type=>'application/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '7B2276657273696F6E223A332C22736F7572636573223A5B227363726970742E6A73225D2C226E616D6573223A5B2277696E646F77222C2261706578222C227468656D65343264656D6F222C22696E69745072657669657754656D706C6174654F707469';
wwv_flow_api.g_varchar2_table(2) := '6F6E73222C2273656C6563746F72222C2264617461222C22656C656D656E7424222C227472793124222C2224222C22636F6D706F6E656E744964222C227472793024222C226C656E677468222C2274656D706C6174654F7074696F6E7348656C70657222';
wwv_flow_api.g_varchar2_table(3) := '2C2261646447656E6572616C50726F706572747954797065222C2270726F70657274696573222C2267657450726F70657274696573222C2263757272656E7456616C756573222C2273706C6974222C2270726F7065727479456469746F72222C2270726F';
wwv_flow_api.g_varchar2_table(4) := '7065727479536574222C22646973706C617947726F75704964222C22646973706C617947726F75705469746C65222C22636F6D6D6F6E222C22616476616E636564222C226368616E6765222C22704576656E74222C227044617461222C2270726F706572';
wwv_flow_api.g_varchar2_table(5) := '747924222C22676574436C6173736573222C2276616C7565222C2268617344656661756C74222C22636C6173736573222C2266696C746572222C22636C6173734E616D65222C226A6F696E222C2264656661756C7456616C756573222C226E6577436C61';
wwv_flow_api.g_varchar2_table(6) := '73736573222C2270726F7065727479222C226F6C64436C6173736573222C2270726576696F757356616C7565222C226F726967696E616C56616C7565222C2272656D6F7665436C617373222C22616464436C617373222C2272657175697265735F72656C';
wwv_flow_api.g_varchar2_table(7) := '6F6164225D2C226D617070696E6773223A2241414141412C4F41414F432C4B41414B432C59414163442C4B41414B432C614141652C4741453943442C4B41414B432C59414159432C3242414136422C53414153432C45414155432C47414537442C494141';
wwv_flow_api.g_varchar2_table(8) := '49432C45414341432C45414151432C454141452C4F41414F482C4541414B492C694241437442432C45414151462C454141452C4F41414F482C4541414B492C694241457442482C45414444432C4541414D492C4F41434D4A2C45414541472C4541476654';
wwv_flow_api.g_varchar2_table(9) := '2C4B41414B572C734241417342432C7942414533422C4D41414D432C45414161622C4B41414B572C734241417342472C6341433143562C47414343412C4541414B572C65414169422C49414149432C4D41414D2C4D41477243542C454141454A2C474141';
wwv_flow_api.g_varchar2_table(10) := '55632C654141652C4341437642622C4B41414D2C43414346632C594141612C434141432C43414356432C65414167422C5341436842432C6B4241416D422C5341436E42502C57414159412C45414157512C51414378422C43414343462C65414167422C57';
wwv_flow_api.g_varchar2_table(11) := '41436842432C6B4241416D422C5741436E42502C57414159412C45414157532C5941472F42432C4F4141512C53414155432C45414151432C47414374422C4941653043432C4541667443432C454141612C53414155432C47414376422C49414149432C47';
wwv_flow_api.g_varchar2_table(12) := '4141612C45414362432C47414157462C474141532C494141495A2C4D41414D2C4B41414B652C5141414F2C53414155432C47414370442C4D41416B422C63414164412C49414341482C474141612C4741434E2C4D41475A492C4B41414B2C4B4149522C4F';
wwv_flow_api.g_varchar2_table(13) := '4148494A2C49414341432C474141572C4941414D31422C4541414B38422C63414163442C4B41414B2C4D41457443482C474165504B2C45414161522C45414157462C4541414D572C53414153522C4F41437643532C45414161562C45414157462C454141';
wwv_flow_api.g_varchar2_table(14) := '4D612C654162515A2C4541556842442C4541414D432C5541547042442C4541414D572C53414153522C51414155482C4541414D572C53414153472C6341437843622C45414155632C594141592C63414163412C594141592C674241456844642C45414155';
wwv_flow_api.g_varchar2_table(15) := '652C534141532C6341436668422C4541414D572C534141534D2C694241436668422C45414155652C534141532C674241536E4370432C454141536D432C59414159482C474143724268432C454141536F432C534141534E222C2266696C65223A22736372';
wwv_flow_api.g_varchar2_table(16) := '6970742E6A73227D';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(776883900720146574)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_file_name=>'js/script.js.map'
,p_mime_type=>'application/json'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '77696E646F772E617065782E7468656D65343264656D6F3D617065782E7468656D65343264656D6F7C7C7B7D2C617065782E7468656D65343264656D6F2E696E69745072657669657754656D706C6174654F7074696F6E733D66756E6374696F6E28652C';
wwv_flow_api.g_varchar2_table(2) := '72297B6C657420612C6F3D2428602E6C746F247B722E636F6D706F6E656E7449647D5F3160292C703D2428602E6C746F247B722E636F6D706F6E656E7449647D5F3060293B613D6F2E6C656E6774683F6F3A702C617065782E74656D706C6174654F7074';
wwv_flow_api.g_varchar2_table(3) := '696F6E7348656C7065722E61646447656E6572616C50726F70657274795479706528293B636F6E737420743D617065782E74656D706C6174654F7074696F6E7348656C7065722E67657450726F7065727469657328722C28722E63757272656E7456616C';
wwv_flow_api.g_varchar2_table(4) := '7565737C7C2222292E73706C697428223A2229293B242865292E70726F7065727479456469746F72287B646174613A7B70726F70657274795365743A5B7B646973706C617947726F757049643A22636F6D6D6F6E222C646973706C617947726F75705469';
wwv_flow_api.g_varchar2_table(5) := '746C653A22436F6D6D6F6E222C70726F706572746965733A742E636F6D6D6F6E7D2C7B646973706C617947726F757049643A22616476616E636564222C646973706C617947726F75705469746C653A22416476616E636564222C70726F70657274696573';
wwv_flow_api.g_varchar2_table(6) := '3A742E616476616E6365647D5D7D2C6368616E67653A66756E6374696F6E28652C6F297B76617220702C743D66756E6374696F6E2865297B76617220613D21312C6F3D28657C7C2222292E73706C697428223A22292E66696C746572282866756E637469';
wwv_flow_api.g_varchar2_table(7) := '6F6E2865297B72657475726E222344454641554C542322213D3D657C7C28613D21302C2131297D29292E6A6F696E28222022293B72657475726E20612626286F2B3D2220222B722E64656661756C7456616C7565732E6A6F696E2822202229292C6F7D2C';
wwv_flow_api.g_varchar2_table(8) := '6E3D74286F2E70726F70657274792E76616C7565292C693D74286F2E70726576696F757356616C7565293B703D6F2E70726F7065727479242C6F2E70726F70657274792E76616C75653D3D3D6F2E70726F70657274792E6F726967696E616C56616C7565';
wwv_flow_api.g_varchar2_table(9) := '3F702E72656D6F7665436C617373282269732D6368616E67656422292E72656D6F7665436C61737328226861732D7761726E696E6722293A28702E616464436C617373282269732D6368616E67656422292C6F2E70726F70657274792E72657175697265';
wwv_flow_api.g_varchar2_table(10) := '735F72656C6F61642626702E616464436C61737328226861732D7761726E696E672229292C612E72656D6F7665436C6173732869292C612E616464436C617373286E297D7D297D3B0A2F2F2320736F757263654D617070696E6755524C3D736372697074';
wwv_flow_api.g_varchar2_table(11) := '2E6A732E6D6170';
null;
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_plugin_file(
 p_id=>wwv_flow_api.id(776884396196146574)
,p_plugin_id=>wwv_flow_api.id(776877005555146556)
,p_file_name=>'js/script.min.js'
,p_mime_type=>'application/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
