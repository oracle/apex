prompt --application/pages/page_01205
begin
--   Manifest
--     PAGE: 01205
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>1205
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Region - Carousel'
,p_alias=>'CAROUSEL-REGION'
,p_step_title=>'Carousel Region - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(405064482015020227)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210419102725'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405179639694156564)
,p_plug_name=>'Use Cases'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405180198055156564)
,p_plug_name=>'Advanced'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405180664967156565)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Show off one sub region at a time. For example, displaying a report and a chart, a slideshow, or different views of the same data.</p>',
'<p class="dm-Hero-steps">Set <strong>Carousel Container</strong> as Region Template.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405181163279156566)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405181667338156566)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405182113971156566)
,p_plug_name=>'Examples'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405192271255165690)
,p_plug_name=>'1. Default'
,p_parent_plug_id=>wwv_flow_api.id(405182113971156566)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>400
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405192787677165690)
,p_plug_name=>'Carousel Region'
,p_parent_plug_id=>wwv_flow_api.id(405192271255165690)
,p_region_template_options=>'#DEFAULT#:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_api.id(1418258663404351882)
,p_plug_display_sequence=>410
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405193236108165691)
,p_plug_name=>'Region A'
,p_parent_plug_id=>wwv_flow_api.id(405192787677165690)
,p_region_css_classes=>'dm-ColorBlock u-color-1 h200'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>420
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region A</h3>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405193784157165691)
,p_plug_name=>'Region B'
,p_parent_plug_id=>wwv_flow_api.id(405192787677165690)
,p_region_css_classes=>'dm-ColorBlock u-color-2 h200'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>430
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region B</h3>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405194257246165692)
,p_plug_name=>'Region C'
,p_parent_plug_id=>wwv_flow_api.id(405192787677165690)
,p_region_css_classes=>'dm-ColorBlock u-color-3 h200'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>440
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region C</h3>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405194783904165692)
,p_plug_name=>'Demo How To'
,p_parent_plug_id=>wwv_flow_api.id(405192271255165690)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>450
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405195226267165693)
,p_plug_name=>'2. Spin and Cycle'
,p_parent_plug_id=>wwv_flow_api.id(405182113971156566)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>810
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405195754410165693)
,p_plug_name=>'Carousel Region'
,p_parent_plug_id=>wwv_flow_api.id(405195226267165693)
,p_region_template_options=>'t-Region--carouselSpin:js-cycle5s:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_api.id(1418258663404351882)
,p_plug_display_sequence=>410
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405196298963165694)
,p_plug_name=>'Region A'
,p_parent_plug_id=>wwv_flow_api.id(405195754410165693)
,p_region_css_classes=>'dm-ColorBlock u-color-4 h200'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>420
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region A</h3>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405196702552165695)
,p_plug_name=>'Region C'
,p_parent_plug_id=>wwv_flow_api.id(405195754410165693)
,p_region_css_classes=>'dm-ColorBlock u-color-6 h200'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>440
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region C</h3>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405197216513165695)
,p_plug_name=>'Region B'
,p_parent_plug_id=>wwv_flow_api.id(405195754410165693)
,p_region_css_classes=>'dm-ColorBlock u-color-5 h200'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>430
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region B</h3>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405197722102165696)
,p_plug_name=>'Demo How To'
,p_parent_plug_id=>wwv_flow_api.id(405195226267165693)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>450
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405198253897165696)
,p_plug_name=>'3. Remember Slide'
,p_parent_plug_id=>wwv_flow_api.id(405182113971156566)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>820
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405198718058165696)
,p_plug_name=>'Carousel Region'
,p_parent_plug_id=>wwv_flow_api.id(405198253897165696)
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_api.id(1418258663404351882)
,p_plug_display_sequence=>410
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405199255923165697)
,p_plug_name=>'Region A'
,p_parent_plug_id=>wwv_flow_api.id(405198718058165696)
,p_region_css_classes=>'dm-ColorBlock u-color-7 h200'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>420
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region A</h3>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405199723225165698)
,p_plug_name=>'Region C'
,p_parent_plug_id=>wwv_flow_api.id(405198718058165696)
,p_region_css_classes=>'dm-ColorBlock u-color-9 h200'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>440
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region C</h3>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405200247907165698)
,p_plug_name=>'Region B'
,p_parent_plug_id=>wwv_flow_api.id(405198718058165696)
,p_region_css_classes=>'dm-ColorBlock u-color-8 h200'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>430
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region B</h3>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405200768144165699)
,p_plug_name=>'Demo How To'
,p_parent_plug_id=>wwv_flow_api.id(405198253897165696)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>450
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405187617287156572)
,p_plug_name=>'Button Positions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405188182953156572)
,p_plug_name=>'Carousel Region with Buttons'
,p_parent_plug_id=>wwv_flow_api.id(405187617287156572)
,p_region_template_options=>'#DEFAULT#:t-Region--carouselSlide:js-cycle10s:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_api.id(1418258663404351882)
,p_plug_display_sequence=>370
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(404406709752489331)
,p_plug_name=>'Region A'
,p_parent_plug_id=>wwv_flow_api.id(405188182953156572)
,p_region_css_classes=>'dm-ColorBlock u-color-7 h200'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region A</h3>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(404406814520489332)
,p_plug_name=>'Region B'
,p_parent_plug_id=>wwv_flow_api.id(405188182953156572)
,p_region_css_classes=>'dm-ColorBlock u-color-8 h200'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region B</h3>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(404406906359489333)
,p_plug_name=>'Region C'
,p_parent_plug_id=>wwv_flow_api.id(405188182953156572)
,p_region_css_classes=>'dm-ColorBlock u-color-9 h200'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region C</h3>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(714379152428623415)
,p_plug_name=>'Template Options'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.DISP_TEMPLATE_OPTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Carousel Container'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(405188538219156573)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(405188182953156572)
,p_button_name=>'BTN_BP_CHG'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Change'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(405188959895156573)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(405188182953156572)
,p_button_name=>'BTN_BP_CLOSE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Close'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(404407071977489334)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(405188182953156572)
,p_button_name=>'BTN_BP_COY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Copy'
,p_button_position=>'REGION_TEMPLATE_COPY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(405189351884156575)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(405188182953156572)
,p_button_name=>'BTN_BP_CREATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(405189703444156575)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(405188182953156572)
,p_button_name=>'BTN_BP_DEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(405190166572156575)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(405188182953156572)
,p_button_name=>'BTN_BP_EDIT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Edit'
,p_button_position=>'REGION_TEMPLATE_EDIT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(404407126038489335)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(405188182953156572)
,p_button_name=>'BTN_BP_HELP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Help'
,p_button_position=>'REGION_TEMPLATE_HELP'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(405190523812156576)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(405188182953156572)
,p_button_name=>'BTN_BP_NEXT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1917875079922318142)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(405181163279156566)
,p_button_name=>'TEMPLATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Region Template'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:6307:&SESSION.:region:&DEBUG.:RP::'
,p_icon_css_classes=>'fa-window-alt-2'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(405190989343156576)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(405188182953156572)
,p_button_name=>'BTN_BP_PREV'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
);
wwv_flow_api.component_end;
end;
/
