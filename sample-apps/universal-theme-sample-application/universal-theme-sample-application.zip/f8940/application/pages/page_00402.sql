prompt --application/pages/page_00402
begin
--   Manifest
--     PAGE: 00402
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>402
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Colors'
,p_alias=>'COLORS'
,p_step_title=>'Colors - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(558266987012620477)
,p_step_template=>wwv_flow_api.id(2623327345562852400)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20210224063007'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(844155314244515514)
,p_plug_name=>'Stateful Colors'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Stateful colors are used for convey additional meaning for a given UI component. For example, you may choose to color a warning alert with a yellow tint.</p>',
'',
'<p>There are 6 stateful colors: normal, hot, informational, danger, warning, and success. You may customize these colors by modifying the Status Colors within Theme Roller.</p>',
'',
'<div class="color-blocks color-blocks--large">',
'  <div class="color-block u-normal">Normal State</div>',
'  <div class="color-block u-hot">Hot State</div>',
'  <div class="color-block u-info">Info State</div>',
'</div>',
'<div class="color-blocks color-blocks--large">',
'  <div class="color-block u-danger">Danger State</div>',
'  <div class="color-block u-warning">Warning</div>',
'  <div class="color-block u-success">Success</div>',
'</div>',
'',
'<p><strong>Note:</strong> Color alone should not be used to convey information as it may not always be accessible.</strong></p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1644963483147523074)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3064597545922501763)
,p_plug_name=>'Introduction'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Universal Theme uses a consistent set of colors across the included components. These colors can be grouped into two palettes: <strong>General Colors</strong> and <strong>Stateful Colors</strong>.</p>',
'<p>You can learn how to use these colors in your own custom UI components by viewing the <a href="f?p=&APP_ID.:6302:&APP_SESSION.">CSS modifier classes</a> in the <a href="f?p=&APP_ID.:6000:&APP_SESSION.">Reference</a> section.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3064597770745502788)
,p_plug_name=>'General Colors'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>General colors are used for adding color accents to several application components such as Charts, Cards, and and more.</p>',
'',
'<p>There are 15 primary colors which are modified to become slightly lighter or darker to create a total of 45 color options. You can customize these colors by modifying the Color Palette within Theme Roller.</p>',
'',
'<p><strong>Primary Colors</strong></p>',
'',
'<div class="color-blocks">',
'  <div class="color-block u-color-1">1</div>',
'  <div class="color-block u-color-2">2</div>',
'  <div class="color-block u-color-3">3</div>',
'  <div class="color-block u-color-4">4</div>',
'  <div class="color-block u-color-5">5</div>',
'  <div class="color-block u-color-6">6</div>',
'  <div class="color-block u-color-7">7</div>',
'  <div class="color-block u-color-8">8</div>',
'  <div class="color-block u-color-9">9</div>',
'  <div class="color-block u-color-10">10</div>',
'  <div class="color-block u-color-11">11</div>',
'  <div class="color-block u-color-12">12</div>',
'  <div class="color-block u-color-13">13</div>',
'  <div class="color-block u-color-14">14</div>',
'  <div class="color-block u-color-15">15</div>',
'</div>',
'',
'<p><strong>Primary Colors - Lighter</strong></p>',
'',
'<div class="color-blocks">',
'  <div class="color-block u-color-16">16</div>',
'  <div class="color-block u-color-17">17</div>',
'  <div class="color-block u-color-18">18</div>',
'  <div class="color-block u-color-19">19</div>',
'  <div class="color-block u-color-20">20</div>',
'  <div class="color-block u-color-21">21</div>',
'  <div class="color-block u-color-22">22</div>',
'  <div class="color-block u-color-23">23</div>',
'  <div class="color-block u-color-24">24</div>',
'  <div class="color-block u-color-25">25</div>',
'  <div class="color-block u-color-26">26</div>',
'  <div class="color-block u-color-27">27</div>',
'  <div class="color-block u-color-28">28</div>',
'  <div class="color-block u-color-29">29</div>',
'  <div class="color-block u-color-30">30</div>',
'</div>',
'',
'<p><strong>Primary Colors - Darker</strong></p>',
'<div class="color-blocks">',
'  <div class="color-block u-color-31">31</div>',
'  <div class="color-block u-color-32">32</div>',
'  <div class="color-block u-color-33">33</div>',
'  <div class="color-block u-color-34">34</div>',
'  <div class="color-block u-color-35">35</div>',
'  <div class="color-block u-color-36">36</div>',
'  <div class="color-block u-color-37">37</div>',
'  <div class="color-block u-color-38">38</div>',
'  <div class="color-block u-color-39">39</div>',
'  <div class="color-block u-color-40">40</div>',
'  <div class="color-block u-color-41">41</div>',
'  <div class="color-block u-color-42">42</div>',
'  <div class="color-block u-color-43">43</div>',
'  <div class="color-block u-color-44">44</div>',
'  <div class="color-block u-color-45">45</div>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
