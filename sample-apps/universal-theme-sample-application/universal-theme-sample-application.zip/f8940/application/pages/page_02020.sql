prompt --application/pages/page_02020
begin
--   Manifest
--     PAGE: 02020
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>2020
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Migration Steps'
,p_alias=>'MIGRATION-STEPS'
,p_step_title=>'Migration Steps - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(431032219555845082)
,p_step_template=>wwv_flow_api.id(2623327345562852400)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20210224063007'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(435209143871906456)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(435212071162916095)
,p_plug_name=>'Before Migration'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'how-to'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>It is <strong>strongly</strong> recommended to take an export of your application before beginning the migration process.</p>',
'',
'<p>This will enable you to easily revert back to the original application if necessary, before making any changes to your application and its metadata.<br />',
'Once you have migrated to the Universal Theme, you can not easily switch it back to the original legacy theme.<br />',
'Additionally, if you re-import the original application, under a different Application ID, you can refer to this application to review how the application looked previously, as opposed to how it looks using the Universal Theme.</p>',
'',
'<p>If you haven''t done so already, you should:</p>',
'',
'<p>Use the Application Utilities > Upgrade Application to update certain built-in widgets in your legacy applications to the latest provided by APEX 5, e.g. FlashChart to AnyChart.</p>',
'',
'<p>This will ensure that those widgets take full advantage of the responsiveness of Universal Theme.</p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(435212405485917038)
,p_plug_name=>'Creating the Theme'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>To create Universal Theme in your application, go to Shared Components, click on Themes and follow the steps below:</p>',
'<p class="dm-Hero-steps"><strong>Note:</strong> If you have already installed the Universal Theme into your application, proceed to the Second Step: <em>Switch to Universal Theme</em>.</p>',
'<ol>',
'  <li><p>Click <strong>Create Theme</strong></p><p>You need to install the Universal Theme into your application to get started.</p>',
'  <p><img src="#THEME_IMAGES#demo/img/Image_7.png" /></p></li>',
'  <li><p>Select <strong>From the Repository.</strong></p>',
'  <p><img src="#THEME_IMAGES#demo/img/Image_8.png" /></p></li>',
'  <li><p>Select <strong>Desktop</strong> as the User Interface.</p>',
'  <p><img src="#THEME_IMAGES#demo/img/Image_9.png" /></p></li>',
'  <li><p>Choose <strong>Standard Themes</strong> as the Theme Type, and <strong>Universal Theme (Theme 42)</strong> as the Theme. </p>',
'  <p> <img src="#THEME_IMAGES#demo/img/Image_10.png" /></p></li>',
'  <li><p>Review your changes and click <strong>Create</strong>.</p>',
'  <p><img src="#THEME_IMAGES#demo/img/Image_11.png" /></p></li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(435212850907917862)
,p_plug_name=>'Switching the Theme'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="dm-Hero-steps"><strong>Note:</strong> Not until you have completed Step 4 below will your application be irreversibly changed. Reverting back to a Tab-based application will be very difficult, which is why it is strongly recommended you hav'
||'e a backup of the application before proceeding further.</p>',
'<ol>',
'  <li><p>Click <strong>Switch Theme</strong></p>',
'  <p><img src="#THEME_IMAGES#demo/img/Image_12.png" /></p></li>',
'  <li><p>Select the current desktop theme, and then select <strong>42. Universal Theme</strong>.',
'    <br />Depending on your application, you may choose to set the <strong>Reset Grid</strong> option to either <strong>Reset fixed region positions</strong> or <strong>Reset all region and item grid positions</strong>.',
'    <br />Reset fixed region positions will maintain your current region positions, where possible, during migration. <em>This is the recommended approach</em>.',
'    <br />Reset all region and item grid positions will ensure item and region positioning will be reset and will force regions and items to stack on top of each other.',
'    <br />Make sure that <strong>Map Template Classes</strong> is set to <strong>No</strong>',
'  <br />Press <strong>Next</strong> to continue.</p>',
'  <p><img src="#THEME_IMAGES#demo/img/Image_13.png" /></p></li>',
'  <li><p>Verify that<strong> </strong>the mappings for your templates and Universal Theme templates are correct.',
'    <br />Use the <a href="f?p=&APP_ID.:2040:&SESSION."><strong>Universal Theme Migration Bookmarklet</strong></a> to automatically assign the right mapping, or check out the full mapping guide located at the end of this guide.',
'    <br />Most of the inconsistencies will be from new templates that Universal theme provides.',
'  <br />Try to choose the template that best matches your existing template. You may want to browse the components in the Universal Theme Sample Application to get a sense of the new templates and their various configurations. </p>',
'  <p><img src="#THEME_IMAGES#demo/img/Image_14.png" /></p></li>',
'  <li><p>Click <strong>Switch Theme</strong>.</p>',
'  <p> <img src="#THEME_IMAGES#demo/img/Image_15.png" /></p></li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
