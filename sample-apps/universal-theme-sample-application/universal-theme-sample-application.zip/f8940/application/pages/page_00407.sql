prompt --application/pages/page_00407
begin
--   Manifest
--     PAGE: 00407
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>407
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Navigation'
,p_alias=>'NAVIGATION'
,p_step_title=>'Navigation - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(558266987012620477)
,p_step_template=>wwv_flow_api.id(2623327345562852400)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20210224063007'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(825274670975768716)
,p_plug_name=>'Menu Bar'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>The <b>Top Navigation Menu</b> template renders your application navigation as a menu bar, similar to what you find on most desktop applications. This is commonly used for more complex applications with several layers of hierarchy within the navig'
||'ation.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(825274744458768717)
,p_plug_name=>'Tabs'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The <b>Top Navigation Tabs</b> template renders your application navigation as tabs and is ideally suited for simple applications where you have approximately 6 or fewer tabs.</p>',
'',
'<p>This navigation template will automatically be positioned to the bottom of the screen for small screen or mobile devices so it is more comfortable to access.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(825274890092768718)
,p_plug_name=>'Mega Menu'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The <b>Top Navigation Mega Menu</b> template renders your application navigation in a popup panel that can be opened or closed from the header menu button.</p>',
'<p>Mega menus are especially useful when you want to display all navigation items at once to your user, and is a very common pattern you will see across the web.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(825274979178768719)
,p_plug_name=>'Side Tree Navigation'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>The <b>Side Navigation Menu</b> template renders your application navigation in a collapsible side panel. The navigation items are rendered as tree nodes that can be expanded.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1515421145173817007)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>Navigation is an important part of your application and can determine the how your users navigate within your application.  There are two navigation concepts that are key for Universal Theme: Navigation Menus and Navigation Bar.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1515421235412817008)
,p_plug_name=>'Navigation Menus'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The primary navigation structure for your application is defined as a <b>Navigation Menu</b> and is based on the <b>List</b> component in APEX. Navigation Menus are hierarchical and can be any level deep.  This navigation control and can be both d'
||'ynamic (based on a query), or static (based on static list entries).  In addition, you can choose to position your navigation to the top or side of your screen.</p>',
'',
'<p>To change your application''s Navigation Menu settings, navigate to Shared Components &rarr; User Interface Defaults and then click on the edit icon next to the Desktop User Interface. From here, you can navigate to the Navigation Menu region and c'
||'hange the options listed.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1515421395231817009)
,p_plug_name=>'Navigation Bar'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The Navigation Bar is positioned near the end of the application''s header, and typically contains links for user authentication, help, feedback, and other global items.</p>',
'',
'<p>Navigation Bars are also based on the <b>List</b> component in APEX. However, as of APEX 5.1, you may only have a two-level deep menu.</p>',
'',
'<p>To change your application''s Navigation Bar settings, navigate to Shared Components &rarr; User Interface Defaults and then click on the edit icon next to the Desktop User Interface. From here, you can navigate to the Navigation Bar region and cha'
||'nge the options listed.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5160189184423760318)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(825275040568768720)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(825274670975768716)
,p_button_name=>'OPEN_PREVIEW_MENU_BAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Open Preview'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(825275356397768723)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(825274744458768717)
,p_button_name=>'OPEN_PREVIEW_TABS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Open Preview'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(825275634824768726)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(825274890092768718)
,p_button_name=>'OPEN_PREVIEW_MEGA_MENU'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Open Preview'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(825275953185768729)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(825274979178768719)
,p_button_name=>'OPEN_PREVIEW_SIDE_TREE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Open Preview'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(825276267651768732)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(825274890092768718)
,p_button_name=>'OPEN_PREVIEW_MEGA_MENU_2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Open Preview - Variation 2'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-external-link'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(825275127324768721)
,p_name=>'Menu Bar Preview'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(825275040568768720)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(825275254228768722)
,p_event_id=>wwv_flow_api.id(825275127324768721)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1120:&APP_SESSION.'',''Menu Bar Preview'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(825275489623768724)
,p_name=>'Tabs Preview'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(825275356397768723)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(825275551621768725)
,p_event_id=>wwv_flow_api.id(825275489623768724)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1121:&APP_SESSION.'',''Tabs Preview'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(825275730412768727)
,p_name=>'Mega Menu Preview'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(825275634824768726)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(825275890793768728)
,p_event_id=>wwv_flow_api.id(825275730412768727)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1122:&APP_SESSION.'',''Mega Menu Preview'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(825276322976768733)
,p_name=>'Mega Menu Preview_2'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(825276267651768732)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(825276424543768734)
,p_event_id=>wwv_flow_api.id(825276322976768733)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1124:&APP_SESSION.'',''Mega Menu Preview 2'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(825276056291768730)
,p_name=>'Side Nav Preview'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(825275953185768729)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(825276128083768731)
,p_event_id=>wwv_flow_api.id(825276056291768730)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1123:&APP_SESSION.'',''Side Navigation Menu Preview'');'
);
wwv_flow_api.component_end;
end;
/
