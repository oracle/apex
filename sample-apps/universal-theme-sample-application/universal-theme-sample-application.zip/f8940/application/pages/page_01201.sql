prompt --application/pages/page_01201
begin
--   Manifest
--     PAGE: 01201
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>1201
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Regions - Standard'
,p_alias=>'STANDARD-REGION'
,p_step_title=>'Standard Region - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(405064482015020227)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.button-bar .t-Region-buttons.t-Region-buttons--top {',
'  border-bottom: 1px solid rgba(0,0,0,.1);',
'  background-color: rgba(0,0,0,.05);',
'}'))
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20210224063007'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405001279057846486)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The generic region template. It works well with all widgets and can be heavily customized.</p>',
'<p class="dm-Hero-steps">Set <strong>Standard </strong> as Region Template.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405001723120846493)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405002281522846494)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405002796728846494)
,p_plug_name=>'Examples'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405003240543846495)
,p_plug_name=>'1. Default'
,p_parent_plug_id=>wwv_flow_api.id(405002796728846494)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405003740688846495)
,p_plug_name=>'Standard Region Template'
,p_parent_plug_id=>wwv_flow_api.id(405003240543846495)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dm-Placeholder h180"> ',
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region Body</h3>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405004218770846496)
,p_plug_name=>'Demo How To'
,p_parent_plug_id=>wwv_flow_api.id(405003240543846495)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405004734816846497)
,p_plug_name=>'2. Hidden Heading'
,p_parent_plug_id=>wwv_flow_api.id(405002796728846494)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405005223088846497)
,p_plug_name=>'Demo How To'
,p_parent_plug_id=>wwv_flow_api.id(405004734816846497)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>80
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405005744401846498)
,p_plug_name=>'Standard Region Template'
,p_parent_plug_id=>wwv_flow_api.id(405004734816846497)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:t-Region--hideHeader'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>70
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dm-Placeholder h180"> ',
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region Body</h3>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405006286304846498)
,p_plug_name=>'3. Icon in Region Header'
,p_parent_plug_id=>wwv_flow_api.id(405002796728846494)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405006786681846499)
,p_plug_name=>'Demo How To'
,p_parent_plug_id=>wwv_flow_api.id(405006286304846498)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>120
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405007218246846499)
,p_plug_name=>'Standard Region Template'
,p_parent_plug_id=>wwv_flow_api.id(405006286304846498)
,p_icon_css_classes=>'fa-line-chart'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:i-h240:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>100
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dm-Placeholder h180"> ',
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region Body</h3>',
'</div>',
'<div class="dm-Placeholder h180"> ',
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region Body</h3>',
'</div>',
'<div class="dm-Placeholder h180"> ',
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region Body</h3>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405007792785846500)
,p_plug_name=>'4. Variation B'
,p_parent_plug_id=>wwv_flow_api.id(405002796728846494)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405008227709846500)
,p_plug_name=>'Standard Region Template'
,p_parent_plug_id=>wwv_flow_api.id(405007792785846500)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:i-h240:t-Region--accent2:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dm-Placeholder h180"> ',
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region Body</h3>',
'</div>',
'<div class="dm-Placeholder h180"> ',
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region Body</h3>',
'</div>',
'<div class="dm-Placeholder h180"> ',
'<span class="a-Icon icon-template-region"></span>',
'<h3>Region Body</h3>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405008772612846502)
,p_plug_name=>'Demo How To'
,p_parent_plug_id=>wwv_flow_api.id(405007792785846500)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405009288923846503)
,p_plug_name=>'Button Positions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(481014591124886801)
,p_plug_name=>'About'
,p_parent_plug_id=>wwv_flow_api.id(405009288923846503)
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p class="dm-Hero-steps">The following region shows all possible button positions.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(481014652070886802)
,p_plug_name=>'Region Title'
,p_parent_plug_id=>wwv_flow_api.id(405009288923846503)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405015006685846510)
,p_plug_name=>'Use Cases'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405009717585846503)
,p_plug_name=>'Region with Button Bar'
,p_parent_plug_id=>wwv_flow_api.id(405015006685846510)
,p_region_css_classes=>'button-bar'
,p_icon_css_classes=>'fa-window-user'
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This region demonstrates a button bar that can be used to navigate between widgets, and also display menu buttons.</p>',
'',
'<p>This region also has a custom style applied to the button container. You can style these "button containers" relatively easily by adding some custom CSS to the page. <br />',
'For example, the class <strong>button-bar</strong> has been applied to the region in Page Designer, and the following CSS has been added to the page:</p>',
'',
'<code>',
'.button-bar .t-Region-buttons.t-Region-buttons--top {',
'  border-bottom: 1px solid rgba(0,0,0,.1);',
'  background-color: rgba(0,0,0,.05);',
'}',
'</code>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405015549018846511)
,p_plug_name=>'Advanced'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(481014728072886803)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(481014652070886802)
,p_button_name=>'Change_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Change'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(481014852273886804)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(481014652070886802)
,p_button_name=>'Close_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Close'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(481014949174886805)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(481014652070886802)
,p_button_name=>'Copy_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Copy'
,p_button_position=>'REGION_TEMPLATE_COPY'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(481015019928886806)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(481014652070886802)
,p_button_name=>'Create_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(481015180805886807)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(481014652070886802)
,p_button_name=>'Delete_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(481015246460886808)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(481014652070886802)
,p_button_name=>'Edit_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Edit'
,p_button_position=>'REGION_TEMPLATE_EDIT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(481015327855886809)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(481014652070886802)
,p_button_name=>'Help_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Help'
,p_button_position=>'REGION_TEMPLATE_HELP'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(481015629798886812)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(481014652070886802)
,p_button_name=>'Next_1_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(405013311816846508)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(405009717585846503)
,p_button_name=>'Next_2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--pillStart'
,p_button_template_id=>wwv_flow_api.id(900079107762114354)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(405013730859846509)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(405009717585846503)
,p_button_name=>'Next_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--pillEnd'
,p_button_template_id=>wwv_flow_api.id(900079107762114354)
,p_button_image_alt=>'Next'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(405014104372846509)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(405009717585846503)
,p_button_name=>'Save'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--small'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Save'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1917870983654289187)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_api.id(405002281522846494)
,p_button_name=>'TEMPLATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Region Template'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:6307:&SESSION.:region:&DEBUG.:RP::'
,p_icon_css_classes=>'fa-window-alt-2'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(481015887399886814)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(481014652070886802)
,p_button_name=>'Previous_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Previous'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(405014533297846509)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(405009717585846503)
,p_button_name=>'Menu'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Menu Button'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_icon_css_classes=>'fa-angle-down'
);
wwv_flow_api.component_end;
end;
/
