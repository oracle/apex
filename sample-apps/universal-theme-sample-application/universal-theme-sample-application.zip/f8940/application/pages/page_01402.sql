prompt --application/pages/page_01402
begin
--   Manifest
--     PAGE: 01402
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>1402
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Reports - Interactive Report'
,p_alias=>'INTERACTIVE-REPORT'
,p_step_title=>'Interactive Report - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(405064482015020227)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210419102725'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(415938462585117770)
,p_plug_name=>'Template Options'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.DISP_TEMPLATE_OPTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Interactive Report'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(415939445074117771)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Interactive Reports provide powerful features for customizing your report such as searching, filtering, sorting, highlighting, group-by, pivot, aggregations, calculations, charting, and more.</p>',
'<p class="dm-Hero-steps">Create a new Region with <strong>Interactive Report</strong> as the region type.</p>',
'',
'<p>You can further enhance Interactive Reports by using the <strong>Interactive Report</strong> region template, and enable template options such as <strong>Show Maximize Button</strong>.</p>',
'<p class="dm-Hero-steps">Set <strong>Interactive Report</strong> as the region template.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(415939963420117772)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(415940489376117772)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(415940952951117773)
,p_plug_name=>'Examples'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(415957209854171599)
,p_plug_name=>'1. Simple'
,p_parent_plug_id=>wwv_flow_api.id(415940952951117773)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(415957716764171599)
,p_plug_name=>'Simple Interactive Report'
,p_parent_plug_id=>wwv_flow_api.id(415957209854171599)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'DEFAULT'
,p_plug_template=>wwv_flow_api.id(651498026300583706)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'  task_name,',
'  start_date,',
'  status,',
'  assigned_to',
'from eba_ut_chart_tasks'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(415958145470171602)
,p_max_row_count=>'1000000'
,p_max_rows_per_page=>'6'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#menu/pencil16x16.gif" alt="" />'
,p_icon_view_columns_per_row=>1
,p_owner=>'SHAKEEB'
,p_internal_uid=>415958145470171602
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(415958229451171607)
,p_db_column_name=>'TASK_NAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Task name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(415958691395171610)
,p_db_column_name=>'START_DATE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Start date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(415959044102171610)
,p_db_column_name=>'STATUS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(415959445220171610)
,p_db_column_name=>'ASSIGNED_TO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Assigned to'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(415959886706171611)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4159599'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TASK_NAME:START_DATE:STATUS:ASSIGNED_TO'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(415960334725171616)
,p_plug_name=>'2. Customized'
,p_parent_plug_id=>wwv_flow_api.id(415940952951117773)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>This Interactive Report has been customized with cell highlighting and a control break on the <i>Assigned To</i> column.  In addition, the region template has the <i>Show Maximize Button</i> template option enabled, allowing you to maximize this r'
||'eport to fill the screen.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(415960875040171617)
,p_plug_name=>'Customized Interactive Report'
,p_parent_plug_id=>wwv_flow_api.id(415960334725171616)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton'
,p_component_template_options=>'DEFAULT'
,p_plug_template=>wwv_flow_api.id(651498026300583706)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'  task_name,',
'  start_date,',
'  status,',
'  case status ',
'    when ''Open'' then ''fa-clock-o is-open''',
'    when ''Closed'' then ''fa-check-circle is-closed''',
'    when ''On-Hold'' then ''fa-exclamation-circle is-holding''',
'    when ''Pending'' then ''fa-exclamation-triangle is-pending''',
'  end status_icon,',
'  assigned_to',
'from eba_ut_chart_tasks',
'order by 2'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(415961249439171617)
,p_max_row_count=>'1000000'
,p_max_rows_per_page=>'6'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'SHAKEEB'
,p_internal_uid=>415961249439171617
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(415961311193171617)
,p_db_column_name=>'TASK_NAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Task name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(415961783254171618)
,p_db_column_name=>'START_DATE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Start date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(415962148662171618)
,p_db_column_name=>'STATUS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(415962598373171618)
,p_db_column_name=>'ASSIGNED_TO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Assigned to'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(415962987619171619)
,p_db_column_name=>'STATUS_ICON'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Status icon'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(415963371136171619)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'4159634'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5
,p_report_columns=>'TASK_NAME:START_DATE:STATUS:ASSIGNED_TO:STATUS_ICON'
,p_sort_column_1=>'START_DATE'
,p_sort_direction_1=>'ASC'
,p_break_on=>'ASSIGNED_TO'
,p_break_enabled_on=>'ASSIGNED_TO'
);
wwv_flow_api.create_worksheet_condition(
 p_id=>wwv_flow_api.id(415963862629171620)
,p_report_id=>wwv_flow_api.id(415963371136171619)
,p_name=>'Closed Projects'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS'
,p_operator=>'='
,p_expr=>'Closed'
,p_condition_sql=>' (case when ("STATUS" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''Closed''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#CBFACB'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(415964327621171621)
,p_plug_name=>'3. Icon View'
,p_parent_plug_id=>wwv_flow_api.id(415940952951117773)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(415964829783171621)
,p_plug_name=>'Icon Interactive Report'
,p_parent_plug_id=>wwv_flow_api.id(415964327621171621)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'DEFAULT'
,p_plug_template=>wwv_flow_api.id(651498026300583706)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'  task_name,',
'  start_date,',
'  status,',
'  case status ',
'    when ''Open'' then ''fa-clock-o is-open''',
'    when ''Closed'' then ''fa-check-circle is-closed''',
'    when ''On-Hold'' then ''fa-exclamation-circle is-holding''',
'    when ''Pending'' then ''fa-exclamation-triangle is-pending''',
'  end status_icon,',
'  assigned_to',
'from eba_ut_chart_tasks',
'order by 2'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(415965239106171622)
,p_max_row_count=>'1000000'
,p_max_rows_per_page=>'6'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#menu/pencil16x16.gif" alt="" />'
,p_icon_view_enabled_yn=>'Y'
,p_icon_view_use_custom=>'Y'
,p_icon_view_custom_link=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dm-IRR-icon">',
'  <span class="fa #STATUS_ICON#"></span>',
'  <span class="dm-IRR-iconLabel">#TASK_NAME#</span>',
'</div>'))
,p_icon_view_columns_per_row=>6
,p_owner=>'SHAKEEB'
,p_internal_uid=>415965239106171622
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(415965316868171622)
,p_db_column_name=>'TASK_NAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Task name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(415965785342171623)
,p_db_column_name=>'START_DATE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Start date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(415966141083171624)
,p_db_column_name=>'STATUS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Status'
,p_column_html_expression=>'<span class="fa #STATUS_ICON#"></span> #STATUS#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(415966525454171624)
,p_db_column_name=>'ASSIGNED_TO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Assigned to'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(415966965555171625)
,p_db_column_name=>'STATUS_ICON'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Status icon'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(415967308850171625)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'4159674'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>5
,p_view_mode=>'ICON'
,p_report_columns=>'TASK_NAME:START_DATE:STATUS:ASSIGNED_TO:STATUS_ICON'
,p_sort_column_1=>'ASSIGNED_TO'
,p_sort_direction_1=>'ASC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(415950726004117785)
,p_plug_name=>'Button Positions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>You can place buttons in the toolbar by setting the button position to <strong>Right of Interactive Report Search Bar</strong>.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405292039780637817)
,p_plug_name=>'Interactive Report with Buttons'
,p_parent_plug_id=>wwv_flow_api.id(415950726004117785)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(651498026300583706)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'  task_name,',
'  start_date,',
'  status,',
'  assigned_to,',
'  case status ',
'    when ''Open'' then ''fa-clock-o is-open''',
'    when ''Closed'' then ''fa-check-circle is-closed''',
'    when ''On-Hold'' then ''fa-exclamation-circle is-holding''',
'    when ''Pending'' then ''fa-exclamation-triangle is-pending''',
'  end status_icon',
'  ',
'from eba_ut_chart_tasks'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(405292196447637818)
,p_max_row_count=>'1000000'
,p_max_rows_per_page=>'6'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'KYLE'
,p_internal_uid=>405292196447637818
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(405292216723637819)
,p_db_column_name=>'TASK_NAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Task name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(405292307781637820)
,p_db_column_name=>'START_DATE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Start date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(405292405684637821)
,p_db_column_name=>'STATUS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Status'
,p_column_html_expression=>'<span class="fa #STATUS_ICON#"></span> #STATUS#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(405292581870637822)
,p_db_column_name=>'ASSIGNED_TO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Assigned to'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(696199521179857820)
,p_db_column_name=>'STATUS_ICON'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Status icon'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(416107540418550027)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4161076'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TASK_NAME:START_DATE:STATUS:ASSIGNED_TO:STATUS_ICON'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1920955192116808999)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(415939963420117772)
,p_button_name=>'TEMPLATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Report Template'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:6307:&SESSION.:reports:&DEBUG.:RP::'
,p_icon_css_classes=>'fa-table'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2056021694920860221)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(415939963420117772)
,p_button_name=>'REGION_TYPE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Region Type'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:6308:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-list'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(415952820746117788)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(405292039780637817)
,p_button_name=>'RIGHT_OF_IR_BAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Right of Search Bar'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.component_end;
end;
/
