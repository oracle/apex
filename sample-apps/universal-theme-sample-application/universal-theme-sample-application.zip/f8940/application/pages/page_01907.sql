prompt --application/pages/page_01907
begin
--   Manifest
--     PAGE: 01907
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>1907
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Tabs and Region Display Selector'
,p_alias=>'TABS-AND-REGION-DISPLAY-SELECTOR'
,p_step_title=>'Tabs and Region Display Selector - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(558266987012620477)
,p_javascript_code_onload=>'apex.theme42demo.jump(''&REQUEST.'');'
,p_step_template=>wwv_flow_api.id(2623327345562852400)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210419102725'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285421700128520223)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The <strong>Region Display Selector</strong> is a Region component that provides a page level navigation control for other regions on the with the <em>Region Display Selector</em> property set to <strong>Yes</strong>.  It can be configured to work'
||' in two modes:</p>',
'<ul>',
'  <li><strong>View Single Region</strong> Show regions as tabs. Selecting a tab will make the corresponding region visible and hide the other selections.</li>',
'  <li><strong>Scroll Window</strong> Always display all the regions on the page. Selecting a tab will scroll your window to the corresponding region.</li>',
'</ul>',
'<p>Follow the instructions below to add a Region Display Selector to your own pages:</p>',
'<div class="dm-Hero-steps  margin-bottom-md">',
'<p><strong>Step 1</strong> Create a <strong>Region Display Selector</strong> region and place it in the <strong>Breadcrumb</strong> region position on your page.</p>',
'<p><strong>Step 2</strong> Modify the other regions on the page and set the <em>Region Display Selector</em> property to <strong>Yes</strong> for the regions you want to appear in the Region Display Selector.</p>',
'</div>',
'<p><strong>Tip:</strong> You can find examples of how to use the Region Display Selector in several of the Packaged Apps bundled with Application Express.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285421868806520224)
,p_plug_name=>'Tabs Region'
,p_region_name=>'tab_container'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The <strong>Tabs Container</strong> Region Template can be used to create a set tabs within your page.  Simply place sub regions within the Tabs Container and they will appear as a tab.</p>',
'<p>This control is useful when you want to display different regions or information, but utilise the same space on a page.</p>',
'',
'<p>Follow the instructions below to add a tabs component your own pages:</p>',
'<div class="dm-Hero-steps  margin-bottom-md">',
'<p><strong>Step 1</strong> Create a new Static Content region and set the Template to <strong>Tabs Container</strong>.</p>',
'<p><strong>Step 2</strong> Create or move sub regions into the Tabs Container, one for each tab you want to have.</p>',
'</div>',
'<p><strong>Tip:</strong> You can easily nest tabs by creating another Tabs Container region within a sub region of an existing Tabs Container region.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2025746929774536714)
,p_plug_name=>'Example 1'
,p_parent_plug_id=>wwv_flow_api.id(2285421868806520224)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2025746410148536709)
,p_plug_name=>'Tabs Container'
,p_parent_plug_id=>wwv_flow_api.id(2025746929774536714)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(1774143203700285855)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2025746550532536710)
,p_plug_name=>'Tab 1'
,p_parent_plug_id=>wwv_flow_api.id(2025746410148536709)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>'Content 1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2025746643523536711)
,p_plug_name=>'Tab 2'
,p_parent_plug_id=>wwv_flow_api.id(2025746410148536709)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source=>'Content 2'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2025746742675536712)
,p_plug_name=>'Tab 3'
,p_parent_plug_id=>wwv_flow_api.id(2025746410148536709)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_source=>'Content 3'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285422747461520233)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_api.id(2025746929774536714)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285422081111520226)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_api.id(2285421868806520224)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.DISP_TEMPLATE_OPTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Tabs Container'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285422150076520227)
,p_plug_name=>'Example 2'
,p_parent_plug_id=>wwv_flow_api.id(2285421868806520224)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285422202988520228)
,p_plug_name=>'Tabs Container'
,p_parent_plug_id=>wwv_flow_api.id(2285422150076520227)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--pill:t-TabsRegion-mod--large'
,p_plug_template=>wwv_flow_api.id(1774143203700285855)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285422309965520229)
,p_plug_name=>'Tab 1'
,p_parent_plug_id=>wwv_flow_api.id(2285422202988520228)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>'Content 1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285422455922520230)
,p_plug_name=>'Tab 2'
,p_parent_plug_id=>wwv_flow_api.id(2285422202988520228)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_source=>'Content 2'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285422560012520231)
,p_plug_name=>'Tab 3'
,p_parent_plug_id=>wwv_flow_api.id(2285422202988520228)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_source=>'Content 3'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285422906352520235)
,p_plug_name=>'Tab 4 - Nested'
,p_parent_plug_id=>wwv_flow_api.id(2285422202988520228)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1922209187092703219)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285423010854520236)
,p_plug_name=>'Nested Container'
,p_parent_plug_id=>wwv_flow_api.id(2285422906352520235)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_api.id(1774143203700285855)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285423193766520237)
,p_plug_name=>'Nested Region A'
,p_parent_plug_id=>wwv_flow_api.id(2285423010854520236)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore accusamus quidem saepe in voluptate ad ea quis maxime consectetur voluptatum eos, laboriosam voluptates cupiditate atque obcaecati numquam fuga, explicabo illo.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285423286595520238)
,p_plug_name=>'Nested Region B'
,p_parent_plug_id=>wwv_flow_api.id(2285423010854520236)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Similique ducimus, rerum illo ea provident a. Veniam voluptates sed quidem incidunt, dolores vel eveniet. Vel officiis facere, totam fuga voluptatum obcaecati!</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285422630439520232)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_api.id(2285422150076520227)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285421972161520225)
,p_plug_name=>'Tabs List'
,p_region_name=>'tab_list'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The <strong>Tabs</strong> List Template can be used to create a set tabs where each tab links to another page.  This is especially useful for applications that require nested or complex navigation hierarchies.</p>',
'',
'<p>Follow the instructions below to add a tabs component your own pages:</p>',
'<p class="dm-Hero-steps">Set <strong>Tabs</strong> as the List Template</p>',
'<p><strong>Tip:</strong> You can add icons to these tabs simply by modifying the icon attribute of the list entry.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285423484801520240)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_api.id(2285421972161520225)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.DISP_TEMPLATE_OPTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'LIST'
,p_attribute_04=>'Tabs'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285423674580520242)
,p_plug_name=>'Example 1 Container'
,p_parent_plug_id=>wwv_flow_api.id(2285421972161520225)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1922209187092703219)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2025746121407536706)
,p_plug_name=>'Example 1'
,p_parent_plug_id=>wwv_flow_api.id(2285423674580520242)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_component_template_options=>'#DEFAULT#:t-Tabs--simple'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(2285543718406476760)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(1840624874773603093)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285423518786520241)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_api.id(2285423674580520242)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285423769316520243)
,p_plug_name=>'Example 2 Container'
,p_parent_plug_id=>wwv_flow_api.id(2285421972161520225)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1922209187092703219)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285423811793520244)
,p_plug_name=>'Example 2'
,p_parent_plug_id=>wwv_flow_api.id(2285423769316520243)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_component_template_options=>'#DEFAULT#:t-Tabs--inlineIcons:t-Tabs--simple'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(2285543718406476760)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(1840624874773603093)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285423920511520245)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_api.id(2285423769316520243)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285424057433520246)
,p_plug_name=>'Example 3 Container'
,p_parent_plug_id=>wwv_flow_api.id(2285421972161520225)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1922209187092703219)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285424124953520247)
,p_plug_name=>'Example 3'
,p_parent_plug_id=>wwv_flow_api.id(2285424057433520246)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_component_template_options=>'#DEFAULT#:t-Tabs--large:t-Tabs--pill:t-Tabs--iconsAbove:t-Tabs--fillLabels'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(2285543718406476760)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(1840624874773603093)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2285424234718520248)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_api.id(2285424057433520246)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4459495255936548240)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>You can use Tabs and the Region Display Selector within your application pages to improve navigation, flow and usability of your pages.  These components are grouped together as they provide similar functionality, but have different implementation'
||'s and use cases.  This page will outline the three distinct methods you can use to apply these components to your page.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4459495563049546423)
,p_plug_name=>'Region Display Selector'
,p_region_name=>'dialog_fixed'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8691554008245997760)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2056000407641600156)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8691554008245997760)
,p_button_name=>'REGION_TYPE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Region Type'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:6308:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-list'
);
wwv_flow_api.component_end;
end;
/
