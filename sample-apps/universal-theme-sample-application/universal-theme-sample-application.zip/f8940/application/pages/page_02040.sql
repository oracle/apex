prompt --application/pages/page_02040
begin
--   Manifest
--     PAGE: 02040
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>2040
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Bookmarklet'
,p_alias=>'BOOKMARKLET'
,p_step_title=>'Bookmarklet - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(431032219555845082)
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var current_url = window.location.href; ',
'var s = ''f'' + window.location.search;',
'var js_url = current_url.replace(s,'''') + ''#APP_IMAGES#bookmarklet.js'';',
'var href = ''javascript:(function(){(function(){if(window.apex.jQuery===undefined){alert("To use this bookmarklet, you need to, first, drag it into your bookmark bars and then click on it on page 386 of the theme switch wizard!");return;}apex.jQuery.g'
||'etScript("'' + js_url + ''").done(function(script,textStatus){console.log(textStatus);}).fail(function(jqxhr,settings,exception){});})();})();'';',
'document.getElementById(''codeOut'').href = href;'))
,p_step_template=>wwv_flow_api.id(2623327345562852400)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20210224063007'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(431043910495209539)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(431045291219212296)
,p_plug_name=>'Bookmarklet for Template Mapping'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>There is not always an equivalent template in Universal Theme for all templates from previous themes. For this reason, the APEX Development Team has created a bookmarklet to assist you with mapping your older templates to your newer templates in t'
||'he Verify Compatibility step of the Switch Theme wizard.</p>',
'<p>It supports mappings from the 3 most popular legacy themes, Theme 24, 25, and 26. It also supports any themes that are based off these legacy themes, i.e.: if your theme was based on one of those themes. When utilized then the bookmarklet will do '
||'most of the mappings correctly to produce the best results from the migration.</p>',
'<p class="dm-Hero-steps">Installation: <strong>Drag</strong> the link below into your bookmarks bar:</p>',
'',
'<div class="dm-bookmarklet">',
'<a id="codeOut" href=''javascript:(function(){(function(){if(window.apex.jQuery===undefined){alert("To use this bookmarklet, you need to, first, drag it into your bookmark bars and then click on it on page 386 of the theme switch wizard!");return;}ape'
||'x.jQuery.getScript("#APP_IMAGES#bookmarklet.js").done(function(script,textStatus){console.log(textStatus);}).fail(function(jqxhr,settings,exception){});})();})();''>Universal Theme Migration Helper V1.1</a>',
'<table class="u-Report">',
'    <thead>',
'        <tr>',
'            <th>',
'                Version',
'            </th>',
'            <th>',
'                Date',
'            </th>',
'            <th>',
'                Changes',
'            </th>',
'        </tr>',
'    </thead>',
'    <tbody>',
'        <tr>',
'            <td>',
'                1.1',
'            </td>',
'            <td>',
'                6/19/15',
'            </td>',
'            <td>',
'                Theme 21, 22, 23 support<br>Internet Explorer Support. <br> Auto Updating',
'            </td>',
'        </tr>',
'        <tr>',
'            <td>',
'                1.01',
'            </td>',
'            <td>',
'                5/13/15',
'            </td>',
'            <td>',
'                Firefox Support',
'            </td>',
'        </tr>',
'        <tr>',
'            <td>',
'                1.0',
'            </td>',
'            <td>',
'',
'            </td>',
'            <td>',
'                Initial Release',
'            </td>',
'        </tr>',
'    </tbody>',
'</table>',
'</div>',
'',
'<p class="dm-Hero-steps">Usage: On Switch Theme page, click on the bookmarklet to update the template mappings.</p>',
'<p><img src="#THEME_IMAGES#demo/img/Image_19.png" /></p>',
'<p>If the theme you are migrating from is supported, then it will automatically match the templates of your older theme to the correct templates in Universal Theme, highlighted in green.</p>',
'<p><img src="#THEME_IMAGES#demo/img/Image_20.png" /></p>',
'<p>Once the mapping process has completed, any errors you encounter will be displayed On an error page.<br />',
'  You can try clicking on the <strong>Map to a Different Theme</strong> button, to try re-mapping with an alternate theme available within the book marklet.<br />',
'If the expected mapping can not be found in the select list for that template, then it will be highlighted in orange.</p>',
'<p><img src="#THEME_IMAGES#demo/img/Image_21.png" /></p>',
'<p>Typically receiving any errors either means your custom templates did not strictly match the theme you chose,<br />',
'or that you have not set <strong>Match Template Classes</strong> to "<strong>No</strong>" in the previous step.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
