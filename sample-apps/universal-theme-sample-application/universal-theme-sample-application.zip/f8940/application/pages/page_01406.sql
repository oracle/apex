prompt --application/pages/page_01406
begin
--   Manifest
--     PAGE: 01406
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>1406
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Reports - Timeline'
,p_alias=>'TIMELINE-REPORTS'
,p_step_title=>'Activity Timeline - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(405064482015020227)
,p_step_template=>wwv_flow_api.id(2623327345562852400)
,p_page_css_classes=>'dm-Page'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210419102725'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416278877139820019)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><strong>Timeline</strong> is a Classic Report template that is useful for displaying a series of events. It can be used to showcase the history of a given widget, recent updates, or new interactions within an application.</p>',
'<p class="dm-Hero-steps">Set <strong>Timeline</strong> as the Report Template.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416279341776820020)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416279808417820020)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416295511453820041)
,p_plug_name=>'Sample Query'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-sql"><code>select',
'  substr(username,0,2) user_avatar,',
'  ''u-color-''|| ( ora_hash(username,45) + 1 ) user_color,',
'  user_name,',
'  event_date,',
'  event_type,',
'  event_title,',
'  event_desc,',
'  case status ',
'    when ''open'' then ''fa fa-clock-o''',
'    when ''closed'' then ''fa fa-check-circle-o''',
'    when ''on-hold'' then ''fa fa-exclamation-circle''',
'    when ''pending'' then ''fa fa-exclamation-triangle''',
'  end event_icon,',
'  case status ',
'    when ''open'' then ''is-new''',
'    when ''closed'' then ''is-removed''',
'    when ''on-hold'' then ''is-updated''',
'    when ''pending'' then ''is-updated''',
'  end event_status,',
'  url event_link',
'from dual</code></pre>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416332902410830288)
,p_plug_name=>'Substution Strings'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dm-ContentWell">',
'<dl class="t-AVPList  t-AVPList--leftAligned">',
'    <dt class="t-AVPList-label">',
'        #EVENT_MODIFIERS#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        CSS Class-based modifiers for an event item',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #EVENT_ATTRIBUTES#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Custom attributes for an event item',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #USER_COLOR#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Color applied to a user initials using u-color-XX classes or custom classes',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #USER_AVATAR#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        User initials or image',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #USER_NAME#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        User name',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #EVENT_DATE#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Date of event displayed below user name',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #EVENT_STATUS#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Type of event. Substitute with "is-new", "is-updated" or "is-removed" for default styling.',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #EVENT_ICON#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Icon of event type.',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #EVENT_TITLE#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Name of event',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #EVENT_DESC#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Description of event displayed below event name',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #EVENT_LINK#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Link for the event',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #EVENT_TYPE#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Type of the event',
'    </dd>',
'</dl>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(766161362753482424)
,p_plug_name=>'Template Options'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.DISP_TEMPLATE_OPTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REPORT'
,p_attribute_05=>'Timeline'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(844155280971515513)
,p_plug_name=>'Examples'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416320344862830277)
,p_plug_name=>'Example: Default'
,p_parent_plug_id=>wwv_flow_api.id(844155280971515513)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(416320811411830277)
,p_name=>'Timeline Report Default'
,p_parent_plug_id=>wwv_flow_api.id(416320344862830277)
,p_template=>wwv_flow_api.id(3052412050530173647)
,p_display_sequence=>420
,p_region_css_classes=>'dm-ContentWell'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--hideNoPagination'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  p.id,',
'  substr(p.created_by,0,2) USER_AVATAR,',
'  p.created EVENT_DATE,',
'  lower(p.created_by) USER_NAME,',
'  t.task_name EVENT_TITLE,',
'  t.created created,',
'  lower(t.created_by) owner,',
'  null EVENT_DESC,',
'  case status ',
'    when ''Open'' then ''fa fa-clock-o''',
'    when ''Closed'' then ''fa fa-check-circle-o''',
'    when ''On-Hold'' then ''fa fa-exclamation-circle''',
'    when ''Pending'' then ''fa fa-exclamation-triangle''',
'  end EVENT_ICON,',
'  case status ',
'    when ''Open'' then ''is-new''',
'    when ''Closed'' then ''is-removed''',
'    when ''On-Hold'' then ''is-updated''',
'    when ''Pending'' then ''is-updated''',
'  end EVENT_STATUS,',
'  status EVENT_TYPE,',
'  ''u-color-''||( ora_hash(p.created_by,44) + 1 ) USER_COLOR',
'from',
'  eba_ut_chart_tasks t,',
'  eba_ut_chart_projects p',
'where',
'  t.project = p.id',
'order by p.created'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(65791776421862960)
,p_query_num_rows=>6
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416321274752830278)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416321647785830278)
,p_query_column_id=>2
,p_column_alias=>'USER_AVATAR'
,p_column_display_sequence=>3
,p_column_heading=>'User avatar'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416322055778830279)
,p_query_column_id=>3
,p_column_alias=>'EVENT_DATE'
,p_column_display_sequence=>4
,p_column_heading=>'Event date'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416322457431830279)
,p_query_column_id=>4
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'User name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416322824015830279)
,p_query_column_id=>5
,p_column_alias=>'EVENT_TITLE'
,p_column_display_sequence=>5
,p_column_heading=>'Event title'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416323242186830280)
,p_query_column_id=>6
,p_column_alias=>'CREATED'
,p_column_display_sequence=>11
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416323656605830280)
,p_query_column_id=>7
,p_column_alias=>'OWNER'
,p_column_display_sequence=>12
,p_column_heading=>'Owner'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416324083446830280)
,p_query_column_id=>8
,p_column_alias=>'EVENT_DESC'
,p_column_display_sequence=>6
,p_column_heading=>'Event desc'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'#CREATED#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416324470118830281)
,p_query_column_id=>9
,p_column_alias=>'EVENT_ICON'
,p_column_display_sequence=>7
,p_column_heading=>'Event icon'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416324847873830281)
,p_query_column_id=>10
,p_column_alias=>'EVENT_STATUS'
,p_column_display_sequence=>8
,p_column_heading=>'Event status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416325276682830281)
,p_query_column_id=>11
,p_column_alias=>'EVENT_TYPE'
,p_column_display_sequence=>10
,p_column_heading=>'Event type'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416325610369830282)
,p_query_column_id=>12
,p_column_alias=>'USER_COLOR'
,p_column_display_sequence=>9
,p_column_heading=>'User color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416326184786830282)
,p_plug_name=>'Demo How To'
,p_parent_plug_id=>wwv_flow_api.id(416320344862830277)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>440
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416326610455830282)
,p_plug_name=>'Example: Compact'
,p_parent_plug_id=>wwv_flow_api.id(844155280971515513)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(416327185859830283)
,p_name=>'Timeline Report Compact'
,p_parent_plug_id=>wwv_flow_api.id(416326610455830282)
,p_template=>wwv_flow_api.id(3052412050530173647)
,p_display_sequence=>10
,p_region_css_classes=>'dm-ContentWell'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Timeline--compact'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  p.id,',
'  substr(p.created_by,0,2) USER_AVATAR,',
'  p.created EVENT_DATE,',
'  lower(p.created_by) USER_NAME,',
'  t.task_name EVENT_TITLE,',
'  t.created created,',
'  lower(t.created_by) owner,',
'  null EVENT_DESC,',
'  case status ',
'    when ''Open'' then ''fa fa-clock-o''',
'    when ''Closed'' then ''fa fa-check-circle-o''',
'    when ''On-Hold'' then ''fa fa-exclamation-circle''',
'    when ''Pending'' then ''fa fa-exclamation-triangle''',
'  end EVENT_ICON,',
'  case status ',
'    when ''Open'' then ''is-new''',
'    when ''Closed'' then ''is-removed''',
'    when ''On-Hold'' then ''is-updated''',
'    when ''Pending'' then ''is-updated''',
'  end EVENT_STATUS,',
'  status EVENT_TYPE,',
'  ''u-color-''||( ora_hash(p.created_by,44) + 1 ) USER_COLOR',
'from',
'  eba_ut_chart_tasks t,',
'  eba_ut_chart_projects p',
'where',
'  t.project = p.id',
'order by p.created'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(65791776421862960)
,p_query_num_rows=>6
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416327582423830283)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416327933667830284)
,p_query_column_id=>2
,p_column_alias=>'USER_AVATAR'
,p_column_display_sequence=>3
,p_column_heading=>'User avatar'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416328387776830284)
,p_query_column_id=>3
,p_column_alias=>'EVENT_DATE'
,p_column_display_sequence=>4
,p_column_heading=>'Event date'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416328774092830285)
,p_query_column_id=>4
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'User name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416329180055830285)
,p_query_column_id=>5
,p_column_alias=>'EVENT_TITLE'
,p_column_display_sequence=>5
,p_column_heading=>'Event title'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416329576168830285)
,p_query_column_id=>6
,p_column_alias=>'CREATED'
,p_column_display_sequence=>11
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416329949959830286)
,p_query_column_id=>7
,p_column_alias=>'OWNER'
,p_column_display_sequence=>12
,p_column_heading=>'Owner'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416330335698830286)
,p_query_column_id=>8
,p_column_alias=>'EVENT_DESC'
,p_column_display_sequence=>6
,p_column_heading=>'Event desc'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'#CREATED#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416330703594830286)
,p_query_column_id=>9
,p_column_alias=>'EVENT_ICON'
,p_column_display_sequence=>7
,p_column_heading=>'Event icon'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416331194768830287)
,p_query_column_id=>10
,p_column_alias=>'EVENT_STATUS'
,p_column_display_sequence=>8
,p_column_heading=>'Event status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416331541523830287)
,p_query_column_id=>11
,p_column_alias=>'EVENT_TYPE'
,p_column_display_sequence=>10
,p_column_heading=>'Event type'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416331982492830287)
,p_query_column_id=>12
,p_column_alias=>'USER_COLOR'
,p_column_display_sequence=>9
,p_column_heading=>'User color'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416332431968830288)
,p_plug_name=>'Demo How To'
,p_parent_plug_id=>wwv_flow_api.id(416326610455830282)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1920956324926814610)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(416279341776820020)
,p_button_name=>'TEMPLATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Report Template'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:6307:&SESSION.:reports:&DEBUG.:RP::'
,p_icon_css_classes=>'fa-table'
);
wwv_flow_api.component_end;
end;
/
