prompt --application/pages/page_01909
begin
--   Manifest
--     PAGE: 01909
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>1909
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Updating Universal Theme'
,p_alias=>'UPDATING-UNIVERSAL-THEME'
,p_step_title=>'Updating Universal Theme - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(431032219555845082)
,p_step_template=>wwv_flow_api.id(2623327345562852400)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20210224063007'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(390434387448898119)
,p_plug_name=>'2. Re-apply your Theme Style'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Once you refresh Universal Theme, the current theme style for your application will be reset to <b>Vita</b>.</p>',
'',
'<p>If your application was using a custom theme style, please follow these steps to set your custom theme style as current:</p>',
'',
'<ol>',
'<li>Run your application</li>',
'<li>Open <b>Theme Roller</b> from the Developer Toolbar</li>',
'<li>Select your custom theme style from the <b>Style</b> select list</li>',
'<li>Click <b>Save</b></li>',
'<li>Click <b>Save</b> again in the Save confirmation dialog, then click <b>OK</b></li>',
'<li>In Theme Roller, click <b>Set as Current</b>, then click <b>OK</b></li>',
'<li>Close Theme Roller</li>',
'</ol>',
'',
'<p><b>NOTE:</b> It is crucial that you re-save your custom theme style. This is necessary because Theme Roller will need to re-compile the css based upon the latest changes to the underlying theme.</p>',
'',
'<p>That''s it. Your custom theme style has been re-applied to your application and set as the current theme style.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(390434490967898120)
,p_plug_name=>'Lost Subscriptions'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info'
,p_plug_template=>wwv_flow_api.id(591654834181983844)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>It is recommended that Universal Theme remain subscribed so that you can easily refresh it to receive updates upon new releases of APEX.  If for some reason your application was unsubscribed or unlocked, you can restore the subscription by followi'
||'ng these steps.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(390434508065898121)
,p_plug_name=>'Restoring Universal Theme Subscription'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Follow these steps to restore the Universal Theme subscription and refresh it based on the latest release.</p>',
'<p><b>NOTE:</b> You will lose any changes or customizations made to templates within Universal Theme.</p>',
'',
'<ol>',
'<li>Navigate to <strong>Shared Components</strong> &rarr; <strong>Themes</strong></li>',
'<li>Verify that the <strong>Subscribed From</strong> column for Universal Theme says <strong>Theme Repository</strong></li>',
'<li>Click on <strong>Restore Theme Subscription</strong> from the side bar.</li>',
'<li>Set <b>Theme Source</b> to <b>Oracle Theme</b></li>',
'<li>Set <b>Master Theme</b> to <b>42. Universal Theme</b></li>',
'<li>Set <b>Match Template</b> to <b>By Template Identifier</b></li>',
'<li>Click <strong>Restore Subscription</strong></li>',
'</ol>',
'',
'<p>This process will refresh the Universal Theme in your application based on master copy from the release of APEX.  Your theme style will also be reset to Vita. If you were using a custom theme stle, you can follow the steps outlined above to re-app'
||'ly your custom theme style.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1093647605104550537)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:margin-bottom-lg'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>You can easily update your applicaion to use the latest version of Universal Theme and keep current with the latest features, enhancements and bug fixes.  Simply follow the steps outlined on this page to get your application''s theme refreshed.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1093647770693550538)
,p_plug_name=>'Backup Reminder'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info'
,p_plug_template=>wwv_flow_api.id(591654834181983844)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>Before you begin, please create back up your application.  You can do this by exporting your application, or by creating a copy of it.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1093647860663550539)
,p_plug_name=>'1. Refresh Universal Theme'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>First, you will need to <b>refresh</b> Universal Theme in your application so it is updated to the most current version.</p>',
'<ol>',
'<li>Navigate to <strong>Shared Components</strong> &rarr; <strong>Themes</strong></li>',
'<li>Verify that the <strong>Subscribed From</strong> column for Universal Theme says <strong>Theme Repository</strong></li>',
'<li>Click on <strong>Universal Theme</strong></li>',
'<li>Click <strong>Verify</strong> in the Theme Subscription region header</li>',
'<li>Click <strong>Verify</strong> in the Verify Theme Subscription Dialog</li>',
'<li>Click <strong>Refresh Theme</strong></li>',
'<li>Click <strong>OK</strong></li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10453888391712414965)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.component_end;
end;
/
