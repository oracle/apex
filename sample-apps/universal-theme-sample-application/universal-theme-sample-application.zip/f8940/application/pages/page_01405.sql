prompt --application/pages/page_01405
begin
--   Manifest
--     PAGE: 01405
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>1405
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Reports - Comments'
,p_alias=>'COMMENTS-REPORT'
,p_step_title=>'Comments Report - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(405064482015020227)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210419102725'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416197110778740474)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This report template is used to display user comments and status updates.</p>',
'<p class="dm-Hero-steps">Set <strong>Comments</strong> as the Report Template.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416197641539740475)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416198195388740475)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416198617049740476)
,p_plug_name=>'Examples'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416238472789767394)
,p_plug_name=>'1. Default'
,p_parent_plug_id=>wwv_flow_api.id(416198617049740476)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>400
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416238933810767394)
,p_plug_name=>'Demo How To'
,p_parent_plug_id=>wwv_flow_api.id(416238472789767394)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>430
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(416239445573767395)
,p_name=>'Comments Report Default'
,p_parent_plug_id=>wwv_flow_api.id(416238472789767394)
,p_template=>wwv_flow_api.id(3052412050530173647)
,p_display_sequence=>410
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Comments--chat'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  p.id,',
'  apex_string.get_initials(p.created_by) USER_ICON,',
'  p.created COMMENT_DATE,',
'  lower(p.created_by) USER_NAME,',
'  '' '' COMMENT_TEXT,',
'  ''Delete'' ACTIONS,',
'  '' '' ATTRIBUTE_1,',
'  '' '' ATTRIBUTE_2,',
'  '' '' ATTRIBUTE_3,',
'  '' '' ATTRIBUTE_4,',
'  t.created task_created,',
'  t.created_by task_owner,',
'  t.task_name task_name,',
'  ''u-color-''||ora_hash(p.created_by,45) icon_modifier',
'from',
'  eba_ut_chart_tasks t,',
'  eba_ut_chart_projects p',
'where',
'  t.project = p.id',
'order by t.created'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(1164140200812557328)
,p_query_num_rows=>6
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416239851865767395)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416240201466767397)
,p_query_column_id=>2
,p_column_alias=>'USER_ICON'
,p_column_display_sequence=>2
,p_column_heading=>'User icon'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416240626210767397)
,p_query_column_id=>3
,p_column_alias=>'COMMENT_DATE'
,p_column_display_sequence=>3
,p_column_heading=>'Comment date'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416241094104767397)
,p_query_column_id=>4
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>4
,p_column_heading=>'User name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416241420073767398)
,p_query_column_id=>5
,p_column_alias=>'COMMENT_TEXT'
,p_column_display_sequence=>5
,p_column_heading=>'Comment text'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'#TASK_NAME# - #TASK_OWNER# (#TASK_CREATED#)'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416241807934767398)
,p_query_column_id=>6
,p_column_alias=>'ACTIONS'
,p_column_display_sequence=>6
,p_column_heading=>'Actions'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:alert(''Implement delete for comment ID: '' + #ID#)'
,p_column_linktext=>'#ACTIONS#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416242254035767398)
,p_query_column_id=>7
,p_column_alias=>'ATTRIBUTE_1'
,p_column_display_sequence=>7
,p_column_heading=>'Attribute 1'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416242640453767399)
,p_query_column_id=>8
,p_column_alias=>'ATTRIBUTE_2'
,p_column_display_sequence=>8
,p_column_heading=>'Attribute 2'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416243073347767399)
,p_query_column_id=>9
,p_column_alias=>'ATTRIBUTE_3'
,p_column_display_sequence=>9
,p_column_heading=>'Attribute 3'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416243485515767399)
,p_query_column_id=>10
,p_column_alias=>'ATTRIBUTE_4'
,p_column_display_sequence=>10
,p_column_heading=>'Attribute 4'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416243892899767399)
,p_query_column_id=>11
,p_column_alias=>'TASK_CREATED'
,p_column_display_sequence=>11
,p_column_heading=>'Task created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416244212356767400)
,p_query_column_id=>12
,p_column_alias=>'TASK_OWNER'
,p_column_display_sequence=>12
,p_column_heading=>'Task owner'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416244650393767400)
,p_query_column_id=>13
,p_column_alias=>'TASK_NAME'
,p_column_display_sequence=>13
,p_column_heading=>'Task name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416245084525767400)
,p_query_column_id=>14
,p_column_alias=>'ICON_MODIFIER'
,p_column_display_sequence=>14
,p_column_heading=>'Icon modifier'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'u-color #ICON_MODIFIER#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416245570718767401)
,p_plug_name=>'2. Variation A'
,p_parent_plug_id=>wwv_flow_api.id(416198617049740476)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>420
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416246057935767401)
,p_plug_name=>'Demo How To'
,p_parent_plug_id=>wwv_flow_api.id(416245570718767401)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HOW_TO_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(416246589468767402)
,p_name=>'Comments Report Variation A'
,p_parent_plug_id=>wwv_flow_api.id(416245570718767401)
,p_display_sequence=>10
,p_component_template_options=>'#DEFAULT#:t-Comments--basic'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  p.id,',
'  apex_string.get_initials(p.created_by) USER_ICON,',
'  p.created COMMENT_DATE,',
'  lower(p.created_by) USER_NAME,',
'  '' '' COMMENT_TEXT,',
'  '' '' ACTIONS,',
'  '' '' ATTRIBUTE_1,',
'  '' '' ATTRIBUTE_2,',
'  '' '' ATTRIBUTE_3,',
'  '' '' ATTRIBUTE_4,',
'  t.created task_created,',
'  t.created_by task_owner,',
'  t.task_name task_name,',
'  ''u-color-''||ora_hash(p.created_by,45) icon_modifier',
'from',
'  eba_ut_chart_tasks t,',
'  eba_ut_chart_projects p',
'where',
'  t.project = p.id',
'order by t.created'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(1164140200812557328)
,p_query_num_rows=>6
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416246918236767402)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416247354939767402)
,p_query_column_id=>2
,p_column_alias=>'USER_ICON'
,p_column_display_sequence=>2
,p_column_heading=>'User icon'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416247785739767403)
,p_query_column_id=>3
,p_column_alias=>'COMMENT_DATE'
,p_column_display_sequence=>3
,p_column_heading=>'Comment date'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416248140281767403)
,p_query_column_id=>4
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>4
,p_column_heading=>'User name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416248576697767404)
,p_query_column_id=>5
,p_column_alias=>'COMMENT_TEXT'
,p_column_display_sequence=>5
,p_column_heading=>'Comment text'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'#TASK_NAME# - #TASK_OWNER# (#TASK_CREATED#)'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416248911917767404)
,p_query_column_id=>6
,p_column_alias=>'ACTIONS'
,p_column_display_sequence=>6
,p_column_heading=>'Actions'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416249315484767404)
,p_query_column_id=>7
,p_column_alias=>'ATTRIBUTE_1'
,p_column_display_sequence=>7
,p_column_heading=>'Attribute 1'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416249745989767404)
,p_query_column_id=>8
,p_column_alias=>'ATTRIBUTE_2'
,p_column_display_sequence=>8
,p_column_heading=>'Attribute 2'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416250143282767405)
,p_query_column_id=>9
,p_column_alias=>'ATTRIBUTE_3'
,p_column_display_sequence=>9
,p_column_heading=>'Attribute 3'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416250592054767405)
,p_query_column_id=>10
,p_column_alias=>'ATTRIBUTE_4'
,p_column_display_sequence=>10
,p_column_heading=>'Attribute 4'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416250924887767405)
,p_query_column_id=>11
,p_column_alias=>'TASK_CREATED'
,p_column_display_sequence=>11
,p_column_heading=>'Task created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416251384523767406)
,p_query_column_id=>12
,p_column_alias=>'TASK_OWNER'
,p_column_display_sequence=>12
,p_column_heading=>'Task owner'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416251736977767406)
,p_query_column_id=>13
,p_column_alias=>'TASK_NAME'
,p_column_display_sequence=>13
,p_column_heading=>'Task name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(416252142670767406)
,p_query_column_id=>14
,p_column_alias=>'ICON_MODIFIER'
,p_column_display_sequence=>14
,p_column_heading=>'Icon modifier'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'u-color #ICON_MODIFIER#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(416215422280740496)
,p_plug_name=>'Template Options'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.DISP_TEMPLATE_OPTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REPORT'
,p_attribute_05=>'Comments'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(915210795544378412)
,p_plug_name=>'Substution Strings'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dm-ContentWell">',
'<dl class="t-AVPList  t-AVPList--leftAligned">',
'    <dt class="t-AVPList-label">',
'        #COMMENT_MODIFIERS#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        CSS Class-based modifiers for a comment item',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #ICON_MODIFIER#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        CSS Class-based modifiers for comment icon',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #USER_ICON#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        CSS Class-based modifiers for user icon',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #USER_NAME#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        User name',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #COMMENT_DATE#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Date of the comment',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #ACTIONS#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Actions for the comment',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #COMMENT_TEXT#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Text of the comment',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #ATTRIBUTE_1#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Additional attribute 1',
'    </dd>',
'    <dt class="t-AVPList-label">',
'       #ATTRIBUTE_2#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Additional attribute 2',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #ATTRIBUTE_3#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Additional attribute 3',
'    </dd>',
'    <dt class="t-AVPList-label">',
'        #ATTRIBUTE_4#',
'    </dt>',
'    <dd class="t-AVPList-value">',
'        Additional attribute 4',
'    </dd>',
'</dl>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1702446335272649525)
,p_plug_name=>'Sample Query'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-sql"><code>select',
'  user_icon, -- use apex_string.get_initials(str) to get initials',
'  comment_date,',
'  user_name,',
'  comment_text,',
'  '' '' comment_modifiers,',
'  ''u-color-''||ora_hash(user_name,45) icon_modifier,',
'  ''Edit'' actions,',
'  '' '' attribute_1,',
'  '' '' attribute_2,',
'  '' '' attribute_3,',
'  '' '' attribute_4',
'from',
'  dual</code></pre>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1920956028246813285)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(416197641539740475)
,p_button_name=>'TEMPLATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Report Template'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:6307:&SESSION.:reports:&DEBUG.:RP::'
,p_icon_css_classes=>'fa-table'
);
wwv_flow_api.component_end;
end;
/
