prompt --application/pages/page_06301
begin
--   Manifest
--     PAGE: 06301
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>6301
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Responsive Utilities'
,p_alias=>'RESPONSIVE-UTILITIES'
,p_step_title=>'Responsive Utilities - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(713639924515207048)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'code.event-name {',
'    background: rgba(147, 180, 197, 0.25);',
'    padding: 6px 8px;',
'    border-radius: 3px;',
'    text-shadow: 1px 1px #fff;',
'}',
'',
'code.event-name:hover {',
'    color: #000;',
'    background:#eee',
'}'))
,p_page_css_classes=>'dm-Page'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'STEFAN'
,p_last_upd_yyyymmddhh24miss=>'20210226110841'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(109707274980854005)
,p_plug_name=>'Examples'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="dm-Code lang-html"><code>&lt;div class="hidden-xs-up"&gt;',
'  This is displayed for screens below 640px only.',
'&lt;/div&gt;',
'',
'&lt;div class="hidden-sm-down"&gt;',
'  This is hidden for small screens, and only visible when the screen is at least 992px wide.',
'&lt;/div&gt;</code></pre>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1193588892315178618)
,p_plug_name=>'Classes'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Use the <span class="class">hidden-<span class="class-var">xxx</span>-up</span> class to hide a given component when the viewport size is at the specified breakpoint or wider.</p>',
'',
'<p>Similarly, use the <span class="class">hidden-<span class="class-var">xxx</span>-down</span> class to hide a given component when the viewport size is at the specified breakpoint or narrower.</p>',
'',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc  dm-Report--grid">',
'  <thead>',
'    <tr>',
'      <th></th>',
'      <th>XXS Screens <small class="breakpoint">&le;640px</small></th>',
'      <th>XS Screens <small class="breakpoint">&gt;640 and &lt;768px</small></th>',
'      <th>Small Screens <small class="breakpoint">&ge;768px and &lt;992px</small></th>',
'      <th>Medium Screens <small class="breakpoint">&ge;992px and &lt;1200px</small></th>',
'      <th>Large Screens <small class="breakpoint">&ge;1200px</small></th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">xxs</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">xs</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">sm</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">md</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-visible">Visible</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">lg</span>-down</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">xxs</span>-up</span></th>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">xs</span>-up</span></th>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">sm</span>-up</span></th>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">md</span>-up</span></th>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-hidden">Hidden</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'    <tr>',
'      <th scope="row"><span class="class">hidden-<span class="class-var">lg</span>-up</span></th>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-visible">Visible</td>',
'      <td class="display-hidden">Hidden</td>',
'    </tr>',
'  </tbody>',
'</table>',
'<p><small>Note: These helper utilities are available in Oracle APEX 18.2 and later.</small></p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1193589106772178620)
,p_plug_name=>'Breakpoints'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Universal Theme uses the following breakpoints for responsive styles. You can apply these helper classes using the <span class="class">hidden-<span class="class-var">xxx</span>-up</span> or <span class="class">hidden-<span class="class-var">xxx</s'
||'pan>-down</span> helper classes.</p>',
'',
'</p>',
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Name</th>',
'      <th style="width: 30%" class="u-textStart">Class Variable</th>',
'      <th class="u-textStart">Details</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr>',
'      <td>XXS Screens</td>',
'      <td><span class="class-var">xxs</span></td>',
'      <td><span class="class-desc">640px and below</span></td></tr>',
'    <tr>',
'      <td>XS Screens</td> ',
'      <td><span class="class-var">xs</span></td> ',
'      <td><span class="class-desc">641px to 767px</span></td></tr>',
'    <tr>',
'      <td>Small Screens</td> ',
'      <td><span class="class-var">sm</span></td> ',
'      <td><span class="class-desc">768px to 991px</span></td></tr>',
'    <tr>',
'      <td>Medium Screens</td> ',
'      <td><span class="class-var">md</span></td> ',
'      <td><span class="class-desc">992px to 1199px</span></td></tr>',
'    <tr>',
'      <td>Large Screens</td> ',
'      <td><span class="class-var">lg</span></td> ',
'      <td><span class="class-desc">1200px and above</span></td></tr>',
'  </tbody>',
'</table>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1433110640562986542)
,p_plug_name=>'Introduction'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_source=>'You can use the following helper classes anywhere in your app to fine-tune the responsive behavior of your page and components. For most Oracle APEX components, you can simply populate the <b>CSS Classes</b> property to apply these modifiers to your '
||'page components.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1450351605052441767)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
);
wwv_flow_api.component_end;
end;
/
