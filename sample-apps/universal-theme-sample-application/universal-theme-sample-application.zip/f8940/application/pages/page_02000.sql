prompt --application/pages/page_02000
begin
--   Manifest
--     PAGE: 02000
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>2000
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Migration Guide'
,p_alias=>'MIGRATION-GUIDE'
,p_step_title=>'Migration Guide - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(431032219555845082)
,p_step_template=>wwv_flow_api.id(2623327345562852400)
,p_page_css_classes=>'dm-Page'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20210120094003'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(107376527283374054)
,p_plug_name=>'Migrating from Other Themes'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:margin-top-lg'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>This guide will cover the steps involved in migrating to the Universal Theme. It will cover the pros and cons of Universal Theme, and how to go through the Theme Switch wizard. This guide also covers the post-migration phase: the immediate tasks, '
||'some best practices for working with Universal Theme, and a list of common problems and solutions encountered during and after the upgrade.  Please note that this guide assumes you have a working knowledge of Application Express fundamentals.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(349882008097259924)
,p_plug_name=>'Migration Guide List from Other Themes'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'t-MediaList--showIcons:u-colors'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(558263404439591029)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(618966256865274517)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(606904371121638638)
,p_plug_name=>'Migrating from jQuery Mobile'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:margin-top-lg'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>If you were using the jQuery Mobile user interface for your APEX apps then now is a good time to transition to the Universal Theme. Learn how you can use Universal Theme to deliver a polished small screen experience and the UI patterns to use for '
||'mobile use cases.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(606904440014638639)
,p_plug_name=>'Migrating from jQuery Mobile List'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'t-MediaList--showIcons:u-colors'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(654287896600461596)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(618966256865274517)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1515423123007817027)
,p_plug_name=>'Updating Universal Theme'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>If you are already using Universal Theme in your applications, you can easily take advantage of new features and updates without having to go through a lot of work.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1515423248136817028)
,p_plug_name=>'Updating Universal Theme List'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'t-MediaList--showIcons:u-colors'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(1566181754433295518)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(618966256865274517)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2124444736165886981)
,p_plug_name=>'Migration Guides'
,p_icon_css_classes=>'fa-lg fa-tasks u-color-11'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1224989219520090364)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
