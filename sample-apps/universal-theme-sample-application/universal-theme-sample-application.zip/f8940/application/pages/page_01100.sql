prompt --application/pages/page_01100
begin
--   Manifest
--     PAGE: 01100
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>1100
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Pages'
,p_alias=>'PAGES'
,p_step_title=>'Pages - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(405064482015020227)
,p_javascript_code_onload=>'apex.theme42demo.jump(''&REQUEST.'');'
,p_step_template=>wwv_flow_api.id(2623327345562852400)
,p_page_css_classes=>'dm-Page'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_page_comment=>'apex.theme42demo.noNavigate();'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20210224063007'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(879725051497769501)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208177424805979201)
,p_plug_name=>'Standard Page'
,p_region_name=>'standard'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The default page template. Ideal for home pages, dashboards, large reports, and other layouts where maximum screen real-estate is desired.<p>',
'<p class="dm-Hero-steps">Set <strong>Standard</strong> as the Page Template</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208177955252979213)
,p_plug_name=>'Standard Page with Side Navigation'
,p_parent_plug_id=>wwv_flow_api.id(1208177424805979201)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="dm-Icon dm-Icon--page side-nav-one-column"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1101:&APP_SESSION.'',''Standard with Side Navigation'')" type="button">View Sample</span>',
'</button>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208178412363979213)
,p_plug_name=>'Standard Page with Top Navigation'
,p_parent_plug_id=>wwv_flow_api.id(1208177424805979201)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="dm-Icon dm-Icon--page top-nav-one-column"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1102:&APP_SESSION.'',''Standard with Top Navigation'')" type="button">View Sample</span>',
'</button>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208510599141392012)
,p_plug_name=>'Left Side Column'
,p_region_name=>'left_side'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Features a left-side display position for search filters, charts, and other interactive widgets.<p>',
'<p class="dm-Hero-steps">Set <strong>Left Side Column</strong> as the Page Template</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208516421329446152)
,p_plug_name=>'Left Side Column with Side Navigation'
,p_parent_plug_id=>wwv_flow_api.id(1208510599141392012)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="dm-Icon dm-Icon--page side-nav-left-column"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1103:&APP_SESSION.'',''Left Side Column Page with Side Navigation'')" type="button">View Sample</span>',
'</button>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208516914292446153)
,p_plug_name=>'Left Side Column with Top Navigation'
,p_parent_plug_id=>wwv_flow_api.id(1208510599141392012)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="dm-Icon dm-Icon--page top-nav-left-column"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1104:&APP_SESSION.'',''Left Side Column Page with Top Navigation'')" type="button">View Sample</span>',
'</button>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208582755068851134)
,p_plug_name=>'Right Side Column'
,p_region_name=>'right_side'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page template features a collapsible right-side display position and is especially useful for displaying action-oriented controls such as buttons or lists.<p>',
'<p class="dm-Hero-steps">Set <strong>Right Side Column</strong> as the Page Template</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208588399024861465)
,p_plug_name=>'Right Side Column with Side Navigation'
,p_parent_plug_id=>wwv_flow_api.id(1208582755068851134)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="dm-Icon dm-Icon--page side-nav-right-column"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1105:&APP_SESSION.'',''Right Side Column Page with Side Navigation'')" type="button">View Sample</span>',
'</button>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208588921163861465)
,p_plug_name=>'Right Side Column with Top Navigation'
,p_parent_plug_id=>wwv_flow_api.id(1208582755068851134)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>100
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="dm-Icon dm-Icon--page top-nav-right-column"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1106:&APP_SESSION.'',''Right Side Column Page with Top Navigation'')" type="button">View Sample</span>',
'</button>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208592780290878079)
,p_plug_name=>'Both Side Column'
,p_region_name=>'both_sides'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page template features both the left side column and the collapsible right-side column and is well suited for very complex pages.<p>',
'<p class="dm-Hero-steps">Set <strong>Left and Right Side Columns</strong> as the Page Template</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208598100460891250)
,p_plug_name=>'Side Columns Page with Side Navigation'
,p_parent_plug_id=>wwv_flow_api.id(1208592780290878079)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>120
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="dm-Icon dm-Icon--page side-nav-side-columns"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1109:&APP_SESSION.'',''Left and Right Side Columns Page with Side Navigation'')" type="button">View Sample</span>',
'</button>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208598434970891250)
,p_plug_name=>'Side Columns Page with Top Navigation'
,p_parent_plug_id=>wwv_flow_api.id(1208592780290878079)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>130
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="dm-Icon dm-Icon--page top-nav-side-columns"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1110:&APP_SESSION.'',''Left and Right Side Columns Page with Top Navigation'')" type="button">View Sample</span>',
'</button>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208604537937911419)
,p_plug_name=>'Marquee Detail'
,p_region_name=>'master_detail'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page template features a collapsible right side column and a title-bar area which contains primary information. This page template is well suited for displaying information about a master record with detailed reports or charts in the body.<p>',
'<p class="dm-Hero-steps">Set <strong>Marquee Detail</strong> as the Page Template</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208618639365930634)
,p_plug_name=>'Master Detail Page with Side Navigation'
,p_parent_plug_id=>wwv_flow_api.id(1208604537937911419)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>150
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="dm-Icon dm-Icon--page side-nav-master-detail-page"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1107:&APP_SESSION.'',''Master Detail Page with Side Navigation'')" type="button">View Sample</span>',
'</button>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208619170202930635)
,p_plug_name=>'Right Column Page with Top Navigation'
,p_parent_plug_id=>wwv_flow_api.id(1208604537937911419)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>160
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="dm-Icon dm-Icon--page top-nav-master-detail-page"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1108:&APP_SESSION.'',''Master Detail Page with Top Navigation'')" type="button">View Sample</span>',
'</button>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208636311646946895)
,p_plug_name=>'Dialog'
,p_region_name=>'dialog'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>These page templates can be loaded as either modal or non-modal (pop-up) dialogs and are very useful for displaying commonly used forms, reports, and other components.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208640476642953023)
,p_plug_name=>'Standard Dialog Page'
,p_parent_plug_id=>wwv_flow_api.id(1208636311646946895)
,p_region_css_classes=>'dm-Hero-screenshot'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>150
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="dm-Hero-steps dm-Hero-steps--slim">Set <strong>Standard Dialog</strong> as the Page Template</p>',
'<span class="dm-Icon dm-Icon--page standard-dialog"></span>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208641280982953025)
,p_plug_name=>'Wizard Dialog Page'
,p_parent_plug_id=>wwv_flow_api.id(1208636311646946895)
,p_region_css_classes=>'dm-Hero-screenshot'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>160
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="dm-Hero-steps dm-Hero-steps--slim">Set <strong>Wizard Dialog</strong> as the Page Template</p>',
'<span class="dm-Icon dm-Icon--page wizard-dialog"></span>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208659039984989922)
,p_plug_name=>'Other'
,p_region_name=>'other'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The <strong>Login</strong> page template provides an elegant user interface for your app''s log in page.<p>',
'<p>The <strong>Minimal Page</strong> page template is useful for single page applications or pages where where navigation is not necessary.<p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208663557461994609)
,p_plug_name=>'Minimal Page Template'
,p_parent_plug_id=>wwv_flow_api.id(1208659039984989922)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>150
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="dm-Hero-steps dm-Hero-steps--slim">Set <strong>Minimal (No  Navigation)</strong> as the Page Template</p>',
'<span class="dm-Icon dm-Icon--page minimal-page"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1113:&APP_SESSION.'',''Minimal Page without Navigation'')" type="button">View Sample</span>',
'</button>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1208664067487994609)
,p_plug_name=>'Login Page Template'
,p_parent_plug_id=>wwv_flow_api.id(1208659039984989922)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>160
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="dm-Hero-steps dm-Hero-steps--slim">Set <strong>Login</strong> as the Page Template</p>',
'<span class="dm-Icon dm-Icon--page login-page"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openSamplePage(''f?p=&APP_ID.:1114:&APP_SESSION.'',''Login Page'')" type="button">View Sample</span>',
'</button>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1885099481441050902)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>Page Templates define the layout and purpose of your pages. This page shows samples of all the available page templates. Universal Theme supports two types of Navigation Menus: tree-based navigation on the side, and tab-like navigation on the top.'
||'</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(791529844939869733)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1208640476642953023)
,p_button_name=>'STD_DIALOG_VIEW'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'View Sample'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1111:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(791530539726869734)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(1208641280982953025)
,p_button_name=>'WIZ_DIALOG_VIEW'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'View Sample'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1112:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1917934323891455542)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(879725051497769501)
,p_button_name=>'TEMPLATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Page Template'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:6307:&SESSION.:page:&DEBUG.:RP::'
,p_icon_css_classes=>'fa-file-o'
);
wwv_flow_api.component_end;
end;
/
