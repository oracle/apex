prompt --application/pages/page_04000
begin
--   Manifest
--     PAGE: 04000
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>4000
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Icons'
,p_alias=>'ICONS'
,p_step_title=>'Icons - &APP_TITLE.'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#demo/icons#MIN#.js',
'#THEME_IMAGES#demo/iconSearch#MIN#.js'))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.jQuery("#P4000_SEARCH").on("keyup",function(){apex.theme42demo.renderIcons({debounce: 250, filterString: this.value});});',
'var returnIcon = function(c){return;};'))
,p_javascript_code_onload=>'apex.theme42demo.renderIcons({});'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.highlight {',
'    background-color: #ffef9a;',
'    color: #635c34;',
'    padding: 2px 0;',
'    box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.05) inset, 0 1px 1px -1px rgba(0, 0, 0, 0.1);',
'    border-radius: 2px;',
'    transition: .1s ease;',
'}'))
,p_page_css_classes=>'dm-Page'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20210323095837'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(349882396322259927)
,p_plug_name=>'Icons'
,p_region_name=>'icons'
,p_region_css_classes=>'dm-Search'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(349883229141259936)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:margin-bottom-sm'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(349883301202259937)
,p_plug_name=>'Icon Builder Dialog'
,p_region_name=>'icon_dialog'
,p_region_css_classes=>'dm-IconDialog'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size720x480'
,p_plug_template=>wwv_flow_api.id(1223645131968329858)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(517887344069372819)
,p_plug_name=>'Icon Builder'
,p_parent_plug_id=>wwv_flow_api.id(349883301202259937)
,p_region_css_classes=>'dm-IconDialog-builder'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(349884034203259944)
,p_plug_name=>'Icon Instructions'
,p_parent_plug_id=>wwv_flow_api.id(517887344069372819)
,p_region_css_classes=>'dm-IconDialog-infoWrap'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dm-IconDialog-info row">',
'    <span class="dm-IconDialog-infoTitle col col-3">HTML <button type="button" title="Copy HTML Markup" class="t-Button t-Button--icon t-Button--tiny t-Button--link t-Button--iconLeft" data-clipboard-source="#icon_code"><span aria-hidden="true" class'
||'="t-Icon t-Icon--left fa fa-synonym"></span>Copy</button></span>',
'    <div class="dm-IconDialog-infoBody col col-9">',
'        <code id="icon_code"></code>',
'    </div>',
'</div>',
'<div class="dm-IconDialog-info row">',
'    <span class="dm-IconDialog-infoTitle col col-3">Icon <button type="button" title="Copy Icon Class" class="t-Button t-Button--icon t-Button--tiny t-Button--link t-Button--iconLeft" data-clipboard-source="#icon_classes"><span aria-hidden="true" cla'
||'ss="t-Icon t-Icon--left fa fa-synonym"></span>Copy</button> </span>',
'    <div class="dm-IconDialog-infoBody col col-9">',
'        <code id="icon_classes"></code>',
'        <small>Enter in the Icon property for Buttons, Regions, and other components.</small>',
'    </div>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(517886366768372809)
,p_plug_name=>'Icon Form'
,p_parent_plug_id=>wwv_flow_api.id(517887344069372819)
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>6
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(517887286192372818)
,p_plug_name=>'Icon Preview'
,p_parent_plug_id=>wwv_flow_api.id(517887344069372819)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>'<div id="icon_preview" class="dm-IconDialog-preview"><span></span></div>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(558385722004194470)
,p_plug_name=>'About Font APEX'
,p_region_name=>'about_font_apex'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(1223645131968329858)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>What is Font APEX?</h3>',
'<p>Font APEX is the icon library for Oracle APEX and Universal Theme.  It was originally designed as a replacement for Font Awesome 4.*, the web''s leading icon library, and therefore contains almost all of the Font Awesome icons, re-drawn originally '
||'on a 16x16 grid as line-icons.  We wanted to make it a seamless switch to go from Font Awesome to Font APEX, and therefore use the same "fa" prefix for the icons, making it easier than ever to move to entirely new icon library.</p>',
'',
'<h3>What''s new in Font APEX 2?</h3>',
'<p>Font APEX 2 expands upon the original Font APEX by providing the complete set of Font APEX icons at a larger size.  There are now two families of icons in Font APEX: small and large. Small icons are based on a 16x16 grid and ideally suited for but'
||'tons and menus. Large icons are based on a 32x32 grid and well suited for places where you need to provide a larger graphic, such as cards, media lists, and hero regions.</p>',
'',
'<p>Many APEX components will automatically use the large or small icons based on the context (such as Template Options), so all you need to do is focus on the icon you want.  For example, when using Cards, the Block and Featured template option will '
||'automatically show the larger versions of icons where the Basic and Compact template options will use icons from the smaller set.</p>',
'',
'<p>There are over 1150 icons in Font APEX, and there are 25 modifiers you can place on top of any existing icons so you can customize any icon to fit your needs.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2880276168635562187)
,p_plug_name=>'Icons'
,p_icon_css_classes=>'fa-lg fa-apex u-color-9'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1224989219520090364)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(349883989532259943)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(517887286192372818)
,p_button_name=>'RESET_ICON'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Reset Icon'
,p_button_position=>'BODY'
,p_button_css_classes=>'dm-IconDialog-resetButton'
,p_icon_css_classes=>'fa-refresh'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1515421727652817013)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(2880276168635562187)
,p_button_name=>'ABOUT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'About Font APEX'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-circle'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(349882606928259930)
,p_name=>'P4000_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(349883229141259936)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Search Icons'
,p_placeholder=>'Search Font APEX Icons...'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_css_classes=>'t-Form-searchField'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_api.id(591757292230152601)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(349883610605259940)
,p_name=>'P4000_ROTATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(517886366768372809)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Rotate'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Rotate 90;fa-rotate-90,Rotate 180;fa-rotate-180,Rotate 270;fa-rotate-270,Flip Horizontal;fa-flip-horizontal,Flip Vertical;fa-flip-vertical'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Normal'
,p_cHeight=>1
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_api.id(869572400154599626)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(385717579943249021)
,p_name=>'P4000_SIZE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(349883229141259936)
,p_item_default=>'SMALL'
,p_prompt=>'Size'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Small;SMALL,Large;LARGE'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_api.id(591757292230152601)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(517886424106372810)
,p_name=>'P4000_ICON_SIZE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(517886366768372809)
,p_use_cache_before_default=>'NO'
,p_item_default=>'null'
,p_prompt=>'Scale'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:1x;null,2x;fa-2x,3x;fa-3x,4x;fa-4x,5x;fa-5x'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_api.id(869572400154599626)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'5'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(517886530500372811)
,p_name=>'P4000_ANIMATION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(517886366768372809)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Animation'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'FONT_ANIMATIONS'
,p_lov=>'.'||wwv_flow_api.id(562737530366047618)||'.'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Static'
,p_cHeight=>1
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_api.id(869572400154599626)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(517887152483372817)
,p_name=>'P4000_ICONCLASS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(349883301202259937)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(756696232994321927)
,p_name=>'P4000_FA_SIZE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(517886366768372809)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Size'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Small;SMALL,Large;LARGE'
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_api.id(869572400154599626)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(873486298805520035)
,p_name=>'P4000_MODIFIER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(517886366768372809)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Modifier'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'STATIC2:',
'25 Percent;fam-25-percent,',
'50 Percent;fam-50-percent,',
'75 Percent;fam-75-percent,',
'100 Percent;fam-100-percent,',
'Arrow Down;fam-arrow-down,',
'Arrow Left;fam-arrow-left,',
'Arrow Right;fam-arrow-right,',
'Arrow Up;fam-arrow-up,',
'Blank;fam-blank,',
'Check;fam-check,',
'Circle;fam-circle,',
'Clock;fam-clock,',
'Ellipsis H;fam-ellipsis-h,',
'Ellipsis V;fam-ellipsis-v,',
'Heart;fam-heart,',
'Information;fam-information,',
'Minus;fam-minus,',
'Pause;fam-pause,',
'Play;fam-play,',
'Plus;fam-plus,',
'Sleep;fam-sleep,',
'Star;fam-star,',
'Stop;fam-stop,',
'Warning;fam-warning,',
'X;fam-x'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'None'
,p_cHeight=>1
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_api.id(869572400154599626)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(873486307070520036)
,p_name=>'P4000_MODIFIER_STATUS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(517886366768372809)
,p_use_cache_before_default=>'NO'
,p_item_default=>'fam-is-success'
,p_prompt=>'Status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'STATIC2:',
'Success;fam-is-success,',
'Warning;fam-is-warning,',
'Danger;fam-is-danger,',
'Info;fam-is-info,',
'Disabled;fam-is-disabled'))
,p_cHeight=>1
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_api.id(869572400154599626)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(349882921191259933)
,p_name=>'Cancel Enter'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4000_SEARCH'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.keyCode == 13'
,p_bind_type=>'bind'
,p_bind_event_type=>'keypress'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(349883091481259934)
,p_event_id=>wwv_flow_api.id(349882921191259933)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(349883416534259938)
,p_name=>'Show Icon Preview Dialog'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.dm-Search-result'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#icons'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(349883523325259939)
,p_event_id=>wwv_flow_api.id(349883416534259938)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var $j = apex.jQuery,',
'    iconClass = $j(this.triggeringElement).find(''.dm-Search-class'').text();',
'$s(''P4000_ICONCLASS'',iconClass);',
'$j("#icon_dialog").dialog({',
'    title: "Icon: " + iconClass',
'}).dialog("open");',
'apex.theme42demo.renderIconPreview();',
'$j(''#P4000_ICON_SIZE'').focus();'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(517886735740372813)
,p_name=>'Apply Modifier to Icon'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4000_ICON_SIZE,P4000_ANIMATION,P4000_ROTATE,P4000_MODIFIER,P4000_MODIFIER_STATUS'
,p_bind_type=>'live'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(517886876005372814)
,p_event_id=>wwv_flow_api.id(517886735740372813)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.theme42demo.renderIconPreview();'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(349884140544259945)
,p_name=>'Reset Icon Settings'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(349883989532259943)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(349884218574259946)
,p_event_id=>wwv_flow_api.id(349884140544259945)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4000_ANIMATION,P4000_ROTATE,P4000_MODIFIER'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(756697293099321937)
,p_event_id=>wwv_flow_api.id(349884140544259945)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s(''P4000_ICON_SIZE'',''null'');',
'apex.theme42demo.renderIconPreview();'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(714379453470623418)
,p_name=>'Toggle Modifier Status'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4000_MODIFIER'
,p_condition_element=>'P4000_MODIFIER'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(714379568314623419)
,p_event_id=>wwv_flow_api.id(714379453470623418)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4000_MODIFIER_STATUS'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(714379657356623420)
,p_event_id=>wwv_flow_api.id(714379453470623418)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4000_MODIFIER_STATUS'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(714379708387623421)
,p_event_id=>wwv_flow_api.id(714379453470623418)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4000_MODIFIER_STATUS'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(1515421837091817014)
,p_name=>'Open About Dialog'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(1515421727652817013)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(1515421977380817015)
,p_event_id=>wwv_flow_api.id(1515421837091817014)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(558385722004194470)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(340246582941216321)
,p_name=>'Toggle Icon Size'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4000_SIZE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(340246691636216322)
,p_event_id=>wwv_flow_api.id(340246582941216321)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var size = $v(''P4000_SIZE''),',
'    icons$ = $( ''#icons'' ),',
'    L_CLASS = ''force-fa-lg'';',
'if ( size === ''LARGE'' ) {',
'    icons$.addClass( L_CLASS );',
'} else {',
'    icons$.removeClass( L_CLASS );',
'}'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(756697066134321935)
,p_event_id=>wwv_flow_api.id(340246582941216321)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4000_FA_SIZE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$v(''P4000_SIZE'');'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(756696358795321928)
,p_name=>'Set Icon Size'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4000_FA_SIZE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(756696456005321929)
,p_event_id=>wwv_flow_api.id(756696358795321928)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s(''P4000_SIZE'',$v(''P4000_FA_SIZE''));',
'apex.theme42demo.renderIconPreview();',
''))
);
wwv_flow_api.component_end;
end;
/
