prompt --application/pages/page_00421
begin
--   Manifest
--     PAGE: 00421
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>421
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Navigation'
,p_alias=>'NAVIGATION2'
,p_step_title=>'Navigation'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(558266987012620477)
,p_step_template=>wwv_flow_api.id(2623327345562852400)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210419102725'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(606904609891638641)
,p_plug_name=>'Side Menu'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>This common navigation pattern is typically referred to as a <b>hamburger menu</b>, drawer menu, or tree navigation and is well suited for applications that have many navigation items, or require nested navigation. On small screens, you simply tap'
||' on the hamburger icon near the top left (or top right when using right-to-left languages) corner of your screen and the menu will slide out. You can make a selection and immediately navigate to the selected item.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(606904726197638642)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_api.id(606904609891638641)
,p_region_css_classes=>'dm-Hero-steps'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1922209187092703219)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><strong>Steps</strong></p>',
'',
'<ul>',
'  <li>Go to Shared Components &rarr; User Interface Attributes &rarr; Edit Desktop</li>',
'  <li>Scroll to Navigation Menu and set <b>Position</b> to Side</li>',
'  <li>Set the <b>List Template</b> to Side Navigation Menu</li>',
'</ul>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(606905024109638645)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_api.id(606904609891638641)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:margin-top-md'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.DISP_TEMPLATE_OPTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'LIST'
,p_attribute_04=>'Side Navigation Menu'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1928343924705643460)
,p_plug_name=>'Side Menu Sample'
,p_parent_plug_id=>wwv_flow_api.id(606904609891638641)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="dm-Icon dm-Icon--page side-nav-one-column"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1101:&APP_SESSION.'',''Page with Side Menu'')" type="button">View Sample</span>',
'</button>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1928343394258643448)
,p_plug_name=>'Tab Menu'
,p_region_name=>'standard'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>Tabs are another very common navigation pattern for small screen devices.  These tabs will automatically position themselves near the top or bottom of the screen depending on the device screensize.  On small screens, the tabs menu will be displaye'
||'d at the bottom of the screen allowing for comfortable use with one hand. On larger screens, the tabs will be near the top of the screen.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(606904861448638643)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_api.id(1928343394258643448)
,p_region_css_classes=>'dm-Hero-steps'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1922209187092703219)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><strong>Steps</strong></p>',
'',
'<ul>',
'  <li>Go to Shared Components &rarr; User Interface Attributes &rarr; Edit Desktop</li>',
'  <li>Scroll to Navigation Menu and set <b>Position</b> to Top</li>',
'  <li>Set the <b>List Template</b> to Top Navigation Tabs</li>',
'</ul>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(606904972531638644)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_api.id(1928343394258643448)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:margin-top-md'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.DISP_TEMPLATE_OPTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'LIST'
,p_attribute_04=>'Top Navigation Tabs'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1928344381816643460)
,p_plug_name=>'Tab Menu Sample'
,p_parent_plug_id=>wwv_flow_api.id(1928343394258643448)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="dm-Icon dm-Icon--page top-nav-one-column"></span>',
'<button class="t-Button t-Button--icon t-Button--iconRight" onclick="apex.theme42demo.openMobileSamplePage(''f?p=&APP_ID.:1115:&APP_SESSION.'',''Page with Tabs Menu'')" type="button">View Sample</span>',
'</button>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2980695377329534171)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4400329440104512860)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>Navigation within your application is critical to its success. When building applications for mobile, it is important to keep in mind the complexity of the application you are developing and which navigation pattern makes most sense for your speci'
||'fic use case. Here are two of the mobile-friendly navigation patterns available in Universal Theme and when to pick one over the other.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
