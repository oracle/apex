prompt --application/pages/page_02010
begin
--   Manifest
--     PAGE: 02010
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>2010
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Why Migrate'
,p_alias=>'WHY-MIGRATE'
,p_step_title=>'Why Migrate - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(431032219555845082)
,p_step_template=>wwv_flow_api.id(2623327345562852400)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20210224063007'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(430899132855155802)
,p_plug_name=>'Cons'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Because migrating to Universal Theme, from older themes, will take development effort and significant time reviewing migrated pages, you should consider the downsides of migrating before moving forward.</p>',
'<ol>',
'  <li>',
'  <p><strong>Different UI</strong>',
'    <br />While Universal Theme is designed to be fully accessible and aesthetically pleasing, users who are completely comfortable with the older theme''s UI, may not immediately like the new theme. Further, training material developed in-house will '
||'need to be upgraded as the look of the pages will undoubtedly change significantly.</p>',
'    <p>This is not a technical issue, since Universal Theme is not a departure from the traditional APEX workflow, but an enhancement on top of your existing processes. Application content, such as pages, regions, buttons, and items, will not be chan'
||'ged as a result of migrating, other than their appearance.</p></li>',
'    <li><p><strong>Regressions</strong>',
'      <br />Some templates carried over from previous themes may not have strict <em>one-to-one</em> equivalents. Some of your custom CSS/JS modifications that were not directly supported in APEX may also no longer work as expected on your pages. The'
||'se and other issues are covered in <strong>Post-Migration Tasks</strong>, <strong>Best Practices</strong>, and <strong>Common Issues After Upgrading</strong> sections below.</p></li>',
'    <li><p><strong>Custom Themes / Templates</strong>',
'        <br />If you have developed a completely custom theme, then migrating to Universal Theme may require significant effort. Similarly, if you defined custom templates then you may find difficulties finding a similar template in the Universal The'
||'me. However, you may find using the new template options and theme roller will make many of your customizations redundant. If not, you will need to manually define custom templates and reapply your custom CSS and HTML post-migration.</p></li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(430899211618155803)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(431021834304724247)
,p_plug_name=>'Pros'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Universal Theme has a number of new features, improvements, and optimizations when compared to themes provided with previous releases of Application Express.  Additionally, Universal Theme utilizes several key UI features of Application Express 5 '
||'and provides a number of new Templates and Template Options that greatly expand the customizability of your application''s UI.</p>',
'',
'<p>Universal Theme provides improvements in almost every facet of defining the User Interface of your applications, and there a number of reasons why it is important to migrate to it immediately.  However, you must first understand your users and see'
||' whether a drastic change in User Interface is appropriate.</p>',
'<p>',
'Below is a quick fact-by-fact look at the many reasons for why you should migrate, and the few reasons why you may not want to migrate to Universal Theme.</p>',
'',
'<h3>Improvements</h3>',
'<ol>',
'<li><strong>Cleaner Templates</strong>',
'<p>Universal Theme has fewer, but more capable templates which can be customized with Template Options. It is quicker and easier to modify the presentation by changing Template Options, rather than by having to select a new template. Template Options'
||' allow for additional visual flourishes and, in some cases, new functionality.',
'<img src="#THEME_IMAGES#demo/img/Image_0.png" /></p></li>',
'',
'<li><strong>Improved Grid Support and Responsive Behavior</strong>',
'<p>',
'Theme 25 introduced Grid Layout support in APEX 4.2, but used a fixed grid which was not easily customizable. Universal Theme introduces a flexible, fluid grid system which can be nested many times over, and is based off the Bootstrap grid.<img src="'
||'#THEME_IMAGES#demo/img/Image_1.png" />',
'</p></li>',
'',
'<li><strong>Mobile Ready</strong>',
'',
'<p>Because of Universal Theme''s improved grid support, applications are responsive out-of-the-box. Therefore, they run well on any mobile device running a modern browser. For example, you will notice that tapping is significantly sped up (no delay in'
||' clicking) in Universal Theme apps compared with legacy ones. </p></li>',
'',
'<li><strong>Future-proofing</strong>',
'',
'<p>While legacy and older themes are supported in APEX 5, Universal Theme is the primary theme. With future releases of Application Express you will be be able to readily upgrade the Universal Theme to take advantages of the new functionality provide'
||'d. Migrating to Universal Theme is a simple means of ensuring your apps provide the most modern and up-to-date user experience for your users.</p></li>',
'</ol>',
'',
'<h3>New Features</h3>',
'<ol>',
'<li><strong>Theme Roller</strong>',
'<p>Older themes required you to to stick with one color and one set of styling. The only means of having your own styling was to override the defaults with CSS or switch to a new theme entirely. Universal Theme addresses this pain point by allowing y'
||'ou to quickly generate a new style for your app, using a GUI.',
'<div class=''two-images-one-row''><img src="#THEME_IMAGES#demo/img/Image_2.png" /><img src="#THEME_IMAGES#demo/img/Image_3.png" /></div>',
'</p></li>',
'',
'<li><strong>Navigation Lists</strong>',
'<p>In Universal theme, you now have the choice between using a top or side navigation menu. Older themes only supported tabs, which always consumed vertical screen real estate. Placing the menu on the side, and allowing it to be collapdsed, works bet'
||'ter for most applications, especially when displayed on widescreen monitors.',
'<img src="#THEME_IMAGES#demo/img/Image_4.png" />',
'</p></li>',
'',
'<li><strong>New UI Components</strong>',
'<p>Universal Theme has built-in templates for a variety of common UI components which are not available in other themes. For example, there are templates for easily creating carousels, tabs, menus, cards, and much more.',
'<img src="#THEME_IMAGES#demo/img/Image_5.png" />',
'</p></li>',
'',
'<li><strong>Maximize/Restore</strong>',
'',
'<p>Universal Theme enables Interactive Reports, Classic Reports, and Standard Regions to be "maximized". With the maximize button template option enabled, end users can now focus on a single region, and scroll through large amounts of data without se'
||'eing other content on the page. This makes it far easier for end users to review these large regions which are often very wide and long. Older themes do not have support for this feature.',
'<img src="#THEME_IMAGES#demo/img/Image_6.png" />',
'</p></li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(431025302387724258)
,p_plug_name=>'Introduction'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This guide shows how to convert to the Universal Theme in Application Express 5. It covers:</p>',
'',
'<ul>',
'    <li>The Pro and Cons of Universal Theme</li>',
'    <li>Migration Steps (Theme Switch Wizard)</li>',
'    <li>Post-migration</li>',
'    <li>Best practices</li>',
'    <li>Common problems and solutions</li>',
'</ul>',
'',
'<p>Please note that this guide assumes you have a working knowledge of Application Express fundamentals.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(431025822045724260)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
);
wwv_flow_api.component_end;
end;
/
