prompt --application/pages/page_02030
begin
--   Manifest
--     PAGE: 02030
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>2030
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Post Migration'
,p_alias=>'POST-MIGRATION'
,p_step_title=>'Post Migration - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(431032219555845082)
,p_step_template=>wwv_flow_api.id(2623327345562852400)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20210224063007'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(435220508486129008)
,p_plug_name=>'Post Migration'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Unlike the previous steps, the following tasks do not have to be completed in any particular order.',
'<br />Instead, it is advised that you carry them out before making new enhancements to your application, to ensure that any issues relating to the migration are not complicated by changes in functionality.</p>',
'<ol>',
'  <li>',
'    <p>While it is not necessary to remove your older theme for your freshly migrated app to work, your older theme no longer serves any functional purpose.',
'    <br />If you haven''t created any custom templates in your older theme (which you''d want to copy over), or if you don''t need to keep the older theme for reference, consider deleting the older theme.</p>',
'  </li>',
'  <li>',
'    <p>Ensure that the list items for <strong>Navigation Menu</strong> are correct, and that the <em>Current For</em> attributes are properly set.',
'    <br />Your tabs will be converted into a list format. If the current for attributes are not set correctly, the navigation links will not be selected when you navigate to each of the pages. </p>',
'    <p><img src="#THEME_IMAGES#demo/img/Image_16.png"/></p>',
'  </li>',
'  <li>',
'    <p>Decide if you want to stick with <strong>Side Navigation</strong> or change to the <strong>Top Menu </strong>as the application''s primary means of navigation.</p>',
'    <p>If you choose to stick with side navigation, it is recommended to select <em>Navigation Icons</em> for each menu entry, otherwise each page will have the same default page icon.',
'      <br />By going to Shared Components > Navigation Menu > List Entry, you can choose from a variety of pre-built icons, allowing you to choose the best match for each page type.',
'    <br />Please note that these icons will only appear if you are using side navigagtion.</p>',
'    <p>To change to <strong>Top Menu</strong> you will need to navigate to Shared Component > User Interface Attributes > Edit Universal Theme. Then change <strong>Position</strong> to <em>Top</em> and <strong>List Template</strong> to <em>Top Menu N'
||'avigation</em>, and then apply changes.</p>',
'    <p><img src="#THEME_IMAGES#demo/img/Image_17.png"/></p>',
'  </li>',
'  <li>',
'    <p><img src="#THEME_IMAGES#demo/img/Image_18.png"/></p>',
'  </li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(435221066689129009)
,p_plug_name=>'Best Practices'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>While most migrations will be relatively painless, there is no set path for how dealing with issues arise as a result of this change. Consider the following pointers for how to exhaustively find and resolve such problems in your new Universal Them'
||'e Application.</p>',
'<ol>',
'  <li><p><strong>Visually review the migrated application.</strong><br />',
'    - Run each page of your application, or at least a good cross section of different pages to make sure that there are no obvious display issues.<br />',
'    - If you have installed your original application under a different Application Id, perform side-by-side comparisons on a wide selection of pages, to ensure different page elements, such as buttons, and the overall page layout are not too diverge'
||'nt.</p>',
'  </li>',
'  <li><p><strong>Check non-standard components.</strong><br />',
'    - Be sure to check any pages where you implemented your own JavaScript to ensure the page still operates correctly. Many of the default class names for elements were changed, and some of the inline scripts that you have augmented your pages with '
||'may no longer be needed. <br />',
'    - Review any pages or templates where you have added any CSS libraries. If necessary, reapply the CSS libraries into the migrated application.<br />',
'    - Review all plug-ins used throughout your application to ensure they are still functioning correctly. Some plug-ins from third parties may not work correctly with Application Express 5. If so, you may need to remove the plug-in or search for an '
||'APEX 5.0 compatible plug-in.</p>',
'  </li>',
'  <li><p><strong>Ask your users to test your app.</strong><br />',
'    - After testing the application yourself, the next step is to ask your users to use the new migrated application to ensure they are comfortable with the new user interface, and can readily use the application.<br />',
'    - Determine from your end users if any end user training material or application documentation needs to be revised before releasing the new application into production.</p>',
'  </li>',
'</ol>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(435223507032129017)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(589350585091837147)
,p_plug_name=>'Post Debugging'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>Once you have brought your application up to a "functional" state, you should consider a few more simple improvements you can readily make to your application, so that you can take full advantage of the new features in both Application Express 5 a'
||'nd Universal Theme. For example, you may want to prototype some different layout options, with a select group of users, to see if existing pages can be readily improved by simply changing some Template Options.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
