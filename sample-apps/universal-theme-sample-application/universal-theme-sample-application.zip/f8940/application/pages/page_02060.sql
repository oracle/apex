prompt --application/pages/page_02060
begin
--   Manifest
--     PAGE: 02060
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>2060
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Migrating from jQuery Mobile'
,p_alias=>'MIGRATING-FROM-JQUERY-MOBILE'
,p_step_title=>'Migrating from jQuery Mobile'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(431032219555845082)
,p_step_template=>wwv_flow_api.id(2623327345562852400)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20210224063007'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(606904283719638637)
,p_plug_name=>'Mobile UI Patterns'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>Here are a number of Mobile UI Patterns you can follow as you build your next mobile app.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(790512378531235910)
,p_plug_name=>'Mobile UI Patterns'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'t-MediaList--showIcons:u-colors'
,p_plug_template=>wwv_flow_api.id(2623330321607852408)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(608043492397034627)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(618966256865274517)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1693511225138594619)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>Here are a few tips and best practices for transitioning your applications from the jQuery Mobile user interface to the Universal Theme.  </p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1693511390727594620)
,p_plug_name=>'jQuery Mobile is no longer supported'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:margin-bottom-lg'
,p_plug_template=>wwv_flow_api.id(591654834181983844)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>Please note that jQuery Mobile applications are desupported.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1693511480697594621)
,p_plug_name=>'Responsive Design and Mobile UI Patterns'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Universal Theme is designed to be responsive, so it will look and feel great on any screen size device. However, the patterns you use for your application may change depending on the your use cases. Here are some commonly asked questions that may '
||'provide some guidance as you build your next app.</p>',
'',
'<ul class="dm-UL">',
'  <li>',
'      <p><strong>How can I migrate my jQuery Mobile app to Universal Theme?</strong><br />',
'      For most apps, perhaps the simplest solution may be to start with a blank slate using Universal Theme.  Identify the key flows of your mobile app, and then reimagine them using all the features and functionality of Universal Theme.  This may be'
||' the perfect opportunity to experiment with the capabilities of Universal Theme and how you can use them to build an incredible small screen experience.</p>',
'  </li>',
'  <li>',
'      <p><strong>Should I build a separate app for mobile and desktop?</strong><br />',
'      This may be unnecessary for most cases. Unless your app will be primarily used on small screen devices, it may be better to optimize the UI of your app for the mobile use case rather than creating a separate app.  However, if you have a very sp'
||'ecific mobile use case, then by all means, build a separate app that is mobile-optimized and applies mobile UI patterns to provide a great small screen experience.</p>',
'  </li>',
'  <li>',
'      <p><strong>What are some things I should keep in mind as I develop my next mobile app?</strong><br />',
'      That''s a great question! First -- who are your users? What type of devices do they use? What is the primary usecase of your application? What is the setting in which your application is used? There are several things to consider before you writ'
||'e a single line of code. The more you understand your users and use cases, the more successful you will be with your APEX app.</p>',
'  </li>',
'</ul>',
'     '))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11053752011746459047)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.component_end;
end;
/
