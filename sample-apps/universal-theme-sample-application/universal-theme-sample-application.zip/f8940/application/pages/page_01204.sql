prompt --application/pages/page_01204
begin
--   Manifest
--     PAGE: 01204
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>8940
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>1204
,p_user_interface_id=>wwv_flow_api.id(821272323468330288)
,p_name=>'Region - Button Container'
,p_alias=>'BUTTON-CONTAINER-REGION'
,p_step_title=>'Button Container - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(405064482015020227)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'TIM'
,p_last_upd_yyyymmddhh24miss=>'20210224063007'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405102577413686799)
,p_plug_name=>'Use Cases'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405103093799686799)
,p_plug_name=>'Advanced'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405103508324686800)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>'<p>Button Groups are a series of buttons that appear together to make a single conrol.  You can create button groups in APEX using the button component, or as a customized radio group page item.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405104083056686801)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1082434711915925186)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(1725934084712570512)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(2623334730651852421)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405104570099686801)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3052412050530173647)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405110226728724407)
,p_plug_name=>'Using Page Buttons'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>You can turn a set of buttons into a button group simply by modifying the template options. Follow these instructions to create a simple button group of the following three buttons.</p>',
'<div class="dm-Hero-steps margin-bottom-md">',
'<strong>Step 1.</strong> Create three buttons in the same button position<br>',
'<strong>Step 2.</strong> Update each of the buttons'' Template Options as follows<br>',
'<ol>',
'  <li>Button A: set <em>Button Set</em> to <b>First Button</b></li>',
'  <li>Button B: set <em>Button Set</em> to <b>Inner Button</b></li>',
'  <li>Button C: set <em>Button Set</em> to <b>Last Button</b></li>',
'</ol>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(405104970129686802)
,p_plug_name=>'Additional Example'
,p_parent_plug_id=>wwv_flow_api.id(405110226728724407)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:margin-top-lg'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>You can have any number of buttons within a button group.  Here is an example of a music player toolbar styled the same method.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2152193383509275422)
,p_plug_name=>'Using Page Items'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(873087052820635270)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>You can also style the <strong>radio button</strong> or <strong>checkbox</strong> items to appear as a Button Group. This is particularly useful when you want to use store the selection in Session State and if you want to Dynamic Actions to perfor'
||'m some client side behavior as you interact with the control.</p>',
'<p>For example, in several Packaged Apps, this technique is used to switch between different displays of the same data.</p>',
'<p>Follow the instrutions below to convert a Radio Group item into a Button Group.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2152194026178275429)
,p_plug_name=>'Step 1'
,p_parent_plug_id=>wwv_flow_api.id(2152193383509275422)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1922209187092703219)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dm-Hero-steps">',
'<strong>Step 1.</strong> Create a Radio Group item and set the following properties:<br>',
'<ol>',
'  <li>Set <em>Number of Columns</em> to the number of buttons you want to have in the button group. In this example, it is set to 3.</li>',
'  <li>Under <strong>List of Values</strong>, make sure that <em>Display Extra Values</em> and <em>Display Null Value</em> are set to <strong>No</strong></li>',
'</ol>',
'<p>After competing this step, you should have a button group that looks like the item below.</p>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2152194171836275430)
,p_plug_name=>'Step 2'
,p_parent_plug_id=>wwv_flow_api.id(2152193383509275422)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1922209187092703219)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dm-Hero-steps">',
'<p><strong>Step 2.</strong> Update the Radio Group item''s Template Options and set <em>Item Group Display</em> to <strong>Display as Pill Button</strong></p>',
'<p>That''s it. Your Radio Group item will now appear as a Button Group.</p>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(405111569535724409)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(405110226728724407)
,p_button_name=>'BTN_GRP_A'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pillStart'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Button A'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-angle-left'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2152192663941275415)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(405110226728724407)
,p_button_name=>'BTN_GRP_B'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pill'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Button B'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-angle-left'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(405111907244724409)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(405110226728724407)
,p_button_name=>'BTN_GRP_C'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pillEnd'
,p_button_template_id=>wwv_flow_api.id(2623334346116852418)
,p_button_image_alt=>'Button C'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-angle-right'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2152192730436275416)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(405104970129686802)
,p_button_name=>'BTN_GRP_2A'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pillStart'
,p_button_template_id=>wwv_flow_api.id(900079107762114354)
,p_button_image_alt=>'Previous'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-step-backward'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2152192829930275417)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(405104970129686802)
,p_button_name=>'BTN_GRP_2B'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pill'
,p_button_template_id=>wwv_flow_api.id(900079107762114354)
,p_button_image_alt=>'Rewind'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-backward'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2152193196109275420)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(405104970129686802)
,p_button_name=>'BTN_GRP_2C'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pill'
,p_button_template_id=>wwv_flow_api.id(900079107762114354)
,p_button_image_alt=>'Play'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2152193271849275421)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(405104970129686802)
,p_button_name=>'BTN_GRP_2D'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pill'
,p_button_template_id=>wwv_flow_api.id(900079107762114354)
,p_button_image_alt=>'Stop'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2152192959102275418)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(405104970129686802)
,p_button_name=>'BTN_GRP_2E'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pill'
,p_button_template_id=>wwv_flow_api.id(900079107762114354)
,p_button_image_alt=>'Forward'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-forward'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2152193034453275419)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_api.id(405104970129686802)
,p_button_name=>'BTN_GRP_2F'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pillEnd'
,p_button_template_id=>wwv_flow_api.id(900079107762114354)
,p_button_image_alt=>'Next'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-step-forward'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(1917874743798315882)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_api.id(405104083056686801)
,p_button_name=>'TEMPLATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(633800930240492718)
,p_button_image_alt=>'Button Template'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:6307:&SESSION.:button:&DEBUG.:RP::'
,p_icon_css_classes=>'fa-button'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2152193751719275426)
,p_name=>'P1204_RADIO_A'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2152194026178275429)
,p_item_default=>'A'
,p_prompt=>'Radio Group'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Option A;A,Option B;B,Option C;C'
,p_field_template=>wwv_flow_api.id(869572400154599626)
,p_item_template_options=>'#DEFAULT#:margin-top-md'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'3'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2152194255538275431)
,p_name=>'P1204_RADIO_B'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2152194171836275430)
,p_item_default=>'A'
,p_prompt=>'Radio Button Group'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Option A;A,Option B;B,Option C;C'
,p_field_template=>wwv_flow_api.id(869572400154599626)
,p_item_template_options=>'#DEFAULT#:margin-top-md:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'3'
,p_attribute_02=>'NONE'
);
wwv_flow_api.component_end;
end;
/
