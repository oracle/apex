prompt --application/pages/page_01916
begin
--   Manifest
--     PAGE: 01916
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>1916
,p_user_interface_id=>wwv_flow_api.id(1319173717720724629)
,p_name=>'Inline Drawer'
,p_alias=>'INLINE-DRAWER'
,p_step_title=>'Inline Drawer'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(902965876267414568)
,p_step_template=>wwv_flow_api.id(3121228739815246741)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_upd_yyyymmddhh24miss=>'20211005091608'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4753590623734799563)
,p_plug_name=>'Demo'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4753593172472811664)
,p_plug_name=>'Auto Width'
,p_region_name=>'drawer_auto'
,p_region_template_options=>'#DEFAULT#:js-dialog-nosize:js-dialog-class-t-Drawer--pullOutStart'
,p_plug_template=>wwv_flow_api.id(709845915981696823)
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>'Set the Template Option Size to "None".'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4753594493461812820)
,p_plug_name=>'Fixed Width'
,p_region_name=>'drawer_fixed'
,p_region_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--md:js-dialog-class-t-Drawer--pullOutEnd'
,p_plug_template=>wwv_flow_api.id(709845915981696823)
,p_plug_display_sequence=>70
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source=>'This is a drawer that is using the Extra Large size.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9195428973341882664)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3550313444782567988)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(9195429240148885656)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>An <strong>inline drawer</strong> displays a region on the current page within a modal dialog that pulls out from the sides of the screen. </p>',
'<p class="dm-Hero-steps">Create a region, set its "Position" attribute to Inline Dialogs, and use <strong>Inline Drawer</strong> as its Region template.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12044919284635218570)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(3121236124904246762)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(709859116482560378)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(4753590623734799563)
,p_button_name=>'OPEN_AUTO_SIZE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3121235740369246759)
,p_button_image_alt=>'Inline Drawer with Auto Size'
,p_button_redirect_url=>'javascript:openModal(''drawer_auto'')'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(709859500458560375)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(4753590623734799563)
,p_button_name=>'OPEN_FIXED'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(3121235740369246759)
,p_button_image_alt=>'Inline Drawer with Fixed Size'
,p_button_redirect_url=>'javascript:openModal(''drawer_fixed'')'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(709860250616560374)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(4753593172472811664)
,p_button_name=>'CANCEL_1'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3121235740369246759)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'javascript:closeModal(''dialog_fixed'')'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(709861609806560371)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(4753594493461812820)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3121235740369246759)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'javascript:closeModal(''dialog_fixed'')'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(709862002322560369)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(4753594493461812820)
,p_button_name=>'OK'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3121235740369246759)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'OK'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(709860603517560374)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(4753593172472811664)
,p_button_name=>'OK_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3121235740369246759)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'OK'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.component_end;
end;
/
