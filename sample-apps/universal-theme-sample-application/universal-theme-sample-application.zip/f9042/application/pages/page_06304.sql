prompt --application/pages/page_06304
begin
--   Manifest
--     PAGE: 06304
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>6304
,p_user_interface_id=>wwv_flow_api.id(1319173717720724629)
,p_name=>'Content Modifiers'
,p_alias=>'CONTENT-MODIFIERS'
,p_step_title=>'Content Modifiers - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.class,',
'.class-value,',
'.class-desc {',
'    display: inline-block;',
'    font-size: 12px;',
'    font-family: ''Menlo'',''Consolas'',monospace;',
'}',
'.class {',
'    color: #9C27B0;',
'}',
'.class.tag {',
'    padding: 4px 8px;',
'    background-color: #FFF;',
'    border-radius: 2px;',
'    box-shadow: inset rgba(225, 190, 231, .25) 0 0 0 1px;',
'}',
'.class-value {',
'    color: #008676;',
'    min-width: 40px;',
'}',
'.class-var {',
'    font-weight: bold;',
'    color: #008676;',
'}',
'.dm-Report--doc {',
'    background: #FFF;',
'    border: 1px solid rgba(0,0,0,.05);',
'}',
'.dm-Report--doc th, ',
'.dm-Report--doc td {',
'    padding: 8px;',
'    min-height: 32px;',
'    background-color: transparent;',
'    border-width: 0 0 1px 0;',
'    border-style: solid;',
'    border-color: rgba(0,0,0,.05);',
'}',
'.dm-Report--doc td {',
'    vertical-align: top;',
'}',
'.dm-Report--doc tr:last-child td {',
'    border-bottom-width: 0;',
'}',
'.dm-Report--doc .class {',
'    min-width: 40px;',
'}',
'.dm-Report--doc .class-desc {',
'    width: 48px;',
'    text-align: right;',
'    color: rgba(0,0,0,.55);',
'    border-radius: 2px;',
'}'))
,p_step_template=>wwv_flow_api.id(3121228739815246741)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'VMORNEAU'
,p_last_upd_yyyymmddhh24miss=>'20210922150713'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1083495694381067445)
,p_plug_name=>'Accessibility'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>These classes can help you build more accessible apps and help you design a more usable experience for all users.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1083497126208067459)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_api.id(1083495694381067445)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-VisuallyHidden</span></td><td>This will make any text visually hidden, but still accessible for screen readers and other assistive technologies.</td></tr>',
'  </tbody>',
'</table>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1083496713093067455)
,p_plug_name=>'Text Transform'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>These classes are useful when you want to control the text case for a given component. For example, an input field where you want characters to display in upper case. </p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1083496735816067456)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_api.id(1083496713093067455)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-text<span class="class-value">Upper</span></span></td><td class="u-textUpper">Sets the text to use all uppercase</td></tr>',
'    <tr><td><span class="class">u-text<span class="class-value">Lower</span></span></td><td class="u-textLower">Sets the text to use all lowercase</td></tr>',
'    <tr><td><span class="class">u-text<span class="class-value">InitCap</span></span></td><td class="u-textInitCap">Sets the first letter in each word to use uppercase</td></tr>',
'  </tbody>',
'</table>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1083496885038067457)
,p_plug_name=>'Text Style'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Use these classes as simple modifiers to control the text style of a given component. For example, you may want to use the <span class="class tag">u-bold</span> to make the text of a button have a stronger weight.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1083497006032067458)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_api.id(1083496885038067457)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-bold</span></td><td class="u-bold">Bolds text</td></tr>',
'    <tr><td><span class="class">u-italics</span></td><td class="u-italics">Italicize text</td></tr>',
'    <tr><td><span class="class">u-underline</span></td><td class="u-underline">Underlines text</td></tr>',
'    <tr><td><span class="class">u-fixedFont</span></td><td class="u-fixedFont">Use a fixed-letter-space font</td></tr>',
'  </tbody>',
'</table>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1565761099769398363)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(2420110581345097560)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1573451762944293862)
,p_plug_name=>'Introduction'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>You can use the following utility classes anywhere in your app to fine-tune the layout of your page and components. For most Oracle APEX components, you can simply populate the <b>CSS Classes</b> property to apply these modifiers to your page comp'
||'onents.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2171713371178543962)
,p_plug_name=>'Text Alignment'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>These classes are direction aware, meaning the text direction will be based on the direction of the language. For example, text using the <span class="class tag">u-text<span class="class-var">Start</span></span> class will align text to the left f'
||'or Left-to-Right languages, and will align text to the right for Right-to-Left languages.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2669300606773569069)
,p_plug_name=>'Classes'
,p_parent_plug_id=>wwv_flow_api.id(2171713371178543962)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="u-Report u-Report--staticBG u-Report--stretch dm-Report--doc">',
'  <thead>',
'    <tr>',
'      <th style="width: 30%" class="u-textStart">Class</th>',
'      <th class="u-textStart">Description</th>',
'    </tr>',
'  </thead>',
'  <tbody>',
'    <tr><td><span class="class">u-text<span class="class-value">Start</span></span></td><td class="u-textStart">Align text to the start of the container</td></tr>',
'    <tr><td><span class="class">u-text<span class="class-value">Center</span></span></td><td class="u-textCenter">Align text to the center of the container</td></tr>',
'    <tr><td><span class="class">u-text<span class="class-value">End</span></span></td><td class="u-textEnd">Align text to the end of the container</td></tr>',
'  </tbody>',
'</table>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5292480070172941370)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(3121236124904246762)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.component_end;
end;
/
