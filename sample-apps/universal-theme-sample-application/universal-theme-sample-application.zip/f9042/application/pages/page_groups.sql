prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 9042
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(902965876267414568)
,p_group_name=>'Components'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(1056168381265014818)
,p_group_name=>'Design'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(928933613808239423)
,p_group_name=>'Migration Guide'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(1211541318767601389)
,p_group_name=>'Tools and Utilities'
);
wwv_flow_api.component_end;
end;
/
