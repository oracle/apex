prompt --application/pages/page_01204
begin
--   Manifest
--     PAGE: 01204
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>1204
,p_user_interface_id=>wwv_flow_api.id(1319173717720724629)
,p_name=>'Region - Button Container'
,p_alias=>'BUTTON-CONTAINER-REGION'
,p_step_title=>'Button Container - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(902965876267414568)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_upd_yyyymmddhh24miss=>'20211005091607'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(903004902577081141)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Button Groups are a series of buttons that appear together to make a single conrol.  You can create button groups in APEX using the button component, or as a customized radio group page item.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(903005477309081142)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(3121236124904246762)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(903005964352081142)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3550313444782567988)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(903011620981118748)
,p_plug_name=>'Using Page Buttons'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>You can turn a set of buttons into a button group simply by modifying the template options. Follow these instructions to create a simple button group of the following three buttons.</p>',
'<div class="dm-Hero-steps margin-bottom-md">',
'<strong>Step 1.</strong> Create three buttons in the same button position<br>',
'<strong>Step 2.</strong> Update each of the buttons'' Template Options as follows<br>',
'<ol>',
'  <li>Button A: set <em>Button Set</em> to <b>First Button</b></li>',
'  <li>Button B: set <em>Button Set</em> to <b>Inner Button</b></li>',
'  <li>Button C: set <em>Button Set</em> to <b>Last Button</b></li>',
'</ol>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(903006364382081143)
,p_plug_name=>'Additional Example'
,p_parent_plug_id=>wwv_flow_api.id(903011620981118748)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:margin-top-lg'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>You can have any number of buttons within a button group.  Here is an example of a music player toolbar styled the same method.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2650094777761669763)
,p_plug_name=>'Using Page Items'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>You can also style the <strong>radio button</strong> or <strong>checkbox</strong> items to appear as a Button Group. This is particularly useful when you want to use store the selection in Session State and if you want to Dynamic Actions to perfor'
||'m some client side behavior as you interact with the control.</p>',
'<p>For example, in several Packaged Apps, this technique is used to switch between different displays of the same data.</p>',
'<p>Follow the instrutions below to convert a Radio Group item into a Button Group.</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2650095420430669770)
,p_plug_name=>'Step 1'
,p_parent_plug_id=>wwv_flow_api.id(2650094777761669763)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(2420110581345097560)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dm-Hero-steps">',
'<strong>Step 1.</strong> Create a Radio Group item and set the following properties:<br>',
'<ol>',
'  <li>Set <em>Number of Columns</em> to the number of buttons you want to have in the button group. In this example, it is set to 3.</li>',
'  <li>Under <strong>List of Values</strong>, make sure that <em>Display Extra Values</em> and <em>Display Null Value</em> are set to <strong>No</strong></li>',
'</ol>',
'<p>After competing this step, you should have a button group that looks like the item below.</p>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2650095566088669771)
,p_plug_name=>'Step 2'
,p_parent_plug_id=>wwv_flow_api.id(2650094777761669763)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(2420110581345097560)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="dm-Hero-steps">',
'<p><strong>Step 2.</strong> Update the Radio Group item''s Template Options and set <em>Item Group Display</em> to <strong>Display as Pill Button</strong></p>',
'<p>That''s it. Your Radio Group item will now appear as a Button Group.</p>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(903012963788118750)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(903011620981118748)
,p_button_name=>'BTN_GRP_A'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pillStart'
,p_button_template_id=>wwv_flow_api.id(3121235740369246759)
,p_button_image_alt=>'Button A'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-angle-left'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2650094058193669756)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(903011620981118748)
,p_button_name=>'BTN_GRP_B'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pill'
,p_button_template_id=>wwv_flow_api.id(3121235740369246759)
,p_button_image_alt=>'Button B'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-angle-left'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(903013301497118750)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(903011620981118748)
,p_button_name=>'BTN_GRP_C'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pillEnd'
,p_button_template_id=>wwv_flow_api.id(3121235740369246759)
,p_button_image_alt=>'Button C'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-angle-right'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2650094124688669757)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(903006364382081143)
,p_button_name=>'BTN_GRP_2A'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pillStart'
,p_button_template_id=>wwv_flow_api.id(1397980502014508695)
,p_button_image_alt=>'Previous'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-step-backward'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2650094224182669758)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_api.id(903006364382081143)
,p_button_name=>'BTN_GRP_2B'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pill'
,p_button_template_id=>wwv_flow_api.id(1397980502014508695)
,p_button_image_alt=>'Rewind'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-backward'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2650094590361669761)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_api.id(903006364382081143)
,p_button_name=>'BTN_GRP_2C'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pill'
,p_button_template_id=>wwv_flow_api.id(1397980502014508695)
,p_button_image_alt=>'Play'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2650094666101669762)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_api.id(903006364382081143)
,p_button_name=>'BTN_GRP_2D'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pill'
,p_button_template_id=>wwv_flow_api.id(1397980502014508695)
,p_button_image_alt=>'Stop'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2650094353354669759)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_api.id(903006364382081143)
,p_button_name=>'BTN_GRP_2E'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pill'
,p_button_template_id=>wwv_flow_api.id(1397980502014508695)
,p_button_image_alt=>'Forward'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-forward'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(2650094428705669760)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_api.id(903006364382081143)
,p_button_name=>'BTN_GRP_2F'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pillEnd'
,p_button_template_id=>wwv_flow_api.id(1397980502014508695)
,p_button_image_alt=>'Next'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-step-forward'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2650095145971669767)
,p_name=>'P1204_RADIO_A'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2650095420430669770)
,p_item_default=>'A'
,p_prompt=>'Radio Group'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Option A;A,Option B;B,Option C;C'
,p_field_template=>wwv_flow_api.id(1367473794406993967)
,p_item_template_options=>'#DEFAULT#:margin-top-md'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'3'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(2650095649790669772)
,p_name=>'P1204_RADIO_B'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(2650095566088669771)
,p_item_default=>'A'
,p_prompt=>'Radio Button Group'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Option A;A,Option B;B,Option C;C'
,p_field_template=>wwv_flow_api.id(1367473794406993967)
,p_item_template_options=>'#DEFAULT#:margin-top-md:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'3'
,p_attribute_02=>'NONE'
);
wwv_flow_api.component_end;
end;
/
