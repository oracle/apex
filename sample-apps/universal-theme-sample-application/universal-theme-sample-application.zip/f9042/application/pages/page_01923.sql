prompt --application/pages/page_01923
begin
--   Manifest
--     PAGE: 01923
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>1923
,p_user_interface_id=>wwv_flow_api.id(1319173717720724629)
,p_name=>'Region Display Selector'
,p_alias=>'REGION-DISPLAY-SELECTOR'
,p_step_title=>'Region Display Selector'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(1056168381265014818)
,p_javascript_code_onload=>'apex.theme42demo.jump(''&REQUEST.'');'
,p_step_template=>wwv_flow_api.id(3121228739815246741)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'VMORNEAU'
,p_last_upd_yyyymmddhh24miss=>'20211005114207'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(299234056681955724)
,p_plug_name=>'Region 1'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--noBorder:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(3121231715860246749)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(299234195377955725)
,p_plug_name=>'Region 2'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--noBorder:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(3121231715860246749)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(299234209400955726)
,p_plug_name=>'Region 3'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--noBorder:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(3121231715860246749)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(299234302611955727)
,p_plug_name=>'Region 4'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--noBorder:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(3121231715860246749)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(299234464540955728)
,p_plug_name=>'Region 5'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--noBorder:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(3121231715860246749)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(299234570264955729)
,p_plug_name=>'Instructions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:t-ContentBlock--shadowBG:js-headingLevel-2'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Demo1'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Then in <strong>Page Designer</strong>, select the regions that should appear on the <strong>Region Display Selector</strong> and set the <em>Region Display Selector</em> property to <strong>Yes</strong>.</p>',
'',
'<p>It is recommended to place a <strong>Region Display Selector</strong> region in the <strong>Breadcrumb</strong> position on your page.</p>'))
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(299234607865955730)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(3121236124904246762)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3083776484632462201)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>The <strong>Region Display Selector</strong> is a Region component that provides a page level navigation control for other regions on the with the <em>Region Display Selector</em> property set to <strong>Yes</strong>.  It can be configured to work'
||' in two modes:</p>',
'<ul>',
'  <li><strong>View Single Region</strong> Show regions as tabs. Selecting a tab will make the corresponding region visible and hide the other selections.</li>',
'  <li><strong>Scroll Window</strong> Always display all the regions on the page. Selecting a tab will scroll your window to the corresponding region.</li>',
'</ul>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5257850347553488401)
,p_plug_name=>'Region Display Selector'
,p_region_name=>'Demo1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3550313444782567988)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'N'
);
wwv_flow_api.component_end;
end;
/
