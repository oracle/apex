prompt --application/pages/page_05000
begin
--   Manifest
--     PAGE: 05000
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>5000
,p_user_interface_id=>wwv_flow_api.id(1319173717720724629)
,p_name=>'Design Patterns'
,p_alias=>'DESIGN-PATTERNS'
,p_step_title=>'Design Patterns - &APP_TITLE.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'.dm-Migration-region {',
'  max-width: 80%;',
'  margin: 0 auto;',
'}',
'.dm-Migration-region > h1 {',
'  margin-top: 16vh;',
'}',
'.dm-Migration-region > h2 {',
'  margin-top: 8vh;',
'}',
'.dm-Migration-region > h3 {',
'  margin-top: 4vh;',
'  font-size: 2.0rem;',
'}',
'.dm-Migration-region ul {',
'  margin: 0;',
'  padding: 0;',
'  list-style-type: decimal;',
'}',
'.dm-Migration-region li {',
'  margin-left: 24px;',
'  margin-bottom: 4vh;',
'}',
'iframe {',
'  border: 0px;',
'  margin: auto;',
'  display: block;',
'  height: 180px;',
'  width: 500px;',
'}',
'.t-Body img {',
'  max-width: 75%;',
'  clip: rect(0, 0, 100px, 0);',
'  margin: auto;',
'  display: block;',
'  border-radius: 2px;',
'}',
'.two-images-one-row {',
'  text-align: center;',
'}',
'.two-images-one-row img {',
'  max-width: 49%;',
'  display: inline-block;',
'  vertical-align: bottom;',
'}',
'blockquote {',
'  font-size: 1.8rem;',
'  line-height: 1.8rem;',
'}',
'',
'.bookmarklet-changelog {',
'    text-align:right; ',
'    font-size:.8em; ',
'    font-style:italic; ',
'    margin-top: -20px;',
'    width: 200px;',
'    margin: auto;',
'}',
'.bookmarklet-changelog b {',
'    float:left;',
'    display:inline-block;',
'}',
'*/'))
,p_step_template=>wwv_flow_api.id(3121228739815246741)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_upd_yyyymmddhh24miss=>'20210827105544'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1862759164384583578)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(3121236124904246762)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1978908279976618692)
,p_plug_name=>'More Info'
,p_region_css_classes=>'dm-Migration-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3550313444782567988)
,p_plug_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1>More information</h1>',
'<p>If for whatever reason this guide fails in providing adequate assistance,  please reach out to us on the Oracle Technology Network (OTN) <a href="http://forums.oracle.com/forums/forum.jspa?forumID=137" target="_blank">discussion forum</a> or on Tw'
||'itter (<a href="https://twitter.com/hashtag/orclapex" target="_blank">#orclapex</a>). Any specific problem you have is likely to be encountered by others. Notifying us will help to improve this guide with additional information and facts relating to '
||'Universal Theme migration.</p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1978913360074618699)
,p_plug_name=>'Why Migrate?'
,p_region_css_classes=>'dm-Migration-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3550313444782567988)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>12
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1>Why should I migrate to Universal Theme?</h1>',
'<p>Universal Theme has a number of new features, improvements, and optimizations when compared to themes provided with previous releases of Application Express.  Additionally, Universal Theme utilizes several key UI features of Application Express 5 '
||'and provides a number of new Templates and Template Options that greatly expand the customizability of your application''s UI.</p>',
'',
'<p>Universal Theme provides improvements in almost every facet of defining the User Interface of your applications, and there a number of reasons why it is important to migrate to it immediately.  However, you must first understand your users and see'
||' whether a drastic change in User Interface is appropriate.</p>',
'<p>',
'Below is a quick fact-by-fact look at the many reasons for why you should migrate, and the few reasons why you may not want to migrate to Universal Theme.</p>',
'',
'<h2>Pros</h2>',
'<h3>Improvements</h3>',
'<ul>',
'<li>Cleaner Templates',
'<p><img src="#THEME_IMAGES#demo/img/Image_0.png" /></p>',
'',
'<p>Universal Theme has fewer, but more capable templates which can be customized with Template Options. It is quicker and easier to modify the presentation by changing Template Options, rather than by having to select a new template. Template Options'
||' allow for additional visual flourishes and, in some cases, new functionality. </p></li>',
'',
'<li>Improved Grid Support and Responsive Behavior',
'<p><img src="#THEME_IMAGES#demo/img/Image_1.png" />',
'Theme 25 introduced Grid Layout support in APEX 4.2, but used a fixed grid which was not easily customizable. Universal Theme introduces a flexible, fluid grid system which can be nested many times over, and is based off the Bootstrap grid.</p></li>',
'',
'<li>Mobile Ready',
'',
'<p>Because of Universal Theme''s improved grid support, applications are responsive out-of-the-box. Therefore, they run well on any mobile device running a modern browser. For example, you will notice that tapping is significantly sped up (no delay in'
||' clicking) in Universal Theme apps compared with legacy ones. </p></li>',
'',
'<li>Future-proofing',
'',
'<p>While legacy and older themes are supported in APEX 5, Universal Theme is the primary theme. With future releases of Application Express you will be be able to readily upgrade the Universal Theme to take advantages of the new functionality provide'
||'d. Migrating to Universal Theme is a simple means of ensuring your apps provide the most modern and up-to-date user experience for your users.</p></li>',
'</ul>',
'<h3>New Features</h3>',
'<ul>',
'<li>Theme Roller',
'',
'<div class=''two-images-one-row''><img src="#THEME_IMAGES#demo/img/Image_2.png" /><img src="#THEME_IMAGES#demo/img/Image_3.png" /></div>',
'',
'',
'<p>Older themes required you to to stick with one color and one set of styling. The only means of having your own styling was to override the defaults with CSS or switch to a new theme entirely. Universal Theme addresses this pain point by allowing y'
||'ou to quickly generate a new style for your app, using a GUI. </p></li>',
'',
'<li>Navigation Lists',
'<p><img src="#THEME_IMAGES#demo/img/Image_4.png" /></p>',
'<p>In Universal theme, you now have the choice between using a top or side navigation menu. Older themes only supported tabs, which always consumed vertical screen real estate. Placing the menu on the side, and allowing it to be collapdsed, works bet'
||'ter for most applications, especially when displayed on widescreen monitors.</p></li>',
'',
'<li>New UI Components',
'',
'<p><img src="#THEME_IMAGES#demo/img/Image_5.png" /></p>',
'<p>Universal Theme has built-in templates for a variety of common UI components which are not available in other themes. For example, there are templates for easily creating carousels, tabs, menus, cards, and much more.</p></li>',
'',
'<li>Maximize/Restore',
'',
'',
'<p><img src="#THEME_IMAGES#demo/img/Image_6.png" /></p>',
'',
'<p>Universal Theme enables Interactive Reports, Classic Reports, and Standard Regions to be "maximized". With the maximize button template option enabled, end users can now focus on a single region, and scroll through large amounts of data without se'
||'eing other content on the page. This makes it far easier for end users to review these large regions which are often very wide and long. Older themes do not have support for this feature. </p></li>',
'</ul>',
'',
'<h2>Cons</h2>',
'',
'<p>Because migrating to Universal Theme, from older themes, will take development effort and significant time reviewing migrated pages, you should consider the downsides of migrating before moving forward.</p>',
'<ul>',
'<li>Different UI.',
'',
'<p>While Universal Theme is designed to be fully accessible and aesthetically pleasing, users who are completely comfortable with the older theme''s UI, may not immediately like the new theme. Further, training material developed in-house will need to'
||' be upgraded as the look of the pages will undoubtedly change significantly.</p>',
'<p>This is not a technical issue, since Universal Theme is not a departure from the traditional APEX workflow, but an enhancement on top of your existing processes. Application content, such as pages, regions, buttons, and items, will not be changed '
||'as a result of migrating, other than their appearance.</p></li>',
'',
'<li>Regressions',
'',
'<p>Some templates carried over from previous themes may not have strict <em>one-to-one</em> equivalents. Some of your custom CSS/JS modifications that were not directly supported in APEX may also no longer work as expected on your pages. These and ot'
||'her issues are covered in <strong>Post-Migration Tasks</strong>, <strong>Best Practices</strong>, and <strong>Common Issues After Upgrading</strong> sections below.</p></li>',
'',
'<li>Custom Themes / Templates',
'',
'<p>If you have developed a completely custom theme, then migrating to Universal Theme may require significant effort. Similarly, if you defined custom templates then you may find difficulties finding a similar template in the Universal Theme. However'
||', you may find using the new template options and theme roller will make many of your customizations redundant. If not, you will need to manually define custom templates and reapply your custom CSS and HTML post-migration.</p></li>',
'',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1978913773097618700)
,p_plug_name=>'Steps to Migrate'
,p_region_css_classes=>'dm-Migration-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3550313444782567988)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'how-to'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1>How do I migrate to Universal Theme?</h1>',
'',
'<p>Before beginning the migration process, it is <strong>strongly</strong> recommended to take an export of your application. This will enable you to easily revert back to the original application if necessary, before making any changes to your appli'
||'cation and its metadata. Once you have migrated to the Universal Theme, you can not easily switch it back to the original legacy theme. Additionally, if you re-import the original application, under a different Application ID, you can refer to this a'
||'pplication to review how the application looked previously, as opposed to how it looks using the Universal Theme.</p>',
'',
'<p>If you haven''t done so already, you should use the Application Utilities > Upgrade Application to update certain built-in widgets in your legacy applications to the latest provided by APEX 5, e.g. FlashChart to AnyChart . This will ensure that tho'
||'se widgets take full advantage of the responsiveness of Universal Theme.</p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1978914219781618702)
,p_plug_name=>'Bookmarklet'
,p_region_css_classes=>'dm-Migration-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3550313444782567988)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1>Bookmarklet</h1>',
'<p>There is not always an equivalent template in Universal Theme for all templates from previous themes. For this reason, the APEX Development Team has created a bookmarklet to assist you with mapping your older templates to your newer templates in t'
||'he Verify Compatibility step of the Switch Theme wizard.</p>',
'',
'<p> The  Universal Theme Migration bookmarklet supports mappings from the 3 most popular legacy themes, Theme 24, 25, and 26. It also supports any themes that are based off these legacy themes, i.e.: if your theme was based on one of those themes. Wh'
||'en utilized then the bookmarklet will do most of the mappings correctly to produce the best results from the migration.</p>',
'',
'<p>To install the bookmarklet, drag the bookmark into your bookmarks bar.</p>',
'',
'<iframe id="bookmarkletIframe" src="#APP_IMAGES#bookmarklet.html"></iframe> ',
'',
'<p>Then, on the Verify Compatibility page, where you perform the template mappings, click on the Universal Theme Migration bookmarklet to attempt to update the template mappings. If the theme you are migrating from is supported, then it will automati'
||'cally match the templates of your older theme to the correct templates in Universal Theme.</p>',
'<p><img src="#THEME_IMAGES#demo/img/Image_19.png" /></p>',
'<p>If your theme is mapped properly, each of the select list values that were successfully altered will be highlighted in green. </p>',
'<p><img src="#THEME_IMAGES#demo/img/Image_20.png" /></p>',
'',
'<p>Once the mapping process has completed, any errors you encounter will be displayed On an error page. You can try clicking on the <b>Map to a Different Theme</b> button, to try re-mapping with an alternate theme available within the book marklet. I'
||'f the expected mapping can not be found in the select list for that template, then it  will be highlighted in orange.</p>',
'<p>   <img src="#THEME_IMAGES#demo/img/Image_21.png" /></p>',
'',
'<p>Typically receiving any errors either means your custom templates did not strictly match the theme you chose, or that you have not set <b>Match Template Classes</b> to "<b>No</b>" in the previous step.</p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1978914591047618703)
,p_plug_name=>'FAQ'
,p_region_css_classes=>'dm-Migration-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3550313444782567988)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1>Frequently Asked Questions</h1>',
'<h2>When Upgrading</h2>',
'<ul>',
'  <li>',
'    <strong>Problem</strong>',
'    <p>Warning: You must have at least two themes installed to be able to switch. Please create a new theme and attempt this action again.</p>',
'    <p><img src="#THEME_IMAGES#demo/img/Image_22.png" /></p>',
'    <strong>Solution</strong>',
'    <p>Create the Universal Theme in your application, as outlined above, before trying to switch your theme. Please <u>start the guide from step #1.</u></p>',
'  </li>',
'  <li>',
'    <strong>Problem</strong> ',
'    <p>This application cannot be converted to a theme using list-based navigation, as it uses two levels of tabs. Please update the application and set current tabs settings to use only one level of tabs prior to switching the theme. (Go to error)</'
||'p>',
'<p><img src="#THEME_IMAGES#demo/img/Image_23.png" /></p>',
'<strong>Solution</strong>',
'<p> Because two-level tabs are not supported in Universal Theme, you must re-design your existing apps to use only one level of tabs, and then switch. If doing so proves too complicated, try deleting the parent tabs, conducting the theme switch, and '
||'then re-creating navigation using a navigation menu post. To delete the parent tabs, you must go to "Shared Components >  Tabs > Edit Tabs > Manage Parent Tabs " and click on each of the parent tabs to access the button to delete them.</p>',
'</li>',
'</ul>',
'',
'<h2>After Upgrading</h2>',
'<ul>',
'<li>',
'<strong>Problem</strong>',
'<p> When running my app on a certain page, I get the error message "Label column span grid setting for this page item is invalid."</p>',
'<strong>Solution</strong>',
'<p><img src="#THEME_IMAGES#demo/img/Image_24.png" /></p>',
'<p> In this example, with a label column span of 3 plus each item''s column span of 1, all 4 together means that the content is 16 columns wide. This exceeds the 12 columns supported by the Universal Theme which results in this error being thrown befo'
||'re the page is rendered in your browser. To Fix: navigate to the page item specified in the error message in page designer or component view, and reduce the number of label column spans that your elements consume. </p>',
'</li>',
'<li>',
'<strong>Problem</strong> ',
'<p>My content is no longer placed in multiple columns</p>',
'<div class=''two-images-one-row''>',
'<img src="#THEME_IMAGES#demo/img/Image_25.png" />',
'<img src="#THEME_IMAGES#demo/img/Image_26.png" />',
'</div>',
'<strong>Solution</strong> ',
'<p>If you reset all the grid positions that your app previously used, then your content will be placed in one column after upgrading. To recreate the columned layout you had before, just drag the regions into new columns with Page Designer.</p>',
'<img src="#THEME_IMAGES#demo/img/Image_27.png" />',
'<p>You can also "fine-tune" the grid and column spans using the right side bar to get a layout that resembles your original theme.</p>',
'</li>',
'<li>',
'<strong>Problem</strong>',
'<p> My navigation bar is not a list </strong> </p>',
'<img src="#THEME_IMAGES#demo/img/Image_29.png" />',
'<strong> Solution </strong>',
'<p> In order to add menus and have fine grain control of your Navigation Bar, i.e., your upper right hand corner links, it will need to be converted from the "Classic" implementation to a "List" based one. To do so, you must first create a new list w'
||'hich contains entries such as your user name (&APP_USER.), a sign out link, and any other app-wide links you would like to have.',
'',
'Once this list is created, navigate to "Shared Components -> User Interface Attributes -> Edit Desktop -> Navigation Bar" and change the Implementation from "Classic" to "List".  "Select the List you created earlier, and set List Template to Navigati'
||'on Bar". Your app will now be using a list-based navigation bar.',
'<img src="#THEME_IMAGES#demo/img/Image_30.png" />',
'With a list-based Navigation Bar, you can then add sub-entries which will appear in a drop down menu.</p>',
'',
'',
'',
'',
'',
'</li>',
'',
'',
'</ul>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1978914994290618703)
,p_plug_name=>'Creating UT in your App'
,p_region_css_classes=>'dm-Migration-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3550313444782567988)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h2>First: Create Universal Theme in your application</h2>',
'<p>From Shared Components, click on Themes and follow the steps below:</p>',
'<p><b>Note:</b> If you have already installed the Universal THeme into your application proceed to the second step, <em>Switch to Universal Theme</em>.</p>',
'<ol>',
'    <li><p>Click <b>Create Theme</b></p><p>You need to install the Universal Theme into your application to get started.</p>',
'        <p><img src="#THEME_IMAGES#demo/img/Image_7.png" /></p></li>',
'    <li><p>Select <b>From the Repository.</b></p>',
'        <p><img src="#THEME_IMAGES#demo/img/Image_8.png" /></p></li>',
'    <li><p>Select <b>Desktop</b> as the User Interface.</p>',
'        <p><img src="#THEME_IMAGES#demo/img/Image_9.png" /></p></li>',
'    <li><p>Choose <b>Standard Themes</b> as the Theme Type, and <b>Universal Theme (Theme 42)</b> as the Theme. </p>',
'        <p> <img src="#THEME_IMAGES#demo/img/Image_10.png" /></p></li>',
'    <li><p>Review your changes and click <b>Create</b>.</p>',
'        <p><img src="#THEME_IMAGES#demo/img/Image_11.png" /></p></li>',
'</ol>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1978915374029618704)
,p_plug_name=>'Switching to UT'
,p_region_css_classes=>'dm-Migration-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3550313444782567988)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h2>Second: Switch to Universal Theme.</h2>',
'<p><b>Note:</b> Not until you have completed Step 4 below will your application be irreversibly changed. Reverting back to a Tab-based application will be very difficult, which is why it is strongly recommended you have a backup of the application be'
||'fore proceeding further.</p>',
'<ol>',
'  <li><p>Click <b>Switch Theme</b></p>',
'    <p><img src="#THEME_IMAGES#demo/img/Image_12.png" /></p></li>',
'  <li><p>Select the current desktop theme, and then select <b>42. Universal Theme</b>. ',
'    <p>Depending on your application, you may choose to set the <b>Reset Grid</b> option to either <b>Reset fixed region positions</b> or <b>Reset all region and item grid positions</b>.</p>',
'     <p>Reset fixed region positions will maintain your current region positions, where possible, during migration. <em>This is the recommended approach</em>.</p>',
'     <p>Reset all region and item grid positions will ensure item and region positioning will be reset and will force regions and items to stack on top of each other.</p>',
'     <p>Make sure that <b>Map Template Classes</b> is set to <b>No</b></p>',
'     <p>Press <b>Next</b> to continue.</p>',
'     <p><img src="#THEME_IMAGES#demo/img/Image_13.png" /></p></li>',
'   <li><p>Verify that<b> </b>the mappings for your templates and Universal Theme templates are correct. Use the <b>Universal Theme Migration Bookmarklet</b> helper below, to automatically assign the right mapping, or check out the full mapping guide '
||'located at the end of this guide.</p>',
'     <p>Most of the inconsistencies will be from new templates that Universal theme provides. Try to choose the template that best matches your existing template. You may want to browse the components in the Universal Theme Sample Application to get '
||'a sense of the new templates and their various configurations. </p>',
'     <p><img src="#THEME_IMAGES#demo/img/Image_14.png" /></p></li>',
'   <li><p>Click <b>Switch Theme</b>.</p>',
'     <p> <img src="#THEME_IMAGES#demo/img/Image_15.png" /></p></li>',
'</ol>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1978915805133618704)
,p_plug_name=>'Post Migration'
,p_region_css_classes=>'dm-Migration-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3550313444782567988)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1>Final steps: Post migration tasks</h1>',
'<p>Unlike the previous steps, the following tasks do not have to be completed in any particular order. Instead, it is advised that you carry them out before making new enhancements to your application, to ensure that any issues relating to the migrat'
||'ion are not complicated by changes in functionality.</p>',
'<ul>',
'    <li>',
'    <p>While it is not necessary to remove your older theme for your freshly migrated app to work, your older theme no longer serves any functional purpose. If you haven''t created any custom templates in your older theme (which you''d want to copy ove'
||'r), or if you don''t need to keep the older theme for reference, consider deleting the older theme.</p>',
'  </li>',
'  <li>',
'    <p>Ensure that the list items for <b>Navigation Menu</b> are correct, and that the <em>Current For</em> attributes are properly set.</p>',
'    <p>Your tabs will be converted into a list format. If the current for attributes are not set correctly, the navigation links will not be selected when you navigate to each of the pages. </p>',
'    <p><img src="#THEME_IMAGES#demo/img/Image_16.png"/></p>',
'  </li>',
'  <li>',
'    <p>Decide if you want to stick with <b>Side Navigation</b> or change to the <b>Top Menu </b>as the application''s primary means of navigation.</p>',
'    <p>If you choose to stick with side navigation, it is recommended to select <em>Navigation Icons</em> for each menu entry, otherwise each page will have the same default page icon. By going to Shared Components > Navigation Menu > List Entry, you'
||' can choose from a variety of pre-built icons, allowing you to choose the best match for each page type. Please note that these icons will only appear if you are using side navigagtion.</p>',
'    <p>To change to <b>Top Menu</b> you will need to navigate to Shared Component > User Interface Attributes > Edit Universal Theme. Then change <b>Position</b> to <em>Top</em> and <b>List Template</b> to <em>Top Menu Navigation</em>, and then apply'
||' changes.</p>',
'    <p><img src="#THEME_IMAGES#demo/img/Image_17.png"/></p>',
'  </li>',
'  <li>',
'    <p><img src="#THEME_IMAGES#demo/img/Image_18.png"/></p>',
'  </li>',
'</ul>',
'',
'<h2>Best Practices for managing post-migration issues</h2>',
'<p>While most migrations will be relatively painless, there is no set path for how dealing with issues arise as a result of this change. Consider the following pointers for how to exhaustively find and resolve such problems in your new Universal Them'
||'e Application.</p>',
'<ol>',
'  <li>Visually review the migrated application.<br/>',
'    - Run each page of your application, or at least a good cross section of different pages to make sure that there are no obvious display issues.<br/>',
'    - If you have installed your original application under a different Application Id, perform side-by-side comparisons on a wide selection of pages, to ensure different page elements, such as buttons, and the overall page layout are not too diverge'
||'nt.',
'  </li>',
'  <li>Check non-standard components.<br/>',
'    - Be sure to check any pages where you implemented your own JavaScript to ensure the page still operates correctly. Many of the default class names for elements were changed, and some of the inline scripts that you have augmented your pages with '
||'may no longer be needed. <br/>',
'    - Review any pages or templates where you have added any CSS libraries. If necessary, reapply the CSS libraries into the migrated application.<br/>',
'    - Review all plug-ins used throughout your application to ensure they are still functioning correctly. Some plug-ins from third parties may not work correctly with Application Express 5. If so, you may need to remove the plug-in or search for an '
||'APEX 5.0 compatible plug-in.',
'  </li>',
'  <li>Ask your users to test your app.<br/>',
'    - After testing the application yourself, the next step is to ask your users to use the new migrated application to ensure they are comfortable with the new user interface, and can readily use the application.<br/>',
'    - Determine from your end users if any end user training material or application documentation needs to be revised before releasing the new application into production.',
'  </li>',
'</ol>',
'',
'<h3>After Debugging</h3>',
'<p>Once you have brought your application up to a "functional" state, you should consider a few more simple improvements you can readily make to your application, so that you can take full advantage of the new features in both Application Express 5 a'
||'nd Universal Theme. For example, you may want to prototype some different layout options, with a select group of users, to see if existing pages can be readily improved by simply changing some Template Options.</p>',
'',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(1978916148293618705)
,p_plug_name=>'Best Practices on Common UI Patterns'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<p>We can increase usability by following design patterns when building applications. This page showcases some of the most common design patterns in for enterprise applications, and instructions on how to apply them for your own flows.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2221421629107504575)
,p_plug_name=>'Design Patterns List'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'t-MediaList--showIcons:u-colors:t-MediaList--cols t-MediaList--2cols'
,p_plug_template=>wwv_flow_api.id(3121231715860246749)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_list_id=>wwv_flow_api.id(1211321025744361569)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(1116867651117668858)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.component_end;
end;
/
