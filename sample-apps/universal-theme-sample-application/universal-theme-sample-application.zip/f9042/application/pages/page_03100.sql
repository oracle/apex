prompt --application/pages/page_03100
begin
--   Manifest
--     PAGE: 03100
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>3100
,p_user_interface_id=>wwv_flow_api.id(1319173717720724629)
,p_name=>'Card Templates'
,p_alias=>'CARD-TEMPLATES'
,p_step_title=>'Card Templates'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(902965876267414568)
,p_page_css_classes=>'dm-Page dm-Page--center'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>'No help is available for this page.'
,p_last_upd_yyyymmddhh24miss=>'20211005091608'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2993552996924713109)
,p_plug_name=>'Cards as a List Template'
,p_icon_css_classes=>'fa-bars'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(284932509042300022)
,p_plug_name=>'Demo'
,p_parent_plug_id=>wwv_flow_api.id(2993552996924713109)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>40
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(883704052515543143)
,p_plug_name=>'Cards List'
,p_region_name=>'Demo1'
,p_parent_plug_id=>wwv_flow_api.id(284932509042300022)
,p_region_sub_css_classes=>'dm-TemplateOption-previewTarget'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--featured t-Cards--block force-fa-lg:t-Cards--displayIcons:t-Cards--cols:t-Cards--desc-2ln:t-Cards--animColorFill'
,p_plug_template=>wwv_flow_api.id(3550313444782567988)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_api.id(2403195714363979661)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(1935642268214819945)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(883704176136543144)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_api.id(2993552996924713109)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Demo1'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2993597350731332594)
,p_plug_name=>'List Custom Attributes'
,p_parent_plug_id=>wwv_flow_api.id(2993552996924713109)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>70
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<dl class="t-AVPList  t-AVPList--leftAligned">',
'  <dt class="t-AVPList-label">#A01#</dt><dd class="t-AVPList-value">Description</dd>',
'  <dt class="t-AVPList-label">#A02#</dt><dd class="t-AVPList-value">Secondary Information</dd>',
'  <dt class="t-AVPList-label">#A03#</dt><dd class="t-AVPList-value">Initials</dd>',
'  <dt class="t-AVPList-label">#A04#</dt><dd class="t-AVPList-value">List Item CSS Classes</dd>',
'  <dt class="t-AVPList-label">#A05#</dt><dd class="t-AVPList-value">Link Attributes</dd>',
'  <dt class="t-AVPList-label">#A06#</dt><dd class="t-AVPList-value">Card Color Class</dd>',
'  <dt class="t-AVPList-label">#A07#</dt><dd class="t-AVPList-value">Subtitle</dd>',
'</dl>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2993600168825332597)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_api.id(2993552996924713109)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Demo1'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3003813828880338492)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_source=>'<p>Cards are useful for presenting a variety of information in small blocks and can be heavily customized. They can be displayed in three styles, with icons or initials, and you can control the layout. With Universal Theme, you can style both <strong'
||'>Lists</strong> or <strong>Classic Reports</strong> regions to appear as cards by setting the appropriate template.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3003814317149338492)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(1580336106168319527)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(2223835478964964853)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(3121236124904246762)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3003814824148338493)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3550313444782567988)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'JUMP'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3003815295227338493)
,p_plug_name=>'Cards as a Report Template'
,p_icon_css_classes=>'fa-table'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2:js-headingLevel-2'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(265669721383256731)
,p_plug_name=>'Instructions'
,p_parent_plug_id=>wwv_flow_api.id(3003815295227338493)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.TEMPLATE_INSTRUCTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Demo2'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(265669871698256732)
,p_plug_name=>'Template Options'
,p_parent_plug_id=>wwv_flow_api.id(3003815295227338493)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--shadowBG:js-headingLevel-3'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.PREVIEW_TEMPLATE_OPTIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'REGION'
,p_attribute_02=>'Demo2'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(284932676681300023)
,p_plug_name=>'Demo'
,p_parent_plug_id=>wwv_flow_api.id(3003815295227338493)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:js-headingLevel-3'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(883704391610543146)
,p_name=>'Cards Report'
,p_region_name=>'Demo2'
,p_parent_plug_id=>wwv_flow_api.id(284932676681300023)
,p_template=>wwv_flow_api.id(3550313444782567988)
,p_display_sequence=>10
,p_region_sub_css_classes=>'dm-TemplateOption-previewTarget'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--featured t-Cards--block force-fa-lg:t-Cards--displayIcons:t-Cards--cols:t-Cards--animColorFill'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  id,',
'  project card_title,',
'  upper(substr(project,0,2)) card_initials,',
'  null card_text,',
'  null card_subtext,',
'  ''fa-cloud'' card_icon, ',
'  lower(created_by) created_by,',
'  created,',
'  lower(updated_by) updated_by,',
'  updated',
'from eba_UT_chart_projects',
'order by 2'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(2023855231844887169)
,p_query_num_rows=>4
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(883704409321543147)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(883704546442543148)
,p_query_column_id=>2
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>2
,p_column_heading=>'Card title'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(883704630326543149)
,p_query_column_id=>3
,p_column_alias=>'CARD_INITIALS'
,p_column_display_sequence=>3
,p_column_heading=>'Card initials'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(883704701212543150)
,p_query_column_id=>4
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>4
,p_column_heading=>'Card text'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'Created by #CREATED_BY# (#CREATED#)'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(883704807195543151)
,p_query_column_id=>5
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>5
,p_column_heading=>'Card subtext'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'Updated #UPDATED#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(883705320508543156)
,p_query_column_id=>6
,p_column_alias=>'CARD_ICON'
,p_column_display_sequence=>10
,p_column_heading=>'Card Icon'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(883704955358543152)
,p_query_column_id=>7
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(883705048670543153)
,p_query_column_id=>8
,p_column_alias=>'CREATED'
,p_column_display_sequence=>7
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(883705146460543154)
,p_query_column_id=>9
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(883705205394543155)
,p_query_column_id=>10
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>9
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(838148787769610670)
,p_plug_name=>'Column Aliases'
,p_parent_plug_id=>wwv_flow_api.id(3003815295227338493)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>60
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<dl class="t-AVPList  t-AVPList--leftAligned">',
'  <dt class="t-AVPList-label">#CARD_MODIFIERS#</dt><dd class="t-AVPList-value">Card CSS Class</dd>',
'  <dt class="t-AVPList-label">#CARD_COLOR#</dt><dd class="t-AVPList-value">Card Color Class</dd>',
'  <dt class="t-AVPList-label">#CARD_ICON#</dt><dd class="t-AVPList-value">Icon</dd>',
'  <dt class="t-AVPList-label">#CARD_INITIALS#</dt><dd class="t-AVPList-value">Initials</dd>',
'  <dt class="t-AVPList-label">#CARD_TITLE#</dt><dd class="t-AVPList-value">Title</dd>',
'  <dt class="t-AVPList-label">#CARD_LINK#</dt><dd class="t-AVPList-value">Link</dd>',
'  <dt class="t-AVPList-label">#CARD_SUBTITLE#</dt><dd class="t-AVPList-value">Subtitle</dd>',
'  <dt class="t-AVPList-label">#CARD_TEXT#</dt><dd class="t-AVPList-value">Description text</dd>',
'  <dt class="t-AVPList-label">#CARD_SUBTEXT#</dt><dd class="t-AVPList-value">Secondary description text</dd>',
'</dl>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4290103397560330605)
,p_plug_name=>'Sample SQL Query'
,p_parent_plug_id=>wwv_flow_api.id(3003815295227338493)
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--lightBG'
,p_plug_template=>wwv_flow_api.id(1370988447073029611)
,p_plug_display_sequence=>50
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'col-sm-12'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.REGION_SOURCE_CODE'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'Demo2'
);
wwv_flow_api.component_end;
end;
/
