prompt --application/shared_components/navigation/lists/ut_sample_links_list
begin
--   Manifest
--     LIST: UT - Sample Links List
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(2403497715067081638)
,p_name=>'UT - Sample Links List'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2403497930460081638)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Amet Incorporated'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-cloud'
,p_list_text_01=>'4'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2403498363738081639)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Ridiculus LLP'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-comments'
,p_list_text_01=>'12'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2403498758992081639)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Tristique LLC'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'4'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2403499185725081639)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Cras Interdum Consulting'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-envelope'
,p_list_text_01=>'431'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2403499539039081640)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Felis Associates'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-dashboard'
,p_list_text_01=>'Pending'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2403499978590081642)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Eros Nec Corporation'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-user'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
