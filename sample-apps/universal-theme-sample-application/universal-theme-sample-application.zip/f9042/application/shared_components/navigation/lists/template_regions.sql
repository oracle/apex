prompt --application/shared_components/navigation/lists/template_regions
begin
--   Manifest
--     LIST: Template - Regions
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(974332733620661859)
,p_name=>'Template - Regions'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(974333377030661866)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Alert'
,p_list_item_link_target=>'f?p=&APP_ID.:1202:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-exclamation-triangle'
,p_list_text_01=>'Alert Notify your users with alerts, confirmations, and other action-oriented messages.'
,p_list_text_03=>'LS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(974334163286661867)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Buttons Container'
,p_list_item_link_target=>'f?p=&APP_ID.:1250:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-square-o'
,p_list_text_01=>'Organize your button bars, toolbars, and simple horizontal forms.'
,p_list_text_03=>'BC'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(974334511329661868)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Carousel'
,p_list_item_link_target=>'f?p=&APP_ID.:1205:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-arrows-h'
,p_list_text_01=>'Show off one sub region at a time. For example, displaying a report and a chart, a slideshow, or different views of the same data.'
,p_list_text_03=>'CS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(974334911059661868)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Collapsible'
,p_list_item_link_target=>'f?p=&APP_ID.:1206:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-folder-open-o'
,p_list_text_01=>'Allow your users to toggle the visibility of a region''s content on the page.'
,p_list_text_03=>'DL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2783434198812844312)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Content Block'
,p_list_item_icon=>'fa-file'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(974333764115661867)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Hero'
,p_list_item_link_target=>'f?p=&APP_ID.:1203:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bullhorn'
,p_list_text_01=>'Capture your users'' attention on homepage, dashboard, and other introductory-style pages. This region template displays an icon, heading and sub headings, and buttons.'
,p_list_text_03=>'HR'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2783434494724844313)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Inline Dialog'
,p_list_item_link_target=>'f?p=&APP_ID.:1911:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-header'
,p_list_text_01=>'An inline dialog displays a region on the current page within a modal dialog.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2783434906238844313)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Interactive Report'
,p_list_item_link_target=>'f?p=&APP_ID.:1402:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-sort-amount-desc'
,p_list_text_01=>'Interactive Reports provide powerful features for customizing your report such as searching, filtering, sorting, highlighting, group-by, pivot, aggregations, calculations, charting, and more.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2783435339822844313)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Login'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:other:&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'A generic login screen.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(974332931192661864)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Standard'
,p_list_item_link_target=>'f?p=&APP_ID.:1201:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-align-justify'
,p_list_text_01=>'The generic region template. It works well with all widgets and can be heavily customized.'
,p_list_text_03=>'SD'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2783435777245844314)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Tab Container'
,p_list_item_link_target=>'f?p=&APP_ID.:1907:&SESSION.:tab_container:&DEBUG.::::'
,p_list_item_icon=>'fa-tabs'
,p_list_text_01=>'The Tabs Container Region Template can be used to create a set tabs within your page.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(974335338803661868)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Title Bar'
,p_list_item_link_target=>'f?p=&APP_ID.:1207:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-adn'
,p_list_text_01=>'Group breadcrumbs, page title, and primary page actions at the top of the page.'
,p_list_text_03=>'TB'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(974341771409015957)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Wizard Container'
,p_list_item_link_target=>'f?p=&APP_ID.:1208:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-magic'
,p_list_text_01=>'Use this region template for the Wizard Progress list, and as the container for your forms.'
,p_list_text_03=>'WZ'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
