prompt --application/shared_components/navigation/lists/ut_design_patterns
begin
--   Manifest
--     LIST: UT - Design Patterns
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(1211321025744361569)
,p_name=>'UT - Design Patterns'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1211321371400361569)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Login Page'
,p_list_item_link_target=>'f?p=&APP_ID.:5001:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-key'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1211321719645361570)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Home and Dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:5002:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1211322143248361570)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Filter Page'
,p_list_item_link_target=>'f?p=&APP_ID.:5003:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header-sidebar-left'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1211322561177361570)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Marquee Page'
,p_list_item_link_target=>'f?p=&APP_ID.:5004:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-check-circle-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1211322988399361570)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Modal Dialogs'
,p_list_item_link_target=>'f?p=&APP_ID.:5005:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-blank'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
