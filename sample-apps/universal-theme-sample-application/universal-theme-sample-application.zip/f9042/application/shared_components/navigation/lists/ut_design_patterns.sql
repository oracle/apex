prompt --application/shared_components/navigation/lists/ut_design_patterns
begin
--   Manifest
--     LIST: UT - Design Patterns
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(1211321025744361569)
,p_name=>'UT - Design Patterns'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.component_end;
end;
/
