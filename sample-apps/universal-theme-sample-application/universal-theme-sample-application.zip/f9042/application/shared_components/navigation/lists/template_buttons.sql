prompt --application/shared_components/navigation/lists/template_buttons
begin
--   Manifest
--     LIST: Template - Buttons
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(974485800259167220)
,p_name=>'Template - Buttons'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(300725361321284356)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Text Only'
,p_list_item_link_target=>'f?p=&APP_ID.:1500:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-text-o'
,p_list_text_01=>'Display only text within a button. This is the standard button in Universal Theme.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(300725692594284355)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Icon Only'
,p_list_item_link_target=>'f?p=&APP_ID.:1500:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-photo'
,p_list_text_01=>'Display only an icon in a button.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(300726019592284354)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Text with Icon'
,p_list_item_link_target=>'f?p=&APP_ID.:1500:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-picture-o'
,p_list_text_01=>'Display an icon to either the right or left of text in a button.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
