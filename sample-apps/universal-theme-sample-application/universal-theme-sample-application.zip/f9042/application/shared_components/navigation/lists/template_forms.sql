prompt --application/shared_components/navigation/lists/template_forms
begin
--   Manifest
--     LIST: Template - Forms
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(974490162833188150)
,p_name=>'Template - Forms'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(300722217323302929)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Floating Labels'
,p_list_item_link_target=>'f?p=&APP_ID.:1600:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-forms'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Float labels in form fields so they take up the space of an empty field and automatically shrink as data is entered.',
''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(300722500795302921)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Labels Above'
,p_list_item_link_target=>'f?p=&APP_ID.:1600:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-forms'
,p_list_text_01=>'Position form field labels above the field.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(300722951562302921)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Labels Horizontal'
,p_list_item_link_target=>'f?p=&APP_ID.:1600:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-forms'
,p_list_text_01=>'Position form field labels to the left of the field.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
