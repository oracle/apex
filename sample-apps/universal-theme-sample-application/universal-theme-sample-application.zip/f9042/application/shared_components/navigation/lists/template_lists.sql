prompt --application/shared_components/navigation/lists/template_lists
begin
--   Manifest
--     LIST: Template - Lists
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(974474777450086212)
,p_name=>'Template - Lists'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2783410675396721492)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Badge List'
,p_list_item_link_target=>'f?p=&APP_ID.:1304:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-badge-list'
,p_list_text_01=>'This list template is useful for displaying badges or counters.'
,p_list_text_03=>'BL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2783411119697726015)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Cards'
,p_list_item_link_target=>'f?p=&APP_ID.:3100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cards'
,p_list_text_01=>'Presents a variety of information in small blocks and can be heavily customized'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(974475696049086221)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Links List'
,p_list_item_link_target=>'f?p=&APP_ID.:1303:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list'
,p_list_text_01=>'This list template provides a list of links which can be used for navigation and other action-oriented tasks. You can optionally show badges, icons, sub list items, and more.'
,p_list_text_03=>'LS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(974474957468086218)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Media List'
,p_list_item_link_target=>'f?p=&APP_ID.:1301:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-media-list'
,p_list_text_01=>'This list template is a very common design pattern involving an icon, heading, description, and a badge.'
,p_list_text_03=>'ML'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2783411469335726015)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Menu Bar'
,p_list_item_link_target=>'f?p=&APP_ID.:1305:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tabs'
,p_list_text_01=>'This list template is used to display a menu bar control and is useful for building pages with advanced interaction.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2783411875402726016)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Menu Popup'
,p_list_item_link_target=>'f?p=&APP_ID.:1306:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list-alt'
,p_list_text_01=>'You can easily create a popup menu in your application by using Lists and associating a button with the menu.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2783412259549726016)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Navigation Bar'
,p_list_item_link_target=>'f?p=&APP_ID.:407:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-breadcrumb'
,p_list_text_01=>'Navigation is an important part of your application and can determine the how your users navigate within your application.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2783412649257726016)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Tabs'
,p_list_item_link_target=>'f?p=&APP_ID.:1907:&SESSION.:tab_list:&DEBUG.::::'
,p_list_item_icon=>'fa-tabs'
,p_list_text_01=>'You can use Tabs within your application pages to improve navigation,'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2783413031964726017)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Wizard Progress'
,p_list_item_link_target=>'f?p=&APP_ID.:1208:&SESSION.:wizard_list:&DEBUG.::::'
,p_list_item_icon=>'fa-wizard'
,p_list_text_01=>'The Wizard Progress List Template is used to display the total steps of a wizard along with a marker of the current step the user is on.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
