prompt --application/shared_components/navigation/lists/templates_region_types
begin
--   Manifest
--     LIST: Templates - Region Types
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(2553813184178510886)
,p_name=>'Templates - Region Types'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305088076881634834)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Alert'
,p_list_item_link_target=>'f?p=&APP_ID.:1202:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-exclamation-triangle'
,p_list_text_01=>'Display alerts, confirmations, and other action-oriented messages.'
,p_list_text_03=>'LS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114169695405708360)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Badges List'
,p_list_item_link_target=>'f?p=&APP_ID.:1304:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-badge-list'
,p_list_text_01=>'Display badges or counters.'
,p_list_text_03=>'BL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553813347280510889)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Breadcrumb'
,p_list_item_link_target=>'f?p=&APP_ID.:3810:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-breadcrumb'
,p_list_text_01=>'Indicate where the user is within the application with a hierarchical list of links.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(345671050303886387)
,p_list_item_display_sequence=>52
,p_list_item_link_text=>'Buttons'
,p_list_item_link_target=>'f?p=&APP_ID.:1500:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-button'
,p_list_text_01=>'Link pages, execute dynamic actions, and more.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(345671387477892421)
,p_list_item_display_sequence=>56
,p_list_item_link_text=>'Button Group'
,p_list_item_link_target=>'f?p=&APP_ID.:1204:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-button-group'
,p_list_text_01=>'Group buttons to appear together to make a single control.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305088863137634835)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Button Container'
,p_list_item_link_target=>'f?p=&APP_ID.:1250:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-button-container'
,p_list_text_01=>'Organize buttons, toolbars, and simple horizontal forms.'
,p_list_text_03=>'BC'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553813783501510890)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Calendar'
,p_list_item_link_target=>'f?p=&APP_ID.:1800:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'Display a calendar based on the Full Calendar library that supports drag and drop, multiple views, and more.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(345687418032273918)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Card Regions'
,p_list_item_link_target=>'f?p=&APP_ID.:3110:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-address-card-o'
,p_list_text_01=>'Present a variety of information in small blocks and can be heavily customized.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114170139706712883)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Card Templates'
,p_list_item_link_target=>'f?p=&APP_ID.:3100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cards'
,p_list_text_01=>'Style regions like Classic Reports or Lists to look like a Cards region.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305089211180634836)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Carousel'
,p_list_item_link_target=>'f?p=&APP_ID.:1205:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-carousel'
,p_list_text_01=>'Show off one sub region at a time. For example, display a report and a chart, a slideshow, or different views of the same data.'
,p_list_text_03=>'CS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553862348613693812)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:1902:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bar-chart'
,p_list_text_01=>'Visualize data in a variety of different ways based on Oracle JavaScript Extension Toolkit (JET) Data Visualizations.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553918606475211531)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Classic Report'
,p_list_item_link_target=>'f?p=&APP_ID.:1401:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>'Display tabular data in a default report template.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305089610910634836)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Collapsible'
,p_list_item_link_target=>'f?p=&APP_ID.:1206:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-collapsible'
,p_list_text_01=>'Toggle the visibility of a region''s content on the page.'
,p_list_text_03=>'DL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(840248829012816733)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Column Toggle Report'
,p_list_item_link_target=>'f?p=&APP_ID.:1720:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-toggle-on'
,p_list_text_01=>'Quickly choose columns to display when screen size is limited.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305244673530115659)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Comments'
,p_list_item_link_target=>'f?p=&APP_ID.:1405:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-comments-o'
,p_list_text_01=>'Display user comments and status updates.'
,p_list_text_03=>'CM'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114188898663817280)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Content Block'
,p_list_item_link_target=>'f?p=&APP_ID.:1209:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-align-justify'
,p_list_text_01=>'Display region content in a simple block.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(345670569305873277)
,p_list_item_display_sequence=>165
,p_list_item_link_text=>'Content Row'
,p_list_item_link_target=>'f?p=&APP_ID.:1407:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-list-left'
,p_list_text_01=>'Display content using a column for selection, such as a checkbox or radio button, an icon, and actions.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1603883804030323920)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Contextual Info'
,p_list_item_link_target=>'f?p=&APP_ID.:1307:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-list-right'
,p_list_text_01=>'Display key-value pairs in a report.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(345681453761026423)
,p_list_item_display_sequence=>175
,p_list_item_link_text=>'Forms'
,p_list_item_link_target=>'f?p=&APP_ID.:1600:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-forms'
,p_list_text_01=>'Declaratively design and control form layout, field templates, and label column widths.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553864296512713280)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Help Text'
,p_list_item_link_target=>'f?p=&APP_ID.:1903:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-info-circle'
,p_list_text_01=>'Provide page-level help to users.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305088463966634835)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>'Hero'
,p_list_item_link_target=>'f?p=&APP_ID.:1203:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bullhorn'
,p_list_text_01=>'Capture attention and display an icon, heading, sub-headings, and buttons on a homepage, dashboard, and other introductory-style pages.'
,p_list_text_03=>'HR'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114189194575817281)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'Inline Dialog'
,p_list_item_link_target=>'f?p=&APP_ID.:1911:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-header'
,p_list_text_01=>'Display a region on the current page within a modal dialog.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553919051052211531)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>'Interactive Grid'
,p_list_item_link_target=>'f?p=&APP_ID.:1410:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-grid-2x'
,p_list_text_01=>'Customize reports using powerful features in this native APEX component.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553919432610211531)
,p_list_item_display_sequence=>230
,p_list_item_link_text=>'Interactive Report'
,p_list_item_link_target=>'f?p=&APP_ID.:1402:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-sort-amount-desc'
,p_list_text_01=>'Create powerful reports using fixed headers, frozen columns, scroll pagination, multiple filters, sorting, aggregates, computations, and more.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305234716058073089)
,p_list_item_display_sequence=>240
,p_list_item_link_text=>'Links List'
,p_list_item_link_target=>'f?p=&APP_ID.:1303:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list'
,p_list_text_01=>'Use a list of links for navigation and other action-oriented tasks, with the option to show badges, icons, sub-list items, and more.'
,p_list_text_03=>'LS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(349044624300458897)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>'List View'
,p_list_item_link_target=>'f?p=&APP_ID.:1700:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list-alt'
,p_list_text_01=>'Display a simple list-based user interface that has a wide range of features such as built in search, list dividers, nested lists, and more.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553864897381722349)
,p_list_item_display_sequence=>260
,p_list_item_link_text=>'Map Chart'
,p_list_item_link_target=>'f?p=&APP_ID.:1904:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-globe'
,p_list_text_01=>'Visualize geo-related data.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305233977477073086)
,p_list_item_display_sequence=>270
,p_list_item_link_text=>'Media List'
,p_list_item_link_target=>'f?p=&APP_ID.:1301:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-media-list'
,p_list_text_01=>'Design lists that involve an icon, heading, description, and a badge.'
,p_list_text_03=>'ML'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114170489344712883)
,p_list_item_display_sequence=>280
,p_list_item_link_text=>'Menu Bar'
,p_list_item_link_target=>'f?p=&APP_ID.:1305:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tabs'
,p_list_text_01=>'Display a menu bar control.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114170895411712884)
,p_list_item_display_sequence=>290
,p_list_item_link_text=>'Menu Popup'
,p_list_item_link_target=>'f?p=&APP_ID.:1306:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list-alt'
,p_list_text_01=>'Display a menu that pops up on a page by using Lists and associating a button with the menu.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114171279558712884)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>'Navigation Bar'
,p_list_item_link_target=>'f?p=&APP_ID.:407:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header'
,p_list_text_01=>'Determine how users navigate within an application.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553865570878727717)
,p_list_item_display_sequence=>310
,p_list_item_link_text=>'PL/SQL Dynamic Content'
,p_list_item_link_target=>'f?p=&APP_ID.:1908:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dynamic-content'
,p_list_text_01=>'Render HTML or text using the PL/SQL Web Toolkit.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(840051207221813809)
,p_list_item_display_sequence=>320
,p_list_item_link_text=>'Reflow Report'
,p_list_item_link_target=>'f?p=&APP_ID.:1710:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tablet'
,p_list_text_01=>'Display data vertically to save space when screen size becomes small.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553866046060732081)
,p_list_item_display_sequence=>330
,p_list_item_link_text=>'Region Display Selector'
,p_list_item_link_target=>'f?p=&APP_ID.:1907:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tabs'
,p_list_text_01=>'Show and hide controls for regions.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3131661237666008237)
,p_list_item_display_sequence=>340
,p_list_item_link_text=>'Search Results'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305087631043634832)
,p_list_item_display_sequence=>350
,p_list_item_link_text=>'Standard'
,p_list_item_link_target=>'f?p=&APP_ID.:1201:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header'
,p_list_text_01=>'Display widgets in a generic region template that can be heavily customized.'
,p_list_text_03=>'SD'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553866434917736866)
,p_list_item_display_sequence=>370
,p_list_item_link_text=>'Static Content'
,p_list_item_link_target=>'f?p=&APP_ID.:1905:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_list_text_01=>'Use HTML markup directly on the page.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114190477096817282)
,p_list_item_display_sequence=>380
,p_list_item_link_text=>'Tab Container'
,p_list_item_link_target=>'f?p=&APP_ID.:1907:&SESSION.:tab_container:&DEBUG.::::'
,p_list_item_icon=>'fa-tabs'
,p_list_text_01=>'Group a set of tabs together within a page.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114171669266712884)
,p_list_item_display_sequence=>390
,p_list_item_link_text=>'Tabs'
,p_list_item_link_target=>'f?p=&APP_ID.:1907:&SESSION.:tab_list:&DEBUG.::::'
,p_list_item_icon=>'fa-tabs'
,p_list_text_01=>'Improve navigation, flow, and usability of pages in an application.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305246693221141026)
,p_list_item_display_sequence=>400
,p_list_item_link_text=>'Timeline'
,p_list_item_link_target=>'f?p=&APP_ID.:1406:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clock-o'
,p_list_text_01=>'Display recent updates and interactions within an application.'
,p_list_text_03=>'TL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305090038654634836)
,p_list_item_display_sequence=>410
,p_list_item_link_text=>'Title Bar'
,p_list_item_link_target=>'f?p=&APP_ID.:1207:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-breadcrumb'
,p_list_text_01=>'Group breadcrumbs, page title, and primary page actions at the top of the page.'
,p_list_text_03=>'TB'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553866946808741722)
,p_list_item_display_sequence=>420
,p_list_item_link_text=>'Tree'
,p_list_item_link_target=>'f?p=&APP_ID.:1901:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tree-org'
,p_list_text_01=>'Perform hierarchical navigation control based on a SQL query.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305243932905115658)
,p_list_item_display_sequence=>430
,p_list_item_link_text=>'Value Attribute Pairs'
,p_list_item_link_target=>'f?p=&APP_ID.:1403:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pause'
,p_list_text_01=>'Display attribute value / key value pairs with Row or Column based queries.'
,p_list_text_03=>'VA'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305096471259988925)
,p_list_item_display_sequence=>440
,p_list_item_link_text=>'Wizard Container'
,p_list_item_link_target=>'f?p=&APP_ID.:1208:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-magic'
,p_list_text_01=>'Contain the Wizard Progress List and forms using this region template.'
,p_list_text_03=>'WZ'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114172051973712885)
,p_list_item_display_sequence=>450
,p_list_item_link_text=>'Wizard Progress'
,p_list_item_link_target=>'f?p=&APP_ID.:1208:&SESSION.:wizard_list:&DEBUG.::::'
,p_list_item_icon=>'fa-wizard'
,p_list_text_01=>'Display the total steps of a wizard along with a marker of the current step the user is on.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
