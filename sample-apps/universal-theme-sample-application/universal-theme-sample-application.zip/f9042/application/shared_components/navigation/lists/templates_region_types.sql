prompt --application/shared_components/navigation/lists/templates_region_types
begin
--   Manifest
--     LIST: Templates - Region Types
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(2553813184178510886)
,p_name=>'Templates - Region Types'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305088076881634834)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Alert'
,p_list_item_link_target=>'f?p=&APP_ID.:1202:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-exclamation-triangle'
,p_list_text_01=>'Alert Notify your users with alerts, confirmations, and other action-oriented messages.'
,p_list_text_03=>'LS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114224842809918427)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Alerts'
,p_list_item_link_target=>'f?p=&APP_ID.:1202:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-exclamation-triangle'
,p_list_text_01=>'Display alerts, confirmations, and other action-oriented messages.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114169695405708360)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Badge List'
,p_list_item_link_target=>'f?p=&APP_ID.:1304:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-badge-list'
,p_list_text_01=>'This list template is useful for displaying badges or counters.'
,p_list_text_03=>'BL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114225136507918428)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Badge List'
,p_list_item_link_target=>'f?p=&APP_ID.:1304:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-badge-list'
,p_list_text_01=>'Displaying badges or counters.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553813347280510889)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Breadcrumb'
,p_list_item_link_target=>'f?p=&APP_ID.:3810:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-breadcrumb'
,p_list_text_01=>'A hierarchical list of links that indicates where the user is within the application from a hierarchical perspective.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305088863137634835)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Buttons Container'
,p_list_item_link_target=>'f?p=&APP_ID.:1250:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-square-o'
,p_list_text_01=>'Organize your button bars, toolbars, and simple horizontal forms.'
,p_list_text_03=>'BC'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553813783501510890)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Calendar'
,p_list_item_link_target=>'f?p=&APP_ID.:1800:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'calendar is based on the Full Calendar library and supports drag and drop, multiple views, and more'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3011206913848649300)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Cards'
,p_list_item_link_target=>'f?p=&APP_ID.:3100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cards'
,p_list_text_01=>'This report template provides the Cards UI and is useful for presenting a variety of information. Cards can be displayed in three styles, with icons or initials, and you can control the layout.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114170139706712883)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Cards'
,p_list_item_link_target=>'f?p=&APP_ID.:3100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cards'
,p_list_text_01=>'Presents a variety of information in small blocks and can be heavily customized'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305089211180634836)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Carousel'
,p_list_item_link_target=>'f?p=&APP_ID.:1205:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-arrows-h'
,p_list_text_01=>'Show off one sub region at a time. For example, displaying a report and a chart, a slideshow, or different views of the same data.'
,p_list_text_03=>'CS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553862348613693812)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Chart'
,p_list_item_link_target=>'f?p=&APP_ID.:1902:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>'Charts are based on Oracle JavaScript Extension Toolkit (JET) Data Visualizations'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553918606475211531)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Classic Report'
,p_list_item_link_target=>'f?p=&APP_ID.:1401:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-align-justify'
,p_list_text_01=>'The default report template used for displaying tabular data'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305089610910634836)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Collapsible'
,p_list_item_link_target=>'f?p=&APP_ID.:1206:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-folder-open-o'
,p_list_text_01=>'Allow your users to toggle the visibility of a region''s content on the page.'
,p_list_text_03=>'DL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(840248829012816733)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Column Toggle Report'
,p_list_item_link_target=>'f?p=&APP_ID.:1720:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-toggle-on'
,p_list_text_01=>'Quickly choose columns to display when screen size is limited.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305244673530115659)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Comments'
,p_list_item_link_target=>'f?p=&APP_ID.:1405:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-comments-o'
,p_list_text_01=>'This report template is used to display user comments and status updates.'
,p_list_text_03=>'CM'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114188898663817280)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Content Block'
,p_list_item_icon=>'fa-file'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1603883804030323920)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Contextual Info'
,p_list_item_link_target=>'f?p=&APP_ID.:1307:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-list-right'
,p_list_text_01=>'This report template is best used to display key value pairs.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553864296512713280)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Help Text'
,p_list_item_link_target=>'f?p=&APP_ID.:1903:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-info-circle'
,p_list_text_01=>'Page-level help'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305088463966634835)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>'Hero'
,p_list_item_link_target=>'f?p=&APP_ID.:1203:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bullhorn'
,p_list_text_01=>'Capture your users'' attention on homepage, dashboard, and other introductory-style pages. This region template displays an icon, heading and sub headings, and buttons.'
,p_list_text_03=>'HR'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114189194575817281)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'Inline Dialog'
,p_list_item_link_target=>'f?p=&APP_ID.:1911:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-header'
,p_list_text_01=>'An inline dialog displays a region on the current page within a modal dialog.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553919051052211531)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>'Interactive Grid'
,p_list_item_link_target=>'f?p=&APP_ID.:1410:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-modal-grid-2x'
,p_list_text_01=>'A native APEX component and provides powerful features for customizing your report'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114189606089817281)
,p_list_item_display_sequence=>220
,p_list_item_link_text=>'Interactive Report'
,p_list_item_link_target=>'f?p=&APP_ID.:1402:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-sort-amount-desc'
,p_list_text_01=>'Interactive Reports provide powerful features for customizing your report such as searching, filtering, sorting, highlighting, group-by, pivot, aggregations, calculations, charting, and more.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553919432610211531)
,p_list_item_display_sequence=>230
,p_list_item_link_text=>'Interactive Report'
,p_list_item_link_target=>'f?p=&APP_ID.:1402:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-sort-amount-asc'
,p_list_text_01=>'All the features you expect for powerful reporting, including fixed headers, frozen columns, scroll pagination, multiple filters, sorting, aggregates, computations, and more'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305234716058073089)
,p_list_item_display_sequence=>240
,p_list_item_link_text=>'Links List'
,p_list_item_link_target=>'f?p=&APP_ID.:1303:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list'
,p_list_text_01=>'This list template provides a list of links which can be used for navigation and other action-oriented tasks. You can optionally show badges, icons, sub list items, and more.'
,p_list_text_03=>'LS'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114190039673817281)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>'Login'
,p_list_item_link_target=>'f?p=&APP_ID.:1100:&SESSION.:other:&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'A generic login screen.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553864897381722349)
,p_list_item_display_sequence=>260
,p_list_item_link_text=>'Map Chart'
,p_list_item_link_target=>'f?p=&APP_ID.:1904:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-globe'
,p_list_text_01=>'Visualize geo related data'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305233977477073086)
,p_list_item_display_sequence=>270
,p_list_item_link_text=>'Media List'
,p_list_item_link_target=>'f?p=&APP_ID.:1301:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-media-list'
,p_list_text_01=>'This list template is a very common design pattern involving an icon, heading, description, and a badge.'
,p_list_text_03=>'ML'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114170489344712883)
,p_list_item_display_sequence=>280
,p_list_item_link_text=>'Menu Bar'
,p_list_item_link_target=>'f?p=&APP_ID.:1305:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tabs'
,p_list_text_01=>'This list template is used to display a menu bar control and is useful for building pages with advanced interaction.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114170895411712884)
,p_list_item_display_sequence=>290
,p_list_item_link_text=>'Menu Popup'
,p_list_item_link_target=>'f?p=&APP_ID.:1306:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list-alt'
,p_list_text_01=>'You can easily create a popup menu in your application by using Lists and associating a button with the menu.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114171279558712884)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>'Navigation Bar'
,p_list_item_link_target=>'f?p=&APP_ID.:407:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-breadcrumb'
,p_list_text_01=>'Navigation is an important part of your application and can determine the how your users navigate within your application.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553865570878727717)
,p_list_item_display_sequence=>310
,p_list_item_link_text=>'PL/SQL Dynamic Content'
,p_list_item_link_target=>'f?p=&APP_ID.:1908:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-terminal'
,p_list_text_01=>'Render HTML or text using the PL/SQL Web Toolkit'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(840051207221813809)
,p_list_item_display_sequence=>320
,p_list_item_link_text=>'Reflow Report'
,p_list_item_link_target=>'f?p=&APP_ID.:1710:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tablet'
,p_list_text_01=>'Display data vertically to save space when screen size becomes small'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553866046060732081)
,p_list_item_display_sequence=>330
,p_list_item_link_text=>'Region Display Selector'
,p_list_item_link_target=>'f?p=&APP_ID.:1907:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tabs'
,p_list_text_01=>'Show and hide controls for regions'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3131661237666008237)
,p_list_item_display_sequence=>340
,p_list_item_link_text=>'Search Results'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305087631043634832)
,p_list_item_display_sequence=>350
,p_list_item_link_text=>'Standard'
,p_list_item_link_target=>'f?p=&APP_ID.:1201:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-align-justify'
,p_list_text_01=>'The generic region template. It works well with all widgets and can be heavily customized.'
,p_list_text_03=>'SD'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305243110842115656)
,p_list_item_display_sequence=>360
,p_list_item_link_text=>'Standard'
,p_list_item_link_target=>'f?p=&APP_ID.:1401:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>'This is the default report template used for displaying tabular data.'
,p_list_text_03=>'RP'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553866434917736866)
,p_list_item_display_sequence=>370
,p_list_item_link_text=>'Static Content'
,p_list_item_link_target=>'f?p=&APP_ID.:1905:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-blank'
,p_list_text_01=>'Use HTML markup directly'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114190477096817282)
,p_list_item_display_sequence=>380
,p_list_item_link_text=>'Tab Container'
,p_list_item_link_target=>'f?p=&APP_ID.:1907:&SESSION.:tab_container:&DEBUG.::::'
,p_list_item_icon=>'fa-tabs'
,p_list_text_01=>'The Tabs Container Region Template can be used to create a set tabs within your page.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114171669266712884)
,p_list_item_display_sequence=>390
,p_list_item_link_text=>'Tabs'
,p_list_item_link_target=>'f?p=&APP_ID.:1907:&SESSION.:tab_list:&DEBUG.::::'
,p_list_item_icon=>'fa-tabs'
,p_list_text_01=>'You can use Tabs within your application pages to improve navigation,'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305246693221141026)
,p_list_item_display_sequence=>400
,p_list_item_link_text=>'Timeline'
,p_list_item_link_target=>'f?p=&APP_ID.:1406:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clock-o'
,p_list_text_01=>'This timeline report template is useful for displaying recent updates and interactions within an application.'
,p_list_text_03=>'TL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305090038654634836)
,p_list_item_display_sequence=>410
,p_list_item_link_text=>'Title Bar'
,p_list_item_link_target=>'f?p=&APP_ID.:1207:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-adn'
,p_list_text_01=>'Group breadcrumbs, page title, and primary page actions at the top of the page.'
,p_list_text_03=>'TB'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2553866946808741722)
,p_list_item_display_sequence=>420
,p_list_item_link_text=>'Tree'
,p_list_item_link_target=>'f?p=&APP_ID.:1901:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tree-org'
,p_list_text_01=>'Hierarchical navigational control based on a SQL query'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305243932905115658)
,p_list_item_display_sequence=>430
,p_list_item_link_text=>'Value Attribute Pairs'
,p_list_item_link_target=>'f?p=&APP_ID.:1403:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pause'
,p_list_text_01=>'This report template is useful for displaying attribute value / key value pairs and works well with both Row or Column based queries.'
,p_list_text_03=>'VA'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(1305096471259988925)
,p_list_item_display_sequence=>440
,p_list_item_link_text=>'Wizard Container'
,p_list_item_link_target=>'f?p=&APP_ID.:1208:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-magic'
,p_list_text_01=>'Use this region template for the Wizard Progress list, and as the container for your forms.'
,p_list_text_03=>'WZ'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(3114172051973712885)
,p_list_item_display_sequence=>450
,p_list_item_link_text=>'Wizard Progress'
,p_list_item_link_target=>'f?p=&APP_ID.:1208:&SESSION.:wizard_list:&DEBUG.::::'
,p_list_item_icon=>'fa-wizard'
,p_list_text_01=>'The Wizard Progress List Template is used to display the total steps of a wizard along with a marker of the current step the user is on.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
