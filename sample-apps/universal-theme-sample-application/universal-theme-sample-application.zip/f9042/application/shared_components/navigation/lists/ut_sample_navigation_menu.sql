prompt --application/shared_components/navigation/lists/ut_sample_navigation_menu
begin
--   Manifest
--     LIST: UT - Sample Navigation Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(2383083486935792669)
,p_name=>'UT - Sample Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383083677675792670)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Menu Item 1'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-home'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383084066392792671)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Menu Item 2'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-user'
,p_list_item_current_type=>'ALWAYS'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383086086040802759)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Sub Menu Item 2.1'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_api.id(2383084066392792671)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383086378648803707)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Sub Menu Item 2.2'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_api.id(2383084066392792671)
,p_list_item_current_type=>'ALWAYS'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383086666544804567)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Sub Menu Item 2.3'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_api.id(2383084066392792671)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383084447249792671)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Menu Item 3'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-play-circle-o'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383086953578806671)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Sub Menu Item 3.1'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_api.id(2383084447249792671)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383087233932807572)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Sub Menu Item 3.2'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_api.id(2383084447249792671)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383087587348808659)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Sub Menu Item 3.2.1'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_api.id(2383087233932807572)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383087875051809702)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Sub Menu Item 3.2.2'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_api.id(2383087233932807572)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383088386612810612)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Sub Menu Item 3.2.3'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_api.id(2383087233932807572)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383084797500792671)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Menu Item 4'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-gear'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383088672228812249)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Sub Menu Item 4.1'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_api.id(2383084797500792671)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383088930595812988)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Sub Menu Item 4.2'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_api.id(2383084797500792671)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383085228519792671)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Menu Item 5'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-alert'
,p_list_item_current_for_pages=>'#'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383089198346814140)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Sub Menu Item 5.1'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_api.id(2383085228519792671)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(2383089548928814776)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Sub Menu Item 5.2'
,p_list_item_link_target=>'#'
,p_parent_list_item_id=>wwv_flow_api.id(2383085228519792671)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
