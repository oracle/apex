prompt --application/shared_components/user_interface/lovs/font_animations
begin
--   Manifest
--     FONT_ANIMATIONS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9042
,p_default_id_offset=>497901394252394341
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(1060638924618441959)
,p_lov_name=>'FONT_ANIMATIONS'
,p_lov_query=>'.'||wwv_flow_api.id(1060638924618441959)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(1060639915523441965)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Spin'
,p_lov_return_value=>'fa-anim-spin'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(1060639191397441962)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Spin in Steps'
,p_lov_return_value=>'fa-anim-spin-step'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(1060639573056441964)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Flash'
,p_lov_return_value=>'fa-anim-flash'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(1060652754838514989)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Horizontal Shake'
,p_lov_return_value=>'fa-anim-horizontal-shake'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(1060653165431514989)
,p_lov_disp_sequence=>50
,p_lov_disp_value=>'Vertical Shake'
,p_lov_return_value=>'fa-anim-vertical-shake'
);
wwv_flow_api.component_end;
end;
/
