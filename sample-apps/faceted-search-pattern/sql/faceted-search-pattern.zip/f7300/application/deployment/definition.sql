prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7300
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- Faceted Search Patterns: Supporting Objects deinstallation.'||wwv_flow.LF||
'-- Run in the application''s parsing s';
wwv_flow_imp.g_varchar2_table(2) := 'chema through APEX Supporting Objects.'||wwv_flow.LF||
'-- Drops the objects defined in FSP_SO and deletes all data i';
wwv_flow_imp.g_varchar2_table(3) := 'n their tables.'||wwv_flow.LF||
'-- Associated indexes and constraints are dropped with the tables.'||wwv_flow.LF||
'-- Expects the su';
wwv_flow_imp.g_varchar2_table(4) := 'pporting objects to exist; intended for a complete installation.'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 1. Reporting views.'||wwv_flow.LF||
'DROP VIEW F';
wwv_flow_imp.g_varchar2_table(5) := 'SP_EMPLOYEE_EVENTS_V;'||wwv_flow.LF||
'DROP VIEW FSP_EMPLOYEE_ORG_V;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 2. Employee associations and events.'||wwv_flow.LF||
'DROP TA';
wwv_flow_imp.g_varchar2_table(6) := 'BLE FSP_EMPLOYEE_EVENTS;'||wwv_flow.LF||
'DROP TABLE FSP_EMPLOYEE_GROUPS;'||wwv_flow.LF||
'DROP TABLE FSP_EMPLOYEE_SKILLS;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 3. Stan';
wwv_flow_imp.g_varchar2_table(7) := 'dalone task and gallery data.'||wwv_flow.LF||
'DROP TABLE FSP_TASKS;'||wwv_flow.LF||
'DROP TABLE FSP_PATTERNS;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 4. Employees, inclu';
wwv_flow_imp.g_varchar2_table(8) := 'ding the self-referencing manager constraint.'||wwv_flow.LF||
'DROP TABLE FSP_EMPLOYEES;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 5. Reference tables, aft';
wwv_flow_imp.g_varchar2_table(9) := 'er their dependent tables have been removed.'||wwv_flow.LF||
'DROP TABLE FSP_LOCATIONS;'||wwv_flow.LF||
'DROP TABLE FSP_COST_CENTERS;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(10) := 'DROP TABLE FSP_GROUPS;'||wwv_flow.LF||
'DROP TABLE FSP_SKILLS;'||wwv_flow.LF||
'DROP TABLE FSP_COUNTRIES;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(4918258002797354368)
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
