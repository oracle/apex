prompt --application/deployment/install/install_faceted_search_patterns_data_pkg
begin
--   Manifest
--     INSTALL: INSTALL-faceted_search_patterns_data_pkg
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    --FSP_COUNTRIES: 249/10000 rows exported, APEX$DATA$PKG/FSP_COUNTRIES$663609'||wwv_flow.LF||
'    apex_data';
wwv_flow_imp.g_varchar2_table(2) := '_install.load_supporting_object_data(p_table_name => ''FSP_COUNTRIES'', p_delete_after_install => fals';
wwv_flow_imp.g_varchar2_table(3) := 'e );'||wwv_flow.LF||
'    --FSP_COST_CENTERS: 10/10000 rows exported, APEX$DATA$PKG/FSP_COST_CENTERS$188552'||wwv_flow.LF||
'    apex_';
wwv_flow_imp.g_varchar2_table(4) := 'data_install.load_supporting_object_data(p_table_name => ''FSP_COST_CENTERS'', p_delete_after_install ';
wwv_flow_imp.g_varchar2_table(5) := '=> false );'||wwv_flow.LF||
'    --FSP_GROUPS: 8/10000 rows exported, APEX$DATA$PKG/FSP_GROUPS$17017'||wwv_flow.LF||
'    apex_data_in';
wwv_flow_imp.g_varchar2_table(6) := 'stall.load_supporting_object_data(p_table_name => ''FSP_GROUPS'', p_delete_after_install => false );'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(7) := '   --FSP_SKILLS: 15/10000 rows exported, APEX$DATA$PKG/FSP_SKILLS$950790'||wwv_flow.LF||
'    apex_data_install.load_';
wwv_flow_imp.g_varchar2_table(8) := 'supporting_object_data(p_table_name => ''FSP_SKILLS'', p_delete_after_install => false );'||wwv_flow.LF||
'    --FSP_LO';
wwv_flow_imp.g_varchar2_table(9) := 'CATIONS: 12/10000 rows exported, APEX$DATA$PKG/FSP_LOCATIONS$280096'||wwv_flow.LF||
'    apex_data_install.load_suppo';
wwv_flow_imp.g_varchar2_table(10) := 'rting_object_data(p_table_name => ''FSP_LOCATIONS'', p_delete_after_install => false );'||wwv_flow.LF||
'    --FSP_EMPL';
wwv_flow_imp.g_varchar2_table(11) := 'OYEES: 120/10000 rows exported, APEX$DATA$PKG/FSP_EMPLOYEES$534467'||wwv_flow.LF||
'    apex_data_install.load_suppor';
wwv_flow_imp.g_varchar2_table(12) := 'ting_object_data(p_table_name => ''FSP_EMPLOYEES'', p_delete_after_install => false );'||wwv_flow.LF||
'    --FSP_EMPLO';
wwv_flow_imp.g_varchar2_table(13) := 'YEE_EVENTS: 360/10000 rows exported, APEX$DATA$PKG/FSP_EMPLOYEE_EVENTS$50463'||wwv_flow.LF||
'    apex_data_install.l';
wwv_flow_imp.g_varchar2_table(14) := 'oad_supporting_object_data(p_table_name => ''FSP_EMPLOYEE_EVENTS'', p_delete_after_install => false );';
wwv_flow_imp.g_varchar2_table(15) := ''||wwv_flow.LF||
'    --FSP_EMPLOYEE_GROUPS: 264/10000 rows exported, APEX$DATA$PKG/FSP_EMPLOYEE_GROUPS$182398'||wwv_flow.LF||
'    ap';
wwv_flow_imp.g_varchar2_table(16) := 'ex_data_install.load_supporting_object_data(p_table_name => ''FSP_EMPLOYEE_GROUPS'', p_delete_after_in';
wwv_flow_imp.g_varchar2_table(17) := 'stall => false );'||wwv_flow.LF||
'    --FSP_EMPLOYEE_SKILLS: 360/10000 rows exported, APEX$DATA$PKG/FSP_EMPLOYEE_SKI';
wwv_flow_imp.g_varchar2_table(18) := 'LLS$908337'||wwv_flow.LF||
'    apex_data_install.load_supporting_object_data(p_table_name => ''FSP_EMPLOYEE_SKILLS'', ';
wwv_flow_imp.g_varchar2_table(19) := 'p_delete_after_install => false );'||wwv_flow.LF||
'    --FSP_PATTERNS: 10/10000 rows exported, APEX$DATA$PKG/FSP_PAT';
wwv_flow_imp.g_varchar2_table(20) := 'TERNS$674302'||wwv_flow.LF||
'    apex_data_install.load_supporting_object_data(p_table_name => ''FSP_PATTERNS'', p_del';
wwv_flow_imp.g_varchar2_table(21) := 'ete_after_install => false );'||wwv_flow.LF||
'    --FSP_TASKS: 100/10000 rows exported, APEX$DATA$PKG/FSP_TASKS$6822';
wwv_flow_imp.g_varchar2_table(22) := '87'||wwv_flow.LF||
'    apex_data_install.load_supporting_object_data(p_table_name => ''FSP_TASKS'', p_delete_after_ins';
wwv_flow_imp.g_varchar2_table(23) := 'tall => false );'||wwv_flow.LF||
'end;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(5347610477212485864)
,p_install_id=>wwv_flow_imp.id(4918258002797354368)
,p_name=>'faceted_search_patterns_data_pkg'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
