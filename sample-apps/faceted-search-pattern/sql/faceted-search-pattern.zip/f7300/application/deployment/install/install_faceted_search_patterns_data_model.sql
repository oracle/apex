prompt --application/deployment/install/install_faceted_search_patterns_data_model
begin
--   Manifest
--     INSTALL: INSTALL-faceted_search_patterns_data_model
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '  CREATE TABLE "FSP_EMPLOYEES" '||wwv_flow.LF||
'   (	"EMPLOYEE_ID" NUMBER DEFAULT ON NULL to_number(sys_guid(), ''XXX';
wwv_flow_imp.g_varchar2_table(2) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') NOT NULL ENABLE, '||wwv_flow.LF||
'	"FIRST_NAME" VARCHAR2(100 CHAR) NOT NULL ENABLE, ';
wwv_flow_imp.g_varchar2_table(3) := ''||wwv_flow.LF||
'	"LAST_NAME" VARCHAR2(100 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"EMAIL" VARCHAR2(320 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"U';
wwv_flow_imp.g_varchar2_table(4) := 'SER_ID" VARCHAR2(255 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"COUNTRY" VARCHAR2(100 CHAR), '||wwv_flow.LF||
'	"GEOGRAPHIC_REGION" VA';
wwv_flow_imp.g_varchar2_table(5) := 'RCHAR2(100 CHAR), '||wwv_flow.LF||
'	"CITY" VARCHAR2(100 CHAR), '||wwv_flow.LF||
'	"CAREER_LEVEL" VARCHAR2(50 CHAR), '||wwv_flow.LF||
'	"JOB_TITLE" VAR';
wwv_flow_imp.g_varchar2_table(6) := 'CHAR2(200 CHAR), '||wwv_flow.LF||
'	"COST_CENTER_ID" NUMBER, '||wwv_flow.LF||
'	"MANAGER_ID" NUMBER, '||wwv_flow.LF||
'	"ORG_SIZE" NUMBER, '||wwv_flow.LF||
'	"DIRECT_RE';
wwv_flow_imp.g_varchar2_table(7) := 'PORTS" NUMBER, '||wwv_flow.LF||
'	"PHONE_COUNTRY_CODE" VARCHAR2(8 CHAR), '||wwv_flow.LF||
'	"PHONE_NUMBER" VARCHAR2(32 CHAR), '||wwv_flow.LF||
'	"PROFI';
wwv_flow_imp.g_varchar2_table(8) := 'LE" JSON, '||wwv_flow.LF||
'	"TAGS" JSON, '||wwv_flow.LF||
'	"PERMALINK" VARCHAR2(1000 CHAR), '||wwv_flow.LF||
'	"TIMEZONE" VARCHAR2(64 CHAR), '||wwv_flow.LF||
'	"GENDE';
wwv_flow_imp.g_varchar2_table(9) := 'R" VARCHAR2(1 CHAR), '||wwv_flow.LF||
'	"LOCATION_ID" NUMBER, '||wwv_flow.LF||
'	"HIRE_DATE" DATE, '||wwv_flow.LF||
'	"LAST_PROMOTION_DATE" DATE, '||wwv_flow.LF||
'	"EM';
wwv_flow_imp.g_varchar2_table(10) := 'PLOYMENT_STATUS" VARCHAR2(20 CHAR) DEFAULT ''ACTIVE'' NOT NULL ENABLE, '||wwv_flow.LF||
'	"EMPLOYMENT_TYPE" VARCHAR2(20';
wwv_flow_imp.g_varchar2_table(11) := ' CHAR) DEFAULT ''FULL_TIME'' NOT NULL ENABLE, '||wwv_flow.LF||
'	"WORK_ARRANGEMENT" VARCHAR2(20 CHAR) DEFAULT ''HYBRID'' ';
wwv_flow_imp.g_varchar2_table(12) := 'NOT NULL ENABLE, '||wwv_flow.LF||
'	"REMOTE_ELIGIBLE_YN" CHAR(1 CHAR) DEFAULT ''N'' NOT NULL ENABLE, '||wwv_flow.LF||
'	"AVATAR" VARCHAR';
wwv_flow_imp.g_varchar2_table(13) := '2(100), '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEES_ORG_SIZE_CK" CHECK (org_size is null or org_size >= 0) ENABLE, ';
wwv_flow_imp.g_varchar2_table(14) := ''||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEES_DIRECT_REPORTS_CK" CHECK (direct_reports is null or direct_reports >= 0';
wwv_flow_imp.g_varchar2_table(15) := ') ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEE_ID_PK" PRIMARY KEY ("EMPLOYEE_ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 C';
wwv_flow_imp.g_varchar2_table(16) := 'ONSTRAINT "FSP_EMPLOYEES_EMAIL_UK" UNIQUE ("EMAIL")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOY';
wwv_flow_imp.g_varchar2_table(17) := 'EES_USER_ID_UK" UNIQUE ("USER_ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEES_STATUS_CK" CH';
wwv_flow_imp.g_varchar2_table(18) := 'ECK (employment_status in (''ACTIVE'', ''LEAVE'', ''INACTIVE'')) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEES_TYPE';
wwv_flow_imp.g_varchar2_table(19) := '_CK" CHECK (employment_type in (''FULL_TIME'', ''PART_TIME'', ''CONTRACTOR'')) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_';
wwv_flow_imp.g_varchar2_table(20) := 'EMPLOYEES_WORK_ARRANGE_CK" CHECK (work_arrangement in (''ONSITE'', ''HYBRID'', ''REMOTE'')) ENABLE, '||wwv_flow.LF||
'	 CON';
wwv_flow_imp.g_varchar2_table(21) := 'STRAINT "FSP_EMPLOYEES_REMOTE_YN_CK" CHECK (remote_eligible_yn in (''Y'', ''N'')) ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREAT';
wwv_flow_imp.g_varchar2_table(22) := 'E TABLE "FSP_COST_CENTERS" '||wwv_flow.LF||
'   (	"COST_CENTER_ID" NUMBER DEFAULT ON NULL to_number(sys_guid(), ''XXXX';
wwv_flow_imp.g_varchar2_table(23) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXX'') NOT NULL ENABLE, '||wwv_flow.LF||
'	"COST_CENTER_DESCRIPTION" VARCHAR2(400 CHAR) NOT N';
wwv_flow_imp.g_varchar2_table(24) := 'ULL ENABLE, '||wwv_flow.LF||
'	"COST_CENTER_CODE" VARCHAR2(30 CHAR), '||wwv_flow.LF||
'	"BUSINESS_UNIT" VARCHAR2(100 CHAR), '||wwv_flow.LF||
'	"ACTIVE_';
wwv_flow_imp.g_varchar2_table(25) := 'YN" CHAR(1 CHAR) DEFAULT ''Y'' NOT NULL ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_COST_CENTER_ID_PK" PRIMARY KEY ("CO';
wwv_flow_imp.g_varchar2_table(26) := 'ST_CENTER_ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_COST_CENTERS_CODE_UK" UNIQUE ("COST_CENTER_';
wwv_flow_imp.g_varchar2_table(27) := 'CODE")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_COST_CENTERS_ACTIVE_CK" CHECK (active_yn in (''Y'', ''';
wwv_flow_imp.g_varchar2_table(28) := 'N'')) ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE TABLE "FSP_COUNTRIES" '||wwv_flow.LF||
'   (	"COUNTRY_CODE_ALPHA2" CHAR(2 CHAR), '||wwv_flow.LF||
'	"COUN';
wwv_flow_imp.g_varchar2_table(29) := 'TRY_CODE_ALPHA3" CHAR(3 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"REGION" VARCHAR2(20 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"COUN';
wwv_flow_imp.g_varchar2_table(30) := 'TRY_NAME" VARCHAR2(200 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"COUNTRY_NAME_ENGLISH" VARCHAR2(200 CHAR) NOT NULL E';
wwv_flow_imp.g_varchar2_table(31) := 'NABLE, '||wwv_flow.LF||
'	"CAPITAL_CITY" VARCHAR2(150 CHAR), '||wwv_flow.LF||
'	"ESTIMATED_POPULATION" NUMBER(15,0) NOT NULL ENABLE, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(32) := '	"ESTIMATED_POPULATION_YEAR" NUMBER(4,0) NOT NULL ENABLE, '||wwv_flow.LF||
'	"OFFICIAL_OR_COMMON_LANGUAGE" VARCHAR2(5';
wwv_flow_imp.g_varchar2_table(33) := '00 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"DESCRIPTION" VARCHAR2(500 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_COU';
wwv_flow_imp.g_varchar2_table(34) := 'NTRIES_ALPHA2_CK" CHECK (country_code_alpha2 = UPPER(country_code_alpha2)) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FS';
wwv_flow_imp.g_varchar2_table(35) := 'P_COUNTRIES_ALPHA3_CK" CHECK (country_code_alpha3 = UPPER(country_code_alpha3)) ENABLE, '||wwv_flow.LF||
'	 CONSTRAIN';
wwv_flow_imp.g_varchar2_table(36) := 'T "FSP_COUNTRIES_REGION_CK" CHECK (region IN (''Africa'', ''Americas'', ''Antarctica'', ''Asia'', ''Europe'', ';
wwv_flow_imp.g_varchar2_table(37) := '''Oceania'')) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_COUNTRIES_POPULATION_CK" CHECK (estimated_population >= 0) EN';
wwv_flow_imp.g_varchar2_table(38) := 'ABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_COUNTRIES_POPULATION_YEAR_CK" CHECK (estimated_population_year BETWEEN 1900';
wwv_flow_imp.g_varchar2_table(39) := ' AND 2100) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_COUNTRIES_PK" PRIMARY KEY ("COUNTRY_CODE_ALPHA2")'||wwv_flow.LF||
'  USING INDE';
wwv_flow_imp.g_varchar2_table(40) := 'X  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_COUNTRIES_ALPHA3_UK" UNIQUE ("COUNTRY_CODE_ALPHA3")'||wwv_flow.LF||
'  USING INDEX  ENA';
wwv_flow_imp.g_varchar2_table(41) := 'BLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE TABLE "FSP_EMPLOYEE_EVENTS" '||wwv_flow.LF||
'   (	"EVENT_ID" NUMBER DEFAULT ON NULL to_number(s';
wwv_flow_imp.g_varchar2_table(42) := 'ys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') NOT NULL ENABLE, '||wwv_flow.LF||
'	"EVENT_CODE" VARCHAR2(50 CHAR) NOT';
wwv_flow_imp.g_varchar2_table(43) := ' NULL ENABLE, '||wwv_flow.LF||
'	"EMPLOYEE_ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"LOCATION_ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"EVE';
wwv_flow_imp.g_varchar2_table(44) := 'NT_TYPE" VARCHAR2(30 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"EVENT_TITLE" VARCHAR2(200 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"E';
wwv_flow_imp.g_varchar2_table(45) := 'VENT_START" TIMESTAMP (6) NOT NULL ENABLE, '||wwv_flow.LF||
'	"EVENT_END" TIMESTAMP (6) NOT NULL ENABLE, '||wwv_flow.LF||
'	"EVENT_STA';
wwv_flow_imp.g_varchar2_table(46) := 'TUS" VARCHAR2(20 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"EVENT_SCOPE" VARCHAR2(20 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"DESCRI';
wwv_flow_imp.g_varchar2_table(47) := 'PTION" VARCHAR2(1000 CHAR), '||wwv_flow.LF||
'	"DELIVERY_MODE" VARCHAR2(20 CHAR) DEFAULT ''HYBRID'' NOT NULL ENABLE, '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(48) := ' CONSTRAINT "FSP_EMPLOYEE_EVENTS_TYPE_CK" CHECK (event_type in'||wwv_flow.LF||
'            (''PERFORMANCE_REVIEW'', ''T';
wwv_flow_imp.g_varchar2_table(49) := 'RAINING'', ''CERTIFICATION'', ''ONBOARDING'')) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEE_EVENTS_STATUS_CK" CHEC';
wwv_flow_imp.g_varchar2_table(50) := 'K (event_status in (''PLANNED'', ''COMPLETE'', ''CANCELLED'')) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEE_EVENTS_';
wwv_flow_imp.g_varchar2_table(51) := 'SCOPE_CK" CHECK (event_scope in (''INDIVIDUAL'', ''TEAM'', ''ORGANIZATION'')) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_E';
wwv_flow_imp.g_varchar2_table(52) := 'MPLOYEE_EVENTS_DATES_CK" CHECK (event_end > event_start) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEE_EVENT_I';
wwv_flow_imp.g_varchar2_table(53) := 'D_PK" PRIMARY KEY ("EVENT_ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEE_EVENTS_CODE_UK" UN';
wwv_flow_imp.g_varchar2_table(54) := 'IQUE ("EVENT_CODE")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEE_EVENTS_DELIVERY_MODE_CK" CHEC';
wwv_flow_imp.g_varchar2_table(55) := 'K (delivery_mode in (''IN_PERSON'', ''HYBRID'', ''VIRTUAL'')) ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE TABLE "FSP_EMPLOYEE_';
wwv_flow_imp.g_varchar2_table(56) := 'GROUPS" '||wwv_flow.LF||
'   (	"EMPLOYEE_GROUP_ID" NUMBER DEFAULT ON NULL to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(57) := 'XXXXXXXXXXXX'') NOT NULL ENABLE, '||wwv_flow.LF||
'	"EMPLOYEE_ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"GROUP_ID" NUMBER NOT NULL';
wwv_flow_imp.g_varchar2_table(58) := ' ENABLE, '||wwv_flow.LF||
'	"JOINED_DATE" DATE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEE_GROUP_ID_PK" PRIMARY KEY ("EMPLOYEE_GROUP';
wwv_flow_imp.g_varchar2_table(59) := '_ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEE_GROUPS_UK" UNIQUE ("EMPLOYEE_ID", "GROUP_ID';
wwv_flow_imp.g_varchar2_table(60) := '")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE TABLE "FSP_EMPLOYEE_SKILLS" '||wwv_flow.LF||
'   (	"EMPLOYEE_SKILL_ID" NUMB';
wwv_flow_imp.g_varchar2_table(61) := 'ER DEFAULT ON NULL to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') NOT NULL ENABLE, '||wwv_flow.LF||
'	"EMP';
wwv_flow_imp.g_varchar2_table(62) := 'LOYEE_ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"SKILL_ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"PROFICIENCY_LEVEL" NUMBER(';
wwv_flow_imp.g_varchar2_table(63) := '1,0) NOT NULL ENABLE, '||wwv_flow.LF||
'	"PRIMARY_YN" CHAR(1 CHAR) DEFAULT ''N'' NOT NULL ENABLE, '||wwv_flow.LF||
'	"CERTIFIED_YN" CHAR';
wwv_flow_imp.g_varchar2_table(64) := '(1 CHAR) DEFAULT ''N'' NOT NULL ENABLE, '||wwv_flow.LF||
'	"ACQUIRED_DATE" DATE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEE_SKILLS_LEV';
wwv_flow_imp.g_varchar2_table(65) := 'EL_CK" CHECK (proficiency_level between 1 and 5) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEE_SKILLS_PRIMARY_';
wwv_flow_imp.g_varchar2_table(66) := 'CK" CHECK (primary_yn in (''Y'', ''N'')) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEE_SKILLS_CERTIFIED_CK" CHECK ';
wwv_flow_imp.g_varchar2_table(67) := '(certified_yn in (''Y'', ''N'')) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEE_SKILL_ID_PK" PRIMARY KEY ("EMPLOYEE';
wwv_flow_imp.g_varchar2_table(68) := '_SKILL_ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_EMPLOYEE_SKILLS_UK" UNIQUE ("EMPLOYEE_ID", "SK';
wwv_flow_imp.g_varchar2_table(69) := 'ILL_ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE TABLE "FSP_GROUPS" '||wwv_flow.LF||
'   (	"GROUP_ID" NUMBER DEFAULT O';
wwv_flow_imp.g_varchar2_table(70) := 'N NULL to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') NOT NULL ENABLE, '||wwv_flow.LF||
'	"GROUP_NAME" VAR';
wwv_flow_imp.g_varchar2_table(71) := 'CHAR2(200 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"GROUP_DESCRIPTION" VARCHAR2(400 CHAR), '||wwv_flow.LF||
'	"GROUP_TYPE" VARCHAR2(3';
wwv_flow_imp.g_varchar2_table(72) := '0 CHAR), '||wwv_flow.LF||
'	"ACTIVE_YN" CHAR(1 CHAR) DEFAULT ''Y'' NOT NULL ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_GROUP_ID_PK" PRI';
wwv_flow_imp.g_varchar2_table(73) := 'MARY KEY ("GROUP_ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_GROUPS_GROUP_NAME_UK" UNIQUE ("GROUP';
wwv_flow_imp.g_varchar2_table(74) := '_NAME")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_GROUPS_ACTIVE_YN_CK" CHECK (active_yn in (''Y'', ''N''';
wwv_flow_imp.g_varchar2_table(75) := ')) ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE TABLE "FSP_LOCATIONS" '||wwv_flow.LF||
'   (	"LOCATION_ID" NUMBER DEFAULT ON NULL to_numbe';
wwv_flow_imp.g_varchar2_table(76) := 'r(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') NOT NULL ENABLE, '||wwv_flow.LF||
'	"LOCATION_CODE" VARCHAR2(30 CHA';
wwv_flow_imp.g_varchar2_table(77) := 'R) NOT NULL ENABLE, '||wwv_flow.LF||
'	"LOCATION_NAME" VARCHAR2(200 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"OFFICE_TYPE" VARCHAR2(3';
wwv_flow_imp.g_varchar2_table(78) := '0 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"CITY" VARCHAR2(100 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"COUNTRY_CODE_ALPHA2" CHAR(2';
wwv_flow_imp.g_varchar2_table(79) := ' CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"TIMEZONE" VARCHAR2(64 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"LATITUDE" NUMBER(9,6) NOT';
wwv_flow_imp.g_varchar2_table(80) := ' NULL ENABLE, '||wwv_flow.LF||
'	"LONGITUDE" NUMBER(9,6) NOT NULL ENABLE, '||wwv_flow.LF||
'	"OPENED_DATE" DATE, '||wwv_flow.LF||
'	"LOCATION_STATUS" V';
wwv_flow_imp.g_varchar2_table(81) := 'ARCHAR2(20 CHAR) DEFAULT ''ACTIVE'' NOT NULL ENABLE, '||wwv_flow.LF||
'	"CAPACITY" NUMBER(8,0), '||wwv_flow.LF||
'	 CONSTRAINT "FSP_LOCA';
wwv_flow_imp.g_varchar2_table(82) := 'TIONS_OFFICE_TYPE_CK" CHECK (office_type in (''HEADQUARTERS'', ''REGIONAL'', ''SATELLITE'', ''REMOTE_HUB''))';
wwv_flow_imp.g_varchar2_table(83) := ' ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_LOCATIONS_STATUS_CK" CHECK (location_status in (''ACTIVE'', ''PLANNED'', ''IN';
wwv_flow_imp.g_varchar2_table(84) := 'ACTIVE'')) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_LOCATIONS_LATITUDE_CK" CHECK (latitude between -90 and 90) ENAB';
wwv_flow_imp.g_varchar2_table(85) := 'LE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_LOCATIONS_LONGITUDE_CK" CHECK (longitude between -180 and 180) ENABLE, '||wwv_flow.LF||
'	 CON';
wwv_flow_imp.g_varchar2_table(86) := 'STRAINT "FSP_LOCATIONS_CAPACITY_CK" CHECK (capacity is null or capacity >= 0) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT ';
wwv_flow_imp.g_varchar2_table(87) := '"FSP_LOCATION_ID_PK" PRIMARY KEY ("LOCATION_ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_LOCATIONS';
wwv_flow_imp.g_varchar2_table(88) := '_CODE_UK" UNIQUE ("LOCATION_CODE")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE TABLE "FSP_PATTERNS" '||wwv_flow.LF||
'   (';
wwv_flow_imp.g_varchar2_table(89) := '	"PATTERN_ID" NUMBER DEFAULT ON NULL to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') NOT N';
wwv_flow_imp.g_varchar2_table(90) := 'ULL ENABLE, '||wwv_flow.LF||
'	"PATTERN_CODE" VARCHAR2(10 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"PATTERN_NAME" VARCHAR2(100 CHAR) ';
wwv_flow_imp.g_varchar2_table(91) := 'NOT NULL ENABLE, '||wwv_flow.LF||
'	"COMPONENT_TYPE" VARCHAR2(100 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"PATTERN_SUMMARY" VARCHAR2';
wwv_flow_imp.g_varchar2_table(92) := '(500 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"ICON_CLASS" VARCHAR2(100 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"PAGE_NO" NUMBER(3,';
wwv_flow_imp.g_varchar2_table(93) := '0) NOT NULL ENABLE, '||wwv_flow.LF||
'	"DISPLAY_SEQUENCE" NUMBER(3,0) NOT NULL ENABLE, '||wwv_flow.LF||
'	"ACTIVE_YN" CHAR(1 CHAR) DEF';
wwv_flow_imp.g_varchar2_table(94) := 'AULT ''Y'' NOT NULL ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_PATTERNS_ACTIVE_YN_CK" CHECK (active_yn in (''Y'', ''N'')) ';
wwv_flow_imp.g_varchar2_table(95) := 'ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_PATTERN_ID_PK" PRIMARY KEY ("PATTERN_ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONST';
wwv_flow_imp.g_varchar2_table(96) := 'RAINT "FSP_PATTERNS_CODE_UK" UNIQUE ("PATTERN_CODE")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_PATTE';
wwv_flow_imp.g_varchar2_table(97) := 'RNS_PAGE_NO_UK" UNIQUE ("PAGE_NO")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE TABLE "FSP_SKILLS" '||wwv_flow.LF||
'   (	"';
wwv_flow_imp.g_varchar2_table(98) := 'SKILL_ID" NUMBER DEFAULT ON NULL to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') NOT NULL ';
wwv_flow_imp.g_varchar2_table(99) := 'ENABLE, '||wwv_flow.LF||
'	"SKILL_CODE" VARCHAR2(30 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"SKILL_NAME" VARCHAR2(100 CHAR) NOT NULL';
wwv_flow_imp.g_varchar2_table(100) := ' ENABLE, '||wwv_flow.LF||
'	"SKILL_CATEGORY" VARCHAR2(100 CHAR) NOT NULL ENABLE, '||wwv_flow.LF||
'	"ACTIVE_YN" CHAR(1 CHAR) DEFAULT ''';
wwv_flow_imp.g_varchar2_table(101) := 'Y'' NOT NULL ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_SKILLS_ACTIVE_YN_CK" CHECK (active_yn in (''Y'', ''N'')) ENABLE, ';
wwv_flow_imp.g_varchar2_table(102) := ''||wwv_flow.LF||
'	 CONSTRAINT "FSP_SKILL_ID_PK" PRIMARY KEY ("SKILL_ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_S';
wwv_flow_imp.g_varchar2_table(103) := 'KILLS_CODE_UK" UNIQUE ("SKILL_CODE")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "FSP_SKILLS_NAME_UK" UNIQU';
wwv_flow_imp.g_varchar2_table(104) := 'E ("SKILL_NAME")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE TABLE "FSP_TASKS" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"TASK';
wwv_flow_imp.g_varchar2_table(105) := '_NAME" VARCHAR2(255 CHAR), '||wwv_flow.LF||
'	"ASSIGNED_TO_EMPNO" NUMBER, '||wwv_flow.LF||
'	"ASSIGNED_TO_NAME" VARCHAR2(255 CHAR), '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(106) := '"ASSIGNED_TO_EMAIL" VARCHAR2(320 CHAR), '||wwv_flow.LF||
'	"HOURS_ALLOCATED" NUMBER, '||wwv_flow.LF||
'	"WORK_MODE" VARCHAR2(255 CHAR)';
wwv_flow_imp.g_varchar2_table(107) := ', '||wwv_flow.LF||
'	"START_DATE" DATE, '||wwv_flow.LF||
'	"END_DATE" DATE, '||wwv_flow.LF||
'	"STATUS" VARCHAR2(25 CHAR), '||wwv_flow.LF||
'	"CALENDAR_COLOR" VARCHAR2(';
wwv_flow_imp.g_varchar2_table(108) := '30 CHAR), '||wwv_flow.LF||
'	 CONSTRAINT "FSP_TASKS_PK" PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'   COMMENT O';
wwv_flow_imp.g_varchar2_table(109) := 'N COLUMN "FSP_COUNTRIES"."COUNTRY_CODE_ALPHA2" IS ''ISO 3166-1 Alpha-2 code; primary key.'';'||wwv_flow.LF||
'   COMMEN';
wwv_flow_imp.g_varchar2_table(110) := 'T ON COLUMN "FSP_COUNTRIES"."COUNTRY_CODE_ALPHA3" IS ''ISO 3166-1 Alpha-3 code.'';'||wwv_flow.LF||
'   COMMENT ON COLUM';
wwv_flow_imp.g_varchar2_table(111) := 'N "FSP_COUNTRIES"."REGION" IS ''UN M49 broad geographic region.'';'||wwv_flow.LF||
'   COMMENT ON COLUMN "FSP_COUNTRIES';
wwv_flow_imp.g_varchar2_table(112) := '"."COUNTRY_NAME" IS ''Country or territory name in a native/local spelling.'';'||wwv_flow.LF||
'   COMMENT ON COLUMN "F';
wwv_flow_imp.g_varchar2_table(113) := 'SP_COUNTRIES"."COUNTRY_NAME_ENGLISH" IS ''Country or territory name in common US English.'';'||wwv_flow.LF||
'   COMMEN';
wwv_flow_imp.g_varchar2_table(114) := 'T ON COLUMN "FSP_COUNTRIES"."CAPITAL_CITY" IS ''Capital city in English; null where no permanent capi';
wwv_flow_imp.g_varchar2_table(115) := 'tal is applicable.'';'||wwv_flow.LF||
'   COMMENT ON COLUMN "FSP_COUNTRIES"."ESTIMATED_POPULATION" IS ''Estimated resid';
wwv_flow_imp.g_varchar2_table(116) := 'ent population for the associated estimate year.'';'||wwv_flow.LF||
'   COMMENT ON COLUMN "FSP_COUNTRIES"."ESTIMATED_P';
wwv_flow_imp.g_varchar2_table(117) := 'OPULATION_YEAR" IS ''Year represented by estimated_population.'';'||wwv_flow.LF||
'   COMMENT ON COLUMN "FSP_COUNTRIES"';
wwv_flow_imp.g_varchar2_table(118) := '."OFFICIAL_OR_COMMON_LANGUAGE" IS ''Official or most commonly used language(s).'';'||wwv_flow.LF||
'   COMMENT ON COLUM';
wwv_flow_imp.g_varchar2_table(119) := 'N "FSP_COUNTRIES"."DESCRIPTION" IS ''Short country or territory description, limited to 500 character';
wwv_flow_imp.g_varchar2_table(120) := 's.'';'||wwv_flow.LF||
'   COMMENT ON TABLE "FSP_COUNTRIES"  IS ''ISO 3166-1 country and territory reference data.'';'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(121) := 'ALTER TABLE "FSP_EMPLOYEES" ADD CONSTRAINT "FSP_EMPLOYEES_COST_CENTER_ID_FK" FOREIGN KEY ("COST_CENT';
wwv_flow_imp.g_varchar2_table(122) := 'ER_ID")'||wwv_flow.LF||
'	  REFERENCES "FSP_COST_CENTERS" ("COST_CENTER_ID") ENABLE;'||wwv_flow.LF||
'  ALTER TABLE "FSP_EMPLOYEES" AD';
wwv_flow_imp.g_varchar2_table(123) := 'D CONSTRAINT "FSP_EMPLOYEES_LOCATION_ID_FK" FOREIGN KEY ("LOCATION_ID")'||wwv_flow.LF||
'	  REFERENCES "FSP_LOCATIONS';
wwv_flow_imp.g_varchar2_table(124) := '" ("LOCATION_ID") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE INDEX "FSP_EMPLOYEES_STATUS_I" ON "FSP_EMPLOYEES" ("EMPLOYMENT_';
wwv_flow_imp.g_varchar2_table(125) := 'STATUS") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE INDEX "FSP_EMPLOYEES_LOCATION_I" ON "FSP_EMPLOYEES" ("LOCATION_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(126) := 'CREATE INDEX "FSP_EMPLOYEES_HIRE_DATE_I" ON "FSP_EMPLOYEES" ("HIRE_DATE") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE INDEX "FSP_';
wwv_flow_imp.g_varchar2_table(127) := 'EMPLOYEES_MANAGER_I" ON "FSP_EMPLOYEES" ("MANAGER_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE INDEX "FSP_EMPLOYEES_CAREER_LE';
wwv_flow_imp.g_varchar2_table(128) := 'VEL_I" ON "FSP_EMPLOYEES" ("CAREER_LEVEL") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE INDEX "FSP_EMPLOYEES_COST_CENTER_I" ON "FS';
wwv_flow_imp.g_varchar2_table(129) := 'P_EMPLOYEES" ("COST_CENTER_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'   COMMENT ON COLUMN "FSP_EMPLOYEES"."LOCATION_ID" IS ''Office ';
wwv_flow_imp.g_varchar2_table(130) := 'location used by map-aware and employee search patterns.'';'||wwv_flow.LF||
'   COMMENT ON COLUMN "FSP_EMPLOYEES"."HIR';
wwv_flow_imp.g_varchar2_table(131) := 'E_DATE" IS ''Employee hire date used by date-range facets.'';'||wwv_flow.LF||
'   COMMENT ON COLUMN "FSP_EMPLOYEES"."EM';
wwv_flow_imp.g_varchar2_table(132) := 'PLOYMENT_STATUS" IS ''Controlled employee status used by categorical facets.'';'||wwv_flow.LF||
'   COMMENT ON COLUMN "';
wwv_flow_imp.g_varchar2_table(133) := 'FSP_EMPLOYEES"."WORK_ARRANGEMENT" IS ''Onsite, hybrid, or remote working arrangement.'';'||wwv_flow.LF||
''||wwv_flow.LF||
'  ALTER TABL';
wwv_flow_imp.g_varchar2_table(134) := 'E "FSP_EMPLOYEE_EVENTS" ADD CONSTRAINT "FSP_EMPLOYEE_EVENTS_EMPLOYEE_FK" FOREIGN KEY ("EMPLOYEE_ID")';
wwv_flow_imp.g_varchar2_table(135) := ''||wwv_flow.LF||
'	  REFERENCES "FSP_EMPLOYEES" ("EMPLOYEE_ID") ENABLE;'||wwv_flow.LF||
'  ALTER TABLE "FSP_EMPLOYEE_EVENTS" ADD CONST';
wwv_flow_imp.g_varchar2_table(136) := 'RAINT "FSP_EMPLOYEE_EVENTS_LOCATION_FK" FOREIGN KEY ("LOCATION_ID")'||wwv_flow.LF||
'	  REFERENCES "FSP_LOCATIONS" ("';
wwv_flow_imp.g_varchar2_table(137) := 'LOCATION_ID") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE INDEX "FSP_EMPLOYEE_EVENTS_START_I" ON "FSP_EMPLOYEE_EVENTS" ("EVENT';
wwv_flow_imp.g_varchar2_table(138) := '_START") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE INDEX "FSP_EMPLOYEE_EVENTS_LOCATION_I" ON "FSP_EMPLOYEE_EVENTS" ("LOCATION_I';
wwv_flow_imp.g_varchar2_table(139) := 'D") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE INDEX "FSP_EMPLOYEE_EVENTS_TYPE_I" ON "FSP_EMPLOYEE_EVENTS" ("EVENT_TYPE") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(140) := '   COMMENT ON COLUMN "FSP_EMPLOYEE_EVENTS"."DELIVERY_MODE" IS ''How the workforce event is delivered:';
wwv_flow_imp.g_varchar2_table(141) := ' IN_PERSON, HYBRID, or VIRTUAL.'';'||wwv_flow.LF||
'   COMMENT ON TABLE "FSP_EMPLOYEE_EVENTS"  IS ''Synthetic employee ';
wwv_flow_imp.g_varchar2_table(142) := 'events used by Calendar and Timeline patterns.'';'||wwv_flow.LF||
''||wwv_flow.LF||
'  ALTER TABLE "FSP_EMPLOYEE_GROUPS" ADD CONSTRAINT';
wwv_flow_imp.g_varchar2_table(143) := ' "FSP_EMPLOYEE_GROUPS_EMPLOYEE_ID_FK" FOREIGN KEY ("EMPLOYEE_ID")'||wwv_flow.LF||
'	  REFERENCES "FSP_EMPLOYEES" ("EM';
wwv_flow_imp.g_varchar2_table(144) := 'PLOYEE_ID") ENABLE;'||wwv_flow.LF||
'  ALTER TABLE "FSP_EMPLOYEE_GROUPS" ADD CONSTRAINT "FSP_EMPLOYEE_GROUPS_GROUP_ID';
wwv_flow_imp.g_varchar2_table(145) := '_FK" FOREIGN KEY ("GROUP_ID")'||wwv_flow.LF||
'	  REFERENCES "FSP_GROUPS" ("GROUP_ID") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE INDEX "FSP_E';
wwv_flow_imp.g_varchar2_table(146) := 'MPLOYEE_GROUPS_EMPLOYEE_I" ON "FSP_EMPLOYEE_GROUPS" ("EMPLOYEE_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE INDEX "FSP_EMPLOY';
wwv_flow_imp.g_varchar2_table(147) := 'EE_GROUPS_GROUP_I" ON "FSP_EMPLOYEE_GROUPS" ("GROUP_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'  ALTER TABLE "FSP_EMPLOYEE_SKILLS" A';
wwv_flow_imp.g_varchar2_table(148) := 'DD CONSTRAINT "FSP_EMPLOYEE_SKILLS_EMPLOYEE_FK" FOREIGN KEY ("EMPLOYEE_ID")'||wwv_flow.LF||
'	  REFERENCES "FSP_EMPLO';
wwv_flow_imp.g_varchar2_table(149) := 'YEES" ("EMPLOYEE_ID") ENABLE;'||wwv_flow.LF||
'  ALTER TABLE "FSP_EMPLOYEE_SKILLS" ADD CONSTRAINT "FSP_EMPLOYEE_SKILL';
wwv_flow_imp.g_varchar2_table(150) := 'S_SKILL_FK" FOREIGN KEY ("SKILL_ID")'||wwv_flow.LF||
'	  REFERENCES "FSP_SKILLS" ("SKILL_ID") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE INDEX';
wwv_flow_imp.g_varchar2_table(151) := ' "FSP_EMPLOYEE_SKILLS_SKILL_I" ON "FSP_EMPLOYEE_SKILLS" ("SKILL_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'   COMMENT ON TABLE "FSP_';
wwv_flow_imp.g_varchar2_table(152) := 'EMPLOYEE_SKILLS"  IS ''Many-to-many employee skill assignments with proficiency attributes.'';'||wwv_flow.LF||
''||wwv_flow.LF||
'  ALTE';
wwv_flow_imp.g_varchar2_table(153) := 'R TABLE "FSP_LOCATIONS" ADD CONSTRAINT "FSP_LOCATIONS_COUNTRY_FK" FOREIGN KEY ("COUNTRY_CODE_ALPHA2"';
wwv_flow_imp.g_varchar2_table(154) := ')'||wwv_flow.LF||
'	  REFERENCES "FSP_COUNTRIES" ("COUNTRY_CODE_ALPHA2") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE INDEX "FSP_LOCATIONS_COUNT';
wwv_flow_imp.g_varchar2_table(155) := 'RY_I" ON "FSP_LOCATIONS" ("COUNTRY_CODE_ALPHA2") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'   COMMENT ON TABLE "FSP_LOCATIONS"  IS ''Offi';
wwv_flow_imp.g_varchar2_table(156) := 'ce locations with map coordinates and capacity attributes.'';'||wwv_flow.LF||
''||wwv_flow.LF||
'   COMMENT ON TABLE "FSP_PATTERNS"  IS';
wwv_flow_imp.g_varchar2_table(157) := ' ''Pattern metadata used by the Page 1 gallery cards.'';'||wwv_flow.LF||
''||wwv_flow.LF||
'   COMMENT ON TABLE "FSP_SKILLS"  IS ''Contro';
wwv_flow_imp.g_varchar2_table(158) := 'lled skill vocabulary used by employee skill facets.'';'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE OR REPLACE FORCE EDITIONABLE VIEW "';
wwv_flow_imp.g_varchar2_table(159) := 'FSP_EMPLOYEE_EVENTS_V" ("EVENT_ID", "EVENT_TITLE", "EVENT_START", "EVENT_END", "EVENT_TYPE", "EVENT_';
wwv_flow_imp.g_varchar2_table(160) := 'STATUS", "EVENT_SCOPE", "DELIVERY_MODE", "DESCRIPTION", "EMPLOYEE_ID", "FIRST_NAME", "LAST_NAME", "G';
wwv_flow_imp.g_varchar2_table(161) := 'EOGRAPHIC_REGION", "COST_CENTER", "EMPLOYEE_NAME", "EVENT_DISPLAY", "START_MONTH", "DURATION_HOURS",';
wwv_flow_imp.g_varchar2_table(162) := ' "EVENT_SUMMARY","LOCATION_ID") AS '||wwv_flow.LF||
'  SELECT ev.event_id,'||wwv_flow.LF||
'       ev.event_title,'||wwv_flow.LF||
'       ev.calendar_';
wwv_flow_imp.g_varchar2_table(163) := 'start AS event_start,'||wwv_flow.LF||
'       ev.calendar_end AS event_end,'||wwv_flow.LF||
'       ev.event_type,'||wwv_flow.LF||
'       ev.event_sta';
wwv_flow_imp.g_varchar2_table(164) := 'tus,'||wwv_flow.LF||
'       ev.event_scope,'||wwv_flow.LF||
'       ev.delivery_mode,'||wwv_flow.LF||
'       ev.description,'||wwv_flow.LF||
'       e.employee_id,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(165) := '     e.first_name,'||wwv_flow.LF||
'       e.last_name,'||wwv_flow.LF||
'       e.geographic_region,'||wwv_flow.LF||
'       cc.cost_center_description';
wwv_flow_imp.g_varchar2_table(166) := ' AS cost_center,'||wwv_flow.LF||
'       e.first_name || '' '' || e.last_name AS employee_name,'||wwv_flow.LF||
'       TO_CHAR(ev.calen';
wwv_flow_imp.g_varchar2_table(167) := 'dar_start, ''HH12:MI AM'') || '' - '' || TO_CHAR(ev.calendar_end, ''HH12:MI AM'') || CHR(10) || REGEXP_REP';
wwv_flow_imp.g_varchar2_table(168) := unistr('LACE(ev.event_title, '' \2014 .*$'', '''') || CHR(10) || e.first_name || '' '' || e.last_name AS event_display');
wwv_flow_imp.g_varchar2_table(169) := ','||wwv_flow.LF||
'       TO_CHAR(ev.calendar_start, ''FMMonth YYYY'', ''NLS_DATE_LANGUAGE=English'') AS start_month,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(170) := unistr('    ev.duration_hours,'||wwv_flow.LF||
'       INITCAP(REPLACE(ev.delivery_mode, ''_'', '' '')) || '' \00B7 '' || TO_CHAR(ev.du');
wwv_flow_imp.g_varchar2_table(171) := unistr('ration_hours, ''FM990D0'') || ''h \00B7 '' || INITCAP(LOWER(ev.event_status)) AS event_summary,'||wwv_flow.LF||
'       ev.lo');
wwv_flow_imp.g_varchar2_table(172) := 'cation_id'||wwv_flow.LF||
'  FROM ('||wwv_flow.LF||
'       SELECT s.*,'||wwv_flow.LF||
'              s.event_start + NUMTODSINTERVAL(TRUNC(SYSDATE) -';
wwv_flow_imp.g_varchar2_table(173) := ' DATE ''2026-07-01'', ''DAY'') AS calendar_start,'||wwv_flow.LF||
'              s.event_end + NUMTODSINTERVAL(TRUNC(SYSD';
wwv_flow_imp.g_varchar2_table(174) := 'ATE) - DATE ''2026-07-01'', ''DAY'') AS calendar_end,'||wwv_flow.LF||
'              ROUND((CAST(s.event_end AS DATE) - C';
wwv_flow_imp.g_varchar2_table(175) := 'AST(s.event_start AS DATE)) * 24, 2) AS duration_hours'||wwv_flow.LF||
'         FROM fsp_employee_events s'||wwv_flow.LF||
'       ) ';
wwv_flow_imp.g_varchar2_table(176) := 'ev'||wwv_flow.LF||
'  JOIN fsp_employees e'||wwv_flow.LF||
'    ON e.employee_id = ev.employee_id'||wwv_flow.LF||
'  LEFT JOIN fsp_cost_centers cc'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(177) := 'ON cc.cost_center_id = e.cost_center_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'  CREATE OR REPLACE FORCE EDITIONABLE VIEW "FSP_EMPLOYEE_O';
wwv_flow_imp.g_varchar2_table(178) := 'RG_V" ("EMPLOYEE_ID", "FIRST_NAME", "LAST_NAME", "EMAIL", "USER_ID", "COUNTRY", "GEOGRAPHIC_REGION",';
wwv_flow_imp.g_varchar2_table(179) := ' "CITY", "CAREER_LEVEL", "JOB_TITLE", "COST_CENTER_ID", "COST_CENTER_DESCRIPTION", "MANAGER_ID", "OR';
wwv_flow_imp.g_varchar2_table(180) := 'G_SIZE", "DIRECT_REPORTS", "PHONE_COUNTRY_CODE", "PHONE_NUMBER", "PROFILE", "TAGS", "PERMALINK", "TI';
wwv_flow_imp.g_varchar2_table(181) := 'MEZONE", "GROUP_ID", "GROUP_NAME", "GROUP_DESCRIPTION") AS '||wwv_flow.LF||
'  select'||wwv_flow.LF||
'  e.employee_id,'||wwv_flow.LF||
'  e.first_name';
wwv_flow_imp.g_varchar2_table(182) := ','||wwv_flow.LF||
'  e.last_name,'||wwv_flow.LF||
'  e.email,'||wwv_flow.LF||
'  e.user_id,'||wwv_flow.LF||
'  e.country,'||wwv_flow.LF||
'  e.geographic_region,'||wwv_flow.LF||
'  e.city,'||wwv_flow.LF||
'  e.career_le';
wwv_flow_imp.g_varchar2_table(183) := 'vel,'||wwv_flow.LF||
'  e.job_title,'||wwv_flow.LF||
'  e.cost_center_id,'||wwv_flow.LF||
'  cc.cost_center_description,'||wwv_flow.LF||
'  e.manager_id,'||wwv_flow.LF||
'  e.org_size,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(184) := '  e.direct_reports,'||wwv_flow.LF||
'  e.phone_country_code,'||wwv_flow.LF||
'  e.phone_number,'||wwv_flow.LF||
'  e.profile,'||wwv_flow.LF||
'  e.tags,'||wwv_flow.LF||
'  e.permalink,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(185) := '  e.timezone,'||wwv_flow.LF||
'  g.group_id,'||wwv_flow.LF||
'  g.group_name,'||wwv_flow.LF||
'  g.group_description'||wwv_flow.LF||
'from fsp_employees e'||wwv_flow.LF||
'left join fsp';
wwv_flow_imp.g_varchar2_table(186) := '_cost_centers cc'||wwv_flow.LF||
'  on cc.cost_center_id = e.cost_center_id'||wwv_flow.LF||
'left join fsp_employee_groups eg'||wwv_flow.LF||
'  on eg.';
wwv_flow_imp.g_varchar2_table(187) := 'employee_id = e.employee_id'||wwv_flow.LF||
'left join fsp_groups g'||wwv_flow.LF||
'  on g.group_id = eg.group_id;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(5344125080361249230)
,p_install_id=>wwv_flow_imp.id(4918258002797354368)
,p_name=>'faceted_search_patterns_data_model'
,p_sequence=>5
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344125178289249236)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FSP_COST_CENTERS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344125385704249237)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FSP_COUNTRIES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344125570791249238)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FSP_EMPLOYEES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344125816226249238)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FSP_EMPLOYEE_EVENTS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344126038249249238)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FSP_EMPLOYEE_GROUPS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344126233566249238)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FSP_EMPLOYEE_SKILLS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344126349066249238)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FSP_GROUPS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344126635990249238)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FSP_LOCATIONS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344126786311249238)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FSP_PATTERNS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344126983067249239)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FSP_SKILLS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344127139318249239)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FSP_TASKS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344127375519249239)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_COST_CENTERS_CODE_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344127624449249239)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_COST_CENTER_ID_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344127795547249239)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_COUNTRIES_ALPHA3_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344127986316249239)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_COUNTRIES_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344128155717249239)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEES_CAREER_LEVEL_I'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344128357027249239)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEES_COST_CENTER_I'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344128631093249240)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEES_EMAIL_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344128777024249240)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEES_HIRE_DATE_I'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344128971169249240)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEES_LOCATION_I'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344129160980249240)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEES_MANAGER_I'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344129423427249240)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEES_STATUS_I'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344129574789249240)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEES_USER_ID_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344129803028249241)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEE_EVENTS_CODE_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344130007394249241)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEE_EVENTS_LOCATION_I'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344130230305249241)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEE_EVENTS_START_I'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344130389384249241)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEE_EVENTS_TYPE_I'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344130554993249241)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEE_EVENT_ID_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344130803047249242)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEE_GROUPS_EMPLOYEE_I'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344130948473249242)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEE_GROUPS_GROUP_I'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344131213757249242)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEE_GROUPS_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344131366512249242)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEE_GROUP_ID_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344131554156249242)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEE_ID_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344131765846249242)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEE_SKILLS_SKILL_I'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344132035539249242)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEE_SKILLS_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344132183083249242)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_EMPLOYEE_SKILL_ID_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344132356106249243)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_GROUPS_GROUP_NAME_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344132567938249243)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_GROUP_ID_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344132824856249243)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_LOCATIONS_CODE_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344133024482249243)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_LOCATIONS_COUNTRY_I'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344133223111249243)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_LOCATION_ID_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344133434683249243)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_PATTERNS_CODE_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344133590605249243)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_PATTERNS_PAGE_NO_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344133810626249243)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_PATTERN_ID_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344133989493249244)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_SKILLS_CODE_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344134193785249244)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_SKILLS_NAME_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344134392043249244)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_SKILL_ID_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344134571065249244)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FSP_TASKS_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344134833775249244)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'FSP_EMPLOYEE_EVENTS_V'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344135016690249244)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'FSP_EMPLOYEE_ORG_V'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(5344135141639249244)
,p_script_id=>wwv_flow_imp.id(5344125080361249230)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'FSP_EMPLOYEE_ORG_V2'
);
wwv_flow_imp.component_end;
end;
/
