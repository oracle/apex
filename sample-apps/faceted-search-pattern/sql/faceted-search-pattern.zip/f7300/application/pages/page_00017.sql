prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>17
,p_name=>'FS-07 - Search Dashboard'
,p_alias=>'FS-07-SEARCH-DASHBOARD'
,p_step_title=>'FS-07 - Search Dashboard'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2530071015796209513
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>When to use</h3>',
'<p>Use this pattern to filter records and review both matching details and aggregate summaries. It suits use cases such as exploring a workforce, inventory, or service portfolio where counts and charts help reveal the distribution of the filtered res'
||'ults.</p>',
'',
'<h3>About this pattern page</h3>',
'<p>Search matches employee details. Job, Cost Center, Employment Status, and Work Arrangement facets support multiple selections. Choices within a facet match any selected value; different facets combine to narrow results. The Classic Report lists ma'
||'tching employees, metric cards summarize employee, job-role, and cost-center counts, and donut charts show their distribution. All summaries reflect the complete filtered result set, not just the current report page. Reset clears all selections.</p>'))
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7773231951538546198)
,p_plug_name=>'FS-07 - Search Dashboard'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(4402049144733325348)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7773322593122948475)
,p_plug_name=>'Cost center distribution'
,p_static_id=>'cost-center-chart'
,p_region_name=>'cost-center-chart'
,p_icon_css_classes=>'fa-badge-dollar'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>6
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(4402891376419419560)
,p_region_id=>wwv_flow_imp.id(7773322593122948475)
,p_chart_type=>'donut'
,p_lazy_loading=>true
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(4402891937393419569)
,p_chart_id=>wwv_flow_imp.id(4402891376419419560)
,p_static_id=>'employee-counts'
,p_seq=>10
,p_name=>'Matching employees'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    with employee_data as (',
'        select e.employee_id id,',
'               trim(e.first_name || '' '' || e.last_name) name,',
'               e.email,',
'               e.job_title job,',
'               coalesce(c.cost_center_description, c.cost_center_code, ''Unassigned'') cost_center,',
'               e.timezone time_zone,',
'               initcap(e.work_arrangement) work_mode,',
'               initcap(e.employment_status) employment_status,',
'               e.country,',
'               e.career_level,',
'               e.cost_center_id',
'          from fsp_employees e',
'          left join fsp_cost_centers c on c.cost_center_id = e.cost_center_id',
'    ), search_terms as (',
'        select lower(replace(',
'                   case when substr(token, 1, 1) = ''"'' and substr(token, -1) = ''"''',
'                        then substr(token, 2, length(token) - 2) else token end,',
'                   ''""'', ''"'')) term',
'          from (',
'            select regexp_substr(:P17_SEARCH, ''"([^"]|"")*"|[^[:space:]]+'', 1, level) token',
'              from dual',
'            connect by level <= regexp_count(:P17_SEARCH, ''"([^"]|"")*"|[^[:space:]]+'')',
'          )',
'    ), matches as (',
'        select e.*',
'          from employee_data e',
'         where (:P17_COST_CENTER is null or e.cost_center in (',
'                    select column_value from table(apex_string.split(:P17_COST_CENTER, '':''))))',
'           and (:P17_JOB is null or e.job in (',
'                    select column_value from table(apex_string.split(:P17_JOB, '':''))))',
'           and (:P17_STATUS is null or e.employment_status in (',
'                    select column_value from table(apex_string.split(:P17_STATUS, '':''))))',
'           and (:P17_WORK_MODE is null or e.work_mode in (',
'                    select column_value from table(apex_string.split(:P17_WORK_MODE, '':''))))',
'           and not exists (',
'                    select 1 from search_terms t',
'                     where t.term is not null',
'                       and instr(lower(nvl(e.name, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.email, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.job, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.cost_center, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.time_zone, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.work_mode, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.employment_status, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.country, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.career_level, '' '')), t.term) = 0)',
'    )',
'    select cost_center label, count(*) employee_count',
'      from matches',
'     group by cost_center',
'     order by employee_count desc, label'))
,p_ajax_items_to_submit=>'P17_SEARCH,P17_COST_CENTER,P17_JOB,P17_STATUS,P17_WORK_MODE'
,p_series_type=>'donut'
,p_items_value_column_name=>'EMPLOYEE_COUNT'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>false
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7773233951063546223)
,p_plug_name=>'Matching employee metrics'
,p_static_id=>'dashboard-metrics'
,p_region_name=>'dashboard-metrics'
,p_icon_css_classes=>'fa-id-card'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    with employee_data as (',
'        select e.employee_id id,',
'               trim(e.first_name || '' '' || e.last_name) name,',
'               e.email,',
'               e.job_title job,',
'               coalesce(c.cost_center_description, c.cost_center_code, ''Unassigned'') cost_center,',
'               e.timezone time_zone,',
'               initcap(e.work_arrangement) work_mode,',
'               initcap(e.employment_status) employment_status,',
'               e.country,',
'               e.career_level,',
'               e.cost_center_id',
'          from fsp_employees e',
'          left join fsp_cost_centers c on c.cost_center_id = e.cost_center_id',
'    ), search_terms as (',
'        select lower(replace(',
'                   case when substr(token, 1, 1) = ''"'' and substr(token, -1) = ''"''',
'                        then substr(token, 2, length(token) - 2) else token end,',
'                   ''""'', ''"'')) term',
'          from (',
'            select regexp_substr(:P17_SEARCH, ''"([^"]|"")*"|[^[:space:]]+'', 1, level) token',
'              from dual',
'            connect by level <= regexp_count(:P17_SEARCH, ''"([^"]|"")*"|[^[:space:]]+'')',
'          )',
'    ), matches as (',
'        select e.*',
'          from employee_data e',
'         where (:P17_COST_CENTER is null or e.cost_center in (',
'                    select column_value from table(apex_string.split(:P17_COST_CENTER, '':''))))',
'           and (:P17_JOB is null or e.job in (',
'                    select column_value from table(apex_string.split(:P17_JOB, '':''))))',
'           and (:P17_STATUS is null or e.employment_status in (',
'                    select column_value from table(apex_string.split(:P17_STATUS, '':''))))',
'           and (:P17_WORK_MODE is null or e.work_mode in (',
'                    select column_value from table(apex_string.split(:P17_WORK_MODE, '':''))))',
'           and not exists (',
'                    select 1 from search_terms t',
'                     where t.term is not null',
'                       and instr(lower(nvl(e.name, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.email, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.job, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.cost_center, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.time_zone, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.work_mode, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.employment_status, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.country, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.career_level, '' '')), t.term) = 0)',
'    ), stats as (',
'        select count(*) employee_count,',
'               count(distinct job) job_count,',
'               count(distinct cost_center_id) cost_center_count',
'          from matches',
'    )',
'    select 1 sort_order, ''Employees count'' label,',
'           to_char(employee_count, ''FM999G999G990'') metric_value, ''fa-users'' icon from stats',
'    union all',
'    select 2, ''Job roles represented'',',
'           to_char(job_count, ''FM999G999G990''), ''fa-briefcase'' from stats',
'    union all',
'    select 3, ''Cost centers represented'',',
'           to_char(cost_center_count, ''FM999G999G990''), ''fa-building-o'' from stats'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'SORT_ORDER'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$METRIC_CARD'
,p_ajax_items_to_submit=>'P17_SEARCH,P17_COST_CENTER,P17_JOB,P17_STATUS,P17_WORK_MODE'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AVATAR_ALIGNMENT', 't-MetricCard-body--avatarAlignmentStart',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_POSITION', 't-MetricCard-body--avatarPositionInline',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_STYLE', 't-MetricCard-avatar--subtle',
  'AVATAR_TYPE', 'icon',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'LAYOUT', '3cols',
  'META', '&LABEL.',
  'METRIC', '&METRIC_VALUE.',
  'METRIC_CSS_CLASSES', 'u-text-subheading-md u-color-1-text ')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7773234345548546223)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7773234108608546223)
,p_name=>'LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LABEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7773234213157546223)
,p_name=>'METRIC_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'METRIC_VALUE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7773234053301546223)
,p_name=>'SORT_ORDER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SORT_ORDER'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7773232142543546222)
,p_plug_name=>'Filter employees'
,p_static_id=>'search'
,p_region_name=>'employee-filters'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(7773232234094546222)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'current_facets_selector', '#active_facets',
  'show_charts', 'Y',
  'show_current_facets', 'E',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7773328514716948553)
,p_name=>'P17_COST_CENTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(7773232142543546222)
,p_prompt=>'Cost Center'
,p_source=>'COST_CENTER'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7773239025277546305)
,p_name=>'P17_JOB'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(7773232142543546222)
,p_prompt=>'Job'
,p_source=>'JOB'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7773239215707546305)
,p_name=>'P17_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7773232142543546222)
,p_prompt=>'Search'
,p_source=>'NAME,EMAIL,JOB,COST_CENTER,TIME_ZONE,WORK_MODE,EMPLOYMENT_STATUS,COUNTRY,CAREER_LEVEL'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7773328686753948553)
,p_name=>'P17_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(7773232142543546222)
,p_prompt=>'Employment Status'
,p_source=>'EMPLOYMENT_STATUS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>10
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7773239335346546305)
,p_name=>'P17_WORK_MODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(7773232142543546222)
,p_prompt=>'Work Arrangement'
,p_source=>'WORK_MODE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>10
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(7773232234094546222)
,p_name=>'Matching employees'
,p_static_id=>'search-results'
,p_region_name=>'search-results'
,p_template=>3374665444246510938
,p_display_sequence=>60
,p_icon_css_classes=>'fa-id-card'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--horizontalBorders'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    select e.employee_id id,',
'           trim(e.first_name || '' '' || e.last_name) name,',
'           apex_string.get_initials(e.first_name || '' '' || e.last_name) as initials,',
'           e.email,',
'           e.job_title job,',
'           coalesce(c.cost_center_description, c.cost_center_code, ''Unassigned'') cost_center,',
'           e.timezone time_zone,',
'           initcap(e.work_arrangement) work_mode,',
'           initcap(e.employment_status) employment_status,',
'           e.country,',
'           e.career_level,',
'           e.cost_center_id,',
'           case  when e.job_title =ANY (''Application Developer'',''BI Developer'',''Senior Software Engineer'',''Software Engineer'')  then ''success'' ',
'                 when e.job_title =ANY (''IT Service Manager'',''Enterprise Sales Manager'') then ''warning''',
'                 when e.job_title =ANY (''Compliance Analyst'',''Compliance Counsel'',''Ethics and Compliance Analyst'') then ''danger''',
'                 else ''info'' end job_title_state,',
'           case  loweR(e.employment_status) when ''active'' then ''fa fa-check-circle-o'' when ''inactive'' then ''fa fa-times-circle-o''   else ''fa fa-minus-circle-o'' end STATUS_ICON,',
'           case  loweR(e.employment_status) when  ''active'' then ''u-success-text''  when ''inactive'' then ''u-danger-text'' else ''u-warning-text'' end STATUS_STATE',
'      from fsp_employees e',
'      left join fsp_cost_centers c on c.cost_center_id = e.cost_center_id'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2542081983073888486
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No employees match these filters. Remove a filter or shorten your search.'
,p_query_row_count_max=>100000
,p_csv_output=>'N'
,p_prn_output=>'Y'
,p_prn_format=>'PDF'
,p_prn_output_link_text=>'<span class="fa fa-download" aria-hidden="true"></span> Download'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width_units=>'PERCENTAGE'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402897080854419590)
,p_query_column_id=>11
,p_column_alias=>'CAREER_LEVEL'
,p_column_display_sequence=>90
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402897506736419591)
,p_query_column_id=>6
,p_column_alias=>'COST_CENTER'
,p_column_display_sequence=>40
,p_column_heading=>'Cost Center'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402897878500419592)
,p_query_column_id=>12
,p_column_alias=>'COST_CENTER_ID'
,p_column_display_sequence=>100
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402898263638419592)
,p_query_column_id=>10
,p_column_alias=>'COUNTRY'
,p_column_display_sequence=>80
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402898708164419592)
,p_query_column_id=>4
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402899107612419593)
,p_query_column_id=>9
,p_column_alias=>'EMPLOYMENT_STATUS'
,p_column_display_sequence=>70
,p_column_heading=>'Employment Status'
,p_column_html_expression=>'<span class="#STATUS_ICON# #STATUS_STATE#"></span>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402899447201419593)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>0
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402901511549419595)
,p_query_column_id=>3
,p_column_alias=>'INITIALS'
,p_column_display_sequence=>140
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402899841906419594)
,p_query_column_id=>5
,p_column_alias=>'JOB'
,p_column_display_sequence=>30
,p_column_heading=>'Job'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{with/}',
'  LABEL:=Status',
'  VALUE:=#JOB#',
'  STATE:=#JOB_TITLE_STATE#',
'  LABEL_DISPLAY:=N',
'  STYLE:=t-Badge--subtle t-Badge--circle',
'  SIZE:=t-Badge--md',
'{apply THEME$BADGE/}'))
,p_column_alignment=>'CENTER'
,p_default_sort_column_sequence=>2
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402902696810419597)
,p_query_column_id=>13
,p_column_alias=>'JOB_TITLE_STATE'
,p_column_display_sequence=>110
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402900315255419594)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>10
,p_column_heading=>'Employee'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="display:flex; align-items:center; gap:8px;">',
'  {with/}',
'  TYPE:=INITIALS',
'  INITIALS:=#INITIALS#',
'  SIZE:=t-Avatar--xs',
'SHAPE:=t-Avatar--circle',
'CSS_CLASSES:=u-color-subtle u-text-secondary',
'  {apply THEME$AVATAR/}',
'  <span>#NAME#</span>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402901898246419597)
,p_query_column_id=>14
,p_column_alias=>'STATUS_ICON'
,p_column_display_sequence=>120
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402902338063419597)
,p_query_column_id=>15
,p_column_alias=>'STATUS_STATE'
,p_column_display_sequence=>130
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402900657522419594)
,p_query_column_id=>7
,p_column_alias=>'TIME_ZONE'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4402901044213419594)
,p_query_column_id=>8
,p_column_alias=>'WORK_MODE'
,p_column_display_sequence=>60
,p_column_heading=>'Work Arrangement'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7773234826495546225)
,p_plug_name=>'Work arrangement distribution'
,p_static_id=>'work-mode-chart'
,p_region_name=>'work-mode-chart'
,p_icon_css_classes=>'fa-laptop'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>6
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(4402903620441419598)
,p_region_id=>wwv_flow_imp.id(7773234826495546225)
,p_chart_type=>'donut'
,p_lazy_loading=>true
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(4402904095156419599)
,p_chart_id=>wwv_flow_imp.id(4402903620441419598)
,p_static_id=>'employee-counts'
,p_seq=>10
,p_name=>'Matching employees'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    with employee_data as (',
'        select e.employee_id id,',
'               trim(e.first_name || '' '' || e.last_name) name,',
'               e.email,',
'               e.job_title job,',
'               coalesce(c.cost_center_description, c.cost_center_code, ''Unassigned'') cost_center,',
'               e.timezone time_zone,',
'               initcap(e.work_arrangement) work_mode,',
'               initcap(e.employment_status) employment_status,',
'               e.country,',
'               e.career_level,',
'               e.cost_center_id',
'          from fsp_employees e',
'          left join fsp_cost_centers c on c.cost_center_id = e.cost_center_id',
'    ), search_terms as (',
'        select lower(replace(',
'                   case when substr(token, 1, 1) = ''"'' and substr(token, -1) = ''"''',
'                        then substr(token, 2, length(token) - 2) else token end,',
'                   ''""'', ''"'')) term',
'          from (',
'            select regexp_substr(:P17_SEARCH, ''"([^"]|"")*"|[^[:space:]]+'', 1, level) token',
'              from dual',
'            connect by level <= regexp_count(:P17_SEARCH, ''"([^"]|"")*"|[^[:space:]]+'')',
'          )',
'    ), matches as (',
'        select e.*',
'          from employee_data e',
'         where (:P17_COST_CENTER is null or e.cost_center in (',
'                    select column_value from table(apex_string.split(:P17_COST_CENTER, '':''))))',
'           and (:P17_JOB is null or e.job in (',
'                    select column_value from table(apex_string.split(:P17_JOB, '':''))))',
'           and (:P17_STATUS is null or e.employment_status in (',
'                    select column_value from table(apex_string.split(:P17_STATUS, '':''))))',
'           and (:P17_WORK_MODE is null or e.work_mode in (',
'                    select column_value from table(apex_string.split(:P17_WORK_MODE, '':''))))',
'           and not exists (',
'                    select 1 from search_terms t',
'                     where t.term is not null',
'                       and instr(lower(nvl(e.name, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.email, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.job, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.cost_center, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.time_zone, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.work_mode, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.employment_status, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.country, '' '')), t.term) = 0',
'                       and instr(lower(nvl(e.career_level, '' '')), t.term) = 0)',
'    )',
'    select nvl(work_mode, ''Unspecified'') label, count(*) employee_count',
'      from matches',
'     group by work_mode',
'     order by employee_count desc, label'))
,p_ajax_items_to_submit=>'P17_SEARCH,P17_COST_CENTER,P17_JOB,P17_STATUS,P17_WORK_MODE'
,p_series_type=>'donut'
,p_items_value_column_name=>'EMPLOYEE_COUNT'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4402889724730419553)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7773231951538546198)
,p_button_name=>'RESET'
,p_static_id=>'reset'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:17,RR'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4402906021881419601)
,p_name=>'Refresh Dashboard After Results Refresh'
,p_static_id=>'refresh-dashboard-regions'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(7773232234094546222)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
,p_da_event_comment=>'Each metric/chart region submits the five facet items and queries the local employee table directly. After Refresh keeps the summaries aligned with the completed Classic Report refresh. Initial summaries are rendered by their native SQL sources.'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4402906350263419601)
,p_event_id=>wwv_flow_imp.id(4402906021881419601)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Cost Center Distribution'
,p_static_id=>'refresh-cost-center-chart'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7773322593122948475)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4402906936669419605)
,p_event_id=>wwv_flow_imp.id(4402906021881419601)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Matching Employee Metrics'
,p_static_id=>'refresh-metrics'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7773233951063546223)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4402907425122419606)
,p_event_id=>wwv_flow_imp.id(4402906021881419601)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Work Arrangement Distribution'
,p_static_id=>'refresh-work-mode-chart'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7773234826495546225)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
