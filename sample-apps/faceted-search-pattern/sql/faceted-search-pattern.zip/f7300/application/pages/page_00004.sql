prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'FS-01 - Content Row'
,p_alias=>'FS-01-CONTENT-ROW'
,p_step_title=>'FS-01 - Content Row'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2530071015796209513
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>When to use</h3>',
'<p>Use this pattern to browse and manage an employee directory when people need to narrow a large list, compare key details at a glance, and contact or act on an employee. It works well when users may search by name, filter across several employee at'
||'tributes, and sort results by a useful field.</p>',
'',
'<h3>About this pattern page</h3>',
'<p>The search field and Job filter help narrow employees by name or role. Checkbox facets for Business Unit, Status, and Work Mode support multiple selections, and the counts beside options show how many matching employees they include. The list pres'
||unistr('ents each employee\2019s status, work mode, name, business unit, location, hire date, and level. Order By sorts the results, currently by hire date descending. Use Email or the row\2019s more-actions menu to act on an employee; Reset clears the filters, and ')
||'Employee starts adding a new record.</p>'))
,p_page_comment=>'Content Row adds explicit ordering to the baseline faceted-search and content-row pattern so users can change result priority without changing the active filters.'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29398438401681948671)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(4402049144733325348)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8792905637705077735)
,p_plug_name=>'Button Bar'
,p_static_id=>'button-bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>2129856781885180476
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<div id="active_facets"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8792903063490077704)
,p_plug_name=>'Filter employees'
,p_static_id=>'search'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(8792902995571077704)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'current_facets_selector', '#active_facets',
  'show_charts', 'Y',
  'show_current_facets', 'E',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7772387960375189173)
,p_name=>'P4_BUSINESS_UNIT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(8792903063490077704)
,p_prompt=>'Business Unit'
,p_source=>'BUSINESS_UNIT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4442386362748719460)
,p_name=>'P4_CAREER_LEVEL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(8792903063490077704)
,p_prompt=>'Level'
,p_source=>'CAREER_LEVEL'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8792910545075077801)
,p_name=>'P4_JOB'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8792903063490077704)
,p_prompt=>'Job'
,p_source=>'JOB_TITLE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8792910104020077800)
,p_name=>'P4_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8792903063490077704)
,p_prompt=>'Search'
,p_source=>'NAME,EMAIL,JOB_TITLE,BUSINESS_UNIT,WORK_ARRANGEMENT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7772388064948189174)
,p_name=>'P4_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(8792903063490077704)
,p_prompt=>'Status'
,p_source=>'EMPLOYMENT_STATUS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>10
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7772388221371189175)
,p_name=>'P4_WORK_MODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(8792903063490077704)
,p_prompt=>'Work Mode'
,p_source=>'WORK_ARRANGEMENT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>10
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8792902995571077704)
,p_plug_name=>'Employees'
,p_static_id=>'search-results'
,p_region_name=>'search-results'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:t-ContentBlock--lightBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select fe.first_name||'' ''||fe.last_name as name',
'      ,fe.job_title',
'      ,fcc.business_unit',
'      ,fe.email',
'      ,fe.phone_country_code||'' ''||fe.phone_number phone_number',
'      ,fe.tags',
'      ,initcap(fe.work_arrangement) work_arrangement',
'      ,TO_CHAR(fe.hire_date, ''DD Mon YYYY'') AS HIRE_DATE_DISPLAY',
'      ,fe.hire_date AS HIRE_DATE',
'      ,initcap(fe.employment_status) employment_status',
'      ,fe.country',
'      ,fe.career_level',
'      ,case fe.employment_status when ''ACTIVE'' then ''success'' ',
'            when ''INACTIVE'' then ''danger''',
'            when ''LEAVE'' then ''warning''',
'       end badge_state',
'      ,case fe.employment_status when ''ACTIVE'' then ''fa-check-circle-o'' ',
'            when ''INACTIVE'' then ''fa-times-circle-o''',
'            when ''LEAVE'' then ''fa-minus-circle-o''',
'       end badge_icon',
'     , avatar',
'     ,fe.employee_id',
'from fsp_employees fe',
'join fsp_cost_centers fcc',
'on fe.cost_center_id = fcc.cost_center_id'))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{"orderBys":[{"key":"REPORTS1","expr":"HIRE_DATE DESC"},{"key":"REPORTS2","expr":"HIRE_DATE ASC"},{"key":"JOB","expr":"JOB_TITLE ASC"},{"key":"ENAME","expr":"NAME ASC"}],"itemName":"P4_ORDER_BY"}'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_IMAGE', '{"source":"URL","url":"#APEX_FILES#sample_data&AVATAR."}',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_TYPE', 'image',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--lg',
  'BADGE_ICON', '&BADGE_ICON.',
  'BADGE_LABEL', 'Status',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_SHAPE', 't-Badge--circle',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'EMPLOYMENT_STATUS',
  'DESCRIPTION', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<div class="u-display-flex u-flex-wrap u-align-items-center u-gap-3 u-text-muted u-text-sm">',
    '  {if BUSINESS_UNIT/}<span class="u-display-flex u-align-items-center u-gap-2"><span class="fa fa-building-o" aria-hidden="true"></span>&BUSINESS_UNIT.</span>{endif/}',
    '  {if COUNTRY/}<span class="u-display-flex u-align-items-center u-gap-2"><span class="fa fa-map-marker-o" aria-hidden="true"></span>&COUNTRY.</span>{endif/}',
    '  {if HIRE_DATE/}<span class="u-display-flex u-align-items-center u-gap-2"><span class="fa fa-calendar" aria-hidden="true"></span>&HIRE_DATE_DISPLAY.</span>{endif/}',
    '  {if CAREER_LEVEL/}<span class="u-display-flex u-align-items-center u-gap-2"><span class="fa fa-signal" aria-hidden="true"></span> &CAREER_LEVEL.</span>{endif/}',
    '</div>')),
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'OVERLINE', '&WORK_ARRANGEMENT.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&NAME.')).to_clob
,p_plug_comment=>'Uses the title-link and compact row-menu pattern from ux-pattern-catalog page 220. Each employee row includes an image avatar, a department badge, and profile and email actions. Order By varies the presentation order.'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(4442386689099719463)
,p_name=>'AVATAR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AVATAR'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>250
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(4442386823454719464)
,p_name=>'BADGE_ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>260
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(4442386613960719462)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>240
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(4442385485890719451)
,p_name=>'BUSINESS_UNIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BUSINESS_UNIT'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>160
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(4442386168559719458)
,p_name=>'CAREER_LEVEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CAREER_LEVEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>230
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(4442386091129719457)
,p_name=>'COUNTRY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COUNTRY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>220
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7772383050671189118)
,p_name=>'EMAIL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMAIL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5341145867650262644)
,p_name=>'EMPLOYEE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMPLOYEE_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>270
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(4442385944583719456)
,p_name=>'EMPLOYMENT_STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMPLOYMENT_STATUS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>210
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(4442385852193719455)
,p_name=>'HIRE_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HIRE_DATE'
,p_data_type=>'DATE'
,p_display_sequence=>200
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7479028581408505)
,p_name=>'HIRE_DATE_DISPLAY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HIRE_DATE_DISPLAY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>280
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(4442385343943719450)
,p_name=>'JOB_TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'JOB_TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>150
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7772174793188318080)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(4442385592065719452)
,p_name=>'PHONE_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PHONE_NUMBER'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>170
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(4442385664339719453)
,p_name=>'TAGS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TAGS'
,p_data_type=>'CLOB'
,p_display_sequence=>180
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(4442385801167719454)
,p_name=>'WORK_ARRANGEMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'WORK_ARRANGEMENT'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>190
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(4442386925788719465)
,p_region_id=>wwv_flow_imp.id(8792902995571077704)
,p_position_id=>352150619613880487
,p_display_sequence=>40
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15:P15_EMPLOYEE_ID,P15_RETURN_PAGE:&EMPLOYEE_ID.,4'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(33792958874235701636)
,p_region_id=>wwv_flow_imp.id(8792902995571077704)
,p_position_id=>365743646611256091
,p_display_sequence=>20
,p_template_id=>365744248288287220
,p_label=>'Email'
,p_static_id=>'email'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'mailto:&EMAIL.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-envelope-o'
,p_action_css_classes=>'t-Button--simple'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(7772663310874988776)
,p_region_id=>wwv_flow_imp.id(8792902995571077704)
,p_position_id=>365743646611256091
,p_display_sequence=>30
,p_template_id=>365745507808291368
,p_label=>'Employee actions'
,p_static_id=>'employee-actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_action_css_classes=>'t-Button--noUI u-color-1'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7772663470377988776)
,p_component_action_id=>wwv_flow_imp.id(7772663310874988776)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Email employee'
,p_static_id=>'email-employee'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'mailto:&EMAIL.'
,p_icon_css_classes=>'fa-envelope-o'
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'EMAIL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7772663375792988776)
,p_component_action_id=>wwv_flow_imp.id(7772663310874988776)
,p_menu_entry_type=>'ENTRY'
,p_label=>'View profile'
,p_static_id=>'view-profile'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15:P15_EMPLOYEE_ID,P15_RETURN_PAGE:&EMPLOYEE_ID.,4'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4441837672455608627)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(29398438401681948671)
,p_button_name=>'Employee'
,p_static_id=>'employee'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--primary:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Employee'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15::'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4402349551065078647)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(29398438401681948671)
,p_button_name=>'RESET'
,p_static_id=>'reset'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:4,RR'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7772396362424250784)
,p_name=>'P4_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8792905637705077735)
,p_item_display_point=>'NEXT'
,p_item_default=>'REPORTS1'
,p_prompt=>'Order By'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Hire Date descending;REPORTS1,Hire Date ascending;REPORTS2,Job;JOB,Employee Name;ENAME'
,p_cHeight=>1
,p_tag_css_classes=>'no-item-ui'
,p_field_template=>2044213549383960320
,p_item_icon_css_classes=>'fa-sort'
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>'Choose the order used to present the currently filtered employee matches.'
);
wwv_flow_imp.component_end;
end;
/
