prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Faceted Search Patterns'
,p_alias=>'FACETED-SEARCH-PATTERNS'
,p_step_title=>'Faceted Search Patterns'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><strong>Purpose:</strong> Faceted Search Patterns is a reference catalog for developers and designers choosing how users find, filter, review, and compare records in Oracle APEX. Each example combines Faceted Search with a result component or supp'
||'orting interaction.</p>',
'<h3>When to use this catalog</h3>',
'<p>Use the catalog to choose a search experience for a new page, compare result layouts, or understand how filtering works with lists, cards, reports, maps, calendars, timelines, summaries, and selection.</p>',
'<h3>Components used on the home page</h3>',
'<ul>',
'<li><strong>Cards region:</strong> Displays each available pattern with its name, description, category badge, and Open example action.</li>',
'<li><strong>Navigation Menu:</strong> Provides direct links to the individual pattern pages.</li>',
'<li><strong>Shared Page Help dialog:</strong> Explains the selected page''s pattern combination, components, interaction, and usage.</li>',
'</ul>',
'<h3>How to explore the app</h3>',
'<ol>',
'<li><strong>Browse and search:</strong> Start with FS-01 - Content Row, FS-02 - Cards, and FS-03 - Search Only Classic Report to compare compact rows, visual cards, and tabular results.</li>',
'<li><strong>Location and time:</strong> Explore FS-04 - Map, FS-05 - Calendar, and FS-06 - Timeline when records are best understood by location, scheduled date, or chronology.</li>',
'<li><strong>Analysis and comparison:</strong> Explore FS-07 - Search Dashboard and FS-08 - Grouped Results for summaries and grouped lists.</li>',
'<li>Open an example and change its search criteria. Observe how the result component responds, then open Help to understand the components used and how they work together.</li>',
'<li>Choose a combination that suits your user''s task and adapt its filtering, result presentation, and actions to your application data.</li>',
'</ol>',
'<h3>Understanding the examples</h3>',
'<p>Employee and task examples use APEX sample data. Map and Calendar use generated demonstration records. The data illustrates each interaction; the reusable part is the component combination and page behavior.</p>',
'<p>Most examples combine a native Faceted Search region with a native result component. Search Dashboard adds synchronized summaries. Each page''s help identifies these supporting components.</p>'))
,p_page_comment=>'Landing page for the faceted-search examples. Use the native cards to compare the same employee dataset across focused APEX result components.'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7766652817904054623)
,p_plug_name=>'Available Patterns'
,p_static_id=>'pattern-index'
,p_region_template_options=>'u-colors:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2076152157930740558
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 as pattern_id,',
'       ''FS-01 - Content Row'' as pattern_title,',
'       ''Core'' as pattern_badge,',
'       ''Filter and sort'' as pattern_subtitle,',
'       ''Scan employee rows, narrow the matches with filters, and open a profile or email action.'' as pattern_description,',
'       ''fa fa-sort-amount-desc'' as pattern_icon,',
'       4 as target_page',
'  from dual',
'union all',
'select 2,',
'       ''FS-02 - Cards'',',
'       ''Core'',',
'       ''Filter and arrange'',',
'       ''Browse employee avatars and summaries, filter and sort the cards, and open a profile.'',',
'       ''fa fa-layout-header-nav-left-cards'',',
'       5',
'  from dual',
'union all',
'select 3,',
'       ''FS-03 - Search Only Classic Report'',',
'       ''Core'',',
'       ''Search only'',',
'       ''Search employee name, job, or salary with one search facet and compare the matching table rows.'',',
'       ''fa fa-table-search'',',
'       7',
'  from dual',
'union all',
'select 4,',
'       ''FS-04 - Map'',',
'       ''Extension'',',
'       ''Filter by location'',',
'       ''Faceted employee search paired with a location-aware map overview.'',',
'       ''fa fa-map-marker'',',
'       9',
'  from dual',
'union all',
'select 5,',
'       ''FS-05 - Calendar'',',
'       ''Extension'',',
'       ''Filter by date'',',
'       ''Faceted search with date filtering beside a calendar result view.'',',
'       ''fa fa-calendar'',',
'       10',
'  from dual',
'union all',
'select 6,',
'       ''FS-06 - Timeline'',',
'       ''Extension'',',
'       ''Review tasks by month'',',
'       ''Filter tasks by start month, assignee, and status, then open a task for more detail.'',',
'       ''fa fa-clock-o'',',
'       12',
'  from dual',
'union all',
'select 9, ''FS-07 - Search Dashboard'', ''Extension'', ''Explore matching employee metrics'', ''See employee counts, job-role and cost-center metrics, plus cost-center and work-arrangement charts update with your filters.'', ''fa fa-dashboard'', 17',
'  from dual',
'union all',
'select 10, ''FS-08 - Grouped Results'', ''Extension'', ''Browse employees by department'', ''Filter employees and scan content rows grouped under department headings.'', ''fa fa-list-alt'', 20',
'  from dual',
'order by pattern_id'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(4402233932998046308)
,p_region_id=>wwv_flow_imp.id(7766652817904054623)
,p_layout_type=>'GRID'
,p_grid_column_count=>4
,p_title_adv_formatting=>false
,p_title_column_name=>'PATTERN_TITLE'
,p_title_css_classes=>'u-color-44-text'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'PATTERN_SUBTITLE'
,p_body_adv_formatting=>false
,p_body_column_name=>'PATTERN_DESCRIPTION'
,p_body_css_classes=>'u-text-muted-color'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'PATTERN_ICON'
,p_icon_position=>'START'
,p_badge_column_name=>'PATTERN_BADGE'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'PATTERN_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4402234357894046311)
,p_card_id=>wwv_flow_imp.id(4402233932998046308)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>10
,p_label=>'Open example'
,p_static_id=>'open'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'f?p=&APP_ID.:&TARGET_PAGE.:&SESSION.::&DEBUG.:::'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-external-link'
,p_action_css_classes=>'t-Button--primary t-Button--simple'
,p_is_hot=>false
);
wwv_flow_imp.component_end;
end;
/
