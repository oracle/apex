prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'FS-05 - Calendar'
,p_alias=>'FS-05-CALENDAR'
,p_step_title=>'FS-05 - Calendar'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2530071015796209513
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>When to use</h3>',
'<p>Use this pattern to filter scheduled activities and explore matching results over time. It suits use cases such as finding appointments, training sessions, meetings, or maintenance activities by category, status, delivery mode, and duration.</p>',
'',
'<h3>About this pattern page</h3>',
'<p>Event Type and Geographic Region support multiple selections; Event Status and Delivery Mode support one selection. Event Scope, Cost Center, and Start Month use select lists to focus the schedule. Duration Hours uses a numeric range to filter act'
||'ivities by length.</p>'))
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33796976527276161320)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(4402049144733325348)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11193748167221155413)
,p_plug_name=>'Workforce Events Calendar'
,p_static_id=>'fs_05_calendar'
,p_region_name=>'fs_05_calendar'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT event_id,',
'       event_title,',
'       event_display,',
'       event_start,',
'       start_month,',
'       event_end,',
'       event_type,',
'       event_status,',
'       event_scope,',
'       delivery_mode,',
'       duration_hours,',
'       event_summary,',
'       description,',
'       employee_name,',
'       geographic_region,',
'       cost_center,',
'       CASE event_type ',
'       WHEN ''PERFORMANCE_REVIEW'' THEN ''u-color-20-bg u-color-35-text u-color-20-border'' ',
'       WHEN ''TRAINING'' THEN ''u-color-24-bg u-color-39-text u-color-24-border'' ',
'       WHEN ''CERTIFICATION'' THEN ''u-color-23-bg u-color-38-text u-color-23-border'' ',
'       ELSE ''u-color-18-bg u-color-33-text u-color-18-border'' ',
'       END AS event_class',
'  FROM fsp_employee_events_v',
' ORDER BY event_start, event_id',
' ;'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_plug_read_only_when_type=>'ALWAYS'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (pOptions) {   ',
'    pOptions.contentHeight = "auto";',
'    return pOptions;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'calendar_export', 'ICAL',
  'calendar_views_and_navigation', 'month:navigation',
  'css_class', 'EVENT_CLASS',
  'display_column', 'EVENT_DISPLAY',
  'drag_and_drop', 'N',
  'end_date_column', 'EVENT_END',
  'event_sorting', 'AUTOMATIC',
  'first_hour', '9',
  'maximum_events_day', '3',
  'multiple_line_event', 'Y',
  'primary_key_column', 'EVENT_ID',
  'responsive_list_view', 'Y',
  'show_time', 'Y',
  'show_tooltip', 'N',
  'show_weekend', 'Y',
  'start_date_column', 'EVENT_START',
  'time_format', '00',
  'view_edit_link', 'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::P11_EVENT_ID:&EVENT_ID.')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11193748021566155413)
,p_plug_name=>'Filter Workforce Events'
,p_static_id=>'fs_05_filters'
,p_icon_css_classes=>'fa-filter'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(11193748167221155413)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'show_charts', 'Y',
  'show_current_facets', 'Y',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11194500320755271274)
,p_name=>'P10_F_COST_CENTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(11193748021566155413)
,p_prompt=>'Cost Center'
,p_source=>'COST_CENTER'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
,p_item_comment=>'Selects one cost center for a focused planning view.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11194526752740803589)
,p_name=>'P10_F_DELIVERY_MODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(11193748021566155413)
,p_prompt=>'Delivery Mode'
,p_source=>'DELIVERY_MODE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov_sort_direction=>'ASC'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'hide_radio_buttons', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>true
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
,p_item_comment=>'A real-world workforce scheduling attribute: In Person, Hybrid, or Virtual.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11194500276707271274)
,p_name=>'P10_F_REGION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(11193748021566155413)
,p_prompt=>'Geographic Region'
,p_source=>'GEOGRAPHIC_REGION'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>10
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>true
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
,p_item_comment=>'Refines events using the employee geographic region.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11194500012204271274)
,p_name=>'P10_F_SCOPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(11193748021566155413)
,p_prompt=>'Event Scope'
,p_source=>'EVENT_SCOPE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
,p_item_comment=>'Selects one operational scope for a focused schedule view.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11194499768726271274)
,p_name=>'P10_F_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11193748021566155413)
,p_prompt=>'Search Workforce Events'
,p_source=>'EVENT_TITLE,EMPLOYEE_NAME,DESCRIPTION'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_item_comment=>'Searches event title, employee, and description.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11194499924558271274)
,p_name=>'P10_F_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(11193748021566155413)
,p_prompt=>'Event Status'
,p_source=>'EVENT_STATUS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov_sort_direction=>'ASC'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'hide_radio_buttons', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>true
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
,p_item_comment=>'A single lifecycle state is appropriate, so this uses a radio group.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11194499834191271274)
,p_name=>'P10_F_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(11193748021566155413)
,p_prompt=>'Event Type'
,p_source=>'EVENT_TYPE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>true
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
,p_item_comment=>'Refines events by event type.'
);
wwv_flow_imp.component_end;
end;
/
