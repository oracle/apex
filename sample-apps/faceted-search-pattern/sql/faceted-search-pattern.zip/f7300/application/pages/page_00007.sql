prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'FS-03 - Search Only Classic Report'
,p_alias=>'FS-03-SEARCH-ONLY-CLASSIC-REPORT'
,p_step_title=>'FS-03 - Search Only Classic Report'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>When to use</h3>',
'<p>',
'  Use this pattern when a single search term is enough to find records',
'  and a table helps users compare values. It suits employee directories',
'  and similar searches without separate category or range filters.',
'</p>',
'',
'<h3>About this pattern page</h3>',
'<p>',
'  One Search facet filters employee records; no category or range facets',
'  are included. The Classic Report shows employee names with initials',
'  avatars, email addresses, and career levels, alongside country,',
'  job title, employment type, and work arrangement. Badges highlight',
'  employment type and work arrangement. Search updates the results',
'  without a full page submission. Clearing Search or selecting Reset',
'  restores all rows.',
'</p>'))
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4406746013802276582)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(4402049144733325348)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29398438534949948672)
,p_plug_name=>'Faceted Search'
,p_static_id=>'faceted-search'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(4406748960584276910)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29398438552133948673)
,p_name=>'P7_SEARCH_FS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(29398438534949948672)
,p_prompt=>'Search Fs'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'external_page_item', 'P7_SEARCH',
  'input_field', 'PAGE_ITEM',
  'search_type', 'ROW')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4406748960584276910)
,p_name=>'FS-03 - Search Only Classic Report'
,p_static_id=>'fs-03-search-only-classic-report'
,p_template=>4504868307683981366
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--horizontalBorders:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT employee_id,',
'       first_name,',
'       last_name,',
'       first_name || '' '' || last_name AS employee_name,',
'       upper(substr(first_name, 1, 1) || substr(last_name, 1, 1)) AS initials,',
'       email,',
'       country,',
'       career_level,',
'       job_title,',
'       employment_status,',
'       INITCAP(REPLACE(employment_type, ''_'', '' '')) AS employment_type,',
'       INITCAP(work_arrangement) AS work_arrangement',
'  FROM fsp_employees',
' ORDER BY last_name, first_name;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2542081983073888486
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'Y'
,p_prn_format=>'PDF'
,p_prn_output_link_text=>'Download'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width_units=>'PERCENTAGE'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(25358151208534436358)
,p_query_column_id=>8
,p_column_alias=>'CAREER_LEVEL'
,p_column_display_sequence=>120
,p_column_heading=>'Career Level'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(25358150887743436355)
,p_query_column_id=>7
,p_column_alias=>'COUNTRY'
,p_column_display_sequence=>150
,p_column_heading=>'Country'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4406750766658276935)
,p_query_column_id=>6
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(25358150389651436350)
,p_query_column_id=>1
,p_column_alias=>'EMPLOYEE_ID'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(25358150657858436353)
,p_query_column_id=>4
,p_column_alias=>'EMPLOYEE_NAME'
,p_column_display_sequence=>70
,p_column_heading=>'Name'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{with/}',
'  TITLE:=#EMPLOYEE_NAME#',
'  DESCRIPTION:=#EMAIL# ',
'  ITEM_CSS_CLASSES:=u-padding-xs',
'  DISPLAY_AVATAR:=Y',
'  AVATAR_TYPE:=initials',
'  AVATAR_INITIALS:=#INITIALS#',
'  AVATAR_SIZE:=t-Avatar--xs',
'  AVATAR_SHAPE:=t-Avatar--circle',
'  AVATAR_CSS_CLASSES:=u-color-subtle u-text-secondary',
'{apply THEME$CONTENT_ROW/}'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(25358152758830436374)
,p_query_column_id=>10
,p_column_alias=>'EMPLOYMENT_STATUS'
,p_column_display_sequence=>160
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(25358152876692436375)
,p_query_column_id=>11
,p_column_alias=>'EMPLOYMENT_TYPE'
,p_column_display_sequence=>130
,p_column_heading=>'Employment Type'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{with/}',
'  LABEL:=Employment Type',
'  VALUE:=#EMPLOYMENT_TYPE#',
'  STATE:={case EMPLOYMENT_TYPE/}{when Full Time/}success{when Part Time/}info{when Contractor/}warning{otherwise/}neutral{endcase/}',
'  LABEL_DISPLAY:=N',
'  STYLE:=t-Badge--subtle',
'  SHAPE:=t-Badge--circle',
'{apply THEME$BADGE/}'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(25358150446689436351)
,p_query_column_id=>2
,p_column_alias=>'FIRST_NAME'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5305140114201309729)
,p_query_column_id=>5
,p_column_alias=>'INITIALS'
,p_column_display_sequence=>170
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(25358151279506436359)
,p_query_column_id=>9
,p_column_alias=>'JOB_TITLE'
,p_column_display_sequence=>140
,p_column_heading=>'Job Title'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(25358150546895436352)
,p_query_column_id=>3
,p_column_alias=>'LAST_NAME'
,p_column_display_sequence=>60
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5305140289756309731)
,p_query_column_id=>12
,p_column_alias=>'WORK_ARRANGEMENT'
,p_column_display_sequence=>180
,p_column_heading=>'Work Arrangement'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{with/}',
'  LABEL:=Work Arrangement',
'  VALUE:=#WORK_ARRANGEMENT#',
'  STATE:={case WORK_ARRANGEMENT/}{when Remote/}info{when Hybrid/}warning{when Onsite/}success{otherwise/}info{endcase/}',
'  LABEL_DISPLAY:=N',
'  STYLE:=t-Badge--subtle',
'  SHAPE:=t-Badge--circle',
'  SIZE:=t-Badge--md',
'{apply THEME$BADGE/}'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4437655744292330601)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(4406746013802276582)
,p_button_name=>'Employee'
,p_static_id=>'employee'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--primary:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Employee'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15::'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4409625333094544210)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4406746013802276582)
,p_button_name=>'RESET'
,p_static_id=>'reset'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:4,RR'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29398438647767948674)
,p_name=>'P7_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4406746013802276582)
,p_item_display_point=>'SMART_FILTERS'
,p_placeholder=>'Search...'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>75
,p_field_template=>2044213549383960320
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'SEARCH',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp.component_end;
end;
/
