prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Event Invitation'
,p_alias=>'EVENT-INVITATION'
,p_page_mode=>'MODAL'
,p_step_title=>'Event Invitation'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1664614232864994871
,p_page_template_options=>'#DEFAULT#:t-Dialog--noPadding:js-dialog-class-t-Drawer--pullOutEnd:t-PageBody--noContentPadding'
,p_dialog_height=>'auto'
,p_dialog_width=>'560'
,p_dialog_max_width=>'640'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(11198729121712989223)
,p_name=>'Invite Details'
,p_static_id=>'invite_details'
,p_template=>4075786578761660127
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--horizontalBorders'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with invitation as (',
'    select ev.event_title,',
'           initcap(replace(ev.event_type, ''_'', '' '')) as event_type_label,',
'           e.first_name || '' '' || e.last_name as attendee_name,',
'           e.job_title,',
'           e.email,',
'           ev.event_start,',
'           ev.event_end,',
'           ev.event_status,',
'           ev.event_scope,',
'           initcap(replace(ev.delivery_mode, ''_'', '' '')) as delivery_mode_label,',
'           l.location_name,',
'           c.country_name,',
'           cc.cost_center_description as cost_center,',
'           ev.description',
'      from fsp_employee_events_v ev',
'      join fsp_employees e on e.employee_id = ev.employee_id',
'      left join fsp_cost_centers cc on cc.cost_center_id = e.cost_center_id',
'      left join fsp_locations l on l.location_id = ev.location_id',
'      left join fsp_countries c on c.country_code_alpha2 = l.country_code_alpha2',
'     where ev.event_id = :P11_EVENT_ID',
')',
'select detail_label, detail_value, display_sequence',
'  from (',
'    select ''Invitation'' as detail_label,',
'           event_title as detail_value,',
'           10 as display_sequence',
'      from invitation',
'    union all',
'    select ''Activity Type'', event_type_label, 20 from invitation',
'    union all',
unistr('    select ''Attendee'', attendee_name || '' \00B7 '' || job_title, 30 from invitation'),
'    union all',
'    select ''Email'', email, 40 from invitation',
'    union all',
'    select ''When'',',
'           to_char(event_start, ''FMDay, FMDD Mon YYYY, HH:MI AM'') ||',
unistr('           '' \2013 '' || to_char(event_end, ''HH:MI AM''),'),
'           50',
'      from invitation',
'    union all',
'    select ''Duration'',',
'           to_char(round((cast(event_end as date) - cast(event_start as date)) * 24, 2), ''FM990D0'') || '' hours'',',
'           60',
'      from invitation',
'    union all',
'    select ''Delivery Mode'', delivery_mode_label, 70 from invitation',
'    union all',
'    select ''Status'', initcap(lower(event_status)), 80 from invitation',
'    union all',
'    select ''Scope'', initcap(lower(event_scope)), 90 from invitation',
'    union all',
unistr('    select ''Location'', location_name || '' \00B7 '' || country_name, 100 from invitation'),
'    union all',
'    select ''Cost Center'', cost_center, 110 from invitation',
'    union all',
'    select ''Invitation Notes'', description, 120 from invitation',
'  )',
' order by display_sequence'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2542081983073888486
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'The selected calendar invitation is not available.'
,p_query_num_rows_type=>'ROWS_X_TO_Y'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4406818863710553653)
,p_query_column_id=>1
,p_column_alias=>'DETAIL_LABEL'
,p_column_display_sequence=>10
,p_column_heading=>'Detail'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4406819252851553654)
,p_query_column_id=>2
,p_column_alias=>'DETAIL_VALUE'
,p_column_display_sequence=>20
,p_column_heading=>'Invitation Information'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4406819730619553655)
,p_query_column_id=>3
,p_column_alias=>'DISPLAY_SEQUENCE'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11198733609466989306)
,p_name=>'P11_EVENT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11198729121712989223)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11197698186719559968)
,p_name=>'P11_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(11198729121712989223)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
