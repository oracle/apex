prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'FS-02 - Cards'
,p_alias=>'FS-02-CARDS'
,p_step_title=>'FS-02 - Cards'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2530071015796209513
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>When to use</h3>',
'<p>Use this pattern to browse and manage employee records when visual identification and quick access to profiles or email are useful. Search and filters help users narrow a larger employee list to relevant results.</p>',
'',
'<h3>About this pattern page</h3>',
unistr('<p>Search for employees, then narrow results by Job, Business Unit, or Status. Sort the cards by First Name. Each card shows an employee\2019s avatar, name and job title, email, and status, with actions to view the profile or email the employee. Use Rese')
||'t to clear the current filters.</p>'))
,p_page_comment=>'Uses the clickable-title and primary/secondary card-action pattern from ux-pattern-catalog page 210. Actions open the selected employee profile or compose an email; the Order By item controls the cards source ordering.'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33795311995286756692)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(4402049144733325348)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8795981371271369818)
,p_plug_name=>'Button Bar'
,p_static_id=>'button-bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>2129856781885180476
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<div id="active_facets"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7765783144482941892)
,p_plug_name=>'Employees'
,p_static_id=>'employees_1'
,p_region_name=>'employees_1'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc:t-CardsRegion--styleC:t-Form--large'
,p_plug_template=>2076152157930740558
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select EMPLOYEE_ID,',
'       FIRST_NAME,',
'       LAST_NAME,',
'       EMAIL,',
'       JOB_TITLE,',
'       initcap(EMPLOYMENT_STATUS) as EMPLOYMENT_STATUS,',
'       case EMPLOYMENT_STATUS when ''ACTIVE'' then ''u-success'' ',
'            when ''INACTIVE'' then ''u-danger''',
'            when ''LEAVE'' then ''u-warning''',
'       end BADGE_STATE,',
'      case EMPLOYMENT_STATUS when ''ACTIVE'' then ''fa-check-circle-o'' ',
'            when ''INACTIVE'' then ''fa-times-circle-o''',
'            when ''LEAVE'' then ''fa-minus-circle-o''',
'       end BADGE_ICON,',
'       CAREER_LEVEL,',
'       COST_CENTER_DESCRIPTION,',
'       BUSINESS_UNIT,',
'       TIMEZONE,',
'       WORK_ARRANGEMENT,',
'       AVATAR',
'  from FSP_EMPLOYEES E, FSP_COST_CENTERS CC',
'  where E.COST_CENTER_ID = CC.COST_CENTER_ID'))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{"orderBys":[{"key":"REPORTS1","expr":"FIRST_NAME DESC"},{"key":"REPORTS2","expr":"LAST_NAME ASC"},{"key":"DEPTNO","expr":"JOB_TITLE ASC"}],"itemName":"P5_ORDER_BY"}'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(4402558773244395209)
,p_region_id=>wwv_flow_imp.id(7765783144482941892)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>true
,p_title_html_expr=>'&FIRST_NAME. &LAST_NAME. - &JOB_TITLE.'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'EMAIL'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'EMPLOYMENT_STATUS'
,p_badge_css_classes=>'&BADGE_STATE.'
,p_media_adv_formatting=>false
,p_media_source_type=>'STATIC_URL'
,p_media_url=>'#APEX_FILES#sample_data&AVATAR.'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'EMPLOYEE_ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4402559333557395215)
,p_card_id=>wwv_flow_imp.id(4402558773244395209)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>30
,p_label=>'Email employee'
,p_static_id=>'email-employee'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'mailto:&EMAIL.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-envelope-o'
,p_action_css_classes=>'t-Button--noUI  u-color-1'
,p_is_hot=>false
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'EMAIL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4402559937458395218)
,p_card_id=>wwv_flow_imp.id(4402558773244395209)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>20
,p_label=>'View profile'
,p_static_id=>'view-profile'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15:P15_EMPLOYEE_ID,P15_RETURN_PAGE:&EMPLOYEE_ID.,5'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-user'
,p_action_css_classes=>'t-Button--primary'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14084078923790810611)
,p_plug_name=>'Filter employees'
,p_static_id=>'filter-employees'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(7765783144482941892)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'current_facets_selector', '#active_facets',
  'show_charts', 'Y',
  'show_current_facets', 'E',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13063572216729922113)
,p_name=>'P5_BUSINESS_UNIT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(14084078923790810611)
,p_prompt=>'Business Unit'
,p_source=>'BUSINESS_UNIT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9733570619103452400)
,p_name=>'P5_CAREER_LEVEL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(14084078923790810611)
,p_prompt=>'Level'
,p_source=>'CAREER_LEVEL'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14084094801429810741)
,p_name=>'P5_JOB'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(14084078923790810611)
,p_prompt=>'Job'
,p_source=>'JOB_TITLE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14084094360374810740)
,p_name=>'P5_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(14084078923790810611)
,p_prompt=>'Search'
,p_source=>'FIRST_NAME,LAST_NAME,EMAIL,JOB_TITLE,BUSINESS_UNIT,WORK_ARRANGEMENT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13063572321302922114)
,p_name=>'P5_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(14084078923790810611)
,p_prompt=>'Status'
,p_source=>'EMPLOYMENT_STATUS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>10
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13063572477725922115)
,p_name=>'P5_WORK_MODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(14084078923790810611)
,p_prompt=>'Work Mode'
,p_source=>'WORK_ARRANGEMENT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>10
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29398439010119948677)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(33795311995286756692)
,p_button_name=>'Employee'
,p_static_id=>'employee'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--primary:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Employee'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15::'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4402556696952395199)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(33795311995286756692)
,p_button_name=>'RESET'
,p_static_id=>'reset'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5,RR'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7816001360780264911)
,p_name=>'P5_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8795981371271369818)
,p_item_display_point=>'NEXT'
,p_item_default=>'REPORTS1'
,p_prompt=>'Order By'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:First Name;REPORTS1,Last Name;REPORTS2,Job Title;DEPTNO'
,p_cHeight=>1
,p_tag_css_classes=>'no-item-ui'
,p_field_template=>2044213549383960320
,p_item_icon_css_classes=>'fa-sort'
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp.component_end;
end;
/
