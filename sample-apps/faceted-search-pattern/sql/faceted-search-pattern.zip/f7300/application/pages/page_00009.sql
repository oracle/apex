prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'FS-04 - Map'
,p_alias=>'FS-04-MAP'
,p_step_title=>'FS-04 - Map'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2530071015796209513
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>When to use</h3>',
'<p>Use this pattern to filter geographically distributed data and explore matching results on a map. It suits use cases such as finding offices, stores, service centers, or facilities by location, category, status, and capacity.</p>',
'',
'<h3>About this pattern page</h3>',
'<p>Geographic Region and Office Type support multiple selections; Location Status supports one selection. Country and Opened Month use select lists, with months ordered newest first. Capacity and Employee Count use numeric ranges to narrow results by'
||' size. Search finds locations by name, city, or country.</p>'))
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38194068720882665253)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(4402049144733325348)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11191910623990854457)
,p_plug_name=>'Filter Locations'
,p_static_id=>'fs_04_filters'
,p_icon_css_classes=>'fa-filter'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(11191910747021854457)
,p_landmark_label=>'Location filters'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'show_charts', 'Y',
  'show_current_facets', 'Y',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11192662903976970303)
,p_name=>'P9_F_CAPACITY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(11191910623990854457)
,p_prompt=>'Capacity'
,p_source=>'CAPACITY'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC2:<=100;|100,100-500;100|500,500-1#G#000;500|1000,1#G#000 - 2#G#000;1000|2000'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'N',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
,p_item_comment=>'Uses a numeric range against location capacity.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11192662490695970303)
,p_name=>'P9_F_COUNTRY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(11191910623990854457)
,p_prompt=>'Country'
,p_source=>'COUNTRY_NAME'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
,p_item_comment=>'Country values depend on the selected geographic region.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11192662517028970303)
,p_name=>'P9_F_OFFICE_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(11191910623990854457)
,p_prompt=>'Office Type'
,p_source=>'OFFICE_TYPE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'D'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>false
,p_fc_show_selected_first=>true
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
,p_item_comment=>'Refines locations by office classification.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11192662385190970303)
,p_name=>'P9_F_REGION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(11191910623990854457)
,p_prompt=>'Geographic Region'
,p_source=>'GEOGRAPHIC_REGION'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>10
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>true
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
,p_item_comment=>'Narrows markers to a geographic region.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11192662218603970303)
,p_name=>'P9_F_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11191910623990854457)
,p_prompt=>'Search Locations'
,p_source=>'LOCATION_NAME,CITY,COUNTRY_NAME'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_item_comment=>'Searches the explicit location name, city, and country allowlist.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11192662643685970303)
,p_name=>'P9_F_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(11191910623990854457)
,p_prompt=>'Location Status'
,p_source=>'LOCATION_STATUS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>true
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
,p_item_comment=>'Selects one lifecycle status, with readable labels and native LOV value icons.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11191910747021854457)
,p_plug_name=>'Workforce Locations'
,p_static_id=>'fs_04_map'
,p_icon_css_classes=>'fa-map-marker'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:js-showMaximizeButton'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.location_id,',
'       l.location_name,',
'       l.office_type,',
'       initcap(replace(l.office_type, ''_'', '' '')) as office_type_label,',
'       l.city,',
'       c.country_name,',
'       c.region as geographic_region,',
'       l.location_status,',
'       initcap(lower(l.location_status)) as location_status_label,',
'       l.opened_date,',
'       to_char(',
'         l.opened_date,',
'         ''FMMonth YYYY'',',
'         ''NLS_DATE_LANGUAGE=English''',
'       ) as opened_month,',
'       to_char(l.opened_date, ''YYYY-MM'') as opened_month_key,',
'       to_char(',
'         l.opened_date,',
'         ''DD Mon YYYY'',',
'         ''NLS_DATE_LANGUAGE=English''',
'       ) as opened_date_display,',
'       l.timezone,',
'       case l.office_type',
'         when ''HEADQUARTERS'' then ''fa-building''',
'         when ''REGIONAL'' then ''fa-building-o''',
'         when ''SATELLITE'' then ''fa-map-marker''',
'         else ''fa-wifi''',
'       end as marker_icon,',
'       case l.office_type',
'         when ''HEADQUARTERS'' then ''#056AC8''',
'         when ''REGIONAL'' then ''#117733''',
'         when ''SATELLITE'' then ''#C66A00''',
'         else ''#6B7280''',
'       end as marker_color,',
'       l.capacity,',
'       l.latitude,',
'       l.longitude,',
'       nvl(ec.employee_count, 0) as employee_count',
'  from fsp_locations l',
'  join fsp_countries c',
'    on c.country_code_alpha2 = l.country_code_alpha2',
'  left join (',
'    select location_id,',
'           count(*) as employee_count',
'      from fsp_employees',
'     group by location_id',
'  ) ec',
'    on ec.location_id = l.location_id',
' order by l.location_name;'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
,p_landmark_label=>'Workforce location map'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(4404575843862098040)
,p_region_id=>wwv_flow_imp.id(11191910747021854457)
,p_height=>800
,p_tilelayer_type=>'CUSTOM'
,p_tilelayer_name_default=>'osm-positron'
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_title=>'Office Types'
,p_legend_position=>'END'
,p_features=>'RECTANGLE_ZOOM:SCALE_BAR:INFINITE_MAP:DISTANCE_TOOL'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(4404576429378098046)
,p_map_region_id=>wwv_flow_imp.id(4404575843862098040)
,p_name=>'Locations'
,p_static_id=>'locations_layer'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_no_data_found_message=>'No locations match the selected filters. Clear a filter to broaden the map.'
,p_no_data_found_icon_classes=>'fa-map-marker'
,p_has_spatial_index=>true
,p_pk_column=>'LOCATION_ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_fill_color=>'&MARKER_COLOR.'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Street View'
,p_point_svg_shape_scale=>'2'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>&LOCATION_NAME!HTML.</strong><br>',
'&CITY!HTML., &COUNTRY_NAME!HTML.<br>',
unistr('&OFFICE_TYPE_LABEL!HTML. \00B7 &LOCATION_STATUS_LABEL!HTML.<br>'),
'Employees: &EMPLOYEE_COUNT!HTML.<br>',
'Capacity: &CAPACITY!HTML.'))
,p_info_window_adv_formatting=>false
,p_legend_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp.component_end;
end;
/
