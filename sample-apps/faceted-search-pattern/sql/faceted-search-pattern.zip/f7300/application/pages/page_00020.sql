prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>20
,p_name=>'FS-08 - Grouped Rows'
,p_alias=>'FS-08-GROUPED-ROWS'
,p_step_title=>'FS-08 - Grouped Rows'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2530071015796209513
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>When to use</h3>',
'<p>Use this pattern to browse employee records and scan key details in a compact list. It suits directories where users need to search, filter by shared attributes, sort, select records, or take actions.</p>',
'',
'<h3>About this pattern page</h3>',
unistr('<p>Search and the Job Title, Business Unit, and Tags List filters narrow the employee list; facet counts show available matches. Each row shows an employee\2019s name, email, tags, and business unit. Use the Job control to sort the list. Select employees')
||unistr(' using the checkboxes or Select All, and use the row\2019s actions menu for available actions.</p>')))
,p_page_comment=>'Content Row adds explicit ordering to the baseline faceted-search and content-row pattern so users can change result priority without changing the active filters.'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12815285425339092703)
,p_plug_name=>'FS-08 - Grouped Results'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(4402049144733325348)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12815289091326092786)
,p_plug_name=>'Button Bar'
,p_static_id=>'button-bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>2129856781885180476
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<div id="active_facets"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12815286517111092755)
,p_plug_name=>'Filter employees'
,p_static_id=>'search'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(12815286449192092755)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'current_facets_selector', '#active_facets',
  'show_charts', 'Y',
  'show_current_facets', 'E',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11794800932779204325)
,p_name=>'P20_BUSINESS_UNIT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(12815286517111092755)
,p_prompt=>'Business Unit'
,p_source=>'BUSINESS_UNIT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12815323517479092953)
,p_name=>'P20_JOB_TITLE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>5
,p_item_plug_id=>wwv_flow_imp.id(12815286517111092755)
,p_prompt=>'Job Title'
,p_source=>'JOB_TITLE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>10
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12815323076424092952)
,p_name=>'P20_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12815286517111092755)
,p_prompt=>'Search'
,p_source=>'NAME,EMAIL,JOB_TITLE,BUSINESS_UNIT,WORK_ARRANGEMENT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11794801193775204327)
,p_name=>'P20_WORK_ARRANGEMENT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(12815286517111092755)
,p_prompt=>'Work Arrangement'
,p_source=>'WORK_ARRANGEMENT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>10
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12815286449192092755)
,p_plug_name=>'Employees'
,p_static_id=>'search-results'
,p_region_name=>'search-results'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:t-ContentBlock--lightBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    fe.employee_id,',
'    fe.first_name || '' '' || fe.last_name as name,',
'    fe.job_title,',
'    fcc.business_unit,',
'    fe.email,',
'    fe.phone_country_code || '' '' || fe.phone_number as phone_number,',
'    fe.tags as tags_json,',
'    (',
'        select listagg(jt.tag_value, '':'')',
'                   within group (order by jt.tag_order)',
'        from json_table(',
'            fe.tags,',
'            ''$[*]'' columns (',
'                tag_order for ordinality,',
'                tag_value varchar2(4000) path ''$''',
'            )',
'        ) jt',
'    ) as tags_list,',
'    initcap(fe.work_arrangement) as work_arrangement,',
'    to_char(fe.hire_date, ''DD Mon YYYY'') as hire_date,',
'    initcap(fe.employment_status) as employment_status,',
'    fe.country,',
'    fe.career_level,',
'    case fe.employment_status',
'        when ''ACTIVE''   then ''success''',
'        when ''INACTIVE'' then ''danger''',
'        when ''LEAVE''    then ''warning''',
'    end as badge_state,',
'    case fe.employment_status',
'        when ''ACTIVE''   then ''fa-check-circle-o''',
'        when ''INACTIVE'' then ''fa-times-circle-o''',
'        when ''LEAVE''    then ''fa-minus-circle-o''',
'    end as badge_icon,',
'    fe.avatar',
'from fsp_employees fe',
'join fsp_cost_centers fcc',
'    on fe.cost_center_id = fcc.cost_center_id'))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{"orderBys":[{"key":"BUSINESS_UNIT","expr":"BUSINESS_UNIT ASC"},{"key":"JOB_TITLE","expr":"JOB_TITLE ASC"},{"key":"ENAME","expr":"NAME ASC"}],"itemName":"P20_ORDER_BY"}'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_row_selection_type=>'MULTIPLE'
,p_select_all_page_item=>'P20_SELECT_ALL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_IMAGE', '{"source":"URL","url":"#APEX_FILES#sample_data&AVATAR."}',
  'AVATAR_SHAPE', 't-Avatar--circle',
  'AVATAR_TYPE', 'image',
  'DESCRIPTION', wwv_flow_string.join(wwv_flow_t_varchar2(
    '&EMAIL.',
    '',
    '{if TAGS_LIST/}<br>{loop ":" TAGS_LIST/}',
    '{with/}',
    '  LABEL:=Tag',
    '  VALUE:=&APEX$ITEM.',
    '  LABEL_DISPLAY:=N',
    '  STYLE:=t-Badge--subtle t-Badge--circle u-text-muted-color',
    '  SIZE:=t-Badge--md',
    '{apply THEME$BADGE/}{endloop/}{endif/}')),
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'GROUP_TITLE', '&BUSINESS_UNIT.',
  'HIDE_BORDERS', 'N',
  'MISC', 'Business Unit: &BUSINESS_UNIT.',
  'OVERLINE', '&WORK_ARRANGEMENT.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&NAME.')).to_clob
,p_plug_comment=>'Uses the title-link and compact row-menu pattern from ux-pattern-catalog page 220. Each employee row includes an image avatar, a department badge, and profile and email actions. Order By varies the presentation order.'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7883361611344376)
,p_name=>'AVATAR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AVATAR'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>180
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7883333271344375)
,p_name=>'BADGE_ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_ICON'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>170
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7883226136344374)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>160
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7882427580344366)
,p_name=>'BUSINESS_UNIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BUSINESS_UNIT'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>true
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7883151599344373)
,p_name=>'CAREER_LEVEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CAREER_LEVEL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>150
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7882977125344372)
,p_name=>'COUNTRY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COUNTRY'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>140
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11794766504292204169)
,p_name=>'EMAIL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMAIL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7883502948344377)
,p_name=>'EMPLOYEE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMPLOYEE_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>190
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7882906082344371)
,p_name=>'EMPLOYMENT_STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMPLOYMENT_STATUS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>130
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7882844368344370)
,p_name=>'HIRE_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HIRE_DATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>120
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7882292112344365)
,p_name=>'JOB_TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'JOB_TITLE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11794558246809333131)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7882452995344367)
,p_name=>'PHONE_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PHONE_NUMBER'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7883823154344380)
,p_name=>'TAGS_JSON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TAGS_JSON'
,p_data_type=>'CLOB'
,p_display_sequence=>200
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7883892951344381)
,p_name=>'TAGS_LIST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TAGS_LIST'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>210
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7882690935344369)
,p_name=>'WORK_ARRANGEMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'WORK_ARRANGEMENT'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>110
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(7883678501344379)
,p_region_id=>wwv_flow_imp.id(12815286449192092755)
,p_position_id=>352150619613880487
,p_display_sequence=>30
,p_static_id=>'action'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15:P15_EMPLOYEE_ID,P15_RETURN_PAGE:&EMPLOYEE_ID.,20'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(11795046764496003827)
,p_region_id=>wwv_flow_imp.id(12815286449192092755)
,p_position_id=>365743646611256091
,p_display_sequence=>20
,p_template_id=>365745507808291368
,p_label=>'Employee actions'
,p_static_id=>'employee-actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(33793476970471040716)
,p_component_action_id=>wwv_flow_imp.id(11795046764496003827)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Delete'
,p_static_id=>'delete'
,p_display_sequence=>40
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_icon_css_classes=>'fa-trash-o'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(11795046923999003827)
,p_component_action_id=>wwv_flow_imp.id(11795046764496003827)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Email employee'
,p_static_id=>'email-employee'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'mailto:&EMAIL.'
,p_icon_css_classes=>'fa-envelope-o'
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'EMAIL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(33793476925872040715)
,p_component_action_id=>wwv_flow_imp.id(11795046764496003827)
,p_menu_entry_type=>'SEPARATOR'
,p_static_id=>'new'
,p_display_sequence=>30
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(11795046829414003827)
,p_component_action_id=>wwv_flow_imp.id(11795046764496003827)
,p_menu_entry_type=>'ENTRY'
,p_label=>'View profile'
,p_static_id=>'view-profile'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15:P15_EMPLOYEE_ID,P15_RETURN_PAGE:&EMPLOYEE_ID.,20'
,p_icon_css_classes=>'fa-user'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4402865729760417721)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(12815285425339092703)
,p_button_name=>'BULK_ACTIONS'
,p_static_id=>'bulk-actions'
,p_show_as_disabled=>false
,p_button_type=>'MENU'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Bulk Actions'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ellipsis-v'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(33793477847015040762)
,p_button_id=>wwv_flow_imp.id(4402865729760417721)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Export'
,p_static_id=>'export'
,p_display_sequence=>50
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_icon_css_classes=>'fa-download'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(33793477797933040761)
,p_button_id=>wwv_flow_imp.id(4402865729760417721)
,p_menu_entry_type=>'SEPARATOR'
,p_static_id=>'new'
,p_display_sequence=>40
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(33793477367168040757)
,p_button_id=>wwv_flow_imp.id(4402865729760417721)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Change department'
,p_static_id=>'update-department'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_icon_css_classes=>'fa-building-o'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(33793477615342040759)
,p_button_id=>wwv_flow_imp.id(4402865729760417721)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Change job title'
,p_static_id=>'update-job-title'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_icon_css_classes=>'fa-briefcase'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(33793477736881040760)
,p_button_id=>wwv_flow_imp.id(4402865729760417721)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Change Location'
,p_static_id=>'update-location'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_icon_css_classes=>'fa-location-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4402868456507417727)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12815285425339092703)
,p_button_name=>'RESET'
,p_static_id=>'reset'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RR,20::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4441711022910575659)
,p_name=>'P20_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12815289091326092786)
,p_item_display_point=>'NEXT'
,p_item_default=>'BUSINESS_UNIT'
,p_prompt=>'Order By'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Job;JOB_TITLE,Employee Name;ENAME,Business Unit;BUSINESS_UNIT'
,p_cHeight=>1
,p_tag_css_classes=>'no-item-ui'
,p_field_template=>2044213549383960320
,p_item_icon_css_classes=>'fa-sort'
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33793480939946040757)
,p_name=>'P20_SELECT_ALL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(12815289091326092786)
,p_item_display_point=>'PREVIOUS'
,p_prompt=>'Select All'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
