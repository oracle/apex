prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'FS-06 - Timeline'
,p_alias=>'FS-06-TIMELINE'
,p_step_title=>'FS-06 - Timeline'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2530071015796209513
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>When to use</h3>',
'<p>Use this pattern to filter records and explore matching results chronologically. It suits use cases such as reviewing tasks, milestones, or activities by date, responsible person, and status, then opening a record for details.</p>',
'',
'<h3>About this pattern page</h3>',
'<p>Search matches task name, assignee, or status. The Month facet supports multiple calendar-month ranges based on task start dates. Status and Assigned To checkbox facets allow multiple selections. The Timeline presents matching tasks with dates, as'
||'signees, and colored status badges. Task titles open details; assignee links filter by person. Reset clears all selections.</p>'))
,p_page_comment=>'Timeline filters tasks using START_DATE. The Month facet supplies named calendar-month ranges with inclusive first-of-month and exclusive next-month boundaries. Keep the sample-task LOV to 25 months (12 before and after the current month) to bound th'
||'e generated facet-count query. Months with no matching tasks are hidden.'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7767457380391262464)
,p_plug_name=>'Activity Timeline'
,p_static_id=>'activity-timeline'
,p_region_name=>'activity-timeline'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:t-ContentBlock--lightBG:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>2325543309974442989
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       TASK_NAME,',
'       ASSIGNED_TO_EMPNO,',
'       ASSIGNED_TO_NAME,',
'       ASSIGNED_TO_EMAIL,',
'       HOURS_ALLOCATED,',
'       WORK_MODE,',
'       START_DATE,',
'       END_DATE,',
'       STATUS,',
'           case',
'    when upper(trim(STATUS)) in (''OPEN'', ''OVERDUE'', ''BLOCKED'') then ''danger''',
'    when upper(trim(STATUS)) in (''ACTIVE'', ''CLOSED'', ''COMPLETED'', ''IN-PROGRESS'', ''IN PROGRESS'') then ''success''',
'    else ''warning''',
'end AS BADGE_STATE,',
'       CALENDAR_COLOR',
'  from FSP_TASKS'))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{"orderBys":[{"key":"START_DATE","expr":"START_DATE ASC"},{"key":"START_DATE_DESC","expr":"START_DATE DESC"},{"key":"ID","expr":"ID ASC"}],"itemName":"P12_ORDER_BY"}'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$TIMELINE'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', 'fa-calendar-month fa-2x',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_TYPE', 'icon',
  'BADGE_LABEL', 'Status',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_SHAPE', 't-Badge--rounded',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'STATUS',
  'DATE', 'START_DATE',
  'DESCRIPTION', 'WORK_MODE',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'STYLE', 't-Timeline--compact',
  'TITLE', 'TASK_NAME',
  'USER_NAME', 'ASSIGNED_TO_NAME')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5341403896284283929)
,p_name=>'ASSIGNED_TO_EMAIL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASSIGNED_TO_EMAIL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5341403816952283928)
,p_name=>'ASSIGNED_TO_EMPNO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASSIGNED_TO_EMPNO'
,p_data_type=>'NUMBER'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7773058552820981915)
,p_name=>'ASSIGNED_TO_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASSIGNED_TO_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>true
,p_value_protected=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5341404400172283934)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>140
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5341404338331283933)
,p_name=>'CALENDAR_COLOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CALENDAR_COLOR'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>130
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5341404236492283932)
,p_name=>'END_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'END_DATE'
,p_data_type=>'DATE'
,p_display_sequence=>120
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5341404009411283930)
,p_name=>'HOURS_ALLOCATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HOURS_ALLOCATED'
,p_data_type=>'NUMBER'
,p_display_sequence=>100
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7767457698008262464)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7767457910542262464)
,p_name=>'START_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'START_DATE'
,p_data_type=>'DATE'
,p_display_sequence=>30
,p_format_mask=>'DD-MON-YYYY'
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>true
,p_value_protected=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7767828621269037479)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>true
,p_value_protected=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7767457809721262464)
,p_name=>'TASK_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TASK_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>true
,p_value_protected=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5341404109878283931)
,p_name=>'WORK_MODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'WORK_MODE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>110
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(7773115145373318138)
,p_region_id=>wwv_flow_imp.id(7767457380391262464)
,p_position_id=>466556751380973050
,p_display_sequence=>20
,p_static_id=>'assignee-name'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::P12_ASSIGNEE:&ASSIGNED_TO_NAME.'
,p_link_attributes=>'title="Filter by this assignee"'
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'ASSIGNED_TO_NAME'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(7773115009452318138)
,p_region_id=>wwv_flow_imp.id(7767457380391262464)
,p_position_id=>352145388392709449
,p_display_sequence=>10
,p_static_id=>'task-title'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7767457215002262464)
,p_plug_name=>'FS-06 - Timeline'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(4402049144733325348)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8801060760557352708)
,p_plug_name=>'Button Bar'
,p_static_id=>'button-bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>2129856781885180476
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<div id="active_facets"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7767457289653262464)
,p_plug_name=>'Filter activities'
,p_static_id=>'search'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(7767457380391262464)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'show_charts', 'Y',
  'show_current_facets', 'Y',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7773056478917954198)
,p_name=>'P12_ASSIGNEE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(7767457289653262464)
,p_prompt=>'Assigned To'
,p_source=>'ASSIGNED_TO_NAME'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4442383886743719435)
,p_name=>'P12_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7767457289653262464)
,p_prompt=>'Search'
,p_placeholder=>'Search...'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7767834593861037540)
,p_name=>'P12_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(7767457289653262464)
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>6
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7773076891000055173)
,p_name=>'P12_TASK_MONTH'
,p_source_data_type=>'DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(7767457289653262464)
,p_prompt=>'Month'
,p_source=>'START_DATE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    select to_char(month_start, ''FMMonth YYYY'', ''NLS_DATE_LANGUAGE=English'') as display_value,',
'           to_char(month_start, ''YYYYMMDDHH24MISS'') || ''|'' ||',
'           to_char(add_months(month_start, 1), ''YYYYMMDDHH24MISS'') as return_value',
'      from (',
'            select add_months(trunc(sysdate, ''MM''), level - 13) as month_start',
'              from dual',
'            connect by level <= 25',
'           )',
'     order by month_start'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'N',
  'select_multiple', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4402804051066408015)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7767457215002262464)
,p_button_name=>'TIMELINE_RESET'
,p_static_id=>'timeline-reset'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Reset Timeline'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:12,RR'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7478962483408504)
,p_name=>'P12_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8801060760557352708)
,p_item_display_point=>'NEXT'
,p_item_default=>'START_DATE'
,p_prompt=>'Order By'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Start Date ascending;START_DATE,Start Date descending;START_DATE_DESC'
,p_cHeight=>1
,p_tag_css_classes=>'no-item-ui'
,p_field_template=>2044213549383960320
,p_item_icon_css_classes=>'fa-sort'
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp.component_end;
end;
/
