prompt --application/shared_components/navigation/breadcrumbentry
begin
--   Manifest
--     BREADCRUMB ENTRY: 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
