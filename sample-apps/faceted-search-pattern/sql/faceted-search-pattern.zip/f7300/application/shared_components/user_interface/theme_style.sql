prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 42
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.1'
,p_default_workspace_id=>20
,p_default_application_id=>7300
,p_default_id_offset=>7825738714325627
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(4405679988573490224)
,p_theme_id=>42
,p_name=>'Iris (Patterns)'
,p_static_id=>'iris-patterns'
,p_css_file_urls=>'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#'
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Iris.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Accent-Pillar":"ocean","@g_CustomAccent-BG":"#0a1b3a","@g_Header_Pillar_Strip":"show","@g_Header_Style":"pillar-dark","@g_Nav_Style":"pillar-light","@g_FontFamily":"oracle_sans","@g_Link-Base":"#0a1b3a","@g_Color-Palette-1":'
||'"#0a1b3a","@g_Color-Palette-1-FG":"#ffffff","@Nav-Exp":"280px"},"customCSS":".t-Button--primary {\n  --a-button-background-color: #0A1B3A;\n  --a-button-border-color: #0A1B3A;\n  --a-button-text-color: #FFFFFF;\n  --a-button-hover-background-color: #'
||'142B52;\n  --a-button-hover-border-color: #142B52;\n  --a-button-hover-text-color: #FFFFFF;\n}\n\n.no-item-ui {\n    --a-field-input-border-width: 0px;\n    --a-field-input-background-color: transparent;\n}","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#4397854249859164597.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
