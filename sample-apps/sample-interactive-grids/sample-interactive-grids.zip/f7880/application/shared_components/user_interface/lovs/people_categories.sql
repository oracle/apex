prompt --application/shared_components/user_interface/lovs/people_categories
begin
--   Manifest
--     PEOPLE_CATEGORIES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7880
,p_default_id_offset=>5957721914053453
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(739946362794503628)
,p_lov_name=>'PEOPLE_CATEGORIES'
,p_static_id=>'people-categories'
,p_lov_query=>'.'||wwv_flow_imp.id(739946362794503628)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089079761'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(739947058378503630)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Arts'
,p_lov_return_value=>'A'
,p_static_id=>'arts'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(739947455896503630)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Business & Law'
,p_lov_return_value=>'B_L'
,p_static_id=>'business-law'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(739947836958503631)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Politics'
,p_lov_return_value=>'P'
,p_static_id=>'politics'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(739946689439503629)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Science & Technology'
,p_lov_return_value=>'S_T'
,p_static_id=>'science-technology'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(739948222301503631)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Sports'
,p_lov_return_value=>'S'
,p_static_id=>'sports'
);
wwv_flow_imp.component_end;
end;
/
