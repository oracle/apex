prompt --application/shared_components/legacy_data_loads/eba_demo_ig_people
begin
--   Manifest
--     EBA_DEMO_IG_PEOPLE
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7880
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_load_table(
 p_id=>wwv_flow_api.id(688968543981143668)
,p_name=>'People'
,p_owner=>'#OWNER#'
,p_table_name=>'EBA_DEMO_IG_PEOPLE'
,p_unique_column_1=>'NAME'
,p_is_uk1_case_sensitive=>'N'
,p_is_uk2_case_sensitive=>'N'
,p_is_uk3_case_sensitive=>'N'
,p_skip_validation=>'N'
);
wwv_flow_api.component_end;
end;
/
