prompt --application/shared_components/security/authorizations/oracle_text_is_available
begin
--   Manifest
--     SECURITY SCHEME: Oracle Text is available
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7880
,p_default_id_offset=>5957721914053453
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(1178230561457949160)
,p_name=>'Oracle Text is available'
,p_static_id=>'oracle-text-is-available'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'plsql_function_body', 'return eba_demo_ig_text_pkg.text_is_available;')).to_clob
,p_error_message=>'Oracle Text is not available in this workspace.'
,p_version_scn=>'1089079761'
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
