prompt --application/shared_components/navigation/lists/editing_list
begin
--   Manifest
--     LIST: Editing List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7880
,p_default_id_offset=>5957721914053453
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(740283782809016857)
,p_name=>'Editing List'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089079761
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(740286755370016892)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Basic Editing'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_list_text_01=>'Demonstrates a standard editable Interactive Grid.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(740286402782016892)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Validation'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::::'
,p_list_text_01=>'Demonstrates how to include validation in your Interactive Grid.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(740286006884016892)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Other Column Types'
,p_list_item_link_target=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.::::'
,p_list_text_01=>'Demonstrates some of the different column types that can be included.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(740285597024016891)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Delete Only'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.::::'
,p_list_text_01=>'Demonstrates changing a grid to only allow deletion of rows.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(740285141642016891)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Protected Rows'
,p_list_item_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.::::'
,p_list_text_01=>'Demonstrates how you can control the ability to update or delete rows.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(740284809018016891)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Form with Grid'
,p_list_item_link_target=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.::::'
,p_list_text_01=>'Demonstrates a single updateable record (form) and an editable report (grid).'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(740284390037016890)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Master Detail'
,p_list_item_link_target=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.::::'
,p_list_text_01=>'Demonstrates a master grid, with detail grids which display the child records for the selected master record.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1962728197303713499)
,p_list_item_display_sequence=>75
,p_list_item_link_text=>'Dynamic Actions'
,p_list_item_link_target=>'f?p=&APP_ID.:58:&SESSION.::&DEBUG.:58:::'
,p_list_text_01=>'This example shows how to use Dynamic Actions within an Interactive Grid.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1632143867874352510)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'People (paging)'
,p_list_item_link_target=>'f?p=&APP_ID.:60:&SESSION.::&DEBUG.::::'
,p_list_text_01=>'Demonstrates editing a larger data set using traditional paging.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1879003969937387580)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Editing in a modal dialog'
,p_list_item_link_target=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.::::'
,p_list_text_01=>'Shows how interactive grids work in a modal dialog.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
