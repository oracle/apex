prompt --application/shared_components/navigation/lists/advanced_list
begin
--   Manifest
--     LIST: Advanced List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7880
,p_default_id_offset=>20533443216848537
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(740329818718160578)
,p_name=>'Advanced List'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089079761
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(740330029933160581)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Feature Customization'
,p_list_item_link_target=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.::::'
,p_list_text_01=>'Demonstrates how to use JavaScript to customize feature configuration settings.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(779698577480487310)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Client Validation'
,p_list_item_link_target=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.::::'
,p_list_text_01=>'Demonstrates using HTML5 form validation to implement client side validations.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(779698868862495423)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Tooltips'
,p_list_item_link_target=>'f?p=&APP_ID.:52:&SESSION.::&DEBUG.::::'
,p_list_text_01=>'Demonstrates how to integrate jQuery UI Tooltips to provide tooltips for Interactive Grid rows and cells.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(779699243917499827)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Advanced Delete'
,p_list_item_link_target=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.::::'
,p_list_text_01=>'Demonstrates how to customize Interactive Grid to focus on the task of deleting. Includes a custom row delete button.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1921857736149839942)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Item Type Plugins'
,p_list_item_link_target=>'f?p=&APP_ID.:56:&SESSION.::&DEBUG.:56:::'
,p_list_text_01=>'Demonstrates how to use an Item Type Plug-In ("Modern Star Rating") within an interactive grid.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1921858082817844388)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Custom Server Processing'
,p_list_item_link_target=>'f?p=&APP_ID.:57:&SESSION.::&DEBUG.:57:::'
,p_list_text_01=>'Shows how to process the submitted interactive grid rows with custom PL/SQL logic. '
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
