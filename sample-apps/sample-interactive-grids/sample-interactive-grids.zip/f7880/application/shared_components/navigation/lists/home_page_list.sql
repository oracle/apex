prompt --application/shared_components/navigation/lists/home_page_list
begin
--   Manifest
--     LIST: Home Page List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7880
,p_default_id_offset=>5957721914053453
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(735213209185456511)
,p_name=>'Home Page List'
,p_static_id=>'home-page-list'
,p_version_scn=>'1089079761'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(735214919534456514)
,p_list_item_display_sequence=>14
,p_list_item_link_text=>'Advanced'
,p_static_id=>'advanced'
,p_list_item_link_target=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-rocket'
,p_list_text_01=>'Demonstrations of advanced Interactive Grid techniques'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(735214562325456514)
,p_list_item_display_sequence=>13
,p_list_item_link_text=>'Editing'
,p_static_id=>'editing'
,p_list_item_link_target=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pencil-square-o'
,p_list_text_01=>'Demonstrations of the editing capabilities of Interactive Grid'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(735214141845456514)
,p_list_item_display_sequence=>12
,p_list_item_link_text=>'Pagination'
,p_static_id=>'pagination'
,p_list_item_link_target=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-chevron-circle-right'
,p_list_text_01=>'Demonstrations of pagination options of Interactive Grid'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(735213778276456513)
,p_list_item_display_sequence=>11
,p_list_item_link_text=>'Reporting'
,p_static_id=>'reporting'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>'Demonstrations of reporting (read-only) capabilities of Interactive Grid'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
