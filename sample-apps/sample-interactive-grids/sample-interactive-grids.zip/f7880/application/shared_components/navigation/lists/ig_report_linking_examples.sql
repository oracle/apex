prompt --application/shared_components/navigation/lists/ig_report_linking_examples
begin
--   Manifest
--     LIST: IG Report Linking Examples
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7880
,p_default_id_offset=>5957721914053453
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1052201078786401892)
,p_name=>'IG Report Linking Examples'
,p_static_id=>'ig-report-linking-examples'
,p_version_scn=>'1089079761'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1052201393456401894)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Clearing report settings'
,p_static_id=>'clearing-report-settings'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:CR:::'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1052224589598515852)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Filtering Report for salaries greater than 3000'
,p_static_id=>'filtering-report-for-salaries-greater-than'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:CR:IG_SAL:3000:'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1052202196184401895)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Invoking a Saved Report'
,p_static_id=>'invoking-a-saved-report'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.:IG_Roles:&DEBUG.:RR:::'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1052202997257401896)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Linking to a Saved Report'
,p_static_id=>'linking-to-a-saved-report'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.:IG[emp]_Main:&DEBUG.:CR:IGGT_SAL:3000:'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1052201799089401895)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Resetting to Developer Defaults'
,p_static_id=>'resetting-to-developer-defaults'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:RR:::'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
