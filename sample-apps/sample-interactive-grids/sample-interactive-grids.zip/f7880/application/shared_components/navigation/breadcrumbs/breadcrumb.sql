prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7880
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(1323695202805702255)
,p_name=>' Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(715311944156524310)
,p_parent_id=>0
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:::'
,p_page_id=>24
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(715319549859559610)
,p_parent_id=>wwv_flow_imp.id(715311944156524310)
,p_short_name=>'Manage Sample Data'
,p_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::'
,p_page_id=>25
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(715380025134584156)
,p_parent_id=>wwv_flow_imp.id(715311944156524310)
,p_short_name=>'Application Theme Style'
,p_link=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:::'
,p_page_id=>26
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(716568605979272479)
,p_parent_id=>wwv_flow_imp.id(719664508977664791)
,p_short_name=>'Basic Reporting'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(716618650777381642)
,p_parent_id=>wwv_flow_imp.id(719664508977664791)
,p_short_name=>'Column Groups'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719664508977664791)
,p_parent_id=>0
,p_short_name=>'Reporting'
,p_link=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:::'
,p_page_id=>37
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719688725300925582)
,p_parent_id=>wwv_flow_imp.id(719664508977664791)
,p_short_name=>'Add Toolbar Button'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719689342144933169)
,p_parent_id=>wwv_flow_imp.id(719664508977664791)
,p_short_name=>'Row Header'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719689713319937092)
,p_parent_id=>wwv_flow_imp.id(719664508977664791)
,p_short_name=>'Sequence Row Header'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719689930520939651)
,p_parent_id=>wwv_flow_imp.id(719664508977664791)
,p_short_name=>'Multiple Selection'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719690336207941249)
,p_parent_id=>wwv_flow_imp.id(719664508977664791)
,p_short_name=>'Saved Reports'
,p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719690509536942889)
,p_parent_id=>wwv_flow_imp.id(719664508977664791)
,p_short_name=>'Single Row View'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719690746691944462)
,p_parent_id=>wwv_flow_imp.id(719709760396990031)
,p_short_name=>'Traditional'
,p_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_page_id=>11
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719709760396990031)
,p_parent_id=>0
,p_short_name=>'Pagination'
,p_link=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:::'
,p_page_id=>38
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719716366736031259)
,p_parent_id=>wwv_flow_imp.id(719664508977664791)
,p_short_name=>'Icon and Detail Views'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719716722924039150)
,p_parent_id=>wwv_flow_imp.id(719709760396990031)
,p_short_name=>'Traditional (Total Rows)'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719716968225041982)
,p_parent_id=>wwv_flow_imp.id(719709760396990031)
,p_short_name=>'Traditional (Custom)'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719717097598044427)
,p_parent_id=>wwv_flow_imp.id(719709760396990031)
,p_short_name=>'Traditional (Select List)'
,p_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719717300132046207)
,p_parent_id=>wwv_flow_imp.id(719709760396990031)
,p_short_name=>'Scroll'
,p_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719717533763048433)
,p_parent_id=>wwv_flow_imp.id(719709760396990031)
,p_short_name=>'Load More'
,p_link=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::'
,p_page_id=>20
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719717692033050830)
,p_parent_id=>wwv_flow_imp.id(719709760396990031)
,p_short_name=>'Full Page with Maximize'
,p_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719717905916054154)
,p_parent_id=>wwv_flow_imp.id(719709760396990031)
,p_short_name=>'Scroll with Maximize'
,p_link=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:::'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719755497521173717)
,p_parent_id=>0
,p_short_name=>'Editing'
,p_link=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:::'
,p_page_id=>39
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719795958556309490)
,p_parent_id=>0
,p_short_name=>'Advanced'
,p_link=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:::'
,p_page_id=>40
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719800723450322753)
,p_parent_id=>wwv_flow_imp.id(719755497521173717)
,p_short_name=>'Basic Editing'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719800905314324333)
,p_parent_id=>wwv_flow_imp.id(719755497521173717)
,p_short_name=>'Validation'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719801136028326766)
,p_parent_id=>wwv_flow_imp.id(719755497521173717)
,p_short_name=>'Other Column Types'
,p_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:::'
,p_page_id=>36
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719801339674328640)
,p_parent_id=>wwv_flow_imp.id(719755497521173717)
,p_short_name=>'Delete Only'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719801553319330230)
,p_parent_id=>wwv_flow_imp.id(719755497521173717)
,p_short_name=>'Protected Rows'
,p_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
,p_page_id=>33
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719801686827332011)
,p_parent_id=>wwv_flow_imp.id(719755497521173717)
,p_short_name=>'Form with Grid'
,p_link=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:::'
,p_page_id=>34
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(719801950827333605)
,p_parent_id=>wwv_flow_imp.id(719755497521173717)
,p_short_name=>'Master Detail'
,p_link=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:::'
,p_page_id=>35
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(720278487324019178)
,p_parent_id=>wwv_flow_imp.id(719795958556309490)
,p_short_name=>'Feature Customization'
,p_link=>'f?p=&APP_ID.:50:&SESSION.'
,p_page_id=>50
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(723457296191136989)
,p_parent_id=>wwv_flow_imp.id(719795958556309490)
,p_short_name=>'Client Validation'
,p_link=>'f?p=&APP_ID.:51:&SESSION.'
,p_page_id=>51
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(723524493621496715)
,p_parent_id=>wwv_flow_imp.id(719795958556309490)
,p_short_name=>'Tooltips'
,p_link=>'f?p=&APP_ID.:52:&SESSION.'
,p_page_id=>52
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(724453277542204738)
,p_parent_id=>wwv_flow_imp.id(719795958556309490)
,p_short_name=>'Advanced Delete'
,p_link=>'f?p=&APP_ID.:53:&SESSION.'
,p_page_id=>53
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(759399657724113979)
,p_parent_id=>wwv_flow_imp.id(719755497521173717)
,p_short_name=>'People (paging)'
,p_link=>'f?p=&APP_ID.:60:&SESSION.'
,p_page_id=>60
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1031667452957553350)
,p_parent_id=>wwv_flow_imp.id(719664508977664791)
,p_short_name=>'Linking to Interactive Grids'
,p_link=>'f?p=&APP_ID.:15:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1157699953571137930)
,p_parent_id=>wwv_flow_imp.id(719664508977664791)
,p_short_name=>'Oracle Text'
,p_link=>'f?p=&APP_ID.:70:&SESSION.'
,p_page_id=>70
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1323695615090702260)
,p_parent_id=>0
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1517731820707424604)
,p_parent_id=>wwv_flow_imp.id(719709760396990031)
,p_short_name=>'Progressive Scroll'
,p_link=>'f?p=&APP_ID.:2:&SESSION.'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1673404782498334062)
,p_parent_id=>wwv_flow_imp.id(719664508977664791)
,p_short_name=>'Chart View'
,p_link=>'f?p=&APP_ID.:14:&SESSION.'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1858465954744429133)
,p_parent_id=>wwv_flow_imp.id(719755497521173717)
,p_short_name=>'Edit (Dialog)'
,p_link=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.:54,55::'
,p_page_id=>54
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1870344112764231303)
,p_parent_id=>wwv_flow_imp.id(719795958556309490)
,p_short_name=>'Item Type Plug-Ins'
,p_link=>'f?p=&APP_ID.:56:&SESSION.'
,p_page_id=>56
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1870448272746637493)
,p_parent_id=>wwv_flow_imp.id(719795958556309490)
,p_short_name=>'Custom Server Processing'
,p_link=>'f?p=&APP_ID.:57:&SESSION.'
,p_page_id=>57
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1942188490866786478)
,p_parent_id=>wwv_flow_imp.id(719755497521173717)
,p_short_name=>'Dynamic Actions'
,p_link=>'f?p=&APP_ID.:58:&SESSION.'
,p_page_id=>58
);
wwv_flow_imp.component_end;
end;
/
