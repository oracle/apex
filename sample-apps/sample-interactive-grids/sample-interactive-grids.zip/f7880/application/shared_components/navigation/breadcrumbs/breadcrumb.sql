prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7880
,p_default_id_offset=>5957721914053453
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(1344228646022550792)
,p_name=>' Breadcrumb'
,p_static_id=>'breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740222168517774119)
,p_parent_id=>wwv_flow_imp.id(740197952194513328)
,p_short_name=>'Add Toolbar Button'
,p_static_id=>'add-toolbar-button'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(735845387373372847)
,p_short_name=>'Administration'
,p_static_id=>'administration'
,p_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:::'
,p_page_id=>24
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740329401773158027)
,p_short_name=>'Advanced'
,p_static_id=>'advanced'
,p_link=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:::'
,p_page_id=>40
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(744986720759053275)
,p_parent_id=>wwv_flow_imp.id(740329401773158027)
,p_short_name=>'Advanced Delete'
,p_static_id=>'advanced-delete'
,p_link=>'f?p=&APP_ID.:53:&SESSION.'
,p_page_id=>53
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(735913468351432693)
,p_parent_id=>wwv_flow_imp.id(735845387373372847)
,p_short_name=>'Application Theme Style'
,p_static_id=>'application-theme-style'
,p_link=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:::'
,p_page_id=>26
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740334166667171290)
,p_parent_id=>wwv_flow_imp.id(740288940738022254)
,p_short_name=>'Basic Editing'
,p_static_id=>'basic-editing'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(737102049196121016)
,p_parent_id=>wwv_flow_imp.id(740197952194513328)
,p_short_name=>'Basic Reporting'
,p_static_id=>'basic-reporting'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1693938225715182599)
,p_parent_id=>wwv_flow_imp.id(740197952194513328)
,p_short_name=>'Chart View'
,p_static_id=>'chart-view'
,p_link=>'f?p=&APP_ID.:14:&SESSION.'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(743990739407985526)
,p_parent_id=>wwv_flow_imp.id(740329401773158027)
,p_short_name=>'Client Validation'
,p_static_id=>'client-validation'
,p_link=>'f?p=&APP_ID.:51:&SESSION.'
,p_page_id=>51
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(737152093994230179)
,p_parent_id=>wwv_flow_imp.id(740197952194513328)
,p_short_name=>'Column Groups'
,p_static_id=>'column-groups'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1890981715963486030)
,p_parent_id=>wwv_flow_imp.id(740329401773158027)
,p_short_name=>'Custom Server Processing'
,p_static_id=>'custom-server-processing'
,p_link=>'f?p=&APP_ID.:57:&SESSION.'
,p_page_id=>57
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740334782891177177)
,p_parent_id=>wwv_flow_imp.id(740288940738022254)
,p_short_name=>'Delete Only'
,p_static_id=>'delete-only'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1962721934083635015)
,p_parent_id=>wwv_flow_imp.id(740288940738022254)
,p_short_name=>'Dynamic Actions'
,p_static_id=>'dynamic-actions'
,p_link=>'f?p=&APP_ID.:58:&SESSION.'
,p_page_id=>58
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1878999397961277670)
,p_parent_id=>wwv_flow_imp.id(740288940738022254)
,p_short_name=>'Edit (Dialog)'
,p_static_id=>'edit-dialog'
,p_link=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.:54,55::'
,p_page_id=>54
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740288940738022254)
,p_short_name=>'Editing'
,p_static_id=>'editing'
,p_link=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:::'
,p_page_id=>39
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740811930540867715)
,p_parent_id=>wwv_flow_imp.id(740329401773158027)
,p_short_name=>'Feature Customization'
,p_static_id=>'feature-customization'
,p_link=>'f?p=&APP_ID.:50:&SESSION.'
,p_page_id=>50
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740335130044180548)
,p_parent_id=>wwv_flow_imp.id(740288940738022254)
,p_short_name=>'Form with Grid'
,p_static_id=>'form-with-grid'
,p_link=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:::'
,p_page_id=>34
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740251135249899367)
,p_parent_id=>wwv_flow_imp.id(740243203613838568)
,p_short_name=>'Full Page with Maximize'
,p_static_id=>'full-page-with-maximize'
,p_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1344229058307550797)
,p_short_name=>'Home'
,p_static_id=>'home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740249809952879796)
,p_parent_id=>wwv_flow_imp.id(740197952194513328)
,p_short_name=>'Icon and Detail Views'
,p_static_id=>'icon-and-detail-views'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1890877555981079840)
,p_parent_id=>wwv_flow_imp.id(740329401773158027)
,p_short_name=>'Item Type Plug-Ins'
,p_static_id=>'item-type-plug-ins'
,p_link=>'f?p=&APP_ID.:56:&SESSION.'
,p_page_id=>56
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1052200896174401887)
,p_parent_id=>wwv_flow_imp.id(740197952194513328)
,p_short_name=>'Linking to Interactive Grids'
,p_static_id=>'linking-to-interactive-grids'
,p_link=>'f?p=&APP_ID.:15:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740250976979896970)
,p_parent_id=>wwv_flow_imp.id(740243203613838568)
,p_short_name=>'Load More'
,p_static_id=>'load-more'
,p_link=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::'
,p_page_id=>20
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(735852993076408147)
,p_parent_id=>wwv_flow_imp.id(735845387373372847)
,p_short_name=>'Manage Sample Data'
,p_static_id=>'manage-sample-data'
,p_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::'
,p_page_id=>25
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740335394044182142)
,p_parent_id=>wwv_flow_imp.id(740288940738022254)
,p_short_name=>'Master Detail'
,p_static_id=>'master-detail'
,p_link=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:::'
,p_page_id=>35
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740223373737788188)
,p_parent_id=>wwv_flow_imp.id(740197952194513328)
,p_short_name=>'Multiple Selection'
,p_static_id=>'multiple-selection'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1178233396787986467)
,p_parent_id=>wwv_flow_imp.id(740197952194513328)
,p_short_name=>'Oracle Text'
,p_static_id=>'oracle-text'
,p_link=>'f?p=&APP_ID.:70:&SESSION.'
,p_page_id=>70
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740334579245175303)
,p_parent_id=>wwv_flow_imp.id(740288940738022254)
,p_short_name=>'Other Column Types'
,p_static_id=>'other-column-types'
,p_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:::'
,p_page_id=>36
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740243203613838568)
,p_short_name=>'Pagination'
,p_static_id=>'pagination'
,p_link=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:::'
,p_page_id=>38
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(779933100940962516)
,p_parent_id=>wwv_flow_imp.id(740288940738022254)
,p_short_name=>'People (paging)'
,p_static_id=>'people-paging'
,p_link=>'f?p=&APP_ID.:60:&SESSION.'
,p_page_id=>60
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1538265263924273141)
,p_parent_id=>wwv_flow_imp.id(740243203613838568)
,p_short_name=>'Progressive Scroll'
,p_static_id=>'progressive-scroll'
,p_link=>'f?p=&APP_ID.:2:&SESSION.'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740334996536178767)
,p_parent_id=>wwv_flow_imp.id(740288940738022254)
,p_short_name=>'Protected Rows'
,p_static_id=>'protected-rows'
,p_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
,p_page_id=>33
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740197952194513328)
,p_short_name=>'Reporting'
,p_static_id=>'reporting'
,p_link=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:::'
,p_page_id=>37
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740222785361781706)
,p_parent_id=>wwv_flow_imp.id(740197952194513328)
,p_short_name=>'Row Header'
,p_static_id=>'row-header'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740223779424789786)
,p_parent_id=>wwv_flow_imp.id(740197952194513328)
,p_short_name=>'Saved Reports'
,p_static_id=>'saved-reports'
,p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740250743348894744)
,p_parent_id=>wwv_flow_imp.id(740243203613838568)
,p_short_name=>'Scroll'
,p_static_id=>'scroll'
,p_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740251349132902691)
,p_parent_id=>wwv_flow_imp.id(740243203613838568)
,p_short_name=>'Scroll with Maximize'
,p_static_id=>'scroll-with-maximize'
,p_link=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:::'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740223156536785629)
,p_parent_id=>wwv_flow_imp.id(740197952194513328)
,p_short_name=>'Sequence Row Header'
,p_static_id=>'sequence-row-header'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740223952753791426)
,p_parent_id=>wwv_flow_imp.id(740197952194513328)
,p_short_name=>'Single Row View'
,p_static_id=>'single-row-view'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(744057936838345252)
,p_parent_id=>wwv_flow_imp.id(740329401773158027)
,p_short_name=>'Tooltips'
,p_static_id=>'tooltips'
,p_link=>'f?p=&APP_ID.:52:&SESSION.'
,p_page_id=>52
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740224189908792999)
,p_parent_id=>wwv_flow_imp.id(740243203613838568)
,p_short_name=>'Traditional'
,p_static_id=>'traditional'
,p_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_page_id=>11
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740250411441890519)
,p_parent_id=>wwv_flow_imp.id(740243203613838568)
,p_short_name=>'Traditional (Custom)'
,p_static_id=>'traditional-custom'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740250540814892964)
,p_parent_id=>wwv_flow_imp.id(740243203613838568)
,p_short_name=>'Traditional (Select List)'
,p_static_id=>'traditional-select-list'
,p_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740250166140887687)
,p_parent_id=>wwv_flow_imp.id(740243203613838568)
,p_short_name=>'Traditional (Total Rows)'
,p_static_id=>'traditional-total-rows'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(740334348531172870)
,p_parent_id=>wwv_flow_imp.id(740288940738022254)
,p_short_name=>'Validation'
,p_static_id=>'validation'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_imp.component_end;
end;
/
