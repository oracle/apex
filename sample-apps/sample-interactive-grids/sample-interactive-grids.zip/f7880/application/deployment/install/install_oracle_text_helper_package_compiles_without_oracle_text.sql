prompt --application/deployment/install/install_oracle_text_helper_package_compiles_without_oracle_text
begin
--   Manifest
--     INSTALL: INSTALL-Oracle TEXT helper package (compiles without Oracle Text)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7880
,p_default_id_offset=>5957721914053453
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_demo_ig_text_pkg authid current_user is'||wwv_flow.LF||
'    function text_is_available';
wwv_flow_imp.g_varchar2_table(2) := ' return boolean;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure create_text_preferences;'||wwv_flow.LF||
'    procedure drop_text_preferences;'||wwv_flow.LF||
'    pr';
wwv_flow_imp.g_varchar2_table(3) := 'ocedure create_text_index;'||wwv_flow.LF||
'    procedure drop_text_index;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure init_oracle_text;'||wwv_flow.LF||
''||wwv_flow.LF||
'    func';
wwv_flow_imp.g_varchar2_table(4) := 'tion convert_text_query( p_enduser_query in varchar2 ) return varchar2;'||wwv_flow.LF||
'end eba_demo_ig_text_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := ''||wwv_flow.LF||
'create or replace package body eba_demo_ig_text_pkg is'||wwv_flow.LF||
'    procedure execute_sql('||wwv_flow.LF||
'        p_sql    ';
wwv_flow_imp.g_varchar2_table(6) := '     in varchar2, '||wwv_flow.LF||
'        p_throw_error in boolean default true'||wwv_flow.LF||
'    ) is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        execute ';
wwv_flow_imp.g_varchar2_table(7) := 'immediate p_sql;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'        when others then '||wwv_flow.LF||
'            if p_throw_error then raise; en';
wwv_flow_imp.g_varchar2_table(8) := 'd if;'||wwv_flow.LF||
'    end execute_sql;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function text_is_available return boolean '||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_dummy nu';
wwv_flow_imp.g_varchar2_table(9) := 'mber;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        select 1 into l_dummy '||wwv_flow.LF||
'          from sys.all_objects'||wwv_flow.LF||
'         where owner  ';
wwv_flow_imp.g_varchar2_table(10) := '     = ''CTXSYS'' '||wwv_flow.LF||
'           and object_name = ''CTX_DDL'' '||wwv_flow.LF||
'           and rownum      = 1;'||wwv_flow.LF||
''||wwv_flow.LF||
'        re';
wwv_flow_imp.g_varchar2_table(11) := 'turn true;'||wwv_flow.LF||
'    exception '||wwv_flow.LF||
'        when NO_DATA_FOUND then return false;'||wwv_flow.LF||
'    end text_is_available;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(12) := '    procedure init_oracle_text is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        if text_is_available then'||wwv_flow.LF||
'            create_tex';
wwv_flow_imp.g_varchar2_table(13) := 't_preferences;'||wwv_flow.LF||
'            create_text_index;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end init_oracle_text;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedu';
wwv_flow_imp.g_varchar2_table(14) := 're drop_text_index is '||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        execute_sql( q''#drop index eba_demo_ig_text_ftx force#'' );'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(15) := '    end drop_text_index;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure drop_text_preferences is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        execute_sql( q''#b';
wwv_flow_imp.g_varchar2_table(16) := 'egin ctx_ddl.drop_preference( ''EBA_DEMO_IG_LX_PREF''); end;#'', false ); '||wwv_flow.LF||
'        execute_sql( q''#begi';
wwv_flow_imp.g_varchar2_table(17) := 'n ctx_ddl.drop_preference( ''EBA_DEMO_IG_DS_PREF''); end;#'', false ); '||wwv_flow.LF||
'        execute_sql( q''#begin c';
wwv_flow_imp.g_varchar2_table(18) := 'tx_ddl.drop_section_group( ''EBA_DEMO_IG_SG_PREF''); end;#'', false ); '||wwv_flow.LF||
'    end drop_text_preferences;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(19) := ''||wwv_flow.LF||
'    procedure create_text_preferences is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        -- Datastore Preference: Index the NAME ';
wwv_flow_imp.g_varchar2_table(20) := 'and the COUNTRY columns'||wwv_flow.LF||
'        execute_sql(q''# '||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            ctx_ddl.create_preference';
wwv_flow_imp.g_varchar2_table(21) := '('||wwv_flow.LF||
'                preference_name  => ''EBA_DEMO_IG_DS_PREF'','||wwv_flow.LF||
'                object_name      => ''MU';
wwv_flow_imp.g_varchar2_table(22) := 'LTI_COLUMN_DATASTORE'''||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'            ctx_ddl.set_attribute('||wwv_flow.LF||
'                pre';
wwv_flow_imp.g_varchar2_table(23) := 'ference_name  => ''EBA_DEMO_IG_DS_PREF'','||wwv_flow.LF||
'                attribute_name   => ''COLUMNS'','||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(24) := '   attribute_value  => ''NAME,COUNTRY,FROM_YR,TO_YR'''||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'            ctx_ddl.crea';
wwv_flow_imp.g_varchar2_table(25) := 'te_section_group('||wwv_flow.LF||
'                group_name       => ''EBA_DEMO_IG_SG_PREF'','||wwv_flow.LF||
'                group_t';
wwv_flow_imp.g_varchar2_table(26) := 'ype       => ''XML_SECTION_GROUP'''||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'            ctx_ddl.add_field_section('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(27) := '            group_name       => ''EBA_DEMO_IG_SG_PREF'','||wwv_flow.LF||
'                section_name     => ''COUNTRY''';
wwv_flow_imp.g_varchar2_table(28) := ','||wwv_flow.LF||
'                tag              => ''COUNTRY'','||wwv_flow.LF||
'                visible          => true'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(29) := '  );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'            ctx_ddl.add_field_section('||wwv_flow.LF||
'                group_name       => ''EBA_DEMO_I';
wwv_flow_imp.g_varchar2_table(30) := 'G_SG_PREF'','||wwv_flow.LF||
'                section_name     => ''NAME'','||wwv_flow.LF||
'                tag              => ''NAME'','||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(31) := '                visible          => true'||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'            ctx_ddl.create_preferen';
wwv_flow_imp.g_varchar2_table(32) := 'ce('||wwv_flow.LF||
'                preference_name  => ''EBA_DEMO_IG_LX_PREF'','||wwv_flow.LF||
'                object_name      => ''';
wwv_flow_imp.g_varchar2_table(33) := 'BASIC_LEXER'''||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'            ctx_ddl.set_attribute('||wwv_flow.LF||
'                preference_n';
wwv_flow_imp.g_varchar2_table(34) := 'ame  => ''EBA_DEMO_IG_LX_PREF'','||wwv_flow.LF||
'                attribute_name   => ''MIXED_CASE'','||wwv_flow.LF||
'                att';
wwv_flow_imp.g_varchar2_table(35) := 'ribute_value  => ''NO'''||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'            ctx_ddl.set_attribute('||wwv_flow.LF||
'                pre';
wwv_flow_imp.g_varchar2_table(36) := 'ference_name  => ''EBA_DEMO_IG_LX_PREF'','||wwv_flow.LF||
'                attribute_name   => ''BASE_LETTER'','||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(37) := '       attribute_value  => ''YES'''||wwv_flow.LF||
'            );'||wwv_flow.LF||
'            ctx_ddl.set_attribute('||wwv_flow.LF||
'                p';
wwv_flow_imp.g_varchar2_table(38) := 'reference_name  => ''EBA_DEMO_IG_LX_PREF'','||wwv_flow.LF||
'                attribute_name   => ''BASE_LETTER_TYPE'','||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(39) := '              attribute_value  => ''GENERIC'''||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        end;#'''||wwv_flow.LF||
'        ); '||wwv_flow.LF||
'    end create';
wwv_flow_imp.g_varchar2_table(40) := '_text_preferences;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure create_text_index is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        execute immediate '||wwv_flow.LF||
'q''#creat';
wwv_flow_imp.g_varchar2_table(41) := 'e index eba_demo_ig_text_ftx on eba_demo_ig_people (name)'||wwv_flow.LF||
'   indextype is ctxsys.context parameters ';
wwv_flow_imp.g_varchar2_table(42) := '( ''section group  EBA_DEMO_IG_SG_PREF'||wwv_flow.LF||
'                                             datastore      EB';
wwv_flow_imp.g_varchar2_table(43) := 'A_DEMO_IG_DS_PREF'||wwv_flow.LF||
'                                             lexer          EBA_DEMO_IG_LX_PREF'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(44) := '                                           stoplist       ctxsys.empty_stoplist'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(45) := '                         memory         10M'||wwv_flow.LF||
'                                             sync       ';
wwv_flow_imp.g_varchar2_table(46) := '    (on commit)'')#'';'||wwv_flow.LF||
'    end create_text_index;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function convert_text_query( p_enduser_query in';
wwv_flow_imp.g_varchar2_table(47) := ' varchar2 ) return varchar2 '||wwv_flow.LF||
'    is '||wwv_flow.LF||
'        l_tokens       apex_application_global.vc_arr2;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(48) := ' l_set_boolean  boolean := false;'||wwv_flow.LF||
''||wwv_flow.LF||
'        c_xml constant varchar2(32767) := ''<query><textquery><pro';
wwv_flow_imp.g_varchar2_table(49) := 'gression>'' ||'||wwv_flow.LF||
'                                            ''<seq>#NORMAL_AND#</seq>'' ||'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(50) := '                               ''<seq>#FUZZY_AND#</seq>'' ||'||wwv_flow.LF||
'                                         ';
wwv_flow_imp.g_varchar2_table(51) := '   ''<seq>#FUZZY_OR#</seq>'' ||'||wwv_flow.LF||
'                                          ''</progression></textquery><';
wwv_flow_imp.g_varchar2_table(52) := '/query>'';'||wwv_flow.LF||
'        l_textquery    varchar2(32767) := '''';'||wwv_flow.LF||
' '||wwv_flow.LF||
'        function generate_query( p_feature';
wwv_flow_imp.g_varchar2_table(53) := ' in varchar2, p_combine in varchar2) return varchar2 is'||wwv_flow.LF||
'            l_query        varchar2(32767);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(54) := '            l_clean_token  varchar2(100);'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            for i in 1..l_tokens.count loop'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(55) := '                l_clean_token := lower( regexp_replace( l_tokens( i ), ''[<>{}/()*%&!$?.:,;\+#]'', '''' ';
wwv_flow_imp.g_varchar2_table(56) := ') );'||wwv_flow.LF||
'                if ltrim( rtrim( l_clean_token ) ) is not null then'||wwv_flow.LF||
'                    if p_fe';
wwv_flow_imp.g_varchar2_table(57) := 'ature = ''FUZZY'' then'||wwv_flow.LF||
'                        l_query := l_query || ''FUZZY({'' || l_clean_token || ''},';
wwv_flow_imp.g_varchar2_table(58) := ' 50, 500) '';'||wwv_flow.LF||
'                    elsif p_feature = ''WILDCARD_RIGHT'' then '||wwv_flow.LF||
'                        l_';
wwv_flow_imp.g_varchar2_table(59) := 'query := l_query || l_clean_token || ''% '';'||wwv_flow.LF||
'                    else '||wwv_flow.LF||
'                        l_query';
wwv_flow_imp.g_varchar2_table(60) := ' := l_query || ''{'' || l_clean_token || ''} '';'||wwv_flow.LF||
'                    end if;'||wwv_flow.LF||
'                    if p_co';
wwv_flow_imp.g_varchar2_table(61) := 'mbine = ''OR'' then '||wwv_flow.LF||
'                        l_query := l_query || '' or '';'||wwv_flow.LF||
'                    else '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(62) := '                       l_query := l_query || '' and '';'||wwv_flow.LF||
'                    end if;'||wwv_flow.LF||
'                en';
wwv_flow_imp.g_varchar2_table(63) := 'd if;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'            if p_combine = ''AND'' then'||wwv_flow.LF||
'                l_query := substr(';
wwv_flow_imp.g_varchar2_table(64) := ' l_query, 1, length( l_query ) - 5 );'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                l_query := substr( l_query, 1';
wwv_flow_imp.g_varchar2_table(65) := ', length( l_query ) - 4 );'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            return ltrim( rtrim( l_query )); '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(66) := ' end generate_query;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        if substr( p_enduser_query, 1, 8 ) = ''ORATEXT:'' then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(67) := '    return substr( p_enduser_query, 9 );'||wwv_flow.LF||
'        else '||wwv_flow.LF||
'            l_textquery := c_xml;'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(68) := ' l_tokens := apex_util.string_to_table( p_enduser_query, '' '' );'||wwv_flow.LF||
'    '||wwv_flow.LF||
'            l_textquery := repl';
wwv_flow_imp.g_varchar2_table(69) := 'ace( l_textquery, ''#NORMAL_AND#'', generate_query( ''NORMAL'', ''AND'' ) );'||wwv_flow.LF||
'            l_textquery := re';
wwv_flow_imp.g_varchar2_table(70) := 'place( l_textquery, ''#FUZZY_AND#'', generate_query( ''FUZZY'', ''AND'' ) );'||wwv_flow.LF||
'    '||wwv_flow.LF||
'            return l_tex';
wwv_flow_imp.g_varchar2_table(71) := 'tquery;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end convert_text_query;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_demo_ig_text_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_demo';
wwv_flow_imp.g_varchar2_table(72) := '_ig_text_pkg.init_oracle_text;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1178229792559924302)
,p_install_id=>wwv_flow_imp.id(1344229312870554153)
,p_name=>'Oracle TEXT helper package (compiles without Oracle Text)'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
