prompt --application/deployment/install/install_data
begin
--   Manifest
--     INSTALL: INSTALL-data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7880
,p_default_id_offset=>5957721914053453
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace procedure eba_demo_ig_data'||wwv_flow.LF||
'as'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'delete from EBA_DEMO_IG_EMP;'||wwv_flow.LF||
'delete from EBA_D';
wwv_flow_imp.g_varchar2_table(2) := 'EMO_IG_DEPT;'||wwv_flow.LF||
'delete from EBA_DEMO_IG_PEOPLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'Insert into EBA_DEMO_IG_DEPT (DEPTNO,DNAME,LOC) values';
wwv_flow_imp.g_varchar2_table(3) := ' (10,''ACCOUNTING'',''NEW YORK'');'||wwv_flow.LF||
'Insert into EBA_DEMO_IG_DEPT (DEPTNO,DNAME,LOC) values (20,''RESEARCH''';
wwv_flow_imp.g_varchar2_table(4) := ',''DALLAS'');'||wwv_flow.LF||
'Insert into EBA_DEMO_IG_DEPT (DEPTNO,DNAME,LOC) values (30,''SALES'',''CHICAGO'');'||wwv_flow.LF||
'Insert in';
wwv_flow_imp.g_varchar2_table(5) := 'to EBA_DEMO_IG_DEPT (DEPTNO,DNAME,LOC) values (40,''OPERATIONS'',''BOSTON'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_DEMO_IG_E';
wwv_flow_imp.g_varchar2_table(6) := 'MP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO,NOTES,ONLEAVE,RATING) values (7839,''KING'',''PRESIDEN';
wwv_flow_imp.g_varchar2_table(7) := 'T'',null,to_date(''17-11-81'',''DD-MM-RR''),5000,null,10,null,''N'', null);'||wwv_flow.LF||
'insert into EBA_DEMO_IG_EMP (EM';
wwv_flow_imp.g_varchar2_table(8) := 'PNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO,NOTES,ONLEAVE,RATING) values (7698,''BLAKE'',''MANAGER'',7839';
wwv_flow_imp.g_varchar2_table(9) := ',to_date(''01-05-81'',''DD-MM-RR''),2850,null,30,''Lorem ipsum dolor sit amet, consectetur adipiscing eli';
wwv_flow_imp.g_varchar2_table(10) := 't, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis ';
wwv_flow_imp.g_varchar2_table(11) := 'nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor ';
wwv_flow_imp.g_varchar2_table(12) := 'in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occa';
wwv_flow_imp.g_varchar2_table(13) := 'ecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'',''N'', nu';
wwv_flow_imp.g_varchar2_table(14) := 'll);'||wwv_flow.LF||
'insert into EBA_DEMO_IG_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO,NOTES,ONLEAVE,RATING)';
wwv_flow_imp.g_varchar2_table(15) := ' values (7782,''CLARK'',''MANAGER'',7839,to_date(''09-06-81'',''DD-MM-RR''),2450,null,10,null,''N'',1);'||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(16) := ' into EBA_DEMO_IG_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO,NOTES,ONLEAVE,RATING) values (75';
wwv_flow_imp.g_varchar2_table(17) := '66,''JONES'',''MANAGER'',7839,to_date(''02-04-81'',''DD-MM-RR''),2975,null,20,null,''N'',1);'||wwv_flow.LF||
'insert into EBA_D';
wwv_flow_imp.g_varchar2_table(18) := 'EMO_IG_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO,NOTES,ONLEAVE,RATING) values (7788,''SCOTT'',';
wwv_flow_imp.g_varchar2_table(19) := '''ANALYST'',7566,to_date(''09-12-82'',''DD-MM-RR''),3000,null,20,null,''N'',3);'||wwv_flow.LF||
'insert into EBA_DEMO_IG_EMP ';
wwv_flow_imp.g_varchar2_table(20) := '(EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO,NOTES,ONLEAVE,RATING) values (7902,''FORD'',''ANALYST'',75';
wwv_flow_imp.g_varchar2_table(21) := '66,to_date(''03-12-81'',''DD-MM-RR''),3000,null,20,null,''N'',2);'||wwv_flow.LF||
'insert into EBA_DEMO_IG_EMP (EMPNO,ENAME';
wwv_flow_imp.g_varchar2_table(22) := ',JOB,MGR,HIREDATE,SAL,COMM,DEPTNO,NOTES,ONLEAVE,RATING) values (7369,''SMITH'',''CLERK'',7902,to_date(''1';
wwv_flow_imp.g_varchar2_table(23) := '7-12-80'',''DD-MM-RR''),800,null,20,null,''N'',null);'||wwv_flow.LF||
'insert into EBA_DEMO_IG_EMP (EMPNO,ENAME,JOB,MGR,HI';
wwv_flow_imp.g_varchar2_table(24) := 'REDATE,SAL,COMM,DEPTNO,NOTES,ONLEAVE,RATING) values (7499,''ALLEN'',''SALESMAN'',7698,to_date(''20-02-81''';
wwv_flow_imp.g_varchar2_table(25) := ',''DD-MM-RR''),1600,300,30,null,''N'',0);'||wwv_flow.LF||
'insert into EBA_DEMO_IG_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,';
wwv_flow_imp.g_varchar2_table(26) := 'COMM,DEPTNO,NOTES,ONLEAVE,RATING) values (7521,''WARD'',''SALESMAN'',7698,to_date(''22-02-81'',''DD-MM-RR'')';
wwv_flow_imp.g_varchar2_table(27) := ',1250,500,30,null,''N'',null);'||wwv_flow.LF||
'insert into EBA_DEMO_IG_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPT';
wwv_flow_imp.g_varchar2_table(28) := 'NO,NOTES,ONLEAVE,RATING) values (7654,''MARTIN'',''SALESMAN'',7698,to_date(''28-09-81'',''DD-MM-RR''),1250,1';
wwv_flow_imp.g_varchar2_table(29) := '400,30,null,''N'',4);'||wwv_flow.LF||
'insert into EBA_DEMO_IG_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO,NOTES,';
wwv_flow_imp.g_varchar2_table(30) := 'ONLEAVE,RATING) values (7844,''TURNER'',''SALESMAN'',7698,to_date(''08-09-81'',''DD-MM-RR''),1500,0,30,null,';
wwv_flow_imp.g_varchar2_table(31) := '''N'',1);'||wwv_flow.LF||
'insert into EBA_DEMO_IG_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO,NOTES,ONLEAVE,RATI';
wwv_flow_imp.g_varchar2_table(32) := 'NG) values (7876,''ADAMS'',''CLERK'',7788,to_date(''12-01-83'',''DD-MM-RR''),1100,null,20,''Medical Leave'',''Y';
wwv_flow_imp.g_varchar2_table(33) := ''',2);'||wwv_flow.LF||
'insert into EBA_DEMO_IG_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO,NOTES,ONLEAVE,RATING';
wwv_flow_imp.g_varchar2_table(34) := ') values (7900,''JAMES'',''CLERK'',7698,to_date(''03-12-81'',''DD-MM-RR''),950,null,30,null,''N'',3);'||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(35) := 'nto EBA_DEMO_IG_EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO,NOTES,ONLEAVE,RATING) values (7934';
wwv_flow_imp.g_varchar2_table(36) := ',''MILLER'',''CLERK'',7782,to_date(''23-01-82'',''DD-MM-RR''),1300,null,10,null,''N'',1);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_DEM';
wwv_flow_imp.g_varchar2_table(37) := 'O_IG_PEOPLE('||wwv_flow.LF||
'    id,'||wwv_flow.LF||
'    name,'||wwv_flow.LF||
'    link,'||wwv_flow.LF||
'    gender,'||wwv_flow.LF||
'    country,'||wwv_flow.LF||
'    category,'||wwv_flow.LF||
'    rating,'||wwv_flow.LF||
'    from';
wwv_flow_imp.g_varchar2_table(38) := '_yr,'||wwv_flow.LF||
'    to_yr) '||wwv_flow.LF||
'with x as ('||wwv_flow.LF||
'    select aaf.blob_content '||wwv_flow.LF||
'      from apex_application_files aaf, '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(39) := '         apex_applications aa'||wwv_flow.LF||
'     where aa.application_id = coalesce(apex_application_install.get_a';
wwv_flow_imp.g_varchar2_table(40) := 'pplication_id,to_number(v(''APP_ID'')))'||wwv_flow.LF||
'       and aaf.flow_id = aa.application_id'||wwv_flow.LF||
'       and aaf.file';
wwv_flow_imp.g_varchar2_table(41) := 'name = ''eba_demo_ig_people.json'''||wwv_flow.LF||
')'||wwv_flow.LF||
'select y.id,'||wwv_flow.LF||
'       y.name,'||wwv_flow.LF||
'       y.link,'||wwv_flow.LF||
'       y.gender,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(42) := '  y.country,'||wwv_flow.LF||
'       y.category,'||wwv_flow.LF||
'       y.rating,'||wwv_flow.LF||
'       y.from_yr,'||wwv_flow.LF||
'       y.to_yr '||wwv_flow.LF||
'from x,'||wwv_flow.LF||
'    json_';
wwv_flow_imp.g_varchar2_table(43) := 'table(x.blob_content, ''$[*]'' columns'||wwv_flow.LF||
'    ('||wwv_flow.LF||
'        id       number        path ''$.ID'','||wwv_flow.LF||
'        name ';
wwv_flow_imp.g_varchar2_table(44) := '    varchar2(255) path ''$.NAME'','||wwv_flow.LF||
'        link     varchar2(255) path ''$.LINK'','||wwv_flow.LF||
'        gender   varc';
wwv_flow_imp.g_varchar2_table(45) := 'har2(1)   path ''$.GENDER'','||wwv_flow.LF||
'        country  varchar2(50)  path ''$.COUNTRY'','||wwv_flow.LF||
'        category varchar';
wwv_flow_imp.g_varchar2_table(46) := '2(10)  path ''$.CATEGORY'','||wwv_flow.LF||
'        rating   number        path ''$.RATING'','||wwv_flow.LF||
'        from_yr  number   ';
wwv_flow_imp.g_varchar2_table(47) := '     path ''$.FROM_YR'','||wwv_flow.LF||
'        to_yr    number        path ''$.TO_YR'''||wwv_flow.LF||
'    )) y;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'b';
wwv_flow_imp.g_varchar2_table(48) := 'egin'||wwv_flow.LF||
'eba_demo_ig_data;'||wwv_flow.LF||
'commit;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1344238571805367334)
,p_install_id=>wwv_flow_imp.id(1344229312870554153)
,p_name=>'data'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
