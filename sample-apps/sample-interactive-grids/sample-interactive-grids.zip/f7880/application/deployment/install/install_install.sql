prompt --application/deployment/install/install_install
begin
--   Manifest
--     INSTALL: INSTALL-install
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7880
,p_default_id_offset=>5957721914053453
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE SEQUENCE EBA_DEMO_IG_DEPT_SEQ MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1';
wwv_flow_imp.g_varchar2_table(2) := ' START WITH 50 NOORDER  NOCYCLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE TABLE "EBA_DEMO_IG_DEPT"'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    "DEPTNO" NUMBER,'||wwv_flow.LF||
'    "DNA';
wwv_flow_imp.g_varchar2_table(3) := 'ME" VARCHAR2(60),'||wwv_flow.LF||
'    "LOC" VARCHAR2(40),'||wwv_flow.LF||
'    "NOTES" VARCHAR2(1000),'||wwv_flow.LF||
'    PRIMARY KEY ("DEPTNO")'||wwv_flow.LF||
'  U';
wwv_flow_imp.g_varchar2_table(4) := 'SING INDEX  ENABLE'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER  "BI_EBA_DEMO_IG_DEPT" '||wwv_flow.LF||
'    before insert on EB';
wwv_flow_imp.g_varchar2_table(5) := 'A_DEMO_IG_DEPT'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      if :new.deptno is null then'||wwv_flow.LF||
'          select eba_dem';
wwv_flow_imp.g_varchar2_table(6) := 'o_ig_dept_seq.nextval into :new.deptno from sys.dual;'||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'    end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TRIGGER "BI_EBA_';
wwv_flow_imp.g_varchar2_table(7) := 'DEMO_IG_DEPT" ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE SEQUENCE EBA_DEMO_IG_EMP_SEQ MINVALUE 1 MAXVALUE 999999999999999999';
wwv_flow_imp.g_varchar2_table(8) := '9999999999 INCREMENT BY 1 START WITH 8000 NOORDER  NOCYCLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE TABLE "EBA_DEMO_IG_EMP"'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(9) := ' "EMPNO" NUMBER NOT NULL ENABLE,'||wwv_flow.LF||
'    "ENAME" VARCHAR2(60),'||wwv_flow.LF||
'    "JOB" VARCHAR2(9),'||wwv_flow.LF||
'    "MGR" NUMBER,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(10) := '    "HIREDATE" DATE,'||wwv_flow.LF||
'    "SAL" NUMBER(7,2),'||wwv_flow.LF||
'    "COMM" NUMBER(7,2),'||wwv_flow.LF||
'    "ONLEAVE" VARCHAR2(1) NOT NU';
wwv_flow_imp.g_varchar2_table(11) := 'LL ENABLE,'||wwv_flow.LF||
'    "NOTES" VARCHAR2(1000),'||wwv_flow.LF||
'    "DEPTNO" NUMBER,'||wwv_flow.LF||
'    "FLEX1" VARCHAR2(1000),'||wwv_flow.LF||
'    "FLEX2" ';
wwv_flow_imp.g_varchar2_table(12) := 'VARCHAR2(1000),'||wwv_flow.LF||
'    "FLEX3" VARCHAR2(1000),'||wwv_flow.LF||
'    "FLEX4" VARCHAR2(1000),'||wwv_flow.LF||
'    "RATING" number,'||wwv_flow.LF||
'    CON';
wwv_flow_imp.g_varchar2_table(13) := 'STRAINT "EBA_DEMO_IG_EMP_RATING_CK" CHECK (RATING between 0 and 9) ENABLE,'||wwv_flow.LF||
'    CONSTRAINT "EBA_DEMO_';
wwv_flow_imp.g_varchar2_table(14) := 'IG_EMP_ONLEAVE_CK" CHECK (ONLEAVE in (''Y'', ''N'')) ENABLE, '||wwv_flow.LF||
'    PRIMARY KEY ("EMPNO")'||wwv_flow.LF||
'  USING INDEX  E';
wwv_flow_imp.g_varchar2_table(15) := 'NABLE'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TABLE "EBA_DEMO_IG_EMP" ADD FOREIGN KEY ("MGR")'||wwv_flow.LF||
'    REFERENCES  "EBA_DEMO_IG_EMP"';
wwv_flow_imp.g_varchar2_table(16) := ' ("EMPNO") ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TABLE "EBA_DEMO_IG_EMP" ADD FOREIGN KEY ("DEPTNO")'||wwv_flow.LF||
'    REFERENCES  "EBA_DE';
wwv_flow_imp.g_varchar2_table(17) := 'MO_IG_DEPT" ("DEPTNO") ON DELETE CASCADE ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER  "BI_EBA_DEMO_IG_EMP" '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(18) := '    before insert on EBA_DEMO_IG_EMP'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      if :new.empno is null then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(19) := '       select eba_demo_ig_emp_seq.nextval into :new.empno from sys.dual;'||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'    end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALT';
wwv_flow_imp.g_varchar2_table(20) := 'ER TRIGGER "BI_EBA_DEMO_IG_EMP" ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'REM Max ID of seeded people data is 104133, so create the ';
wwv_flow_imp.g_varchar2_table(21) := 'sequence starting'||wwv_flow.LF||
'REM beyond that to avoid clashes if developers create more people rows'||wwv_flow.LF||
'CREATE SEQU';
wwv_flow_imp.g_varchar2_table(22) := 'ENCE EBA_DEMO_IG_PEOPLE_SEQ MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WI';
wwv_flow_imp.g_varchar2_table(23) := 'TH 105000 CACHE 20 NOORDER  NOCYCLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE TABLE  "EBA_DEMO_IG_PEOPLE" '||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    "ID" NUMBER,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(24) := '"RATING" NUMBER,'||wwv_flow.LF||
'    "NAME" VARCHAR2(255),'||wwv_flow.LF||
'    "COUNTRY" VARCHAR2(50),'||wwv_flow.LF||
'    "FROM_YR" NUMBER,'||wwv_flow.LF||
'    "TO';
wwv_flow_imp.g_varchar2_table(25) := '_YR" NUMBER,'||wwv_flow.LF||
'    "LINK" VARCHAR2(255),'||wwv_flow.LF||
'    "CATEGORY" VARCHAR2(10),'||wwv_flow.LF||
'    "GENDER" VARCHAR2(1),'||wwv_flow.LF||
'    "F';
wwv_flow_imp.g_varchar2_table(26) := 'LEX1" VARCHAR2(1000),'||wwv_flow.LF||
'    "FLEX2" VARCHAR2(1000),'||wwv_flow.LF||
'    "FLEX3" VARCHAR2(1000),'||wwv_flow.LF||
'     CONSTRAINT "EBA_D';
wwv_flow_imp.g_varchar2_table(27) := 'EMO_IG_PEOPLE_PK" PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER  "BI_EB';
wwv_flow_imp.g_varchar2_table(28) := 'A_DEMO_IG_PEOPLE" '||wwv_flow.LF||
'  before insert on EBA_DEMO_IG_PEOPLE              '||wwv_flow.LF||
'  for each row '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  if :n';
wwv_flow_imp.g_varchar2_table(29) := 'ew."ID" is null then'||wwv_flow.LF||
'    select eba_demo_ig_people_seq.nextval into :new.id from sys.dual;'||wwv_flow.LF||
'  end if;';
wwv_flow_imp.g_varchar2_table(30) := ''||wwv_flow.LF||
'end;'||wwv_flow.LF||
''||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TRIGGER  "BI_EBA_DEMO_IG_PEOPLE" ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1344230708367745955)
,p_install_id=>wwv_flow_imp.id(1344229312870554153)
,p_name=>'install'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
