prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7880
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7880
,p_default_id_offset=>5957721914053453
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '----------------------------------------------------------------'||wwv_flow.LF||
'-- Remove Procedure'||wwv_flow.LF||
'---------------';
wwv_flow_imp.g_varchar2_table(2) := '-------------------------------------------------'||wwv_flow.LF||
'drop procedure eba_demo_ig_data;'||wwv_flow.LF||
'-----------------';
wwv_flow_imp.g_varchar2_table(3) := '-----------------------------------------------'||wwv_flow.LF||
'-- Remove Tables'||wwv_flow.LF||
'-----------------------------------';
wwv_flow_imp.g_varchar2_table(4) := '----------------------------'||wwv_flow.LF||
'drop table eba_demo_ig_emp    cascade constraints purge;'||wwv_flow.LF||
'drop table eba';
wwv_flow_imp.g_varchar2_table(5) := '_demo_ig_dept   cascade constraints purge;'||wwv_flow.LF||
'drop table eba_demo_ig_people cascade constraints purge;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(6) := ''||wwv_flow.LF||
'----------------------------------------------------------------'||wwv_flow.LF||
'-- Remove sequences'||wwv_flow.LF||
'--------------';
wwv_flow_imp.g_varchar2_table(7) := '--------------------------------------------------'||wwv_flow.LF||
'drop sequence eba_demo_ig_dept_seq;'||wwv_flow.LF||
'drop sequence';
wwv_flow_imp.g_varchar2_table(8) := ' eba_demo_ig_emp_seq;'||wwv_flow.LF||
'drop sequence eba_demo_ig_people_seq;'||wwv_flow.LF||
''||wwv_flow.LF||
'---------------------------------------';
wwv_flow_imp.g_varchar2_table(9) := '-------------------------'||wwv_flow.LF||
'-- Remove Oracle Text objects'||wwv_flow.LF||
'--------------------------------------------';
wwv_flow_imp.g_varchar2_table(10) := '--------------------'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_demo_ig_text_pkg.drop_text_preferences;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop package eba_';
wwv_flow_imp.g_varchar2_table(11) := 'demo_ig_text_pkg;'||wwv_flow.LF||
'  ';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(1344229312870554153)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE SEQUENCE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'EBA_DEMO_IG_DEPT:EBA_DEMO_IG_EMP:EBA_DEMO_IG_PEOPLE'
);
wwv_flow_imp.component_end;
end;
/
