prompt --application/shared_components/user_interface/lovs/people_gender
begin
--   Manifest
--     PEOPLE_GENDER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7880
,p_default_id_offset=>5957721914053453
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(739949108507507773)
,p_lov_name=>'PEOPLE_GENDER'
,p_static_id=>'people-gender'
,p_lov_query=>'.'||wwv_flow_imp.id(739949108507507773)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089079761'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(739949768758507773)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Female'
,p_lov_return_value=>'F'
,p_static_id=>'female'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(739949328834507773)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Male'
,p_lov_return_value=>'M'
,p_static_id=>'male'
);
wwv_flow_imp.component_end;
end;
/
