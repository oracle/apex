prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 9200
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>20
,p_default_application_id=>9200
,p_default_id_offset=>6233788281304841
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(20534763133427939682)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop package excm_util;',
'drop view excm_content_v;',
'drop table excm_content;',
'drop table excm_rte_images;'))
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'EXCM_CONTENT:EXCM_RTE_IMAGES:EXCM_UTIL'
);
wwv_flow_imp.component_end;
end;
/
