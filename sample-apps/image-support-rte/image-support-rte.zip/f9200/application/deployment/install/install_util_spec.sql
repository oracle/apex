prompt --application/deployment/install/install_util_spec
begin
--   Manifest
--     INSTALL: INSTALL-util spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>20
,p_default_application_id=>9200
,p_default_id_offset=>6233788281304841
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(21046291572501718287)
,p_install_id=>wwv_flow_imp.id(20534763133427939682)
,p_name=>'util spec'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package excm_util  ',
'as  ',
'',
'-- used in EXCM_CONTENT_V to replace the session placeholder, if it exists, with the current user''s session id',
'function replace_session_on_display (',
'    p_body        in  clob,',
'    p_session_id  in  number )',
'    return clob;',
' ',
'-- used by the application-level POST_IMAGE process to upload the image and return (via apex_json.write) a url to display it',
'procedure upload_rte_image (  ',
'    p_file_base64      in  clob,  ',
'    p_filename         in  varchar2,  ',
'    p_mimetype         in  varchar2,  ',
'    p_image_ref_id     in  number ) ;  ',
'  ',
'procedure add_content (  ',
'    p_content          in  clob,  ',
'    p_image_ref_id     in  number );  ',
'  ',
'procedure update_content (  ',
'    p_content_id       in  number,  ',
'    p_content          in  clob,  ',
'    p_image_ref_id     in  number );  ',
'  ',
'procedure delete_content (  ',
'    p_content_id       in  number );    ',
' ',
'end excm_util;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
