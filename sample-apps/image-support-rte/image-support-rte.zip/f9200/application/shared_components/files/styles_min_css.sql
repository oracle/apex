prompt --application/shared_components/files/styles_min_css
begin
--   Manifest
--     APP STATIC FILES: 9200
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>9200
,p_default_id_offset=>6233788281304841
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E742D436F6D6D656E74732D636F6D6D656E7420696D67207B6D61782D77696474683A20313030253B6865696768743A206175746F3B7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(28315403650137826822)
,p_file_name=>'styles.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
