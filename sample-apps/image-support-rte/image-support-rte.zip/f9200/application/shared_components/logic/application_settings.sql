prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 9200
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>9200
,p_default_id_offset=>6233788281304841
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(20534536039906695606)
,p_name=>'GET_IMAGE_PREFIX'
,p_value=>'/pls/apex/r/dbtools_prod/image-support-for-rte/'
,p_is_required=>'N'
,p_on_upgrade_keep_value=>true
,p_version_scn=>45653214478676
);
wwv_flow_imp.component_end;
end;
/
