prompt --application/shared_components/logic/application_processes/post_image
begin
--   Manifest
--     APPLICATION PROCESS: POST_IMAGE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9200
,p_default_id_offset=>6233788281304841
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(19904240233499600229)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_name=>'POST_IMAGE'
,p_static_id=>'post-image'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'excm_util.upload_rte_image (',
'    p_file_base64  => apex_application.g_clob_01,',
'    p_filename     => apex_application.g_x02,',
'    p_mimetype     => apex_application.g_x03,',
'    p_image_ref_id => json_value(apex_application.g_x01, ''$.imageRefId'') );'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>'45280264444225'
);
wwv_flow_imp.component_end;
end;
/
