prompt --application/shared_components/logic/application_processes/set_get_image_prefix
begin
--   Manifest
--     APPLICATION PROCESS: set GET_IMAGE_PREFIX
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9200
,p_default_id_offset=>6233788281304841
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(20534852888533956625)
,p_process_sequence=>1
,p_process_point=>'ON_NEW_INSTANCE'
,p_process_name=>'set GET_IMAGE_PREFIX'
,p_static_id=>'set-get-image-prefix'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_app_setting.set_value(',
'    p_name  => ''GET_IMAGE_PREFIX'',',
'    p_value => substr(APEX_UTIL.HOST_URL(''SCRIPT''),length(APEX_UTIL.HOST_URL())+1));'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'nvl(apex_app_setting.get_value (p_name  => ''GET_IMAGE_PREFIX''),''x'') != substr(APEX_UTIL.HOST_URL(''SCRIPT''),length(APEX_UTIL.HOST_URL())+1)'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_version_scn=>'45291343667693'
);
wwv_flow_imp.component_end;
end;
/
