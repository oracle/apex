prompt --application/deployment/install/install_create_tables_and_view
begin
--   Manifest
--     INSTALL: INSTALL-create tables and view
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9200
,p_default_id_offset=>6233788281304841
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table excm_content ('||wwv_flow.LF||
'    id                number default on null to_number(sys_guid(), ''XXXX';
wwv_flow_imp.g_varchar2_table(2) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                          constraint excm_content_pk primary key,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(3) := '  body              clob,'||wwv_flow.LF||
'    body_html         clob,'||wwv_flow.LF||
'    body_no_images    clob,'||wwv_flow.LF||
'    image_ref_id  ';
wwv_flow_imp.g_varchar2_table(4) := '    number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created           date not null,'||wwv_flow.LF||
'    created_by        varchar2(255 char) not';
wwv_flow_imp.g_varchar2_table(5) := ' null,'||wwv_flow.LF||
'    updated           date not null,'||wwv_flow.LF||
'    updated_by        varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'cre';
wwv_flow_imp.g_varchar2_table(6) := 'ate index excm_content_i1 on excm_content (image_ref_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger excm_content_bi';
wwv_flow_imp.g_varchar2_table(7) := 'u '||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on excm_content'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(8) := '    :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USE';
wwv_flow_imp.g_varchar2_table(9) := 'R''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APE';
wwv_flow_imp.g_varchar2_table(10) := 'X$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- DONE IN TRIGGER TO PREVENT MANUAL UPDATE OF BODY_HTML'||wwv_flow.LF||
'    :new';
wwv_flow_imp.g_varchar2_table(11) := '.body_html := apex_markdown.to_html(:new.body);'||wwv_flow.LF||
'end excm_content_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace view exc';
wwv_flow_imp.g_varchar2_table(12) := 'm_content_v as'||wwv_flow.LF||
'select id, '||wwv_flow.LF||
'       excm_util.replace_session_on_display(body, sys_context(''APEX$SESSI';
wwv_flow_imp.g_varchar2_table(13) := 'ON'', ''APP_SESSION'') ) body,'||wwv_flow.LF||
'       excm_util.replace_session_on_display(body_html, sys_context(''APEX';
wwv_flow_imp.g_varchar2_table(14) := '$SESSION'', ''APP_SESSION'') ) body_html,'||wwv_flow.LF||
'       body_no_images, '||wwv_flow.LF||
'       image_ref_id,'||wwv_flow.LF||
'       created, ';
wwv_flow_imp.g_varchar2_table(15) := 'created_by, updated, updated_by'||wwv_flow.LF||
'  from excm_content;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table excm_rte_images ('||wwv_flow.LF||
'    id        ';
wwv_flow_imp.g_varchar2_table(16) := '         number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(17) := '                  constraint excm_rte_images_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    file_blob          blob     ';
wwv_flow_imp.g_varchar2_table(18) := '          not null,'||wwv_flow.LF||
'    unique_filename    varchar2(512 char) not null,'||wwv_flow.LF||
'    filename           varch';
wwv_flow_imp.g_varchar2_table(19) := 'ar2(512 char), -- image.png for screensnaps'||wwv_flow.LF||
'    mimetype           varchar2(512 char),'||wwv_flow.LF||
'    blob_size';
wwv_flow_imp.g_varchar2_table(20) := '          number,'||wwv_flow.LF||
'    image_ref_id      number             not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created            d';
wwv_flow_imp.g_varchar2_table(21) := 'ate not null,'||wwv_flow.LF||
'    created_by         varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table excm_rte_images add';
wwv_flow_imp.g_varchar2_table(22) := ' constraint excm_rte_images_uk '||wwv_flow.LF||
'    unique (unique_filename);'||wwv_flow.LF||
''||wwv_flow.LF||
'create index excm_rte_images_i1 on ex';
wwv_flow_imp.g_varchar2_table(23) := 'cm_rte_images (image_ref_id);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(21046110377220958071)
,p_install_id=>wwv_flow_imp.id(20534763133427939682)
,p_name=>'create tables and view'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
