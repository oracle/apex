prompt --application/deployment/install/install_util_body
begin
--   Manifest
--     INSTALL: INSTALL-util body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9200
,p_default_id_offset=>6233788281304841
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body excm_util'||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'g_session_placeholder constant varchar2(20) := ''~RTE*SE';
wwv_flow_imp.g_varchar2_table(2) := 'SS~'';'||wwv_flow.LF||
''||wwv_flow.LF||
'-- this removes images from abandoned content (ie. content never created but images uploaded)';
wwv_flow_imp.g_varchar2_table(3) := ''||wwv_flow.LF||
'--   this is executed each time content is scanned to avoid the need for a job to do the cleanup'||wwv_flow.LF||
'pr';
wwv_flow_imp.g_varchar2_table(4) := 'ocedure cleanup_old_images'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    delete from excm_rte_images'||wwv_flow.LF||
'     where image_ref_id not in (';
wwv_flow_imp.g_varchar2_table(5) := 'select image_ref_id from excm_content)'||wwv_flow.LF||
'       and created < sysdate-1;'||wwv_flow.LF||
'end cleanup_old_images;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- ';
wwv_flow_imp.g_varchar2_table(6) := 'this returns a colon separated list of all the names of images within a clob'||wwv_flow.LF||
'function find_images ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '    p_clob  in  clob )'||wwv_flow.LF||
'    return varchar2 '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_clob                clob;'||wwv_flow.LF||
'    l_clob_length    ';
wwv_flow_imp.g_varchar2_table(8) := '     integer;'||wwv_flow.LF||
'    l_image_prefix        varchar2(255)  := ''](''||apex_app_setting.get_value (p_name =';
wwv_flow_imp.g_varchar2_table(9) := '> ''GET_IMAGE_PREFIX'')||''get-image?x01='';'||wwv_flow.LF||
'    l_prefix_length       number         := length(l_image_';
wwv_flow_imp.g_varchar2_table(10) := 'prefix);'||wwv_flow.LF||
'    l_image_list          varchar2(4000) := null;'||wwv_flow.LF||
'    l_start               integer        ';
wwv_flow_imp.g_varchar2_table(11) := ':= 1;'||wwv_flow.LF||
'    l_match               integer;'||wwv_flow.LF||
'    l_image_name          varchar2(255);'||wwv_flow.LF||
'    l_loop_count  ';
wwv_flow_imp.g_varchar2_table(12) := '        integer        := 0;'||wwv_flow.LF||
'    l_max_loops           integer        := 100;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- remove se';
wwv_flow_imp.g_varchar2_table(13) := 'ssion placeholder (if it exists)'||wwv_flow.LF||
'    l_clob := replace(p_clob,''session=''||g_session_placeholder||''&''';
wwv_flow_imp.g_varchar2_table(14) := ','''');'||wwv_flow.LF||
'    -- Get the length of the clob'||wwv_flow.LF||
'    l_clob_length := dbms_lob.getlength(l_clob);'||wwv_flow.LF||
'    -- Loop';
wwv_flow_imp.g_varchar2_table(15) := ' through the clob to extract image names'||wwv_flow.LF||
'    while l_start <= l_clob_length loop'||wwv_flow.LF||
'        if l_loop_c';
wwv_flow_imp.g_varchar2_table(16) := 'ount > l_max_loops then'||wwv_flow.LF||
'            exit; -- prevent infinite loop'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        l_match :';
wwv_flow_imp.g_varchar2_table(17) := '= null;'||wwv_flow.LF||
'        -- will find the beginning of the image string'||wwv_flow.LF||
'        l_match := instr(l_clob, l_im';
wwv_flow_imp.g_varchar2_table(18) := 'age_prefix, l_start, 1);'||wwv_flow.LF||
'        exit when l_match = 0;'||wwv_flow.LF||
'        -- extract the image name'||wwv_flow.LF||
'        l_';
wwv_flow_imp.g_varchar2_table(19) := 'image_name := substr(l_clob, l_match + l_prefix_length, 22);'||wwv_flow.LF||
'        -- Append to the image list'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(20) := '     if l_image_list is not null then'||wwv_flow.LF||
'            l_image_list := l_image_list || '':'' || l_image_nam';
wwv_flow_imp.g_varchar2_table(21) := 'e;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            l_image_list := l_image_name;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- Move position f';
wwv_flow_imp.g_varchar2_table(22) := 'orward to continue searching'||wwv_flow.LF||
'        l_start := l_match + l_prefix_length + 22;'||wwv_flow.LF||
'        l_loop_count';
wwv_flow_imp.g_varchar2_table(23) := ' := l_loop_count + 1;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_image_list;'||wwv_flow.LF||
'end find_images;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- this finds all t';
wwv_flow_imp.g_varchar2_table(24) := 'he image links in a clob and replaces with [image], for use in IRs and emails'||wwv_flow.LF||
'--   called by insert ';
wwv_flow_imp.g_varchar2_table(25) := 'and update procedures (store the resulting clob for reuse as created one and displayed multiple time';
wwv_flow_imp.g_varchar2_table(26) := 's)'||wwv_flow.LF||
'function replace_images ('||wwv_flow.LF||
'    p_clob  in  clob )'||wwv_flow.LF||
'    return clob '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_clob_length         in';
wwv_flow_imp.g_varchar2_table(27) := 'teger;'||wwv_flow.LF||
'    l_image_prefix        varchar2(255);'||wwv_flow.LF||
'    l_prefix_length       number;'||wwv_flow.LF||
'    l_image_list  ';
wwv_flow_imp.g_varchar2_table(28) := '        varchar2(4000) := null;'||wwv_flow.LF||
'    l_start               integer;'||wwv_flow.LF||
'    l_match               integer';
wwv_flow_imp.g_varchar2_table(29) := ';'||wwv_flow.LF||
'    l_begin               integer;'||wwv_flow.LF||
'    l_image_name          varchar2(255);'||wwv_flow.LF||
'    l_alt_text        ';
wwv_flow_imp.g_varchar2_table(30) := '    varchar2(4000);'||wwv_flow.LF||
'    l_filename            varchar2(255);'||wwv_flow.LF||
'    l_loop_count          integer;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(31) := 'l_max_loops           integer        := 100;'||wwv_flow.LF||
'    l_clob                clob           := p_clob;'||wwv_flow.LF||
'beg';
wwv_flow_imp.g_varchar2_table(32) := 'in'||wwv_flow.LF||
'    -- Get the length of the input clob'||wwv_flow.LF||
'    l_clob_length := dbms_lob.getlength(p_clob);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- ';
wwv_flow_imp.g_varchar2_table(33) := 'first check without session - if needed, a second loop using session'||wwv_flow.LF||
'    for i in 1..2 loop'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(34) := 'if i = 1 then'||wwv_flow.LF||
'           l_image_prefix   := ''](''||apex_app_setting.get_value (p_name => ''GET_IMAGE_';
wwv_flow_imp.g_varchar2_table(35) := 'PREFIX'')||''get-image?x01='';'||wwv_flow.LF||
'           l_prefix_length  := length(l_image_prefix);'||wwv_flow.LF||
'           l_star';
wwv_flow_imp.g_varchar2_table(36) := 't          := 1;'||wwv_flow.LF||
'           l_loop_count     := 0;    '||wwv_flow.LF||
'        else'||wwv_flow.LF||
'           -- Search again inclu';
wwv_flow_imp.g_varchar2_table(37) := 'ding session'||wwv_flow.LF||
'           l_image_prefix   := ''](''||apex_app_setting.get_value (p_name => ''GET_IMAGE_P';
wwv_flow_imp.g_varchar2_table(38) := 'REFIX'')||''get-image?session=''||g_session_placeholder||''&x01='';'||wwv_flow.LF||
'           l_prefix_length  := length';
wwv_flow_imp.g_varchar2_table(39) := '(l_image_prefix);'||wwv_flow.LF||
'           l_start          := 1;'||wwv_flow.LF||
'           l_loop_count     := 0;'||wwv_flow.LF||
'        end if';
wwv_flow_imp.g_varchar2_table(40) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Loop through the clob to find and replace image names'||wwv_flow.LF||
'        while l_start <= l_clob_';
wwv_flow_imp.g_varchar2_table(41) := 'length loop'||wwv_flow.LF||
'            if l_loop_count > l_max_loops then'||wwv_flow.LF||
'                exit; -- prevent infinite';
wwv_flow_imp.g_varchar2_table(42) := ' loop'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            l_match := null;'||wwv_flow.LF||
'            -- will find the beginning of the';
wwv_flow_imp.g_varchar2_table(43) := ' image string'||wwv_flow.LF||
'            l_match := instr(p_clob, l_image_prefix, l_start, 1);'||wwv_flow.LF||
'            exit whe';
wwv_flow_imp.g_varchar2_table(44) := 'n l_match = 0;'||wwv_flow.LF||
'            -- extract the image name'||wwv_flow.LF||
'            l_image_name := substr(p_clob, l_ma';
wwv_flow_imp.g_varchar2_table(45) := 'tch + l_prefix_length, 22);'||wwv_flow.LF||
'            -- if no alt text added, find image name'||wwv_flow.LF||
'            if subs';
wwv_flow_imp.g_varchar2_table(46) := 'tr(p_clob,l_match-2,2) = ''!['' then'||wwv_flow.LF||
'               -- find filename of image, if was file and not scr';
wwv_flow_imp.g_varchar2_table(47) := 'eensnap'||wwv_flow.LF||
'               -- if image gets delete from images table, editing the content will fail to s';
wwv_flow_imp.g_varchar2_table(48) := 'ave'||wwv_flow.LF||
'               --    wrapping this allows l_filename to be null, which is handled during replace';
wwv_flow_imp.g_varchar2_table(49) := 'ment'||wwv_flow.LF||
'               begin'||wwv_flow.LF||
'                   select filename'||wwv_flow.LF||
'                     into l_filename'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(50) := '                   from excm_rte_images'||wwv_flow.LF||
'                    where unique_filename = l_image_name;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(51) := '             exception'||wwv_flow.LF||
'                   when no_data_found then null;'||wwv_flow.LF||
'               end;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(52) := '       -- replace image link'||wwv_flow.LF||
'               if nvl(l_filename,''image.png'') != ''image.png'' then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(53) := '              -- if link was added to image, there will be extra square brackets'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(54) := 'l_clob := replace(l_clob,''[![''||l_image_prefix||l_image_name||'')]'',''[''||l_filename||'']'');'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(55) := '         l_clob := replace(l_clob,''![''||l_image_prefix||l_image_name||'')'',''[''||l_filename||'']'');'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(56) := '            else'||wwv_flow.LF||
'                   -- if link was added to image, there will be extra square bracke';
wwv_flow_imp.g_varchar2_table(57) := 'ts'||wwv_flow.LF||
'                   l_clob := replace(l_clob,''[![''||l_image_prefix||l_image_name||'')]'',''[image]'');';
wwv_flow_imp.g_varchar2_table(58) := ''||wwv_flow.LF||
'                   l_clob := replace(l_clob,''![''||l_image_prefix||l_image_name||'')'',''[image]'');'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(59) := '            end if;'||wwv_flow.LF||
'               l_filename := null;'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                l_begin     ';
wwv_flow_imp.g_varchar2_table(60) := ':= instr(p_clob, ''!['', -(l_clob_length-l_match), 1);'||wwv_flow.LF||
'                l_alt_text  := substr(p_clob, l';
wwv_flow_imp.g_varchar2_table(61) := '_begin+2, l_match-l_begin-2);'||wwv_flow.LF||
'                -- if link was added to image, there will be extra squ';
wwv_flow_imp.g_varchar2_table(62) := 'are brackets'||wwv_flow.LF||
'                l_clob      := replace(l_clob,''[![''||l_alt_text||l_image_prefix||l_imag';
wwv_flow_imp.g_varchar2_table(63) := 'e_name||'')]'',''[''||l_alt_text||'']'');'||wwv_flow.LF||
'                l_clob      := replace(l_clob,''![''||l_alt_text||';
wwv_flow_imp.g_varchar2_table(64) := 'l_image_prefix||l_image_name||'')'',''[''||l_alt_text||'']'');'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- Move po';
wwv_flow_imp.g_varchar2_table(65) := 'sition forward to continue searching'||wwv_flow.LF||
'            l_start := l_match + l_prefix_length + 22;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(66) := '    l_loop_count := l_loop_count + 1;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- if any images replace then no ne';
wwv_flow_imp.g_varchar2_table(67) := 'ed to check using session'||wwv_flow.LF||
'        if l_image_name is not null then'||wwv_flow.LF||
'           return l_clob;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(68) := ' end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'end replace_images;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function replace_session_on_save ';
wwv_flow_imp.g_varchar2_table(69) := '('||wwv_flow.LF||
'    p_body        in  clob )'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    return regexp_replace(p_body, ''(\?|&)(se';
wwv_flow_imp.g_varchar2_table(70) := 'ssion=)([[:digit:]]+)'', ''\1\2'' || g_session_placeholder);'||wwv_flow.LF||
'end replace_session_on_save;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function re';
wwv_flow_imp.g_varchar2_table(71) := 'place_session_on_display ('||wwv_flow.LF||
'    p_body        in  clob,'||wwv_flow.LF||
'    p_session_id  in  number )'||wwv_flow.LF||
'    return clo';
wwv_flow_imp.g_varchar2_table(72) := 'b'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    return replace(p_body, ''session=''||g_session_placeholder, ''session='' || p_session_id)';
wwv_flow_imp.g_varchar2_table(73) := ';'||wwv_flow.LF||
'end replace_session_on_display;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- images can be removed during edit or pasted in and then remo';
wwv_flow_imp.g_varchar2_table(74) := 'ved before create'||wwv_flow.LF||
'--   this ensures those are removed'||wwv_flow.LF||
'procedure remove_orphan_images ('||wwv_flow.LF||
'    p_content';
wwv_flow_imp.g_varchar2_table(75) := '_id  in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_list  varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select image_re';
wwv_flow_imp.g_varchar2_table(76) := 'f_id, body'||wwv_flow.LF||
'          from excm_content '||wwv_flow.LF||
'         where id = p_content_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l_image_';
wwv_flow_imp.g_varchar2_table(77) := 'list := '':''||find_images(c1.body)||'':'';'||wwv_flow.LF||
''||wwv_flow.LF||
'        delete from excm_rte_images'||wwv_flow.LF||
'         where image_re';
wwv_flow_imp.g_varchar2_table(78) := 'f_id = c1.image_ref_id '||wwv_flow.LF||
'           and instr(l_image_list,'':''||unique_filename||'':'') = 0;'||wwv_flow.LF||
'    end lo';
wwv_flow_imp.g_varchar2_table(79) := 'op;'||wwv_flow.LF||
''||wwv_flow.LF||
'    cleanup_old_images;'||wwv_flow.LF||
'end remove_orphan_images;'||wwv_flow.LF||
''||wwv_flow.LF||
'--------------------------------------------';
wwv_flow_imp.g_varchar2_table(80) := '--------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure upload_rte_image ('||wwv_flow.LF||
'    p_file_base64           in  clob,'||wwv_flow.LF||
'    p_filename         ';
wwv_flow_imp.g_varchar2_table(81) := '     in  varchar2,'||wwv_flow.LF||
'    p_mimetype              in  varchar2,'||wwv_flow.LF||
'    p_image_ref_id          in  number ';
wwv_flow_imp.g_varchar2_table(82) := ') '||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_rte_file_types     varchar2(255) := ''jpeg|image/jpeg,jpg|image/jpg,gif|image/gif,png|im';
wwv_flow_imp.g_varchar2_table(83) := 'age/png,webp|image/webp'';'||wwv_flow.LF||
'    l_unique_filename    excm_rte_images.unique_filename%type;'||wwv_flow.LF||
'    l_max_f';
wwv_flow_imp.g_varchar2_table(84) := 'ile_size_mb   pls_integer := 3;'||wwv_flow.LF||
'    l_file               blob;'||wwv_flow.LF||
'    l_url                varchar2(400';
wwv_flow_imp.g_varchar2_table(85) := '0);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- Exceptions'||wwv_flow.LF||
'    e_image_too_large    exception;'||wwv_flow.LF||
'    e_invalid_mime_type  exception;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(86) := 'function remove_debug ('||wwv_flow.LF||
'        p_url        in  varchar2 )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l';
wwv_flow_imp.g_varchar2_table(87) := '_url  varchar2(4000);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_url := regexp_replace(p_url, ''&debug=(YES|LEVEL[1-9])'', ''''';
wwv_flow_imp.g_varchar2_table(88) := ');'||wwv_flow.LF||
'        l_url := regexp_replace(l_url, ''debug=(YES|LEVEL[1-9])&'', '''');'||wwv_flow.LF||
''||wwv_flow.LF||
'        return l_url;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(89) := ' end remove_debug;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- Handles JSON message error handling'||wwv_flow.LF||
'    procedure send_error ('||wwv_flow.LF||
'        p_';
wwv_flow_imp.g_varchar2_table(90) := 'message in varchar2 )'||wwv_flow.LF||
'    as'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        apex_json.open_object;'||wwv_flow.LF||
'        apex_json.open_object(';
wwv_flow_imp.g_varchar2_table(91) := '''error'');'||wwv_flow.LF||
'        apex_json.write(''message'', p_message);'||wwv_flow.LF||
'        apex_json.close_object;'||wwv_flow.LF||
'        ape';
wwv_flow_imp.g_varchar2_table(92) := 'x_json.close_object;'||wwv_flow.LF||
'    end send_error;'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_file := apex_web_service.clobbase642blob(p_fil';
wwv_flow_imp.g_varchar2_table(93) := 'e_base64);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- Validations'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- File not too big'||wwv_flow.LF||
'    if dbms_lob.getlength(l_file) / ( power(';
wwv_flow_imp.g_varchar2_table(94) := '1024, 3) / 1024 ) > l_max_file_size_mb then'||wwv_flow.LF||
'        raise e_image_too_large;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- Val';
wwv_flow_imp.g_varchar2_table(95) := 'id mimetype'||wwv_flow.LF||
'    if instr(l_rte_file_types, ''|'' || lower(p_mimetype), 1) = 0 then'||wwv_flow.LF||
'        raise e_inv';
wwv_flow_imp.g_varchar2_table(96) := 'alid_mime_type;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_unique_filename := dbms_random.string(''a'',8) || ''-'' || substr(dbm';
wwv_flow_imp.g_varchar2_table(97) := 's_random.normal,-4) || ''-'' || dbms_random.string(''a'',8);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into excm_rte_images'||wwv_flow.LF||
'        (f';
wwv_flow_imp.g_varchar2_table(98) := 'ile_blob, unique_filename, filename, mimetype, blob_size, '||wwv_flow.LF||
'         created, created_by, image_ref_i';
wwv_flow_imp.g_varchar2_table(99) := 'd)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (l_file, l_unique_filename, p_filename, p_mimetype, dbms_lob.getlength(l_file)';
wwv_flow_imp.g_varchar2_table(100) := ', '||wwv_flow.LF||
'         sysdate, apex_application.g_user, p_image_ref_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'    apex_json.open_object;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- P';
wwv_flow_imp.g_varchar2_table(101) := '9000: Rejoin Sessions: Enabled for all sessions (where supported)'||wwv_flow.LF||
'    l_url := apex_page.get_url ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(102) := '                p_page => 9000,'||wwv_flow.LF||
'                 p_plain_url => true,'||wwv_flow.LF||
'                 p_x01  => l_u';
wwv_flow_imp.g_varchar2_table(103) := 'nique_filename );'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_url := remove_debug(l_url);'||wwv_flow.LF||
''||wwv_flow.LF||
'    apex_json.write(''url'', l_url);'||wwv_flow.LF||
' '||wwv_flow.LF||
'    apex_';
wwv_flow_imp.g_varchar2_table(104) := 'json.write(''mimetype'', p_mimetype);'||wwv_flow.LF||
'    apex_json.close_object;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'        when e_image_too_';
wwv_flow_imp.g_varchar2_table(105) := 'large then'||wwv_flow.LF||
'            send_error ('||wwv_flow.LF||
'                p_message => apex_string.format('||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(106) := '     p_message  => ''File too large must be less than %0MB'','||wwv_flow.LF||
'                    p0         => l_max_';
wwv_flow_imp.g_varchar2_table(107) := 'file_size_mb'||wwv_flow.LF||
'                )'||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        when e_invalid_mime_type then'||wwv_flow.LF||
'            send';
wwv_flow_imp.g_varchar2_table(108) := '_error(p_message => ''Invalid mimetype'');'||wwv_flow.LF||
'        when others then'||wwv_flow.LF||
'            send_error(p_message =';
wwv_flow_imp.g_varchar2_table(109) := '> ''Could not upload file: '' || sqlerrm );'||wwv_flow.LF||
'end upload_rte_image;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_content ('||wwv_flow.LF||
'    p_cont';
wwv_flow_imp.g_varchar2_table(110) := 'ent       in  clob,'||wwv_flow.LF||
'    p_image_ref_id  in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_content_id      number;'||wwv_flow.LF||
'    l_clob    ';
wwv_flow_imp.g_varchar2_table(111) := '        clob;'||wwv_flow.LF||
'    l_clob_no_images  clob;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_clob := replace_session_on_save(p_content);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(112) := '  l_clob_no_images := replace_images(l_clob);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into excm_content '||wwv_flow.LF||
'        (body, body_no_';
wwv_flow_imp.g_varchar2_table(113) := 'images, image_ref_id)'||wwv_flow.LF||
'    values '||wwv_flow.LF||
'        (l_clob, l_clob_no_images, p_image_ref_id)'||wwv_flow.LF||
'    returning i';
wwv_flow_imp.g_varchar2_table(114) := 'd into l_content_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing cleanup'||wwv_flow.LF||
'    remove_orphan_images (p_content_id => l_';
wwv_flow_imp.g_varchar2_table(115) := 'content_id);'||wwv_flow.LF||
'end add_content;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_content ('||wwv_flow.LF||
'    p_content_id     in  number,'||wwv_flow.LF||
'    p_co';
wwv_flow_imp.g_varchar2_table(116) := 'ntent        in  clob,'||wwv_flow.LF||
'    p_image_ref_id   in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_ref_id      number;'||wwv_flow.LF||
'    l_im';
wwv_flow_imp.g_varchar2_table(117) := 'age_list        varchar2(4000);'||wwv_flow.LF||
'    l_clob              clob;'||wwv_flow.LF||
'    l_clob_no_images    clob;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(118) := '  l_clob := replace_session_on_save(p_content);'||wwv_flow.LF||
'    l_clob_no_images := replace_images(l_clob);'||wwv_flow.LF||
''||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(119) := ' -- returns the existing image_ref_id'||wwv_flow.LF||
'    update excm_content '||wwv_flow.LF||
'       set body = l_clob,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(120) := 'body_no_images = l_clob_no_images'||wwv_flow.LF||
'     where id = p_content_id'||wwv_flow.LF||
'    returning image_ref_id into l_ima';
wwv_flow_imp.g_varchar2_table(121) := 'ge_ref_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_image_list := find_images(l_clob);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- if no images found, no nee';
wwv_flow_imp.g_varchar2_table(122) := 'd to update references'||wwv_flow.LF||
'    if l_image_list is not null then'||wwv_flow.LF||
'        -- updating image_ref_id to matc';
wwv_flow_imp.g_varchar2_table(123) := 'h that of the existing content'||wwv_flow.LF||
'        update excm_rte_images'||wwv_flow.LF||
'           set image_ref_id = l_image_';
wwv_flow_imp.g_varchar2_table(124) := 'ref_id '||wwv_flow.LF||
'         where instr('':''||l_image_list||'':'','':''||unique_filename||'':'') > 0'||wwv_flow.LF||
'           and im';
wwv_flow_imp.g_varchar2_table(125) := 'age_ref_id = p_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing cleanup'||wwv_flow.LF||
'    remove_orphan_images (p_content_i';
wwv_flow_imp.g_varchar2_table(126) := 'd => p_content_id);'||wwv_flow.LF||
'end update_content;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_content ('||wwv_flow.LF||
'    p_content_id    in  number ';
wwv_flow_imp.g_varchar2_table(127) := ')'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_ref_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select image_ref_id'||wwv_flow.LF||
'      into l_image_ref_id'||wwv_flow.LF||
'      from ';
wwv_flow_imp.g_varchar2_table(128) := 'excm_content'||wwv_flow.LF||
'     where id = p_content_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from excm_rte_images'||wwv_flow.LF||
'     where image_ref_id ';
wwv_flow_imp.g_varchar2_table(129) := '= l_image_ref_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from excm_content'||wwv_flow.LF||
'     where id = p_content_id;'||wwv_flow.LF||
'end delete_content;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(130) := 'end excm_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(21046142261491965233)
,p_install_id=>wwv_flow_imp.id(20534763133427939682)
,p_name=>'util body'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
