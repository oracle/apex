prompt --application/deployment/install/install_table_and_column_comments
begin
--   Manifest
--     INSTALL: INSTALL-table and column comments
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9200
,p_default_id_offset=>6233788281304841
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'comment on table EXCM_CONTENT is ''Contains CLOB content for this example app'';'||wwv_flow.LF||
'comment on column EXC';
wwv_flow_imp.g_varchar2_table(2) := 'M_CONTENT.ID is ''System generated unique identifier of the content row'';'||wwv_flow.LF||
'comment on column EXCM_CONT';
wwv_flow_imp.g_varchar2_table(3) := 'ENT.BODY is ''Content entered via the UI'';'||wwv_flow.LF||
'comment on column EXCM_CONTENT.BODY_HTML is ''HTML version ';
wwv_flow_imp.g_varchar2_table(4) := 'of content entered via the UI, used in reports using the Comment template'';'||wwv_flow.LF||
'comment on column EXCM_C';
wwv_flow_imp.g_varchar2_table(5) := 'ONTENT.BODY_NO_IMAGES is ''Content with image references removed, used for emails and reports where i';
wwv_flow_imp.g_varchar2_table(6) := 'mages cannot be displayed'';'||wwv_flow.LF||
'comment on column EXCM_CONTENT.IMAGE_REF_ID is ''System generated unique ';
wwv_flow_imp.g_varchar2_table(7) := 'identifier used to link images within the BODY column to those images within EXCM_RTE_IMAGES'';'||wwv_flow.LF||
'comme';
wwv_flow_imp.g_varchar2_table(8) := 'nt on column EXCM_CONTENT.CREATED is ''Date on which this content was created'';'||wwv_flow.LF||
'comment on column EXC';
wwv_flow_imp.g_varchar2_table(9) := 'M_CONTENT.CREATED_BY is ''Username of user who created the content'';'||wwv_flow.LF||
'comment on column EXCM_CONTENT.U';
wwv_flow_imp.g_varchar2_table(10) := 'PDATED is ''Date on which this content was last updated'';'||wwv_flow.LF||
'comment on column EXCM_CONTENT.UPDATED_BY i';
wwv_flow_imp.g_varchar2_table(11) := 's ''Username of user who last updated the content'';'||wwv_flow.LF||
''||wwv_flow.LF||
'comment on table EXCM_CONTENT_V is ''Contains CLO';
wwv_flow_imp.g_varchar2_table(12) := 'B content for this example app'';'||wwv_flow.LF||
'comment on column EXCM_CONTENT_V.ID is ''System generated unique ide';
wwv_flow_imp.g_varchar2_table(13) := 'ntifier of the content row'';'||wwv_flow.LF||
'comment on column EXCM_CONTENT_V.BODY is ''Content entered via the UI'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(14) := 'comment on column EXCM_CONTENT_V.BODY_HTML is ''HTML version of content entered via the UI, used in r';
wwv_flow_imp.g_varchar2_table(15) := 'eports using the Comment template'';'||wwv_flow.LF||
'comment on column EXCM_CONTENT_V.BODY_NO_IMAGES is ''Content with';
wwv_flow_imp.g_varchar2_table(16) := ' image references removed, used for emails and reports where images cannot be displayed'';'||wwv_flow.LF||
'comment on';
wwv_flow_imp.g_varchar2_table(17) := ' column EXCM_CONTENT_V.IMAGE_REF_ID is ''System generated unique identifier used to link images withi';
wwv_flow_imp.g_varchar2_table(18) := 'n the BODY column to those images within EXCM_RTE_IMAGES'';'||wwv_flow.LF||
'comment on column EXCM_CONTENT_V.CREATED ';
wwv_flow_imp.g_varchar2_table(19) := 'is ''Date on which this content was created'';'||wwv_flow.LF||
'comment on column EXCM_CONTENT_V.CREATED_BY is ''Usernam';
wwv_flow_imp.g_varchar2_table(20) := 'e of user who created the content'';'||wwv_flow.LF||
'comment on column EXCM_CONTENT_V.UPDATED is ''Date on which this ';
wwv_flow_imp.g_varchar2_table(21) := 'content was last updated'';'||wwv_flow.LF||
'comment on column EXCM_CONTENT_V.UPDATED_BY is ''Username of user who last';
wwv_flow_imp.g_varchar2_table(22) := ' updated the content'';'||wwv_flow.LF||
''||wwv_flow.LF||
'comment on table EXCM_RTE_IMAGES is ''All images referenced within EXCM_CONTE';
wwv_flow_imp.g_varchar2_table(23) := 'NT.BODY'';'||wwv_flow.LF||
'comment on column EXCM_RTE_IMAGES.ID is ''System generated unique identifier of the image'';';
wwv_flow_imp.g_varchar2_table(24) := ''||wwv_flow.LF||
'comment on column EXCM_RTE_IMAGES.FILE_BLOB is ''BLOB containing the image'';'||wwv_flow.LF||
'comment on column EXCM_';
wwv_flow_imp.g_varchar2_table(25) := 'RTE_IMAGES.UNIQUE_FILENAME is ''System Generated unique filename, not numeric, that uniquely identifi';
wwv_flow_imp.g_varchar2_table(26) := 'es the image - used to reference the image within EXCM_CONTENT.BODY'';'||wwv_flow.LF||
'comment on column EXCM_RTE_IMA';
wwv_flow_imp.g_varchar2_table(27) := 'GES.FILENAME is ''Actual filename of the image, if a file was dragged in - image.png if the image was';
wwv_flow_imp.g_varchar2_table(28) := ' pasted in.'';'||wwv_flow.LF||
'comment on column EXCM_RTE_IMAGES.MIMETYPE is ''MIME type of the image, needed for disp';
wwv_flow_imp.g_varchar2_table(29) := 'lay'';'||wwv_flow.LF||
'comment on column EXCM_RTE_IMAGES.BLOB_SIZE is ''Size of the image, needed for display'';'||wwv_flow.LF||
'commen';
wwv_flow_imp.g_varchar2_table(30) := 't on column EXCM_RTE_IMAGES.IMAGE_REF_ID is ''System generated unique identifier used to link to EXCM';
wwv_flow_imp.g_varchar2_table(31) := '_RTE_IMAGES.IMAGE_REF_ID to find unreferenced images'';'||wwv_flow.LF||
'comment on column EXCM_RTE_IMAGES.CREATED is ';
wwv_flow_imp.g_varchar2_table(32) := '''Date on which this image was uploaded'';'||wwv_flow.LF||
'comment on column EXCM_RTE_IMAGES.CREATED_BY is ''Username o';
wwv_flow_imp.g_varchar2_table(33) := 'f user who uploaded the image'';';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(23908495240325273209)
,p_install_id=>wwv_flow_imp.id(20534763133427939682)
,p_name=>'table and column comments'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
