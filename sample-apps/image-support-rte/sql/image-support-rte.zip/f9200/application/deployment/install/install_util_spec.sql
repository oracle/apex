prompt --application/deployment/install/install_util_spec
begin
--   Manifest
--     INSTALL: INSTALL-util spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9200
,p_default_id_offset=>6233788281304841
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package excm_util  '||wwv_flow.LF||
'as  '||wwv_flow.LF||
''||wwv_flow.LF||
'-- used in EXCM_CONTENT_V to replace the session placeho';
wwv_flow_imp.g_varchar2_table(2) := 'lder, if it exists, with the current user''s session id'||wwv_flow.LF||
'function replace_session_on_display ('||wwv_flow.LF||
'    p_b';
wwv_flow_imp.g_varchar2_table(3) := 'ody        in  clob,'||wwv_flow.LF||
'    p_session_id  in  number )'||wwv_flow.LF||
'    return clob;'||wwv_flow.LF||
' '||wwv_flow.LF||
'-- used by the application-le';
wwv_flow_imp.g_varchar2_table(4) := 'vel POST_IMAGE process to upload the image and return (via apex_json.write) a url to display it'||wwv_flow.LF||
'proc';
wwv_flow_imp.g_varchar2_table(5) := 'edure upload_rte_image (  '||wwv_flow.LF||
'    p_file_base64      in  clob,  '||wwv_flow.LF||
'    p_filename         in  varchar2,  ';
wwv_flow_imp.g_varchar2_table(6) := ''||wwv_flow.LF||
'    p_mimetype         in  varchar2,  '||wwv_flow.LF||
'    p_image_ref_id     in  number ) ;  '||wwv_flow.LF||
'  '||wwv_flow.LF||
'procedure add_con';
wwv_flow_imp.g_varchar2_table(7) := 'tent (  '||wwv_flow.LF||
'    p_content          in  clob,  '||wwv_flow.LF||
'    p_image_ref_id     in  number );  '||wwv_flow.LF||
'  '||wwv_flow.LF||
'procedure upda';
wwv_flow_imp.g_varchar2_table(8) := 'te_content (  '||wwv_flow.LF||
'    p_content_id       in  number,  '||wwv_flow.LF||
'    p_content          in  clob,  '||wwv_flow.LF||
'    p_image_r';
wwv_flow_imp.g_varchar2_table(9) := 'ef_id     in  number );  '||wwv_flow.LF||
'  '||wwv_flow.LF||
'procedure delete_content (  '||wwv_flow.LF||
'    p_content_id       in  number );    '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
'end excm_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(21046291572501718287)
,p_install_id=>wwv_flow_imp.id(20534763133427939682)
,p_name=>'util spec'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
