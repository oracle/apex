prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 9200
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9200
,p_default_id_offset=>6233788281304841
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop package excm_util;'||wwv_flow.LF||
'drop view excm_content_v;'||wwv_flow.LF||
'drop table excm_content;'||wwv_flow.LF||
'drop table excm_rte_image';
wwv_flow_imp.g_varchar2_table(2) := 's;';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(20534763133427939682)
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'EXCM_CONTENT:EXCM_RTE_IMAGES:EXCM_UTIL'
);
wwv_flow_imp.component_end;
end;
/
