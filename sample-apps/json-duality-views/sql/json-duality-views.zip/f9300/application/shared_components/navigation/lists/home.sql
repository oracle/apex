prompt --application/shared_components/navigation/lists/home
begin
--   Manifest
--     LIST: Home
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9300
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(6861230487627790390)
,p_name=>'Home'
,p_static_id=>'home'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6861230544363790391)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'About JSON Relational Duality Views'
,p_static_id=>'about-duality-view'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-info-circle'
,p_list_text_01=>'Review the JSON Relational Duality View DDL, generated JSON schema, and sample JSON document shape used by the app.'
,p_translate_list_text_y_n=>'Y'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6861230651258790394)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Purchase Orders Inbox'
,p_static_id=>'purchase-orders-inbox'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-inbox'
,p_list_text_01=>'Explore the email-style parent and child pattern with purchase orders in the left sidebar and details on the right.'
,p_translate_list_text_y_n=>'Y'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6861230746608790394)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Purchase Orders Report'
,p_static_id=>'purchase-orders-stacked'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>'Use the vertical parent and child pattern with the purchase order parent above nested line items.'
,p_translate_list_text_y_n=>'Y'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
