prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9300
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(5528715858987777183)
,p_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6865567727434347162)
,p_short_name=>'About JSON Relational Duality Views'
,p_static_id=>'about-duality-views'
,p_link=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5528901981995439294)
,p_short_name=>'Purchase Orders Report'
,p_static_id=>'my-purchase-orders'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.'
,p_page_id=>10
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5528851442207813059)
,p_parent_id=>wwv_flow_imp.id(5528901981995439294)
,p_short_name=>'Purchase Order #&P6_PO_NUMBER.'
,p_static_id=>'purchase-order-amp-p6-po-id-details'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6859843606401186107)
,p_short_name=>'Purchase Orders Inbox'
,p_static_id=>'purchase-orders-inbox'
,p_link=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.'
,p_page_id=>20
);
wwv_flow_imp.component_end;
end;
/
