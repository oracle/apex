prompt --application/deployment/buildoptions
begin
--   Manifest
--     INSTALL BUILD OPTIONS: 9300
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9300
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
