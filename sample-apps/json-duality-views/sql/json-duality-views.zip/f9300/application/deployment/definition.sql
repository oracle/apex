prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 9300
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9300
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop table if exists dv_customers cascade constraints;'||wwv_flow.LF||
'drop table if exists dv_purchase_orders casca';
wwv_flow_imp.g_varchar2_table(2) := 'de constraints;'||wwv_flow.LF||
'drop table if exists dv_products cascade constraints;'||wwv_flow.LF||
'drop table if exists dv_po_lin';
wwv_flow_imp.g_varchar2_table(3) := 'e_items cascade constraints;'||wwv_flow.LF||
'drop trigger if exists trg_dv_po_number;'||wwv_flow.LF||
'drop trigger if exists trg_dv_';
wwv_flow_imp.g_varchar2_table(4) := 'po_line_items;'||wwv_flow.LF||
'drop sequence if exists dv_po_number_seq;'||wwv_flow.LF||
'drop view if exists dv_purchase_order_dv;';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(5528902706493450773)
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
