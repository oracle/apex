prompt --application/deployment/install/install_insert_data
begin
--   Manifest
--     INSTALL: INSTALL-Insert Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9300
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- CUSTOMER DATA'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, C';
wwv_flow_imp.g_varchar2_table(2) := 'ITY, STATE, ZIP_CODE) VALUES (1003, ''Linda Green'', ''Green Autos'', ''517-367-7021'', ''linda.green@green';
wwv_flow_imp.g_varchar2_table(3) := 'cars.com'', ''4782 West End Ave'', ''Lansing'', ''MI'', ''48906'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NA';
wwv_flow_imp.g_varchar2_table(4) := 'ME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1004, ''Henry Miller'', ''Mille';
wwv_flow_imp.g_varchar2_table(5) := 'r Motors'', ''517-367-7222'', ''h.miller@millermotors.com'', ''5201 Eastport Rd'', ''Grand Rapids'', ''MI'', ''4';
wwv_flow_imp.g_varchar2_table(6) := '9503'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STAT';
wwv_flow_imp.g_varchar2_table(7) := 'E, ZIP_CODE) VALUES (1005, ''Sandra Lee'', ''Lee Engineering'', ''517-367-7311'', ''sandra.lee@leeeng.com'',';
wwv_flow_imp.g_varchar2_table(8) := ' ''153 Maple Ave'', ''Ann Arbor'', ''MI'', ''48103'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_';
wwv_flow_imp.g_varchar2_table(9) := 'NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1006, ''James Wilson'', ''Wilco Parts'', ''51';
wwv_flow_imp.g_varchar2_table(10) := '7-379-1101'', ''jwilson@wilcoparts.com'', ''818 Oak St'', ''Jackson'', ''MI'', ''49201'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTO';
wwv_flow_imp.g_varchar2_table(11) := 'MERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1007, ''';
wwv_flow_imp.g_varchar2_table(12) := 'Jennifer Fox'', ''Fox Fasteners'', ''517-367-7333'', ''jfox@foxf.com'', ''234 Grand Ave'', ''Kalamazoo'', ''MI'',';
wwv_flow_imp.g_varchar2_table(13) := ' ''49001'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, S';
wwv_flow_imp.g_varchar2_table(14) := 'TATE, ZIP_CODE) VALUES (1008, ''Michael Kim'', ''Kim Car Care'', ''517-379-1155'', ''mkim@kimcare.com'', ''94';
wwv_flow_imp.g_varchar2_table(15) := '1 Central Pkwy'', ''Battle Creek'', ''MI'', ''49015'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPAN';
wwv_flow_imp.g_varchar2_table(16) := 'Y_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1009, ''Patricia Bennett'', ''Bennett Rep';
wwv_flow_imp.g_varchar2_table(17) := 'air'', ''517-367-7444'', ''pbennett@bennettrepair.com'', ''1120 N Main St'', ''Holland'', ''MI'', ''49423'');'||wwv_flow.LF||
'INS';
wwv_flow_imp.g_varchar2_table(18) := 'ERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE';
wwv_flow_imp.g_varchar2_table(19) := ') VALUES (1010, ''Steven Carter'', ''Carter Service'', ''517-367-7555'', ''scarter@cartersvc.com'', ''2999 In';
wwv_flow_imp.g_varchar2_table(20) := 'dustrial Dr'', ''Muskegon'', ''MI'', ''49442'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME,';
wwv_flow_imp.g_varchar2_table(21) := ' PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1011, ''Emily Davis'', ''Davis Automotive'', ''517';
wwv_flow_imp.g_varchar2_table(22) := '-367-7666'', ''emily@davisauth.com'', ''1021 S Wheeler Rd'', ''Saginaw'', ''MI'', ''48609'');'||wwv_flow.LF||
'INSERT INTO DV_CU';
wwv_flow_imp.g_varchar2_table(23) := 'STOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1012';
wwv_flow_imp.g_varchar2_table(24) := ', ''William Clark'', ''Clark Parts'', ''517-379-1212'', ''william@clarkparts.com'', ''1689 River Rd'', ''Bay Ci';
wwv_flow_imp.g_varchar2_table(25) := 'ty'', ''MI'', ''48706'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRES';
wwv_flow_imp.g_varchar2_table(26) := 'S, CITY, STATE, ZIP_CODE) VALUES (1013, ''Olivia Turner'', ''Turner Supplies'', ''517-367-7777'', ''oliviat';
wwv_flow_imp.g_varchar2_table(27) := '@turnersup.com'', ''9005 N Cedar St'', ''Flint'', ''MI'', ''48505'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, ';
wwv_flow_imp.g_varchar2_table(28) := 'NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1014, ''Matthew Evans'', ''Ev';
wwv_flow_imp.g_varchar2_table(29) := 'ans Group'', ''517-367-7888'', ''mevans@evansgroup.com'', ''4222 Westburton Ave'', ''Warren'', ''MI'', ''48091'')';
wwv_flow_imp.g_varchar2_table(30) := ';'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP';
wwv_flow_imp.g_varchar2_table(31) := '_CODE) VALUES (1015, ''Sophia Harris'', ''Harris Fleet'', ''517-367-7999'', ''sophia@harrisfleet.com'', ''303';
wwv_flow_imp.g_varchar2_table(32) := ' Congress St'', ''Sterling Heights'', ''MI'', ''48310'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMP';
wwv_flow_imp.g_varchar2_table(33) := 'ANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1016, ''Benjamin Scott'', ''Scott Heavy';
wwv_flow_imp.g_varchar2_table(34) := ' Duty'', ''517-367-8001'', ''ben.scott@shd.com'', ''8822 Remington Dr'', ''Livonia'', ''MI'', ''48150'');'||wwv_flow.LF||
'INSERT ';
wwv_flow_imp.g_varchar2_table(35) := 'INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VA';
wwv_flow_imp.g_varchar2_table(36) := 'LUES (1017, ''Ava Walker'', ''Walker Imports'', ''517-367-8111'', ''avawalker@walkerimports.com'', ''1130 S F';
wwv_flow_imp.g_varchar2_table(37) := 'ieldstone Ct'', ''Troy'', ''MI'', ''48083'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PH';
wwv_flow_imp.g_varchar2_table(38) := 'ONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1018, ''Logan Nelson'', ''Nelson Autoworks'', ''517-3';
wwv_flow_imp.g_varchar2_table(39) := '67-8222'', ''logan@nelsonautoworks.com'', ''2508 Sunset Blvd'', ''Rochester Hills'', ''MI'', ''48309'');'||wwv_flow.LF||
'INSERT';
wwv_flow_imp.g_varchar2_table(40) := ' INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) V';
wwv_flow_imp.g_varchar2_table(41) := 'ALUES (1019, ''Chloe Baker'', ''Baker Garage'', ''517-367-8333'', ''chloeb@bakergrg.com'', ''7413 Warner Rd'',';
wwv_flow_imp.g_varchar2_table(42) := ' ''Southfield'', ''MI'', ''48076'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMA';
wwv_flow_imp.g_varchar2_table(43) := 'IL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1020, ''David Hall'', ''Hall Mechanics'', ''517-367-8444'', ''d';
wwv_flow_imp.g_varchar2_table(44) := 'hall@hallmech.com'', ''1677 Bartlett St'', ''Farmington Hills'', ''MI'', ''48334'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS';
wwv_flow_imp.g_varchar2_table(45) := ' (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1021, ''Grac';
wwv_flow_imp.g_varchar2_table(46) := 'e Adams'', ''Adams Supplies'', ''517-367-8555'', ''grace@adamssup.com'', ''4115 Sherwood Ln'', ''Westland'', ''M';
wwv_flow_imp.g_varchar2_table(47) := 'I'', ''48185'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY';
wwv_flow_imp.g_varchar2_table(48) := ', STATE, ZIP_CODE) VALUES (1022, ''Jackson Perez'', ''Perez Automotive'', ''517-367-8666'', ''jperez@pereza';
wwv_flow_imp.g_varchar2_table(49) := 'uto.com'', ''8799 Candlewood Dr'', ''Novi'', ''MI'', ''48375'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME,';
wwv_flow_imp.g_varchar2_table(50) := ' COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1023, ''Ella Moore'', ''Moore Car ';
wwv_flow_imp.g_varchar2_table(51) := 'Parts'', ''517-367-8777'', ''emoore@moorecar.com'', ''2721 Glenwood Ave'', ''Dearborn'', ''MI'', ''48126'');'||wwv_flow.LF||
'INSE';
wwv_flow_imp.g_varchar2_table(52) := 'RT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE)';
wwv_flow_imp.g_varchar2_table(53) := ' VALUES (1024, ''Mason Martinez'', ''Martinez Autos'', ''517-367-8888'', ''mason@martinezauto.com'', ''1101 C';
wwv_flow_imp.g_varchar2_table(54) := 'restview Rd'', ''Wyoming'', ''MI'', ''49509'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, ';
wwv_flow_imp.g_varchar2_table(55) := 'PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1025, ''Lily Taylor'', ''Taylor Performance'', ''51';
wwv_flow_imp.g_varchar2_table(56) := '7-367-8999'', ''lilyt@tayperf.com'', ''661 College Park Dr'', ''Midland'', ''MI'', ''48640'');'||wwv_flow.LF||
'INSERT INTO DV_C';
wwv_flow_imp.g_varchar2_table(57) := 'USTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (102';
wwv_flow_imp.g_varchar2_table(58) := '6, ''Lucas Thomas'', ''Thomas Electronics'', ''517-367-9001'', ''lucast@tomelectro.com'', ''1584 Meadowbrook ';
wwv_flow_imp.g_varchar2_table(59) := 'Rd'', ''Ypsilanti'', ''MI'', ''48197'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, ';
wwv_flow_imp.g_varchar2_table(60) := 'EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1027, ''Zoe Anderson'', ''Anderson Motor Co.'', ''517-367-';
wwv_flow_imp.g_varchar2_table(61) := '9111'', ''zoea@andersonmotor.com'', ''4024 Apple Ridge Dr'', ''Sylvania'', ''OH'', ''43560'');'||wwv_flow.LF||
'INSERT INTO DV_C';
wwv_flow_imp.g_varchar2_table(62) := 'USTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (102';
wwv_flow_imp.g_varchar2_table(63) := '8, ''Daniel Lee'', ''Lee Speed Shop'', ''517-367-9222'', ''daniel@leespeed.com'', ''8201 W Morrow Rd'', ''Toled';
wwv_flow_imp.g_varchar2_table(64) := 'o'', ''OH'', ''43615'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS';
wwv_flow_imp.g_varchar2_table(65) := ', CITY, STATE, ZIP_CODE) VALUES (1029, ''Victoria White'', ''White Auto Mall'', ''517-367-9333'', ''victori';
wwv_flow_imp.g_varchar2_table(66) := 'a@whiteauto.com'', ''5532 Eastland Dr'', ''Sandusky'', ''OH'', ''44870'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER';
wwv_flow_imp.g_varchar2_table(67) := '_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CITY, STATE, ZIP_CODE) VALUES (1030, ''Carter Lewis'',';
wwv_flow_imp.g_varchar2_table(68) := ' ''Lewis Car Solutions'', ''517-367-9444'', ''clewis@lewiscar.com'', ''900 Landing Blvd'', ''Bowling Green'', ';
wwv_flow_imp.g_varchar2_table(69) := '''OH'', ''43402'');'||wwv_flow.LF||
'INSERT INTO DV_CUSTOMERS (CUSTOMER_ID, NAME, COMPANY_NAME, PHONE, EMAIL, ADDRESS, CI';
wwv_flow_imp.g_varchar2_table(70) := 'TY, STATE, ZIP_CODE) VALUES (1031, ''Scarlett Young'', ''Young Supplies'', ''517-367-9555'', ''scarlett@you';
wwv_flow_imp.g_varchar2_table(71) := 'ngsupplies.com'', ''1875 Greenleaf Ct'', ''Findlay'', ''OH'', ''45840'');'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PRODUCTS DATA'||wwv_flow.LF||
'INSERT INTO DV_PR';
wwv_flow_imp.g_varchar2_table(72) := 'ODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3011, ''154-32691'', ''Spark Plug'', ';
wwv_flow_imp.g_varchar2_table(73) := '4.95);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3012, ''87';
wwv_flow_imp.g_varchar2_table(74) := '2-33410'', ''Fuel Injector'', 56.40);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, U';
wwv_flow_imp.g_varchar2_table(75) := 'NIT_PRICE) VALUES (3013, ''561-49200'', ''Alternator'', 154.60);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PR';
wwv_flow_imp.g_varchar2_table(76) := 'ODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3014, ''305-34520'', ''Radiator'', 134.20);'||wwv_flow.LF||
'INSERT INTO DV_';
wwv_flow_imp.g_varchar2_table(77) := 'PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3015, ''703-92034'', ''Oil Filter''';
wwv_flow_imp.g_varchar2_table(78) := ', 7.80);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3016, ''';
wwv_flow_imp.g_varchar2_table(79) := '198-56210'', ''Air Filter'', 14.35);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UN';
wwv_flow_imp.g_varchar2_table(80) := 'IT_PRICE) VALUES (3017, ''543-12987'', ''Timing Belt'', 37.50);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRO';
wwv_flow_imp.g_varchar2_table(81) := 'DUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3018, ''238-90876'', ''Water Pump'', 84.99);'||wwv_flow.LF||
'INSERT INTO DV_';
wwv_flow_imp.g_varchar2_table(82) := 'PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3019, ''954-63811'', ''Clutch Kit''';
wwv_flow_imp.g_varchar2_table(83) := ', 132.75);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3020,';
wwv_flow_imp.g_varchar2_table(84) := ' ''687-70547'', ''Ignition Coil'', 44.80);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTIO';
wwv_flow_imp.g_varchar2_table(85) := 'N, UNIT_PRICE) VALUES (3021, ''206-98412'', ''Wheel Bearing'', 36.65);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_';
wwv_flow_imp.g_varchar2_table(86) := 'ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3022, ''410-58327'', ''Shock Absorber'', 55.40);'||wwv_flow.LF||
'INSE';
wwv_flow_imp.g_varchar2_table(87) := 'RT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3023, ''329-28465'', ''';
wwv_flow_imp.g_varchar2_table(88) := 'Brake Rotor'', 63.20);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VA';
wwv_flow_imp.g_varchar2_table(89) := 'LUES (3024, ''677-52891'', ''Muffler'', 109.99);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESC';
wwv_flow_imp.g_varchar2_table(90) := 'RIPTION, UNIT_PRICE) VALUES (3025, ''788-92105'', ''Catalytic Converter'', 199.87);'||wwv_flow.LF||
'INSERT INTO DV_PRODU';
wwv_flow_imp.g_varchar2_table(91) := 'CTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3026, ''380-45012'', ''Power Steering P';
wwv_flow_imp.g_varchar2_table(92) := 'ump'', 127.30);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3';
wwv_flow_imp.g_varchar2_table(93) := '027, ''567-48120'', ''Transmission Mount'', 38.90);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, D';
wwv_flow_imp.g_varchar2_table(94) := 'ESCRIPTION, UNIT_PRICE) VALUES (3028, ''228-67501'', ''Battery'', 89.99);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODU';
wwv_flow_imp.g_varchar2_table(95) := 'CT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3029, ''679-11922'', ''Radiator Cap'', 8.75);'||wwv_flow.LF||
'INSE';
wwv_flow_imp.g_varchar2_table(96) := 'RT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3030, ''110-27450'', ''';
wwv_flow_imp.g_varchar2_table(97) := 'Wiper Blade'', 13.30);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VA';
wwv_flow_imp.g_varchar2_table(98) := 'LUES (3031, ''285-19736'', ''CV Joint'', 53.60);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESC';
wwv_flow_imp.g_varchar2_table(99) := 'RIPTION, UNIT_PRICE) VALUES (3032, ''134-29417'', ''Tie Rod End'', 22.99);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PROD';
wwv_flow_imp.g_varchar2_table(100) := 'UCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3033, ''472-11503'', ''Ball Joint'', 29.75);'||wwv_flow.LF||
'INSE';
wwv_flow_imp.g_varchar2_table(101) := 'RT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3034, ''659-39041'', ''';
wwv_flow_imp.g_varchar2_table(102) := 'Thermostat'', 18.20);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VAL';
wwv_flow_imp.g_varchar2_table(103) := 'UES (3035, ''372-99083'', ''Headlight Bulb'', 9.45);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, ';
wwv_flow_imp.g_varchar2_table(104) := 'DESCRIPTION, UNIT_PRICE) VALUES (3036, ''457-51278'', ''Tail Light'', 36.10);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (P';
wwv_flow_imp.g_varchar2_table(105) := 'RODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3037, ''647-39918'', ''Fog Light'', 28.35);'||wwv_flow.LF||
'IN';
wwv_flow_imp.g_varchar2_table(106) := 'SERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3038, ''749-12804'',';
wwv_flow_imp.g_varchar2_table(107) := ' ''AC Compressor'', 178.90);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRIC';
wwv_flow_imp.g_varchar2_table(108) := 'E) VALUES (3039, ''200-98517'', ''Heater Core'', 79.40);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CO';
wwv_flow_imp.g_varchar2_table(109) := 'DE, DESCRIPTION, UNIT_PRICE) VALUES (3040, ''315-98264'', ''Blower Motor'', 49.25);'||wwv_flow.LF||
'INSERT INTO DV_PRODU';
wwv_flow_imp.g_varchar2_table(110) := 'CTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3041, ''917-63280'', ''Window Regulator';
wwv_flow_imp.g_varchar2_table(111) := ''', 59.10);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3042,';
wwv_flow_imp.g_varchar2_table(112) := ' ''851-97013'', ''Fuel Tank'', 178.75);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, ';
wwv_flow_imp.g_varchar2_table(113) := 'UNIT_PRICE) VALUES (3043, ''422-66105'', ''Oxygen Sensor'', 41.18);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID,';
wwv_flow_imp.g_varchar2_table(114) := ' PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3044, ''794-52278'', ''Throttle Body'', 154.60);'||wwv_flow.LF||
'INSERT ';
wwv_flow_imp.g_varchar2_table(115) := 'INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3045, ''326-74061'', ''Mas';
wwv_flow_imp.g_varchar2_table(116) := 's Air Flow Sensor'', 129.40);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PR';
wwv_flow_imp.g_varchar2_table(117) := 'ICE) VALUES (3046, ''530-90227'', ''Crankshaft Position Sensor'', 38.50);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODU';
wwv_flow_imp.g_varchar2_table(118) := 'CT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3047, ''673-81239'', ''Camshaft Position Sensor'',';
wwv_flow_imp.g_varchar2_table(119) := ' 33.99);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3048, ''';
wwv_flow_imp.g_varchar2_table(120) := '945-81040'', ''Engine Mount'', 47.65);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, ';
wwv_flow_imp.g_varchar2_table(121) := 'UNIT_PRICE) VALUES (3049, ''823-11504'', ''Door Handle'', 25.57);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, P';
wwv_flow_imp.g_varchar2_table(122) := 'RODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3050, ''347-33320'', ''Window Switch'', 39.90);'||wwv_flow.LF||
'INSERT INT';
wwv_flow_imp.g_varchar2_table(123) := 'O DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3051, ''422-37140'', ''Hood L';
wwv_flow_imp.g_varchar2_table(124) := 'atch'', 18.99);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3';
wwv_flow_imp.g_varchar2_table(125) := '052, ''423-64920'', ''Trunk Lock'', 22.20);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTI';
wwv_flow_imp.g_varchar2_table(126) := 'ON, UNIT_PRICE) VALUES (3053, ''610-23855'', ''Rear View Mirror'', 29.10);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PROD';
wwv_flow_imp.g_varchar2_table(127) := 'UCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3054, ''279-47855'', ''Side Mirror'', 54.66);'||wwv_flow.LF||
'INS';
wwv_flow_imp.g_varchar2_table(128) := 'ERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3055, ''287-91542'', ';
wwv_flow_imp.g_varchar2_table(129) := '''Sun Visor'', 16.78);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VAL';
wwv_flow_imp.g_varchar2_table(130) := 'UES (3056, ''504-15784'', ''Seat Belt'', 35.50);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESC';
wwv_flow_imp.g_varchar2_table(131) := 'RIPTION, UNIT_PRICE) VALUES (3057, ''212-47290'', ''Dashboard'', 219.22);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODU';
wwv_flow_imp.g_varchar2_table(132) := 'CT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3058, ''173-79425'', ''Glove Box'', 44.75);'||wwv_flow.LF||
'INSERT';
wwv_flow_imp.g_varchar2_table(133) := ' INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3059, ''188-48394'', ''Ge';
wwv_flow_imp.g_varchar2_table(134) := 'ar Shift Knob'', 17.69);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) ';
wwv_flow_imp.g_varchar2_table(135) := 'VALUES (3060, ''165-70543'', ''Steering Wheel'', 94.50);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CO';
wwv_flow_imp.g_varchar2_table(136) := 'DE, DESCRIPTION, UNIT_PRICE) VALUES (3061, ''584-42051'', ''Speaker'', 33.49);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (';
wwv_flow_imp.g_varchar2_table(137) := 'PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3062, ''485-18411'', ''Radio'', 74.60);'||wwv_flow.LF||
'INSER';
wwv_flow_imp.g_varchar2_table(138) := 'T INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3063, ''785-12721'', ''A';
wwv_flow_imp.g_varchar2_table(139) := 'ntenna'', 13.80);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES ';
wwv_flow_imp.g_varchar2_table(140) := '(3064, ''634-21157'', ''Grille'', 54.19);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION';
wwv_flow_imp.g_varchar2_table(141) := ', UNIT_PRICE) VALUES (3065, ''548-32019'', ''Bumper'', 159.99);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRO';
wwv_flow_imp.g_varchar2_table(142) := 'DUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3066, ''437-78461'', ''Fender'', 139.50);'||wwv_flow.LF||
'INSERT INTO DV_PRO';
wwv_flow_imp.g_varchar2_table(143) := 'DUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3067, ''816-29547'', ''Hood'', 174.95)';
wwv_flow_imp.g_varchar2_table(144) := ';'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3068, ''497-814';
wwv_flow_imp.g_varchar2_table(145) := '58'', ''Trunk Lid'', 167.75);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRIC';
wwv_flow_imp.g_varchar2_table(146) := 'E) VALUES (3069, ''721-36917'', ''Quarter Panel'', 188.60);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT';
wwv_flow_imp.g_varchar2_table(147) := '_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3070, ''325-19428'', ''Roof Panel'', 234.20);'||wwv_flow.LF||
'INSERT INTO DV_PRO';
wwv_flow_imp.g_varchar2_table(148) := 'DUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3071, ''625-79348'', ''Door Panel'', 1';
wwv_flow_imp.g_varchar2_table(149) := '13.35);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3072, ''2';
wwv_flow_imp.g_varchar2_table(150) := '03-79432'', ''Tailgate'', 149.80);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT';
wwv_flow_imp.g_varchar2_table(151) := '_PRICE) VALUES (3073, ''110-39475'', ''Floor Mat'', 24.40);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT';
wwv_flow_imp.g_varchar2_table(152) := '_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3074, ''645-59320'', ''Seat Cushion'', 64.75);'||wwv_flow.LF||
'INSERT INTO DV_PR';
wwv_flow_imp.g_varchar2_table(153) := 'ODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3075, ''774-22042'', ''Headrest'', 19';
wwv_flow_imp.g_varchar2_table(154) := '.45);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3076, ''308';
wwv_flow_imp.g_varchar2_table(155) := '-79913'', ''Carpet'', 87.85);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRIC';
wwv_flow_imp.g_varchar2_table(156) := 'E) VALUES (3077, ''250-59062'', ''Accelerator Pedal'', 26.34);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PROD';
wwv_flow_imp.g_varchar2_table(157) := 'UCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3078, ''482-96213'', ''Brake Pedal'', 27.83);'||wwv_flow.LF||
'INSERT INTO DV_';
wwv_flow_imp.g_varchar2_table(158) := 'PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3079, ''368-12354'', ''Clutch Peda';
wwv_flow_imp.g_varchar2_table(159) := 'l'', 29.18);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3080';
wwv_flow_imp.g_varchar2_table(160) := ', ''576-31462'', ''Gas Cap'', 8.22);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNI';
wwv_flow_imp.g_varchar2_table(161) := 'T_PRICE) VALUES (3081, ''149-33800'', ''License Plate Frame'', 6.99);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_I';
wwv_flow_imp.g_varchar2_table(162) := 'D, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3082, ''533-50231'', ''Alternator Belt'', 13.50);'||wwv_flow.LF||
'INSE';
wwv_flow_imp.g_varchar2_table(163) := 'RT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3083, ''411-81514'', ''';
wwv_flow_imp.g_varchar2_table(164) := 'Fan Clutch'', 41.10);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VAL';
wwv_flow_imp.g_varchar2_table(165) := 'UES (3084, ''277-48143'', ''Blower Motor Resistor'', 21.45);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUC';
wwv_flow_imp.g_varchar2_table(166) := 'T_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3085, ''214-32013'', ''EGR Valve'', 54.25);'||wwv_flow.LF||
'INSERT INTO DV_PROD';
wwv_flow_imp.g_varchar2_table(167) := 'UCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3086, ''458-41980'', ''Idle Air Contro';
wwv_flow_imp.g_varchar2_table(168) := 'l Valve'', 37.95);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES';
wwv_flow_imp.g_varchar2_table(169) := ' (3087, ''622-40952'', ''PCV Valve'', 9.98);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPT';
wwv_flow_imp.g_varchar2_table(170) := 'ION, UNIT_PRICE) VALUES (3088, ''353-52156'', ''Drive Shaft'', 104.90);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT';
wwv_flow_imp.g_varchar2_table(171) := '_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3089, ''174-28512'', ''Axle Shaft'', 98.45);'||wwv_flow.LF||
'INSERT ';
wwv_flow_imp.g_varchar2_table(172) := 'INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3090, ''938-40174'', ''Dif';
wwv_flow_imp.g_varchar2_table(173) := 'ferential'', 295.87);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VAL';
wwv_flow_imp.g_varchar2_table(174) := 'UES (3091, ''285-62409'', ''Transfer Case'', 385.60);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE,';
wwv_flow_imp.g_varchar2_table(175) := ' DESCRIPTION, UNIT_PRICE) VALUES (3092, ''525-18237'', ''Transmission Pan'', 43.28);'||wwv_flow.LF||
'INSERT INTO DV_PROD';
wwv_flow_imp.g_varchar2_table(176) := 'UCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3093, ''281-46935'', ''Valve Cover'', 6';
wwv_flow_imp.g_varchar2_table(177) := '6.17);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3094, ''34';
wwv_flow_imp.g_varchar2_table(178) := '0-29861'', ''Flywheel'', 179.90);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_';
wwv_flow_imp.g_varchar2_table(179) := 'PRICE) VALUES (3095, ''494-57311'', ''Starter Motor'', 87.90);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PROD';
wwv_flow_imp.g_varchar2_table(180) := 'UCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3096, ''204-49251'', ''Serpentine Belt'', 17.35);'||wwv_flow.LF||
'INSERT INTO';
wwv_flow_imp.g_varchar2_table(181) := ' DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3097, ''581-02249'', ''Timing ';
wwv_flow_imp.g_varchar2_table(182) := 'Chain'', 48.45);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (';
wwv_flow_imp.g_varchar2_table(183) := '3098, ''195-15832'', ''Piston'', 34.14);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION,';
wwv_flow_imp.g_varchar2_table(184) := ' UNIT_PRICE) VALUES (3099, ''310-83197'', ''Engine Oil Pan'', 89.48);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_I';
wwv_flow_imp.g_varchar2_table(185) := 'D, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3100, ''476-21938'', ''Fuel Rail'', 61.59);'||wwv_flow.LF||
'INSERT INT';
wwv_flow_imp.g_varchar2_table(186) := 'O DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3101, ''220-56937'', ''Intake';
wwv_flow_imp.g_varchar2_table(187) := ' Manifold'', 115.30);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VAL';
wwv_flow_imp.g_varchar2_table(188) := 'UES (3102, ''752-49016'', ''Exhaust Manifold'', 129.75);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CO';
wwv_flow_imp.g_varchar2_table(189) := 'DE, DESCRIPTION, UNIT_PRICE) VALUES (3103, ''364-87362'', ''Turbocharger'', 476.19);'||wwv_flow.LF||
'INSERT INTO DV_PROD';
wwv_flow_imp.g_varchar2_table(190) := 'UCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3104, ''857-32146'', ''Supercharger'', ';
wwv_flow_imp.g_varchar2_table(191) := '560.70);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3105, ''';
wwv_flow_imp.g_varchar2_table(192) := '352-41278'', ''Intercooler'', 132.12);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, ';
wwv_flow_imp.g_varchar2_table(193) := 'UNIT_PRICE) VALUES (3106, ''400-51432'', ''Radiator Fan'', 64.50);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, ';
wwv_flow_imp.g_varchar2_table(194) := 'PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3107, ''172-45819'', ''Coolant Reservoir'', 32.29);'||wwv_flow.LF||
'INSER';
wwv_flow_imp.g_varchar2_table(195) := 'T INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VALUES (3108, ''315-41590'', ''H';
wwv_flow_imp.g_varchar2_table(196) := 'eater Hose'', 11.63);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_CODE, DESCRIPTION, UNIT_PRICE) VAL';
wwv_flow_imp.g_varchar2_table(197) := 'UES (3109, ''241-16989'', ''Transmission Cooler'', 81.19);'||wwv_flow.LF||
'INSERT INTO DV_PRODUCTS (PRODUCT_ID, PRODUCT_';
wwv_flow_imp.g_varchar2_table(198) := 'CODE, DESCRIPTION, UNIT_PRICE) VALUES (3110, ''123-49851'', ''Front Axle'', 205.44);'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PURCHASE ORDER ';
wwv_flow_imp.g_varchar2_table(199) := 'DOCUMENT DATA'||wwv_flow.LF||
'-- Products and standalone customers are reference data above. Purchase orders and the';
wwv_flow_imp.g_varchar2_table(200) := 'ir nested line items are seeded through the JSON Relational Duality View API.'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2002'||wwv_flow.LF||
'INSERT ';
wwv_flow_imp.g_varchar2_table(201) := 'INTO DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 2002,'||wwv_flow.LF||
'  "po_number": "29374",'||wwv_flow.LF||
'  "status": ';
wwv_flow_imp.g_varchar2_table(202) := '"DRAFT",'||wwv_flow.LF||
'  "date": "2022-11-14T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 1003,'||wwv_flow.LF||
'    "name": "Lind';
wwv_flow_imp.g_varchar2_table(203) := 'a Green",'||wwv_flow.LF||
'    "company_name": "Green Autos",'||wwv_flow.LF||
'    "phone": "517-367-7021",'||wwv_flow.LF||
'    "email": "linda.green@';
wwv_flow_imp.g_varchar2_table(204) := 'greencars.com",'||wwv_flow.LF||
'    "address": "4782 West End Ave",'||wwv_flow.LF||
'    "city": "Lansing",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'    "z';
wwv_flow_imp.g_varchar2_table(205) := 'ip_code": "48906"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructions": "Leave at front desk",'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(206) := '   "line_item_id": 4004,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3011,'||wwv_flow.LF||
'        "product_code": "154';
wwv_flow_imp.g_varchar2_table(207) := '-32691",'||wwv_flow.LF||
'        "desc": "Spark Plug",'||wwv_flow.LF||
'        "unit_price": 4.95'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(208) := '  "unit_price": 4.95,'||wwv_flow.LF||
'      "updated_on": "2022-11-14T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4';
wwv_flow_imp.g_varchar2_table(209) := '005,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3012,'||wwv_flow.LF||
'        "product_code": "872-33410",'||wwv_flow.LF||
'        "de';
wwv_flow_imp.g_varchar2_table(210) := 'sc": "Fuel Injector",'||wwv_flow.LF||
'        "unit_price": 56.4'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 5';
wwv_flow_imp.g_varchar2_table(211) := '6.4,'||wwv_flow.LF||
'      "updated_on": "2023-05-29T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4006,'||wwv_flow.LF||
'      "produ';
wwv_flow_imp.g_varchar2_table(212) := 'ct": {'||wwv_flow.LF||
'        "product_id": 3013,'||wwv_flow.LF||
'        "product_code": "561-49200",'||wwv_flow.LF||
'        "desc": "Alternator"';
wwv_flow_imp.g_varchar2_table(213) := ','||wwv_flow.LF||
'        "unit_price": 154.6'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 154.6,'||wwv_flow.LF||
'      "update';
wwv_flow_imp.g_varchar2_table(214) := 'd_on": "2023-08-18T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2003'||wwv_flow.LF||
'INSERT INTO DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(215) := 'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 2003,'||wwv_flow.LF||
'  "po_number": "48390",'||wwv_flow.LF||
'  "status": "COMPLETED",'||wwv_flow.LF||
'  "date": "2022-12-2';
wwv_flow_imp.g_varchar2_table(216) := '5T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 1004,'||wwv_flow.LF||
'    "name": "Henry Miller",'||wwv_flow.LF||
'    "company_name"';
wwv_flow_imp.g_varchar2_table(217) := ': "Miller Motors",'||wwv_flow.LF||
'    "phone": "517-367-7222",'||wwv_flow.LF||
'    "email": "h.miller@millermotors.com",'||wwv_flow.LF||
'    "addre';
wwv_flow_imp.g_varchar2_table(218) := 'ss": "5201 Eastport Rd",'||wwv_flow.LF||
'    "city": "Grand Rapids",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'    "zip_code": "49503"'||wwv_flow.LF||
'  },';
wwv_flow_imp.g_varchar2_table(219) := ''||wwv_flow.LF||
'  "delivery_instructions": "Deliver after noon",'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4007';
wwv_flow_imp.g_varchar2_table(220) := ','||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3011,'||wwv_flow.LF||
'        "product_code": "154-32691",'||wwv_flow.LF||
'        "desc"';
wwv_flow_imp.g_varchar2_table(221) := ': "Spark Plug",'||wwv_flow.LF||
'        "unit_price": 4.95'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 5,'||wwv_flow.LF||
'      "unit_price": 4.95,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(222) := '     "updated_on": "2024-01-02T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4008,'||wwv_flow.LF||
'      "product": {';
wwv_flow_imp.g_varchar2_table(223) := ''||wwv_flow.LF||
'        "product_id": 3020,'||wwv_flow.LF||
'        "product_code": "687-70547",'||wwv_flow.LF||
'        "desc": "Ignition Coil",'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(224) := '       "unit_price": 44.8'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 44.8,'||wwv_flow.LF||
'      "updated_on"';
wwv_flow_imp.g_varchar2_table(225) := ': "2022-12-25T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4009,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product';
wwv_flow_imp.g_varchar2_table(226) := '_id": 3014,'||wwv_flow.LF||
'        "product_code": "305-34520",'||wwv_flow.LF||
'        "desc": "Radiator",'||wwv_flow.LF||
'        "unit_price": 1';
wwv_flow_imp.g_varchar2_table(227) := '34.2'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 134.2,'||wwv_flow.LF||
'      "updated_on": "2023-06-17T00:00:';
wwv_flow_imp.g_varchar2_table(228) := '00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2004'||wwv_flow.LF||
'INSERT INTO DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": ';
wwv_flow_imp.g_varchar2_table(229) := '2004,'||wwv_flow.LF||
'  "po_number": "50938",'||wwv_flow.LF||
'  "status": "REJECTED",'||wwv_flow.LF||
'  "date": "2022-07-03T00:00:00",'||wwv_flow.LF||
'  "customer":';
wwv_flow_imp.g_varchar2_table(230) := ' {'||wwv_flow.LF||
'    "customer_id": 1005,'||wwv_flow.LF||
'    "name": "Sandra Lee",'||wwv_flow.LF||
'    "company_name": "Lee Engineering",'||wwv_flow.LF||
'    "ph';
wwv_flow_imp.g_varchar2_table(231) := 'one": "517-367-7311",'||wwv_flow.LF||
'    "email": "sandra.lee@leeeng.com",'||wwv_flow.LF||
'    "address": "153 Maple Ave",'||wwv_flow.LF||
'    "cit';
wwv_flow_imp.g_varchar2_table(232) := 'y": "Ann Arbor",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'    "zip_code": "48103"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructions": null,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(233) := '"line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4010,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3012,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(234) := '     "product_code": "872-33410",'||wwv_flow.LF||
'        "desc": "Fuel Injector",'||wwv_flow.LF||
'        "unit_price": 56.4'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(235) := '},'||wwv_flow.LF||
'      "quantity": 3,'||wwv_flow.LF||
'      "unit_price": 56.4,'||wwv_flow.LF||
'      "updated_on": "2022-07-03T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(236) := '   {'||wwv_flow.LF||
'      "line_item_id": 4011,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3015,'||wwv_flow.LF||
'        "product_cod';
wwv_flow_imp.g_varchar2_table(237) := 'e": "703-92034",'||wwv_flow.LF||
'        "desc": "Oil Filter",'||wwv_flow.LF||
'        "unit_price": 7.8'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": ';
wwv_flow_imp.g_varchar2_table(238) := '1,'||wwv_flow.LF||
'      "unit_price": 7.8,'||wwv_flow.LF||
'      "updated_on": "2023-03-28T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_';
wwv_flow_imp.g_varchar2_table(239) := 'id": 4012,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3016,'||wwv_flow.LF||
'        "product_code": "198-56210",'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(240) := '   "desc": "Air Filter",'||wwv_flow.LF||
'        "unit_price": 14.35'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price';
wwv_flow_imp.g_varchar2_table(241) := '": 14.35,'||wwv_flow.LF||
'      "updated_on": "2024-04-10T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2005'||wwv_flow.LF||
'INSERT INTO DV_PU';
wwv_flow_imp.g_varchar2_table(242) := 'RCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 2005,'||wwv_flow.LF||
'  "po_number": "11902",'||wwv_flow.LF||
'  "status": "DRAFT",'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(243) := ' "date": "2023-09-04T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 1006,'||wwv_flow.LF||
'    "name": "James Wilson",';
wwv_flow_imp.g_varchar2_table(244) := ''||wwv_flow.LF||
'    "company_name": "Wilco Parts",'||wwv_flow.LF||
'    "phone": "517-379-1101",'||wwv_flow.LF||
'    "email": "jwilson@wilcoparts.co';
wwv_flow_imp.g_varchar2_table(245) := 'm",'||wwv_flow.LF||
'    "address": "818 Oak St",'||wwv_flow.LF||
'    "city": "Jackson",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'    "zip_code": "49201"'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(246) := ' },'||wwv_flow.LF||
'  "delivery_instructions": null,'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4013,'||wwv_flow.LF||
'      "prod';
wwv_flow_imp.g_varchar2_table(247) := 'uct": {'||wwv_flow.LF||
'        "product_id": 3011,'||wwv_flow.LF||
'        "product_code": "154-32691",'||wwv_flow.LF||
'        "desc": "Spark Plug';
wwv_flow_imp.g_varchar2_table(248) := '",'||wwv_flow.LF||
'        "unit_price": 4.95'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 4.95,'||wwv_flow.LF||
'      "updated';
wwv_flow_imp.g_varchar2_table(249) := '_on": "2024-02-11T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4014,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "pro';
wwv_flow_imp.g_varchar2_table(250) := 'duct_id": 3030,'||wwv_flow.LF||
'        "product_code": "110-27450",'||wwv_flow.LF||
'        "desc": "Wiper Blade",'||wwv_flow.LF||
'        "unit_pr';
wwv_flow_imp.g_varchar2_table(251) := 'ice": 13.3'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 4,'||wwv_flow.LF||
'      "unit_price": 13.3,'||wwv_flow.LF||
'      "updated_on": "2023-10-15T0';
wwv_flow_imp.g_varchar2_table(252) := '0:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4015,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3014,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(253) := '     "product_code": "305-34520",'||wwv_flow.LF||
'        "desc": "Radiator",'||wwv_flow.LF||
'        "unit_price": 134.2'||wwv_flow.LF||
'      },'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(254) := '     "quantity": 5,'||wwv_flow.LF||
'      "unit_price": 134.2,'||wwv_flow.LF||
'      "updated_on": "2023-09-04T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}';
wwv_flow_imp.g_varchar2_table(255) := '''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2006'||wwv_flow.LF||
'INSERT INTO DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 2006,'||wwv_flow.LF||
'  "po_num';
wwv_flow_imp.g_varchar2_table(256) := 'ber": "20475",'||wwv_flow.LF||
'  "status": "COMPLETED",'||wwv_flow.LF||
'  "date": "2022-09-18T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "custom';
wwv_flow_imp.g_varchar2_table(257) := 'er_id": 1007,'||wwv_flow.LF||
'    "name": "Jennifer Fox",'||wwv_flow.LF||
'    "company_name": "Fox Fasteners",'||wwv_flow.LF||
'    "phone": "517-367';
wwv_flow_imp.g_varchar2_table(258) := '-7333",'||wwv_flow.LF||
'    "email": "jfox@foxf.com",'||wwv_flow.LF||
'    "address": "234 Grand Ave",'||wwv_flow.LF||
'    "city": "Kalamazoo",'||wwv_flow.LF||
'    "';
wwv_flow_imp.g_varchar2_table(259) := 'state": "MI",'||wwv_flow.LF||
'    "zip_code": "49001"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructions": "Call before delivery",'||wwv_flow.LF||
'  "lin';
wwv_flow_imp.g_varchar2_table(260) := 'e_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4016,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3013,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(261) := ' "product_code": "561-49200",'||wwv_flow.LF||
'        "desc": "Alternator",'||wwv_flow.LF||
'        "unit_price": 154.6'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(262) := '   "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 154.6,'||wwv_flow.LF||
'      "updated_on": "2023-01-08T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(263) := '      "line_item_id": 4017,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3022,'||wwv_flow.LF||
'        "product_code": "';
wwv_flow_imp.g_varchar2_table(264) := '410-58327",'||wwv_flow.LF||
'        "desc": "Shock Absorber",'||wwv_flow.LF||
'        "unit_price": 55.4'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": ';
wwv_flow_imp.g_varchar2_table(265) := '2,'||wwv_flow.LF||
'      "unit_price": 55.4,'||wwv_flow.LF||
'      "updated_on": "2022-09-18T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item';
wwv_flow_imp.g_varchar2_table(266) := '_id": 4018,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3041,'||wwv_flow.LF||
'        "product_code": "917-63280",'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(267) := '    "desc": "Window Regulator",'||wwv_flow.LF||
'        "unit_price": 59.1'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit';
wwv_flow_imp.g_varchar2_table(268) := '_price": 59.1,'||wwv_flow.LF||
'      "updated_on": "2023-03-16T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2007'||wwv_flow.LF||
'INSERT INTO ';
wwv_flow_imp.g_varchar2_table(269) := 'DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 2007,'||wwv_flow.LF||
'  "po_number": "37492",'||wwv_flow.LF||
'  "status": "DRAF';
wwv_flow_imp.g_varchar2_table(270) := 'T",'||wwv_flow.LF||
'  "date": "2022-08-19T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 1008,'||wwv_flow.LF||
'    "name": "Michael K';
wwv_flow_imp.g_varchar2_table(271) := 'im",'||wwv_flow.LF||
'    "company_name": "Kim Car Care",'||wwv_flow.LF||
'    "phone": "517-379-1155",'||wwv_flow.LF||
'    "email": "mkim@kimcare.com';
wwv_flow_imp.g_varchar2_table(272) := '",'||wwv_flow.LF||
'    "address": "941 Central Pkwy",'||wwv_flow.LF||
'    "city": "Battle Creek",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'    "zip_code":';
wwv_flow_imp.g_varchar2_table(273) := ' "49015"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructions": null,'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4019,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(274) := '     "product": {'||wwv_flow.LF||
'        "product_id": 3041,'||wwv_flow.LF||
'        "product_code": "917-63280",'||wwv_flow.LF||
'        "desc": "';
wwv_flow_imp.g_varchar2_table(275) := 'Window Regulator",'||wwv_flow.LF||
'        "unit_price": 59.1'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 3,'||wwv_flow.LF||
'      "unit_price": 59.1';
wwv_flow_imp.g_varchar2_table(276) := ','||wwv_flow.LF||
'      "updated_on": "2022-08-19T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4020,'||wwv_flow.LF||
'      "product"';
wwv_flow_imp.g_varchar2_table(277) := ': {'||wwv_flow.LF||
'        "product_id": 3015,'||wwv_flow.LF||
'        "product_code": "703-92034",'||wwv_flow.LF||
'        "desc": "Oil Filter",'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(278) := '       "unit_price": 7.8'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 7.8,'||wwv_flow.LF||
'      "updated_on": ';
wwv_flow_imp.g_varchar2_table(279) := '"2023-10-18T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4021,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_i';
wwv_flow_imp.g_varchar2_table(280) := 'd": 3065,'||wwv_flow.LF||
'        "product_code": "548-32019",'||wwv_flow.LF||
'        "desc": "Bumper",'||wwv_flow.LF||
'        "unit_price": 159.9';
wwv_flow_imp.g_varchar2_table(281) := '9'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 159.99,'||wwv_flow.LF||
'      "updated_on": "2023-05-01T00:00:00';
wwv_flow_imp.g_varchar2_table(282) := '"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2008'||wwv_flow.LF||
'INSERT INTO DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 20';
wwv_flow_imp.g_varchar2_table(283) := '08,'||wwv_flow.LF||
'  "po_number": "91203",'||wwv_flow.LF||
'  "status": "COMPLETED",'||wwv_flow.LF||
'  "date": "2022-06-11T00:00:00",'||wwv_flow.LF||
'  "customer": ';
wwv_flow_imp.g_varchar2_table(284) := '{'||wwv_flow.LF||
'    "customer_id": 1009,'||wwv_flow.LF||
'    "name": "Patricia Bennett",'||wwv_flow.LF||
'    "company_name": "Bennett Repair",'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(285) := ' "phone": "517-367-7444",'||wwv_flow.LF||
'    "email": "pbennett@bennettrepair.com",'||wwv_flow.LF||
'    "address": "1120 N Main St"';
wwv_flow_imp.g_varchar2_table(286) := ','||wwv_flow.LF||
'    "city": "Holland",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'    "zip_code": "49423"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructions": ';
wwv_flow_imp.g_varchar2_table(287) := 'null,'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4022,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3';
wwv_flow_imp.g_varchar2_table(288) := '065,'||wwv_flow.LF||
'        "product_code": "548-32019",'||wwv_flow.LF||
'        "desc": "Bumper",'||wwv_flow.LF||
'        "unit_price": 159.99'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(289) := '   },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 159.99,'||wwv_flow.LF||
'      "updated_on": "2024-02-13T00:00:00"'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(290) := ' },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4023,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3077,'||wwv_flow.LF||
'        "produc';
wwv_flow_imp.g_varchar2_table(291) := 't_code": "250-59062",'||wwv_flow.LF||
'        "desc": "Accelerator Pedal",'||wwv_flow.LF||
'        "unit_price": 26.34'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(292) := '  "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 26.34,'||wwv_flow.LF||
'      "updated_on": "2022-06-11T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(293) := '     "line_item_id": 4024,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3080,'||wwv_flow.LF||
'        "product_code": "5';
wwv_flow_imp.g_varchar2_table(294) := '76-31462",'||wwv_flow.LF||
'        "desc": "Gas Cap",'||wwv_flow.LF||
'        "unit_price": 8.22'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 3,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(295) := ' "unit_price": 8.22,'||wwv_flow.LF||
'      "updated_on": "2023-02-09T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2009'||wwv_flow.LF||
'INSERT';
wwv_flow_imp.g_varchar2_table(296) := ' INTO DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 2009,'||wwv_flow.LF||
'  "po_number": "77322",'||wwv_flow.LF||
'  "status":';
wwv_flow_imp.g_varchar2_table(297) := ' "DRAFT",'||wwv_flow.LF||
'  "date": "2023-01-16T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 1010,'||wwv_flow.LF||
'    "name": "Ste';
wwv_flow_imp.g_varchar2_table(298) := 'ven Carter",'||wwv_flow.LF||
'    "company_name": "Carter Service",'||wwv_flow.LF||
'    "phone": "517-367-7555",'||wwv_flow.LF||
'    "email": "scarte';
wwv_flow_imp.g_varchar2_table(299) := 'r@cartersvc.com",'||wwv_flow.LF||
'    "address": "2999 Industrial Dr",'||wwv_flow.LF||
'    "city": "Muskegon",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(300) := '  "zip_code": "49442"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructions": null,'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item';
wwv_flow_imp.g_varchar2_table(301) := '_id": 4025,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3077,'||wwv_flow.LF||
'        "product_code": "250-59062",'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(302) := '    "desc": "Accelerator Pedal",'||wwv_flow.LF||
'        "unit_price": 26.34'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "un';
wwv_flow_imp.g_varchar2_table(303) := 'it_price": 26.34,'||wwv_flow.LF||
'      "updated_on": "2024-01-07T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4026,';
wwv_flow_imp.g_varchar2_table(304) := ''||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3090,'||wwv_flow.LF||
'        "product_code": "938-40174",'||wwv_flow.LF||
'        "desc":';
wwv_flow_imp.g_varchar2_table(305) := ' "Differential",'||wwv_flow.LF||
'        "unit_price": 295.87'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 295.';
wwv_flow_imp.g_varchar2_table(306) := '87,'||wwv_flow.LF||
'      "updated_on": "2023-01-16T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4027,'||wwv_flow.LF||
'      "produc';
wwv_flow_imp.g_varchar2_table(307) := 't": {'||wwv_flow.LF||
'        "product_id": 3103,'||wwv_flow.LF||
'        "product_code": "364-87362",'||wwv_flow.LF||
'        "desc": "Turbocharger';
wwv_flow_imp.g_varchar2_table(308) := '",'||wwv_flow.LF||
'        "unit_price": 476.19'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 476.19,'||wwv_flow.LF||
'      "upd';
wwv_flow_imp.g_varchar2_table(309) := 'ated_on": "2022-12-21T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2010'||wwv_flow.LF||
'INSERT INTO DV_PURCHASE_ORDER_DV (DAT';
wwv_flow_imp.g_varchar2_table(310) := 'A)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 2010,'||wwv_flow.LF||
'  "po_number": "67281",'||wwv_flow.LF||
'  "status": "REJECTED",'||wwv_flow.LF||
'  "date": "2022-11';
wwv_flow_imp.g_varchar2_table(311) := '-29T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 1011,'||wwv_flow.LF||
'    "name": "Emily Davis",'||wwv_flow.LF||
'    "company_name';
wwv_flow_imp.g_varchar2_table(312) := '": "Davis Automotive",'||wwv_flow.LF||
'    "phone": "517-367-7666",'||wwv_flow.LF||
'    "email": "emily@davisauth.com",'||wwv_flow.LF||
'    "address';
wwv_flow_imp.g_varchar2_table(313) := '": "1021 S Wheeler Rd",'||wwv_flow.LF||
'    "city": "Saginaw",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'    "zip_code": "48609"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "de';
wwv_flow_imp.g_varchar2_table(314) := 'livery_instructions": "Contact upon arrival",'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4028,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(315) := '    "product": {'||wwv_flow.LF||
'        "product_id": 3013,'||wwv_flow.LF||
'        "product_code": "561-49200",'||wwv_flow.LF||
'        "desc": "A';
wwv_flow_imp.g_varchar2_table(316) := 'lternator",'||wwv_flow.LF||
'        "unit_price": 154.6'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 154.6,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(317) := '   "updated_on": "2022-11-29T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4029,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(318) := '       "product_id": 3016,'||wwv_flow.LF||
'        "product_code": "198-56210",'||wwv_flow.LF||
'        "desc": "Air Filter",'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(319) := '  "unit_price": 14.35'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 14.35,'||wwv_flow.LF||
'      "updated_on": "';
wwv_flow_imp.g_varchar2_table(320) := '2023-12-15T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4030,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id';
wwv_flow_imp.g_varchar2_table(321) := '": 3090,'||wwv_flow.LF||
'        "product_code": "938-40174",'||wwv_flow.LF||
'        "desc": "Differential",'||wwv_flow.LF||
'        "unit_price": ';
wwv_flow_imp.g_varchar2_table(322) := '295.87'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 295.87,'||wwv_flow.LF||
'      "updated_on": "2022-12-04T00:';
wwv_flow_imp.g_varchar2_table(323) := '00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2011'||wwv_flow.LF||
'INSERT INTO DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id';
wwv_flow_imp.g_varchar2_table(324) := '": 2011,'||wwv_flow.LF||
'  "po_number": "84012",'||wwv_flow.LF||
'  "status": "COMPLETED",'||wwv_flow.LF||
'  "date": "2022-08-27T00:00:00",'||wwv_flow.LF||
'  "custom';
wwv_flow_imp.g_varchar2_table(325) := 'er": {'||wwv_flow.LF||
'    "customer_id": 1012,'||wwv_flow.LF||
'    "name": "William Clark",'||wwv_flow.LF||
'    "company_name": "Clark Parts",'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(326) := '"phone": "517-379-1212",'||wwv_flow.LF||
'    "email": "william@clarkparts.com",'||wwv_flow.LF||
'    "address": "1689 River Rd",'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(327) := '"city": "Bay City",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'    "zip_code": "48706"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructions": null,';
wwv_flow_imp.g_varchar2_table(328) := ''||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4031,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3110,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(329) := '        "product_code": "123-49851",'||wwv_flow.LF||
'        "desc": "Front Axle",'||wwv_flow.LF||
'        "unit_price": 205.44'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(330) := '  },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 205.44,'||wwv_flow.LF||
'      "updated_on": "2023-07-08T00:00:00"'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(331) := '},'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4032,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3105,'||wwv_flow.LF||
'        "product';
wwv_flow_imp.g_varchar2_table(332) := '_code": "352-41278",'||wwv_flow.LF||
'        "desc": "Intercooler",'||wwv_flow.LF||
'        "unit_price": 132.12'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "qua';
wwv_flow_imp.g_varchar2_table(333) := 'ntity": 1,'||wwv_flow.LF||
'      "unit_price": 132.12,'||wwv_flow.LF||
'      "updated_on": "2022-08-27T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(334) := '"line_item_id": 4033,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3080,'||wwv_flow.LF||
'        "product_code": "576-31';
wwv_flow_imp.g_varchar2_table(335) := '462",'||wwv_flow.LF||
'        "desc": "Gas Cap",'||wwv_flow.LF||
'        "unit_price": 8.22'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "uni';
wwv_flow_imp.g_varchar2_table(336) := 't_price": 8.22,'||wwv_flow.LF||
'      "updated_on": "2023-09-28T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2012'||wwv_flow.LF||
'INSERT INTO';
wwv_flow_imp.g_varchar2_table(337) := ' DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 2012,'||wwv_flow.LF||
'  "po_number": "54812",'||wwv_flow.LF||
'  "status": "DRA';
wwv_flow_imp.g_varchar2_table(338) := 'FT",'||wwv_flow.LF||
'  "date": "2022-12-19T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 1013,'||wwv_flow.LF||
'    "name": "Olivia T';
wwv_flow_imp.g_varchar2_table(339) := 'urner",'||wwv_flow.LF||
'    "company_name": "Turner Supplies",'||wwv_flow.LF||
'    "phone": "517-367-7777",'||wwv_flow.LF||
'    "email": "oliviat@tu';
wwv_flow_imp.g_varchar2_table(340) := 'rnersup.com",'||wwv_flow.LF||
'    "address": "9005 N Cedar St",'||wwv_flow.LF||
'    "city": "Flint",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'    "zip_cod';
wwv_flow_imp.g_varchar2_table(341) := 'e": "48505"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructions": null,'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4034';
wwv_flow_imp.g_varchar2_table(342) := ','||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3012,'||wwv_flow.LF||
'        "product_code": "872-33410",'||wwv_flow.LF||
'        "desc"';
wwv_flow_imp.g_varchar2_table(343) := ': "Fuel Injector",'||wwv_flow.LF||
'        "unit_price": 56.4'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 3,'||wwv_flow.LF||
'      "unit_price": 56.4';
wwv_flow_imp.g_varchar2_table(344) := ','||wwv_flow.LF||
'      "updated_on": "2023-08-04T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4035,'||wwv_flow.LF||
'      "product"';
wwv_flow_imp.g_varchar2_table(345) := ': {'||wwv_flow.LF||
'        "product_id": 3011,'||wwv_flow.LF||
'        "product_code": "154-32691",'||wwv_flow.LF||
'        "desc": "Spark Plug",'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(346) := '       "unit_price": 4.95'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 4.95,'||wwv_flow.LF||
'      "updated_on"';
wwv_flow_imp.g_varchar2_table(347) := ': "2022-12-19T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4036,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product';
wwv_flow_imp.g_varchar2_table(348) := '_id": 3041,'||wwv_flow.LF||
'        "product_code": "917-63280",'||wwv_flow.LF||
'        "desc": "Window Regulator",'||wwv_flow.LF||
'        "unit_p';
wwv_flow_imp.g_varchar2_table(349) := 'rice": 59.1'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 59.1,'||wwv_flow.LF||
'      "updated_on": "2024-04-09T';
wwv_flow_imp.g_varchar2_table(350) := '00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2013'||wwv_flow.LF||
'INSERT INTO DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "';
wwv_flow_imp.g_varchar2_table(351) := '_id": 2013,'||wwv_flow.LF||
'  "po_number": "31297",'||wwv_flow.LF||
'  "status": "REJECTED",'||wwv_flow.LF||
'  "date": "2023-05-22T00:00:00",'||wwv_flow.LF||
'  "cust';
wwv_flow_imp.g_varchar2_table(352) := 'omer": {'||wwv_flow.LF||
'    "customer_id": 1014,'||wwv_flow.LF||
'    "name": "Matthew Evans",'||wwv_flow.LF||
'    "company_name": "Evans Group",'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(353) := '  "phone": "517-367-7888",'||wwv_flow.LF||
'    "email": "mevans@evansgroup.com",'||wwv_flow.LF||
'    "address": "4222 Westburton Ave';
wwv_flow_imp.g_varchar2_table(354) := '",'||wwv_flow.LF||
'    "city": "Warren",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'    "zip_code": "48091"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructions": ';
wwv_flow_imp.g_varchar2_table(355) := 'null,'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4037,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3';
wwv_flow_imp.g_varchar2_table(356) := '077,'||wwv_flow.LF||
'        "product_code": "250-59062",'||wwv_flow.LF||
'        "desc": "Accelerator Pedal",'||wwv_flow.LF||
'        "unit_price":';
wwv_flow_imp.g_varchar2_table(357) := ' 26.34'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 26.34,'||wwv_flow.LF||
'      "updated_on": "2023-11-16T00:0';
wwv_flow_imp.g_varchar2_table(358) := '0:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4038,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3014,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(359) := '  "product_code": "305-34520",'||wwv_flow.LF||
'        "desc": "Radiator",'||wwv_flow.LF||
'        "unit_price": 134.2'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(360) := '  "quantity": 3,'||wwv_flow.LF||
'      "unit_price": 134.2,'||wwv_flow.LF||
'      "updated_on": "2023-07-18T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(361) := '     "line_item_id": 4039,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3065,'||wwv_flow.LF||
'        "product_code": "5';
wwv_flow_imp.g_varchar2_table(362) := '48-32019",'||wwv_flow.LF||
'        "desc": "Bumper",'||wwv_flow.LF||
'        "unit_price": 159.99'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(363) := '  "unit_price": 159.99,'||wwv_flow.LF||
'      "updated_on": "2023-05-22T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2014'||wwv_flow.LF||
'INS';
wwv_flow_imp.g_varchar2_table(364) := 'ERT INTO DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 2014,'||wwv_flow.LF||
'  "po_number": "70085",'||wwv_flow.LF||
'  "statu';
wwv_flow_imp.g_varchar2_table(365) := 's": "DRAFT",'||wwv_flow.LF||
'  "date": "2022-09-09T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 1015,'||wwv_flow.LF||
'    "name": "';
wwv_flow_imp.g_varchar2_table(366) := 'Sophia Harris",'||wwv_flow.LF||
'    "company_name": "Harris Fleet",'||wwv_flow.LF||
'    "phone": "517-367-7999",'||wwv_flow.LF||
'    "email": "sophi';
wwv_flow_imp.g_varchar2_table(367) := 'a@harrisfleet.com",'||wwv_flow.LF||
'    "address": "303 Congress St",'||wwv_flow.LF||
'    "city": "Sterling Heights",'||wwv_flow.LF||
'    "state": "';
wwv_flow_imp.g_varchar2_table(368) := 'MI",'||wwv_flow.LF||
'    "zip_code": "48310"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructions": "Urgent",'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(369) := ' "line_item_id": 4040,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3013,'||wwv_flow.LF||
'        "product_code": "561-4';
wwv_flow_imp.g_varchar2_table(370) := '9200",'||wwv_flow.LF||
'        "desc": "Alternator",'||wwv_flow.LF||
'        "unit_price": 154.6'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(371) := ' "unit_price": 154.6,'||wwv_flow.LF||
'      "updated_on": "2023-01-22T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4';
wwv_flow_imp.g_varchar2_table(372) := '041,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3012,'||wwv_flow.LF||
'        "product_code": "872-33410",'||wwv_flow.LF||
'        "de';
wwv_flow_imp.g_varchar2_table(373) := 'sc": "Fuel Injector",'||wwv_flow.LF||
'        "unit_price": 56.4'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 5';
wwv_flow_imp.g_varchar2_table(374) := '6.4,'||wwv_flow.LF||
'      "updated_on": "2022-09-09T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4042,'||wwv_flow.LF||
'      "produ';
wwv_flow_imp.g_varchar2_table(375) := 'ct": {'||wwv_flow.LF||
'        "product_id": 3030,'||wwv_flow.LF||
'        "product_code": "110-27450",'||wwv_flow.LF||
'        "desc": "Wiper Blade';
wwv_flow_imp.g_varchar2_table(376) := '",'||wwv_flow.LF||
'        "unit_price": 13.3'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 13.3,'||wwv_flow.LF||
'      "updated';
wwv_flow_imp.g_varchar2_table(377) := '_on": "2024-03-12T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2015'||wwv_flow.LF||
'INSERT INTO DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'V';
wwv_flow_imp.g_varchar2_table(378) := 'ALUES (json(''{'||wwv_flow.LF||
'  "_id": 2015,'||wwv_flow.LF||
'  "po_number": "44010",'||wwv_flow.LF||
'  "status": "COMPLETED",'||wwv_flow.LF||
'  "date": "2022-07-23';
wwv_flow_imp.g_varchar2_table(379) := 'T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 1016,'||wwv_flow.LF||
'    "name": "Benjamin Scott",'||wwv_flow.LF||
'    "company_name';
wwv_flow_imp.g_varchar2_table(380) := '": "Scott Heavy Duty",'||wwv_flow.LF||
'    "phone": "517-367-8001",'||wwv_flow.LF||
'    "email": "ben.scott@shd.com",'||wwv_flow.LF||
'    "address":';
wwv_flow_imp.g_varchar2_table(381) := ' "8822 Remington Dr",'||wwv_flow.LF||
'    "city": "Livonia",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'    "zip_code": "48150"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "deli';
wwv_flow_imp.g_varchar2_table(382) := 'very_instructions": null,'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4043,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(383) := '     "product_id": 3015,'||wwv_flow.LF||
'        "product_code": "703-92034",'||wwv_flow.LF||
'        "desc": "Oil Filter",'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(384) := '"unit_price": 7.8'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 7.8,'||wwv_flow.LF||
'      "updated_on": "2022-0';
wwv_flow_imp.g_varchar2_table(385) := '9-30T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4044,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 302';
wwv_flow_imp.g_varchar2_table(386) := '0,'||wwv_flow.LF||
'        "product_code": "687-70547",'||wwv_flow.LF||
'        "desc": "Ignition Coil",'||wwv_flow.LF||
'        "unit_price": 44.8'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(387) := '      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 44.8,'||wwv_flow.LF||
'      "updated_on": "2023-02-10T00:00:00"'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(388) := '  },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4045,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3011,'||wwv_flow.LF||
'        "produ';
wwv_flow_imp.g_varchar2_table(389) := 'ct_code": "154-32691",'||wwv_flow.LF||
'        "desc": "Spark Plug",'||wwv_flow.LF||
'        "unit_price": 4.95'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quan';
wwv_flow_imp.g_varchar2_table(390) := 'tity": 6,'||wwv_flow.LF||
'      "unit_price": 4.95,'||wwv_flow.LF||
'      "updated_on": "2022-07-23T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO';
wwv_flow_imp.g_varchar2_table(391) := '_ID 2016'||wwv_flow.LF||
'INSERT INTO DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 2016,'||wwv_flow.LF||
'  "po_number": "9754';
wwv_flow_imp.g_varchar2_table(392) := '4",'||wwv_flow.LF||
'  "status": "COMPLETED",'||wwv_flow.LF||
'  "date": "2022-10-18T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 101';
wwv_flow_imp.g_varchar2_table(393) := '7,'||wwv_flow.LF||
'    "name": "Ava Walker",'||wwv_flow.LF||
'    "company_name": "Walker Imports",'||wwv_flow.LF||
'    "phone": "517-367-8111",'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(394) := '"email": "avawalker@walkerimports.com",'||wwv_flow.LF||
'    "address": "1130 S Fieldstone Ct",'||wwv_flow.LF||
'    "city": "Troy",'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(395) := '   "state": "MI",'||wwv_flow.LF||
'    "zip_code": "48083"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructions": null,'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(396) := '  {'||wwv_flow.LF||
'      "line_item_id": 4046,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3077,'||wwv_flow.LF||
'        "product_code';
wwv_flow_imp.g_varchar2_table(397) := '": "250-59062",'||wwv_flow.LF||
'        "desc": "Accelerator Pedal",'||wwv_flow.LF||
'        "unit_price": 26.34'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "qua';
wwv_flow_imp.g_varchar2_table(398) := 'ntity": 2,'||wwv_flow.LF||
'      "unit_price": 26.34,'||wwv_flow.LF||
'      "updated_on": "2024-01-22T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "';
wwv_flow_imp.g_varchar2_table(399) := 'line_item_id": 4047,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3013,'||wwv_flow.LF||
'        "product_code": "561-492';
wwv_flow_imp.g_varchar2_table(400) := '00",'||wwv_flow.LF||
'        "desc": "Alternator",'||wwv_flow.LF||
'        "unit_price": 154.6'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 3,'||wwv_flow.LF||
'      "';
wwv_flow_imp.g_varchar2_table(401) := 'unit_price": 154.6,'||wwv_flow.LF||
'      "updated_on": "2022-10-18T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 404';
wwv_flow_imp.g_varchar2_table(402) := '8,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3090,'||wwv_flow.LF||
'        "product_code": "938-40174",'||wwv_flow.LF||
'        "desc';
wwv_flow_imp.g_varchar2_table(403) := '": "Differential",'||wwv_flow.LF||
'        "unit_price": 295.87'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 29';
wwv_flow_imp.g_varchar2_table(404) := '5.87,'||wwv_flow.LF||
'      "updated_on": "2023-06-07T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2017'||wwv_flow.LF||
'INSERT INTO DV_PURCHA';
wwv_flow_imp.g_varchar2_table(405) := 'SE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 2017,'||wwv_flow.LF||
'  "po_number": "40598",'||wwv_flow.LF||
'  "status": "REJECTED",'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(406) := '"date": "2022-05-13T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 1018,'||wwv_flow.LF||
'    "name": "Logan Nelson",'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(407) := '    "company_name": "Nelson Autoworks",'||wwv_flow.LF||
'    "phone": "517-367-8222",'||wwv_flow.LF||
'    "email": "logan@nelsonautow';
wwv_flow_imp.g_varchar2_table(408) := 'orks.com",'||wwv_flow.LF||
'    "address": "2508 Sunset Blvd",'||wwv_flow.LF||
'    "city": "Rochester Hills",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(409) := '"zip_code": "48309"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructions": "Deliver side door",'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(410) := '   "line_item_id": 4049,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3014,'||wwv_flow.LF||
'        "product_code": "305';
wwv_flow_imp.g_varchar2_table(411) := '-34520",'||wwv_flow.LF||
'        "desc": "Radiator",'||wwv_flow.LF||
'        "unit_price": 134.2'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(412) := ' "unit_price": 134.2,'||wwv_flow.LF||
'      "updated_on": "2023-11-27T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4';
wwv_flow_imp.g_varchar2_table(413) := '050,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3015,'||wwv_flow.LF||
'        "product_code": "703-92034",'||wwv_flow.LF||
'        "de';
wwv_flow_imp.g_varchar2_table(414) := 'sc": "Oil Filter",'||wwv_flow.LF||
'        "unit_price": 7.8'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 7.8,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(415) := '      "updated_on": "2022-05-13T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4051,'||wwv_flow.LF||
'      "product": ';
wwv_flow_imp.g_varchar2_table(416) := '{'||wwv_flow.LF||
'        "product_id": 3011,'||wwv_flow.LF||
'        "product_code": "154-32691",'||wwv_flow.LF||
'        "desc": "Spark Plug",'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(417) := '     "unit_price": 4.95'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 1,'||wwv_flow.LF||
'      "unit_price": 4.95,'||wwv_flow.LF||
'      "updated_on": ';
wwv_flow_imp.g_varchar2_table(418) := '"2022-12-20T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2018'||wwv_flow.LF||
'INSERT INTO DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES ';
wwv_flow_imp.g_varchar2_table(419) := '(json(''{'||wwv_flow.LF||
'  "_id": 2018,'||wwv_flow.LF||
'  "po_number": "61104",'||wwv_flow.LF||
'  "status": "DRAFT",'||wwv_flow.LF||
'  "date": "2022-11-16T00:00:00"';
wwv_flow_imp.g_varchar2_table(420) := ','||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 1019,'||wwv_flow.LF||
'    "name": "Chloe Baker",'||wwv_flow.LF||
'    "company_name": "Baker Gar';
wwv_flow_imp.g_varchar2_table(421) := 'age",'||wwv_flow.LF||
'    "phone": "517-367-8333",'||wwv_flow.LF||
'    "email": "chloeb@bakergrg.com",'||wwv_flow.LF||
'    "address": "7413 Warner R';
wwv_flow_imp.g_varchar2_table(422) := 'd",'||wwv_flow.LF||
'    "city": "Southfield",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'    "zip_code": "48076"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructio';
wwv_flow_imp.g_varchar2_table(423) := 'ns": null,'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4052,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_i';
wwv_flow_imp.g_varchar2_table(424) := 'd": 3013,'||wwv_flow.LF||
'        "product_code": "561-49200",'||wwv_flow.LF||
'        "desc": "Alternator",'||wwv_flow.LF||
'        "unit_price": 1';
wwv_flow_imp.g_varchar2_table(425) := '54.6'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 3,'||wwv_flow.LF||
'      "unit_price": 154.6,'||wwv_flow.LF||
'      "updated_on": "2024-02-05T00:00:';
wwv_flow_imp.g_varchar2_table(426) := '00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4053,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3041,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(427) := '"product_code": "917-63280",'||wwv_flow.LF||
'        "desc": "Window Regulator",'||wwv_flow.LF||
'        "unit_price": 59.1'||wwv_flow.LF||
'      },';
wwv_flow_imp.g_varchar2_table(428) := ''||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 59.1,'||wwv_flow.LF||
'      "updated_on": "2023-08-23T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(429) := ' {'||wwv_flow.LF||
'      "line_item_id": 4054,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3077,'||wwv_flow.LF||
'        "product_code"';
wwv_flow_imp.g_varchar2_table(430) := ': "250-59062",'||wwv_flow.LF||
'        "desc": "Accelerator Pedal",'||wwv_flow.LF||
'        "unit_price": 26.34'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quan';
wwv_flow_imp.g_varchar2_table(431) := 'tity": 1,'||wwv_flow.LF||
'      "unit_price": 26.34,'||wwv_flow.LF||
'      "updated_on": "2022-11-16T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- P';
wwv_flow_imp.g_varchar2_table(432) := 'O_ID 2019'||wwv_flow.LF||
'INSERT INTO DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 2019,'||wwv_flow.LF||
'  "po_number": "802';
wwv_flow_imp.g_varchar2_table(433) := '14",'||wwv_flow.LF||
'  "status": "REJECTED",'||wwv_flow.LF||
'  "date": "2022-08-14T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 102';
wwv_flow_imp.g_varchar2_table(434) := '0,'||wwv_flow.LF||
'    "name": "David Hall",'||wwv_flow.LF||
'    "company_name": "Hall Mechanics",'||wwv_flow.LF||
'    "phone": "517-367-8444",'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(435) := '"email": "dhall@hallmech.com",'||wwv_flow.LF||
'    "address": "1677 Bartlett St",'||wwv_flow.LF||
'    "city": "Farmington Hills",'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(436) := '  "state": "MI",'||wwv_flow.LF||
'    "zip_code": "48334"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructions": null,'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(437) := ' {'||wwv_flow.LF||
'      "line_item_id": 4055,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3015,'||wwv_flow.LF||
'        "product_code"';
wwv_flow_imp.g_varchar2_table(438) := ': "703-92034",'||wwv_flow.LF||
'        "desc": "Oil Filter",'||wwv_flow.LF||
'        "unit_price": 7.8'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,';
wwv_flow_imp.g_varchar2_table(439) := ''||wwv_flow.LF||
'      "unit_price": 7.8,'||wwv_flow.LF||
'      "updated_on": "2022-10-07T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id';
wwv_flow_imp.g_varchar2_table(440) := '": 4056,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3012,'||wwv_flow.LF||
'        "product_code": "872-33410",'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(441) := ' "desc": "Fuel Injector",'||wwv_flow.LF||
'        "unit_price": 56.4'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price';
wwv_flow_imp.g_varchar2_table(442) := '": 56.4,'||wwv_flow.LF||
'      "updated_on": "2023-05-25T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4057,'||wwv_flow.LF||
'      "p';
wwv_flow_imp.g_varchar2_table(443) := 'roduct": {'||wwv_flow.LF||
'        "product_id": 3011,'||wwv_flow.LF||
'        "product_code": "154-32691",'||wwv_flow.LF||
'        "desc": "Spark P';
wwv_flow_imp.g_varchar2_table(444) := 'lug",'||wwv_flow.LF||
'        "unit_price": 4.95'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 4,'||wwv_flow.LF||
'      "unit_price": 4.95,'||wwv_flow.LF||
'      "upda';
wwv_flow_imp.g_varchar2_table(445) := 'ted_on": "2022-08-14T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- PO_ID 2020'||wwv_flow.LF||
'INSERT INTO DV_PURCHASE_ORDER_DV (DATA';
wwv_flow_imp.g_varchar2_table(446) := ')'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 2020,'||wwv_flow.LF||
'  "po_number": "10401",'||wwv_flow.LF||
'  "status": "COMPLETED",'||wwv_flow.LF||
'  "date": "2022-04';
wwv_flow_imp.g_varchar2_table(447) := '-23T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 1021,'||wwv_flow.LF||
'    "name": "Grace Adams",'||wwv_flow.LF||
'    "company_name';
wwv_flow_imp.g_varchar2_table(448) := '": "Adams Supplies",'||wwv_flow.LF||
'    "phone": "517-367-8555",'||wwv_flow.LF||
'    "email": "grace@adamssup.com",'||wwv_flow.LF||
'    "address": ';
wwv_flow_imp.g_varchar2_table(449) := '"4115 Sherwood Ln",'||wwv_flow.LF||
'    "city": "Westland",'||wwv_flow.LF||
'    "state": "MI",'||wwv_flow.LF||
'    "zip_code": "48185"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "deliv';
wwv_flow_imp.g_varchar2_table(450) := 'ery_instructions": null,'||wwv_flow.LF||
'  "line_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4058,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(451) := '    "product_id": 3014,'||wwv_flow.LF||
'        "product_code": "305-34520",'||wwv_flow.LF||
'        "desc": "Radiator",'||wwv_flow.LF||
'        "un';
wwv_flow_imp.g_varchar2_table(452) := 'it_price": 134.2'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 134.2,'||wwv_flow.LF||
'      "updated_on": "2022-';
wwv_flow_imp.g_varchar2_table(453) := '04-23T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4059,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 30';
wwv_flow_imp.g_varchar2_table(454) := '90,'||wwv_flow.LF||
'        "product_code": "938-40174",'||wwv_flow.LF||
'        "desc": "Differential",'||wwv_flow.LF||
'        "unit_price": 295.8';
wwv_flow_imp.g_varchar2_table(455) := '7'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 295.87,'||wwv_flow.LF||
'      "updated_on": "2024-03-04T00:00:00';
wwv_flow_imp.g_varchar2_table(456) := '"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4060,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3065,'||wwv_flow.LF||
'        "p';
wwv_flow_imp.g_varchar2_table(457) := 'roduct_code": "548-32019",'||wwv_flow.LF||
'        "desc": "Bumper",'||wwv_flow.LF||
'        "unit_price": 159.99'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "qu';
wwv_flow_imp.g_varchar2_table(458) := 'antity": 3,'||wwv_flow.LF||
'      "unit_price": 159.99,'||wwv_flow.LF||
'      "updated_on": "2023-07-30T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-';
wwv_flow_imp.g_varchar2_table(459) := '- PO_ID 2021'||wwv_flow.LF||
'INSERT INTO DV_PURCHASE_ORDER_DV (DATA)'||wwv_flow.LF||
'VALUES (json(''{'||wwv_flow.LF||
'  "_id": 2021,'||wwv_flow.LF||
'  "po_number": "';
wwv_flow_imp.g_varchar2_table(460) := '90218",'||wwv_flow.LF||
'  "status": "DRAFT",'||wwv_flow.LF||
'  "date": "2022-06-06T00:00:00",'||wwv_flow.LF||
'  "customer": {'||wwv_flow.LF||
'    "customer_id": 102';
wwv_flow_imp.g_varchar2_table(461) := '2,'||wwv_flow.LF||
'    "name": "Jackson Perez",'||wwv_flow.LF||
'    "company_name": "Perez Automotive",'||wwv_flow.LF||
'    "phone": "517-367-8666",';
wwv_flow_imp.g_varchar2_table(462) := ''||wwv_flow.LF||
'    "email": "jperez@perezauto.com",'||wwv_flow.LF||
'    "address": "8799 Candlewood Dr",'||wwv_flow.LF||
'    "city": "Novi",'||wwv_flow.LF||
'    "';
wwv_flow_imp.g_varchar2_table(463) := 'state": "MI",'||wwv_flow.LF||
'    "zip_code": "48375"'||wwv_flow.LF||
'  },'||wwv_flow.LF||
'  "delivery_instructions": "Deliver rear entrance",'||wwv_flow.LF||
'  "li';
wwv_flow_imp.g_varchar2_table(464) := 'ne_items": ['||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_id": 4061,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3041,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(465) := '  "product_code": "917-63280",'||wwv_flow.LF||
'        "desc": "Window Regulator",'||wwv_flow.LF||
'        "unit_price": 59.1'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(466) := '},'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "unit_price": 59.1,'||wwv_flow.LF||
'      "updated_on": "2023-04-13T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(467) := '   {'||wwv_flow.LF||
'      "line_item_id": 4062,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3015,'||wwv_flow.LF||
'        "product_cod';
wwv_flow_imp.g_varchar2_table(468) := 'e": "703-92034",'||wwv_flow.LF||
'        "desc": "Oil Filter",'||wwv_flow.LF||
'        "unit_price": 7.8'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": ';
wwv_flow_imp.g_varchar2_table(469) := '2,'||wwv_flow.LF||
'      "unit_price": 7.8,'||wwv_flow.LF||
'      "updated_on": "2022-06-06T00:00:00"'||wwv_flow.LF||
'    },'||wwv_flow.LF||
'    {'||wwv_flow.LF||
'      "line_item_';
wwv_flow_imp.g_varchar2_table(470) := 'id": 4063,'||wwv_flow.LF||
'      "product": {'||wwv_flow.LF||
'        "product_id": 3077,'||wwv_flow.LF||
'        "product_code": "250-59062",'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(471) := '   "desc": "Accelerator Pedal",'||wwv_flow.LF||
'        "unit_price": 26.34'||wwv_flow.LF||
'      },'||wwv_flow.LF||
'      "quantity": 2,'||wwv_flow.LF||
'      "uni';
wwv_flow_imp.g_varchar2_table(472) := 't_price": 26.34,'||wwv_flow.LF||
'      "updated_on": "2023-03-08T00:00:00"'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'  ]'||wwv_flow.LF||
'}''));'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(5528903490347455713)
,p_install_id=>wwv_flow_imp.id(5528902706493450773)
,p_name=>'Insert Data'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
