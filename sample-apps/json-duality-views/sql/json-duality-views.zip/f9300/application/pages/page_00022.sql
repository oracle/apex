prompt --application/pages/page_00022
begin
--   Manifest
--     PAGE: 00022
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9300
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>22
,p_name=>'About JSON Relational Duality View'
,p_alias=>'ABOUT-DUALITY-VIEW'
,p_step_title=>'About JSON Relational Duality View'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5525475291695041298)
,p_plug_name=>'APEX Usage'
,p_static_id=>'apex-usage'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    This sample app uses the JSON Relational Duality View <code>DV_PURCHASE_ORDER_DV</code>',
'    as the purchase order data source. The shared APEX JSON Relational Duality View source',
'    <code>purchase-orders</code> exposes the purchase order document, including the nested',
'    <code>line_items</code> array used by the child regions.',
'</p>',
'<p>',
'    The view is defined with GraphQL/simple syntax and uses the <code>@alias</code> directive',
'    so generated SQL fields can reference the root purchase order row with a documented alias',
'    instead of the previous hidden alias workaround.',
'</p>',
'<p>',
'    <strong>Purchase Orders Report</strong> shows the vertical parent and child pattern:',
'    purchase order details on top and line items underneath, backed declaratively by the',
'    JSON Relational Duality View source.',
'</p>',
'<p>',
'    <strong>Purchase Orders Inbox</strong> shows the email-style pattern: purchase orders',
'    in the left side column and the selected order details on the right. Its line-item',
'    detail region is also backed by the JSON Relational Duality View source.',
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6864841462901520239)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(5528715858987777183)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5525475403213041298)
,p_plug_name=>'JSON Relational Duality View DDL'
,p_static_id=>'duality-view-ddl'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'                <p>',
'                    The supporting objects create the purchase order JSON Relational Duality View with GraphQL/simple syntax.',
'                    The root table uses <code>@alias(as: po)</code>, which lets generated fields',
'                    correlate back to the selected purchase order using <code>po.po_id</code>.',
'                </p>',
'                <pre><code>CREATE OR REPLACE FORCE EDITIONABLE JSON RELATIONAL DUALITY VIEW "DV_PURCHASE_ORDER_DV" AS',
'dv_purchase_orders @alias(as: po) @insert @update @delete',
'{',
'  _id: po_id',
'  po_number: po_number',
'  status: status',
'  date: po_date',
'  customer: dv_customers @insert @update @nodelete',
'  {',
'    customer_id: customer_id',
'    name: name',
'    company_name: company_name',
'    phone: phone',
'    email: email',
'    address: address',
'    city: city',
'    state: state',
'    zip_code: zip_code',
'  }',
'  delivery_instructions: delivery_instructions',
'  line_items: dv_po_line_items @insert @update @delete',
'  [{',
'    line_item_id: line_id',
'    product: dv_products @noinsert @noupdate @nodelete',
'    {',
'      product_id: product_id',
'      product_code: product_code',
'      desc: description',
'      unit_price: unit_price',
'    }',
'    quantity: quantity',
'    unit_price: unit_price',
'    updated_on: updated_on',
'  }]',
'  total_amount @generated(sql: "select nvl(sum(i.unit_price * i.quantity), 0) from dv_po_line_items i where i.po_id = po.po_id")',
'  last_updated @generated(sql: "select greatest(nvl(max(i.updated_on), po.po_date), po.po_date) from dv_po_line_items i where i.po_id = po.po_id")',
'};</code></pre>',
'                '))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6861236943732790632)
,p_plug_name=>'JSON Schema'
,p_static_id=>'json-schema'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'                <p>',
'                    Oracle Database can describe a JSON Relational Duality View as a JSON schema. This gives',
'                    the sample app a concrete way to show the document contract that comes from the underlying',
'                    tables, keys, update permissions, generated fields, and nested arrays.',
'                </p>',
'                <pre><code>select json_serialize(',
'         dbms_json_schema.describe(''DV_PURCHASE_ORDER_DV'')',
'         returning clob pretty',
'       ) schema_json',
'  from dual;</code></pre>',
'                <pre><code>{',
'  "title" : "DV_PURCHASE_ORDER_DV",',
'  "dbObject" : "ORACLE.DV_PURCHASE_ORDER_DV",',
'  "dbObjectType" : "dualityView",',
'  "dbObjectProperties" : [ "insert", "update", "delete", "check" ],',
'  "properties" : {',
'    "_id" : {',
'      "type" : "number",',
'      "dbAssigned" : true',
'    },',
'    "total_amount" : {',
'      "dbGenerated" : true',
'    },',
'    "last_updated" : {',
'      "dbGenerated" : true',
'    },',
'    "customer" : {',
'      "type" : "object",',
'      "dbPrimaryKey" : [ "customer_id" ]',
'    },',
'    "line_items" : {',
'      "type" : "array",',
'      "items" : {',
'        "type" : "object",',
'        "dbPrimaryKey" : [ "line_item_id" ],',
'        "properties" : {',
'          "updated_on" : {',
'            "type" : "string",',
'            "format" : "date-time"',
'          }',
'        }',
'      }',
'    }',
'  },',
'  "dbPrimaryKey" : [ "_id" ],',
'  "additionalProperties" : false',
'}</code></pre>',
'                '))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5525475181686041298)
,p_plug_name=>'Region Display Selector'
,p_static_id=>'region-display-selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_landmark_type=>'navigation'
,p_landmark_label=>'JSON Relational Duality View Information'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6861237048033790633)
,p_plug_name=>'Sample JSON Document'
,p_static_id=>'sample-json-document'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>45
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'                <p>',
'                    This is the purchase order document shape used by the JSON Relational Duality View. The insert payload',
'                    omits database-generated fields such as <code>_id</code>, <code>_metadata</code>,',
'                    <code>total_amount</code>, <code>last_updated</code>, and line item identifiers.',
'                    Line item <code>updated_on</code> values can be supplied or defaulted by the table trigger.',
'                </p>',
'                <pre><code>{',
'  "po_number" : "93001001",',
'  "status" : "DRAFT",',
'  "date" : "2026-06-10T00:00:00",',
'  "customer" : {',
'    "customer_id" : 1005,',
'    "name" : "Sandra Lee",',
'    "company_name" : "Lee Engineering",',
'    "phone" : "517-367-7311",',
'    "email" : "sandra.lee@leeeng.com",',
'    "address" : "153 Maple Ave",',
'    "city" : "Ann Arbor",',
'    "state" : "MI",',
'    "zip_code" : "48103"',
'  },',
'  "delivery_instructions" : "Deliver after noon",',
'  "line_items" : [',
'    {',
'      "product" : {',
'        "product_id" : 3016,',
'        "product_code" : "198-56210",',
'        "desc" : "Air Filter",',
'        "unit_price" : 14.35',
'      },',
'      "quantity" : 2,',
'      "unit_price" : 14.35',
'    },',
'    {',
'      "product" : {',
'        "product_id" : 3015,',
'        "product_code" : "703-92034",',
'        "desc" : "Oil Filter",',
'        "unit_price" : 7.80',
'      },',
'      "quantity" : 1,',
'      "unit_price" : 7.80',
'    }',
'  ]',
'}</code></pre>',
'                <p>',
'                    After the document is stored, the view projects generated metadata and derived values',
'                    back into the JSON document.',
'                </p>',
'                <pre><code>{',
'  "_id" : 2004,',
'  "_metadata" : {',
'    "etag" : "D0767158D5838268137E0ECF3FC90291",',
'    "asof" : "000000000730D08E"',
'  },',
'  "po_number" : "50938",',
'  "status" : "REJECTED",',
'  "date" : "2022-07-03T00:00:00",',
'  "customer" : {',
'    "customer_id" : 1005,',
'    "name" : "Sandra Lee",',
'    "company_name" : "Lee Engineering",',
'    "phone" : "517-367-7311",',
'    "email" : "sandra.lee@leeeng.com",',
'    "address" : "153 Maple Ave",',
'    "city" : "Ann Arbor",',
'    "state" : "MI",',
'    "zip_code" : "48103"',
'  },',
'  "delivery_instructions" : null,',
'  "line_items" : [',
'    {',
'      "line_item_id" : 4010,',
'      "product" : {',
'        "product_id" : 3012,',
'        "product_code" : "872-33410",',
'        "desc" : "Fuel Injector",',
'        "unit_price" : 56.4',
'      },',
'      "quantity" : 3,',
'      "unit_price" : 56.4,',
'      "updated_on" : "2024-04-10T00:00:00"',
'    },',
'    {',
'      "line_item_id" : 4011,',
'      "product" : {',
'        "product_id" : 3015,',
'        "product_code" : "703-92034",',
'        "desc" : "Oil Filter",',
'        "unit_price" : 7.8',
'      },',
'      "quantity" : 1,',
'      "unit_price" : 7.8,',
'      "updated_on" : "2024-04-10T00:00:00"',
'    },',
'    {',
'      "line_item_id" : 4012,',
'      "product" : {',
'        "product_id" : 3016,',
'        "product_code" : "198-56210",',
'        "desc" : "Air Filter",',
'        "unit_price" : 14.35',
'      },',
'      "quantity" : 2,',
'      "unit_price" : 14.35,',
'      "updated_on" : "2024-04-10T00:00:00"',
'    }',
'  ],',
'  "total_amount" : 205.7,',
'  "last_updated" : "2024-04-10T00:00:00"',
'}</code></pre>',
'                '))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
