prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9300
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>20
,p_name=>'Purchase Orders - Inbox'
,p_alias=>'PURCHASE-ORDERS-INBOX'
,p_step_title=>'Purchase Orders - Inbox'
,p_allow_duplicate_submissions=>'N'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Scroll Results Only in Side Column */',
'.t-Body-side {',
'    display: flex;',
'    flex-direction: column;',
'    overflow: hidden;',
'}',
'.search-results {',
'    flex: 1;',
'    overflow: auto;',
'}',
'/* Format Search Region */',
'.search-region {',
'    border-bottom: 1px solid rgba(0,0,0,.1);',
'    flex-shrink: 0;',
'}',
'',
'/* Minor List UI Customizations */',
'.t-MediaList {',
'    --ut-medialist-icon-border-radius: .25rem;',
'}',
'.t-MediaList-desc {',
'    white-space: pre-line;',
'}',
''))
,p_step_template=>2528119710305719084
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(933721798038023514)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(5528715858987777183)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5525838099112638252)
,p_name=>'Line Items'
,p_static_id=>'dv-po-line-items'
,p_template=>4073835273271169698
,p_display_sequence=>40
,p_region_css_classes=>'js-detail-region'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_location=>'DUALITY_VIEW'
,p_array_column_id=>wwv_flow_imp.id(5526072798953083114)
,p_document_source_id=>wwv_flow_imp.id(5528755791817793164)
,p_query_where=>'PO_ID = :P20_PO_ID and LINE_ID is not null'
,p_source_post_processing=>'WHERE_ORDER_BY_CLAUSE'
,p_display_when_condition=>'P20_PO_ID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P20_PO_ID'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found.'
,p_query_row_count_max=>5000
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524226809533895988)
,p_query_column_id=>13
,p_column_alias=>'CUSTOMER_ADDRESS'
,p_column_display_sequence=>102
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524226249909895983)
,p_query_column_id=>8
,p_column_alias=>'CUSTOMER_CITY'
,p_column_display_sequence=>52
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524227088998895991)
,p_query_column_id=>16
,p_column_alias=>'CUSTOMER_COMPANY_NAME'
,p_column_display_sequence=>132
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524226437262895985)
,p_query_column_id=>10
,p_column_alias=>'CUSTOMER_EMAIL'
,p_column_display_sequence=>72
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524226949518895990)
,p_query_column_id=>15
,p_column_alias=>'CUSTOMER_ID'
,p_column_display_sequence=>122
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524226376754895984)
,p_query_column_id=>9
,p_column_alias=>'CUSTOMER_NAME'
,p_column_display_sequence=>62
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524226535364895986)
,p_query_column_id=>11
,p_column_alias=>'CUSTOMER_PHONE'
,p_column_display_sequence=>82
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524226708807895987)
,p_query_column_id=>12
,p_column_alias=>'CUSTOMER_STATE'
,p_column_display_sequence=>92
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524226887201895989)
,p_query_column_id=>14
,p_column_alias=>'CUSTOMER_ZIP_CODE'
,p_column_display_sequence=>112
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524225819167895979)
,p_query_column_id=>4
,p_column_alias=>'DATE'
,p_column_display_sequence=>12
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524226186216895982)
,p_query_column_id=>7
,p_column_alias=>'DELIVERY_INSTRUCTIONS'
,p_column_display_sequence=>42
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524227379543895994)
,p_query_column_id=>25
,p_column_alias=>'LAST_UPDATED'
,p_column_display_sequence=>162
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524227424990895995)
,p_query_column_id=>2
,p_column_alias=>'LINE_ID'
,p_column_display_sequence=>5
,p_column_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:8:P8_PO_ID,P8_LINE_ID:#PO_ID#,#LINE_ID#'
,p_column_linktext=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'exists (',
'    select 1',
'      from dv_purchase_order_dv d',
'     where json_value(d.data, ''$._id'' returning number) = :P20_PO_ID',
'       and json_value(d.data, ''$.status'') = ''DRAFT''',
')'))
,p_display_when_condition2=>'SQL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524228111986896001)
,p_query_column_id=>21
,p_column_alias=>'LINE_ITEMS_POS'
,p_column_display_sequence=>232
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524174639268860034)
,p_query_column_id=>1
,p_column_alias=>'PO_ID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524225967305895980)
,p_query_column_id=>5
,p_column_alias=>'PO_NUMBER'
,p_column_display_sequence=>22
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524227836473895999)
,p_query_column_id=>19
,p_column_alias=>'PRODUCT_DESC'
,p_column_display_sequence=>10
,p_column_heading=>'Product'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524227565410895996)
,p_query_column_id=>3
,p_column_alias=>'PRODUCT_ID'
,p_column_display_sequence=>182
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524227939550896000)
,p_query_column_id=>20
,p_column_alias=>'PRODUCT_PRODUCT_CODE'
,p_column_display_sequence=>20
,p_column_heading=>'Code'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524227777913895998)
,p_query_column_id=>18
,p_column_alias=>'PRODUCT_UNIT_PRICE'
,p_column_display_sequence=>202
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524227693823895997)
,p_query_column_id=>17
,p_column_alias=>'QUANTITY'
,p_column_display_sequence=>30
,p_column_heading=>'Qty'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524227304315895993)
,p_query_column_id=>24
,p_column_alias=>'STATUS'
,p_column_display_sequence=>152
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524226056578895981)
,p_query_column_id=>6
,p_column_alias=>'TOTAL_AMOUNT'
,p_column_display_sequence=>32
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524228293262896003)
,p_query_column_id=>23
,p_column_alias=>'UNIT_PRICE'
,p_column_display_sequence=>40
,p_column_heading=>'Unit Price'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5524228166529896002)
,p_query_column_id=>22
,p_column_alias=>'amount'
,p_column_display_sequence=>50
,p_column_heading=>'Line Total'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5525832054983638231)
,p_plug_name=>'Purchase Order'
,p_static_id=>'dv-purchase-orders'
,p_region_css_classes=>'js-master-region po-document-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select po_id,',
'       po_number,',
'       status,',
'       status_state,',
'       order_date,',
'       total_amount,',
'       last_updated,',
'       customer_name,',
'       customer_email,',
'       customer_phone,',
'       customer_company_name,',
'       customer_address,',
'       delivery_instructions',
'  from (',
'    select json_value(data, ''$._id'' returning number) po_id,',
'           json_value(data, ''$.po_number'') po_number,',
'           json_value(data, ''$.status'') status,',
'           case json_value(data, ''$.status'')',
'             when ''COMPLETED'' then ''success''',
'             when ''REJECTED'' then ''danger''',
'             else ''info''',
'           end status_state,',
'           to_char(to_date(substr(json_value(data, ''$.date''), 1, 10), ''YYYY-MM-DD''), ''Mon DD, YYYY'') order_date,',
'           to_char(json_value(data, ''$.total_amount'' returning number), ''FML999G999G990D00'') total_amount,',
'           to_char(to_date(substr(json_value(data, ''$.last_updated''), 1, 10), ''YYYY-MM-DD''), ''Mon DD, YYYY'') last_updated,',
'           json_value(data, ''$.customer.name'') customer_name,',
'           json_value(data, ''$.customer.email'') customer_email,',
'           json_value(data, ''$.customer.phone'') customer_phone,',
'           json_value(data, ''$.customer.company_name'') customer_company_name,',
'           json_value(data, ''$.customer.address'') || '', '' ||',
'           json_value(data, ''$.customer.city'') || '', '' ||',
'           json_value(data, ''$.customer.state'') || '' '' ||',
'           json_value(data, ''$.customer.zip_code'') customer_address,',
'           json_value(data, ''$.delivery_instructions'') delivery_instructions',
'      from dv_purchase_order_dv',
'  )',
' where po_id = :P20_PO_ID'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P20_PO_ID'
,p_plug_query_num_rows=>1
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P20_PO_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', 'Status',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_SHAPE', 't-Badge--rounded',
  'BADGE_SIZE', 't-Badge--md',
  'BADGE_STATE', 'STATUS_STATE',
  'BADGE_STYLE', 't-Badge--subtle',
  'BADGE_VALUE', 'STATUS',
  'DESCRIPTION', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<strong>&CUSTOMER_COMPANY_NAME!HTML.</strong><br>',
    '&CUSTOMER_EMAIL!HTML. &middot; &CUSTOMER_PHONE!HTML.<br>',
    '&CUSTOMER_ADDRESS!HTML.',
    '{if DELIVERY_INSTRUCTIONS/}<br><br>',
    '<strong>Delivery Instructions</strong><br>',
    '&DELIVERY_INSTRUCTIONS!HTML.',
    '{endif/}')),
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'MISC', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<span class="u-text-subtitle-6">&TOTAL_AMOUNT!HTML.</span><br>',
    'Order Date: <strong>&ORDER_DATE!HTML.</strong><br>',
    'Last Updated: <strong>&LAST_UPDATED!HTML.</strong>')),
  'OVERLINE', 'PO #&PO_NUMBER.',
  'REMOVE_PADDING', 'N',
  'STACK_MOBILE', 'N',
  'TITLE', '&CUSTOMER_NAME!HTML.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5524902489459647201)
,p_name=>'CUSTOMER_ADDRESS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CUSTOMER_ADDRESS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5524902559487647202)
,p_name=>'CUSTOMER_COMPANY_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CUSTOMER_COMPANY_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5524902697695647202)
,p_name=>'CUSTOMER_EMAIL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CUSTOMER_EMAIL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5524902729403647202)
,p_name=>'CUSTOMER_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CUSTOMER_NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5524902876036647202)
,p_name=>'CUSTOMER_PHONE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CUSTOMER_PHONE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5524902923029647202)
,p_name=>'DELIVERY_INSTRUCTIONS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DELIVERY_INSTRUCTIONS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>110
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5524903135582647202)
,p_name=>'LAST_UPDATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5524903267984647202)
,p_name=>'ORDER_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ORDER_DATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5524903354418647202)
,p_name=>'PO_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PO_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5524903444986647202)
,p_name=>'PO_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PO_NUMBER'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5524903537417647202)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6861236298607790591)
,p_name=>'STATUS_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS_STATE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>95
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5524903636099647202)
,p_name=>'TOTAL_AMOUNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_AMOUNT'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>35
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(6864841577811520240)
,p_region_id=>wwv_flow_imp.id(5525832054983638231)
,p_position_id=>363792341120765662
,p_display_sequence=>10
,p_template_id=>363792942797796791
,p_label=>'Edit'
,p_static_id=>'edit'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:21,RP:P21_PO_ID:&PO_ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-pencil-square-o'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5525827489310638123)
,p_name=>'Purchase Orders'
,p_static_id=>'master-records'
,p_template=>3372714138756020509
,p_display_sequence=>40
,p_region_css_classes=>'search-results'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'t-MediaList--showIcons:t-MediaList--showDesc:t-MediaList--stack'
,p_display_point=>'REGION_POSITION_02'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_location=>'DUALITY_VIEW'
,p_document_source_id=>wwv_flow_imp.id(5528755791817793164)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "PO_ID",',
'    null LINK_CLASS,',
'    apex_page.get_url(p_items => ''P20_PO_ID'', p_values => "PO_ID") LINK,',
'    -- null ICON_CLASS,',
'   case STATUS',
'     when ''COMPLETED'' then ''fa fa-file-check''',
'     when ''REJECTED'' then ''fa fa-file-x''',
'     else ''fa fa-file-edit''',
'   end ICON_CLASS,',
'    null LINK_ATTR,',
'   case STATUS',
'     when ''COMPLETED'' then ''u-success''',
'     when ''REJECTED'' then ''u-danger''',
'     else ''u-info''',
'   end ICON_COLOR_CLASS,',
'    case when coalesce(:P20_PO_ID,''0'') = "PO_ID"',
'      then ''is-selected'' ',
'      else '' ''',
'    end LIST_CLASS,',
'    ''PO #'' || "PO_NUMBER" LIST_TITLE,',
'    substr(',
'        coalesce("CUSTOMER_COMPANY_NAME", "CUSTOMER_NAME") ||',
'        chr(10) ||',
'        to_char("TOTAL_AMOUNT", ''FML999G999G990D00'') ||',
unistr('        '' \00B7 '' ||'),
'        to_char("DATE", ''Mon DD, YYYY''),',
'        1,',
'        200',
'    ) LIST_TEXT,',
'    "STATUS" LIST_BADGE',
'from #APEX$SOURCE_DATA#',
'where :P20_SEARCH is null',
'   or instr(',
'        upper(',
'            "PO_NUMBER" || '' '' ||',
'            "STATUS" || '' '' ||',
'            coalesce("CUSTOMER_COMPANY_NAME", "CUSTOMER_NAME") || '' '' ||',
'            "CUSTOMER_EMAIL"',
'        ),',
'        upper(:P20_SEARCH)',
'      ) > 0',
'order by "LAST_UPDATED" desc nulls last, "PO_NUMBER"'))
,p_source_post_processing=>'SQL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P20_SEARCH'
,p_lazy_loading=>false
,p_query_row_template=>2095080600153409441
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'<div class="u-tC">No data found.</div>'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5525601564114108001)
,p_query_column_id=>4
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>210
,p_column_heading=>'Icon Class'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5525601790005108003)
,p_query_column_id=>6
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>230
,p_column_heading=>'Icon Color Class'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5525601516141108000)
,p_query_column_id=>3
,p_column_alias=>'LINK'
,p_column_display_sequence=>200
,p_column_heading=>'Link'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5525601671342108002)
,p_query_column_id=>5
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>220
,p_column_heading=>'Link Attr'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5525601324987107999)
,p_query_column_id=>2
,p_column_alias=>'LINK_CLASS'
,p_column_display_sequence=>190
,p_column_heading=>'Link Class'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5525602061167108006)
,p_query_column_id=>10
,p_column_alias=>'LIST_BADGE'
,p_column_display_sequence=>260
,p_column_heading=>'List Badge'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5525601879190108004)
,p_query_column_id=>7
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>240
,p_column_heading=>'List Class'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5525602002191108005)
,p_query_column_id=>9
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>250
,p_column_heading=>'List Text'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5525601252752107998)
,p_query_column_id=>8
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>180
,p_column_heading=>'List Title'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5525599585116107981)
,p_query_column_id=>1
,p_column_alias=>'PO_ID'
,p_column_display_sequence=>10
,p_column_heading=>'Po Id'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5525854267664638268)
,p_plug_name=>'No Record Selected'
,p_static_id=>'no-record-selected'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>60
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'No Record Selected'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P20_PO_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5525837638637638251)
,p_plug_name=>'Region Display Selector'
,p_static_id=>'region-display-selector'
,p_region_css_classes=>'js-detail-rds'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P20_PO_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5525826661203638120)
,p_plug_name=>'Search'
,p_static_id=>'search'
,p_region_css_classes=>'search-region padding-md'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(933721902356023516)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(933721798038023514)
,p_button_name=>'ACTIONS'
,p_static_id=>'actions'
,p_show_as_disabled=>false
,p_button_type=>'MENU'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Actions'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ellipsis-v'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(933722003883023517)
,p_button_id=>wwv_flow_imp.id(933721902356023516)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Show Query'
,p_static_id=>'show-query'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:23'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5524177147714860034)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5525838099112638252)
,p_button_name=>'POP_DV_PO_LINE_ITEMS'
,p_static_id=>'pop-dv-po-line-items'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Add Line Item'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:9,RP:P9_PO_ID:&P20_PO_ID.'
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5525846302005638258)
,p_name=>'P20_PO_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5525832054983638231)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5525842389688638131)
,p_name=>'P20_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5525826661203638120)
,p_prompt=>'Search'
,p_placeholder=>'Search...'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'autocomplete="off"'
,p_label_alignment=>'RIGHT'
,p_field_template=>2042262243893469891
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--postTextBlock'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5524188612682860037)
,p_name=>'Refresh Line Items and Purchase Order'
,p_static_id=>'dialog-closed'
,p_event_sequence=>40
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5524189015688860038)
,p_event_id=>wwv_flow_imp.id(5524188612682860037)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5525838099112638252)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6861236321552790599)
,p_event_id=>wwv_flow_imp.id(5524188612682860037)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh-2'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5525832054983638231)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6861236517615790600)
,p_event_id=>wwv_flow_imp.id(5524188612682860037)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh-4'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5525827489310638123)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5524189454934860038)
,p_name=>'Dialog Closed'
,p_static_id=>'dialog-closed-2'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(5525832054983638231)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5524189902315860039)
,p_event_id=>wwv_flow_imp.id(5524189454934860038)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5525832054983638231)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5524190404209860039)
,p_name=>'Perform Search'
,p_static_id=>'perform-search'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P20_SEARCH'
,p_condition_element=>'JAVASCRIPT_EXPRESSION'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'this.browserEvent.which === apex.jQuery.ui.keyCode.ENTER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5524191237523860039)
,p_event_id=>wwv_flow_imp.id(5524190404209860039)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_static_id=>'native-cancel-event'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5524190801610860039)
,p_event_id=>wwv_flow_imp.id(5524190404209860039)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5525827489310638123)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5524898841004597107)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Select First Purchase Order'
,p_static_id=>'select-first-purchase-order'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    select po_id',
'      into :P20_PO_ID',
'      from (',
'          select json_value(data, ''$._id'' returning number) po_id',
'            from dv_purchase_order_dv',
'           order by json_value(data, ''$.last_updated'') desc nulls last,',
'                    json_value(data, ''$.po_number'')',
'      )',
'     where rownum = 1;',
'exception',
'    when no_data_found then',
'        null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P20_PO_ID'
,p_process_when_type=>'ITEM_IS_NULL'
,p_internal_uid=>2427822935534829
);
wwv_flow_imp.component_end;
end;
/
