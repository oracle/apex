prompt --application/pages/page_00023
begin
--   Manifest
--     PAGE: 00023
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9300
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>23
,p_name=>'Purchase Order Query'
,p_alias=>'PURCHASE-ORDER-QUERY'
,p_page_mode=>'MODAL'
,p_step_title=>'Purchase Order Query'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_dialog_chained=>'N'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6864841311641520238)
,p_plug_name=>'About'
,p_static_id=>'about'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>2042159785845301134
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This query reads one purchase order document from <code>DV_PURCHASE_ORDER_DV</code> and formats the inbox/detail content.</p>',
'<p>Static view metadata, DDL, and generated JSON schema are shown here because they are the same for every selected purchase order.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5525511469085599008)
,p_plug_name=>'Display Query'
,p_static_id=>'display-query'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="po-query-code"><code>select po_id,',
'      po_number,',
'      status,',
'      status_state,',
'      order_date,',
'      total_amount,',
'      last_updated,',
'      customer_name,',
'      customer_email,',
'      customer_phone,',
'      customer_company_name,',
'      customer_address,',
'      delivery_instructions',
' from (',
'   select json_value(data, ''$._id'' returning number) po_id,',
'          json_value(data, ''$.po_number'') po_number,',
'          json_value(data, ''$.status'') status,',
'          case json_value(data, ''$.status'')',
'            when ''COMPLETED'' then ''success''',
'            when ''REJECTED'' then ''danger''',
'            else ''info''',
'          end status_state,',
'          to_char(to_date(substr(json_value(data, ''$.date''), 1, 10), ''YYYY-MM-DD''), ''Mon DD, YYYY'') order_date,',
'          to_char(json_value(data, ''$.total_amount'' returning number), ''FML999G999G990D00'') total_amount,',
'          to_char(to_date(substr(json_value(data, ''$.last_updated''), 1, 10), ''YYYY-MM-DD''), ''Mon DD, YYYY'') last_updated,',
'          json_value(data, ''$.customer.name'') customer_name,',
'          json_value(data, ''$.customer.email'') customer_email,',
'          json_value(data, ''$.customer.phone'') customer_phone,',
'          json_value(data, ''$.customer.company_name'') customer_company_name,',
'          json_value(data, ''$.customer.address'') || '', '' ||',
'          json_value(data, ''$.customer.city'') || '', '' ||',
'          json_value(data, ''$.customer.state'') || '' '' ||',
'          json_value(data, ''$.customer.zip_code'') customer_address,',
'          json_value(data, ''$.delivery_instructions'') delivery_instructions',
'     from dv_purchase_order_dv',
' )',
'where po_id = :P20_PO_ID</code></pre>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5525511589124599008)
,p_plug_name=>'JSON Relational Duality View DDL'
,p_static_id=>'duality-view-ddl'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="po-query-code"><code>CREATE OR REPLACE FORCE EDITIONABLE JSON RELATIONAL DUALITY VIEW "DV_PURCHASE_ORDER_DV" AS',
'dv_purchase_orders @alias(as: po) @insert @update @delete',
'{',
'  _id: po_id',
'  po_number: po_number',
'  status: status',
'  date: po_date',
'  customer: dv_customers @insert @update @nodelete',
'  {',
'    customer_id: customer_id',
'    name: name',
'    company_name: company_name',
'    phone: phone',
'    email: email',
'    address: address',
'    city: city',
'    state: state',
'    zip_code: zip_code',
'  }',
'  delivery_instructions: delivery_instructions',
'  line_items: dv_po_line_items @insert @update @delete',
'  [{',
'    line_item_id: line_id',
'    product: dv_products @noinsert @noupdate @nodelete',
'    {',
'      product_id: product_id',
'      product_code: product_code',
'      desc: description',
'      unit_price: unit_price',
'    }',
'    quantity: quantity',
'    unit_price: unit_price',
'    updated_on: updated_on',
'  }]',
'  total_amount @generated(sql: "select nvl(sum(i.unit_price * i.quantity), 0) from dv_po_line_items i where i.po_id = po.po_id")',
'  last_updated @generated(sql: "select greatest(nvl(max(i.updated_on), po.po_date), po.po_date) from dv_po_line_items i where i.po_id = po.po_id")',
'};</code></pre>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6861237241292790634)
,p_plug_name=>'JSON Schema'
,p_static_id=>'json-schema'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre class="po-query-code"><code>select json_serialize(',
'         dbms_json_schema.describe(''DV_PURCHASE_ORDER_DV'')',
'         returning clob pretty',
'       ) schema_json',
'  from dual;</code></pre>',
'',
'<br />',
'',
'<pre class="po-query-code"><code>{',
'  "title" : "DV_PURCHASE_ORDER_DV",',
'  "dbObject" : "ORACLE.DV_PURCHASE_ORDER_DV",',
'  "dbObjectType" : "dualityView",',
'  "dbObjectProperties" : [ "insert", "update", "delete", "check" ],',
'  "properties" : {',
'    "_id" : {',
'      "type" : "number",',
'      "dbAssigned" : true',
'    },',
'    "total_amount" : {',
'      "dbGenerated" : true',
'    },',
'    "last_updated" : {',
'      "dbGenerated" : true',
'    },',
'    "customer" : {',
'      "type" : "object",',
'      "dbPrimaryKey" : [ "customer_id" ]',
'    },',
'    "line_items" : {',
'      "type" : "array",',
'      "items" : {',
'        "type" : "object",',
'        "dbPrimaryKey" : [ "line_item_id" ],',
'        "properties" : {',
'          "updated_on" : {',
'            "type" : "string",',
'            "format" : "date-time"',
'          }',
'        }',
'      }',
'    }',
'  },',
'  "dbPrimaryKey" : [ "_id" ],',
'  "additionalProperties" : false',
'}</code></pre>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(6864840332583520228)
,p_name=>'Query'
,p_static_id=>'query'
,p_template=>4073835273271169698
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''DV_PURCHASE_ORDER_DV''      as "JSON Relational Duality View",',
'       ''JSON Relational Duality''   as "View Type",',
'       ''_id / po_id''               as "Root Key",',
'       ''line_items''                as "Child Array",',
'       ''Purchase Orders - Inbox''   as "Used By",',
'       ''read/write where allowed''  as "Update Mode"',
'  from dual'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2101991776017792140
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6864840987988520234)
,p_query_column_id=>4
,p_column_alias=>'Child Array'
,p_column_display_sequence=>40
,p_column_heading=>'Child Array'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6435912926602414)
,p_query_column_id=>1
,p_column_alias=>'JSON Relational Duality View'
,p_column_display_sequence=>10
,p_column_heading=>'JSON Relational Duality View'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6864840806369520233)
,p_query_column_id=>3
,p_column_alias=>'Root Key'
,p_column_display_sequence=>30
,p_column_heading=>'Root Key'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6864841159157520236)
,p_query_column_id=>6
,p_column_alias=>'Update Mode'
,p_column_display_sequence=>60
,p_column_heading=>'Update Mode'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6864841040682520235)
,p_query_column_id=>5
,p_column_alias=>'Used By'
,p_column_display_sequence=>50
,p_column_heading=>'Used By'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6864840770728520232)
,p_query_column_id=>2
,p_column_alias=>'View Type'
,p_column_display_sequence=>20
,p_column_heading=>'View Type'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5525511381252599008)
,p_plug_name=>'Region Display Selector'
,p_static_id=>'region-display-selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_landmark_type=>'navigation'
,p_landmark_label=>'Purchase Order Source'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp.component_end;
end;
/
