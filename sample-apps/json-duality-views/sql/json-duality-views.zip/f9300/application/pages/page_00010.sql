prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9300
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'Purchase Orders - Stacked'
,p_alias=>'PURCHASE-ORDERS-STACKED'
,p_step_title=>'Purchase Orders - Stacked'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Colorful Badges */',
'.t-Badge--COMPLETED {',
'    --ut-badge-text-color: var(--ut-badge-subtle-success-text-color, var(--a-palette-success));',
'    --ut-badge-background-color: var(--ut-badge-subtle-success-background-color, var(--a-palette-success-shade));',
'}',
'.t-Badge--REJECTED {',
'    --ut-badge-text-color: var(--ut-badge-subtle-danger-text-color, var(--a-palette-danger));',
'    --ut-badge-background-color: var(--ut-badge-subtle-danger-background-color, var(--a-palette-danger-shade));',
'}',
'.t-Badge--DRAFT {',
'    --ut-badge-text-color: var(--ut-badge-subtle-info-text-color, var(--a-palette-info));',
'    --ut-badge-background-color: var(--ut-badge-subtle-info-background-color, var(--a-palette-info-shade));',
'}'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6861233679954790536)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'duality-view-demo-region'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(5528715858987777183)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6861233899368790537)
,p_plug_name=>'Purchase Orders'
,p_static_id=>'purchase-orders-report'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>'DUALITY_VIEW'
,p_document_source_id=>wwv_flow_imp.id(5528755791817793164)
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6861233972826790537)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_internal_uid=>35489932199300093
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861234074757790539)
,p_db_column_name=>'CUSTOMER_ADDRESS'
,p_display_order=>130
,p_column_identifier=>'K'
,p_column_label=>'Customer Address'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861234156431790540)
,p_db_column_name=>'CUSTOMER_CITY'
,p_display_order=>90
,p_column_identifier=>'F'
,p_column_label=>'Customer City'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861234225711790541)
,p_db_column_name=>'CUSTOMER_COMPANY_NAME'
,p_display_order=>50
,p_column_identifier=>'N'
,p_column_label=>'Company'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861234372134790541)
,p_db_column_name=>'CUSTOMER_EMAIL'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Customer Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861234486887790541)
,p_db_column_name=>'CUSTOMER_ID'
,p_display_order=>150
,p_is_primary_key=>'Y'
,p_column_identifier=>'M'
,p_column_label=>'Customer Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861234594542790541)
,p_db_column_name=>'CUSTOMER_NAME'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'Customer Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861234608674790541)
,p_db_column_name=>'CUSTOMER_PHONE'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Customer Phone'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861234764411790541)
,p_db_column_name=>'CUSTOMER_STATE'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'Customer State'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861234835040790541)
,p_db_column_name=>'CUSTOMER_ZIP_CODE'
,p_display_order=>140
,p_column_identifier=>'L'
,p_column_label=>'Customer Zip Code'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861234916904790542)
,p_db_column_name=>'DATE'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'PO Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861235053182790542)
,p_db_column_name=>'DELIVERY_INSTRUCTIONS'
,p_display_order=>80
,p_column_identifier=>'E'
,p_column_label=>'Delivery Instructions'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861235135302790542)
,p_db_column_name=>'LAST_UPDATED'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'Last Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861235204702790542)
,p_db_column_name=>'LINE_ITEMS'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'Line Items'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861235323952790542)
,p_db_column_name=>'PO_ID'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Po Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861235424583790542)
,p_db_column_name=>'PO_NUMBER'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'PO Number'
,p_column_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_PO_ID,P6_CUSTOMER_ID:#PO_ID#,#CUSTOMER_ID#'
,p_column_linktext=>'#PO_NUMBER#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_css_classes=>'u-bold'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861235532112790543)
,p_db_column_name=>'STATUS'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>'Status'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'TMPL_THEME_42$BADGE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'LABEL', 'Status',
  'LABEL_DISPLAY', 'N',
  'SIZE', 't-Badge--sm',
  'STATE', 'STATUS',
  'STYLE', 't-Badge--subtle',
  'VALUE', 'STATUS')).to_clob
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6861235660916790543)
,p_db_column_name=>'TOTAL_AMOUNT'
,p_display_order=>70
,p_column_identifier=>'D'
,p_column_label=>'Total Amount'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6861235795250790543)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'115905'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PO_NUMBER:STATUS:DATE:LAST_UPDATED:CUSTOMER_NAME:CUSTOMER_COMPANY_NAME:CUSTOMER_CITY:CUSTOMER_ZIP_CODE:TOTAL_AMOUNT'
,p_sort_column_1=>'LAST_UPDATED'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'DATE'
,p_sort_direction_2=>'DESC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6861235958674790585)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6861233679954790536)
,p_button_name=>'CREATE'
,p_static_id=>'create-purchase-order-button'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Purchase Order'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:2'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6861236009668790585)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6861233899368790537)
,p_button_name=>'RESET_REPORT'
,p_static_id=>'reset-report'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RR'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-undo-alt'
,p_grid_new_row=>'Y'
);
wwv_flow_imp.component_end;
end;
/
