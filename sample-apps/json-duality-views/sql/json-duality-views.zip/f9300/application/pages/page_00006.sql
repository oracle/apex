prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9300
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Purchase Order &P6_PO_ID. Details'
,p_alias=>'PURCHASE-ORDER-P6-PO-ID-DETAILS'
,p_step_title=>'Purchase Order &P6_PO_ID. Details'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_read_only_when=>'P6_STATUS'
,p_read_only_when2=>'DRAFT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5558550528103233113)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(5528715858987777183)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5526080324887083154)
,p_name=>'Line Items'
,p_static_id=>'line-items-report'
,p_template=>4073835273271169698
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--horizontalBorders:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_location=>'DUALITY_VIEW'
,p_array_column_id=>wwv_flow_imp.id(5526072798953083114)
,p_document_source_id=>wwv_flow_imp.id(5528755791817793164)
,p_query_where=>'PO_ID = :P6_PO_ID and LINE_ID is not null'
,p_source_post_processing=>'WHERE_ORDER_BY_CLAUSE'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P6_PO_ID,P6_STATUS'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5526081544065083154)
,p_query_column_id=>2
,p_column_alias=>'LINE_ID'
,p_column_display_sequence=>150
,p_column_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:8:P8_PO_ID,P8_LINE_ID:#PO_ID#,#LINE_ID#'
,p_column_linktext=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P6_STATUS'
,p_display_when_condition2=>'DRAFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5526081800058083155)
,p_query_column_id=>1
,p_column_alias=>'PO_ID'
,p_column_display_sequence=>240
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5526081998973083155)
,p_query_column_id=>19
,p_column_alias=>'PRODUCT_DESC'
,p_column_display_sequence=>190
,p_column_heading=>'Product'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5526082139690083155)
,p_query_column_id=>20
,p_column_alias=>'PRODUCT_PRODUCT_CODE'
,p_column_display_sequence=>170
,p_column_heading=>'Code'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5526082382992083155)
,p_query_column_id=>17
,p_column_alias=>'QUANTITY'
,p_column_display_sequence=>200
,p_column_heading=>'Quantity'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5526082594587083155)
,p_query_column_id=>23
,p_column_alias=>'UNIT_PRICE'
,p_column_display_sequence=>210
,p_column_heading=>'Purchase Price'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5526082663737083155)
,p_query_column_id=>22
,p_column_alias=>'amount'
,p_column_display_sequence=>230
,p_column_heading=>'Amount'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5526082892763083155)
,p_name=>'Order Details'
,p_static_id=>'order-details-region'
,p_template=>4502917002193490937
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:margin-left-md'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo-label--stacked:t-ContextualInfo--hideNulls:t-Report--hideNoPagination'
,p_display_point=>'REGION_POSITION_01'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_location=>'DUALITY_VIEW'
,p_document_source_id=>wwv_flow_imp.id(5528755791817793164)
,p_query_where=>'PO_ID = :P6_PO_ID'
,p_source_post_processing=>'WHERE_ORDER_BY_CLAUSE'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P6_PO_ID'
,p_lazy_loading=>false
,p_query_row_template=>2117249020861433971
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5526082924802083155)
,p_query_column_id=>13
,p_column_alias=>'CUSTOMER_ID'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5526083093977083155)
,p_query_column_id=>2
,p_column_alias=>'DATE'
,p_column_display_sequence=>70
,p_column_heading=>'Created On'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5526083197672083155)
,p_query_column_id=>1
,p_column_alias=>'PO_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5526083223576083155)
,p_query_column_id=>3
,p_column_alias=>'PO_NUMBER'
,p_column_display_sequence=>20
,p_column_heading=>'P.O. Number'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5526083350313083155)
,p_query_column_id=>16
,p_column_alias=>'STATUS'
,p_column_display_sequence=>180
,p_column_heading=>'Status'
,p_column_css_class=>'u-textInitCap'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5526083472218083155)
,p_query_column_id=>4
,p_column_alias=>'TOTAL_AMOUNT'
,p_column_display_sequence=>60
,p_column_heading=>'Order Total'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5526082761908083155)
,p_plug_name=>'Customer'
,p_static_id=>'purchase-order-details-form'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-Region--removeHeader js-removeLandmark:margin-bottom-md'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_location=>'DUALITY_VIEW'
,p_document_source_id=>wwv_flow_imp.id(5528755791817793164)
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5526083912204083174)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5526080324887083154)
,p_button_name=>'ADD_LINE_ITEM'
,p_static_id=>'add-line-item-button'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Add'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:9:P9_PO_ID:&P6_PO_ID.'
,p_button_condition=>'P6_STATUS'
,p_button_condition2=>'DRAFT'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5526083980265083174)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(5558550528103233113)
,p_button_name=>'COMPLETE'
,p_static_id=>'complete-order-button'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Complete'
,p_button_position=>'DELETE'
,p_button_condition=>'P6_STATUS'
,p_button_condition2=>'DRAFT'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_grid_new_row=>'Y'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5526083737057083174)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(5558550528103233113)
,p_button_name=>'CREATE'
,p_static_id=>'create-purchase-order-button'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>':P6_PO_ID is null or :P6_CUSTOMER_ID is null'
,p_button_condition2=>'SQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5526083524682083174)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(5558550528103233113)
,p_button_name=>'DELETE'
,p_static_id=>'delete-purchase-order-button'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Delete'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>':P6_PO_ID is not null and :P6_CUSTOMER_ID is not null and :P6_STATUS = ''DRAFT'''
,p_button_condition2=>'SQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'Y'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5526084045019083174)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(5558550528103233113)
,p_button_name=>'REJECT'
,p_static_id=>'reject-order-button'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Reject'
,p_button_position=>'DELETE'
,p_button_condition=>'P6_STATUS'
,p_button_condition2=>'DRAFT'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_grid_new_row=>'Y'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5526083696619083174)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(5558550528103233113)
,p_button_name=>'SAVE'
,p_static_id=>'save-purchase-order-button'
,p_show_as_disabled=>false
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>':P6_PO_ID is not null and :P6_CUSTOMER_ID is not null and :P6_STATUS = ''DRAFT'''
,p_button_condition2=>'SQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'Y'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(6435027756602386)
,p_branch_action=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
,p_branch_condition_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_branch_condition=>'RELOAD'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5558539553482239212)
,p_name=>'P6_CUSTOMER_ADDRESS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_item_source_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_prompt=>'Customer Address'
,p_source=>'CUSTOMER_ADDRESS'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>32
,p_cMaxlength=>200
,p_cHeight=>3
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5558540341010239210)
,p_name=>'P6_CUSTOMER_COMPANY_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_item_source_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_prompt=>'Company Name'
,p_source=>'CUSTOMER_COMPANY_NAME'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>100
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5558538346603239215)
,p_name=>'P6_CUSTOMER_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_item_source_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_prompt=>'Email'
,p_source=>'CUSTOMER_EMAIL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>100
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'EMAIL',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5558535538166239223)
,p_name=>'P6_CUSTOMER_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_item_source_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_item_default=>'1003'
,p_source=>'CUSTOMER_ID'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5558537921354239216)
,p_name=>'P6_CUSTOMER_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_item_source_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_prompt=>'Name'
,p_source=>'CUSTOMER_NAME'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>100
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5558538697846239214)
,p_name=>'P6_CUSTOMER_PHONE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_item_source_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_prompt=>'Phone'
,p_source=>'CUSTOMER_PHONE'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEL',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5558535858915239222)
,p_name=>'P6_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_item_source_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_source=>'DATE'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_item_comment=>'date in header'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5558537129629239218)
,p_name=>'P6_DELIVERY_INSTRUCTIONS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_item_source_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_prompt=>'Delivery Instructions'
,p_source=>'DELIVERY_INSTRUCTIONS'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>500
,p_cHeight=>3
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5558535126185239224)
,p_name=>'P6_PO_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_item_source_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_source=>'PO_ID'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5558536348848239220)
,p_name=>'P6_PO_NUMBER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_item_source_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_source=>'PO_NUMBER'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5563367390090658288)
,p_name=>'P6_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_item_source_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_source=>'STATUS'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5558536750045239219)
,p_name=>'P6_TOTAL_AMOUNT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_item_source_plug_id=>wwv_flow_imp.id(5526082761908083155)
,p_source=>'TOTAL_AMOUNT'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_item_comment=>'nicer display (larger)'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5528400225004732302)
,p_name=>'Refresh Line Items/Total'
,p_static_id=>'refresh-line-items-total-da_1'
,p_event_sequence=>20
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5528400541759732305)
,p_event_id=>wwv_flow_imp.id(5528400225004732302)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-submit-page'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'request_button_name', 'RELOAD',
  'show_processing', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5526084421555083174)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(5526082761908083155)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Purchase Order'
,p_static_id=>'initialize-purchase-order'
,p_internal_uid=>3146672814051777
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5526084553341083174)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(5526082761908083155)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Purchase Order'
,p_static_id=>'process-purchase-order-details'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'prevent_lost_updates', 'Y',
  'return_primary_keys_after_insert', 'Y',
  'target_type', 'REGION_SOURCE')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'RELOAD'
,p_process_when_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_internal_uid=>3147037639051777
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5526084636392083174)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Status Completed'
,p_static_id=>'set-status-completed'
,p_process_sql_clob=>':P6_STATUS := ''COMPLETED'';'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(5526083980265083174)
,p_process_success_message=>'Purchase Order set to Completed.'
,p_internal_uid=>3164293888051788
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5526084743103083174)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Status Rejected'
,p_static_id=>'set-status-rejected'
,p_process_sql_clob=>':P6_STATUS := ''REJECTED'';'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(5526084045019083174)
,p_process_success_message=>'Purchase Order set to Rejected.'
,p_internal_uid=>3164622121051788
);
wwv_flow_imp.component_end;
end;
/
