prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 9110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9110
,p_default_id_offset=>14093677360354599
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop view emp_dept_v;'||wwv_flow.LF||
'drop table eba_demo_dg_emp;'||wwv_flow.LF||
'drop table eba_demo_dg_dept;'||wwv_flow.LF||
'--'||wwv_flow.LF||
'drop table eba_dem';
wwv_flow_imp.g_varchar2_table(2) := 'o_dg_order_items;'||wwv_flow.LF||
'drop table eba_demo_dg_orders;'||wwv_flow.LF||
'drop table eba_demo_dg_products;'||wwv_flow.LF||
'drop table eba_dem';
wwv_flow_imp.g_varchar2_table(3) := 'o_dg_customers;';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(1873880973961151598)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
);
wwv_flow_imp.component_end;
end;
/
