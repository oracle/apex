prompt --application/shared_components/user_interface/template_options
begin
--   Manifest
--     THEME OPTIONS: 42
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9110
,p_default_id_offset=>14093677360354599
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
