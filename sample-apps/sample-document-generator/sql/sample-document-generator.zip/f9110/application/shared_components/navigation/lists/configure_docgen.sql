prompt --application/shared_components/navigation/lists/configure_docgen
begin
--   Manifest
--     LIST: Configure DocGen
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9110
,p_default_id_offset=>14093677360354599
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(2629823885460051293)
,p_name=>'Configure DocGen'
,p_static_id=>'configure-docgen'
,p_version_scn=>'37167715869267'
);
wwv_flow_imp.component_end;
end;
/
