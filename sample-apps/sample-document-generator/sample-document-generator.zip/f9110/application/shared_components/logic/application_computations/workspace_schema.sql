prompt --application/shared_components/logic/application_computations/workspace_schema
begin
--   Manifest
--     APPLICATION COMPUTATION: WORKSPACE_SCHEMA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>9110
,p_default_id_offset=>14093677360354599
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(1858961441807133703)
,p_computation_sequence=>10
,p_computation_item=>'WORKSPACE_SCHEMA'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'sys_context(''USERENV'',''CURRENT_SCHEMA'')'
,p_version_scn=>41149317311489
);
wwv_flow_imp.component_end;
end;
/
