prompt --application/shared_components/logic/application_items/workspace_schema
begin
--   Manifest
--     APPLICATION ITEM: WORKSPACE_SCHEMA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>9110
,p_default_id_offset=>14093677360354599
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(1858961019542131789)
,p_name=>'WORKSPACE_SCHEMA'
,p_protection_level=>'I'
,p_version_scn=>41149316691578
);
wwv_flow_imp.component_end;
end;
/
