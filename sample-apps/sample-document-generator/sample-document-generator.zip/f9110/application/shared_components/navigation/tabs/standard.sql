prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 9110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9110
,p_default_id_offset=>36426266025113707
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
