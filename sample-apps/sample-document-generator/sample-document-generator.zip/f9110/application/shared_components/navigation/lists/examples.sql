prompt --application/shared_components/navigation/lists/examples
begin
--   Manifest
--     LIST: Examples
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9110
,p_default_id_offset=>36426266025113707
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1861285162382413101)
,p_name=>'Examples'
,p_list_status=>'PUBLIC'
,p_version_scn=>37167715869267
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1861285440360413103)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Customer Order'
,p_list_text_01=>'A purchase order form, based on the Order / Order Item Sample Data Set.'
,p_list_text_02=>'document-screenshots/customer-order.png'
,p_list_text_03=>'templates/customer-order.docx'
,p_list_text_04=>'ORDER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1861285799166413104)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Employee Overview'
,p_list_text_01=>'A report with a table containing employee details.'
,p_list_text_02=>'document-screenshots/employees.png'
,p_list_text_03=>'templates/employees.docx'
,p_list_text_04=>'EMPLOYEES'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1844882638547019000)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Employees Per Department'
,p_list_text_01=>'A report with employees per department per page.'
,p_list_text_02=>'document-screenshots/emp_per_dept.png'
,p_list_text_03=>'templates/emp_per_dept.docx'
,p_list_text_04=>'EMP_PER_DEPT'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
