prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 9110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>9110
,p_default_id_offset=>1800742893178832216
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(1823361030575683292)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop view emp_dept_v;',
'drop table eba_demo_dg_emp;',
'drop table eba_demo_dg_dept;',
'--',
'drop table eba_demo_dg_order_items;',
'drop table eba_demo_dg_orders;',
'drop table eba_demo_dg_products;',
'drop table eba_demo_dg_customers;'))
);
wwv_flow_imp.component_end;
end;
/
