prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 9110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>9110
,p_default_id_offset=>36426266025113707
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(1859787296600796999)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop view emp_dept_v;',
'drop table eba_demo_dg_emp;',
'drop table eba_demo_dg_dept;',
'--',
'drop table eba_demo_dg_order_items;',
'drop table eba_demo_dg_orders;',
'drop table eba_demo_dg_products;',
'drop table eba_demo_dg_customers;'))
);
wwv_flow_imp.component_end;
end;
/
